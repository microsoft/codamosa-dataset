

# Generated at 2022-06-22 03:28:20.051770
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("    a    b    c    ") == "a b c"
    assert squeeze("    a    b    c    ") != "a b c "
    assert squeeze("") == ""
    assert squeeze("abc") == "abc"
    assert squeeze("   ") == ""
    assert squeeze("\n a \nb \t \tc \r\n") == "\n a \nb \t \tc \r\n"



# Generated at 2022-06-22 03:28:23.683248
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_input = "a=1&b=2&c=3"
    parsed = parse_qs_bytes(test_input)
    assert parsed == {
        b"a": [b"1"],
        b"b": [b"2"],
        b"c": [b"3"]
    }



# Generated at 2022-06-22 03:28:33.293997
# Unit test for function json_decode
def test_json_decode():
    assert json_decode(b'{"a": "b"}') == dict(a="b")
    assert json_decode('{"a": "b"}') == dict(a="b")
    assert json_decode(b'{"a": 1}') == dict(a=1)
    assert json_decode('{"a": 1}') == dict(a=1)
    assert json_decode(b'[1, 2, 3]') == [1, 2, 3]
    assert json_decode('[1, 2, 3]') == [1, 2, 3]
    assert json_decode(b'"a"') == "a"
    assert json_decode('"a"') == "a"
    assert json_decode(b'"a"') == "a"

# Generated at 2022-06-22 03:28:39.648916
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#201;') == 'É'
    assert xhtml_unescape('&amp;#201;') == '&#201;'
    assert xhtml_unescape('&copy;') == '©'
    assert xhtml_unescape('&aacute;') == 'á'
test_xhtml_unescape()


# Generated at 2022-06-22 03:28:42.210107
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("test") == "%27test%27"
    assert url_escape("test", plus=False) == "test"


# Generated at 2022-06-22 03:28:45.803951
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<>"\'&') == '&lt;&gt;&quot;&#39;&amp;'


# xhtml_unescape's behavior is somewhat controversial so we'll implement
# it here, but not expose it at the module level.

# Generated at 2022-06-22 03:28:57.880756
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == u""
    assert linkify(u"") == u""
    assert linkify(u"foo bar") == u"foo bar"
    assert linkify(u"http://www.example.com") == u'<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify(u"http://foo.com/blah_blah") == u'<a href="http://foo.com/blah_blah">http://foo.com/blah_blah</a>'
    assert linkify(u"http://foo.com/blah_blah/") == u'<a href="http://foo.com/blah_blah/">http://foo.com/blah_blah/</a>'

# Generated at 2022-06-22 03:29:03.271559
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_dict = parse_qs_bytes(b'k1=v1&k2=v2&k2=v2&k1=v1&k1=v1', True)
    assert test_dict == {'k1': [b'v1', b'v1', b'v1'], 'k2': [b'v2', b'v2']}


# Generated at 2022-06-22 03:29:09.664025
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a b     c') == 'a b c'
    assert squeeze(' a b     c') == 'a b c'
    assert squeeze('      a b     c') == 'a b c'
    assert squeeze('      a b     c      ') == 'a b c'
    assert squeeze('a \nb     c') == 'a b c'



# Generated at 2022-06-22 03:29:21.083890
# Unit test for function linkify
def test_linkify():
    assert linkify("text") == "text"
    assert linkify("http://example.com") == """\
<a href="http://example.com">http://example.com</a>"""
    assert linkify("http://example.com/foo") == """\
<a href="http://example.com/foo">http://example.com/foo</a>"""
    assert linkify(
        "http://tornadoweb.org", extra_params='rel="nofollow" class="external"'
    ) == """\
<a href="http://tornadoweb.org" rel="nofollow" class="external">\
http://tornadoweb.org</a>"""

# Generated at 2022-06-22 03:29:42.876099
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("a=1&b=2") == {"a": [b"1"], "b": [b"2"]}
    assert parse_qs_bytes("a=1") == {"a": [b"1"]}
    assert parse_qs_bytes("a=1&b=2&a=3") == {"a": [b"1", b"3"], "b": [b"2"]}
    assert parse_qs_bytes("a=1&b=2&a=3", keep_blank_values=True) == {"a": [b"1", b"3"], "b": [b"2"]}

# Generated at 2022-06-22 03:29:55.454134
# Unit test for function linkify

# Generated at 2022-06-22 03:29:59.414843
# Unit test for function json_decode
def test_json_decode():
    data = {"a":1, "b":2}
    assert json_decode(json.dumps(data)) == data
    assert json_decode(bytes(json.dumps(data), "utf-8")) == data



# Generated at 2022-06-22 03:30:09.421991
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query = parse_qs_bytes(b'a=1&b=2')
    assert query == {'a': [b'1'], 'b': [b'2']}

test_parse_qs_bytes()

_BASESTRING_TYPES = (bytes, str)
_NUMBER_TYPES = (int, float)
_ALLOWED_TYPES = _BASESTRING_TYPES + _NUMBER_TYPES

if typing.TYPE_CHECKING:
    # typing not currently supported by mypy (see
    # https://github.com/python/mypy/issues/2712), so we have to suppress
    # the error to make this import work.
    # noinspection PyUnresolvedReferences
    from typing import Type
    _NumberTypes = typing.Type[float]

# Generated at 2022-06-22 03:30:17.271780
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": 1}) == '{"a": 1}'
    assert json_encode({"a": "</script>"}) == '{"a": "<\\/script>"}'
    assert json_encode({"a": ["</script>"]}) == '{"a": ["<\\/script>"]}'
    assert json_encode({"a": ["</script>", {"b": 1}]}) == '{"a": ["<\\/script>", {"b": 1}]}'



# Generated at 2022-06-22 03:30:19.276933
# Unit test for function utf8
def test_utf8():
    assert utf8(u'foo') == b'foo'



# Generated at 2022-06-22 03:30:23.010104
# Unit test for function native_str
def test_native_str():
    assert native_str(b"abc") == "abc"
    assert native_str(u"abc") == "abc"
    assert isinstance(native_str(b"abc"), str)
    assert isinstance(native_str(u"abc"), str)



# Generated at 2022-06-22 03:30:28.129936
# Unit test for function json_encode
def test_json_encode():
    test_json = dict(name="name", age=18)

# Generated at 2022-06-22 03:30:34.197735
# Unit test for function utf8
def test_utf8():
    t = utf8("hello")
    assert isinstance(t, bytes)
    t = utf8(t)
    assert isinstance(t, bytes)
    t = utf8(None)
    assert t is None
    t = utf8(123)
    assert isinstance(t, int)

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:30:41.800272
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<script>') == '&lt;script&gt;'
    assert xhtml_escape('"') == '&quot;'
    assert xhtml_escape("'") == '&#39;'

_XHTML_UNESCAPE_ENTITY_RE = re.compile("&(#?)(\d{1,5}|\w{1,8});")



# Generated at 2022-06-22 03:30:53.929089
# Unit test for function recursive_unicode
def test_recursive_unicode():
    recursive_unicode({
        b'foo': 123,
        'bar': [b'des', b'neu', b'fra'],
        'baz': {
            123: {b'des': 'german', b'fra': 'french', b'ita': 'italian'},
            b'other': {'number': 1337},
            'foo': b'bar',
        },
    },)

_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-22 03:30:55.184911
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=b&c=d") == {"a": [b"b"], "c": [b"d"]}




# Generated at 2022-06-22 03:30:56.805700
# Unit test for function json_encode
def test_json_encode():
    value = 5
    expected = '5'
    assert json_encode(value)== expected
    
    

# Generated at 2022-06-22 03:31:08.207144
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(u'f"oo') == 'f&quot;oo'


_JSON_ESCAPE_RE = re.compile(r"[&<>\"\x00-\x1f]")

# Generated at 2022-06-22 03:31:20.141644
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('x') == 'x'
    assert url_unescape('%%') == '%%'
    assert url_unescape('') == ''

    # The source string is one character beyond the ASCII range (u"\u0130")
    # The string '\xC4\xB0' is the UTF-8 representation of that character.
    assert url_unescape('%C4%B0', encoding="utf-8") == u"\u0130"
    with pytest.raises(UnicodeDecodeError):
        # Test that the function raises the appropriate exception when
        # the encoding is incorrect.
        url_unescape('%C4%B0', encoding="ascii")

# Generated at 2022-06-22 03:31:32.403046
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;hello&gt;") == "<hello>"
    assert xhtml_unescape("&lt;hello&gt;&amp;&quot;&#39;") == "<hello>&\"'"


# json_encode, json_decode moved to escape.py to avoid circular import
# issues, so don't use @native_strs here.
_BASESTRING_TYPES = str, bytes, bytearray  # noqa
if hasattr(__builtins__, "unicode"):  # noqa
    _BASESTRING_TYPES += __builtins__.unicode,  # type: ignore

_TO_UNICODE_TYPES = (bytes, type(None))  # type: typing.Tuple
_NATIVE_STRING_TYPES

# Generated at 2022-06-22 03:31:41.105090
# Unit test for function json_encode
def test_json_encode():
    print(json_encode("</"))

# json_encode defaults to allowing non-ASCII characters, which
# means it may not be safe to embed such data in an HTML
# <script> tag.  If you know the data is safe to embed, you
# can pass ensure_ascii=False to be more efficient.  Note that
# this is **not** secure unless you know the data is safe.
# It's up to you to do the necessary validation.

# Generated at 2022-06-22 03:31:43.474301
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    a = parse_qs_bytes('name=value')
    assert a['name'] == [b'value']


# Generated at 2022-06-22 03:31:48.062858
# Unit test for function url_escape
def test_url_escape():
    expected = "http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26blah%3Ddingus"
    testurl = "http://example.com/?foo=bar&blah=dingus"
    result = url_escape(testurl, True)
    assert result == expected, "Tornado's url_escape() failed"
test_url_escape()



# Generated at 2022-06-22 03:31:52.713420
# Unit test for function json_decode
def test_json_decode():
    s_dict = {'ss': 'ss'}
    s_dict_str = str(s_dict)
    json_dict = json_decode(s_dict_str)
    assert json_dict == s_dict


# Generated at 2022-06-22 03:32:10.037421
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
  assert '&#44;' == xhtml_unescape('&amp;#44;')
  assert '&#44;' == xhtml_unescape('&#x26;#44;')
  assert '&#44;' == xhtml_unescape('&#X26;#44;')
  assert '&#44;' == xhtml_unescape('&#X26;#044;')
  assert '&#44;' == xhtml_unescape('&#x26;#x2c;')
  assert '&#44;' == xhtml_unescape('&#x26;#x02c;')
  assert '&#44;' == xhtml_unescape('&#x26;#X2C;')

# Generated at 2022-06-22 03:32:14.871456
# Unit test for function url_unescape
def test_url_unescape():
    value = '%E6%8A%95%E5%BD%B1%E6%8A%95%E5%BD%B1%E6%8A%95%E5%BD%B1'
    value = tornado.escape.url_unescape(value, encoding=None)
    print(value)


# Generated at 2022-06-22 03:32:23.909483
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    extra_params = "rel='nofollow' class='external'"
    actual = linkify(text, extra_params=extra_params)
    expected = u'Hello <a href="http://tornadoweb.org" rel=\'nofollow\' class=\'external\'>http://tornadoweb.org</a>!'
    assert actual == expected
    pass

# Test cases
if __name__ == '__main__':
    test_linkify()
    pass

# Generated at 2022-06-22 03:32:25.106164
# Unit test for function native_str
def test_native_str():
    assert utf8("foo") == b"foo"


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-22 03:32:29.086975
# Unit test for function json_decode
def test_json_decode():
    # Using the json.decode example
    print(json_decode('{"one" : "1", "two" : "2", "three" : "3"}'))
    print(json_decode('{"one" : "1", "two" : "2", "three" : "3"}'))



# Generated at 2022-06-22 03:32:32.567838
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8("abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\u00E9") == b"\xC3\xA9"



# Generated at 2022-06-22 03:32:38.988670
# Unit test for function utf8
def test_utf8():
    assert utf8('foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8(unicode_type('foo')) == b'foo'
    assert utf8(b'foo') == b'foo'
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:32:44.347129
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    data = parse_qs_bytes(b'x=1&y=2&y=3')
    assert isinstance(data['x'][0], bytes)
    assert data['x'][0] == b'1'
    assert isinstance(data['y'], list)
    assert isinstance(data['y'][0], bytes)
    assert data['y'][0] == b'2'
    assert isinstance(data['y'][1], bytes)
    assert data['y'][1] == b'3'



# Generated at 2022-06-22 03:32:45.783123
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("b   d   f    ") == "b d f"


# Generated at 2022-06-22 03:32:50.131340
# Unit test for function linkify
def test_linkify():
    text="I love Tornado http://tornadoweb.org"
    res=linkify(text)
    print(res)
if __name__=="__main__":
    test_linkify()

# Generated at 2022-06-22 03:32:57.708355
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("hello") == 'hello'
    assert url_unescape("hello", "utf-8") == 'hello'



# Generated at 2022-06-22 03:33:08.859135
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1') == {b'a': [b'1']}
    assert parse_qs_bytes(b'a=1&a=2') == {b'a': [b'1', b'2']}
    assert parse_qs_bytes(b'a=1&b=2&a=3', keep_blank_values=True) == {b'a': [b'1', b'3'], b'b': [b'2']}
    assert parse_qs_bytes(b'a=1&b=2&a=3', keep_blank_values=True, strict_parsing=True) == {b'a': [b'1', b'3'], b'b': [b'2']}

# Generated at 2022-06-22 03:33:13.042428
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'd=a&d=b') == {'d': [b'a', b'b']}
    assert parse_qs_bytes(b'b=a&b=b') == {'b': [b'a', b'b']}



# Generated at 2022-06-22 03:33:19.773726
# Unit test for function json_decode
def test_json_decode():
    if isinstance(json_decode("{'a':1}"), dict):
        return 1
    else:
        return 0

# end of test #


# Obsolete aliases that used to be exposed at top level.
# Please do not use these in new code.
utf8 = _utf8
_unicode = _utf8
_bytes = bytes
escape = xhtml_escape
unescape = xhtml_unescape



# Generated at 2022-06-22 03:33:25.092490
# Unit test for function native_str
def test_native_str():
    assert native_str("s") == b"s"
    assert native_str("") == b""
    assert native_str("\u00fc") == "\u00fc".encode("utf-8")
    assert native_str("\u00fc".encode("utf-8")) == "\u00fc".encode("utf-8")

# Generated at 2022-06-22 03:33:37.168960
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;') == "<"
    assert xhtml_unescape('&#60;') == "<"
    assert xhtml_unescape('&#060;') == "<"
    assert xhtml_unescape('&#0060;') == "<"
    assert xhtml_unescape('&#00060;') == "<"
    assert xhtml_unescape('&#000060;') == "<"
    assert xhtml_unescape('&#0000060;') == "<"
    assert xhtml_unescape('&#60;') == "<"
    assert xhtml_unescape('&#060;') == "<"
    assert xhtml_unescape('&#0060;') == "<"
    assert xhtml_unescape('&#00060;') == "<"
    assert xhtml_unescape

# Generated at 2022-06-22 03:33:38.939294
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div>") == "&lt;div&gt;"


# Generated at 2022-06-22 03:33:41.466660
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&a;") == "&a;"
    assert xhtml_unescape("&quot;"), '"'


# Generated at 2022-06-22 03:33:43.607472
# Unit test for function utf8
def test_utf8():
    a = utf8(None)
    assert a is None


_to_basestring_types = (bytes, str, type(None))



# Generated at 2022-06-22 03:33:52.909141
# Unit test for function linkify
def test_linkify():
    text = '''This is a tornado.org link http://www.tornadoweb.org/
    This is a mailto link mailto:test@test.com
    This is a google link www.google.com
    This is another link http://www.example.com/'''
    print(linkify(text))

test_linkify()

# linkify(text[, shorten=False][, extra_params=''][, require_protocol=True])
# use with function/class : get_link(self, key, shorten=True, extra_params='target="_blank"'):


# Generated at 2022-06-22 03:34:00.323551
# Unit test for function squeeze
def test_squeeze():
    if squeeze("123") != "123":
        raise RuntimeError
    if squeeze("1  2  3  4  5") != "1 2 3 4 5":
        raise RuntimeError



# Generated at 2022-06-22 03:34:11.196266
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'key': b"value"}) == {'key': 'value'}
    assert recursive_unicode({'key': b"value"}, key='value') == {'key': 'value'}
test_recursive_unicode()          

# Non-ASCII characters that we treat as whitespace for the purpose of
# word splitting. The characters are taken from the Unicode category
# "Separator, Space" (Zs).
# http://www.unicode.org/Public/4.0-Update/UnicodeData-4.0.0.txt

# Generated at 2022-06-22 03:34:16.249657
# Unit test for function json_decode
def test_json_decode():
    assert isinstance(json_decode("{\"test\": 1}"), dict)
    assert json_decode("{\"test\": 1}").get("test") == 1
    assert isinstance(json_decode("[1,2,3]"), list)
    assert json_decode("[1,2,3]") == [1,2,3]
    assert json_decode(" 1 ") == 1


# Generated at 2022-06-22 03:34:28.018769
# Unit test for function linkify
def test_linkify():
    src_text = "Hello http://www.google.com/ and www.zombo.com!"
    html_text = linkify(src_text)
    assert html_text == "Hello <a href=\"http://www.google.com/\">http://www.google.com/</a> and <a href=\"http://www.zombo.com\">www.zombo.com</a>!"
    html_text = linkify(src_text, extra_params='rel="nofollow" class="external"')
    assert html_text == "Hello <a href=\"http://www.google.com/\" rel=\"nofollow\" class=\"external\">http://www.google.com/</a> and <a href=\"http://www.zombo.com\" rel=\"nofollow\" class=\"external\">www.zombo.com</a>!"


# Generated at 2022-06-22 03:34:35.639312
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([b'a', b'b', [b'c', (b'd', b'e')], b'f']) ==\
           ['a', 'b', ['c', ('d', 'e')], 'f']
    assert recursive_unicode({b'a' : b'b', b'c': {b'd':b'e'}}) ==\
           {'a':'b', 'c': {'d':'e'}}
test_recursive_unicode()

# aliases
escape = utf8
squeeze = squeeze
url_escape = url_escape
recursive_unicode = recursive_unicode



# Generated at 2022-06-22 03:34:47.090731
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2") == {b"a": [b"1"], b"b": [b"2"]}
test_parse_qs_bytes()



# Generated at 2022-06-22 03:34:49.062258
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert "&amp;&lt;&gt;&quot;&#39;" == xhtml_escape("&<>\"'")


# Generated at 2022-06-22 03:34:51.228919
# Unit test for function native_str
def test_native_str():
    x = '\u0394'
    y = native_str(x)
    assert isinstance(y, str)



# Generated at 2022-06-22 03:34:53.147141
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://www.baidu.com") == "http%3A%2F%2Fwww.baidu.com"


# Generated at 2022-06-22 03:34:58.830873
# Unit test for function native_str
def test_native_str():
    assert native_str(u"x") == "x"
    assert native_str("x") == "x"
    assert native_str(b"x") == "x"
    assert native_str(1) == "1"
    assert callable(native_str(lambda: None))



# Generated at 2022-06-22 03:35:06.487540
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("""/你好""") == """/%E4%BD%A0%E5%A5%BD"""


# Generated at 2022-06-22 03:35:07.714990
# Unit test for function json_decode
def test_json_decode():
    json_decode('{"a": "b", "c": 3}')



# Generated at 2022-06-22 03:35:11.748380
# Unit test for function linkify
def test_linkify():
    url = 'www.baidu.com'
    new_url = linkify(url)
    assert ('<a href="http://www.baidu.com">www.baidu.com</a>') == new_url

# Generated at 2022-06-22 03:35:17.818733
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('hello world') == 'hello+world'
    assert url_escape('hello world', plus=False) == 'hello%20world'
    assert url_escape('?foo=bar%20baz') == '%3Ffoo%3Dbar%2Bbaz'



# Generated at 2022-06-22 03:35:20.251415
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"foo") == u"foo"
    assert recursive_unicode({"foo": b"bar"}) == {u"foo": u"bar"}



# Generated at 2022-06-22 03:35:24.833830
# Unit test for function native_str
def test_native_str():
    assert native_str(None) is None
    assert native_str('foo') == 'foo'
    native_str(u'\u00f6') == '\xc3\xb6'
    
    

if str is bytes:
    native_str = to_unicode
else:
    native_str = utf8



# Generated at 2022-06-22 03:35:35.106979
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(u"a%20b%2Bc", plus=True) == u"a b+c"
    assert url_unescape(u"a%20b%2Bc", plus=False) == u"a b+c"
    assert url_unescape(u"a%20b%2Bc", plus=True, encoding='ascii') == u"a b+c"
    assert url_unescape(u"a%20b%2Bc", plus=False, encoding='ascii') == u"a b+c"
    assert url_unescape(b"a%20b%2Bc", encoding=None, plus=True) == b"a b c"

# Generated at 2022-06-22 03:35:47.646859
# Unit test for function recursive_unicode
def test_recursive_unicode():
    string = '\u20ac'
    testlist = [string, '€']
    testdict = {'euro':string, 'key':'value'}
    testtuple = ('tuple', string, 'tuple2')
    if 1:
        assert recursive_unicode(testlist) == [*map(to_unicode, testlist)]
        assert recursive_unicode(testdict) == {k: to_unicode(v) for k, v in testdict.items()}
        assert recursive_unicode(testtuple) == tuple(map(to_unicode, testtuple))
    if 1:
        assert recursive_unicode(string) == string
        assert recursive_unicode('string') == 'string'
        assert recursive_unicode(123) == 123
        assert recursive_unicode(123.123) == 123

# Generated at 2022-06-22 03:35:57.133462
# Unit test for function json_encode
def test_json_encode():
    import json
    import tornado.escape
    def check(input_, expected_output):
        actual_output = json.dumps(input_)
        if actual_output != expected_output:
            print(actual_output)
    check({}, '{}')
    check({"a": 1}, '{"a": 1}')
    check([1], '[1]')
    check([1, 2], '[1, 2]')
    check([1, "2"], '[1, "2"]')
    check([1, {"a": "3"}], '[1, {"a": "3"}]')
    check([1, {"a": "</script>"}], '[1, {"a": "<\\/script>"}]')
test_json_encode()

# The fact that json_decode wraps json.loads is an implementation detail.

# Generated at 2022-06-22 03:36:09.187407
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
    print(linkify("Hello http://www.tornadoweb.org!"))

    print(linkify("Hello mysite.com!"))
    print(linkify("Hello www.mysite.com!"))
    print(linkify("Hello http://mysite.com!"))
    print(linkify("Hello http://www.mysite.com!"))

    print(linkify("Hello https://mysite.com!"))
    print(linkify("Hello https://www.mysite.com!"))
    print(linkify("Hello ftp://mysite.com!"))
    print(linkify("Hello ftp://www.mysite.com!"))

    print(linkify("Hello mailto:user@mysite.com!"))

# Generated at 2022-06-22 03:36:26.008443
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("foo")==b"foo"

# Generated at 2022-06-22 03:36:33.376292
# Unit test for function url_escape
def test_url_escape():
    # parameter value is str
    plus: bool = True
    value: str = 'http://www.baidu.com/'
    encoded_value: str = url_escape(value, plus)
    assert isinstance(encoded_value, str)
    # parameter value is bytes
    plus = False
    value: bytes = b'http://www.baidu.com/'
    encoded_value: str = url_escape(value, plus)
    assert isinstance(encoded_value, str)



# Generated at 2022-06-22 03:36:40.402981
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('123') == '123'
    assert xhtml_escape('hello') == 'hello'
    assert xhtml_escape('&') == '&amp;'
    assert xhtml_escape('<') == '&lt;'
    assert xhtml_escape('>') == '&gt;'
    assert xhtml_escape('"') == '&quot;'
    assert xhtml_escape("'") == '&#39;'
test_xhtml_escape()



# Generated at 2022-06-22 03:36:50.722892
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp; &lt; &gt; &quot; &#39;') == "& < > \" '"
    assert xhtml_unescape('&#3&#9&#3&#9; &#x3&#x9; &#x3&#x9') == '&#3&#9&#3&#9; &#x3&#x9; &#x3&#x9'
    assert xhtml_unescape('&#x3&#x9;&#x3&#x9;&#x3&#x9;') == '&#x3&#x9;&#x3&#x9;&#x3&#x9;'

# Generated at 2022-06-22 03:36:57.739334
# Unit test for function native_str
def test_native_str():
    assert native_str('hello') == 'hello'
    assert native_str(u'你好') == '你好'
    assert native_str(b'\xe4\xbd\xa0\xe5\xa5\xbd') == '你好'
    assert native_str(b'\xe4\xbd\xa0\xe5\xa5\xbd', encoding='utf-8') == '你好'
    assert native_str(b'\xe4\xbd\xa0\xe5\xa5\xbd', encoding='gbk') == u'你好'
    assert native_str(b'\xe4\xbd\xa0\xe5\xa5\xbd', encoding='utf-8', errors='ignore') == '你好'
    assert native

# Generated at 2022-06-22 03:36:59.864603
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("1") == 1
    assert json_decode("{\"k\":\"v\"}") == {"k":"v"}


# Generated at 2022-06-22 03:37:09.827471
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"foo=bar") == {"foo": [b"bar"]}
    assert parse_qs_bytes(b"foo=bar&foo=baz") == {"foo": [b"bar", b"baz"]}
    assert parse_qs_bytes(b"foo=bar&bar=baz") == {"foo": [b"bar"], "bar": [b"baz"]}
    assert parse_qs_bytes(b"foo=bar&baz") == {"foo": [b"bar"], "baz": [b""]}
    assert parse_qs_bytes(b"foo&bar") == {"foo": [b""], "bar": [b""]}

# Generated at 2022-06-22 03:37:18.591418
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"name=Bob&age=30") == {b'name': [b'Bob'], b'age': [b'30']}

test_parse_qs_bytes()

# This singleton "dummy" object is used as a stand-in for functions that
# have been removed from this module.  We still need it for backwards
# compatibility with code that used to import it from here.
_MISSING = object()

# These replacements are ordered by decreasing likelihood of occurrence
# in incorrectly escaped data, to avoid false positives.
_BASIC_ESCAPE = re.compile(r"[&<>\"]")
_BASIC_UNESCAPE = _BASIC_ESCAPE.sub


# Generated at 2022-06-22 03:37:30.942175
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=bar&foo=baz&blah=%20') == {b'foo':[b'bar',b'baz'], b'blah':[b' ']}
    assert parse_qs_bytes(b'foo=bar&foo=baz&blah=%20', keep_blank_values=False) == {b'foo':[b'bar',b'baz']}
    assert parse_qs_bytes(b'foo=bar&foo=baz&blah=%20', strict_parsing=False) == {b'foo':[b'bar',b'baz'], b'blah':[b'%20']}

# Generated at 2022-06-22 03:37:32.551885
# Unit test for function recursive_unicode
def test_recursive_unicode():
    if isinstance({}, dict):
        print("yes")

# Generated at 2022-06-22 03:37:54.559042
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("foo@bar.com") == "foo%40bar.com"
    assert url_escape(r"/a b c/") == "%2Fa%20b%20c%2F"
    assert url_escape(r"/a b c/", plus=False) == "%2Fa+b+c%2F"
    assert url_escape(u"\u00a2") == "%C2%A2"
    assert url_escape(u"\u3042") == "%E3%81%82"

