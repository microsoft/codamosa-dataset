

# Generated at 2022-06-22 03:28:24.434397
# Unit test for function json_decode
def test_json_decode():
    result = json_decode('{"a":1}')
    assert result == {'a': 1}


# Generated at 2022-06-22 03:28:30.177194
# Unit test for function utf8
def test_utf8():
    assert b'foo' == utf8('foo')
    assert b'' == utf8('')
    assert b'\xc3\xa9' == utf8('\u00e9')
    assert None is utf8(None)
    try:
        utf8(object())
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:28:42.839270
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a+b", plus=False) == b"a+b"
    assert url_unescape(b"a+b", plus=True) == b"a b"
    assert url_unescape(b"a%20b", plus=True) == b"a b"
    assert url_unescape(b"a%2Bb", plus=False) == b"a+b"
    assert url_unescape(b"a+b", encoding=None, plus=False) == b"a+b"
    assert url_unescape(b"a+b", encoding=None, plus=True) == b"a b"
    assert url_unescape(b"a%2Bb", encoding=None, plus=False) == b"a%2Bb"

# Generated at 2022-06-22 03:28:46.639816
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"asdsd%23", plus=False) == "asdsd#"
    assert url_unescape("asdsd%23", plus=False) == "asdsd#"
# End unit test for function url_unescape


# Generated at 2022-06-22 03:28:50.642916
# Unit test for function squeeze
def test_squeeze():
    rst = squeeze("  abc  def  g\th")
    assert rst == "abc def g h"



# Generated at 2022-06-22 03:28:56.063107
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&gt;') == '>'


# to_unicode was previously recommended for escaping strings before
# writing them to JSON.  Use json_encode instead.
to_unicode = json_decode



# Generated at 2022-06-22 03:29:01.489756
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # test single-value queries
    assert parse_qs_bytes("x=1") == {"x": [b"1"]}
    assert parse_qs_bytes("x=1", strict_parsing=True) == {"x": [b"1"]}
    assert parse_qs_bytes("x=1", keep_blank_values=True) == {"x": [b"1"]}
    assert parse_qs_bytes("x=1", keep_blank_values=True, strict_parsing=True) == {"x": [b"1"]}
    assert parse_qs_bytes(b"x=1") == {"x": [b"1"]}
    assert parse_qs_bytes(b"x=1", strict_parsing=True) == {"x": [b"1"]}

# Generated at 2022-06-22 03:29:04.518582
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query = b'foo=%c3%b6&bar=val%3D1+val%3D2+val%3D3'
    result = parse_qs_bytes(query)
    assert result == {'foo': [_u(b'\xc3\xb6')], 'bar': [_u(b'val=1 val=2 val=3')]}
# End of test



# Generated at 2022-06-22 03:29:16.433620
# Unit test for function linkify
def test_linkify():
    assert linkify("http://google.com") == '<a href="http://google.com">http://google.com</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("www.google.com", require_protocol=True) == 'www.google.com'
    assert linkify(
        "http://google.com", extra_params=" rel='nofollow'"
    ) == "<a href='http://google.com' rel='nofollow'>http://google.com</a>"

# Generated at 2022-06-22 03:29:26.035846
# Unit test for function utf8
def test_utf8():
    assert utf8('hi') == b'hi'
    assert utf8(b'hi') == b'hi'
    assert utf8('hé') == b'h\xc3\xa9'
    assert utf8(u'hé') == b'h\xc3\xa9'
    assert utf8(None) == None
    assert utf8(1) == None
    assert utf8('1') == None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:46.032249
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test = 'a=%E4%BA%AC%E4%B8%9C&b=1'
    d = parse_qs_bytes(test)
    assert d == {"a": [b"\xE4\xBA\xAC\xE4\xB8\x9C"], "b": [b"1"]}
    assert d.get("a") == [b"\xE4\xBA\xAC\xE4\xB8\x9C"]
    assert d.get("a")[0] == b"\xE4\xBA\xAC\xE4\xB8\x9C"

# Generated at 2022-06-22 03:29:53.950967
# Unit test for function json_decode
def test_json_decode():
    def assert_decode(s: str,result: Any) -> None:
        assert json_decode(s) == result
    assert_decode("1",1)
    assert_decode('"abc"','abc')
    assert_decode('[1,"abc"]',[1,"abc"])
    assert_decode('{"a":1,"b":"abc"}',{"a":1,"b":"abc"})


# Generated at 2022-06-22 03:30:00.347680
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('http%3A%2F%2Fwww%2Ezhihu%2Ecom%2Fquestion%2F11837625')=='http://www.zhihu.com/question/11837625'
    assert url_unescape('http://www.zhihu.com/question/11837625',encoding=None)==b'http://www.zhihu.com/question/11837625'


# Generated at 2022-06-22 03:30:05.893569
# Unit test for function url_escape
def test_url_escape():
    # 定义一个文件路径
    path = "/Users/didi/Github/PycharmProjects/Tornado/test"
    print("path:" + path)
    # 将 \ 转为 %2F
    print("url_escape: " + url_escape(path))



# Generated at 2022-06-22 03:30:12.201967
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'%0A') == b'\n'
    assert url_unescape('%0A') == '\n'
    assert url_unescape(b'%0A', encoding=None) == b'\n'
    assert url_unescape(b'%0A', plus=False) == b'\n'
    assert url_unescape('%0A', plus=False) == '\n'
    assert url_unescape(b'%0A', encoding=None, plus=False) == b'\n'



# Generated at 2022-06-22 03:30:16.653671
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    # type: () -> None
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#26;") == "&"
    assert xhtml_unescape("&#x26;") == "&"
    assert xhtml_unescape("&nbsp;") == " "



# Generated at 2022-06-22 03:30:24.270177
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape("&amp;&lt;&gt;&quot;&#39;") == "&amp;&lt;&gt;&quot;&#39;"
    assert (xhtml_escape("&amp;&lt;&gt;&quot;&#39;", True) ==
            "&amp;&lt;&gt;&quot;&#39;")

# Get the Python version of the _to_basestring function

# Generated at 2022-06-22 03:30:32.277753
# Unit test for function json_decode
def test_json_decode():
    a = "{\"key\":[\"value\"]}"
    b = json_decode(a)
    c = b['key'][0]
    assert c == "value"

# json_decode's docstring is copied from tornado.escape.


# to_unicode is copied from tornado.escape.  This function is not used in
# tornado itself anymore (it's been moved to torndb), but we need it
# to make our own tools work without requireing extra installation.

# Generated at 2022-06-22 03:30:44.795100
# Unit test for function linkify
def test_linkify():
    text = linkify("Hello http://tornadoweb.org!")
    assert text == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    text = linkify("Hello http://tornadoweb.org! And this is my twitter https://twitter.com/xeeros")
    assert text == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>! And this is my twitter <a href=\"https://twitter.com/xeeros\">https://twitter.com/xeeros</a>"


# Match an html tag of the form <foo bar="baz"> or <foo>
_HTML_TAG_RE = re.compile(r"</?\w+(?: +\w+=\"[^\"]*\"|) *>")



# Generated at 2022-06-22 03:30:52.716461
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'x=y') == {b'x': [b'y']}
    assert parse_qs_bytes(b'x=%20') == {b'x': [b' ']}
    assert parse_qs_bytes(b'x=%2B') == {b'x': [b'+']}
    assert parse_qs_bytes(b'x=+') == {b'x': [b'+']}
    assert parse_qs_bytes(b'x=%2b') == {b'x': [b'+']}
    assert parse_qs_bytes(b'x=+%2B+') == {b'x': [b'+ +']}

# Generated at 2022-06-22 03:31:13.266710
# Unit test for function json_decode
def test_json_decode():
    json_decode(b"a")
    json_decode(b'{"a": 1}')
    json_decode('a')
    json_decode('{"a": 1}')
    try:
        json_decode({})
    except TypeError:
        pass
    else:
        raise Exception()
    try:
        json_decode({"a": 1})
    except TypeError:
        pass
    else:
        raise Exception()


_basestring_type = str
if typing.TYPE_CHECKING:
    # Define _basestring_type based on the real basestring type for Sphinx docs
    # (we can't just use typing.Union[str, bytes] because Sphinx doesn't import
    # this file).
    from typing import TYPE_CHECKING, Optional, Union


# Generated at 2022-06-22 03:31:15.512143
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    xhtml_unescape("&lt;some_string&gt;")


# Generated at 2022-06-22 03:31:17.617595
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  ab  c ') == 'ab c'



# Generated at 2022-06-22 03:31:21.412105
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<a>") == "&lt;a&gt;"
    assert xhtml_escape("<t>") == "&lt;t&gt;"
    assert xhtml_escape("<z>") == "&lt;z&gt;"


# Generated at 2022-06-22 03:31:33.505118
# Unit test for function json_decode
def test_json_decode():
    from tornado.test.util import unittest
    from tornado.test.httpclient_test import _TestHTTPConnection
    import contextlib
    import io
    import socketserver
    import threading
    import time

    def json_encode_hook(obj):
        if isinstance(obj, _TestHTTPConnection):
            return {'__TestHTTPConnection__': True}
        raise TypeError("%r is not JSON serializable" % obj)

    @contextlib.contextmanager
    def mock_connection(response, chunksize=None):
        class MockServer(socketserver.ThreadingTCPServer):
            allow_reuse_address = True

# Generated at 2022-06-22 03:31:45.570016
# Unit test for function native_str
def test_native_str():
    assert isinstance(to_unicode("hello"), unicode_type)
    assert isinstance(to_unicode(b"hello"), unicode_type)
    assert to_unicode("goodbye") == "goodbye"
    assert to_unicode(b"goodbye") == "goodbye"
    assert isinstance(to_unicode("ümlaut"), unicode_type)
    assert isinstance(to_unicode(b"\xc3\xbclaut"), unicode_type)
    assert to_unicode("\xac\xed") == u"\uFFFD"
    assert to_unicode(b"\xac\xed") == "\xac\xed"
    assert isinstance(to_unicode(None), type(None))
    assert to_unicode(None) is None



# Generated at 2022-06-22 03:31:49.422081
# Unit test for function native_str
def test_native_str():
    """Make sure native_str always returns the expected
    str type.
    """
    if not (isinstance("", str) and isinstance("".encode("utf8"), bytes)):
        raise AssertionError("unexpected str / bytes types in native_str")

    assert isinstance(native_str(b"ascii"), str)
    assert isinstance(native_str(u"unicode"), str)



# Generated at 2022-06-22 03:31:58.812706
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<h1>Hello</h1>') == '&lt;h1&gt;Hello&lt;/h1&gt;'
    assert xhtml_escape(1234) == "1234"
    assert xhtml_escape('&<>"\'') == '&amp;&lt;&gt;&quot;&#39;'
    assert xhtml_escape(None) == ""
    assert xhtml_escape(1.23) == "1.23"
    assert xhtml_escape(True) == "True"
    assert xhtml_escape('<h1>Hello</h1>') == '&lt;h1&gt;Hello&lt;/h1&gt;'



# Generated at 2022-06-22 03:32:10.563907
# Unit test for function native_str
def test_native_str():
  assert native_str("Fine") == "Fine"
  assert native_str("Fine".encode("utf8"), "utf8") == "Fine"
  assert native_str("Fine".encode("ascii"), "ascii") == "Fine"
  assert native_str("Fine".encode("ascii"), "utf8") == "Fine"
  assert native_str("Fine", "utf8") == "Fine"
  assert native_str("Fine", "ascii") == "Fine"
  #
  assert native_str("добро") == "добро"
  assert native_str("добро".encode("utf8"), "utf8") == "добро"
  assert native_str("добро".encode("ascii"), "ascii")

# Generated at 2022-06-22 03:32:12.195111
# Unit test for function json_decode
def test_json_decode():
    string = '[1,2,3]'
    print(json_decode(string))


# Generated at 2022-06-22 03:32:26.760200
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("1 2") == r"1+2"
    assert url_escape("1 2", plus=False) == r"1%202"



# Generated at 2022-06-22 03:32:28.385617
# Unit test for function url_escape
def test_url_escape():
    v = url_escape('path/name')
    print(v)
# test_url_escape()



# Generated at 2022-06-22 03:32:40.365826
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http+%3A%2F%2Fwww.google.com") == b"http+%3A%2F%2Fwww.google.com"
    assert url_unescape(b"http+%3A%2F%2Fwww.google.com") == b"http+%3A%2F%2Fwww.google.com"
    assert url_unescape("http+%3A%2F%2Fwww.google.com", plus=False) == "http+:%2F%2Fwww.google.com"
    assert url_unescape("http+%3A%2F%2Fwww.google.com", plus=False, encoding=None) == b"http+%3A%2F%2Fwww.google.com"

# Generated at 2022-06-22 03:32:42.472159
# Unit test for function utf8
def test_utf8():
    pass

# Generated at 2022-06-22 03:32:47.163240
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<script>') == "&lt;script&gt;"
    assert xhtml_escape('"') == "&quot;"
    assert xhtml_escape("'") == "&#39;"
    assert xhtml_escape('&') == "&amp;"



# Generated at 2022-06-22 03:32:59.634182
# Unit test for function json_encode
def test_json_encode():
    # Here are some objects that are accepted by the standard library
    # JSON encoder.
    json_encode(None)
    json_encode(True)
    json_encode(False)
    json_encode(1)
    json_encode(1.1)
    json_encode("foo")
    json_encode("\u2713")
    json_encode("\u2713".encode("utf-8"))
    json_encode("\u2713".encode("latin1"))
    json_encode(u"\u2713")
    json_encode([1, 2, 3])
    json_encode((1, 2, 3))
    json_encode({1, 2, 3})
    json_encode({})

# Generated at 2022-06-22 03:33:10.253969
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == u''
    assert linkify(u'') == u''
    assert linkify(u'Hello') == u'Hello'
    assert linkify(u'Hello http://tornadoweb.org !') == \
        u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a> !'
    assert linkify(u'Hello http://tornadoweb.org', shorten=True) == \
        u'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>'
    assert linkify(u'Hello www.tornadoweb.org', shorten=True) == \
        u'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'

# Generated at 2022-06-22 03:33:20.448660
# Unit test for function json_decode
def test_json_decode():
    str1 = '{"a":1}'
    assert json_decode(str1) == {"a":1}
    str2 = '{"b":2}'
    assert json_decode(str2) == {"b":2}
    str3 = str1 + str2
    assert json_decode(str3) == {"a":1, "b":2}
    str4 = str1 + str1 + str1
    assert json_decode(str4) == {"a":1, "a":1, "a":1}
    str5 = str2 + str2 + str2
    assert json_decode(str5) == {"b":2, "b":2, "b":2}

# Generated at 2022-06-22 03:33:32.845479
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;script&gt;alert(1);&lt;/script&gt;') == '<script>alert(1);</script>'
    assert xhtml_unescape('&#39;&#x3C;&#x3E;&#34;&#38;&#39;') == "'<>\"&'"


# json_encode, json_decode moved to escape.py to avoid circular imports
# at import time

_ESCAPE_HTML_CODEPOINTS = set(i for i in range(1, 32) if i not in (9, 10, 13))
_ESCAPE_HTML_CODEPOINTS.update(range(127, 160))

# Generated at 2022-06-22 03:33:38.186306
# Unit test for function json_decode
def test_json_decode():
    value = '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'
    expected_value = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}
    actual_value = json_decode(value)
    assert actual_value == expected_value, "ERROR on decoding json string"



# Generated at 2022-06-22 03:33:49.191383
# Unit test for function linkify
def test_linkify():
    text='<a> Hello 123 http://tornadoweb.org! '
    re=linkify(text)
    print(re)

#test_linkify()


# Generated at 2022-06-22 03:33:56.873780
# Unit test for function url_escape
def test_url_escape():
    a = url_escape("https://www.google.com/search?q=tornado+httputil.url_concat&oq=tornado+httputil.url_concat&aqs=chrome..69i57.5280j0j7&sourceid=chrome&ie=UTF-8")
    print(a)

_UTF8_TYPES = (bytes, type(None))  # type: typing.Tuple



# Generated at 2022-06-22 03:34:08.439558
# Unit test for function json_decode
def test_json_decode():
    import datetime

    value = b'{"foo": "bar"}'
    result = json_decode(value)
    assert isinstance(result, dict)
    assert result['foo'] == 'bar'

    value = '{"foo": "bar"}'
    result = json_decode(value)
    assert isinstance(result, dict)
    assert result['foo'] == 'bar'

    value = b'{"date": "2010-01-01 10:00:00"}'
    result = json_decode(value)
    assert isinstance(result, dict)
    assert result['date'] == datetime.datetime(2010, 1, 1, 10, 0, 0)

    value = '{"date": "2010-01-01 10:00:00"}'
    result = json_decode(value)
    assert isinstance

# Generated at 2022-06-22 03:34:12.878554
# Unit test for function linkify
def test_linkify():
    assert linkify(u"https://www.tornadoweb.org")==u'<a href="https://www.tornadoweb.org">https://www.tornadoweb.org</a>'
    assert linkify(u"https://www.tornadoweb.org/en/stable/")==u'<a href="https://www.tornadoweb.org/en/stable/">https://www.tornadoweb.org/en/stable/</a>'
    assert linkify(u"https://www.tornadoweb.org/en/stable/httplib.html")==u'<a href="https://www.tornadoweb.org/en/stable/httplib.html">https://www.tornadoweb.org/en/sta...</a>'

# Generated at 2022-06-22 03:34:16.251145
# Unit test for function json_decode
def test_json_decode():
    j = '{"a": "b", "c": "d"}'
    obj = json_decode(j)
    assert obj["a"] == "b"
    assert obj["c"] == "d"
    
    

# Generated at 2022-06-22 03:34:25.507928
# Unit test for function url_unescape
def test_url_unescape():
    result = url_unescape('hello', plus=False)
    assert isinstance(result, str)
    assert result == 'hello'
    result = url_unescape('hello', plus=True)
    assert isinstance(result, str)
    assert result == 'hello'
    result = url_unescape(b'hello', plus=False)
    assert isinstance(result, bytes)
    assert result == b'hello'
    result = url_unescape(b'hello', plus=True)
    assert isinstance(result, bytes)
    assert result == b'hello'



# Generated at 2022-06-22 03:34:26.987973
# Unit test for function linkify
def test_linkify():
    print(linkify(u"http://example.com/"))

# Generated at 2022-06-22 03:34:33.285363
# Unit test for function json_decode
def test_json_decode():
    from tornado.escape import json_decode
    # assert json_decode("{\"a\": 1}") == {"a": 1}
    print("test_json_decode:", json_decode("{\"a\": 1}"))
    assert json_decode("{\"a\": 1}") == {"a": 1}, 'json_decode failed'
test_json_decode()



# Generated at 2022-06-22 03:34:39.292604
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'foo+bar=baz%20qux') == 'foo bar=baz qux'
    assert url_unescape(b'foo%2Bbar=baz+qux', encoding="latin1") == 'foo+bar=baz+qux'
    assert url_unescape(b'foo%2Bbar=baz+qux', encoding=None) == b'foo+bar=baz qux'
    assert url_unescape(b'foo+bar=baz%20qux', plus=False) == 'foo+bar=baz qux'
    assert (url_unescape(u'foo+bar=baz%20qux', plus=False,
        encoding=None) == b'foo+bar=baz qux')

# Generated at 2022-06-22 03:34:49.138548
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():  # noqa
    assert parse_qs_bytes(b"a=1&b=2") == {b'a': [b'1'], b'b': [b'2']}
    assert parse_qs_bytes(b"a=1;b=2", strict_parsing=True) == {b'a': [b'1'], b'b': [b'2']}
    assert parse_qs_bytes(b"a=1&b=2") == {'a': [b'1'], 'b': [b'2']}
    assert parse_qs_bytes(b"a=&b=2") == {'a': [b''], 'b': [b'2']}

# Generated at 2022-06-22 03:35:17.349035
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;div&gt;an html string&lt;/div&gt;") == "<div>an html string</div>"
    assert xhtml_unescape("&#60;div&#62;an html string&#60;/div&#62;") == "<div>an html string</div>"
test_xhtml_unescape()

_PARSE_ENTITY_RE = re.compile(r"&#(\d+?);|&#x([\da-fA-F]{2,4});|&(\w+?);")



# Generated at 2022-06-22 03:35:26.804304
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"a": [1, "simple"], "b": {"c": 0.0}}') == {"a": [1, "simple"], "b": {"c": 0.0}}
    assert json_decode('[1, 2, 3]') == [1, 2, 3]
    assert json_decode('''{"a": [1, "simple"], "b": {"c": 0.0}}''') == {"a": [1, "simple"], "b": {"c": 0.0}}
    assert json_decode('''[1, 2, 3]''') == [1, 2, 3]

# Generated at 2022-06-22 03:35:38.118635
# Unit test for function url_unescape
def test_url_unescape():
    if url_unescape(b"a+b%20c", plus=True) != b"a+b c":
        raise ValueError("url_unescape failed")
    if url_unescape(b"a+b%20c", plus=False) != b"a b c":
        raise ValueError("url_unescape failed")
    if url_unescape(b"a+b%20c", encoding="ascii") != "a+b c":
        raise ValueError("url_unescape failed")
    if url_unescape(b"a+b%20c", encoding="ascii", plus=False) != "a b c":
        raise ValueError("url_unescape failed")

# Generated at 2022-06-22 03:35:48.301338
# Unit test for function json_encode
def test_json_encode():
    assert json_encode([1,2,3]) == '[1,2,3]'
    assert json_encode([]) == '[]'
    assert json_encode({1:'a'}) == '{"1":"a"}'
    assert json_encode({}) == '{}'
    assert json_encode(12.5) == '12.5'
    assert json_encode(12) == '12'
    assert json_encode(9**9**9) == '2733262979466032906242967731859361658912'
test_json_encode()

_JSON_DECODE_OPTIONS = json.JSONDecoder().parse


# Generated at 2022-06-22 03:35:53.949847
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # type: () -> None
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode([1, [1, 2]]) == [1, [1, 2]]
    assert recursive_unicode(b"foo") == u"foo"
    assert recursive_unicode([b"foo"]) == [u"foo"]
    assert recursive_unicode({"foo": b"bar"}) == {u"foo": u"bar"}



# Generated at 2022-06-22 03:36:02.271253
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<script>alert("Hello World!");</script>') == '&lt;script&gt;alert("Hello World!");&lt;/script&gt;'

_JS_ESCAPE_MAP = {
    ord("'"): "\\x27",
    ord('"'): "\\x22",
}


# escape every ASCII character with a value less than 32
_JS_ESCAPE_MAP.update({c: "\\x%02x" % c for c in range(32)})



# Generated at 2022-06-22 03:36:08.544462
# Unit test for function native_str
def test_native_str():
    assert native_str('abc') == 'abc'
    assert native_str(b'abc') == 'abc'
    assert native_str('你好') == '你好'
    assert native_str(b'\xe4\xbd\xa0\xe5\xa5\xbd') == '你好'



# Generated at 2022-06-22 03:36:10.230941
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a b    c   d') == 'a b c d'



# Generated at 2022-06-22 03:36:14.174044
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    inputq = b"a=1&b=1&b=2"
    output_result = parse_qs_bytes(inputq)
    assert output_result == {'b': [b'1', b'2'], 'a': [b'1']}



# Generated at 2022-06-22 03:36:23.392298
# Unit test for function json_encode
def test_json_encode():
    dict_1 = {'a':1,'b':2,'c':3}
    json_dict = json_encode(dict_1)
    assert dict_1 == json.loads(json_dict), 'json_encode function failed'


_HTML_TYPES = (str, bytes)

if hasattr(html.entities, "name2codepoint"):  # type: ignore
    _HTML_UNESCAPE = {v: k for k, v in html.entities.name2codepoint.items()}
else:
    _HTML_UNESCAPE = html.entities.html5

