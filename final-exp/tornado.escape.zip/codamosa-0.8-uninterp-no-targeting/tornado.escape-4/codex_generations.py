

# Generated at 2022-06-22 03:28:35.112671
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>&\"'") == "&lt;&gt;&amp;&quot;&#39;"


# json_encode, json_decode moved to tornado.escape and deprecated
# in Tornado 4.0.
# TODO: remove these aliases in Tornado 5.0
json_encode = json.dumps

try:
    # Python 2.7+
    from json import JSONDecodeError
except ImportError:
    JSONDecodeError = ValueError

json_decode = json.loads

# to_unicode moved to tornado.escape in Tornado 4.0
to_unicode = unicode_type

# to_basestring moved to tornado.escape in Tornado 4.0
to_basestring = unicode_type

# recursive_unicode moved to tornado.escape in Tornado 4.

# Generated at 2022-06-22 03:28:38.945304
# Unit test for function url_unescape
def test_url_unescape():  # noqa: F811
    assert url_unescape('a+b') == 'a b'
    assert url_unescape('a+b', plus=False) == 'a+b'



# Generated at 2022-06-22 03:28:43.616492
# Unit test for function utf8
def test_utf8():
    s = utf8("foo")  # noqa: F811
    assert s == b"foo"
    assert s is not "foo"
    s = utf8(b"foo")
    assert s == b"foo"
    s = utf8(None)
    assert s is None



# Generated at 2022-06-22 03:28:50.588806
# Unit test for function native_str
def test_native_str():
    assert native_str(None) is None
    assert native_str(1) == '1'
    assert native_str('foo') == 'foo'
    assert native_str(u'foo') == u'foo'
    assert native_str(b'foo') == b'foo'


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-22 03:28:57.744654
# Unit test for function utf8
def test_utf8():
    u = typing.cast(str, typing.cast(typing.Any, None))
    utf8(u)
    u = u"123"
    b = utf8(u)
    assert b.decode("utf-8") == u
    b = utf8(b)
    assert b.decode("utf-8") == u
    b = utf8(None)
    assert b is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:04.739061
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(" a  b\tc\rd\ne") == "a b c d e"
    assert squeeze("\x00\x01\x02\x03\x04\x05\x06\x07\x08") == ""
    assert squeeze("Sphinx  \x0c  documentation  \x0c  generator") == "Sphinx documentation generator"
    assert squeeze(" a  b\tc\rd\ne") == "a b c d e"
    print("Successfully passed tests")



# Generated at 2022-06-22 03:29:13.993312
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%7Ea%25b') == '~a%b'
    assert url_unescape('/a%7Eb', plus=False) == '/a~b'
    assert url_unescape('a=%2B') == 'a=+'
    assert url_unescape('%2B', encoding='ascii') == '+'
    assert url_unescape(b'%2B') == b'+'
    assert url_unescape('%2B', encoding=None) == b'+'
test_url_unescape()


# Generated at 2022-06-22 03:29:18.030133
# Unit test for function recursive_unicode
def test_recursive_unicode():
    example = {
        'foo': [1, 2, {'bar': b'baz'}]
    }
    expected = {
        'foo': [1, 2, {'bar': 'baz'}]
    }
    assert recursive_unicode(example) == expected



# Generated at 2022-06-22 03:29:31.036276
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8("\N{SNOWMAN}") == b"\xe2\x98\x83"
    assert utf8(u"\N{SNOWMAN}") == b"\xe2\x98\x83"
    assert utf8(None) is None
    assert utf8(object()) == b"<object object at 0x%x>" % id(object())
    assert utf8(u"\N{REPLACEMENT CHARACTER}") == b"\xef\xbf\xbd"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:37.747962
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Case: qs is type bytes
    assert parse_qs_bytes(b'foo=bar&bar=baz', False, False) == {'foo': [b'bar'], 'bar': [b'baz']}

    # Case: qs is type str
    assert parse_qs_bytes('foo=bar&bar=baz', False, False) == {'foo': ['bar'], 'bar': ['baz']}



# Generated at 2022-06-22 03:29:58.946883
# Unit test for function squeeze
def test_squeeze():
    value = "ABC \n \t \r DEF"
    print(squeeze(value))
    assert squeeze(value) == "ABC DEF"
    return



# Generated at 2022-06-22 03:30:01.837151
# Unit test for function recursive_unicode
def test_recursive_unicode():
    result = recursive_unicode({'key': [('a1', 'b1'), ('a2', 'b2')]})
    print(result)


# Generated at 2022-06-22 03:30:08.449281
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&#60;") == "<"
    assert xhtml_unescape("&#x3c;") == "<"
    assert xhtml_unescape("&#X3c;") == "<"
    assert xhtml_unescape("&#X3c;") == "<"
    assert xhtml_unescape("&lt;&gt;&amp;&quot;&apos;") == "<>&\"'"



# Generated at 2022-06-22 03:30:14.046926
# Unit test for function json_decode
def test_json_decode():
    recieved = json_decode('{"key1": "val1", "key2": "val2"}')
    expected = {"key1": "val1", "key2": "val2"}
    assert recieved == expected



# Generated at 2022-06-22 03:30:18.726128
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes(
        b"q=query+string+parameters&foo=bar&foo=baz"
    )
    print(result)
    assert result == {
        b"foo": [b"bar", b"baz"],
        b"q": [b"query string parameters"],
    }

test_parse_qs_bytes()
# Original function

# Generated at 2022-06-22 03:30:21.355191
# Unit test for function url_escape
def test_url_escape():
    assert "%20" in url_escape(u" ")
    assert "%20" not in url_escape(u" ", plus=False)


# Generated at 2022-06-22 03:30:24.359041
# Unit test for function utf8
def test_utf8():
    assert utf8('abc') == b'abc'
    assert utf8(None) is None

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:30:36.867805
# Unit test for function recursive_unicode
def test_recursive_unicode():
    def _t_dict(t):
        return recursive_unicode(t[0]) == t[1]
    def _t_list(t):
        return recursive_unicode(t[0]) == t[1]
    def _t_tuple(t):
        return recursive_unicode(t[0]) == t[1]

    assert _t_dict(({"b": b"a"}, {"b": u"a"}))
    assert _t_dict(({"b": {"b": b"a"}}, {"b": {"b": u"a"}}))
    assert _t_dict(({"b": [b"a"]}, {"b": [u"a"]}))
    assert _t_dict(({"b": (b"a")}, {"b": (u"a")}))

# Generated at 2022-06-22 03:30:48.474973
# Unit test for function linkify

# Generated at 2022-06-22 03:30:51.952476
# Unit test for function squeeze
def test_squeeze():
    s = 'hi    hello sir'
    expected = 'hi hello sir'
    result = squeeze(s)
    print(result)
    assert result == expected



# Generated at 2022-06-22 03:31:08.207049
# Unit test for function utf8
def test_utf8():
    # type: () -> None
    assert utf8(u"foo") == b"foo"
    assert utf8(u"foo".encode("utf-8")) == b"foo"
    assert utf8(u"\xe9") == b"\xc3\xa9"
    assert utf8(None) is None
    assert utf8(object()) == b"<object object at 0x%x>" % id(object())


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:31:15.243716
# Unit test for function squeeze
def test_squeeze():
    my_str = '''This is a string of text. It has many words in it.
    It's also got some punctuation.
    What do you think it should look like when squeezed?'''
    my_str_squeezed = 'This is a string of text. It has many words in it. It\'s also got some punctuation. What do you think it should look like when squeezed?'
    assert(squeeze(my_str) == my_str_squeezed)


# Generated at 2022-06-22 03:31:24.574766
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2") == {b"a": [b"1"], b"b": [b"2"]}
    assert parse_qs_bytes(b"a=1;b=2", strict_parsing=True) == {b"a": [b"1;b=2"]}
    assert parse_qs_bytes(b"a=1;b=2") == {b"a": [b"1"], b"b": [b"2"]}
    assert parse_qs_bytes(b"a=1&a=2") == {b"a": [b"1", b"2"]}
    assert parse_qs_bytes(b"a=&b=2") == {b"a": [b""], b"b": [b"2"]}
    assert parse

# Generated at 2022-06-22 03:31:29.078642
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("this&#39; and that &quot;") == "this' and that \""
    assert xhtml_unescape("&amp;") == "&"

_BASESTRING_TYPES = str, bytes


# Generated at 2022-06-22 03:31:34.481102
# Unit test for function url_unescape
def test_url_unescape():
    if url_unescape("%7e%21%40%23%24%26%27%28%29%2a%3d%3f%5e%5c%7c%2f%2c%3a%3b%2b", plus=False) == "~!@#$&'()*=?^\\|/,":
        print("url_unescape pass")
    else:
        print("url_unescape fail")



# Generated at 2022-06-22 03:31:37.372619
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("alex.yuan"), "alex.yuan"



# Generated at 2022-06-22 03:31:41.713048
# Unit test for function linkify
def test_linkify():
    words = ['Hello', 'http://tornadoweb.org', '!']
    words_link = ['Hello', '<a href="http://tornadoweb.org">http://tornadoweb.org</a>', '!']

    assert words_link == linkify(' '.join(words)).split(' ')



# Generated at 2022-06-22 03:31:46.005633
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"haha": ["saf", b"b", "d", [b"b", "g"]]}) == {"haha": ["saf", "b", "d", ["b", "g"]]}
test_recursive_unicode()

# test_recursive_unicode()

# Generated at 2022-06-22 03:31:49.845170
# Unit test for function json_encode
def test_json_encode():

    data ={'username':'kevin','password':'111111'}
    print(json_encode(data))
    assert type(json_encode(data)) == str
    assert json_encode(data) == r'{"username": "kevin", "password": "111111"}'
# Unit test end

_JSON_DECODE_ERROR = getattr(json, "JSONDecodeError", ValueError)



# Generated at 2022-06-22 03:31:54.371509
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("abc") == "abc"
    assert squeeze("abc  ") == "abc"
    assert squeeze("  abc") == "abc"
    assert squeeze("  abc  ") == "abc"
test_squeeze()



# Generated at 2022-06-22 03:32:02.464310
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a      b       c') == 'a b c'



# Generated at 2022-06-22 03:32:04.809747
# Unit test for function native_str
def test_native_str():
    to_str(None)


# Generated at 2022-06-22 03:32:15.267711
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # For future bug fixes, add a unit test here corresponding
    # to every type handled by recursive_unicode above.

    assert recursive_unicode(b'foo') == 'foo'
    assert recursive_unicode(b'\xc3\xa9') == 'é'
    assert recursive_unicode(None) is None
    assert recursive_unicode([b'foo', b'foo']) == ['foo', 'foo']

    assert recursive_unicode({'foo': b'bar'}) == {'foo': 'bar'}
    assert recursive_unicode({'foo': b'\xc3\xa9'}) == {'foo': 'é'}
    assert recursive_unicode({'foo': None}) == {'foo': None}

# Generated at 2022-06-22 03:32:28.387352
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_result = parse_qs_bytes('key=value')
    assert test_result == {"key": [b"value"]}
    test_result = parse_qs_bytes('key=val%20ue')
    assert test_result == {"key": [b"val ue"]}
    test_result = parse_qs_bytes(b'key=value')
    assert test_result == {"key": [b"value"]}
    test_result = parse_qs_bytes('key=value1&key=value2')
    assert test_result == {"key": [b"value1", b"value2"]}
    test_result = parse_qs_bytes(b'key===&%')
    assert test_result == {"key": [b"=", b""]}
    test_result = parse_qs_bytes(b'')

# Generated at 2022-06-22 03:32:35.683910
# Unit test for function json_decode
def test_json_decode():
    json_value = json_encode(['foo', 10, False])
    assert json_decode(json_value) == ['foo', 10, False]


_BASESTRING_TYPES = (str, bytes)

# TODO:  memoryview?

if False:
    # Python 3.x
    _BASESTRING_TYPES = (str,)



# Generated at 2022-06-22 03:32:37.307693
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("a&amp;a") == "a&a"


# Generated at 2022-06-22 03:32:41.088167
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("hello world") == "hello world"
    assert squeeze(" hello world") == "hello world"
    assert squeeze("  hello   world   ") == "hello world"
    assert squeeze("\n \t hello \n \t world \t \r") == "hello world"


# Generated at 2022-06-22 03:32:54.025530
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#x20;') == ' '
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&#x26;') == '&'
    assert xhtml_unescape('&#38;') == '&'

_JS_ESCAPE_RE = re.compile(r'[\x00-\x19\U0010ffff]')

# Generated at 2022-06-22 03:33:06.345209
# Unit test for function linkify
def test_linkify():

    text = linkify('www.facebook.com')
    assert text == '<a href="http://www.facebook.com">www.facebook.com</a>'

    text = linkify('http://www.facebook.com')
    assert text == '<a href="http://www.facebook.com">http://www.facebook.com</a>'

    text = linkify('www.facebook.com', True)
    assert text == '<a href="http://www.facebook.com">www.facebook.com</a>'

    text = linkify('http://www.facebook.com', True)
    assert text == '<a href="http://www.facebook.com">http://www.facebook.com</a>'

    text = linkify('http://shorten.me.com/1234567890')

# Generated at 2022-06-22 03:33:11.016221
# Unit test for function url_escape
def test_url_escape():
    a = 'http://www.example.com/?p=1'
    b = 'https%3A%2F%2Fwww.example.com%2F%3Fp%3D1'
    out = url_escape(a)
    if out == b:
        print("Test Passed")
    else:
        print("Test Failed")
# Unit test function call
test_url_escape()


# Generated at 2022-06-22 03:33:23.606158
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&#39;") == "'"
test_xhtml_unescape()



# Generated at 2022-06-22 03:33:24.993885
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"a": 1}') == {"a": 1}



# Generated at 2022-06-22 03:33:26.649407
# Unit test for function url_unescape
def test_url_unescape():
    test_input= "thisisatest"
    print(url_unescape(test_input))



# Generated at 2022-06-22 03:33:28.276512
# Unit test for function squeeze
def test_squeeze():
    test = squeeze("")
    assert test == ""



# Generated at 2022-06-22 03:33:39.188121
# Unit test for function recursive_unicode
def test_recursive_unicode():
    def helper(data, expected):
        assert recursive_unicode(data)==expected
    data = {
        u'key1': {
            u'key2': [
                u'value1',
                bytearray(b'value2'),
                {
                    u'key3': bytearray(b'value3')
                },
                [
                    u'listvalue1',
                    bytearray(b'listvalue2')
                ]
            ],
            u'key4': u'value4',
            u'key5': bytearray(b'value5')
        }
    }

# Generated at 2022-06-22 03:33:50.311378
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "bar"}) == '{"foo": "bar"}'
    assert json_encode(1) == "1"
    assert json_encode([1, 2]) == "[1, 2]"
    assert json_encode({"html": "<html>"}) == '{"html": "<html>"}'
    assert json_encode({"slash": "</script>"}) == '{"slash": "<\\/script>"}'
    assert json_encode({"bs": "\\"}) == '{"bs": "\\\\"}'

    def test_decode(s, **kwargs):
        assert json.loads(s, **kwargs) == {"value": "&"}

    test_decode(json_encode({"value": "&"}), strict_parsing=False)



# Generated at 2022-06-22 03:33:58.608742
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    original_str = "&#256;&#x100;&#x1;&nbsp;&quot;&apos;&amp;&gt;&lt;"
    correct_str = "ĀĀ &quot;'&><"
    assert xhtml_unescape(original_str) == correct_str

_BASESTRING_TYPES = typing.TYPE_CHECKING and typing.Union[str, bytes] or str



# Generated at 2022-06-22 03:34:04.180543
# Unit test for function utf8
def test_utf8():
    assert utf8('\u00e9') == '\xc3\xa9'
    assert utf8(b'\xc3\xa9') == b'\xc3\xa9'
    assert utf8(None) == None
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-22 03:34:11.025538
# Unit test for function utf8
def test_utf8():
    assert utf8('\u2192') == b'\xe2\x86\x92'
    assert utf8('папа') == b'\xd0\xbf\xd0\xb0\xd0\xbf\xd0\xb0'
    assert utf8(None) is None
    assert utf8(b'abc') == b'abc'

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:13.946329
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  aaa bbb ccc  ddd eee    fff   ggg    ') == 'aaa bbb ccc ddd eee fff ggg'
    print('Pass Test: squeeze')


# Generated at 2022-06-22 03:34:26.938236
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode("what") == "what"
    assert recursive_unicode(b"what") == "what"
    assert recursive_unicode(("a", "b", "c")) == ("a", "b", "c")
    assert recursive_unicode([1, 2, 3]) == [1, 2, 3]
    assert recursive_unicode({"a": 1}) == {"a": 1}
    assert recursive_unicode({"a": b"b"}) == {"a": "b"}



# Generated at 2022-06-22 03:34:31.554309
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://yahoo.com") == "http%3A//yahoo.com"
    assert url_escape("http://yahoo.com", plus = True) == "http%3A%2F%2Fyahoo.com"



# Generated at 2022-06-22 03:34:36.213839
# Unit test for function json_encode
def test_json_encode():
    import json
    assert json.dumps({"</script>":"</script>"}) == '{"</script>": "</script>"}'
    assert json_encode({"</script>":"</script>"}) == '{"\\u003c/script\\u003e": "\\u003c/script\\u003e"}'



# Generated at 2022-06-22 03:34:48.020340
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print('-----test_xhtml_unescape-----')
    import re
    import tornado.escape as escape
    from tornado.escape import xhtml_unescape as unescape
    # Regression test for tools/pretty_errors/pretty_errors.py
    # Test that &jdoe; is not unescaped to �jdoe;
    assert escape.xhtml_unescape('&jdoe;') == '&jdoe;'
    # Test that &#39; is not unescaped to ', etc
    assert escape.xhtml_unescape('&#39;') == '&#39;'
    assert escape.xhtml_unescape('&#0000039;') == '&#0000039;'
    # Test that &#39 is not unescaped to '
    assert escape.xhtml_unescape('&#39')

# Generated at 2022-06-22 03:34:54.750613
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html></html>") == "&lt;html&gt;&lt;/html&gt;"
    assert xhtml_escape("&<>'\"") == "&amp;&lt;&gt;&#39;&quot;"



# Generated at 2022-06-22 03:35:01.209679
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"
test_xhtml_escape()


# escape() and _unicode() is copied from
# https://github.com/facebook/tornado/blob/master/tornado/escape.py.
# Copyright 2008 Facebook.
# Licensed under the Apache License, Version 2.0.

# Generated at 2022-06-22 03:35:08.234995
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http%3A%2F%2F%3F%3D%26") == "http://?=&"
    assert url_unescape("http%3A%2F%2F%3F%3D%26", encoding=None) == b"http://?=&"


# Get rid of characters that might cause illegal file names on some
# platforms while avoiding UNIX reserved filenames.
# https://en.wikipedia.org/wiki/Filename#Reserved_characters_and_words
_ILLEGAL_FILENAME_CHARACTERS_RE = re.compile(r'[<>:"\?\*\\/|\x00-\x1f]')

# Generated at 2022-06-22 03:35:20.753058
# Unit test for function url_escape

# Generated at 2022-06-22 03:35:25.019742
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('"x"') == "x"
    assert json_decode('[1, 2, 3]') == [1, 2, 3]
    # Checking for bytes is tricky; need to use assertWarns.
    #assertWarns(DeprecationWarning, json_decode, b"x") == b"x"


# Generated at 2022-06-22 03:35:31.100049
# Unit test for function url_unescape
def test_url_unescape():
    unescaped = url_unescape("http%3A%2F%2Fwww.tornadoweb.org%2F")
    assert unescaped == "http://www.tornadoweb.org/"
    unescaped = url_unescape("http%3A%2F%2Fwww.tornadoweb.org%2F", plus=False)
    assert unescaped == "http%3A%2F%2Fwww.tornadoweb.org%2F"


# Generated at 2022-06-22 03:35:45.191767
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # Unicode string
    value = "String to be escaped"
    assert xhtml_escape(value) == "String to be escaped"

    # Bytes string
    value = "Bytes string to be escaped".encode()
    assert xhtml_escape(value) == "Bytes string to be escaped"


_URL_FORM_ENCODING_RE = re.compile(r"[^\x21-\x3f]")



# Generated at 2022-06-22 03:35:55.632043
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(xhtml_escape(u"abc")) == u"abc"
    assert xhtml_unescape(xhtml_escape(u"<007>")) == u"<007>"
    assert xhtml_unescape(xhtml_escape(u"&")) == u"&"
    assert xhtml_unescape(xhtml_escape(u"<foo>")) == u"<foo>"
    assert xhtml_unescape(xhtml_escape(u"<foo>&")) == u"<foo>&"
    assert xhtml_unescape(xhtml_escape(u"hello 'world'")) == u"hello 'world'"
    assert xhtml_unescape(xhtml_escape(u"hello \"world\"")) == u"hello \"world\"" # noqa


# py2 and py3 compatibility helpers
_UN

# Generated at 2022-06-22 03:35:59.700682
# Unit test for function url_escape
def test_url_escape():
    a=url_escape('a;bcd')
    b=urllib.parse.quote_plus('a;bcd')
    assert(a==b)



# Generated at 2022-06-22 03:36:04.350664
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;a href=&#34;x&#39;k&#34;&gt;') == '<a href="x\'k">'

_BASESTRING_TYPE = type("")
_UNICODE_TYPE = type(u"")



# Generated at 2022-06-22 03:36:07.004741
# Unit test for function url_escape
def test_url_escape():
    assert url_escape(' ') == '+'
    assert url_escape(' ', plus=False) == '%20'
    assert url_escape('"') == '%22'


# Generated at 2022-06-22 03:36:10.525573
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  as  df   sd   sadf  sdfsad  asdf ") == "as df sd sadf sdfsad asdf"


# Generated at 2022-06-22 03:36:15.894498
# Unit test for function utf8
def test_utf8():
    str1 = utf8('this is a test')
    str2 = utf8(b'this is a test')
    str3 = utf8(None)
    assert str1 == b'this is a test'
    assert str2 == b'this is a test'
    assert str3 is None
    return True
test_utf8()



# Generated at 2022-06-22 03:36:20.951841
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape('a&#35;b'))
    assert xhtml_unescape('a&#35;b') == 'a#b'
    assert xhtml_unescape('a&#35') == 'a#35'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('<') == '<'
test_xhtml_unescape()


# Generated at 2022-06-22 03:36:26.145624
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Code to demonstrate the use of the function parse_qs_bytes
    from tornado import escape

    qs = 'key1=value1&key2=value2&key3=value3'
    print(escape.parse_qs_bytes(qs))


# Generated at 2022-06-22 03:36:31.153831
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query_str = 'a=1&b=2'
    encoded = parse_qs_bytes(query_str)
    assert encoded == {'a':[b'1'], 'b':[b'2']}
test_parse_qs_bytes()


# Generated at 2022-06-22 03:36:52.501322
# Unit test for function json_decode
def test_json_decode():
    value = """{"key": "value"}"""

    assert json_decode(value) == {"key": "value"}
    assert json_decode(value.encode()) == {"key": "value"}



# Generated at 2022-06-22 03:36:57.829523
# Unit test for function url_escape
def test_url_escape():
    assert url_escape(symbol_to_string(''), True) == ''
    assert url_escape(symbol_to_string('a'), True) == 'a'
    assert url_escape(symbol_to_string('a b'), True) == 'a+b'
    assert url_escape(symbol_to_string('a b'), False) == 'a%20b'



# Generated at 2022-06-22 03:37:02.755371
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#34;') == '"'
    assert xhtml_unescape('&#x22;') == '"'
    assert xhtml_unescape('&nbsp;') == ' '



# Generated at 2022-06-22 03:37:04.151613
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('   123\n \t') == '123'
test_squeeze()



# Generated at 2022-06-22 03:37:11.306674
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<div></div>')=='&lt;div&gt;&lt;/div&gt;'
    assert xhtml_escape("hello")=='hello'

_JSON_ENCODE_OPTIONS = {}

try:
    # In python 3.6 and later, we can use the compact separators
    separators = (",", ":")
    _JSON_ENCODE_OPTIONS = dict(separators=separators)
except TypeError:
    # In python 3.5, fall back to the most compact setting
    _JSON_ENCODE_OPTIONS = dict(separators=(",", ":"), sort_keys=True)

# json_encode is complicated because it can take either strings or bytes,
# but the type of the input must be reflected in the output.  We use
# encode

# Generated at 2022-06-22 03:37:16.407838
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze("abc def ghi") == "abc def ghi")
    assert(squeeze("abc\tdef\tghi") == "abc def ghi")
    assert(squeeze("abc  def  ghi") == "abc def ghi")
    assert(squeeze("abc\n  \n\tdef\n   ghi") == "abc def ghi")
test_squeeze()


# Generated at 2022-06-22 03:37:20.291828
# Unit test for function url_escape
def test_url_escape():
    value = 'http://www.tornadoweb.org/en/stable/'
    url_s = url_escape(value)
    print(url_s)
# test_url_escape()



# Generated at 2022-06-22 03:37:21.538714
# Unit test for function native_str
def test_native_str():
    pass



# Generated at 2022-06-22 03:37:33.550385
# Unit test for function json_decode
def test_json_decode():
    # If a value already is a string, it should be left alone
    assert json_decode('"a"') == "a"
    # Unicode strings are decoded as usual
    assert json_decode('"\\u0026"') == "&"
    # Non-ASCII bytestrings should be decoded with the correct encoding
    assert json_decode(b'"\\u0026"') == "&"
    assert json_decode(b'"\\u00a2"') == "\xa2"
    # Invalid UTF-8 in bytestrings should raise a ValueError
    try:
        json_decode(b'"\\u0026"')
    except ValueError:
        pass
    else:
        assert False, "did not get expected ValueError"



# Generated at 2022-06-22 03:37:39.018374
# Unit test for function native_str
def test_native_str():
    assert native_str("test") == "test"
    assert native_str(b"test") == "test"
    assert native_str(None) is None
    assert native_str(u"test") == "test"
    assert native_str(u"\xe7\xbd\x91\xe9\xa1\xb5") == "\xe7\xbd\x91\xe9\xa1\xb5"


# Generated at 2022-06-22 03:37:56.789888
# Unit test for function xhtml_escape
def test_xhtml_escape():
    str = xhtml_escape("<script>alert('hello')</script>")
    print(str)



# Generated at 2022-06-22 03:38:02.003529
# Unit test for function utf8
def test_utf8():
    t = ''
    a = '测试'
    assert utf8(a) == '测试'.encode('utf-8')

_TO_UNICODE_TYPES = (unicode_type, type(None))

