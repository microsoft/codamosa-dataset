

# Generated at 2022-06-22 03:28:20.807930
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"foo": b"bar"}) == {"foo": "bar"}
    assert recursive_unicode({"foo": ["bar", b"baz"]}) == {"foo": ["bar", "baz"]}



# Generated at 2022-06-22 03:28:22.399755
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('哈哈')=='哈哈'


# Generated at 2022-06-22 03:28:26.366012
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    expected = {"a": [b"1"], "c": [b"2"]}
    parsed = parse_qs_bytes(b"a=1&b=&c=2", keep_blank_values=True)
    assert expected == parsed



# Generated at 2022-06-22 03:28:30.133838
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(b'  a  b   c') == 'a b c'
    assert squeeze(bytes([194, 32, 194, 32, 194, 32])) == ' a  a  a'
    assert squeeze('  a  b   c') == 'a b c'



# Generated at 2022-06-22 03:28:34.687759
# Unit test for function utf8
def test_utf8():
    print("utf8 test")
    print("utf8('a') ", utf8("a",))
    print("utf8('1') ", utf8("1",))
    print("utf8('1') ", utf8(1))



# Generated at 2022-06-22 03:28:45.603140
# Unit test for function utf8
def test_utf8():
    print("Testing function utf8...", end="")
    class Foo(str): pass
    assert utf8("") == b""
    assert utf8("a") == b"a"
    # non-UTF8 byte string, should throw an error
    try:
        utf8(bytes([0b11110000, 0b10000000, 0b10000000, 0b10101100]))
        assert False, "should have thrown an error"
    except:
        pass
    # unicode strings are fine
    assert utf8("a") == b"a"
    assert utf8(u"a") == b"a"
    # None is fine too
    assert utf8(None) is None
    print("Passed.")

test_utf8()



# Generated at 2022-06-22 03:28:57.656456
# Unit test for function linkify
def test_linkify():
    func = linkify
    # Test the linkify function
    assert func('google.com') == 'google.com'
    assert func('http://facebook.com') == '<a href="http://facebook.com">http://facebook.com</a>'
    assert func('http://facebook.com/') == '<a href="http://facebook.com/">http://facebook.com/</a>'
    assert func('http://facebook.com/yui') == '<a href="http://facebook.com/yui">http://facebook.com/yui</a>'
    assert func('http://facebook.com/yui/') == '<a href="http://facebook.com/yui/">http://facebook.com/yui/</a>'

# Generated at 2022-06-22 03:29:09.566301
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'http%3A%2F%2Fwww.example.com%2F') == 'http://www.example.com/'
    assert url_unescape(b'http%3A%2F%2Fwww.example.com%2F', plus=False) == 'http://www.example.com/'
    assert url_unescape(b'http%3A%2F%2Fwww.example.com%2F', encoding='utf-8') == 'http://www.example.com/'
    assert url_unescape(b'http%3A%2F%2Fwww.example.com%2F', encoding='utf-8', plus=False) == 'http://www.example.com/'

# Generated at 2022-06-22 03:29:20.987310
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<script>') == '&lt;script&gt;'


_JS_ESCAPE_RE = re.compile(r'[&<>\"\']')
_JS_ESCAPE_DICT = {
    '&': '\\u0026',
    '<': '\\u003c',
    '>': '\\u003e',
    '"': '\\u0022',
    "'": '\\u0027',
}
_JS_QUOTES_RE = re.compile(r'[<>\"\']')
_JS_QUOTES_DICT = {
    '<': '\\u003c',
    '>': '\\u003e',
    '"': '\\u0022',
    "'": '\\u0027',
}



# Generated at 2022-06-22 03:29:23.357751
# Unit test for function url_escape
def test_url_escape():
    assert url_escape(r"c:\\") == "%5C"
    assert url_escape(r"a/b") == "a%2Fb"
    assert url_escape(r"a/b",False) == "a%2Fb"
    assert url_escape(r"a b") == "a+b"
    assert url_escape(r"a b",False) == "a%20b"

    

# Generated at 2022-06-22 03:29:42.967034
# Unit test for function linkify
def test_linkify():
    if __name__=="__main__":
        text = "Hello http://tornadoweb.org!"
        result = linkify(text)
        assert result == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!', result

# Generated at 2022-06-22 03:29:44.474403
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;&gt;") == "<>"



# Generated at 2022-06-22 03:29:46.286591
# Unit test for function url_escape
def test_url_escape():
    s = 'hello world'
    t = 'hello+world'
    assert url_escape(s) == t



# Generated at 2022-06-22 03:29:53.790041
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a" : "b"}) == '{"a": "b"}'
    assert json_encode({"a" : "</"}) == '{"a": "<\\/"}'
    

# json_encode_string is used when json_encode might return a
# non-string result, such as when encoding a dict.  It explicitly
# decodes the result to a string if necessary.

# Generated at 2022-06-22 03:29:55.648487
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    xhtml_unescape("&gt;&lt;&amp;&quot;&#39;")

# Generated at 2022-06-22 03:30:00.391513
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('[1,2,3]') == [1,2,3]
    assert json_decode(b'[1,2,3]') == [1,2,3]

_RECURSION_PROTECTION = set()  # type: typing.Set[Any]



# Generated at 2022-06-22 03:30:07.059604
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('This is a    test') == 'This is a test'
    
    
#_URL_UNSAFE = re.compile(r"[^\w\d\-\.~_]+")
#def url_escape(value: str, plus: bool = True) -> str:
#    """Escapes a URL for use in a URL query string or `<a>` tag.

#    This function is similar to `urllib.quote`, but it also replaces spaces
#    with ``+`` (plus) signs.  It does not handle non-ASCII characters
#    (which require special handling in Python 3, and must be encoded in
#    UTF-8 if used in URL paths).  It also does not encode ``~``,
#    which is sometimes used in URLs even though it is not stricty necessary.

#    .. versionchanged::

# Generated at 2022-06-22 03:30:15.970849
# Unit test for function json_decode
def test_json_decode():
    rst = json_decode('{\n    "clients_list": [[\n        "测试客户端安卓",\n        "2020-03-03",\n        "0"\n    ], [\n        "测试客户端2",\n        "2020-03-03",\n        "0"\n    ]]\n}')
    print(rst)
    assert isinstance(rst, dict)



# Generated at 2022-06-22 03:30:23.231202
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;tag&gt;') == '<tag>'
    assert xhtml_unescape('&#60;tag&#62;') == '<tag>'
    assert xhtml_unescape('&#x3c;tag&#x3e;') == '<tag>'

# Quoted-printable
_QUOTED_PRINTABLE_RE = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\xFF]")


# Generated at 2022-06-22 03:30:24.487766
# Unit test for function linkify
def test_linkify():
    linkify("http://www.yahoo.com")



# Generated at 2022-06-22 03:30:38.904770
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"foo": b"bar"}) == {"foo": "bar"}
    assert recursive_unicode([b"1", b"2", "3"]) == ["1", "2", "3"]
    assert recursive_unicode(("1", b"2", 3)) == ("1", "2", 3)
    assert recursive_unicode(b"foo") == "foo"
    # Sanity check: make sure it doesn't convert ints
    assert recursive_unicode(1) == 1
    assert recursive_unicode({"foo": 1}) == {"foo": 1}



# Generated at 2022-06-22 03:30:49.166835
# Unit test for function recursive_unicode
def test_recursive_unicode():
    import types
    d = {
        # `bytes` is unicode_type for python3
        "bytes": True,
        "str": True,
        "unicode": True,
        "list": [True, ()],
        "tuple": (True, []),
        "dict": {"str": True, "unicode": False},
        "set": {"str", "unicode"},
        "frozenset": frozenset(("str", "unicode")),
        "object": object(),
        "type": types.ModuleType,
        "None": None,
        # int, long, float, ...
    }
    assert recursive_unicode(d) == recursive_unicode(d)
    assert recursive_unicode(d) == d


# Generated at 2022-06-22 03:30:56.926784
# Unit test for function utf8
def test_utf8():
    assert utf8("This is a test") == b"This is a test"
    assert utf8(b"This is a test") == b"This is a test"
    assert utf8(None) is None
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:31:04.413723
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<p>Hello & World</p>") == "&lt;p&gt;Hello &amp; World&lt;/p&gt;"
    assert xhtml_escape("<p>Hello & World</p>", True) == "&lt;p&gt;Hello &amp; World&lt;/p&gt;"
    assert xhtml_escape("<p>Hello & World</p>", False) == "<p>Hello &amp; World</p>"



# Generated at 2022-06-22 03:31:08.879554
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == u'<a href="http://example.com">http://example.com</a>'
    assert linkify("www.example.com") == u'<a href="http://www.example.com">www.example.com</a>'
    assert linkify("Hello http://example.com") == u'Hello <a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/path with spaces") == u'<a href="http://example.com/path%20with%20spaces">http://example.com/path with spaces</a>'  # noqa: E501

# Generated at 2022-06-22 03:31:11.044640
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    value = "&#39;abcde12345&quot;&gt;&lt;"
    assert xhtml_unescape(value) == "'abcde12345\"><"



# Generated at 2022-06-22 03:31:17.526086
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"%C3%A9") == "é"
    assert url_unescape(b"%C3%A9", encoding=None) == b"\xc3\xa9"


# Note we can't use str.format here, since it's not available in Python 2.5

# Generated at 2022-06-22 03:31:25.278096
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('http://example.com/some%20path') == 'http://example.com/some path'
    assert url_unescape('http://example.com/some%2Bpath') == 'http://example.com/some+path'
    assert url_unescape('http://example.com/some%20path', plus=False) == 'http://example.com/some path'
    assert url_unescape('http://example.com/some%2Bpath', plus=False) == 'http://example.com/some%2Bpath'
    assert url_unescape(b'http://example.com/some%20path') == b'http://example.com/some path'

# Generated at 2022-06-22 03:31:28.957835
# Unit test for function recursive_unicode
def test_recursive_unicode():
    s = recursive_unicode({1: 'a', 2: 'b'})
    print(s)
    s = recursive_unicode([1, 2, 3])
    print(s)



# Generated at 2022-06-22 03:31:35.805991
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape("& &amp; &lt; &gt; &#33; &#33"))
    print(xhtml_unescape("&#33; &#33; &#33; &#33"))
    try:
        print(xhtml_unescape("&#33&; &#33; &#33; &#33"))
    except:
        print("decimal")
    try:
        print(xhtml_unescape("&#x1f; &#x1f; &#x1f; &#x1f"))
    except:
        print("hexdecimal")


# Generated at 2022-06-22 03:31:47.026950
# Unit test for function utf8
def test_utf8():
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(None) is None
    try:
        utf8(3)
        assert False, "Expected exception"
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:31:57.617265
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == """<a href="http://example.com">http://example.com</a>"""
    assert linkify("http://www.example.com") == """<a href="http://www.example.com">http://www.example.com</a>"""
    assert linkify("www.example.com") == """<a href="http://www.example.com">www.example.com</a>"""
    assert linkify("Hello http://example.com") == """Hello <a href="http://example.com">http://example.com</a>"""
    assert linkify("Hello http://www.example.com") == """Hello <a href="http://www.example.com">http://www.example.com</a>"""

# Generated at 2022-06-22 03:32:04.010806
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    urlinfo = parse_qs_bytes(b'a=1&b=2&c=3')
    assert urlinfo['a'] == [b'1']
    assert urlinfo['b'] == [b'2']
    assert urlinfo['c'] == [b'3']


# Generated at 2022-06-22 03:32:06.427165
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&amp;') == '&'


# Generated at 2022-06-22 03:32:11.180153
# Unit test for function native_str
def test_native_str():
    # Tests None
    assert native_str(None) is None
    # Tests unicode
    assert isinstance(native_str(u"\u00E9"), str)
    # Tests str
    assert isinstance(native_str("hello"), str)
    # Tests bytes
    assert isinstance(native_str(b"\xc3\xa9"), str)



# Generated at 2022-06-22 03:32:16.283065
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(dict(ascii=b"ascii", utf8=b"\xef\xbf\xbd")) == \
        {'ascii': 'ascii', 'utf8': "\ufffd"}
    assert recursive_unicode(["ascii", b"\xef\xbf\xbd"]) == \
        ['ascii', "\ufffd"]



# Generated at 2022-06-22 03:32:26.669279
# Unit test for function native_str
def test_native_str():
    if not isinstance(
        _unicode("hello"), unicode_type
    ):  # noqa: F821
        # hacky way to make pyflakes happy
        import builtins
        _unicode = getattr(builtins, "unicode")  # noqa: F821

    assert _native_str(b"hello") == "hello"
    assert _native_str("hello") == "hello"
    assert _native_str(u"hello") == u"hello"


_BASESTRING_TYPES = (str, bytes)



# Generated at 2022-06-22 03:32:28.313413
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1") == {"a": [b"1"]}



# Generated at 2022-06-22 03:32:29.624456
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  hello       world  ') == 'hello world'



# Generated at 2022-06-22 03:32:32.947193
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    (
        result,
        expected
    ) = (
        parse_qs_bytes(b"a=1&b=2;c=3"),
        {
            "a": [b"1"],
            "b": [b"2"],
            "c": [b"3"]
        }
    )

    assert result == expected


# Generated at 2022-06-22 03:32:42.602268
# Unit test for function native_str
def test_native_str():
    import sys
    if sys.version_info < (3, 0):
        assert util.native_str(None) == str(None)
        assert util.native_str(b"abc") ==  str(b"abc")
        assert util.native_str(u"abc") == str(u"abc")
    else:
        assert util.native_str(None) == str(None)
        assert util.native_str(b"abc") ==  str(b"abc", 'utf-8')
        assert util.native_str(u"abc") == str(u"abc")

# Generated at 2022-06-22 03:32:54.872960
# Unit test for function json_decode
def test_json_decode():
    assert json_decode(b"1") == 1
    assert json_decode('"x"') == "x"
    assert json_decode('true') == True
    assert json_decode('null') == None
    assert json_decode('{"a":1}') == {"a": 1}
    assert json_decode('[1, ""]') == [1, ""]
    try:
        json_decode('{"a":1')
        assert False
    except ValueError:
        pass


_json_decode = json_decode

try:
    import ujson
except ImportError:
    pass

# Generated at 2022-06-22 03:33:00.296001
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes("a=1&b=2&c=3")
    assert result == {b"a": [b"1"], b"b": [b"2"], b"c": [b"3"]}
test_parse_qs_bytes()
# End of unit test



# Generated at 2022-06-22 03:33:03.751549
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  a   b c    ") == "a b c"
    assert squeeze("  a   b c   d ") != "a b c d"



# Generated at 2022-06-22 03:33:09.943528
# Unit test for function json_decode
def test_json_decode():
    value = b'{"key1" : 1, "key2" : "value2"}'
    print(type(value), value)
    print(type(json_decode(value)), json_decode(value))
test_json_decode()

_recurser = (
    typing.Union[
        typing.List[
            str
        ],
        typing.List[
            typing.Dict[
                str,
                str
            ]
        ]
    ]
)


# Generated at 2022-06-22 03:33:15.261827
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
    print(linkify("Hello http://tornadoweb.org!", shorten=True))


# This singleton pattern does not work in a multithreaded environment.
# See notes in the module docstring.
_NULL_ARG_DEFAULT = object()



# Generated at 2022-06-22 03:33:26.823302
# Unit test for function json_encode
def test_json_encode():
    print("test json_encode")
    print("%s" % json_encode("abc"))
    print("%s" % json_encode("abc1"))
    print("%s" % json_encode("abc[1]"))
    print("%s" % json_encode("abc\"1"))
    print("%s" % json_encode("abc2"))
    print("%s" % json_encode("abc2"))
    print("%s" % json_encode("abc3"))
    print("%s" % json_encode("abc4"))
    print("%s" % json_encode("abc5"))
    print("%s" % json_encode("abc6"))
    print("%s" % json_encode("abc7"))

# Generated at 2022-06-22 03:33:38.471962
# Unit test for function linkify
def test_linkify():
    assert linkify(u"http://x.com") == u'<a href="http://x.com">http://x.com</a>'
    assert linkify(u"http://x.com", shorten=True) == u'<a href="http://x.com">http://x.com</a>'
    assert linkify(u"http://example.com") == u'<a href="http://example.com">http://example.com</a>'
    assert linkify(u"http://example.com", shorten=True) == u'<a href="http://example.com">example.com</a>'
    assert linkify(u"http://example.com/foo") == u'<a href="http://example.com/foo">http://example.com/foo</a>'

# Generated at 2022-06-22 03:33:42.155144
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs_str = 'a=1&b=2'
    res = parse_qs_bytes(qs_str)
    assert res['a'][0] == b'1'
    assert res['b'][0] == b'2'


# Generated at 2022-06-22 03:33:46.870194
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a+b") == "a+b"
    assert url_unescape("a b") == "a b"
    assert url_unescape("a+b", plus=False) == "a+b"
    assert url_unescape("a b", plus=False) == "a b"



# Generated at 2022-06-22 03:34:03.277462
# Unit test for function json_encode
def test_json_encode():
    # assert json.dumps({"name": "张三"}).replace("</", "<\\/") == r'{"name": "\u5f20\u4e09"}'
    assert json_encode({"name": "张三"}) == r'{"name": "\u5f20\u4e09"}'

# json_encode = json.dumps
# def test_json_encode():
#     assert json_encode({"name": "张三"}) == r'{"name": "\\u5f20\\u4e09"}'

# json_encode = json_encode
# def test_json_encode():
#     assert json_encode({"name": "张三"}) == r'{"name": "\u5f20\u4e09"}'

# Make

# Generated at 2022-06-22 03:34:10.078525
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.facebook.com/tornado") == '<a href="http://www.facebook.com/tornado">http://www.facebook.com/tornado</a>'
    assert linkify("www.facebook.com/tornado") == '<a href="http://www.facebook.com/tornado">www.facebook.com/tornado</a>'
    
test_linkify()
 
# 单元测试函数linkify（）

# Generated at 2022-06-22 03:34:15.172706
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(
        {'foo': bytes('foo', 'utf-8'), 'bar': b'bar', 'baz': ['foo', b'bar']}
    ) == {'foo': 'foo', 'bar': 'bar', 'baz': ['foo', 'bar']}
test_recursive_unicode()

# TODO: Figure out why the CharsetMetaClass is here.

# Generated at 2022-06-22 03:34:27.160697
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div/>") == "&lt;div/&gt;"
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_escape("\"") == "&quot;"
    assert xhtml_escape("\'") == "&#39;"
    assert xhtml_escape("abc'test") == "abc&#39;test"
    assert xhtml_escape("abc\"test") == "abc&quot;test"
    assert xhtml_escape("abc&test") == "abc&amp;test"
    assert xhtml_escape("abc&&test") == "abc&amp;&amp;test"
    assert xhtml_escape("abc\"test\'") == "abc&quot;test&#39;"
test_xhtml_escape()



# Generated at 2022-06-22 03:34:33.036677
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("%2B", plus=True) == "+"
    assert url_unescape("%2B", plus=False) == "%2B"
    assert url_unescape("%2B", encoding=None, plus=True) == b"+"
    assert url_unescape("%2B", encoding=None, plus=False) == b"%2B"



# Generated at 2022-06-22 03:34:37.338475
# Unit test for function json_decode
def test_json_decode():
    assert isinstance(json_decode("test"), str)
    assert isinstance(json_decode(b"test"), str)
    assert isinstance(json_decode(u"test"), str)
    assert isinstance(json_decode("[]"), list)


_UTF8_TYPES = (bytes, type(None))  # typing.AnyStr for python<3.7
_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:42.580378
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([b'byte', 'str', 'unicode']) == ['byte', 'str', 'unicode']
    assert recursive_unicode([b'byte', 'str', 'unicode']) == [b'byte', 'str', 'unicode']
test_recursive_unicode()



# Generated at 2022-06-22 03:34:51.522271
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes('key=value') == {b'key': [b'value']}
    assert parse_qs_bytes('key=value&key=value2') == {b'key': [b'value', b'value2']}
    assert parse_qs_bytes('key=value=value2') == {b'key': [b'value=value2']}
    assert parse_qs_bytes('key=value1=value2') == {b'key': [b'value1=value2']}
    assert parse_qs_bytes('key=value1%3Dvalue2') == {b'key': [b'value1=value2']}

# Generated at 2022-06-22 03:35:01.292046
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'foo': '<script>'}) == '{"foo": "<\\/script>"}'


_JSON_DECODE_OPTIONS = json.JSONDecodeError
if json.__version__ >= "2.6":
    # In simplejson 2.6 and later, the allow_nan argument determines whether
    # it is an error to parse a NAN or INF value.  Older versions implicitly
    # allowed this, so they did not have this argument.
    _JSON_DECODE_OPTIONS = {"allow_nan": False} # type: ignore



# Generated at 2022-06-22 03:35:07.514115
# Unit test for function recursive_unicode
def test_recursive_unicode():
    def check(obj, expected):
        assert recursive_unicode(obj) == expected

    check("foo", "foo")
    check(b"foo", "foo")
    check({"a": "b"}, {"a": "b"})
    check({"a": {"b": "c"}}, {"a": {"b": "c"}})
    check({"a": [b"b"]}, {"a": ["b"]})
    check({"a": (b"b", "c")}, {"a": ("b", "c")})
    check([b"foo", {"a": ("b", u"c")}], ["foo", {"a": ("b", u"c")}])



# Generated at 2022-06-22 03:35:19.416099
# Unit test for function json_encode
def test_json_encode():
    result = json_encode({"a" : "</"})
    if result == '{"a": "<\\/"}':
        print("pass")
    else:
        print("fail")
test_json_encode()



# Generated at 2022-06-22 03:35:24.871357
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"bytes") == u"bytes"
    assert recursive_unicode(u"unicode") == u"unicode"
    assert recursive_unicode({"bytes": b"bytes"}) == {u"bytes": u"bytes"}
    assert recursive_unicode([b"bytes"]) == [u"bytes"]
    assert recursive_unicode((b"bytes",)) == (u"bytes",)

    # Test invalid data types
    try:
        recursive_unicode(None)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-22 03:35:31.277232
# Unit test for function json_encode
def test_json_encode():
    import json
    d = {'a':1,'b':2}
    j = json.dumps(d)
    assert j == '{"a": 1, "b": 2}'
    j = json_encode(d)
    assert j == '{"a": 1, "b": 2}'

# Note that json_decode wraps json.loads.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-22 03:35:36.360457
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a+b+c", "utf-8") == "a b c"
    assert url_unescape(b"a+b+c", encoding=None) == b"a b c"
    assert url_unescape("a+b+c", "utf-8", plus=False) == "a+b+c"


# Generated at 2022-06-22 03:35:48.373064
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", require_protocol=False) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("ws://example.com/websocket", require_protocol=False) == 'ws://example.com/websocket'
    assert linkify("example.com", require_protocol=False) == '<a href="http://example.com">example.com</a>'
    assert linkify("hello http://example.com", require_protocol=False) == 'hello <a href="http://example.com">http://example.com</a>'

# Generated at 2022-06-22 03:35:49.341925
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a b  c d') == 'a b c d'


# Generated at 2022-06-22 03:35:53.281596
# Unit test for function xhtml_escape
def test_xhtml_escape():
    raw_string = '&<>"\''
    escaped_string = xhtml_escape(raw_string)
    assert escaped_string == "&amp;&lt;&gt;&quot;&#39;"

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:36:00.921566
# Unit test for function utf8
def test_utf8():
    assert utf8('hello') == b'hello'
    assert utf8(u'hello') == b'hello'
    assert utf8(None) is None
    try:
        utf8(object())
        assert False, 'Expected TypeError'
    except TypeError:
        pass
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:36:06.962159
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str(b"abc"), str)
    assert native_str(b"abc") == "abc"
    assert isinstance(native_str("abc"), str)
    assert native_str("abc") == "abc"


if str is bytes:
    native_str = to_unicode
else:
    native_str = to_basestring



# Generated at 2022-06-22 03:36:09.386810
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    data = xhtml_unescape('&#x21;')
    assert data == '!'

# Generated at 2022-06-22 03:36:18.788586
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"test": b"test"}) == {"test": "test"}



# Generated at 2022-06-22 03:36:31.155765
# Unit test for function native_str
def test_native_str():
    if six.PY3:
        assert native_str('hello') == 'hello'
        assert type(native_str('hello')) == str
        assert native_str(u'hello') == 'hello'
        assert type(native_str(u'hello')) == str
        assert native_str(b'foo\xef\xbf\xbdbar') == 'foo�bar'
        assert type(native_str(u'foo\xef\xbf\xbdbar')) == str
    else:
        assert native_str('hello') == 'hello'
        assert type(native_str('hello')) == str
        assert native_str(u'hello') == 'hello'
        assert type(native_str(u'hello')) == str

# Generated at 2022-06-22 03:36:36.737323
# Unit test for function url_unescape
def test_url_unescape():  # noqa: F811
    assert url_unescape("a+b", "utf-8", True) == "a b"
    assert url_unescape("a+b", "utf-8", False) == "a+b"
    assert url_unescape("a+b", None, True) == b"a b"
    assert url_unescape("a+b", None, False) == b"a+b"



# Generated at 2022-06-22 03:36:39.456004
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<'&\">") == '&lt;&#39;&amp;&quot;&gt;'


# Generated at 2022-06-22 03:36:43.224389
# Unit test for function squeeze
def test_squeeze():
    value = "Its a test String"
    assert squeeze(value) == "Its a test String"
    value = "Its a test      String"
    assert squeeze(value) == "Its a test String"
    value = "Its a test        String"
    assert squeeze(value) == "Its a test String"
    value = "Its a test         String"
    assert squeeze(value) == "Its a test String"


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:36:52.085660
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2") == {b"a": [b"1"], b"b": [b"2"]}
    assert parse_qs_bytes(b"a=1&a=2") == {b"a": [b"1", b"2"]}
    assert parse_qs_bytes(b"a=1&a=2&b=x") == {b"a": [b"1", b"2"], b"b": [b"x"]}


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:36:58.334168
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    s = b"foo=bar&hello=world"
    result = parse_qs_bytes(s)
    assert isinstance(result, dict)
    assert sorted(list(result.keys())) == ["foo", "hello"]
    assert result["foo"] == [b"bar"]
    assert result["hello"] == [b"world"]

    s = b"foo=bar&hello=world&foo=bar2"
    result = parse_qs_bytes(s)
    assert isinstance(result, dict)
    assert sorted(list(result.keys())) == ["foo", "hello"]
    assert result["foo"] == [b"bar", b"bar2"]
    assert result["hello"] == [b"world"]

    # Keep blank value
    s = b"foo=bar&foo="

# Generated at 2022-06-22 03:37:05.465547
# Unit test for function linkify
def test_linkify():
    s = linkify(
        '''<script>alert(1)</script>
    www.google.com
    localhost
    hello http://world!
    '''
    )
    assert(not 'script' in s)
    assert('google.com' in s)
    assert('localhost' in s)
    assert('http://world' in s)



# Generated at 2022-06-22 03:37:11.914000
# Unit test for function linkify
def test_linkify():
    sample1 = "Hello www.tornadoweb.org!"
    linkified1 = linkify(sample1)
    assert linkified1 == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!"
    assert linkify(sample1, require_protocol=True) == sample1

    sample2 = "Hello http://tornadoweb.org!"
    linkified2 = linkify(sample2)
    assert linkified2 == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

    sample3 = "Hello http://www.tornadoweb.org/page/index.html?param=1&param2=2#test!"
    linkified3 = linkify(sample3)

# Generated at 2022-06-22 03:37:15.175425
# Unit test for function json_decode
def test_json_decode():
    '''
    >>> res = json_decode('{"key": "value"}')
    >>> res
    {'key': 'value'}
    >>> res['key']
    'value'
    '''
    pass



# Generated at 2022-06-22 03:37:27.843804
# Unit test for function linkify
def test_linkify():
    text = "Hello, http://www.tornadoweb.org/en/stable/!"
    result = linkify(text)
    assert result == 'Hello, <a href="http://www.tornadoweb.org/en/stable/">http://www.tornadoweb.org/en/stable/</a>!'



# Generated at 2022-06-22 03:37:31.118248
# Unit test for function utf8
def test_utf8():
    assert utf8('Hello') == b'Hello'

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:37:34.966516
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("a&b<c>d\'e\"f") == "a&amp;b&lt;c&gt;d&#39;e&quot;f"


# Generated at 2022-06-22 03:37:36.655371
# Unit test for function url_escape
def test_url_escape():
    def add_one(x):
        return x+1
    assert add_one(2) == 3 
test_url_escape()


# Generated at 2022-06-22 03:37:38.513682
# Unit test for function squeeze
def test_squeeze():
    s = squeeze("a   b  c       d")
    assert s == "a b c d"


# Generated at 2022-06-22 03:37:44.020121
# Unit test for function url_escape
def test_url_escape():
    input = 'http://www.i.ua/'
    desired_output = 'http%3A//www.i.ua/'
    assert url_escape(input) == desired_output
    desired_output = 'http://www.i.ua/'
    assert url_escape(input, plus=False) == desired_output


# Generated at 2022-06-22 03:37:50.229888
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("aa   bb  cc    dd") == "aa bb cc dd"
    assert squeeze("aa\tbb\ncc\rdd") == "aa bb cc dd"
    assert squeeze(" aa   bb  cc    dd ") == "aa bb cc dd"

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:37:57.357984
# Unit test for function native_str
def test_native_str():
    assert native_str(u'abc\u1234') == 'abc\u1234'
    assert native_str(b'abc\xe1\x88\xb4') == u'abcሴ'
    assert native_str(None) is None
    # In python2, str(u'abc\u1234') == 'abc\\u1234'.
    # In python3, str(b'abc\xe1\x88\xb4') == "b'abc\\xe1\\x88\\xb4'".
# to_unicode() has been lifted from bencode.py, originally written by Petru Paler.
# This function makes sense as long as we are dealing with byte strings (not unicode objects).
# (We don't need to deal with unicode objects internally, because we assume that there are only
# latin1 byte strings in