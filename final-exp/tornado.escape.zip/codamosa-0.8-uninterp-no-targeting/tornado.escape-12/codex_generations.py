

# Generated at 2022-06-22 03:28:20.389207
# Unit test for function json_encode
def test_json_encode():
    value = [1, "one", [2, "two"], {3: "three"}]
    expected = '[1, "one", [2, "two"], {"3": "three"}]'
    assert json_encode(value) == expected

# import base64

# Generated at 2022-06-22 03:28:21.671400
# Unit test for function native_str
def test_native_str():
    assert native_str(1) == '1'



# Generated at 2022-06-22 03:28:29.712107
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'x=1&y=2&z=3'
    result = parse_qs_bytes(qs)
    assert(result == {'x': [b'1'], 'y': [b'2'], 'z': [b'3']})
    qs = 'x=1&x=2&x=3'
    result = parse_qs_bytes(qs)
    assert(result == {'x': [b'1', b'2', b'3']})



# Generated at 2022-06-22 03:28:36.355596
# Unit test for function url_unescape
def test_url_unescape():
    # typing: () -> None
    assert url_unescape(b"http%3A%2F%2Ffoo%2Ecom%2F") == "http://foo.com/"
    assert url_unescape(b"http%3A%2F%2Ffoo%2Ecom%2F", encoding=None) == b"http://foo.com/"
    assert url_unescape(b"%E5%B0%8F%E5%A7%90") == "小姐"
    assert url_unescape(b"%E5%B0%8F%E5%A7%90", encoding=None) == b"\xe5\xb0\x8f\xe5\xa7\x90"



# Generated at 2022-06-22 03:28:45.310746
# Unit test for function linkify
def test_linkify():
    text= "hello https://www.google.com, and https://www.yahoo.com"
    extra_params='rel="nofollow" class="external"'
    result = linkify(text, extra_params=extra_params)
    print(result)
#test_linkify()

XHTML_ESCAPE_RE = re.compile(r'[&<>"\']')
XHTML_ESCAPE_DICT = {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}



# Generated at 2022-06-22 03:28:55.571196
# Unit test for function utf8
def test_utf8():
    assert utf8(u'foo') == b'foo'
    assert utf8('foo') == b'foo'
    assert utf8(u'\N{SNOWMAN}') == b'\xe2\x98\x83'
    assert utf8(None) is None
    try:
        utf8(object())
        assert False, "did not get expected TypeError"
    except TypeError:
        pass
    try:
        utf8(1)
        assert False, "did not get expected TypeError"
    except TypeError:
        pass

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:04.627180
# Unit test for function json_encode
def test_json_encode():
    test_data = ['</script><script>alert(1)</script>']
    ret = json_encode(test_data)
    assert ret == '["<\\/script><script>alert(1)<\\/script>"]'


_JSON_DECODE_OPTIONS = json.JSONDecoder(strict=False).parse
try:
    _JSON_DECODE_OPTIONS = json.JSONDecoder(strict=False,
                                            object_pairs_hook=collections.OrderedDict).parse
except TypeError:
    # TypeError: object_pairs_hook is an unrecognized keyword argument
    pass



# Generated at 2022-06-22 03:29:16.523013
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('s')=='s'
    assert url_escape('s',plus=False)=='s'
    assert url_escape(utf8('s')) == 's'
    assert url_escape(utf8('s'),plus=False) == 's'
    assert url_escape(b'\xe5')=='%E5'
    assert url_escape(b'\xe5',plus=False)=='%E5'
    assert url_escape(utf8(b'\xe5')) == '%E5'
    assert url_escape(utf8(b'\xe5'),plus=False) == '%E5'
    assert url_escape(' ') == '%20'
    assert url_escape(' ') == '+'

# Generated at 2022-06-22 03:29:22.300357
# Unit test for function json_decode
def test_json_decode():
    value = '{"a":"a"}'
    json_decode(value)
    value = b'{"a":"a"}'
    json_decode(value)
    value = '{"a":"a"}'
    json_decode(value)


_HTML_UNSAFE_IN_JSON_RE = re.compile(r"[<>&='\"]")



# Generated at 2022-06-22 03:29:27.207732
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print('Test parse_qs_bytes')
    print(parse_qs_bytes(b'a=b&b=a'))
    print(parse_qs_bytes(b'a=b&b=a',keep_blank_values=True))


# Generated at 2022-06-22 03:29:48.258994
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a+b") == b"a b"
    assert url_unescape("a+b") == "a b"



# Generated at 2022-06-22 03:30:00.799739
# Unit test for function linkify
def test_linkify():
    assert(linkify("test string http://www.example.com", extra_params="target=_blank")
           == "test string <a href=\"http://www.example.com\" target=_blank>http://www.example.com</a>")
    assert(linkify("test string http://www.example.com?a=1&b=3", extra_params="target=_blank")
           == "test string <a href=\"http://www.example.com?a=1&b=3\" target=_blank>http://www.example.com?a=1&b=3</a>")

# Generated at 2022-06-22 03:30:11.056972
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8("foo".encode("latin1")) == b"foo"
    assert utf8(None) is None
    assert utf8(u"foo") == b"foo"
    assert utf8(b"foo") == b"foo"
    # assert utf8(1) == TypeError
    assert utf8("foo") == b"foo"
    assert utf8("foo".encode("latin1")) == b"foo"
    assert utf8(None) is None
    assert utf8(u"foo") == b"foo"
    assert utf8(b"foo") == b"foo"
    assert utf8(1) == TypeError


# Generated at 2022-06-22 03:30:21.572433
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(" ") == b" "
    assert utf8("한국") == b"\xed\x95\x9c\xea\xb5\xad"  # utf8
    assert utf8("한국") == b"\xed\x95\x9c\xea\xb5\xad"  # utf8
    assert utf8("한국".encode("utf8")) == b"\xed\x95\x9c\xea\xb5\xad"  # utf8
    assert utf8(b"abc") == b"abc"
    assert utf8(b" ") == b" "

# Generated at 2022-06-22 03:30:33.176966
# Unit test for function linkify
def test_linkify():
    import re
    text="This is my website <a href='https://yadunandank.github.io/'>https://yadunandank.github.io/</a> "
    assert linkify(text) == text, "Failed to linkify an already linked text"
    text = "This is my website https://yadunandank.github.io/ "
    assert re.search("<a href=[^>]*>https://yadunandank.github.io/<\/a>",linkify(text))

    text = "This is my website www.yadunandank.github.io "
    assert re.search("<a href=[^>]*>www.yadunandank.github.io<\/a>",linkify(text))


# Generated at 2022-06-22 03:30:45.646611
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http+%E4%BD%A0%E5%A5%BD%20",encoding="utf-8",plus=True) == "http+你好 "

# Generated at 2022-06-22 03:30:52.988467
# Unit test for function json_decode
def test_json_decode():
    a = '''[
    {
        "name": "id",
        "type": "int",
        "primary": true,
        "auto_increment": true
    },
    {
        "name": "name",
        "type": "text"
    }
]'''
    print(json_decode(a))
test_json_decode()

# urllib.parse.quote and urlparse.urlencode have inconsistent treatment of
# unicode strings in python2. In python3 they all accept unicode strings,
# but make different assumptions about how they should be encoded (latin1,
# utf-8). urllib_parse_urlencode is a wrapper around urlparse.urlencode for
# consistency with urllib_parse_quote.

# Generated at 2022-06-22 03:30:56.600865
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org, www.baidu.com!"
    result = linkify(text)
    print(result)

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-22 03:31:00.526150
# Unit test for function recursive_unicode
def test_recursive_unicode():
  assert recursive_unicode({"1":b"a", "2":[b"b", b"c"], "3":(b"d", b"e")}) == \
      {"1":"a", "2":["b", "c"], "3":("d", "e")}


# Generated at 2022-06-22 03:31:06.345667
# Unit test for function recursive_unicode
def test_recursive_unicode():
    test_dict = {'key': 'value', 'key1': 123}
    assert recursive_unicode(test_dict) == {'key': 'value', 'key1': 123}
    test_list = [1,2,3]
    assert recursive_unicode(test_list) == [1,2,3]



# Generated at 2022-06-22 03:31:23.392628
# Unit test for function json_encode
def test_json_encode():
    d = {'name': 'liujian', 'age': 28}
    print(json_encode(d))



# Generated at 2022-06-22 03:31:29.499017
# Unit test for function utf8
def test_utf8():
    assert utf8(None) == None
    assert utf8("") == b""
    assert utf8('\xe2\x9c\x93') == b"\xe2\x9c\x93"

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:31:31.893707
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("      \t\r\n\r\n\r\nHello   world   !\r\n\r\n\r\n") == "Hello world !"


# Generated at 2022-06-22 03:31:35.576659
# Unit test for function linkify
def test_linkify():
    text = "hello http://tornadoweb.org rain http://qq.com"
    new_text = linkify(text, shorten=True, extra_params="", require_protocol=False, permitted_protocols=["http", "https"])
    print(new_text)


# Generated at 2022-06-22 03:31:37.518257
# Unit test for function linkify
def test_linkify():
    assert linkify(u"foo http://www.google.com bar") == u'foo <a href="http://www.google.com">http://www.google.com</a> bar'



# Generated at 2022-06-22 03:31:41.655271
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'sample': 'blah'}) == '{"sample": "blah"}'
    assert json_encode({'<': '>'}) == '{"<": ">"}'
    assert json_encode({'<': '</script>'}) == '{"<": "<\\/script>"}'



# Generated at 2022-06-22 03:31:48.093447
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj1 = [b"abc", "def", [b"ghi", u"jkl"], {u"mno": b"pqr", "stu": b"vwx"}]
    obj2 = recursive_unicode(obj1)
    # assertEqual is too verbose for this simple test (and unit tests
    # should be simple)
    assert obj2 == [u'abc', 'def', [u'ghi', 'jkl'], {'stu': u'vwx', u'mno': u'pqr'}]



# Generated at 2022-06-22 03:31:53.525772
# Unit test for function native_str
def test_native_str():
    unicode_arg = u"test\u2603"
    bytes_arg = b"test\xe2\x98\x83"
    assert native_str(unicode_arg) == "test\u2603"
    assert native_str(bytes_arg) == "test\u2603"



# Generated at 2022-06-22 03:31:59.433821
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({}) == "{}"
    assert json_encode({"a": 3, "b": "abc"}) == '{"a": 3, "b": "abc"}'
    # 非dict对象类型
    assert json_encode([1, 2, 3]) == '[1, 2, 3]'
    assert json_encode((1, 2, 3)) == '[1, 2, 3]'
    """
    assert json_encode(3) == '3'
    """



# Generated at 2022-06-22 03:32:11.136903
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b'123') == '123'
    assert recursive_unicode(123) == 123
    assert recursive_unicode([b'123']) == ['123']
    assert recursive_unicode([123]) == [123]
    assert recursive_unicode([[b'123']]) == [['123']]
    assert recursive_unicode([[123]]) == [[123]]
    assert recursive_unicode({b'key': b'123'}) == {'key': '123'}
    assert recursive_unicode({'key': b'123'}) == {'key': '123'}
    assert recursive_unicode({'key': 123}) == {'key': 123}
    assert recursive_unicode({b'key': 123}) == {'key': 123}
    
test_recursive_unicode()


# Generated at 2022-06-22 03:32:20.545487
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = "<>"
    result = xhtml_escape(value)
    assert result == "&lt;&gt;"



# Generated at 2022-06-22 03:32:31.157364
# Unit test for function json_encode
def test_json_encode():
    import json
    x = u"\xb5"
    y = json.dumps(x)
    assert y == '"\u00b5"'
    y = json.dumps("\xb5")
    assert y == '"\u00b5"'
    y = json.dumps("\xb5".encode("utf-8"))
    assert y == '"\u00b5"'
    y = json.dumps("\xb5".encode("latin1"))
    assert y == '"\u00b5"'
    y = json.dumps("\xb5".encode("latin1").decode("utf-8"))
    assert y == '"\u00b5"'
    y = json_encode("\xb5")
    assert y == '"\u00b5"'

# Generated at 2022-06-22 03:32:36.644378
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
  print('Test xhtml_unescape')
  assert('<>&"\'' == xhtml_unescape('&lt;&gt;&amp;"\''))

_BASESTRING_TYPES = (str, bytes)

# Type alias
_UNICODE_TYPES = typing.Union[str, bytes]
_UNICODE_TYPE = str


# Generated at 2022-06-22 03:32:44.875302
# Unit test for function recursive_unicode

# Generated at 2022-06-22 03:32:53.611874
# Unit test for function utf8
def test_utf8():
    assert utf8(b"foo") is b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(None) is None
    assert utf8(u"foo") == b"foo"
    assert utf8(u"\u2603") == '\xe2\x98\x83'
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        raise Exception("Expected TypeError")



# Generated at 2022-06-22 03:33:01.465729
# Unit test for function native_str
def test_native_str():
    assert native_str(b"abc") == "abc"
    assert native_str(u"abc") == "abc"
    assert native_str(None) is None
    assert native_str(123) == "123"
    assert native_str(Exception()) == "<Exception at 0x%x>" % id(Exception())


_BASESTRING_TYPES = (unicode_type, bytes, type(None))



# Generated at 2022-06-22 03:33:11.593053
# Unit test for function recursive_unicode
def test_recursive_unicode():
    l = [
        1,
        2,
        3,
        {
            'int': 1,
            'float': 2.0,
            'list': [1, 2, 3],
            'tuple': (1, 2, 3),
            'dict': {1: 11, 2: 22, 3: 33},
        },
        {
            b'int': 1,
            b'float': 2.0,
            b'list': [1, 2, 3],
            b'tuple': (1, 2, 3),
            b'dict': {1: 11, 2: 22, 3: 33},
        },
    ]
    recursive_unicode(l)
    assert 'int' in l[3]
    assert 'float' in l[3]
    assert 'list' in l[3]

# Generated at 2022-06-22 03:33:15.216996
# Unit test for function utf8
def test_utf8():
    assert utf8('abcd') == b'abcd'
    assert utf8(None) == None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:33:26.780927
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print("\nTesting function parse_qs_bytes")
    from tornado.httputil import parse_qs_bytes
    qs = b"a=%61&b=+&c=a+b&d=%26%3d"
    result = parse_qs_bytes(qs)
    print("result =", result)
    assert isinstance(result, dict)
    assert len(result) == 4
    assert b"a" in result and isinstance(result[b"a"], list) and len(result[b"a"]) == 1 and result[b"a"][0] == b"a"
    assert b"b" in result and isinstance(result[b"b"], list) and len(result[b"b"]) == 1 and result[b"b"][0] == b" "
    assert b"c"

# Generated at 2022-06-22 03:33:30.081055
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert(recursive_unicode(b'\x80') == u'\u0080')
test_recursive_unicode()



# Generated at 2022-06-22 03:33:40.199672
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'fields%2C%20quotes', encoding=None) == b'fields, quotes'
    assert url_unescape('fields%2C%20quotes') == 'fields, quotes'
    with pytest.raises(TypeError):
        url_unescape(b'fields%2C%20quotes', encoding='utf-8')


# Generated at 2022-06-22 03:33:42.477205
# Unit test for function utf8
def test_utf8():
  assert True


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:33:49.020337
# Unit test for function utf8
def test_utf8():
    assert utf8(u"Hello") == b"Hello"
    assert utf8(u"Hello\n") == b"Hello\n"
    assert utf8(b"Hello") == b"Hello"
    assert utf8(b"Hello\n") == b"Hello\n"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:33:53.279999
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"foo": b"bar"}) == {"foo": "bar"}
    assert recursive_unicode([b"bar", {"foo": b"bar"}]) == ["bar", {"foo": "bar"}]



# Generated at 2022-06-22 03:34:04.787600
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b'123') == '123'
    assert recursive_unicode(['1',2,b'3']) == ['1',2,'3']
    assert recursive_unicode((('1',2),'3',[b'4',b'5'])) == (('1',2),'3',['4','5'])
    assert recursive_unicode({'1': 2, b'3': {b'4': [5,6]}}) == {'1':2, '3':{'4':[5,6]}}
    assert recursive_unicode(dict) == dict
    assert recursive_unicode(list) == list
    assert recursive_unicode(tuple) == tuple
    assert recursive_unicode(bytes) == bytes


# Generated at 2022-06-22 03:34:14.891612
# Unit test for function linkify
def test_linkify():
    def test_linkify(text, urls_expected, extra_params_expected=''):
        html = linkify(text, extra_params='rel="nofollow"')
        for url in urls_expected:
            assert url in html, \
            '%s not in %s for %s' % (url, html, text)
        for url in urls_expected:
            assert 'href="%s"' % url in html, \
            'href="%s" not in %s for %s' % (url, html, text)
        for extra in extra_params_expected:
            assert extra in html, \
            '%s not in %s for %s' % (extra, html, text)

    test_linkify("http://example.com", ["http://example.com"])

# Generated at 2022-06-22 03:34:19.514001
# Unit test for function native_str
def test_native_str():
    if isinstance(u'a', str):
        assert native_str(u'a') == 'a'
        assert native_str(b'a') == b'a'
    else:
        assert native_str(u'a') == u'a'
        assert native_str(b'a') == 'a'

# Generated at 2022-06-22 03:34:29.883609
# Unit test for function squeeze
def test_squeeze():
    assert "abc" == squeeze("abc")
    assert "abc" == squeeze("abc ")
    assert "abc" == squeeze("abc  ")
    assert "abc" == squeeze(" abc")
    assert "abc" == squeeze("  abc")
    assert "abc" == squeeze(" abc ")
    assert "abc" == squeeze("  abc  ")
    assert "a b c" == squeeze("a   b    c")
    assert "a b c" == squeeze("a\tb\tc")
    assert "a b c" == squeeze("a\nb\nc")
    assert "a b c" == squeeze("a\rb\rc")
    assert "a b c" == squeeze("a\rb\nc")
    assert "a b c" == squeeze("a\nb\rc")
    assert "a b c"

# Generated at 2022-06-22 03:34:38.949213
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    x = "&lt;&gt;&quot;&apos;&amp;"
    assert xhtml_unescape(x) == "<>\"'&"
    x = "&#60;&#62;&#34;&#39;&#38;"
    assert xhtml_unescape(x) == "<>\"'&"
    x = "&#x3c;&#x3e;&#x22;&#x27;&#x26;"
    assert xhtml_unescape(x) == "<>\"'&"
    x = "&lt;&gt;&quot;&apos;&amp;&#34;"
    assert xhtml_unescape(x) == "<>\"'&\""

# Generated at 2022-06-22 03:34:48.906180
# Unit test for function json_decode
def test_json_decode():
    # Test with str input
    # given str
    #str_input = '{ "a": "b" }'
    # TypeError: the JSON object must be str, not 'UnicodeType'
    #json_object = json_decode(str_input)
    #assert json_object == json.loads(str_input)
    
    # Test with bytes input
    bytes_input = b'{ "a": "b" }'
    json_object = json_decode(bytes_input)
    assert json_object == json.loads(bytes_input.decode('utf-8'))
    # Also test with str input
    str_input = bytes_input.decode('utf-8')
    json_object = json_decode(str_input)
    assert json_object == json.loads(str_input)

# Generated at 2022-06-22 03:35:00.835274
# Unit test for function recursive_unicode
def test_recursive_unicode():
    import os
    import shutil
    import tempfile
    
    name = 'recursive'
    data = {
        "path" : tempfile.mkdtemp(name),"name" : name
    }

    recursive_unicode(data)
    assert(isinstance(data["name"], str))
    shutil.rmtree(data["path"])


# Generated at 2022-06-22 03:35:08.030095
# Unit test for function recursive_unicode
def test_recursive_unicode():
    test_obj = {'a':1, 'b':b'\xc2\x80', 'c':b'a\xc2\x80', 'd':'a\xc2\x80', 
                'e':{'a': b'\xc2\x80', 'b':'a\xc2\x80'},
                'f':[b'\xc2\x80'], 'g':(b'a\xc2\x80', 'a\xc2\x80'),
                'h':[{'a':b'\xc2\x80'}], 'i':{'a':[b'a\xc2\x80']}}
    assert recursive_unicode(test_obj) == test_obj

# Generated at 2022-06-22 03:35:18.423557
# Unit test for function native_str
def test_native_str():
    assert native_str("abc") == "abc"
    assert native_str(b"abc") == "abc"
    assert native_str(u"abc") == "abc"
    assert native_str(u"\xe9") == "\xc3\xa9"

    x = u"\xe9"
    x = x.encode("utf-8")
    assert native_str(x) == "\xc3\xa9"

    x = u"\xe9"
    x = x.encode("latin1")
    assert native_str(x) == "\xe9"



# Generated at 2022-06-22 03:35:21.969371
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"hello", encoding=None) == b"hello"
    assert url_unescape(b"%25", encoding=None) == b"%"
    assert url_unescape(b"%25", encoding="utf-8") == "%"
    assert url_unescape(b"hello+world", encoding=None) == b"hello+world"
    assert url_unescape(b"hello+world", encoding="utf-8") == "hello world"
    assert url_unescape(u"hello+world", encoding=None) == b"hello+world"
    assert url_unescape(u"hello+world", encoding="utf-8") == "hello world"
    assert url_unescape(b"hello%20world", encoding=None) == b"hello world"

# Generated at 2022-06-22 03:35:27.085142
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"foo") == "foo"
    assert recursive_unicode([b"foo", b"bar"]) == ["foo", "bar"]
    assert (
        recursive_unicode({"foo": b"bar", "baz": [b"quux", b"corge"]})
        == {"foo": "bar", "baz": ["quux", "corge"]}
    )



# Generated at 2022-06-22 03:35:30.599727
# Unit test for function squeeze
def test_squeeze():
    assert "a b" == squeeze("a    b")
    assert "" == squeeze("")
    assert " " == squeeze(" ")
    assert " a" == squeeze(" a")
    assert "a " == squeeze("a ")


# Generated at 2022-06-22 03:35:32.126218
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('\n Hello  nb\t') == 'Hello nb'



# Generated at 2022-06-22 03:35:45.038460
# Unit test for function utf8
def test_utf8():
    assert utf8(" ".encode("utf-8")) is not None
    assert utf8("") == b""
    assert utf8(None) is None
    assert utf8("abc") == b"abc"
    assert utf8("\u00fc") == b"\xc3\xbc"
    assert utf8("\u00fc".encode("utf-8")) == b"\xc3\xbc"
    assert utf8("\u00fc".encode("utf-8")) is not None
    assert utf8("\u00fc".encode("latin1")) == b"\xfc"
    assert utf8("\u00fc".encode("latin1")) is not None
    assert utf8(2) == b"2"
test_utf8()



# Generated at 2022-06-22 03:35:53.511638
# Unit test for function utf8
def test_utf8():
    assert utf8("") == b""
    assert utf8("hello") == b"hello"
    assert utf8(b"hello") == b"hello"
    assert utf8(None) is None
    try:
        utf8(5)
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:36:05.578184
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str('\xe4\xb8\xad\xe6\x96\x87'), str)
    assert isinstance(native_str(b'\xe4\xb8\xad\xe6\x96\x87'), str)
    assert isinstance(native_str(u'\u4e2d\u6587'), str)

    assert native_str('\xe4\xb8\xad\xe6\x96\x87') == '中文'
    assert native_str('\xe4\xb8\xad\xe6\x96\x87', 'utf8') == '中文'
    assert native_str('\xe4\xb8\xad\xe6\x96\x87', 'gbk') == '中文'


# Generated at 2022-06-22 03:36:20.099160
# Unit test for function json_decode
def test_json_decode():
    a = json_decode('{\"a\":\"v\",\"b\":1}')
    assert isinstance(a, dict)
    assert len(a) == 2, len(a)
    # assert a['a'] == 'v', a


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:36:27.276190
# Unit test for function squeeze
def test_squeeze():
    assert 'a    b' == squeeze('a    b')
    assert 'a b' == squeeze('a    b')
    assert 'a b' == squeeze('  a    b  ')
    assert 'a b' == squeeze('  a\nb  ')
    assert squeeze('a\n\nb') == 'a b'
    assert squeeze('a\n\rb') == 'a\rb'
    assert 'a  b' == squeeze('a\t\nb')



# Generated at 2022-06-22 03:36:29.982134
# Unit test for function json_encode
def test_json_encode():
    #
    a=json_encode("abc")

# Generated at 2022-06-22 03:36:33.463669
# Unit test for function json_encode
def test_json_encode():
    assert json_encode('abc') == '"abc"'
    assert json_encode("</") == '"<\\/"'
    assert json_encode("<\\/") == '"<\\\\\\/"'

test_json_encode()



# Generated at 2022-06-22 03:36:40.168084
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = recursive_unicode(
        {"foo": b"bar", "baz": [b"quux", b"corge"], "grault": ("garply", "waldo", b"fred")}
    )
    if x != {
        "foo": "bar",
        "baz": ["quux", "corge"],
        "grault": ("garply", "waldo", "fred"),
    }:
        raise Exception("recursive_unicode failed")



# Generated at 2022-06-22 03:36:47.045608
# Unit test for function recursive_unicode
def test_recursive_unicode():
    o1 = {b"a": b"b", u"c": u"d"}
    assert recursive_unicode(o1)=={u"a": u"b", u"c": u"d"}
    o2 = [b"a", u"b", [b"c", u"d"]]
    assert recursive_unicode(o2)==[u"a", u"b", [u"c", u"d"]]



# Generated at 2022-06-22 03:36:54.573942
# Unit test for function squeeze
def test_squeeze():
    #squeeze works as expected
    print(squeeze("     all     whitespace     stuff      ") == "all whitespace stuff")
    #squeeze squeezes, but doesn't remove all whitespace
    print(squeeze("     all     whitespace     stuff      ") != "allwhitespacestuff")
    #squeeze doesn't split words
    print(squeeze("      all   whitespace     stuff      ") != "allwhitespacestuff")
    #squeeze doesn't work with non-strings
    try:
        squeeze(1)
    except:
        print(True)


# Generated at 2022-06-22 03:36:55.378545
# Unit test for function url_escape
def test_url_escape():
    url_escape("foo")


# Generated at 2022-06-22 03:37:05.425917
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(123) == "123"
    assert xhtml_escape(None) == "None"
    assert xhtml_escape("abc") == "abc"


# htmldecode and htmlencode are copied from cgi.escape in Python 3.4
# with the addition of a couple extra characters to the html5 entities
# dict.

_HTML5_UNICODE_MAP = {
    "&apos;": "'",
    "&quot;": '"',
    "&apos;": "'",
    "&#x2f;": "/"
}



# Generated at 2022-06-22 03:37:07.700770
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = {"a": 1, "b": [1, 2, 3], "c": b"ddd", "d": ("c", "d")}
    res = recursive_unicode(x)
    pass



# Generated at 2022-06-22 03:37:33.727051
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{}") == {}
    assert json_decode("true") is True
    assert json_decode("10") == 10
    assert json_decode("\"10\"") == "10"
    assert json_decode("[1,2,3]") == [1, 2, 3]
    assert json_decode("\"{\\\"key\\\":\\\"value\\\"}\"") == {"key": "value"}



# Generated at 2022-06-22 03:37:39.912246
# Unit test for function xhtml_escape
def test_xhtml_escape():
    s = "bla<a>\n&nbsp;\ndf>'\""
    assert xhtml_escape(s) == "bla&lt;a&gt;\n&amp;nbsp;\ndf&gt;&#39;&quot;"

_URL_ESCAPE_RE = re.compile(r"[\x00-\x20%'" + r'()<>@,;:\\"/\[\]\?={}]')



# Generated at 2022-06-22 03:37:44.409877
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    b_qs = b'foo=abc&bar=xy+z&bar=123'
    qs = 'foo=abc&bar=xy+z&bar=123'
    assert parse_qs_bytes(q) == parse_qs_bytes(b_qs)

# Generated at 2022-06-22 03:37:54.506420
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # type: () -> None
    assert recursive_unicode("foo") == "foo"
    assert recursive_unicode("foo".encode("utf-8")) == "foo"
    assert recursive_unicode("foo".encode("ascii")) == "foo"
    assert recursive_unicode("foo".encode("ascii").decode("utf-8")) == "foo"
    assert recursive_unicode("föo".encode("latin-1").decode("utf-8")) == "föo"
    assert recursive_unicode(1) == 1
    assert recursive_unicode([1, 2, 3]) == [1, 2, 3]
    assert recursive_unicode((1, 2, 3)) == (1, 2, 3)