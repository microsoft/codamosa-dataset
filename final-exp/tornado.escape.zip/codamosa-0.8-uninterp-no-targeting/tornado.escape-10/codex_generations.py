

# Generated at 2022-06-22 03:28:33.062062
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=bar&foo=baz&blah=&blah=a&blah=b', True) == {'foo': [b'bar', b'baz'], 'blah': [b'', b'a', b'b']}
    assert parse_qs_bytes(b'foo=bar&foo=baz&blah=&blah=a&blah=b') == {'foo': [b'bar', b'baz'], 'blah': [b'a', b'b']}

# Generated at 2022-06-22 03:28:45.097363
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'', strict_parsing=True) == dict()
    assert parse_qs_bytes(b'a=1', strict_parsing=True) == dict(a=['1'])
    assert parse_qs_bytes(b'a=1&b=2', strict_parsing=True) == dict(a=['1'], b=['2'])
    assert parse_qs_bytes(b'a=1&a=2', strict_parsing=True) == dict(a=['1', '2'])
    assert parse_qs_bytes(b'a=&a=2', strict_parsing=True) == dict(a=['', '2'])
    assert parse_qs_bytes(b'a=&a=', strict_parsing=True) == dict

# Generated at 2022-06-22 03:28:46.271100
# Unit test for function url_escape
def test_url_escape():
    print(url_escape('abcd?123'))


# Generated at 2022-06-22 03:28:53.757502
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    r1 = parse_qs_bytes(b"one=1&two=2")
    assert isinstance(r1, dict)
    assert r1 == {b"one": [b"1"], b"two": [b"2"]}

    r2 = parse_qs_bytes(b"one=&two=2")
    assert r2 == {b"one": [b""], b"two": [b"2"]}


# Generated at 2022-06-22 03:29:04.627874
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = {
        u"ascii": b"ascii",
        u"dict": {
            u"foo": b"bar",
            u"unicode": u"blah\u1234"
        },
        u"list": [
            b"blah",
            {
                u"ascii": b"ascii",
                u"unicode": u"blah\u1234"
            },
            u"blah\u1234",
            b"blah"
        ]
    }
    x_unicode = recursive_unicode(x)
    for keys, values in x_unicode.items():
        assert isinstance(keys, unicode_type)

# Generated at 2022-06-22 03:29:10.157558
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(None) == "null"
    assert json_encode(1) == "1"
    assert json_encode(["foo"]) == '["foo"]'
    assert json_encode({"foo": 1}) == '{"foo": 1}'
test_json_encode()



# Generated at 2022-06-22 03:29:21.547051
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    # The following test code is from tornado project
    test_input = "&#62;&#x3e;&#X3E;&#x3E;&LT;&lt;&notit;&#60;&#060;&#0060;&#00060;&#000060;&#0000060;&#60;"
    expected_output = "><><><<<<><<<<<<"
    assert xhtml_unescape(test_input) == expected_output
    # The following test code is from tornado project
    test_input = "&#62&#x3E&#X3E&#x3E&LT&lt<&notit;&#60&#060&#0060&#00060&#000060&#0000060&#60"

# Generated at 2022-06-22 03:29:27.605691
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org! world@google.com"
    expect = 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>! <a href="mailto:world@google.com">world@google.com</a>'
    assert linkify(text) == expect

# Generated at 2022-06-22 03:29:40.204934
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<a href="&">') == '&lt;a href=&quot;&amp;&quot;&gt;'
# test_xhtml_escape

_URL_ESCAPE_RE = re.compile("%s|%s" % (
    re.escape("%:&=+$,/?#[]!~*'()@|;\""),
    "%"
))
# NOTE: urllib.quote only encodes spaces as '+', not '%20'. We're
# going to punt on that, and encode spaces as '%20', which is more
# correct, and also makes our purposes here work correctly.

# Generated at 2022-06-22 03:29:47.734092
# Unit test for function utf8
def test_utf8():
  assert utf8(b'foo') == b'foo'
  assert utf8('foo') == b'foo'
  assert utf8(u'foo') == b'foo'
  assert utf8(None) is None
  assert utf8(1) == b'1'
  assert utf8(object()) == b'<object object at 0x%x>' % id(object())


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:30:03.021192
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'x': b'foo'}) == {'x': 'foo'}
    assert recursive_unicode({u'x': b'foo'}) == {'x': 'foo'}
    assert recursive_unicode([b'foo']) == ['foo']
    assert recursive_unicode((b'foo',)) == ('foo',)
    assert recursive_unicode(b'foo') == 'foo'



# Generated at 2022-06-22 03:30:06.973242
# Unit test for function linkify
def test_linkify():
    msg = "This is a test http://www.google.com of linkify"
    linkified = linkify(msg)

# Generated at 2022-06-22 03:30:13.314265
# Unit test for function utf8
def test_utf8():
    utf8(None)
    utf8('123')
    utf8(b'123')


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:30:18.211878
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;&#39;&quot;&quot;&#34;&#x27;&#x27;') == "''\"\"\"''"
    assert xhtml_unescape('&lt;&gt;&amp;') == "<>&"


_BASESTRING_TYPES = typing.Union[str, bytes]



# Generated at 2022-06-22 03:30:21.298999
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('https://www.baidu.com') == 'https%3A//www.baidu.com'
test_url_escape()

# Generated at 2022-06-22 03:30:28.129737
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"abc") == "abc"
    assert recursive_unicode(dict(a=b"a", b=b"b")) == {"a": "a", "b": "b"}
    assert recursive_unicode(["a", b"b", 123]) == ["a", "b", 123]
    assert recursive_unicode(("a", b"b", 123)) == ("a", "b", 123)



# Generated at 2022-06-22 03:30:32.229895
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;Hello&gt;") == "<Hello>"
    assert xhtml_unescape('&quot;Hello&quot;') == '"Hello"'
    assert xhtml_unescape('&#39;Hello&#39;') == "'Hello'"



# Generated at 2022-06-22 03:30:35.175416
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = ">>> <><<>><<>"
    assert(xhtml_escape(value)=='>>> &lt;&gt;&lt;&lt;&gt;&lt;&lt;&gt;')


# Generated at 2022-06-22 03:30:37.644445
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  a  b  c  ') == 'a b c'
    

# Generated at 2022-06-22 03:30:43.705243
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert b"\xe6\xb5\x8b\xe8\xaf\x95" == parse_qs_bytes("%E6%B5%8B%E8%AF%95")["%E6%B5%8B%E8%AF%95"][0]



# Generated at 2022-06-22 03:30:58.944760
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8(b"foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(None) == None
    try:
        utf8(1)
        raise Exception("Expected TypeError")
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:31:07.133803
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;span&gt;Hello&#x2F;World&lt;&#x2F;span&gt;") == "<span>Hello/World</span>"
    assert xhtml_unescape("&amp;&amp;&amp;&amp;&lt;") == "&&&&<"
    assert xhtml_unescape("&lt;&amp;&gt;&amp;&amp;&lt;") == "<&>&&<"
test_xhtml_unescape()

# Used by xhtml_unescape

# Generated at 2022-06-22 03:31:10.061766
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<Hello, World>") == "&lt;Hello, World&gt;"
    assert xhtml_escape("<&'Hello, World'>") == "&lt;&amp;'Hello, World'&gt;"



# Generated at 2022-06-22 03:31:22.091497
# Unit test for function xhtml_escape
def test_xhtml_escape():
    pluies = u"Piégé dans l'ascenseur, j'ai vu, l'accident, c'était incroyable."
    escape_pluies = xhtml_escape(pluies)
    assert escape_pluies == "Piégé dans l'ascenseur, j'ai vu, l'accident, c'était incroyable."
# Test for function xhtml_escape
test_xhtml_escape()


_JSON_DECODE_PATTERN = re.compile(r"\\(\\|'|\"|/|b|f|n|r|t|u([0-9a-fA-F]{4}))")

# Generated at 2022-06-22 03:31:31.235444
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query = b'foo=bar&foo=baz&blah=%20spam%20'
    result = parse_qs_bytes(query)
    assert isinstance(result, dict)
    assert isinstance(result['foo'], list)
    for item in result['foo']:
        assert isinstance(item, bytes)
    assert result['foo'][0] == b'bar'
    assert result['foo'][1] == b'baz'
    assert result['blah'][0] == b'spam '



# Generated at 2022-06-22 03:31:38.924546
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a%20b", encoding="utf-8") == "a b"
    assert url_unescape(b"a%20b", encoding="ascii") == "a b"
    assert url_unescape(b"a+b", encoding="utf-8") == "a b"
    assert url_unescape(b"a+b", encoding="ascii") == "a+b"
    assert url_unescape(b"a%20b", encoding="utf-8", plus=False) == "a b"
    assert url_unescape(b"a%20b", encoding="ascii", plus=False) == "a b"
    assert url_unescape(b"a+b", encoding="utf-8", plus=False) == "a+b"
    assert url_unescape

# Generated at 2022-06-22 03:31:48.773060
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<html></html>') == "&lt;html&gt;&lt;/html&gt;"

# Escapes a string so it is valid within HTML or XML.
# Escapes the characters <, >, ", ', and &. When used in attribute values the
# escaped strings must be enclosed in quotes.
_xhtml_escape_re = re.compile('[&<>"]')
_xhtml_escape_dct = {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': "&quot;"}
_xhtml_escape = lambda value: _xhtml_escape_re.sub(
    lambda match: _xhtml_escape_dct[match.group(0)], to_basestring(value))

# html_escape is deprecated in

# Generated at 2022-06-22 03:31:59.227139
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'key': 'value'}) == {'key': 'value'}
    assert recursive_unicode({b'key': b'value'}) == {'key': 'value'}
    assert recursive_unicode({b'key': b'value', 'key': 'value'}) == {'key': 'value'}
    assert recursive_unicode(['value1', b'value2', 'value3']) == ['value1', 'value2', 'value3']
    assert recursive_unicode([b'value1', b'value2', 'value3']) == ['value1', 'value2', 'value3']
    assert recursive_unicode((b'value1', 'value2')) == ('value1', 'value2')

# Generated at 2022-06-22 03:32:04.159775
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = b"foo=bar&foo=baz&blah=&blah=asdf&foo=&foo="
    print(parse_qs_bytes(qs))


# test_parse_qs_bytes()



# Generated at 2022-06-22 03:32:11.139108
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"x": b"asdf"}) == {"x": u"asdf"}
    assert recursive_unicode({"x": {"y": b"asdf"}}) == {"x": {"y": u"asdf"}}
    assert recursive_unicode([b"asdf"]) == [u"asdf"]
    assert recursive_unicode((b"asdf",)) == (u"asdf",)
    assert recursive_unicode(b"asdf") == u"asdf"



# Generated at 2022-06-22 03:32:26.623578
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = b"a=1&b=2&b=3"
    assert parse_qs_bytes(qs) == {"a": [b"1"], "b": [b"2", b"3"]}
    qs = "a=1&b=2&b=3"
    assert parse_qs_bytes(qs) == {"a": [b"1"], "b": [b"2", b"3"]}


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:32:30.756814
# Unit test for function utf8
def test_utf8():
    """Test case for function utf8"""
    assert utf8('utf8') == b'utf8'
    assert utf8(b'test utf8') == b'test utf8'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:32:35.435783
# Unit test for function squeeze
def test_squeeze():
    s = squeeze("a \t b \n c \r d e") #squeeze everything in the list
    assert s == "a b c d e"
    print(s)

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:32:44.111994
# Unit test for function json_decode
def test_json_decode():
    l = [{"a": 1}, {"b": 2}]
    l_str = json.dumps(l)
    l_str_bytes = bytes(l_str, encoding="utf-8")
    l1 = json_decode(l_str)
    assert l == l1
    l2 = json_decode(l_str_bytes)
    assert l == l2
    # print("json_decode(json.dumps(l)) == l" + str(l1))
    # print("assert json_decode(json.dumps(l)) == l" + str(l == l1))
    # print("json_decode(bytes(json.dumps(l), encoding=\"utf-8\")) == l" + str(l2))
    # print("assert json_decode(bytes(json.dumps

# Generated at 2022-06-22 03:32:51.644055
# Unit test for function json_decode
def test_json_decode():
    test_value = '{"user_id":123,"user_name":"test","is_admin":false}'
    test_result = json_decode(test_value)

    assert len(test_result) > 0
    assert type(test_result) == dict


_RECURSION_LIMIT = 1000
_RECURSION_LIMIT_CHECK_TYPES = (list, dict)


# Generated at 2022-06-22 03:32:58.580677
# Unit test for function utf8
def test_utf8(): # noqa: F811
    assert utf8("foo") == b"foo"
    assert utf8(u"\u1234") == b"\xe1\x88\xb4"
    assert utf8(None) is None
    try:
        utf8(object())
    except TypeError:
        pass
    else:
        assert False, "expected TypeError"



# Generated at 2022-06-22 03:33:09.441852
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    print(linkify(text))


_STRIP_HTML_RE = re.compile(r"(?:<[^>]+>|&[#\w]+;)+")
_SIMPLE_EMAIL_RE = (
    r"[\w.+-]+@([\w-]+\.)+[a-zA-Z]{2,6}$"
)
# Match a valid email address.
# This can be used to check whether an email address is valid
# without actually sending an email to it.

# Generated at 2022-06-22 03:33:17.121667
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("aaa") == "aaa"
    assert url_unescape("aaa", encoding="utf-8") == "aaa"
    assert url_unescape("aaa", encoding="utf-8", plus=False) == "aaa"
    assert url_unescape("aaa", encoding=None, plus=True) == b"aaa"
    assert url_unescape("aaa", encoding=None, plus=False) == b"aaa"
    
if __name__ == '__main__':
    test_url_unescape()



# Generated at 2022-06-22 03:33:27.306243
# Unit test for function native_str
def test_native_str():
    assert native_str("") == ""
    assert native_str(b"") == ""
    assert native_str(u"") == ""
    assert native_str(b"a") == "a"
    assert native_str(b"\xe2\x99\xa5") == u"\u2765"
    assert native_str(u"\u2765") == u"\u2765"
    assert native_str(1) == "1"

    # Even on PY3 this should be a utf-8 string, not unicode
    assert native_str(b"\xe2\x99\xa5", force_bytes=True) == b"\xe2\x99\xa5"


# Generated at 2022-06-22 03:33:32.104923
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("abc") == "abc"
    assert url_escape("a b") == "a+b"
    assert url_escape("a+b") == "a%2Bb"



# Generated at 2022-06-22 03:33:48.822127
# Unit test for function url_unescape
def test_url_unescape():
    assert unicode_type(url_unescape(b'hello%20there')) == u'hello there'
    assert unicode_type(url_unescape('hello%20there')) == u'hello there'
    assert url_unescape(b'hello%20there', encoding=None) == b'hello there'
    assert url_unescape(b'hello+there', plus=True) == u'hello there'
    assert url_unescape('hello+there', plus=True) == u'hello there'
    assert url_unescape(b'hello+there', encoding=None, plus=True) == b'hello there'



# Generated at 2022-06-22 03:33:56.909903
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"foo") == u"foo"
    assert recursive_unicode({"foo": b"bar"}) == {u"foo": u"bar"}
    assert recursive_unicode({b"foo": b"bar"}) == {u"foo": u"bar"}
    assert recursive_unicode([b"foo"]) == [u"foo"]
    assert recursive_unicode((b"foo",)) == (u"foo",)



# Generated at 2022-06-22 03:34:08.441737
# Unit test for function utf8
def test_utf8():
    try:
        str_a = "abc"
        b = utf8(str_a)
    except:
        assert False

    try:
        b = utf8(None)
    except:
        assert False

    try:
        str_a = "abc"
        bytes_a = utf8(str_a)
        if not bytes_a == b"abc":
            raise AssertionError("utf8 failed")
    except:
        assert False

    try:
        b = utf8(None)
        if b != None:
            raise AssertionError("utf8 failed")
    except:
        assert False

    try:
        utf8(123)
        raise AssertionError("utf8 failed")
    except TypeError:
        pass
    except:
        assert False



# Generated at 2022-06-22 03:34:09.889319
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  s  s  ') == ' s s '


_utf8_str = None  # type: Optional[bytes]
_utf8_str_2 = None  # type: Optional[bytes]



# Generated at 2022-06-22 03:34:19.698106
# Unit test for function url_escape
def test_url_escape():
    from tornado.util import b
    assert url_escape("q1=0&q2=2 3") == "q1%3D0%26q2%3D2+3"
    assert url_escape("q1=0&q2=2 3", plus=False) == "q1%3D0%26q2%3D2%203"
    assert url_escape(b("q1=0&q2=2 3")) == "q1%3D0%26q2%3D2+3"
    assert url_escape(b("q1=0&q2=2 3"), plus=False) == "q1%3D0%26q2%3D2%203"
    # Non-ASCII characters get urlencoded as UTF-8:
    assert url_escape("\ufffd=\ufffd")

# Generated at 2022-06-22 03:34:21.284929
# Unit test for function json_decode
def test_json_decode():
    # TODO: Write tests for this function
    assert True


# Generated at 2022-06-22 03:34:25.927464
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('[1, 2, 3]') == [1, 2, 3]
    assert json_decode(b'[1, 2, 3]') == [1, 2, 3]


# Generated at 2022-06-22 03:34:32.202510
# Unit test for function utf8
def test_utf8():
    assert utf8(u"abc") == b"abc"
    assert utf8("abc") == b"abc"
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:36.693971
# Unit test for function utf8
def test_utf8():
    assert utf8("Hello") == b"Hello"
    assert utf8(None) == None
    assert utf8(b"Hello") == b"Hello"
    try:
        utf8(5)
        assert False
    except TypeError as e:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:40.895325
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes('foo=a%20b&bar=baz') == dict(foo=[b'a b'], bar=[b'baz'])



# Generated at 2022-06-22 03:34:50.553136
# Unit test for function json_encode
def test_json_encode():
    a = json_encode({"a":"b"})
    assert a == '{"a": "b"}'
    return


# Generated at 2022-06-22 03:34:57.294827
# Unit test for function linkify
def test_linkify():
    print (linkify("Hello http://tornadoweb.org!"))
    print (linkify("Hello http://tornadoweb.org/", shorten=True))
    print (linkify("Hello http://tornadoweb.org/", shorten=True, require_protocol=True))
    print (linkify("Hello http://tornadoweb.org/", shorten=True, permitted_protocols=["http"]))
    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    print (linkify("Hello http://tornadoweb.org/", shorten=True, permitted_protocols=["http"], extra_params=extra_params_cb))

# Generated at 2022-06-22 03:34:58.610782
# Unit test for function url_unescape
def test_url_unescape():
    print(url_unescape('%E8%B6%85%E7%BA%A7', 'utf-8'))


# Generated at 2022-06-22 03:35:07.462662
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print("Start test_xhtml_unescape")
    value = '&lt;html&gt;'
    value = xhtml_unescape(value)
    if value == "<html>":
        print("Pass!")
    else:
        print("Failed!")
test_xhtml_unescape()

# hex version of html.entities.html5

# Generated at 2022-06-22 03:35:09.380956
# Unit test for function json_decode
def test_json_decode():
    print(json_decode('{"name": "liushuai", "age": 18}'))


# Generated at 2022-06-22 03:35:18.423692
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    input_string = b'?name=David\xC3\x8A&lastname=wolever&job=system_engineer&age=25'
    input_string2 = '?name=David\xC3\x8A&lastname=wolever&job=system_engineer&age=25'
    print(parse_qs_bytes(input_string))
    print(parse_qs_bytes(input_string2))

#test_parse_qs_bytes()


# Generated at 2022-06-22 03:35:22.093399
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("hello  world") == "hello world"
    assert squeeze("  hello \nworld\t") == "hello world"


# This module used to define a "recursive_unicode" function, but
# recursion was not necessary, nor was it correct (in python3 all strings
# are unicode).



# Generated at 2022-06-22 03:35:26.848040
# Unit test for function native_str
def test_native_str():
    assert str == bytes, "not support python2"
    assert native_str(1) == '1'
    assert native_str(None) == 'None'
    assert native_str('a') == 'a'
    assert native_str(b'a') == 'a'
    assert native_str(u'\u6C49') == '\u6C49'



# Generated at 2022-06-22 03:35:29.246044
# Unit test for function url_unescape
def test_url_unescape():
    result: str = url_unescape('/2.5/weather?id=524901&APPID=1111111111')
    assert result == '/2.5/weather?id=524901&APPID=1111111111',\
        'url_unescape function works incorrectly'


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:35:34.208824
# Unit test for function url_escape
def test_url_escape():
    '''
    test for url_escape(value: Union[str, bytes], plus: bool = True) -> str:
    '''
    print(url_escape("a"))
    print(url_escape("a", plus=False))
    print(url_escape("a "))
    print(url_escape("a a"))
    return True



# Generated at 2022-06-22 03:35:49.682384
# Unit test for function linkify
def test_linkify():
    text = 'test http://google.com test'
    res = linkify(text)

# Generated at 2022-06-22 03:35:53.720997
# Unit test for function json_encode
def test_json_encode():
    a = {'t':{'t':1}}
    print(json_encode(a))
test_json_encode()

# json_encode_pretty is just json_encode with pretty printing enabled
json_encode_pretty = functools.partial(json.dumps, indent=4)  # type: ignore

# Generated at 2022-06-22 03:36:05.709105
# Unit test for function json_encode
def test_json_encode():
    from tornado.util import ObjectDict
    value = {
        "foo" : "bar",
        "g" : [1, 2],
        "x": ObjectDict(a=1),
        "l" : [1, 2, ObjectDict(b=4), [5, 6]],
        "n" : {
            "a" : 1,
            "c" : ObjectDict(f=5, h=7)
        }
    }
    res = json_encode(value)
    assert res == '{"foo": "bar", "g": [1, 2], "x": {"a": 1}, "l": [1, 2, {"b": 4}, [5, 6]], "n": {"a": 1, "c": {"f": 5, "h": 7}}}'
test_json_encode()

# Generated at 2022-06-22 03:36:09.943005
# Unit test for function url_escape
def test_url_escape():
    """
    Unit test for function url_escape
    """
    assert url_escape("/path?a=a%&b=b") == "/path?a=a%25&b=b"


# Generated at 2022-06-22 03:36:13.185459
# Unit test for function json_decode
def test_json_decode():
    json_str = '{"a":1, "b":2}'
    json_str_obj = json.loads(json_str)
    assert json_str_obj == json_decode(json_str)



# Generated at 2022-06-22 03:36:17.366754
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    text = "&#39;&#39;&#39;&quot;&#39;&#39;&quot;&#39;&quot;'"
    assert xhtml_unescape(text) == "'''\"''\"''\"'"



# Generated at 2022-06-22 03:36:21.474708
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = {
        1: b"1",
        2: b"2",
        3: [b"1", b"2", b"3"],
        4: {
            1: b"1",
            2: b"2",
            3: b"3",
        },
        5: b"5"
    }
    assert recursive_unicode(obj) == {
        1: "1",
        2: "2",
        3: ["1", "2", "3"],
        4: {
            1: "1",
            2: "2",
            3: "3"
        },
        5: "5"
    }

# Generated at 2022-06-22 03:36:24.397299
# Unit test for function native_str
def test_native_str():
    a=native_str("你好")
    return a


# Generated at 2022-06-22 03:36:35.102127
# Unit test for function linkify
def test_linkify():
    url1 = 'http://www.jd.com'
    link1 = linkify(url1)
    assert(link1.find(url1)>=0)
    link2 = linkify(url1, shorten = True)
    assert(link2.find(url1)>=0)
    link3 = linkify(url1, require_protocol = True)
    assert(link3.find(url1)>=0)
    url2 = 'www.jd.com'
    link4 = linkify(url2, require_protocol = True)
    assert(link4.find(url2)<0)
    link5 = linkify(url2)
    assert(link5.find(url2)>=0)

# Generated at 2022-06-22 03:36:47.083184
# Unit test for function json_decode
def test_json_decode():
    from io import StringIO

# Generated at 2022-06-22 03:36:55.379058
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("some&<>text'") == "some&amp;&lt;&gt;text&#39;"



# Generated at 2022-06-22 03:36:57.796617
# Unit test for function squeeze
def test_squeeze():
    s = 'pqr   abc'
    expected = 'pqr abc'
    assert squeeze(s) == expected
    print("Test passed")



# Generated at 2022-06-22 03:36:59.468484
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"key":"value"}') == {"key":"value"}


# Generated at 2022-06-22 03:37:05.159152
# Unit test for function url_unescape
def test_url_unescape():
  assert url_unescape(b'\xc2\xa0') == '\xa0'
  assert url_unescape('\xc2\xa0') == '\xa0'
  assert url_unescape('%c2%a0') == '\xa0'



# Generated at 2022-06-22 03:37:11.574497
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&apos;") == "'"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&#34;") == '"'
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&#38;") == "&"
    assert xhtml_unescape("&#60;") == "<"
    assert xhtml_unescape("&#62;") == ">"


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:37:15.782099
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    expected = {"__utf8": [b"1"], "state": [b"Lg"], "name": [b""]}
    actual = parse_qs_bytes(
        b"__utf8=1&name=&state=Lg", keep_blank_values=True, strict_parsing=True
    )
    assert expected == actual



# Generated at 2022-06-22 03:37:22.529533
# Unit test for function utf8
def test_utf8():
    assert utf8(u'foo') == b'foo'
    assert utf8('foo') == b'foo'
    assert utf8(None) is None
    try:
        utf8(42)
    except TypeError:
        pass
    else:
        assert False, "Did not detect error"

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:37:25.385275
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("Thyme &time=<is> now") == "Thyme &amp;time=&lt;is> now"


# Generated at 2022-06-22 03:37:36.582145
# Unit test for function url_unescape
def test_url_unescape():
    print(url_unescape(b'www.google.com'))
    print(url_unescape(b'www.google.com', None))
    print(url_unescape('%0D%0A'))
    print(url_unescape(b'%0D%0A', None, False))
    print(url_unescape('%0D%0A', None, True))
    print(url_unescape('%0D%0A', 'utf-8', True))
    print(url_unescape('%0D%0A', 'utf-8', False))
    print(url_unescape(b'%0D%0A', 'utf-8', False))
    print(url_unescape(b'%0D%0A', 'utf-8', True))


# Generated at 2022-06-22 03:37:48.581446
# Unit test for function linkify
def test_linkify():
    assert '<a href="http://www.yahoo.com" target="_blank">http://www.yahoo.com</a>' == linkify("http://www.yahoo.com", extra_params='target="_blank"')
    assert '<a href="https://www.yahoo.com" target="_blank">https://www.yahoo.com</a>' == linkify("https://www.yahoo.com", extra_params='target="_blank"')
    assert '<a href="http://www.yahoo.com" target="_blank">www.yahoo.com</a>' == linkify("www.yahoo.com", extra_params='target="_blank"')

# Generated at 2022-06-22 03:38:05.372378
# Unit test for function native_str
def test_native_str():
    x = '中文'
    y = b'1234'
    z = b'\xe4\xb8\xad\xe6\x96\x87'
    a = {'x': '中文', 'y': b'1234', 'z': b'\xe4\xb8\xad\xe6\x96\x87'}
    assert native_str() == ''
    assert native_str(x) == x
    assert native_str(y) == '1234'
    assert native_str(z) == x
    assert native_str(a) == "{'x': '中文', 'y': '1234', 'z': '中文'}"