

# Generated at 2022-06-24 08:17:32.451677
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("test") == "test"
    assert url_escape("foo bar") == "foo+bar"
    assert url_escape("foo bar", plus=False) == "foo%20bar"
    assert url_escape("/:/") == "/%3A/"



# Generated at 2022-06-24 08:17:35.877286
# Unit test for function native_str
def test_native_str():
    # from tornado.util import native_str
    assert utf8('123')
    assert to_unicode('123')
    
    # this is different from python2
    assert type(utf8('123')) is bytes
    assert type(to_unicode('123')) is str
test_native_str()


# Generated at 2022-06-24 08:17:41.170249
# Unit test for function url_escape
def test_url_escape():
    url = url_escape('http://a.b.c.d/1')
    print (url)
    assert url == 'http%3A%2F%2Fa.b.c.d%2F1'
test_url_escape()



# Generated at 2022-06-24 08:17:47.179092
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a b c ") == "a b c"
    assert squeeze(" a b c ") == "a b c"
    assert squeeze("  a  b  c  ") == "a b c"
    assert squeeze("a b c\t\t") == "a b c"
    assert squeeze("\n\n\na b c\t\t") == "a b c"
    assert squeeze("\t\ta b c\t\t") == "a b c"
    return True

# test_squeeze()


# Generated at 2022-06-24 08:17:49.940243
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&nbsp;') == '&nbsp;'

_BASESTRING_TYPES = (str, bytes)



# Generated at 2022-06-24 08:17:55.695543
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'%C3%A9') == 'é'
    assert url_unescape(b'%C3%A9', plus=False) == 'é'
    assert url_unescape(b'%C3%A9', encoding='latin1') == '\ufffd'
    assert url_unescape('%C3%A9') == 'é'



# Generated at 2022-06-24 08:18:05.230010
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>&") == "&lt;&gt;&amp;"
    assert xhtml_escape("'") == "&#39;"


_XML_ESCAPE_RE = re.compile("[&<>\"']")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
}


# Generated at 2022-06-24 08:18:10.913332
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b"xhtml escape") == 'xhtml escape'
    assert xhtml_escape(b"<><>") == '&lt;&gt;&lt;&gt;'
    assert xhtml_escape(b"&") == '&amp;'




# Generated at 2022-06-24 08:18:16.154993
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({b"b": b"bb", "u": u"uu", "uuu": u"uuuu"}) == {
        "b": "bb",
        "u": "uu",
        "uuu": "uuuu",
    }
    assert recursive_unicode([b"b", u"u", u"uu"]) == ["b", "u", "uu"]
    assert recursive_unicode((b"b", u"u", u"uu")) == ("b", "u", "uu")
    assert recursive_unicode(b"b") == "b"
    assert recursive_unicode(u"u") == "u"
    assert recursive_unicode(123) == 123



# Generated at 2022-06-24 08:18:20.117055
# Unit test for function json_encode
def test_json_encode():
    a = {'a': 'b'}
    # print('[wzw] test_json_encode:', type(a), json_encode(a))
    assert isinstance(json_encode(a), str)


# Generated at 2022-06-24 08:18:26.057115
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert _XHTML_ESCAPE_RE.sub(lambda match: _XHTML_ESCAPE_DICT[match.group(0)], 'p') == 'p'
test_xhtml_escape()


_JSON_ESCAPE = re.compile(r"([<>&])")
_JSON_ESCAPE_DCT = {"<": "\\u003c", ">": "\\u003e", "&": "\\u0026"}



# Generated at 2022-06-24 08:18:33.139178
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": "b"}) == {"a": u"b"}
    assert recursive_unicode({"a": {"b": "c"}}) == {"a": {"b": u"c"}}
    assert recursive_unicode({"a": 1}) == {"a": 1}
    assert recursive_unicode([u"b", u"c"]) == [u"b", u"c"]
    assert recursive_unicode([b"b", u"c"]) == [u"b", u"c"]
    assert recursive_unicode([1]) == [1]
    assert recursive_unicode([]) == []

test_recursive_unicode()



# Generated at 2022-06-24 08:18:44.249158
# Unit test for function json_decode
def test_json_decode():
    test_str = "Hello World"
    test_str_unicode = "你好"
    test_str_bytes = "你好".encode("utf-8")
    test_int = 10
    test_list = [1, 2, 3]
    test_dict = {"key1": 1, "key2": 2}
    assert json_decode(json.dumps(test_str)) == json_decode(test_str)
    assert json_decode(json.dumps(test_str_unicode)) == json_decode(test_str_unicode)
    assert json_decode(json.dumps(test_str_bytes)) == json_decode(test_str_bytes)

# Generated at 2022-06-24 08:18:45.512824
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("abc") == 'abc'
    assert url_escape("ABC") == 'ABC'
    assert url_escape("aBc") == 'aBc'



# Generated at 2022-06-24 08:18:53.364834
# Unit test for function json_decode
def test_json_decode():
    import os
    import json
    import filecmp
    json_file = "data/inputs/API_SP.POP.TOTL_DS2_en_json_v2_897309.json"
    with open(json_file) as f:
        data = json.load(f)
    # json_decode(str)
    assert type(json_decode(json.dumps(data))) is dict
    # json_decode(unicode)
    assert type(json_decode(str(data))) is dict
    # json_decode(bytes)
    assert type(json_decode(bytes(json.dumps(data), 'utf-8'))) is dict
    # json_decode(bytes)
    #assert type(json_decode(bytes(json.dumps(data), 'utf-

# Generated at 2022-06-24 08:19:01.691260
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": "b", "c": "d"}) == {
        "a": to_unicode("b"),
        "c": to_unicode("d"),
    }
    assert recursive_unicode(["a", "b"]) == [to_unicode("a"), to_unicode("b")]
    assert recursive_unicode(("a", "b")) == (to_unicode("a"), to_unicode("b"))
    assert recursive_unicode("a") == to_unicode("a")



# Generated at 2022-06-24 08:19:07.517785
# Unit test for function linkify
def test_linkify():
    actual = linkify(
        "www.torrnadoweb.org is a cool site. check it out! "
        "http://www.tornadoweb.org/en/stable/index.html#hello-world"
        "http://www.google.com/search?q=hi%20there&source=lnt&tbs=qdr:m"
    )
    print(actual)


# A very slightly safer version of 


# Generated at 2022-06-24 08:19:17.815312
# Unit test for function linkify
def test_linkify():
    assert linkify("") == ""
    assert linkify("Hello") == "Hello"
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    # TODO: investigate why it writes '<a href="http://\nhttp://www.example.com"></a><a'
    # assert linkify("http://\nhttp://www.example.com") == '<a href="http://\nhttp://www.example.com"></a><a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("Hello http://example.com!") == 'Hello <a href="http://example.com">http://example.com</a>!'

# Generated at 2022-06-24 08:19:19.382904
# Unit test for function json_encode
def test_json_encode():
    json_encode("</") == "<\\/"


# Generated at 2022-06-24 08:19:25.104609
# Unit test for function native_str
def test_native_str():
    check(
        native_str("foo"),
        "foo",
        "native_str() should return the str version of unicode objects",
    )
    b = "foo".encode("utf-8")
    check(
        native_str(b),
        b,
        "native_str() should return the str version of byte objects",
    )


native_str = to_unicode  # noqa: F811



# Generated at 2022-06-24 08:19:35.679618
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&amp;') == '&'

    assert xhtml_unescape('&#x27;') == "'"
    assert xhtml_unescape('&#X27;') == "'"

    assert xhtml_unescape('&#34;') == '"'
    assert xhtml_unescape('&#039;') == "'"

    assert xhtml_unescape('&#0039;') == "'"

    assert xhtml_unescape('&#X00039;') == "'"

    assert xhtml_un

# Generated at 2022-06-24 08:19:39.178180
# Unit test for function json_decode
def test_json_decode():
    test_str = '{"key1": {"key1": "val1"}, "key2": "val2"}'
    test_obj = tornado.escape.json_decode(test_str)
    assert type(test_obj) is dict
    assert test_obj['key1']['key1'] == 'val1'


# utf8 to str

# Generated at 2022-06-24 08:19:47.696602
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8("f\xe4\xab\xac") == b"f\xc3\xa4\xe2\xab\xac"
    assert utf8(None) is None
    assert utf8(b"blah") == b"blah"
    from tornado.test.util import ExpectedException

    with ExpectedException(TypeError, "not a byte string"):
        utf8(1)


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:55.878257
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("1+2") == "1 2"
    assert url_unescape(b"1+2", encoding=None) == b"1 2"
    assert url_unescape("1%2B2", encoding=None) == b"1+2"
    assert url_unescape(b"1%2B2") == "1+2"
    assert url_unescape("1%2B2") == "1+2"
    assert url_unescape(b"1%2B2", encoding="utf-8") == "1+2"
    assert url_unescape("1%2B2", encoding="utf-8") == "1+2"
    assert url_unescape("1+2", plus=False) == "1+2"

# Generated at 2022-06-24 08:20:05.224826
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http://a%2Fb", plus=False, encoding="utf-8") == "http://a%2Fb"
    assert url_unescape("http://a%2Fb", plus=True, encoding="utf-8") == "http://a/b"
    assert url_unescape("http://a+b", plus=False, encoding="utf-8") == "http://a+b"
    assert url_unescape("http://a+b", plus=True, encoding="utf-8") == "http://a b"



# Generated at 2022-06-24 08:20:11.165677
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'a':'a','b': 'b'}) == {'a':'a','b': 'b'}
    assert recursive_unicode([1,2,3]) == [1,2,3]
    assert recursive_unicode((1,2,3)) == (1,2,3)
    assert recursive_unicode(b'abc') == 'abc'
    assert recursive_unicode(object) != object
    assert recursive_unicode('abc') == 'abc'


# Generated at 2022-06-24 08:20:15.459502
# Unit test for function utf8
def test_utf8():
    assert utf8("string") == b"string"
    assert utf8(u"string") == b"string"
    assert utf8(b"bytestring") == b"bytestring"
    assert utf8(None) is None

    try:
        utf8(1)
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:20:21.856353
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"&=%20", encoding="utf-8") == "&=%20"
    assert url_unescape(b"&=%20", encoding=None) == b"&=%20"
    assert url_unescape(b"&=+", encoding="utf-8") == "&=+"
    assert url_unescape(b"&=%2B", encoding=None) == b"&=+"



# Generated at 2022-06-24 08:20:31.670436
# Unit test for function url_escape
def test_url_escape():
    print("the result is : " , url_escape("https://www.baidu.com/s?wd=pythontest&rsv_spt=1&rsv_iqid=0xb8e89b9800009478&issp=1&f=3&rsv_bp=1&rsv_idx=2&ie=utf-8&tn=baiduhome_pg&rsv_enter=1&rsv_sug3=2&rsv_n=2&rsv_sug1=2&rsv_sug7=100&rsv_sug2=0&prefixsug=pythontest&rsp=0&inputT=5721&rsv_sug4=5721"))


# Generated at 2022-06-24 08:20:35.498435
# Unit test for function recursive_unicode
def test_recursive_unicode():
        obj = {
            'str': 'test',
            'str2': '中国',
            'list': [1, b'str', 'text'],
            'dict': {
                'k': 'v',
                'k2': b'v2'
            }
        }
        print(recursive_unicode(obj))
#test_recursive_unicode()



# Generated at 2022-06-24 08:20:36.663232
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  a  b  c  ") == "a b c"



# Generated at 2022-06-24 08:20:47.919335
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;&gt;") == "<>"
    assert xhtml_unescape("&lt&gt") == "&lt&gt"
    assert xhtml_unescape("&#60;&#62;") == "<>"
    assert xhtml_unescape("&#x3c;&#x3e;") == "<>"
    assert (
        xhtml_unescape("&Copy; &#169; &#xA9; &#xA9; &#xAE;")
        == "© © © © ®"
    )
    assert xhtml_unescape("&#60;&#62") == "&#60;&#62"
    assert xhtml_unescape("&#60;&#62;&#60") == "&#60;&#62;&#60"
   

# Generated at 2022-06-24 08:20:52.233485
# Unit test for function json_decode
def test_json_decode():
    a = json_decode("{}")
    b = json_decode("[1,2,3]")
    c = json_decode("true")
    d = json_decode("1")
    assert a == {}
    assert b == [1,2,3]
    assert c == True
    assert d == 1



# Generated at 2022-06-24 08:20:58.292471
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<script>alert("this") & that</script>') == '&lt;script&gt;alert(&quot;this&quot;) &amp; that&lt;/script&gt;'

test_xhtml_escape()


_URL_ENCODE_PATTERN = re.compile(r'[^\x09\x0a\x0d\x20-\x7e\x80-\xff]')



# Generated at 2022-06-24 08:21:08.255610
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("a=1&a=2&b=3", keep_blank_values=True) == {b"a": [b"1", b"2"], b"b": [b"3"]}
    assert parse_qs_bytes("a=1&a=2&b=3", keep_blank_values=False) == {b"a": [b"1", b"2"], b"b": [b"3"]}
    assert parse_qs_bytes("a=1&a=2&b=3", keep_blank_values=True, strict_parsing=True) == {b"a": [b"1", b"2"], b"b": [b"3"]}

# Generated at 2022-06-24 08:21:14.115871
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    try:
        xhtml_unescape('&#38;')
        xhtml_unescape('&amp;')
        xhtml_unescape('&adf;')
        xhtml_unescape('&#x2A;')
    except:
        assert False
# End unit test

_BASESTRING_TYPES = (str, bytes, unicode_type)



# Generated at 2022-06-24 08:21:17.394548
# Unit test for function squeeze
def test_squeeze():
    string = "thi\tst  is\n  te\rsttng"
    value = squeeze(string)
    assert value == "thi st is te sttng"



# Generated at 2022-06-24 08:21:19.937529
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    """Test function xhtml_unescape"""
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_unescape("&lt;") == "<"
    print('Pass')


# Generated at 2022-06-24 08:21:32.189488
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("test%E8%AF%AD%E8%A8%80") == "test语言"
    assert url_unescape(b'test%E8%AF%AD%E8%A8%80') == b'test%E8%AF%AD%E8%A8%80'

# Generated at 2022-06-24 08:21:36.639468
# Unit test for function utf8
def test_utf8():
    assert utf8(u"asdf") == b"asdf"
    assert utf8(None) is None
    assert utf8(b"asdf") == b"asdf"
    assert utf8(u"\u20ac") == b"\xe2\x82\xac"



# Generated at 2022-06-24 08:21:41.459244
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    string = b"foo=bar&baz=fob&baz=bob"
    res = parse_qs_bytes(string)
    expected = {'foo': ['bar'], 'baz': ['fob', 'bob']}
    assert res == expected, 'Test failed'


# Generated at 2022-06-24 08:21:44.050481
# Unit test for function url_escape
def test_url_escape():
    s = 'a$#@? b'
    url_escape(s)
    url_escape(s, plus=False)


# Generated at 2022-06-24 08:21:49.791102
# Unit test for function url_unescape
def test_url_unescape():
    value: bytes = b"https://www.google.com.tw/search?q=hello+world&oq=hello+world&aqs=chrome..69i57.7750j0j1&sourceid=chrome&ie=UTF-8"
    value = url_unescape(
        value, encoding=None, plus=True
    )
    print(value)



# Generated at 2022-06-24 08:21:58.324898
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&#65;") == "A"
    assert xhtml_unescape("&#x41;") == "A"
    assert xhtml_unescape("&#x41;&#x42;&#x43;") == "ABC"

# Function _convert_entity

# Generated at 2022-06-24 08:22:01.133800
# Unit test for function utf8
def test_utf8():
    result = utf8("hello")
    assert result == b"hello"
    result = utf8(b"hello")
    assert result == b"hello"



# Generated at 2022-06-24 08:22:03.007376
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "key=value&key2=value2"
    assert parse_qs_bytes(qs) == {b'key': [b'value'], b'key2': [b'value2']}



# Generated at 2022-06-24 08:22:09.461656
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert '<', xhtml_unescape('&lt;')
    assert '>', xhtml_unescape('&gt;')
    assert '"', xhtml_unescape('&quot;')
    assert "'", xhtml_unescape('&#39;')
    assert '\\', xhtml_unescape('&#92;')
    assert '&', xhtml_unescape('&amp;')



# Generated at 2022-06-24 08:22:10.889579
# Unit test for function url_escape
def test_url_escape():
    url_escape('http://www.baidu.com/')


# Generated at 2022-06-24 08:22:14.450409
# Unit test for function native_str
def test_native_str():
    assert native_str("Hello World") == "Hello World"
    assert native_str(u"Hello World") == "Hello World"
    assert native_str(b"Hello World") == "Hello World"
    assert native_str(None) == ""



# Generated at 2022-06-24 08:22:20.307142
# Unit test for function utf8
def test_utf8():
    # type: () -> None
    print(utf8(None))
    print(utf8("test"))
    print(utf8(b"test"))
    # print(utf8(3))  # error
    try:
        utf8(3)
    except TypeError:
        print("error")


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:22:23.418048
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
  print('A'==xhtml_unescape('A'))

_BASESTRING_TYPES = (str, bytes)

if typing.TYPE_CHECKING:
    _BASESTRING_TYPES = typing.Union[str, bytes]



# Generated at 2022-06-24 08:22:32.020896
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    input1=b'foo=how+are+you&bar=10%25'
    output1={'foo': [b'how are you'], 'bar': [b'10%']}
    assert parse_qs_bytes(input1) == output1
    input2=b'foo=how+are+you&bar=10%25&hoge=i++am%0afine'
    output2={'foo': [b'how are you'], 'bar': [b'10%'], 'hoge':[b'i  am\nfine']}
    assert parse_qs_bytes(input2) == output2


# Generated at 2022-06-24 08:22:43.126145
# Unit test for function recursive_unicode
def test_recursive_unicode():
    data = {'a': b'foo', 'b': u'bar', 'c': {'d': b'blah'}}
    assert recursive_unicode(data) == {'a': u'foo', 'b': u'bar', 'c': {'d': u'blah'}}
    assert recursive_unicode(data) == {'a': 'foo', 'b': 'bar', 'c': {'d': 'blah'}} # Note that recursive_unicode returns unicode
    assert json_decode(json_encode(recursive_unicode(data))) == data
    data = {u'a': 'foo'.encode(), u'b': 'bar', u'c': {u'd': 'blah'.encode()}}

# Generated at 2022-06-24 08:22:49.765073
# Unit test for function recursive_unicode
def test_recursive_unicode():
    val = {
        'foo' : b'bar',
        'baz' : b'test',
    }
    assert recursive_unicode(val) == {'foo': 'bar', 'baz': 'test'}


# Fake byte literal support:  In python2, one can write b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do
# that in python 3, so we need a function wrapper.  b() should only
# be applied to literal strings.  Use native_str() for anything else.

# Generated at 2022-06-24 08:23:01.427596
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('abc') == 'abc'
    assert url_unescape('%20') == ' '
    assert url_unescape('%25%20') == '% '
    assert url_unescape('%25%20', plus=False) == '%20'
    assert url_unescape('xxx%20xxx', plus=False) == 'xxx%20xxx'
    assert url_unescape('%7e/%60') == '~/`'
    assert url_unescape('%7e/%60', plus=False) == '~/`'
    assert url_unescape('%E2%82%AC', encoding='latin1') == '\u20ac'
    assert url_unescape('%2B') == '+'

# Generated at 2022-06-24 08:23:03.232163
# Unit test for function json_encode
def test_json_encode():
    assert json_encode([1, 2, 3]) == '[1, 2, 3]'



# Generated at 2022-06-24 08:23:08.871248
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes("a=1&b=2&b=3")
    assert result == {b"a": ["1"], b"b": ["2", "3"]}
    result = parse_qs_bytes("a=1&b=2&b=3", keep_blank_values=True)
    assert result == {b"a": ["1"], b"b": ["2", "3"]}
    result = parse_qs_bytes("a=&b=2&b=3", keep_blank_values=True)
    assert result == {b"a": [""], b"b": ["2", "3"]}
    result = parse_qs_bytes("a=&b=2&b=3", keep_blank_values=False)
    assert result == {b"b": ["2", "3"]}
   

# Generated at 2022-06-24 08:23:11.350772
# Unit test for function recursive_unicode
def test_recursive_unicode():
    data_1 = to_unicode("good morning")
    assert data_1 == recursive_unicode(data_1)


# Generated at 2022-06-24 08:23:14.983063
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a  b\tc    d') == 'a b c d'
    assert squeeze(' f o o       b a r ') == 'f o o b a r'

# squeeze()



# Generated at 2022-06-24 08:23:18.294444
# Unit test for function utf8
def test_utf8():
    assert b"abc" == utf8(b"abc")
    assert b"abc" == utf8(u"abc")
    assert b"abc" == utf8(u"abc".encode("utf-8"))
    assert None is utf8(None)
    assert b"\xc3\xa9" == utf8(u"\xe9")


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:23:20.316763
# Unit test for function native_str
def test_native_str():
    try:
        native_str(str("str"))
    except:
        return False
    return True


# Generated at 2022-06-24 08:23:25.579177
# Unit test for function recursive_unicode
def test_recursive_unicode():
    inp = {b'key': 'value',
            b'1': [3, b'hi', {b'test': b'bytes'}]}
    out = recursive_unicode(inp)
    assert out['key'] == 'value'
    assert out[b'1'][1] == 'hi'
    assert isinstance(out[b'1'][2]['test'], str)


# Generated at 2022-06-24 08:23:34.969053
# Unit test for function url_escape
def test_url_escape():
    # Using the module level function.
    assert url_escape('') == ''
    assert url_escape('/') == '%2F'
    assert url_escape('a b') == 'a+b'
    assert url_escape('a b', plus=False) == 'a%20b'
    assert url_escape('?/') == '%3F%2F'
    assert url_escape('?/', plus=False) == '%3F%2F'

# Generated at 2022-06-24 08:23:42.189060
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
    print(linkify("www.facebook.com"))
    print(linkify("www.facebook.com", require_protocol=True))
    print(linkify("https://www.facebook.com"))
    print(linkify("http://www.facebook.com"))
    print(linkify("http://www.facebook.com", require_protocol=True))
    print(linkify("https://www.facebook.com", require_protocol=True))
    print(
        linkify(
            "https://www.facebook.com/sharer/sharer.php?u=www.baidu.com",
            require_protocol=True,
        )
    )

# test_linkify()


# Generated at 2022-06-24 08:23:52.351580
# Unit test for function linkify
def test_linkify():
    from tornado import template
    import unittest

    class LinkifyTest(unittest.TestCase):
        def test_linkify(self):
            self.assertEqual(
                linkify(
                    'hello http://example.com !'),
                'hello <a href="http://example.com">http://example.com</a> !'
            )

            self.assertEqual(
                linkify(
                    'hello tornado://example.com !'),
                'hello tornado://example.com !'
            )  # should not linkify
            self.assertEqual(
                linkify('hello www.example.com !'),
                'hello <a href="http://www.example.com">www.example.com</a> !'
            )

# Generated at 2022-06-24 08:23:59.129726
# Unit test for function url_unescape
def test_url_unescape():

    value = 'http://localhost:8080/api/app/app_id/app_content/app_key=?!%7B%22key1%22%3A%22val1%22%2C%22key2%22%3A%22val2%22%7D'
    res = url_unescape(value)
    print(res)

# Generated at 2022-06-24 08:24:01.639193
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert(xhtml_escape("<>\"'&") == "&lt;&gt;&quot;&#39;&amp;")


# Generated at 2022-06-24 08:24:12.631132
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"foo=bar") == {b"foo": [b"bar"]}
    assert parse_qs_bytes(b"foo=bar", strict_parsing=True) == {b"foo": [b"bar"]}
    assert parse_qs_bytes(b"foo=bar=baz") == {b"foo": [b"bar=baz"]}
    assert parse_qs_bytes(b"foo=bar=baz", strict_parsing=True) == {b"foo": [b"bar=baz"]}
    assert parse_qs_bytes(b"foo+bar=baz++") == {b"foo bar": [b"baz  "]}

# Generated at 2022-06-24 08:24:18.165156
# Unit test for function xhtml_escape

# Generated at 2022-06-24 08:24:27.339548
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('1  2\t3\n 4\r5') == '1 2 3 4 5'
    assert squeeze('1  2\t3\n 4\r5 ') == '1 2 3 4 5'
    assert squeeze('1  2\t3\n 4\r5  ') == '1 2 3 4 5'
    assert squeeze('1  2\t3\n 4\r5   ') == '1 2 3 4 5'
    assert squeeze('1  2\t3\n 4\r5    ') == '1 2 3 4 5'
    assert squeeze('1  2\t3\n 4\r5     ') == '1 2 3 4 5'
    assert squeeze('1  2\t3\n 4\r5      ') == '1 2 3 4 5'

# Generated at 2022-06-24 08:24:31.775899
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # import backported_collections as collections
    import collections
    #
    # class MultiDict(collections.OrderedDict):
    #     def __getitem__(self, key):
    #         """
    #         Return the first data value for the last key, or a list
    #         of values for a key.
    #         """
    #         if key in self:
    #             return self.get(key)
    #
    #         raise collections.KeyError("Key not found: %s" % key)
    #
    #     def getall(self, key):
    #         """Return a list of all values for the named field."""
    #         return list(self.items(key))
    #
    #     def getlist(self, key, type=None):
    #         """
    #

# Generated at 2022-06-24 08:24:39.792436
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("<hello>") == "&lt;hello&gt;"
    assert xhtml_unescape("&lt;hello&gt;") == "<hello>"
    assert xhtml_unescape("&amp;hello&amp;") == "&hello&"
    assert xhtml_unescape("&#34;hello&#34;") == "\"hello\""

_URL_SAFE = b"-_.!~*'()"
_RFC3986_UNRESERVED = [chr(i) for i in range(128) if chr(i).isalnum() or chr(i) in _URL_SAFE]
_RFC3986_RESERVED = {"%2B": "+", "%2C": ","}

# Generated at 2022-06-24 08:24:49.950633
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(
        '&<>"\'') == '&amp;&lt;&gt;"\''
    assert xhtml_escape('&#38;&#60;&#62;&#34;&#39;') == '&amp;&#60;&#62;&#34;&#39;'
    assert xhtml_escape(u'&#38;&#60;&#62;&#34;&#39;') == u'&amp;&#60;&#62;&#34;&#39;'


# to_unicode was previously documented as the correct way to convert to
# an escaped string.  It is still used internally in some places, but
# new code should use the native str type and xhtml_escape or json_encode
# as needed.  The native str type is

# Generated at 2022-06-24 08:24:54.133159
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = b"foo"
    assert recursive_unicode(x) == u"foo"
    x = {"a": b"foo", "b": [b"bar"]}
    assert recursive_unicode(x) == {u"a": u"foo", u"b": [u"bar"]}



# Generated at 2022-06-24 08:25:03.237563
# Unit test for function json_decode
def test_json_decode():
    # type: () -> None
    assert json_decode('{"a": "b"}') == {"a": "b"}
    assert json_decode(b'{"a": "b"}') == {"a": "b"}
    assert json_decode('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}

    assert json_decode('{"a": "b"}') == {"a": "b"}
    assert json_decode(b'{"a": "b"}') == {"a": "b"}
    assert json_decode(b'{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}



# Generated at 2022-06-24 08:25:14.566142
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    expected = {
        b"key": [b"value"],
        b"empty": [b""],
        b"multi": [b"value", b"other"],
        b"multiempty": [b"", b""],
    }
    assert parse_qs_bytes(b"key=value&multi=value&multi=other&empty=&multiempty=&multiempty=") == expected
    assert parse_qs_bytes(b"key=value&multi=value&multi=other&empty&multiempty&multiempty", keep_blank_values=True) == expected
    assert parse_qs_bytes(b"key=value&multi=value&multi=other;empty;multiempty;multiempty") == expected

# Generated at 2022-06-24 08:25:17.435480
# Unit test for function squeeze
def test_squeeze():
    value = "a b c d"
    expected = "a b c d"
    result = squeeze(value)
    assert result == expected

_unicode = unicode_type



# Generated at 2022-06-24 08:25:22.094589
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    ret = xhtml_unescape("&lt;a &amp; &gt; &#39;&quot; &nbsp;&#x20;&#32;")
    print(ret)

test_xhtml_unescape()

# 转换为unicode

# Generated at 2022-06-24 08:25:28.924566
# Unit test for function native_str
def test_native_str():
    if hasattr(str, 'decode'):  # pragma: no branch
        # Python 2
        assert isinstance(native_str(b'foo'), bytes)
        assert native_str(b'foo') == b'foo'
        assert native_str(u'foo') == b'foo'
        assert isinstance(native_str(u'foo'), bytes)
        assert native_str(b'foo', 'latin1') == b'foo'
        assert native_str(u'foo', 'latin1') == b'foo'
        assert native_str(b'foo', 'utf8') == b'foo'
        assert native_str(u'foo', 'utf8') == b'foo'
        assert native_str(b'foo', 'ascii') == b'foo'

# Generated at 2022-06-24 08:25:38.128185
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("abc\ndef\nghi") == "abc def ghi"
    assert squeeze("   abc def ghi  ") == "abc def ghi"
    assert squeeze("   abc  \n  def  \n  ghi  ") == "abc def ghi"
    assert squeeze("   abc  \n  \t\n  ghi  ") == "abc ghi"
    assert squeeze("   abc  \n  \t\n  \t\n  \n  ghi  ") == "abc ghi"
    assert squeeze("   a   b    c     d      e       f        g         h  ") == "a b c d e f g h"

# Generated at 2022-06-24 08:25:48.122045
# Unit test for function linkify
def test_linkify():
    assert (
        linkify('Testing http://example.com')
        == 'Testing <a href="http://example.com">http://example.com</a>'
    )
    assert (
        linkify(
            'Testing http://example.com',
            extra_params="rel='nofollow'",
        )
        == "Testing <a href='http://example.com' rel='nofollow'>http://example.com</a>"
    )
    assert (
        linkify(
            'Testing http://example.com',
            require_protocol=True,
        )
        == "Testing http://example.com"
    )
    assert (
        linkify(
            'Testing www.example.com',
            require_protocol=True,
        )
        == "Testing www.example.com"
    )

# Generated at 2022-06-24 08:25:56.654495
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%2B') == '+'
    assert url_unescape(b'%2B') == b'+'
    assert url_unescape('%2B', plus=False) == '%2B'
    assert url_unescape(b'%2B', plus=False) == b'%2B'
    assert url_unescape('+') == '+'
    assert url_unescape(b'+') == b'+'
    assert url_unescape('+', plus=False) == '+'
    assert url_unescape(b'+', plus=False) == b'+'



# Generated at 2022-06-24 08:26:03.212765
# Unit test for function native_str
def test_native_str():
    assert native_str('hello world') == 'hello world'
    assert native_str(b'hello world', 'utf-8') == 'hello world'
    assert native_str(b'\xe6\xb5\x8b\xe8\xaf\x95') == '\xe6\xb5\x8b\xe8\xaf\x95'
    assert native_str(b'\xe6\xb5\x8b\xe8\xaf\x95', 'utf-8') == '\xe6\xb5\x8b\xe8\xaf\x95'



# Generated at 2022-06-24 08:26:10.924865
# Unit test for function native_str
def test_native_str():
    # type: () -> None
    assert native_str("\N{SNOWMAN}") == "\u2603"
    assert native_str("\u2603") == "\u2603"
    assert native_str("\u2603", encoding="ascii") == "?"
    assert native_str("\u2603", errors="ignore") == ""
    assert native_str("\u2603", encoding="ascii", errors="ignore") == ""
    assert native_str(b"\u2603") == "\u2603"
    assert native_str(b"\u2603", encoding="ascii") == "?"
    assert native_str(b"\u2603", errors="ignore") == ""
    assert native_str(b"\u2603", encoding="ascii", errors="ignore") == ""


# Generated at 2022-06-24 08:26:21.392993
# Unit test for function linkify
def test_linkify():
    url_1 = 'https://www.google.com/search?q=test&oq=test&aqs=chrome..69i57j69i60l3j0l2.3432j1j7&sourceid=chrome&ie=UTF-8'
    url_2 = 'http://www.facebook.com/login'
    url_3 = 'www.jd.com'
    
    print(linkify(url_1))
    print(linkify(url_2))
    print(linkify(url_3))

test_linkify()

# output
# https://www.google.com/search?q=test&oq=test&aqs=chrome..69i57j69i60l3j0l2.3432j1j7&sourceid=chrome&ie=UTF-8
# http

# Generated at 2022-06-24 08:26:29.529855
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("This is a <b>test</b>") == "This is a &lt;b&gt;test&lt;/b&gt;"
    assert xhtml_escape('"This" is a <b>test</b>') == "&quot;This&quot; is a &lt;b&gt;test&lt;/b&gt;"

_XML_ESCAPE_RE = re.compile(
    "[&<>\"']|([^\0-\177])|([&<>\"'][^<>&\"']*[&<>\"'])"
)

# Generated at 2022-06-24 08:26:32.553186
# Unit test for function recursive_unicode
def test_recursive_unicode():
    c = {b'a': [b'b', b'c'], b'd': {b'e': b'f'}}
    assert recursive_unicode(c) == {'a': ['b', 'c'], 'd': {'e': 'f'}}



# Generated at 2022-06-24 08:26:39.428660
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("hello http://example.com") == 'hello <a href="http://example.com">http://example.com</a>'
    assert linkify("hello http://example.com more") == 'hello <a href="http://example.com">http://example.com</a> more'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-24 08:26:48.624653
# Unit test for function url_escape
def test_url_escape():
    def innerTest(
        value: str, plus: Union[str, bytes], expected: str
    ) -> None:
        result = url_escape(value, plus)
        print(result)
        assert result == expected

    innerTest("abc", True, "abc")
    innerTest("abc", False, "abc")
    innerTest("ab c", True, "ab+c")
    innerTest("ab c", False, "ab%20c")
    innerTest("ab,c", True, "ab,c")
    innerTest("ab,c", False, "ab,c")
    innerTest("ab/c", True, "ab/c")
    innerTest("ab/c", False, "ab/c")
    innerTest("ab.c", True, "ab.c")

# Generated at 2022-06-24 08:27:00.576441
# Unit test for function linkify
def test_linkify():
    # Test simple case
    assert linkify(u"Hello http://example.com") == u'Hello <a href="http://example.com">http://example.com</a>'
    # Test case with title
    assert linkify(u"Hello http://example.com", False, None) == u'Hello <a href="http://example.com" title="http://example.com">http://example.com</a>'
    # Test case with extra params
    assert linkify(u"Hello http://example.com", False, u'rel="nofollow"') == u'Hello <a href="http://example.com" title="http://example.com" rel="nofollow">http://example.com</a>'
    assert linkify(u"Hello http://example.com", False, u"rel='nofollow'") == u

# Generated at 2022-06-24 08:27:08.175255
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#x27;') == "'"
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&#x27') == '&#x27'
    assert xhtml_unescape('&#x27;&#x27;') == "''"
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&quot;&quot;&quot;&amp;&#39;') == "'"


# Deprecated alias (see the deprecated_alias decorator in tornado.util).
# This alias will be removed in Tornado 6.0, along with most uses in
# Tornado itself.
xhtml_escape_ = xhtml_escape



# Generated at 2022-06-24 08:27:10.935677
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"



# Generated at 2022-06-24 08:27:18.876734
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.tornadoweb.org/") == '<a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>'
    assert linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify("Hello www.tornadoweb.org!") == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>!'
    assert (linkify("Hello ftp.example.com") ==
            'Hello <a href="ftp://ftp.example.com">ftp.example.com</a>')

# Generated at 2022-06-24 08:27:22.225445
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1") == {'a': [b'1']}


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:27:32.544490
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.world.com") == 'hello <a href="http://www.world.com">http://www.world.com</a>'
    assert linkify("hello https://www.world.com") == 'hello <a href="https://www.world.com">https://www.world.com</a>'
    assert linkify("hello www.world.com") == 'hello <a href="http://www.world.com">www.world.com</a>'
    assert linkify("hello 127.0.0.1") == "hello 127.0.0.1"