

# Generated at 2022-06-24 08:17:36.737611
# Unit test for function json_encode
def test_json_encode():
    assert '{"a": "b"}' == json_encode({"a": "b"})
    assert '["a", "b"]' == json_encode(["a", "b"])
    assert '"a"' == json_encode("a")
    assert 'true' == json_encode(True)
test_json_encode()



# Generated at 2022-06-24 08:17:43.452826
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("test", plus=True) == "test"
    # assert url_escape("test plus", plus=True) == "test+plus"
    assert url_escape("test", plus=False) == "test"
    assert url_escape("test+plus", plus=False) == "test%2Bplus"



# Generated at 2022-06-24 08:17:49.984737
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    res1=parse_qs_bytes('a=b&c=d&a=e')
    assert res1['a']==[b'b', b'e']
    assert res1['c']==[b'd']
    res2=parse_qs_bytes('a=b&a=c',keep_blank_values=True)
    assert res2['a']==[b'b', b'c']
test_parse_qs_bytes()




# Generated at 2022-06-24 08:17:58.988287
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org, and http://google.com!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>, and <a href=\"http://google.com\">http://google.com</a>!"
    assert linkify("http://example.com/explicit", require_protocol=True) == '<a href="http://example.com/explicit">http://example.com/explicit</a>'
    assert linkify("http://example.com/explicit", require_protocol=False) == '<a href="http://example.com/explicit">http://example.com/explicit</a>'
    assert linkify("example.com", require_protocol=True) == 'example.com'
    assert linkify

# Generated at 2022-06-24 08:18:10.784020
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<script>") == "&lt;script&gt;"
    assert xhtml_escape("&<>\"\'") == "&amp;&lt;&gt;&quot;&#39;"


_JSON_ESCAPE_RE = re.compile(r"(?<!\\)\"")

# Generated at 2022-06-24 08:18:13.381400
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("Hello  World  ") == "Hello World"
    assert squeeze("Hello \t\r\n World") == "Hello World"
    assert squeeze("Hello") == "Hello"
    assert squeeze("   ") == ""
test_squeeze()


# Generated at 2022-06-24 08:18:24.332476
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    parse_qs_bytes("")
    parse_qs_bytes("a=b")
    parse_qs_bytes("a=b;c=d", keep_blank_values=True)
    parse_qs_bytes("a=1&a=2", strict_parsing=True)
    parse_qs_bytes("a=&a=", strict_parsing=True)
    parse_qs_bytes("a=%26", strict_parsing=True, keep_blank_values=True)
    with pytest.raises(ValueError):
        parse_qs_bytes("a=&a")
    with pytest.raises(ValueError):
        parse_qs_bytes("a=&a=&a")

# Generated at 2022-06-24 08:18:33.507513
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a    hello world") == "a hello world"
    assert squeeze("    hello") == "hello"
    assert squeeze("hello   ") == "hello"
    assert squeeze("hello world") == "hello world"
    assert squeeze("hello\tworld") == "hello world"
    assert squeeze("hello\nworld") == "hello world"
    assert squeeze("hello\rworld") == "hello world"
    assert squeeze(" !") == "!"
    assert squeeze(" !") == "!"

# Generated at 2022-06-24 08:18:37.385200
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([1,2,b"3"]) == [1,2,"3"]
    assert recursive_unicode([1,[2,b"3"]]) == [1,[2,"3"]]
    assert recursive_unicode({"a": b"b"}) == {"a": "b"}
    assert recursive_unicode({"a": {"b": b"c"}}) == {"a": {"b": "c"}}
    class TestClass(object):
        pass
    t = TestClass()
    assert recursive_unicode({"a": {"b": t}}) == {"a": {"b": t}}



# Generated at 2022-06-24 08:18:38.860804
# Unit test for function json_encode
def test_json_encode():
    assert "</script>" in json_encode({"</script>": True})



# Generated at 2022-06-24 08:18:41.518681
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("a b") == "a+b"
    assert url_escape("a b", plus=False) == "a%20b"
    test_url_escape()



# Generated at 2022-06-24 08:18:43.051971
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "name=john&age=28"
    result = parse_qs_bytes(qs)
    assert result == {b"name": [b"john"], b"age": [b"28"]}, "parse_qs_bytes error"
test_parse_qs_bytes()



# Generated at 2022-06-24 08:18:51.676971
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b'') == '', "Empty string xhtml_escape"
    assert xhtml_escape('&<>\'"') == '&amp;&lt;&gt;&quot;&#39;', "xhtml_escape"
    assert (
        xhtml_escape(
            'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.9) '
            'Gecko/20100824 Firefox/3.6.9'
        )
        == 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.9) '
        'Gecko/20100824 Firefox/3.6.9'
    ), "xhtml_escape"

# Generated at 2022-06-24 08:19:03.269770
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http://site.com/page?id=1&seq=1") == "http://site.com/page?id=1&seq=1"
    assert url_unescape("http://site.com/page?id=1+2&seq=1") == "http://site.com/page?id=1+2&seq=1"
    assert url_unescape("http://site.com/page?id=1&seq=1", plus=False) == "http://site.com/page?id=1&seq=1"
    assert url_unescape("http://site.com/page?id=1+2+3&seq=1", plus=False) == "http://site.com/page?id=1+2 3&seq=1"

# Generated at 2022-06-24 08:19:14.355947
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    def test(s, keep_blank_values = False, strict_parsing = False):
        return parse_qs_bytes(s, keep_blank_values,
                            strict_parsing)

# Generated at 2022-06-24 08:19:19.765976
# Unit test for function json_decode
def test_json_decode():
    import json
    import json_extension
    s = json.dumps({'a': 'b', 'c': {'d': 5, 'e': 'f', 'g': [1, 2]}})
    print(json.loads(s))
    print(json_extension.json_decode(s))

# test_json_decode()

_JSON_DECODE_ERROR = getattr(json, 'JSONDecodeError', ValueError)
json_decode.Error = _JSON_DECODE_ERROR



# Generated at 2022-06-24 08:19:24.850437
# Unit test for function utf8
def test_utf8():
    testing = [
        (None, None),
        (b"ascii", b"ascii"),
        (u"unicöde", b"unic\xc3\xb6de"),
    ]
    for val, expected in testing:
        assert utf8(val) == expected


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:30.700858
# Unit test for function linkify
def test_linkify():
    test_case = {
        'link': 'http://www.baidu.com',
        'expected_result': '<a href="http://www.baidu.com">http://www.baidu.com</a>',
    }
    result = linkify(test_case['link'])
    assert result == test_case['expected_result']

# Generated at 2022-06-24 08:19:38.155070
# Unit test for function squeeze
def test_squeeze():
    try:
        assert ("a  b  c" == squeeze("a  b  c"))
        print("Test 1 passed")
    except:
        print("Test 1 failed")
    try:
        assert ("abc" == squeeze("abc"))
        print("Test 2 passed")
    except:
        print("Test 2 failed")
    try:
        assert ("a  b  " == squeeze("a     b    "))
        print("Test 3 passed")
    except:
        print("Test 3 failed")
    try:
        assert ("  a  b" == squeeze("   a     b"))
        print("Test 4 passed")
    except:
        print("Test 4 failed")

# Generated at 2022-06-24 08:19:39.612439
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>" == "&lt;&gt;")

# Generated at 2022-06-24 08:19:49.124983
# Unit test for function native_str
def test_native_str():
    if sys.version_info[0] >= 3:
        assert native_str(u"foo") == "foo"
        assert not isinstance(native_str(u"foo"), unicode)
        assert native_str(b"foo") == b"foo"
        assert not isinstance(native_str(b"foo"), bytes)
        assert native_str(None) is None
    else:
        assert native_str(u"foo") == u"foo"
        assert isinstance(native_str(u"foo"), unicode)
        assert native_str(b"foo") == b"foo"
        assert isinstance(native_str(b"foo"), bytes)
        assert native_str(None) is None


# Generated at 2022-06-24 08:19:50.416032
# Unit test for function squeeze
def test_squeeze():
    s = squeeze("          hello \t\n\t world\n\n         ")
    assert s == "hello world"



# Generated at 2022-06-24 08:19:56.096392
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'test':1}) == {'test':1}
    assert recursive_unicode([1,'test']) == [1,'test']
    assert recursive_unicode((1,'test')) == (1,'test')
    assert recursive_unicode(b'1') == '1'
    assert recursive_unicode(b'test') == 'test'
    assert recursive_unicode(b'test\xe9') == 'test\xe9'
    assert recursive_unicode(1) == 1
    assert recursive_unicode('') == ''
    assert recursive_unicode('test') == 'test'
    assert recursive_unicode('test\xe9') == 'test\xe9'
    assert recursive_unicode(u'test\xe9') == 'test\xe9'

# Generated at 2022-06-24 08:20:05.223187
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": "b"}) == {"a": "b"}
    assert recursive_unicode({"a": b"b", 2: 3}) == {"a": "b", 2: 3}
    assert recursive_unicode(("a", "b", b"c")) == ("a", "b", "c")
    assert recursive_unicode(("a", b"b", b"c")) == ("a", "b", "c")
    assert recursive_unicode(["a", ["b", b"c"]]) == ["a", ["b", "c"]]



# Generated at 2022-06-24 08:20:08.396467
# Unit test for function json_decode
def test_json_decode():
    a = json_decode(r'{"a":"b"}')
    a1, a2 = a.keys()
    assert a1 == 'a'
    assert a2 == 'b'
assert test_json_decode()



# Generated at 2022-06-24 08:20:09.600515
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape("abc")
    url_unescape("abc", encoding=None)


# Generated at 2022-06-24 08:20:13.124477
# Unit test for function recursive_unicode
def test_recursive_unicode():
    result = recursive_unicode({"foo": [b"abc", b"def"]})
    assert isinstance(result["foo"][0], str)


# Generated at 2022-06-24 08:20:23.045070
# Unit test for function url_unescape
def test_url_unescape():
    result = url_unescape(b'%20', encoding = None, plus = False)
    assert result == b'%20', 'result of url_unescape is not right'
    result = url_unescape(b'%20', encoding = None, plus = True)
    assert result == b' '
    result = url_unescape('%20', encoding = 'ascii', plus = False)
    assert result == '%20'
    result = url_unescape('%20', encoding = 'ascii', plus = True)
    assert result == ' '
    result = url_unescape(' ', encoding = 'ascii', plus = True)
    assert result == '+'


# Generated at 2022-06-24 08:20:24.275291
# Unit test for function json_encode
def test_json_encode():
    pass



# Generated at 2022-06-24 08:20:32.773427
# Unit test for function linkify
def test_linkify():
    print("********* test_linkify start *********")
    text = '<a href="http://foo/bar?a=b&amp;c=d">Test</a>'
    expected = '&lt;a href=&quot;http://foo/bar?a=b&amp;amp;c=d&quot;&gt;Test&lt;/a&gt;'
    s = _unicode(xhtml_escape(text))
    print("s = ", s)
    assert s == expected
    print("********* test_linkify end *********")
test_linkify()


# Generated at 2022-06-24 08:20:34.419130
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    try:
        unicode('utf-8')
    except Exception as e:
        print (e)
        return
    

# Generated at 2022-06-24 08:20:44.720048
# Unit test for function recursive_unicode

# Generated at 2022-06-24 08:20:46.754758
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<div>') == "&lt;div&gt;"


# Generated at 2022-06-24 08:20:48.331046
# Unit test for function json_decode
def test_json_decode():
    pass


# @functools.lru_cache(maxsize=1000)

# Generated at 2022-06-24 08:20:58.101858
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('abc') == 'abc'
    assert url_escape('a b') == 'a+b'
    assert url_escape('a b', False) == 'a%20b'
    # proper quoting of special chars
    assert url_escape('?%') == '%3F%25'
    assert url_escape('?%', False) == '%3F%25'
    # non-ascii
    assert url_escape('\xc2\xa9') == '%C2%A9'
    assert url_escape('\xc2\xa9', False) == '%C2%A9'
    # bytes
    assert url_escape(b'abc') == 'abc'
    assert url_escape(b'a b') == 'a+b'

# Generated at 2022-06-24 08:21:00.656019
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
    print(linkify("www.facebook.com"))

test_linkify()



# Generated at 2022-06-24 08:21:05.909774
# Unit test for function linkify
def test_linkify():
    text = "Link www.facebook.com, http://Mysite.com"
    print(linkify(text))
    text = "Link www.facebook.com, http://Mysite.com"
    print(linkify(text))


# From Django:
# https://github.com/django/django/blob/master/django/utils/encoding.py

# Generated at 2022-06-24 08:21:11.487077
# Unit test for function native_str
def test_native_str():
    primes = [1,3,5,7,11,13,17,19,23,29,31,37]
    for i, v in enumerate(primes):
        assert str(v) == _native_str(v)
        assert isinstance(str(v), str)



# Generated at 2022-06-24 08:21:22.456550
# Unit test for function linkify
def test_linkify():
    test_text = (
        u"\u6b22\u8fce\u6765\u5230\u6211\u7684\u535a\u5ba2http://zrq.me\n"
        u"\u9053\u7406\u540e\u7aef\u7684\n"
        u"Thrift\u670d\u52a1\u5668\u5b9e\u8df5\n"
        u"\u5bf9\u4e8ePython\u5f00\u53d1\u8005---\u4ee5\u4e3a\u4f60\u4e2a\u4eba\u53c2\u8003\u3002"
    )
    linkified_text = link

# Generated at 2022-06-24 08:21:23.585955
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(b"%20", encoding=None)



# Generated at 2022-06-24 08:21:35.481237
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert(xhtml_unescape('&lt;&#45;&gt;') == '<-' )


# When we encounter an unknown entity beyond this point, we allow it
# to pass through as is, so it will appear in the final document.
# This behavior is not specified by the standard, but it has become
# the de facto standard among web browsers.  In most cases, this is
# probably harmless.
_UNKNOWN_HTML_ENTITY = re.compile(r"&#(\d+);?")
_UNKNOWN_HTML_ENTITY_GT = re.compile(r"&#(\d+);")
_UNKNOWN_XML_ENTITY = re.compile(r"&#(\d+);")
_UNKNOWN_XML_ENTITY_GT = re.compile(r"&#(\d+);")



# Generated at 2022-06-24 08:21:47.076804
# Unit test for function recursive_unicode
def test_recursive_unicode():
    mylist = [u'a', 2, u'c']
    mylist1 = recursive_unicode(mylist)
    assert isinstance(mylist1[0], str)

    mytuple = (u'a', 2, u'c')
    mytuple1 = recursive_unicode(mytuple)
    assert isinstance(mytuple1[0], str)

    mydict = {'a': 1, 2: u'b', u'c': 3}
    mydict1 = recursive_unicode(mydict)
    assert isinstance(mydict1['a'], str)
    assert isinstance(mydict1[2], str)
    assert isinstance(mydict1['c'], str)



# Generated at 2022-06-24 08:21:52.067327
# Unit test for function linkify
def test_linkify():
    # Asserts
    assert linkify("", shorten=False, extra_params="", require_protocol=False, permitted_protocols=["http", "https"]) == ""


# Generated at 2022-06-24 08:21:55.356982
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = {"a": "A", "b": "B", "c": "C", "d": "D"}
    recursive_unicode(obj)
    assert True

# Let's make sure it works with __builtin__
try:
    from __builtin__ import unicode
except ImportError:
    pass



# Generated at 2022-06-24 08:22:04.389623
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    # Simple url
    assert linkify("http://www.facebook.com/") == '<a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    # Simple url with text
    assert linkify("http://www.facebook.com/", shorten=True) == '<a href="http://www.facebook.com/">facebook.com</a>'
    # Simple url with query string
    assert linkify("http://www.facebook.com/?d=1") == '<a href="http://www.facebook.com/?d=1">http://www.facebook.com/?d=1</a>'
    # Url with hyphens and underscores

# Generated at 2022-06-24 08:22:07.448612
# Unit test for function url_escape
def test_url_escape():
    a = 1
    b = 1
    c = 1
    url_escape(a,b)
    url_escape(a,b)


# Generated at 2022-06-24 08:22:14.670339
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=b&c=d') == {b'a': [b'b'], b'c': [b'd']}
    assert parse_qs_bytes(b'a=b&c=d&a=e') == {b'a': [b'b', b'e'], b'c': [b'd']}
    assert parse_qs_bytes(b'a=') == {b'a': [b'']}
    assert parse_qs_bytes(b'a=&b=') == {b'a': [b''], b'b': [b'']}
    assert parse_qs_bytes(b'=a') == {b'': [b'a']}
    assert parse_qs_bytes(b'&=') == {b'': [b'']}
    assert parse_

# Generated at 2022-06-24 08:22:25.048271
# Unit test for function linkify
def test_linkify():
    assert linkify("hello http://www.example.com/ good") == \
        'hello <a href="http://www.example.com/">http://www.example.com/</a> good'
    assert linkify("hello http://www.example.com/_%50_ good") == \
        'hello <a href="http://www.example.com/_%50_">http://www.example.com/_%50_</a> good'
    assert linkify("hello www.example.com good") == \
        'hello <a href="http://www.example.com">www.example.com</a> good'

# Generated at 2022-06-24 08:22:34.250896
# Unit test for function linkify
def test_linkify():
    # Ensure linkify does not crash for these inputs
    for _input in (
        # Non-strings
        None,
        # Bytes: http://facebook.com is ASCII-only, so this is safe
        b"Basic message without links http://facebook.com",
        # Unicode: http://facebook.com is ASCII-only, so this is safe
        u"Basic message without links http://facebook.com",
    ):
        stripped_output = linkify(_input)
        assert isinstance(stripped_output, str)
    assert linkify("http://www.example.com", shorten=True) == (
        '<a href="http://www.example.com">http://www.example.com</a>'
    )

# Generated at 2022-06-24 08:22:36.765374
# Unit test for function xhtml_escape
def test_xhtml_escape():assert xhtml_escape("""<>"'&""") == """&lt;&gt;&quot;&#39;&amp;"""



# Generated at 2022-06-24 08:22:42.896247
# Unit test for function url_escape
def test_url_escape():
    a = {'a': 1, 'b': 2}
    assert utf8(a) == b'{' + utf8('a') + b': 1, ' + utf8('b') + b': 2}'
    assert url_escape(utf8(a)) == '%7B%27a%27%3A+1%2C+%27b%27%3A+2%7D'


# Generated at 2022-06-24 08:22:46.942641
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = recursive_unicode(['cat', 'horse', 56])
    assert isinstance(x[0], str)
    assert isinstance(x[1], str)
    assert isinstance(x[2], int)

test_recursive_unicode()



# Generated at 2022-06-24 08:22:51.807850
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://baidu.com") == 'http%3A%2F%2Fbaidu.com'
    assert url_escape("http://baidu.com", plus=False) == 'http%3A//baidu.com'
test_url_escape()



# Generated at 2022-06-24 08:22:54.750643
# Unit test for function json_encode
def test_json_encode():
    val = json_encode({'foo': '<script>'})
    assert val == '{"foo": "<\\/script>"}'
test_json_encode()


_BASESTRING_TYPE = typing.Union[bytes, str]



# Generated at 2022-06-24 08:22:59.715312
# Unit test for function linkify
def test_linkify():
    assert linkify(
        """I like http://www.example.com/foo_bar.html and http://www.example.net/."""
    ) == """I like <a href="http://www.example.com/foo_bar.html">http://www.example.com/foo_bar.html</a> and <a href="http://www.example.net/">http://www.example.net/</a>."""



# Generated at 2022-06-24 08:23:10.054959
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://example.com") == 'Hello <a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://example.com", shorten=True) == 'Hello <a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://example.com/foo/bar/baz") == 'Hello <a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-24 08:23:12.649606
# Unit test for function native_str
def test_native_str():
    from tornado.escape import native_str
# Input: (1,b'other')
    native_str((1,b'other'))
# Expected: (1, 'other')



# Generated at 2022-06-24 08:23:22.501695
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("Go to http://www.example.com") == 'Go to <a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("Go to http://www.example.com/") == 'Go to <a href="http://www.example.com/">http://www.example.com/</a>'

# Generated at 2022-06-24 08:23:32.525571
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("http://github.com/foo/bar") == '<a href="http://github.com/foo/bar">http://github.com/foo/bar</a>'
    assert linkify("www.github.com") == '<a href="http://www.github.com">www.github.com</a>'
    assert linkify("http://github.com/foo/bar.") == '<a href="http://github.com/foo/bar">http://github.com/foo/bar</a>.'
    assert linkify("(http://github.com/foo/bar)") == '(<a href="http://github.com/foo/bar">http://github.com/foo/bar</a>)'

# Generated at 2022-06-24 08:23:41.427985
# Unit test for function utf8
def test_utf8():
    assert utf8('foo') == b'foo'
    assert utf8(b'foo') == b'foo'
    assert utf8(None) is None
    assert utf8(u'foo') == b'foo'
    assert utf8(u'\u2603') == b'\xe2\x98\x83'
    assert utf8(u'\U0001f30d') == b'\xf0\x9f\x8c\x8d'
    try:
        utf8(b'\xff')
    except UnicodeDecodeError:
        pass
    else:
        assert False, 'Expected exception'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:23:51.949504
# Unit test for function linkify
def test_linkify():
    assert linkify("foo http://www.google.com/") == 'foo <a href="http://www.google.com/">http://www.google.com/</a>'

    # Make sure it doesn't suck up email addresses
    assert linkify("hi a@b.com there") == 'hi a@b.com there'

    # Make sure it doesn't linkify javascript:
    assert linkify("javascript:alert()") == 'javascript:alert()'

    # Make sure trailing punctuation is not included in the link:
    assert linkify("go to http://www.google.com/.") == 'go to <a href="http://www.google.com/">http://www.google.com/</a>.'


# Generated at 2022-06-24 08:23:55.632861
# Unit test for function url_escape
def test_url_escape():
    value1 = "This is a test."
    value2 = "This is a test."
    plus1 = True 
    plus2 = False
    url_escape(value1,plus1)
    url_escape(value2,plus2)
    # test with 0 - 1
    value = "0"
    plus = True
    url_escape(value,plus)



# Generated at 2022-06-24 08:24:00.714936
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(None) is None
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        assert 0, "did not detect error"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:24:10.379536
# Unit test for function xhtml_escape
def test_xhtml_escape():
    xhtml_escape('<>&"\'')


_BASESTRING_TYPES = (bytes, unicode_type)  # type: typing.Tuple[typing.Any, ...]
if str is not unicode_type:  # Python 3
    _BASESTRING_TYPES += (str,)  # type: ignore

_TO_UNICODE_TYPES = (bytes, type(None))  # type: typing.Tuple[typing.Any, ...]
if str is not unicode_type:  # Python 3
    _TO_UNICODE_TYPES += (str,)  # type: ignore


# Generated at 2022-06-24 08:24:17.942849
# Unit test for function native_str
def test_native_str():
    assert native_str(u'foo') == u'foo'
    assert native_str(u'foo'.encode('utf-8')) == u'foo'
    assert native_str(u'\xe9') == u'\xe9'
    assert native_str(u'\xe9'.encode('utf-8')) == u'\xe9'
    assert native_str(u'\xe9'.encode('latin1')) == u'\xe9'
    assert native_str(b'foo') == u'foo'
    assert native_str(b'foo', 'utf-8') == u'foo'
    assert native_str(b'\xe9', 'latin1') == u'\xe9'

# Generated at 2022-06-24 08:24:22.365086
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('http://www.google.com') == 'http%3A%2F%2Fwww.google.com'
    assert url_escape('http://www.google.com', plus=False) == 'http%3A%2F%2Fwww.google.com'


# Generated at 2022-06-24 08:24:25.642356
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b"<>\"'") == "&lt;&gt;&quot;&#39;"


# to_unicode was previously named _unicode not because it was private,
# but to avoid conflicts with the built-in "unicode" function/type

# Generated at 2022-06-24 08:24:34.006868
# Unit test for function native_str
def test_native_str():
    print(__name__)
    print(type(__name__))
    for x in range(4):
        print('the count is ', x)
    str_s = 'aaa'
    print(type(str_s))
    print(type(url_unescape(str_s)))


if __name__ == "__main__":
    test_native_str()

# Generated at 2022-06-24 08:24:36.477168
# Unit test for function json_encode
def test_json_encode():
    test_string = "one/two/three"
    want = '"one\\/two\\/three"'
    assert(json_encode(test_string) == want)
test_json_encode()



# Generated at 2022-06-24 08:24:38.911099
# Unit test for function utf8
def test_utf8():
  assert isinstance(utf8('a'), bytes)


_TO_UNICODE_TYPES = (str, type(None))



# Generated at 2022-06-24 08:24:48.892248
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%20b", encoding=None, plus=True) == b"a b"
    assert url_unescape("a+b", encoding=None, plus=False) == b"a+b"
    assert url_unescape("a+b", encoding="ascii", plus=True) == "a b"
    assert url_unescape("a b", encoding="ascii", plus=False) == "a b"
    assert url_unescape("a%2Bb", encoding="ascii", plus=True) == "a%2Bb"
    assert url_unescape("a%2Bb", encoding="ascii", plus=False) == "a+b"


# Generated at 2022-06-24 08:24:55.558670
# Unit test for function native_str
def test_native_str():
    from tornado.escape import native_str
    assert isinstance(native_str(b'foo'), str)
    assert isinstance(native_str('foo'), str)
    assert native_str(123) == '123'
    assert native_str(b'foo') == 'foo'
    assert native_str('foo') == 'foo'
    assert native_str(None) is None
    assert native_str(object()) == repr(object())



# Generated at 2022-06-24 08:25:04.709312
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert {b"foo": [b"bar"]} == parse_qs_bytes(b"foo=bar")
    assert {b"foo": [b"bar"]} == parse_qs_bytes("foo=bar")
    assert {b"foo": [b"bar"]} == parse_qs_bytes("foo=bar".encode("ascii"))
    assert {b"foo": [b"bar"]} == parse_qs_bytes("foo=bar".encode("utf8"))
    assert {b"foo": [b"bar"]} == parse_qs_bytes("foo=bar".encode("utf8"), strict_parsing=True)
    assert {b"foo": [b"bar"]} == parse_qs_bytes("foo=bar".encode("utf16"))

    # There is no strict_parsing for parse_qs

# Generated at 2022-06-24 08:25:07.734534
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(
        [1, 2, {'a': 1, 'b': b'\xef\xbb\xbf<html>', 'c': 3}]
    ) == [1, 2, {'a': 1, 'b': '<html>', 'c': 3}]

# test_recursive_unicode()



# Generated at 2022-06-24 08:25:10.334205
# Unit test for function json_encode
def test_json_encode():
    #assert json_encode(r'</script>') == r'<\/script>'
    json_encode(r'</script>')



# Generated at 2022-06-24 08:25:15.920233
# Unit test for function recursive_unicode
def test_recursive_unicode():
    from tornado.util import recursive_unicode
    test_dict = {b'key1': b'value1', b'key2': [b'subkey1', b'subkey2']}
    assert b'key1' in test_dict
    assert u'key1' not in test_dict
    assert b'value1' in list(test_dict.values())
    assert u'value1' not in list(test_dict.values())

    new_dict = recursive_unicode(test_dict)
    assert 'key1' in new_dict
    assert u'key1' in new_dict
    assert 'value1' in list(new_dict.values())
    assert u'value1' in list(new_dict.values())

    # Test the use case of a dict value. #2490

# Generated at 2022-06-24 08:25:23.070245
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&#x27;") == "'"
    assert xhtml_unescape("&quot;") == '"'


# json_encode and json_decode stole with gratitude from simplejson.
# Copyright (c) 2006 Bob Ippolito. All rights reserved.
# http://undefined.org/python/#simplejson


# Generated at 2022-06-24 08:25:31.422775
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('') == ''
    assert xhtml_escape(11) == '11'
    assert xhtml_escape(None) == 'None'
    assert xhtml_escape(True) == 'True'
    assert xhtml_escape(False) == 'False'
    assert xhtml_escape('a<b>c') == 'a&lt;b&gt;c'
test_xhtml_escape()



# Generated at 2022-06-24 08:25:44.713937
# Unit test for function recursive_unicode
def test_recursive_unicode():
    s = {'a': 1, 'b': b"2"}
    assert recursive_unicode(s) == {'a': 1, 'b': "2"}

# Test function recursive_unicode
test_recursive_unicode()

# I originally used the regex from
# http://daringfireball.net/2010/07/improved_regex_for_matching_urls
# but it gets all exponential on certain patterns (such as too many trailing
# dots), causing the regex matcher to never return.
# This regex should avoid those problems.

# Generated at 2022-06-24 08:25:46.049898
# Unit test for function json_decode
def test_json_decode():
    json_decode("{}")
    json_decode("{\"a\":1,\"b\":2}")
    json_decode("[1,2]")


# Generated at 2022-06-24 08:25:48.642791
# Unit test for function utf8
def test_utf8():
    if not isinstance('test', bytes):
        assert utf8('test') == b'test'
        assert utf8(b'test') == b'test'
        assert utf8(None) == None

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:25:53.026328
# Unit test for function json_encode
def test_json_encode():
    value = {
        "foo": ["bar", "baz"],
        "quux": "hello world",
        "html": "<b>",
        "null": None,
    }
    assert json_encode(value) == '{"foo": ["bar", "baz"], "quux": "hello world", "html": "<b>", "null": null}'


# Generated at 2022-06-24 08:25:56.611678
# Unit test for function url_unescape
def test_url_unescape():
    s = url_unescape("abc+-<>")
    assert s == "abc+-<>"
    s = url_unescape("%E5%93%88%E5%93%88")
    assert s == "哈哈"


# Generated at 2022-06-24 08:26:04.800458
# Unit test for function utf8
def test_utf8():
    assert utf8("hello") == b"hello"
    assert utf8(u"hello") == b"hello"
    assert utf8(b"hello") == b"hello"
    assert utf8(None) is None
    try:
        utf8(123)
    except TypeError:
        pass
    else:
        assert False
    if _unicode is not str:

        def to_unicode(x):
            return x

    else:

        def to_unicode(x):
            return x.decode("utf-8")

    assert to_unicode(utf8(u"\xe9")) == u"\xe9"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:07.028852
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = b'a=1&b=2'
    assert parse_qs_bytes(qs) == {'a': [b'1'], 'b': [b'2']}
test_parse_qs_bytes()



# Generated at 2022-06-24 08:26:15.125935
# Unit test for function utf8
def test_utf8():
    assert utf8("hello") == b"hello"
    assert utf8("\u1234") == b"\xe1\x88\xb4"
    assert utf8(None) is None
    try:
        utf8(1)
        assert False
    except TypeError:
        pass
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:26.177795
# Unit test for function native_str
def test_native_str():
    import sys
    assert native_str(b"foo") == b"foo"
    assert native_str(u"foo") == "foo"
    assert native_str(b"foo", "latin1") == b"foo"
    assert native_str(u"foo", "latin1") == "foo"
    assert native_str(b"\xff", "latin1") == b"\xff"
    assert native_str(u"\u2603", "latin1") == "\u2603"

    assert native_str(None) is None
    assert native_str(object()) == "<...>"

    # Error handling:
    with pytest.raises(TypeError):
        native_str(b"foo", "utf8", object())

# Generated at 2022-06-24 08:26:27.639505
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("some   text") == "some text"


# Generated at 2022-06-24 08:26:32.032617
# Unit test for function recursive_unicode
def test_recursive_unicode():
    expected = {
        'punchline': 'tokyo?',
        'setup': 'knock knock'
    }
    result = recursive_unicode({
        b'punchline': b'tokyo?',
        b'setup': b'knock knock'
    })
    assert result == expected

# Generated at 2022-06-24 08:26:33.266645
# Unit test for function json_encode
def test_json_encode():
    assert json_encode('</script>') == '"<\\/script>"'



# Generated at 2022-06-24 08:26:39.170797
# Unit test for function json_decode
def test_json_decode():
    assert(json_decode("{'a': 'b'}") == {'a': 'b'})
    assert(json_decode("a") == "a")
    assert(json_decode("'a'") == "a")
    assert(json_decode("1") == 1)
    assert(json_decode("[1, 2, 3]") == [1, 2, 3])

# This regular expression matches the start of any javascript directive,
# including the one before a line continuation character.
_JS_ESCAPE_REGEX = re.compile(r'(<!--.*?-->|^\s*(?://)?<!\[CDATA\[.*?//\]\]>|^\s*(?://)?.)',
                              re.MULTILINE | re.DOTALL)


# Generated at 2022-06-24 08:26:45.758013
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape("\"") == "&quot;"

xhtml_unescape = html.unescape

# Generated at 2022-06-24 08:26:48.737852
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"foo=b%25r") == {"foo": [b"b%r"]}
# test_parse_qs_bytes()


# Generated at 2022-06-24 08:26:57.795023
# Unit test for function utf8
def test_utf8():
    checkEqual(utf8(b"123"),b"123")
    checkEqual(utf8("123"),b"123")
    checkEqual(utf8(None),None)
    checkEqual(utf8(repr),b"<built-in function repr>")
    try:
        utf8(123)
        checkEqual(1,0)
    except TypeError:
        checkEqual(1,1)
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:27:04.008985
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("abc%20def", plus=True) == "abc def"
    assert url_unescape("abc+def", plus=True) == "abc def"
    assert url_unescape("abc%20def", plus=False) == "abc%20def"
    assert url_unescape("abc+def", plus=False) == "abc+def"


_UTF8_TYPES = (bytes, type(None))  # Objects that should be UTF-8 encoded



# Generated at 2022-06-24 08:27:09.564655
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('<head>') == '&lt;head&gt;'
    assert xhtml_unescape('&lt;head&gt;') == '<head>'
    assert xhtml_unescape('&lt;&gt;&amp;&quot;&#39;') == '<>&"\''
test_xhtml_unescape()



# Generated at 2022-06-24 08:27:12.657106
# Unit test for function json_decode
def test_json_decode():
    s = '''[{"key": "value"}]'''
    assert json_decode(s) == [{"key": "value"}]


_UTF8_TYPES = (bytes, type(None))  # type: typing.ClassVar[Any]



# Generated at 2022-06-24 08:27:16.324915
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    # test xhtml_unescape function
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&lt;&lt;&lt;&amp;') == '<<<&'


# utility function for xhtml_unescape

# Generated at 2022-06-24 08:27:17.940235
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print(parse_qs_bytes("a=1"))
test_parse_qs_bytes()



# Generated at 2022-06-24 08:27:24.387256
# Unit test for function json_decode
def test_json_decode():
    a = json_decode("{'test': '.123'}")
    assert a['test'] == '.123'

# json_encode_basestring_as_str is used as a fallback for
# systems that do not have json.encoder.ESCAPE_SLASH.
# Like the built-in version it escapes forward slashes, but
# unlike the built-in version it does not escape backwards
# slashes.

# Generated at 2022-06-24 08:27:29.927282
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert(xhtml_escape('<div class="spam">') == '&lt;div class=&quot;spam&quot;&gt;')
test_xhtml_escape()

_JSON_ESCAPE_RE = re.compile(r"[\x00-\x1f<>\"]")



# Generated at 2022-06-24 08:27:36.747261
# Unit test for function utf8
def test_utf8():
    assert utf8('abc') == b'abc'
    assert utf8('\xe7\xbd\x91\xe9\xa1\xb5') == b'\xe7\xbd\x91\xe9\xa1\xb5'
    assert utf8(b'\xe7\xbd\x91\xe9\xa1\xb5') == b'\xe7\xbd\x91\xe9\xa1\xb5'

