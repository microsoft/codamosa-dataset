

# Generated at 2022-06-24 08:17:35.574903
# Unit test for function linkify
def test_linkify():
    #assert linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify("Hello www.tornadoweb.org!") == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>!'



# Generated at 2022-06-24 08:17:41.273370
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # Unit test for function recursive_unicode
    obj = ["abcd", "efgh"]
    try:
        result = recursive_unicode(obj)
    except Exception as e:
        print("Exception", e)
        return False
    return True


# Generated at 2022-06-24 08:17:44.814879
# Unit test for function url_escape
def test_url_escape():
    assert 'https%3A%2F%2Fwww.google.com' == url_escape('https://www.google.com', plus=False)
    assert 'https%3A%2F%2Fwww.google.com' == url_escape('https://www.google.com')


# Generated at 2022-06-24 08:17:55.570700
# Unit test for function recursive_unicode
def test_recursive_unicode():
    data = [
        1,
        2,
        'abc',
        bytes('\xc3\xa9', 'utf-8'),
        {
            bytes('\xe0\xa4\xa6', 'utf-8'): bytes('\xe0\xa4\xb9', 'utf-8')
        },
        [
            {
                bytes('\xe0\xa4\xa6', 'utf-8'): bytes('\xe0\xa4\xb9', 'utf-8')
            }
        ]
    ]
    ret = recursive_unicode(data)

# Generated at 2022-06-24 08:18:01.931006
# Unit test for function recursive_unicode
def test_recursive_unicode():
    utf8 = b"\xc3\xbf"
    dict_ascii = {"name": "Nino", "lastname": "Tolomio", "age": "20"}
    dict_non_ascii = {"name": "Nino", "lastname": utf8, "age": "20"}
    list_ascii = ["Nino", "Tolomio", "20"]
    list_non_ascii = ["Nino", utf8, "20"]
    tuple_ascii = ("Nino", "Tolomio", "20")
    tuple_non_ascii = ("Nino", utf8, "20")
    s_ascii = "name"
    s_non_ascii = utf8


# Generated at 2022-06-24 08:18:07.440776
# Unit test for function json_decode
def test_json_decode():
    assert(json_decode('{"key": "value"}') == {"key": "value"})

# json_encode_pretty and json_decode are tested in test_escape.py

_RECODE_HTML_ENTITY_RE = re.compile(r"&(#?)(\d{1,5}|\w{1,8});")



# Generated at 2022-06-24 08:18:15.090235
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([b"a"]) == [u"a"]
    assert recursive_unicode([b"a", [b"b"]]) == [u"a", [u"b"]]
    assert recursive_unicode({"a": [b"b"]}) == {u"a": [u"b"]}
    # recursive_unicode gratuitously supports tuples,
    # which are not often used with json.
    assert recursive_unicode((b"a", (b"b", ))) == (u"a", (u"b", ))



# Generated at 2022-06-24 08:18:24.589568
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_dict = {}
    # test 1: simple case
    qs1 = "?example_key=example_value&example_key2=example_value2"
    test_dict = {b"example_key": [b"example_value"], b"example_key2":[b"example_value2"]}
    assert parse_qs_bytes(qs1) == test_dict

    # test 2: keep_blank_values = True
    test_dict = {b"example_key": [b"example_value"], b"example_key2":[b"example_value2"], b"": [b""]}
    assert parse_qs_bytes(qs1, keep_blank_values=True) == test_dict


# Generated at 2022-06-24 08:18:30.190149
# Unit test for function url_escape
def test_url_escape():
    escape_value = url_escape(b"here&there")
    assert escape_value == "%68%65%72%65%26%74%68%65%72%65"
    escape_value = url_escape(b"here&there", plus=False)
    assert escape_value == "%68%65%72%65%26%74%68%65%72%65"
test_url_escape()



# Generated at 2022-06-24 08:18:35.601338
# Unit test for function json_decode
def test_json_decode():
    import json
    a = '{"name":"Frank","age":23}'
    b = '{"name":"Frank","age":23}'.encode('utf-8')
    c = bytes('{"name":"Frank","age":23}', encoding='utf-8')
    assert json_decode(a) == json.loads(a)
    assert json_decode(b) == json.loads(b.decode())
    assert json_decode(c) == json.loads(c.decode())


# Generated at 2022-06-24 08:18:37.389943
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("你好\n tornado!") == "你好 tornado!"



# Generated at 2022-06-24 08:18:42.927156
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("foo%21%23%25%7E%2A%2B%3D%3F%5E%60%7C%5B%5D%5C%7B%7D") == "foo!#$%~*+=" \
                                                                                "?^`|[]\\{}"
    assert url_unescape("foo%20bar%20123%2C%20abc", encoding="utf-8") == "foo bar 123, abc"
    assert url_unescape("foo+bar+123,+abc", encoding="utf-8", plus=False) == "foo bar 123, abc"
    assert url_unescape("foo+bar+123,+abc", encoding="utf-8", plus=True) == "foo bar 123, abc"

# Generated at 2022-06-24 08:18:46.377595
# Unit test for function json_encode
def test_json_encode():
    # type: () -> None
    value = json_encode({'test': True})
    assert value == '{"test": true}'
try:
    # On Python 3.4+ json.JSONEncoder defaults to pretty printing
    # with an indent of 4 spaces.  This is a nice feature but we
    # don't want it (in general, pretty printing should be opt-in
    # since it can degrade performance and it isn't supported by all
    # json parsers) so we adjust the indent back to 0 here.
    json._default_encoder.indent = 0  # type: ignore
except Exception:
    # On Python 3.2 and 3.3 this attribute doesn't exist; it doesn't
    # seem worth worrying about.
    pass



# Generated at 2022-06-24 08:18:52.088066
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("A") == "A"
    assert url_escape("???") == "???"
    assert url_escape("%") == "%25"
    assert url_escape("&") == "%26"
    assert url_escape("?") == "%3F"
    assert url_escape("+") == "%2B"
    assert url_escape(" ") == "%20"
    assert url_escape(" ", plus=False) == "+"
    assert url_escape("\u4f60\u597d") == "%E4%BD%A0%E5%A5%BD"


# Generated at 2022-06-24 08:18:57.804567
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = recursive_unicode({'foo': 'bar', 'baz': [1, 2, 3], 'boo': ('a', 'b', 'c')})
    y = recursive_unicode({'foo': u'bar', 'baz': [1, 2, 3], 'boo': ('a', 'b', 'c')})
    assert x==y

# Generated at 2022-06-24 08:19:01.954751
# Unit test for function recursive_unicode
def test_recursive_unicode():
    w = {"a": 1, "b": ["1", 2, (1, "str")], "c": b"bytes"}
    x = recursive_unicode(w)
    assert type(x['b'][2][1]) == str
    assert type(x['c']) == str

# Generated at 2022-06-24 08:19:05.153540
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    s = xhtml_unescape(b"&amp;&apos;&gt;&lt;&quot;")
    assert s == "'><\""


# Generated at 2022-06-24 08:19:16.242042
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<x>") == "&lt;x&gt;"
    assert xhtml_escape("abc &&& def") == "abc &amp;&amp;&amp; def"
    assert xhtml_escape("a\"b") == "a&quot;b"
    assert xhtml_escape("a'b") == "a&#39;b"
    assert xhtml_escape("<>\"'&") == "&lt;&gt;&quot;&#39;&amp;"


_URL_ESCAPE_RE = re.compile(r"[a-fA-F0-9]{2}")



# Generated at 2022-06-24 08:19:19.005393
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>\"'&") == "&lt;&gt;&quot;&#39;&amp;"


# Generated at 2022-06-24 08:19:23.356550
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(["testing", [0, 1, 2]]) == ["testing", [0, 1, 2]]
    assert recursive_unicode((1, 2, 3)) == (1, 2, 3)
    assert recursive_unicode({ 1: 2 }) == { 1: 2 }



# Generated at 2022-06-24 08:19:34.578736
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    from tornado.testing import AsyncHTTPTestCase, ExpectLog
    import urllib
    import tornado.httpclient
    import tornado.web
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    
    def _parse_qs_bytes(qs, keep_blank_values=False, strict_parsing=False):
        # This is gross, but python3 doesn't give us another way.
        # Latin1 is the universal donor of character encodings.
        if isinstance(qs, bytes):
            qs = qs.decode("latin1")
        result = urllib.parse.parse_qs(
            qs, keep_blank_values, strict_parsing, encoding="latin1", errors="strict"
        )
        encoded = {}


# Generated at 2022-06-24 08:19:38.422723
# Unit test for function squeeze
def test_squeeze():
    lst = ['   pla   y   ', '  ', '']
    for i in lst:
        assert squeeze(i) == 'pla y'


# Generated at 2022-06-24 08:19:41.097805
# Unit test for function json_decode
def test_json_decode():
    d = {'name':'zs','age':123}
    t = json.dumps(d)
    print(json_decode(t))


# Generated at 2022-06-24 08:19:49.343202
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Test that it gets byte strings back in the right encoding.
    assert parse_qs_bytes(b"foo=%E5%93%89%E5%93%89", encoding="utf-8") == {
        "foo": [u"哉哉".encode("utf-8")]
    }
    # Test that it gets unicode strings back too.
    assert parse_qs_bytes(u"foo=%E5%93%89%E5%93%89", encoding="utf-8") == {
        "foo": [u"哉哉".encode("utf-8")]
    }



# Generated at 2022-06-24 08:19:54.907163
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(value=b'foo+bar', encoding='utf-8', plus=True)
    url_unescape(value='foo+bar', encoding='utf-8', plus=True)
    url_unescape(value=b'foo+bar', encoding='utf-8', plus=False)
    url_unescape(value='foo+bar', encoding='utf-8', plus=False)
    url_unescape(value=b'foo+bar', encoding=None, plus=True)
    url_unescape(value=b'foo+bar', encoding=None, plus=False)


# This is imported as a module-level function to avoid a circular import
# in the common case where we are also importing the `escape.xhtml_unescape`
# function.  The circularity comes from the fact that
# `xhtml_un

# Generated at 2022-06-24 08:20:00.292561
# Unit test for function json_encode
def test_json_encode():
    value = {"a": 1, "b": True, "c":"</"}
    st = json.dumps(value)
    assert json_encode(value) == st.replace("</", "<\\/")
test_json_encode()


# json_decode wraps json.loads since 2.1.

# Generated at 2022-06-24 08:20:09.927128
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = {
        "key": b"value",
        "list": [1, 2, 3, b"4"],
        "tuple": (1, 2, 3, b"4"),
        "dict": {"one": 1, b"two": 2},
        "int": 1,
        "bytes": b"foo",
    }
    expected = {
        "key": "value",
        "list": [1, 2, 3, "4"],
        "tuple": (1, 2, 3, "4"),
        "dict": {"one": 1, "two": 2},
        "int": 1,
        "bytes": "foo",
    }
    assert recursive_unicode(obj) == expected



# Generated at 2022-06-24 08:20:13.338747
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    s = "test=test"
    result = parse_qs_bytes(s)
    assert result
    assert isinstance(result['test'][0], bytes)

# Generated at 2022-06-24 08:20:24.686429
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&gt;&lt;') == '><'
    assert xhtml_unescape("&quot;&apos;") == '"\''
    # Un-escape incorrect XHTML
    assert xhtml_unescape('&#65') == 'A'
    assert xhtml_unescape('&#x41') == 'A'
    assert xhtml_unescape('&#x666') == 'f'
    assert xhtml_unescape('&#x41;&#x43;&#x3d;&#x3f;') == 'AC=?'
    assert xhtml_unescape('&#65&#;&#x;&x') == 'AA&&x'


# json_encode and json_decode partially

# Generated at 2022-06-24 08:20:27.746392
# Unit test for function recursive_unicode
def test_recursive_unicode():
    a = {"a":"a", "b": "b"}
    b = recursive_unicode(a)
    assert(type(b['a']) == str)

test_recursive_unicode()


# Generated at 2022-06-24 08:20:35.716722
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert "'" in _XHTML_ESCAPE_RE.pattern


# Workaround for https://bugs.python.org/issue26658
_HTML_UNESCAPE_TABLE = {
    "&amp;": "&",
    "&lt;": "<",
    "&gt;": ">",
    "&quot;": '"',
    "&#39;": "'",
}
for _name in html.entities.entitydefs:
    if len(_name) == 1:
        _unescaped = chr(html.entities.name2codepoint[_name])
        if _unescaped != "&":
            _HTML_UNESCAPE_TABLE["&%s;" % _name] = _unescaped

# Generated at 2022-06-24 08:20:39.254555
# Unit test for function linkify
def test_linkify():
    assert (
        linkify(
            "http://example.com/path/file?foo=bar&baz=blah"
        )
        == '<a href="http://example.com/path/file?foo=bar&baz=blah">http://example.com/path/file?foo=bar&amp;baz=blah</a>'
    )
test_linkify()



# Generated at 2022-06-24 08:20:50.793938
# Unit test for function linkify
def test_linkify():
    text = "Hello http://www.tornadoweb.org!"
    text = linkify(text)
    assert text == 'Hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>!'

    text = "Hello www.tornadoweb.org!"
    text = linkify(text)
    assert text == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>!'

    text = "Hello http://www.tornadoweb.org/!"
    text = linkify(text)
    assert text == 'Hello <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>!'

    text = "Hello https://www.tornadoweb.org/!"

# Generated at 2022-06-24 08:20:58.353591
# Unit test for function recursive_unicode
def test_recursive_unicode():
    r_dict = {"key1": "value1", "key2": "value2", "key3": "value3"}
    r_list = ["value1", "value2", "value3"]
    r_tuple = tuple(r_list)
    r_dict_res = recursive_unicode(r_dict)
    r_list_res = recursive_unicode(r_list)
    r_tuple_res = recursive_unicode(r_tuple)
    assert(r_dict_res["key1"] == "value1")
    assert(r_dict_res["key2"] == "value2")
    assert(r_dict_res["key3"] == "value3")
    assert(r_list_res[0] == "value1")

# Generated at 2022-06-24 08:20:59.677193
# Unit test for function native_str
def test_native_str():
    print(native_str("中文"))

# Generated at 2022-06-24 08:21:01.182668
# Unit test for function native_str
def test_native_str():
    seq = to_unicode("Hello")
    assert seq == r"Hello"

# Generated at 2022-06-24 08:21:04.415270
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(1) == '1'
    assert json_encode(True) == 'true'
    assert json_encode(False) == 'false'
    assert json_encode(None) == 'null'
    assert json_encode(['a', 1, True]) == '["a", 1, true]'
    assert json_encode(json_encode(['a', 1, True])) == '"\\"a\\", 1, true"'



# Generated at 2022-06-24 08:21:05.852004
# Unit test for function utf8
def test_utf8():
    s = 'ä'
    if isinstance(s, unicode_type):
        return utf8(s)
    else:
        return s



# Generated at 2022-06-24 08:21:17.203508
# Unit test for function parse_qs_bytes

# Generated at 2022-06-24 08:21:21.756917
# Unit test for function utf8
def test_utf8():
    try:
        assert utf8(None) == None
        assert utf8("test") == b"test"
        assert utf8(b"test") == b"test"
        assert utf8(u"test") == b"test"
    except BaseException as e:
        print(e)



# Generated at 2022-06-24 08:21:23.771022
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('a b c') == 'a+b+c'
    assert url_escape('a b c', plus=False) == 'a%20b%20c'



# Generated at 2022-06-24 08:21:27.723797
# Unit test for function url_escape
def test_url_escape():
    x=url_escape("http://www.google.com",False)
    assert x=='http%3A//www.google.com'
    print("test_url_escape(): passed")



# Generated at 2022-06-24 08:21:29.529655
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    res = xhtml_unescape('&quot;&#39;&lt;&gt;&amp;')
    assert(res == '"\'<>&')


# Generated at 2022-06-24 08:21:39.762092
# Unit test for function linkify
def test_linkify():
    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    text = linkify(
        text="Hello <b>http://tornadoweb.org</b>!", 
        shorten=True, 
        extra_params='rel="nofollow" class="external"',
        require_protocol=False,
        permitted_protocols=["http", "https"],
        )
    print(text)

# Generated at 2022-06-24 08:21:43.102862
# Unit test for function native_str
def test_native_str():
    assert native_str is str
    assert native_str('abc') == 'abc'
    assert isinstance(native_str('abc'), str)



# Generated at 2022-06-24 08:21:49.646509
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{}') == {}
    assert json_decode('[]') == []
    assert json_decode('"a"') == 'a'
    assert json_decode('{"a": "b"}') == {'a': 'b'}
# END Unit test for function json_decode


# to_unicode is deprecated.  Please use tornado.util.u (unicode on py2,
# str on py3) instead.

# Generated at 2022-06-24 08:22:01.931763
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('/path/to?a=1&b=2', plus=True) == '%2Fpath%2Fto%3Fa%3D1%2Bb%3D2'
    s = '你好，世界'
    assert url_escape(utf8(s), plus=True) == '%E4%BD%A0%E5%A5%BD%EF%BC%8C%E4%B8%96%E7%95%8C'
    assert url_escape(utf8(s), plus=False) == '%E4%BD%A0%E5%A5%BD%EF%BC%8C%E4%B8%96%E7%95%8C'
test_url_escape()


# Generated at 2022-06-24 08:22:04.537526
# Unit test for function url_escape
def test_url_escape():
    print(url_escape("http://event:8081/events?type=goods&id=2"))



# Generated at 2022-06-24 08:22:09.514289
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"a":"1"}') == {"a":"1"}
    assert json_decode(b'{"a":"1"}') == {"a":"1"}


_BASESTRING_TYPES = (str, bytes)
_UNICODE_TYPES = (str)



# Generated at 2022-06-24 08:22:13.022230
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": [1, 2, 3], "b": 4, "c": "d"}) == '{"a": [1, 2, 3], "b": 4, "c": "d"}'



# Generated at 2022-06-24 08:22:22.892686
# Unit test for function native_str
def test_native_str():
    str_list = ['hello',
                '世界',
                '你好',
                'こんにちは',
                '안녕하세요']

    for s in str_list:
        assert to_unicode(s) == s
        assert to_basestring(s) == s

    bytes_list = [b'hello',
                  bytes(u'世界'.encode('utf-8')),
                  bytes(u'你好'.encode('utf-8')),
                  bytes(u'こんにちは'.encode('utf-8')),
                  bytes(u'안녕하세요'.encode('utf-8'))]

    for s in bytes_list:
        assert ut

# Generated at 2022-06-24 08:22:32.826154
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert(xhtml_unescape("&amp;") == "&")
    assert(xhtml_unescape("&#123;") == "{}".format(chr(123)))
    assert(xhtml_unescape("&quot;") == "\"")
    assert(xhtml_unescape("&gt;") == ">")
    assert(xhtml_unescape("&lt;") == "<")
    assert(xhtml_unescape("&#39;") == "'")
    assert(xhtml_unescape("&#x3f;") == "?")
    assert(xhtml_unescape("&apos;") == "'")
    assert(xhtml_unescape("&copy;") == "©")
test_xhtml_unescape()


# TODO: move this to a _convert_entity function.


# Generated at 2022-06-24 08:22:43.732167
# Unit test for function recursive_unicode
def test_recursive_unicode():
    nested = {'a': [1, 'text', {'a':b'text'},[b'text']],
              'b': [b'text']}
    nested_ans = {'a': [1, 'text', {'a': 'text'}, ['text']],
                  'b': ['text']}
    assert recursive_unicode(nested) == nested_ans


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to literal
# latin1 strings.  Once we drop support for 2.5, we can remove this

# Generated at 2022-06-24 08:22:54.116043
# Unit test for function linkify
def test_linkify():
    assert linkify(u'http://example.com') == u'<a href="http://example.com">http://example.com</a>'
    assert linkify(u'http://example.com:8080') == u'<a href="http://example.com:8080">http://example.com:8080</a>'
    assert linkify(u'mailto:user@domain.com') == u'<a href="mailto:user@domain.com">user@domain.com</a>'
    assert linkify(u'www.google.com') == u'<a href="http://www.google.com">www.google.com</a>'
    assert linkify(u'http://localhost:5000') == u'<a href="http://localhost:5000">http://localhost:5000</a>'

# Generated at 2022-06-24 08:22:56.620517
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&<>"\'') == '&amp;&lt;&gt;&quot;&#39;'


# Generated at 2022-06-24 08:23:00.407148
# Unit test for function url_unescape
def test_url_unescape():
    value = ''
    encoding = ''
    plus = True
    assert url_unescape(value, encoding, plus)



# Generated at 2022-06-24 08:23:07.064500
# Unit test for function utf8
def test_utf8():
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(None) is None
    try:
        utf8(1)
        self.fail("Expected TypeError, but got none")
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:23:10.289433
# Unit test for function json_encode
def test_json_encode():
    print(json_encode({"a":1}))
    print(json_encode("</script>"))

# json_decode is just json.loads with a bit of extra error handling.


# Generated at 2022-06-24 08:23:17.123995
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert '&amp;' == xhtml_escape('&')

_JSON_ESCAPE_RE = re.compile(r"[<>&]")
_JSON_ESCAPE_DICT = {
    "<": r"\\u003C",
    ">": r"\\u003E",
    "&": r"\\u0026",
}



# Generated at 2022-06-24 08:23:26.898626
# Unit test for function squeeze
def test_squeeze():
    #return re.sub(r"[\x00-\x20]+", " ", value).strip()
    value = "   a   b   c   d    e    f    g    h      i      j     "
    print(value)
    value = re.sub(r"[\x00-\x20]+", " ", value).strip()
    print(value)


_UTF8_TYPES = (bytes, type(None))
_TO_UNICODE_TYPES = (unicode_type, type(None))

# if sys.version_info >= (3, 0):
#    _UTF8_TYPES = (bytes, type(None))
#    _TO_UNICODE_TYPES = (str, type(None))
# else:
#    _UTF8_TYPES = (str,

# Generated at 2022-06-24 08:23:31.888420
# Unit test for function recursive_unicode
def test_recursive_unicode():
    from tests.util import assert_equal
    assert_equal(recursive_unicode({"a": [1, 2, 3], "b": "x", "d": b"y"}),
                 {"a": [1, 2, 3], "b": "x", "d": "y"})
    assert_equal(recursive_unicode(["a", b"b"]), ["a", "b"])
    assert_equal(recursive_unicode(("a", b"b")), ("a", "b"))
    assert_equal(recursive_unicode(b"a"), "a")



# Generated at 2022-06-24 08:23:38.665965
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&copy;") == "©"
    assert xhtml_unescape("&#x26;") == "&"
    assert xhtml_unescape("&#38;") == "&"
    assert xhtml_unescape("&#00038;") == "&"
    assert xhtml_unescape("&blah;") == "&blah;"

_BASESTRING_TYPES = (str, bytes)



# Generated at 2022-06-24 08:23:45.144029
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_dict = {
        "a": ["b"],
        "c": ["d", "e"],
        "f": ["g", "h", "i"],
    }
    qs = b"a=b&c=d&c=e&f=g&f=h&f=i"
    assert parse_qs_bytes(qs) == test_dict
    assert parse_qs_bytes(qs.decode("ascii")) == test_dict
    assert parse_qs_bytes(qs, keep_blank_values=True) == test_dict



# Generated at 2022-06-24 08:23:52.794442
# Unit test for function json_decode
def test_json_decode():
    print('=============function json_decode===========')
    dict_data = json_decode('{"name":"Bing","age":20,"job":"Python"}')
    print(dict_data)
    print(dict_data['name'])
    print(dict_data['age'])
    print(dict_data['job'])
    print(type(dict_data))

test_json_decode()


# base_escape and base_unescape need to take an explicit encoding
# argument, rather than use 'utf-8' (the default for urllib.quote and
# urllib.unquote) because they are invoked as part of the construction
# of the get() and post() functions in httpclient, which need to be
# able to use other encodings in certain cases (mostly for tests)


# Generated at 2022-06-24 08:23:58.921246
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    d = parse_qs_bytes('Goods=1&Goods=2')
    assert d == {'Goods': [b'1', b'2']}
    assert d['Goods'][0] == b'1'

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:24:10.429941
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(['a', 'b']) == ['a', 'b']
    assert recursive_unicode((1, 2)) == (1, 2)
    assert recursive_unicode({'k1':'v1', 'k2':'v2'}) == {'k1':'v1', 'k2':'v2'}
    assert recursive_unicode({'k1':'v1', 'k2':'v2', b'k3': b'v3'}) == {
        'k1':'v1', 'k2':'v2', 'k3':'v3'
    }

# Generated at 2022-06-24 08:24:13.313793
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"



# Generated at 2022-06-24 08:24:20.355275
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({}) == '{}'
    assert json_encode([]) == '[]'
    assert json_encode("abc") == '"abc"'
    assert json_encode(dict(a="b", c="d")) == '{"a": "b", "c": "d"}'
    assert json_encode(dict(a=[1,2,3])) == '{"a": [1, 2, 3]}'



# Generated at 2022-06-24 08:24:28.473987
# Unit test for function native_str
def test_native_str():
    uni_value = '\u00E1'
    assert native_str(uni_value) == 'á'
    uni_value = '\u00E1\u20AC'
    assert native_str(uni_value) == 'á€'
    uni_value = '\u20AC\u20AC\u20AC\u20AC'
    assert native_str(uni_value) == '€€€€'
    uni_value = '\u20AC\u20AC\u20AC\u20AC'
    assert native_str(uni_value) == '€€€€'
    uni_value = '\u20AC\u20AC\u20AC\u20AC\u20AC'
    assert native_str(uni_value) == '€€€€€'
    un

# Generated at 2022-06-24 08:24:30.909214
# Unit test for function url_unescape
def test_url_unescape():
    assert(url_unescape("http://localhost:8080/1.html") == "http://localhost:8080/1.html")
test_url_unescape()



# Generated at 2022-06-24 08:24:39.336011
# Unit test for function linkify

# Generated at 2022-06-24 08:24:49.756428
# Unit test for function linkify
def test_linkify():
    assert linkify('hello http://example.com') == 'hello <a href="http://example.com">http://example.com</a>'
    assert linkify('hello http://example.com',extra_params='class="test"') == 'hello <a class="test" href="http://example.com">http://example.com</a>'
    assert linkify('hello www.example.com',require_protocol=False) == 'hello <a href="http://www.example.com">www.example.com</a>'
    assert linkify('hello www.example.com',require_protocol=True) == 'hello www.example.com'

# Generated at 2022-06-24 08:24:57.036828
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(
        {"text": "abc", "number": 1, "tuple": (1,2), "subdict": {"subtext": "sub"}}
    ) == {
        "text": "abc",
        "number": 1,
        "tuple": (1,2),
        "subdict": {"subtext": "sub"}
    }
    assert recursive_unicode("") == ""
    assert recursive_unicode("def") == "def"
test_recursive_unicode()



# Generated at 2022-06-24 08:25:05.640336
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/path/to/file.html?foo=bar&baz=quux#frag") == '<a href="http://example.com/path/to/file.html?foo=bar&baz=quux#frag">http://example.com/path/to/file.html?foo=bar&baz=quux#frag</a>'
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'


# Generated at 2022-06-24 08:25:09.071958
# Unit test for function xhtml_escape
def test_xhtml_escape():
    test_str = "hel'lo"
    result = xhtml_escape(test_str)
    assert result == "hel&#39;lo"


# Generated at 2022-06-24 08:25:20.173455
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # type: () -> None
    assert recursive_unicode({"foo": u"bar"}) == {"foo": u"bar"}
    assert recursive_unicode({"foo": "bar"}) == {"foo": u"bar"}
    assert recursive_unicode([u"foo", "bar"]) == [u"foo", u"bar"]
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode((u"foo", "bar")) == (u"foo", u"bar")
    assert recursive_unicode((1, 2)) == (1, 2)
    assert recursive_unicode("foo") == u"foo"
    assert recursive_unicode(u"foo") == u"foo"
    assert recursive_unicode(1) == 1


# Generated at 2022-06-24 08:25:22.093870
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{\"a\": \"b\"}") == {"a": "b"}



# Generated at 2022-06-24 08:25:29.162848
# Unit test for function native_str
def test_native_str():
    try:
        assert astr('x', encoding='ascii').__class__ == str
        assert astr('x', encoding='ascii').__class__ != bytes
    except SyntaxError:
        assert bytes('x', encoding='ascii').__class__ == str
        assert unicode('x', encoding='ascii').__class__ == str


# Generated at 2022-06-24 08:25:31.460410
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    aa = "a=b&c=d"
    print(parse_qs_bytes(aa))

test_parse_qs_bytes()



# Generated at 2022-06-24 08:25:44.714605
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('http://www.baidu.com/%E5%8C%97%E4%BA%AC') == 'http://www.baidu.com/北京'
    assert url_unescape('http://www.baidu.com/%E5%8C%97%E4%BA%AC', encoding='utf-8') == 'http://www.baidu.com/北京'
    assert url_unescape('http://www.baidu.com/北京') == 'http://www.baidu.com/北京'

# Generated at 2022-06-24 08:25:48.955472
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"

_JSON_ESCAPE = {
    ord("&"): "\\u0026",
    ord("<"): "\\u003c",
    ord(">"): "\\u003e",
    # In json-encoded strings, U+2028 and U+2029 characters count as
    # line endings and must be encoded.
    ord("\u2028"): "\\u2028",
    ord("\u2029"): "\\u2029",
}


_RECURSION_LIMIT = 500



# Generated at 2022-06-24 08:25:56.738167
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'%E4%B8%AD%E6%96%87') == '中文', '中文'
    assert url_unescape(b'%D0%A1%D1%83%D0%B1%D0%B8%D0%BB%D0%B8%D1%8F') == 'Субилия', 'Субилия'
    #assert url_unescape('%7E') == '~', '~'
    assert url_unescape('%7E', 'us-ascii') == '~', '~'
    #assert url_unescape('http%3A%2F%2Fgoogle.com%2F') == 'http://google.com/', 'http://google.com/'

# Generated at 2022-06-24 08:26:04.897848
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('abc') == "abc"
    assert url_unescape('abc%3Fdef') == "abc?def"
    assert url_unescape('a+b+c') == "a+b+c"
    assert url_unescape(b'abc', plus=False) == "abc"
    assert url_unescape(b'abc%3Fdef', plus=False) == "abc?def"
    assert url_unescape(b'a+b+c', plus=False) == "a b c"
    assert url_unescape(b'abc', encoding=None) == b"abc"
    assert url_unescape(b'abc%3Fdef', encoding=None) == b"abc?def"

# Generated at 2022-06-24 08:26:10.787934
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode("test") == "test"
    assert recursive_unicode("test".encode("utf-8")) == "test"
    assert recursive_unicode(1) == 1
    assert recursive_unicode([1, "test", "test".encode("utf-8")]) == [1, "test", "test"]
    assert recursive_unicode((1, "test", "test".encode("utf-8"))) == (1, "test", "test")
    return "recursive_unicode test success"
print(test_recursive_unicode())
print("/n")


# Generated at 2022-06-24 08:26:16.517721
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b"<script>") == "&lt;script&gt;"
    assert xhtml_escape("hello < there") == "hello &lt; there"
    assert xhtml_escape(u"'") == "&#39;"

_JSON_DECODE_ERROR = (ValueError, TypeError)



# Generated at 2022-06-24 08:26:18.896266
# Unit test for function native_str
def test_native_str():
    assert native_str(1) == "1"
    assert native_str(None) is None


# Generated at 2022-06-24 08:26:23.927384
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div>") == "&lt;div&gt;"
    assert xhtml_escape("&lt;div&gt;") == "&amp;lt;div&amp;gt;"
    assert xhtml_escape("""'"&<>""") == "&#39;&quot;&amp;&lt;&gt;"



# Generated at 2022-06-24 08:26:26.754423
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<script>") == "&lt;script&gt;"


_URL_ESCAPE_RE = re.compile(r"[^a-zA-Z0-9_.*-]")



# Generated at 2022-06-24 08:26:29.146659
# Unit test for function native_str
def test_native_str():
    assert type(native_str("")) is str
    assert type(native_str("hello")) is str
    assert type(native_str(u"hi")) is str
    assert type(native_str(u"")) is str

# Generated at 2022-06-24 08:26:36.914683
# Unit test for function recursive_unicode
def test_recursive_unicode():
    from tornado.escape import recursive_unicode
    def _test(obj):
        for i in obj:
            if isinstance(i, dict):
                _test(i.values())
            elif isinstance(i, list):
                _test(i)
            else:
                assert isinstance(i, unicode_type)
    test_list_a = [b'a', b'b', b'c', [b'd', b'e'], {b'f': b'g', b'h': b'i'}]
    test_list_b = [b'a', b'b', b'c', [b'd', b'e'], {b'f': b'g', b'h': b'i', b'j': [b'k', b'l']}]

# Generated at 2022-06-24 08:26:41.310131
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": "abc"}) == {"a": "abc"}
    assert recursive_unicode([1, 2, 3]) == [1, 2, 3]
    assert recursive_unicode((1, 2, 3)) == (1, 2, 3)



# Generated at 2022-06-24 08:26:49.392309
# Unit test for function json_encode
def test_json_encode():
    assert (json_encode(None) == "null")
    assert (json_encode(True) == "true")
    assert (json_encode(False) == "false")
    assert (json_encode(1) == "1")
    assert (json_encode(1234) == "1234")
    assert (json_encode(1.1) == "1.1")
    assert (json_encode(123.4) == "123.4")
    assert (json_encode(1.1e-6) == "1.1e-06")
    assert (json_encode([]) == "[]")

# Generated at 2022-06-24 08:27:01.189179
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze("A  B  C  D") == "A B C D")
    assert(squeeze("  A B  C D  ") == "A B C D")
    assert(squeeze("a b\tc d\nef  g") == "a b c d ef g")

#-----------------------------------------------------------------------------

# Configuration for linkify is based on the linkify function of
# Django (http://www.djangoproject.com/).
#
# Copyright (c) Django Software Foundation and individual contributors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#    1. Redistributions of source code must retain the above copyright notice,
#       this list of conditions and the following disclaimer.


# Generated at 2022-06-24 08:27:13.957368
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_escape("<" ) == "&lt;"
    assert xhtml_escape(">" ) == "&gt;"
    assert xhtml_escape('"' ) == "&quot;"
    assert xhtml_escape("'" ) == "&#39;"
test_xhtml_escape()

_XHTML_UNESCAPE_RE = re.compile(r"&(#?)(\d+|\w+);")

# From http://codereview.stackexchange.com/questions/102659/
#        html-escape-string-in-python-without-using-regex
_HTML_ESCAPE_BASE_CHARS: bytes = bytearray(range(32))
_HTML_ESCAPE_BASE

# Generated at 2022-06-24 08:27:18.217620
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"
    assert xhtml_escape("<foo & bar>") == "&lt;foo &amp; bar&gt;"
    assert xhtml_escape("<foo &amp; bar>") == "&lt;foo &amp;amp; bar&gt;"



# Generated at 2022-06-24 08:27:30.014632
# Unit test for function native_str
def test_native_str():
    '''
    to_basestring is one version of native_str, which is deprecated in python3.
    to_basestring is removed in python3.8, so we need to use native_str.
    '''
    assert(native_str("hello") == 'hello')
    assert(native_str(b"hello") == b'hello')
    assert(native_str("你好") == '你好')
    assert(native_str(b"\xe4\xbd\xa0\xe5\xa5\xbd") == b'\xe4\xbd\xa0\xe5\xa5\xbd')
    assert(native_str("abc\xff") == 'abc\xff')
    assert(native_str(b"abc\xff") == b'abc\xff')

# Generated at 2022-06-24 08:27:40.524039
# Unit test for function native_str
def test_native_str():
    s = '\xff'
    u = s.encode('latin1').decode('utf8')
    assert s == native_str(s)
    assert u == native_str(u)
    assert '\xff' == native_str(b'\xff')
    assert '\x80' == native_str(b'\xc2\x80')
    assert '\ud800' == native_str(b'\xed\xa0\x80')
    assert '\udfff' == native_str(b'\xed\xbf\xbf')
    assert '\udc00' == native_str(b'\xed\xb0\x80')
    assert '\uffff' == native_str(b'\xef\xbf\xbf')
    assert '\U00010000' == native