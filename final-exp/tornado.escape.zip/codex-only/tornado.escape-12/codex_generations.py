

# Generated at 2022-06-24 08:17:36.252518
# Unit test for function json_decode
def test_json_decode():
    global json_decode
    global json_encode
    assert json_decode(json_encode([1, 2, "ab"])) == [1, 2, "ab"]
    assert json_decode(json_encode({"a": 123, "b": {"x": "y"}})) == {"a": 123, "b": {"x": "y"}}
test_json_decode()



# Generated at 2022-06-24 08:17:41.220659
# Unit test for function url_unescape
def test_url_unescape():
    print(url_unescape(b'https://www.baidu.com'))
    print(url_unescape(b'https://www.baidu.com',None))



# Generated at 2022-06-24 08:17:43.497807
# Unit test for function xhtml_escape
def test_xhtml_escape():
  assert xhtml_escape("<a>&</a>") == "&lt;a>&amp;&lt;/a>"




# Generated at 2022-06-24 08:17:53.393129
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():

    # Test case when encoding is None
    string = parse_qs_bytes("a=1&b=2", encoding=None)
    assert {b'a': [b'1'], b'b': [b'2']} == string

    # Test case when encoding is valid
    string = parse_qs_bytes("a=1&b=2", encoding='utf-8')
    assert {b'a': [b'1'], b'b': [b'2']} == string

    # Test case when encoding is invalid
    try:
        parse_qs_bytes("a=1&b=2", encoding='error')
        assert False
    except UnicodeDecodeError:
        assert True

# Generated at 2022-06-24 08:17:57.280229
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<foo>") == "&lt;foo&gt;"
    assert xhtml_escape("abc ' \" &") == "abc &#39; &quot; &amp;"
    assert xhtml_escape(""">'""") == "&quot;&gt;&#39;&quot;"



# Generated at 2022-06-24 08:18:10.699123
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a%2b+") == "a+ "
    assert url_unescape(b"a+", plus=False) == "a+"
    assert url_unescape(b"a+", encoding="latin1") == "a+"
    assert url_unescape(b"a+", encoding="latin1", plus=False) == "a+"
    assert url_unescape(b"a%2b+", encoding="utf-8") == "a+ "
    assert url_unescape(b"a%2B+", encoding="utf-8") == "a+ "
    assert url_unescape(b"a%2B+", encoding="utf-8", plus=False) == "a%2B "

# Generated at 2022-06-24 08:18:16.543046
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(u"foo") == u"foo"
    assert recursive_unicode(b"foo") == u"foo"
    assert recursive_unicode([b"foo", b"bar"]) == [u"foo", u"bar"]
    assert recursive_unicode((b"foo", b"bar")) == (u"foo", u"bar")
    assert recursive_unicode({b"foo": b"bar"}) == {u"foo": u"bar"}


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though, so we need a function wrapper
# to convert our string literals.  b() should only be applied to

# Generated at 2022-06-24 08:18:26.676768
# Unit test for function recursive_unicode
def test_recursive_unicode():
    def check(obj):
        print("obj:=",obj)
        # str & bytes
        if isinstance(obj, str):
            assert isinstance(recursive_unicode(obj), str)
        elif isinstance(obj, bytes):
            assert isinstance(recursive_unicode(obj), str)
        # tuple & list & dict
        elif isinstance(obj, (tuple,list,dict)):
            assert recursive_unicode(obj) == obj
        # other type
        else:
            assert recursive_unicode(obj) == obj
    # single value
    check("d")
    check(b"d")
    check(None)
    check("")
    # tuple
    check((1,2,"d",b"d"))
    check(())
    # list

# Generated at 2022-06-24 08:18:31.139130
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&apos;') == "'"
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&#x27;') == "'"

# Generated at 2022-06-24 08:18:42.132716
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    from urllib.parse import parse_qs

# Generated at 2022-06-24 08:18:50.232970
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    d1 = parse_qs_bytes(b"a=1&b=foo&c=%E4%BD%A0")
    d2 = parse_qs_bytes(u"a=1&b=foo&c=%E4%BD%A0".encode("utf8"))
    try:
        # this works in python2.7 but not in python3
        next(k for k, v in d1.items() if v[0] != d2[k][0])
    except StopIteration:
        pass
    else:
        assert False, "parse_qs_bytes returned different values for utf8 and latin1 input"


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:19:01.781959
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"


_JSON_ESCAPE_RE = re.compile(r'[\x00-\x1f\\"]')

# Generated at 2022-06-24 08:19:09.131918
# Unit test for function utf8
def test_utf8():
    import unittest
    from tornado.util import utf8
    from tornado.testing import AsyncTestCase

    class Utf8TestCase(AsyncTestCase):
        def test_utf8(self):
            if isinstance(u"\xe9", bytes):
                # python 2
                self.assertEqual(utf8(u"\xe9"), "\xc3\xa9")
            else:
                # python 3
                self.assertEqual(utf8(u"\xe9"), b"\xc3\xa9")

    Utf8TestCase().test_utf8()



# Generated at 2022-06-24 08:19:11.783385
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape("&#160;"))
    
test_xhtml_unescape()


# Generated at 2022-06-24 08:19:17.073498
# Unit test for function utf8
def test_utf8():
    assert utf8(b'hello') == b'hello'
    assert utf8('hello') == b'hello'
    assert utf8(None) == None
    try:
        utf8(2)
    except TypeError:
        pass
    else:
        raise


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:22.820874
# Unit test for function json_decode
def test_json_decode():
    s = json_decode("{'a':123,'b': [1,2,3]}")
    print(s['a'])
    print(s['b'])

_UTF8_TYPES = (bytes, type(None))

if typing.TYPE_CHECKING:
    _UTF8_TYPES = _UTF8_TYPES + (str,)


# Generated at 2022-06-24 08:19:26.053784
# Unit test for function url_escape
def test_url_escape():
    url_escape.__annotations__.get('value')
    url_escape.__annotations__.get('plus')



# Generated at 2022-06-24 08:19:35.900546
# Unit test for function url_unescape

# Generated at 2022-06-24 08:19:39.814060
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("1<23>456'7890&") == "1&lt;23&gt;456&#39;7890&amp;"
test_xhtml_escape()



# Generated at 2022-06-24 08:19:46.015262
# Unit test for function recursive_unicode
def test_recursive_unicode():
    l = [1, 2, 3]
    d = {"1": 1, "2": l}
    l.append(d)
    l2 = recursive_unicode(l)
    assert isinstance(l2[0], str)
    assert isinstance(d["1"], str)
    assert isinstance(d["2"], list)
    assert isinstance(d["2"][2]["1"], str)
    assert isinstance(d["2"][2]["2"], list)



# Generated at 2022-06-24 08:19:50.591807
# Unit test for function native_str
def test_native_str():
    assert native_str('hello'.encode('utf8')) == 'hello'
    assert native_str(None) is None
    assert native_str(u'hello') == 'hello'

_BASESTRING_TYPES = (str, type(None))



# Generated at 2022-06-24 08:19:52.539422
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("    \n \n\n\n\t\tqw   \t\n \r  e  r   \r\r\rty\r\t") == "qw e rty"



# Generated at 2022-06-24 08:19:54.312269
# Unit test for function native_str
def test_native_str():
    print("native_str('a') = {}".format(native_str('a')))
    print("native_str(b'a') = {}".format(native_str(b'a')))



# Generated at 2022-06-24 08:20:03.178362
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"
    assert xhtml_escape("&lt;") == "&amp;lt;"

_URL_SAFE = r"[^A-Za-z0-9/:=\-_#\?\&]"
_ESCAPE_RE = re.compile(r"%s|%s" % (_URL_SAFE, html.entities.entitydefs))
_UTF8_RE = re.compile(r"[\x80-\xff]")



# Generated at 2022-06-24 08:20:12.253694
# Unit test for function url_unescape
def test_url_unescape():
    a = b'http://tornado.readthedocs.io/en/latest/security.html#unicode-urls'
    print(url_unescape(a))
    b = 'http://tornado.readthedocs.io/en/latest/security.html#unicode-urls'
    print(url_unescape(b))
    c = b'http://tornado.readthedocs.io/en/latest/security.html%23unicode-urls'
    print(url_unescape(c))
    c = b'http://tornado.readthedocs.io/en/latest/security.html%23unicode-urls'
    print(url_unescape(c, encoding='utf-8'))

# Generated at 2022-06-24 08:20:16.201285
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b"<") == "&lt;"
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape(None) == "None"


# Generated at 2022-06-24 08:20:20.393753
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("test\ntext") == "test text"
    assert squeeze("test \n \t \r text") == "test text"
    assert squeeze("test text") == "test text"


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:20:22.613998
# Unit test for function native_str
def test_native_str():
    assert 1 == 1, "Test that 1 == 1"
    assert 1 == 2, "Test that 1 == 2"

# Generated at 2022-06-24 08:20:28.769307
# Unit test for function json_encode
def test_json_encode():
    x = json_encode({"a": 1, "c": [1, 2, 3], "b": "hello world"})
    print(x)
#test_json_encode()



# Generated at 2022-06-24 08:20:31.504711
# Unit test for function squeeze
def test_squeeze():
    result = squeeze('    I    am    a    sentence.')
    assert result == 'I am a sentence.'
    result = squeeze('I     \tam        a\nsentence.')
    assert result == 'I am a sentence.'



# Generated at 2022-06-24 08:20:32.340782
# Unit test for function native_str
def test_native_str():
    pass


# Generated at 2022-06-24 08:20:42.076312
# Unit test for function linkify
def test_linkify():
    assert linkify("http://foo.com/") == '<a href="http://foo.com/">http://foo.com/</a>'
    assert linkify("https://foo.com/") == '<a href="https://foo.com/">https://foo.com/</a>'
    assert linkify("foo@foo.com") == '<a href="mailto:foo@foo.com">foo@foo.com</a>'
    assert linkify("www.foo.com") == '<a href="http://www.foo.com">www.foo.com</a>'
    assert linkify("http://user:pass@foo.com") == '<a href="http://user:pass@foo.com">http://user:pass@foo.com</a>'

# Generated at 2022-06-24 08:20:44.168893
# Unit test for function url_unescape
def test_url_unescape():
    assert (url_unescape("hello%2Bworld", encoding='ascii') == "hello world")



# Generated at 2022-06-24 08:20:53.985358
# Unit test for function xhtml_escape
def test_xhtml_escape():
    xhtml_escape(__name__)
    xhtml_escape('a')
    xhtml_escape(b'a')
    xhtml_escape(u'a')


_JSON_ESCAPE_RE = re.compile(r"[&<>\"\'\x00-\x1f]")
_JSON_ESCAPE_DICT = {
    u"&": u"\\u0026",
    u"<": u"\\u003c",
    u">": u"\\u003e",
    u'"': u'\\u0022',
    u"'": u"\\u0027",
    u"\u0000": u"\\u0000",
}

# Generated at 2022-06-24 08:20:55.757710
# Unit test for function url_escape
def test_url_escape():
    assert (url_escape("http://localhost:8000/abc") == "http%3A//localhost%3A8000/abc")


# Generated at 2022-06-24 08:20:58.805816
# Unit test for function url_escape
def test_url_escape():
    s="url"
    s1=url_escape(s)
    print(s1)
# test_url_escape()


# Generated at 2022-06-24 08:21:08.425525
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=bar') == {'foo': [b'bar']}
    assert parse_qs_bytes(b'foo=bar&foo=baz') == {'foo': [b'bar', b'baz']}
    # with non-ascii keys/values
    assert parse_qs_bytes(b'foo=bar&x=\xff') == {'foo': [b'bar'], 'x': [b'\xff']}
    assert parse_qs_bytes(b'x=\xff=a') == {'x': [b'\xff=a']}
    assert parse_qs_bytes(b'x=a&x=\xff') == {'x': [b'a', b'\xff']}
    # blank values

# Generated at 2022-06-24 08:21:12.020246
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('a b') == 'a+b'
    assert url_escape('a b', plus=False) == 'a%20b'

### Testing
import pytest


# Generated at 2022-06-24 08:21:16.130257
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{}')   is {}
    assert json_decode('[1]')  is [1]
    assert json_decode('null') is None
    # test string
    assert json_decode('"foobar"') == "foobar"



# Generated at 2022-06-24 08:21:23.398674
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8('') == b''
    assert utf8('foo') == b'foo'
    assert utf8('\xe2\x98\x83') == b'\xe2\x98\x83'
    assert utf8(b'foo') == b'foo'
    assert utf8(b'\xe2\x98\x83') == b'\xe2\x98\x83'
    try:
        utf8(object())
        assert False, "expected TypeError"
    except TypeError:
        pass



# Generated at 2022-06-24 08:21:35.360574
# Unit test for function native_str
def test_native_str():
    # 将bytes 转换成 str
    print(native_str(b'foo'))
    print(native_str('foo'))
    print(native_str(b'\x80\x81\x82'))
    print(native_str('\x80\x81\x82'))
    # 将bytes 转换成 str, 指定编码
    print(native_str(b'\x80\x81\x82', 'latin1'))
    print(native_str('\x80\x81\x82', 'latin1'))
    print(native_str(b'foo', 'latin1'))
    print(native_str('foo', 'latin1'))

# Generated at 2022-06-24 08:21:42.855297
# Unit test for function utf8
def test_utf8():
    assert utf8('abc') == b'abc'
    assert utf8(b'abc') == b'abc'
    assert utf8(None) == None
    assert utf8(u'abc') == b'abc'
    
    try:
        utf8(3)
        assert False
    except TypeError as e:
        assert str(e) == "Expected bytes, unicode, or None; got <class 'int'>"
      



# Generated at 2022-06-24 08:21:46.423911
# Unit test for function json_decode
def test_json_decode():
    # For input of type str
    assert json_decode("{}") == {}
    # For input of type bytes
    assert json_decode(b"{}") == {}


# Generated at 2022-06-24 08:21:56.688976
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{ "foo": [ 1, 2, 3, {"a": "b"} ] }') == {
        "foo": [1, 2, 3, {"a": "b"}]
    }


# constants from http://www.iana.org/assignments/character-sets
CS_ISO_8859_1 = "ISO-8859-1"
CS_ISO_8859_2 = "ISO-8859-2"
CS_ISO_8859_3 = "ISO-8859-3"
CS_ISO_8859_4 = "ISO-8859-4"
CS_ISO_8859_5 = "ISO-8859-5"
CS_ISO_8859_6 = "ISO-8859-6"
CS_ISO_8859_7 = "ISO-8859-7"
CS

# Generated at 2022-06-24 08:22:00.772033
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    d = parse_qs_bytes(b'foo=bar&baz=sdfs')
    assert d['foo'][0] == b'bar'
    assert d['baz'][0] == b'sdfs'


# Generated at 2022-06-24 08:22:02.489169
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;&gt;&lt;&quot;&#39;') == '&><"\''

_BASESTRING_TYPES = type(b"")


# Generated at 2022-06-24 08:22:12.730315
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{}') == {}
    assert json_decode('[]') == []
    assert json_decode('"foo"') == "foo"
    assert json_decode('{"foo": "bar"}') == {"foo": "bar"}
    assert json_decode(b'{"foo": "bar"}') == {"foo": "bar"}
    assert json_decode('["foo", {"bar": ["baz", null, 1.0, 2]}]') == [
        "foo",
        {"bar": ["baz", None, 1.0, 2]},
    ]


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:22:13.382979
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("") == {}

# Generated at 2022-06-24 08:22:23.390605
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape("%7B%22v%22:%221.0%22%2C%22status%22:1%2C%22msg%22:%22%22%2C%22data%22:%7B%22title%22:%22%E8%BD%A6%E5%8A%A0%22%2C%22content%22:%22%E5%8F%91%E5%B8%83%E6%8B%9B%E8%BD%A6%22%2C%22create_time%22:%222016-11-30%2016:00:00%22%7D%7D", "utf-8")

# Generated at 2022-06-24 08:22:33.211490
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("x") == "x"
    assert url_escape(" ") == "%20"
    assert url_escape("/") == "%2F"
    assert url_escape("+") == "%2B"
    assert url_escape("-") == "-"
    assert url_escape("&") == "%26"
    assert url_escape("?") == "%3F"
    assert url_escape("=") == "%3D"
    assert url_escape("%") == "%25"
    assert url_escape("a b") == "a+b"
    assert url_escape("a b", plus=False) == "a%20b"
    assert url_escape("\xff") == "%FF"
    assert url_escape("\u0100") == "%C4%80"

# Generated at 2022-06-24 08:22:44.456413
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2") == {b"a": [b"1"], b"b": [b"2"]}
    assert parse_qs_bytes(b"a=1&b=2", keep_blank_values=True) == {b"a": [b"1"], b"b": [b"2"]}
    assert parse_qs_bytes(b"a=&b=2") == {b"a": [b""], b"b": [b"2"]}
    assert parse_qs_bytes(b"a=&b=2", keep_blank_values=True) == {b"a": [b""], b"b": [b"2"]}

# Generated at 2022-06-24 08:22:51.896245
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8("föo") == b"f\xc3\xb6o"
    assert utf8("föö") == b"f\xc3\xb6\xc3\xb6"
    assert utf8("föö") != b"f\xf6\xf6"
    assert utf8(u"föö") == b"f\xc3\xb6\xc3\xb6"
    assert utf8(u"föö") != b"f\xf6\xf6"



# Generated at 2022-06-24 08:22:53.761175
# Unit test for function json_decode
def test_json_decode():
    a = "{'key1':1,'key2':'spam'}"
    print(json_decode(a))


# Generated at 2022-06-24 08:23:01.233546
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"hello") == "hello"
    assert url_unescape(u"hello") == "hello"
    assert url_unescape(u"hello", "latin1") == "hello"
    assert url_unescape(b"hello%20world") == "hello world"
    assert url_unescape(u"hello%20world") == "hello world"
    assert url_unescape(b"%2B") == "+"
    assert url_unescape(u"%2B") == "+"
    assert url_unescape(b"%2B", plus=False) == "%2B"
    assert url_unescape(u"%2B", plus=False) == "%2B"



# Generated at 2022-06-24 08:23:07.783596
# Unit test for function utf8
def test_utf8():
    assert utf8("Hello") == b"Hello"
    assert utf8(b"Hello") == b"Hello"
    # assert utf8(None) is None
    # assert utf8(1) == b"1"
    # assert utf8(1.2) == b"1.2"
    # assert utf8(object()) == b"<object object at 0x%" % id(object())


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:23:17.570803
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#38;&nbsp;&quot;&#38;") == "&\u00a0\"&"
    assert xhtml_unescape("&#x0026;&#x00A0;&#x0022;&#x0026;") == "&\u00a0\"&"
    assert xhtml_unescape("&amp;&amp;&#38;") == "&&&"
    assert xhtml_unescape("&#38&#x26") == "&\u0026"



# Generated at 2022-06-24 08:23:21.118388
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("x y") == "x+y"
    assert url_escape("x y", plus=False) == "x%20y"
test_url_escape()


# Generated at 2022-06-24 08:23:27.147261
# Unit test for function json_encode
def test_json_encode():
    val = {"key_hello": "hello"}
    # The fact that json_encode wraps json.dumps is an implementation detail.
    # Please see https://github.com/tornadoweb/tornado/pull/706
    # before sending a pull request that adds **kwargs to this function.
    assert json_encode(val) == '{"key_hello": "hello"}'


_JSON_DECODE_ERROR = ValueError("Error decoding JSON")



# Generated at 2022-06-24 08:23:30.438797
# Unit test for function json_decode
def test_json_decode():
    result = json_decode('{"name": "test"}')
    assert result['name'] == 'test'

DEFAULT_NAMES = ["utf8", "utf-8", "ascii"]



# Generated at 2022-06-24 08:23:33.036412
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("a b", plus=False) == "a%20b"
    assert url_escape("a b", plus=True) == "a+b"



# Generated at 2022-06-24 08:23:41.660065
# Unit test for function json_decode
def test_json_decode():
    # Test if json_decode returns dict when str or bytes input is given
    assert isinstance(json_decode('{}'), dict)
    assert isinstance(json_decode(b'{}'), dict)
    # Test if json_decode returns list when str or bytes input is given
    assert isinstance(json_decode('[]'), list)
    assert isinstance(json_decode(b'[]'), list)
    # Test if json_decode returns str when str or bytes input is given
    assert isinstance(json_decode('a'), str)
    assert isinstance(json_decode(b'a'), str)
    # Test if json_decode returns int when str or bytes input is given
    assert isinstance(json_decode('1'), int)

# Generated at 2022-06-24 08:23:52.085559
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'%e7%bd%91%e6%98%93', encoding='utf-8') == '网易'
    assert url_unescape('%e7%bd%91%e6%98%93', encoding='utf-8') == '网易'
    assert url_unescape('%e7%bd%91%e6%98%93') == '网易'
    assert url_unescape(b'%e7%bd%91%e6%98%93') == b'\xe7\xbd\x91\xe6\x98\x93'
    assert url_unescape(b'%e7%bd%91%e6%98%93', encoding='utf-8') == '网易'



# Generated at 2022-06-24 08:23:56.921358
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&") == "&amp;"

_XHTML_UNESCAPE_ENTITY_RE = re.compile("&(#?)(\d{1,5}|\w{1,8});")



# Generated at 2022-06-24 08:24:00.449376
# Unit test for function native_str
def test_native_str():
    pass

try:
    _NATIVE_STR_TYPES = (str, type(None))
except NameError:  # pragma: nocover
    _NATIVE_STR_TYPES = (bytes, type(None))


# Generated at 2022-06-24 08:24:07.347518
# Unit test for function json_decode
def test_json_decode():
    some_dict = {'name': 'thomas', 'age': 28}
    some_dict_json = json_encode(some_dict)
    some_dict_decoded = json_decode(some_dict_json)
    print(some_dict_decoded)
    assert some_dict_decoded['name'] == some_dict['name']
    assert some_dict_decoded['age'] == some_dict['age']
test_json_decode()


# Generated at 2022-06-24 08:24:09.513244
# Unit test for function utf8
def test_utf8():
    x = utf8('test')
    assert b'test' == x
test_utf8()



# Generated at 2022-06-24 08:24:11.644837
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("abc efg") == "abc efg"
    assert squeeze("abc     efg") == "abc efg"



# Generated at 2022-06-24 08:24:19.496278
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = recursive_unicode({"ascii": b"ascii", "two": [b"one", b"two"]})
    print(x)
    assert b"ascii" not in x["ascii"]

# tested in test_unicode_
# test_recursive_unicode()
test_recursive_unicode()



# Generated at 2022-06-24 08:24:27.641545
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(10) == '10'
    assert json_encode(10.0) == '10.0'
    assert json_encode(True) == 'true'
    assert json_encode('{"1": 1}') == '"{\\"1\\": 1}"'
    data = [1,2,3]
    assert json_encode(data) == '[1, 2, 3]'
    data = {1:1, 2:2}
    assert json_encode(data) == '{"1": 1, "2": 2}'
    # function
    assert json_encode(json_encode) == 'null'


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:24:36.992414
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#34;") == '"'
    assert xhtml_unescape("&#38;") == '&'
    assert xhtml_unescape("&#60;") == '<'
    assert xhtml_unescape("&#62;") == '>'
    assert xhtml_unescape("&#160;") == "\xa0"
    assert xhtml_unescape("&nbsp;") == "\xa0"
    assert xhtml_unescape

# Generated at 2022-06-24 08:24:47.609781
# Unit test for function json_decode
def test_json_decode():
    assert True == json_decode('true')
    assert False == json_decode('false')
    assert None == json_decode('null')
    assert {'a':1,'b':2} == json_decode('{"a":1,"b":2}')
    assert [{'a':1,'b':2},{'a':3,'b':4}] == json_decode('[{"a":1,"b":2},{"a":3,"b":4}]')
    assert ['a1','a2'] == json_decode('["a1","a2"]')


# json_encode_pretty is compatible with _json_encode_pretty
# in web.py (http://webpy.org).

# Generated at 2022-06-24 08:24:53.342985
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": "b"}) == {"a": "b"}
    assert recursive_unicode({"a": "b".encode("utf-8")}) == {"a": "b"}
    assert recursive_unicode({"a": {"b": "c".encode("utf-8")}}) == {"a": {"b": "c"}}
    assert recursive_unicode({"a": "b".encode("utf-8")}) == {"a": "b"}
    assert recursive_unicode(["a", "b"]) == ["a", "b"]
    assert recursive_unicode(["a".encode("utf-8"), "b"]) == ["a", "b"]
    assert recursive_unicode(("a", "b")) == ("a", "b")

# Generated at 2022-06-24 08:25:01.363266
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b'abc') == 'abc'
    assert recursive_unicode(['abc']) == ['abc']
    assert recursive_unicode((1, 2, 3, b'abc')) == (1, 2, 3, 'abc')
    assert recursive_unicode({'a': b'abc'}) == {'a': 'abc'}
    assert recursive_unicode({'a': {'b': b'abc'}}) == {'a': {'b': 'abc'}}

# These methodx are for use in templates
# Methods for templates

# Generated at 2022-06-24 08:25:05.282184
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('hello world') == 'hello%20world'
    assert url_escape('/my/path/?foo=bar') == '/my/path/%3Ffoo=bar'
    assert url_escape('/my/path/?foo=bar', plus=False) == '/my/path/%3Ffoo%3Dbar'



# Generated at 2022-06-24 08:25:14.092532
# Unit test for function native_str
def test_native_str():
    assert native_str(b'foo') == 'foo'
    assert native_str(u'foo') == 'foo'
    assert native_str(b'foo'.decode('ascii')) == 'foo'
    native_str(b'f\xe9oo'.decode('utf-8')) == u'f\xe9oo'
    assert native_str(u'f\xe9oo'.encode('utf-8')) == u'f\xe9oo'
    assert native_str(b'f\xe9oo') == u'f\xe9oo'


# Generated at 2022-06-24 08:25:19.444189
# Unit test for function utf8
def test_utf8():
    utf8(b"foo")
    utf8("foo")
    utf8(None)
    utf8(1234)
    utf8(b"foo\xe9")
    utf8("foo\xc3\xa9")
    utf8("foo\xe9".encode("iso-8859-1"))
    utf8(u"foo\xe9")

    try:
        utf8(u"foo\xe9".encode("iso-8859-1"))
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:25:23.327298
# Unit test for function json_decode
def test_json_decode():
    assert type(json_decode("{}")) == dict
    assert type(json_decode("[0, 1, 2]")) == list
    assert type(json_decode("true")) == bool
    assert type(json_decode("\"yes\"")) == str


# Generated at 2022-06-24 08:25:32.570776
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("123")==123
    assert json_decode('"123"')=="123"
    assert json_decode('{"a":1,"b":2}')=={"a":1,"b":2}
    assert json_decode(json_encode({"a":1,"b":2}))=={"a":1,"b":2}
    assert json_decode(json_encode({"a":1.1,"b":2}))=={"a":1.1,"b":2}

test_json_decode()



# Generated at 2022-06-24 08:25:44.746063
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('one\ttwo three') == 'one two three'

_LINK_RE = re.compile(r'<a [^>]*href=["\'](.*?)["\']', re.I)
_SCRIPT_RE = re.compile(r'<script [^>]*src=["\'](.*?)["\']', re.I)
_STYLE_RE = re.compile(r'<link [^>]*href=["\'](.*?)["\']', re.I)
_TAG_RE = re.compile(
    r"<(?P<tag>\w+)(?P<attrs>(?: [^>]+|/)+)>"
    r"|</(?P<closetag>\w+)>|(?P<text>\S+)"
)



# Generated at 2022-06-24 08:25:48.553953
# Unit test for function url_escape
def test_url_escape():
    url_escape("", plus = True)
    url_escape("", plus = False)
    url_escape("http://www.baidu.com")
    url_escape("http://www.baidu.com", plus = False)



# Generated at 2022-06-24 08:25:54.990209
# Unit test for function native_str
def test_native_str():
    assert native_str(None) is None
    assert native_str(u"abc") == b"abc"
    assert native_str(b"abc") == b"abc"
    assert native_str(u"\u2603") == b"\xe2\x98\x83"
    assert native_str(b"\xe2\x98\x83") == b"\xe2\x98\x83"
    assert native_str(1) == b"1"
    assert native_str(1.9) == b"1.9"
    assert native_str(True) == b"True"



# Generated at 2022-06-24 08:26:05.399770
# Unit test for function json_encode
def test_json_encode():
    print(json_encode({
        "foo": "bar",
        "baz": ["a", "b", "c"],
    }))
    print(json_encode("\u2028\u2029"))


_JSONDecodeError = getattr(json, "JSONDecodeError")


# The fact that json_decode wraps json.loads is an implementation detail.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-24 08:26:15.091580
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&') == '&amp;'
    assert xhtml_escape('<') == '&lt;'
    assert xhtml_escape('>') == '&gt;'
    assert xhtml_escape('"') == '&quot;'
    assert xhtml_escape('\'') == '&#39;'


_URL_ESCAPE_RE = re.compile(r"[^a-zA-Z0-9\/\-_.~%]")
_URL_ESCAPE_DICT = {
    v: "%{0:02x}".format(ord(v))
    for v in " !\"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~"
}



# Generated at 2022-06-24 08:26:17.639491
# Unit test for function url_escape
def test_url_escape():
    assert (url_escape("a") == "a")
    assert (url_escape("/") == "%2F")



# Generated at 2022-06-24 08:26:26.022619
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # Note: http://stackoverflow.com/questions/36081603/python-3-5-1-builtin-name-unicode-is-not-defined
    try:
      unicode(b'abcde', 'utf-8')
      unicode('abcde')
      assert(True)
    except Exception as e:
      assert(False)
    try:
      to_unicode(b'abcde')
      to_unicode('abcde')
      assert(True)
    except Exception as e:
      assert(False)

# vim: set ts=4 sts=4 sw=4 et:

# Generated at 2022-06-24 08:26:31.240922
# Unit test for function recursive_unicode
def test_recursive_unicode():
    n = [1, 'hai', [2, 3], ('tuple', 'tuple')]
    n_unicode = recursive_unicode(n)
    expected = u'[1, u\'hai\', [2, 3], (u\'tuple\', u\'tuple\')]'
    assert str(n_unicode) == expected

test_recursive_unicode()

# Use our own version of partial that is compatible with pickling

# Generated at 2022-06-24 08:26:33.356736
# Unit test for function xhtml_escape
def test_xhtml_escape():
    mystring = "this is a string"
    mystring_html = "this is a string"
    assert xhtml_escape(mystring) == mystring_html



# Generated at 2022-06-24 08:26:35.857191
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([u"test1", u"test2"])== ['test1', 'test2']


# Workaround for https://bugs.python.org/issue5323

# Generated at 2022-06-24 08:26:43.568442
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>&\"'") == "&lt;&gt;&amp;&quot;&#39;"

_XML_ESCAPE_RE = re.compile("[&<>\"']")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
}



# Generated at 2022-06-24 08:26:45.622070
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("hello    jason") == "hello jason"
    assert squeeze("    hello    world    ") == "hello world"



# Generated at 2022-06-24 08:26:53.192370
# Unit test for function native_str
def test_native_str():
    assert native_str(b"foo") == b"foo"
    assert native_str(u"foo") == u"foo"
    assert type(native_str(b"foo")) is str
    assert type(native_str(u"foo")) is str
native_str = type(b"foo").__str__
_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-24 08:26:57.455802
# Unit test for function native_str
def test_native_str():
    assert "\\xA1" == native_str(b"\xA1")
    assert "\\u2603" == native_str("\u2603")
    assert "\\U0001d120" == native_str("\U0001D120")
    assert "\\" == native_str("\\")



# Generated at 2022-06-24 08:26:59.290170
# Unit test for function native_str
def test_native_str():
    native_str("hello")


# Generated at 2022-06-24 08:27:07.470104
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&b=2') == {b'a':[b'1'],b'b':[b'2']}
    assert parse_qs_bytes(b'a=1&b=2&b=3') == {b'a':[b'1'],b'b':[b'2',b'3']}
    assert parse_qs_bytes(b'a=1&b=2&b=3') == {b'a':[b'1'],b'b':[b'2',b'3']}
    assert parse_qs_bytes(b'a=1&b=2&b=3',strict_parsing=True) == {b'a':[b'1'],b'b':[b'2',b'3']}

# Generated at 2022-06-24 08:27:14.500408
# Unit test for function native_str
def test_native_str():
    assert native_str(b'bytes') == 'bytes'
    assert native_str(b'bytes', 'ascii') == 'bytes'
    assert native_str(b'bytes', 'utf8') == 'bytes'
    assert native_str(u'unicode') == 'unicode'

    assert native_str(b'\xe2\x98\x83', encoding='utf-8') == u"\u2603"
    assert native_str(b'\xe2\x98') == u"\xe2\x98"
    assert native_str(b'\xe2\x98', encoding='utf-8', errors='replace') == u"\ufffd"
    assert native_str(b'\xe2\x98', encoding='ascii', errors='replace') == u"\ufffd"
    assert native

# Generated at 2022-06-24 08:27:19.270937
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert "&lt;script&gt;&amp;" == xhtml_escape("<script>&")
    assert "&lt;script&gt;&amp;" == xhtml_escape("<script>&")


_JSON_ESCAPE_RE = re.compile(r"[<>&]")
_JSON_ESCAPE_DICT = {
    "<": r"\u003c",
    ">": r"\u003e",
    "&": r"\u0026",
}



# Generated at 2022-06-24 08:27:22.668134
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("1") == "1"
    assert squeeze("a b") == "a b"
    assert squeeze("a \n\t b") == "a b"



# Generated at 2022-06-24 08:27:32.832761
# Unit test for function native_str
def test_native_str():
    for i in range(0, sys.maxunicode + 1):
        try:
            x = chr(i)
        except ValueError:
            continue
        if i < 0x10000:
            assert native_str(x) == x