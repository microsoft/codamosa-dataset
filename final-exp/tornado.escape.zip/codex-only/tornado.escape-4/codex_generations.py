

# Generated at 2022-06-24 08:17:31.328678
# Unit test for function json_encode
def test_json_encode():
    json_encode(1)
    json_encode({})
    json_encode(['a', 'b'])
    json_encode(None)


# Generated at 2022-06-24 08:17:35.876616
# Unit test for function url_escape
def test_url_escape():
    # Tests for function url_escape
    assert url_escape("http://localhost:8080/search?q=foo&foo=bar"
                      "&foo=bar+2&foo=bar%203") == \
        "http%3A//localhost%3A8080/search%3Fq%3Dfoo%26foo%3Dbar" \
        "%26foo%3Dbar%2B2%26foo%3Dbar%25203"


# Generated at 2022-06-24 08:17:45.638078
# Unit test for function url_escape
def test_url_escape():
    s = "https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&tn=baidu&wd=早上好"
    result = "https%3A//www.baidu.com/s%3Fie%3Dutf-8%26f%3D8%26rsv_bp%3D1%26tn%3Dbaidu%26wd%3D%E6%97%A9%E4%B8%8A%E5%A5%BD"
    assert url_escape(s)==result
test_url_escape()


# Generated at 2022-06-24 08:17:48.875997
# Unit test for function utf8
def test_utf8():
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    try:
        assert utf8(1) == b"1"
    except:
        pass


# Generated at 2022-06-24 08:17:52.634208
# Unit test for function json_encode
def test_json_encode():
    a = '{\"hello\": \"world\"}'
    b = json_encode({"hello": "world"})
    assert a == b
    assert type(b) == str

# Generated at 2022-06-24 08:17:59.375772
# Unit test for function url_unescape
def test_url_unescape():
    # type: () -> None
    assert url_unescape('https%3A%2F%2Fwww.google.com%2F%3Fq%3Dtest', plus=True) == 'https://www.google.com/?q=test'
    assert url_unescape('https%3A%2F%2Fwww.google.com%2F%3Fq%3Dtest', plus=False) == 'https%3A%2F%2Fwww.google.com%2F%3Fq%3Dtest'
t_url_unescape = test_url_unescape()

re_compile_cache: Dict[str, re.Pattern] = {}


# Generated at 2022-06-24 08:18:05.175201
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('') == ''
    assert xhtml_escape('abc&<>"\'') == 'abc&amp;&lt;&gt;&quot;&#39;'
    assert xhtml_escape(b'abc') == 'abc'


_URL_SAFE = "-_.~"



# Generated at 2022-06-24 08:18:15.638876
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    import urllib.parse
    import ujson as json

    qs = "a=1&b=2"
    parsed_qs = urllib.parse.parse_qs(qs)
    my_parsed_qs = parse_qs_bytes(qs)
    assert json.encode(my_parsed_qs) == json.encode(parsed_qs)

    qs = "a=1&b=2&c=&d=3"
    parsed_qs = urllib.parse.parse_qs(qs)
    my_parsed_qs = parse_qs_bytes(qs)
    assert json.encode(my_parsed_qs) == json.encode(parsed_qs)


_UTF8_TYPES = (bytes, type(None))


# Generated at 2022-06-24 08:18:19.711477
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1") == {b"a": [b"1"]}
    assert parse_qs_bytes(b"a=a%20b") == {b"a": [b"a b"]}



# Generated at 2022-06-24 08:18:28.370500
# Unit test for function xhtml_escape
def test_xhtml_escape():
    s = xhtml_escape("foo")
    if type(s) is not str: raise Exception(s)
    s = xhtml_escape(1)
    if type(s) is not str: raise Exception(s)
    s = xhtml_escape(1.1)
    if type(s) is not str: raise Exception(s)
    s = xhtml_escape(1j)
    if type(s) is not str: raise Exception(s)
    s = xhtml_escape(1)
    if type(s) is not str: raise Exception(s)



# Generated at 2022-06-24 08:18:31.840662
# Unit test for function native_str
def test_native_str():
    for value in ["unicode", b"bytes"]:
        for encoding in [None, "utf-8"]:
            assert native_str(value, encoding) == str(value)


_BASESTRING_TYPES = (unicode_type, bytes, type(None))



# Generated at 2022-06-24 08:18:39.104526
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%3Cmoo%3E', encoding=None) == b'<moo>'
    assert url_unescape('%3Cmoo%3E') == '<moo>'
    assert url_unescape('%3Cmoo%3E', plus=False) == '%3Cmoo%3E'
    assert url_unescape(b'%3Cmoo%3E', plus=False) == '%3Cmoo%3E'



# Generated at 2022-06-24 08:18:41.416677
# Unit test for function url_escape
def test_url_escape():
    print(url_escape("TEST", plus=True))
    print(url_escape("TEST", plus=False))
# test_url_escape()



# Generated at 2022-06-24 08:18:48.615778
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8(b"abc") == b"abc"
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\u0141") == b"\xc5\x81"
    try:
        utf8(1)
        assert False
    except TypeError:
        pass

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:50.536018
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    value = xhtml_unescape('&amp;')
    assert value == '&'


# Generated at 2022-06-24 08:18:59.566385
# Unit test for function utf8
def test_utf8():
    assert utf8('abc') == (b'abc')
    assert utf8(b'abc') == (b'abc')
    assert utf8(None) == (None)
    try:
        utf8(123)
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))

# to_unicode was previously named _unicode not because it was private,
# but to avoid conflicts with the built-in unicode() function/type
# on python2.

# Generated at 2022-06-24 08:19:03.884381
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape("this is a test & this too") == "this is a test &amp; this too"


# to_unicode was previously named _unicode not because it was private,
# but to avoid conflicts with the built-in unicode() function/type

# Generated at 2022-06-24 08:19:07.361791
# Unit test for function json_encode
def test_json_encode():
    j = json.dumps({'a': 'b'})
    assert json_encode({'a': 'b'}) == j
    assert json_encode({'a': 'b'}) != {'a': 'b'}
test_json_encode()



# Generated at 2022-06-24 08:19:10.610949
# Unit test for function url_escape
def test_url_escape():
    value = utf8('~')
    assert url_escape(value) == b'%7E'



# Generated at 2022-06-24 08:19:13.111962
# Unit test for function url_escape
def test_url_escape():
    url_escape(b"123",False)
# url_escape end


# Generated at 2022-06-24 08:19:23.676045
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8("\xe9") == b"\xc3\xa9"
    assert utf8("\u1234") == b"\xe1\x88\xb4"
    assert utf8("\U0001f34c") == b"\xf0\x9f\x8d\x8c"
    assert utf8("") == b""
    assert utf8(None) is None
    assert type(utf8("")) == bytes
    assert type(utf8(None)) == type(None)



# Generated at 2022-06-24 08:19:32.443856
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&quot;") == "\""
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&amp;") == "&"
    assert (
        xhtml_unescape("&lt;&gt;&amp;&quot;&#39;")
        == "<>&\"'"
    ), "All escaped characters should be un-escaped."



# Generated at 2022-06-24 08:19:43.371117
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%2Bb") == "a+b"
    assert url_unescape("a%2Bb", encoding="utf-8") == "a+b"
    assert url_unescape("a%2Bb", encoding=None) == b"a+b"
    assert url_unescape("a+b", encoding=None) == b"a b"
    assert url_unescape("a+b", plus=False, encoding=None) == b"a+b"
    assert url_unescape("a+b", plus=False) == "a+b"



# Generated at 2022-06-24 08:19:45.663594
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    x = b"a=1&a=2&b=3"
    y = parse_qs_bytes(x)
    print(y)
    assert y == {b"a": [b"1", b"2"], b"b": [b"3"]}


# Dict formatting


# Generated at 2022-06-24 08:19:54.973923
# Unit test for function native_str
def test_native_str():
    assert tornado.web.native_str(b"\xe4\xbd\xa0\xe5\xa5\xbd") == Tornado.util.NativeString("你好")
    assert tornado.web.native_str(b"\xe4\xbd\xa0\xe5\xa5\xbd", "latin1") == "ä½ å¥½"
    assert tornado.web.native_str("hello") == "hello"
    assert tornado.web.native_str(None) == None
    assert tornado.web.native_str(u"\u82b1\u5b63\u5496\u5561") == Tornado.util.NativeString("花季咖啡")

# Generated at 2022-06-24 08:19:59.514171
# Unit test for function url_unescape
def test_url_unescape():
    result = url_unescape(b'http%3A%2F%2Fwww.google.com%2F')
    assert result == 'http://www.google.com/'
test_url_unescape()



# Generated at 2022-06-24 08:20:10.357910
# Unit test for function linkify
def test_linkify():
    def check(text, expected):
        result = linkify(text)
        if result != expected:
            print('\n%s...\n%s...\nexpected:\n%s\ngot:\n%s' % (text[:40],
                                                              result[:40],
                                                              expected[:40],
                                                              result[:40]))
            assert False

    check('http://www.facebook.com',
          '<a href="http://www.facebook.com">http://www.facebook.com</a>')
    check('http://www.facebook.com/xxx',
          '<a href="http://www.facebook.com/xxx">http://www.facebook.com/xxx</a>')

# Generated at 2022-06-24 08:20:14.021806
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8("\u00A0") == b"\xc2\xa0"
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:20:17.702767
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  f  ") == "f"
    assert squeeze("  fo   o  ") == "fo o"
    assert squeeze("  foo     bar  ") == "foo bar"



# Generated at 2022-06-24 08:20:27.747713
# Unit test for function linkify

# Generated at 2022-06-24 08:20:28.750768
# Unit test for function utf8
def test_utf8():
    assert utf8("test") == b"test"



# Generated at 2022-06-24 08:20:31.746546
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('/') == '/'
    assert url_escape('/%20/') == '/%20/'
    assert url_escape('/', plus = False) == '/'
    assert url_escape('/', plus = True) == '%2F'



# Generated at 2022-06-24 08:20:40.087160
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == \
        '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com?foo=bar&baz=blah") == \
        '<a href="http://example.com?foo=bar&amp;baz=blah">http://example.com?foo=bar&amp;baz=blah</a>'
    assert linkify("www.example.com") == \
        '<a href="http://www.example.com">www.example.com</a>'
    assert linkify("http://www.example.com/foo/bar") == \
        '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'
   

# Generated at 2022-06-24 08:20:47.341612
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b'abc') == 'abc'
    assert recursive_unicode(1) == 1

    assert recursive_unicode({
        'a':'b',
        'c':b'd',
        'e':{'f':b'g'}
    }) == {
            'a':'b',
            'c':'d',
            'e':{'f':'g'}
        }



# Generated at 2022-06-24 08:20:52.036627
# Unit test for function json_decode
def test_json_decode():
    # type: () -> None
    assert json_decode('{"a": 1}') == {'a': 1}
    assert json_decode(b'{"a": 1}') == {'a': 1}


_RECURSION_PROTECTION = re.compile(r"\$RecursionGuard\$[a-f0-9]{32}")



# Generated at 2022-06-24 08:20:58.852168
# Unit test for function url_escape
def test_url_escape():
    p = url_escape('https://www.baidu.com/s?wd=tornado', True)
    assert p == 'https%3A%2F%2Fwww.baidu.com%2Fs%3Fwd%3Dtornado'
    q = url_escape('https://www.baidu.com/s?wd=tornado', False)
    assert q == 'https%3A%2F%2Fwww.baidu.com%2Fs%3Fwd%3Dtornado'



# Generated at 2022-06-24 08:21:05.197270
# Unit test for function native_str
def test_native_str():
    if str is bytes:
        assert native_str(u"foo") == b"foo"
        assert native_str("foo") == b"foo"
    else:
        assert native_str(u"foo") == u"foo"
        assert native_str("foo") == u"foo"
        assert native_str(b"foo") == u"foo"


_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-24 08:21:09.934925
# Unit test for function json_decode
def test_json_decode():
    value = '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'
    print(json_decode(value))
if __name__ == '__main__':
    test_json_decode()

# Get the same behavior as the "old" `escape.url_escape` and
# `escape.url_unescape` functions in Tornado 2.1 and earlier.
_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:21:12.615954
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = "'"
    escaped_value = xhtml_escape(value)
    assert escaped_value == "&#39;"



# Generated at 2022-06-24 08:21:22.792391
# Unit test for function json_encode
def test_json_encode():
    print(json_encode(None))
    print(json_encode(True))
    print(json_encode(False))
    print(json_encode(123))
    print(json_encode(123.456))
    print(json_encode(123.456e102))
    print(json_encode(123.456e-456))
    print(json_encode(123.456E102))
    print(json_encode(123.456E-456))
    print(json_encode("abc"))
    print(json_encode("abc\ndef"))
    print(json_encode("abc\ud4c4def"))
    print(json_encode("abc\ndef"))
    print(json_encode([1,2,3,4]))

# Generated at 2022-06-24 08:21:24.919033
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    a = xhtml_unescape('&#34;;<br>&#x27;')
    assert a == '";;<br>\''


# Generated at 2022-06-24 08:21:37.148259
# Unit test for function linkify
def test_linkify():
    text = "Check out http://github.com"
    html = linkify(text)
    assert html == 'Check out <a href="http://github.com">http://github.com</a>'

    text = "Check out http://github.com"
    html = linkify(text, shorten=True)
    assert html == 'Check out <a href="http://github.com">github.com</a>'

    text = "Check out http://github.com"
    html = linkify(text, extra_params="rel='nofollow'")
    assert html == 'Check out <a href="http://github.com" rel="nofollow">http://github.com</a>'

    text = "Check out www.github.com"
    html = linkify(text, require_protocol=True)

# Generated at 2022-06-24 08:21:48.944067
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("'''") == '&#39;&#39;&#39;'
    assert xhtml_escape('"""') == '&quot;&quot;&quot;'
    assert xhtml_escape("<>") == '&lt;&gt;'
    assert xhtml_escape("''") == '&#39;&#39;'
    assert xhtml_escape('""') == '&quot;&quot;'
    assert xhtml_escape("") == ''
    assert xhtml_escape("'") == "&#39;"
    assert xhtml_escape('"') == "&quot;"
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape(">") == "&gt;"

# Generated at 2022-06-24 08:21:54.088379
# Unit test for function xhtml_escape
def test_xhtml_escape():
    s="&<>'\""
    ans='&amp;&lt;&gt;&#39;&quot;'
    res=xhtml_escape(s)
    assert res==ans
    print('test completed')

test_xhtml_escape()



# Generated at 2022-06-24 08:21:57.866114
# Unit test for function native_str
def test_native_str():
    x = native_str('foo')
    assert x == 'foo'


# Generated at 2022-06-24 08:22:00.111903
# Unit test for function url_escape
def test_url_escape():
    url_escape("http://example.com/hello world")
    # http://example.com/hello+world



# Generated at 2022-06-24 08:22:06.981108
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&nbsp;") == " "
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("aa&#39;bb") == "aa'bb"
    assert xhtml_unescape("aa&nbsp;bb") == "aa bb"
    assert xhtml_unescape("aa&#39;bb&amp;cc&lt;dd&gt;ee") == "aa'bb&cc<dd>ee"


# Generated at 2022-06-24 08:22:12.138041
# Unit test for function xhtml_escape
def test_xhtml_escape():
    for input in [
        "&<>\"'",
        "&amp;&lt;&gt;&quot;&#39;",
        "&amp;&lt;&gt;&quot;&#39;",
        "&amp;&lt;&gt;&quot;&#39;",
    ]:

        assert True

# Generated at 2022-06-24 08:22:21.496024
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   hello   world  \n") == "hello world"
    assert squeeze("   hello   world,  \n") == "hello world,"
    assert squeeze("   hello   world.  \n") == "hello world."
    assert squeeze("   hello  ,  world  \n") == "hello, world"
    assert squeeze("   hello,  world  \n") == "hello, world"
    assert squeeze("   hello.  world  \n") == "hello. world"
    assert squeeze("   hello; world  \n") == "hello; world"
    assert squeeze("   hello: world  \n") == "hello: world"



# Generated at 2022-06-24 08:22:28.897996
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
  assert xhtml_unescape('a&gt;b') == 'a>b'
  assert xhtml_unescape('a&lt;b') == 'a<b'
  assert xhtml_unescape('a&#39;b') == "a'b"
  assert xhtml_unescape('a&quot;b') == 'a"b'
  assert xhtml_unescape('a&amp;b') == 'a&b'
  assert xhtml_unescape('a&#123;b') == 'a{b'
  assert xhtml_unescape('a&#x123;b') == 'a{b'

_BASESTRING_TYPES = (str, bytes)



# Generated at 2022-06-24 08:22:37.164177
# Unit test for function linkify
def test_linkify():
    linkify("Hello http://tornadoweb.org!")
    m =_URL_RE.search("Hello http://tornadoweb.org!")
    m.group(1)
    m.group(2)
    linkify("Hello http://tornadoweb.org/post/tag/tag1?query=tag2&query2=tag3!",
           shorten = True)

# Generated at 2022-06-24 08:22:40.790857
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<>&"\'') == '&lt;&gt;&amp;&quot;&#39;'


# XXX deprecate this in favor of xhtml_escape?

# Generated at 2022-06-24 08:22:50.023058
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&#38;') == '&'
    assert xhtml_unescape('&#x26;') == '&'
    assert xhtml_unescape('&#X26;') == '&'
    assert xhtml_unescape('&foo;') == '&foo;'
    assert xhtml_unescape('&f00;') == '\u00ef\u00bc\u0080'



# Generated at 2022-06-24 08:22:55.339463
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('hello  ') == squeeze('hello')
    assert squeeze(' hello') == squeeze('hello')
    assert squeeze('hello') == squeeze('hello')
    assert squeeze('hello  world') == squeeze('hello world')
    assert squeeze('hello\t world') == squeeze('hello world')
    assert squeeze('hello\nworld') == squeeze('hello world')
    assert squeeze('hello\r\nworld') == squeeze('hello world')



# Generated at 2022-06-24 08:23:07.656740
# Unit test for function json_encode
def test_json_encode():
    #noinspection PyUnresolvedReferences
    mylist=[1,2,3]
    encoded=json_encode(mylist)
    assert encoded == "[1, 2, 3]"
    dic={'a':1,'b':2}
    encoded=json_encode(dic)
    assert encoded=='{"a": 1, "b": 2}'
    test='a/b'
    encoded=json_encode(test)
    assert encoded=='"a\\/b"'
    assert json_encode(None)=='null'
    assert json_encode(1)=='1'

_JSON_DECODE_ERROR_MESSAGE = (
    "JSON must be str, bytes or bytearray, not %s"
)



# Generated at 2022-06-24 08:23:20.205022
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    result = linkify(text, extra_params='rel="nofollow" class="external"')
    print(result)
    text = 'Hello www.tornadoweb.org!'
    result = linkify(text, extra_params='rel="nofollow" class="external"')
    print(result)
    text = 'Hello [www.tornadoweb.org]'
    result = linkify(text, extra_params='rel="nofollow" class="external"')
    print(result)
    text = 'Hello www.tornadoweb.org www.tornadoweb.org www.tornadoweb.org.c'
    result = linkify(text, extra_params='rel="nofollow" class="external"')
    print(result)

# Generated at 2022-06-24 08:23:25.210292
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # Test for dict
    assert recursive_unicode({'a': b'\xc3\x9c', 'b': b'\xc3\xbc'}) == {'a': 'Ü', 'b': 'ü'}
    assert recursive_unicode({'a': b'\xc3\x9c', 'b': b'\x00'}) == {'a': 'Ü', 'b': '\x00'}
    assert recursive_unicode({'a': b'\xc3\x9c', 'b': None}) == {'a': 'Ü', 'b': None}
    # Test for list
    assert recursive_unicode([b'\xc3\x9c', b'\xc3\xbc']) == ['Ü', 'ü']

# Generated at 2022-06-24 08:23:32.899553
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    L = ["&quot;","&lt;","&gt;","&amp;","&#34;","&#60;","&#62;","&#38;"]
    from tornado.util import raise_exc_info
    for i in range(len(L) - 1):
        for j in range(i + 1, len(L)):
            try:
                result = L[i] == L[j]
                if result is True:
                    raise Exception("xhtml_unescape test failed!")
            except Exception as e:
                raise_exc_info(sys.exc_info())
# Unit test end


_BASESTRING_TYPES = (str, bytes, bytearray)


# Generated at 2022-06-24 08:23:36.501973
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    html = linkify(text)
    assert html == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'



# Generated at 2022-06-24 08:23:41.872869
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<>&"') == "&lt;&gt;&amp;&quot;"
    assert xhtml_escape("foo") == "foo"
    assert xhtml_escape("foo'bar") == "foo&#39;bar"
    assert xhtml_escape("foo&bar") == "foo&amp;bar"
test_xhtml_escape()



# Generated at 2022-06-24 08:23:52.179952
# Unit test for function linkify
def test_linkify():
    print(linkify("http://foo.com/blah_blah"))
    print(linkify(" http://foo.com/blah_blah"))
    print(linkify("hi http://foo.com/blah_blah"))
    print(linkify("hi http://foo.com/blah_blah", extra_params='rel="nofollow"'))
    print(linkify("go to http://www.foo.com/ and https://foo.com/"))
    print(linkify("http://foo.com/blah_blah_(wikipedia)#cite-1"))
    print(linkify("http://foo.com/blah_blah_(wikipedia)_blah#cite-1"))
    print(linkify("http://foo.com/unicode_(✪)_in_parens"))

# Generated at 2022-06-24 08:24:02.306116
# Unit test for function url_unescape
def test_url_unescape():
    # type: () -> None
    assert isinstance(url_unescape("%20"), str)
    assert isinstance(url_unescape("%20", encoding=None), bytes)
    assert url_unescape("%2B") == "+"
    assert url_unescape("%2B", plus=False) == "%2B"
    assert url_unescape("%2B", encoding=None, plus=False) == b"%2B"
    assert url_unescape("%", encoding=None) == b"%"
    assert url_unescape("%", encoding="utf-8") == "%"
    assert url_unescape("%ZZ", encoding=None) == b"%"
    assert url_unescape("%ZZ", encoding="utf-8") == "%ZZ"

# Generated at 2022-06-24 08:24:09.818628
# Unit test for function utf8
def test_utf8():
    assert isinstance(utf8(""), bytes)
    assert isinstance(utf8("foo"), bytes)
    assert isinstance(utf8("\u00e9"), bytes)
    assert utf8("") == b""
    assert utf8("foo") == b"foo"
    assert utf8("\u00e9") == b"\xc3\xa9"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:24:15.938915
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # type: () -> None
    import tornado.util
    import tornado.escape
    import json
    json_string = json.dumps({u"Foo": u"b\xf3ar", u"bar": u"foo"})
    decoded = tornado.escape.json_decode(json_string)
    assert tornado.util.recursive_unicode(decoded) == {u"Foo": u"b\xf3ar", u"bar": u"foo"}



# Generated at 2022-06-24 08:24:20.495150
# Unit test for function utf8
def test_utf8():
    assert isinstance(utf8('\xe2\x9b'), bytes)
    assert utf8('\xe2\x9b').decode('utf-8') == '\u263b'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:24:23.041665
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a%2Bb%2Bc") == u"a+b+c"



# Generated at 2022-06-24 08:24:29.839100
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a  b  c") == "a b c"
    assert squeeze("a\tb\tc") == "a b c"
    assert squeeze(" a b  c ") == "a b c"
    assert squeeze("   a   b   c   ") == "a b c"
    assert squeeze("a\tb\tc\t") == "a b c"



# Generated at 2022-06-24 08:24:35.285220
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Case : Failing Case
    assert parse_qs_bytes(b"", keep_blank_values=False, strict_parsing=False) == {}

    # Case : Passing Case
    assert parse_qs_bytes(b"b=1&c=1",keep_blank_values=False,strict_parsing=False) == {b'b': [b'1'], b'c': [b'1']}

# Generated at 2022-06-24 08:24:37.878713
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;a href=&quot;https://www.baidu.com&quot;&gt;') == '<a href=\"https://www.baidu.com\">'



# Generated at 2022-06-24 08:24:41.418002
# Unit test for function native_str
def test_native_str():
    assert native_str(u'foo') == 'foo'
    assert native_str('foo') == 'foo'



# Generated at 2022-06-24 08:24:46.721808
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"q=%CE%94%CE%B5%CF%85%CF%84%CE%BF%CF%82", encoding=None) == b"q=\xce\x94\xce\xb5\xcf\x85\xcf\x84\xce\xbf\xcf\x82"



# Generated at 2022-06-24 08:24:58.047475
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify(u'no link.') == u'no link.'
    assert linkify(u'no link.', shorten=True) == u'no link.'
    assert linkify(u'http://example.com', shorten=False) == (
            u'<a href="http://example.com">http://example.com</a>'
        )
    assert linkify(u'http://example.com', shorten=True) == (
            u'<a href="http://example.com">example.com</a>'
        )

# Generated at 2022-06-24 08:25:01.107437
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a b c") == "a b c"
    assert squeeze("   a\tb c  ") == "a b c"
    assert squeeze("a\nb\tc  \t\n") == "a b c"



# Generated at 2022-06-24 08:25:11.410342
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div>test&test</div>") == "&lt;div&gt;test&amp;test&lt;/div&gt;"


_JSON_ESCAPE_RE = re.compile(r"[&<>\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]")

# Generated at 2022-06-24 08:25:14.082453
# Unit test for function url_escape
def test_url_escape():
    url = url_escape("test")
    assert url == "test"
    url = url_escape("test", True)
    assert url == "test"


# Generated at 2022-06-24 08:25:20.343517
# Unit test for function json_decode
def test_json_decode():
    """Unit test for function json_decode"""
    from tornado.web import RequestHandler, Application
    class TestHandler(RequestHandler):
        def get(self):
            value = self.get_argument("value")
            # The string is first converted to bytes, then to unicode, and
            # subsequently to a Python object.
            self.write(json_decode(value))

    app = Application([("/", TestHandler)])

    response = app.get_response(app.create_http_server(), "/?value=%22value%22")
    assert response.body == b'"value"'
    response = app.get_response(app.create_http_server(), "/?value=true")
    assert response.body == b'true'



# Generated at 2022-06-24 08:25:24.408453
# Unit test for function linkify
def test_linkify():
    text = "google.com is a website, www.google.com is a website! www.google.cn is a website too."
    result = linkify(text, shorten=True, extra_params="rel='nofollow' class='external'")
    print(result)


import types



# Generated at 2022-06-24 08:25:34.562353
# Unit test for function url_unescape
def test_url_unescape():  # noqa: F811
    encoding = "utf-8"
    plus = True
    value: Union[str, bytes] = b'https://www.google.com/search?ei=4Kj0W--nMYisjwTi6YmYAg&q=pythontutor&oq=python+tutor&gs_l=psy-ab.3..0l10.2486.5155..5447...1.0..0.73.539.8......0....1..gws-wiz.......0i71j35i39j0i22i30j33i160.O3Bqf0yhKjI'
    unquote = urllib.parse.unquote_plus if plus else urllib.parse.unquote

# Generated at 2022-06-24 08:25:45.178398
# Unit test for function url_unescape
def test_url_unescape():
    assert b'abc' == url_unescape('abc')
    assert b'abc' == url_unescape('abc', encoding=None)
    assert 'abc' == url_unescape('abc', encoding='ascii')
    assert 'abc def' == url_unescape('abc+def')
    assert u'\xe9' == url_unescape('%C3%A9', encoding='utf-8')
    assert u'\xe9' == url_unescape('%c3%a9', encoding='utf-8')
    assert u'abc \xe9' == url_unescape('abc+%c3%a9', encoding='utf-8')
    assert u'abc \xe9' == url_unescape('abc+%C3%A9', encoding='utf-8')

# Generated at 2022-06-24 08:25:51.566621
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    s_0 = '&#x00026;'
    s_1 = '&amp;'
    s_2 = '&#38;'
    assert xhtml_unescape(s_0) == s_0[2:]
    assert xhtml_unescape(s_1) == s_1[1:-1]
    assert xhtml_unescape(s_2) == s_2[1:-1]
test_xhtml_unescape()

# html entities

# Generated at 2022-06-24 08:25:56.520155
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert(xhtml_escape('<em>HTML</em>') == '&lt;em>HTML&lt;/em>')
    assert(xhtml_escape('this is "good"') == 'this is &quot;good&quot;')
    assert(xhtml_escape('this is \'good\'') == 'this is &#39;good&#39;')


# Generated at 2022-06-24 08:26:03.956577
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(None) == "null"
    assert json_encode(3) == "3"
    assert json_encode(["a", u"b", 123]) == '["a", "b", 123]'
    assert json_encode({"a": 2, "b": 3}) == '{"a": 2, "b": 3}'



# Generated at 2022-06-24 08:26:13.350453
# Unit test for function json_encode
def test_json_encode():
    v = str(1)
    assert json_encode(v) == json.dumps(v)
    v = chr(1)
    assert json_encode(v) == json.dumps(v)
    v = [1,2,"1"]
    
    v = json_encode(v)
    assert v == json.dumps(v)
    assert v.replace("</", "<\\/") == json.dumps(v).replace("</", "<\\/")
    try:
        v = "1"
        assert v == json_encode(v)
    except Exception:
        assert False, 'exception'
    v = "</"
    assert v.replace("</", "<\\/") == json_encode(v)


# Generated at 2022-06-24 08:26:17.956081
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("ABC") == "ABC"
    assert url_escape("http://127.0.0.1/") == "http%3A//127.0.0.1/"


# Generated at 2022-06-24 08:26:22.286506
# Unit test for function json_decode
def test_json_decode():
    test_result = json_decode('["foo", {"bar": ["baz", null, 1.0, 2]}]')
    assert test_result == ["foo", {"bar": ["baz", None, 1.0, 2]}]



# Generated at 2022-06-24 08:26:27.086845
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"hello": "world"}) == {"hello": "world"}
    assert recursive_unicode({"hello": b"world"}) == {"hello": "world"}
    assert recursive_unicode({"hello": ["world"]}) == {"hello": ["world"]}
    assert recursive_unicode({"hello": [b"world"]}) == {"hello": ["world"]}
    assert recursive_unicode({"hello": (1, 2)}) == {"hello": (1, 2)}
    assert recursive_unicode({"hello": (1, b"world")}) == {"hello": (1, "world")}



# Generated at 2022-06-24 08:26:29.833754
# Unit test for function url_escape
def test_url_escape():
    # type: () -> None
    url_escape("testing, 1, 2, 3")



# Generated at 2022-06-24 08:26:32.280864
# Unit test for function native_str
def test_native_str():
    from tornado.escape import native_str
    value = native_str(b'\xe4\xb8\xad\xe6\x96\x87')
    print(value)


# Generated at 2022-06-24 08:26:38.333835
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('A&B') == 'A&amp;B'
    assert xhtml_escape('A<B>C') == 'A&lt;B&gt;C'
    assert xhtml_escape('A"B"C') == 'A&quot;B&quot;C'
    assert xhtml_escape("A'B'C") == "A&#39;B&#39;C"
    assert xhtml_escape('A&amp;B') == 'A&amp;amp;B'

# Escape characters for JSON string values
_JSON_ESCAPE = re.compile(r'[\x00-\x1f\\"\b\f\n\r\t]')

# Generated at 2022-06-24 08:26:45.116005
# Unit test for function json_encode
def test_json_encode():
    # Arrange
    myValue = json.dumps({'foo': 'foo', 'bar': 'bar'})
    # Act
    json_encode(myValue)
    # Assert

# The fact that json_decode wraps json.loads is an implementation detail.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-24 08:26:51.656937
# Unit test for function json_decode
def test_json_decode():
    """
    Test function json_decode, which tests the json_decode function in the utility.py
    """
    assert json_decode("{" + str("a") + ":" + str(1) + "}") == {"a": 1}
    assert json_decode("{'a':1}") == {"a": 1}
#Unit test for function json_encode

# Generated at 2022-06-24 08:26:55.167935
# Unit test for function json_encode
def test_json_encode():
    from tornado.escape import json_encode
    assert json_encode(u'\xe9') == b'"\\u00e9"', json_encode(u'\xe9')



# Generated at 2022-06-24 08:27:03.236466
# Unit test for function utf8
def test_utf8():
    assert isinstance(utf8("abc"), bytes)
    assert isinstance(utf8(u"abc"), bytes)
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(None) is None
    assert utf8(b"abc") == b"abc"
    assert raises(TypeError, utf8, 1)
    assert raises(TypeError, utf8, object())


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:27:10.812897
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj1 = {'key1': 'value1', 'key2': 'value2'}
    obj2='value1'
    obj3=[1,2,3]
    obj4=('value1', 'value2')
    
    assert recursive_unicode(obj1) == {'key1': 'value1', 'key2': 'value2'}
    assert recursive_unicode(obj2) == 'value1'
    assert recursive_unicode(obj3) == [1,2,3]
    assert recursive_unicode(obj4) == ('value1', 'value2')
   


# Generated at 2022-06-24 08:27:12.001562
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  1\n2  3") == "1 2 3"



# Generated at 2022-06-24 08:27:17.829044
# Unit test for function json_decode
def test_json_decode():
    a = json_decode("abc")
    b = json_decode(b"abc")
    assert a == b

# This singleton is used as a placeholder for the ``_callback`` keyword
# argument passed to ``url_concat``.  Using a mutable object like a list
# makes it possible to update the callback name from inside a function.
# (We could also use a local function closure instead of a list,
# but this is only supported in python >= 3.2)
_URL_CONCAT_CALLBACK_KEY = []



# Generated at 2022-06-24 08:27:24.664817
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"x": "y"}') == {"x":"y"}
    assert json_decode('[1,2,3]') == [1,2,3]


_URL_ESCAPE_RE = re.compile(r"[^a-zA-Z0-9_.-]")
_URL_ESCAPE_DICT = {
    "&": "%26",
    "'": "%27",
    "/": "%2F",
}



# Generated at 2022-06-24 08:27:30.748617
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'%2B', encoding=None, plus=True) == b'+'


# This function was copied from urllib.unquote() with a different default
# for the encoding, and some changes to handle + and %20.  The function
# is used by url_unescape above and by utils.parse_body_arguments.
# It should never be called directly.