

# Generated at 2022-06-24 08:17:34.067919
# Unit test for function native_str
def test_native_str():
    assert native_str(b"ascii", "ascii") == b"ascii"
    assert native_str("ascii", "ascii") == "ascii"
    assert native_str("привет", "utf8") == "привет"



# Generated at 2022-06-24 08:17:36.050815
# Unit test for function url_escape
def test_url_escape():
    assert url_escape(" ")=="%20"
    assert url_escape(" ", plus=False)=="%20"
    assert url_escape(" " ,plus=True)=="+"


# Generated at 2022-06-24 08:17:43.834998
# Unit test for function url_escape
def test_url_escape():
    print(url_escape('http://www.baidu.com/s?wd=乱码测试'))
    print(urllib.parse.quote('http://www.baidu.com/s?wd=乱码测试'))
    print(urllib.parse.quote_plus('http://www.baidu.com/s?wd=乱码测试'))

# Generated at 2022-06-24 08:17:47.255521
# Unit test for function utf8
def test_utf8():
    assert utf8('abc') == b'abc'
    assert utf8(s) == b'abc'
    assert utf8(b'abc') == b'abc'
    assert utf8(None) == None



# Generated at 2022-06-24 08:17:53.482267
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(None) is None


# This regular expression matches any of the named html entities
# (e.g. '&lt;', '&gt;').
_HTML_UNICODE_RE = re.compile(r"&(#?)(\d{1,5}|\w{1,8});")

# Generated at 2022-06-24 08:17:55.518132
# Unit test for function squeeze
def test_squeeze():
    s = squeeze("Test me \t \r\n")
    print("squeeze result is {}".format(s))
    
    

# Generated at 2022-06-24 08:17:59.828227
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # 3.6: [b'abc', b'def'], [b'123', b'456']
    # 3.7: [b'abc', b'def'], [b'123', b'456']
    assert parse_qs_bytes(b'a=abc&a=def&b=123&b=456') == \
        {b'a': [b'abc', b'def'], b'b': [b'123', b'456']}


# Generated at 2022-06-24 08:18:05.920919
# Unit test for function squeeze
def test_squeeze():
    s = "lorem ipsum     dolor   sit amet"
    assert(squeeze(s) == "lorem ipsum dolor sit amet")
    assert(squeeze("") == "")
    assert(squeeze("    ") == "")
    assert(squeeze("abc") == "abc")


# Generated at 2022-06-24 08:18:15.491308
# Unit test for function url_unescape
def test_url_unescape():
    bs1 = bytes("a+b", encoding="utf8")
    str1 = "%E6%B5%8B%E8%AF%95"
    assert (url_unescape(bs1) == b'a b')
    assert (url_unescape(str1, plus=True) == "测试")
    assert (url_unescape(bs1, encoding="utf8", plus=False) == "a%20b")
    assert (url_unescape(str1, encoding="utf8", plus=True) == "测试")
    assert (url_unescape(bytes(str1, encoding="utf8"), encoding="utf8") == b"%E6%B5%8B%E8%AF%95")



# Generated at 2022-06-24 08:18:20.368303
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{'a': 100, 'b': 200}") == {'a': 100, 'b': 200}
    assert json_decode(b"{'a': 100, 'b': 200}") == {'a': 100, 'b': 200}

test_json_decode()



# Generated at 2022-06-24 08:18:23.370710
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("1") == 1
    assert json_decode("[]") == []
    assert json_decode("{}") == {}
    assert json_decode("null") is None
    
    

# Generated at 2022-06-24 08:18:26.853156
# Unit test for function json_encode
def test_json_encode():
    try:
        import ujson
        assert json_encode(10) == ujson.dumps(10) #'10'
    except ImportError:
        pass
    assert json_encode(10) == '10'
    assert json_encode('\"') == '"\\""'

# Generated at 2022-06-24 08:18:29.745724
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print('====test_parse_qs_bytes====')
    p = parse_qs_bytes(b"a=1&b=2")
    print(p)
test_parse_qs_bytes()


# Generated at 2022-06-24 08:18:34.408218
# Unit test for function json_decode
def test_json_decode():
    json_decode('"\\""')

# Make sure that ascii() recodes opaque byte strings.
#
# The native json module doesn't handle this (it converts to Latin-1
# and then back to UTF-8), but our json module should.

# Generated at 2022-06-24 08:18:41.648471
# Unit test for function url_escape
def test_url_escape():
  assert url_escape("/?foo=bar&baz=bang") == "%2F%3Ffoo%3Dbar%26baz%3Dbang"
  assert url_escape("/?foo=bar&baz=bang", plus=False) == "%2F%3Ffoo%3Dbar%26baz%3Dbang"
  # Default behavior is to use plus
  assert url_escape("value with spaces") == "value+with+spaces"
  # But plus can be disabled
  assert url_escape("value with spaces", plus=False) == "value%20with%20spaces"
  assert url_escape("spaces and !*'()@#$^&~") == "spaces+and+%21%2A%27%28%29%40%23%24%5E%26%7E"
  assert url

# Generated at 2022-06-24 08:18:48.654713
# Unit test for function json_decode
def test_json_decode():
    tests = [
        ("null", "null"),
        ("true", "true"),
        ("false", "false"),
        ("42", "42"),
        ("4.2", "4.2"),
        ("\"asdf\"", "\"asdf\""),
        ("[1, 2, 3]", "1, 2, 3"),
        ("{\"a\": 1, \"b\": 2}", "a=1 b=2"),
    ]
    for (decoded, encoded) in tests:
        assert json_decode(encoded) == decoded, encoded


# Generated at 2022-06-24 08:18:52.946197
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    # from tornado.escape import xhtml_unescape
    print(xhtml_unescape('&lt;'))
    return
# Unit test: $ python3 -m tornado.escape
test_xhtml_unescape()


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:18:59.521892
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://www.google.com/search?q=foo bar") == "http://www.google.com/search?q=foo+bar"
    assert url_escape("http://www.google.com/search?q=foo bar", plus=False) == "http://www.google.com/search?q=foo%20bar"
test_url_escape()
    
    

# Generated at 2022-06-24 08:19:08.428932
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([b'1', b'2', b'3']) == ['1', '2', '3']
    assert recursive_unicode((b'1', b'2', b'3')) == ('1', '2', '3')
    assert recursive_unicode({b'name': b'mu', b'age': 18}) == {'name': 'mu', 'age': 18}
    assert recursive_unicode([{b'name': b'mu', b'age': 18}, {b'name': b'sv', b'age': 19}]) == \
        [{'name': 'mu', 'age': 18}, {'name': 'sv', 'age': 19}]

# Generated at 2022-06-24 08:19:15.652446
# Unit test for function json_decode
def test_json_decode():
    @typing.overload
    def fun(a, b):
        pass

    @fun.register
    def _(a: int, b: str):
        pass

    @fun.register
    def _(a: float, b: (int, str)):
        pass

    b = {'a': 1, 'b': 'text'}
    a = json_decode('{"a": 1, "b": "text"}')
    fun(**a)



# Generated at 2022-06-24 08:19:17.852671
# Unit test for function url_unescape
def test_url_unescape():
    if url_unescape('http://www.tornadoweb.org/') != 'http://www.tornadoweb.org/':
        return False
    else:
        return True



# Generated at 2022-06-24 08:19:20.742581
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == '<'
    assert xhtml_unescape("&#60;") == "<"



# Generated at 2022-06-24 08:19:26.203764
# Unit test for function xhtml_escape
def test_xhtml_escape():
    try:
        xhtml_escape("1 & 1")
        xhtml_escape("test <test>")
        xhtml_escape("test 'test'")
        xhtml_escape("test \"test\"")
    except Exception as e:
        assert False, "Function xhtml_escape raised exception"
test_xhtml_escape()


_URL_ESCAPE_RE = re.compile(r"[^\w\-\.~:/?#\[\]@!$&'()*+,;=]")



# Generated at 2022-06-24 08:19:28.089872
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp; &#39; &#x33;') == '& \' !'


# Generated at 2022-06-24 08:19:33.042238
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(" \r\t ") == " "
    assert squeeze(" \r\t 123 abc  ") == "123 abc"
    assert squeeze("   123  abc  ") == "123 abc"
    assert squeeze("\r\n \r\n 123 \r\nabc  \r\n") == "123 abc"



# Generated at 2022-06-24 08:19:44.473605
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape("https://abc.com")
    url_unescape("https://abc.com", plus=True)
    url_unescape("https://abc.com", plus=False)
    url_unescape("https://abc.com", encoding=None)
    url_unescape("https://abc.com", encoding=None, plus=True)
    url_unescape("https://abc.com", encoding=None, plus=False)
    url_unescape("https://abc.com", encoding="utf-8")
    url_unescape("https://abc.com", encoding="utf-8", plus=True)
    url_unescape("https://abc.com", encoding="utf-8", plus=False)


# Generated at 2022-06-24 08:19:46.624603
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query_string = "foo=bar&foo=baz&blah=&foo=%c3%af"
    assert(parse_qs_bytes(query_string) == {"foo":[b'bar', b'baz', b'\xc3\xaf'], "blah":[b'']})



# Generated at 2022-06-24 08:19:55.427590
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('\n\n                                           \n \n\n') == ' '


# It's impossible to write a regex that matches all email addresses
# without matching something else that isn't an email address,
# so this is limited to the small subset of email addresses that we
# actually need for tornado's current usage.  (And if we ever need
# to match a broader range of addresses, we can make this smarter.)
# This regex is similar to the one in python's stdlib, but it doesn't
# allow quoted local parts, escapes, or whitespace.
_EMAIL_REGEX = re.compile(
    r'^[\w.!#$%&\'*+\-/=?\^`{|}~]+@[\w\-]+(?:\.[\w\-]+)+$'
)



# Generated at 2022-06-24 08:20:02.754868
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    d = parse_qs_bytes(b"a=1&b=2")
    assert d == {"a": [b"1"], "b": [b"2"]}
    assert isinstance(list(d.keys())[0], str)
    assert isinstance(d["a"][0], bytes)


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:20:06.854114
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'a':2}) == '{"a": 2}'
    assert json_encode({'a': 'ab</'}) == '{"a": "ab<\\/"}'

_JSON_DECODE_OPTIONS = {
    "strict": False
}



# Generated at 2022-06-24 08:20:09.762921
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('xé') == 'x%C3%A9'
    assert url_escape(1) == '1'
    assert url_escape(1, True) == '1'



# Generated at 2022-06-24 08:20:13.612722
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze(' \n\t I love \t\n  Python \n') == 'I love Python')


_HTML_TYPES = ("text/html", "application/xhtml+xml")



# Generated at 2022-06-24 08:20:18.518204
# Unit test for function linkify

# Generated at 2022-06-24 08:20:23.459770
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    s = xhtml_unescape("&lt;span&gt;")
    assert s == "<span>", "xhtml_unescape failed to unescape &lt;span&gt;"
    s = xhtml_unescape("&#xD835;")
    assert s == "𝍱", "xhtml_unescape failed to unescape &#xD835;"


# Generated at 2022-06-24 08:20:34.435068
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert(parse_qs_bytes('a=1&b=2') == {'a': ['1'], 'b': ['2']})
    assert(parse_qs_bytes('a=1&b=2&a=3', keep_blank_values=True) == {'a': ['1', '3'], 'b': ['2']})
    assert(parse_qs_bytes('a=1&b=2&a=3', strict_parsing=True) == {'a': ['3'], 'b': ['2']})
    assert(parse_qs_bytes('a=1;b=2;a=3', strict_parsing=True) == {'a': ['1', '3'], 'b': ['2']})

# Generated at 2022-06-24 08:20:36.236513
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;name&gt;&lt;/name&gt;') == '<name></name>'


# Generated at 2022-06-24 08:20:47.442668
# Unit test for function linkify
def test_linkify():
    #Test basic links
    assert(linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>')
    assert(linkify("https://example.com") == '<a href="https://example.com">https://example.com</a>')
    assert(linkify("http://ex-ample.com") == '<a href="http://ex-ample.com">http://ex-ample.com</a>')
    assert(linkify("https://ex-ample.com") == '<a href="https://ex-ample.com">https://ex-ample.com</a>')
    #Test www links
    assert(linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>')

# Generated at 2022-06-24 08:20:56.179840
# Unit test for function json_encode
def test_json_encode():
    from tornado.util import b
    import json
    print(json_encode({1: 2}))
    print(json.dumps({1: 2}))
    print(type(json_encode({1: 2})))
    print(type(json.dumps({1: 2})))

# Since the json module is much faster than simplejson,
# prefer it if it is available.
try:
    from json.encoder import JSONEncoder
except ImportError:
    try:
        from simplejson.encoder import JSONEncoder
    except ImportError:
        JSONEncoder = None  # type: ignore

# Note that we have to pass in json_encode as a kwarg to fix a pyflakes
# error on Python 3.5.2 with the PyCharm inspections. The error is:
# Local variable 'json

# Generated at 2022-06-24 08:21:07.085757
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "a+%C3%A9+and+%26+%26="
    d = parse_qs_bytes(qs)

    assert d == {"a": ["\xe9"], "and": ["&", "&="]}
test_parse_qs_bytes()

# to_unicode and to_basestring are helpful for Python 3
# compatibility in cases where str() or "".format() must be used
# on byte or unicode strings.  When dealing solely with unicode
# strings throughout an application, they are unnecessary and
# potentially harmful (they are slow on PyPy).  However, when
# forced to interact with a system that provides utf-8-encoded
# bytestrings, they can be useful:
#    u = to_unicode(s)
#    b = to_basestring(u)



# Generated at 2022-06-24 08:21:12.765275
# Unit test for function native_str
def test_native_str():
    assert to_unicode("abc") == u"abc"
    assert to_unicode(u"abc") == u"abc"
    assert to_unicode(b"abc") == u"abc"
    assert to_unicode(None) is None
    try:
        to_unicode(123)
        assert False, "expected exception"
    except TypeError:
        pass



# Generated at 2022-06-24 08:21:15.496591
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div></div>") == "&lt;div&gt;&lt;/div&gt;"



# Generated at 2022-06-24 08:21:18.612197
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = ["hello", "world"]
    recursive_unicode(obj)
    assert obj == ["hello", "world"]
    obj = {"key": "value"}
    recursive_unicode(obj)
    assert obj == {"key": "value"}


# Generated at 2022-06-24 08:21:20.449154
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print(parse_qs_bytes(b'a=1&b=2'))

test_parse_qs_bytes()



# Generated at 2022-06-24 08:21:24.662354
# Unit test for function url_escape
def test_url_escape():
    print(url_escape('http://www.apirelease.com/?x=1',plus=False))

# Generated at 2022-06-24 08:21:32.470555
# Unit test for function linkify
def test_linkify():
    assert linkify('http://www.example.com/foo/') == '<a href="http://www.example.com/foo/">http://www.example.com/foo/</a>'

test_linkify()

_HTML_UNESCAPE_RE = re.compile(r"&(#[0-9]+|#x[0-9a-fA-F]+|\w+);", re.UNICODE)



# Generated at 2022-06-24 08:21:36.876876
# Unit test for function json_encode
def test_json_encode():
    if isinstance(json_encode({"a": "<"}), str):
        print('json_encode func success')
    else:
        print('json_encode func error')
test_json_encode()


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:21:41.255722
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   123   ") == "123"
    assert squeeze("   foo   bar   gogogo   ") == "foo bar gogogo"
    assert squeeze("   ") == ""


# In order to prevent XSS attacks, we escape all HTML output.

# Generated at 2022-06-24 08:21:51.423546
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("test") == "test"
    assert xhtml_escape("<b>") == "&lt;b&gt;"
    assert xhtml_escape("&lt;") == "&amp;lt;"
    assert xhtml_escape("&<>") == "&amp;&lt;&gt;"
    assert xhtml_escape("<>&") == "&lt;&gt;&amp;"
    assert xhtml_escape("'") == "&#39;"
    assert xhtml_escape("&#39;") == "&amp;#39;"
# ------------------------------------------------------------------------------



# Generated at 2022-06-24 08:21:57.849030
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    from tornado.util import bytes_type
    assert xhtml_unescape("a&amp;b") == "a&b"
    assert isinstance(xhtml_unescape("a&amp;b"), str)
    assert xhtml_unescape("a&amp;b") != b"a&b"
    assert xhtml_unescape("a&amp;b") == "a&b"
    assert xhtml_unescape("a&#39;b") == "a'b"
    assert xhtml_unescape("a&#39;b") == b"a'b".decode()
    assert xhtml_unescape("a&#39;b".encode()) == b"a'b".decode()


# Generated at 2022-06-24 08:21:59.185015
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a     b") == "a b"



# Generated at 2022-06-24 08:22:04.733781
# Unit test for function utf8
def test_utf8():
    # utf8() is quite trivial, but here's a unit test anyway
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8("\xc3\xa9") == b"\xc3\xa9"
    assert utf8(u"\u00e9") == b"\xc3\xa9"
    
    
    
    


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:22:14.262525
# Unit test for function json_encode
def test_json_encode():
    test_dict = {'a': 1, 'b': 2}
    json_test_dict = '{"a": 1, "b": 2}'
    json_test_dict_escaped = json_encode(test_dict)
    if not isinstance(json_test_dict_escaped, str):
        raise Exception("Not a valid string")
    elif json_test_dict == json_test_dict_escaped:
        raise Exception("The string is not escaped")
    elif json_test_dict != json_encode(test_dict):
        raise Exception("The string is not escaped correctly")
    else:
        print("test_json_encode success")

test_json_encode()


# Generated at 2022-06-24 08:22:24.408053
# Unit test for function utf8
def test_utf8():
    # test normal str
    s1 = "hello word"
    s2 = utf8(s1)
    assert isinstance(s2, bytes)
    assert s2 == b"hello word"

    # test bytes
    s1 = b"hello word"
    s2 = utf8(s1)
    assert isinstance(s2, bytes)
    assert s2 == b"hello word"

    # test None
    s1 = None
    s2 = utf8(s1)
    assert s2 == None

    # test unicode
    s1 = "你好"
    s2 = utf8(s1)
    assert isinstance(s2, bytes)
    assert s2 == b"\xe4\xbd\xa0\xe5\xa5\xbd"

    # test error

# Generated at 2022-06-24 08:22:32.639777
# Unit test for function utf8
def test_utf8():
    if isinstance(utf8(b"foo"), bytes):
        assert utf8(b"foo") == b"foo"
        assert utf8("foo") == b"foo"
        assert utf8(None) is None
        try:
            # This function is not meant to be used with non-ASCII characters.
            # If you want unicode, you should use the to_unicode function.
            utf8("f\xc3\xb6o")
            assert False, "Expected a non-ASCII character to raise an error"
        except UnicodeError:
            pass



# Generated at 2022-06-24 08:22:35.290318
# Unit test for function native_str
def test_native_str():
    assert str("abc") == "abc"


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:22:46.158955
# Unit test for function native_str
def test_native_str():
    assert native_str("abc") == "abc"
    assert native_str(b"abc") == "abc"
    assert native_str(None) == None
    assert native_str(1) == "1"
    assert native_str(123.456) == "123.456"
    assert native_str(["a", 123, None]) == "['a', 123, None]"
    assert native_str(1, "utf-8") == "1"
    assert native_str(b"1", "utf-8") == "1"
    assert native_str(b"1", "ascii") == "1"
    assert native_str(1, "ascii") == "1"
    assert native_str({"a": 123}) == "{'a': 123}"

# Generated at 2022-06-24 08:22:50.566021
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a   b   c   ") == "a b c"
    assert squeeze("a\nb\nc\nd\n") == "a b c d"

#_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:23:01.769740
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("https://www.google.com/search?q=youtube") == "https%3A%2F%2Fwww.google.com%2Fsearch%3Fq%3Dyoutube"

# Generated at 2022-06-24 08:23:08.222700
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # type: () -> None
    assert xhtml_escape('<>"&\'') == '&lt;&gt;&quot;&amp;&#39;'
    assert xhtml_escape('>') == '&gt;'
    assert xhtml_escape(u"<>\"'&") == u'&lt;&gt;&quot;&#39;&amp;'
    assert xhtml_escape(b"<>\"'&") == b'&lt;&gt;&quot;&#39;&amp;'



# Generated at 2022-06-24 08:23:12.480970
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(b'\xc3') == '"\\u00c3"'
    assert json_encode({'\xc3': 3}) == '{"\\u00c3": 3}'
    assert json_encode(b'<script>') == '"<script>"'

# Generated at 2022-06-24 08:23:17.434445
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{}') == {}
    assert json_decode('{"k1": "v1", "k2": "v2"}') == {'k1': 'v1', 'k2': 'v2'}
    assert json_decode('"v"') == 'v'
    assert json_decode('30') == 30
    assert json_decode('1.1') == 1.1


# Generated at 2022-06-24 08:23:28.805273
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b"&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape("&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"

_JSON_ESC = re.compile(r'[\x00-\x1f\\"\b\f\n\r\t]')

# Generated at 2022-06-24 08:23:35.466316
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = {"a": b"asdf", "b": u"\u00fcmlaut", "c": [b"asdf", u"\u00fcmlaut"]}
    recursive_unicode(x)
    assert isinstance(x.get("a"), str)
    assert isinstance(x.get("b"), str)
    assert isinstance(x.get("c"), list)



# Generated at 2022-06-24 08:23:37.708563
# Unit test for function url_escape
def test_url_escape():
    x = url_escape("http://www.baidu.com")
    assert x == "http%3A%2F%2Fwww.baidu.com"


# Generated at 2022-06-24 08:23:43.283481
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    str1 = "&#20013;&#25991;"
    str2 = "&#x4e2d;&#x56fd;"
    str3 = "&#25991;&#x4e2d;"
    print(xhtml_unescape(str1))
    print(xhtml_unescape(str2))
    print(xhtml_unescape(str3))
test_xhtml_unescape()



# Generated at 2022-06-24 08:23:49.102104
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b"<") == "&lt;"
    assert xhtml_escape(b"a < b") == "a &lt; b"

    assert xhtml_escape(b"a < b") != "a > b"
    assert xhtml_escape(b"a < b") != "_XHTML_ESCAPE_DICT"


# Generated at 2022-06-24 08:23:51.558392
# Unit test for function url_escape
def test_url_escape():
    print('url_escape:',url_escape('c%3Dd'))


# Generated at 2022-06-24 08:23:52.858119
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  abc  bcd  ') == 'abc bcd'



# Generated at 2022-06-24 08:24:02.780748
# Unit test for function utf8
def test_utf8():
    assert test(utf8, 'a') == 'a'
    assert test(utf8, 'a').__class__ == str
    assert test(utf8, 'aasdf') == 'aasdf'
    assert test(utf8, 'aaßdf') == 'aaßdf' # utf-8
    assert test(utf8, u'aaßdf') == 'aaßdf' # utf-8
    try:
        assert test(utf8, u'aa\0df') == 'aa\x00df' # utf-8
        raise ValueError('test failed because utf8 should not accept \0 in input')
    except ValueError:
        pass

# Generated at 2022-06-24 08:24:09.920710
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query_string = 'error=access_denied&error_description=user+denied+your+request'
    query_string = query_string.encode()
    print(parse_qs_bytes(query_string))
test_parse_qs_bytes()

# _UTF8_TYPES were added in Python 3.6
_UTF8_TYPES = (bytes,)
try:
    _UTF8_TYPES += (str,)
except NameError:
    pass



# Generated at 2022-06-24 08:24:15.730561
# Unit test for function recursive_unicode
def test_recursive_unicode():
    d = {"a": ["b", "c".encode("utf-8")], "b": "c".encode("utf-8"), "c": 1}
    unicode_d = recursive_unicode(d)
    assert type(unicode_d['b']) == str
    assert type(unicode_d["a"][1]) == str
    assert type(unicode_d.keys()) == list
    assert type(unicode_d.values()) == list
    assert type(unicode_d.items()) == list



# Generated at 2022-06-24 08:24:25.717414
# Unit test for function recursive_unicode
def test_recursive_unicode():
    test_obj = {b'a': 'test'}
    result = recursive_unicode(test_obj)
    assert isinstance(result, dict)
    assert isinstance(result.keys(), str)
    assert isinstance(result.values(), str)
    test_obj = [b'a', 'test', 1]
    result = recursive_unicode(test_obj)
    assert isinstance(result, list)
    assert isinstance(result[0], str)
    assert isinstance(result[1], str)
    assert isinstance(result[2], int)
    test_obj = (b'a', 'test', 1)
    result = recursive_unicode(test_obj)
    assert isinstance(result, tuple)
    assert isinstance(result[0], str)
    assert isinstance(result[1], str)

# Generated at 2022-06-24 08:24:32.710581
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    import tornado.testing
    ascii_qs = b"foo=bar"
    parsed = parse_qs_bytes(ascii_qs)
    tornado.testing.assert_equal(parsed, {b"foo": [b"bar"]})
    latin1_qs = b"foo=\xe9"
    parsed = parse_qs_bytes(latin1_qs)
    tornado.testing.assert_equal(parsed, {b"foo": [b"\xe9"]})



# Generated at 2022-06-24 08:24:38.867461
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({b'a': b'a', b'unicode': 'b'}) == {'a': 'a', 'unicode': 'b'}, \
    "recursive_unicode should convert values from bytes to string."

    assert recursive_unicode(['a', 'b']) == ['a', 'b'], \
    "recursive_unicode should not convert list of strings."

    assert recursive_unicode(['a', b'b']) == ['a', 'b'], \
    "recursive_unicode should convert list of mixed types to list of strings."
    


# Generated at 2022-06-24 08:24:42.372428
# Unit test for function native_str
def test_native_str():
    assert native_str(u"foo") == "foo"
    assert native_str(b"foo") == "foo"



# Generated at 2022-06-24 08:24:51.071163
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('http://www.google.com/search?q=tornado+web+server&amp;ie=utf-8&amp;oe=utf-8&amp;aq=t&amp;rls=org.mozilla:en-US:official&amp;client=firefox-a',
        plus=True) == 'http://www.google.com/search?q=tornado web server&ie=utf-8&oe=utf-8&aq=t&rls=org.mozilla:en-US:official&client=firefox-a'

# Generated at 2022-06-24 08:24:55.072441
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'key1': b'value1', 'key2': [1, 2, b'3']}) == {'key1': 'value1', 'key2': [1, 2, '3']}



# Generated at 2022-06-24 08:25:02.890460
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode("hello") == "hello"
    assert recursive_unicode({"hi": "there"}) == {"hi": "there"}
    assert recursive_unicode({"hi": "there".encode("utf-8")}) == {"hi": "there"}
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode([1, 2, "a".encode("utf-8")]) == [1, 2, "a"]
    assert recursive_unicode((1, 2, "a".encode("utf-8"))) == (1, 2, "a")



# Generated at 2022-06-24 08:25:04.871465
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;a href='test&gt;'&gt;") == "<a href='test>'>"

_BASESTRING_TYPES = (type(u""), bytes)

# Generated at 2022-06-24 08:25:09.329460
# Unit test for function json_decode
def test_json_decode():
    print(json_decode('["foo", {"bar":["baz", null, 1.0, 2]}]'))
    print('["foo", {"bar":["baz", null, 1.0, 2]}]')


# json_encode and json_decode currently assume that the encodings of
# input strings are utf8.  This may change in the future.
#
# This is a relatively low-level function for converting a string
# (bytestring in python2, unicode in python3) to a utf8-encoded bytestring.
# This function comes from toronado.escape.utf8().

# Generated at 2022-06-24 08:25:15.006037
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#38;") == "&"
    assert xhtml_unescape("&#x26;") == "&"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#38&#x26;&amp;") == "&&"
    assert xhtml_unescape("&amp") == "&amp"


# Generated at 2022-06-24 08:25:17.974630
# Unit test for function url_escape
def test_url_escape():
        url = "http://www.google.com"
        assert url_escape(url) == "http%3A%2F%2Fwww.google.com"



# Generated at 2022-06-24 08:25:27.026764
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.facebook.com") == '<a href="http://www.facebook.com">http://www.facebook.com</a>'
    assert linkify("www.facebook.com") == '<a href="http://www.facebook.com">www.facebook.com</a>'
    assert linkify("www.facebook.com", require_protocol=True) == 'www.facebook.com'
    assert linkify("www.facebook.com", require_protocol=True, permitted_protocols=["http"]) == '<a href="http://www.facebook.com">www.facebook.com</a>'

# Generated at 2022-06-24 08:25:34.775076
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = xhtml_escape('"<<=>"&"')
    res = '&quot;&lt;&lt;=&gt;&quot;&amp;&quot;'
    assert res == value
    value = xhtml_escape("'<<=>&'")
    res = "&#39;&lt;&lt;=&gt;&amp;&#39;"
    assert res == value
    value = xhtml_escape('<<=>&')
    res = "&lt;&lt;=&gt;&amp;"
    assert res == value

_BASESTRING_TYPES = (str, bytes)  # type: Tuple[Any, ...]



# Generated at 2022-06-24 08:25:45.534825
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('') == ''
    assert xhtml_unescape('&amp;&lt;&gt;&quot;&apos;') == '&<>"\''
    assert xhtml_unescape('&#38;&#60;&#62;&#34;&#39;') == '&<>"\''
    assert xhtml_unescape('&amp;amp;') == '&amp;'
    assert xhtml_unescape('&amp;#38;') == '&#38;'
test_xhtml_unescape()
_URL_ESCAPE_RE = re.compile(r"[a-fA-F0-9]{2}")

# Generated at 2022-06-24 08:25:52.078853
# Unit test for function recursive_unicode
def test_recursive_unicode():
    dd = {
        'a': 1,
        'b': 'b',
        'c': b'd',
        'd': [
            {
                'a': 1,
                'b': b'b'
            }
        ],
        'e': [
            {
                'a': 1,
                'b': b'b'
            }
        ]
    }
    print(dd)
    print(recursive_unicode(dd))
# test_recursive_unicode()



# Generated at 2022-06-24 08:25:55.681701
# Unit test for function utf8
def test_utf8(): assert utf8("a") == b"a"


_TO_UNICODE_TYPES = (unicode_type, type(None))

if typing.TYPE_CHECKING:
    _TO_UNICODE_TYPES += (bytes,)



# Generated at 2022-06-24 08:26:01.907137
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('https%3A%2F%2Fdeveloper.android.com%2Findex.html') == "https://developer.android.com/index.html"
test_url_unescape()



# Generated at 2022-06-24 08:26:08.582267
# Unit test for function linkify
def test_linkify():
    print(linkify('check out http://example.com/a-letter/'))
    print(linkify('check out www.com'))
    print(linkify('check out www.com', require_protocol=True))
    print(linkify('check out http://example.com/a-letter/?a=b&c=d', shorten=True))
    print(
        linkify(
            'check out http://example.com/a-letter-with-a-really-long-slug-that-gets-shortened/?a=b&c=d',  # noqa: E501
            shorten=True,
        )
    )

# Generated at 2022-06-24 08:26:13.349245
# Unit test for function json_decode
def test_json_decode():
    json_str = '{"name":"larry","age":18}'
    result = json_decode(json_str)
    print(type(result))
    print(result)
#test_json_decode()

# Generated at 2022-06-24 08:26:17.087419
# Unit test for function json_decode
def test_json_decode():
    json_decode('[1, 2, 3]')
    json_decode('{"age": 39, "name": "John"}')



# Generated at 2022-06-24 08:26:27.494787
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    origin_str = "&#120436;&#120436;"
    print(xhtml_unescape(origin_str))
    print(type(xhtml_unescape(origin_str)))
# Test case for function xhtml_unescape
test_xhtml_unescape()

# @overload
# def json_decode(value: str) -> Any: ...

# @overload
# def json_decode(value: bytes) -> Any: ...

# def json_decode(value: Union[str, bytes]) -> Any:
#    """Returns Python objects for the given JSON string."""
#    # TODO: json_decode should take an argument for the encoding of
#    #  the input.  Decoding from UTF-8 should be the default, but other
#    #  encodings should be supported.

# Generated at 2022-06-24 08:26:37.763890
# Unit test for function json_decode
def test_json_decode():
    def test_json_decode_data_set():
        L = [
            ([1, 2, 3], [1, 2, 3]),
            ({"a": 1, "b": 2}, {"a": 1, "b": 2}),
        ]
        for data, expected in L:
            yield {
                "data": data,
                "expected": expected,
            }

    def test_json_decode_exception(data):
        try:
            result = json_decode(data)
        except Exception:
            return True
        else:
            return False

    for data_set in test_json_decode_data_set():
        data = json_encode(data_set["data"])
        result = json_decode(data)
        expected = data_set["expected"]
        assert result == expected

# Generated at 2022-06-24 08:26:41.734477
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('user%20email@example.com') == 'user%20email%40example.com'
    assert url_escape('user email@example.com') == 'user+email%40example.com'
test_url_escape()



# Generated at 2022-06-24 08:26:49.617238
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    s = "key=val&key=val2&key=val%20with%20spaces&boolean"
    assert parse_qs_bytes(s) == {
        "key": [b"val", b"val2", b"val with spaces"],
        "boolean": [b""],
    }
    assert parse_qs_bytes(s.encode("utf8")) == {
        "key": [b"val", b"val2", b"val with spaces"],
        "boolean": [b""],
    }
    assert parse_qs_bytes(s, keep_blank_values=True) == {
        "key": [b"val", b"val2", b"val with spaces"],
        "boolean": [b""],
    }

# Generated at 2022-06-24 08:27:01.372118
# Unit test for function xhtml_unescape

# Generated at 2022-06-24 08:27:07.980776
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'http://www.google.com/search?q=%20') == 'http://www.google.com/search?q= '
    assert url_unescape('%e4%b8%ad%e6%96%87') == '中文'
    assert url_unescape('%e4%b8%ad%e6%96%87', encoding=None) == b'\xe4\xb8\xad\xe6\x96\x87'
    assert url_unescape('%E4%B8%AD%E6%96%87', encoding=None) == b'\xe4\xb8\xad\xe6\x96\x87'


# Generated at 2022-06-24 08:27:11.814548
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str(), str)
    assert isinstance(native_str('foo'), str)
    assert isinstance(native_str(b'foo'), str)
    assert isinstance(native_str(b'foo', 'utf-8'), str)
    assert isinstance(native_str(u'foo'), str)



# Generated at 2022-06-24 08:27:16.583686
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  a  b ') == 'a b'
    assert squeeze('  a  b ') == 'a b'



# Generated at 2022-06-24 08:27:28.128484
# Unit test for function linkify
def test_linkify():
    print("test_linkify")
    # All the test cases are taken from the original unit tests of linkify
    # function in tornado.

# Generated at 2022-06-24 08:27:35.304492
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    _string = "&lt;&lt;&lt;"
    _string_converted = "<<<"
    assert xhtml_unescape(_string) == _string_converted, "xhtml_unescape doesn't work"

_BASESTRING_TYPES = (str, bytes)  # type: tuple

if hasattr(html.entities, "name2codepoint"):
    _HTML_UNICODE_MAP = html.entities.name2codepoint.copy()  # type: ignore
else:
    _HTML_UNICODE_MAP = {}  # type: ignore