

# Generated at 2022-06-24 08:17:39.744357
# Unit test for function url_unescape
def test_url_unescape():
    import io
    import sys

    # save stdout
    stdout = sys.stdout
    # set stdout to a io.StringIO object
    sys.stdout = io.StringIO()

    # test url_unescape with argument encoding as None
    url_unescape(value=b"http%3A%2F%2Fwww.google.com%2F", encoding=None)
    # get stdout
    output1 = sys.stdout.getvalue()
    # test url_unescape with argument encoding as utf-8
    url_unescape(value=b"http%3A%2F%2Fwww.google.com%2F", encoding="utf-8")
    # get stdout
    output2 = sys.stdout.getvalue()

    # print output1 and output2 so that mypy is happy

# Generated at 2022-06-24 08:17:46.459068
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<b>hi</b>") == "&lt;b&gt;hi&lt;/b&gt;"
    assert xhtml_escape("<b>hi</b>") != "&lt;b&gt;hi&lt;/b>"
    assert xhtml_escape("<b>hi</b>") != "&lt;b&gt;hi</b>"
    assert xhtml_escape("<b>hi</b>") == "&lt;b&gt;hi&lt;/b>"


# Generated at 2022-06-24 08:17:48.199029
# Unit test for function squeeze
def test_squeeze():
    value = "hello world     how are you"
    ans = squeeze(value)
    assert ans == "hello world how are you"


# Generated at 2022-06-24 08:17:56.326307
# Unit test for function json_decode
def test_json_decode():
    # type: () -> None
    s = '''[
        {
            "Name": "Wartortle",
            "Attack": 63,
            "Defense": 80,
            "Sp_Atk": 65,
            "Sp_Def": 80,
            "Speed": 58
        },
        {
            "Name": "Metapod",
            "Attack": 20,
            "Defense": 55,
            "Sp_Atk": 25,
            "Sp_Def": 25,
            "Speed": 30
        }
    ]'''

    assert json_decode(s) == json.loads(s)



# Generated at 2022-06-24 08:18:02.397785
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    import urllib.parse
    import copy
    a = {b'asdf': [b'asdf'], 'ghjk': ['ghjk']}
    assert a == parse_qs_bytes(urllib.parse.urlencode(a))
    b = {b'asdf': [b'asdf', b'qwer'], 'ghjk': ['ghjk']}
    assert b == parse_qs_bytes(urllib.parse.urlencode(b))
    c = copy.deepcopy(b)
    c[b'asdf'] = [b'asdf']
    assert c == parse_qs_bytes(urllib.parse.urlencode(c))
    d = copy.deepcopy(b)
    d['asdf'] = ['asdf', 'qwer']
    assert d

# Generated at 2022-06-24 08:18:07.396093
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('http://www.google.com/') == 'http%3A%2F%2Fwww.google.com%2F'
    assert url_escape('http://www.google.com/', plus=False) == 'http%3A%2F%2Fwww.google.com%2F'



# Generated at 2022-06-24 08:18:14.157880
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('a < b') == 'a &lt; b'
    assert xhtml_escape('a &gt; b') == 'a &amp;gt; b'
    assert xhtml_escape('a &amp; b') == 'a &amp; b'
    assert xhtml_escape('a & b') == 'a &amp; b'
    assert xhtml_escape('a\'"&b') == 'a&#39;&quot;&amp;b'


# Generated at 2022-06-24 08:18:19.442069
# Unit test for function utf8
def test_utf8():
    assert b"123"==utf8("123")
    assert b"123"==utf8(b"123")
    try:
        utf8(123)
        assert False
    except TypeError:
        pass

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:21.768868
# Unit test for function squeeze
def test_squeeze():
    return squeeze("    foo    bar    \n\n  \t   qux ") == 'foo bar qux'



# Generated at 2022-06-24 08:18:29.510493
# Unit test for function linkify

# Generated at 2022-06-24 08:18:32.157091
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert '&lt;a>' == xhtml_escape('<a>')



# Generated at 2022-06-24 08:18:38.091188
# Unit test for function utf8
def test_utf8():  # pragma: no cover
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(None) is None
    try:
        utf8(b"abc")
        assert False
    except TypeError:
        pass
    try:
        utf8(1)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-24 08:18:41.876235
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("a=1&b=2") == {"a": [b"1"], "b": [b"2"]}
    assert parse_qs_bytes("a=1&a=2") == {"a": [b"1", b"2"]}



# Generated at 2022-06-24 08:18:45.863459
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a  b c   d") == "a b c d"
    assert squeeze("a\nb\tc\nd") == "a b c d"
    assert squeeze("\ta\r\nb\tc\nd  ") == "a b c d"


# Generated at 2022-06-24 08:18:50.763346
# Unit test for function squeeze
def test_squeeze():
    print(squeeze('  foo   bar    baz  '))
# for i in range(4):
#     test_squeeze()

# workaround to fix a bug in the escape module in python 3.2
# as per http://bugs.python.org/issue4978
if urllib.parse.__dict__["_ALWAYS_SAFE"].find("~") == -1:
    urllib.parse._ALWAYS_SAFE += "~"



# Generated at 2022-06-24 08:18:58.721425
# Unit test for function squeeze
def test_squeeze():
    a = "abcd"
    b = "abcd "
    c = " abcd"
    d = " abcd "
    e = " "
    f = " "*1000
    g = " a b   c"
    assert squeeze(a) == a
    assert squeeze(b) == a
    assert squeeze(c) == a
    assert squeeze(d) == a
    assert squeeze(e) == e
    assert squeeze(f) == e
    assert squeeze(g) == "a b c"


# Generated at 2022-06-24 08:19:01.866607
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"description": "<script>console.log('hi');</script>"}) == '{"description": "<script>console.log(\'hi\');<\\/script>"}'



# Generated at 2022-06-24 08:19:12.573658
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'x=1&x=2&x=3')['x'] == [b'1', b'2', b'3']
    assert parse_qs_bytes(b'x=1&x=2&x=3', keep_blank_values=True)['x'] == [b'1', b'2', b'3']
    assert parse_qs_bytes(b'x=1&y=2') == {b'x': [b'1'], b'y': [b'2']}
    assert parse_qs_bytes(b'x=') == {b'x': [b'']}
    assert parse_qs_bytes(b'x=&y=2') == {b'x': [b''], b'y': [b'2']}

# Generated at 2022-06-24 08:19:19.580114
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    x1 = "&lt;&gt;"
    s1 = xhtml_unescape(x1)
    assert s1 == "<>"
    x2 = "&gt;"
    s2 = xhtml_unescape(x2)
    assert s2 == ">"

# Generated at 2022-06-24 08:19:23.194452
# Unit test for function json_encode
def test_json_encode():
    example = json_encode({
        'a': 1,
        'b': 2
    })
    assert len(example) == 9

_JSON_DECODE_FUNC: Optional[Callable[[str], Any]] = None



# Generated at 2022-06-24 08:19:24.469206
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"



# Generated at 2022-06-24 08:19:28.348625
# Unit test for function url_unescape
def test_url_unescape():
    try:
        url_unescape()
    except TypeError as e:
        print('TypeError raised as expected')

test_url_unescape()



# Generated at 2022-06-24 08:19:31.865702
# Unit test for function json_encode
def test_json_encode():
    l = ["/", "//", "/foo", "foo/", "foo//bar"]
    assert json_encode(l) == '["/", "//", "/foo", "foo/", "foo//bar"]'



# Generated at 2022-06-24 08:19:45.466051
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    import pytest
    qs = 'test=test_string&test=another_test_string'
    result = parse_qs_bytes(qs)
    expected = {'test': [b'test_string', b'another_test_string']}
    assert result == expected
    qs = 'test=test_string&test=another_test_string&test=&&='
    result = parse_qs_bytes(qs)
    expected = {'test': [b'test_string', b'another_test_string', b'', b'', b'']}
    assert result == expected
    qs = 'version=1.0&db=enwiki&list=search&srwhat=text&srsearch=test'
    result = parse_qs_bytes(qs)

# Generated at 2022-06-24 08:19:54.792736
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"") == {}
    assert parse_qs_bytes(b"=") == {"": [""]}
    assert parse_qs_bytes(b"=a") == {"": ["a"]}
    assert parse_qs_bytes(b"a=") == {"a": [""]}
    assert parse_qs_bytes(b"a=1") == {"a": ["1"]}
    assert parse_qs_bytes(b"&a=1") == {"a": ["1"]}
    assert parse_qs_bytes(b"a=1&b=2") == {"a": ["1"], "b": ["2"]}
    assert parse_qs_bytes(b"a=1&a=2") == {"a": ["1", "2"]}

# Generated at 2022-06-24 08:20:06.946334
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"foo=1&foo=2", strict_parsing=True) == {"foo": [b"1", b"2"]}
    assert parse_qs_bytes(b"foo", strict_parsing=True) == {"foo": [b""]}
    assert (
        parse_qs_bytes(b"foo=1;foo=2", strict_parsing=True)
        == parse_qs_bytes(b"foo=1&foo=2", strict_parsing=True)
    )
    assert (
        parse_qs_bytes(b"foo=1&foo=2&foo=3", strict_parsing=True)
        == {"foo": [b"1", b"2", b"3"]}
    )

# Generated at 2022-06-24 08:20:09.845875
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(("foo", b"bar", {"baz": b"flibble"})) == (
        "foo",
        "bar",
        {"baz": "flibble"},
    )



# Generated at 2022-06-24 08:20:12.280875
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"


# Generated at 2022-06-24 08:20:19.218265
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes('state=%2Fprofile&session_state=9064fdf099ff26c353d1f9ffa9e8cfb7c45d8055..b016', keep_blank_values=False, strict_parsing=False)
    for k, v in result.items():
        print(k,v)
    assert 'state' in result
    assert 'session_state' in result


# Generated at 2022-06-24 08:20:23.702500
# Unit test for function url_unescape
def test_url_unescape():
    value: str = "abc"
    url_unescape(value, encoding=None, plus=True)
    url_unescape(value, encoding=None, plus=False)
    url_unescape(value, encoding="utf-8", plus=True)
    url_unescape(value, encoding="utf-8", plus=False)



# Generated at 2022-06-24 08:20:26.566093
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%20') == ' '
    assert url_unescape('%26') == '&'
    
#test_url_unescape()



# Generated at 2022-06-24 08:20:29.526318
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&lt;&#39;&quot;&amp;&gt;") == r"<'\"&>"



# Generated at 2022-06-24 08:20:31.100700
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<test>")=="&lt;test>"


# Generated at 2022-06-24 08:20:34.853638
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;div&gt;') == '<div>'
    assert xhtml_unescape('&lt;&amp;') == '<&'
    assert xhtml_unescape('&#60;div&#62;') == '<div>'
    assert xhtml_unescape('&#039;') == "'"



# Generated at 2022-06-24 08:20:37.388509
# Unit test for function json_decode
def test_json_decode():
    s = json_encode({'data': 'test'})
    print(s)
    ss = json_decode(s)
    print(ss)

# test_json_decode()

_UTF8_TYPES = (bytes, type(None))  # type: typing.TypeVar



# Generated at 2022-06-24 08:20:48.925116
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    r = parse_qs_bytes(b"a=1&b=2")
    assert r == {"a": [b"1"], "b": [b"2"]}
    r = parse_qs_bytes(u"a=1&b=2", strict_parsing=True)
    assert r == {"a": [b"1"], "b": [b"2"]}
    r = parse_qs_bytes(b"a=1&b=2&a=3", strict_parsing=True)
    assert r == {"a": [b"1", b"3"], "b": [b"2"]}
    r = parse_qs_bytes(b"a&b=2", strict_parsing=True)
    assert r == {"a": [b""], "b": [b"2"]}



# Generated at 2022-06-24 08:20:57.873672
# Unit test for function url_unescape
def test_url_unescape():
    v = url_escape("this is a test")
    assert url_unescape(v) == 'this is a test'
    v = url_escape("this is a test", plus=False)
    assert url_unescape(v) == 'this is a test'
    v = url_escape("this is a test")
    assert url_unescape(v, "utf-8") == 'this is a test'
    v = url_escape("this is a test", plus=False)
    assert url_unescape(v, "utf-8") == 'this is a test'
    v = url_escape(b"this is a test")
    assert url_unescape(v, None) == b'this is a test'



# Generated at 2022-06-24 08:21:01.774471
# Unit test for function url_escape
def test_url_escape():
    import urllib
    urllib.parse.quote(b'hello world')
    urllib.parse.quote_plus(b'hello world')
    url_escape(b'hello world')
    url_escape(b'hello world', plus=False)



# Generated at 2022-06-24 08:21:09.312652
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert b"foo=bar" in parse_qs_bytes(b"foo=bar&foo=baz")["foo"]
    assert b"bar" in parse_qs_bytes(b"foo=bar&foo=baz")["foo"]
    assert b"baz" in parse_qs_bytes(b"foo=bar&foo=baz")["foo"]

    assert parse_qs_bytes(b"foo=1")["foo"][0] == b"1"
    assert parse_qs_bytes(b"foo=1")["foo"][0] == b"1"



# Generated at 2022-06-24 08:21:13.852191
# Unit test for function json_decode
def test_json_decode():
    j = '{"d": {"a": ["hello"]}}'
    print(json_decode(j))  #{'d': {'a': ['hello']}}
    # print(json_decode(b'{"d": {"a": ["hello"]}}'))  #{'d': {'a': ['hello']}}
    # assert json_decode("") == "", "This is a test."
    # assert json_decode("1") == 1, "This is a test."
    # assert json_decode("{}") == {}, "This is a test."
    # assert json_decode("[]") == [], "This is a test."
    # assert json_decode("true") is True, "This is a test."
    # assert json_decode("false") is False, "This is a test."


# Generated at 2022-06-24 08:21:18.334024
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;') == "'"

_BASESTRING_TYPES = (str,)  # type: typing.Tuple[type, ...]
if typing.TYPE_CHECKING:
    _BASESTRING_TYPES += (bytes,)



# Generated at 2022-06-24 08:21:26.835484
# Unit test for function json_encode
def test_json_encode():
    assert json_encode("</") == '"<\\/"'

# Airbrake note: Calling these methods is considered difficult, since they
# are called at arbitrary places throughout the codebase. If you're looking to
# suppress errors from these methods, use the following regexes:
# json_encode(_value)
# json_decode(_value)
# _convert_entity(_match)
# url_escape(_value, _plus)
# url_unescape(_value, encoding, _plus)
# url_concat(*args)
# url_encode(obj, encoding, _check_circular)
# _format_timedelta(_seconds)
# _format_size(_size, _binary=False, _k=1024)



# Generated at 2022-06-24 08:21:28.972502
# Unit test for function native_str
def test_native_str():
    assert 'a' == native_str('a')
    assert 'a' == native_str(b'a')
    assert u'a' == native_str(u'a')



# Generated at 2022-06-24 08:21:30.937098
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('https://leetcode.com/problems/container-with-most-water') == 'https://leetcode.com/problems/container-with-most-water'


# Generated at 2022-06-24 08:21:33.809507
# Unit test for function native_str
def test_native_str():
    # type: (...) -> None
    # Test that native_str gets a native str from a unicode object.
    assert isinstance(native_str(u"foo"), str)
    # Test that native_str gets a native str from a bytestring.
    assert isinstance(native_str(b"foo"), str)
    # Test that native_str gets a native str from a non-string object.
    assert isinstance(native_str(object()), str)



# Generated at 2022-06-24 08:21:40.057433
# Unit test for function json_decode
def test_json_decode():
    a = dict()
    a["key1"] = "value1"
    print(json_decode(a))
    b = str()
    b = '{"key1":value1}'
    c = json_decode(b)
    print(c["key1"])
#test_json_decode()


# Generated at 2022-06-24 08:21:42.986621
# Unit test for function url_escape
def test_url_escape():
    res = url_escape('bar')
    assert res == 'bar'
test_url_escape()


# Generated at 2022-06-24 08:21:52.131623
# Unit test for function json_decode
def test_json_decode():
    import unittest

    import tornado.escape

    class EscapeTest(unittest.TestCase):
        def test_json_decode(self):
            self.assertEqual(tornado.escape.json_decode('["foo", {"bar":["baz", null, 1.0, 2]}]'),
                             ['foo', {'bar': ['baz', None, 1.0, 2]}])
            self.assertEqual(tornado.escape.json_decode('null'), None)
            self.assertEqual(tornado.escape.json_decode('1'), 1)
            self.assertEqual(tornado.escape.json_decode('"foo"'), 'foo')
            self.assertEqual(tornado.escape.json_decode('"\\"foo\\""'), '"foo"')

    unitt

# Generated at 2022-06-24 08:21:54.052588
# Unit test for function json_decode
def test_json_decode():
    assert(json_decode("1") == 1)
    assert(json_decode(b"1") == 1)



# Generated at 2022-06-24 08:21:59.902658
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_dict = parse_qs_bytes(b'foo=abc&bar=123')
    assert test_dict['foo'] == [b'abc']
    assert test_dict['bar'] == [b'123']



# Generated at 2022-06-24 08:22:01.750528
# Unit test for function native_str
def test_native_str():
    value = 'abc'
    assert native_str(value) == value
    assert type(native_str(value)) == str


# Generated at 2022-06-24 08:22:11.031997
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(["", 1, "", "", "", ""]) == ["", 1, "", "", "", ""]
    # x = {"key": "value"}
    # assert recursive_unicode(x) == {"key": u"value"}
    # assert recursive_unicode({"key": "value"}) == {u"key": u"value"}
    # assert recursive_unicode([1, 2, 3, 4]) == [1, 2, 3, 4]
    # assert recursive_unicode((1, 2, 3, 4)) == (1, 2, 3, 4)

# Generated at 2022-06-24 08:22:13.873051
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    d = parse_qs_bytes('name=David&age=32')
    assert d['name'][0] == 'David'
    assert d['age'][0] == '32'


# Generated at 2022-06-24 08:22:23.016667
# Unit test for function utf8
def test_utf8():
    assert utf8("") == b""
    assert utf8("a") == b"a"
    assert utf8("abcd") == b"abcd"
    assert utf8(u"abcd") == b"abcd"
    assert utf8(b"abcd") == b"abcd"
    assert utf8(None) is None
    try:
        utf8(2)
    except TypeError:
        pass
    else:
        assert False, "Should have thrown a TypeError"


_TO_UNICODE_TYPES = (unicode_type, type(None))


# noinspection PyUnresolvedReferences

# Generated at 2022-06-24 08:22:32.938963
# Unit test for function linkify
def test_linkify():
    _URL_RE_TEST = re.compile(
        r"""\b((?:([\w-]+):(/{1,3})|www[.])(?:(?:(?:[^\s&()]|&amp;|&quot;)*(?:[^!"#$%&'()*+,.:;<=>?@\[\]^`{|}~\s]))|(?:\((?:[^\s&()]|&amp;|&quot;)*\))))"""  # noqa: E501
    )
    test_input = """http://tornadoweb.org/ es una biblioteca que permite desarrollar aplicaciones web y websockets 
    asincronas en python"""
    test_output = linkify(test_input)
    result = _URL_RE

# Generated at 2022-06-24 08:22:43.501637
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert recursive_unicode(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert recursive_unicode({'a': 'A', 'b': 'B', 'c': 'C'}) == {'a': 'A', 'b': 'B', 'c': 'C'}
    assert recursive_unicode({'a': [1, 2, 3], 'b': 'B', 'c': 'C'}) == {'a': [1, 2, 3], 'b': 'B', 'c': 'C'}
    assert recursive_unicode(123) == 123
    assert recursive_unicode(b'abc') == 'abc'

# Generated at 2022-06-24 08:22:44.997050
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"

# Generated at 2022-06-24 08:22:47.683070
# Unit test for function json_decode
def test_json_decode():
    input_string = '{"foo": ["bar", "baz"]}'
    output = {'foo': ['bar', 'baz']}
    assert json_decode(input_string) == output



# Generated at 2022-06-24 08:22:58.212839
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(1234) == 1234
    assert recursive_unicode("1234") == "1234"
    assert recursive_unicode("hálló") == "hálló"
    assert recursive_unicode(b"1234") == "1234"

# Generated at 2022-06-24 08:23:08.298164
# Unit test for function linkify

# Generated at 2022-06-24 08:23:20.784931
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("\"a\"") == "a"
    assert json_decode("1") == 1
    assert json_decode("{}") == {}
    assert json_decode("null") is None
    assert json_decode("true") is True
    assert json_decode("false") is False
    assert json_decode("[]") == []


_HTML_UNESCAPE = {
    ord("&"): "&amp;",
    ord("<"): "&lt;",
    ord(">"): "&gt;",
    ord('"'): "&quot;",
    ord("'"): "&#x27;",
}


_RECODE_HTML_ENTITY = re.compile(r"&(#?)(\w+?);")



# Generated at 2022-06-24 08:23:26.643561
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # 测试第一个参数为字符串, 返回值为
    # {'a': [b'1'], 'b': [b'2'], 'c': [b'3'], 'd': [b'4']}
    print(parse_qs_bytes('a=1&b=2&c=3&d=4'))


# TODO: move to urllib3

# Generated at 2022-06-24 08:23:34.999669
# Unit test for function linkify
def test_linkify():
    assert linkify(
        'http://example.com',
        shorten=True,
        extra_params='rel="nofollow" class="external noopener noreferrer"',
        require_protocol=True,
    ) == (
        '<a href="http://example.com" '
        'rel="nofollow" class="external noopener noreferrer">'
        'http://example.com</a>'
    )

# Generated at 2022-06-24 08:23:37.294679
# Unit test for function url_escape
def test_url_escape():
    url_escape("Tornado is a Python web framework and \
    asynchronous networking library")


# Generated at 2022-06-24 08:23:46.116398
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('This is a test') == 'This is a test'
    assert squeeze('This   is a test') == 'This is a test'
    assert squeeze('This   is a "test"') == 'This is a "test"'
    assert squeeze('This   is a "test" ') == 'This is a "test"'
    assert squeeze('This   is a \n"test" ') == 'This is a "test"'
    assert squeeze('This   is a \r"test" ') == 'This is a "test"'
    assert squeeze('This   is a \r\n"test" ') == 'This is a "test"'
    assert squeeze('This   is a \r\n"test"') == 'This is a "test"'

# Generated at 2022-06-24 08:23:48.677293
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div>Hello & Goodbye</div>") == "&lt;div&gt;Hello &amp; Goodbye&lt;/div&gt;"


# Generated at 2022-06-24 08:23:52.651688
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&b=2') == {'a': [b'1'], 'b': [b'2']}



# Generated at 2022-06-24 08:24:02.600457
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # type: () -> None
    def test_xhtml_escape_helper(value, expected):
        # type: (Union[str, bytes], str) -> None
        actual = xhtml_escape(value)
        if actual != expected:
            raise Exception(
                    'xhtml_escape("%s") = "%s" != "%s"' %
                    (value, actual, expected))
    test_xhtml_escape_helper('<>&"\'', '&lt;&gt;&amp;&quot;&#39;')
    test_xhtml_escape_helper(b'<>&"\'', '&lt;&gt;&amp;&quot;&#39;')
    # Second test is to make sure that we handle surrogates properly.
    # This string has a high surrogate of u'\ud800

# Generated at 2022-06-24 08:24:05.008506
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'a': 'b', 'c': 'd'}) == '{"a": "b", "c": "d"}'



# Generated at 2022-06-24 08:24:15.030397
# Unit test for function native_str
def test_native_str():
    s = to_unicode(b"abc")
    assert isinstance(s, unicode_type)
#     assert s == "abc"


# These JSON encoding variants do not escape forward slashes. This behavior
# is consistent with other web frameworks and JavaScript contexts,
# but is not compliant with the ECMA-262 specification for JavaScript.
# Note: json_encode remains compliant with ECMA-262.
_JSON_RECURSIVE_ENCODER = json.JSONEncoder(
    skipkeys=False,
    ensure_ascii=True,
    check_circular=True,
    allow_nan=True,
    indent=None,
    separators=None,
    default=None,
)
_JSON_RECURSIVE_ENCODER.item_separator = ","



# Generated at 2022-06-24 08:24:17.153234
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze('hello \t\n\t world\n') == 'hello world')

# Generated at 2022-06-24 08:24:23.214815
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>'&") == "&lt;&gt;&#39;&amp;"

_HTML_UNESCAPE_RE = re.compile(
    "&(#(?:x[0-9a-f]+|\d+)|\w+);", flags=re.IGNORECASE
)
_UNESCAPE_MAP: Dict[str, Callable[[str], str]]  # type: ignore



# Generated at 2022-06-24 08:24:33.981079
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\u2603") == b"\xe2\x98\x83"
    assert utf8(None) is None
    assert utf8(b"") == b""
    try:
        utf8(1)
        assert False, "expected exception"
    except TypeError:
        pass
    try:
        utf8(object())
        assert False, "expected exception"
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:24:38.508381
# Unit test for function native_str
def test_native_str():
    a = 1
    b = 123
    c = "123"
    d = "1.23"
    e = "hello"
    assert native_str(a)=="1"
    assert native_str(b) == "123"
    assert native_str(c)=="123"
    assert native_str(d)=="1.23"
    assert native_str(e)== "hello"

# Generated at 2022-06-24 08:24:42.890147
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    corrupt_input = "&<>\"';&amp;&lt;&quot;" 
    assert xhtml_unescape(corrupt_input) == "&<>\"';&&<\""


# Generated at 2022-06-24 08:24:48.315624
# Unit test for function linkify
def test_linkify():
    string = "http://blog.csdn.net/win_lin/article/details/12079427"
    result = linkify(string)
    print(result)
    assert result == '<a href="http://blog.csdn.net/win_lin/article/details/12079427">http://blog.csdn.net/win_lin/article/details/12079427</a>'



# Generated at 2022-06-24 08:24:59.461075
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_dict = parse_qs_bytes(b"a=b")
    assert test_dict == {'a': [b'b']}
    test_dict1 = parse_qs_bytes(b"a=b&a=c")
    assert test_dict1 == {'a': [b'b', b'c']}
    test_dict2 = parse_qs_bytes(b"a=b&a=c&d=e")
    assert test_dict2 == {'a': [b'b', b'c'], "d": [b"e"]}
    test_dict3 = parse_qs_bytes(b"a=b&a=c&d=")
    assert test_dict3 == {'a': [b'b', b'c']}

# Generated at 2022-06-24 08:25:07.025046
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # If a unicode string is passed in, it should return the same string
    u = to_unicode('hi')
    assert(recursive_unicode(u) == u)
    # If a list is passed in, it should return the same list
    l = [1, 2, to_unicode('hi')]
    assert(recursive_unicode(l) == l)
    # If a bytestring is passed in, it should return a unicode string of the same value
    b = b'hi'
    assert(recursive_unicode(b) == to_unicode(b))
    # If a list of bytestrings is passed in, it should return a list of unicode strings of the same value
    l = [1, 2, b'hi']

# Generated at 2022-06-24 08:25:09.475975
# Unit test for function json_encode
def test_json_encode():
    assert(json_encode({"a": "b"}) == '{"a": "b"}')


# Generated at 2022-06-24 08:25:14.083729
# Unit test for function json_encode
def test_json_encode():
    assert json_encode('</script>') == '"<\\/script>"'

# json_decode is just a wrapper around json.loads.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-24 08:25:22.495498
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unscape("&quot;") == '"'
    assert xhtml_unescape("&apos;") == "'"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#1234;") == "Ӓ"


_BASESTRING_TYPE = bytes


if str is unicode_type:  # python 2
    _BASESTRING_TYPE = unicode_type



# Generated at 2022-06-24 08:25:30.661976
# Unit test for function utf8
def test_utf8():
    print(utf8('test'))
    print(utf8('test'.encode('utf-8')))
    print(utf8(None))
    try:
        print(utf8(1))
    except TypeError:
        print('TypeError')
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:25:41.317073
# Unit test for function utf8
def test_utf8():
    assert utf8('foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8(u'\u0e51') == b'\xe0\xb9\x91'
    assert utf8(None) is None
    try:
        utf8(u'\ud800')
        raise Exception("did not get expected exception")
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-24 08:25:43.016740
# Unit test for function json_decode
def test_json_decode():
    assert json_decode(b'123') == 123
    assert json_decode('123') == 123



# Generated at 2022-06-24 08:25:52.876674
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/some_long_path") == '<a href="http://www.example.com/some_long_path">http://www.example.com/some_long_...</a>'
    assert linkify("http://www.example.com/some_long_path?with=args") == '<a href="http://www.example.com/some_long_path?with=args">http://www.example.com/some_long_...</a>'

# Generated at 2022-06-24 08:26:02.014389
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("hello http://example.com") == 'hello <a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("hello http://example.com/foo&bar") == 'hello <a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'


# The following is a list of words that should not be capitalized
# for titlecase because all uppercase versions (e.g.

# Generated at 2022-06-24 08:26:07.309537
# Unit test for function recursive_unicode
def test_recursive_unicode():
    print('[+] RUN test_recursive_unicode')
    assert recursive_unicode(bytes('hého', encoding='utf-8')) == 'hého'
    assert recursive_unicode(bytes('hého', encoding='utf-8')) != bytes('hého', encoding='utf-8')
    assert recursive_unicode(bytes('hého', encoding='utf-8')) != 'ho'

    assert recursive_unicode(['hého', 'hihi']) == ['hého', 'hihi']
    assert recursive_unicode(['hého', 'hihi']) != ['heho', 'hihi']
    assert recursive_unicode(['hého', 'hihi']) != ['hého', 'hého']


# Generated at 2022-06-24 08:26:18.841538
# Unit test for function squeeze
def test_squeeze():
    #Squeeze should remove all extra whitespace
    value_1 = "there is lots   of   space"
    assert squeeze(value_1)=="there is lots of space"
    #Squeeze should replace \n with a space
    value_2="\n\n\n\n this is a string with newlines in it \n\n\n\n\n"
    assert squeeze(value_2)==" this is a string with newlines in it "
    #Squeeze should remove all tabs
    value_3="there\tare\ttabs\tin\tthis\tstring"
    assert squeeze(value_3)=="there are tabs in this string"
    #Squeeze should remove all carriage returns

# Generated at 2022-06-24 08:26:23.770866
# Unit test for function json_decode
def test_json_decode():
    # Type hinting
    func: Callable[[Union[str, bytes]], Any] = json_decode
    # Valid type
    result: Any = func('{"a":1,"b":2}')
    assert isinstance(result, dict)
    assert result['a'] == 1
    assert isinstance(result['b'], int)


# json_encode and json_decode don't need to be public.
_json_decode = json.JSONDecoder().decode
_json_encode = json.JSONEncoder().encode



# Generated at 2022-06-24 08:26:32.182325
# Unit test for function linkify
def test_linkify():
    text_with_url = "Hello http://tornadoweb.org!"
    text_without_url = "Hello World!"
    assert linkify(text_with_url) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text_without_url) == "Hello World!"



# Generated at 2022-06-24 08:26:35.130868
# Unit test for function linkify
def test_linkify():
    text = 'My name is feng. http://www.chinahadoop.cn'
    assert linkify(text) == 'My name is feng. <a href="http://www.chinahadoop.cn">http://www.chinahadoop.cn</a>'


# Generated at 2022-06-24 08:26:38.081014
# Unit test for function squeeze
def test_squeeze():
    """squeeze 函数的单测函数"""
    assert squeeze(" a  b  ") == "a b"


_UTF8_TYPES = (bytes, type(None))  # noqa: F821
_TO_UNICODE_TYPES = (unicode_type, type(None))  # noqa: F821



# Generated at 2022-06-24 08:26:40.147559
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'a%2B%2Bb') == b'a++b'



# Generated at 2022-06-24 08:26:47.413304
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&#29;') == '\x1d'
    assert xhtml_unescape('&#x1d;') == '\x1d'
    assert xhtml_unescape('&#X1d;') == '\x1d'
    assert xhtml_unescape('&#X1D;') == '\x1d'

# end of test_xhtml_unescape


# Generated at 2022-06-24 08:26:50.597243
# Unit test for function native_str
def test_native_str():
    import locale
    locale.setlocale(locale.LC_ALL, '')
    assert native_str('中文') == '中文'


# Generated at 2022-06-24 08:26:56.316080
# Unit test for function utf8
def test_utf8():
    assert utf8("hello") == b"hello"
    assert isinstance(utf8(u"hello"), bytes)
    assert utf8(b"hello") == b"hello"
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:57.746791
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('abc')=='abc'



# Generated at 2022-06-24 08:27:06.737036
# Unit test for function native_str
def test_native_str():
    # type: () -> None
    assert native_str("abc") == "abc"
    assert native_str(u"abc") == "abc"
    assert native_str("汉字") == "汉字"
    assert native_str(u"汉字") == "汉字"
    assert native_str(b"\x80") == "€"
    assert native_str(b"\xc2\x80") == "€"
    assert native_str(u"\x80") == "€"

    # Force the internal cache of native_str to reset and
    # then test it again
    native_str.cache_clear()

    assert native_str("abc") == "abc"
    assert native_str(u"abc") == "abc"

# Generated at 2022-06-24 08:27:08.095308
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"


# Generated at 2022-06-24 08:27:16.869059
# Unit test for function url_escape
def test_url_escape():
    res = url_escape('https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=1&tn=baidu&wd=tornado%E4%BB%A3%E7%A0%81%E8%A7%A3%E8%AF%BB&rsv_pq=e0d90b49001f98a2&rsv_t=d97bs4QNY%2BUdwuB4CZ%2BgS9tjxTtTbHlTd%2BHgwHT7MdElZoO%2BgNXrUtFkCtN0&rqlang=cn&rsv_enter=1&rsv_dl=tb&inputT=8249')
   

# Generated at 2022-06-24 08:27:19.001415
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str('hello'), str)
    assert isinstance(native_str(b'hello'), str)



# Generated at 2022-06-24 08:27:28.220378
# Unit test for function json_encode
def test_json_encode():
    s = json_encode(None)
    assert s == "null"
    s = json_encode(123)
    assert s == '123'
    s = json_encode("123")
    assert s == '"123"'
    s = json_encode("<")
    assert s == '"<"'
    s = json_encode([1,2,3])
    assert s == '[1,2,3]'
    s = json_encode({"a":1, "b":2})
    assert s == '{"a":1,"b":2}'



# Generated at 2022-06-24 08:27:32.115478
# Unit test for function utf8
def test_utf8():
    assert utf8(b'1') == b'1'
    assert utf8('1') == b'1'
    assert utf8(None) == None
    assert utf8(123) == 123

_TO_UNICODE_TYPES = (unicode_type, type(None))

