

# Generated at 2022-06-24 08:17:36.128514
# Unit test for function url_escape
def test_url_escape():
    assert "http%3A%2F%2Fwww.example.com%2F%3Fkey1%3Dvalue1%26key2%3Dvalue2" == url_escape("http://www.example.com/?key1=value1&key2=value2")



# Generated at 2022-06-24 08:17:42.813571
# Unit test for function recursive_unicode
def test_recursive_unicode():
    class TestObj(object):
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return repr(self.value)
        
    assert recursive_unicode([b'foo', TestObj(b'bar')]) == ['foo', TestObj('bar')]



# Generated at 2022-06-24 08:17:45.660648
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze("  a  b  c \t\t  d\n\n\n\n")=="a b c d")


# Generated at 2022-06-24 08:17:52.444133
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = recursive_unicode(
        {"ascii": b"ascii_value", "foo": b"foo_value", "inner": {"bar": b"bar_value"}}
    )
    assert isinstance(x, dict) and isinstance(x['ascii'], str) and isinstance(x['foo'], str) and isinstance(x['foo'], str) and isinstance(x['inner']['bar'], str)


# Generated at 2022-06-24 08:17:55.611673
# Unit test for function json_decode
def test_json_decode():
    result = json_decode('{"a":1,"b":2}')
    assert result['a'] == 1 and result["b"] == 2
    
    
    

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:18:01.137601
# Unit test for function url_unescape
def test_url_unescape(): # type: () -> None
    assert url_unescape(b'http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26baz%3Dbah') == url_unescape('http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26baz%3Dbah', encoding='utf-8')
    assert url_unescape('http%3A%2F%2Fexample.com%2F%3Ffoo%3Dbar%26baz%3Dbah', encoding=None) == b'http://example.com/?foo=bar&baz=bah'



# Generated at 2022-06-24 08:18:10.486954
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("true") is True
    assert json_decode("false") is False
    assert json_decode("null") is None
    assert json_decode("3.14") == 3.14
    assert json_decode("3") == 3
    assert json_decode("3.14") == 3.14
    assert json_decode('"abc"') == "abc"
    assert json_decode("[1, 2, 3]") == [1, 2, 3]
    assert json_decode("{'a': 1, 'b': 2}") == {"a": 1, "b": 2}


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:18:12.918269
# Unit test for function url_escape
def test_url_escape():
	"""
	check the function url_escape
	:return:
	"""
	assert(url_escape("select * from t")=="select+%2A+from+t")
test_url_escape()


# Generated at 2022-06-24 08:18:20.568516
# Unit test for function utf8
def test_utf8():
    assert utf8(u'\u00e9') == b'\xc3\xa9'
    assert utf8(b'\xc3\xa9') == b'\xc3\xa9'
    assert utf8(None) is None
    try:
        utf8(1)
    except TypeError as e:
        assert 'Expected bytes, unicode, or None; got' in str(e)



# Generated at 2022-06-24 08:18:30.271300
# Unit test for function url_escape
def test_url_escape():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import tornado.escape
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    class MainHandler(tornado.web.RequestHandler):
        @gen_test
        def get(self):
            url = 'http://www.google.com'
            url_escape_result = tornado.escape.url_escape(url, False)
            self.write(url_escape_result)

    class Application(tornado.web.Application):
        def __init__(self):
            handlers = [
                (r"/", MainHandler)
            ]
            tornado.web.Application.__init__(self, handlers)
    def main():
        port = 8888
        print('Tornado HTTP server is starting on %d ...' % port)


# Generated at 2022-06-24 08:18:42.042185
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(b"&lt;") == "<"
    assert xhtml_unescape(b"&#60;") == "<"
    assert xhtml_unescape(b"&#x3c;") == "<"
    assert xhtml_unescape(b"&#X3c;") == "<"
    assert xhtml_unescape(b"&#X3C;") == "<"
    assert xhtml_unescape(b"&LT;") == "<"
    assert xhtml_unescape(b"&#060;") == "<"
    assert xhtml_unescape(b"&#0060;") == "<"
    assert xhtml_unescape(b"&#00060;") == "<"
    assert xhtml_unescape(b"&#000060;") == "<"

# Generated at 2022-06-24 08:18:46.404399
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes(b'a=1&b=2')
    assert isinstance(result, dict)
    assert result['a'][0].decode('latin1') == '1'
    assert result['b'][0].decode('latin1') == '2'



# Generated at 2022-06-24 08:18:50.730197
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com", extra_params='rel="nofollow"') == '<a href="http://www.example.com" rel="nofollow">http://www.example.com</a>'
    assert linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-24 08:18:56.879487
# Unit test for function native_str
def test_native_str():
    assert native_str("123") == "123"
    assert native_str(b"123") == "123"  # type: ignore
    assert native_str(b"123".decode('utf-8')) == "123"  # type: ignore


_BASESTRING_TYPES = (bytes, str, type(None))



# Generated at 2022-06-24 08:19:07.026803
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("hello") == "hello"
    assert url_escape("hello world") == "hello+world"
    assert url_escape("a b c") == "a+b+c"
    assert url_escape("a+b+c") == "a%2Bb%2Bc"
    assert url_escape("/path/to/file") == "%2Fpath%2Fto%2Ffile"
    assert url_escape("/path/to/file", plus=False) == "%2Fpath%2Fto%2Ffile"
    assert url_escape("?param=1") == "%3Fparam%3D1"
    assert url_escape("?param=1", plus=False) == "%3Fparam%3D1"




# Generated at 2022-06-24 08:19:08.821932
# Unit test for function squeeze
def test_squeeze():
    a = squeeze("sdfsdfsdfs    \nsdfsdfsdfsf")
    print("result: ", a)



# Generated at 2022-06-24 08:19:14.561175
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str(1), str)
    assert isinstance(native_str(b'abc'), str)
    assert native_str(b'abc') == 'abc'
    assert isinstance(native_str('def'), str)
    assert native_str('def') == 'def'
    
test_native_str()


# Generated at 2022-06-24 08:19:16.463505
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&<>"\'') == "&amp;&lt;&gt;&quot;&#39;"


# Generated at 2022-06-24 08:19:23.357537
# Unit test for function native_str
def test_native_str():
    test.assert_equals(bytes, type(native_str(b'bytes')))
    test.assert_equals(unicode_type, type(native_str(u'unicode')))
    test.assert_is_instance(native_str('string'), type(u'string'))
    test.assert_equals(None, native_str(None))


test_native_str()


# Generated at 2022-06-24 08:19:28.546223
# Unit test for function json_encode
def test_json_encode():
    a = '{"a":1,"b":2,"c":"<script></script>"}'
    print(json_encode(json.loads(a)))
    # {"a": 1, "b": 2, "c": "<script><\\/script>"}



# Generated at 2022-06-24 08:19:30.271305
# Unit test for function squeeze
def test_squeeze():
    value = "good   morning"
    ret = squeeze(value)
    assert ret == "good morning"

# Generated at 2022-06-24 08:19:36.590540
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('str') == 'str'
    assert xhtml_escape('<') == '&lt;'
    assert xhtml_escape('"') == '&quot;'
    assert xhtml_escape('"str"') == '&quot;str&quot;'
    assert xhtml_escape(1) == '1'
    assert xhtml_escape(None) == ''
    #assert xhtml_escape(True) == 'True'
    assert xhtml_escape(False) == 'False'



# Generated at 2022-06-24 08:19:42.488240
# Unit test for function json_decode
def test_json_decode():
    """
    j = '{"one": "1", "two": "2", "three": "3"}'
    print (json_decode(j))
    print (json_decode(j)["three"])
    """
    #j = {'one': '1', 'two': '2', 'three': '3'}
    #print (j['three'])
    j = '{"one": "1", "two": "2", "three": "3"}'
    p = json_decode(j)
    #print (p['one'])
    #print (p['two'])
    print (p['three'])

#test_json_decode()



# Generated at 2022-06-24 08:19:45.207383
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": 1}) == '{"a": 1}'

_JSON_DECODE_PATTERN = re.compile(r'\\(?![/u"])')



# Generated at 2022-06-24 08:19:46.576450
# Unit test for function native_str
def test_native_str():
    assert native_str(b'abc') == b'abc'
    assert native_str(u'abc') == b'abc'
    assert native_str(None) == None



# Generated at 2022-06-24 08:19:50.098387
# Unit test for function squeeze
def test_squeeze():
    str1 = "Hello     world     "
    str2 = squeeze(str1)
    if str2 == "Hello world":
        print("Pass")
    else:
        print("Fail")
test_squeeze()


# Generated at 2022-06-24 08:19:57.359112
# Unit test for function linkify
def test_linkify():
    
    assert linkify("This is a test text") == "This is a test text"
    assert linkify("This is a a test http://test.com/ text") == "This is a a test <a href=\"http://test.com/\">http://test.com/</a> text"
    assert linkify("This is a a test http://test.com/ which is looooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooong text") == "This is a a test <a href=\"http://test.com/\">http://test.com/</a> which is looooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooong text"

# Generated at 2022-06-24 08:20:04.860822
# Unit test for function utf8
def test_utf8():
    assert utf8(b"hello") == b"hello"
    assert utf8("hello") == b"hello"
    assert utf8("hello") == "hello"
    assert utf8(None) is None


# All the unicode_* functions below were originally copied from
# https://github.com/fiorix/pytidylib/blob/master/pytidylib/utils.py
#
# These functions were copied from tornado.utils, with modifications

# Generated at 2022-06-24 08:20:07.681611
# Unit test for function linkify
def test_linkify():
    input = "hello http://world.com"
    output = "hello <a href=\"http://world.com\">http://world.com</a>"
    assert(linkify(input) == output)



# Generated at 2022-06-24 08:20:09.172359
# Unit test for function url_escape
def test_url_escape():
    string = 'yes'
    assert url_escape(string) == 'yes'


# Generated at 2022-06-24 08:20:17.868518
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8("\u1234") == b"\xe1\x88\xb4"
    assert utf8("\ud800\udf00") == b"\xf0\x90\x8c\x80"
    assert utf8(None) is None
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        raise Exception("Failed to raise error")



# Generated at 2022-06-24 08:20:27.780832
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    from cgi import escape
    from tornado.escape import xhtml_unescape
    xhtml_unescape(escape('&#34;'))


# reserved (in RFC 3986 or RFC 2396)
_reserved = re.compile(r"[ &=+$,:;?@\"#%<>\*\[\]\{\}\|\\\^\~\`]")

# Generated at 2022-06-24 08:20:31.555273
# Unit test for function native_str
def test_native_str():
    from pyecharts.utils import is_py3

    if is_py3:
        assert 'a' == native_str('a')
        assert 'a' == native_str(b'a')
    else:
        assert 'a' == native_str('a')
        assert b'a' == native_str(b'a')



# Generated at 2022-06-24 08:20:39.862287
# Unit test for function linkify
def test_linkify():
    text = "http://www.google.com/?q=test"
    assert "google" in linkify(text, require_protocol=False)
    assert "google" not in linkify(text, require_protocol=True)
    assert "google" in linkify(text, require_protocol=False, permitted_protocols=["http"])
    assert "google" not in linkify(text, require_protocol=False, permitted_protocols=["ftp"])
    text = "www.google.com/?q=test"
    assert "google" in linkify(text, require_protocol=False)
    assert "google" not in linkify(text, require_protocol=True)
    assert "google" in linkify(text, require_protocol=False, permitted_protocols=["http"])


# Generated at 2022-06-24 08:20:47.627865
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<2>') == "&lt;2&gt;"
    assert xhtml_escape(b"<2>") == "&lt;2&gt;"
    assert xhtml_escape("& <> ' \"") == "&amp; &lt;&gt; &#39; &quot;"
    assert xhtml_escape(b"& <> ' \"") == "&amp; &lt;&gt; &#39; &quot;"
    

# Generated at 2022-06-24 08:20:56.039985
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a+b") == "a b"
    assert url_unescape("a+b", plus=False) == "a+b"
    assert url_unescape("a%20b") == "a b"
    assert url_unescape("a%20b", encoding="latin1") == "a b"
    assert url_unescape("a%20b", encoding=None) == b"a b"
    assert url_unescape("a%20b", encoding=None, plus=False) == b"a b"
    assert url_unescape(b"a%20b", encoding=None) == b"a b"
    assert url_unescape(b"a%20b", encoding=None, plus=False) == b"a b"



# Generated at 2022-06-24 08:21:06.960882
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('abcd') == 'abcd'
    # No whitespace
    assert squeeze('  abcd  ') == 'abcd'
    assert squeeze('  abcd   efg   hij  ') == 'abcd efg hij'
    # Unicode whitespace
    assert squeeze('  abcd\u3000\u3000efg\u3000hij  ') == 'abcd efg hij'
    # lstrip
    assert squeeze('  abcd') == 'abcd'
    assert squeeze('  abcd   ') == 'abcd'
    assert squeeze('  abcd   efg   hij  ') == 'abcd efg hij'
    # rstrip
    assert squeeze('abcd  ') == 'abcd'
    assert squeeze('  abcd  ') == 'abcd'

# Generated at 2022-06-24 08:21:14.082793
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print("test_xhtml_unescape...")
    assert "&" == xhtml_unescape("&amp;")
    assert "\"" == xhtml_unescape("&quot;")
    assert "'" == xhtml_unescape("&#39;")
    assert "<" == xhtml_unescape("&lt;")
    assert ">" == xhtml_unescape("&gt;")
    print("test_xhtml_unescape ok")

test_xhtml_unescape()



# Generated at 2022-06-24 08:21:20.056215
# Unit test for function json_encode
def test_json_encode():
    print(json_encode('"foo"\r\n'))
    # "\"foo\"\\r\\n"
    print(json.dumps('"foo"\r\n'))
    # "\"foo\"\r\n"
    # json.dumps() first calls str() on each object, then escapes Unicode characters.
test_json_encode()

_JSON_DECODE_OPTIONS = getattr(json, "JSONDecodeError", ValueError)



# Generated at 2022-06-24 08:21:25.828085
# Unit test for function json_encode
def test_json_encode():
    import json
    import tornado.escape
    test_json = json.loads("""
        {
           "id": "http://www.somewhere.com/somewhere/somewherein/path",
           "title": "Some module name"
        }
    """)
    test_json = tornado.escape.json_encode(test_json)
    assert(test_json == '{"id": "http://www.somewhere.com/somewhere/somewherein/path", "title": "Some module name"}')
    


# Generated at 2022-06-24 08:21:27.990592
# Unit test for function squeeze
def test_squeeze():
    print(squeeze("    hello world   "))
test_squeeze()


# Generated at 2022-06-24 08:21:38.675410
# Unit test for function json_decode
def test_json_decode():
    json_str = json_encode({"123": 123})
    print(json_str)
    print(type(json_str))
    json_obj = json_decode(json_str)
    print(json_obj)
    print(type(json_obj))
    assert json_obj["123"] == 123
test_json_decode()

# Background on why this module uses so many regular expressions:
#
# In python 2.x, urllib.unquote (called by url_unescape) does not handle
# non-utf8 query arguments.  It decodes everything using latin1, which
# does not correctly unquote strings containing %encode-to-bytes.
# urllib.unquote does correctly unquote strings where the %encode-to-bytes
# sequence encodes a utf8-encodable unic

# Generated at 2022-06-24 08:21:42.036983
# Unit test for function json_encode
def test_json_encode():
    obj = {'a': 'b\\c"d'}
    assert(json_encode(obj) == '{"a": "b\\\\c\\"d"}')
    obj = {'a': 'b\\c"d'}
    assert(json_encode(obj) == '{"a": "b\\\\c\\"d"}')

# Generated at 2022-06-24 08:21:51.794074
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('/test/?foo=bar#test') == '/test/%3Ffoo%3Dbar%23test'
    assert url_escape('/test/?foo=bar#test', plus=False) == '/test/%3Ffoo=bar%23test'
    assert url_escape('/TEST/') == '/TEST/'
    assert url_escape('/TEST/?foo=BAR#test') == '/TEST/%3Ffoo%3DBAR%23test'
    assert url_escape('/TEST/?foo=BAR#test', plus=False) == '/TEST/%3Ffoo=BAR%23test'
    assert url_escape('/TEST/foo bar/') == '/TEST/foo+bar/'

# Generated at 2022-06-24 08:21:56.504298
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode('\u5176\u4ed6') == '\u5176\u4ed6'
    assert recursive_unicode(['\u5176\u4ed6', {'\u5176\u4ed6': '\u5176\u4ed6'}]) == ['\u5176\u4ed6', {'\u5176\u4ed6': '\u5176\u4ed6'}]



# Generated at 2022-06-24 08:22:01.585623
# Unit test for function utf8
def test_utf8():
    assert utf8("Hello") == "Hello"
    assert utf8(u"Hello") == "Hello"
    assert utf8(u"Hello", "UTF-8") == "Hello"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:22:13.312738
# Unit test for function native_str
def test_native_str():
    assert native_str(b"abc") == b"abc"
    assert native_str(u"abc") == b"abc"
    assert native_str(u"abc", "UTF-8") == b"abc"
    assert native_str(b"abc", "UTF-8") == b"abc"
    assert native_str(u"智联招聘", "UTF-8") == b"\xe6\x99\xba\xe8\x81\x94\xe6\x8b\x9b\xe8\x81\x98"
    assert native_str(u"智联招聘", "GBK") == b"\xd6\xd0\xc1\xaa\xd5\xdf\xb3\xc6"

# Generated at 2022-06-24 08:22:23.349132
# Unit test for function linkify
def test_linkify():
    assert linkify("asdf http://foo.com/") == 'asdf <a href="http://foo.com/">http://foo.com/</a>'
    assert linkify("asdf http://foo.com/", require_protocol=True) == 'asdf http://foo.com/'
    assert linkify(
        "asdf http://foo.com/",
        permitted_protocols=(),
    ) == 'asdf http://foo.com/'
    assert (
        linkify("asdf http://foo.com/", permitted_protocols=["foo"])
        == 'asdf http://foo.com/'
    )
    assert linkify("asdf foo.com/", require_protocol=True) == 'asdf foo.com/'

# Generated at 2022-06-24 08:22:27.075124
# Unit test for function linkify
def test_linkify():
  print(linkify("Hello http://tornadoweb.org!"))
  print(linkify("Hello https://tornadoweb.org!"))
  print(linkify("Hello www.tornadoweb.org?"))

test_linkify()



# Generated at 2022-06-24 08:22:31.558700
# Unit test for function native_str
def test_native_str():
    assert native_str(b'foo') == 'foo'
    assert native_str(u'foo') == 'foo'
    assert native_str('foo') == 'foo'


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:22:42.372785
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Test unicode
    qs='x=y'
    assert parse_qs_bytes(qs) == {'x': ['y']}
    qs='x=y&x=z'
    assert parse_qs_bytes(qs) == {'x': ['y', 'z']}
    qs='x=y&x='
    assert parse_qs_bytes(qs) == {'x': ['y', '']}
    # Test bytes
    qs=b'x=y'
    assert parse_qs_bytes(qs) == {'x': [b'y']}
    qs=b'x=y&x=z'
    assert parse_qs_bytes(qs) == {'x': [b'y', b'z']}
    qs=b'x=y&x='
    assert parse_

# Generated at 2022-06-24 08:22:47.843168
# Unit test for function linkify
def test_linkify():
    assert(linkify("Hello http://tornadoweb.org!") == \
           "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!")
test_linkify()

# Tests for recursive_unicode taken from Python's own test suite:
# http://svn.python.org/view/python/branches/py3k/Lib/test/test_unicode.py?view=markup

# Generated at 2022-06-24 08:22:58.310690
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"
# test for xhtml_escape end


# Python 3.4 requests does use tornado.escape
# type: ignore
_unicode = str  # type: Callable[..., str]


to_unicode = _unicode

# If __all__ is defined, then we preserve that to prevent weird things like
# "from tornado.escape import *" silently importing the six and webencodings
# modules.  If __all__ is not defined, we explicitly import everything into
# the tornado.escape namespace to preserve backwards compatibility.  (In
# Python 2, we don't need to worry about this because the abc module is
# built-in and always available.)
__all__ = ["xhtml_escape"]

# Generated at 2022-06-24 08:23:04.747848
# Unit test for function xhtml_escape
def test_xhtml_escape():
    if xhtml_escape('<a href="test" onclick="alert(\'test\')" class="test">test</a>') == '&lt;a href=&quot;test&quot; onclick=&quot;alert(&#39;test&#39;)&quot; class=&quot;test&quot;&gt;test&lt;/a&gt;':
        return 1
    else:
        return 0
print(test_xhtml_escape())

# Generated at 2022-06-24 08:23:09.934010
# Unit test for function xhtml_escape
def test_xhtml_escape():
    s = "T&T>T\"T'T"
    assert xhtml_escape(s) == "T&amp;T&gt;T&quot;T&#39;T"

_HTML_TYPES = (
    typing.List,
    typing.Dict,
    typing.Tuple,
    typing.Set,
    typing.Generator,
    typing.Iterator,
)

_HTML_QUOTE_ENTITIES = dict(
    (k, "&%s;" % k) for k in html.entities.html5 if k != "'"
)
_HTML_QUOTE_ENTITIES["'"] = "&#39;"

_JSON_RECURSION_LIMIT = 512



# Generated at 2022-06-24 08:23:21.855610
# Unit test for function url_escape

# Generated at 2022-06-24 08:23:32.148510
# Unit test for function linkify
def test_linkify():
    assert(linkify("Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!")


if hasattr(types, "ClassType"):

    def is_class(obj: Any) -> bool:
        """Returns true if the given object is a class.

        We are required to have this workaround for Python 2 because
        of how Python 2 distinguishes classes from instances.
        """
        return isinstance(obj, (type, types.ClassType))  # type: ignore
else:

    def is_class(obj: Any) -> bool:
        """Returns true if the given object is a class.

        We are required to have this workaround for Python 2 because
        of how Python 2 distinguishes classes from instances.
        """
        return isinstance(obj, type)



# Generated at 2022-06-24 08:23:41.230083
# Unit test for function xhtml_escape
def test_xhtml_escape():
    org_list=["This is a test", 'a"b', "a'b", "a<b", "a>b", "a&b"]
    ans_list = ["This is a test", 'a&quot;b', "a&#39;b", "a&lt;b", "a&gt;b", "a&amp;b"]
    ans_tuple=tuple(ans_list)
    for i, org in enumerate(org_list):
        ans = ans_tuple[i]
        assert ans == xhtml_escape(org)


_JSON_ESCAPE_RE = re.compile(r"[\x00-\x1f\\]")

# Generated at 2022-06-24 08:23:51.874784
# Unit test for function native_str
def test_native_str():
    assert native_str(b'foo') == 'foo'
    assert native_str(b'foo', 'latin1') == 'foo'
    assert native_str('foo') == 'foo'
    assert native_str(u'foo') == u'foo'
    assert native_str('\xc3\xa9', 'utf8') == u'\xe9'
    assert native_str(b'\xc3\xa9', 'latin1') == u'\xc3\xa9'
    assert native_str(b'\xc3\xa9', 'utf8') == u'\xe9'
    assert native_str(u'\xe9', 'latin1') == u'\xe9'
    assert native_str(u'\xe9', 'utf8') == u'\xe9'



# Generated at 2022-06-24 08:23:53.411618
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"


# Generated at 2022-06-24 08:23:59.813687
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
  value="&lt; &amp; &gt; &quot; &#39; &nbsp; &#X201D;"
  print(xhtml_unescape(value))
# test_xhtml_unescape()

# Allow easy overriding of the _unicode function for tests.
_unicode = unicode_type



# Generated at 2022-06-24 08:24:05.162496
# Unit test for function json_encode
def test_json_encode():
    a = json_encode({'name': 'test'})
    print(a)
test_json_encode()


_JSON_DECODE_OPTIONS = {
    # Use the Python parser (not C speedups) for matching the escape sequence.
    'strict': False,
    # Set parse_float=decimal.Decimal for precise decimal representation.
}



# Generated at 2022-06-24 08:24:13.999587
# Unit test for function recursive_unicode
def test_recursive_unicode():
    def do_test(obj):
        assert recursive_unicode(obj) == obj
    for obj in [
        12, 3.14, "hello", u"hello", b"hello",
        [b"hello", u"world"], (b"hello", u"world"),
        {"hello": b"world"}, {"hello": u"world"},
        {"hello": {"world": u"!"}},
        {"hello": {"world": [1, 2, 3]}},
    ]:
        do_test(obj)
    # the following is an actual weird edge case we found in the wild
    do_test((1, (b"\xff", {b"hi": u"bye"})))



# Generated at 2022-06-24 08:24:14.894052
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(r"hello\nworld\t") == r"hello world"



# Generated at 2022-06-24 08:24:21.084871
# Unit test for function linkify
def test_linkify():
    assert linkify('http://facebook.com/flu') == '<a href="http://facebook.com/flu">http://facebook.com/flu</a>'
    assert linkify('https://www.facebook.com/flu') == '<a href="https://www.facebook.com/flu">https://www.facebook.com/flu</a>'
    assert linkify('www.facebook.com/flu') == '<a href="http://www.facebook.com/flu">www.facebook.com/flu</a>'
    assert linkify('www.facebook.com/flu/') == '<a href="http://www.facebook.com/flu/">www.facebook.com/flu/</a>'
    assert linkify('www.facebook.com/flu:') == 'www.facebook.com/flu:'

# Generated at 2022-06-24 08:24:23.130045
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("a b") == "a+b"
    assert url_escape("a b", plus=False) == "a%20b"


# Generated at 2022-06-24 08:24:34.914514
# Unit test for function url_unescape
def test_url_unescape():
    # Test the 'plus' argument.
    assert url_unescape("%2B") == "+"
    assert url_unescape("%2B", plus=True) == " "
    assert url_unescape("%2B", plus=False) == "+"
    # Test the 'encoding' argument.
    assert url_unescape("%E2%82%AC") == "\u20ac"
    assert url_unescape("%E2%82%AC", encoding="ascii") == "â‚¬"
    assert url_unescape("%E2%82%AC", encoding=None) == b"\xe2\x82\xac"
    # Test the 'ascii' argument.

# Generated at 2022-06-24 08:24:46.644073
# Unit test for function utf8
def test_utf8():
    assert utf8("hi") == b"hi"
    assert utf8("привет") == b"\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82"
    assert utf8("привет".encode("utf-8")) == b"\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82"
    assert utf8(None) is None
    try:
        utf8(u"\u0100")
        raise Exception("Expected exception")
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-24 08:24:51.790531
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('''&lt;a &#39;test&#39;=&quot;blah&quot;
href=&quot;/foo?bar=baz&amp;name=Nick&quot;&gt;''') == '<a \'test\'="blah" href="/foo?bar=baz&name=Nick">'

# Generated at 2022-06-24 08:25:02.364250
# Unit test for function recursive_unicode
def test_recursive_unicode():
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase
    from tornado.escape import recursive_unicode

    class TestRecursiveUnicode(AsyncTestCase):
        def test_recursive_unicode(self):
            # Nothing to do if it's already unicode
            self.assertEqual(recursive_unicode('foo'), 'foo')

            # Strings get decoded
            self.assertEqual(recursive_unicode(b'foo'), 'foo')

            # Iterables get recursively walked
            self.assertEqual(recursive_unicode(['foo', b'bar']), ['foo', 'bar'])
            self.assertEqual(recursive_unicode(('foo', b'bar')), ['foo', 'bar'])

# Generated at 2022-06-24 08:25:07.137967
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    url = "https://www.baidu.com/s?wd=%E8%A1%A5%E6%9C%BA%E6%B2%B9%E5%8D%A1%E8%B4%AD%E4%B9%B0%20%E7%94%A8%E4%BA%BA%E6%9C%8D%E5%8A%A1"
    print(parse_qs_bytes(url))
    print(urllib.parse.parse_qs(url))
# test_parse_qs_bytes()



# Generated at 2022-06-24 08:25:18.507994
# Unit test for function json_decode
def test_json_decode():
    class lst(list):
        pass
    class dct(dict):
        pass
    assert json_decode('{"a": "b"}') == {"a": "b"}
    assert isinstance(json_decode('{"a": "b"}'), dict)
    assert isinstance(json_decode('{"a": "b"}', object_hook=dct), dct)
    assert isinstance(json_decode('{"a": "b"}', object_pairs_hook=dct), dct)
    assert json_decode('{"a": "b"}', object_pairs_hook=dct) == {"a": "b"}
    assert json_decode('{"a": "b"}', object_pairs_hook=lst)[0] == ("a", "b")

# Generated at 2022-06-24 08:25:27.314589
# Unit test for function utf8
def test_utf8():
    assert utf8(b"12345") == b"12345"
    assert utf8("12345") == b"12345"
    assert utf8(None) is None
    assert utf8(b"12345") == b"12345"
    assert utf8("12345") == b"12345"
    assert utf8(None) is None
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        assert False, "need to raise TypeError"


# Why are strings translated to unicode in templates but not in handlers?
#
#   1.  To simplify things, only utf8 and unicode strings are supported
#       in templates.
#
#       These are directly supported by the template language and libc
#       and don't require the developer to keep track

# Generated at 2022-06-24 08:25:35.567438
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("%27") == "'"
    assert url_unescape("%27", None) == b"'"
    assert url_unescape("hi%20there", None) == b"hi there"
    assert url_unescape("%61%62") == "ab"
    assert url_unescape("%61%62", None) == b"ab"
    assert url_unescape("%61%62%63") == "abc"
    assert url_unescape("%61%62%63", None) == b"abc"
    assert url_unescape("%61+%62") == "a b"
    assert url_unescape("%61+%62", None) == b"a b"
    assert url_unescape("%61+%62%63") == "a bc"

# Generated at 2022-06-24 08:25:46.045064
# Unit test for function linkify
def test_linkify():
    #print(linkify("Hello http://tornadoweb.org!"))
    print(linkify('this is a good url: http://www.baidu.com'))
    print(linkify('this is a good url: www.baidu.com'))
    print(linkify('this is a good url: ftp://www.baidu.com'))
    print(linkify('this is a good url: www.baidu.com',extra_params="rel='nofollow'"))
    print(linkify('this is a good url: www.baidu.com',extra_params=lambda x: "rel='nofollow'"))
    print(linkify('this is a good url: www.baidu.com',require_protocol=False))

# Generated at 2022-06-24 08:25:49.242094
# Unit test for function utf8
def test_utf8():
    assert utf8("test") == b"test"
    if hasattr(b"", "decode"):
        assert utf8(b"test") == b"test"
        assert utf8(None) is None
        try:
            utf8(1)
        except TypeError:
            pass
        else:
            assert False


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:25:52.167100
# Unit test for function url_escape
def test_url_escape():
    url_escape("http:///www.baidu.com?wd=%E4%BD%A0%E5%A5%BD")



# Generated at 2022-06-24 08:25:59.239705
# Unit test for function utf8
def test_utf8():
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(None) is None
    # assert utf8(1) == b'1'
    # print(utf8(1))
    try:
        utf8(1)
    except TypeError as e:
        print(e)


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:01.549470
# Unit test for function native_str
def test_native_str():
    pass


_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-24 08:26:08.283955
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8("foo") == utf8("foo")
    assert utf8("foo") is utf8("foo")
    assert utf8("foo") == utf8(b"foo")
    assert utf8("foo") == utf8(u"foo")
    assert utf8("foo") is utf8(b"foo")
    assert utf8("foo") is utf8(u"foo")
    assert utf8(u"foo") is utf8(b"foo")
    assert utf8(b"foo") is utf8(u"foo")
    assert utf8(b"foo") is utf8(b"foo")
    assert utf8(b"foo") == utf8(u"foo")
   

# Generated at 2022-06-24 08:26:19.667989
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;') == '\''
    assert xhtml_unescape('<h2>&#39;</h2>') == "<h2>'</h2>"
    assert xhtml_unescape('&lt;h2&gt;&#39;&lt;/h2&gt;') == "<h2>'</h2>"
    assert xhtml_unescape('&#x26;&#x27;&#xa9;&#xae;&#x2122;') == "&\'©®™"
    assert xhtml_unescape('&amp;amp;&amp;&lt;&gt;') == "&amp;&<>"

# Generated at 2022-06-24 08:26:24.539674
# Unit test for function linkify
def test_linkify():
    assert (linkify(u'hello http://example.com world') ==
            u'hello <a href="http://example.com">http://example.com</a> world')
    assert (linkify(u'hello www.example.com world') ==
            u'hello <a href="http://www.example.com">www.example.com</a> world')
    assert (linkify(u'hello http://example.com:8000/foo/world?hello=world#test') ==
            u'hello <a href="http://example.com:8000/foo/world?hello=world#test">http://example.com:8000/foo/world?hello=world#test</a>')

# Generated at 2022-06-24 08:26:31.927880
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = b'a=1&a=2&b=3&b=4'
    result = parse_qs_bytes(qs)
    assert result == {'a': [b'1', b'2'], 'b': [b'3', b'4']}

test_parse_qs_bytes()



# Generated at 2022-06-24 08:26:36.047831
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    test_cases = {
        "&lt;foo &amp;&amp;&apos;bar&apos;&gt;": "<foo &&'bar'>",
        "&lt;foo&gt;&apos;bar&apos;&lt;/foo&gt;": "<foo>'bar'</foo>",
    }
    for unescaped, expected in test_cases.items():
        print(xhtml_unescape(unescaped))
#test_xhtml_unescape()



# Generated at 2022-06-24 08:26:38.864479
# Unit test for function url_escape
def test_url_escape():
    # type: () -> None
    assert url_escape('abc def') == 'abc%20def'
    assert url_escape('abc def', True) == 'abc+def'



# Generated at 2022-06-24 08:26:42.610729
# Unit test for function url_escape
def test_url_escape():
    value = 'abc 汉字'
    ret = url_escape(value)
    assert(ret.find('%') != -1)
    assert(ret.find('+') == -1)



# Generated at 2022-06-24 08:26:49.942698
# Unit test for function recursive_unicode
def test_recursive_unicode():
    import pytest
    with pytest.raises(TypeError):
        recursive_unicode(123)
    assert recursive_unicode(b"123") == "123"
    assert recursive_unicode([b"123", b"456"]) == ["123", "456"]
    assert recursive_unicode({"a": b"123", "b": [b"456", b"789"]}) == {"a": "123", "b": ["456", "789"]}
    assert recursive_unicode({"a": b"123", "b": [b"456", b"789"], (1, 2): "abc"}) == {"a": "123", "b": ["456", "789"], (1, 2): "abc"}

# Generated at 2022-06-24 08:26:52.098306
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&quot;") == '"'



# Generated at 2022-06-24 08:26:54.598943
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("foo  bar") == "foo bar"
    assert squeeze("   foo   bar   ") == "foo bar"



# Generated at 2022-06-24 08:26:58.816187
# Unit test for function json_decode
def test_json_decode():
    s = '{"age": 18, "name": "joe"}'
    print(json_decode(s))

test_json_decode()

_recursive_re_compile = re.compile(r"\$\{([^}]*)\}")



# Generated at 2022-06-24 08:27:07.186128
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert '&' == xhtml_unescape('&amp;')
    assert '"' == xhtml_unescape('&quot;')
    assert '<' == xhtml_unescape('&lt;')
    assert '>' == xhtml_unescape('&gt;')
    assert "'" == xhtml_unescape('&apos;')  #&apos; is not a standard html entity, but it is accepted
    assert '&#39;' == xhtml_unescape('&#39;')
    assert '&quot;' == xhtml_unescape('&quot;')
    assert '¢' == xhtml_unescape('&cent;')

_URL_RE = re.compile(r'%([0-9a-fA-F]{2})')



# Generated at 2022-06-24 08:27:10.852601
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('/test url') == '%2Ftest+url'
    assert url_escape('/test url', False) == '%2Ftest%20url'
    assert url_escape('/test url', True) == '%2Ftest+url'


# Generated at 2022-06-24 08:27:14.889610
# Unit test for function json_decode
def test_json_decode():
    s = '{"name":"adam","age":23}'
    print("json s: ", s)
    json_d = json.loads(s)
    print("json_d: ", json_d)
    print("json_d['name']: ", json_d['name'])
    print("json_d['age']: ", json_d['age'])


# Generated at 2022-06-24 08:27:25.828732
# Unit test for function json_encode
def test_json_encode():
    l = json_encode({'hello': "world"})
    assert l == '{"hello": "world"}'
    l = json_encode([1,2,3])
    assert l == '[1, 2, 3]'
    l = json_encode(None)
    assert l == 'null'
    l = json_encode(True)
    assert l == 'true'
    l = json_encode(False)
    assert l == 'false'
    l = json_encode(0)
    assert l == '0'


# Generated at 2022-06-24 08:27:31.777102
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(None) == "null"
    assert json_encode(False) == "false"
    assert json_encode(True) == "true"
    assert json_encode(0) == "0"
    assert json_encode(0.1) == "0.1"
    assert json_encode([1,2]) == '[1, 2]'
    assert json_encode({'a': 42}) == '{"a": 42}'



# Generated at 2022-06-24 08:27:34.825795
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#39;") == "'" and xhtml_unescape("&amp;") == "&"

_BASESTRING_DEFAULT = str
_UTF8_DEFAULT = "utf-8"

