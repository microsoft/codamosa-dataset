

# Generated at 2022-06-24 08:17:35.044207
# Unit test for function json_encode
def test_json_encode():
    a = {'name': 'kevin'}
    b = json_encode(a)
    c = json.dumps(a)
    print(b)
    print(c)


# Generated at 2022-06-24 08:17:43.498432
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    "test for function parse_qs_bytes"
    assert parse_qs_bytes(b'login=joe&password=god') == {b'login': [b'joe'], b'password': [b'god']}
    assert parse_qs_bytes(b'x=%26&y=%3d%3d%22%27%5c%0d%0a') == {b'x': [b'&'], b'y': [b'=="\'\\\r\n']}


# Generated at 2022-06-24 08:17:44.988977
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"
# End unit test


# Generated at 2022-06-24 08:17:51.433086
# Unit test for function linkify
def test_linkify():    
    text = u"Hello http://tornadoweb.org!"
    new_text = linkify(text)
    assert new_text == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    return
    # no longer works:
    new_text = linkify(text, shorten=True)
    assert new_text == u'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>!'
    new_text = linkify(text, require_protocol=True)
    assert new_text == u'Hello http://tornadoweb.org!'
    text = u"http://www.google.com http://www.yahoo.com"
    new_text = linkify(text, extra_params='class="external"')

# Generated at 2022-06-24 08:17:58.997514
# Unit test for function xhtml_escape
def test_xhtml_escape():
    s = "abc&<>'d"
    x = xhtml_escape(s)
    assert x == "abc&amp;&lt;&gt;&#39;d"
    assert isinstance(x, str)
    s = "abc&<>'d"
    x = xhtml_escape(s.encode('utf-8'))
    assert x == "abc&amp;&lt;&gt;&#39;d"
    assert isinstance(x, str)
test_xhtml_escape()

# to_unicode was previously named _unicode not because it was private,
# but to avoid conflicts with the built-in unicode() function/type

# Generated at 2022-06-24 08:18:07.574577
# Unit test for function linkify
def test_linkify():
  assert linkify('www.example.com') == '<a href="http://www.example.com">www.example.com</a>'
  assert 'javascript' not in linkify('javascript:alert(document.location)')
  assert linkify('foo@example.com') == '<a href="mailto:foo@example.com">foo@example.com</a>'
  assert linkify('foo@example.com', permitted_protocols=['mailto'])

test_linkify()



# Generated at 2022-06-24 08:18:08.327997
# Unit test for function url_escape
def test_url_escape(): url_escape("+")



# Generated at 2022-06-24 08:18:10.655468
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(
        "& < > \" '"
        ) == '&amp; &lt; &gt; &quot; &#39;'


# Generated at 2022-06-24 08:18:16.506773
# Unit test for function url_unescape

# Generated at 2022-06-24 08:18:21.425254
# Unit test for function utf8
def test_utf8():
    assert utf8('\u00e9') == b'\xc3\xa9'
    assert utf8(u'\u00e9') == b'\xc3\xa9'  # unicode type


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:27.657588
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&#60;") == "<"
    assert xhtml_unescape("&#x3c;") == "<"
    assert xhtml_unescape("&lt") == "&lt"
    assert xhtml_unescape("&#a60;") == "&#a60;"
    assert xhtml_unescape("&#xa60;") == "&#xa60;"


_UNSAFE = re.compile(r"[&<>\"']")



# Generated at 2022-06-24 08:18:30.984046
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("1", encoding=None) == b"1"
    assert url_unescape("1", encoding="utf-8") == "1"
    assert url_unescape("%2B", plus=False, encoding="utf-8") == "+"



# Generated at 2022-06-24 08:18:42.131629
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;abc&gt;') == '<abc>'
    assert xhtml_unescape('&#39;abc&#39;') == "'abc'"


# transliterations
# These functions are copied from python's html module in its stdlib, to
# maintain compatibility. It is possible that a future version of python
# will add these functions to the html module, in which case we may be able to
# remove our copies.
# This is the full copyright notice for python's html module:

"""Utility functions for dealing with HTML."""

# Copyright 1999-2012 by Fredrik Lundh
#
# By obtaining, using, and/or copying this software and/or its
# associated documentation, you agree that you have read, understood,
# and will comply with the following terms and conditions:
#
# Permission to use,

# Generated at 2022-06-24 08:18:47.828675
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'a=1&b=2&c=中文'
    parsed = parse_qs_bytes(qs)
    assert parsed == {
    'a': [b'1'],
    'b': [b'2'],
    'c': [b'\xe4\xb8\xad\xe6\x96\x87']
    }

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:18:50.775233
# Unit test for function json_decode
def test_json_decode():
    # type: () -> None
    l1 = [1, 2, 3]
    l2 = json_decode(json_encode(l1))
    assert l1 == l2
test_json_decode()



# Generated at 2022-06-24 08:18:54.367909
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    xhtml_unescape('''&#39;&#34;&#38;''')
    xhtml_unescape('''&amp;#39;&quot;&amp;''')



# Generated at 2022-06-24 08:19:05.699588
# Unit test for function squeeze
def test_squeeze():
    test_string = "Hello World!  This is a test string."
    assert squeeze(test_string) == "Hello World! This is a test string."
    assert squeeze("    Hello World   ") == "Hello World"
    assert squeeze("\tHello World") == "Hello World"
    assert squeeze("Hello\tWorld") == "Hello World"
    assert squeeze("Hello    World") == "Hello World"
    assert squeeze("Hello World") == "Hello World"

# Based on https://github.com/facebook/tornado/blob/master/tornado/escape.py.
# Copyright 2009 Facebook
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#     http://www.apache.org

# Generated at 2022-06-24 08:19:15.883863
# Unit test for function native_str
def test_native_str():
    '''
    text = "我是中文"
    # 如果text不是unicode，则会抛出异常
    print('1'.encode('ascii'))

    # 如果text是unicode，则还原为utf8的编码
    print(text.encode('utf8'))
    '''
    text = "我是中文"
    print('1'.decode('ascii'))



# Generated at 2022-06-24 08:19:24.239219
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print (parse_qs_bytes("foo=bar&baz=quux"))
test_parse_qs_bytes()


# urllib.parse.unquote_to_bytes is new in python3.5; fall back to a
# compatibility version on older versions
if getattr(urllib.parse, "unquote_to_bytes", None) is None:
    _unquote_to_bytes = lambda s: urllib.parse.unquote(s).encode("utf8")
else:
    _unquote_to_bytes = urllib.parse.unquote_to_bytes



# Generated at 2022-06-24 08:19:30.128104
# Unit test for function url_escape
def test_url_escape():
    # Make sure calling with unicode doesn't fail.
    # On python3, url_escape always returns unicode, and calling it with
    # bytes will fail.  On python2, url_escape can return either and
    # it's up to the caller to use the right one.
    url_escape(b'\xc3\xa9')



# Generated at 2022-06-24 08:19:33.495166
# Unit test for function utf8
def test_utf8():
    assert utf8(b'abc') == b'abc'
    assert utf8(u'abc') == b'abc'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:39.914962
# Unit test for function url_escape
def test_url_escape():
    # Warning: we cannot test the plus=True case because
    # Python's unquote_plus does not allow the plus character
    # to be escaped.
    assert url_escape("foo bar") == urllib.parse.quote("foo bar")
    assert url_escape("/") == "%2F"



# Generated at 2022-06-24 08:19:48.016686
# Unit test for function utf8
def test_utf8():  # pragma: no cover
    assert utf8("\xe9") == b"\xc3\xa9"
    assert utf8("abcd") == b"abcd"
    assert utf8(None) is None
    try:
        utf8(u"\xe9")
        assert False
    except TypeError:
        pass
    try:
        utf8("\xe9".encode("ascii"))
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:56.097513
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   a") == "a"
    assert squeeze("a   ") == "a"
    assert squeeze("   a   ") == "a"
    assert squeeze("   a b  c   ") == "a b c"
    assert squeeze("a. . .b. . .".replace(".", "\x00")) == "a b"

    # All the whitespace chars in the 'skip' list below are
    # translated to spaces for squeeze()

# Generated at 2022-06-24 08:19:59.414159
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div>Hello World!</div>") == "&lt;div&gt;Hello World!&lt;/div&gt;"

# Generated at 2022-06-24 08:20:06.533462
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&lt;&gt;&amp;&quot;&#39;") == r"<>&\"'"
    with pytest.raises(Exception) as excinfo:
        xhtml_unescape(b"&#39;")
    assert isinstance(excinfo.value, Exception)
    assert excinfo.value.args == (
        "'to_basestring' requires a str or bytes object",
    )



# Generated at 2022-06-24 08:20:10.714249
# Unit test for function url_unescape
def test_url_unescape():
	# define a str
	str1="test"
	# define a byte
	byte1=b"yes"
	# test method when byte type
	assert url_unescape(byte1)==b'yes'
	# test method when str type
	assert url_unescape(str1,encoding='utf-8')=='test'



# Generated at 2022-06-24 08:20:14.029954
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("a\"b") == "a&quot;b"
    assert xhtml_escape(b"") == ""
    assert xhtml_escape(b"a") == "a"


# Generated at 2022-06-24 08:20:17.032620
# Unit test for function utf8
def test_utf8():
    result = utf8('abc')
    assert type(result) == bytes
    assert result == b'abc'



# Generated at 2022-06-24 08:20:21.261590
# Unit test for function json_decode
def test_json_decode():
    assert(len(json_decode(b'{"a":5,"b":[2]}')) == 2)
    assert(json_decode(b'{"a":5,"b":[2]}')["a"] == 5)
    print("test json_decode passed")



# Generated at 2022-06-24 08:20:26.911678
# Unit test for function native_str
def test_native_str():
    assert to_unicode(b"foo") == u"foo"
    assert to_unicode(u"foo") == u"foo"
    assert to_unicode(None) is None
    try:
        to_unicode(object())
        assert 0, "did not get expected exception"
    except TypeError:
        pass


_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-24 08:20:29.802710
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#34;&#39;&#60;&#62;&#38;") == "\"'<>&"

# Generated at 2022-06-24 08:20:36.040783
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode((1, 2)) == (1, 2)
    assert recursive_unicode({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert recursive_unicode({"a": b"1", "b": b"2"}) == {"a": "1", "b": "2"}
    assert recursive_unicode([1, [b"2", [b"3"], 4]]) == [1, ["2", ["3"], 4]]
    assert recursive_unicode([1, (b"2", b"3", 4)]) == [1, ("2", "3", 4)]



# Generated at 2022-06-24 08:20:40.934767
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert ("&lt;script&gt;&lt;/script&gt;").replace("&lt;","<").replace("&gt;",">") == "<script></script>"


# to_unicode was previously captured here for backwards compatibility,
# but it is no longer used by Tornado. To avoid breaking scripts that
# import this method from Tornado, we make it an alias for str.
to_unicode = str

# to_basestring is used for ensuring both byte and unicode strings
# are handled properly.  Strings are passed through, but bytes are
# decoded to unicode.
if typing.TYPE_CHECKING:
    to_basestring = Union[str, unicode_type]

# Generated at 2022-06-24 08:20:51.781756
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    if xhtml_unescape("&lt;div&gt;&amp;&lt;/div&gt;") == "<div>&<div>":
        return True
    else:
        raise RuntimeError("Unittest failed")
test_xhtml_unescape()

# Per http://www.w3.org/TR/html4/sgml/entities.html
# Also contains HTML5 specific entities.

# Generated at 2022-06-24 08:20:56.188075
# Unit test for function native_str
def test_native_str():  # noqa: F811
    assert isinstance(native_str(b"foo"), str)
    assert isinstance(native_str(u"foo"), str)
    assert native_str(b"foo") == "foo"
    assert native_str(u"foo") == "foo"
    assert native_str(None) is None



# Generated at 2022-06-24 08:21:07.085810
# Unit test for function linkify
def test_linkify():
    assert linkify(u"http://x.com") == u'<a href="http://x.com">http://x.com</a>'
    assert linkify(u"http://x.com, y.com") == u'<a href="http://x.com">http://x.com</a>, <a href="http://y.com">y.com</a>'
    assert linkify(u"http://x.com?y=1&z=2") == u'<a href="http://x.com?y=1&amp;z=2">http://x.com?y=1&amp;z=2</a>'

# Generated at 2022-06-24 08:21:11.105630
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('1 2 3') == '1 2 3'
    assert squeeze('1  2  3') == '1 2 3'
    assert squeeze('1 \t\n2 \t\n3') == '1 2 3'
    
    

# Generated at 2022-06-24 08:21:17.388742
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": 1, "b": [1, 2, 3], "c": "c"}) == '{"a": 1, "b": [1, 2, 3], "c": "c"}'

_JSON_DECODE_FUNCS = {int: int, str: str, unicode_type: str}
try:
    import decimal
except ImportError:
    pass
else:
    _JSON_DECODE_FUNCS[decimal.Decimal] = float



# Generated at 2022-06-24 08:21:21.921379
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("abc") =="abc"
    assert url_unescape(b"abc") == b"abc"
    assert url_unescape("%00") == b"\x00"
    assert url_unescape(b"%00") == b"\x00"
    # The + replacement isn't applied when you pass an encoding argument
    assert url_unescape("abc+def") == "abc+def"
    assert url_unescape("abc+def", plus=False) == "abc+def"
    assert url_unescape("abc def") == "abc def"
    assert url_unescape("abc def", plus=False) == "abc def"
    assert url_unescape("abc+def", encoding="utf-8") == "abc+def"

# Generated at 2022-06-24 08:21:25.344788
# Unit test for function json_encode
def test_json_encode():
    data = {"a":"b", "c":"/"}
    assert(json_encode(data) == '{"a": "b", "c": "\\/"}')


# The fact that json_decode wraps json.loads is an implementation detail.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-24 08:21:32.249680
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://www.google.com/?name=hongliang") == "http%3A//www.google.com/?name=hongliang"
    assert url_escape("http://www.google.com/?name=hongliang", plus=False) == "http%3A//www.google.com/?name=hongliang"



# Generated at 2022-06-24 08:21:33.969648
# Unit test for function json_decode
def test_json_decode():
    a=json_decode('[1,2,3]')
    print(a)

# Generated at 2022-06-24 08:21:40.058382
# Unit test for function native_str
def test_native_str():
    c = bytearray("\xcf\x80", "utf-8")
    assert native_str(c) == u"\u03c0"

    d = bytearray("\xc2\x80", "utf-8")
    assert native_str(d) == u"\u0080"



# Generated at 2022-06-24 08:21:46.323935
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:21:48.003847
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert isinstance(xhtml_unescape("&lt;&gt;"), str)


# Generated at 2022-06-24 08:21:57.553463
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = {'a': ['b', 'c'], 'd': {'e': 'f'}, 'g': 'h'}
    obj_unicode = recursive_unicode(obj)
    assert type(obj_unicode) == dict
    assert type(obj_unicode['a']) == list
    assert type(obj_unicode['a'][0]) == str
    assert type(obj_unicode['a'][1]) == str
    assert type(obj_unicode['d']) == dict
    assert type(obj_unicode['d']['e']) == str
    assert type(obj_unicode['g']) == str

_BASESTRING_TYPES = (unicode_type, bytes, type(None))



# Generated at 2022-06-24 08:22:05.513695
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<div class="foo"></div>') == '&lt;div class=&quot;foo&quot;&gt;&lt;/div&gt;'


# to_unicode was previously undocumented, but apparently widely used; it
# is now part of our public API.
# If to_unicode ever gets non-trivial translations or encodings, we will have
# to rev the major version number and mark the previous implementation as
# deprecated.


# Generated at 2022-06-24 08:22:15.657296
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    v = 'x=1&y=2'
    r = parse_qs_bytes(v.encode('ascii'))
    assert(r == {'x':[b'1'], 'y':[b'2']})
    r = parse_qs_bytes(b'x=1&y=2')
    assert(r == {'x':[b'1'], 'y':[b'2']})

# Generated at 2022-06-24 08:22:20.346148
# Unit test for function url_escape
def test_url_escape():
    assert 'https%3A%2F%2Fblog.gitea.io%2F2018%2F08%2F23%2Fgitea-1-5-is-released%2F' == url_escape(
        'https://blog.gitea.io/2018/08/23/gitea-1-5-is-released/')



# Generated at 2022-06-24 08:22:29.412637
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http://example.com/path%20with%20spaces") == "http://example.com/path with spaces"
    assert url_unescape(b"path%20with%20spaces") == "path with spaces"
    assert url_unescape("path%20with%20spaces", encoding=None) == b"path with spaces"
    assert url_unescape("path%20with%20spaces", plus=False) == "path%20with%20spaces"
    assert url_unescape("path+with+spaces", plus=True) == "path with spaces"
    assert url_unescape("path+with+spaces") == "path with spaces"
    assert url_unescape("http://example.com/path+with+spaces") == "http://example.com/path with spaces"


# Generated at 2022-06-24 08:22:31.739548
# Unit test for function url_escape
def test_url_escape():
    print(url_escape("http://example.com"))
    print(url_escape("http://example.com", False))

# test_url_escape()


# Generated at 2022-06-24 08:22:42.645293
# Unit test for function native_str
def test_native_str():
    assert native_str('привет') == '\\u043f\\u0440\\u0438\\u0432\\u0435\\u0442'
    assert native_str('привет'.encode('utf-8')) == '\\u043f\\u0440\\u0438\\u0432\\u0435\\u0442'
    assert native_str('привет'.encode('latin1')) == '\xcf\xf0\xe8\xe2\xe5\xf2'
    assert native_str(b'\xcf\xf0\xe8\xe2\xe5\xf2') == 'привет'

# Generated at 2022-06-24 08:22:50.993625
# Unit test for function utf8
def test_utf8():
    assert utf8(b'foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8('foo') == b'foo'
    assert utf8(None) is None
    try:
        utf8(42)
        assert False, 'utf8(42) did not raise correct exception'
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:23:01.039188
# Unit test for function utf8
def test_utf8():
    test = lambda x: utf8(x) == x.encode("utf-8")
    assert test("hello")
    assert test("")
    assert test("\u2603")
    assert test("\xe2\x98\x83")
assert utf8("hello") == b"hello"
assert utf8("") == b""
assert utf8("\u2603") == b"\xe2\x98\x83"
assert utf8("\xe2\x98\x83") == b"\xe2\x98\x83"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:23:03.934982
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"foo":"bar"}') == {'foo': 'bar'}
    assert json_decode(b'{"foo":"bar"}') == {'foo': 'bar'}



# Generated at 2022-06-24 08:23:12.787304
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"") == {}
    assert parse_qs_bytes(b"asdf") == {}
    assert parse_qs_bytes(b"a=1") == {"a": [b"1"]}
    assert parse_qs_bytes(b"a=1&b=2") == {"a": [b"1"], "b": [b"2"]}
    assert parse_qs_bytes(b"a=1&a=2") == {"a": [b"1", b"2"]}
    assert parse_qs_bytes(b"a=1&b=&a=2") == {"a": [b"1", b"2"], "b": [b""]}
    assert parse_qs_bytes(b"q=%F6") == {"q": [b"\xc3\xb6"]}

# Generated at 2022-06-24 08:23:18.733234
# Unit test for function utf8
def test_utf8():
    res = utf8('中华人民共和国')
    assert isinstance(res, bytes)
    res = utf8(None)
    assert res is None



# Generated at 2022-06-24 08:23:28.167983
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape(">") == "&gt;"
    assert xhtml_escape("\"") == "&quot;"
    assert xhtml_escape("\'") == "&#39;"
    assert xhtml_escape("&") == "&amp;"


# json_encode, json_decode moved to escape.py to avoid a circular import

_URL_ESCAPE_RE = re.compile(r"[^\w\-\.~]")
_URL_ESCAPE_SLOW_RE = re.compile(r"[^/\w\-\.~%]")

# Generated at 2022-06-24 08:23:29.594751
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("abc    def") == 'abc def'


# Generated at 2022-06-24 08:23:31.102650
# Unit test for function json_decode
def test_json_decode():
    s = json_decode('{"a":1}')
    assert s['a'] == 1


# Generated at 2022-06-24 08:23:40.477053
# Unit test for function xhtml_escape
def test_xhtml_escape():
    s = "&<>\"'"
    assert xhtml_escape("&<>\"'") == s
    assert xhtml_escape(s) == s
    assert xhtml_escape(b"&<>\"'") == s

_JS_ESCAPE_RE = re.compile(r'[\x00-\x19\\"\b\f\n\r\t]')

# Generated at 2022-06-24 08:23:43.562626
# Unit test for function linkify
def test_linkify():
    assert (linkify("http://example.com") == '<a href="http://example.com">example.com</a>')

# Generated at 2022-06-24 08:23:52.960825
# Unit test for function native_str
def test_native_str():
    # These should all be equal to the repr equivalent
    assert native_str(123) == "123"
    assert native_str(u'foo') == repr('foo')
    assert native_str(u"foo") == repr('foo')
    assert native_str(u'foo %s') == repr('foo %s')
    # This is a non-printable non-ASCII character
    assert native_str(u'\xA8 bar') == repr(u'\xA8 bar'.encode('utf8'))
    # This is a non-printable ASCII character
    assert native_str(u'foo \x07 bar') == repr(u'foo \x07 bar'.encode('utf8'))
    # This is a printable character but one that doesn't look like
    # anything in ASCII.

# Generated at 2022-06-24 08:23:58.072660
# Unit test for function squeeze
def test_squeeze():
    # make sure that the function squeeze can deal with whitespace characters
    a = "hello    world"
    b = "hello world"
    assert(squeeze(a) == b) == True


# Generated at 2022-06-24 08:24:06.159274
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("/") == "%2F"
    assert url_escape("/", plus=False) == "%2F"
    assert url_escape("/", plus=True) == "%2F"
    assert url_escape("+") == "%2B"
    assert url_escape("+", plus=False) == "%2B"
    assert url_escape("+", plus=True) == "+"
    assert url_escape("a b") == "a+b"
    assert url_escape("a b", plus=False) == "a%20b"



# Generated at 2022-06-24 08:24:12.930592
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8(b"foo") == b"foo"
    assert utf8(None) is None
    try:
        utf8(u"foo")
        assert False
    except TypeError:
        pass

    try:
        utf8(object())
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:24:13.804294
# Unit test for function native_str
def test_native_str():
    assert str(1) == "1"

# Generated at 2022-06-24 08:24:20.048567
# Unit test for function linkify
def test_linkify():
    text = linkify("Hello http://tornadoweb.org!")
    print(text)
    text = linkify("Hello http://tornadoweb.org!", shorten=True)
    print(text)
    text = linkify(
        "Hello http://tornadoweb.org!",
        extra_params='rel="nofollow" class="external"',
    )
    print(text)
    text = linkify(
        "Hello http://tornadoweb.org!",
        require_protocol=True,
    )
    print(text)
    text = linkify(
        "Hello http://tornadoweb.org!",
        require_protocol=True,
        permitted_protocols=["http", "ftp", "mailto"],
    )
    print(text)

# Generated at 2022-06-24 08:24:23.384183
# Unit test for function json_encode
def test_json_encode():
    print('test json_encode')
    assert json_encode(42) == "42"
    assert json_encode(42.5) == "42.5"

test_json_encode()



# Generated at 2022-06-24 08:24:33.154362
# Unit test for function squeeze
def test_squeeze():
    print('\nTest squeeze')
    print(squeeze(''))
    print(squeeze(' '))
    print(squeeze(' one '))
    print(squeeze('  one  two  '))
    print(squeeze('\tone\ttwo\n'))
    print(squeeze('\tone\ttwo\n'))
    print(squeeze(' \t \t\r \t  \n \r\t test \r\t\r'))
test_squeeze()

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:24:39.706573
# Unit test for function native_str
def test_native_str():
    assert native_str('ahoj') == 'ahoj'
    assert native_str(b'ahoj') == 'ahoj'
    assert native_str(bytearray(b'ahoj')) == 'ahoj'
    assert native_str(u'ahoj') == 'ahoj'
    assert native_str(2) == '2'
    assert native_str(2.50) == '2.5'
    assert native_str(to_unicode('ahoj')) == 'ahoj'

test_native_str()


# Generated at 2022-06-24 08:24:41.684661
# Unit test for function url_escape
def test_url_escape():
    return url_escape


# Generated at 2022-06-24 08:24:52.027300
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a   b   c") == "a b c"
    assert squeeze("    a") == "a"
    assert squeeze("a   ") == "a"
    assert squeeze("  a  b c   ") == "a b c"


# Dicts of code:name for all XHTML entities
# From cgi.escape in Python 3.2
_html_entity_defs = {name: "&{};".format(name) for name in ('lt gt amp quot apos'.split())}
# From html.entitites in Python 3.2
_html_entity_defs.update(html.entities.entitydefs)


# Generated at 2022-06-24 08:24:53.423932
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(True) == "true"


# Generated at 2022-06-24 08:24:58.610141
# Unit test for function linkify
def test_linkify():
    text = '''
        Invite me to your party! More info: www.tornadoweb.org and
        https://github.com/tornadoweb/tornado.
    '''
    assert (
        linkify(text)
        == '''
        Invite me to your party! More info: <a href="http://www.tornadoweb.org">www.tornadoweb.org</a> and
        <a href="https://github.com/tornadoweb/tornado">https://github.com/tornadoweb/tornado</a>.
    '''
        # TODO: unify whitespace in this string and remove the next line
        .strip()
    )

# Generated at 2022-06-24 08:25:03.888405
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"foo=bar&baz=blah&c%2Bd=e%20f") == {
        b'c+d': [b'e f'],
        b'baz': [b'blah'],
        b'foo': [b'bar'],
    }


# html_escape and xhtml_escape are the same function.
html_escape = xhtml_escape



# Generated at 2022-06-24 08:25:06.724526
# Unit test for function squeeze
def test_squeeze():
    print(squeeze("This is    a string"))
    print(squeeze("This is\n a string"))
    print(squeeze("This is a string"))


# Generated at 2022-06-24 08:25:09.688693
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&<>"\'') == "&amp;&lt;&gt;&quot;&#39;"



# Generated at 2022-06-24 08:25:13.508870
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    dic = parse_qs_bytes("a=b&c=d&e=f")
    assert dic == b"{'a': ['b'], 'c': ['d'], 'e': ['f']}" 


# Generated at 2022-06-24 08:25:20.326920
# Unit test for function linkify

# Generated at 2022-06-24 08:25:25.156697
# Unit test for function native_str
def test_native_str():
    assert native_str('\xc3\xa9') == u'\xe9'.encode()



# Generated at 2022-06-24 08:25:28.240472
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('value', True) == 'value'
    assert url_escape('value', False) == 'value'
    assert url_escape('value') == 'value'


# Generated at 2022-06-24 08:25:35.776251
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():  #noqa
    assert parse_qs_bytes(b"foo=bar&baz=ding") == {b"foo": [b"bar"], b"baz": [b"ding"]}
    assert parse_qs_bytes(b"foo=bar&foo=ding") == {b"foo": [b"bar", b"ding"]}


# When dealing with the unicode representation of URLs (i.e. PATH_INFO),
# use urllib.parse.unquote instead of decode('string_escape').  See
# http://bugs.python.org/issue23885 for details.

# Generated at 2022-06-24 08:25:46.595309
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=bar%3D') == {b'foo': [b'bar=']}
    assert parse_qs_bytes(b'foo=bar=baz') == {b'foo': [b'bar=baz']}
    assert parse_qs_bytes(b'foo=bar&bar=baz') == {b'foo': [b'bar'], b'bar': [b'baz']}
    assert parse_qs_bytes(b'foo=bar&bar=baz&bar=bax') == {b'foo': [b'bar'], b'bar': [b'baz', b'bax']}
    assert parse_qs_bytes(b'foo=bar&bar=') == {b'foo': [b'bar'], b'bar': [b'']}

# Generated at 2022-06-24 08:25:48.835718
# Unit test for function url_escape
def test_url_escape():
    print(url_escape('http://localhost:8899/a?a=1&b=2'))
#test_url_escape()



# Generated at 2022-06-24 08:25:56.684721
# Unit test for function linkify
def test_linkify():
    from nose.tools import assert_equal

# Generated at 2022-06-24 08:26:04.866454
# Unit test for function recursive_unicode

# Generated at 2022-06-24 08:26:08.254329
# Unit test for function utf8
def test_utf8():
    assert utf8(u"abc") == b"abc"
    assert utf8("abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(None) is None

    # These will raise TypeError:
    # utf8(10)
    # utf8(object())
    # utf8(dict())



# Generated at 2022-06-24 08:26:11.402809
# Unit test for function json_decode
def test_json_decode():
    result = json_decode('{"name":"human","age":18}')
    assert type(result) is dict
    assert result == {"name": "human", "age": 18}


# Generated at 2022-06-24 08:26:21.560648
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = b'a=1&b=%C3%A9'
    result = parse_qs_bytes(qs)
    if isinstance(result, list):
        assert result[0] == b'1'
        assert result[1] == b'\xc3\xa9'
    else:
        assert result['a'][0] == b'1'
        assert result['b'][0] == b'\xc3\xa9'
    qs = 'a=1&b=%C3%A9'
    result = parse_qs_bytes(qs)
    if isinstance(result, list):
        assert result[0] == b'1'
        assert result[1] == b'\xc3\xa9'
    else:
        assert result['a'][0] == b'1'


# Generated at 2022-06-24 08:26:25.861100
# Unit test for function recursive_unicode
def test_recursive_unicode():
    '''
    test for recursive_unicode
    '''
    assert recursive_unicode({'foo':b'hello'})=={'foo':'hello'}
    assert recursive_unicode([b'hello',b'world'])==['hello','world']
    assert recursive_unicode(b'hello')=='hello'


# Generated at 2022-06-24 08:26:30.495387
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert (xhtml_escape("<html>") == "&lt;html&gt")
    assert (xhtml_escape("\"") == "&quot;")


# Generated at 2022-06-24 08:26:35.418820
# Unit test for function url_unescape
def test_url_unescape():  # noqa: F811
    assert url_unescape("Hello%20G%C3%B6del") == "Hello G\u00f6del"
    assert url_unescape("Hello+G%C3%B6del", encoding=None) == b"Hello G\xc3\xb6del"
    assert url_unescape("Hello+G%C3%B6del", encoding="utf-8") == "Hello G\u00f6del"



# Generated at 2022-06-24 08:26:38.248371
# Unit test for function url_unescape
def test_url_unescape(): # noqa: F811
    url_unescape(value=b"%21%23%24%26%27%28%29%2A%2B%2C%3B%3D%3F%40%5B%5D%5E%60%7B%7D%7E", encoding=None, plus=True)

# Generated at 2022-06-24 08:26:42.459164
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%E4%B8%AD%E6%96%87') == '中文', repr(url_unescape('%E4%B8%AD%E6%96%87'))



# Generated at 2022-06-24 08:26:48.361163
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes("a=1&b=2&c=3&d=", True)
    assert type(result['c'][0]) == bytes
    assert result['c'][0] == b'3'
    assert result['c'][0] != b'c'
    assert result['d'][0] == b''



# Generated at 2022-06-24 08:27:00.310084
# Unit test for function utf8
def test_utf8():
    assert utf8("hello") == b"hello"
    assert utf8("hello".encode("utf-8")) == b"hello"
    assert utf8("hello 世界") == b"hello \xe4\xb8\x96\xe7\x95\x8c"
    assert (
        utf8("hello 世界".encode("utf-8")) == b"hello \xe4\xb8\x96\xe7\x95\x8c"
    )
    assert utf8(b"hello") == b"hello"

# Generated at 2022-06-24 08:27:11.397027
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str(u'\xe9'), str)
    assert isinstance(native_str(b'\xc3\xa9'), str)

if str is unicode_type:  # type: ignore
    native_str = to_unicode  # type: ignore
else:
    native_str = utf8  # type: ignore

# These mapping are used to fixup some of the differences between
# Python 2 and Python 3 and to remove non-alphanumeric characters
# from the string.

# Generated at 2022-06-24 08:27:12.950616
# Unit test for function native_str
def test_native_str():
    assert native_str(b"test") is "test"
    assert native_str(u"test") is "test"

# Generated at 2022-06-24 08:27:19.923698
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'foo') == 'foo'
    assert url_unescape(b'foo', encoding=None) == 'foo'
    assert url_unescape(b'foo', encoding=None, plus=False) == 'foo'
    assert url_unescape(b'foo', encoding='utf-8') == 'foo'
    assert isinstance(url_unescape(b'foo', encoding='utf-8'), str)
    assert url_unescape(b'foo', encoding='utf-8', plus=False) == 'foo'
    assert isinstance(url_unescape(b'foo', encoding='utf-8', plus=False), str)
    assert url_unescape(u'foo', encoding='utf-8') == 'foo'

# Generated at 2022-06-24 08:27:25.925867
# Unit test for function native_str
def test_native_str():
    """Test that native_str() accepts both bytes and unicode."""
    native_str(b"abc")
    native_str("abc")
    try:
        native_str(1)
    except TypeError:
        pass
    else:
        assert False, "native_str(1) didn't raise TypeError"



# Generated at 2022-06-24 08:27:34.329081
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("abc") == "abc"
    assert url_unescape("abc", plus=False) == "abc"
    assert url_unescape("abc", encoding=None) == b"abc"
    assert url_unescape("abc", encoding=None, plus=False) == b"abc"
    assert url_unescape("%C3%B6") == "ö"
    assert url_unescape("%C3%B6", plus=False) == "ö"