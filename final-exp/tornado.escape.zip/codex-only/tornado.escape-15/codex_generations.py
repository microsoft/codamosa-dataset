

# Generated at 2022-06-24 08:17:34.407602
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Create a query string
    query_string = 'a=1&b=2&b=3&b=4'
    # Parse a query string by using the function parse_qs_bytes
    result = parse_qs_bytes(query_string, keep_blank_values = False, strict_parsing = False)
    # Assert the result
    assert result == {'a': [b'1'], 'b': [b'2', b'3', b'4']}, "Should be equal"

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:17:43.408201
# Unit test for function native_str
def test_native_str():
    assert native_str(b"foo") == "foo"
    assert native_str(u"foo") == "foo"
    assert native_str(b"foo", "latin1") == "foo"
    assert native_str(u"\u2603", "latin1") == "\u2603"


# python2/3 compatibility
try:
    _unicode = unicode
    _basestring = basestring
    _str = str
except NameError:
    _unicode = str
    _basestring = str
    _str = bytes



# Generated at 2022-06-24 08:17:48.539737
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape ('&amp;') == '&'
    assert xhtml_unescape ('&#62;') == '>'
    assert xhtml_unescape ('&lt;') == '<'
    assert xhtml_unescape ('&gt;') == '>'
    assert xhtml_unescape ('&#39;') == '\''
    assert xhtml_unescape ('&#34;') == '"'
    assert xhtml_unescape ('&quot;') == '"'


# Generated at 2022-06-24 08:17:51.423038
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("ab c  d e   fghi  jklm    nopq") == "ab c d e fghi jklm nopq"



# Generated at 2022-06-24 08:17:59.910512
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&apos;") == "'"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("foo &amp; bar") == "foo & bar"
    assert xhtml_unescape("&#32;") == " "
    assert xhtml_unescape("&#x20;") == " "
    assert xhtml_unescape("&#x7e;") == "~"
    assert xhtml_unescape("&#127;") == "\u007f"
    assert xhtml_unescape("&#37;") == "%"
    assert x

# Generated at 2022-06-24 08:18:05.115200
# Unit test for function utf8
def test_utf8():
    assert utf8("hello") == b"hello"
    assert utf8("\xc2\xa2") == b"\xc2\xa2"
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:13.296660
# Unit test for function xhtml_escape
def test_xhtml_escape():
    """
    Unit test for xhtml_escape
    :return:
    """

# Generated at 2022-06-24 08:18:24.246449
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    inputs = [
        (b"", {}),
        (b"a=b", {"a": [b"b"]}),
        (b"a=b=c", {"a": [b"b=c"]}),
        (b"&=b", {"": [b"b"]}),
        (b"&&&=b", {"": [b"", b"", b"b"]}),
        (b"a=1&a=2", {"a": [b"1", b"2"]}),
    ]
    for qs, expected in inputs:
        assert parse_qs_bytes(qs) == expected
        assert parse_qs_bytes(qs, keep_blank_values=True) == expected
url_escape_unicode = url_escape
url_unescape_unicode = url_unescape
_UTF8

# Generated at 2022-06-24 08:18:27.675330
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str(""), str)


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:18:36.492620
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("1 > 2") == '1 &gt; 2'
    assert xhtml_escape("1 < 2") == '1 &lt; 2'
    assert xhtml_escape("""1 < 2 & "quoted" 'text'""") == '1 &lt; 2 &amp; "quoted" &#39;text&#39;'
    assert xhtml_escape("1 & 2") == '1 &amp; 2'


# Generated at 2022-06-24 08:18:41.144786
# Unit test for function linkify
def test_linkify():
    assert linkify("foo http://example.com/") == (
        'foo <a href="http://example.com/" rel="nofollow">'
        'http://example.com/</a>'
    )
    assert linkify('foo http://example.com/\nbar') == (
        'foo <a href="http://example.com/" rel="nofollow">'
        'http://example.com/</a>\nbar'
    )
    assert linkify('foo <a href="http://example.com">http://example.com</a>') == (
        'foo <a href="http://example.com" rel="nofollow">'
        'http://example.com</a>'
    )

# Generated at 2022-06-24 08:18:47.786237
# Unit test for function utf8
def test_utf8():
    assert isinstance(utf8("foo"), bytes)
    assert isinstance(utf8(u"foo"), bytes)
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(u"\u1234") == b"\xe1\x88\xb4"
    assert utf8(None) is None
    assert utf8(123) == b"123"



# Generated at 2022-06-24 08:18:56.980020
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"x": "y"}) == {"x": "y"}
    assert recursive_unicode({"x": b"y"}) == {"x": "y"}
    assert recursive_unicode({"x": ["y"]}) == {"x": ["y"]}
    assert recursive_unicode({"x": [b"y"]}) == {"x": ["y"]}
    assert recursive_unicode([b"y"]) == ["y"]
    assert recursive_unicode((b"y",)) == ("y",)
    assert recursive_unicode("y") == "y"
    assert recursive_unicode(b"y") == "y"



# Generated at 2022-06-24 08:19:01.549594
# Unit test for function json_encode
def test_json_encode():
  val = {'test': 5}
  assert(json_encode(val) == '{"test": 5}')


_JSON_DECODE_PATTERN = re.compile(r"^\s*\w+\s*\((.*)\)\s*;?\s*$")



# Generated at 2022-06-24 08:19:12.360130
# Unit test for function utf8
def test_utf8():
    def t(v, expected):
        res = utf8(v)
        if res != expected:
            raise Exception(
                "utf8(%s) = %s; expected %s" % (repr(v), repr(res), repr(expected))
            )

    t("", b"")
    t("foo", b"foo")
    # this is the unittest.TestCase assertEqual in python3
    t(None, None)
    t(b"", b"")
    t(b"foo", b"foo")
    t(u"", b"")
    t(u"foo", b"foo")
    class UnicodeSubclass(unicode_type):
        pass
    t(UnicodeSubclass("foo"), b"foo")
    t(b"foo", b"foo")



# Generated at 2022-06-24 08:19:18.036691
# Unit test for function json_decode
def test_json_decode():
    s_json = r'{ "key1": "value1", "key2": [ "value2", "value3" ] }'
    obj = json_decode(s_json)
    assert len(obj) == 2
    assert obj['key1'] == 'value1'
    assert len(obj['key2']) == 2
    assert obj['key2'][0] == 'value2'
    assert obj['key2'][1] == 'value3'



# Generated at 2022-06-24 08:19:22.647966
# Unit test for function native_str
def test_native_str():
    s = 'hello world'
    assert native_str(s) is s
    assert native_str(b'hello world') is s
    assert native_str(u'hello world') is s


_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-24 08:19:23.655889
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == '<'



# Generated at 2022-06-24 08:19:30.699084
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8("Hello") == b'Hello'
    assert utf8(b'Hello') == b'Hello'
    assert utf8(u'\u1234') == b'\xe1\x88\xb4'
    #test_utf8()

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:40.676917
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert(parse_qs_bytes(b'key=val&key%20with%20spaces=val') == {'key': [b'val'], 'key with spaces': [b'val']})
    assert(parse_qs_bytes(b'key=val&key%20with%20spaces=val', keep_blank_values=True) == {'key': [b'val'], 'key with spaces': [b'val']})
    assert(parse_qs_bytes(b'key=val&key%20with%20spaces=val', keep_blank_values=False) == {'key': [b'val'], 'key with spaces': [b'val']})

# Generated at 2022-06-24 08:19:45.422544
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    value = 'name=jack&age=10'
    res = parse_qs_bytes(value)
    assert (res == {'name': [b'jack'], 'age': [b'10']})

_UTF8_TYPES = (bytes, type(None))
_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:49.975750
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("e'&<>") == "e&#39;&amp;&lt;&gt;"
    assert xhtml_escape("e<>") == "e&lt;&gt;"
    assert xhtml_escape("e") == "e"

_unicode_type = str

# Generated at 2022-06-24 08:19:54.627097
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"

    x = "a\xd0\xa0"  # a Russian character in two-bytes.
    x_utf8 = x.encode("utf-8")
    assert utf8(x) == x_utf8

    try:
        utf8(object())
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:59.011639
# Unit test for function native_str
def test_native_str():
  s = 'isMyCat的貓' 
  a = to_unicode(s)
  b = a.encode('utf-8')
  assert s == b
print (test_native_str())


# Generated at 2022-06-24 08:20:09.968357
# Unit test for function linkify
def test_linkify():
    # linkify with defaults
    text = linkify("Hello http://example.com! I'm just a regular email@email.com.")
    assert text == 'Hello <a href="http://example.com">http://example.com</a>! I\'m just a regular <a href="mailto:email@email.com">email@email.com</a>.', "Function linkify did not linkify correctly!"
    # linkify with shortened url
    text = linkify("Hello http://example.com/12345678910! I'm just a regular email@email.com.")

# Generated at 2022-06-24 08:20:14.596946
# Unit test for function native_str
def test_native_str():
    native_str("string")
    native_str("string".encode("utf-8"))
    native_str("string".encode("utf-8"), 'utf-8')
    native_str("string", 'utf-8')
    native_str("string".encode("utf-8"), 'utf-8')
    native_str("string", 'gbk')
    native_str("string".encode("utf-8"), 'gbk')
    # noinspection PyTypeChecker
    native_str(10)



# Generated at 2022-06-24 08:20:17.369460
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "</script>"}) == '{"foo": "<\\/script>"}'



# Generated at 2022-06-24 08:20:19.796322
# Unit test for function json_decode
def test_json_decode():
    dic = json_decode('{"a":1}')
    assert dic['a'] == 1


# Generated at 2022-06-24 08:20:24.939618
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({b'a':1}) == {u'a': 1}
    assert recursive_unicode({b'a':b'b'}) == {u'a': u'b'}
    assert recursive_unicode((b'a',b'b')) == (u'a', u'b')
    assert recursive_unicode([b'a',b'b']) == [u'a', u'b']


# Generated at 2022-06-24 08:20:26.001927
# Unit test for function native_str
def test_native_str():
    assert False

# Generated at 2022-06-24 08:20:32.962348
# Unit test for function utf8
def test_utf8():
    assert utf8('foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8(u'\u00a9') == b'\xc2\xa9'
    assert utf8(u'\u00a9'.encode('utf-8')) == b'\xc2\xa9'
    assert utf8(b'foo') == b'foo'
    assert utf8(None) is None
    try:
        utf8(42)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-24 08:20:35.677092
# Unit test for function xhtml_escape
def test_xhtml_escape():
    r = xhtml_escape("<a>Hello 'World'!</a>")
    print(r)
    assert r == "&lt;a&gt;Hello &#39;World&#39;!&lt;/a&gt;"



# Generated at 2022-06-24 08:20:46.544542
# Unit test for function url_unescape
def test_url_unescape():  # noqa: F811
    assert url_unescape("foo", None) == b"foo"
    assert url_unescape("foo") == "foo"
    assert url_unescape("foo", encoding="ascii") == "foo"
    assert url_unescape("foo%2Fbar") == "foo/bar"
    assert url_unescape("foo%2Fbar", plus=False) == "foo%2Fbar"
    assert url_unescape(b"foo%2Fbar") == b"foo/bar"
    assert url_unescape(b"foo%2Fbar", plus=False) == b"foo%2Fbar"
    assert url_unescape(b"foo%2Fbar", encoding="ascii") == "foo/bar"

# Generated at 2022-06-24 08:20:55.616646
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert (
            xhtml_escape('Test & escape <html> "characters" \'in string\'')
            == 'Test &amp; escape &lt;html&gt; &quot;characters&quot; &#39;in string&#39;'
    )
# test_xhtml_escape()

_URLSAFE_NOQUOTE_RE = re.compile(br"[^\-\w.~:/?#\[\]@!\$&'\(\)\*\+,;=]")


# We don't do anything for %, but apparently some browsers treat
# %20 instead of '+' as a space in queries.  We also don't
# care about non-ascii characters, which urllib.quote does
# convert.  So for compatibility with browsers and http,
# we use the same conversion.


# Generated at 2022-06-24 08:21:06.713160
# Unit test for function linkify
def test_linkify():
    assert linkify('http://www.tornadoweb.org') == '<a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'
    assert linkify('www.tornadoweb.org') == '<a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    assert linkify('http://www.tornadoweb.org/', require_protocol=False) == '<a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>'
    assert linkify('www.tornadoweb.org/', require_protocol=False) == '<a href="http://www.tornadoweb.org/">www.tornadoweb.org/</a>'

# Generated at 2022-06-24 08:21:17.261543
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"") == {}
    assert parse_qs_bytes(b"&") == {}
    assert parse_qs_bytes(b"&&&") == {}
    assert parse_qs_bytes(b"a=b") == {b"a": [b"b"]}
    assert parse_qs_bytes(b"a=b=c") == {b"a": [b"b=c"]}
    assert parse_qs_bytes(b"a") == {b"a": [b""]}
    assert parse_qs_bytes(b"a=") == {b"a": [b""]}
    assert parse_qs_bytes(b"=a") == {b"": [b"a"]}
    assert parse_qs_bytes(b"=") == {b"": [b""]}

# Generated at 2022-06-24 08:21:21.784130
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"lemon": "soda", "apple": "juice"}) == {'lemon': 'soda', 'apple': 'juice'}
    assert recursive_unicode(["lemon", "soda", "apple", "juice"]) == ['lemon', 'soda', 'apple', 'juice']
    assert recursive_unicode((b'lemon', b'soda', b'apple', b'juice')) == ('lemon', 'soda', 'apple', 'juice')
    assert recursive_unicode([[b'lemon', b'soda', b'apple', b'juice']]) == [['lemon', 'soda', 'apple', 'juice']]


# Generated at 2022-06-24 08:21:26.899916
# Unit test for function linkify
def test_linkify():
    assert linkify("hello") == "hello"
    assert (
        linkify("hello http://www.facebook.com/ and https://www.google.com/")
        == 'hello <a href="http://www.facebook.com/">http://www.facebook.com/</a> and <a href="https://www.google.com/">https://www.google.com/</a>'
    )
    assert linkify("hello www.facebook.com/") == 'hello <a href="http://www.facebook.com/">www.facebook.com/</a>'
    assert linkify("hello http://www.facebook.com/", require_protocol=True) == "hello http://www.facebook.com/"

# Generated at 2022-06-24 08:21:38.165590
# Unit test for function utf8
def test_utf8():
    assert utf8('foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8('foo'.encode('utf-8')) == b'foo'

if typing.TYPE_CHECKING:
    def to_unicode(value: Union[str, bytes]) -> str:
        """Converts a string argument to a unicode string.

        If the argument is already a unicode string or None, it is returned
        unchanged.  Otherwise it must be a byte string and is decoded as utf8.
        """
        if isinstance(value, unicode_type):
            return value
        if not isinstance(value, bytes):
            raise TypeError("Expected bytes, unicode, or None; got %r" % type(value))

# Generated at 2022-06-24 08:21:40.022875
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("\r\n\ta   c") == "a c"


# Generated at 2022-06-24 08:21:42.407700
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('aa   bb cc') == 'aa bb cc'


# Generated at 2022-06-24 08:21:47.263011
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = "<script>console.log('Hello World')</script>"
    assert xhtml_escape(value) == "&lt;script&gt;console.log(&#39;Hello World&#39;)&lt;/script&gt;"
test_xhtml_escape()



# Generated at 2022-06-24 08:21:51.796030
# Unit test for function json_encode
def test_json_encode():
    from tornado import escape
    a=escape.json_encode([1,2,3])
    print('a=',a)
#test_json_encode()



# Generated at 2022-06-24 08:21:58.642281
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&apos;") == "'"
    assert xhtml_unescape("&#5;") == "\x05"
    assert xhtml_unescape("&#005;") == "\x05"
    assert xhtml_unescape("&#x0005;") == "\x05"
    assert xhtml_unescape("&#x05;") == "\x05"
    assert xhtml_unescape("&#x005;") == "\x05"

# Generated at 2022-06-24 08:22:01.959662
# Unit test for function squeeze
def test_squeeze():
    p1 = "  \ta\t \nb  "
    p2 = "   a   b   "
    assert squeeze(p1) == squeeze(p2)


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:22:04.581994
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{'a':1}") =={'a':1}


# Generated at 2022-06-24 08:22:09.562858
# Unit test for function url_escape
def test_url_escape():
    a1 = "https://username:password@github.com/tornadoweb/tornado"
    a2 = "https%3A%2F%2Fusername%3Apassword%40github.com%2Ftornadoweb%2Ftornado"
    assert url_escape(a1) == a2



# Generated at 2022-06-24 08:22:13.393909
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'name%5B%5D=gaga&name%5B%5D=lulu'
    qs = parse_qs_bytes(qs)
    a = list(qs.keys())
    assert 'name[]' in a 
    assert 'name[]' in a

# Generated at 2022-06-24 08:22:17.708965
# Unit test for function native_str
def test_native_str():
    assert 'aaa' == native_str(b'aaa')
    assert 'aaa' == native_str('aaa')
    assert 'aaa' == native_str(u'aaa')


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:22:20.230483
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'a=x%20y&b=bar'
    result = parse_qs_bytes(qs)
    assert result == {"a": [b"x y"], "b": [b"bar"]}
    result = parse_qs_bytes(qs.encode('utf-8'))
    assert result == {"a": [b"x y"], "b": [b"bar"]}


# Generated at 2022-06-24 08:22:24.210993
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;script&gt;alert(&#39;gotcha&#39;);&lt;/script&gt;") == "<script>alert('gotcha');</script>"
    assert xhtml_unescape("&lt;&gt;&amp;&quot;&apos;") == "<>&\"'"
test_xhtml_unescape()



# Generated at 2022-06-24 08:22:25.596729
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('we', 'utf-8') == u'we'



# Generated at 2022-06-24 08:22:28.643471
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;h1&gt;Page Title&lt;/h1&gt;')=='<h1>Page Title</h1>'

# Generated at 2022-06-24 08:22:35.128343
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"") == {}
    assert parse_qs_bytes(b"foo=bar") == {"foo": [b"bar"]}
    assert parse_qs_bytes(b"foo=bar&foo=baz") == {"foo": [b"bar", b"baz"]}
    assert parse_qs_bytes(b"foo=1&foo=2") == {"foo": [b"1", b"2"]}
    assert parse_qs_bytes(b"foo=bar&&&foo=baz") == {"foo": [b"bar", b"baz"]}
    assert parse_qs_bytes(b"blah=") == {"blah": [b""]}

# Generated at 2022-06-24 08:22:38.002979
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('a b') == 'a+b'
    assert url_escape('a b', plus=False) == 'a%20b'



# Generated at 2022-06-24 08:22:40.861910
# Unit test for function json_encode
def test_json_encode():
    desired = '{"a": 1, "b": 2}'
    to_test = json_encode({'a': 1, 'b': 2})
    assert(desired == to_test)

### function test
test_json_encode()



# Generated at 2022-06-24 08:22:43.777356
# Unit test for function native_str
def test_native_str():
    native_str("abc")


# https://github.com/python/mypy/issues/1927
native_str = str  # type: Callable[[Union[str, bytes]], str]



# Generated at 2022-06-24 08:22:54.109970
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify('Hello') == 'Hello'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Hello http://tornadoweb.org/, and http://twitter.com!') == 'Hello <a href="http://tornadoweb.org/">http://tornadoweb.org/</a>, and <a href="http://twitter.com">http://twitter.com</a>!'

# Generated at 2022-06-24 08:23:01.847030
# Unit test for function linkify
def test_linkify():
    def params(url):
        return 'rel="nofollow"'
    assert to_unicode(linkify("")) == ""
    assert to_unicode(linkify("http://example.com")) == u'<a href="http://example.com" rel="nofollow">http://example.com</a>'  # noqa: E501
    assert to_unicode(linkify("Hello http://tornadoweb.org!", extra_params=params)) == u'Hello <a href="http://tornadoweb.org" rel="nofollow">http://tornadoweb.org</a>!'  # noqa: E501

# Generated at 2022-06-24 08:23:03.232048
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2")

# Generated at 2022-06-24 08:23:04.492520
# Unit test for function native_str
def test_native_str():
    r = to_unicode(r'\u4e2d\u6587')
    assert r == '中文'



# Generated at 2022-06-24 08:23:10.858633
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(u'%E2%82%AC', plus=False) == u'\u20ac'
    assert url_unescape(b'%E2%82%AC', encoding=None, plus=False) == b'\xe2\x82\xac'
    
    

# Generated at 2022-06-24 08:23:17.856420
# Unit test for function utf8
def test_utf8():
    # empty string
    assert utf8('') == b''
    assert utf8(b'') == b''
    # one utf8 character
    assert utf8('x') == b'x'
    assert utf8(b'x') == b'x'
    assert utf8('\u0E46') == b'\xe0\xb9\x86'
    assert utf8(b'\xe0\xb9\x86') == b'\xe0\xb9\x86'
    # two utf8 characters
    assert utf8('\u0E46x') == b'\xe0\xb9\x86x'
    assert utf8(b'\xe0\xb9\x86x') == b'\xe0\xb9\x86x'
    # invalid

# Generated at 2022-06-24 08:23:23.402874
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([1, 2, 3, [b"123", b"456"]]) == [1, 2, 3, ["123", "456"]]
    assert recursive_unicode({1: 1, 2: b"2"}) == {1: 1, 2: "2"}
    assert recursive_unicode((1, b"2")) == (1, "2")

test_recursive_unicode()



# Generated at 2022-06-24 08:23:28.610195
# Unit test for function utf8
def test_utf8():
    assert utf8(u'foo') == b'foo'
    assert utf8(u'foo'.encode('utf-8')) == b'foo'
    assert utf8(u'\u1234') == b'\xe1\x88\xb4'
    assert utf8(None) is None
    try:
        utf8('foo')
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'


# Generated at 2022-06-24 08:23:30.597195
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a bcd') == 'a bcd'
    assert squeeze('a   bcd') == 'a bcd'



# Generated at 2022-06-24 08:23:40.177372
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert "&amp;&lt;&gt;&quot;&#39;" == xhtml_escape("&<>\"'")
    assert "a&lt;&lt;&lt;&lt;&lt;&lt;&lt;" == xhtml_escape("a<"*7)
    assert "&gt;&gt;&gt;&gt;&gt;&gt;&gt;a" == xhtml_escape(">"*7 + "a")
    assert "a&gt;&gt;&gt;&gt;&gt;&gt;&gt;a" == xhtml_escape("a" + ">"*7 + "a")

# Generated at 2022-06-24 08:23:41.982571
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape('&#39&#39&amp;&#39;&lt;&gt'))



# Generated at 2022-06-24 08:23:52.237731
# Unit test for function linkify
def test_linkify():
    text = "Hello http://example.com!"

    # linkify returns unicode objects in both py2 and py3
    assert isinstance(linkify(text), type(u""))
    assert linkify(text) == (
        'Hello <a href="http://example.com">http://example.com</a>!'
    )

    assert linkify(linkify(text)) == (
        'Hello <a href="http://example.com">http://example.com</a>!'
    )

    assert linkify(u"Hello http://example.com!") == (
        'Hello <a href="http://example.com">http://example.com</a>!'
    )


# Generated at 2022-06-24 08:23:59.920598
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('sdfsdfs  dfsdf  sdfsdfsdfsdf   sdsds') =='sdfsdfs dfsdf sdfsdfsdfsdf sdsds'


_ASCII_ALNUM_CHARACTERS = (
    u"0123456789"
    u"abcdefghijklmnopqrstuvwxyz"
    u"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
)



# Generated at 2022-06-24 08:24:07.609317
# Unit test for function native_str
def test_native_str():
    assert native_str(3) == '3'
    assert native_str(u'foo') == 'foo'
    assert native_str('foo') == 'foo'
    assert native_str(b'foo') == 'foo'
    assert native_str(u'\u2603') == '\u2603'
    assert native_str('\u2603') == '\u2603'
    assert native_str(b'\xe2\x98\x83') == '\u2603'

test_native_str()

# Generated at 2022-06-24 08:24:12.962099
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # I assume the sys.getdefaultencoding() is 'ascii'
    a = [1, b'te\xe4st', {'b': b'foo\xe4'}]
    expect = [1, 'te\xe4st', {'b': 'foo\xe4'}]
    assert recursive_unicode(a) == expect
    print(recursive_unicode(a))



# Generated at 2022-06-24 08:24:14.748816
# Unit test for function native_str
def test_native_str():
    pass


_BASESTRING_TYPES = (bytes, unicode_type, type(None))



# Generated at 2022-06-24 08:24:18.427866
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a b  c  d") == "a b c d"
    assert squeeze("   ") == ""
    assert squeeze("a") == "a"
    assert squeeze("a b") == "a b"



# Generated at 2022-06-24 08:24:21.237649
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(url_escape('v')) == 'v'
    assert url_unescape('v') == 'v'

# Generated at 2022-06-24 08:24:26.601209
# Unit test for function native_str
def test_native_str():
    test_string = "I am a test string"
    assert native_str(test_string) == test_string
    assert isinstance(native_str(test_string), type(test_string))
    test_string_utf8 = "I am a test string á"
    assert native_str(test_string_utf8) == test_string_utf8
    assert isinstance(native_str(test_string_utf8), type(test_string_utf8))


# Generated at 2022-06-24 08:24:32.345541
# Unit test for function json_encode
def test_json_encode():
    import json
    data = json.loads('{"foo": "bar"}')
    result1 = json_encode(data)
    result2 = json.dumps(data)
    assert result1 == result2

# json_decode wraps json.loads.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-24 08:24:40.032220
# Unit test for function recursive_unicode

# Generated at 2022-06-24 08:24:53.861424
# Unit test for function recursive_unicode
def test_recursive_unicode():
    _test_recursive_unicode(1)
    _test_recursive_unicode('a')
    _test_recursive_unicode([1])
    _test_recursive_unicode(['a'])
    _test_recursive_unicode({'a': 1})
    _test_recursive_unicode({1: 'a'})
    _test_recursive_unicode({'a': 'b'})
    _test_recursive_unicode([[{'a': [1, 'a', {'b': 'b'}]}]])
    _test_recursive_unicode({'a': [1, 'a', {'b': 'b'}]})
    _test_recursive_unicode([{'a': [1, 'a', {'b': 'b'}]}])



# Generated at 2022-06-24 08:24:58.661102
# Unit test for function json_encode
def test_json_encode():
    _a = json_encode({"name":"Tom"})
    print(_a)
# test_json_encode()


# We need a special safe_decoder so we don't end up in
# infinite recursion when we have self-referential objects

# Generated at 2022-06-24 08:25:03.001044
# Unit test for function squeeze
def test_squeeze():
    print("value.strip() = %s" % squeeze("  he  llo world   "))
    print("value.strip() = %s" % squeeze("    hello world   "))
    print("value.strip() = %s" % squeeze("  he  llo world"))
    print("value.strip() = %s" % squeeze("hello world"))


# Generated at 2022-06-24 08:25:14.352469
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a":1, "b":2}) == '{"a": 1, "b": 2}'
    assert json_encode({"a":{"b":2}}) == '{"a": {"b": 2}}'
    assert json_encode({"a":{"b":{"c":3}}}) == '{"a": {"b": {"c": 3}}}'
    assert json_encode({"a":{"b":"b"}}) == '{"a": {"b": "b"}}'
    assert json_encode({"a":{"b":"b"}}) == '{"a": {"b": "b"}}'
    assert json_encode(["a", "b"]) == '["a", "b"]'

# Generated at 2022-06-24 08:25:19.551169
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a+b c", encoding=None) == b'a b c'
    assert url_unescape("a+b c", encoding='ascii') == 'a b c'
    assert url_unescape("a+b c", encoding='utf-8', plus=False) == 'a+b c'



# Generated at 2022-06-24 08:25:27.719582
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # type: () -> None
    assert xhtml_escape("<script>") == "&lt;script&gt;"
    assert xhtml_escape("'single quotes'") == "&#39;single quotes&#39;"
    assert xhtml_escape('"double quotes"') == "&quot;double quotes&quot;"
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_escape("&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape("<a href='/foo?a=b&c=d'>") == "&lt;a href=&#39;/foo?a=b&amp;c=d&#39;&gt;"



# Generated at 2022-06-24 08:25:39.209565
# Unit test for function recursive_unicode
def test_recursive_unicode():
    import types
    obj = {
        'a': 1,
        'b': [1, 2, 'x', {'c': b'd'}],
        'c': {'g': b'h'},
    }
    assert recursive_unicode(obj) == {
        'a': 1,
        'b': [1, 2, 'x', {'c': 'd'}],
        'c': {'g': 'h'},
    }
    assert isinstance(recursive_unicode(obj), types.DictType)
    assert isinstance(recursive_unicode(obj)['b'], types.ListType)
    assert isinstance(recursive_unicode(obj)['b'][3], types.DictType)

# Generated at 2022-06-24 08:25:40.278797
# Unit test for function xhtml_escape
def test_xhtml_escape():
    xhtml_escape('<')



# Generated at 2022-06-24 08:25:46.636357
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert(xhtml_escape('<>')=="&lt;&gt;")
    assert(xhtml_escape('< >')=="&lt; &gt;")
    assert(xhtml_escape('<a>')=="&lt;a&gt;")
    assert(xhtml_escape('"')=="&quot;")
    assert(xhtml_escape("'")=="&#39;")
    assert(xhtml_escape('&')=="&amp;")


# Generated at 2022-06-24 08:25:48.697113
# Unit test for function json_decode
def test_json_decode():
    json_decode("{}")
    json_decode("true")
    json_decode("[]")

# Generated at 2022-06-24 08:25:51.825540
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"rec": [b"yes", {"no": b"no", b"yes": "yes"}]}) == {
        "rec": ["yes", {"no": "no", "yes": "yes"}]
    }


# Generated at 2022-06-24 08:26:01.109533
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("asdfs http://www.google.com, jfdlsjkfd") == 'asdfs <a href="http://www.google.com">http://www.google.com</a>, jfdlsjkfd'
    assert linkify("asdfs http://www.google.com, jfdlsjkfd") == 'asdfs <a href="http://www.google.com">http://www.google.com</a>, jfdlsjkfd'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'

# Generated at 2022-06-24 08:26:09.917234
# Unit test for function recursive_unicode
def test_recursive_unicode():
    samples = [
        b'a',
        [1,2,3,b'a',b'b',b'c'],
        (1,2,3,b'a',b'b',b'c'),
        {'a': b'abc'}
    ]
    for number, sample in enumerate(samples, 1):
        recursive_unicoded = recursive_unicode(sample)
        assert not isinstance(recursive_unicoded, bytes)
        # Below two lines are equivalent
        assert isinstance(recursive_unicoded, typing.Union[tuple, list, dict])
        assert isinstance(recursive_unicoded, (tuple, list, dict))
        print('Sample {} passed test'.format(number))

test_recursive_unicode()

# get_all_arguments of a function could be

# Generated at 2022-06-24 08:26:20.840764
# Unit test for function url_unescape
def test_url_unescape():
    urls = dict(
        # tsting URL with encoded spaces
        test_url1 = "https://www.google.co.in/search?q=Python+testing",
        # tsting URL with encoded spaces, plus and dash
        test_url2 = "https://www.google.co.in/search?q=Python+--testing+%2B",
        # tsting URL with encoded spaces and plus
        test_url3 = "https://www.google.co.in/search?q=Python+testing+%2B",
        # tsting URL with encoded space and plus
        test_url4 = "https://www.google.co.in/search?q=Python+testing+%2B"
    )

# Generated at 2022-06-24 08:26:22.860019
# Unit test for function url_escape
def test_url_escape():
    print(url_escape("fasdfasf"))
#test_url_escape()


# Generated at 2022-06-24 08:26:27.458191
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&") == "&"
    assert xhtml_unescape("&#1;") == "&#1;"
    assert xhtml_unescape("foo&#;bar") == "foo&#;bar"
    assert xhtml_unescape("&#1;&#2;") == "&#1;&#2;"
# test for xhtml_unescape


# Generated at 2022-06-24 08:26:30.729319
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('\t\t hello  world  ') == 'hello world'
    assert squeeze(' \n\n\t123   456') == '123 456'


# Generated at 2022-06-24 08:26:38.251379
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Test with byte input
    byte_input = b'foo=bar&foo=baz&blah=1&blah=2&empty=F'
    result = parse_qs_bytes(byte_input)
    assert result == {
        'foo' : ['bar', 'baz'],
        'blah' : ['1', '2'],
        'empty' : [b'F'],
        }
    # Test with string input
    string_input = 'foo=bar&foo=baz&blah=1&blah=2&empty=F'
    result = parse_qs_bytes(string_input)

# Generated at 2022-06-24 08:26:48.114076
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"foo": "bar"}) == {"foo": "bar"}
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode({"foo": [1, "bar"]}) == {"foo": [1, "bar"]}
    assert recursive_unicode(b"foo") == "foo"


if str is not unicode_type:
    # if str == unicode, we don't need this function at all
    def native_str(s: Any, encoding: str = "ascii", errors: Optional[str] = "strict") -> str:
        """Convert to the native str type, using the given encoding and error
        handling.
        """
        if isinstance(s, unicode_type):
            return s.encode(encoding, errors)
        el

# Generated at 2022-06-24 08:26:54.082026
# Unit test for function recursive_unicode
def test_recursive_unicode():
    s = {'foo': ['bar', b'baz'], 'blah': b'gah'}
    s = recursive_unicode(s)
    assert isinstance(s['foo'][1], str)
    assert isinstance(s['blah'], str)
    test_recursive_unicode()



# Generated at 2022-06-24 08:26:57.114753
# Unit test for function utf8
def test_utf8():
    utf8(None)
    utf8(b'hello world')
    utf8('hello world')
    with raises(TypeError):
        utf8(1)
test_utf8()



# Generated at 2022-06-24 08:27:00.576441
# Unit test for function json_decode
def test_json_decode():
    dict_string = "{'name': 'leng', 'age': 18, 'weight': 64}"
    dict_ = json_decode(dict_string)
    assert dict_["age"] == 18


# Generated at 2022-06-24 08:27:06.195476
# Unit test for function json_encode
def test_json_encode():
    assert json_encode('a') == '"a"'
    assert json_encode('a"b') == '"a\\"b"'
    assert json_encode('a"b"c') == '"a\\"b\\"c"'


# json_encode_pretty is left non-wrapped for backwards compatibility,
# but it probably should wrap json.dumps(value, indent=4)
# Note that json.dumps produces invalid JSON (with trailing commas in lists)
# when passed "indent" arguments.

# Generated at 2022-06-24 08:27:08.840128
# Unit test for function linkify
def test_linkify():
  html = linkify("Hello http://tornadoweb.org!")
  assert html == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!", f"linkify function error: {html}"
  print("All tests passed")

test_linkify()


# Generated at 2022-06-24 08:27:10.303321
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<&>") == '&lt;&amp;&gt;'


# Generated at 2022-06-24 08:27:18.446023
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(value=b"https://github.com/tornadoweb/tornado/pull/706", encoding=None) == b'https://github.com/tornadoweb/tornado/pull/706'
    assert url_unescape(value=b"https%3A%2F%2Fgithub.com%2Ftornadoweb%2Ftornado%2Fpull%2F706", encoding=None) == b'https://github.com/tornadoweb/tornado/pull/706'
    assert url_unescape(value=b"https%3A%2F%2Fgithub.com%2Ftornadoweb%2Ftornado%2Fpull%2F706", encoding='utf-8') == 'https://github.com/tornadoweb/tornado/pull/706'

# Generated at 2022-06-24 08:27:23.275790
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('"1"') == "1"
    assert json_decode('1') == 1
    assert json_decode('[1, 2, 3]') == [1, 2, 3]
    assert json_decode('{"a": 1}') == {"a": 1}



# Generated at 2022-06-24 08:27:27.304595
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

# Generated at 2022-06-24 08:27:35.005435
# Unit test for function linkify
def test_linkify():
    assert linkify('Hello http://tornadoweb.org!') == \
        'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('www.foo.com') == \
        '<a href="http://www.foo.com">www.foo.com</a>'
    assert linkify('Hello http://tornadoweb.org!, and http://google.com!') == \
        'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!, and ' \
        '<a href="http://google.com">http://google.com</a>!'