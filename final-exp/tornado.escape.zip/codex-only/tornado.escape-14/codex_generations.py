

# Generated at 2022-06-24 08:17:37.170730
# Unit test for function utf8
def test_utf8():
    assert utf8(u"abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(None) is None
    try:
        utf8(123)
    except TypeError:
        pass
    else:
        raise Exception("Failed to raise TypeError")


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:17:46.815270
# Unit test for function utf8
def test_utf8():
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(None) is None
    assert utf8(u"\u0394") == b"\xce\x94"
    try:
        utf8({"foo": 1})
        assert False, "Expected TypeError"
    except TypeError:
        pass
    try:
        utf8(object())
        assert False, "Expected TypeError"
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:17:57.095880
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("a=1&b=2") == {"a": ["1"], "b": ["2"]}
    assert parse_qs_bytes("a=1&b=2&a=3") == {"a": ["1", "3"], "b": ["2"]}
    assert parse_qs_bytes("a=1=2") == {"a": ["1=2"]}
    assert parse_qs_bytes("a=&b=") == {"a": [""], "b": [""]}
    assert parse_qs_bytes("a=&b=", True) == {"a": ["", ""], "b": ["", ""]}
    assert parse_qs_bytes("a=&b=", False) == {"a": [""], "b": [""]}

# Generated at 2022-06-24 08:18:09.629475
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#38;&#x20;&#X41;&#x42;&#43;&#44;') == '& &AB+,'
    assert xhtml_unescape('&quot;&#39;&#6;&#7;&lt;&gt;&amp;') == '"\'&lt;&gt;&'
    #assert xhtml_unescape('&#011;&#012;&#013;') == '\t\n\r'
    assert xhtml_unescape('&quot;&#39;&#6;&#7;&lt;&gt;&amp;') == '"\'&lt;&gt;&'



# Generated at 2022-06-24 08:18:11.900454
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"key": "value"}') == {'key': 'value'}
    assert json_decode(b'"hello"') == 'hello'



# Generated at 2022-06-24 08:18:19.600407
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = "hello<world"
    assert xhtml_escape(value) == "hello&lt;world"
    assert isinstance(xhtml_escape(value), str)


_JSON_ESCAPE_RE = re.compile(r"[<>&\"]")
_JSON_ESCAPE_DICT = {"<": "\\u003c", ">": "\\u003e", "&": "\\u0026", '"': "\\u0022"}



# Generated at 2022-06-24 08:18:24.460246
# Unit test for function utf8
def test_utf8():
    assert utf8("aaa") == b"aaa"
    assert utf8(u"aaa") == b"aaa"
    assert utf8(u"\u2603") == b"\xe2\x98\x83"
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:27.720601
# Unit test for function linkify
def test_linkify():
    # Unicode strings with characters outside of ASCII
    try:
        text = u'français'
        text.encode('ascii')
    except UnicodeEncodeError:
        pass
    else:
        assert True == False, "Didn't get expected UnicodeEncodeError"
    #...



# Generated at 2022-06-24 08:18:32.517874
# Unit test for function linkify
def test_linkify():
    assert (
        linkify('hello http://www.youku.com.')
        == 'hello <a href="http://www.youku.com">http://www.youku.com</a>.'
    )
    assert (
        linkify(
            'hello http://www.youku.com/a/b_c.',
            shorten=True,
            require_protocol=True,
            permitted_protocols=('http', 'https', 'mailto', 'javascript'),
        )
        == 'hello <a href="http://www.youku.com/a/b_c" title="http://www.youku.com/a/b_c">http://www.youku.com/...</a>.'
    )

# Generated at 2022-06-24 08:18:38.002639
# Unit test for function json_decode
def test_json_decode():
    my_json_str = '{"username": "qinhao", "age": 10}'
    print(type(my_json_str))
    my_json_dict = json_decode(my_json_str)
    print(type(my_json_dict))
    print(my_json_dict)
    print(my_json_dict['username'])


# Generated at 2022-06-24 08:18:41.246114
# Unit test for function native_str
def test_native_str():
    t = [
        (174, b"174"),
        (u"foo", b"foo"),
        (None, None),
    ]
    for t1, t2 in t:
        assert t1 == to_unicode(t2)



# Generated at 2022-06-24 08:18:45.129406
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    d = parse_qs_bytes('a=b&c=d')
    assert(d['a']==[b'b'])
    assert(d['c']==[b'd'])


# Generated at 2022-06-24 08:18:49.870375
# Unit test for function url_unescape
def test_url_unescape():
    url = "http://www.baidu.com/s?wd=tornado%20body_arguments&rsv_spt=1&issp=1&f=8&rsv_bp=0&rsv_idx=2&ie=utf-8&tn=baiduhome_pg&rsv_enter=1&rsv_sug3=6&rsv_sug1=6&rsv_sug7=100"
    response = url_unescape(url)
    print(response)

test_url_unescape()


# Generated at 2022-06-24 08:18:51.010011
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"



# Generated at 2022-06-24 08:19:02.619563
# Unit test for function native_str
def test_native_str():
    import sys
    os = sys.platform
    if os == "linux" or os == "darwin":
        assert native_str('hello') == 'hello'
        assert native_str(to_unicode('\u00A9')) == '©'
        assert native_str(b'\xc3\xa9') == 'é'
        assert native_str(bytearray(b'caf\xc3')) == 'cafÃ'
    elif os == 'win32':
        assert native_str('hello') == 'hello'
        assert native_str(to_unicode('\u00A9')) == '©'
        assert native_str(b'\xc3\xa9') == 'Ã©'

# Generated at 2022-06-24 08:19:13.763658
# Unit test for function linkify
def test_linkify():
    assert linkify("a http://link.com/ to test_linkify") == 'a <a href="http://link.com/">http://link.com/</a> to test_linkify'
    assert linkify("a http://link.com/ to test_linkify", shorten=True) == 'a <a href="http://link.com/">http://link.co...</a> to test_linkify'
    assert linkify("a http://link.com/ to test_linkify", require_protocol=True) == 'a http://link.com/ to test_linkify'
    assert linkify("a http://link.com/ to test_linkify", permitted_protocols=["http"]) == 'a <a href="http://link.com/">http://link.com/</a> to test_linkify'

# Generated at 2022-06-24 08:19:20.784827
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert repr(recursive_unicode([1, 2])) == "[1, 2]"
    assert repr(recursive_unicode([1, b"2"])) == "[1, '2']"
    assert repr(recursive_unicode((1, 2))) == "(1, 2)"
    assert repr(recursive_unicode((1, b"2"))) == "(1, '2')"
    assert repr(recursive_unicode({1: 2})) == "{1: 2}"
    assert repr(recursive_unicode({1: b"2"})) == "{1: '2'}"
    assert repr(recursive_unicode(b"foo")) == "'foo'"
    assert repr(recursive_unicode(1)) == "1"


# Generated at 2022-06-24 08:19:22.713642
# Unit test for function url_escape
def test_url_escape():
    pass
    #url_escape("http://www.w3school.com.cn/b.asp?url=http://www.w3school.com.cn/sql/sql_where.Asp")



# Generated at 2022-06-24 08:19:27.938568
# Unit test for function squeeze
def test_squeeze():
    x = "   dd   d d  d  d d    d \t \t\t \n \n \n \t d  \t \t \t \n \n \n \t \t \t \t d"
    x = squeeze(x)
    print(x)



# Generated at 2022-06-24 08:19:29.711771
# Unit test for function url_escape
def test_url_escape():
    value = "abc 123"
    assert url_escape(value, plus = True) == "abc+123"



# Generated at 2022-06-24 08:19:33.137598
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert(xhtml_escape("<>&\"'")=="&lt;&gt;&amp;&quot;&#39;")

_BASESTRING_TYPES = (bytes, str, unicode_type)



# Generated at 2022-06-24 08:19:42.299950
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'a':b'b', 'c': [b'd', u'e', 1, [b'f']]}) == \
            {'a':'b', 'c': ['d', u'e', 1, ['f']]}

    assert recursive_unicode([{b'a':b'b'}, u"c", b'd', [u'e']]) == \
            [{'a':'b'}, u'c', 'd', [u'e']]



# Generated at 2022-06-24 08:19:45.380049
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("\"1\"") == "&quot;1&quot;"
    assert xhtml_escape("'1'") == "&#39;1&#39;"

_json_decoder = json.JSONDecoder()



# Generated at 2022-06-24 08:19:51.943032
# Unit test for function native_str
def test_native_str():
    assert native_str(b'\xc4\xe3\xba\xc3', 'utf-8') == u'中文'
    assert native_str(u'中文') == u'中文'
    try:
        assert native_str(u'中文'.encode('ascii')) == u'中文'
    except UnicodeDecodeError:
        pass

if __name__ == '__main__':
    test_native_str()



# Generated at 2022-06-24 08:19:58.236234
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<a>&\"'</a>") == "&lt;a&gt;&amp;&quot;&#39;&lt;/a&gt;"

_URL_ESCAPE_RE = re.compile(r"[^a-zA-Z0-9.~_/-]")

# Generated at 2022-06-24 08:20:03.459887
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('') == ''
    assert squeeze('a') == 'a'
    assert squeeze(' a') == 'a'
    assert squeeze('a ') == 'a'
    assert squeeze(' a ') == 'a'
    assert squeeze(' \t a \n') == 'a'



# Generated at 2022-06-24 08:20:11.540473
# Unit test for function native_str
def test_native_str():
    assert _unicode("abc") == "abc"
    assert _unicode(u"abc") == u"abc"
    assert _unicode(b"abc") == u"abc"



# Generated at 2022-06-24 08:20:16.338867
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({}) == '{}'
    assert json_encode({"a": 1}) == '{"a": 1}'
    assert json_encode(["a", "b", 1]) == '["a", "b", 1]'



# Generated at 2022-06-24 08:20:20.166478
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"html": "</script>"}) == '{"html": "<\\/script>"}'


# json_decode is supplied by json.loads (and loads() may be faster
# when decoding a large number of small strings).



# Generated at 2022-06-24 08:20:26.911435
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = recursive_unicode({"a": 1, "b": "2", "c": [3, b"4"], "d": (b"5", 6)})
    assert obj["a"] == 1
    assert obj["b"] == "2"
    assert obj["c"][0] == 3
    assert obj["c"][1] == "4"
    assert obj["d"][0] == "5"
    assert obj["d"][1] == 6

_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:20:35.436691
# Unit test for function json_encode
def test_json_encode():
    from tornado.escape import json_encode
    from tornado import testing
    import json
    import re
    import string
    
    class JsonEncodeTest(testing.AsyncTestCase):
        def setUp(self):
            super(JsonEncodeTest, self).setUp()

# Generated at 2022-06-24 08:20:39.072975
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8(b"abc") == b"abc"
    
    assert utf8("abc") == "abc".encode()
    assert utf8(u"abc") == "abc".encode()
    assert utf8(u"\xe9") == "\xc3\xa9".encode()
test_utf8()

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:20:41.718249
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<a>") == "&lt;a&gt;"


# Generated at 2022-06-24 08:20:45.020399
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'a': 1, 'b': [1, {'c': b'd'}]}) == {'a': 1, 'b': [1, {'c': 'd'}]}



# Generated at 2022-06-24 08:20:54.690366
# Unit test for function linkify
def test_linkify():
    print(linkify("www.google.com"))
    print(linkify("http://www.google.com"))
    print(linkify("https://www.google.com"))
    print(linkify("ftp://ftp.google.com"))
    print(linkify("http://tornado.readthedocs.io/en/latest/index.html"))
    print(linkify("www.google.com?q=query"))
    print(linkify("www.google.com?q=query?string"))
    print(linkify("http://tornadoweb.org"))
    print(linkify("http://www.tornadoweb.org"))
    print(linkify("https://www.tornadoweb.org"))
    print(linkify("ftp://ftp.tornadoweb.org"))

# Generated at 2022-06-24 08:21:05.782342
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(['abc', b'def']) == ['abc', 'def']
    assert recursive_unicode([b'abc', b'def']) == ['abc', 'def']
    assert recursive_unicode([b'abc', ['def']]) == ['abc', ['def']]
    assert recursive_unicode({'abc': b'def'}) == {'abc': 'def'}
    assert recursive_unicode(b'abc') == 'abc'
    assert recursive_unicode('abc') == 'abc'
    assert recursive_unicode(1) == 1
    assert recursive_unicode(['abc', 1, {'def': b'ghi'}, (1, 2)]) == \
            ['abc', 1, {'def': 'ghi'}, (1, 2)]

# Generated at 2022-06-24 08:21:13.320390
# Unit test for function recursive_unicode
def test_recursive_unicode():
    result = {u'a': 1, u'b': [1, '2', b'3'], u'c': {u'd': {u'e': [{b'a': 1}, 1, 2], b'f': 2}}}
    assert recursive_unicode(result) == {'a': 1, 'b': [1, '2', '3'], 'c': {'d': {'e': [{'a': 1}, 1, 2], 'f': 2}}}


# Generated at 2022-06-24 08:21:17.267990
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<foo>") == "&lt;foo&gt;"
    assert xhtml_escape("abc&>def") == "abc&amp;&gt;def"
#test_xhtml_escape()



# Generated at 2022-06-24 08:21:18.819855
# Unit test for function json_encode
def test_json_encode():
    assert(json_encode({'a': 1}) == '{"a": 1}')



# Generated at 2022-06-24 08:21:21.676674
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('a%2Bb', plus=True) == 'a b'
    assert url_unescape('a+b', plus=True) == 'a b'



# Generated at 2022-06-24 08:21:26.130216
# Unit test for function squeeze
def test_squeeze():
    my_value = " hi everybody   "
    my_value = squeeze(my_value)
    print(my_value)
    return my_value
test_squeeze()


# Generated at 2022-06-24 08:21:30.179710
# Unit test for function recursive_unicode
def test_recursive_unicode():
    a = [1,2,3,'a',{'b':'b'}]
    assert recursive_unicode(a) == [1,2,3,'a',{'b':'b'}]
    try:
        assert recursive_unicode(b'a') == 'a'
        assert recursive_unicode(a) == [1,2,3,'a',{'b':'b'}]
    except:
        pass


# Generated at 2022-06-24 08:21:40.164782
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("foo bar") == "foo bar"
    assert linkify("foo http://www.x.com/ bar") == r'foo <a href="http://www.x.com/">http://www.x.com/</a> bar'
    assert linkify("foo www.x.com bar") == r'foo <a href="http://www.x.com">www.x.com</a> bar'

# Generated at 2022-06-24 08:21:46.436749
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2") == {"a": [b"1"], "b": [b"2"]}
    assert parse_qs_bytes(b"a=1&a=2") == {"a": [b"1", b"2"]}



# Generated at 2022-06-24 08:21:47.793652
# Unit test for function url_escape
def test_url_escape():
    import urllib
    urllib.parse.quote("a")



# Generated at 2022-06-24 08:21:57.433770
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#124;") == "|"
    assert xhtml_unescape("&nbsp;") == u"\xa0"
    assert xhtml_unescape("&#x3c;") == "<"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&blah;") == "&blah;"
    assert xhtml_unescape("&_#39;") == "&_#39;"
    assert xhtml_unescape("&amp;") == "&amp;"
    assert xhtml_unescape("&blahblah;") == "&blahblah;"
    assert xhtml_unescape("&#x00;") == "&#x00;"
    assert xhtml_unescape("&#x;") == "&#x;"

# Generated at 2022-06-24 08:22:00.305892
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%E6%B5%8B%E8%AF%95') == '测试'
    assert url_unescape('%E6%B5%8B%E8%AF%95', 'utf-8') == '测试'
    assert url_unescape('%E6%B5%8B%E8%AF%95', None, plus=False) == b'\xe6\xb5\x8b\xe8\xaf\x95'



# Generated at 2022-06-24 08:22:02.306348
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<a>") == "&lt;a&gt;"



# Generated at 2022-06-24 08:22:12.302276
# Unit test for function utf8
def test_utf8():
    test_input_string = "abc"
    test_expected_output = utf8(test_input_string)
    assert(isinstance(test_expected_output, bytes))
    assert(test_expected_output == b"abc")
    test_input_string = b"abc"
    test_expected_output = utf8(test_input_string)
    assert(isinstance(test_expected_output, bytes))
    assert(test_expected_output == b"abc")
test_utf8()

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:22:16.569436
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": "a", "b": "b"}) == '{"a": "a", "b": "b"}'
    assert json_encode({"a": "a", "b": "</script>"}) == '{"a": "a", "b": "<\\/script>"}'


_JSON_DECODE_ERROR = json.JSONDecodeError

# Generated at 2022-06-24 08:22:19.330790
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('"<>&\'') == '&quot;&lt;&gt;&amp;&#39;'

_basestring_type = (bytes, str)



# Generated at 2022-06-24 08:22:21.873149
# Unit test for function squeeze
def test_squeeze():
    string = squeeze('hello   world        ')
    if string == 'hello world':
        print('test squeeze() pass')
    else:
        print('test squeeze() fail')


# Generated at 2022-06-24 08:22:30.700764
# Unit test for function xhtml_escape
def test_xhtml_escape():

    print("\nTest function xhtml_escape")

    def test(name: str, is_valid: bool, input: Union[str, bytes], expected_output: str):
        print("Testing", name)
        output = xhtml_escape(input)
        if is_valid:
            assert output == expected_output
            print("Success")
        else:
            assert output != expected_output
            print("Success")

    test("to_basestring test 1", True, b"TEST", "TEST")
    test("to_basestring test 2", True, "TEST", "TEST")
    test("no change", True, "TEST TEST", "TEST TEST")
    test("escape &", True, "TEST & TEST", "TEST &amp; TEST")

# Generated at 2022-06-24 08:22:35.917448
# Unit test for function recursive_unicode
def test_recursive_unicode():
    in_data = [
        'abc', 
        {
            'b': 'b', 
            'a': 'a', 
            'c': 'c'
        }, 
        [
            'b', 
            'a', 
            'c'
        ], 
        (
            'b', 
            'a', 
            'c'
        )
    ]
    out_data = [
        'abc', 
        {
            'a': 'a', 
            'b': 'b', 
            'c': 'c'
        }, 
        [
            'b', 
            'a', 
            'c'
        ], 
        (
            'b', 
            'a', 
            'c'
        )
    ]
    u_data = recursive_

# Generated at 2022-06-24 08:22:39.552992
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<script>") == "&lt;script&gt;"
    assert xhtml_escape("test") == "test"
    assert xhtml_escape("'") == "&#39;"



# Generated at 2022-06-24 08:22:49.247246
# Unit test for function linkify

# Generated at 2022-06-24 08:23:00.481704
# Unit test for function recursive_unicode
def test_recursive_unicode():
    nf_list_bytes = [b'1', '2', 123, b'456']
    nf_dict_bytes = {b'123': b'456', '789': '0'}
    nf_list_uni = [u'1', '2', 123, u'456']
    nf_dict_uni = {u'123': u'456', u'789': u'0'}
    assert recursive_unicode(nf_list_bytes) == nf_list_uni
    assert recursive_unicode(nf_dict_bytes) == nf_dict_uni

_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:23:10.391190
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_data = [ ("a=1&b=2&c=3", {"a": b"1", "b": b"2", "c": b"3"}),
                  ("a=&b=&c=3", {"a": b"", "b": b"", "c": b"3"}),
                  ("a=1&&c=2", {"a": b"1", "c": b"2"}),
                  ("a=1&a=2&a=banana", {"a": [b"1", b"2", b"banana"]}) ]
    for qs, expected in test_data:
        assert expected == parse_qs_bytes(qs)
    #print(type(parse_qs_bytes('a=1&b=2&c=3')))



# Generated at 2022-06-24 08:23:14.346714
# Unit test for function xhtml_escape
def test_xhtml_escape():
	assert xhtml_escape('<script>alert("test")</script>') == '&lt;script&gt;alert(&quot;test&quot;)&lt;/script&gt;'
test_xhtml_escape()


_TYPES_COMPATIBLE_WITH_BASESTRING = (str, bytes, bytearray)



# Generated at 2022-06-24 08:23:17.856089
# Unit test for function native_str
def test_native_str():
    u = '\u00A0'
    s = u.encode('utf-8')
    assert native_str(u, 'utf-8') == s
    assert native_str(u) == s
    assert native_str(s) == s

    assert native_str('x') == b'x'
    assert native_str(b'x') == b'x'
    assert native_str(1) == b'1'


# Generated at 2022-06-24 08:23:20.113823
# Unit test for function json_decode
def test_json_decode():
    value = json_decode('{"a": 1}')
    assert isinstance(value, dict)
    assert value == {"a": 1}


# Generated at 2022-06-24 08:23:21.099953
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    value = '&#34;'
    assert xhtml_unescape(value) == '"'


# Generated at 2022-06-24 08:23:23.014423
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("asdfg") == "asdfg"
    assert squeeze("asdfg   asdfg") == "asdfg asdfg"



# Generated at 2022-06-24 08:23:33.189757
# Unit test for function url_escape
def test_url_escape():
    value = '\r\n'
    print(url_escape(value))
    value = '$'
    print(url_escape(value))
    value = 'a'
    print(url_escape(value))
    value = 'ab'
    print(url_escape(value))
    value = 'abc'
    print(url_escape(value))
    value = 'abcd'
    print(url_escape(value))
    value = 'abcde'
    print(url_escape(value))
    value = 'abcdef'
    print(url_escape(value))
    value = 'abcdefg'
    print(url_escape(value))
    value = 'abcdefgh'
    print(url_escape(value))
    print(url_escape(value, False))

test_url_escape()

# Generated at 2022-06-24 08:23:41.343191
# Unit test for function url_escape
def test_url_escape():
    x = url_escape('http://www.example.com/index.html')
    assert x == 'http%3A%2F%2Fwww.example.com%2Findex.html'
test_url_escape()

# The list of non-alphanumeric characters excluded from URL-escaping
_URL_ESCAPE_RE = re.compile(r'[^a-zA-Z0-9\-\.\_\~]')
# The list of ASCII characters that should not be %-encoded
_URL_SAFE_CHARS = b"/:?#[]@!$&'()*+,;=.-_~"
_URL_SAFE = frozenset(_URL_SAFE_CHARS + b" ")


# Generated at 2022-06-24 08:23:46.345462
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": b"foo"}) == {"a": "foo"}
    assert recursive_unicode(["a", b"foo"]) == ["a", "foo"]
    assert recursive_unicode((b"foo", )) == ("foo", )



# Generated at 2022-06-24 08:23:51.200559
# Unit test for function json_decode
def test_json_decode():
    try:
        json_decode('{ "test": true, "a": "abc" }')
        json_decode(u'{ "test": true, "a": "abc" }')
        json_decode(b'{ "test": true, "a": "abc" }')
    except (ValueError, TypeError):
        assert False, 'json_decode should not raise'



# Generated at 2022-06-24 08:23:57.193140
# Unit test for function json_encode
def test_json_encode():
    print(json_encode({"name": "bob", }))
    assert json_encode({"name": "bob", }) == '{"name": "bob"}'
test_json_encode()

# Note that we're monkeypatching a builtin here (unicode)
# That's generally bad but in this case ascii encoding should always
# be available on both py2 and py3 so it should be safe.
try:
    unicode
except NameError:
    pass
else:
    basestring = unicode_type = unicode = str
    bytes_type = bytes
    unichr = chr


# Generated at 2022-06-24 08:23:59.942334
# Unit test for function json_decode
def test_json_decode():
    value = "{'a': 1, 'b': 'asd'}"
    assert json_decode(value) == {'a': 1, 'b': 'asd'}


# Generated at 2022-06-24 08:24:07.243411
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = {"y":b"z", "t":[1,2,3]}
    y = recursive_unicode(x)
    assert y["y"] == "z"
    assert type(y["y"]) == unicode_type
    assert type(y["t"]) == list
    assert type(y["t"][0]) == int
    assert y == {'t': [1, 2, 3], 'y': u'z'}
    print("test_recursive_unicode() passed")


# Generated at 2022-06-24 08:24:15.508327
# Unit test for function json_encode
def test_json_encode():
    d = {
        'key0': 'value0',
        'key1': 'value1',
        'key2': 'value2',
    }
    print(d, type(d)) # {'key0': 'value0', 'key1': 'value1', 'key2': 'value2'} <class 'dict'>
    print(json.dumps(d))
    print(json.dumps(d).replace("</", "<\\/")) # {"key0": "value0", "key1": "value1", "key2": "value2"} {"key0": "value0", "key1": "value1", "key2": "value2"}
test_json_encode()

# to_unicode is removed in Tornado 6
_UNSET = object()

# Generated at 2022-06-24 08:24:20.542597
# Unit test for function json_decode
def test_json_decode():
    json_str = '{"a": "b"}'
    d = json_decode(json_str)
    assert d['a'] == 'b'
    json_byte = b'{"a": "b"}'
    d = json_decode(json_byte)
    assert d['a'] == 'b'
test_json_decode()



# Generated at 2022-06-24 08:24:26.027933
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&quot;") == '"'


# Generated at 2022-06-24 08:24:37.498900
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(u"N\xf8") == b"N\xc3\xb8"
    assert utf8(b"foo") == b"foo"
    assert utf8(None) is None
    try:
        utf8(object())
        assert False, "did not get expected TypeError"
    except TypeError:
        pass
    try:
        utf8(u"N\xf8").encode("latin1")
        assert False, "did not get expected UnicodeDecodeError"
    except UnicodeDecodeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:24:38.910872
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"

# Generated at 2022-06-24 08:24:42.372781
# Unit test for function native_str
def test_native_str(): 
    assert native_str(b'hello') == 'hello'
    assert native_str('hello') == 'hello'


# Generated at 2022-06-24 08:24:44.741124
# Unit test for function url_unescape
def test_url_unescape():
    result = url_unescape(b"1+2", encoding = 'utf-8', plus = True)
    assert result == "1 2"



# Generated at 2022-06-24 08:24:55.072152
# Unit test for function linkify
def test_linkify():
    text = "http://www.google.com"
    print(linkify(text))
    text = "https://www.google.com"
    print(linkify(text))
    text = "www.google.com"
    print(linkify(text))
    text = "http://localhost:80/"
    print(linkify(text))
    text = "http://localhost:80/index.html"
    print(linkify(text))
    text = "http://localhost:80/index.php"
    print(linkify(text))
    text = "http://localhost:80/index.php?a=1&b=2"
    print(linkify(text))

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-24 08:25:02.567731
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(None) is None
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\u2603") == b"\xe2\x98\x83"
    assert utf8(u"\ud800\udc00") == b"\xf0\x90\x80\x80"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:25:04.090807
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"x":1, "y":13}') == {"x":1, "y":13}, "Bad json_decode"
# /Unit test for function json_decode



# Generated at 2022-06-24 08:25:10.239085
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = "<script>alert('xss')</script>"
    result = "&lt;script&gt;alert(&#39;xss&#39;)&lt;/script&gt;"
    assert result == xhtml_escape(value)

_JSON_ESCAPE_RE = re.compile(r"""([\x00-\x1f\\"<>'])""")

# Generated at 2022-06-24 08:25:14.162884
# Unit test for function native_str
def test_native_str():
    assert 'a' == native_str(b'a')
    assert 'a' == native_str('a')
    try:
        native_str(1)
        assert False
    except AssertionError:
        raise AssertionError()
    except:
        pass
    assert 'a' == native_str(bytearray(b'a'))
    assert 'a' == native_str(io.BytesIO(b'a'))
    assert 'a' == native_str(array.array('b', b'a'))

# Generated at 2022-06-24 08:25:19.759736
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('http://localhost/') == 'http%3A%2F%2Flocalhost%2F'
    assert url_escape('http://localhost/', True) == 'http%3A//localhost/'
    assert url_escape(' ', False) == '%20'
    assert url_escape(' ', True) == '+'
test_url_escape()



# Generated at 2022-06-24 08:25:24.897677
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<p>&</p>") == "&lt;p&gt;&amp;&lt;/p&gt;"
    assert xhtml_escape("<p>&</p>") == "&lt;p&gt;&amp;&lt;/p&gt;"

_BASESTRING_TYPES = (unicode_type, bytes)


# Generated at 2022-06-24 08:25:34.637846
# Unit test for function json_decode
def test_json_decode():
    assert isinstance(json_decode('{}'), dict)
    assert isinstance(json_decode('[]'), list)
    assert isinstance(json_decode('"foobar"'), str)
    assert isinstance(json_decode('42'), int)
    assert isinstance(json_decode('true'), bool)
    assert isinstance(json_decode('false'), bool)
    assert isinstance(json_decode('null'), type(None))

    assert json_decode('{}') == {}
    assert json_decode('{"foo": "bar"}') == {'foo': 'bar'}
    assert json_decode('[1, 2, 3]') == [1, 2, 3]
    assert json_decode('"foo"') == "foo"
    assert json_decode('1') == 1

# Generated at 2022-06-24 08:25:45.240296
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query_string = b'one=two&three=four&five=six+seven'
    assert parse_qs_bytes(query_string) == {'one': [b'two'], 'three': [b'four'], 'five': [b'six seven']}
test_parse_qs_bytes()

# I originally used the regex from
# http://daringfireball.net/2010/07/improved_regex_for_matching_urls
# but it gets all exponential on certain patterns (such as too many trailing
# dots), causing the regex matcher to never return.
# This regex should avoid those problems.

# Generated at 2022-06-24 08:25:51.953205
# Unit test for function utf8
def test_utf8():
    def check(value, expected):
        result = utf8(value)
        assert result == expected
        assert isinstance(result, type(expected))

    check(None, None)
    check("", b"")
    check("Hello", b"Hello")
    check("Привет", b"\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82")



# Generated at 2022-06-24 08:25:56.256337
# Unit test for function json_encode
def test_json_encode():
    test_dict = dict(key=[1,2,3])
    res = json_encode(test_dict)
    print(res)
# test_json_encode()


# to_unicode is deprecated in favor of utf8(value).  It remains here
# for backwards compatibility but may be removed in a future version
# of Tornado.

# Generated at 2022-06-24 08:25:59.562884
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<tag>") == "&lt;tag&gt;"

_URL_ESCAPE_RE = re.compile(r'[^a-zA-Z0-9_.-]')



# Generated at 2022-06-24 08:26:08.933340
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Utility to check the results for bytes.
    def is_byte_list(l):
        for i in l:
            if not isinstance(i, bytes):
                return False
        return True


# Generated at 2022-06-24 08:26:13.895577
# Unit test for function recursive_unicode
def test_recursive_unicode():
    d = {'a': 6, 'b': ['a', 'b', 'c', u'\xb5']}
    c = recursive_unicode(d)
    return c

# test = test_recursive_unicode()
# print(test)


# Generated at 2022-06-24 08:26:22.516764
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&amp;haha") == "&haha"
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&#39;haha") == "'haha"
    assert xhtml_unescape("&#1234;") == "ሴ"
    assert xhtml_unescape("&#x4e00;") == "一"
    assert xhtml_unescape("&apos;") == "'"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'

# Generated at 2022-06-24 08:26:25.943133
# Unit test for function url_escape
def test_url_escape():
    print(url_escape('123456', True))
    print(url_escape('123456'))
    print(url_escape('1 2 3 4 5 6', True))
    print(url_escape('1 2 3 4 5 6'))
# test_url_escape()



# Generated at 2022-06-24 08:26:37.414973
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    d = parse_qs_bytes("a=1&b=2")
    assert d == {'a': ['1'], 'b': ['2']}
    d = parse_qs_bytes("a=1&b=2", keep_blank_values=True)
    assert d == {'a': ['1'], 'b': ['2']}
    d = parse_qs_bytes("a=1&b=2", strict_parsing=True)
    assert d == {'a': ['1'], 'b': ['2']}
    d = parse_qs_bytes("a=1&b=2", keep_blank_values=True, strict_parsing=True)
    assert d == {'a': ['1'], 'b': ['2']}


# Generated at 2022-06-24 08:26:45.115474
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%2Bb+c", 'utf-8', False) == 'a+b+c'
    assert url_unescape("a%2Bb+c", 'utf-8', True) == 'a+b c'
    assert url_unescape("a%2Bb+c", None, True) == b'a+b c'
    assert url_unescape("a%2Bb+c", None, False) == b'a+b+c'



# Generated at 2022-06-24 08:26:48.951580
# Unit test for function utf8
def test_utf8():
    s = u"https://www.google.com"
    assert b"google" in utf8(s)
    assert utf8(s) == b"https://www.google.com"


# Generated at 2022-06-24 08:26:53.656572
# Unit test for function json_encode
def test_json_encode():
    dic = {'name':'wang','age':18}
    print(json_encode(dic))

test_json_encode()

_JSON_DECODE_FUNC: typing.Optional[Callable] = None


# Generated at 2022-06-24 08:26:55.453976
# Unit test for function json_decode
def test_json_decode():
    test_str = '{"name": "Sarah", "age": "14"}'
    assert json_decode(test_str) == {"name": "Sarah", "age": "14"}


# Generated at 2022-06-24 08:26:58.194383
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r'&amp;<&lt;&gt;&quot;&#39;') == '&<><"\''



# Generated at 2022-06-24 08:27:03.214123
# Unit test for function squeeze
def test_squeeze():
    input = "  hello  world  "
    output = "hello world"

    if(squeeze(input) != output):
        print("squeeze(  hello  world  ) returned \"", squeeze(input), "\" instead of \"", output, "\"")
        return


# Generated at 2022-06-24 08:27:07.346371
# Unit test for function utf8
def test_utf8():
    assert utf8(u"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(None) is None



# Generated at 2022-06-24 08:27:16.743412
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert isinstance(xhtml_escape("<hello>"), str)
    assert isinstance(xhtml_escape("&hello&"), str)
    assert isinstance(xhtml_escape("'hello'"), str)
    assert xhtml_escape("'hello'") == "&#39;hello&#39;"

# xhtml_unescape is provided by xml_helpers.py.


_JS_ESCAPE_RE = re.compile(r"""([^\w\s"'-])""")

# Generated at 2022-06-24 08:27:21.046510
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"x=%26") == {"x": [b"&"]}
    assert parse_qs_bytes("x=%26") == {"x": ["&"]}
    assert parse_qs_bytes("x=%26", strict_parsing=True) == {"x": ["&"]}
    assert parse_qs_bytes("x=%2") == {"x": ["%2"]}
    assert parse_qs_bytes("x=%2", strict_parsing=True) == {}



# Generated at 2022-06-24 08:27:24.202930
# Unit test for function url_escape
def test_url_escape():
    print(url_escape('http://www.baidu.com'))
    print(url_escape('http://www.baidu.com',plus=False))
test_url_escape()



# Generated at 2022-06-24 08:27:27.259273
# Unit test for function url_escape
def test_url_escape():
    url_escape("http://127.0.0.1:8000/epc_static/media/img/epc_logo.png")



# Generated at 2022-06-24 08:27:29.619709
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&<>"\'') == '&amp;&lt;&gt;&quot;&#39;'


# Generated at 2022-06-24 08:27:39.496808
# Unit test for function json_encode
def test_json_encode():
    # json_encode/json.dumps
    # String
    assert json_encode("123") == json.dumps("123")
    assert json_encode("abc") == json.dumps("abc")
    # List
    assert json_encode(["abc", "edf"]) == json.dumps(["abc", "edf"])
    assert json_encode(["edf", 123, [1, 2, 3]]) == json.dumps(["edf", 123, [1, 2, 3]])
    # Dictionary
    assert json_encode({"name":"zhangsan", "age":20}) == json.dumps({"name":"zhangsan", "age":20})
    assert json_encode({"name":"lisi", "age":20, "class": [1, 2, 3]})