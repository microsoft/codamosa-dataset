

# Generated at 2022-06-24 08:17:34.568360
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze("   Hello World   ") == "Hello World")
    print("Test squeeze: OK")


# Generated at 2022-06-24 08:17:45.933876
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify('Hi') == 'Hi'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Go to http://www.google.com/search?q=test') == 'Go to <a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify(linkify('Go to http://www.google.com/search?q=test')) == 'Go to <a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'

# Generated at 2022-06-24 08:17:52.849102
# Unit test for function utf8
def test_utf8():  # noqa: N802
    assert utf8(b"a") == b"a"
    assert utf8(u"a") == b"a"
    assert utf8(None) is None
    try:
        utf8(0)
    except TypeError:
        pass
    else:
        raise Exception("expected TypeError")


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:17:55.231829
# Unit test for function url_escape
def test_url_escape():
    url_value = 'http://www.zhaozhiyong1989.com'
    url_escape(url_value)
    return url_escape(url_value)



# Generated at 2022-06-24 08:17:58.187380
# Unit test for function utf8
def test_utf8():
    s = '中文'
    assert utf8(s) == s.encode('utf8')
    assert utf8(None) == None

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:07.745337
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"/%2F", plus=False) == "/"
    assert url_unescape(b"/%2F", plus=True) == "/"
    assert url_unescape(b"/%2F") == "/"
    assert url_unescape("/%2F") == "/"
    assert url_unescape(b"/%2F", encoding=None) == b"/"
    assert url_unescape("/%2F", encoding=None, plus=True) == b"/"
    assert url_unescape("/%2F", encoding=None, plus=False) == b"/"
    assert url_unescape("/%2F", encoding=None) == b"/"
    assert url_unescape(b"/%2F", encoding=None, plus=True) == b"/"


# Generated at 2022-06-24 08:18:10.291731
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("a=1&a=2&b=3") == {"a": [b"1", b"2"], "b": [b"3"]}
    assert parse_qs_bytes("a=1;a=2;b=3", True, True) == {"a": [b"1", b"2"], "b": [b"3"]}
test_parse_qs_bytes()



# Generated at 2022-06-24 08:18:11.427678
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  a  b   c d") == "a b c d"



# Generated at 2022-06-24 08:18:18.160488
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<Hello World>')=='&lt;Hello World&gt;'
    assert xhtml_escape('"Hello World"')=='&quot;Hello World&quot;'
    assert xhtml_escape('\'Hello World\'')=='&#39;Hello World&#39;'
    assert xhtml_escape('&Hello World&')=='&amp;Hello World&amp;'


# Generated at 2022-06-24 08:18:27.720005
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http%3A%2F%2Fwww.example.com%2F", encoding=None) == b'http://www.example.com/'
    assert url_unescape("http%3A%2F%2Fwww.example.com%2F", encoding="utf-8") == "http://www.example.com/"
    assert url_unescape("http%3A%2F%2Fwww.example.com%2F", encoding="utf-8", plus=False) == "http://www.example.com/"
    assert url_unescape("http%3A%2F%2Fwww.example.com%2F", encoding="utf-8", plus=True) == "http://www.example.com/"

# Generated at 2022-06-24 08:18:32.722457
# Unit test for function utf8
def test_utf8():
    for x, expect in [
        (b"foo", b"foo"),
        (u"foo", b"foo"),
        (u"\u2713", b"\xe2\x9c\x93"),
        (u"\u2713".encode("utf-8"), b"\xe2\x9c\x93"),
        (None, None),
    ]:
        assert utf8(x) == expect



# Generated at 2022-06-24 08:18:34.974229
# Unit test for function xhtml_escape
def test_xhtml_escape():
  from tornado.escape import xhtml_escape
  assert xhtml_escape('<html>&') == "&lt;html&gt;&amp;"


# Generated at 2022-06-24 08:18:45.561595
# Unit test for function url_escape
def test_url_escape():
    result = url_escape('/path/to/file?foo=bar&baz=quux', plus=True)
    assert result == '/path/to/file%3Ffoo%3Dbar%26baz%3Dquux'
    result = url_escape('/path/to/file?foo=bar&baz=quux', plus=False)
    assert result == '/path/to/file%3Ffoo=bar&baz=quux'
    result = url_escape('/path/to/file?foo=bar&baz=quux', plus=False)
    assert result == '/path/to/file%3Ffoo=bar&baz=quux'
    result = url_escape('/path/to/file?foo=bar&baz=quux', plus=False)

# Generated at 2022-06-24 08:18:46.143264
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape('asdf')


# Generated at 2022-06-24 08:18:48.343920
# Unit test for function native_str
def test_native_str():
    str_ = native_str(dict(s=1))
    assert isinstance(str_, str)
    assert str_ == "{'s': 1}"



# Generated at 2022-06-24 08:18:59.693482
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%5E1') == '^1'  # type: ignore
    assert url_unescape('%5E1', encoding=None) == b'^1'  # type: ignore
    assert url_unescape('foo') == 'foo'  # type: ignore
    assert url_unescape('foo', encoding=None) == b'foo'  # type: ignore
    assert url_unescape('foo+bar') == 'foo bar'  # type: ignore
    assert url_unescape('foo+bar', encoding=None) == b'foo bar'  # type: ignore
    assert url_unescape('foo+bar', plus=False) == 'foo+bar'  # type: ignore
    assert url_unescape('foo+bar', encoding=None, plus=False) == b'foo+bar'  # type

# Generated at 2022-06-24 08:19:06.873385
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&#62;") == ">"
    assert xhtml_unescape("&#x3e;") == ">"
    assert xhtml_unescape("&#X3E;") == ">"
    assert xhtml_unescape("&#X3E;") == ">"
    assert xhtml_unescape("&nbsp;") == " "
    assert xhtml_unescape("&xxx;") == "&xxx;"


# Generated at 2022-06-24 08:19:17.169525
# Unit test for function recursive_unicode
def test_recursive_unicode():
    """test case for recursive_unicode"""
    assert recursive_unicode({"asd":'name'}) == {'asd': 'name'}
    assert recursive_unicode({"asd":'n\x00ame'}) == {'asd': 'n\x00ame'}
    assert recursive_unicode({"asd":'n\x00ame'}) == {'asd': 'n\x00ame'}
    assert recursive_unicode([1, 2, 3]) == [1, 2, 3]
    assert recursive_unicode((1, 2, 3)) == (1, 2, 3)
    assert recursive_unicode({"asd":'n\x00ame'}) == {'asd': 'n\x00ame'}
    assert recursive_unicode(b"a\x00") == b

# Generated at 2022-06-24 08:19:19.058857
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   a   b  c    ") == "a b c"



# Generated at 2022-06-24 08:19:27.639704
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com", True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com:80", True) == '<a href="http://example.com:80">http://example.com:80</a>'
    assert linkify("http://example.com/foo", True) == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://user@example.com/foo", True) == '<a href="http://user@example.com/foo">http://user@example.com/foo</a>'


# Generated at 2022-06-24 08:19:29.849084
# Unit test for function squeeze
def test_squeeze():
    x = """
    line 1
    line 2
    line 3
    """
    print(squeeze(x))



# Generated at 2022-06-24 08:19:36.556045
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;&#39;&quot;&gt;&amp;') == "<'\">&"


# adapted from http://wiki.python.org/moin/EscapingHtml
_HTML_ESCAPE_RE = re.compile("[&<>\"']")
_HTML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#x27;",
}



# Generated at 2022-06-24 08:19:38.247618
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(b'abc', plus=True)
    url_unescape(b'abc', plus=True, encoding=None)



# Generated at 2022-06-24 08:19:42.527873
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze('x') == 'x')
    assert(squeeze('x x') == 'x x')
    assert(squeeze('x  x') == 'x x')
    assert(squeeze('x \n \t \rx') == 'x x')
    return



# Generated at 2022-06-24 08:19:47.458820
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'a=1&b=2&c=3'
    expected = {'a': [b'1'], 'b': [b'2'], 'c': [b'3']}
    assert parse_qs_bytes(qs) == expected
    print('PASS')
test_parse_qs_bytes()


# Generated at 2022-06-24 08:19:53.393945
# Unit test for function url_escape
def test_url_escape():
    print("Unit test for function url_escape")
    url="https://api.douban.com/v2/book/1220562"
    print("url=%s"%url)
    url_escaped=url_escape(url)
    print("url_escaped=%s"%url_escaped)
    assert(url_escaped.index("https%3A%2F%2Fapi.douban.com%2Fv2%2Fbook%2F1220562")>=0)



# Generated at 2022-06-24 08:19:57.004318
# Unit test for function utf8
def test_utf8():
    teststr = "Hello, world"
    bytestr = b"Hello, world"
    assert utf8(teststr) == bytestr
    assert utf8(bytestr) == bytestr
    assert utf8(None) == None
    try:
        utf8(123)
        assert False
    except TypeError as e:
        print('TypeError: ' + str(e))



# Generated at 2022-06-24 08:20:03.043420
# Unit test for function xhtml_escape
def test_xhtml_escape():
    print(xhtml_escape('&<>"\''))


_BASESTRING_TYPES = (type(b""), type(u""))

# JSON permissions.
Json_Permissions = typing.List[typing.Union[typing.Tuple[int, typing.Optional[int]], int, bool]]


# Generated at 2022-06-24 08:20:07.867471
# Unit test for function json_decode
def test_json_decode():
    json_string =\
    '''{
        'abc': 123,
        'def': 345,
        'ghi': 567
     }'''

    expected_output =\
    {'abc': 123,
     'def': 345,
     'ghi': 567
     }

    pretty_print(json_decode(json_string), expected_output)



# Generated at 2022-06-24 08:20:10.317673
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('''&lt;&gt;&amp;&quot;&#39;''') == '''<>&"'''



# Generated at 2022-06-24 08:20:14.892267
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{\"a\": 1, \"b\": 2}") == {"a":1, "b":2}
    assert json_decode("{'a': 1, 'b': 2}") == {"a":1, "b":2}



# Generated at 2022-06-24 08:20:19.796050
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&amp;&amp;") == "&&"
    assert xhtml_unescape("&amp;&amp;&amp;") == "&&&"



# Generated at 2022-06-24 08:20:21.083146
# Unit test for function json_encode
def test_json_encode():
    print(json_encode(["</script>"]))


# Generated at 2022-06-24 08:20:29.212800
# Unit test for function json_encode
def test_json_encode():
    import json
    import tornado.escape
    data = {"hello": "world", "foo": "bar"}
    assert tornado.escape.json_encode(data) == json.dumps(data)
    data = {"a": ["</script><script>alert('xss')</script>"]}
    assert tornado.escape.json_encode(data) == json.dumps(data).replace("</", "<\\/")


# json_encode defaults to encoding UTF-8, which is a bad default
# because some browsers will not decode it without a charset= parameter.
# Firefox even enforces this when the type is text/html.
# http://stackoverflow.com/questions/12777622/how-to-force-chrome-to-render-json-as-text-not-downloadable-file
# http://meta.stack

# Generated at 2022-06-24 08:20:36.814676
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&#38;') == '&'
    assert xhtml_unescape('&#x26;') == '&'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&#60;') == '<'
    assert xhtml_unescape('&#x3c;') == '<'
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&#62;') == '>'
    assert xhtml_unescape('&#x3e;') == '>'
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#34;') == '"'
   

# Generated at 2022-06-24 08:20:48.101953
# Unit test for function xhtml_escape
def test_xhtml_escape():
    pass
    # assert xhtml_escape('&<>\"') == '&amp;&lt;&gt;&quot;'
    # assert xhtml_escape('"<>&\'') == '&quot;&lt;&gt;&amp;&#39;'
    # assert xhtml_escape(b'&<>\"') == '&amp;&lt;&gt;&quot;'


_XML_ESCAPE_RE = re.compile("[&<>\"']")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
}



# Generated at 2022-06-24 08:20:56.571683
# Unit test for function json_decode
def test_json_decode():
    test1 = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    assert json_decode(test1) == ["foo", {"bar": ["baz", None, 1.0, 2]}]
    test2 = '"\\"foo\\bar"'
    assert json_decode(test2) == '"foo\x08ar'
    test3 = '"\\"foo\\bar"'
    assert json_decode(test3.encode('utf-8')) == '"foo\x08ar'

# regex for decoding html entities
_HTML_UNESCAPE_REGEX = re.compile(r"&(#?)(\d{1,5}|\w{1,8});")
# Used by unescape.
# Code is from http://wiki.python.org/moin/

# Generated at 2022-06-24 08:21:00.868044
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "</script>"}) == '{"foo": "<\\/script>"}'


_RECURSIVE_REFERENCE_ERROR = (
    "Unsafe recursive call without a context setting self.recursive_reference"
)



# Generated at 2022-06-24 08:21:07.662211
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("/path/to/file?foo=bar&baz=ding") == "%2Fpath%2Fto%2Ffile%3Ffoo%3Dbar%26baz%3Dding"
    assert url_escape("/path/to/file?foo=bar&baz=ding",plus=True) == "%2Fpath%2Fto%2Ffile%3Ffoo%3Dbar%26baz%3Dding"
print(test_url_escape.__name__)



# Generated at 2022-06-24 08:21:09.349284
# Unit test for function squeeze
def test_squeeze():
    v = 'aa  \t\tb'
    assert squeeze(v) == 'aa b'



# Generated at 2022-06-24 08:21:14.371411
# Unit test for function json_decode
def test_json_decode():
    ret = json_decode('{"foo": "bar"}')
    assert isinstance(ret, dict)
    assert ret['foo'] == 'bar'
    ret = json_decode(b'{"foo": "bar"}')
    assert isinstance(ret, dict)
    assert ret['foo'] == 'bar'
test_json_decode()



# Generated at 2022-06-24 08:21:16.953602
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(None) is None
    try:
        utf8(object())
        assert False
    except:
        assert True


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:21:25.913213
# Unit test for function json_encode
def test_json_encode():
    from tornado.util import b
    assert json_encode(None) == "null"
    assert json_encode(True) == "true"
    assert json_encode(False) == "false"
    assert json_encode(0) == "0"
    assert json_encode(0.0) == "0.0"
    assert json_encode(123456789) == "123456789"
    assert json_encode(1e200) == "1.0e+200"
    assert re.match(r'^-?\d+(\.\d+)?(e-?\d+)?$', json_encode(1e-200))
    assert json_encode(b("ascii")) == '"ascii"'

# Generated at 2022-06-24 08:21:31.462020
# Unit test for function json_decode
def test_json_decode():
    json_test_str = '{"foo": "bar", "baz": "blah"}'
    print(json_decode(json_test_str))
test_json_decode()

_UTF8_TYPES = (bytes, type(None))  # Objects that should be UTF-8 encoded



# Generated at 2022-06-24 08:21:34.750906
# Unit test for function native_str
def test_native_str():
    str_unicode = "hello"
    str_bytes = b"hello"
    str_int = 3
    print(native_str(str_unicode))
    print(native_str(str_bytes))
    print(native_str(str_int))


# test_native_str()

_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:21:37.036646
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(" foo  bar  ") == "foo bar"



# Generated at 2022-06-24 08:21:42.987350
# Unit test for function utf8
def test_utf8():
    utf8("example")
    utf8(None)
    utf8(b'example')
    try:
        utf8({'a': 1})
    except TypeError:
        pass
    else:
        assert False


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:21:47.309594
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;h1>&#xD83D;&#xDE03;&lt;/h1>") == "<h1>😃</h1>"
test_xhtml_unescape()



# Generated at 2022-06-24 08:21:53.060149
# Unit test for function utf8
def test_utf8():
    assert b"abc" == utf8("abc")
    assert b"abc" == utf8(b"abc")
    assert b"\xe9" == utf8("\xe9")
    assert None == utf8(None)



# Generated at 2022-06-24 08:22:04.963916
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;script&gt;") == "<script>"
    assert xhtml_unescape("&quot;test&quot;") == "\"test\""
    assert xhtml_unescape("&#39;test&#39;") == "\'test\'"
    assert xhtml_unescape("&amp;&amp;") == "&&"
    assert xhtml_unescape("&copy;") == "©"
    assert xhtml_unescape("&#169;") == "©"
    assert xhtml_unescape(b"&amp;&amp;".decode('utf-8')) == "&&"
    assert xhtml_unescape(b"&copy;".decode('utf-8')) == "©"

# Generated at 2022-06-24 08:22:15.296155
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": "b"}) == {"a": "b"}
    assert recursive_unicode({"a": u"b"}) == {"a": u"b"}
    assert recursive_unicode({"a": "b".encode("utf-8")}) == {"a": u"b"}
    assert recursive_unicode({"a": {"b": "c"}}) == {"a": {"b": "c"}}
    assert recursive_unicode({"a": {"b": "c".encode("utf-8")}}) == {
        "a": {"b": u"c"}
    }
    assert recursive_unicode(["a", "b"]) == ["a", "b"]
    assert recursive_unicode(["a", u"b"]) == ["a", u"b"]
    assert recursive_

# Generated at 2022-06-24 08:22:21.485589
# Unit test for function json_decode
def test_json_decode():
    print(json_decode('{ "a": "b", "c": "d" }'))
    print(json_decode('[1,2,3,4,5]'))
    print(json_decode(b'{ "a": "b", "c": "d" }'))
    print(json_decode(b'[1,2,3,4,5]'))
# test_json_decode()


# Generated at 2022-06-24 08:22:28.899972
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('') == ''
    assert xhtml_escape('abc') == 'abc'
    assert xhtml_escape('"<>&\'') == '&quot;&lt;&gt;&amp;&#39;'

_JSON_ESCAPE_RE = re.compile(r"[%s]" % "".join(["\\"] + list(_XHTML_ESCAPE_DICT.keys())))
_JSON_ESCAPE_DICT = {
    ">": "\u003E",
    "<": "\u003C",
    "&": "\u0026",
    '"': "\u0022",
    "'": "\u0027",
}



# Generated at 2022-06-24 08:22:38.771837
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    #assert xhtml_unescape(u"&amp;") == u"&"
    #assert xhtml_unescape(u"&#65;") == u"A"
    #assert xhtml_unescape(u"&#x41;") == u"A"
    #assert xhtml_unescape(u"&lt;") == u"<"
    #assert xhtml_unescape(u"&gt;") == u">"
    #assert xhtml_unescape(u"&quot;") == u"\""
    #assert xhtml_unescape(u"&apos;") == u"'"
    assert xhtml_unescape(b"&amp;") == u"&"
    assert xhtml_unescape(b"&#65;") == u"A"

# Generated at 2022-06-24 08:22:41.133667
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2",strict_parsing=True) == {b"a": [b"1"], b"b": [b"2"]}
test_parse_qs_bytes()



# Generated at 2022-06-24 08:22:48.812749
# Unit test for function utf8
def test_utf8():
    assert utf8("\xe9") == b"\xc3\xa9"
    assert utf8(u"\xe9") == b"\xc3\xa9"
    assert utf8(b"\xc3\xa9") == b"\xc3\xa9"
    assert utf8(None) is None
    try:
        utf8(b"\xff")
    except UnicodeDecodeError:
        pass
    else:
        raise Exception("expected error")


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:22:52.234374
# Unit test for function squeeze
def test_squeeze():
    original = 'a  b  c'

    print('original string:', original)
    modified = squeeze(original)
    print('squeezed string:', modified)


# squeeze()


_URL_ESCAPE_RE = re.compile(r"[^a-zA-Z0-9_.]")



# Generated at 2022-06-24 08:22:59.930456
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&#38;') == '&'
    assert xhtml_unescape('&#x26;') == '&'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&#60;') == '<'
    assert xhtml_unescape('&#x3C;') == '<'
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&#62;') == '>'
    assert xhtml_unescape('&#x3E;') == '>'



# Generated at 2022-06-24 08:23:04.664577
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode('aaa') == 'aaa'
    assert recursive_unicode(b'bbb') == 'bbb'
    assert recursive_unicode({'foo': b'bar'}) == {'foo': 'bar'}
    assert recursive_unicode([b'foo', b'bar']) == ['foo', 'bar']

# Generated at 2022-06-24 08:23:09.520367
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;') == '&'
# test end


# Generated at 2022-06-24 08:23:12.337362
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('ab') == 'ab'
    assert url_escape('ab ') == 'ab+'
    assert url_escape('ab', plus = False) == 'ab'



# Generated at 2022-06-24 08:23:22.311256
# Unit test for function utf8
def test_utf8():
    assert utf8(None) == None
    assert utf8(b"ascii") == b"ascii"
    assert utf8("ascii") == b"ascii"
    assert utf8("\xe9") == b"\xc3\xa9" # encoding of unicode character
    assert utf8(u"\xe9") == b"\xc3\xa9" # encoding of unicode character
    # utf8(object) raises an error
    try:
        utf8(object())
    except TypeError as e:
        assert str(e) == "Expected bytes, unicode, or None; got <class 'object'>"
    else:
        raise Exception("should have raised error")


_TO_UNICODE_TYPES = (unicode_type, type(None))

# Generated at 2022-06-24 08:23:32.355506
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # type: () -> None
    assert recursive_unicode("hello") == "hello"
    assert recursive_unicode("h\xe9ll\xf6") == "héllö"
    assert recursive_unicode([1, 2, 3]) == [1, 2, 3]
    assert recursive_unicode((1, 2, 3)) == (1, 2, 3)
    assert recursive_unicode({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert recursive_unicode({"a": 1, "b": b"\xe2\x99\xa5"}) == {
        "a": 1,
        "b": "♥",
    }
    assert isinstance(recursive_unicode({"x": "y"})["x"], str)

# Generated at 2022-06-24 08:23:40.417012
# Unit test for function json_decode
def test_json_decode():
    assert(json_decode('"a"') == "a")
    assert(json_decode('1') == 1)
    assert(json_decode('true') is True)
    assert(json_decode('false') is False)
    assert(json_decode('[1,2,3]') == [1,2,3])
    assert(json_decode('{"a":1}') == {"a":1})


# Aliases that can be dropped if/when we drop Python 2.5 support
utf8 = _utf8 = utf8_encoding  # type: Callable
_unicode = unicode_type
_bytes_type = bytes

# Generated at 2022-06-24 08:23:48.209661
# Unit test for function json_encode
def test_json_encode():
    # 1) test for correct result for json_encode function
    assert json_encode({"hello": "tornado"}) == json.dumps({"hello": "tornado"}).replace("</", "<\\/")
    # 2) test for argument exception raised when the argument is not a valid json string
    try:
        json_encode("hello world")
    except TypeError as e:
        assert(str(e) == "Object of type 'str' is not JSON serializable")



# Generated at 2022-06-24 08:23:56.886144
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'') == {}
    assert parse_qs_bytes(b'a=b') == {'a': [b'b']}
    assert parse_qs_bytes(b'a=b&a=c') == {'a': [b'b', b'c']}
    assert parse_qs_bytes(b'a=b&a=c&d=e') == {'a': [b'b', b'c'], 'd': [b'e']}
    assert parse_qs_bytes(b'a=1&a=2&a=', keep_blank_values=True) == {'a': [b'1', b'2', b'']}

# Generated at 2022-06-24 08:24:03.208301
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<test>") == "&lt;test&gt;"
    assert xhtml_escape("'test'") == "&#39;test&#39;"
    assert xhtml_escape('"test"') == "&quot;test&quot;"
    assert xhtml_escape("&test;") == "&amp;test;"
# Unit test end


_JSON_ESCAPE = re.compile(r"[<>&'\"]")
_JSON_ESCAPE_DCT = {"<": "\\u003c", ">": "\\u003e", "&": "\\u0026", '"': "\\u0022", "'": "\\u0027"}



# Generated at 2022-06-24 08:24:05.214020
# Unit test for function native_str
def test_native_str():
    s = "abcçççč"
    assert s == native_str(s)


# Generated at 2022-06-24 08:24:13.680391
# Unit test for function utf8
def test_utf8():
    assert utf8(None) == None
    assert utf8("text") == b"text"
    assert utf8("Zażółć gęślą jaźń") == b"Za\xc5\xbc\xc3\xb3\xc5\x82\xc4\x87 g\xc4\x99\xc5\x9bl\xc4\x85 ja\xc5\xba\xc5\x84" # noqa
    try:
        utf8(3)
        assert False, "This code should not be reached"
    except TypeError:
        assert True



# Generated at 2022-06-24 08:24:18.037691
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("") == ""
    assert squeeze("           ") == " "
    assert squeeze("a    \tb") == "a b"
    assert squeeze("a    \tb   c") == "a b c"


# Generated at 2022-06-24 08:24:22.082567
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&lt; &gt; &quot; &apos; &amp; &#34; &#39; &#xc2;") == "< > \" ' & \" ' â"
test_xhtml_unescape()



# Generated at 2022-06-24 08:24:28.042623
# Unit test for function json_decode
def test_json_decode():
    from typing import Dict
    data = u'''
        {
            "menu": {
                "id": "file",
                "value": "File",
                "popup": {
                    "menuitem": [
                        {"value": "New", "onclick": "CreateNewDoc()"},
                        {"value": "Open", "onclick": "OpenDoc()"},
                        {"value": "Close", "onclick": "CloseDoc()"}
                    ]
                }
            }
        }
    '''
    data_dict: Dict[str, Any] = json_decode(data)



# Generated at 2022-06-24 08:24:31.705810
# Unit test for function json_encode
def test_json_encode():
    assert json_encode("</") == '"<\\/"'

# These constants are declared separately rather than as a dict subclass
# because we want to take advantage of the memory savings of sharing
# the identical _XHTML_ESCAPE_DICT structure between all instances.

# Generated at 2022-06-24 08:24:39.764563
# Unit test for function json_decode
def test_json_decode():
    value = json.dumps({'q': 1})  # type: bytes
    res = json_decode(value)      # type: bytes
    assert type(res) == dict
    assert res['q'] == 1
    res = json_decode(b'{"q": 1}')  # type: bytes
    assert type(res) == dict
    assert res['q'] == 1
    res = json_decode(b'{"q": 1}')  # type: bytes
    assert type(res) == dict
    assert res['q'] == 1


_basestring_type = typing.Text
_unicode_type = typing.Text


# Generated at 2022-06-24 08:24:43.987820
# Unit test for function url_escape
def test_url_escape():
    value = "It is so shiny"
    plus = True
    assert url_escape(value,plus) == "It%20is%20so%20shiny"
test_url_escape()



# Generated at 2022-06-24 08:24:47.537845
# Unit test for function json_decode
def test_json_decode():
    assert type(json_decode("{\"foo\":5, \"bar\": \"baz\"}"))==dict
    assert json_decode("{\"foo\":5, \"bar\": \"baz\"}")["foo"]==5


# Generated at 2022-06-24 08:24:58.889658
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"foo") == u"foo"
    assert recursive_unicode({b"foo": b"bar"}) == {u"foo": u"bar"}
    assert recursive_unicode({u"foo": b"bar"}) == {u"foo": u"bar"}
    assert recursive_unicode({1: b"foo", 2: b"bar"}) == {1: u"foo", 2: u"bar"}
    assert recursive_unicode((b"foo", b"bar")) == (u"foo", u"bar")
    assert recursive_unicode([b"foo", b"bar"]) == [u"foo", u"bar"]
    assert recursive_unicode(u"foo") == u"foo"

# Generated at 2022-06-24 08:25:06.213524
# Unit test for function native_str
def test_native_str():
    assert native_str('abc') == 'abc'
    assert native_str(b'abc') == 'abc'
    assert native_str(u'abc') == 'abc'
    assert isinstance(native_str('abc'), str)
    assert isinstance(native_str(b'abc'), str)
    assert isinstance(native_str(u'abc'), str)
    assert native_str(u'\u2603') == u'\u2603'
    assert native_str(b'\xe2\x98\x83', 'utf8') == u'\u2603'
    assert native_str(b'\xe2\x98\x83', 'latin1') == u'â˜ƒ'



# Generated at 2022-06-24 08:25:10.768424
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"
    assert xhtml_escape("'") == "&#39;"

_BASESTRING_TYPES = (bytes, str, typing.Text)



# Generated at 2022-06-24 08:25:21.614439
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;') == '\''
    assert xhtml_unescape('&apos;') == '\''
    assert xhtml_unescape('&amp;&gt;&lt;&quot;&apos;') == '&><"\''
    assert xhtml_unescape(r'&#39;') == "\'"
    assert xhtml_unescape(r'&#39') == "&#39"
    assert xhtml_unescape(r'&#39df;') == r'&#39df;'
    assert xhtml_unescape(r'&#39df') == r'&#39df'
    assert xhtml_unescape(r'&#39dfdjf&#39df') == r'&#39dfdjf&#39df'

_accept

# Generated at 2022-06-24 08:25:25.012540
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(b'foo', None)
    url_unescape(b'foo', b'utf-8', False)
    url_unescape(b'foo', 'utf-8', True)
    url_unescape(b'foo', 'utf-8')



# Generated at 2022-06-24 08:25:27.842043
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("f k") == 'f+k'
    assert url_escape("f k", False) == 'f%20k'


# Generated at 2022-06-24 08:25:32.659324
# Unit test for function native_str
def test_native_str():
    if sys.version_info < (3, 0):
        assert native_str(b"foo") == "foo"
        with pytest.raises(TypeError):
            native_str(u"foo")
    else:
        assert native_str(b"foo") == b"foo"
        assert native_str(u"foo") == u"foo"

# Generated at 2022-06-24 08:25:44.745333
# Unit test for function native_str
def test_native_str():
    assert native_str("") == ""
    assert native_str("test") == "test"
    assert native_str(b"test") == "test"
    assert native_str("test", 'ascii') == "test"
    assert native_str(b"test", 'ascii') == "test"
    assert native_str("test", 'utf8') == "test"
    assert native_str(b"test", 'utf8') == "test"
    assert native_str(u"test") == "test"
    assert native_str(u"test", 'utf8') == "test"
    assert native_str(u"test", 'ascii') == "test"
    assert native_str(u"\u00E9") == "\u00E9"

# Generated at 2022-06-24 08:25:50.422871
# Unit test for function json_decode
def test_json_decode():
    value = b'{"a": 10, "b": [1, 2]}'
    x = json_decode(value)
    assert isinstance(x, dict)
    assert list(x.keys()) == ["a", "b"]
    assert isinstance(x["a"], int)
    assert isinstance(x["b"], list)
    assert len(x["b"]) == 2


# Generated at 2022-06-24 08:25:59.869418
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    a = b"a=1&b=2"
    # print(parse_qs_bytes(a))
    #{'a': [b'1'], 'b': [b'2']}
    # print(parse_qs_bytes(a, True))
    #{'a': [b'1'], 'b': [b'2']}
    # print(parse_qs_bytes(a, True, True))
    #{'a': [b'1'], 'b': [b'2']}
    # print(parse_qs_bytes(a, False, True))
    #{'a': [b'1'], 'b': [b'2']}
    # print(parse_qs_bytes(a, False))
    #{'a': [b'1'], 'b': [b'2']

# Generated at 2022-06-24 08:26:09.115244
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8("") == b""
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(u"f\u00f6\u00f6") == b"f\xc3\xb6\xc3\xb6"
    assert utf8(u"\u20ac") == b"\xe2\x82\xac"
    try:
        utf8(20)
    except TypeError:
        pass
    else:
        assert False, "Did not raise TypeError"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:11.967724
# Unit test for function json_decode
def test_json_decode():
    a = '{"a":"b"}'
    assert json_decode(a) == {u"a": u"b"}
test_json_decode()



# Generated at 2022-06-24 08:26:16.980340
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;&#39;&#x4e00;") == '&\'一'


# Generated at 2022-06-24 08:26:18.895114
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape("&lt;&gt;"))


# Generated at 2022-06-24 08:26:25.300473
# Unit test for function native_str
def test_native_str():
    if 'utf-8'.endswith('8'):  # Python 3
        assert native_str(bytes(b'\xe2\x99\xa5')) == '\xe2\x99\xa5'
        assert native_str('\xe2\x99\xa5') == '\xe2\x99\xa5'
    else:  # Python 2
        assert native_str(bytes(b'\xe2\x99\xa5')) == '\xe2\x99\xa5'
        assert native_str('\xe2\x99\xa5') == u'\xe2\x99\xa5'
_UNICODE_TYPES = (unicode_type, type(None))
_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-24 08:26:27.274511
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<div>") == "&lt;div&gt;"


# Generated at 2022-06-24 08:26:31.583799
# Unit test for function native_str
def test_native_str():
    # make sure native_str can encode unicode
    assert to_unicode("é") == "é"

    # make sure native_str doesn't double-encode utf8
    assert to_unicode("é".encode("utf-8")) == "é"



# Generated at 2022-06-24 08:26:37.805086
# Unit test for function json_decode

# Generated at 2022-06-24 08:26:43.513332
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    s = parse_qs_bytes(b'_xsrf=2|7093f12f|d4102c21f4e8f4bc0e9d039d5a5f5e5e|1593317559&email=bruce%40gmail.com&passwd=bruce')
    print(s)



# Generated at 2022-06-24 08:26:48.028775
# Unit test for function squeeze
def test_squeeze():
    print ("----------")
    print(squeeze("""\
foo


bar
"""))
    print (squeeze("a   b   c"))
    print (squeeze("a\tb\tc"))
    print (squeeze("a\rb\rc"))
    print (squeeze("a\nb\nc"))
    print (squeeze("    a    b    c     "))
    print ("----------")



# Generated at 2022-06-24 08:26:59.982585
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&b=2') == {b'a': [b'1'], b'b': [b'2']}
    assert parse_qs_bytes(b'a=1&b=2', True) == {b'a': [b'1'], b'b': [b'2'], b'': [b'']}
    assert parse_qs_bytes(b'a=1&b=2', False, True) == {b'a': [b'1'], b'b': [b'2']}
    assert parse_qs_bytes(b'a=1&b=2&b=3') == {b'a': [b'1'], b'b': [b'2', b'3']}

# Generated at 2022-06-24 08:27:02.480049
# Unit test for function utf8
def test_utf8():
    print(utf8('aaa'))
    print(utf8(b'aaa'))
    print(utf8(None))


# Generated at 2022-06-24 08:27:13.999950
# Unit test for function utf8
def test_utf8():
    assert utf8('\u00e0\u00e1\u00e2') == b'\xc3\xa0\xc3\xa1\xc3\xa2'
    assert utf8('\u0430\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xb0\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert utf8('\u0670') == b'\xd9\xb0'

# Generated at 2022-06-24 08:27:18.258396
# Unit test for function url_unescape
def test_url_unescape():
    str = url_unescape("url")
    str = url_unescape("url", encoding="utf-8")
    str = url_unescape("url", encoding=None)
    str = url_unescape("url", encoding="utf-8", plus=True)
    str = url_unescape("url", encoding=None, plus=True)


# Generated at 2022-06-24 08:27:29.352054
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print('test_parse_qs_bytes()')
    print(parse_qs_bytes('foo=bar&foo=baz'))
    print(parse_qs_bytes(b'foo=bar&foo=baz'))
    print(parse_qs_bytes('foo=bar&foo=baz', keep_blank_values=True))
    print(parse_qs_bytes(b'foo=bar&foo=baz', keep_blank_values=True))
    print(parse_qs_bytes('foo=bar&foo=baz', strict_parsing=True))
    print(parse_qs_bytes(b'foo=bar&foo=baz', strict_parsing=True))
test_parse_qs_bytes()


# Generated at 2022-06-24 08:27:33.551971
# Unit test for function native_str
def test_native_str():
    assert native_str(None) is None  # noqa: F821
    assert native_str(b"abc") == "abc"
    assert native_str("abc") == "abc"
    if not six.PY3:
        assert native_str(u"abc") == "abc"

