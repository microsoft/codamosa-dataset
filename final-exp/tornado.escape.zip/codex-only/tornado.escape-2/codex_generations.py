

# Generated at 2022-06-24 08:17:39.300155
# Unit test for function native_str
def test_native_str():
    assert to_unicode("abc") == "abc"
    assert to_unicode(b"abc") == "abc"
    assert to_unicode("äöü") == "äöü"
    assert to_unicode(b"\xc3\xa4\xc3\xb6\xc3\xbc") == "äöü"


_BASESTRING_TYPES = (bytes, unicode_type, type(None))



# Generated at 2022-06-24 08:17:48.632699
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert(xhtml_escape("<script>") == "&lt;script&gt;")
    assert(xhtml_escape("'") == "&#39;")


# json_encode and json_decode are copied from http://json.org/json.py.
# Copyright 2005-2013 Bob Ippolito.
# Changes are subject to the Apache 2.0 license.
# http://www.apache.org/licenses/LICENSE-2.0.html
#
# Use speedups if available (simplejson).
try:
    import simplejson as json_lib
except ImportError:
    import json as json_lib

escape = (
    json_lib.dumps
    if hasattr(json_lib, "dumps")
    else json_lib.write  # type: ignore
)  # type: Callable[[

# Generated at 2022-06-24 08:17:52.900781
# Unit test for function native_str
def test_native_str():
    assert_equals(native_str('a'), 'a')
    #assert_equals(native_str(u'a'), 'a')
    #assert_equals(native_str(b'a'), 'a')


# Generated at 2022-06-24 08:17:54.932430
# Unit test for function linkify
def test_linkify():
    assert '<a href="http://example.com/">http://example.com/</a>' == linkify('http://example.com/')



# Generated at 2022-06-24 08:17:56.444166
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "bar"}) == '{"foo": "bar"}'



# Generated at 2022-06-24 08:18:05.862768
# Unit test for function url_unescape
def test_url_unescape():
    #print(url_unescape(b'https%3A%2F%2Fbaidu.com%2F%E5%9C%A8', 'utf-8'))
    t = url_unescape('https%3A%2F%2Fbaidu.com%2F%E5%9C%A8', 'utf-8')
    print(t)
#test_url_unescape()


# The following code is adapted from the utf8 function in
# http://www.webtoolkit.info/
_noop = object()



# Generated at 2022-06-24 08:18:10.434599
# Unit test for function json_encode
def test_json_encode():
    assert json_encode([1, 2, 3]) == "[1, 2, 3]"
    assert json_encode("</script>") == '"<\\/script>"'
test_json_encode()


_JSON_DECODE_REGEX = re.compile(r'\s*([,:]|\[|\]|{|})\s*')



# Generated at 2022-06-24 08:18:15.842094
# Unit test for function utf8
def test_utf8():
    assert utf8(b"Hello world") == b"Hello world"
    assert utf8("Hello world") == b"Hello world"
    assert utf8(None) is None
    try:
        utf8(1)
        assert False, "Failed to raise exception"
    except TypeError:
        pass
    try:
        utf8(object())
        assert False, "Failed to raise exception"
    except TypeError:
        pass
    assert utf8(u"Hello world") == b"Hello world"
    assert utf8(u"\u2318") == b"\xe2\x8c\x98"  # Mac option symbol



# Generated at 2022-06-24 08:18:20.167676
# Unit test for function json_decode
def test_json_decode():
    path = './data/'
    for file in os.listdir(path):
        file = path + file
        print(file)
        with open(file) as f:
            json_decode(json.dumps(json.load(f)))


# Generated at 2022-06-24 08:18:26.231771
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#x20EA;') == '⃪'
    assert xhtml_unescape('&#0041;') == 'A'
    assert xhtml_unescape('&#x7e;') == '~'
    assert xhtml_unescape('&nbsp;') == '\xa0'
    assert xhtml_unescape('&nbsp; &amp; &lt; &gt;') == '\xa0 & < >'

# Test unescape function for xhtml

# Generated at 2022-06-24 08:18:34.009811
# Unit test for function json_encode
def test_json_encode():
    # Encode some JSON and verify that it's valid.
    input_value = {"foo": "bar"}
    encoded_value = json_encode(input_value)
    assert encoded_value == '{"foo": "bar"}'
    assert json.loads(encoded_value) == input_value

    # Verify that forward slashes are escaped.
    assert json_encode("&</script>") == '"&\\u003c/script\\u003e"'
    # Really extra paranoia to make sure this doesn't break if we
    # change the implementation.
    assert json_encode("&</script>") != '"&</script>"'

    # Verify that we don't escape forward slashes unless we have to.

# Generated at 2022-06-24 08:18:40.352808
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert(xhtml_escape("<Hello>") == "&lt;Hello&gt;")
    assert(xhtml_escape("<") == "&lt;")
    assert(xhtml_escape(">") == "&gt;")
    assert(xhtml_escape("\"") == "&quot;")
    assert(xhtml_escape("\'") == "&#39;")
    assert(xhtml_escape("&") == "&amp;")



# Generated at 2022-06-24 08:18:42.863535
# Unit test for function json_decode
def test_json_decode():
    assert type(json_decode('{"abc":1}')) == dict
    assert json_decode('{"abc":1}')['abc'] == 1


# Generated at 2022-06-24 08:18:51.648221
# Unit test for function linkify
def test_linkify():
    # a valid url
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

    # a valid url with port
    text = 'Hello www.example.com:8000 !'
    assert linkify(text) == 'Hello <a href="http://www.example.com:8000">www.example.com:8000</a> !'

    # a valid url with https
    text = 'Hello https://www.example.com !'
    assert linkify(text) == 'Hello <a href="https://www.example.com">https://www.example.com</a> !'

    # a valid url with ftp
    text = 'Hello ftp://www.example.com !'

# Generated at 2022-06-24 08:18:58.621094
# Unit test for function utf8
def test_utf8():
    assert utf8(u'\u00e9') == b'\xc3\xa9'
    assert utf8('\xe9') == b'\xe9'
    assert utf8(b'\xe9') == b'\xe9'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:08.595332
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([1,2,3]) == [1,2,3]
    assert recursive_unicode(['foo','bar']) == ['foo','bar']
    assert recursive_unicode((1,2,3)) == (1,2,3)
    assert recursive_unicode(('foo','bar')) == ('foo','bar')
    assert recursive_unicode({1:2,3:4}) == {1:2,3:4}
    assert recursive_unicode({'foo':'bar'}) == {'foo':'bar'}
    assert recursive_unicode({
        'foo':{1:2},
        'bar':(1,2),
    }) == {'foo':{1:2}, 'bar':(1,2)}

# get_ident is used by the threading module, but it doesn

# Generated at 2022-06-24 08:19:12.134561
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('111') == '111'
    assert url_escape('11 1') == '11+1'
    assert url_escape('11 1', False) == '11%201'


# Generated at 2022-06-24 08:19:16.592749
# Unit test for function json_encode
def test_json_encode():
    d = {'a': 1, 'b': 'foo'}
    assert json_encode(d) == '{"a": 1, "b": "foo"}'
    assert json_encode([1, 2, 3]) == '[1, 2, 3]'
    assert json_encode("</script>") == '"<\\/script>"'



# Generated at 2022-06-24 08:19:18.899430
# Unit test for function json_decode
def test_json_decode():
    x = {"a": "b"}
    print(json_decode(json_encode(x)))



# Generated at 2022-06-24 08:19:27.532423
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('"1"') == 1
    assert json_decode('["1"]') == ["1"]
    assert json_decode(b'"1"') == 1
    assert json_decode(b'["1"]') == ["1"]
    assert json_decode(b'null') == None
    assert json_decode('null') == None
    assert json_decode('{"a": 1}') == {"a": 1}
    assert json_decode(b'{"a": 1}') == {"a": 1}
    assert json_decode(b'{"a": {"b": 2}}') == {"a": {"b": 2}}

# Generated at 2022-06-24 08:19:29.757266
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"<": "json"}).index("<\\/") != -1, "json_encode error"


# Generated at 2022-06-24 08:19:32.489633
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("a+b") == "a%2Bb"
    assert url_escape("a+b", plus=True) == "a+b"



# Generated at 2022-06-24 08:19:40.246339
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # The function's docstring is a unit test
    pass

# Escaping for HTML, XML, and XHTML
xhtml_escape.func_annotations = {
    "value": Union[str, bytes],
    "return": str,
}

_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:19:49.726794
# Unit test for function recursive_unicode
def test_recursive_unicode():
    print(recursive_unicode({'a': 'a', 'b': {'c': b'c'}, 'd': b'd'}))
    assert(recursive_unicode({'a': 'a', 'b': {'c': b'c'}, 'd': b'd'}) ==
           {'a': 'a', 'b': {'c': 'c'}, 'd': 'd'})
test_recursive_unicode()

# Fake byte literal support:  In python2, literal strings like b'foo' are just
# aliases for regular strings, which aren't very helpful.  In python3, byte
# strings also exist, and in python3.2+, literal strings like u'foo' are not
# aliases for regular strings.



# Generated at 2022-06-24 08:19:52.391957
# Unit test for function url_escape
def test_url_escape():
    value = "acb a <>vc"
    plus = True
    quote = urllib.parse.quote_plus if plus else urllib.parse.quote
    url_value = url_escape(value,plus)
    # print(url_value)
    assert url_value == quote(utf8(value))
test_url_escape()


# Generated at 2022-06-24 08:19:57.727890
# Unit test for function json_encode
def test_json_encode():
    # Test that forward slashes are escaped
    # and other characters (e.g. quotes and <) are not.
    assert json_encode('</script>') == '"<\\/script>"'
    assert json_encode('<\'"\\') == '"<\'\\"\\\\"'
    # Test with a well-known example from json.org
    assert json_encode({"url": "/foo?a=b&c=d"}) == '{"url": "/foo?a=b&c=d"}'
    # Test with a unicode character
    assert json_encode({"a": "\u00e9"}) == '{"a": "\\u00e9"}'
test_json_encode()


# settings for variable names used in json_decode
_CONVENTIONAL_VARIABLE_NAMES

# Generated at 2022-06-24 08:20:05.399992
# Unit test for function utf8
def test_utf8():
    assert utf8(u"asdf") == b"asdf"
    assert utf8(b"asdf") == b"asdf"
    assert utf8(None) is None
    # The next line fails
#     assert utf8(object()) == b"<object object at 0x7f8f965180e0>"
test_utf8()


_BASESTRING_TYPES = (str, bytes, type(None))



# Generated at 2022-06-24 08:20:11.001916
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a b c') == 'a b c'
    assert squeeze('a  b c') == 'a b c'
    assert squeeze('a \t b \n c') == 'a b c'
    assert squeeze(' a\t b \n c') == 'a b c'
    assert squeeze('a \t\tb \n c') == 'a b c'
    assert squeeze(' a \t\t b \n c ') == 'a b c'



# Generated at 2022-06-24 08:20:18.659136
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('abc dfg hij')=='abc dfg hij'
    assert squeeze(' abc dfg hij ')=='abc dfg hij'
    assert squeeze(' abc dfg h  ij ')=='abc dfg h ij'
    assert squeeze(' abc dfg h  ij    ')=='abc dfg h ij'
    assert squeeze(' \n\rabc dfg h  ij    ')=='abc dfg h ij'


# Generated at 2022-06-24 08:20:28.003947
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#63;') == '?'
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&#x27;') == "'"
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&#x60;') == '`'
    assert xhtml_unescape('&#96;') == '`'
    assert xhtml_unescape('&#x2C;') == ','
    assert xhtml_unescape('&#44;') == ','

# Generated at 2022-06-24 08:20:34.329789
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape( "&#32;" ) == " "
    assert xhtml_unescape( "&amp;&lt;&gt;&quot;&apos;" ) == "&<>\"'"
    assert xhtml_unescape( "&aacute;&Aacute;&eacute;&Eacute;&iacute;&Iacute;&oacute;&Oacute;&uacute;&Uacute;&ntilde;&Ntilde;" ) == "áÁéÉíÍóÓúÚñÑ"

# Generated at 2022-06-24 08:20:38.445046
# Unit test for function json_decode
def test_json_decode():
    str_object = '{"key":"value"}'
    str_decode = {"key":"value"}
    assert json_decode(str_object) == str_decode

    byte_object = b'{"key":"value"}'
    byte_decode = {"key":"value"}
    assert json_decode(byte_object) == byte_decode


# Generated at 2022-06-24 08:20:45.259426
# Unit test for function utf8
def test_utf8():
    utf8(None)
    utf8('abcde')
    utf8(b'abcde')
    # python 2
    utf8(u'abcde')
    assertRaises(TypeError, utf8, 123)
    assertRaises(TypeError, utf8, [1,2])


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:20:54.878132
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=%c3%a9+bar', True) == {b'foo': [b'\xc3\xa9 bar']}
    assert parse_qs_bytes(b'foo=%c3%a9+%25+bar', True) == {b'foo': [b'\xc3\xa9 % bar']}
    # '+' is the default value for keep_blank_values
    assert parse_qs_bytes(b'foo=%c3%a9+%25+bar') == {b'foo': [b'\xc3\xa9 % bar']}
    assert parse_qs_bytes(b'foo=%c3%a9+bar', False) == {b'foo': [b'\xc3\xa9 bar']}

# Generated at 2022-06-24 08:20:56.247094
# Unit test for function native_str
def test_native_str():
    assert isinstance(native_str("ascii"), str)
test_native_str()


# Generated at 2022-06-24 08:21:02.033804
# Unit test for function native_str
def test_native_str():
    if "native_str" not in globals():
        assert False, "'native_str' does not exist"
    if not isinstance(native_str, Callable):
        assert False, "'native_str' is not callable"

    if "unicode_type" not in globals():
        assert False, "'unicode_type' does not exist"
    if not isinstance(unicode_type, type):
        assert False, "'unicode_type' is not a type"

    if "unicode" not in globals():
        assert False, "'unicode' does not exist"
    if not isinstance(unicode, Callable):
        assert False, "'unicode' is not callable"

    class native_unicode(unicode):
        pass

    o = native_unicode('汉语')

# Generated at 2022-06-24 08:21:10.208066
# Unit test for function utf8
def test_utf8():
    value_unicode = 'abc'
    value_bytes = b'abc'
    value_none = None
    utf8_unicode = utf8(value_unicode)
    utf8_bytes = utf8(value_bytes)
    utf8_none = utf8(value_none)
    # utf8_unicode = abec, type: bytes
    # utf8_bytes = b'abc', type: bytes
    # utf8_none = None, type: None
    assert (type(utf8_unicode) == bytes)
    assert (type(utf8_bytes) == bytes)
    assert (type(utf8_none) == type(None))


# I originally used the regex from
# http://daringfireball.net/2010/07/improved_regex_for_

# Generated at 2022-06-24 08:21:12.373070
# Unit test for function linkify
def test_linkify():
    print(linkify('hello http://www.example.com/ this is a test '))



# Generated at 2022-06-24 08:21:22.529370
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;a&gt;") == "<a>"
    assert xhtml_unescape("&lt;a&gt;&gt;&nbsp;&amp;&copy;") == "<a>&nbsp;&amp;&copy;"
    assert xhtml_unescape("&lt;a&gt;&gt;&nbsp;&amp;&copy;") == "<a>&nbsp;&amp;&copy;"
    assert xhtml_unescape("&#34;&#xA0;&#xA9;&#32;") == """'"\xa0\xa9 """
    assert xhtml_unescape("&#34;&#xA0;&#xA9;&#32;") == """'"\xa0\xa9 """

# Generated at 2022-06-24 08:21:26.930660
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a+b", encoding="utf-8") == "a b"
    assert url_unescape(b"a+b", encoding=None) == b"a b"
    assert url_unescape("a+b", encoding="utf-8") == "a b"
    assert url_unescape("a+b", encoding=None) == b"a b"



# Generated at 2022-06-24 08:21:32.571091
# Unit test for function json_encode
def test_json_encode():
    test_data = [
        "a",
        "b",
        "c",
        "d",
        "e",
    ]
    expected = '["a", "b", "c", "d", "e"]'
    assert json_encode(test_data) == expected


# Generated at 2022-06-24 08:21:36.956445
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  aaaa  bbb   c  ') == 'aaaa bbb c'
    assert squeeze('  aaaa  bbb   c  ') != 'aaaa  bbb   c  '

url_escape = urllib.parse.quote
url_unescape = urllib.parse.unquote



# Generated at 2022-06-24 08:21:48.783901
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   a   b  c d   e") == "a b c d e"
    assert squeeze("\na\n\n\nb\n\nc\nd\ne") == "a b c d e"
    assert squeeze("\ta\tb\tc\td\te") == "a b c d e"
    assert squeeze("a\nb\nc\n\nd\n") == "a b c d"
    assert squeeze("\t\ta\t\t\tb\t\tc\t\td\t\te") == "a b c d e"
    assert squeeze("\n\n\n\na\n\n\n\n\nb\n\n\nc\n\n\n\nd\n\n\ne") == "a b c d e"

# Generated at 2022-06-24 08:21:52.276334
# Unit test for function utf8
def test_utf8():
    x = utf8("abc")
    assert x[0] == 97


# Generated at 2022-06-24 08:21:56.747482
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("some&") == "some&amp;"
    assert xhtml_escape("some<") == "some&lt;"
    assert xhtml_escape("some>") == "some&gt;"
    assert xhtml_escape("some\"") == "some&quot;"
    assert xhtml_escape("some'") == "some&#39;"
    assert xhtml_escape("\"some\"") == "&quot;some&quot;"



# Generated at 2022-06-24 08:22:05.260734
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#39;') == '\''
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&gt;') == '>'

    assert xhtml_unescape('&#39;') == '\''
    assert xhtml_unescape('&#65;') == 'A'
    assert xhtml_unescape('&#x41;') == 'A'
    assert xhtml_unescape('&#x3A3;') == 'Σ'

    assert xhtml_unescape('&Anum;') == 'ℵ'

# Generated at 2022-06-24 08:22:11.032797
# Unit test for function utf8
def test_utf8():
    test_str1 = "愛你"
    test_str2 = "I Love You"
    assert utf8(test_str1) == b'\xe6\x84\x9b\xe4\xbd\xa0'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:22:22.330696
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&<>"\'') == '&amp;&lt;&gt;&quot;&#39;'
    assert xhtml_escape(b'foo') == 'foo'
    assert xhtml_escape(u'foo') == 'foo'
    assert xhtml_escape(u'foo\N{SNOWMAN}') == 'foo\N{SNOWMAN}'

_JSON_ESCAPE_RE = re.compile(r'[\x00-\x1f\\"\b\f\n\r\t]')

# Generated at 2022-06-24 08:22:28.786659
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # create a nested dictionary
    a = {b"key1": b"value1", b"key2": b"value2"}
    # call our recursive_unicode() function
    recursive_unicode(a)
    # TODO: add assert to check the result
    # if the assert passes, it's OK
    # if the assert fails, it will throw AssertionError
    assert isinstance(a['key1'], str)
    assert isinstance(a['key2'], str)
    assert a['key1'] == 'value1'
    assert a['key2'] == 'value2'


# Generated at 2022-06-24 08:22:35.215760
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"foo=bar&baz=1") == {"foo": [b"bar"], "baz": [b"1"]}
    assert parse_qs_bytes(b"foo=bar&baz=1&baz=2") == {"foo": [b"bar"], "baz": [b"1", b"2"]}
    assert parse_qs_bytes(b"foo=bar;baz=1") == {"foo": [b"bar"], "baz": [b"1"]}
    assert parse_qs_bytes(b"foo=bar;baz=1;baz=2") == {"foo": [b"bar"], "baz": [b"1", b"2"]}

# Generated at 2022-06-24 08:22:38.430008
# Unit test for function utf8
def test_utf8():
    c = '你好'
    assert utf8(c) == '你好'

# Generated at 2022-06-24 08:22:42.091481
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&#39;') == "'"

# _convert_entity is used in xhtml_unescape

# Generated at 2022-06-24 08:22:53.144990
# Unit test for function url_unescape
def test_url_unescape():
    encoded = '%C3%A9'
    decoded = url_unescape(encoded)
    assert decoded == 'é'
    assert type(decoded) is str
    decoded = url_unescape(encoded, encoding=None)
    assert decoded == b'\xc3\xa9'
    assert type(decoded) is bytes
    decoded = url_unescape(encoded, encoding='ascii')
    assert decoded == 'é'
    assert type(decoded) is str
    decoded = url_unescape(encoded, encoding='ascii', plus=False)
    assert decoded == '%C3%A9'
    assert type(decoded) is str
    encoded = '%2B'
    decoded = url_unescape(encoded, encoding='ascii')


# Generated at 2022-06-24 08:22:55.596182
# Unit test for function native_str
def test_native_str():
    assert native_str("hello") == "hello"
    assert native_str(u("hello")) == "hello"



# Generated at 2022-06-24 08:23:02.118579
# Unit test for function json_decode
def test_json_decode():
    test_str = """
    {
        "abc": 1,
        "def": 2
    }
    """
    test_obj = json_decode(test_str)
    assert test_obj["abc"] == 1
    assert test_obj["def"] == 2



# Generated at 2022-06-24 08:23:05.480083
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;') == '\''
    assert xhtml_unescape('&#x7B;') == '{'
    assert xhtml_unescape('') == ''



# Generated at 2022-06-24 08:23:16.486590
# Unit test for function native_str
def test_native_str():
    # r'' yields unicode strings on py2, bytes strings on py3
    assert native_str(r'\xc3\xbc') == '\xc3\xbc'
    assert native_str(r'\xc3\xbc'.encode('utf8')) == '\xc3\xbc'
    assert native_str(r'\xc3\xbc'.encode('latin1')) == '\xc3\xbc'.encode('latin1')
    assert native_str(r'abc') == 'abc'
    assert native_str(r'abc'.encode('utf8')) == 'abc'
    assert native_str(r'abc'.encode('latin1')) == 'abc'.encode('latin1')
    assert native_str(b'\xc3\xbc') == b

# Generated at 2022-06-24 08:23:26.373568
# Unit test for function linkify
def test_linkify():
    print (linkify('hello world'))
    print (linkify('http://example.com'))
    print (linkify('hi www.example.com world'))
    print (linkify('hi www.example.com world', require_protocol=False))
   # print (linkify(text, extra_params='rel="nofollow" class="external"')
    print (linkify('hello world', extra_params="rel='nofollow' class='external'"))
    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    #require_protocol=True
    print (linkify('hi www.example.com world', require_protocol=True))
    print

# Generated at 2022-06-24 08:23:34.998121
# Unit test for function utf8
def test_utf8():
    assert utf8(None) == None
    assert utf8(b'abc') == b'abc'
    assert utf8('\u07ff') == b'\xdf\xbf'
    assert utf8('\u0800') == b'\xe0\xa0\x80'
    assert utf8('\ufffd') == b'\xef\xbf\xbd'
    assert utf8('\U0001f43e') == b'\xf0\x9f\x91\xbe'
    assert utf8('\U0010ffff') == b'\xf4\x8f\xbf\xbf'
    try:
        utf8('\ud83d')
    except TypeError:
        pass
    else:
        assert False


_TO_UNICODE_TY

# Generated at 2022-06-24 08:23:38.046782
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = "&<>\"'"
    expected = "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape(value) == expected


# Generated at 2022-06-24 08:23:42.453979
# Unit test for function xhtml_escape
def test_xhtml_escape():
    s = "& < > \" '"
    n = xhtml_escape(s)
    assert n == "&amp; &lt; &gt; &quot; &#39;"



# Generated at 2022-06-24 08:23:52.021064
# Unit test for function utf8
def test_utf8():
    def assert_utf8(expected, input):
        actual = utf8(input)
        assert expected == actual, "%r != %r" % (expected, actual)

    assert_utf8(b'abc', b'abc')
    assert_utf8(b'abc', u'abc')
    assert_utf8(u'abc'.encode('utf8'), u'abc')
    assert_utf8(None, None)
    assert_utf8(b'\xe4\xb8\x96\xe7\x95\x8c', u'\u4e16\u754c')
    try:
        assert_utf8(b'abc', 1)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-24 08:24:00.039032
# Unit test for function url_unescape
def test_url_unescape():  # noqa: F811
    assert url_unescape('a+b') == 'a b'
    assert url_unescape('a+b', encoding=None) == b'a b'
    assert url_unescape(b'a%2Bb', encoding=None) == b'a+b'
    assert url_unescape(b'a%2Bb', plus=False, encoding=None) == b'a+b'
    assert url_unescape(b'a%2Bb', encoding='ascii') == 'a+b'
    assert url_unescape(b'a%2Bb', plus=False, encoding='ascii') == 'a b'
    assert url_unescape(b'a%2Bb', encoding='utf-8') == 'a+b'

# Generated at 2022-06-24 08:24:09.716538
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&#34;") == '"'
    assert xhtml_unescape("&#x22;") == '"'
test_xhtml_unescape()


# Allow use of u'' to represent a Unicode string even when no unicode
# literals are available (some versions of Python < 2.6 don't have them).
if type("") == unicode_type:
    def _unicode(s):
        return s
else:
    def _unicode(s):
        return s if isinstance(s, unicode_type) else s.decode("utf-8", "replace")



# Generated at 2022-06-24 08:24:17.788355
# Unit test for function json_encode
def test_json_encode():
    # data from github link
    data = [
        {'slash': '/'},
        {'slash': '/', 'slash-escaped': '\/'},
        {'html': '<html>'},
        {'html': '<html>', 'html-escaped': '<html>'},
    ]
    encoded = json_encode(data)
    assert encoded == json.dumps(data)
    encoded2 = json.dumps(data).replace("</", "<\\/")
    assert encoded == encoded2
    encoded3 = json_encode(data).replace("</", "<\\/")
    assert encoded == encoded3


# to_unicode is deprecated in favor of tornado.util.to_unicode,
# and will be removed in Tornado 6.0.
to_unicode = unicode_type

# Generated at 2022-06-24 08:24:23.464822
# Unit test for function json_encode
def test_json_encode():
    # Given
    value = '{"name":"Joseph","age":24, "school": "CS"}'
    expected_json_encoded_value = '{"name":"Joseph","age":24, "school": "CS"}'
    # When
    json_encoded_value = json_encode(value)
    # Then
    assert json_encoded_value == expected_json_encoded_value



# Generated at 2022-06-24 08:24:33.198394
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%20') == '%20'
    assert url_unescape('%20', plus=False) == '%20'
    assert url_unescape('a', plus=False) == 'a'
    assert url_unescape('a', encoding='utf-8', plus=False) == 'a'
    assert url_unescape('a+%2B+%2B', encoding='utf-8', plus=False) == 'a+ + +'
    assert url_unescape('a+%2B+%2B', encoding='utf-8', plus=True) == 'a  +'



# Generated at 2022-06-24 08:24:43.895259
# Unit test for function linkify
def test_linkify():
    assert linkify(r'"test":http://example.com') == r'''"test":<a href="http://example.com">http://example.com</a>'''
    assert linkify(r'http://example.com') == r'<a href="http://example.com">http://example.com</a>'
    assert linkify(r'http://example.com/foo') == r'<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify(r'http://example.com/foo/bar') == r'<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'

# Generated at 2022-06-24 08:24:50.715431
# Unit test for function json_encode
def test_json_encode():
    assert json_encode("a") == '"a"'
    assert json_encode("\\n") == '"\\\\n"'
    assert json_encode("/") == '"\\/"'
    assert json_encode("a//b") == '"a//b"'
    assert json_encode("a\\/a") == '"a\\\\/a"'
test_json_encode()


# to_unicode is used for paths and headers, which may be either
# bytes or unicode strings.  We use utf-8 for the default encoding
# since it is an ASCII superset and is likely to be the most useful.

# Generated at 2022-06-24 08:25:01.406611
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs1 = parse_qs_bytes(b'a=1&b=2&b=3')
    assert qs1[b'a'] == [b'1']
    assert len(qs1[b'b']) == 2
    assert qs1[b'b'][0] == b'2'
    assert qs1[b'b'][1] == b'3'

    qs2 = parse_qs_bytes(b'a=1&b&c=')
    assert qs2[b'a'] == [b'1']
    assert qs2[b'b'] == [b'']
    assert qs2[b'c'] == [b'']

    qs3 = parse_qs_bytes(b'a=1&&&&&b=2&&&&b=3', True)


# Generated at 2022-06-24 08:25:04.128179
# Unit test for function squeeze
def test_squeeze():
    assert b'a b  c' == squeeze(b'a b  c')
    assert b'a b  c' == squeeze(b'a       b  c')
    assert b'a b  c' == squeeze(b'a \t\r\nb  c')



# Generated at 2022-06-24 08:25:10.260882
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#42;") == "*"
    assert xhtml_unescape("&#x2a;") == "*"
    assert xhtml_unescape("&nbsp;") == "\u00a0"
    assert xhtml_unescape("&nbsp;&amp;&nbsp;") == "\u00a0&\u00a0"
    assert xhtml_unescape("&quot;&lt;&gt;&apos;&amp;") == "\"<>'&"
    assert xhtml_unescape("&lt;&foo;") == "&lt;&foo;"
    assert xhtml_unescape("&bogus;") == "&bogus;"



# Generated at 2022-06-24 08:25:14.266158
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    expected = {
        b"foo": [b"foo1"],
        b"bar": [b"bar1", b"bar2"],
    }
    assert expected == parse_qs_bytes(b"foo=foo1&bar=bar1&bar=bar2")



# Generated at 2022-06-24 08:25:24.796293
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert(xhtml_unescape("&#38;") == "&")
    assert(xhtml_unescape("&amp;") == "&")
    assert(xhtml_unescape("&#x26;") == "&")
    assert(xhtml_unescape("&lt;") == "<")
    assert(xhtml_unescape("&#60;") == "<")
    assert(xhtml_unescape("&gt;") == ">")
    assert(xhtml_unescape("&#62;") == ">")
    assert(xhtml_unescape("&quot;") == '"')
    assert(xhtml_unescape("&#34;") == '"')
    assert(xhtml_unescape("&apos;") == "'")

# Generated at 2022-06-24 08:25:29.596031
# Unit test for function json_decode
def test_json_decode():
    "Testing function json_decode"
    assert json_decode("{'foo':'bar'}") == {'foo': 'bar'}
    assert json_decode('{"foo": "bar"}') == {'foo': 'bar'}
test_json_decode()



# Generated at 2022-06-24 08:25:34.488697
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    ascii = "&lt;div&gt;&#39;hello&#39;&lt;/div&gt;"
    utf8 = "&#20320;&#22909;"
    assert xhtml_unescape(ascii) == "<div>'hello'</div>"
    assert xhtml_unescape(utf8) == "吼龍"


_BASESTRING_TYPES = (bytes, str, bytearray)


# Generated at 2022-06-24 08:25:42.311254
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8("中国") == b"\xe4\xb8\xad\xe5\x9b\xbd"
    assert utf8("中国".encode("gbk")) == b"\xe4\xb8\xad\xe5\x9b\xbd"



# Generated at 2022-06-24 08:25:52.239490
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert 1 == recursive_unicode(1)
    assert 1.0 == recursive_unicode(1.0)
    assert "s" == recursive_unicode("s")
    assert u"s" == recursive_unicode(u"s")
    assert "Hello World!" == recursive_unicode("Hello World!")
    assert u"Hello World!" == recursive_unicode(u"Hello World!")

    assert [1] == recursive_unicode([1])
    assert [1, 2] == recursive_unicode([1, 2])
    assert ["s"] == recursive_unicode(["s"])
    assert [u"s"] == recursive_unicode([u"s"])
    assert ["Hello World!"] == recursive_unicode(["Hello World!"])

# Generated at 2022-06-24 08:25:57.232312
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    a = xhtml_unescape("&#x93;&#xfa;")
    assert(a=="Гъ")
test_xhtml_unescape()

_BASESTRING_TYPES = (bytes, str, unicode_type)  # type: Tuple[Any, ...]
_HTML_TYPES = _BASESTRING_TYPES



# Generated at 2022-06-24 08:26:02.524083
# Unit test for function utf8
def test_utf8():
    assert utf8(unicode_type()) == b""
    assert utf8(u"фыва") == b"\xd1\x84\xd1\x8b\xd0\xb2\xd0\xb0"
    try:
        utf8(123)
        assert False
    except TypeError:
        assert True


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:08.978780
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'f%3Dd') == {'f':[b'd']}
test_parse_qs_bytes()


# Generated at 2022-06-24 08:26:13.514296
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("xyz", encoding="utf-8") == "xyz"
    assert url_unescape("", encoding="utf-8") == ""
    assert url_unescape(b"xyz", encoding="utf-8") == "xyz"
    assert url_unescape(b"xyz", encoding="utf-8") == "xyz"
    assert url_unescape(b"xyz", encoding=None) == b"xyz"
    assert url_unescape(b"xyz", encoding=None) == b"xyz"
    assert url_unescape(b"xyz", encoding="utf-8", plus=True) == "xyz"
    assert url_unescape(b"x/y/z", encoding="utf-8", plus=False) == "x/y/z"



# Generated at 2022-06-24 08:26:17.594977
# Unit test for function utf8
def test_utf8(): assert utf8('abc') == b'abc'

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:23.550497
# Unit test for function recursive_unicode
def test_recursive_unicode():
    for data in (
        1, u"1", b"1",
        [], [u"1", b"2", 3], (u"1", b"2", 3),
        {}, {u"1": b"2"}, {"1": 2},
    ):
        assert recursive_unicode(data) == recursive_unicode(recursive_unicode(data))



# Generated at 2022-06-24 08:26:33.450227
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({}) == '{}'
    assert json_encode([]) == '[]'
    assert json_encode({"a": "b"}) == '{"a": "b"}'
    assert json_encode([1, 2, 3]) == '[1, 2, 3]'
    assert (
        json_encode({"a": "</script>"})
        == '{"a": "<\\/script>"}'
    )



# Generated at 2022-06-24 08:26:44.584288
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<div>') == '&lt;div&gt;'
    assert xhtml_escape('<div/>') == '&lt;div/&gt;'
    assert xhtml_escape('<div />') == '&lt;div /&gt;'
    assert xhtml_escape('<div  />') == '&lt;div  /&gt;'
    assert xhtml_escape('<div\t/>') == '&lt;div\t/&gt;'
    assert xhtml_escape('<div attr=val attr2 = "val2"/>') == '&lt;div attr=val attr2 = "val2"/&gt;'

# Generated at 2022-06-24 08:26:49.150872
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>&\"'") == "&lt;&gt;&amp;&quot;&#39;"

_URL_ESCAPE_RE = re.compile(r"[^a-zA-Z0-9_.~-]")



# Generated at 2022-06-24 08:26:57.065978
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("email=exampe@example.com&name=诶默") == \
        "email=exampe%40example.com&name=%E8%AF%B6%E9%BB%98"
    assert url_escape("email=exampe@example.com&name=诶默", plus=True) == \
        "email=exampe+%40example.com&name=%E8%AF%B6%E9%BB%98"



# Generated at 2022-06-24 08:27:00.933197
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
  print(xhtml_unescape("&lt;&gt;&quot;&#39;&amp;"))
  print(xhtml_unescape("&lt;&gt;&quot;&apos;&amp;"))
 



# Generated at 2022-06-24 08:27:03.888663
# Unit test for function url_escape
def test_url_escape():
    print(url_escape('http://example.com/?param=1&foo=bar'))
    print(url_escape('http://example.com/?param=1&foo=bar',False))
test_url_escape()


# Generated at 2022-06-24 08:27:09.395354
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = '&<>"\''
    escape = "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape(value) == escape

_JSON_ENCODE_OPTIONS = {
    "ensure_ascii": False,
    "separators": ",:",
    "escape_forward_slashes": False,
}



# Generated at 2022-06-24 08:27:12.405465
# Unit test for function json_encode
def test_json_encode():
    dic_test = {
        'test': 'ok',
        'test1': 1,
        'test2': {'test': 'ok'}
    }
    print(json_encode(dic_test))


# json_decode wraps json.loads with comments stripped.

# Generated at 2022-06-24 08:27:19.877885
# Unit test for function json_decode
def test_json_decode():
    s = '["foo", {"bar":["baz", null, 1.0, 2]}]'
    assert json_decode(s) == ['foo', {'bar': ['baz', None, 1.0, 2]}]
    s = '"\\"foo\\bar"'
    assert json_decode(s) == '"foo\x08ar'

_recursive_repr = re.compile(r"^<(class|function).*>$")

# TODO: assume json_encode will handle recursive structures?

# Generated at 2022-06-24 08:27:23.136923
# Unit test for function json_decode
def test_json_decode():
    assert  json_decode(r'{"hello"}') == {"hello"}
    assert  json_decode(r'{"hello":"world"}') ==  {"hello":"world"}


# Generated at 2022-06-24 08:27:27.723474
# Unit test for function linkify
def test_linkify():
    text = u"https://github.com"
    result = linkify(text)
    assert result == u'<a href="https://github.com">https://github.com</a>'


_sentinel = object()



# Generated at 2022-06-24 08:27:31.459934
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": "b"}) == '{"a": "b"}'
    assert json_encode({"a": ["<\\/script>"]}) == '{"a": ["<\\\\/script>"]}'


_json_decode = json.JSONDecoder().decode

# Generated at 2022-06-24 08:27:38.161922
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'foo') == 'foo'
    # The following 3 tests show different behaviors on Python 2 and Python 3
    assert url_unescape(b'foo+bar') == 'foo+bar'
    assert url_unescape(b'foo+bar', plus=False) == 'foo bar'
    assert url_unescape(b'foo%2Bbar') == 'foo+bar'
    assert url_unescape(b'foo%2Bbar', plus=False) == 'foo+bar'

