

# Generated at 2022-06-24 08:17:38.836208
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a b \t\n\n c   d') == 'a b c d'
    assert not squeeze('a  b') == 'a b'

# This set of entities is defined by default for all XML and HTML documents.
# In addition, there is a small set of XML entities that are special
# (for example, "<" is the start of a tag).  HTML supports some additional
# entities for special characters that aren't in the default set, including
# some (such as &apos;) that aren't strictly valid in XML.
_HTML_UNICODE_MAP = (
    ("&amp;", "&"),
    ("&apos;", "'"),
    ("&gt;", ">"),
    ("&lt;", "<"),
    ("&quot;", '"'),
)

# Generated at 2022-06-24 08:17:48.390704
# Unit test for function native_str
def test_native_str():
    import sys
    print('native_str(%s) -> %s' % (3, native_str(3)))
    print('native_str(%s) -> %s' % (3.14159, native_str(3.14159)))
    print('native_str(%s) -> %s' % ("Hello, World!", native_str("Hello, World!")))
    print('native_str(%s, %s) -> %s' % (chr(0x3042), 'utf-8', native_str(chr(0x3042), 'utf-8')))
    print('native_str(%s) -> %s' % (chr(0x3042), native_str(chr(0x3042))))

# Generated at 2022-06-24 08:17:56.488688
# Unit test for function xhtml_escape
def test_xhtml_escape():
  assert xhtml_escape("<script>alert('xss');</script>") == "&lt;script&gt;alert(&#39;xss&#39;);&lt;/script&gt;"
test_xhtml_escape()


_XML_ESCAPE_RE = re.compile("[&<>\"']")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
}



# Generated at 2022-06-24 08:18:04.693762
# Unit test for function native_str
def test_native_str():
    assert native_str(b"abc") == b"abc"
    assert native_str(b"abc".decode("utf-8")) == "abc"
    assert native_str("abc") == "abc"
    assert native_str(u"abc") == "abc"
    assert native_str(None) is None


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:18:08.072558
# Unit test for function linkify
def test_linkify():
    text=linkify("Hello http://tornadoweb.org!", shorten=False, extra_params='rel="nofollow" class="external', require_protocol=False, permitted_protocols=['http', 'https'])
    print(text)

# Generated at 2022-06-24 08:18:09.357541
# Unit test for function json_encode
def test_json_encode():
    assert json_encode('/') == '"\\/"'



# Generated at 2022-06-24 08:18:11.985033
# Unit test for function utf8
def test_utf8():
    assert utf8('123') == b'123'
    assert utf8(None) is None
    assert utf8('123') == '123'.encode()



# Generated at 2022-06-24 08:18:16.322715
# Unit test for function native_str
def test_native_str():
    string = "_çãõ"
    assert isinstance(string, str) == True
    assert isinstance(string, bytes) == False
    assert isinstance(string, unicode_type) == False

test_native_str()


# Generated at 2022-06-24 08:18:26.496213
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a+%3C%3E%22%27z") == "a+<>\"'z"
    assert url_unescape("a+%3C%3E%22%27z", plus=False) == "a+%3C%3E%22%27z"
    assert url_unescape(b"a+%3C%3E%22%27z") == b"a+<>\"'z"
    assert url_unescape(b"a+%3C%3E%22%27z", plus=False) == b"a+%3C%3E%22%27z"
    assert url_unescape(b"a+%3C%3E%22%27z", encoding=None) == b"a+<>\"'z"
    assert url_unescape

# Generated at 2022-06-24 08:18:30.629904
# Unit test for function utf8
def test_utf8():
    assert utf8('abc') == b'abc'
    assert utf8(u'abc') == b'abc'
    assert utf8(None) is None
    assert utf8(1) == b'1'
    
    
_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:32.838178
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert ">" == xhtml_unescape("&gt;")



# Generated at 2022-06-24 08:18:37.960694
# Unit test for function utf8
def test_utf8():
    assert utf8('foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8(b'foo') == b'foo'
    assert utf8(None) == None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:47.949799
# Unit test for function native_str
def test_native_str():
    assert isinstance(_unicode(u"foo"), unicode_type)
    assert isinstance(_unicode(b"foo"), unicode_type)
    assert isinstance(_unicode(None), unicode_type)
    assert isinstance(_unicode(u"\u2603"), unicode_type)
    assert isinstance(_unicode(b"\xe2\x98\x83"), unicode_type)
    assert _unicode(None) == unicode_type(None)
    assert _unicode(u"foo") == u"foo"
    assert _unicode(b"foo") == u"foo"
    assert _unicode(b"\xc3\xa9") == u"\xe9"


_BASESTRING_TYPES = (unicode_type, bytes, type(None))



# Generated at 2022-06-24 08:18:58.279150
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape(">") == "&gt;"
    assert xhtml_escape('"') == "&quot;"
    assert xhtml_escape("'") == "&#39;"
    assert xhtml_escape("<script>alert('xss')</script>") == "&lt;script&gt;alert(&#39;xss&#39;)&lt;/script&gt;"
    assert xhtml_escape("<span>") == "&lt;span&gt;"

_URL_UNSAFE_SHORT = re.compile(r"[&\"'<>%]")



# Generated at 2022-06-24 08:19:03.508666
# Unit test for function json_decode
def test_json_decode():
    assert json.loads(u'{"name": "Maks", "age": 25}') == json_decode(u'{"name": "Maks", "age": 25}')
# Testing utils
test_json_decode()


# to_unicode is deprecated in favor of to_basestring.
to_unicode = to_basestring = bytes_type = unicode_type



# Generated at 2022-06-24 08:19:09.169416
# Unit test for function utf8
def test_utf8():
    if sys.version_info >= (3,):
        assert utf8('foo') == b'foo'
        assert utf8(None) is None
    else:
        assert utf8('foo') == 'foo'
        assert utf8(u'foo') == 'foo'
        assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:12.900134
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&b=2') == {'a': [b'1'], 'b': [b'2']}



# Generated at 2022-06-24 08:19:17.073746
# Unit test for function squeeze
def test_squeeze():
    s = "This is a test"
    assert squeeze(s) == "This is a test"
    s = "This is \ta \ntest"
    assert squeeze(s) == "This is a test"
    s = "This   is \ta   \ntest"
    assert squeeze(s) == "This is a test"



# Generated at 2022-06-24 08:19:24.385346
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": "a"}) == {"a": "a"}
    assert recursive_unicode({"a": b"a"}) == {"a": "a"}
    assert recursive_unicode([b"a"]) == ["a"]
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode((b"a",)) == ("a",)
    assert recursive_unicode((1, 2)) == (1, 2)
    assert recursive_unicode(1) == 1



# Generated at 2022-06-24 08:19:33.084384
# Unit test for function utf8
def test_utf8():
    assert utf8(b"abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\xe9") == b"\xc3\xa9"
    assert utf8(None) is None
    try:
        utf8(123)
    except TypeError:
        pass
    else:
        assert False, "Failed to raise TypeError"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:45.506077
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = {1: 2, 'a': 'b'}
    y = recursive_unicode(x)
    assert y == {1: 2, 'a': 'b'}
    assert isinstance(y, dict)
    assert isinstance(y[1], int)
    assert isinstance(y['a'], str)

    x = [1, 'a']
    y = recursive_unicode(x)
    assert y == [1, 'a']
    assert isinstance(y, list)
    assert isinstance(y[0], int)
    assert isinstance(y[1], str)

    x = (1, [1, 'a'])
    y = recursive_unicode(x)
    assert y == (1, [1, 'a'])
    assert isinstance(y, tuple)
    assert isinstance

# Generated at 2022-06-24 08:19:48.683819
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&nbsp;&lt;&gt;&quot;&#39;") == "&nbsp;<>\"'"


# Generated at 2022-06-24 08:19:56.528230
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://www.oschina.net?key=哈哈", plus=True) == "http%3A%2F%2Fwww.oschina.net%3Fkey%3D%E5%93%88%E5%93%88"
    assert url_escape("http://www.oschina.net?key=哈哈", plus=False) == "http%3A%2F%2Fwww.oschina.net%3Fkey%3D%E5%93%88%E5%93%88"

# Generated at 2022-06-24 08:20:08.002478
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    text = "Hello www.baidu.com!"
    assert linkify(text,require_protocol=False) == 'Hello <a href="http://www.baidu.com">www.baidu.com</a>!'
    text = "Hello www.baidu.com!"
    assert linkify(text,require_protocol=True) == 'Hello www.baidu.com!'
    text = "http://www.baidu.com/index.html?"

# Generated at 2022-06-24 08:20:13.206721
# Unit test for function utf8
def test_utf8():
    assert utf8(b'\xe4\xb8\xad\xe6\x96\x87')==b'\xe4\xb8\xad\xe6\x96\x87'
    assert utf8(u'中文')==b'\xe4\xb8\xad\xe6\x96\x87'
    assert utf8(None)==None
    assert_raises(TypeError,lambda: utf8(object()))
# test_utf8()



# Generated at 2022-06-24 08:20:22.084237
# Unit test for function url_escape
def test_url_escape():
    import urllib
    assert url_escape('a') == urllib.parse.quote_plus('a')
    assert url_escape('a', plus=False) == urllib.parse.quote('a')
    assert url_escape('a b') == urllib.parse.quote_plus('a b')
    assert url_escape('a b', plus=False) == urllib.parse.quote('a b')
    assert url_escape('a', plus=True) == urllib.parse.quote_plus('a')
test_url_escape()


# Generated at 2022-06-24 08:20:32.305522
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(False) == 'false'
    assert json_encode(42) == '42'
    assert json_encode('test') == '"test"'
    assert json_encode('"<script>') == '"\\u0022\\u003cscript\\u003e"'
    assert json_encode(['A', 42]) == '["A",42]'
    assert json_encode({'A': 42}) == '{"A":42}'
    assert json_encode(to_basestring('\xe7\xbd\x91\xe9\xa1\xb5')) == '"\\u7f51\\u9875"'

# When we are in Python 3 and cdecimal is available, json_encode should use
# CDecimal instead of Decimal and fallback to str for unsupported types

# Generated at 2022-06-24 08:20:33.399053
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("    a    b    ") == "a b"




# Generated at 2022-06-24 08:20:35.162086
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape("\"") == "&quot;"


# Generated at 2022-06-24 08:20:45.868834
# Unit test for function recursive_unicode

# Generated at 2022-06-24 08:20:55.137741
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a+b") == b"a b"
    assert url_unescape(b"a+b", encoding=None) == b"a b"
    assert url_unescape(b"a%20b") == b"a b"
    assert url_unescape(b"a%20b", encoding=None) == b"a b"
    # assert url_unescape(u"a+b") == u"a+b"
    assert url_unescape(u"a+b", plus=False) == u"a+b"
    assert url_unescape(b"a+b", plus=False) == u"a+b"
    # assert url_unescape(u"a%20b") == u"a b"

# Generated at 2022-06-24 08:21:06.168167
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('a+b') == 'a+b'
    assert url_unescape('a+b', plus=False) == 'a b'
    assert url_unescape('a%20b') == 'a b'
    assert url_unescape(b'a%20b') == b'a b'
    assert url_unescape(b'a%20b', encoding=None) == b'a b'
    assert url_unescape(b'a+b', encoding=None) == b'a+b'
    assert url_unescape(b'a+b', encoding=None, plus=False) == b'a b'

    # b'a b' and not b'a%20b'
    assert url_unescape('a+b', encoding=None) == b'a b'
    # 'a

# Generated at 2022-06-24 08:21:12.324383
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2&a=3") == {b"a": [b"1", b"3"], b"b": [b"2"]}
test_parse_qs_bytes()

# urllib treats + specially in query strings but not urlencoded form data,
# so we need separate decoding functions.


# Generated at 2022-06-24 08:21:13.976079
# Unit test for function json_encode
def test_json_encode():
    assert '{"a": "</script>"}' == json_encode({"a": "</script>"})



# Generated at 2022-06-24 08:21:16.505453
# Unit test for function url_escape
def test_url_escape():
    s = "http://www.baidu.com/s?wd=hongwenjun"
    print(url_escape(s))


# Generated at 2022-06-24 08:21:19.285162
# Unit test for function url_unescape
def test_url_unescape():
    v = url_unescape("%E4%B8%AD%E6%96%87", encoding="UTF-8")
    print(v)
    assert v == "中文"



# Generated at 2022-06-24 08:21:24.218495
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"


# Generated at 2022-06-24 08:21:25.755546
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("a<b>c") == "a&lt;b&gt;c"



# Generated at 2022-06-24 08:21:32.579614
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("") == ""
    assert squeeze(" ") == " "
    assert squeeze("\t\n\x0b\x0c\r ") == " "
    assert squeeze(" \t\n\x0b\x0c\r ") == " "
    assert squeeze("\t\n\x0b\x0c\r a") == " a"
    assert squeeze("a\t\n\x0b\x0c\r ") == "a "
    assert squeeze(" \t\n\x0b\x0c\r a \t\n\x0b\x0c\r ") == " a "
    assert squeeze("a") == "a"
    assert squeeze(" a") == " a"
    assert squeeze("a ") == "a "

# Generated at 2022-06-24 08:21:36.637656
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    pairs = parse_qs_bytes("a=b&%20=1&%3F=2")
    assert pairs == {"a": [b"b"], " ": [b"1"], "?": [b"2"]}
test_parse_qs_bytes()



# Generated at 2022-06-24 08:21:42.562367
# Unit test for function squeeze
def test_squeeze():
  #print("\n\nTesting squeeze()\n\n")
  
  test_string = "Hello\nThere\tHow\nAre    \t   You?"
  actual = squeeze(test_string)
  expected = "Hello There How Are You?"
  if actual != expected:
    print("Failed Test")
    print("Expected: " + "\"" + expected + "\"")
    print("Actual: " + "\"" + actual + "\"")
  else:
    print("Squeeze Passed")

test_squeeze()



# Generated at 2022-06-24 08:21:46.623473
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=bar&baz=quux') == {'foo': [b'bar'], 'baz': [b'quux']}


# Generated at 2022-06-24 08:21:54.886945
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(' a \tb \n') == 'a b'
    assert squeeze(' \t  \n \r   \r\t  \r\r') == ''
    assert squeeze(' a  b') == 'a b'
    assert squeeze('a \tb \n') == 'a b'
    assert squeeze(' a\tb\n') == 'a b'
    assert squeeze(' \t \n') == ''
    assert squeeze(' \t  \n \r   \r\t  \r\r') == ''



# Generated at 2022-06-24 08:22:00.359583
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{\"test\": \"val\"}") == {'test': 'val'}
    assert json_decode(b"{\"test\": \"val\"}") == {'test': 'val'}



# Generated at 2022-06-24 08:22:07.170315
# Unit test for function native_str
def test_native_str():
    assert native_str(b"\xe9") == "\xe9"
    assert native_str(b"\xe9", "utf8") == "é"
    assert native_str(b"\xe9", "ascii", "ignore") == ""
    assert native_str(b"\xe9", "ascii", "replace") == "?"
    assert native_str(b"\xe9", "ascii", "xmlcharrefreplace") == "&#233;"
from tornado.concurrent import TracebackFuture  # noqa
from tornado.util import raise_exc_info  # noqa
from tornado.util import basestring_type  # noqa
from tornado.util import exec_in  # noqa
from tornado.util import errno_from_exception  # noqa
from tornado.util import import_object 

# Generated at 2022-06-24 08:22:12.604563
# Unit test for function json_decode
def test_json_decode():
    decoded_value = json_decode('{"key": "value"}')
    assert isinstance(decoded_value, dict)
    assert decoded_value == {'key': 'value'}


_JSON_DECODE_ERROR = (
    "JSONDecodeError is available in Python 3.5 and above. "
    "Please use the json_decode() method instead."
)



# Generated at 2022-06-24 08:22:23.419540
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'foo') == b'foo'
    assert url_unescape('foo') == 'foo'
    assert url_unescape(b'foo', encoding=None) == b'foo'
    assert url_unescape('foo', encoding=None) == b'foo'
    assert url_unescape(b'foo', encoding='utf-8') == 'foo'
    assert url_unescape('foo', encoding='utf-8') == 'foo'
    assert url_unescape('foo', encoding=None, plus=False) == b'foo'
    assert url_unescape(b'foo', encoding=None, plus=False) == b'foo'
    assert url_unescape('foo', encoding='utf-8', plus=False) == 'foo'

# Generated at 2022-06-24 08:22:33.236567
# Unit test for function linkify

# Generated at 2022-06-24 08:22:40.745466
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('value') == 'value'
    assert url_escape('') == ''
    assert url_escape('/') == '/'
    assert url_escape(' ') == '%20'
    assert url_escape('value?a=1') == 'value%3Fa%3D1'
    assert url_escape('value?a=1', plus=True) == 'value%3Fa%3D1'
    assert url_escape('value ') == 'value%20'



# Generated at 2022-06-24 08:22:50.022690
# Unit test for function xhtml_escape
def test_xhtml_escape():
    print(xhtml_escape("<foo>"))
test_xhtml_escape()



# Generated at 2022-06-24 08:22:53.210924
# Unit test for function json_encode
def test_json_encode():
    print("--- unit test for json_encode() ---")
    print(json_encode({'name':'Bob', 'age':20}))
test_json_encode()



# Generated at 2022-06-24 08:22:59.298778
# Unit test for function url_unescape
def test_url_unescape():
    #my_str = '%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82'
    my_str = 'hello'
    my_bytes = b'hello'

    #print(url_unescape(my_str, encoding='cp1251'))
    print(url_unescape(my_str))
    print(url_unescape(my_bytes))

#test_url_unescape()



# Generated at 2022-06-24 08:23:03.099008
# Unit test for function url_escape
def test_url_escape():
    # assume
    assert url_escape(value="abc def") == "abc+def"
    # assert
    assert url_escape(value="abc def", plus=False) == "abc%20def"
test_url_escape()
    


# Generated at 2022-06-24 08:23:12.937582
# Unit test for function linkify
def test_linkify():
    assert(
        linkify("Hello http://tornadoweb.org!") ==
        'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    )
    assert(
        linkify("Hello https://tornadoweb.org!") ==
        'Hello <a href="https://tornadoweb.org">https://tornadoweb.org</a>!'
    )
    assert(
        linkify("Hello www.tornadoweb.org") ==
        'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    )

# Generated at 2022-06-24 08:23:15.967903
# Unit test for function json_decode
def test_json_decode():
    try:
        json_decode('{"a":"b"}')
        json_decode(b'{"a":"b"}')
    except ValueError:
        return False
    return True

# Generated at 2022-06-24 08:23:25.987774
# Unit test for function linkify
def test_linkify():
    text = "Hey look, I found www.tornadoweb.org and http://www.google.com"
    epxect_result = 'Hey look, I found <a href="http://www.tornadoweb.org">www.tornadoweb.org</a> and <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify(text) == epxect_result
test_linkify()

# Use our native StringTypes type defined above in place of str.
# This is mostly useful for python 2/3 compatibility where the
# native str type is actually unicode.
StringTypes = native_str_type
ByteStringTypes = bytes  # type: Type[Union[bytes, bytearray]]



# Generated at 2022-06-24 08:23:34.998241
# Unit test for function json_encode
def test_json_encode():
    assert 'null' == json_encode(None)
    assert '1' == json_encode(1)
    assert '1.1' == json_encode(1.1)
    assert '"abc"' == json_encode("abc")
    assert '"abc\\nabc"' == json_encode("abc\nabc")
    assert 'true' == json_encode(True)
    assert 'false' == json_encode(False)
    assert '[]' == json_encode([])
    assert '[1]' == json_encode([1])
    assert '[1,2]' == json_encode([1, 2])
    assert '{"a":1}' == json_encode({'a':1})

# Generated at 2022-06-24 08:23:37.658195
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": 1}) == '{"a": 1}'
test_json_encode()



# Generated at 2022-06-24 08:23:46.379026
# Unit test for function linkify
def test_linkify():
    text = '这是一个测试'
    assert _URL_RE.sub(make_link, text) == None

RE_ATTR_NAME = re.compile(r'[_a-zA-Z][_a-zA-Z0-9-]*')
RE_ATTR_VALUE = re.compile(r'(?:[^\s"\']|"[^"]*"|\'[^\']*\')*')

# Generated at 2022-06-24 08:23:53.839801
# Unit test for function url_escape
def test_url_escape():
    # basic
    assert url_escape('url_escape') == 'url_escape'

    # nothing else changed
    characters = string.punctuation + string.digits
    for character in characters:
        assert url_escape(character) == character

    # keep reserved characters
    assert url_escape('!*\'();:@&=+$,/?#[]') == '!*\'();:@&=+$,/?#[]'

    # space should be encoded as %20
    assert url_escape(' ') == '%20'

    # plus should be encoded by default
    assert url_escape(' ') == '%20'

    # plus should NOT be encoded when plus=False
    assert url_escape(' ', plus=False) == '+'

    # plus should be encoded as %2B

# Generated at 2022-06-24 08:23:57.167298
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%20string") == "a string"



# Generated at 2022-06-24 08:24:00.314941
# Unit test for function utf8
def test_utf8():
    assert utf8("hello") == b"hello"
    assert utf8(b"hello") == b"hello"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:24:04.800499
# Unit test for function squeeze
def test_squeeze():
    test_str = "My name is Kate."
    expected_results = "My name is Kate."
    print('Expected Result: ', expected_results)
    actual_results = squeeze(test_str)
    print('Actual Result: ', actual_results)
    assert actual_results == expected_results

# Generated at 2022-06-24 08:24:11.301025
# Unit test for function url_unescape
def test_url_unescape():
    # Replace with the string that you want to test
    assert url_unescape(b"c++") == "c++"
    assert url_unescape("c++") == "c++"
    assert url_unescape("%2B") == "%2B"
    assert url_unescape("%2B", plus=False) == "+"
    assert url_unescape("%2B", encoding="utf-8", plus=False) == "+"



# Generated at 2022-06-24 08:24:16.755848
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<>"&\'') == '&lt;&gt;&quot;&amp;\''



# Generated at 2022-06-24 08:24:22.570688
# Unit test for function native_str
def test_native_str():
    from tornado import platform

    native_str(True)
    native_str(1)
    native_str(1.5)
    native_str(1.0)
    native_str(1j)
    native_str(b'abc')
    native_str(u'\u00E9')
    native_str(u'\ud802')
    native_str(u'\U0001F60A')
    native_str(u'\u00E9'.encode('utf-8'))
    native_str(u'\ud802'.encode('utf-8'))
    native_str(u'\U0001F60A'.encode('utf-8'))
    native_str(u'\u00E9'.encode('utf-32'))

# Generated at 2022-06-24 08:24:28.146864
# Unit test for function linkify
def test_linkify():
    text = '''Hello http://www.google.com!
    www.google.com
    http://google.com
    <a href="http://google.com">http://google.com</a>'''
    print(linkify(text))


# Generated at 2022-06-24 08:24:33.065538
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    import tornado.util
    d = {'a': ['a'], 'b': ['b']}
    s = tornado.util.url_concat(d)
    d2 = parse_qs_bytes(s)
    for k,v in d2.items():
        assert(k)
        assert(len(v) == 1)
        assert(v[0])



# Generated at 2022-06-24 08:24:35.972403
# Unit test for function url_escape
def test_url_escape():
    url = "i am a url"
    print(url_escape(url))
    url = url.encode()
    print(url_escape(url))
    print(url_escape(url,plus=False))

# Generated at 2022-06-24 08:24:42.203134
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert b'\'&;<>' == '\'"&;<>'.encode()
    assert b'\'&;<>"' == xhtml_escape('\'"&;<>').encode()
    assert b'&gt;' == '>'.encode()
    assert b'&gt;' == xhtml_escape('>').encode()
    assert b'&lt;' == '<'.encode()
    assert b'&lt;' == xhtml_escape('<').encode()
    assert b'&quot;' == '"'.encode()
    assert b'&quot;' == xhtml_escape('"').encode()
    assert b'&#39;' == "'".encode()
    assert b'&#39;' == xhtml_escape("'").encode()

# Generated at 2022-06-24 08:24:47.573906
# Unit test for function json_decode
def test_json_decode():
    assert(json_decode('{"key": "value"}') == {'key': 'value'})
    try:
        assert(json_decode(b'{"key": "value"}') == {'key': 'value'})
    except Exception as e:
        print("Bytes object is not supported. Decode bytes object to str first")
        print(e)


# Generated at 2022-06-24 08:24:57.142369
# Unit test for function json_decode
def test_json_decode():
    """
    Unit test for function json_decode
    """
    json_str = "{\"name\": \"hirofumi\"}"
    assert json_decode(json_str)["name"] == "hirofumi"
    json_str2 = "{\"me\": [{\"name\": \"hirofumi\"}, {\"name\": \"fumihiro\"}]}"
    assert json_decode(json_str2)["me"][0]["name"] == "hirofumi"
    assert json_decode(json_str2)["me"][1]["name"] == "fumihiro"


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:24:58.703250
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape('/static/favicon.ico?foo=32&bar=23')
    # assert url_unescape(1, 1, 1) == 3
    # assert url_unescape(5, 2) == 7



# Generated at 2022-06-24 08:25:09.114852
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert "&lt;div&gt;" == xhtml_escape("<div>")
    assert "&apos;&amp;&quot;&gt;&lt;" == xhtml_escape("'&\"><")


# Generated at 2022-06-24 08:25:16.626511
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    dict = {b"a1": [b"1"], b"a2": [b"2", b"3"], b"a3": [b"4", b"5", b"6"]}
    data = b"a1=1&a2=2&a2=3&a3=4&a3=5&a3=6"
    result = parse_qs_bytes(data)
    assert dict == result, 'test_parse_qs_bytes failed, please check the code'
test_parse_qs_bytes()



# Generated at 2022-06-24 08:25:21.305063
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'<':'</'}) == json.dumps({'<':'</'}).replace("</", "<\\/")


_JSON_DECODE_FUNC = json.JSONDecoder().decode
_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:25:24.760800
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  a  b  ') == 'a b'
    assert squeeze('\n\n a\tb \r\n') == 'a b'
    assert squeeze('\t \n\t\r  a\tb\t   ') == 'a b'



# Generated at 2022-06-24 08:25:32.399048
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert b'a=%c3%b1' == urllib.parse.urlencode({'a': '\xc3\xb1'}, True).encode('utf-8')
    assert b'a=%c3%b1' == urllib.parse.urlencode({'a': '\xc3\xb1'}, True).encode('utf-8')
    assert (b'a=%c3%b1') == parse_qs_bytes(b'a=\xc3\xb1')['a'][0]


# Generated at 2022-06-24 08:25:37.796918
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('') == ''
    assert squeeze('abc') == 'abc'
    assert squeeze('  a  bc  ') == 'a bc'


# Generated at 2022-06-24 08:25:39.932009
# Unit test for function json_decode
def test_json_decode():
    data = b'{"l":"l","m":"m"}'
    res = json_decode(data)
    print(res)


# Generated at 2022-06-24 08:25:49.784208
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&b=2') == {'a':[b'1'], 'b':[b'2']}
    assert parse_qs_bytes(b'a=1&b=2', keep_blank_values=True) == {'a':[b'1'], 'b':[b'2']}
    assert parse_qs_values(b'a=1&b=2', strict_parsing=True) == {'a':[b'1'], 'b':[b'2']}
    assert parse_qs_bytes(b'a=1&b=2', keep_blank_values=True, strict_parsing=True) == {'a':[b'1'], 'b':[b'2']}
    # Bad encoding, not latin1, should

# Generated at 2022-06-24 08:25:54.075675
# Unit test for function native_str
def test_native_str():
    assert (native_str('hello').__class__==str)
    assert (native_str(u'hello').__class__==unicode)
    assert (native_str(b'bytes')=='bytes')
    assert (native_str(u'unicode')=='unicode')


# Generated at 2022-06-24 08:26:02.342672
# Unit test for function native_str
def test_native_str():
    assert native_str(b"abc") == "abc"
    assert native_str(u"abc") == "abc"
    assert native_str(True) == "True"
    assert native_str(b"ascii", encoding="ascii") == "ascii"
    assert native_str(u"\u00e9", encoding="latin1") == "\\xe9"
    assert native_str(bytearray(b"\xe9"), encoding="latin1") == "\\xe9"
    # test for None, issue #627
    assert native_str(None) is None

_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:26:03.709306
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape('test+test')

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-24 08:26:04.581484
# Unit test for function json_encode
def test_json_encode():
    assert (json_encode('/') == '"\\/"')


# Generated at 2022-06-24 08:26:06.314143
# Unit test for function json_encode
def test_json_encode():
    print(json_encode({}))
    print(json_encode({'a':'b'}))
#test_json_encode()


# Generated at 2022-06-24 08:26:15.837565
# Unit test for function native_str
def test_native_str():
    assert native_str("hello") == "hello"
    assert native_str("hello", "utf-8") == "hello"
    assert native_str("\xe4\xb8\xad\xe6\x96\x87", "utf-8") == "\xe4\xb8\xad\xe6\x96\x87"
    assert native_str("\xe4\xb8\xad\xe6\x96\x87".encode("utf-8"), "utf-8") == "\xe4\xb8\xad\xe6\x96\x87"


# TODO: more robust regex, see also unicode_type
_BASESTRING_TYPES = (str, bytes)



# Generated at 2022-06-24 08:26:19.825483
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes(b"a=1&b=2")
    assert result["a"] == [b"1"]
    assert result["b"] == [b"2"]



# Generated at 2022-06-24 08:26:22.670120
# Unit test for function utf8
def test_utf8():
    str = "dummy"
    assert(utf8(str) == b"dummy")
    return
test_utf8()



# Generated at 2022-06-24 08:26:30.152390
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    parsed = parse_qs_bytes(b"a=1&b=2;c=3", keep_blank_values=True)
    assert parsed == {b"a": [b"1"], b"b": [b"2"], b"c": [b"3"]}

    parsed = parse_qs_bytes(b"a=1;b=2;a=3", keep_blank_values=True)
    assert parsed == {b"a": [b"1", b"3"], b"b": [b"2"]}

    parsed = parse_qs_bytes(b"a=1;a=", keep_blank_values=True)
    assert parsed == {b"a": [b"1", b""]}

    parsed = parse_qs_bytes(b"a=1;a=", keep_blank_values=False)

# Generated at 2022-06-24 08:26:35.958940
# Unit test for function xhtml_escape
def test_xhtml_escape():
    print('xhtml_escape("<html>") == %s' % repr(xhtml_escape("<html>")))

if __name__ == "__main__":
    test_xhtml_escape()


_XML_ESCAPE_RE = re.compile("[&<>\"']")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
}



# Generated at 2022-06-24 08:26:45.875936
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("1") == 1
    assert json_decode("true") == True
    assert json_decode("[]") == []
    assert json_decode('{"a":1}') == {"a":1}


# Get the Platform's HTML Parser (we're using Python's implementation)
try:
    # Python 3
    from html.parser import HTMLParser
except ImportError:
    # Python 2
    from HTMLParser import HTMLParser

try:
    from html import unescape as _unescape_html
except ImportError:
    # Python 2.6 or 2.7
    def _unescape_html(text: str) -> str:
        return HTMLParser().unescape(text)



# Generated at 2022-06-24 08:26:48.275504
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a":"b"}) == '{"a": "b"}'
test_json_encode()

_JSON_DECODE_OPTIONS = (
    json.JSONDecodeError.STRICT,
    json.JSONDecodeError.BACKSLASH_IN_STRING,
    json.JSONDecodeError.INVALID_UTF8,
)



# Generated at 2022-06-24 08:27:00.255503
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    def parse_qs_bytes(qs, keep_blank_values=False, strict_parsing=False):
        return urllib.parse.parse_qs(qs, keep_blank_values, strict_parsing, encoding="latin1")
    assert parse_qs_bytes('foo=bar&foo=quux') == {'foo': ['bar', 'quux']}
    assert parse_qs_bytes(b'foo=bar&foo=quux') == {'foo': ['bar', 'quux']}
    assert parse_qs_bytes('foo=') == {'foo': ['']}
    assert parse_qs_bytes(b'foo=') == {'foo': ['']}
    assert parse_qs_bytes('foo') == {}
    assert parse_qs_bytes(b'foo') == {}
    assert parse_qs

# Generated at 2022-06-24 08:27:08.038964
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes("a=1&b=2")
    assert result == {b"a": [b"1"], b"b": [b"2"]}
    result = parse_qs_bytes(b"a=1&b=2")
    assert result == {b"a": [b"1"], b"b": [b"2"]}
    result = parse_qs_bytes(b"a=1&b=2", True)
    assert result == {b"a": [b"1"], b"b": [b"2"]}
    result = parse_qs_bytes(b"a=1&b=2", strict_parsing=True)
    assert result == {b"a": [b"1"], b"b": [b"2"]}
test_parse_qs_bytes()


_

# Generated at 2022-06-24 08:27:10.084123
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    b1 = '{"type":"register","login":"anton","password":"topsecret"}'
    b2 = b1.encode('utf-8')
    print(b2)
    b3 = parse_qs_bytes(b2)
    print(b3)

# Generated at 2022-06-24 08:27:14.782017
# Unit test for function json_decode
def test_json_decode():
    test_json_str = '{"a":1}'
    test_json = json_decode(test_json_str)
    print(dict(test_json))

# test_json_decode()

_URL_ESCAPING_RE = re.compile(r"[^\w;,/?:@&=+$\-_.!~*'()%]")

# Used in the url_unescape method below

# Generated at 2022-06-24 08:27:18.669874
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(None) is None
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:27:21.578101
# Unit test for function utf8
def test_utf8():
    for s in r'abc\u1234':
        s = ord(s)
        print(s)


# Generated at 2022-06-24 08:27:24.342056
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('a    b') == 'a b'
    assert squeeze('\ta\t\tb\t\t \t') == 'a b'


# Generated at 2022-06-24 08:27:33.797114
# Unit test for function url_escape
def test_url_escape():
    value = "http://www.baidu.com/s?wd=&rsv_bp=0&tn=baidu&rsv_spt=3&oq=HTTP%25E4%25B8%258E%25E3%2580%258CHTTP&rsv_pq=c2aef230000115e3&rsv_t=8d2fRRLRvUA%2Bn1fwxn3Bqp3vEJj5Zf%2B8rAoA20vwy%2F%2BUxg8%2B39YHvh%2Fg&rqlang=cn&rsv_enter=1&rsv_sug3=1&rsv_sug2=0&inputT=436&rsv_sug4=436"
    url

# Generated at 2022-06-24 08:27:42.806473
# Unit test for function recursive_unicode
def test_recursive_unicode():
    if sys.version_info[0] == 3:
        codec = 'utf-8'
    else:
        codec = 'unicode_escape'
    to_unicode = codecs.getdecoder(codec)