

# Generated at 2022-06-24 08:17:36.610163
# Unit test for function utf8
def test_utf8():
    assert utf8(None) == None
    assert utf8('\xe4\xb8\xad\xe6\x96\x87'.encode('utf8')) == '\xe4\xb8\xad\xe6\x96\x87'
    assert utf8('\xe4\xb8\xad\xe6\x96\x87') == '\xe4\xb8\xad\xe6\x96\x87'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:17:42.070707
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{'key':'value'}") == {'key':'value'}

_recursive_repr = re.compile(r"^<(class|function).*>$")



# Generated at 2022-06-24 08:17:49.814652
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape(r"&a = &b"))
    print(xhtml_unescape(r"&a = &b&gt;"))
    print(xhtml_unescape(r"&a = &b&gt&"))
    print(xhtml_unescape(r"&a = &b&gt"))
    print(xhtml_unescape(r"&a = &b&go"))
    print(xhtml_unescape(r"&a = &b&g"))
    print(xhtml_unescape(r"&a = &b&"))
    print(xhtml_unescape(r"&a = &b"))
    print(xhtml_unescape(r"&a = &b&;&"))
    print(xhtml_unescape(r"&a = &b&;"))
   

# Generated at 2022-06-24 08:17:51.332446
# Unit test for function squeeze
def test_squeeze():
    print(squeeze('    abc def   ghi'))


# Generated at 2022-06-24 08:17:58.186871
# Unit test for function linkify
def test_linkify():
    # Add some tests here
    text = '''
    今天我要到南京东路去上班，请求带我去上班的同学与我联系。
    我的联系方式：http://www.baidu.com
    '''
    result = linkify(text)
    print(result, type(result))

test_linkify()

# the components of a link

# Generated at 2022-06-24 08:18:07.745367
# Unit test for function xhtml_escape
def test_xhtml_escape():
    if __name__ == '__main__':
        xhtml_escape("")


_JSON_ESCAPE_RE = re.compile(r'[\x00-\x1f\\"\b\f\n\r\t]')
_JSON_ESCAPE_DCT = {
    "\\": "\\\\",
    '"': '\\"',
    "\b": "\\b",
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "\t": "\\t",
}
for i in range(0x20):
    _JSON_ESCAPE_DCT.setdefault(chr(i), "\\u%04x" % (i,))

# Escape every ASCII character with a value less than 32.
_JSON_ESCAPE

# Generated at 2022-06-24 08:18:12.049563
# Unit test for function utf8
def test_utf8():
    assert utf8(1) == b'1'
    assert utf8(None) is None
    assert utf8('\xe9') == b'\xc3\xa9'
    assert utf8(u'\xe9') == b'\xc3\xa9'
    assert utf8(b'\xe9') == b'\xe9'
    assert utf8(True) == b'True'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:18:14.628681
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("       hello  world") == "hello world", "test squeeze() failed"
test_squeeze()



# Generated at 2022-06-24 08:18:25.183736
# Unit test for function utf8
def test_utf8():
    assert isinstance(utf8(""), bytes)
    assert isinstance(utf8("foo"), bytes)
    assert utf8("foo") == b"foo"
    assert isinstance(utf8(b""), bytes)
    assert isinstance(utf8(b"foo"), bytes)
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(b"foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(u"foo") == u"foo".encode("utf-8")
    assert utf8(u"\u2603") == b"\xe2\x98\x83"
    assert utf8(None) is None
    assert utf8(1)

# Generated at 2022-06-24 08:18:27.036783
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"slash": "</"}) == '{"slash": "<\\/"}'

# aliases
_hush_pyflakes = [json_encode]
del _hush_pyflakes


# to_unicode is deprecated.  Use native str instead of unicode on py3

# Generated at 2022-06-24 08:18:35.372103
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    test_str = "&copy;&#xA9;&#169;&lt;&gt;&amp;&quot;&#34;&#x22;&apos;&#39;&#x27;"
    assert xhtml_unescape(test_str) == "©©©<>&\"\"\"'''"
test_xhtml_unescape()



# Generated at 2022-06-24 08:18:37.303025
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;&gt;&amp;") == "<>&"



# Generated at 2022-06-24 08:18:44.203397
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("/a%20b") == "/a b"
    assert url_unescape("a+b") == "a b"
    assert url_unescape("a+b", plus=False) == "a+b"
    assert url_unescape("/a%20b".encode("utf-8")) == b"/a b"
    assert url_unescape("/a%20b".encode("utf-8"), plus=False) == b"/a%20b"



# Generated at 2022-06-24 08:18:46.171316
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze("  hello    world    ") == "hello world")

# Convert a string to a list of characters

# Generated at 2022-06-24 08:18:55.609586
# Unit test for function native_str
def test_native_str():
    from tornado.util import _U_STR_TYPE, _UNSUPPORTED_STR_TYPE, _U_STR_TYPE # noqa
    from tornado.util import unicode_type, basestring_type # noqa
    assert native_str() == ''
    assert native_str('1') == '1'
    assert native_str(b'1') == '1'
    assert native_str('1'.encode('utf-8')) == '1'
    assert native_str(1) == '1'
    assert native_str(None) == 'None'
    assert native_str(1, encoding='latin1') == '1'
    assert native_str(None, encoding='latin1') == 'None'
    assert native_str('1', encoding='latin1') == '1'
    assert native_str

# Generated at 2022-06-24 08:19:06.453774
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(1) == 1
    assert recursive_unicode("1") == "1"
    assert recursive_unicode({"a": 1, "b": "2"}) == {"a": 1, "b": "2"}
    assert recursive_unicode({"a": 1, "b": "2", "c": {"d": 3}}) == {"a": 1, "b": "2", "c": {"d": 3}}
    assert recursive_unicode(("1", "2")) == ("1", "2")
    assert recursive_unicode((1, "2")) == (1, "2")
test_recursive_unicode()

# From https://github.com/simplejson/simplejson/blob/master/simplejson/encoder.py
_PRETTY_DEFAULT = object()
_PRETTY

# Generated at 2022-06-24 08:19:12.072721
# Unit test for function squeeze
def test_squeeze():
    var1 = 'this is a  test'
    var2 = 'this is a test'
    if squeeze(var1) == var2:
        print('test passed')
    else:
        print('test failed')

test_squeeze()


# Generated at 2022-06-24 08:19:23.111201
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape(42) == "42"
    assert xhtml_escape(None) is None

_XML_ESCAPE_RE = re.compile("[&<>\"]")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
}



# Generated at 2022-06-24 08:19:27.723973
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"x":1}') == {"x":1}
    assert json_decode(b'{"x":1}') == {"x":1}
    assert json_decode("") == None



# Generated at 2022-06-24 08:19:34.389713
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
    print(linkify("www.tottus.com.pe"))
    print(linkify("www.tottus.com.pe", require_protocol=False))


test_linkify()

# if __name__ == "__main__":
#     # test_linkify()
#     r = parse_qs_bytes("q=aa&a=%3D%3D&q=bb&q=cc")
#     print(r)
#     print("")

# Generated at 2022-06-24 08:19:36.556512
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<div>&nbsp</div>') == '&lt;div&gt;&amp;nbsp&lt;/div&gt;'


# Generated at 2022-06-24 08:19:43.235917
# Unit test for function utf8
def test_utf8():
    assert isinstance(utf8(None), bytes)
    assert isinstance(utf8(b"abc"), bytes)
    assert isinstance(utf8("abc"), bytes)
    assert b"abc" == utf8(b"abc")
    assert b"abc" == utf8("abc")
    assert utf8(None) == None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:19:45.946469
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{'a':1}") == dict(a=1)
    assert json_decode("1") == 1
    assert json_decode("'a'") == "a"
    assert json_decode("[1,'a']") == [1, "a"]


# Use a __copy__ method if it exists, otherwise fall back to copy.copy

# Generated at 2022-06-24 08:19:55.192920
# Unit test for function native_str
def test_native_str():
    # type: () -> None
    assert native_str(b'1\xf4') == '1\xf4'
    assert native_str(u'1\xf4') == '1\xf4'
    assert native_str(1) == '1'
    assert native_str(None) == 'None'
    assert native_str(b'1\xf4', encoding='ascii') == '1\xf4'
    assert native_str(u'1\xf4', encoding='ascii') == '1\xf4'
    assert native_str(1, encoding='ascii') == '1'
    assert native_str(None, encoding='ascii') == 'None'
    assert isinstance(native_str(b'', encoding='ascii'), str)



# Generated at 2022-06-24 08:19:57.762765
# Unit test for function json_encode
def test_json_encode():
    # print(json_encode({"a":111}))
    pass



# Generated at 2022-06-24 08:20:08.013543
# Unit test for function native_str
def test_native_str():
    """
    Make sure that native_str() properly converts to native strings
    """
    str1 = 'test1'
    str2 = u'test2'
    str3 = b'test3'

    if str is unicode_type:
        assert str1 == native_str(str1)
        assert str1 == native_str(str2)
        assert str1 == native_str(str3)
    else:
        assert str2 == native_str(str1)
        assert str2 == native_str(str2)
        assert str2 == native_str(str3)

if str is bytes:
    native_str = to_unicode
else:
    native_str = utf8



# Generated at 2022-06-24 08:20:09.408559
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = '{"name":"lisi"}'
    ret = parse_qs_bytes(qs)
    assert isinstance(ret, dict)
    assert True
test_parse_qs_bytes()



# Generated at 2022-06-24 08:20:11.470844
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(u"<hello>") == u"&lt;hello&gt;"
    assert xhtml_escape(u"<hello>") == "&lt;hello&gt;"



# Generated at 2022-06-24 08:20:22.958872
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8("f\u00F6o") == b"f\xc3\xb6o"
    assert utf8("f\u00F6o".encode("latin1")) == b"f\xc3\xb6o"
    assert utf8(u"f\u00F6o") == b"f\xc3\xb6o"
    assert utf8("f\u00F6o".encode("utf8")) == b"f\xc3\xb6o"
    assert utf8("f\u00F6o".encode("utf16")) == b"f\xc3\xb6o"

# Generated at 2022-06-24 08:20:32.376288
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"e%2B8.5", encoding=None) == b"e+8.5"
    assert url_unescape(b"e%2B8.5%2Cf%2B9.5", plus=False) == "e%2B8.5%2Cf%2B9.5"
    assert url_unescape(b"e%2B8.5%2Cf%2B9.5%2Cg%2B10.5", encoding='utf-8') == "e+8.5,f+9.5,g+10.5"

# Generated at 2022-06-24 08:20:37.535611
# Unit test for function native_str
def test_native_str():
    assert native_str(b'abc') == 'abc'
    assert native_str(u'abc') == 'abc'
    assert native_str(None) is None
    try:
        native_str(1)
    except:
        pass
    else:
        assert False, "native_str should have raised exception"


_BASESTRING_TYPES = (unicode_type, bytes, type(None))



# Generated at 2022-06-24 08:20:45.071495
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    xhtml_unescape("&#x3C;&#60;&#x3e;")
    xhtml_unescape("&lt;&lt;&gt;")
    xhtml_unescape("&#38;&#x26;&amp;")
    xhtml_unescape("&#x3C;&#60;&#x3e;&#38;&#x26;&amp;")


_BASESTRING_TYPES = typing.Union[str, bytes]

# Generated at 2022-06-24 08:20:49.507925
# Unit test for function json_encode
def test_json_encode():
    attr = json_encode({
        'name': 'luo',
        'age': 18
        })
    print(attr)
test_json_encode()


# json_decode wraps json.loads and logs errors.  It also implicitly
# assumes that the input is UTF-8 encoded.

# Generated at 2022-06-24 08:20:58.990559
# Unit test for function native_str
def test_native_str():
    assert native_str(u"foo") == u"foo"
    assert native_str(u"foo".encode("utf-8")) == u"foo"
    assert native_str(b"foo") == u"foo"
    assert native_str(b"foo".decode("utf-8")) == u"foo"
    assert native_str(u"\u2603".encode("utf-8")) == u"\u2603"
    assert native_str(b"\xe2\x98\x83") == u"\u2603"
    if not PY2:
        # surrogateescape is only supported in py3
        assert native_str(b"\xff\xfd\x03") == u"\udcff\udcfd\x03"



# Generated at 2022-06-24 08:21:02.557253
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&copy;") == "©"

# Generated at 2022-06-24 08:21:10.486273
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("\x00\x01\x02\x0a\x0d\x20") == " "
    assert squeeze("\x00\x01\x02\x0a\x0d\x20\x20\x20") == " "
    assert squeeze("\x00\x01  \x02\x0a\x0d\x20\x20\x20") == " "
    assert squeeze("\x00\x01\x02\x0a\x0d\x20\x20\x20\x20\x20") == " "
    assert squeeze("\x00\x01\x02\x0a\x0d\x20\x20\x20\x20\x20\x20\x20") == " "
    assert squeeze("") == ""
test_squ

# Generated at 2022-06-24 08:21:13.230294
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "</bar>"}) == '{"foo": "<\\/bar>"}'
test_json_encode()



# Generated at 2022-06-24 08:21:23.398771
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'abc') == b'abc'
    assert url_unescape(u"\u03bc") == u"\u03bc"
    assert url_unescape(u"\u03bc", 'utf-8') == u"\u03bc"
    assert url_unescape(url_escape(u"\u03bc")) == u"\u03bc"
    assert url_unescape(url_escape(u"\u03bc").encode('ascii')) == u"\u03bc"
    assert url_unescape(url_escape(u"\u03bc"), 'ascii') == u"\u03bc"
    assert url_unescape(url_escape(u"\u03bc").encode('latin1')) == u"\u03bc"

# Generated at 2022-06-24 08:21:27.753977
# Unit test for function utf8
def test_utf8():
    assert utf8(u"foo") == b"foo"
    assert utf8(u"\u00A0") == u"\u00A0".encode("utf-8")
    assert utf8(b"foo") == b"foo"
    assert utf8(None) is None
    assert utf8(object()) == b"<object object at 0x%x>" % id(object())



# Generated at 2022-06-24 08:21:34.862965
# Unit test for function url_escape
def test_url_escape():
    from tornado.testing import AsyncTestCase
    from tornado.testing import gen_test

    class Test(AsyncTestCase):
        @gen_test(timeout=0.1)
        async def test(self):
            res = url_escape('http://www.baidu.com',True)
            assert 'http%3A%2F%2Fwww.baidu.com' in res

    test = Test()
    res = test.test()
    # print(res)


# Generated at 2022-06-24 08:21:44.003280
# Unit test for function utf8
def test_utf8():
    assert utf8("x") == b"x"
    assert utf8(b"x") == b"x"
    assert utf8(None) == None
    assert utf8(u"x") == b"x"
    assert utf8(u"\u00a3") == b"\xc2\xa3"
    try:
        utf8(object())
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:21:52.972820
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    expected = 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text) == expected


# TODO:  pypy doesn't have the ctypes module, so we can't run this test
# there.  should figure out another way to test this.
# if ctypes:
#     import ctypes
#     _c_test_linkify = ctypes.CDLL(os.path.join(
#         os.path.dirname(__file__), "libtest_linkify.so")).test_linkify
#     def test_linkify():
#         text = u"Hello http://tornadoweb.org!"
#         expected = u"Hello <a href=\"http://tornadoweb.org\">

# Generated at 2022-06-24 08:22:04.963384
# Unit test for function linkify

# Generated at 2022-06-24 08:22:15.294797
# Unit test for function url_unescape
def test_url_unescape():
    print(url_unescape("%C3%A9", encoding=None, plus=True))
    print(url_unescape("%C3%A9", encoding="utf-8", plus=True))
    print(url_unescape("%C3%A9", encoding="utf-8", plus=False))
    print(url_unescape("%C3%A9&gt;&lt;", encoding=None, plus=True))
    print(url_unescape("%C3%A9&gt;&lt;", encoding="utf-8", plus=True))
    print(url_unescape("%C3%A9&gt;&lt;", encoding="utf-8", plus=False))
    print(url_unescape("%C3%A9", encoding=None, plus=False))

# Generated at 2022-06-24 08:22:18.905028
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%2B') == b'+'
    assert url_unescape('%2B', plus=False) == b'%2B'
    assert url_unescape('%2B', encoding=None) == '+'
    assert url_unescape('%2B', encoding=None, plus=False) == '%2B'
    assert url_unescape('%2B', encoding='ascii') == '+'
    assert url_unescape('%2B', encoding='ascii', plus=False) == '%2B'
    assert url_unescape('%%28%2B%29') == '%(+)'



# Generated at 2022-06-24 08:22:28.852901
# Unit test for function linkify

# Generated at 2022-06-24 08:22:35.236066
# Unit test for function utf8
def test_utf8():
    ascii_byte_value = utf8("abc")
    assert b"abc" == ascii_byte_value
    unicode_value = "áéíóúñ"
    utf8_byte_value = utf8(unicode_value)
    assert b"\xc3\xa1\xc3\xa9\xc3\xad\xc3\xb3\xc3\xba\xc3\xb1" == utf8_byte_value
    utf8_byte_value = utf8(b"\xc3\xa1\xc3\xa9\xc3\xad\xc3\xb3\xc3\xba\xc3\xb1")

# Generated at 2022-06-24 08:22:46.159124
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{}") == {}
    assert json_decode("[]") == []
    assert json_decode("[1,2]") == [1,2]
    assert json_decode("true")

    # unicode characters will be automatically converted to `str`
    assert json_decode("\"foo\"") == "foo"
    assert json_decode("\"foo\u00e9\"") == "fooé"

    # Test for both `str` and `bytes` inputs
    assert json_decode(b"\"foo\"") == "foo"
    assert json_decode(b"\"foo\u00e9\"") == "fooé"


_BASESTRING_TYPES = (str, bytes)

# Generated at 2022-06-24 08:22:50.566122
# Unit test for function squeeze
def test_squeeze():
    s = ' hello world '
    assert squeeze(s) == 'hello world'


# json_encode, json_decode, squeeze, and recursive_unicode were originally
# based on the similar functions in web.py.



# Generated at 2022-06-24 08:22:52.519502
# Unit test for function json_decode
def test_json_decode():
    print(json_decode('{"key":"value"}'))


# Generated at 2022-06-24 08:22:58.594487
# Unit test for function xhtml_escape
def test_xhtml_escape():
    """xhtml_escape - where the value of a parameter is escaped for inclusion in XML"""
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_escape('"') == "&quot;"
    assert xhtml_escape("'") == "&#39;"
    assert xhtml_escape(">") == "&gt;"


_URL_ESCAPE_RE = re.compile(r"[<>\r\n\"#%]| {2,}")

# Generated at 2022-06-24 08:23:07.952260
# Unit test for function url_unescape
def test_url_unescape():
    # type: () -> None
    assert(url_unescape(b"foo+bar").decode() == "foo bar")
    assert(url_unescape(b"foo+%2Bbar").decode() == "foo+bar")
    assert(url_unescape(b"foo+%2Bbar", plus=False).decode() == "foo bar")
    assert(url_unescape(b"foo+%2Bbar", encoding=None).decode() == "foo+%2Bbar")
    assert(url_unescape(b"foo+%2Bbar", encoding=None, plus=False).decode() == "foo+bar")
    assert(url_unescape(u"foo+bar") == u"foo bar")



# Generated at 2022-06-24 08:23:17.304189
# Unit test for function squeeze
def test_squeeze():
    assert "".join(squeeze("")) == "";
    assert "".join(squeeze(" ")) == " ";
    assert "".join(squeeze("   ")) == " ";
    assert "".join(squeeze("  a  b  ")) == " a b ";
    assert "".join(squeeze("  a\tb\n ")) == " a b ";
    assert "".join(squeeze("  a\x00b\x20 ")) == " a b ";



# Generated at 2022-06-24 08:23:27.043188
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([1, [2, 3, [4, 5]]]) == [1, [2, 3, [4, 5]]]
    assert recursive_unicode([1, [2, 3, [4, '5']]]) == [1, [2, 3, [4, '5']]]
    assert recursive_unicode({'a': 1, 'b': [2, 3, {'c': [4, '5']}]}) == {'a': 1, 'b': [2, 3, {'c': [4, '5']}]}
    assert recursive_unicode({'a': 1, 'b': [2, 3, {'c': [4, b'5']}]}) == {'a': 1, 'b': [2, 3, {'c': [4, '5']}]}


# Generated at 2022-06-24 08:23:35.047994
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape("\"<>'&") == "&quot;&lt;&gt;&#39;&amp;"



# Generated at 2022-06-24 08:23:41.492535
# Unit test for function json_decode
def test_json_decode():
    assert(json_decode('{"a": 1}')) == {'a': 1}
test_json_decode()


_JSON_DECODE_ERROR = (
    "JSONDecodeError was added in Python 3.5. "
    "tornado.escape.json_decode cannot obey this behavior because "
    "it is available on Python 2 as well. Use json.loads directly instead."
)



# Generated at 2022-06-24 08:23:50.760104
# Unit test for function native_str
def test_native_str():
    native_str(1)  # type: ignore
    native_str(None)
    native_str(1, 'utf-8')  # type: ignore
    native_str(None, 'utf-8')
    native_str(1, 'utf-8', 'strict')  # type: ignore
    native_str(None, 'utf-8', 'strict')
    # These should not type check
    try:
        native_str(1, 'utf-8', 'replace', 1)  # type: ignore
    except TypeError:
        pass
    try:
        native_str()  # type: ignore
    except TypeError:
        pass



# Generated at 2022-06-24 08:23:57.193631
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    def to_utf8(s):
        if isinstance(s, str):
            return s.encode("utf-8")
        else:
            return s

    test1 = b"a=foo&b=bar&b=baz&b=quux&c="
    test1_utf8 = to_utf8(test1)
    answer1 = {b"a": [b"foo"], b"b": [b"bar", b"baz", b"quux"], b"c": [b""]}
    assert parse_qs_bytes(test1_utf8) == answer1
    assert parse_qs_bytes(test1) == answer1



# Generated at 2022-06-24 08:24:04.592824
# Unit test for function recursive_unicode
def test_recursive_unicode():
    s = b"hi"
    assert recursive_unicode(s) == "hi"

    l = [b"hi", "there"]
    assert recursive_unicode(l) == ["hi", "there"]

    d = {"a": b"hi", "b": "there"}
    assert recursive_unicode(d) == {"a": "hi", "b": "there"}

    t = (b"hi", "there")
    assert recursive_unicode(t) == ("hi", "there")

    assert recursive_unicode(1) == 1



# Generated at 2022-06-24 08:24:14.911290
# Unit test for function linkify
def test_linkify():
    assert linkify("http://yahoo.com") == "http://yahoo.com"
    assert linkify("http://yahoo.com/%20foo") == 'http://yahoo.com/%20foo'
    assert linkify("hello http://yahoo.com") == 'hello <a href="http://yahoo.com">http://yahoo.com</a>'
    assert linkify("hello http://yahoo.com/%20foo") == 'hello <a href="http://yahoo.com/%20foo">http://yahoo.com/%20foo</a>'
    assert linkify("hello http://yahoo.com/%20foo", require_protocol=False) == 'hello <a href="http://yahoo.com/%20foo">yahoo.com/%20foo</a>'

# Generated at 2022-06-24 08:24:20.117465
# Unit test for function native_str
def test_native_str():
    assert utf8(b'foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8(None) is None


# to_unicode was previously named _unicode not because it was private,
# but to avoid conflicts with the built-in unicode() function/type
_unicode = to_unicode



# Generated at 2022-06-24 08:24:25.361012
# Unit test for function json_decode
def test_json_decode():
    test_string = '{"test": "value"}'
    test_bytes = '{"test": "value"}'.encode('utf-8')
    assert json_decode(test_bytes) == json_decode(test_string)

_recoding_re = re.compile(rb"&#\d+;|&#x[0-9a-f]+;|&\w+;")



# Generated at 2022-06-24 08:24:34.872176
# Unit test for function native_str
def test_native_str():
    if sys.version_info >= (3, 0):
        assert native_str(b'foo') == 'foo'
        assert native_str('foo') == 'foo'
        assert native_str(None) == None
        assert native_str(b'\xe4\xb8\xad') == '中'
    else:
        assert native_str(b'foo') == 'foo'
        assert native_str('foo') == b'foo'
        assert native_str(None) == None
        assert native_str(u'\xe4\xb8\xad') == b'\xe4\xb8\xad'

_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-24 08:24:46.605027
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r'&amp;&lt;&gt;&quot;&#39;') == r'&<>"\''
    assert xhtml_unescape(r'&amp;&lt;&gt;&quot;&#39;&') == r'&<>"\'&'
    assert xhtml_unescape(r'Tab\tNewLine\nCarriageReturn\r') == 'Tab\tNewLine\nCarriageReturn\r'
    assert xhtml_unescape(r'&#9;&#10;&#13;') == 'Tab\tNewLine\nCarriageReturn\r'
    assert xhtml_unescape(r'&#x9;&#xa;&#xd;') == 'Tab\tNewLine\nCarriageReturn\r'
    assert xhtml_

# Generated at 2022-06-24 08:24:50.245737
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("x=1&y=2") == {
        b"x": [b"1"],
        b"y": [b"2"],
    }

# end of test_parse_qs_bytes



# Generated at 2022-06-24 08:24:54.789907
# Unit test for function utf8
def test_utf8():
    value = u'集团'
    print(type(value))
    print(type(utf8(value)))
    print(value)
    print(utf8(value))
test_utf8()

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:25:04.248713
# Unit test for function url_unescape
def test_url_unescape():
    test_url_unescape.last_value = url_unescape(b"foo\xffbar\x00baz\x1f", "utf-8", plus = False)

# a map of HTML/XML entity names to the Unicode characters they represent
_HTML_UNICODE_MAP = html.entities.entitydefs

# In Python 3, the HTMLParser module has been removed and the functionality
# moved to html.parser.  The minidom module uses HTMLParser to implement the
# .unescape method, but html.parser is stricter and doesn't support some of
# the character references we need to unescape.  So we roll our own using
# regexes.
_character_entity_re = re.compile(r"&(#?)(\d{1,5}|\w{1,8});")



# Generated at 2022-06-24 08:25:08.233820
# Unit test for function native_str
def test_native_str():
    assert native_str(b"foo") == "foo"
    assert native_str(u"foo") == "foo"
    assert native_str(1) == "1"



# Generated at 2022-06-24 08:25:18.458078
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(xhtml_escape('&=""><&')) == '&=""><&'
    assert xhtml_unescape(xhtml_escape('&amp;=&quot;&gt;&lt;&amp;')) == '&=""><&'
    assert xhtml_unescape(xhtml_escape('&#38;=&#34;&#62;&#60;&#38;')) == '&=""><&'
    assert xhtml_unescape(xhtml_escape('&#038;=&#034;&#062;&#060;&#038;')) == '&=""><&'


# to be compatible with tornado.escape.recursive_unicode

# Generated at 2022-06-24 08:25:25.544072
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&quot;") == '"'
    # 关键注意
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&quot;", True) == '"'
    assert xhtml_unescape("&#39;", True) == "'"
    assert xhtml_unescape("&#x27;", True) == "'"
    assert xhtml_unescape("&#27;", True) == "'"
test_xhtml_unescape()



# Generated at 2022-06-24 08:25:31.000987
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(value=None, encoding='utf8')


# When we write our own generators to return chunks of data,
# we often want to just write the chunk directly to the output
# without the overhead of wrapping it in a single-element list
# first.  This is a shortcut for that.
# It is a separate function to ensure it is independently optimized.

# Generated at 2022-06-24 08:25:44.688422
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # type: () -> None
    result = parse_qs_bytes(b"a=1&b=2&b=3")
    assert isinstance(result, dict)
    assert isinstance(list(result.keys())[0], str)
    assert isinstance(list(result.values())[0][0], bytes)


# Some dictionaries to use when parsing

# Generated at 2022-06-24 08:25:48.106697
# Unit test for function utf8
def test_utf8():
    assert utf8(u'abc') == b'abc'
    assert utf8(b'xyz') == b'xyz'
    assert utf8(None) is None
    try:
        utf8(object())
        assert False, "Failed to raise error when argument is not a string"
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:25:56.225109
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert not parse_qs_bytes(b"")
    assert parse_qs_bytes(b"foo=bar") == {"foo": [b"bar"]}
    assert parse_qs_bytes(b"foo=bar&foo=baz") == {"foo": [b"bar", b"baz"]}
    assert parse_qs_bytes(b"foo=1&foo=2") == {"foo": [b"1", b"2"]}
    assert parse_qs_bytes(b"foo=bar&baz=bing") == {"foo": [b"bar"], "baz": [b"bing"]}
    assert parse_qs_bytes(b"foo=bar&baz=bing", True) == {"foo": [b"bar"], "baz": [b"bing"]}

# Generated at 2022-06-24 08:25:58.318396
# Unit test for function squeeze
def test_squeeze():
    result = squeeze('  aa  bb   cc   ')
    assert result == 'aa bb cc', result



# Generated at 2022-06-24 08:26:03.034274
# Unit test for function native_str
def test_native_str():
    if sys.version_info[0] >= 3:
        assert native_str(b"ascii") == "ascii"
        assert native_str(b"ascii", "latin1") == "ascii"
    else:
        assert native_str(b"ascii") == b"ascii"
        assert native_str(b"ascii", "latin1") == u"ascii"



# Generated at 2022-06-24 08:26:05.383335
# Unit test for function url_escape
def test_url_escape():
    s = url_escape('test string')
    assert s == urllib.parse.quote_plus('test string')
    s = url_escape('test string', plus=False)
    assert s == urllib.parse.quote('test string')



# Generated at 2022-06-24 08:26:15.508682
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   hello   world   ") == "hello world"
    assert squeeze("   hello\n \n \t   world   ") == "hello world"


# When dealing with the standard library across python 2 and 3 it is
# sometimes useful to have a direct conversion between bytes and string
# objects, so we define forward and backwards compatibility methods
# for that here.  In python 2 these are no-ops, and in python 3 they
# call the utf8-encoding and decoding methods.
if unicode_type is str:
    def to_unicode(value: Union[str, bytes]) -> str:
        return value

    def to_basestring(value: Union[str, bytes]) -> str:
        return value



# Generated at 2022-06-24 08:26:24.110367
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('%s' % 'string') == 'string'
    assert url_escape('%s' % '1233') == '1233'
    assert url_escape('%s' % ' ') == '+'
    assert url_escape('%s' % 'string', False) == 'string'
    assert url_escape('%s' % 'string', True) == 'string'
    assert url_escape('%s' % ' ', True) == '+'
    assert url_escape('%s' % ' ', False) == '%20'



# Generated at 2022-06-24 08:26:30.070785
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(1) == '1'
    assert xhtml_escape('a<b') == 'a&lt;b'


# Generated at 2022-06-24 08:26:34.046093
# Unit test for function url_unescape
def test_url_unescape():
    assert(url_unescape('http%3A%2F%2Fwww.google.com%2Fa') == 'http://www.google.com/a')
    assert(url_unescape('http%3A%2F%2Fwww.google.com%2Fa', encoding=None) == b'http://www.google.com/a')
    assert(url_unescape('http%3A%2F%2Fwww.google.com%0a', encoding='utf-8') == 'http://www.google.com\n')
    assert(url_unescape('http%3A%2F%2Fwww.google.com%2Fa', encoding='utf-8', plus=False) == 'http://www.google.c%2Fa')

# Generated at 2022-06-24 08:26:35.698462
# Unit test for function json_decode
def test_json_decode():
  assert json_decode('"a"') == 'a'
  assert json_decode('"a"') != 'b'



# Generated at 2022-06-24 08:26:37.174511
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('test  Test') == 'test Test'



# Generated at 2022-06-24 08:26:45.840380
# Unit test for function utf8
def test_utf8():
    assert b"abc" == utf8("abc")
    assert utf8(None) is None
    assert b"\xe4\xbd\xa0" == utf8("\u4f60")
    assert b"\xe4\xbd\xa0" == utf8(u"\u4f60")
    raises(TypeError, utf8, 1)
    raises(TypeError, utf8, object())
    raises(TypeError, utf8, b"\xff")

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:26:57.648748
# Unit test for function linkify

# Generated at 2022-06-24 08:27:05.091282
# Unit test for function utf8
def test_utf8():
    assert utf8(u"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(b"foo") == b"foo"
    assert utf8(None) is None
    try:
        utf8(object())
        assert False
    except TypeError:
        pass
    try:
        utf8([])
        assert False
    except TypeError:
        pass
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-24 08:27:14.927400
# Unit test for function linkify
def test_linkify():
    assert linkify("") == ""
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/foo") == '<a href="http://www.google.com/foo">http://www.google.com/foo</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello www.google.com") == 'Hello <a href="http://www.google.com">www.google.com</a>'

# Generated at 2022-06-24 08:27:19.126865
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(1) == "1"
    assert json_encode({"key": "value"}) == '{"key": "value"}'

# The fact that json_decode wraps json.loads is an implementation detail.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-24 08:27:29.927969
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#9829;") == u"♥"
    assert xhtml_unescape("&#x2665;") == u"♥"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&apos;") == "'"
    assert xhtml_unescape("&#x27;") == "'"
test_xhtml_unescape()



# Generated at 2022-06-24 08:27:40.433273
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp; &#38;") == "& &"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&#x27;") == "'"

    assert xhtml_unescape("a&#1;b") == "ab"
    assert xhtml_unescape("a&#01;b") == "ab"
    assert xhtml_unescape("a&#0123456789;b") == "ab"
    assert xhtml_unescape("&#39;") == "'"