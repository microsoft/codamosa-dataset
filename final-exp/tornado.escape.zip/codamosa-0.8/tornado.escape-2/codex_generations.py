

# Generated at 2022-06-12 13:20:28.295875
# Unit test for function linkify
def test_linkify():
    # test base func
    text = "Hello http://tornadoweb.org!"
    expected = "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    ret = linkify(text, shorten=False, extra_params="", require_protocol=False, permitted_protocols=["http", "https"])
    assert text == ret, "ret = %s"%(ret)

# _BASIC_URL_RE originally from http://daringfireball.net/2010/07/improved_regex_for_matching_urls
#
# In python, \w is unicode-aware so we use \w instead of [a-zA-Z0-9]
#
# we also expand the set of valid TLD characters from the original
# regex, which only allowed letters

# Generated at 2022-06-12 13:20:34.531598
# Unit test for function linkify
def test_linkify():
    assert linkify('convert to link') == 'convert to link'
    assert linkify('http://example.com/') == '<a href="http://example.com/">http://example.com/</a>'
    assert linkify('http://example.com/abc') == '<a href="http://example.com/abc">http://example.com/abc</a>'
    assert linkify('http://example.com/abc/efg.htm') == '<a href="http://example.com/abc/efg.htm">http://example.com/abc/efg.htm</a>'



# Generated at 2022-06-12 13:20:41.175476
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello http://tornadoweb.org!", extra_params="rel='nofollow'") == "Hello <a href=\"http://tornadoweb.org\" rel='nofollow'>http://tornadoweb.org</a>!"
    assert linkify("Hello http://tornadoweb.org!", shorten=True, extra_params="rel='nofollow'") == "Hello <a href=\"http://tornadoweb.org\" rel='nofollow' title=\"http://tornadoweb.org\">http://tornadow...</a>"


# Generated at 2022-06-12 13:20:47.006825
# Unit test for function linkify
def test_linkify():
    COLOR_TEMPLATE = (
        """
    background-color: #f66;
    color: white;
    text-decoration: none;
    padding: 1px;
    """
    )
    def extra_style(url):
        return 'style="%s"' % COLOR_TEMPLATE
    url = 'https://www.instagram.com/accounts/login/?source=auth_switcher'
    assert linkify(url, extra_params=extra_style) != None 
    
    

# Generated at 2022-06-12 13:20:57.762475
# Unit test for function linkify
def test_linkify():
    assert linkify("") == ""
    assert linkify("Hello") == "Hello"
    assert linkify("Hello www.tornadoweb.org world") == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a> world'  # noqa: E501
    assert linkify("Hello http://tornadoweb.org world") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a> world'  # noqa: E501


# The charset used for the xml declaration of the templates
# (use instead of str(...) to ensure that the type is correct in both python 2
# and 3)
_UNICODE_TYPE = type(u"")



# Generated at 2022-06-12 13:21:05.694289
# Unit test for function linkify
def test_linkify():
    print("\nUnit test for function linkify():")
    urls = (
        "http://www.example.com/path/to/resource.xml?key=value&another=another_value",
        "http://user:password@hostname/path?key=value&key2=value2#anchor",
    )
    for url in urls:
        print(linkify(url))
    print(linkify("See http://en.wikipedia.org/wiki/Percent-encoding#Types_of_URI_characters"))
    
    

# Generated at 2022-06-12 13:21:06.785588
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    print(linkify(text))

test_linkify()


# Generated at 2022-06-12 13:21:12.428162
# Unit test for function linkify
def test_linkify():
    msg = 'Bye'
    assert linkify(msg) == msg

    msg = 'Hello http://tornadoweb.org'
    assert linkify(msg) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>'

    msg = 'Hello https://tornadoweb.org'
    assert linkify(msg) == 'Hello <a href="https://tornadoweb.org">https://tornadoweb.org</a>'

    msg = 'Hello www.tornadoweb.org'
    assert linkify(msg) == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'

    msg = 'Hello www.tornadoweb.org/feature'

# Generated at 2022-06-12 13:21:19.286197
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("Hello") == "Hello"
    assert (
        linkify("Visit http://tornadoweb.org/ for more details.")
        == 'Visit <a href="http://tornadoweb.org/">http://tornadoweb.org/</a> for more details.'
    )
    assert (
        linkify("hello http://example.com/?foo=bar&baz=quux")
        == 'hello <a href="http://example.com/?foo=bar&baz=quux">http://example.com/?foo=bar&baz=quux</a>'
    )

# Generated at 2022-06-12 13:21:21.431370
# Unit test for function linkify
def test_linkify():
    text = "It is a good website: https://www.baidu.com"
    print(linkify(text))
# test_linkify()

# test for function escape

# Generated at 2022-06-12 13:21:33.870713
# Unit test for function linkify
def test_linkify():
    cases = [
        ['Hello http://tornadoweb.org!', 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'],
        ['...and http://www.google.com?someparam=1', '...and <a href="http://www.google.com?someparam=1">http://www.google.com?someparam=1</a>']
    ]
    test = not all([linkify(case[0])==case[1] for case in cases])
    assert test == False, 'Unit test for function linkify failed.'


# Generated at 2022-06-12 13:21:41.696487
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == u''
    assert linkify(u'') == u''
    assert linkify(u'Hello') == u'Hello'
    assert linkify(u'http://woof') == u'<a href="http://woof">http://woof</a>'
    assert linkify(u'http://woof#bar') == u'<a href="http://woof#bar">http://woof#bar</a>'
    assert linkify(u'http://woof#bar') == u'<a href="http://woof#bar">http://woof#bar</a>'
    assert linkify(u'https://∂og.com') == u'<a href="https://∂og.com">https://∂og.com</a>'

# Generated at 2022-06-12 13:21:44.263998
# Unit test for function linkify
def test_linkify():
    assert linkify(u'Hello http://tornadoweb.org!')==u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    
test_linkify()



# Generated at 2022-06-12 13:21:53.961202
# Unit test for function linkify
def test_linkify():
    # Example from module docs
    output = linkify("Hello http://tornadoweb.org!")
    assert output == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    output = linkify("Hello http://facebook.com!")
    assert output == 'Hello <a href="http://facebook.com">http://facebook.com</a>!'
    # Not a protocol, no linkify
    output = linkify("Hello www.facebook.com!", require_protocol=True)
    assert output == "Hello www.facebook.com!"
    # Bad protocol, no linkify
    output = linkify("Hello javascript://something", permitted_protocols=["http"])
    assert output == 'Hello javascript://something'
    # Good protocol, linkify

# Generated at 2022-06-12 13:22:03.139862
# Unit test for function linkify
def test_linkify():
    text = "Hello world http://www.test.com.  Test something with no protocol test and something with a protocol mailto://someone@somewhere.com"
    x = linkify(text, shorten=True)
    assert x == 'Hello world <a href="http://www.test.com" title="http://www.test.com">www.test.com</a>.  Test something with no protocol test and something with a protocol <a href="mailto://someone@somewhere.com" title="mailto://someone@somewhere.com">mailto://someone@somewhere.com</a>'
    x = linkify(text, shorten=False)

# Generated at 2022-06-12 13:22:07.413131
# Unit test for function linkify
def test_linkify():
    import doctest
    from tornado.escape import linkify
    doctest.testmod(linkify)
import typing

from tornado.escape import json_decode
from tornado.options import define, options, parser
from tornado.platform.asyncio import AsyncIOMainLoop
from tornado.util import import_object
from tornado.web import Application, RequestHandler, StaticFileHandler



# Generated at 2022-06-12 13:22:11.546631
# Unit test for function linkify
def test_linkify():
    # Test that linkify converts a URL in plain text into a clickable link.
    assert linkify("http://www.google.com", shorten=False) == '<a href="http://www.google.com">http://www.google.com</a>'
    # Test that linkify works when given unicode characters in the URL.
    # (It should not raise an exception)
    assert "&#34;" not in linkify("http://foo.com/bar/baz?q=Tilburg&lang=nl")


# Generated at 2022-06-12 13:22:16.330506
# Unit test for function linkify
def test_linkify():
    text = linkify("www.torndado.org")
    print(text)
if __name__ == '__main__':
    test_linkify()

# Use our own linkify implementation in the chinese text
_URL_RE = re.compile(
    to_unicode(r"(http[s]?://(?:[\w./-]*))")
)



# Generated at 2022-06-12 13:22:25.425636
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify("Hello http://tornadoweb.org!  This is a test of linkify.", shorten=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!  This is a test of linkif...'
    assert linkify("www.facebook.com") == '<a href="http://www.facebook.com">www.facebook.com</a>'

# Generated at 2022-06-12 13:22:35.728540
# Unit test for function linkify
def test_linkify():
  # success functions
  assert linkify("Hello www.google.com!") == 'Hello <a href="http://www.google.com">www.google.com</a>!'
  assert linkify("Hello http://www.google.com!") == 'Hello <a href="http://www.google.com">http://www.google.com</a>!'

  # missing protocol
  assert linkify("Hello www.google.com!", require_protocol=True) == 'Hello www.google.com!'

  # bad protocol
  assert linkify("Hello javascript:alert(3)", permitted_protocols=["http"]) == 'Hello javascript:alert(3)'

  # extra_params

# Generated at 2022-06-12 13:22:46.672093
# Unit test for function linkify
def test_linkify():
    text = '''
    <a href="http://baidu.com">hello linkify</a>

    http://qq.com

    https://qq.com

    www.google.com

    https://www.google.com

    https://cn.bing.com

    www.qq.com

    www.baidu.com
    '''
    linkify(text)


# Generated at 2022-06-12 13:22:55.783431
# Unit test for function linkify
def test_linkify():
    if not linkify("http://google.com") == '<a href="http://google.com">http://google.com</a>':
        raise AssertionError()

# V8
# SELF_CLOSE_TAGS = ("br", "col", "img", "input")
#
#
# def escape(value):
#     """Converts the characters &, <, >, ' and " in string values to
#     their corresponding HTML entities.
#     """
#     return _escape_regex.sub(_convert_entity, to_basestring(value))
#
#
# def xhtml_escape(value):
#     """Escapes a string so it is valid within XML or XHTML.
#
#     This converts the characters &, <, >, ' and " to
#     &amp;amp;&amp;

# Generated at 2022-06-12 13:22:59.058333
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    result = linkify(text)
    expected = 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert result == expected

# Generated at 2022-06-12 13:23:08.316918
# Unit test for function linkify
def test_linkify():
    text = "Hello www.youtube.com world"
    text2 = "Hello youtube.com world"
    text3 = "Hello https://www.youtube.com world"
    normalize = lambda s: urllib.parse.unquote(s.replace('&amp;', '&'))
    assert normalize(linkify(text)) == 'Hello <a href="http://www.youtube.com">www.youtube.com</a> world'
    assert normalize(linkify(text2)) == 'Hello <a href="http://youtube.com">youtube.com</a> world'
    assert normalize(linkify(text3)) == 'Hello <a href="https://www.youtube.com">https://www.youtube.com</a> world'
    print('test_linkify ok')

test_linkify()


# Generated at 2022-06-12 13:23:17.093059
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com/search?hl=en&q=tornadoweb&btnG=Google+Search&aq=f&oq=")=="<a href=\"http://www.google.com/search?hl=en&amp;q=tornadoweb&amp;btnG=Google+Search&amp;aq=f&amp;oq=\">http://www.google.com/search?hl=en&amp;q=tornadoweb&amp;btnG=Google+Search&amp;aq=f&amp;oq=</a>"
    #assert linkify("www.google.com")=="<a href=\"http://www.google.com\">www.google.com</a>"
test_linkify()


# Generated at 2022-06-12 13:23:25.007290
# Unit test for function linkify
def test_linkify():
    text = (
        "Just a link http://example.com/ with some text "
        "a link to http://example.com/test.txt "
        "that is really really long..."
    )
    expected = (
        "Just a link <a href=\"http://example.com/\">http://example.com/</a> "
        "with some text a link to "
        "<a href=\"http://example.com/test.txt\">http://example.com/test.txt</a> "
        "that is really really long..."
    )
    actual = linkify(text)
    assert actual == expected



# Generated at 2022-06-12 13:23:34.392086
# Unit test for function linkify
def test_linkify():
    assert linkify(u"www.google.com") == u'<a href="http://www.google.com">www.google.com</a>'
    assert linkify(u"http://google.com") == u'<a href="http://google.com">http://google.com</a>'
    assert linkify(u"http://foo.com/bar/baz") == u'<a href="http://foo.com/bar/baz">http://foo.com/bar/baz</a>'
    assert linkify(u"http://foo.com/bar/baz.html") == u'<a href="http://foo.com/bar/baz.html">http://foo.com/bar/baz.html</a>'

# Generated at 2022-06-12 13:23:37.091446
# Unit test for function linkify
def test_linkify():
    s = linkify("Hello http://tornadoweb.org !")
    assert s == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a> !"



# Generated at 2022-06-12 13:23:39.063299
# Unit test for function linkify
def test_linkify():
    print(linkify('Hello www.facebook.com!'))
if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-12 13:23:47.859875
# Unit test for function linkify
def test_linkify():
    text = "test Tornado http://www.tornadoweb.org"
    links = linkify(text, permitted_protocols=['http'])
    print(f"text: {text}")
    print(f"links: {links}")
    print("-"*20)
    text = "test Tornado http://www.tornadoweb.org, https://www.python.org"
    links = linkify(text, permitted_protocols=['http', 'https'])
    print(f"text: {text}")
    print(f"links: {links}")
    print("-"*20)
    text = "test Tornado www.tornadoweb.org"
    links = linkify(text, require_protocol = False, permitted_protocols=['http', 'https'])

# Generated at 2022-06-12 13:24:01.096041
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    text2 = "Hello www.tornadoweb.org!"
    text3 = "Hello http://www.tornadoweb.org/test/test?test=test&test2=test2."
    text4 = "Hello http://www.tornadoweb.org/test/test?test=test&test2=test2"
    text5 = "Hello http://www.tornadoweb.org/test/test?test=test&test2=test2+is+a+test"
    text6 = "Tornado is a Python web framework and asynchronous networking library, originally developed at FriendFeed."
    text7 = "https://github.com/tornadoweb/tornado"


# Generated at 2022-06-12 13:24:10.036907
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == "<a href=\"http://www.google.com\">http://www.google.com</a>"
    assert linkify("Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify("Hello http://tornadoweb.org/! How are you?") == "Hello <a href=\"http://tornadoweb.org/\">http://tornadoweb.org/</a>! How are you?"
    assert linkify("Hello http://tornadoweb.org/!") == "Hello <a href=\"http://tornadoweb.org/\">http://tornadoweb.org/</a>!"
test_linkify()



# Generated at 2022-06-12 13:24:17.129013
# Unit test for function linkify
def test_linkify():
    global _URL_RE,make_link
    import re
    import unittest
    import tornado.web
    import tornado.escape

    class LinkifyTest(unittest.TestCase):
        def linkify_helper(self, text, extra_params=None, **kwargs):
            return tornado.escape.linkify(
                text, extra_params=extra_params, **kwargs)

        def test_linkify(self):
            self.assertEqual(
                self.linkify_helper("foo http://www.facebook.com/ bar"),
                'foo <a href="http://www.facebook.com/">http://www.facebook.com/</a> bar')

# Generated at 2022-06-12 13:24:22.449660
# Unit test for function linkify
def test_linkify():
    for source, target in (
        (None, None),
        ("", ""),
        ("http://www.facebook.com/tornadoweb", '<a href="http://www.facebook.com/tornadoweb">http://www.facebook.com/tornadoweb</a>'),
        ("no protocol", 'no protocol'),
        ("http: bad protocol", 'http: bad protocol'),
    ):
        yield check_linkify, source, target



# Generated at 2022-06-12 13:24:32.223663
# Unit test for function linkify

# Generated at 2022-06-12 13:24:38.068723
# Unit test for function linkify
def test_linkify():
    '''
    The function is tested with below example
    '''
    assert linkify('Google') == 'Google'
    assert linkify('https://stackoverflow.com') == '<a href="https://stackoverflow.com">https://stackoverflow.com</a>'
    assert linkify('https://stackoverflow.com', shorten=True) == '<a href="https://stackoverflow.com" title="https://stackoverflow.com">https://stack...</a>'

# Generated at 2022-06-12 13:24:49.112890
# Unit test for function linkify

# Generated at 2022-06-12 13:24:53.680964
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com/") == 'hello <a href="http://www.google.com/">http://www.google.com/</a>'

# Generated at 2022-06-12 13:24:56.455940
# Unit test for function linkify
def test_linkify():
    text = linkify("Welcome https://facebook.com")
    print(text)
    print(type(text))

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-12 13:25:05.581757
# Unit test for function linkify

# Generated at 2022-06-12 13:25:15.538330
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'


# Generated at 2022-06-12 13:25:20.219703
# Unit test for function linkify
def test_linkify():
    text = "Check out my pet monkey at http://www.example.com/ and http://www.foo.com"
    assert linkify(text)=='Check out my pet monkey at <a href="http://www.example.com/">www.example.com</a> and <a href="http://www.foo.com">www.foo.com</a>'


# Generated at 2022-06-12 13:25:28.240553
# Unit test for function linkify
def test_linkify():
    def assert_linkify(text, expected, **kwargs):
        eq = assert_equal
        if 'shorten' in kwargs:
            text += " x" * 100
        # print text
        # print linkify(text, **kwargs)
        eq(linkify(text, **kwargs), expected)

    # Simple
    yield assert_linkify, "Hello http://tornadoweb.org!", 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!',

    # With extra params

# Generated at 2022-06-12 13:25:34.938372
# Unit test for function linkify
def test_linkify():
    text = r'''Hello http://tornadoweb.org!
              This is the example.com homepage.
              You can also email me@example.com'''

    assert linkify(text) == r'''Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!
              This is the <a href="http://example.com">example.com</a> homepage.
              You can also email <a href="mailto:me@example.com">me@example.com</a>'''



# Generated at 2022-06-12 13:25:37.011486
# Unit test for function linkify
def test_linkify():
    linkify('test')
    linkify('test')
    linkify('test')
    linkify('test')
    linkify('test')

# Generated at 2022-06-12 13:25:42.358080
# Unit test for function linkify
def test_linkify():
    text = "http://www.example.com/foo &amp; bar"
    expected = '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    expected += ' &amp; '
    expected += '<a href="http://bar">http://bar</a>'
    real = linkify(text)
    assert expected == real



# Generated at 2022-06-12 13:25:51.080356
# Unit test for function linkify
def test_linkify():
    text = linkify("Hello http://tornadoweb.org!")
    assert text == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    text = linkify("Hello www.tornadoweb.org!")
    assert text == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!"
    text = linkify("Hello http://tornadoweb.org! &amp;", extra_params="")
    assert text == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>! &amp;"
    text = linkify("Hello www.tornadoweb.org! &amp;", extra_params="")

# Generated at 2022-06-12 13:26:00.413575
# Unit test for function linkify
def test_linkify():
    assert linkify('http://www.example.com') == \
        '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify('web+test@example.com') == \
        '<a href="http://web+test@example.com">web+test@example.com</a>'
    assert linkify('test@example.com') == \
        '<a href="http://test@example.com">test@example.com</a>'
    assert linkify('www.example.com') == \
        '<a href="http://www.example.com">www.example.com</a>'

# Generated at 2022-06-12 13:26:09.972633
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello www.google.com!") == "Hello <a href=\"http://www.google.com\">www.google.com</a>!"
    assert linkify("Hello http://www.google.com!") == "Hello <a href=\"http://www.google.com\">http://www.google.com</a>!"
    assert linkify("Hello http://www.google.com:8000!") == "Hello <a href=\"http://www.google.com:8000\">http://www.google.com:8000</a>!"

# Generated at 2022-06-12 13:26:18.295580
# Unit test for function linkify

# Generated at 2022-06-12 13:26:25.809892
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    result = linkify(text)
    print(result)

test_linkify()    


# Generated at 2022-06-12 13:26:36.247892
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("Hello World") == "Hello World"
    assert linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'  # noqa: E501
    assert linkify("Hello http://tornadoweb.org/!") == 'Hello <a href="http://tornadoweb.org/">http://tornadoweb.org/</a>!'  # noqa: E501

# Generated at 2022-06-12 13:26:43.343261
# Unit test for function linkify
def test_linkify():
    text = "this is http://www.baidu.com/s?wd=python+tornado"
    assert linkify(text) == 'this is <a href="http://www.baidu.com/s?wd=python+tornado">http://www.baidu.com/s?wd=python+tornado</a>'
    assert linkify("<a href='http://example.com'>http://example.com</a>") != '<a href=\'http://example.com\'>http://example.com</a>'
    # text = '<a href="http://example.com">http://example.com</a>'
    # print(linkify(text))

# Generated at 2022-06-12 13:26:52.315272
# Unit test for function linkify
def test_linkify():
    assert linkify("https://spark.apache.org/docs/2.2.0/api/python/pyspark.sql.html#pyspark.sql.SparkSession.builder")
    assert linkify("This is \r\nhttps://spark.apache.org")
    assert linkify("This is \nhttp://abc.com")
    assert linkify("This is \nhttps://abc.com")
    assert linkify("http://RDD.html")
    assert linkify("https://RDD.html")
    assert linkify("网址是https://www.baidu.com")
    assert linkify("网址是http://www.baidu.com")
    assert linkify("网址是https://www.baidu.com")
    assert not link

# Generated at 2022-06-12 13:27:01.155202
# Unit test for function linkify
def test_linkify():
    from .util import _unicode
    
    # check each kind of protocol for a valid URL
    def test(proto):
        url = proto + "://www.example.com/blah"
        assert linkify(url) == '<a href="%s">%s</a>' % (url, url)

    yield test("http")
    yield test("https")
    yield test("ftp")

    # check various invalid URLs are not linkified
    def test(url):
        assert linkify(url) == _unicode(url)

    yield test("http://")
    yield test("http://?")
    yield test("http://???")
    yield test("http://??/??")
    yield test("http://#")
    yield test("http://##")
    yield test("http://##/")
   

# Generated at 2022-06-12 13:27:06.643794
# Unit test for function linkify
def test_linkify():
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'
    assert linkify("hello www.example.com foo") == 'hello <a href="http://www.example.com">www.example.com</a> foo'


# Inline linkify function - Thanks, Armin!
# http://stackoverflow.com/questions/11974034/python-turn-urls-into-links-in-string


# Generated at 2022-06-12 13:27:11.439103
# Unit test for function linkify
def test_linkify():
    assert linkify(
        u"http://example.com/"
    ) == u'<a href="http://example.com/">http://example.com/</a>'
    assert linkify(
        u"example.com"
    ) == u'<a href="http://example.com">example.com</a>'



# Generated at 2022-06-12 13:27:17.899925
# Unit test for function linkify
def test_linkify():
    assert linkify('https://www.google.com/') == '<a href="https://www.google.com/">https://www.google.com/</a>'
test_linkify()

_EMAIL_RE = re.compile(r"([\w!#$%&'*+\-/=?^_`{|}~]+@[\w.-]+)")



# Generated at 2022-06-12 13:27:27.009023
# Unit test for function linkify
def test_linkify():
    assert linkify("http://foo.com") == (
        '<a href="http://foo.com">http://foo.com</a>'
    )
    assert linkify("x@y.com") == '<a href="mailto:x@y.com">x@y.com</a>'
    assert linkify("http://foo.com", require_protocol=True) == (
        '<a href="http://foo.com">http://foo.com</a>'
    )
    assert linkify("a@b.com", require_protocol=True) == "a@b.com"
    assert linkify("http://foo.com/") == (
        '<a href="http://foo.com/">http://foo.com/</a>'
    )
    assert linkify("foo.com")

# Generated at 2022-06-12 13:27:33.806289
# Unit test for function linkify
def test_linkify():
    print(linkify("www.facebook.com", shorten=True, permitted_protocols=["http", "https"]))
    print(linkify("http://www.baidu.com",shorten=True, permitted_protocols=["http", "https"]))
    print(linkify("http://www.baidu.com?flfjlej",shorten=True, permitted_protocols=["http", "https"]))
    print(linkify("http://www.baidu.com/",shorten=True, permitted_protocols=["http", "https"]))

# Generated at 2022-06-12 13:27:40.836217
# Unit test for function linkify
def test_linkify():
    text = " Hello http://tornadoweb.org! "
    lText = linkify(text, shorten=False, extra_params='rel="nofollow" class="external"')
    print(lText)


# Generated at 2022-06-12 13:27:43.191052
# Unit test for function linkify
def test_linkify():
    text = "I love you http://www.baidu.com/"
    print(linkify(text))


# Generated at 2022-06-12 13:27:45.520716
# Unit test for function linkify
def test_linkify():
    before = """
hello http://www.facebook.com
http://www.baidu.com
    """
    after = linkify(before)
    print(after)


# Generated at 2022-06-12 13:27:55.778752
# Unit test for function linkify
def test_linkify():
    assert linkify("google.com") == '<a href="http://google.com">google.com</a>'
    assert linkify("google.com", shorten=True) == '<a href="http://google.com">google.com</a>'
    assert linkify("http://google.com") == '<a href="http://google.com">http://google.com</a>'
    assert linkify("google.com/foo/bar") == '<a href="http://google.com/foo/bar">google.com/foo/bar</a>'
    assert linkify("google.com/foo") == '<a href="http://google.com/foo">google.com/foo</a>'

# Generated at 2022-06-12 13:28:07.747632
# Unit test for function linkify
def test_linkify():
    assert "&lt;&gt;&amp;&quot;&#39;&#33;&#42;&#43;&#45;&#46;&#47;&#58;&#59;" == xhtml_escape("<>&\"'!?*+-,./:;")
    assert "&lt;&gt;&amp;&quot;&#39;&#33;&#42;&#43;&#45;&#46;&#47;&#58;&#59;" == xhtml_escape(u"<>&\"'!?*+-,./:;")

# Generated at 2022-06-12 13:28:10.828810
# Unit test for function linkify
def test_linkify():
    from tornado.escape import native_str
    assert native_str(linkify("http://www.facebook.com")) == '<a href="http://www.facebook.com">http://www.facebook.com</a>'



# Generated at 2022-06-12 13:28:19.460867
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=tornado") == '<a href="http://www.google.com/search?q=tornado">http://www.google.com/search?q=tornado</a>'
    assert linkify("Here is a link: http://www.google.com") == 'Here is a link: <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://tornadoweb.org") == '<a href="http://tornadoweb.org">http://tornadoweb.org</a>'

# Generated at 2022-06-12 13:28:24.656871
# Unit test for function linkify
def test_linkify():
    text = linkify(
        "Hello http://tornadoweb.org!",
        extra_params='rel="nofollow" class="external"',
    )
    assert text == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!', text

    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'

    text = linkify(
        "Hello http://example.com and http://tornadoweb.org!",
        extra_params=extra_params_cb,
    )

# Generated at 2022-06-12 13:28:35.503885
# Unit test for function linkify
def test_linkify():
    #import re
    #_URL_RE = re.compile(
    #    to_unicode(
    #        r"""\b((?:([\w-]+):(/{1,3})|www[.])(?:(?:(?:[^\s&()]|&amp;|&quot;)*(?:[^!"#$%&'()*+,.:;<=>?@\[\]^`{|}~\s]))|(?:\((?:[^\s&()]|&amp;|&quot;)*\)))+)"""  # noqa: E501
    #    )
    #)
    extra_params = " "
    def make_link(m: typing.Match) -> str:
        url = m.group(1)
        proto = m.group(2)

# Generated at 2022-06-12 13:28:38.400255
# Unit test for function linkify
def test_linkify():
    text = "www.example.com"
    assert b'<a href="http://www.example.com">www.example.com</a>' in linkify(text)


# Generated at 2022-06-12 13:28:52.559331
# Unit test for function linkify
def test_linkify():
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("https://www.google.com") == '<a href="https://www.google.com">https://www.google.com</a>'
    assert linkify("http://www.google.com/test/test.html") == '<a href="http://www.google.com/test/test.html">http://www.google.com/test/test.html</a>' # noqa

# Generated at 2022-06-12 13:28:54.091491
# Unit test for function linkify
def test_linkify():
    s = "Hello http://tornadoweb.org!"
    print(linkify(s))

# Generated at 2022-06-12 13:28:59.105328
# Unit test for function linkify
def test_linkify():
    assert linkify(b"http://www.facebook.com") == '<a href="http://www.facebook.com">http://www.facebook.com</a>'
    assert linkify(u"http://www.facebook.com") == '<a href="http://www.facebook.com">http://www.facebook.com</a>'
test_linkify()



# Generated at 2022-06-12 13:29:03.593221
# Unit test for function linkify
def test_linkify():
    text = "Test google.com/calendar"
    print(linkify(text))
    text = "Test http://google.com"
    print(linkify(text))
    text = "Test http://www.google.com"
    print(linkify(text))
    text = "Test http://www.google.com/calendar"
    print(linkify(text))

# Generated at 2022-06-12 13:29:09.626646
# Unit test for function linkify

# Generated at 2022-06-12 13:29:16.770856
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'


# Mapping of URI schemas to regular expressions for matching URIs
# that use that scheme.

# Generated at 2022-06-12 13:29:25.052272
# Unit test for function linkify
def test_linkify():
    assert linkify("foo http://www.example.com bar") == \
           u'foo <a href="http://www.example.com">http://www.example.com</a> bar'
    assert linkify("http://www.example.com") == \
           u'<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("foo http://www.example.com/\u2713 bar") == \
           u'foo <a href="http://www.example.com/\u2713">http://www.example.com/\u2713</a> bar'

# Generated at 2022-06-12 13:29:35.391540
# Unit test for function linkify

# Generated at 2022-06-12 13:29:42.203848
# Unit test for function linkify
def test_linkify():
    test_input = '''Hello https://tornadoweb.org!
    you can visit https://google.com
    or http://yahoo.com'''
    test_output = '''Hello <a href="https://tornadoweb.org">https://tornadoweb.org</a>!
    you can visit <a href="https://google.com">https://google.com</a>
    or <a href="http://yahoo.com">http://yahoo.com</a>'''
    assert test_output == linkify(test_input), 'test_linkify failed'



# Generated at 2022-06-12 13:29:44.091736
# Unit test for function linkify
def test_linkify():
    s = linkify("Hello http://tornadoweb.org!")
    print(s)
test_linkify()


# Generated at 2022-06-12 13:29:53.469372
# Unit test for function linkify
def test_linkify():
    print(linkify("I Love U. http://www.example.com"))
    print(linkify("https://example.com"))
    # print(linkify("www.example.com",require_protocol=False)) #looks failed

# test_linkify()

_HTML_TYPES = (
    bytes,
    type(None),
)



# Generated at 2022-06-12 13:30:03.931622
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify(" ") == " "
    assert linkify("hello") == "hello"
    assert linkify("hello www.google.com") == 'hello <a href="http://www.google.com">www.google.com</a>'
    assert linkify("hello www.google.com/foo/bar?a=b&allo=bonjour") == 'hello <a href="http://www.google.com/foo/bar?a=b&allo=bonjour">www.google.com/foo/bar?a=b&allo=bonjour</a>'

# Generated at 2022-06-12 13:30:08.371736
# Unit test for function linkify
def test_linkify():
    text1 = linkify("Hello http://tornadoweb.org !")
    text2 = linkify("Hello http://tornadoweb.org !", shorten=True, require_protocol=False)
    # print(text1)
    # print(text2)


# print(test_linkify())


# Generated at 2022-06-12 13:30:15.811028
# Unit test for function linkify