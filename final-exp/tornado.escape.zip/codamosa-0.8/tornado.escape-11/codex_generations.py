

# Generated at 2022-06-12 13:20:47.293364
# Unit test for function linkify
def test_linkify():
    text = "www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&rsv_idx=2&tn=93380420_hao_pg&wd=tornado%E5%8C%B9%E9%85%8D%E9%9D%A2%E5%90%91%E8%A7%84%E5%88%99&fenlei=256&rsv_pq=c484271f00032fe8&rsv_t=bfe7HlNqezdz98ZNg%2Fh6zmF6nS%2BgU7MxU6QM1hhV4Zjjz9Kd%2BFaRlCQuwKw&rsv_enter=1"

# Generated at 2022-06-12 13:20:59.027276
# Unit test for function linkify
def test_linkify():
    text = linkify("Hello http://tornadoweb.org!")
    print('to_unicode:', text)
    assert text == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    # text = linkify('Hello (http://tornadoweb.org/). Goodbye.')
    # assert text == 'Hello (<a href="http://tornadoweb.org/">http://tornadoweb.org/</a>). Goodbye.'
    # text = linkify('Hello <http://tornadoweb.org/>. Goodbye.')
    # assert text == 'Hello &lt;<a href="http://tornadoweb.org/">http://tornadoweb.org/</a>&gt;. Goodbye.'
    # text = linkify('Hello www.tornadoweb.org. Goodbye.')


# Generated at 2022-06-12 13:21:00.976368
# Unit test for function linkify
def test_linkify():
    assert linkify("http://github.com") == '<a href="http://github.com">http://github.com</a>'

# Generated at 2022-06-12 13:21:09.800812
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"foo%20bar") == "foo bar"
    assert url_unescape(u"foo%20bar") == "foo bar"
    assert url_unescape(b"foo%20bar", encoding=None) == b"foo bar"
    assert url_unescape(u"foo%2Bbar") == "foo+bar"
    assert url_unescape(u"foo%2Bbar", plus=False) == "foo+bar"
    assert url_unescape(u"foo+bar") == "foo bar"
    assert url_unescape(u"foo+bar", plus=False) == u"foo+bar"



# Generated at 2022-06-12 13:21:16.649110
# Unit test for function linkify

# Generated at 2022-06-12 13:21:23.884165
# Unit test for function url_unescape
def test_url_unescape():
    # type: () -> None
    assert url_unescape(b'abc', encoding=None) == b'abc'
    assert url_unescape('%E4%B8%AD') == '中'
    assert url_unescape(b'%E4%B8%AD', encoding=None) == b'%E4%B8%AD'
    assert url_unescape('%E4%B8%AD', encoding=None) == b'%E4%B8%AD'
    assert url_unescape(b'abc', encoding='ascii') == 'abc'
    assert url_unescape(b'%E4%B8%AD', encoding='ascii') == '中'



# Generated at 2022-06-12 13:21:25.233250
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://www.test.com!"))



# Generated at 2022-06-12 13:21:32.632658
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == r'<a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://example.com!") == r'Hello <a href="http://example.com">http://example.com</a>!'
    assert linkify("Hello http://example.com:5000/foo/bar?a=b&c=d!") == r'Hello <a href="http://example.com:5000/foo/bar?a=b&c=d">http://example.com:5000/foo/bar?a=b&c=d</a>!'

# Generated at 2022-06-12 13:21:38.756766
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(b"foo")
    url_unescape(b"foo", encoding=None)
    url_unescape(b"foo", encoding="utf-8")
    url_unescape(b"foo", encoding="utf-8", plus=True) # noqa: F811
    url_unescape(u"foo")
    url_unescape(u"foo", encoding=None)
    url_unescape(u"foo", encoding="utf-8")
    url_unescape(u"foo", encoding="utf-8", plus=True) # noqa: F811



# Generated at 2022-06-12 13:21:44.046494
# Unit test for function linkify
def test_linkify():
    assert linkify(b'http://example.com') == '<a href="http://example.com">http://example.com</a>'
    assert linkify(b'no link') == 'no link'
    assert linkify(b'http://example.com/a&b') == '<a href="http://example.com/a&b">http://example.com/a&amp;b</a>'
    assert linkify(b'http://www.example.com') == '<a href="http://www.example.com">http://www.example.com</a>'



# Generated at 2022-06-12 13:21:59.363800
# Unit test for function linkify
def test_linkify():
    text = 'kjaadfjakdflja@google.com, www.google.com, http://google.com'
    print(linkify(text))


# Generated at 2022-06-12 13:22:08.179762
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    result = linkify(text)
    assert result == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

    text = "Hello https://www.google.com!"
    result = linkify(text)
    assert result == "Hello <a href=\"https://www.google.com\">https://www.google.com</a>!"

    text = "Hello www.google.com!"
    result = linkify(text)
    assert result == "Hello <a href=\"http://www.google.com\">www.google.com</a>!"

if __name__ == "__main__":
    test_linkify()
# Based on the _websafe_json codec from simplejson
# http://simplejson.readthedoc

# Generated at 2022-06-12 13:22:17.582920
# Unit test for function linkify
def test_linkify():
    text = """
       Hi\n
       This is a test of linkify
       http://www.google.com
       http://www.google.com/search?q=hello
       www.google.com
    """
    assert linkify(text) == """
       Hi\n
       This is a test of linkify
       <a href="http://www.google.com">http://www.google.com</a>
       <a href="http://www.google.com/search?q=hello">http://www.google.com/search?q=hello</a>
       <a href="http://www.google.com">www.google.com</a>
    """


# Generated at 2022-06-12 13:22:26.385007
# Unit test for function linkify
def test_linkify():
    assert linkify("http://foo.com") == """<a href="http://foo.com">http://foo.com</a>"""
    assert linkify("http://foo.com/") == """<a href="http://foo.com/">http://foo.com/</a>"""
    assert linkify("foo.com") == """<a href="http://foo.com">foo.com</a>"""
    assert linkify("foo.com/") == """<a href="http://foo.com/">foo.com/</a>"""
    assert linkify("foo.comfoo") == """foo.comfoo"""
    assert linkify("foo.com?bar") == """<a href="http://foo.com?bar">foo.com?bar</a>"""

# Generated at 2022-06-12 13:22:36.741675
# Unit test for function linkify
def test_linkify():
    assert(linkify('http://example_url.com/') == '<a href="http://example_url.com/">http://example_url.com/</a>')
    assert(linkify('http://example_url.com/hello_world.html') == '<a href="http://example_url.com/hello_world.html">http://example_url.com/hello_world.html</a>')
    assert(linkify('http://example_url.com/hello_world.html', shorten=True) == '<a href="http://example_url.com/hello_world.html">http://example_url.com/hello_wo...</a>')

# Generated at 2022-06-12 13:22:40.704122
# Unit test for function linkify
def test_linkify():
    test_text = "Hello http://tornadoweb.org!"
    expected = "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    
    a = linkify(test_text)
    assert a == expected
    pass

test_linkify()


# Generated at 2022-06-12 13:22:45.487892
# Unit test for function linkify
def test_linkify():
    #test linkify function
    assert(linkify("Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!")
    assert(linkify("Hello www.tornadoweb.org!") == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!")

test_linkify()



# Generated at 2022-06-12 13:22:54.549194
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'

    assert linkify('http://example.com/some/path') == '<a href="http://example.com/some/path">http://example.com/some/path</a>'

    assert linkify('hello http://example.com') == 'hello <a href="http://example.com">http://example.com</a>'

    assert linkify('http://example.com/some/path hello') == '<a href="http://example.com/some/path">http://example.com/some/path</a> hello'


# Generated at 2022-06-12 13:23:03.830475
# Unit test for function linkify
def test_linkify():
    import sys
    import os
    res = linkify(
        "Hello http://tornadoweb.org!",
        shorten=False,
        extra_params='rel="nofollow" class="external"',
        require_protocol=True,
        permitted_protocols=["http", "https"]
    )
    assert res == u'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'

    # this is Python 2 specific, which has been removed.
    f = open('/tmp/test.txt', 'w')
    f.write(res)
    f.close() 

# Generated at 2022-06-12 13:23:13.421493
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
    print(linkify("Hello http://tornadoweb.org!", shorten=False))
    print(linkify("Hello http://tornadoweb.org!", shorten=True))
    print(linkify("Hello http://tornadoweb.org!", shorten=True, extra_params='class="external"'))
    print(linkify("Hello http://tornadoweb.org!", shorten=True, extra_params='rel="nofollow" class="external"'))
    def extra_params_cb(url):
        print(url)
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'


# Generated at 2022-06-12 13:23:28.332699
# Unit test for function linkify
def test_linkify():
    assert linkify('Read my post on http://example.com/blog/post-1') == \
        'Read my post on <a href="http://example.com/blog/post-1">' + \
        'http://example.com/blog/post-1</a>'
    assert linkify('This is my link: www.facebook.com') == \
        'This is my link: www.facebook.com'
    assert linkify('This is my link: www.facebook.com',
                   require_protocol=True) == \
        'This is my link: <a href="http://www.facebook.com">' + \
        'www.facebook.com</a>'

# Generated at 2022-06-12 13:23:37.879338
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example") == '<a href="http://example">http://example</a>'
    assert linkify("http://example.com/test.html") == '<a href="http://example.com/test.html">http://example.com/test.html</a>'
    assert linkify("http://example.com/test.html?a=1&b=2") == \
        '<a href="http://example.com/test.html?a=1&amp;b=2">http://example.com/test.html?a=1&amp;b=2</a>'

# Generated at 2022-06-12 13:23:41.925857
# Unit test for function linkify

# Generated at 2022-06-12 13:23:44.493504
# Unit test for function linkify
def test_linkify():
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
test_linkify()
 

# Generated at 2022-06-12 13:23:54.013086
# Unit test for function linkify
def test_linkify():
    assert linkify("one") == "one"
    assert linkify("hello http://google.com/ there") == (
        "hello <a href=\"http://google.com/\">http://google.com/</a> there")
    assert linkify("http://google.com/?q=bar") == (
        "<a href=\"http://google.com/?q=bar\">http://google.com/?q=bar</a>")
    assert linkify("http://google.com/?q=bar") == (
        "<a href=\"http://google.com/?q=bar\">http://google.com/?q=bar</a>")
    assert linkify("http://google.com/?q=bar", shorten=True) == (
        "<a href=\"http://google.com/?q=bar\">http://google.com/?q=...</a>")

# Generated at 2022-06-12 13:24:03.467202
# Unit test for function linkify
def test_linkify():
    assert linkify('http://yuan.com'), '<a href="http://yuan.com">http://yuan.com</a>'
    assert linkify('www.yuan.com'), '<a href="http://www.yuan.com">www.yuan.com</a>'
    assert linkify('yuan.com'), '<a href="http://yuan.com">yuan.com</a>'
    assert linkify('yuan.com?a=1'), '<a href="http://yuan.com?a=1">yuan.com?a=1</a>'

# Generated at 2022-06-12 13:24:08.292098
# Unit test for function linkify
def test_linkify():
        import unittest
        class TestLinkify(unittest.TestCase):
                def test_linkify(self):
                        str = "Hello http://tornadoweb.org!"
                        ans = "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
                        self.assertEqual(linkify(str), ans)
        return unittest.main(verbosity=2)

# Generated at 2022-06-12 13:24:16.000411
# Unit test for function linkify
def test_linkify():
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('http://ru.wikipedia.org/wiki/URL') == '<a href="http://ru.wikipedia.org/wiki/URL">http://ru.wikipedia.org/wiki/URL</a>'
    assert linkify('Hello http://tornadoweb.org!',) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-12 13:24:25.010963
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org") == """hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>"""
    assert linkify("hello https://www.tornadoweb.org") == """hello <a href="https://www.tornadoweb.org">https://www.tornadoweb.org</a>"""
    assert linkify("hello ftp://www.tornadoweb.org") == """hello <a href="ftp://www.tornadoweb.org">ftp://www.tornadoweb.org</a>"""

# Generated at 2022-06-12 13:24:33.239138
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello http://tornadoweb.org/") == "Hello <a href=\"http://tornadoweb.org/\">http://tornadoweb.org/</a>"
    assert linkify("http://tornadoweb.org/ Hello") == "<a href=\"http://tornadoweb.org/\">http://tornadoweb.org/</a> Hello"
    assert linkify("http://tornadoweb.org/ Hello, http://tornadoweb.org/") == "<a href=\"http://tornadoweb.org/\">http://tornadoweb.org/</a> Hello, <a href=\"http://tornadoweb.org/\">http://tornadoweb.org/</a>"

# Generated at 2022-06-12 13:24:39.895761
# Unit test for function linkify
def test_linkify():
    s = 'Hello http://tornadoweb.org!'
    r = linkify(s)
    print(s, '==>', r)



# Generated at 2022-06-12 13:24:51.642079
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://example.com") == 'Hello <a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://example.com", extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://example.com" rel="nofollow" class="external">http://example.com</a>'
    assert linkify("http://example.com to be or http://example.com/not") == '<a href="http://example.com">http://example.com</a> to be or <a href="http://example.com/not">http://example.com/not</a>'

test_

# Generated at 2022-06-12 13:25:01.979715
# Unit test for function linkify

# Generated at 2022-06-12 13:25:03.238286
# Unit test for function linkify
def test_linkify():
    # linkify function is tested in tornado.test.util_test
    assert False

# Generated at 2022-06-12 13:25:13.566279
# Unit test for function linkify
def test_linkify():

    assert linkify(
        "www.facebook.com"
    ) == '<a href="http://www.facebook.com">www.facebook.com</a>'
    assert linkify(
        "http://40.media.tumblr.com/tumblr_m5vax0Dpf91r1t8iro1_r1_400.gif"
    ) == '<a href="http://40.media.tumblr.com/tumblr_m5vax0Dpf91r1t8iro1_r1_400.gif">' \
          'http://40.media.tumblr.com/tumblr_m5vax0Dpf91r1t8iro1_r1_400.gif</a>'

# Generated at 2022-06-12 13:25:22.172498
# Unit test for function linkify
def test_linkify():
    s = '<a href="http://tornadoweb.org/" rel="nofollow">http://tornadoweb.org/</a>'
    assert linkify("http://tornadoweb.org/", extra_params='rel="nofollow"') == s
    assert linkify("http://tornadoweb.org/", extra_params=lambda x: 'rel="nofollow"') == s


# These aliases used to be provided for backward compatibility,
# but are no longer in tornado.util.
escape = xhtml_escape
recursiveEscape = recursive_xhtml_escape
url_escape_with_plus = url_escape
url_unescape_with_plus = url_unescape



# Generated at 2022-06-12 13:25:29.493101
# Unit test for function linkify
def test_linkify():
    assert linkify(
        "http://somewhere.com/index.asp?param1=val1&param2=val2") == \
    '<a href="http://somewhere.com/index.asp?param1=val1&param2=val2">' \
    'http://somewhere.com/index.asp?param1=val1&param2=val2</a>'
    assert linkify(
        "www.somewhere.com/index.asp?param1=val1&param2=val2") == \
    '<a href="http://www.somewhere.com/index.asp?param1=val1&param2=val2">' \
    'www.somewhere.com/index.asp?param1=val1&param2=val2</a>'



# Generated at 2022-06-12 13:25:32.153170
# Unit test for function linkify
def test_linkify():
    assert (linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>')



# Generated at 2022-06-12 13:25:41.995488
# Unit test for function linkify
def test_linkify():
    assert linkify("hello www.example.com") == u'hello <a href="http://www.example.com">www.example.com</a>'
    assert linkify("example.com") == u'example.com'
    assert linkify("example.com:8080") == u'example.com:8080'
    assert linkify("http://example.com:8080") == u'<a href="http://example.com:8080">http://example.com:8080</a>'
    assert linkify("example.com:8080/path") == u'<a href="http://example.com:8080/path">example.com:8080/path</a>'
    assert linkify("(example.com:8080)") == u'(example.com:8080)'

# Generated at 2022-06-12 13:25:50.796381
# Unit test for function linkify
def test_linkify():
    assert linkify("http://foo.com") == '<a href="http://foo.com">http://foo.com</a>'
    assert linkify("foo.com") == '<a href="http://foo.com">foo.com</a>'
    assert linkify("foo.com", require_protocol=True) == 'foo.com'
    assert linkify("foo.com", permitted_protocols=["ftp"]) == 'foo.com'
    assert linkify("javascript:alert(0)") == 'javascript:alert(0)'
    assert linkify("foo.com", extra_params="class=\"bar\"") == '<a class="bar" href="http://foo.com">foo.com</a>'

# Generated at 2022-06-12 13:26:05.616398
# Unit test for function linkify
def test_linkify():
    # linkify(text, shorten=False)
    text = '<a href="http://example.com">http://example.com</a>'
    print('linkify(text, shorten=False)=',linkify(text, shorten=False))
    # linkify(text, shorten=True)
    print('linkify(text, shorten=True)=',linkify(text, shorten=True))
    # linkify(text, extra_params="class='external'")  
    print('linkify(text, extra_params="class=\'external\'")=',linkify(text, extra_params="class='external'"))
    # linkify(text, require_protocol = True)
    print('linkify(text, require_protocol = True)=',linkify(text, require_protocol = True))
    # linkify(text, permitted

# Generated at 2022-06-12 13:26:11.219455
# Unit test for function linkify
def test_linkify():
  _test_links=['http://www.github.com','http://www.google.com','ftp://ftp.someserver.com','www.facebook.com','www.twitter.com']
  _test_text=''
  for _link in _test_links:
    _test_text+=_link+' '
    print(_link,'-->',linkify(_link))
  print('\n',_test_text,'-->\n',linkify(_test_text))

# Generated at 2022-06-12 13:26:13.792486
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
    #OUTPUT: Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!



# Generated at 2022-06-12 13:26:21.604128
# Unit test for function linkify
def test_linkify():
    # basic cases
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/") == '<a href="http://example.com/foo/bar/">http://example.com/foo/bar/</a>'
    assert linkify("http://example.com/foo/bar/?baz") == '<a href="http://example.com/foo/bar/?baz">http://example.com/foo/bar/?ba...</a>'

# Generated at 2022-06-12 13:26:32.412960
# Unit test for function linkify
def test_linkify():
    text = '<p>This is a <a href="http://www.tornadoweb.org/en/stable/">link</a></p>'
    assert(linkify(text) == text)

    text = '<p>Try http://www.google.com/search?q=linkify, it should work.'
    right = '<p>Try <a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>, it should work.'
    assert(linkify(text) == right)

    text = '<p>http://www.google.com/search?q=linkify and http://www.tornadoweb.org/en/stable/</p>'

# Generated at 2022-06-12 13:26:38.130427
# Unit test for function linkify
def test_linkify():
    text = "Text www.tornadoweb.org, http://www.tornadoweb.org"
    text_linkified = linkify(text)
    assert (
        text_linkified == "Text <a href='http://www.tornadoweb.org'>www.tornadoweb.org</a>, <a href='http://www.tornadoweb.org'>http://www.tornadoweb.org</a>"
    )



# Generated at 2022-06-12 13:26:45.331396
# Unit test for function linkify

# Generated at 2022-06-12 13:26:51.222438
# Unit test for function linkify
def test_linkify():
    text = "this is http://google.com and www.baidu.com"
    print(linkify(text))
    text = "this is http://google.com, www.baidu.com and https://www.wikipedia.org"
    print(linkify(text))
    text = "this is http://google.com and www.baidu.com and https://www.wikipedia.org"
    print(linkify(text, shorten=True, permitted_protocols = ["https"]))

# Generated at 2022-06-12 13:26:52.481474
# Unit test for function linkify
def test_linkify():
    linkify("Hello http://tornadoweb.org!")




# Generated at 2022-06-12 13:27:01.279490
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello world http://example.com"))
    print(linkify("Hello world http://example.com", shorten=True))
    print(
        linkify(
            "Hello world http://example.com",
            extra_params='rel="nofollow" class="external"',
        )
    )

    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'

    print(linkify("Hello world http://example.com", extra_params=extra_params_cb))
    print(linkify("Hello world http://example.com", shorten=True, require_protocol=True))

# Generated at 2022-06-12 13:27:11.914973
# Unit test for function linkify
def test_linkify():
    text = "See http://example.com"
    assert linkify(text) == u'See <a href="http://example.com">http://example.com</a>'



# Generated at 2022-06-12 13:27:22.952122
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.facebook.com/") == '<a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify("http://www.facebook.com/", shorten=True) == '<a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify("www.facebook.com", require_protocol=False) == '<a href="http://www.facebook.com">www.facebook.com</a>'
    assert linkify("www.facebook.com", require_protocol=True) == 'www.facebook.com'

# Generated at 2022-06-12 13:27:30.939600
# Unit test for function linkify
def test_linkify():
    assert linkify("") == ""
    assert linkify("<http://www.google.co.uk>") == '<a href="http://www.google.co.uk">http://www.google.co.uk</a>'
    assert linkify("http://www.google.co.uk") == '<a href="http://www.google.co.uk">http://www.google.co.uk</a>'
    assert linkify("http://www.google.co.uk", require_protocol=False) == '<a href="http://www.google.co.uk">http://www.google.co.uk</a>'

# Generated at 2022-06-12 13:27:33.857483
# Unit test for function linkify
def test_linkify():
    import unittest
    import doctest
    from tornado.escape import linkify
    d = doctest.DocTestSuite(linkify)
    unittest.TextTestRunner().run(d)



# Generated at 2022-06-12 13:27:39.826165
# Unit test for function linkify
def test_linkify():
    print(linkify('Hello www.facebook.com!'))
    print(linkify('Hello http://tornadoweb.org!'))

test_linkify()

re_compile = re.compile

_XHTML_ESCAPE_RE = re_compile(r"([\"&'<>])")
_XHTML_ESCAPE_DICT = {"\"": "quot", "&": "amp", "'": "#39", "<": "lt", ">": "gt"}



# Generated at 2022-06-12 13:27:50.243844
# Unit test for function linkify
def test_linkify():
    # Test linkify
    assert linkify("http://www.tornadoweb.org/") == \
        '<a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>'
    assert linkify("http://www.tornadoweb.org", shorten=True) == \
        '<a href="http://www.tornadoweb.org" ' \
        'title="http://www.tornadoweb.org">http://www.tornadoweb...</a>'
    assert linkify("foo@example.com") == \
        '<a href="mailto:foo@example.com">foo@example.com</a>'

# Generated at 2022-06-12 13:27:59.550408
# Unit test for function linkify
def test_linkify():
    print(linkify('Hello http://tornadoweb.org!'))
    print(linkify('Hello http://tornadoweb.org!', shorten=True))
    print(linkify('Hello http://facebook.com!', shorten=True))
    print(linkify('Hello https://facebook.com!', shorten=True))
    print(linkify('Hello https://www.facebook.com!', shorten=True))
    print(linkify('Hello https://www.facebook.com/pages/Hell-yes/123442223334432?ref=ts', shorten=True))
    print(linkify('www.facebook.com/pages/Hell-yes/123442223334432?ref=ts', shorten=True, require_protocol=True))

# Generated at 2022-06-12 13:28:11.610150
# Unit test for function linkify
def test_linkify():
    test_str = "Hello http://tornadoweb.org!"
    test_result = linkify(test_str)
    print(test_result)
    assert test_result == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

    test_result = linkify(test_str, require_protocol=False)
    print(test_result)
    assert test_result == 'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>!'

    test_result = linkify(test_str, shorten=True)
    print(test_result)
    assert test_result == 'Hello <a href="http://tornadoweb.org" title="http://tornadoweb.org">tornadoweb.org</a>!'

    test_result = linkify

# Generated at 2022-06-12 13:28:19.567031
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(text, shorten=True) == "Hello <a href=\"http://tornadoweb.org\" title=\"http://tornadoweb.org\">http://tornad...</a>!"
    assert linkify(text, require_protocol=True) == "Hello http://tornadoweb.org!"
    assert linkify(text, require_protocol=True, permitted_protocols=["http","https"]) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"


# Generated at 2022-06-12 13:28:23.457946
# Unit test for function linkify
def test_linkify():
    assert linkify(b"http://www.facebook.com/l3vy http://google.com/l3vy") == u'<a href="http://www.facebook.com/l3vy">http://www.facebook.com/l3vy</a> <a href="http://google.com/l3vy">http://google.com/l3vy</a>'

# Generated at 2022-06-12 13:28:35.348641
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))
test_linkify()

_EMAIL_RE = re.compile(
    r"""
    \b
    [a-z0-9._%+-]+       # username
    @
    [a-z0-9.-]+          # domain name
    \.
    [a-z]{2,4}           # top-level domain (TLD)
    \b
""",
    re.VERBOSE | re.IGNORECASE,
)



# Generated at 2022-06-12 13:28:43.284377
# Unit test for function linkify
def test_linkify():
    assert linkify("http://google.com") == '<a href="http://google.com">http://google.com</a>'
    assert linkify("http://google.com will not be changed") == '<a href="http://google.com">http://google.com</a> will not be changed'
    assert linkify("http://google.com/path/?&=%2F") == '<a href="http://google.com/path/?&=%2F">http://google.com/path/?&=%2F</a>'

    assert linkify("ftp://ftp.google.com") == '<a href="ftp://ftp.google.com">ftp://ftp.google.com</a>'

# Generated at 2022-06-12 13:28:53.018401
# Unit test for function linkify
def test_linkify():
    assert linkify(
        u"http://example.com/") == u'<a href="http://example.com/">http://example.com/</a>'
    assert (linkify(u"http://example.com/", shorten=True)
            == u'<a href="http://example.com/" title="http://example.com/">http://example.com/</a>')
    assert (linkify(u"http://www.example.com/", shorten=True)
            == u'<a href="http://www.example.com/" title="http://www.example.com/">http://www.example.com/</a>')

# Generated at 2022-06-12 13:28:55.242408
# Unit test for function linkify
def test_linkify():
    print(linkify('Hello http://tornadoweb.org!'))
    print(linkify('Hello http://tornadoweb.org!', shorten=True))
    print(linkify('Hello http://tornadoweb.org!', require_protocol=True))
    print(linkify('Hello www.tornadoweb.org!', require_protocol=True))



# Generated at 2022-06-12 13:29:04.370388
# Unit test for function linkify
def test_linkify():
    s = "Hello http://tornadoweb.org!"
    assert linkify(s) == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

    # subdomain
    s = "Hello http://example.tornadoweb.org!"
    assert linkify(s) == u'Hello <a href="http://example.tornadoweb.org">http://example.tornadoweb.org</a>!'

    # path
    s = "Hello http://example.com/path/suffix"
    assert linkify(s) == u'Hello <a href="http://example.com/path/suffix">http://example.com/path/suffix</a>'

    # query param
    s = "Hello http://example.com/path?arg=value"

# Generated at 2022-06-12 13:29:10.374105
# Unit test for function linkify
def test_linkify():
    test = linkify("hello world http://www.baidu.com")
    assert test == "hello world <a href=\"http://www.baidu.com\">http://www.baidu.com</a>"
    text = "http://www.tornadoweb.org/"
    test = linkify(text, extra_params='rel="nofollow" class="external"')
    assert test == "<a href=\"http://www.tornadoweb.org/\" rel=\"nofollow\" class=\"external\">http://www.tornadoweb.org/</a>"
    test = linkify("hello www.baidu.com", require_protocol=True)
    assert test == "hello www.baidu.com"
    test = linkify("hello www.baidu.com", require_protocol=False)
    assert test

# Generated at 2022-06-12 13:29:17.345316
# Unit test for function linkify
def test_linkify():
    assert linkify("http://google.com")=='<a href="http://google.com">http://google.com</a>'
    assert linkify("http://google.com")==linkify("google.com")
    assert linkify("<p>http://google.com</p>")=='<p><a href="http://google.com">http://google.com</a></p>'
    assert linkify("<p>google.com</p>")==linkify("google.com")
    assert linkify("<p>google.com</p>")==u'<p><a href="http://google.com">google.com</a></p>'
test_linkify()

# From http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/52560

# Generated at 2022-06-12 13:29:24.496230
# Unit test for function linkify
def test_linkify():
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'  # noqa: E501
    assert linkify('http://test.com/test', extra_params='test') == '<a href="http://test.com/test" test>http://test.com/test</a>'  # noqa: E501
    assert linkify('http://test.com/test', extra_params='test', shorten=True) == '<a href="http://test.com/test" test>http://test.com/tes...</a>'  # noqa: E501



# Generated at 2022-06-12 13:29:34.827183
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/path/to/file.html") == \
           '<a href="http://example.com/path/to/file.html">http://example.com/path/to/file.html</a>'
    assert linkify("Hello http://example.com") == 'Hello <a href="http://example.com">http://example.com</a>'

# Generated at 2022-06-12 13:29:44.015825
# Unit test for function linkify
def test_linkify():
    print( linkify( "Hello http://tornadoweb.org!") )
    print( linkify( "Hello http://tornadoweb.org!", extra_params='rel="nofollow" class="external"')  )
    def extra_params_cb(url):
              if url.startswith("http://example.com"):
                  return 'class="internal"'
              else:
                  return 'class="external" rel="nofollow"'
    
    print( linkify( "Hello www.google.com/", extra_params=extra_params_cb))
    print( linkify( "Hello www.google.com/", require_protocol=True))
    print( linkify( "Hello www.google.com/", require_protocol=False))

# Generated at 2022-06-12 13:29:58.036810
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("example.com") == '<a href="http://example.com">example.com</a>'
    assert linkify("hello http://example.com") == 'hello <a href="http://example.com">http://example.com</a>'
    assert linkify("hello www.example.com") == 'hello <a href="http://www.example.com">www.example.com</a>'
    assert linkify("yeah http://foo.com/bar/baz bar") == 'yeah <a href="http://foo.com/bar/baz">http://foo.com/bar/baz</a> bar'

# Generated at 2022-06-12 13:30:08.687803
# Unit test for function linkify
def test_linkify():
    assert (
        linkify(
            "Check out www.facebook.com and http://www.tornadoweb.org/en/stable/",
            extra_params='rel="nofollow"',
        )
        == 'Check out <a href="http://www.facebook.com" rel="nofollow">www.facebook.com</a> and <a href="http://www.tornadoweb.org/en/stable/" rel="nofollow">http://www.tornadoweb.org/en/stable/</a>'  # noqa: E501
    )

# Generated at 2022-06-12 13:30:16.042527
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello http://tornadoweb.org!") == \
        "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify("WWW.tornadoweb.org") == \
        "<a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>"
    assert linkify("+http://tornadoweb.org") == \
        "<a href=\"http://tornadoweb.org\">+http://tornadoweb.org</a>"
    assert linkify("WWW.tornadoweb.org", require_protocol=True) == \
        "WWW.tornadoweb.org"