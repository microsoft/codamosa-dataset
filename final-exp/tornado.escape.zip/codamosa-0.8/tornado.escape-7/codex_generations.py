

# Generated at 2022-06-12 13:20:21.964886
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'http://foo.com/bar+baz').encode('utf8') == b'http://foo.com/bar+baz'  # noqa: E501
    assert url_unescape('http://foo.com/bar+baz') == 'http://foo.com/bar baz'  # noqa: E501



# Generated at 2022-06-12 13:20:28.587228
# Unit test for function linkify
def test_linkify():
    import re
    from tornado.escape import linkify
    assert linkify('http://foo.com') == '<a href="http://foo.com">http://foo.com</a>'
    m = re.search(r'href="(.*?)"', linkify('http://foo.com'))
    assert m.group(1) == 'http://foo.com'
    assert linkify('http://foo.com/baz') == '<a href="http://foo.com/baz">http://foo.com/baz</a>'
    assert linkify('www.foo.com') == '<a href="http://www.foo.com">www.foo.com</a>'

# Generated at 2022-06-12 13:20:37.484955
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("example.com") == '<a href="http://example.com">example.com</a>'
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'
    assert linkify("http://example.com example.com") == '<a href="http://example.com">http://example.com</a> <a href="http://example.com">example.com</a>'

# Generated at 2022-06-12 13:20:46.193270
# Unit test for function linkify
def test_linkify():
  assert linkify("http://www.baidu.com") == \
    u'<a href="http://www.baidu.com">http://www.baidu.com</a>'
  assert linkify("www.baidu.com") == \
    u'<a href="http://www.baidu.com">www.baidu.com</a>'
  assert linkify("<p>http://blah.com</p>") == \
    u'<p><a href="http://blah.com">http://blah.com</a></p>'

# Generated at 2022-06-12 13:20:52.255386
# Unit test for function linkify
def test_linkify():
    
    text = "Hello http://tornadoweb.org!"
    print("text:", text)
    assert linkify(text) == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    
    text = "Hello http://tornadoweb.org!"
    print("text:", text)
    assert linkify(text, shorten=True) == u'Hello <a href="http://tornadoweb.org" title="http://tornadoweb.org">http://tornadoweb.org</a>!'

    text = "Hello www.tornadoweb.org!"
    print("text:", text)
    assert linkify(text, require_protocol=True) == u'Hello www.tornadoweb.org!'

    text = "Hello www.tornadoweb.org!"
   

# Generated at 2022-06-12 13:20:54.524445
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("test", encoding=None)
    assert url_unescape("test", encoding="utf-8")



# Generated at 2022-06-12 13:21:05.397369
# Unit test for function linkify
def test_linkify():
    assert linkify(r"Hello http://www.tornadoweb.org!") == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>!'
    assert linkify(r"Hello http://www.tornadoweb.org/!") == 'Hello <a href="http://www.tornadoweb.org/">www.tornadoweb.org/</a>!'
    assert linkify(r"Hello http://www.tornadoweb.org:8080/!") == 'Hello <a href="http://www.tornadoweb.org:8080/">www.tornadoweb.org:8080/</a>!'

# Generated at 2022-06-12 13:21:09.500881
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))

test_linkify()

#_STRIP_HTML_RE = re.compile(r"</?[\w\s]*/?>")
_STRIP_HTML_RE = re.compile(r"<[^>]*>")


# Generated at 2022-06-12 13:21:16.920497
# Unit test for function linkify
def test_linkify():
    assert linkify(u"http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify(u"http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify(u"http://example.com:80/foo/bar?baz=1&inga=2&quux#frag") == '<a href="http://example.com:80/foo/bar?baz=1&inga=2&quux#frag">http://example.com:80/foo/bar?baz=1&inga=2&quux#frag</a>'

# Generated at 2022-06-12 13:21:22.750685
# Unit test for function linkify
def test_linkify():
    text = "Hello http://www.google.com/!"
    good = 'Hello <a href="http://www.google.com/">http://www.google.com/</a>!'
    assert linkify(text) == good

    text = 'Hello http://user:password@www.google.com/!'
    good = 'Hello <a href="http://user:password@www.google.com/">http://user:password@www.google.com/</a>!'
    assert linkify(text) == good

    text = 'Hello http://www.google.com/url?q=http://www.facebook.com/'

# Generated at 2022-06-12 13:21:34.249819
# Unit test for function linkify
def test_linkify():
  assert "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!" == linkify("Hello http://tornadoweb.org!")



# Generated at 2022-06-12 13:21:36.987938
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    result = linkify(text)
    assert result == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'



# Generated at 2022-06-12 13:21:44.150602
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello http://tornadoweb.org!") == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify("Hello ftp://tornadoweb.org/") == u'Hello <a href="ftp://tornadoweb.org/">ftp://tornadoweb.org/</a>'
    assert linkify("Hello http://tornadoweb.org:8000/foo") == u'Hello <a href="http://tornadoweb.org:8000/foo">http://tornadoweb.org:8000/foo</a>'
    assert linkify("Hello http://www.yahoo.com/my/path") == u'Hello <a href="http://www.yahoo.com/my/path">http://www.yahoo.com/my/path</a>'


# Generated at 2022-06-12 13:21:53.808340
# Unit test for function linkify
def test_linkify():
    assert linkify('http://example.com') == '<a href="http://example.com">http://example.com</a>'
    assert linkify('http://example.com/foo') == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify('www.example.com') == '<a href="http://www.example.com">www.example.com</a>'
    assert linkify('a@example.com') == '<a href="mailto:a@example.com">a@example.com</a>'
    assert linkify('b@example.com', 'mailto') == '<a href="mailto:b@example.com">b@example.com</a>'

# Generated at 2022-06-12 13:21:56.600802
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("abc") == 'abc'
    assert url_unescape("abc%26") == 'abc&'
    assert url_unescape("abc%26", plus=False) == 'abc%26'


# Generated at 2022-06-12 13:22:06.050226
# Unit test for function linkify
def test_linkify():
    # should not modify link
    text = u'<a href="http://example.com/">http://example.com/</a>'
    assert linkify(text) == text

    # should linkify http
    text = u'foo http://example.com bar'
    assert linkify(text) == u'foo <a href="http://example.com" title="http://example.com">http://example.com</a> bar'

    # should linkify parenthesis
    text = u'foo http://example.com/bar/baz/bax?arg1=1&arg2=2 bar'

# Generated at 2022-06-12 13:22:13.934133
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%3D1%26b%3D2", plus=True) == "a=1&b=2"
    assert url_unescape("a%3D1%26b%3D2", plus=False) == "a=1&b=2"
    assert url_unescape(b"a%3D1%26b%3D2", encoding=None, plus=True) == b"a=1&b=2"
    assert url_unescape(b"a%3D1%26b%3D2", encoding=None, plus=False) == b"a=1&b=2"
    assert url_unescape("a+%3D1%26b%3D2") == "a +%3D1&b=2"

# Generated at 2022-06-12 13:22:16.540967
# Unit test for function linkify
def test_linkify():
    ans = linkify("Hello http://tornadoweb.org!")
    assert ans == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
# ---


# Generated at 2022-06-12 13:22:18.476473
# Unit test for function linkify
def test_linkify():
    text=linkify("http://www.baidu.com")
    print(text)


# Generated at 2022-06-12 13:22:28.065302
# Unit test for function url_unescape

# Generated at 2022-06-12 13:22:36.353278
# Unit test for function linkify
def test_linkify():
    text = "http://127.0.0.1:5000"
    print(linkify(text))



# Generated at 2022-06-12 13:22:45.272028
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%D8%AA', encoding=None) == b'\xd8\xaa'
    assert url_unescape('%D8%AA', encoding='utf-8') == 'ت'
    assert url_unescape('%25D8%25AA') == '%D8%AA'
    assert url_unescape('%D8%AA', plus=False) == '%D8%AA'
    assert url_unescape('%D8 AA', encoding='utf-8') == '%D8 AA'
    assert url_unescape(b'%25D8 AA', encoding='utf-8') == '%25D8 AA'
    assert url_unescape(b'%25D8+AA', encoding='utf-8') == '%25D8 AA'

# Generated at 2022-06-12 13:22:51.295457
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.27o.cn") == '<a href="http://www.27o.cn">http://www.27o.cn</a>'
    assert linkify("https://www.27o.cn") == '<a href="https://www.27o.cn">https://www.27o.cn</a>'
    assert linkify("www.27o.cn") == '<a href="http://www.27o.cn">www.27o.cn</a>'
    assert linkify("www.27o.cn?a=1&b=2") == '<a href="http://www.27o.cn?a=1&b=2">www.27o.cn?a=1&b=2</a>'

# Generated at 2022-06-12 13:22:56.899630
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"abc", encoding=None, plus=True) == b"abc"
    assert url_unescape(b"hello%20world", encoding=None, plus=True) == b"hello world"
    assert url_unescape(b"%7Euser", encoding=None, plus=True) == b"~user"
    assert url_unescape(b"%7Euser", "utf-8", True) == "~user"



# Generated at 2022-06-12 13:23:06.431838
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("xxxa%2Bb%2Bc") == b"xxxa+b c"
    assert url_unescape("xxxa%2Bb%2Bc", None) == b"xxxa+b c"
    assert url_unescape("xxxa%2Bb%2Bc", "utf-8") == "xxxa+b c"
    assert url_unescape("xxxa%2Bb%2Bc", "utf-8", False) == "xxxa+b+c"
    assert url_unescape("xxxa%2Bb%2Bc", plus=False) == b"xxxa+b+c"
    assert url_unescape(b"xxxa%2Bb%2Bc", plus=False) == b"xxxa+b+c"
    assert url_unescape

# Generated at 2022-06-12 13:23:15.582979
# Unit test for function url_unescape
def test_url_unescape():
    f = lambda value, encoding=None, plus=True: (
        [
            url_unescape(value, encoding=encoding, plus=plus).__class__,
            url_unescape(value, encoding=encoding, plus=plus),
        ]
    )
    assert f("abc%26") == [bytes, b"abc&"]
    assert f("abc%26".encode("utf8")) == [bytes, b"abc&"]
    assert f("abc%26", encoding="utf8") == [str, "abc&"]
    assert f("abc+%26", encoding="utf8") == [str, "abc&"]
    assert f("") == [bytes, b""]


# Match HTML comments
_comment = re.compile(r"<!--(.*?)-->", re.DOTALL)



# Generated at 2022-06-12 13:23:19.180827
# Unit test for function url_unescape
def test_url_unescape():
    plus: bool = True
    encoding: Optional[str] = None
    value: Union[str, bytes] = '%255f'
    url_unescape(value, encoding=encoding, plus=plus)


# Generated at 2022-06-12 13:23:28.855623
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("Hello http://example.com") == "Hello <a href=\"http://example.com\">http://example.com</a>"
    assert linkify("http://example.com/") == "<a href=\"http://example.com/\">http://example.com/</a>"
    assert linkify("Hello http://example.com, and http://google.com!") == "Hello <a href=\"http://example.com\">http://example.com</a>, and <a href=\"http://google.com\">http://google.com</a>!"
    assert linkify("http://example.com/foo&bar") == "<a href=\"http://example.com/foo&amp;bar\">http://example.com/foo&amp;bar</a>"
    assert link

# Generated at 2022-06-12 13:23:38.328984
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'abcd')==b'abcd'
    assert url_unescape(b'abcd', encoding=None) == b'abcd'
    assert url_unescape(b'abcd', plus=False) == b'abcd'
    assert url_unescape(b'abcd', encoding=None, plus=False) == b'abcd'
    assert url_unescape(b'ab+cd')==b'ab cd'
    assert url_unescape(b'ab+cd', encoding=None)==b'ab cd'
    assert url_unescape(b'ab+cd', plus=False) == b'ab+cd'
    assert url_unescape(b'ab+cd', encoding=None, plus=False) == b'ab+cd'

# Generated at 2022-06-12 13:23:40.684726
# Unit test for function linkify
def test_linkify():
    base_url="https://tornado-zh.readthedocs.io/zh/latest/genindex.html"
    print(linkify(base_url))

# Generated at 2022-06-12 13:23:49.052575
# Unit test for function linkify
def test_linkify():
    import doctest
    doctest.testmod(linkify)

test_linkify()

# Generated at 2022-06-12 13:23:51.115722
# Unit test for function linkify
def test_linkify():
    assert linkify("http://foo.com") == u'<a href="http://foo.com">http://foo.com</a>'



# Generated at 2022-06-12 13:23:56.206290
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify("Hello www.tornadoweb.org!") == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!"



# Generated at 2022-06-12 13:24:03.336878
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert(linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!')
    text = "Hello http://tornadoweb.org! This is a link: www.yahoo.com"
    assert(linkify(text, require_protocol=False) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>! This is a link: <a href="http://www.yahoo.com">www.yahoo.com</a>')


# Generated at 2022-06-12 13:24:04.579611
# Unit test for function linkify
def test_linkify():
    print (linkify("Hello www.google.com!"))


# Generated at 2022-06-12 13:24:13.342102
# Unit test for function linkify
def test_linkify():
    """ Unit test for function linkify
    """
    # Test that linkify works correctly
    assert linkify("foo http://www.google.com bar") == \
        "foo <a href=\"http://www.google.com\">http://www.google.com</a> bar"

    # Test that linkify works correctly with ftps
    assert linkify("foo ftp://foo.bar baz") == \
        "foo <a href=\"ftp://foo.bar\">ftp://foo.bar</a> baz"

    # Test that linkify correctly accepts a custom set of permitted protocols
    assert linkify("foo git://foo.bar baz", permitted_protocols=["git"]) == \
        "foo <a href=\"git://foo.bar\">git://foo.bar</a> baz"

    # Test that linkify escapes %

# Generated at 2022-06-12 13:24:19.421361
# Unit test for function linkify
def test_linkify():
    text_1=linkify('www.baidu.com')
    assert text_1=="<a href=\"http://www.baidu.com\">www.baidu.com</a>"
    text_2=linkify('you@example.com')
    assert text_2=="you@example.com"
    text_3=linkify('https://baidu.com')
    assert text_3=="<a href=\"https://baidu.com\">https://baidu.com</a>"
    text_4=linkify('http://baidu.com')
    assert text_4=="<a href=\"http://baidu.com\">http://baidu.com</a>"
    text_5=linkify('http://baidu.com/a/b',shorten=True)
   

# Generated at 2022-06-12 13:24:29.281943
# Unit test for function linkify
def test_linkify():
    assert linkify(text="Hello http://www.baidu.com") == 'Hello <a href="http://www.baidu.com">http://www.baidu.com</a>'
    assert linkify(text="Hello http://www.baidu.com", shorten=True) == 'Hello <a href="http://www.baidu.com">http://www.baidu.com</a>'
    assert linkify(text="Hello http://www.baidu.com", shorten=True, require_protocol=True) == 'Hello <a href="http://www.baidu.com">http://www.baidu.com</a>'

# Generated at 2022-06-12 13:24:38.923000
# Unit test for function linkify

# Generated at 2022-06-12 13:24:50.099912
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'


# This dictionary says:
#     The key is a character.
#     The value for the key is the number of spaces the character
#     should be replaced with for plain text output.

# Generated at 2022-06-12 13:25:06.260509
# Unit test for function linkify
def test_linkify():
    data=[("www.sohu.com", '<a href="http://www.sohu.com">www.sohu.com</a>'),
          ("https://www.sohu.com", '<a href="https://www.sohu.com">https://www.sohu.com</a>'),
          ("http://www.sohu.com", '<a href="http://www.sohu.com">http://www.sohu.com</a>'),
          ("www.sohu.com", '<a href="http://www.sohu.com">www.sohu.com</a>'),
          ("www.sohu.com", '<a href="http://www.sohu.com">www.sohu.com</a>')
         ]

# Generated at 2022-06-12 13:25:18.006941
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == None
    assert linkify(1) == 1
    assert linkify('http://example.com/') == '<a href="http://example.com/">http://example.com/</a>'
    assert linkify('http://example.com/', shorten=True) == '<a href="http://example.com/" title="http://example.com/">http://example.com/</a>'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-12 13:25:20.908305
# Unit test for function linkify
def test_linkify():
    assert linkify("hello http://tornadoweb.org") == 'hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>'
test_linkify()
print('test_linkify() passed')


# Generated at 2022-06-12 13:25:28.731297
# Unit test for function linkify
def test_linkify():
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("foo@example.com") == '<a href="mailto:foo@example.com">foo@example.com</a>'
    assert linkify("<i>example.com</i>") == '&lt;i&gt;example.com&lt;/i&gt;'
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-12 13:25:38.579303
# Unit test for function linkify
def test_linkify():
    print("test_linkify()")
    assert(linkify("Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!")
    assert(linkify("Hello https://tornadoweb.org!") == "Hello <a href=\"https://tornadoweb.org\">https://tornadoweb.org</a>!")
    assert(linkify("Hello ftp://tornadoweb.org!") == "Hello <a href=\"ftp://tornadoweb.org\">ftp://tornadoweb.org</a>!")
    assert(linkify("Hello www.tornadoweb.org!") == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!")

# Generated at 2022-06-12 13:25:48.211214
# Unit test for function linkify

# Generated at 2022-06-12 13:25:55.047162
# Unit test for function linkify
def test_linkify():
    text = "testing http://www.facebook.com"
    answer = linkify(text=text)
    assert answer == 'testing <a href="http://www.facebook.com">http://www.facebook.com</a>'
    #linkify function

    text = "testing http://www.facebook.com and http://www.google.com"
    answer = linkify(text=text)
    assert answer == 'testing <a href="http://www.facebook.com">http://www.facebook.com</a> and <a href="http://www.google.com">http://www.google.com</a>'
    #linkify function

    text = "testing http://www.facebook.com and https://www.google.com"
    answer = linkify(text=text)

# Generated at 2022-06-12 13:26:02.016064
# Unit test for function linkify
def test_linkify():
    text = "see http://github.com/test. find www.google.com/search?q=www.google.com or test@google.com"
    expect = 'see <a href="http://github.com/test">http://github.com/test</a>. find <a href="http://www.google.com/search?q=www.google.com">www.google.com/search?q=www.google.com</a> or test@google.com'
    assert linkify(text) == expect

# Generated at 2022-06-12 13:26:04.423525
# Unit test for function linkify
def test_linkify():
    print(linkify(linkify("nihao",shorten =True)))
    print(linkify(linkify("nihao", shorten= True),extra_params="1111"))


# Generated at 2022-06-12 13:26:13.537291
# Unit test for function linkify
def test_linkify():
    def extra_params(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    text = '''
        <p>This is a very simple HTML document.</p>
        <p>It is not very interesting, but it is very short.
        <ul>
        <li>http://example.com/foo (internal)</li>
        <li>http://www.google.com/ (external)</li>
        <li>www.facebook.com (external url without protocol)</li>
        <li>Not a url: foo.com</li>
        </p>'''

# Generated at 2022-06-12 13:26:24.597780
# Unit test for function linkify
def test_linkify():
    assert linkify(b'abc') == u'abc'
    assert linkify(u'abc') == u'abc'
    assert linkify('example.com') == u'<a href="http://example.com">example.com</a>'
    assert linkify('go to www.example.com') == u'go to <a href="http://www.example.com">www.example.com</a>'
    assert linkify('example.com.') == u'<a href="http://example.com">example.com</a>.'
    assert linkify('(example.com)') == u'(<a href="http://example.com">example.com</a>)'
    assert linkify('example.com:8000') == u'<a href="http://example.com:8000">example.com:8000</a>'

# Generated at 2022-06-12 13:26:35.242194
# Unit test for function linkify
def test_linkify():
    text = "http://example.com http://www.example.com www.example.com mailto:me@example.com"
    assert linkify(text) == u'<a href="http://example.com">http://example.com</a> <a href="http://www.example.com">http://www.example.com</a> <a href="http://www.example.com">www.example.com</a> <a href="mailto:me@example.com">mailto:me@example.com</a>'
    text = "https://example.com ftp://example.com javascript://example.com"

# Generated at 2022-06-12 13:26:43.567413
# Unit test for function linkify
def test_linkify():
    test = "Hello http://tornadoweb.org!"
    result = linkify(test)
    assert result == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

# TODO: unit test for function squeeze
# TODO: unit test for function object_hook
# TODO: unit test for function json_encode
# TODO: unit test for function json_decode
# TODO: unit test for function parse_qs_bytes
# TODO: unit test for function utf8
# TODO: unit test for function to_unicode
# TODO: unit test for function recursive_unicode

# test = "Hello http://tornadoweb.org!"
# result = linkify(test)
# print(result)

# Generated at 2022-06-12 13:26:46.336249
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    extra_params = 'rel="nofollow" class="external"'
    expected = 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'
    assert linkify(text, extra_params=extra_params) == expected

# Generated at 2022-06-12 13:26:51.082094
# Unit test for function linkify
def test_linkify():
    assert linkify('') == ''
    assert linkify(u'hi') == u'hi'
    assert linkify(u'hi http://example.com') == u'hi <a href="http://example.com">http://example.com</a>'
    assert linkify(u'http://example.com') == u'<a href="http://example.com">http://example.com</a>'
    assert (linkify(u'http://example.com:8080/asdf?sdf=3&q=asdf#sdf') ==
            u'<a href="http://example.com:8080/asdf?sdf=3&q=asdf#sdf">http://example.com:8080/asdf?sdf=3&q=asdf#sdf</a>')
    assert linkify

# Generated at 2022-06-12 13:27:00.038717
# Unit test for function linkify
def test_linkify():
    assert r'<a href="http://example.com">http://example.com</a>' == linkify(
        "http://example.com"
    )
    assert (
        r'<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
        == linkify("http://example.com/foo&bar")
    )
    assert (
        r'<a href="http://example.com" rel="nofollow">http://example.com</a>'
        == linkify("http://example.com", extra_params='rel="nofollow"')
    )

# Generated at 2022-06-12 13:27:09.144979
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''

    assert linkify('abc') == 'abc'
    assert linkify('abc def') == 'abc def'

    assert linkify('http://example.com') == '<a href="http://example.com">http://example.com</a>'
    assert linkify('A http://example.com B') == 'A <a href="http://example.com">http://example.com</a> B'
    assert linkify('A http://example.com/path B') == 'A <a href="http://example.com/path">http://example.com/path</a> B'

# Generated at 2022-06-12 13:27:20.157473
# Unit test for function linkify

# Generated at 2022-06-12 13:27:25.790075
# Unit test for function linkify
def test_linkify():
    text = linkify("http://www.example.com, https://www.example.com")
    print(text)
# test_linkify()


_HTML_UNICODE_REPLACEMENTS = {
    ord("<"): "&lt;",
    ord(">"): "&gt;",
    ord('"'): "&quot;",
    ord("'"): "&#39;",
}



# Generated at 2022-06-12 13:27:27.803128
# Unit test for function linkify
def test_linkify():
    text = "Hello http://www.google.com"
    assert linkify(text) == "Hello <a href=\"http://www.google.com\">http://www.google.com</a>"

# Generated at 2022-06-12 13:27:42.483939
# Unit test for function linkify

# Generated at 2022-06-12 13:27:52.416972
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("Hi there http://example.com/foo") == 'Hi there <a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo, http://example.com/bar") == '<a href="http://example.com/foo">http://example.com/foo</a>, <a href="http://example.com/bar">http://example.com/bar</a>'
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'

# Generated at 2022-06-12 13:28:03.284079
# Unit test for function linkify
def test_linkify():
    assert r"""Just text""" == linkify(r"""Just text""")
    assert r"""Leave <b>HTML</b> alone""" == linkify(r"""Leave <b>HTML</b> alone""")
    assert r"""<b>&lt;&gt;&amp;&quot;&#39;</b>""" == linkify(r"""<b>&lt;&gt;&amp;"'</b>""")
    assert r"""Just text""" == linkify(r"""Just text""")
    assert '<a href="http://www.google.com">http://www.google.com</a>' == linkify('http://www.google.com')
    assert '<a href="http://www.google.com">http://www.google.com</a>' == linkify('www.google.com')

# Generated at 2022-06-12 13:28:13.691915
# Unit test for function linkify
def test_linkify():
    assert linkify('foo@example.com') == '<a href="mailto:foo@example.com">foo@example.com</a>'

    assert linkify('') == ''
    assert linkify('x') == 'x'
    assert linkify('x @y') == 'x @y'
    assert linkify('x y') == 'x y'
    assert linkify('x @y z') == 'x @y z'
    assert linkify('x y z') == 'x y z'

    assert linkify('@y') == '<a href="https://twitter.com/y">@y</a>'
    assert linkify('x @y') == 'x <a href="https://twitter.com/y">@y</a>'

# Generated at 2022-06-12 13:28:16.970857
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
test_linkify()

# TODO: MD5
# TODO: SHA1
# TODO: escape

# Generated at 2022-06-12 13:28:21.372274
# Unit test for function linkify
def test_linkify():
    # 2 tests
    # linkify with shorten = True
    text = "Hello www.google.ca"
    print(linkify(text, shorten = True)) # prints 'Hello <a href="http://www.google.ca">www.google.ca</a>' 
    # linkify with shorten = False
    print(linkify(text, shorten = False)) # prints 'Hello <a href="http://www.google.ca">http://www.google.ca</a>'



# Generated at 2022-06-12 13:28:31.875998
# Unit test for function linkify
def test_linkify():
    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'

    text = "Hello http://tornadoweb.org!"
    result = linkify(text)
    assert result == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

    text = "Hello http://tornadoweb.org! www.tornadoweb.org http://www.example.com/foo"
    result = linkify(text, extra_params="rel=\"nofollow\" class=\"external\"")

# Generated at 2022-06-12 13:28:36.752710
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org"))
    print(linkify("Hello http://tornadoweb.org", shorten=True))
    print(linkify("Hello www.tornadoweb.org!", shorten=True))
    print(linkify("Hello www.tornadoweb.org!", shorten=True, require_protocol=True))
test_linkify()


# Generated at 2022-06-12 13:28:41.221326
# Unit test for function linkify
def test_linkify():
    linkify("Hello http://tornadoweb.org!")
    linkify("Hello http://tornadoweb.org/!", shorten=True)
    linkify('Hello www.tornadoweb.org!' )
    linkify('Hello www.tornadoweb.org/!', shorten=True)
    linkify("Hello http://tornadoweb.org/!", extra_params='rel="nofollow" class="external"')


# Generated at 2022-06-12 13:28:50.739470
# Unit test for function linkify
def test_linkify():
    text = 'Hello www.tornadoweb.org!'
    text_linkified = linkify(text)
    assert_equal(text_linkified,
        'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>!')

    text_linkified = linkify(text, require_protocol=True)
    assert_equal(text_linkified, text)

    text2 = 'Hello mailto:someone@example.com!'
    text2_linkified = linkify(text2)
    assert_equal(text2_linkified,
        'Hello <a href="mailto:someone@example.com">mailto:someone@example.com</a>!')

    text2_linkified = linkify(text2, permitted_protocols=["mailto"])
    assert_

# Generated at 2022-06-12 13:29:04.370355
# Unit test for function linkify
def test_linkify():
    module_name = __name__
    assert linkify("test http://www.google.com", extra_params="extra") \
           == 'test <a href="http://www.google.com" extra>http://www.google.com</a>'
    assert linkify("test http://www.google.com", extra_params="") \
           == 'test <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("test http://www.google.com", extra_params=" ", require_protocol=False) \
           == 'test <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-12 13:29:06.784139
# Unit test for function linkify
def test_linkify():
    fragment = linkify("Hello http://www.google.com!")
    assert fragment == 'Hello <a href="http://www.google.com">http://www.google.com</a>!'
    assert callable(linkify("Hello http://www.google.com!", print))

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-12 13:29:12.529786
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify(u"foo") == u"foo"
    assert linkify(u"foo bar http://www.google.com baz") == \
           u'foo bar <a href="http://www.google.com">http://www.google.com</a> baz'
    assert linkify(u"foo http://www.google.com/search?q=tornadoweb&ie=utf-8&oe=utf-8 baz") == \
           u'foo <a href="http://www.google.com/search?q=tornadoweb&amp;ie=utf-8&amp;oe=utf-8">http://www.google.com/search?q=tornadoweb&amp;ie=utf-8&amp;oe=utf-8</a> baz'

# Generated at 2022-06-12 13:29:19.575583
# Unit test for function linkify
def test_linkify():
    assert linkify(
            None) == u''
    assert linkify(u'') == u''
    assert 'a href="http://google.com">google.com</a>' in linkify(
            u'google.com')
    assert 'a href="http://google.com">google.com</a>' in linkify(
            u'http://google.com')
    assert 'a href="http://google.com">http://google.com</a>' in linkify(
            u'http://google.com', shorten=True)
    assert (u'<a href="http://google.com">http://google.com</a> '
            u'<a href="http://google.com">google.com</a>') in linkify(
            u'http://google.com google.com')

# Generated at 2022-06-12 13:29:28.516918
# Unit test for function linkify
def test_linkify():
    assert linkify(b"http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("Hello http://example.com") == 'Hello <a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo.png") == '<a href="http://example.com/foo.png">http://example.com/foo.png</a>'
    assert linkify("http://example.com/foo.png", shorten=True) == '<a href="http://example.com/foo.png">http://example.com/foo....</a>'  # noqa

# Generated at 2022-06-12 13:29:39.188363
# Unit test for function linkify
def test_linkify():
    assert linkify(u'a http://www.example.com/ link') == u'a <a href="http://www.example.com/" rel="nofollow">http://www.example.com/</a> link'
    assert linkify(u'a https://www.example.com/ link') == u'a <a href="https://www.example.com/" rel="nofollow">https://www.example.com/</a> link'
    assert linkify(u'a ftp://www.example.com/ link') == u'a <a href="ftp://www.example.com/">ftp://www.example.com/</a> link'

# Generated at 2022-06-12 13:29:44.701724
# Unit test for function linkify
def test_linkify():
    def test_linkify(t, perm=None, require_protocol=None, extra=None, short=None):
        perm = perm or ["http", "https"]
        require_protocol = require_protocol or False
        short = short or False
        extra = extra or ""
        print(t)
        t = _unicode(t)
        print(linkify(
            t,
            permitted_protocols=perm,
            require_protocol=require_protocol,
            extra_params=extra,
            shorten=short
        ))
    test_linkify("http://www.facebook.com/")
    test_linkify("www.facebook.com/")
    test_linkify("www.example.com/page?name=something&id=3")

# Generated at 2022-06-12 13:29:47.066930
# Unit test for function linkify
def test_linkify():
    s = 'Hello http://tornadoweb.org!'
    linkified = linkify(s)
    assert linkified == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'



# Generated at 2022-06-12 13:29:52.820845
# Unit test for function linkify
def test_linkify():

    assert linkify('Simple test http://tornadoweb.org') == u'Simple test <a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    assert linkify('<em>Just</em> a http://test.com') == u'<em>Just</em> a <a href="http://test.com">http://test.com</a>'
    assert linkify('See http://example.com') == u'See <a href="http://example.com">http://example.com</a>'
    assert linkify('http://www.example.com/') == u'<a href="http://www.example.com/">http://www.example.com/</a>'

# Generated at 2022-06-12 13:30:03.215226
# Unit test for function linkify
def test_linkify():
    assert(linkify('www.google.com')=='<a href="http://www.google.com">www.google.com</a>')
    assert(linkify('https://www.google.com')=='<a href="https://www.google.com">https://www.google.com</a>')
    
test_linkify()    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-12 13:30:15.386244
# Unit test for function linkify
def test_linkify():
    print("testing linkify")
    a = linkify("Hello")
    print("linkify(Hello) = %s" % a)
    print("linkify(Hello + 1) = %s" % linkify("Hello + 1"))
    print("linkify(Google www.google.com) = %s" % linkify("Google www.google.com"))
    print("linkify(Google http://www.google.com) = %s" % linkify("Google http://www.google.com"))
    print("linkify(Google http://www.google.com?id=1) = %s" % linkify("Google http://www.google.com?id=1"))
    print("linkify(Google http://www.google.com/id/1) = %s" % linkify("Google http://www.google.com/id/1"))