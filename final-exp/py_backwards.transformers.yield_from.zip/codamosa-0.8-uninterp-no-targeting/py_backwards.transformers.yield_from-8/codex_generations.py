

# Generated at 2022-06-21 18:19:04.268467
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:19:10.224987
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...unittest import get_args
    from . import capture_args

    def test_func(node):
        with capture_args() as args:
            YieldFromTransformer().visit(node)

        return args.kwargs.get('node')

    get_args(test_func, node=ast.YieldFrom())

# Generated at 2022-06-21 18:19:11.326753
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:18.203146
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # prepare data
    tree = ast.parse("""
a = yield from b
yield from c
""", mode="exec")
    # prepare transformer
    transformer = YieldFromTransformer()
    # run test
    result = transformer.visit(tree)
    # assert

# Generated at 2022-06-21 18:19:18.933693
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:19:19.938012
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:28.373321
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = \
'''def foo():
    x = yield from bar()
    return x
'''
    expected = \
'''def foo():
    exc = None
    iterable = iter(bar())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                x = exc.value

            break

    return x
'''
    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    assert expected == astor.to_source(new_tree)

# Generated at 2022-06-21 18:19:29.793320
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:41.033139
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test(node: Node, expected: Node) -> None:
        res = YieldFromTransformer().visit(node)
        assert res == expected, dump_diff(res, expected)


# Generated at 2022-06-21 18:19:47.804577
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.context import build_ast
    from ..utils.helpers import compare_asts
    from ..utils.tree import print_tree
    import astunparse
    # with open('/home/alexey/tmp/yield_from.txt', 'r', encoding='utf-8') as fd:
    #     code = fd.read()
    # tree = compiler.ast.parse(code)

# Generated at 2022-06-21 18:20:04.579473
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .testutil import FuncNodeTransformer

    def transform(node: str, version: str) -> None:
        tree = ast.parse(node)
        transformer = YieldFromTransformer()
        tree = transformer.visit(tree)
        FuncNodeTransformer(version).visit(tree)

    yield_from = """
    async def foo():
        await bar()
        yield from baz()
    """
    yield_from_targ = """
    async def foo():
        await bar()
        x = yield from baz()
        y = [1, 2, 3]
    """
    yield_from_targ_mult_assign = """
    async def foo():
        await bar()
        x = y = yield from baz()
        y = [1, 2, 3]
    """
    yield

# Generated at 2022-06-21 18:20:05.559500
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import ast_util

# Generated at 2022-06-21 18:20:15.001248
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node1 = ast.parse("async def foo(bar):\n    a = yield from bar\n    return a\n")
    node2 = ast.parse("def foo(bar):\n    a = 2\n    b = yield from bar\n    b += 1\n    return b\n")
    node3 = ast.parse("def foo(bar):\n    a = 2\n    b = 5\n    c = yield from bar\n    c *= 2\n    return c\n")


# Generated at 2022-06-21 18:20:18.106456
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node_transformer = YieldFromTransformer()
    assert node_transformer is not None


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:20:24.232675
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(hasattr(YieldFromTransformer, '_get_yield_from_index'))
    assert(hasattr(YieldFromTransformer, '_emulate_yield_from'))
    assert(hasattr(YieldFromTransformer, '_handle_assignments'))
    assert(hasattr(YieldFromTransformer, '_handle_expressions'))
    assert(hasattr(YieldFromTransformer, 'visit'))

# Generated at 2022-06-21 18:20:30.321972
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transformers.future_builtins import FutureBuiltinsTransformer

    instance = YieldFromTransformer()
    sample_code = """
    def foo(a, b):
        c = yield from a
        d = yield from b
    """
    tree = ast.parse(sample_code)
    instance.visit(tree)
    tree = FutureBuiltinsTransformer().visit(tree)


# Generated at 2022-06-21 18:20:31.430554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-21 18:20:42.532393
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..testing import assert_transformed_code
    source = textwrap.dedent("""
        a = yield from (1, 2, 3)
        b = yield from [1, 2, 3]
        c = (yield from (1, 2, 3))
        d = [yield from (1, 2, 3)]
        e = yield from yield from 'hello'
    """)

# Generated at 2022-06-21 18:20:53.474634
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    string_input = textwrap.dedent("""
    def test_generator_yield_from():
        yf = yield
        while True:
            yf = yield from yf
        yf = yield from yf
    """)


# Generated at 2022-06-21 18:21:04.831899
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..common import Examples

    examples = Examples()
    examples.add_file('test', 'yield from_1.py')
    examples.add_file('test', 'yield from_2.py')
    examples.add_file('test', 'yield from_3.py')
    examples.add_file('test', 'yield from_4.py')
    examples.add_file('test', 'yield from_5.py')
    examples.add_file('test', 'yield from_6.py')
    examples.add_file('test', 'yield from_7.py')
    examples.add_file('test', 'yield from_8.py')
    examples.add_file('test', 'yield from_9.py')

# Generated at 2022-06-21 18:21:15.587395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:21:23.137539
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module_node = ast.parse('a = yield from gen')
    module_node_with_raise = ast.parse('try:\n'
                                       '    a = yield from gen\n'
                                       'except TypeError:\n'
                                       '    pass')
    function_node = ast.parse('def func():\n'
                              '    a = yield from gen')
    function_node_with_try = ast.parse('def func():\n'
                                       '    try:\n'
                                       '        a = yield from gen\n'
                                       '    except BaseException:\n'
                                       '        pass')

# Generated at 2022-06-21 18:21:34.649285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import astunparse
    from .yield_to_return import YieldToReturnTransformer
    from .function import FunctionTransformer
    from .annotate import AnnotationTransformer
    from .expression import ExpressionTransformer
    from .loop import LoopTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .misc import MiscTransformer
    from .if_else import IfElseTransformer
    from .try_except import TryExceptTransformer


# Generated at 2022-06-21 18:21:36.400937
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..ast_transformer import AstTransformer
    from ..utils.source import source


# Generated at 2022-06-21 18:21:43.628658
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import get_test_content
    from ..utils.tree_compare import compare_trees
    module_original, module_compiled = get_test_content('yieldfrom')
    module_original = ast.parse(module_original)
    module_compiled = ast.parse(module_compiled)

    transformer = YieldFromTransformer()
    transformer.visit(module_original)
    assert compare_trees(module_original, module_compiled)

# Generated at 2022-06-21 18:21:44.587362
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _x = YieldFromTransformer()

# Generated at 2022-06-21 18:21:49.377114
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import compare_with_native
    compare_with_native(YieldFromTransformer,
                        'def gen():\n    yield from range(3)\n',
                        'def gen():\n    let(iterable)\n    iterable = iter(range(3))\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            if hasattr(exc, \'value\'):\n                exc = exc.value\n            break\n',
                        ('3.2.3', '3.3.0'))


# Generated at 2022-06-21 18:21:50.772771
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    __tracebackhide__ = True


# Generated at 2022-06-21 18:21:52.180369
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(isinstance(YieldFromTransformer(), YieldFromTransformer))

# Generated at 2022-06-21 18:21:53.697907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base_tester import BaseTester

# Generated at 2022-06-21 18:22:24.910650
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """def func():
    yield from range(10)
    try:
        yield from range(10)
    except Exception as e:
        print(e)
    yield from range(10)
"""
    node = ast.parse(code)
    YieldFromTransformer.run(node)

# Generated at 2022-06-21 18:22:26.668755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception:
        assert False


# Generated at 2022-06-21 18:22:27.267436
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:22:30.759227
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from unittest import TestCase
    from .base import MockTree
    from .base import _make_suite as make_suite
    from ..utils.tree import dump_ast
    from ..unredactor import Unredactor

    class TestYieldFromTransformer(TestCase):
        def check(self, code: str, expected: str):
            tree = MockTree(code, __file__)
            transformer = YieldFromTransformer(tree)
            result = dump_ast(transformer.visit(tree.module))
            unredactor = Unredactor(result)
            result = unredactor.visit(unredactor.tree)
            self.assertEqual(result, expected)


# Generated at 2022-06-21 18:22:43.588049
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    from ..utils.source import source_to_code
    from typed_astunparse import unparse
    class Test(unittest.TestCase):
        def test_method_visit(self):
            def __init__(self):
                self._tree_changed = False

            def visit(self, node):
                node = self._handle_assignments(node)
                node = self._handle_expressions(node)
                return node

            def _get_yield_from_index(self, node, type_):
                if hasattr(node, 'body') and isinstance(node.body, list):
                    for n, child in enumerate(node.body):
                        if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                            return n

                return

# Generated at 2022-06-21 18:22:45.180660
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        assert False


# Generated at 2022-06-21 18:22:55.257774
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..parse import parse
    from .test_base_node_transformer import node_transformer_test
    from .test_base_node_transformer import DummyNodeTransformer

    test_code = """
    def test_function():
        a = yield from test_function2()
        yield from test_function3()
        return yield from test_function4()
    """


# Generated at 2022-06-21 18:23:02.154116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

    source = '''
try:
    a = yield from gen()
except Exception:
    pass

for a in yield from gen():
    pass

if a == 1:
    x = yield from gen()

while a:
    x = yield from gen()
'''

    tree = ast.parse(source)
    transformer.visit(tree)


# Generated at 2022-06-21 18:23:05.508918
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer(target_version=(3, 2))
    assert isinstance(yield_from_transformer, YieldFromTransformer)

# Generated at 2022-06-21 18:23:09.265813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        transformer = YieldFromTransformer()
        assert transformer is not None
    except Exception:
        print('FAILED: test_YieldFromTransformer')
        raise
    else:
        print('PASSED: test_YieldFromTransformer')


# Generated at 2022-06-21 18:23:53.244507
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:24:02.917280
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    @snippet
    def sample(a, b, c):
        try:
            yield from foo()
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                c = exc.value
        yield c

    code = sample.get_source()

    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)

    source = ast.fix_missing_locations(tree)
    code = compile(source, filename='<inline>', mode='exec')

    globals_ = {}
    locals_ = {'foo': lambda: range(1000)}
    exec(code, globals_, locals_)

    for i in locals_['sample'](1, 2, 3):
        assert i == 998

# Generated at 2022-06-21 18:24:09.619633
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.examples import yield_from_1, yield_from_2, yield_from_3, yield_from_4
    func = yield_from_1()
    assert func() == 42
    func = yield_from_2()
    assert func() == 42
    func = yield_from_3()
    assert list(func()) == [1, 2, 3]
    func = yield_from_4()
    assert list(func()) == [1, 2, 3]

# Generated at 2022-06-21 18:24:10.623671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None

# Generated at 2022-06-21 18:24:20.812191
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    input_ = 'def f():\n    x = yield from range(3)\n    return x'
    expected = 'def f():\n    exc = VariablesGenerator.generate("exc")\n    target = exc.value\n    iterable = None\n    iterable = iter(range(3))\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            if hasattr(exc, \'value\'):\n                target = exc.value\n            break\n    return target'
    actual = YieldFromTransformer().visit(ast.parse(input_))
    assert_equal(ast.dump(ast.fix_missing_locations(actual)), expected)

# Generated at 2022-06-21 18:24:21.697149
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-21 18:24:31.943749
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseTestTransformer
    from ..utils.source import Source, source_to_str
    from ..utils.helpers import dump

    class TestTransformer(BaseTestTransformer):

        transformers = [YieldFromTransformer]

        def test_YieldFromTransformer(self):
            source = Source.from_string(
                '''
                    result = yield from func()
                    try:
                        yield from gen()
                    finally:
                        pass
                    yield from func()
                ''')
            result = source_to_str(self.transform(source.tree))


# Generated at 2022-06-21 18:24:42.401725
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import astunparse
    from ..utils.source import source

    class TestYieldFromTransformerVisit(unittest.TestCase):
        def test_1(self):
            code = 'yield from gen;'
            tree = source.to_ast(code)
            YieldFromTransformer().visit(tree)
            actual = astunparse.unparse(tree)
            expected = 'exc = None\n' \
                       'iterable = iter(gen)\n' \
                       'while True:\n' \
                       '    try:\n' \
                       '        yield next(iterable)\n' \
                       '    except StopIteration as exc:\n' \
                       '        break'
            self.assertEqual(actual, expected)


# Generated at 2022-06-21 18:24:43.895748
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    from .base import NodeTest
    from ..utils.tree import dump


# Generated at 2022-06-21 18:24:47.531267
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("""
        yield from foo()
    """)
    node = YieldFromTransformer().visit(node)
    assert "" == ast.unparse(node)



# Generated at 2022-06-21 18:26:34.659287
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test = YieldFromTransformer()
    assert test.target == (3, 2)


# Unit tests for function _get_yield_from_index in YieldFromTransformer

# Generated at 2022-06-21 18:26:35.723024
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)



# Generated at 2022-06-21 18:26:42.165749
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == 'Compiles yield from to special while statement.'
    assert YieldFromTransformer.target == (3, 2)
    yft = YieldFromTransformer._get_yield_from_index(None, None)
    assert yft is None
    yft = YieldFromTransformer._emulate_yield_from(None, None)
    assert yft == []

# Generated at 2022-06-21 18:26:50.541551
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    # Unit test for visit method of Try node
    def test_Try(self):
        body = [ast.Expr(value=ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load())))]

        node = ast.Try(body=body,
                       handlers=[ast.ExceptHandler(type=None,
                                                   name=None,
                                                   body=[ast.Pass()])],
                       orelse=[],
                       finalbody=[])


# Generated at 2022-06-21 18:26:59.609780
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module_node = ast.parse('a = yield from [1]')
    transformer = YieldFromTransformer()
    node = transformer.visit(module_node)

    from ..utils.python_kit import LocalPythonKit
    from ..utils.operators import Assign, Yield, AssertEqual, Expressions, Var, True_, While, Gt, GetAttr, For, Import, Subscript, List, Module, Name, Attribute, FunctionDef, Store, If, Int, Eq, Continue
    from inspect import signature


# Generated at 2022-06-21 18:27:04.141257
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    import astunparse as ap
    from ..utils.helpers import get_ast
    from ..transforms.scope import ResolveLocalVariables
    from ..transforms.map_unpack_transformer import MapUnpackTransformer
    from ..transforms.name_refactor import NameRefactor


# Generated at 2022-06-21 18:27:06.539187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3
    except Exception as e:
        return
    YieldFromTransformer(ast3.parse("[1, 2, 3]"))

# Generated at 2022-06-21 18:27:07.733545
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-21 18:27:08.567083
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:27:15.176410
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import dump
    from . import parse

    code = """
    def f():
        x = yield from range(10)
        yield from x
    """
    expected = """
    def f():
        let(iterable)

        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    x = exc.value
                break
        let(iterable)

        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    tree = parse(code)
    transformed = YieldFromTransformer().visit(tree)
    assert dump(transformed) == expected

    code