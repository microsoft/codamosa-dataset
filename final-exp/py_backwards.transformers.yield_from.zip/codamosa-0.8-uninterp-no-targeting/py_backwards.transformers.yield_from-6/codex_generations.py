

# Generated at 2022-06-21 18:19:09.089071
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:19:10.273801
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:12.271277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    YieldFromTransformer(ast3.parse('print(1)'))

# Generated at 2022-06-21 18:19:24.079155
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse('from typed_ast import ast3 as ast\n' +
    'node = ast.parse(\'result = \'\n' +
    '                \'yield from [1, 2, 3]\')\n' +
    'visitor = YieldFromTransformer()\n' +
    'node = visitor.visit(node)')
    exec(compile(node, '', 'exec'))

# Generated at 2022-06-21 18:19:25.107949
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-21 18:19:27.350073
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..cli import transform
    from ..utils.source import source
    from ..tests.utils import compare_ast


# Generated at 2022-06-21 18:19:39.879105
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # type: () -> None
    try:
        from typed_ast import ast3 as ast
        from ..utils.tree import print_ast
        from ..utils.snippet import snippet
        from ..utils.codegen import to_source
    except ImportError:
        return
    source = """
        def f():
            yield from [1, 2]
        """
    print('Source:')
    print(source)
    tree = ast.parse(source)
    print('Transformed:')
    print_ast(tree)
    print('Evaluated:')
    print(to_source(tree))
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print('Transformed:')
    print_ast(tree)
    print('Evaluated:')

# Generated at 2022-06-21 18:19:40.483617
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-21 18:19:42.352758
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() != None

# Generated at 2022-06-21 18:19:43.307072
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:49.948676
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:55.549546
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast

    ast_tree = get_ast('''
    def inner(arg):
        yield from arg

    def outer():
        yield from inner(1)
        a = yield from inner(2)
        yield from inner(3)
    ''')

    transformer = YieldFromTransformer()
    assert transformer.visit(ast_tree)

# Generated at 2022-06-21 18:19:58.899592
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import Source
    from ..parser.compile import PyccelCompiler


# Generated at 2022-06-21 18:20:10.349198
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast
    import unittest
    import textwrap
    from typed_ast.ast3 import parse
    from typed_astunparse import astunparse
    from translate.transformers import YieldFromTransformer
    
    
    class TestYieldFromTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = YieldFromTransformer()
        
        def test_handles_try(self):
            for variant in [1, 2]:
                with self.subTest(variant=variant):
                    if variant == 1:
                        orig = textwrap.dedent(
                            """
                            try:
                                yield from (i for i in range(5))
                            except StopIteration as e:
                                pass
                            """)

# Generated at 2022-06-21 18:20:12.514909
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Initialization of class YieldFromTransformer
    obj = YieldFromTransformer()

    # Initialization of the tree

# Generated at 2022-06-21 18:20:18.569397
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile_string
    from ..utils.source import source

    script = source(
        """
        def test_func(x):
            a = yield from x
            b = yield from x
            return a, b
        """
    )

    node = compile_string(script, '<test>', 'exec')
    node = YieldFromTransformer().visit(node)


# Generated at 2022-06-21 18:20:19.546818
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:20:21.782615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import assert_equal_with_printing


# Generated at 2022-06-21 18:20:33.124675
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.node.module import point_module, new_module
    from ..utils.node.stmt import new_function, new_if, new_for
    from ..utils.node.expr import new_yield_from, new_call, new_name
    from ..utils.node.helper import new_assign, new_expr
    from ..utils.node.stmt import new_return
    from ..utils.node.args import new_arguments, new_arg

    excs = ['StopIteration', 'ValueError']

    def _run_test(module, expected_module):
        transformer = YieldFromTransformer()
        module = transformer.visit(module)
        assert expected_module == module

    # Test for yield from expression

# Generated at 2022-06-21 18:20:34.320516
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    m = YieldFromTransformer()
    pass

# Generated at 2022-06-21 18:21:01.670838
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .transformer_test_case import TransformerTestCase, run_tests

    class TestYieldFromTransformer(TransformerTestCase):
        def test_yield_from_in_function(self):
            code = '''
                def foo():
                    yield from [1, 2, 3]
            '''
            expected = '''
                def foo():
                    iterable = iter([1, 2, 3])
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            break
            '''
            self.check_ast(YieldFromTransformer, code, expected)


# Generated at 2022-06-21 18:21:08.366454
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    init_func = ast.FunctionDef("__init__")
    ast.Assign(ast.Name(""), ast.Name(""))
    ast.Expr(ast.YieldFrom(ast.Attribute(ast.Name(""), "__iter__")))
    classdef = ast.ClassDef("IterClass",
                            [],
                            [init_func],
                            [],
                            [],
                            type_comment=None)
    ast.Module([classdef])

# Generated at 2022-06-21 18:21:13.181465
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_utils import generate_test_function
    from .test_utils import generate_expected_function

    def test():
        l = [1, 2, 3, 4, 5]
        for item in l:
            yield from l  # pylint: disable=pointless-statement


# Generated at 2022-06-21 18:21:22.044420
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer()
    code = '''
    def foo():
        yield from (x for x in range(10))

    def foo2():
        x = yield from (z for z in range(10))

    def foo3():
        yield from (y for y in range(10))
    '''
    tree = ast.parse(code)
    t.visit(tree)

# Generated at 2022-06-21 18:21:26.312994
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helpers import parse, to_python
    from .test_helpers import ThreadingTransformManager as TransformManager

    manager = TransformManager()
    manager.register(YieldFromTransformer)


# Generated at 2022-06-21 18:21:27.446360
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # TODO
    pass


# Generated at 2022-06-21 18:21:38.500910
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    yield_from = ast.YieldFrom()

    tree = ast.parse('''
        def foo():
            yield from bar()
    ''')
    assert YieldFromTransformer().visit(tree) == ast.parse('''
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        None = exc.value
                    break
    ''')

    tree = ast.parse('''
        def foo():
            foo = yield from bar()
    ''')

# Generated at 2022-06-21 18:21:45.540579
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import assert_equal_source
    assert_equal_source(YieldFromTransformer,
                        """
                        def f():
                            x = yield from a
                        """, """
                        def f():
                            exc = None
                            iterable = iter(a)
                            while True:
                                try:
                                    yield next(iterable)
                                except StopIteration as exc:
                                    x = exc.value
                                    break
                        """)



# Generated at 2022-06-21 18:21:56.341805
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test_yield_from_transformer
    code = '''a = yield from range(10)'''
    assert 'yield from' in code
    new_code = YieldFromTransformer()(code)
    assert 'yield from' not in new_code
    assert 'yield next(iterable)' in new_code
    assert 'iterable = iter(range(10))' in new_code
    exec(new_code, locals())
    assert a == 9
    # test_yield_from_without_assignment
    code = '''yield from range(10)'''
    assert 'yield from' in code
    new_code = YieldFromTransformer()(code)
    assert 'yield from' not in new_code
    assert 'yield next(iterable)' in new_code

# Generated at 2022-06-21 18:22:05.018201
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..parsing import parse

    node: ast.AST = parse('yield from it')
    YieldFromTransformer().visit(node)

    expect = '''
    def f():
        _locals = locals()
        _locals.update(globals())
        exec(py_compile.compile('_py_code', '_py_file', 'exec'), _locals, _locals)
        del _locals
    f()
    '''

    from ..utils.unparse import Unparser
    unparser = Unparser(node)
    code = unparser.get_code()
    assert expect == code
    exec(code)

# Generated at 2022-06-21 18:22:17.630356
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()
# _END


# Generated at 2022-06-21 18:22:28.356724
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import parse
    from ..utils.helpers import check_equal
    from ..utils.helpers import dump

    f = """
    def f(x):
        y = yield from x
        return y
    """
    expected = """
    def f(x):
        let(exc)
        let(iterable)
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
            if hasattr(exc, 'value'):
                y = exc.value

                break

        return y

    """
    tree = parse(f)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    check_equal(dump(new_tree), expected)

# Generated at 2022-06-21 18:22:29.098374
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:22:30.059016
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass


# Generated at 2022-06-21 18:22:42.906247
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils.parsing import get_ast

    class TestYieldFromTransformer(YieldFromTransformer):
        def visit_Module(self, node: ast.Module) -> ast.AST:
            node = self.generic_visit(node)

            if not self._tree_changed:
                return node

            return node

    source = dedent('''
        def foo(x, y):
            z = yield from bar(x)
            yield from baz(z, y)

        def foo2(x, y):
            yield from bar(x)
            yield from baz(y)
        ''')

# Generated at 2022-06-21 18:22:50.430782
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    code = """
        def foo(x):
            while x:
                yield from bar(x)
            yield from bar(x)
            bar(x)
            baz(x)

        def baz(x):
            yield from bar(x)
            yield from bar(x)
    """
    node = ast.parse(code)
    transformer = YieldFromTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-21 18:22:56.529284
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def test(x):
        y = yield from "foo"
        z = yield from "bar"
        yield from "baz"
        return 15
    """
    a = ast.parse(code)
    result = YieldFromTransformer().visit(a)

# Generated at 2022-06-21 18:22:59.963672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Allowed instantiations
    YieldFromTransformer()
    # Unsupported instantiations
    # YieldFromTransformer(1,2,3)
    # YieldFromTransformer(x=1,z=3)
    # YieldFromTransformer(1,x=1)
    

# Generated at 2022-06-21 18:23:11.581822
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from .context import Context
    from .return_statement import ReturnStatementTransformer
    from .yield_statement import YieldStatementTransformer
    from .generator import GeneratorTransformer
    from .assignment_expression import AssignmentExpressionTransformer
    from .for_loop import ForLoopTransformer

    code = '''
    def foo(x):
        return x + 1
    right = foo(left)
    '''

    tr = Context(
        code,
        YieldFromTransformer,
        ReturnStatementTransformer,
        ForLoopTransformer,
        YieldStatementTransformer,
        GeneratorTransformer,
        AssignmentExpressionTransformer,
    )

    assert(tr.code == '''
    def foo(x):
        return x + 1

    right = foo(left)
    ''')



# Generated at 2022-06-21 18:23:21.483476
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .util_classes import SampleTransformer

    class TestTransformer(SampleTransformer):
        def __init__(self, *args, **kwargs):
            self.yield_from = YieldFromTransformer(*args, **kwargs)

        def visit_FunctionDef(self, node: ast.AST) -> ast.AST:
            extend_tuple_if_needed(node.args)
            node = node.__class__(
                name=node.name,
                args=node.args,
                body=self.yield_from.visit(node.body),
                decorator_list=node.decorator_list,
                returns=node.returns
            )

            return node


# Generated at 2022-06-21 18:23:45.415902
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest


# Generated at 2022-06-21 18:23:47.962332
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..transpile import Transpiler

    code = '''
    def fib():
        a = 0
        b = 1
        while True:
            yield a
            a, b = b, a + b
    def test():
        for i in range(10):
            yield from fib()
    '''
    tree = ast.parse(code)
    transpiler = Transpiler([YieldFromTransformer], python_version='3.2')
    transpiler.transpile_tree(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-21 18:23:49.004395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert(transformer)

# Generated at 2022-06-21 18:23:59.844789
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import ast_transformer

    class TestTransformer(YieldFromTransformer):
        def __init__(self):
            super().__init__()
            self.counter = 0
            self.assert_counter = 0

        def _assert(self, *args, **kwargs):
            self.assert_counter += 1
            self.assertEqual(*args, **kwargs)

        def generic_visit(self, node):
            self.counter += 1
            return node

    @ast_transformer(TestTransformer)
    def fn1(x):
        x = yield from x
        return x

    s = ast.parse(fn1.__code__.co_code,
                  '<string>', 'exec')
    assert_equal(TestTransformer().generic_visit(s), s)
    assert_equal

# Generated at 2022-06-21 18:24:05.938497
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    from typed_ast.ast3 import parse
    from typed_ast import ast3
    from typed_ast.transforms.YieldFromTransformer import YieldFromTransformer

    class Test(unittest.TestCase):
        def test_try_statement(self):
            source = '''
try:
    x = yield from 1
except:
    pass
            '''

            source_expected = '''
exc = None
try:
    try:
        iterable = iter(1)
        while True:
            try:
                x = next(iterable)
            except StopIteration as exc:
                x = exc.value
                break
    except:
        pass
except:
    exc = None
            '''
            module = parse(source, mode="exec")
            transform = YieldFromTrans

# Generated at 2022-06-21 18:24:16.710202
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap
    from ..utils.source import source, source0

    source0 = textwrap.dedent(source0)
    source = textwrap.dedent(source)

    tree0 = astor.parse_file(source0)
    tree1 = astor.parse_file(source)

    transformer = YieldFromTransformer()
    transformer.visit(tree0)
    result0 = astor.to_source(tree0)
    transformer.visit(tree1)
    result1 = astor.to_source(tree1)

    assert transformer._tree_changed is True


# Generated at 2022-06-21 18:24:20.360173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.test_transformer import get_test, get_test_cases

    for case in get_test_cases(__file__):
        yield get_test(YieldFromTransformer(), *case)

# Generated at 2022-06-21 18:24:26.399082
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import check_transform

    code = '''
        def f():
            result = yield from generator()
    '''
    expect = '''
        def f():
            let(iterable)
            iterable = iter(generator())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    result = exc.value
                    break
    '''
    check_transform(YieldFromTransformer, code, expect)



# Generated at 2022-06-21 18:24:27.249988
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:24:31.152092
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""def f(): return tuple(yield from (1, 2, 3))""", "", "exec")
    ast.fix_missing_locations(tree)

# Generated at 2022-06-21 18:25:57.517909
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..visitor import Visitor
    from ..utils.source import source_to_nodes
    from ..utils.helpers import to_source
    source = '''
    def f():
        yield from foo
    '''
    nodes = source_to_nodes(source)
    nodes[0].body[0].args[0] = ast.arg(arg='foo', annotation=None)
    visitor = Visitor(YieldFromTransformer())
    new_nodes = visitor.visit(nodes)
    print(to_source(new_nodes))


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:26:00.983930
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

# Generated at 2022-06-21 18:26:08.073417
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.ast_unparse import unparse
    source = 'def f(): yield from g()'
    expected = """def f():
    let(iterable)
    iterable = iter(g())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break"""
    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    if transformer.tree_changed():
        source = unparse(tree)
    assert source == expected

# Generated at 2022-06-21 18:26:12.639401
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fake import fake_ast
    from ..utils.helpers import AstSugar
    from ..utils.tree import get_ast_str

    module = fake_ast("""
        def f():
            a, b = yield from g()
            print(j)
            yield from h()
            yield from i()
    """)

    result_buffer = []

# Generated at 2022-06-21 18:26:21.358019
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse('def test(a):\n'
                       '    c = yield from a + b\n'
                       '    yield from a + b')
    YieldFromTransformer().visit(module)

# Generated at 2022-06-21 18:26:23.053363
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _YieldFromTransformer = YieldFromTransformer()
    # Test the attribute is correctly set
    assert _YieldFromTransformer.target == (3, 2)

# Generated at 2022-06-21 18:26:33.704795
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from ..utils.helpers import compare_ast


# Generated at 2022-06-21 18:26:42.133290
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .compare import compare_ast
    from ..utils.helpers import generate_var_name
    from ..utils.snippet import let, snippet, extend
    import ast
    import random
    import string

    class Transformer(BaseNodeTransformer):
        """Compiles yield from to special while statement."""

        def __init__(self):
            self._tree_changed = False
            self.name = None


# Generated at 2022-06-21 18:26:47.689447
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        with open('tests/fixtures/yield_from.py') as f:
            code = f.read()
    except:
        print(sys.exc_info()[1])
    else:
        tree = ast.parse(code)
        transformer = YieldFromTransformer()
        transformer.visit(tree)
        print(ast.dump(tree))

if __name__ == '__main__':
    the_ans = test_YieldFromTransformer()
    print(the_ans)

# Generated at 2022-06-21 18:26:48.455252
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # No raise
    assert YieldFromTransformer()