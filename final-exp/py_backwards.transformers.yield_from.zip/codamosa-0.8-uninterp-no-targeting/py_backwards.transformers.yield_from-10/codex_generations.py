

# Generated at 2022-06-21 18:19:16.609322
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from test.test_compiler import get_code
    from ..utils.transformers import TransformerPipeline, ast_print
    from .stabilizer import Stabilizer
    from .traditional_to_modern import TraditionalToModern

    code = get_code('yield_from.py')
    tree = ast.parse(code)
    pipeline = TransformerPipeline(Stabilizer(),
                                   TraditionalToModern,
                                   YieldFromTransformer,
                                   TraditionalToModern,
                                   Stabilizer())
    tree2 = pipeline.visit(tree)
    print(ast_print(tree2))

# Generated at 2022-06-21 18:19:22.449282
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3
    from nuitka.optimizations.TraceCollections import TraceCollections
    import inspect
    import astunparse

    code = inspect.getsource(TraceCollections.visit_Assign)
    module = ast3.parse(code)
    module = YieldFromTransformer().visit(module)
    print(astunparse.unparse(module))
    print()

# Generated at 2022-06-21 18:19:31.266438
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.test_utils import assert_output
    from ..utils.transform import Transformer

    test_input = '''
    def foo():
        a = (yield from b)
        yield from c
        yield from d
    '''


# Generated at 2022-06-21 18:19:41.581410
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import TemplatedTransformerTestCase
    from ..utils.ast import dump_tree, load_tree

    class TestTransformer(TemplatedTransformerTestCase):
        transformer = YieldFromTransformer

        @classmethod
        def get_transformation_cases(cls):
            yield 0, """
            x = (yield from range(10))
            """, """
            let(iterable)
            iterable = iter(range(10))
            while True:
                try:
                    x = next(iterable)
                    yield x
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        x = exc.value
                    break
            """


# Generated at 2022-06-21 18:19:52.873321
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert ast.dump(YieldFromTransformer().visit(ast.parse("""
    try:
        ...
    except:
        ...
    """)), False) == ast.dump(ast.parse("""
    try:
        ...
    except:
        ...
    """), False)

    assert ast.dump(YieldFromTransformer().visit(ast.parse("""
    if ...:
        try:
            ...
        except:
            ...
    """)), False) == ast.dump(ast.parse("""
    if ...:
        try:
            ...
        except:
            ...
    """), False)


# Generated at 2022-06-21 18:19:55.741993
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .stubs import FunctionDef
    from .check import Checker

    def test_1():
        """Test for method visit"""

# Generated at 2022-06-21 18:19:56.759100
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:20:06.987713
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import AST, Expr, Assign, YieldFrom

    assert isinstance(YieldFromTransformer(), YieldFromTransformer)
    assert isinstance(YieldFromTransformer().visit(AST()), AST)
    assert isinstance(YieldFromTransformer()._get_yield_from_index(AST(), AST()), int)
    assert isinstance(YieldFromTransformer()._emulate_yield_from(AST(), YieldFrom(AST())), list)
    assert isinstance(YieldFromTransformer()._handle_assignments(AST()), AST)
    assert isinstance(YieldFromTransformer()._handle_expressions(AST()), AST)

# Generated at 2022-06-21 18:20:16.734864
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer()
    code = """
    a = yield from range(10)
    yield from range(10)
    """
    expected = ['let(iterable)', 'iterable = iter(range(10))', 'while True:',
                'try:', 'a = next(iterable)', 'except StopIteration as exc:',
                'break', 'let(iterable)', 'iterable = iter(range(10))',
                'while True:', 'try:', 'next(iterable)',
                'except StopIteration as exc:', 'break']
    parse_tree = ast.parse(code)
    result = t.visit(parse_tree)
    body = list(map(lambda x: x.body[0].value.s, result.body))
    assert body == expected

# Generated at 2022-06-21 18:20:27.336020
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typing
    import astunparse
    import textwrap
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import YieldFrom
    from typed_ast import NodeTransformer
    from .yield_from_transformer import YieldFromTransformer

    source = '''
    def test_yield_from():
        yield from range(0, 10)
    '''
    tree = ast.parse(textwrap.dedent(source))
    tree = YieldFromTransformer().visit(tree)
    print(astunparse.unparse(tree))

# Generated at 2022-06-21 18:20:39.612817
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import transform
    from ..defaults import DEFAULT_TRANSFORMERS
    from ..exceptions import TransformerParseError
    from .test_base import get_node_of_type

    node = transform('''
    class Test:
        def process(self):
            result = yield from other()
    ''', transformers=[YieldFromTransformer])

    while_node = get_node_of_type(node, ast.While)
    assert while_node is not None



# Generated at 2022-06-21 18:20:51.117569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def assert_yield_from_transformed(source: str,
                                      expected: str,
                                      variant: str = 'assignment') -> None:
        if variant == 'expression':
            source = f'{source}\npass'
        root = ast.parse(source)
        transformer = YieldFromTransformer()
        transformer.visit(root)
        generated = ast.unparse(root).strip()
        assert generated == expected


# Generated at 2022-06-21 18:20:52.265821
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transormer = YieldFromTransformer()
    assert transormer is not None



# Generated at 2022-06-21 18:20:59.553070
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_nodes
    from ..utils.helpers import print_tree
    import ast as python_ast
    node = source_to_nodes("""
    def test():
        _ = yield from range(3)
        yield from range(3)
        (yield from range(3))
        a = yield from range(3)
        a, = yield from range(3)
    """)

    YieldFromTransformer(python_ast.Module([node])).visit(node)
    print_tree(node)

# Generated at 2022-06-21 18:21:10.425793
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from ..utils.tree_inspector import TreeInspector

# Generated at 2022-06-21 18:21:11.859440
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-21 18:21:21.219169
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert YieldFromTransformer.run('x = yield from y') == 'exc = VariablesGenerator.generate("exc")\n' \
                                                          'iterable = iter(y)\n' \
                                                          'while True:\n' \
                                                          '  try:\n' \
                                                          '    yield next(iterable)\n' \
                                                          '  except StopIteration as exc:\n' \
                                                          '    x = exc.value\n' \
                                                          '    break'

# Generated at 2022-06-21 18:21:25.883423
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.target == (3, 2)
    YieldFromTransformer()


# Generated at 2022-06-21 18:21:28.176455
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('1+1')
    result = YieldFromTransformer().visit(node)
    assert result is not None

# Generated at 2022-06-21 18:21:29.141657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:21:37.061258
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    item = YieldFromTransformer()
    assert isinstance(item, BaseNodeTransformer)
    assert item.target == (3, 2)


# Generated at 2022-06-21 18:21:38.654884
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:21:44.887809
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    def convert(compiled: str, expected: str) -> None:
        tree = astor.parse_file(compiled)
        transformer = YieldFromTransformer()
        transformer.visit(tree)
        assert astor.to_source(tree) == expected

    def prepare_string(string: str) -> str:
        return string.replace(" ", "").replace("\n", "")


# Generated at 2022-06-21 18:21:45.794156
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:21:56.596851
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    class TestYieldFromTransformer_visit(YieldFromTransformer):
        def __init__(self):
            self.py_ver = 3.8
            self.tree_changed = False
            self.vars_gen = VariablesGenerator()
    from .tools import run_transformer_visit_test

# Generated at 2022-06-21 18:22:04.214121
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('a = yield from b')
    node = YieldFromTransformer.run(tree)
    assert ast.dump(node, annotate_fields=False) == (
        'Module(body=[Assign(targets=[Name(id=a, ctx=Store())], '
        'value=Call(func=Name(id=yield_from, ctx=Load()), '
        'args=[Name(id=b, ctx=Load())], keywords=[])), Expr(value=None)])'
    )



# Generated at 2022-06-21 18:22:14.275588
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.typechecker import TypeChecker

    global result
    result = None

    global value
    value = True

    # type: () -> typing.Generator[bool, None, None]
    def gen():
        global result
        result = yield

    # type: () -> typing.Generator[bool, None, None]
    def gen2():
        global value
        yield False
        value = False
        yield True

    @snippet
    def yield_from_test():
        let(res)
        res = yield from gen()
        return res

    class MockedMod(ast.Module):
        pass

    tree = yield_from_test.get_tree(MockedMod)
    YieldFromTransformer().visit(tree)

    assert TypeChecker(tree).check()
    assert result is None


# Generated at 2022-06-21 18:22:17.528480
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = '''
    def gen():
        yield from 1
        yield from 2
        yield from 3
    '''
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-21 18:22:18.964082
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:22:21.889359
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__qualname__ == 'YieldFromTransformer'

# Generated at 2022-06-21 18:22:35.409691
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:22:37.844808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:22:38.918479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:22:40.032823
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print (YieldFromTransformer)


# Generated at 2022-06-21 18:22:49.020767
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    import ast
    import astunparse
    code = inspect.getsource(test_YieldFromTransformer_visit)
    code_ast = ast.parse(code)
    transformer = YieldFromTransformer()
    new_ast = transformer.visit(code_ast)

    assert transformer._tree_changed is True
    assert transformer._visited_nodes > 0


# Generated at 2022-06-21 18:22:59.298550
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = 'import asyncio\nasync def gu(loop):\n    x = await asyncio.sleep(1, loop=loop)'
    tree = ast.parse(code)
    tree = YieldFromTransformer().visit(tree)
    exp_code = 'import asyncio\nasync def gu(loop):\n    _iterable = iter(asyncio.sleep(1, loop=loop))\n    while True:\n        try:\n            x = next(_iterable)\n        except StopIteration as _exc:\n            if hasattr(_exc, \'value\'):\n                x = _exc.value\n            break'
    exp_tree = ast.parse(exp_code)
    assert ast.dump(tree) == ast.dump(exp_tree)


__all__ = ['YieldFromTransformer']

# Generated at 2022-06-21 18:23:02.002682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        result = YieldFromTransformer()
    except Exception as e:
        print(e)

# Generated at 2022-06-21 18:23:05.896950
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from io import StringIO
    from ..main import main
    from ..utils.helpers import VariablesGenerator

    # Generating an AST
    target = StringIO()

# Generated at 2022-06-21 18:23:12.119619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    global_ns = {'__builtins__': __builtins__}
    code = '''def foo():
        yield_from('a')
        '''
    m = parse(code)
    YieldFromTransformer().visit(m)
    code = compile(m, '', 'exec')
    exec(code, global_ns, global_ns)
    foo = global_ns['foo']
    assert ''.join(foo()) == 'a'

# Generated at 2022-06-21 18:23:13.989443
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.target == (3, 2)


# Generated at 2022-06-21 18:23:36.558598
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    y = YieldFromTransformer()
    assert y is not None

# Generated at 2022-06-21 18:23:42.897738
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import textwrap
    from .base import BaseNodeTransformer
    from pytype.context import Context
    from pytype.typegraph import TypeGraph
    from pytype.pytd import pytd
    from pytype.tests import test_base
    from pytype.tests import test_inference

    node = YieldFromTransformer()
    assert isinstance(node, BaseNodeTransformer)
    assert isinstance(node, YieldFromTransformer)


# Generated at 2022-06-21 18:23:46.783043
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    ast_node = ast.AST
    ast_node.body = [ast.Expr(value=ast.YieldFrom(value=ast.Num(n=1)))]
    assert isinstance(yield_from_transformer.visit(ast_node), ast.AST)

# Generated at 2022-06-21 18:23:49.604487
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    one = 1
    two = 2
    three = 3
    four = 4


    def func(x: int) -> int:
        yield from (x, x*2)


    yft = YieldFromTransformer()
    assert yft.visit(func) == func

# Generated at 2022-06-21 18:23:50.735904
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ut = YieldFromTransformer()
    assert ut is not None

# Generated at 2022-06-21 18:24:01.482194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def yield_from_leaves_some_assignments_unhandled():
        code = '''
            def foo():
                a = yield from 1
        '''
        module = ast.parse(code)

        YieldFromTransformer.run_on(module)

        assert module == ast.parse(code)

    def yield_from_leaves_some_expressions_unhandled():
        code = '''
            def foo():
                yield from 1
        '''
        module = ast.parse(code)

        YieldFromTransformer.run_on(module)

        assert module == ast.parse(code)

    def yield_from_transforms_assignments():
        code = '''
            def foo():
                a = yield from 1
                b = yield from 2
                c = yield from 3
        '''


# Generated at 2022-06-21 18:24:01.986842
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit(): pass

# Generated at 2022-06-21 18:24:05.424114
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer
    try:
        YieldFromTransformer()
    except TypeError:
        pass
    except Exception:
        assert False, 'wrong exception raised'


# Generated at 2022-06-21 18:24:08.101562
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer('foo')
        assert False, "Expected TypeError not raised"
    except TypeError:
        pass

# Generated at 2022-06-21 18:24:09.910301
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'

# Generated at 2022-06-21 18:25:01.075747
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..backport_ast import parse
    from .unpacking_transformer import UnpackingTransformer
    from .unpacking_assignment_transformer import UnpackingAssignmentTransformer

# Generated at 2022-06-21 18:25:01.579592
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:25:02.422360
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:25:12.703933
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:25:22.908774
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ast import literal_eval
    from ...utils.env import env
    env.log.setLevel('WARNING')

    with open('tests/fixtures/sample_generator.py') as f:
        tree = ast.parse(f.read())

    # Without assign
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert literal_eval(astor.to_source(tree)) == literal_eval(
        '''
        def generator():
            yield from [x for x in range(5)]
            yield from (x for x in range(6))
            yield 1, 2, 3, 4, 5
            yield 'hello'
            return 666
        '''
    )
    assert env.errors == []

    # With assign

# Generated at 2022-06-21 18:25:33.481196
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.snippet import snippet
    from typing import List

    @snippet
    def test(a) -> List[int]:
        def foo():
            yield from range(a) # This line will be substituted with while statement.
        return foo()

    from .snippet_to_ast import snippet_to_ast
    from .helpers import get_target, create_module

    module = create_module(test.get_source())
    # This will cause syntax error as `yield from` is available in version >= 3.3
    # module = create_module("def foo():\n\tyield from range(a)")
    target = get_target(module, YieldFromTransformer)
    YieldFromTransformer().visit(target)

    assert isinstance(target, ast.FunctionDef)

# Generated at 2022-06-21 18:25:36.145576
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 18:25:36.620554
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:25:38.629610
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:25:40.826709
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert instance is not None

if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:27:44.039276
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import astor
    from thistothat.transpilers.utils.tree import as_ast

    class TestYieldFromTransformerVisit(unittest.TestCase):
        def test_it(self):
            tree = as_ast("""
            def func():
                yield from foo()
            """)
            ast.fix_missing_locations(tree)
            transformer = YieldFromTransformer()
            compiled_tree = transformer.visit(tree)
            self.assertEqual(astor.to_source(compiled_tree), """
            def func():
                iterable=iter(foo())
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        exc.value
                    break
            """)
    unittest.main()




# Generated at 2022-06-21 18:27:45.838128
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    import astor
    from .unpacking import UnpackingTransformer

# Generated at 2022-06-21 18:27:54.670948
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert isinstance(YieldFromTransformer().visit(
        ast.parse('yield_from[a for b in c]')), ast.AST)
    assert isinstance(YieldFromTransformer().visit(
        ast.parse('def a(x,y,z): yield_from[a for b in c]')), ast.AST)
    assert isinstance(YieldFromTransformer().visit(
        ast.parse('(yield_from[a for b in c])')), ast.AST)
    assert isinstance(YieldFromTransformer().visit(
        ast.parse('yield from (yield from [a for b in c])')), ast.AST)

# Generated at 2022-06-21 18:28:00.761215
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast

    node = ast.Expr(
        value=ast.YieldFrom(
            value=ast.Name(
                id='__name__',
                ctx=ast.Load()
            )
        )
    )

    node = ast.Module(body=[node])
    node = YieldFromTransformer().visit(node)

    assert ast.dump(node) == \
        "Module(body=[Expr(value=Call(func=Name(id='yield_from', ctx=Load()), " \
        "args=[Name(id='__name__', ctx=Load())], keywords=[], starargs=None, kwargs=None))], type_ignores=[])"

# Generated at 2022-06-21 18:28:08.184682
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.snippet import code
    from ..utils.ast import parse

    assert code(YieldFromTransformer(3, 2).visit(parse('''
        def f():
            yield from iter([])
    '''))) == code('''
        def f():
            let(iterable)
            iterable = iter([])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    ''')


# Generated at 2022-06-21 18:28:09.362887
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-21 18:28:20.958399
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit(): 
    _input = '''
import ast
from typed_ast import ast3 as ast
import typed_ast.ast3

from typedast import YieldFromTransformer

tree = ast.parse('from mygen import gen\nx = y\ny = 1\nif y == 1:\n    a = gen(1,2)\n    a = sum(gen(1,2))')

transform = YieldFromTransformer()
transform.visit(tree)

print(ast.dump(tree, include_attributes=True, annotate_fields=False, include_aliases=False))
'''

# Generated at 2022-06-21 18:28:22.040089
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-21 18:28:29.290738
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # $ cat test/python3_test_code/test_YieldFromTransformer_visit.py
    class MyIter():
        def __iter__(self):
            return self
        def __next__(self):
            return 42
    def test_yield_from(it):
        yield from it
    test_yield_from(MyIter())
    # $ python3 -m memory_profiler test/python3_test_code/test_YieldFromTransformer_visit.py
    # Filename: test/python3_test_code/test_YieldFromTransformer_visit.py
    #
    # Line #    Mem usage    Increment   Line Contents
    # ================================================
    #     21     12.0 MiB     12.0 MiB   @profile
    #     22                             def test_

# Generated at 2022-06-21 18:28:30.377813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(),YieldFromTransformer)