

# Generated at 2022-06-21 18:19:16.625348
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_utils import generate_test_function

    # Assert correct transformation of simple yield from
    def test_function1():
        a = yield from test_function2()
        b = yield from test_function2()

    def expected1():
        let(exc, iterable)
        result = []
        iterable = iter(test_function2())
        while True:
            try:
                result.append(next(iterable))
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
        iterable = iter(test_function2())
        while True:
            try:
                result.append(next(iterable))
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    b = exc.value
                break

# Generated at 2022-06-21 18:19:19.585479
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..supply import Supply
    from ..common.testing import get_test_case_from_test_file
    from ..common.testing import run_standard_tests

    Supply.current = Supply('transformer')

    # assert run_standard_tests(
    #     YieldFromTransformer(0),
    #     get_test_case_from_test_file('yieldfrom.txt'),
    #     include_slow_tests=True,
    # )

# Generated at 2022-06-21 18:19:29.638463
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast

    # Test snippet
    assert (result_assignment.get_body(target=100, exc='exc') ==
            [ast.Assign(
                targets=[ast.Num(100)],
                value=ast.Attribute(value=ast.Name(id='exc', ctx=ast.Load()),
                                    attr='value', ctx=ast.Load())
            )])

# Generated at 2022-06-21 18:19:30.866612
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass



# Generated at 2022-06-21 18:19:41.552029
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    snippet = """
    def a(b: int) -> None:
        x, y = [await x for x in b], await x
    """

    expected_transformation = """
    def a(b: int) -> None:
        let(iterable, x)
        let(iterable_1)
        let(exc, exc_1)
        iterable = iter(b)
        while True:
            try:
                x = next(iterable)
            except StopIteration as exc:
                x = exc.value
                break
        iterable_1 = iter(x)
        while True:
            try:
                x = next(iterable_1)
            except StopIteration as exc_1:
                x = exc_1.value
                break
    """

    node = ast.parse(snippet)

# Generated at 2022-06-21 18:19:42.881268
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:49.094969
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from typing import Generator
    class MyYield:
        def __init__(self) -> None:
            self.x = 0
        def __iter__(self) -> Generator:
            return self
        def __next__(self) -> int:
            if self.x < 3:
                self.x += 1
                return self.x
            else:
                raise StopIteration


# Generated at 2022-06-21 18:19:51.723429
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except TypeError:
        assert False, 'Instantiating YieldFromTransformer failed.'

# Generated at 2022-06-21 18:19:53.069404
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)

# Generated at 2022-06-21 18:19:53.709268
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass # FIXME

# Generated at 2022-06-21 18:20:10.659910
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

    node_1 = ast.Module(
        body=[
            ast.FunctionDef(
                name='func',
                args=ast.arguments(args=[], vararg=None, kwonlyargs=[],
                                   kw_defaults=[], kwarg=None, defaults=[]),
                body=[
                    ast.Expr(value=ast.YieldFrom(value=ast.Name(id='x', ctx=ast.Load()))),
                ],
                decorator_list=[],
                returns=None
            ),
        ]
    )

# Generated at 2022-06-21 18:20:16.453730
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #def f(): yield from g()
    body = [ast.Expr(value=ast.YieldFrom(value=ast.Name(id='g', ctx=ast.Load())))]
    function_def = ast.FunctionDef(name='f', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=body)
    module = ast.Module(body=[function_def])
    module = YieldFromTransformer().visit(module)
    assert module.body[0].body[0].value.func.id == 'iter'

# Generated at 2022-06-21 18:20:23.010691
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    #TODO: Rewrite unit test, because it's not compiled to target version now.
    #TODO: Add more unit tests to cover cases like this.
    # import ast
    #
    # def visit(self, node: ast.AST) -> ast.AST:
    #     node = self._handle_assignments(node)
    #     node = self._handle_expressions(node)
    #     return self.generic_visit(node)
    pass

# Generated at 2022-06-21 18:20:23.991817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None) is not None

# Generated at 2022-06-21 18:20:24.970077
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:20:26.089521
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-21 18:20:27.599102
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helpers import round_trip

# Generated at 2022-06-21 18:20:39.430464
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.visitor import PrintVisitor
    from ..utils.test_utils import source_to_nodes
    source = 'yield from x'
    node = source_to_nodes(source)[-1]
    transformer = YieldFromTransformer()
    res = transformer.visit(node)
    visitor = PrintVisitor()
    visitor.visit(node)
    visitor.visit(res)

# Generated at 2022-06-21 18:20:40.409057
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

# Generated at 2022-06-21 18:20:51.778736
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    actual = ast.Module(
        body=[ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.YieldFrom(value=ast.Name(id='b', ctx=ast.Load())))])

# Generated at 2022-06-21 18:21:05.751461
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()


# Generated at 2022-06-21 18:21:16.764557
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import TreeBuilder
    
    source = """
    def __init__(self):
        self.field0 = yield from iterable
        self.field1 = yield from iterable
        yield from iterable
    """
    
    tree = TreeBuilder().string_build(source)
    YieldFromTransformer().visit(tree)
    

# Generated at 2022-06-21 18:21:23.767168
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing.utils import get_visitor_output


# Generated at 2022-06-21 18:21:34.946673
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .testutils import round_trip
    from .testutils import transform, TransformResult

    from ..utils.helpers import extract_names

    tree = transform(
        """
        def f():
            x = yield from [1, 2, 3]
        """,
        YieldFromTransformer,
    )
    assert extract_names(tree) == 'x'
    round_trip(tree, TransformResult(
        """
        def f():
            let(iterable)
            iterable = iter([1, 2, 3])
            while True:
                try:
                    next(iterable)
                except StopIteration as exc:
                    x = exc.value
                    break
        """,
        YieldFromTransformer,
    ))


# Generated at 2022-06-21 18:21:35.974212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:21:38.247366
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.interpreter import assert_interpreter

# Generated at 2022-06-21 18:21:42.299175
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_utils import parse_to_ast as parse

# Generated at 2022-06-21 18:21:45.499437
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    from .unparse import Unparser
    from .yield_from import YieldFromTransformer
    import astunparse


# Generated at 2022-06-21 18:21:56.294176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTestCase, NodeTestCase
    from .test_typed_ast import parse
    from .test_helpers import get_target_nodes

    class TestCase(BaseNodeTestCase[YieldFromTransformer]):
        target = YieldFromTransformer.target  # type: ignore
        transformer_func = YieldFromTransformer.transform  # type: ignore

    class TestExpr(NodeTestCase[ast.AST]):
        target = YieldFromTransformer.target  # type: ignore
        transformer_func = YieldFromTransformer.transform  # type: ignore

    def get_target_nodes(tree: ast.AST) -> List[ast.AST]:
        return get_target_nodes(tree, ast.YieldFrom)


# Generated at 2022-06-21 18:21:57.214277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:22:19.128393
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:22:25.054104
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:22:26.399272
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    raise NotImplementedError()



# Generated at 2022-06-21 18:22:27.557439
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:22:40.356068
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from typed_astunparse import unparse
    from ..utils.helpers import assert_code_equal, single_node_tree

    tp = YieldFromTransformer()

    code = textwrap.dedent("""\
        def fun():
            a = yield_from(1,2,3)
            b = yield_from(1,2,3)
            yield_from(1,2,3)

        def fun():
            yield_from(1,2,3)
            yield_from(1,2,3)
            yield_from(1,2,3)
        """)


# Generated at 2022-06-21 18:22:45.660813
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = 'a = yield from b'
    expected = """
a = None
while True:
    try:
        a = next(iter(b))
    except StopIteration as exc:
        if exc.value:
            a = exc.value
        break
"""
    assert expected.strip() == YieldFromTransformer().visit(ast.parse(source)).body[0].body[0].body[0].body[0].body[0]



# Generated at 2022-06-21 18:22:55.793987
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .AssignmentExpressionTransformer import AssignmentExpressionTransformer
    from .GetAnnotationsTransformer import GetAnnotationsTransformer
    from .ClassDefTransformer import ClassDefTransformer
    from .with_stmt import WithStmtTransformer
    from .FunctionDefTransformer import FunctionDefTransformer
    from .FunctionDefType import FunctionDefType
    from .CodeType import CodeType
    from .GlobalState import GlobalState
    from .LoopTransformer import LoopTransformer
    from .IfStmtTransformer import IfStmtTransformer
    from .TryStmtTransformer import TryStmtTransformer



# Generated at 2022-06-21 18:22:57.576594
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  from ..utils.helpers import get_ast, get_node
  ast_tree = get_ast("yield from x")
  node = get_node(ast_tree, ast.YieldFrom)
  node = YieldFromTransformer.visit(node)

# Generated at 2022-06-21 18:23:06.044730
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Given
    test_code: ast.Module = ast.parse("""
    def test():
        a = yield from something_generator()
        b = yield from something_generator()
        print(a, b)
    """)
    yield_from_transformer = YieldFromTransformer()

    # When
    yield_from_transformer.visit(test_code)
    compiled_code = compile(test_code, __file__, 'exec')

    # Then
    assert "a = next(iterator)" in compiled_code.co_code.hex()

# Generated at 2022-06-21 18:23:07.894982
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import compile_func, assert_ast_equal


# Generated at 2022-06-21 18:23:54.601255
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import sys
    if sys.version_info[:2] == (3, 6):
        return

    tree = ast.parse("""
    def f(gen):
        yield from gen
    """)
    expected = """
    def f(gen):
        let(iterable)
        iterable = iter(gen)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break

    """
    expected = ast.parse(expected)
    tree = YieldFromTransformer().visit(tree)
    assert astunparse.unparse(tree) == astunparse.unparse(expected)

# Generated at 2022-06-21 18:23:55.866983
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:05.561478
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with YieldFromTransformer() as transformer:
        mod = ast.parse('x = yield from gen')
        transformer.visit(mod)

# Generated at 2022-06-21 18:24:06.896841
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer()

# Generated at 2022-06-21 18:24:17.775162
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.helpers import get_test_nodes, iterate_test_tree
    from ..utils.helpers import assert_equal_ast, assert_not_equal_ast
    from ..utils.collections import ASTCollection, transform_ast

    nodes = get_test_nodes('yield_from')
    for node in iterate_test_tree(nodes):
        node = transform_ast(node, YieldFromTransformer)
        # Build from source formatted
        node_copy = ASTCollection.from_source(textwrap.dedent(ASTCollection.to_source(node)))
        assert_not_equal_ast(node, node_copy)
        node_copy = transform_ast(node_copy, YieldFromTransformer)
        assert_equal_ast(node, node_copy)

# Generated at 2022-06-21 18:24:27.558360
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse as ast_parse
    from ..utils.parsecode import parse

    a, b = ast_parse('a = yield from (x for x in [1, 2, 3])'), 'a = (lambda _gen:_gen.__next__() if hasattr(_gen,"__next__") else _gen.next()) (iter((x for x in [1, 2, 3])))'
    c, d = ast_parse('yield from (x for x in [1, 2, 3])'), '_it = (x for x in [1, 2, 3])\nwhile True:\n    try:\n        yield next(_it)\n    except StopIteration as _exc:\n        if hasattr(_exc,\'value\'):\n            x = _exc.value\n            break'

# Generated at 2022-06-21 18:24:38.679604
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast2 as ast2
    import ast2 as ast2

    def transform(s: str) -> ast2.AST:
        tree = ast.parse(s, mode='exec')
        node = YieldFromTransformer().visit(tree)
        return node

    assert ast2.dump(transform("yield from a")) == \
        "Program([YieldFrom(Name(a, Load()), Load(), Store())])"

    assert ast2.dump(transform("yield from g()")) == \
        "Program([YieldFrom(Call(Name(g, Load()), [], [], None, None, Load()), Load(), Store())])"


# Generated at 2022-06-21 18:24:48.755320
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    program = """
    yield from smth
    """
    module = ast.parse(program)
    YieldFromTransformer().visit(module)
    expected = """
    let(iterable)
    iterable = iter(smth)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                exc = exc.value
            break
    """
    assert expected == ast.unparse(module)

    program = """
    yield from smth
    yield from smth2
    """
    module = ast.parse(program)
    YieldFromTransformer().visit(module)

# Generated at 2022-06-21 18:24:53.875362
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tests.test_py2c.test_snippets.test_yield_from_transformer import test_snippet
    from . import Py2C

    node = test_snippet
    transformed = Py2C.transform(node,
                                 YieldFromTransformer)
    assert Py2C.compile(transformed)

# Generated at 2022-06-21 18:24:55.618518
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)

# Generated at 2022-06-21 18:26:47.052583
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)



# Generated at 2022-06-21 18:26:53.509803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def func():
        a = yield from iter([1, 2, 3])

    expected = """
    def func():
        exc = None
        iterable = None
        iterable = iter([1, 2, 3])
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                a = exc.value
                break
    """
    actual = ast.dump(YieldFromTransformer().visit(parse(func)))
    assert actual == dedent(expected).strip()

# Generated at 2022-06-21 18:27:00.728147
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test ignore nodes without body
    assert YieldFromTransformer()._get_yield_from_index(ast.Lambda(), ast.Expr) is None

    # Test ignore nodes with empty body
    assert YieldFromTransformer()._get_yield_from_index(ast.Module(body=[]), ast.Expr) is None

    # Test ignore nodes with body without yield from
    assert YieldFromTransformer()._get_yield_from_index(ast.Module(body=[ast.Expr(value=ast.Name())]), ast.Expr) is None

    # Test find yield from
    node = ast.Module(body=[ast.Expr(value=ast.YieldFrom(value=ast.Name()))])

# Generated at 2022-06-21 18:27:03.424328
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..compiler import transform
    from ...workflow import CallableTask, task


# Generated at 2022-06-21 18:27:05.010710
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''Test for creating an object of class YieldFromTransformer'''
    YieldFromTransformer()


# Generated at 2022-06-21 18:27:13.221753
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    import typed_astunparse

    node = ast.parse(
        """
        x = yield from range(10)
        f()
        yield from range(10)
        """)
    expected_node = ast.parse(
        """
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    x = exc.value
                break
        f()
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
        """)
    transformer = YieldFromTransformer()

    # Act
   

# Generated at 2022-06-21 18:27:17.247703
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    YieldFromTransformer.__module__ = 'YieldFromTransformer'

    yield_from_transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:27:18.569311
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): assert YieldFromTransformer([])

# Generated at 2022-06-21 18:27:28.612727
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_node
    import astunparse

# Generated at 2022-06-21 18:27:40.156414
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from types import FunctionType
    from ..utils import run_on_lines
    from textwrap import dedent

    source = dedent("""
        def test():
            a = yield from foo(1)
            assert a == 2
            yield from foo(3)
            yield from foo()
            return a
        """)
