

# Generated at 2022-06-21 18:19:16.674048
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def func(node):
        return True


# Generated at 2022-06-21 18:19:27.447092
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .variables import VariablesTransformer

# Generated at 2022-06-21 18:19:29.013260
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()
    return tr

# Generated at 2022-06-21 18:19:33.879938
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from copy import deepcopy as copy

    from typed_astunparse import unparse
    import typed_ast.ast3 as ast

    from mypy_boto3_builder.structures.class_node import ClassNode


# Generated at 2022-06-21 18:19:35.160814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:19:43.221225
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:19:54.385006
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helper import run_test_visitor
    from ..utils.test_helper import *
    from ..utils.check_source import check_source

    source = '''
    def f(x):
        yield from x
    '''
    expected = '''
    def f(x):
        let(iterable)
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    '''
    check_source(source, expected)

    source = '''
    def f(x):
        a = yield from x
    '''

# Generated at 2022-06-21 18:19:55.344849
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert isinstance(yield_from_transformer, YieldFromTransformer)


# Generated at 2022-06-21 18:20:07.133309
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:20:09.483464
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)
    # BaseNodeTransformer constructor has no parameters.
    # Therefor it can not fail.

# Generated at 2022-06-21 18:20:17.353126
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
# vim: set tabstop=8 softtabstop=4 shiftwidth=4 expandtab:

# Generated at 2022-06-21 18:20:18.724124
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:20:19.734491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-21 18:20:25.975887
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import io
    import sys
    import unittest
    import astunparse
    from flake8_typing_imports.transformers.yield_from import YieldFromTransformer  # type: ignore
    from flake8_typing_imports.utils.tree import find_all_of_type

    class TestYieldFromTransformerClass(unittest.TestCase):
        maxDiff = None

# Generated at 2022-06-21 18:20:37.653938
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import get_ast, transform
    def _test(code, compare=True):
        tree = get_ast(code)
        YieldFromTransformer().visit(tree)

        assert VariablesGenerator.is_clear()
        if compare:
            assert astor.to_source(tree) == code
        return tree

    # Test with multiple yield from expressions
    def test_multiple_yield_from():
        node = _test('''
        def func(a):
            while True:
                yield from a
            while True:
                yield from a
        ''', False)

        gen = node.body[0].body[0].body[0].body[0]
        assert isinstance(gen, ast.While)
       

# Generated at 2022-06-21 18:20:44.122333
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import parse
    from ..utils import ast_helpers
    code = '''
        def f(a):
            pass
    '''
    node_tree = parse(code)
    node = ast_helpers.get_func_def_by_name(node_tree, 'f')
    transformer = YieldFromTransformer()
    transformer.visit(node)
    print(node)


__all__ = ['YieldFromTransformer']

# Generated at 2022-06-21 18:20:55.509314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('''
    def foo():
        yield from bar()
    ''')

    m = ast.parse('''
    def bar():
        yield from baz()
    ''')
    tree.body.append(m)

    m = ast.parse('''
    def baz():
        yield from foobar()
    ''')
    tree.body.append(m)

    # Setup forbidden names
    import keyword
    generator = VariablesGenerator(set(keyword.kwlist), lambda x: False)
    # Generating a transformer
    tr = YieldFromTransformer(generator)
    tr.visit(tree)
    result = ''.join(ast.unparse(tree))
    # Assert

# Generated at 2022-06-21 18:21:04.429216
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import os,sys
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    snippet_dir = curr_dir+'/../snippets'
    sys.path.insert(0,snippet_dir)
    from yield_from_snippet import snip
    from ..utils.helpers import get_ast

    a = 3
    b = 4
    s = snip.get_source()
    tree = get_ast(s)

    t = YieldFromTransformer()
    tt = t.visit(tree)

    print(ast.dump(tt))

# Generated at 2022-06-21 18:21:05.817964
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert inspect.isclass(YieldFromTransformer)


# Generated at 2022-06-21 18:21:16.813209
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:21:31.285708
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''
    def foo(self):
        get_context()
        return a
    '''
    tree = ast.parse(code)
    new_tree = YieldFromTransformer().visit(tree)
    assert ast.dump(new_tree) == ast.dump(tree)



# Generated at 2022-06-21 18:21:41.493371
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    expected = "while True:\n    try:\n        let(a)\n        a = next(b)\n        yield a\n    except (StopIteration) as exc:\n        a = exc.value\n        break"
    actual = YieldFromTransformer().visit(
        ast.FunctionDef(name='f',
                        body=[ast.While(test=ast.NameConstant(value=True),
                                        body=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='b', ctx=ast.Load())))],
                                        orelse=[])],
                        decorator_list=[],
                        returns=None))
    assert_equal(expected, ast.dump(actual))

# Generated at 2022-06-21 18:21:43.964153
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer._get_yield_from_index(None, ast.Expr) is None
    return transformer

# Generated at 2022-06-21 18:21:49.990859
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import check_node_transformer
    check_node_transformer(YieldFromTransformer, "def foo():\n"
                                                 "    x = yield from bar()\n"
                                                 "    yield from bar()\n"
                                                 "    pass\n"
                                                 "def bar():\n"
                                                 "    for i in range(5):\n"
                                                 "        yield i\n"
                                                 "\n")

# Generated at 2022-06-21 18:21:52.555058
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('def foo():\n'
                     '    x = yield from bar()\n')
    transformer = YieldFromTransformer()
    assert transformer.visit(tree)

# Generated at 2022-06-21 18:21:53.596535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

# Generated at 2022-06-21 18:22:03.276365
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # source: yield from a
    node = ast.parse('''
yield from a
    ''').body[0]

    # target: let iterable
    #         iterable = iter(a)
    #         while True:
    #             try:
    #                 yield next(iterable)
    #             except StopIteration as exc:
    #                 break
    target = ast.parse('''
let iterable
iterable = iter(a)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        break
    ''')

    assert YieldFromTransformer().visit(node) == target.body[0]

# Generated at 2022-06-21 18:22:07.528573
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import FakeDialect
    from ..utils.tree import ast_from_str, ast_to_str
    from ..dialect.functions import SpecialFunctionsDialect


# Generated at 2022-06-21 18:22:08.489520
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()


# Generated at 2022-06-21 18:22:09.069065
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:22:43.593130
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def func():
        yield from a
        a = yield from b
        yield from c


# Generated at 2022-06-21 18:22:49.442223
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from cyt.transpiler import Transpiler
    from cyt.utils.helpers import get_source
    from cyt.utils.tree import get_tree

    source = get_source(YieldFromTransformer.__module__, 'test_YieldFromTransformer_visit')
    tree = get_tree(source)
    tree = Transpiler([
        YieldFromTransformer()
    ], target=(3, 6)).visit(tree)

    src = ast.unparse(tree)
    assert src == source.replace('yield from', 'yield from __cython__')



# Generated at 2022-06-21 18:22:59.441260
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

    # test_yield_from_to_assign
    code = 'a = yield from [1]'
    expected_code = '''\
a = None
exc = None
iterable = iter([1])
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        a = exc.value
        break
'''
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    astor.to_source(tree) == expected_code
    # test_yield_from_to_expr
    code = 'yield from [1]'

# Generated at 2022-06-21 18:23:10.729017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # ast.FunctionDef(
    #     name='test_YieldFromTransformer',
    #     args=ast.arguments(
    #         args=[],
    #         vararg=None,
    #         kwonlyargs=[],
    #         kw_defaults=[],
    #         kwarg=None,
    #         defaults=[]),
    #     body=[],
    #     decorator_list=[],
    #     returns=None),
    yft = YieldFromTransformer()
    assert yft.target == (3,2)
    assert yft.version == None
    assert yft.node == None
    assert yft.tree_changed == False

# unit test for _get_yield_from_index() of class YieldFromTransformer

# Generated at 2022-06-21 18:23:19.926248
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseTestTransformer
    import os
    import sys
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')))
    import aiocompat
    import unittest

    class TestYieldFromTransformer(BaseTestTransformer, unittest.TestCase):
        TRANSFORMER = YieldFromTransformer
        BASEDIR = os.path.abspath(os.path.dirname(__file__))
        EXCLUDES = []
        FILEPATHS = [os.path.join(BASEDIR, 'test_data/yield_from_transformer')]

    TestYieldFromTransformer.run()

# Generated at 2022-06-21 18:23:25.745368
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    f = """def f():
        yield from gen
    """
    expected = """def f():
        let(iterable)
        iterable = iter(gen)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    tree = ast.parse(f)

    YieldFromTransformer().visit(tree)

    assert expected == astunparse.unparse(tree)

# Generated at 2022-06-21 18:23:28.724272
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestYieldTransformer:
        def __init__(self):
            self.test = YieldFromTransformer()
    a = TestYieldTransformer()
    assert a



# Generated at 2022-06-21 18:23:30.130147
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.codegen import to_source


# Generated at 2022-06-21 18:23:41.685315
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    import astunparse

    module = inspect.getmodule(inspect.currentframe())
    ast_code = ast.parse(inspect.getsource(module))
    t = YieldFromTransformer()
    t.visit(ast_code)

# Generated at 2022-06-21 18:23:43.818517
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    import sys
    # init

# Generated at 2022-06-21 18:24:29.285388
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:24:32.992776
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse(u"yield from generator")
    YieldFromTransformer().visit(tree)
    print(ast.dump(tree, include_attributes=True))


# Generated at 2022-06-21 18:24:43.055449
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..enforce_variable_types import EnforceVariableTypesTransformer
    import sys
    import io

    method_source = '''
    def foo():
        result = yield from my_iterable
        yield result
    '''

    tree = ast.parse(method_source)
    result = io.StringIO()

    for transformer in [EnforceVariableTypesTransformer,
                        YieldFromTransformer]:
        transformer(tree).run()
        original, _ = transformer.tree_to_code(tree)
        result.write(original)

    expected = '''
    def foo():
        iterable = iter(my_iterable)
        while True:
            try:
                result = next(iterable)
            except StopIteration as exc:
                result = exc.value
                break
        yield result
    '''

   

# Generated at 2022-06-21 18:24:44.148775
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(node=None, verbose=None)

# Generated at 2022-06-21 18:24:45.999034
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:46.830829
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()


# Generated at 2022-06-21 18:24:53.798024
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile_string
    from textwrap import dedent

    node = compile_string(dedent("""
        def f():
            p = (i for i in range(5))
            yield from p
            yield from p
            a = yield from (j for j in range(5))
            yield from p"""), '<test>', 'exec')
    YieldFromTransformer().visit(node)
    code = compile(node, '<test>', 'exec')

    assert eval(code) == 0

# Generated at 2022-06-21 18:24:55.569752
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass



# Generated at 2022-06-21 18:25:04.157422
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:25:05.142255
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:27:13.523027
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import get_node

    node = get_node('''
    def func1():
        a = yield
        yield from func2()
        c = yield
        yield from func3()
        d = yield

    def func2():
        yield from func3()
        yield from func4()
        yield from func5()
        yield from func6()

    def func5():
        yield from func6()
        yield from func7()
    ''')


# Generated at 2022-06-21 18:27:17.153075
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("""
    def func():
        a = yield from range(5)
        return a
    """)
    expected = ast.parse("""
    def func():
        exc = gen_1
        iterable = iter(range(5))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                exc = exc
                a = exc.value
                break
        return a
    """)
    result = YieldFromTransformer().visit(node)
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-21 18:27:18.777177
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:27:28.803542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast as _ast
    from .ast_helpers import ast_source_code
    from .unwrap_statements import UnwrapStatements

    def test_snippet(source):  # pylint: disable=invalid-name
        tree = _ast.parse(source)
        UnwrapStatements(indent=0).visit(tree)
        YieldFromTransformer().visit(tree)
        return ast_source_code(tree)


# Generated at 2022-06-21 18:27:37.216210
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import check_code

    source = """\
    def f():
        g()
        a.b = yield from c
        d
        """

    expected = """\
    def f():
        g()
        let(iterable)
        iterable = iter(c)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a.b = exc.value
                break
        d
        """

    check_code(expected, source, max_version=YieldFromTransformer.target)



# Generated at 2022-06-21 18:27:46.859249
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import NodeTransformerBase
    from .unpacking import UnpackingTransformer
    from .helpers import print_node

    class DummyTransformer(NodeTransformerBase):
        target = (3, 8)
        def visit_YieldFrom(self, node):
            return ast.Expr(ast.Constant(10, lineno=1))

    source = '''
    def a():
        x, y = yield from b()
        c[y - 1] = yield from d()
        return yield from e()
        '''

    node = ast.parse(source)
    UnpackingTransformer().visit(node)
    DummyTransformer().visit(node)
    YieldFromTransformer().visit(node)
    print_node(node)

# Generated at 2022-06-21 18:27:47.726003
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass



# Generated at 2022-06-21 18:27:57.467703
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.example import example
    from ..common.testing import ExampleTester
    from ..utils.helpers import get_ast
    from ..context import Context

    tester = ExampleTester(ExampleTester.Example.yield_from,
                           ExampleTester.Example.class_yield_from)
    context = Context()
    yield_from_transformer = YieldFromTransformer(context)

    for test in tester.get_examples():
        source = get_ast(test.code)
        transformed = yield_from_transformer.visit(source)
        example_tester = ExampleTester(ExampleTester.Example.yield_from_builtin)
        example_tester.add_next_example(ExampleTester.Example.class_yield_from_builtin)

# Generated at 2022-06-21 18:27:58.376446
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:28:05.041957
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .._compat import IS_PY38_PLUS

    from ..utils.helpers import set_parent_nodes
    from .inner_if_transformer import InnerIfTransformer
    from .dead_if_branch_eliminator import DeadIfBranchEliminator
    from .yield_from_transformer import YieldFromTransformer
    from .unused_variables_remover import UnusedVariablesRemover
    from .transformer import Transformer
    from ..node_visitor import NodeVisitor
