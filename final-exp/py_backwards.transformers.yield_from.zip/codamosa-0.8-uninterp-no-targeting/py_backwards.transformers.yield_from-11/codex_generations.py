

# Generated at 2022-06-21 18:19:03.288211
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:10.785171
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from mypy_extensions import NoReturn
    from typed_ast import ast3 as ast
    from ..compile import scope2ast


# Generated at 2022-06-21 18:19:13.010467
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # The assertion raises if an object of YieldFromTransformer class
    # is not created successfully
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:19:24.697680
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:32.400725
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import unittest.mock as mock
    from ..utils.testing import expected_failure

    class TestYieldFromTransformer(unittest.TestCase):
        def test_basic(self):
            x = mock.MagicMock()
            x.configure_mock(name='yield_from_test')
            ex = mock.MagicMock()
            ex.configure_mock(name='exc')
            assign = result_assignment.get_body(target=x, exc=ex)
            yield_from_while = yield_from.get_body(generator=x, exc=ex, assignment=assign)

# Generated at 2022-06-21 18:19:34.759558
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast
    import astunparse


# Generated at 2022-06-21 18:19:38.977619
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Mock(ast.AST):
        pass
    class Mock2(ast.AST):
        pass
    class Mock3(ast.AST):
        pass

    node = Mock(body=[Mock2(), Mock3()])
    YieldFromTransformer().visit(node)



# Generated at 2022-06-21 18:19:43.144601
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import _ast as ast
    module = ast.Module([ast.Expr(value=ast.YieldFrom(value=None))])
    transformer = YieldFromTransformer()
    node = transformer.visit(module)
    assert module is node
    assert isinstance(node.body[0], ast.Assign)
    assert isinstance(node.body[0].value, ast.YieldFrom)
    assert len(node.body) == 1


# Generated at 2022-06-21 18:19:54.282881
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""
    if condition:
        yield from foo
        yield from bar
        yield from baz
    else:
        yield from aaa
    """, feature_version=(3, 6))
    tf = YieldFromTransformer()
    tf.visit(tree)

# Generated at 2022-06-21 18:19:55.400261
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:20:12.071752
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source
    from ..utils.visitor import NodeTransformerScheduler

    scheduler = NodeTransformerScheduler()
    scheduler.add_transformer(YieldFromTransformer)
    source = source('''
    def test(generator):
        a, b, c = yield from generator
        while True:
            yield from generator
            yield from generator
            a, b, c = yield from generator
            yield from generator
            return
        yield from generator
    ''')


# Generated at 2022-06-21 18:20:18.916998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def test_method():
        a = yield from [1, 2, 3]
        assert a is None

    method_ast = ast.parse(inspect.getsource(test_method))
    YieldFromTransformer().visit(method_ast)
    globs = {}
    exec(compile(method_ast, '', 'exec'), globs)
    globs['test_method']()

# Generated at 2022-06-21 18:20:24.635061
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.examples import yield_from_transformer
    from ..visitor import NodeVisitor
    from ..utils.compiler import compile_snippet

    code = yield_from_transformer.get_code()
    node = compile_snippet(code)
    visitor = NodeVisitor(YieldFromTransformer)
    visitor.visit(node)

    assert node is not None
    assert code != node

# Generated at 2022-06-21 18:20:25.246558
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-21 18:20:27.238520
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # class for testing
    class A:
        pass

    f = A()
    assert(isinstance(f, A))

# Generated at 2022-06-21 18:20:31.616288
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("def foo(): yield from bar()")
    node = YieldFromTransformer.run(node)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    node = node.body[0]
    assert isinstance(node, ast.FunctionDef)
    assert len(node.body) == 1
    node = node.body[0]
    assert isinstance(node, ast.While)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Yield)
    assert isinstance(node.body[1], ast.ExceptHandler)
    assert len(node.body[1].body) == 1

# Generated at 2022-06-21 18:20:32.846759
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-21 18:20:33.885050
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = 3
    assert x == 3

# Generated at 2022-06-21 18:20:39.751438
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    if sys.version_info < (3, 6):
        return
    tree = ast.parse('from inspect import isgeneratorfunction')
    YieldFromTransformer().visit(tree)
    assert '''from inspect import isgeneratorfunction''' == ast.dump(tree)


# Generated at 2022-06-21 18:20:51.240033
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from astor.source_repr import to_source

    class TestYieldFromTransformer(YieldFromTransformer):
        def visit_Try(self, node: ast.Try) -> ast.AST:
            node = super().visit_Try(node)
            return node

        def visit_If(self, node: ast.If) -> ast.AST:
            node = super().visit_If(node)
            return node

        def visit_While(self, node: ast.While) -> ast.AST:
            node = super().visit_While(node)
            return node

        def visit_For(self, node: ast.For) -> ast.AST:
            node = super().visit_For(node)
            return node


# Generated at 2022-06-21 18:21:06.002930
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:21:07.330560
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    print(obj)

# Generated at 2022-06-21 18:21:08.234871
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()



# Generated at 2022-06-21 18:21:19.010976
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    exc = "e"
    target = "a"
    iterable = "i"
    generator = "g"
    assignment = result_assignment.get_body(exc=exc,target=target)
    assignment = "".join(assignment)
    while_statement = yield_from.get_body(generator=generator,
                                          assignment=assignment,
                                          exc=exc)
    while_statement = "".join(while_statement)
    program = f"{target} = yield from {generator}"
    expected_program = f"{while_statement}\n{target} = {exc}.value"
    actual_program = compile(program, "<ast>", "exec")
    expected_program = compile(expected_program, "<ast>", "exec")

# Generated at 2022-06-21 18:21:29.856268
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')
    assert hasattr(YieldFromTransformer, 'visit')
    assert hasattr(YieldFromTransformer, '_emulate_yield_from')
    assert hasattr(YieldFromTransformer, '_get_yield_from_index')
    assert hasattr(YieldFromTransformer, '_handle_assignments')
    assert hasattr(YieldFromTransformer, '_handle_expressions')
    assert hasattr(YieldFromTransformer, '_tree_changed')
    # 
    assert callable(YieldFromTransformer.visit)
    assert callable(YieldFromTransformer._emulate_yield_from)
    assert callable(YieldFromTransformer._get_yield_from_index)

# Generated at 2022-06-21 18:21:30.218202
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:21:36.773195
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    print('Testing method YieldFromTransformer.visit')
    import astor
    from itertools import count
    from ..optimizations.yield_from import YieldFromTransformer
    from ..utils.helpers import VariablesGenerator

    def inner(x):
        yield from x
        yield from range(x)

    def outer():
        yield from 'abc'
        yield from range(3)
        let(a)
        a = yield from range(4)
        yield from a
        let(b)
        b = yield from inner(5)
        yield from b

    ast_module = ast.parse(outer.__code__)
    ast_module2 = astor.to_ast(outer)
    assert astor.dump_tree(ast_module) == astor.dump_tree(ast_module2)



# Generated at 2022-06-21 18:21:47.749726
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    function_def = ast.FunctionDef('func', ast.arguments([], None, None, []), [
        ast.Expr(ast.YieldFrom(ast.Name('gen', ast.Load())))], [], None)
    obj = YieldFromTransformer()
    actual = obj._handle_expressions(function_def)
    actual = ast.dump(actual, include_attributes=True)

# Generated at 2022-06-21 18:21:58.709706
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as pyast
    from ..utils.python_ast import PythonAst
    source = '''
a, b, c = yield from [1, 2, 3]
        '''
    source_ast = PythonAst.parse(source)
    node_transformer = YieldFromTransformer()
    node_transformer.visit(source_ast)
    fixed = '''
let(iterable)
iterable = iter([1, 2, 3])
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        if hasattr(exc, 'value'):
            b = exc.value
        if hasattr(exc, 'value'):
            c = exc.value
        break
        '''
   

# Generated at 2022-06-21 18:22:01.719303
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception:
        assert False
    else:
        assert True

# Unit tests for method _get_yield_from_index of class YieldFromTransformer

# Generated at 2022-06-21 18:22:23.806980
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:22:35.779844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def f():
        a = yield from b
        yield from c
    """
    expected = """
    def f():
        exc = _exc_
        iterable = iter(b)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                exc = _exc_
                if hasattr(exc, 'value'):
                    a = exc.value
                break
        exc = _exc_
        iterable = iter(c)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                exc = _exc_
                break
    """
    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-21 18:22:38.186943
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node : ast3.AST
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-21 18:22:47.290029
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def func():
        yield_from_ast = ast.YieldFrom(value=ast.Name(id='f', ctx=ast.Load()))
        assignment_ast = ast.Assign(targets=[ast.Name('target', ast.Store())], value=yield_from_ast)
        expression_ast = ast.Expr(value=yield_from_ast)
        expected = """\
            iterable = iter(f)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        target = exc.value
                    break
                """
        return [expected, ast.Module(body=[assignment_ast, expression_ast])]

    actual = YieldFromTransformer().visit(func()[1])
   

# Generated at 2022-06-21 18:22:51.024136
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    import sys
    if sys.version_info >= (3, 7):
        from ...tests.fixtures.codegen import test_YieldFromTransformer_visit as func

# Generated at 2022-06-21 18:22:52.762122
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None
    return transformer


# Generated at 2022-06-21 18:22:53.534618
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:23:01.526987
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import test_utils
    from . import if_statement

    ast_tree = test_utils.build_ast("""
    def foo(generator):
        result = yield from generator
        yield result
    """)

    expected_ast = test_utils.build_ast("""
    def foo(generator):
        exc = VariablesGenerator.generate('exc')
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    result = exc.value
                break
        yield result
    """, set_context=True)

    tr = YieldFromTransformer()
    tr.visit(ast_tree)


# Generated at 2022-06-21 18:23:12.494535
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ... import ast3 as ast
    from ..utils.helpers import make_function

    transform = YieldFromTransformer().visit

    assert make_function(transform, """
    a = yield from (1, 2, 3)
    """
    ) == make_function("""
    let(iterable)
    iterable = iter((1, 2, 3))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                a = exc.value
            break
    """
    )


# Generated at 2022-06-21 18:23:22.106549
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ... import testing

    testing.assert_code_equal(
        r'''
            def test_method():
                yield from 1 + 2
        ''',
        r'''
            def test_method():
                let(iterable)
                iterable = iter(1 + 2)
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        if hasattr(exc, 'value'):
                            pass
                        break
        ''',
        YieldFromTransformer, 3, 2
    )


# Generated at 2022-06-21 18:25:03.260163
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()

# Generated at 2022-06-21 18:25:08.179685
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # type: () -> None
    a = 1
    generator = (a for a in range(3))

    @snippet
    def generator_function():
        for x in generator:
            return x

    node = ast.parse(inspect.getsource(generator_function))
    YieldFromTransformer().visit(node)
    assert_source(node, inspect.getsource(generator_function))

    @snippet
    def generator_comprehension():
        return [x for x in generator]

    node = ast.parse(inspect.getsource(generator_comprehension))
    YieldFromTransformer().visit(node)
    assert_source(node, inspect.getsource(generator_comprehension))


# Generated at 2022-06-21 18:25:12.658554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test to check whether the class can be instantiated or not
    try:
        transformer = YieldFromTransformer()
    except Exception as e:
        print(e)
        assert False, "Unable to instantiate class"
    assert True


# Generated at 2022-06-21 18:25:22.858721
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump
    global vars
    a = ast.parse("try: pass\nexcept (AttributeError, ValueError): pass\n")
    b = ast.parse(
        "try:"
        "    pass"
        "except (AttributeError, ValueError):"
        "    pass"
    )
    c = ast.parse(
        "try: pass"
        "except (AttributeError, ValueError):"
        "    pass"
    )
    d = ast.parse(
        "try: pass\n"
        "except (AttributeError, ValueError):"
        "    pass"
    )

    for tree in [a, b, c, d]:
        print(dump(tree))
        print()

        t = YieldFromTransformer()

# Generated at 2022-06-21 18:25:33.438581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import test_tree
    from typed_ast import ast3
    expected = '''\
    from __future__ import generators
    from typing import Generator, Any

    def a():
        yield from b()

    def b() -> Generator[None, int, None]:
        yield 0
        c = yield from c()
        yield 1

    def c() -> Generator[None, int, None]:
        exc = None
        iterable = iter(d())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    c = exc.value
                break

    def d() -> Generator[int, int, None]:
        yield None
        yield 0
    '''
    tree = test_tree.parse(expected)
    Yield

# Generated at 2022-06-21 18:25:34.860134
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer((1,2))


# Generated at 2022-06-21 18:25:44.873230
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestYieldFromTransformer():
        def test_get_yield_from_index(self):
            t1 = ast.parse("def f(): yield from a")
            t2 = ast.parse("def f(): yield from a if b < c else d")
            t3 = ast.parse("def f(): yield from a if b < c else d")
            test_result = YieldFromTransformer()._get_yield_from_index(t1, ast.Expr)
            assert test_result == 0, "test_get_yield_from_index 1 fail!"
            test_result = YieldFromTransformer()._get_yield_from_index(t1, ast.Assign)
            assert test_result is None, "test_get_yield_from_index 2 fail!"
            test_result = Yield

# Generated at 2022-06-21 18:25:51.718926
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Transformer(YieldFromTransformer):
        pass
    yield isinstance, Transformer(), YieldFromTransformer
    yield hasattr, Transformer(), 'generic_visit'
    yield hasattr, Transformer(), 'visit'
    yield hasattr, Transformer(), '_tree_changed'
    yield hasattr, Transformer(), '_handle_assignments'
    yield hasattr, Transformer(), '_handle_expressions'
    yield hasattr, Transformer(), '_get_yield_from_index'
    yield hasattr, Transformer(), '_emulate_yield_from'


# Generated at 2022-06-21 18:25:52.261183
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:26:00.167841
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node1 = ast.parse("""
try:
    x = yield from f()
except Exception as exc:
    pass
""")
    node2 = ast.parse("""
try:
    yield from f()
except Exception as exc:
    pass
""")
    node3 = ast.parse("""
try:
    yield from g()
except Exception as exc:
    pass
""")
    node4 = ast.parse("""
for x in range(1):
    yield from f()
""")
    node5 = ast.parse("for x in range(1):\n    yield\n")
    node6 = ast.parse("def func():\n    yield from f()\n")
    node7 = ast.parse("def func():\n    yield from g()\n")