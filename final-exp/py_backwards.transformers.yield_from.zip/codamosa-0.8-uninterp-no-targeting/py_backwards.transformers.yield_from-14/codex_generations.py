

# Generated at 2022-06-21 18:19:16.609507
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import assert_node_equal

    tree = ast.parse('a = yield from b')
    tr = YieldFromTransformer()
    result = tr.visit(tree)
    expect = ast.parse('''
    a = None
    iterable = iter(b)
    while True:
        try:
            a = next(iterable)
            yield a
        except StopIteration as exc:
            a = exc.value
            break
    ''')
    assert_node_equal(result, expect)



# Generated at 2022-06-21 18:19:25.352072
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    expected_result = ast.parse("""
    def generator():
        yield 3
    def test_func():
        result = None
        while True:
            try:
                result = next(generator())
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    result = exc.value
                break
        return result
    """)
    code = ast.parse("""
    def generator():
        yield 3
    def test_func():
        result = yield from generator()
    """)
    result = YieldFromTransformer().visit(code)
    assert ast.dump(result) == ast.dump(expected_result)

# Generated at 2022-06-21 18:19:32.740679
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.ast_helpers import get_tree
    from ..handler import get_transformer_handler
    from ..utils.helpers import VariablesGenerator
    tree = get_tree(YieldFromTransformer, '''
    def fib1():
      yield from [1, 2, 3, 4]

    def fib2():
      yield from (1, 2, 3, 4)

    def fib3():
      x = [1, 2, 3, 4]
      yield from x
    ''')
    print(astor.dump_tree(tree))
    handler = get_transformer_handler(YieldFromTransformer)
    assert not handler.tree_changed
    handler.apply(tree)
    assert handler.tree_changed
    print(astor.dump_tree(tree))
    assert astor

# Generated at 2022-06-21 18:19:33.506701
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:19:36.894852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer(None)
    assert x._get_yield_from_index(None, None) == None
    assert x._emulate_yield_from(None, None) == []

# Generated at 2022-06-21 18:19:38.297100
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:39.267723
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:47.538954
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _assert_source_equal(
        YieldFromTransformer().visit(
            ast.parse("yield from x")
        ),
        """
        result = None
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                result = exc.value
                break
        """
    )

    # Test yield_from in a function

# Generated at 2022-06-21 18:19:53.694666
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None).target_version == (3, 2)
    assert not hasattr(YieldFromTransformer, '_handle_assignments')
    assert not hasattr(YieldFromTransformer, '_handle_expressions')
    assert not hasattr(YieldFromTransformer, '_get_yield_from_index')
    assert not hasattr(YieldFromTransformer, '_emulate_yield_from')

# Generated at 2022-06-21 18:19:55.349644
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer([]) == {}


# Generated at 2022-06-21 18:20:01.227903
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer)


# Generated at 2022-06-21 18:20:08.988044
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():  # noqa: D103
    from ..utils.test_resources import FakeTree
    tree = FakeTree(3.2, module='''
        def no_yield_from_inside_method(x):
            pass
    ''')

    expected = FakeTree(3.2, module='''
        def no_yield_from_inside_method(x):
            pass
    ''')

    transformer = YieldFromTransformer()
    transformer.visit(tree.module)
    assert tree == expected



# Generated at 2022-06-21 18:20:16.787942
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from .utils import check_equal


# Generated at 2022-06-21 18:20:24.523750
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from codegen import as_source
    import textwrap
    node = as_source(ast.parse(textwrap.dedent("""
        a = yield from f()
    """)))
    transformer = YieldFromTransformer()
    new_node = transformer.visit(node)
    assert as_source(new_node) == textwrap.dedent("""
        iterable = iter(f())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                a = exc.value
                break
    """)

# Generated at 2022-06-21 18:20:30.362062
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import make_visitor, to_source
    ast_module = ast.parse(
        """
        def outer_func(val):
            yield_from_obj = SomeClass(val)
            yield from yield_from_obj
            yield from yield_from_obj
            yield from yield_from_obj
        """)
    transformer = YieldFromTransformer()
    transformer.visit(ast_module)

# Generated at 2022-06-21 18:20:41.651762
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import Iterator
    from ..utils.source import source_to_unicode
    from ..transformers.base import BaseNodeTransformer
    import astunparse

    def source(s):
        return source_to_unicode(s).strip()

    def transform(s):
        module = ast.parse(s)
        YieldFromTransformer().visit(module)
        return astunparse.unparse(module)

    def compare(s):
        module = ast.parse(s)
        module = YieldFromTransformer().visit(module)
        assert astunparse.unparse(module) == s

    def check(expected, code):
        assert transform(code) == expected


# Generated at 2022-06-21 18:20:42.628845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:20:43.208388
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-21 18:20:43.817977
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    ...

# Generated at 2022-06-21 18:20:48.197304
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert not YieldFromTransformer.is_applicable(3, 6)
    assert YieldFromTransformer.is_applicable(3, 2)
    assert YieldFromTransformer(3, 2).tree_changed is False

# Generated at 2022-06-21 18:20:54.925789
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = YieldFromTransformer()
    assert yield_from is not None

# Generated at 2022-06-21 18:21:05.818538
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import textwrap
    from ..utils.helpers import get_ast
    from ..utils.compat import meta

    code = 'a = yield from iterable_object'
    node = get_ast(textwrap.dedent(code))
    YieldFromTransformer().visit(node)

# Generated at 2022-06-21 18:21:16.856116
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import generate_code

    def check(node, result):
        transformed = YieldFromTransformer().visit(node)
        assert generate_code(transformed) == result

    # test_YieldFromTransformer_visit_basic
    check(
        ast.parse('def foo(): yield from bar'),
        'def foo():\n'
        '    exc = VariablesGenerator.generate(\'exc\')\n'
        '    iterable = iter(bar)\n'
        '    while True:\n'
        '        try:\n'
        '            yield next(iterable)\n'
        '        except StopIteration as exc:\n'
        '            if hasattr(exc, \'value\'):\n'
        '                exc = exc.value\n'
        '            break'
    )

# Generated at 2022-06-21 18:21:17.771681
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-21 18:21:24.195396
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils.helpers import compare_source
    code = dedent("""
    def test():
        x = yield from test(yield from 1)
        yield from test(yield from 1)
        yield from test(yield from 1)
        yield from test(yield from 1)
        yield from test(yield from 1)
        y = yield from test(yield from 1)
    """)

# Generated at 2022-06-21 18:21:25.738786
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yieldFromTransformer = YieldFromTransformer()


# Generated at 2022-06-21 18:21:28.372124
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transpiler = YieldFromTransformer()

    # Success
    try:
        YieldFromTransformer()
        assert True
    except:
        assert False


# Generated at 2022-06-21 18:21:29.719090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    print(transformer)

# Generated at 2022-06-21 18:21:41.199786
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..unittest_tools import assertASTEqual
    from ..unittest_tools import parse
    stmt = """
    target = []
    target += yield from other_generator
    target += yield from other_generator2
    """

# Generated at 2022-06-21 18:21:44.836063
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_equivalent_code
    from ..utils.test_utils import print_test_id
    from ..utils.test_utils import load_ast


# Generated at 2022-06-21 18:21:56.335287
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import compiler
    # Test 1: Assign

# Generated at 2022-06-21 18:22:00.137879
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Test case for YieldFromTransformer.

    '''
    # Constructing a object of class YieldFromTransformer
    obj = YieldFromTransformer()

    # Testing cases for visit(self, node: ast.AST)

# Generated at 2022-06-21 18:22:11.035974
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast
    import astunparse
    from ..utils.helpers import ScopeBuilder
    from ..utils.helpers import VariablesGenerator
    from typed_ast.ast3 import YieldFrom
    from .namedexpr_transformer import NamedExprTransformer
    from .class_transformer import ClassTransformer
    from .function_transformer import FunctionTransformer

# Generated at 2022-06-21 18:22:18.494360
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from ..utils.preprocess import preprocess
    from ..utils.randomizer import randomizer
    from ..utils.helpers import check_code

    parser = preprocess.get_parser()
    code = parser.parse("def f():\n"
                        "    yield from g()\n"
                        "    return x\n")
    tree = preprocess.preprocess_code(code)

    for _ in range(100):
        transformed = randomizer.randomize_module(tree)
        transformed = YieldFromTransformer().visit(transformed)
        check_code.assert_equals(transformed, code)


# Generated at 2022-06-21 18:22:29.219235
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fake_ast import FakeASTBuilder, FakeFunctionDef

    # Test module transformer
    builder = FakeASTBuilder()
    builder.add(
        FakeFunctionDef('fake_1',
                        builder.add(FakeFunctionDef('fake_2'))))
    builder.add(
        FakeFunctionDef('fake_3'))

    node = builder.get_ast()
    transformer = YieldFromTransformer()
    transformer.visit(node)
    assert isinstance(node, ast.Module)  # type: ignore
    assert len(node.body) == 2

    # Test function transformer
    builder = FakeASTBuilder()
    builder.add(
        FakeFunctionDef('fake_1',
                        builder.add(FakeFunctionDef('fake_2'))))
    builder.add(
        FakeFunctionDef('fake_3'))

   

# Generated at 2022-06-21 18:22:30.586822
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import dump_python_source


# Generated at 2022-06-21 18:22:43.427087
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    # helpers
    def check_transform(before, after, **kwargs):
        t = YieldFromTransformer(**kwargs)
        t.visit(before)
        assert before == after

    class TestYieldFromTransformer(unittest.TestCase):
        def setUp(self):
            from typed_ast import ast3 as ast
            from ..utils.snippet import snippet, let


            @snippet
            def func():
                yield_from(None)
            self.node = ast.parse('\n'.join(func.get_body()))

        def test_result_assignment_get_body(self):
            import typed_ast.ast3 as ast
            exp = result_assignment.get_body(exc='exc', target='target')
            exp_ref = ast

# Generated at 2022-06-21 18:22:46.576167
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test snippet
    code = 'def foo():\n    return a,b,c'
    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    transformed = transformer.visit(tree)
    assert transformer.tree_changed


# Generated at 2022-06-21 18:22:57.271831
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import transform

    # 'yield from' in module
    code = """
        def func():
            yield from gen()
    """
    res = """
        def func():
            generator = gen()
            exc = None
            while True:
                try:
                    yield next(generator)
                except StopIteration as exc:
                    break
    """
    assert transform(YieldFromTransformer, code) == res

    # 'yield from' in function
    code = """
        def func():
            yield from gen()
    """
    res = """
        def func():
            generator = gen()
            exc = None
            while True:
                try:
                    yield next(generator)
                except StopIteration as exc:
                    break
    """

# Generated at 2022-06-21 18:23:08.268642
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert YieldFromTransformer().visit(
        ast.parse(
            'def func():\n'
            '    a = yield from range(1, 10)\n'
        )
    ) == ast.parse(
        'def func():\n'
        '    _yf = iter(range(1, 10))\n'
        '    while True:\n'
        '        try:\n'
        '            next(_yf)\n'
        '        except StopIteration as exc:\n'
        '            a = exc.value\n'
        '            break'
    )

# Generated at 2022-06-21 18:23:38.133335
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import textwrap
    from ..utils.ast_builder import build_ast

    code = textwrap.dedent('''
    x = yield from range(10)
    ''')
    root = build_ast(code)
    transformer = YieldFromTransformer()
    transformer.visit(root)
    expected_code = textwrap.dedent('''
    let(iterable)
    iterable = iter(range(10))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            x = exc.value
            break
    ''')
    assert expected_code.strip() == transformer.dumps().strip()



# Generated at 2022-06-21 18:23:43.862496
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...tests.test_backends import assert_backend
    from ...tests.utils.asserts import assert_ast

    src = """
    yield from foo
    """

    expected = """
    for _ in foo:
        yield next(_)
    """

    assert_backend(src, YieldFromTransformer, expected)
    assert_ast(expected)


# Generated at 2022-06-21 18:23:53.172252
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astunparse import dump
    try:
        from _ast import PyCF_ONLY_AST
    except ImportError:
        PyCF_ONLY_AST = 0

    tree = ast.parse('yield from iter(x)', mode='eval')
    as_string = dump(tree)
    assert as_string == '<ast.Expression object at 0x10f70b208>'
    expected_tree = ast.parse('(yield from iter(x))')
    expected_as_string = dump(expected_tree)
    assert expected_as_string == 'yield from iter(x)'

    # test empty tree
    tree = ast.parse('', mode='eval')
    expected_tree = ast.parse('(yield from iter(x))')
    expected_as_string = dump(expected_tree)
   

# Generated at 2022-06-21 18:23:58.632246
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = """
        def f():
            yield from g()
    """

    expected = """
        def f():
            it = iter(g())
            while True:
                try:
                    yield next(it)
                except StopIteration:
                    break
    """

    tree = ast.parse(source)
    node = YieldFromTransformer(tree, [])
    assert str(node) == expected

# Generated at 2022-06-21 18:24:08.810550
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:24:14.569691
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_astunparse import unparse
    from typed_ast.ast3 import FunctionDef

    def test(funcdef: FunctionDef, exp=None):
        y = YieldFromTransformer()
        res = y.visit(funcdef)
        if exp is not None:
            assert unparse(res) == exp


# Generated at 2022-06-21 18:24:19.774119
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures import function_def_body
    from ..utils.helpers import dump, compiles_to

    def test(func, expected):
        tree = ast.parse(func)
        YieldFromTransformer().visit(tree)
        assert compiles_to(dump(tree), expected)


# Generated at 2022-06-21 18:24:29.376494
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from nope.transformations import YieldFromTransformer
    import ast
    code = """def foo():\n    yield from bar()"""
    E = ast.parse(code, mode='exec')
    E = YieldFromTransformer().visit(E)
    print('YieldFromTransformer:\n', E)
    return E

# Unit test: optional test of AST transformations
if __name__ == '__main__':
    import ast
    import sys
    import time
    from nope import transforms
    from nope.transformations import Pipeline
    from sand import compile_single
    from sand import disassemble
    from sand import interpret
    from sand import transform
    from sand.compiler import Compiler
    from sand.transformations import PipelineTransformation

    # Build test unit
    target = sys.argv[1]
   

# Generated at 2022-06-21 18:24:30.671469
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print(YieldFromTransformer)


# Generated at 2022-06-21 18:24:35.919446
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase
    test = BaseNodeTransformerTestCase(
        transformer_class=YieldFromTransformer,
        module_test='test.test_yield',
        suffix='_yield_from'
    )
    test.test__visit_method()

# Generated at 2022-06-21 18:25:26.774857
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import SourceNode
    assert YieldFromTransformer(SourceNode()).visit(
        ast.parse('yield from foo()')) == ast.parse(
        'result = None\nwhile True:\n    try:\n        result = next(iter(foo()))\n    except StopIteration as exc:\n        if hasattr(exc, \'value\'):\n            result = exc.value\n        break')

# Generated at 2022-06-21 18:25:36.361416
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import _ast
    from .base import dump_ast
    from ..utils.helpers import load_ast

    code = '''
    def f():
        x = yield from (1, 2)
        yield from (1, 2)
        y = 1
        y = 2
        yield from (1, 2)
    '''

# Generated at 2022-06-21 18:25:43.648889
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...tests.testing_utils import build_and_run
    source = """
        def func(iterable):
            generator = (yield from iterable)
            yield generator

        gen = func([1, 2, 3])
        next(gen)
        next(gen)
    """
    module, _, _ = build_and_run(source, transformer_class=YieldFromTransformer)
    func = module.func
    next(func([1, 2, 3]))



# Generated at 2022-06-21 18:25:45.089132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.YieldFrom()
    b = YieldFromTransformer()
    b.visit(a)

# Generated at 2022-06-21 18:25:46.252132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with assert_raises_composition_error():
        YieldFromTransformer(None)

# Generated at 2022-06-21 18:25:47.438455
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()



# Generated at 2022-06-21 18:25:48.229679
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-21 18:25:52.829320
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import assert_equal_source
    from ..testing import run_transformer_test

    def test_transform_function(source):
        tree = ast.parse(source)
        transformer = YieldFromTransformer()
        tree = transformer.visit(tree)

        assert_equal_source(source, tree)

    run_transformer_test(YieldFromTransformer, test_transform_function)

# Generated at 2022-06-21 18:25:54.380058
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert isinstance(t, BaseNodeTransformer)


# Generated at 2022-06-21 18:25:55.201358
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None

# Generated at 2022-06-21 18:29:00.609763
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer()

# vim: set tabstop=4 shiftwidth=4 softtabstop=4 expandtab:

# Generated at 2022-06-21 18:29:05.023422
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.FunctionDef(name='spam',
                           body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                                            value=ast.YieldFrom(value=ast.Name(id='y',
                                                                               ctx=ast.Load())))])
    trans = YieldFromTransformer()
    res = trans.visit(node)
    assert isinstance(res, ast.FunctionDef)