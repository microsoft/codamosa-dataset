

# Generated at 2022-06-21 18:19:08.564980
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformerTest
    import astor
    style = "fmt"

# Generated at 2022-06-21 18:19:16.824330
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    import typing as t

    class TestClass(YieldFromTransformer):
        def visit_FunctionDef(self, node):
            return super().visit(node)

    test_code = '''
    def func(foo: list):
        yield from foo
    '''

    expected_code = '''
    def func(foo: list):
        let(iterable)
        iterable = iter(foo)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    foo = exc.value
                break
    '''

    tree = ast.parse(test_code)
    transformer = TestClass()
    new_tree = transformer.visit(tree)

    assert ast.dump

# Generated at 2022-06-21 18:19:17.459491
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:19:19.825157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _YieldFromTransformer = YieldFromTransformer()
    _YieldFromTransformer.visit()
    assert True


# Generated at 2022-06-21 18:19:20.955598
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:19:21.357857
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:30.734904
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import parse
    from .. import unpythonic as unp
    test_g = unp.genlet([1, 2, 3])
    input_ = '''
    def foo(genlet):
        a = 2
        y1 = yield from genlet
        a = y1
        y2 = yield from genlet
        return y2
    '''

# Generated at 2022-06-21 18:19:41.551448
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class FakeExpr(ast.AST):
        _fields = ['value']

    t = YieldFromTransformer()
    node = ast.Module([
        ast.FunctionDef(
            'test',
            ast.arguments([], None, None, []),
            [
                ast.Assign([ast.Name('a', ast.Store())], ast.YieldFrom(ast.List([], ast.Load()))),
                ast.Assign([ast.Name('b', ast.Store())], ast.YieldFrom(ast.List([], ast.Load()))),
                ast.Return(ast.Name('a', ast.Load()))
            ],
            [])
    ])
    body = t.visit(node).body[0].body

    assert isinstance(body[0], ast.Assign)

# Generated at 2022-06-21 18:19:48.504473
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    from ..utils.tests import make_function, make_generator
    from ..utils.snippet import insert_at

    def test_case(*args):
        source, expected = args
        tree = ast.parse(source)
        expected_tree = ast.parse(expected)
        transformer = YieldFromTransformer()
        result = transformer.visit(tree)
        assert result.body == expected_tree.body


# Generated at 2022-06-21 18:20:00.067286
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from textwrap import dedent
    import astor as astor_module
    import ast as ast_module
    # test to see if the assert fails or not
    test_tree = astor_module.parse_file(dedent('''
    def fibonacci():
        a, b = 0, 1
        while True:
            yield a
            a, b = b, a + b
    def test(a, b):
        a = b + 1
        return a + b
    test(1, 2)
    test('1', '2')
    '''), return_ast=True)
    YieldFromTransformer().visit(test_tree)
    test_result = astor_module.to_source(test_tree)

# Generated at 2022-06-21 18:20:14.874417
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        import astunparse
        import inspect
    except ImportError:
        return

    class MyClass(object):
        def __init__(self):
            self.my_field = 'Hello'

        def test(self):
            return 0

    class NewMyClass(MyClass):
        def __init__(self):
            super(NewMyClass, self).__init__()
            print(self.my_field)

        def test(self):
            print(1)
            super(NewMyClass, self).test()
            print(2)

    assert YieldFromTransformer() is not None
    assert inspect.isclass(YieldFromTransformer)

    assert astunparse.unparse(YieldFromTransformer.get_parser()) is not None

# Generated at 2022-06-21 18:20:23.109317
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    
    tree = ast.parse("""
    from typing import Iterator
    class A:
        def __iter__(self):
            for i in range(5):
                yield i**3
        def __next__(self):
            return self.__iter__()
    def test(a: A) -> Iterator:
        yield from a.__iter__()
    """)

    tr = YieldFromTransformer()
    tree = tr.visit(tree)

# Generated at 2022-06-21 18:20:24.875608
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import ast_to_str

# Generated at 2022-06-21 18:20:25.976755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	return YieldFromTransformer()

# Generated at 2022-06-21 18:20:37.642874
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformer
    from .fake_nodes import FakeNodeTransformerA
    from ..utils.tree_helper import TreeHelper

    # Setup
    input_data = ['def f():\n', '    yield from g()\n']
    expected_data = ['def f():\n', '    let(iterable)\n', '    iterable = iter(g())\n', '    while True:\n', '        try:\n', '            yield next(iterable)\n', '        except StopIteration as exc:\n', '            break\n']
    filename = 'fake_filename.py'
    tree_helper = TreeHelper(input_data, '')
    tree_helper.prepare_tree()

    yield_from_transformer = YieldFromTransformer(tree_helper)
    yield_

# Generated at 2022-06-21 18:20:39.244602
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import compile_source

# Generated at 2022-06-21 18:20:50.778815
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..unit import ast_equal
    from . import python_to_python as p2p

    code = """
        def foo():
            x = yield from 'abc'
            yield from range(x)
    """
    module = ast.parse(code)
    trans = YieldFromTransformer(module)
    p2p.fix_missing_locations(trans.visit(module))

# Generated at 2022-06-21 18:20:51.498811
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-21 18:20:52.723331
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:20:58.873125
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typing import Dict
    from static_typing.compiler.parser import parse
    from static_typing.compiler.utils import module_to_str

    input_ = "def add(a, b):\n  return a + b"
    expected_output = "def add(a, b):\n  return a + b"
    actual_output = module_to_str(parse(input_, None))
    assert actual_output == expected_output

# Generated at 2022-06-21 18:21:05.175016
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:21:16.194994
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import stmt

    fn_def = stmt.FunctionDef(
        name='func',
        args=stmt.arguments(),
        body=[],
        decorator_list=[])
    yield_from = stmt.YieldFrom(stmt.Name(id='name', ctx=stmt.Load()))

    fn_def.body.append(
        stmt.Expr(value=yield_from))
    yield_from_transformer = YieldFromTransformer()
    module = stmt.Module(body=[fn_def])
    yield_from_transformer.visit(module)
    assert yield_from_transformer.is_changed is True
    assert len(module.body) == 1
    assert len(module.body[0].body) == 1

# Generated at 2022-06-21 18:21:21.350940
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import save_tree, result_tree, assert_tree
    from . import tree

    code = """
    def f():
        yield from range(5)
        yield from range(5)
        yield from range(5)
    """

    tree = tree(code)
    result = result_tree(code)

    for node in YieldFromTransformer.find_in_tree(tree):
        node = YieldFromTransformer().visit(node)
    assert_tree(tree, result)



# Generated at 2022-06-21 18:21:22.401436
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast import parse


# Generated at 2022-06-21 18:21:29.478390
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _YieldFromTransformer = YieldFromTransformer()
    ast_tree = "def DummyFunc(seq):\n\tdef DummyGenFunc(seq):\n\t\tyield from seq\n\tseq = DummyGenFunc(seq)\n\ta, b = yield from seq\n\tprint(a, b)"
    #print(_YieldFromTransformer.visit(ast.parse(ast_tree)))



# Generated at 2022-06-21 18:21:32.985929
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('def foo(): yield from bar()')
    assert tree == YieldFromTransformer().visit(tree)

    tree = ast.parse('def foo(): yield from bar()')

# Generated at 2022-06-21 18:21:34.040651
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:21:35.436484
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet = YieldFromTransformer()

# Generated at 2022-06-21 18:21:37.112240
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import typed_astunparse
    from ast import parse
    

# Generated at 2022-06-21 18:21:39.868424
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..units import check_transformation, transform_snippet
    from ast_toolbox import ast_repr, dump


# Generated at 2022-06-21 18:21:51.001573
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:21:51.993258
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:21:52.721450
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-21 18:22:02.153906
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helpers import assert_equal_ast, parse

# Test without target
    source = "yield from foo()"
    expected = yield_from.get_ast(generator="foo()", assignment=[], exc="exc")
    assert_equal_ast(YieldFromTransformer().visit(parse(source)), expected)

# Test with target
    source = "x = yield from foo()"
    expected = yield_from.get_ast(generator="foo()", assignment=result_assignment.get_ast(exc="exc", target="x"), exc="exc")
    assert_equal_ast(YieldFromTransformer().visit(parse(source)), expected)

# Generated at 2022-06-21 18:22:03.512263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert False, "Tests for YieldFromTransformer are not implemented."

# Generated at 2022-06-21 18:22:05.965241
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)


# Generated at 2022-06-21 18:22:15.146747
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor  # type: ignore
    import textwrap
    from ..convert import Py3ToPy2Converter
    from astor import codegen

    code = textwrap.dedent('''
    def f(*args, **kwargs):      
        yield from g(1)
        x = yield from h(2)
        yield from i(3)
    ''')
    converter = Py3ToPy2Converter()
    tree = ast.parse(code)
    new_tree = converter.visit(tree)
    source = codegen.to_source(new_tree).strip()

# Generated at 2022-06-21 18:22:26.584284
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from collections import namedtuple
    from ..base import UnitTest
    from ..utils.test_utils import gen_test_example
    from ..utils.tree import parse_str

    class YieldFromTestCase(namedtuple('TestCase',
                                       ['original', 'expected']), UnitTest):
        pass


# Generated at 2022-06-21 18:22:27.718357
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:22:29.296531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        assert False


# Generated at 2022-06-21 18:22:59.725699
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_python import Function
    from .ast_conversion import ast_to_func
    from .block_transformation import BlockTransformer

    def test_func(a, b, c):
        yield from range(a)
        if b:
            yield from range(c)
        yield from range(a)

    tree = ast.parse(inspect.getsource(test_func))
    node = YieldFromTransformer().visit(tree)
    node = BlockTransformer().visit(node)

    func = ast_to_func(Function(node))
    # first yield from statement is wrapped in while loop,
    # second yield from statement remains in its place
    assert ', '.join(map(str, func(1, True, 3))[:5]) == '0, 0, 1, 2, 0'

# Generated at 2022-06-21 18:23:02.212737
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(tree = None)


# Generated at 2022-06-21 18:23:04.568657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:23:07.071292
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    from ..utils.tree import get_code
    from ..utils.parser import parse_ast


# Generated at 2022-06-21 18:23:09.513898
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    This test case tests the constructor of YieldFromTransformer class.
    '''
    test = YieldFromTransformer()
    assert test is not None


# Generated at 2022-06-21 18:23:10.994956
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..compiler import compile
    node = ast.parse("result = yield from range(10)")
    transformer = YieldFromTransformer()
    transformed = transformer.visit(node)
    compiled = compile(transformed)
    exec(compiled)
    assert result == 9

# Generated at 2022-06-21 18:23:15.800338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    obj.visit([ast.Assign([ast.Name(id = 'a', ctx = ast.Store())], value = ast.YieldFrom(value = ast.Num(n = 1))),
               ast.Expr(value = ast.YieldFrom(value = ast.Num(n = 1)))])


# Generated at 2022-06-21 18:23:21.750319
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .generator import GeneratorTransformer
    from typed_ast.ast3 import parse
    from .utils.helpers import VariablesGenerator
    from .utils.tree import get_body

    class DummyNodeTransformer(BaseNodeTransformer):

        def visit_Expr(self, node: ast.Expr) -> ast.AST:
            node.value = ast.Str('DUMMY')
            return node


# Generated at 2022-06-21 18:23:23.504371
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Assert that the class initializes properly
    tr = YieldFromTransformer()

# Generated at 2022-06-21 18:23:26.570902
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.codegen import to_source
    from ..pipeline import Pipeline
    import astor


# Generated at 2022-06-21 18:24:12.054573
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)



# Generated at 2022-06-21 18:24:22.854732
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_equal_ignore_ws, parse_to_ast

    transformer = YieldFromTransformer()
    tree = parse_to_ast("""
    lst = [1, 2, 3]
    lst2 = (x for x in lst)
    yield from lst
    yield from lst2
    x = yield from lst2
    """)
    code = compile(transformer.visit(tree), '<string>', 'exec')
    exec(code)

# Generated at 2022-06-21 18:24:33.646301
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import List
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Assign, Expr, YieldFrom
    from ..utils.testing import get_single_node

    assign_yield_from_node = Assign(targets=[
        ast.Name(id='result', ctx=ast.Store()),
        ], value=YieldFrom(value=ast.Name(id='gen', ctx=ast.Load())))
    exp_yield_from_node = Expr(value=YieldFrom(value=ast.Name(id='gen', ctx=ast.Load())))
    module = get_single_node(
        assign_yield_from_node, exp_yield_from_node, assign_yield_from_node
        )

# Generated at 2022-06-21 18:24:36.067895
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Generic test to test if the class was constructed correctly
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)

# Generated at 2022-06-21 18:24:37.826035
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None, 'Unit test failed'


# Generated at 2022-06-21 18:24:48.028966
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.fake_file import FakeFile
    from ..utils.fake_context import FakeContext
    from ..utils.helpers import FakeFileMixin
    from ..utils.tree_compiler import TreeCompiler

    result = TreeCompiler(
        context=FakeContext(),
        file=FakeFile('a = yield from get_iterator()')
    ).get_ast()

    fake_file = FakeFileMixin.get_content(result)

# Generated at 2022-06-21 18:24:49.099602
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	y = YieldFromTransformer()


# Generated at 2022-06-21 18:24:52.763656
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    from typed_ast.ast3 import parse

    class TestYieldFromTransformer(YieldFromTransformer):
        # Method visit overridden
        pass


# Generated at 2022-06-21 18:24:55.475672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # unit test for constructor of class YieldFromTransformer
    x = YieldFromTransformer()
    assert x is not None

# Generated at 2022-06-21 18:25:04.083553
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor, typed_ast.ast3, typed_astunparse
    # Build AST for:
    # def foobar():
    #     a = yield from b
    #     yield from c
    exp1 = typed_ast.ast3.YieldFrom(
        value=typed_ast.ast3.Name(id='b', ctx=typed_ast.ast3.Load())
    )
    exp2 = typed_ast.ast3.YieldFrom(
        value=typed_ast.ast3.Name(id='c', ctx=typed_ast.ast3.Load())
    )


# Generated at 2022-06-21 18:27:06.545839
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    input_str = """
    while True:
        a = yield from f()
        b = yield from g()
        yield c
    """
    expected_result = """
    while True:
        let(iterable)
        iterable = iter(f())
        while True:
            try:
                a = next(iterable)
            except StopIteration as exc:
                break
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                b = next(iterable)
            except StopIteration as exc:
                break
        yield c
    """
    transformer = YieldFromTransformer()
    tree = ast.parse(input_str)
    transformed_tree = transformer.visit(tree)
    result = ast.unparse(transformed_tree)

# Generated at 2022-06-21 18:27:12.609849
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_snippet
    snippet_ = """
    a = (yield from range(10))
    """
    expected_ = """
    let(iterable)
    iterable = iter(range(10))
    while True:
        try:
            a = next(iterable)
            yield a
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                a = exc.value
            break
    """
    assert_snippet(snippet_, expected_, YieldFromTransformer)

# Generated at 2022-06-21 18:27:14.363211
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:27:15.510232
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast.ast3 as ast



# Generated at 2022-06-21 18:27:17.619943
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast_helper import parse, equal_ast, dump

# Generated at 2022-06-21 18:27:28.110111
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.resolver import resolve_names

    try_body = [ast.Expr(ast.YieldFrom(ast.Name(id='A', ctx=ast.Load())))]
    try_handler = ast.ExceptHandler(None, None, try_body)
    try_stmt = ast.Try(try_body, [try_handler], [], [])


# Generated at 2022-06-21 18:27:39.906216
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from nuitka.nodes.AssignNodes import (
        ExpressionTargetVariableRef,
        ExpressionTargetTempVariableRef,
    )
    from nuitka.nodes.BuiltinIteratorNodes import ExpressionBuiltinIter1
    from nuitka.nodes.ConditionalNodes import ExpressionConditional
    from nuitka.nodes.ContainerMakingNodes import (
        ExpressionListOperationAppend,
        ExpressionListOperationExtend,
        ExpressionListOperationPop,
        ExpressionListOperationRemove,
        ExpressionListOperationSort,
    )
    from nuitka.nodes.ConstantRefNodes import ExpressionConstantRef
    from nuitka.nodes.DictionaryNodes import StatementDictOperationSet, StatementDictOperationSetKeyValuePair

# Generated at 2022-06-21 18:27:41.310702
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor


# Generated at 2022-06-21 18:27:47.029323
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.YieldFrom(None)
    ac = YieldFromTransformer.convert(a)
    assert ac is None
    assert not a.is_changed

    # YieldFromTransformer.visit is not supported by typed_ast
    #
    # b = ast.FunctionDef()
    # b.body = [a]
    # bc = YieldFromTransformer.convert(b)
    # assert len(bc.body) == 1
    # assert bc.is_changed

# Generated at 2022-06-21 18:27:56.882494
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test_function():
        yield_from [1]
        yield_from [2]
    test_function = YieldFromTransformer().visit(test_function)
    assert test_function.__code__.co_flags & 0x20 == 0x20
    assert test_function.__code__.co_code == b'\x84\x83}\x01\x00|\x00\x00}\x02\x00|\x01\x00}\x03\x00\x83\x17\x02\x82\x01\x00\x83\x00}\x01\x00|\x00\x00\x84|\x01\x00\x83S\x00}'
    assert test_function.__code__.co_consts == (None, {}, 1, 2)