

# Generated at 2022-06-21 18:19:05.088642
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:13.138819
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom(ast.Constant(0))
    assign = ast.Assign([ast.Name(id='var', ctx=ast.Store())], yield_from)
    expr = ast.Expr(yield_from)
    module = ast.Module([assign, expr])
    from ..transformers.yield_from import YieldFromTransformer

    trans = YieldFromTransformer()
    result = trans.visit(module)
    print(result)



# Generated at 2022-06-21 18:19:24.698237
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    #
    # test for function yield_from(generator, exc, assignment)
    #
    code = "yield_from(a)"
    expected_code = "iterable = iter(a)\nwhile True:\n    try:\n        yield next(iterable)\n    except StopIteration as exc:\n        break\n"
    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert expected_code == astor.to_source(tree)
    #
    # test for variable f yield_from(a)
    #
    code = "f = yield_from(a)"

# Generated at 2022-06-21 18:19:32.411814
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from typed_ast.transforms.YieldFromTransformer import YieldFromTransformer
    from typed_ast.transforms.YieldFromTransformer import yield_from
    from typed_ast.transforms.YieldFromTransformer import result_assignment
    from ..utils import helpers

    # testing if_stmt

    class Test():
        def generator(self):
            yield True
            yield False

        def test(self):
            if (yield from self.generator()):
                pass

    ast_new = helpers.ast_from_class(Test)

    transformer = YieldFromTransformer()
    transformer.visit(ast_new)

    exc = '_typed_ast_transform_exc'
    generator = '_typed_ast_transform_generator'
    iter

# Generated at 2022-06-21 18:19:35.611800
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
       YieldFromTransformer
       YieldFromTransformer()
    except:
       raise Exception("Unit test for constructor of class YieldFromTransformer has failed.")

# Generated at 2022-06-21 18:19:43.220883
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import parse_to_ast, assert_source
    mod = """
a = yield from b
yield from c
"""
    expected = """
let(exc)
let(iterable)
iterable = iter(b)
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        break
let(exc)
let(iterable)
iterable = iter(c)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        break
"""
    mod_ast = parse_to_ast(mod)
    result_ast = YieldFromTransformer().visit(mod_ast)
    assert_source(expected, result_ast)

# Generated at 2022-06-21 18:19:44.502694
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor


# Generated at 2022-06-21 18:19:55.500178
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    import astor
    import astunparse
    from textx.scoping import Postponed
    from ..utils import helpers
    from ..transformer import Transformer

    parser = helpers.get_parser('./test/support/yield-from.ty')
    expected_parser = helpers.get_parser('./test/support/yield-from-transformed.py')

    input_source = textwrap.dedent('''
    ''')

    source = parser.parse(input_source)

    trans = Transformer(YieldFromTransformer)
    source = trans.visit(source)

    expected_source = expected_parser.parse('''
    ''')


# Generated at 2022-06-21 18:20:07.320370
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..dump import dump

    code = """
    def gen():
        print('a')
        yield 1
        print('b')
        yield 2
        print('c')

    def f():  # yeah
        a = yield from gen()
        print('done', a)

    def g():  # yeah
        yield from gen()

    def h():  # yeah
        yield from gen() + [1, 2, 3]
    """
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    assert len(set(dump(tree))) == 1

# Generated at 2022-06-21 18:20:17.486899
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import Try, Expr, YieldFrom, Module, parse
    from .base import BaseNodeTransformerTest, node_equals

    class YieldFromTransformerTest(YieldFromTransformer, BaseNodeTransformerTest):
        pass

    code = '''def foo():
        try:
            a = yield from [1, 2, 3]
            b = yield from [4, 5, 6]
        except:
            pass'''
    parsed = parse(code)
    trans = YieldFromTransformerTest()
    trans.visit(parsed)
    root = trans._get_root()


# Generated at 2022-06-21 18:20:24.426340
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-21 18:20:36.013271
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typing import Optional
    from typed_ast import ast3 as ast
    from ..utils.tree import insert_at

    def test_YieldFromTransformer_get_yield_from_index():
        def _get_yield_from_index(node: ast.AST,
                                  type_: Optional[ast.AST]) -> Optional[int]:
            if hasattr(node, 'body') and isinstance(node.body, list):
                for n, child in enumerate(node.body):
                    if type_ is None:
                        if isinstance(child, ast.YieldFrom):
                            return n
                    else:
                        if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                            return n
            return None


# Generated at 2022-06-21 18:20:47.643581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import NodeTransformer
    from inspect import getmembers
    from ast import Assign, Expr, YieldFrom, Name, Call, FunctionDef, Module
    from ast import AST, parse as ast_parse, dump as ast_dump
    from io import StringIO
    code = '''
    def f():
        a = yield from g()
        yield from g()
        yield from g()
        yield from g()
        yield from g()
    '''
    def parse(code: str, **kwargs) -> Module:
        return ast_parse(code, **kwargs)

    def dump(node: AST) -> str:
        return ast_dump(node)

    def func_name(func) -> str:
        return func.__name__


# Generated at 2022-06-21 18:20:58.070091
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os
    import sys
    import unittest
    sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))

    from unittest.mock import Mock, patch
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer
    from ..utils.snippet import snippet, let, extend

    class _test(unittest.TestCase):
        def test(self):
            m = Mock(spec=YieldFromTransformer)
            m._get_yield_from_index.return_value = None

# Generated at 2022-06-21 18:20:59.853143
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..unit_test import get_path
    from ..utils.helpers import parse_ast

# Generated at 2022-06-21 18:21:11.029242
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from typed_ast.ast3 import Return, FunctionDef, Yield, YieldFrom, Expr, If, While, For, Try, Name

    source = """
    def foo():
        yield from bar()
        while True:
            yield from bar()
            if True:
                yield from bar()
            else:
                yield from bar()
            for _ in bar():
                yield from bar()
        try:
            yield from bar()
        except:
            yield from bar()
        return yield from bar()
    """


# Generated at 2022-06-21 18:21:20.592498
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ast_test_case import AstTestCase
    transformer = YieldFromTransformer()

    def test_visit_Assign(self):
        node = ast.parse('a = yield from foo()').body[0]
        node = transformer.generic_visit(node)  # type: ignore
        expected = ast.parse('''
a = next(iterable)
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break
''').body[0]
        assert astor.to_source(expected) == astor.to_source(node)

    def test_visit_Expr(self):
        node = ast.parse('yield from foo()').body

# Generated at 2022-06-21 18:21:21.893390
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert bool(YieldFromTransformer) == True


# Generated at 2022-06-21 18:21:23.282478
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    assert YieldFromTransformer()
    '''


# Generated at 2022-06-21 18:21:34.830879
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.fake import FakeFile
    from ..utils.helpers import dump

    code = """\
a = yield from
e = yield from
f = d = yield from
d = yield from
"""

# Generated at 2022-06-21 18:21:48.166280
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(3, 3)


# Generated at 2022-06-21 18:21:56.202600
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import transformer as _transformer
    from .. import utils as _utils
    from ..utils import load_module
    import sys as _sys
    import re as _re
    _transformer.register(_utils.get_full_name(YieldFromTransformer()))
    _sys.path.append('tests/test_programs/')

# Generated at 2022-06-21 18:21:56.773747
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:21:58.072090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    visitor = YieldFromTransformer(False, False, False)

# Generated at 2022-06-21 18:22:09.258113
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from nuitka.nodes.AssignmentNodes import ExpressionTargetTempVariableRef
    from nuitka.nodes.YieldNodes import ExpressionYield
    from nuitka.nodes.YieldNodes import ExpressionYieldFrom

    foo = ExpressionTargetTempVariableRef(variable = ExpressionTempVariableRef(variable = ExpressionTempVariableRef(variable = ExpressionTempVariableRef(variable = None))))
    bar = ExpressionTargetTempVariableRef(variable = ExpressionTempVariableRef(variable = ExpressionTempVariableRef(variable = ExpressionTempVariableRef(variable = None))))
    raising = ExpressionYield(expression = ExpressionYieldFrom(yield_from = ExpressionTempVariableRef(variable = None)))
    catcher = ExpressionYield(expression = ExpressionYieldFrom(yield_from = ExpressionTempVariableRef(variable = None)))

# Generated at 2022-06-21 18:22:10.271130
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:22:17.518785
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:22:23.971156
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...test.test_pipelines import visit_test_data
    from ...utils.source import source_to_unicode
    from ...stages.to_typed_ast import ToTypedAst
    from ...stages.from_typed_ast import FromTypedAst
    from ..constants import DJANGO_30_LATEST


# Generated at 2022-06-21 18:22:35.933693
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import test_utils

    tree_before = """
if x:
    y = yield from a
    a = yield from b
    print((yield from c))
else:
    a = yield from d
    s = a + yield from e
"""


# Generated at 2022-06-21 18:22:40.537941
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse, Try, If, While, For, FunctionDef, Module, Assign, Expr
    from ast_helpers.extract import iter_nodes
    from pytest import raises
    from typed_ast.ast3 import Name

# Generated at 2022-06-21 18:23:13.867266
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse('''class A(object):
    def foo(self):
        while True:
            result = yield from [1, 2, 3]
            yield result
        else:
            result = yield from iter([])
            yield result''')
    transformer = YieldFromTransformer()
    module = transformer.visit(module)
    assert transformer.changed()

# Generated at 2022-06-21 18:23:15.073993
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:23:15.920576
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:23:26.617789
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.fixtures import tree_from_func
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer
    from ..utils.tree import dict_to_node
    from ..tests.fixtures import run_transformer_test

    @run_transformer_test
    def do_test():
        def test_func(a, b) -> float:
            c = a + b
            d = yield from (1 for _ in c)
            c = yield from c
            d = yield from (1 for _ in c)
            return c * d * 2

        test_tree = tree_from_func(test_func)
        transformer = YieldFromTransformer()
        transformer.visit(test_tree)
        transformer.generic_visit(test_tree)
        return test_tree

# Generated at 2022-06-21 18:23:27.837215
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(None)
    assert transformer


# Generated at 2022-06-21 18:23:28.377746
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-21 18:23:28.917788
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:23:29.994095
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass #implemented in test_base.py

# Generated at 2022-06-21 18:23:38.328030
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = """
        try:
            yield from x
        except SequenceError as e:
            pass
    """
    expected = """
        try:
            iterable = iter(x)
        except SequenceError as e:
            pass
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, "value"):
                    exc = exc.value
            break
    """
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    assert expected == astunparse.unparse(tree)

# Generated at 2022-06-21 18:23:43.947448
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class A(object):
        def __init__(self):
            self.value = 5
            self.name = "Sam"
    assert YieldFromTransformer()._get_yield_from_index(A(), ast.Assign) is None
    assert YieldFromTransformer()._get_yield_from_index(A(), ast.Expr) is None

# Generated at 2022-06-21 18:24:39.601792
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_cases import TestCase, BlockTestCase
    from ..utils.test_utils import transform

    @snippet
    def source(a: int) -> int:
        yield from [1, 2]

    @snippet
    def expected(a: int) -> int:
        let(iterable1)
        iterable1 = iter([1, 2])
        while True:
            try:
                yield next(iterable1)
            except StopIteration as exc1:
                if hasattr(exc1, 'value'):
                    exc1 = exc1.value
                break

    case = TestCase(source, expected)

    @snippet
    def source(a: int) -> int:
        x = yield from [1, 2]


# Generated at 2022-06-21 18:24:50.543638
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Setup a test case with a statement, which is not actually executable.
    # The test case is there to check the result,
    # and not the correctness of the generated code.
    code = """
    def test_func(result):
        res = yield from result  # This is the statement that should be transformed
    """
    result = YieldFromTransformer().visit(parse(code).body[0])
    assert result.body[0].value.body == [
        ast.Name(id='exc', ctx=Load()),
        ast.Assign(targets=[ast.Name(id='result', ctx=Store())], value=ast.Name(id='exc', ctx=Load()))
    ]
    assert isinstance(result.body[0].value.body[0], ast.expr)

# Generated at 2022-06-21 18:24:51.483016
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-21 18:24:52.318248
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:58.364869
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = '''
        def foo():
            yield from bar()
        '''
    expected_source = '''
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        '''
    assert expected_source == YieldFromTransformer.run(source)



# Generated at 2022-06-21 18:25:07.022920
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.utils import make_test_module
    from ..utils.helpers import compare_ast
    from .transformer import TransformerList

    transformer = TransformerList([YieldFromTransformer()])
    new_module = make_test_module(transformer)

# Generated at 2022-06-21 18:25:18.455339
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = '''
        def foo():
            yield from bar()
            yield from baz()
        '''

# Generated at 2022-06-21 18:25:19.350987
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:25:30.270493
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Arrange
    from typed_ast.transforms import YieldFromTransformer

    transformed_ast = ast.parse(
        """def f():
    for x in ['a']:
        yield from x""")
    og_ast = ast.parse(
        """def f():
    for x in ['a']:
        let(iterable)
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break""")

    # Act
    transformed_ast = ast.fix_missing_locations(transformed_ast)
    YieldFromTransformer().visit(transformed_ast)
    transformed_ast = ast.fix_missing_locations(transformed_ast)

    og_ast = ast.fix_missing_locations

# Generated at 2022-06-21 18:25:32.703012
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test YieldFromTransformer constructor"""
    try:
        YieldFromTransformer()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-21 18:27:41.863632
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-21 18:27:49.300455
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from typing import Union
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    class YieldFromTransformer(BaseNodeTransformer):
        """Compiles yield from to special while statement."""
        target = (3, 2)

# Generated at 2022-06-21 18:27:57.832262
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code1 = """
    def foo():
        yield from [1, 2]

    def bar():
        for item in [1, 2, 3]:
            yield from foo()
    """

    code2 = """
    yield from foo()
    """

    code3 = """
    a = yield from foo()
    """

    code4 = """
    if True:
        yield from [1, 2, 3]
    """

    code5 = """
    while True:
        yield from foo()
    """

    code6 = """
    try:
        yield from [1, 2, 3]
    except:
        pass

    finally:
        yield from foo()
    """

    code7 = """
    def foo():
        yield from bar()
        yield from baz()
    """


# Generated at 2022-06-21 18:28:06.726362
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astor.code_gen import to_source
    from .fake_nodes import FakeTry
    from .fake_nodes import FakeExpr
    from .fake_nodes import FakeAssign
    from .fake_nodes import FakeYieldFrom
    from .fake_nodes import FakeModule

    # Before: try: ... except Exception: ...

    body = FakeTry(body=FakeExpr(FakeYieldFrom()))
    modified_tree = YieldFromTransformer().visit(body)
    expected_tree = FakeTry(body=FakeExpr(FakeYieldFrom()))
    assert to_source(modified_tree) == to_source(expected_tree)

    # Before: try: ... except Exception: a = b

    body = FakeTry(body=FakeAssign(FakeYieldFrom()))

# Generated at 2022-06-21 18:28:07.982153
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:28:10.655330
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        transformer = YieldFromTransformer()
    except Exception as e:
        assert type(e) is TypeError
        print("TypeError has been caught")

# Generated at 2022-06-21 18:28:22.331724
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse('''
    try:
        yield from 1
    except:
        a = 2
    ''')  # type: ast.Module
    node = YieldFromTransformer().visit(node)
    assert node == ast.parse('''
    iterable = iter(1)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            a = exc.value
            break
    ''')


if __name__ == '__main__':
    node = ast.parse('''
    try:
        try:
            yield from 1
        except:
            yield from 2
    except:
        a = 2
    ''')
    print(node)
    node = YieldFromTransformer().visit(node)

# Generated at 2022-06-21 18:28:29.009873
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3
    from .clean_up_line_jumps import CleanUpLineJumps
    from .clean_up_imports import CleanUpImports
    from .standard_transforms import StandardTransforms
    from .local_transforms import LocalTransforms

    def check(before, after):
        transformer = YieldFromTransformer()
        result = transformer.visit(ast3.parse(before))
        result = CleanUpLineJumps().visit(result)
        result = CleanUpImports().visit(result)
        result = LocalTransforms().visit(result)
        result = StandardTransforms(transformer.target).visit(result)
        assert str(result) == after


# Generated at 2022-06-21 18:28:29.833577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-21 18:28:36.050120
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from nicelib.nice.yield_from import YieldFromTransformer

    def compare(src, result):
        module = ast.parse(dedent(src))
        module = YieldFromTransformer().visit(module)
        assert module == ast.parse(dedent(result))

    compare("""
    def test(x):
        yield from x
    """, """
    def test(x):
        exc = __expr_0__
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                pass
                break
    """)
