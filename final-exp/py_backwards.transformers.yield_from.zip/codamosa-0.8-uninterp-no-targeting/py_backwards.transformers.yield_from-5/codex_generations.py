

# Generated at 2022-06-21 18:19:16.696008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(hasattr(YieldFromTransformer, '__init__'))
    assert(hasattr(YieldFromTransformer, 'target'))
    assert(hasattr(YieldFromTransformer, '_get_yield_from_index'))
    assert(hasattr(YieldFromTransformer, '_emulate_yield_from'))
    assert(hasattr(YieldFromTransformer, '_handle_assignments'))
    assert(hasattr(YieldFromTransformer, '_handle_expressions'))
    assert(hasattr(YieldFromTransformer, 'visit'))
    x = YieldFromTransformer()
    x.visit('string')
    x._get_yield_from_index(ast,'Type')
    x._emulate_yield_from(ast,'node')
   

# Generated at 2022-06-21 18:19:27.446823
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ast_helper import cmp_source
    tree = ast.parse('bar = foo()\n'
                     'yield from bar\n'
                     'f = yield from bar\n'
                     'yield from bar\n'
                     'yield from foo()\n')
    module = YieldFromTransformer().visit(tree)

# Generated at 2022-06-21 18:19:36.085886
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        ast.parse('1')
    except Exception as e:
        print(e)
    else:
        pass
    finally:
        pass
    yield_from_transformer = YieldFromTransformer()
    assert isinstance(yield_from_transformer, YieldFromTransformer)
    assert isinstance(yield_from_transformer, BaseNodeTransformer)
if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:19:43.550796
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    code = """
    def method_1():
        i = yield from (1, 2)
    def method_2():
        yield from (1, 2)
    def method_3():
        yield from 1
    """
    expected = """
    def method_1():
        while True:
            try:
                yield next(iter(1, 2))
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    i = exc.value
                break

    def method_2():
        while True:
            try:
                yield next(iter(1, 2))
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc.value
                break

    def method_3():
        yield from 1

    """
    tree = ast.parse

# Generated at 2022-06-21 18:19:52.591917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = """
        async def async_func(a):
            yield from a
    """
    expected = """
        async def async_func(a):
            let(iterable)
            iterable = iter(a)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
    """
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    result = compile(tree, __file__, "exec")
    assert expected == inspect.getsource(result).strip()

# Generated at 2022-06-21 18:20:03.718632
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import parse_str
    from ..utils.helpers import isvalid
    from ..utils.fstrings import FStrings
    # Test for illegal input
    code1 = '''
    a = 1
    a = yield from b
    '''
    tree = parse_str(code1)
    assert isvalid(tree)

    trans = FStrings(tree)
    out1 = trans.get_source()
    trans = YieldFromTransformer(tree)
    out2 = trans.get_source()
    assert out1 == out2

    # Test for illegal input
    code1 = '''
    a = 1
    yield from b
    '''
    tree = parse_str(code1)
    assert isvalid(tree)

    trans = FStrings(tree)
    out1 = trans.get

# Generated at 2022-06-21 18:20:10.533806
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:20:11.694224
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None


# Generated at 2022-06-21 18:20:18.118567
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): 
    # Init
    node_ = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.YieldFrom(value=ast.Name(id='iterable', ctx=ast.Load()), ctx=ast.Load()))
    node__ = ast.Expr(value=ast.YieldFrom(value=ast.Name(id='iterable', ctx=ast.Load()), ctx=ast.Load()))
    
    # Assignments
    assert isinstance(node_, ast.Assign)
    assert isinstance(node__, ast.Expr)
    
    # Init of class YieldFromTransformer
    yield_from_transformer = YieldFromTransformer()
    
    # name

# Generated at 2022-06-21 18:20:19.874676
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer.__doc__
    x = 5

test_YieldFromTransformer()

# Generated at 2022-06-21 18:20:36.447121
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse('def func():\n yield from iter(range(5))\n')
    visitor = YieldFromTransformer()
    new_ast = visitor.visit(module)

# Generated at 2022-06-21 18:20:48.022123
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    target_code = """
        def g(m, n):
            while n > 0:
                yield m
                n -= 1
        def f():
            a = yield from g(1, 2)
            b = yield from g(2, 3)
    """

# Generated at 2022-06-21 18:20:49.820084
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import test_nodes


# Generated at 2022-06-21 18:21:00.287585
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""
    import typed_astunparse
    from .constant import ConstantTransformer

    class TestYieldFromTransformer(YieldFromTransformer):
        @property
        def constants(self) -> ConstantTransformer:
            raise NotImplementedError

    class TestConstantsTransformer(ConstantTransformer):
        def visit_List(self, node: ast.List) -> ast.AST:
            return node

        def visit_Tuple(self, node: ast.Tuple) -> ast.AST:
            return node

    constants = TestConstantsTransformer()
    constants.visit = constants.generic_visit
    transformer = TestYieldFromTransformer(constants)
    transformer.visit = transformer.generic_visit


# Generated at 2022-06-21 18:21:00.911134
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:21:11.775936
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import ast_printer
    from ..utils.helpers import VariablesGenerator
    node = ast.parse('yield from 1')
    transformer = YieldFromTransformer()
    new_node = transformer.visit(node)
    assert ast_printer.dumps(new_node) == """def _py_inline_0():
    yield from 1
if __name__ == '__main__':
    exc = None
    iterable = iter(_py_inline_0())
    while True:
        try:
            _py_inline_1 = next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                _py_inline_1 = exc.value
            break
        yield _py_inline_1
"""

# Generated at 2022-06-21 18:21:13.227911
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer


# Generated at 2022-06-21 18:21:22.074877
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitors import print_tree
    from ..utils.compare_ast import compare_ast

    from .yield_from_to_while import transform_yield_from_to_while
    from .yield_from_to_raise_stop_iteration import transform_yield_from_to_raise_stop_iteration
    from .yield_from_to_generator import transform_yield_from_to_generator

    code = """
        values = []
        while True:
            try:
                values.append(next(iterable))
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    inner_iterator = exc.value
                break
        return inner_iterator
    """

# Generated at 2022-06-21 18:21:33.187719
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    # Test, when yield from is used in function as expression
    @snippet
    def test_yield_from_expression(a):
        yield from a

    tree = ast.parse(test_yield_from_expression)
    new_node = YieldFromTransformer().visit(tree)

    iterable = VariablesGenerator.generate('iterable')
    exc = VariablesGenerator.generate('exc')
    expected = yield_from.get_body(generator='a',
                                   assignment=[result_assignment.get_body(exc=exc,
                                                                         target=exc.value)],
                                   iterable=iterable,
                                   exc=exc)
    assert new_node.body[0].body[0] == expected[0]

# Generated at 2022-06-21 18:21:36.973832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet = """
    def foo():
        a = yield from bar()
    """
    node = ast.parse(snippet)
    # If a == 0 at the end of snippet then it works
    YieldFromTransformer().visit(node) == 0

# Generated at 2022-06-21 18:21:49.768426
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.messages import MessagesHolder
    from ..utils.asserts import assert_ast

    source = """def foo():
    a, b = yield from bar()"""

    expected = """def foo():
    let(iterable)
    iterable = iter(bar())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            a, b = exc.value
            break"""

    # TODO: fix placeholders set
    with MessagesHolder() as mh:
        assert_ast(source, expected, YieldFromTransformer, ())



# Generated at 2022-06-21 18:22:00.606669
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typing import cast

    from typed_ast import ast3
    from typed_ast.ast3 import YieldFrom
    from typed_ast import py_compile

    from ..utils.helpers import load_module, dump_module

    yfts = YieldFromTransformer([])

    m = isinstance(ast3.parse("x = y"), ast3.AST)
    assert m, "ast3.parse('x = y') should be of class AST"

    m = load_module(__file__, 'targets/yield_from.py')
    assert isinstance(m, ast.Module), "Type of m is %s" % type(m)
    yfts.visit(m)

    # TODO: Check that the output is reasonable
    m = dump_module(m)


# Generated at 2022-06-21 18:22:04.882292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    parsed = ast.parse(source)

    from ..dump import dump

    dump(parsed)

    transformed = YieldFromTransformer().visit(parsed)

    # TODO: uncomment when fixed
    # assert transformed != parsed
    dump(transformed)

# Generated at 2022-06-21 18:22:07.479779
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import get_test_nodes


# Generated at 2022-06-21 18:22:08.110276
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-21 18:22:09.500327
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-21 18:22:10.078533
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer([1])) == YieldFromTransformer

# Generated at 2022-06-21 18:22:11.385583
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)

# Generated at 2022-06-21 18:22:12.265113
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:22:23.657017
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    py_ast = ast.parse('a = yield from [1, 2, 3]', mode='exec')
    node_transformer = YieldFromTransformer()
    out = node_transformer.visit(py_ast)
    result = ast.dump(out)

# Generated at 2022-06-21 18:22:35.534676
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-21 18:22:38.821526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import M
    from ..tree_transforms import YieldFromTransformer


# Generated at 2022-06-21 18:22:39.933699
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:22:47.646488
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..transpilers import Transpiler
    from ..utils.helpers import load_module_ast

    code = """
    def f():
        yield from (1 for _ in range(3))
    """

    local_vars = {}
    exec(code, {}, local_vars)

    result = Transpiler([YieldFromTransformer()]).transpile_module(local_vars['f'])
    expected = load_module_ast("""
    def f():
        iterable = iter((1 for _ in range(3)))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)

    assert result == expected

# Generated at 2022-06-21 18:22:48.818247
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:22:59.117057
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:23:10.681808
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    def test__emulate_yield_from(target,
                                 node):
        yield_from = YieldFromTransformer()
        gen = yield_from._emulate_yield_from(target, node)
        return list(gen)


    yield_from = ast.parse('yield from 1').body[0].value

# Generated at 2022-06-21 18:23:20.565109
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #first test case
    input_code = """yield from some_generator"""
    input_ast = ast.parse(input_code)
    expected_code = """
iterable = iter(some_generator)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            exc.value
        break"""
    expected_ast = ast.parse(expected_code)
    transform = YieldFromTransformer(input_code, input_ast)
    actual_ast = transform.visit(input_ast)
    assert ast.dump(actual_ast) == ast.dump(expected_ast)

    #second test case
    input_code = """yield from some_generator + 1"""

# Generated at 2022-06-21 18:23:30.419008
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    generator_visitor = YieldFromTransformer()
    test_tree = ast.parse(
        """
        def foo():
            yield from range(3)
            return 42
        """
    )
    expected = ast.parse(
        """
        def foo():
            let(iterable)
            iterable = iter(range(3))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
            return 42
        """
    )
    generator_visitor.visit(test_tree)
    diff = ast.dump(test_tree) == ast.dump(expected)
    assert diff, "Yield from is not supported"


# Generated at 2022-06-21 18:23:31.365464
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:23:41.274531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    

# Generated at 2022-06-21 18:23:42.490512
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-21 18:23:49.604414
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import compare_source

    tree = ast.parse('''
    def foo():
        yield from range(10)
        yield 3
    ''')
    expected = ast.parse('''
    def foo():
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
        yield 3
    ''')

    YieldFromTransformer().visit(tree)

    compare_source(expected, tree)

# Generated at 2022-06-21 18:23:50.590933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__doc__ is not None

# Generated at 2022-06-21 18:24:01.481361
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .ast_processing import AstProcessor
    from .type_merge import TypeMerge

    from ..utils.helpers import ast_dump

    processor = AstProcessor([
        YieldFromTransformer,
        TypeMerge,
    ], from_file=False)

    source = """
        def func():
            a = yield from (i for i in range(10))
            b = yield from [1,2,3]
            c = yield
            d = 1
            yield

        def func2():
            i = 0
            while True:
                i = yield from (i for i in range(i + 1))
                yield i
    """


# Generated at 2022-06-21 18:24:07.682690
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    s = """
    yield from A
    """

    expected = """
    let(iterable)
    iterable = iter(A)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    """

    node = ast.parse(s)
    assert(expected in str(YieldFromTransformer().visit(node.body[0])))

# Generated at 2022-06-21 18:24:19.195768
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class FunctionDef(ast.FunctionDef):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, name='foo', args=ast.arguments(), **kwargs)

    class Module(ast.Module):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, body=[], **kwargs)

    class Expr(ast.Expr):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class Assign(ast.Assign):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


# Generated at 2022-06-21 18:24:28.766564
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typing
    import astor
    node = ast.parse(
        '''
        def test() -> None:
            yield from 1
            i = yield from 2
            yield from 3
        '''
    )
    assert astor.to_source(node) \
        == '''
       def test() -> None:
           yield from 1
           i = yield from 2
           yield from 3
       '''

    YieldFromTransformer().visit(node)

# Generated at 2022-06-21 18:24:31.201983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(None, None)

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:24:41.800189
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import io
    import astunparse

    s = 'def h(): yield from f()'
    tree = ast.parse(s)
    YieldFromTransformer().visit(tree)
    s_result = astunparse.unparse(tree)

    sys.stdout = io.StringIO()
    print(s)
    print(s_result)
    actual = sys.stdout.getvalue()[:-1]

    sys.stdout = io.StringIO()
    print('def h():')
    print('  let(exc)')
    print('  let(iterable)')
    print('  iterable = iter(f())')
    print('  while True:')
    print('    try:')
    print('      yield next(iterable)')

# Generated at 2022-06-21 18:25:04.981871
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''
    def foo():
        a = yield from range(1, 4)
        yield a
    '''

    expected = '''
    def foo():
        let(iterable)
        iterable = iter(range(1, 4))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
        yield a
    '''

    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == expected



# Generated at 2022-06-21 18:25:10.081517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..meta import to_source
    from ..ast_processing import process_ast_tree
    from ..utils.helpers import eval_
    from ..utils.snippet import snippet_to_source
    snippet_to_source(result_assignment)
    snippet_to_source(yield_from)


# Generated at 2022-06-21 18:25:11.528786
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-21 18:25:17.529094
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x.__class__.__name__ == 'YieldFromTransformer'
    assert isinstance(x, BaseNodeTransformer)
    assert hasattr(x, '_target_version')
    assert x._target_version.major == 3
    assert x._target_version.minor == 2
    assert not x._tree_changed


# Generated at 2022-06-21 18:25:18.341435
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:25:19.993751
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t.target == (3, 2)


# Generated at 2022-06-21 18:25:21.357567
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()

# Generated at 2022-06-21 18:25:32.169960
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    v = YieldFromTransformer()
    module = ast.parse('from typing import Any, List\n'
                       'def f(x: List[Any]):\n'
                       '    y = yield from x')
    tree = v.visit(module)
    expected_tree = ast.parse('from typing import Any, Iterator, List\n'
                              'def f(x: List[Any]) -> Iterator[Any]:\n'
                              '    let(iterable)\n'
                              '    iterable = iter(x)\n'
                              '    while True:\n'
                              '        try:\n'
                              '            yield next(iterable)\n'
                              '        except StopIteration as exc:\n'
                              '            y = exc.value\n'
                              '            break')

# Generated at 2022-06-21 18:25:39.266589
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import Any
    from ..utils import get_ast, compare_asts
    ast1 = get_ast(r"""
        def gen_fib(n):
            a, b = 0, 1

            for i in range(n):
                yield a
                a, b = b, a + b
                                
        for i in gen_fib(10):
            print(i)
        """)


# Generated at 2022-06-21 18:25:47.932436
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import AssertTreeEqual
    from ..utils.tree import parse, compare_trees
    from ..utils.helpers import get_ast_statement_cnt

    code = """
    def f():
        x = yield from g()
        yield from g()
        yield from g()
        yield from g()
        print(yield from g())
        yield from g()
        return yield from g()
    """
    tree = parse(code)
    t = YieldFromTransformer()
    tree = t.visit(tree)
    compare_trees(code, tree)
    assert t.tree_changed
    assert get_ast_statement_cnt(tree) == get_ast_statement_cnt(parse(code)) + 7



# Generated at 2022-06-21 18:26:33.614850
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # FIXME: Add tests, if possible, to test YieldFromTransformer
    pass

# Generated at 2022-06-21 18:26:34.428690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse 


# Generated at 2022-06-21 18:26:35.246301
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-21 18:26:43.550357
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from ..utils.importlib import import_file
    from ..test.test_base import CodeTestCase
    import astunparse
    import os

    # TODO: write tests
    test_case = CodeTestCase()
    test_case.setUp()
    test_case.test_import_libs()

    src_path = os.path.join(os.path.dirname(__file__), '..', 'test', 'yield_from_test', 'src')
    out_path = os.path.join(os.path.dirname(__file__), '..', 'test', 'yield_from_test', 'output')

# Generated at 2022-06-21 18:26:52.779677
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # This test is not working
    #
    # Test of the method visit of class YieldFromTransformer,
    # which is called by method visit of the parent class BaseNodeTransformer
    #

    # Set up the test case
    code = """
    a = yield from l
    c = 1
    """
    func_name = 'test_function'
    expected_code = """
    iterable = iter(l)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                a = exc.value
            break
    c = 1
    """

    # Call the method
    result = YieldFromTransformer(func_name)
    result.visit(code)
    # assert result == expected_code


# Unit

# Generated at 2022-06-21 18:26:54.090748
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-21 18:26:58.951926
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import testutils
    from .. import refactor

    tree = testutils.load_example_ast('yield_from.py')

    target = (3, 2)
    refactor = refactor.RefactoringTool(tree, {}, target_versions=target)
    refactor.register_transformer(YieldFromTransformer)
    refactor.refactor()

    testutils.compare_trees(tree, 'yield_from_result.py')

# Generated at 2022-06-21 18:27:01.638533
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    constructor_test_helper(
        YieldFromTransformer,
        [],
        {"target": (3, 2)}
    )

# Generated at 2022-06-21 18:27:02.826880
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer({}))

# Generated at 2022-06-21 18:27:11.664001
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()

    result = transformer.visit(ast.parse(
        'def foo():\n'
        '    while True:\n'
        '        yield from bar()\n'
        '        result = yield from bar()\n'
        '    yield from bar()\n'
    ))


# Generated at 2022-06-21 18:28:24.347375
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import (
        assert_syntax,
        get_test_cases,
    )

    test_cases = get_test_cases(__file__, 'YieldFromTransformer', only_if=lambda x: x.endswith('.pyi'),
                                subdir='ref_yield_from', remove_prefix=len(__file__) + 1)

    for test_case in test_cases:
        if test_case.name.startswith('test_'):
            expected = test_case.read()
            actual = YieldFromTransformer().visit(test_case.input)
            test_case.check(expected, actual, assert_syntax)

# Generated at 2022-06-21 18:28:27.483176
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_modules import module_with_yield_from, module_without_yield_from

    transformer = YieldFromTransformer()
    with_yield_from = module_with_yield_from.get_ast()
    assert transformer.run(with_yield_from) == module_without_yield_from.get_ast()

# Generated at 2022-06-21 18:28:31.411479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast
    from ..translators.python_translator import PythonTranslator
    node_tgt = ast.parse('def f(): yield from [1, 2, 3]').body[0]
    print(PythonTranslator().visit(node_tgt))
    YieldFromTransformer().visit(node_tgt)
    print(PythonTranslator().visit(node_tgt))

# Generated at 2022-06-21 18:28:37.026529
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    from ..optimize.local_block_fuser import LocalBlockFuser
    from ..optimize.constant_variable_eliminator import ConstantVariableEliminator
    from ..optimize.unreachable_code_eliminator import UnreachableCodeEliminator
    from ..optimize.loop_invariant_code_motion import LoopInvariantCodeMotion

    source = r"""
    def fun(a):
        b = [1, 2]
        for i in range(10):
            for j in b:
                yield from a
    """

    node = ast.parse(source)
    YieldFromTransformer().visit(node)
    node = UnreachableCodeEliminator().visit(node)
    node = LocalBlockFuser().visit(node)
    node = ConstantVariableEliminator

# Generated at 2022-06-21 18:28:39.251619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-21 18:28:42.063379
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_ast

    class TestTransformer(YieldFromTransformer):
        def visit_Module(self, node):  # type: ignore
            self.generic_visit(node)
            return node


# Generated at 2022-06-21 18:28:51.649397
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..pipeline.compiler import compile
    from ..pipeline.processor import Processor
    from ..utils.helpers import dump_code

    class Test(Processor):
        def process_try(self, node):
            yield node

        def process_while(self, node):
            yield node

        def process_for(self, node):
            yield node

        def process_if(self, node):
            yield node

    code = """
    class C:
        def f(self):
            try:
                yield from range(10)
            except Exception as e:
                pass
    """
    dump_code(compile(code, processors=[
        YieldFromTransformer(),
        Test(),
    ]))

    assert True

# Generated at 2022-06-21 18:28:59.632279
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from nope.platforms.python.transformer.yield_from import YieldFromTransformer
    from nope.platforms.python.transformer.base import BaseNodeTransformer

    class NodeTransformer(BaseNodeTransformer):
        def __init__(self, tree):
            self.tree = tree
            self.parent_stack = []
            self.node_stack = [tree]

        def generic_visit(self, node):
            pass


# Generated at 2022-06-21 18:29:00.849164
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import run_test_string


# Generated at 2022-06-21 18:29:09.325805
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tester import make_assert_transformation

    # yield from
    make_assert_transformation(
        YieldFromTransformer,
        """yield from a""",
        """exc = generate('exc')
iterable = iter(a)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            pass
        break"""
    )

    # yield from a = ...