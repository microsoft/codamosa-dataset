

# Generated at 2022-06-21 18:19:12.628744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..node_transformation import NodeTransformerPipeline
    from ..node_transformation import CompileError
    from .statement_lift import StatementLiftTransformer
    from .goto import GotoTransformer

    pipeline = NodeTransformerPipeline([
        StatementLiftTransformer,
        GotoTransformer,
        YieldFromTransformer,
    ])
    try:
        pipeline.visit_Module(ast.parse("while True:\n if a:\n  yield from b()"))
    except CompileError:
        pass

# Generated at 2022-06-21 18:19:15.294404
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    return yield_from_transformer

# Generated at 2022-06-21 18:19:17.700508
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-21 18:19:20.952779
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    sys.path.append("../")
    import typed_astunparse
    # https://github.com/python/typed_ast/issues/7

# Generated at 2022-06-21 18:19:30.451634
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.Try(body=[ast.Expr(value=ast.YieldFrom(value=ast.Num(n=1)))],
                   handlers=[ast.ExceptHandler(type=None, name=None, body=[])],
                   orelse=[],
                   finalbody=[])

# Generated at 2022-06-21 18:19:32.836293
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import transform


# Generated at 2022-06-21 18:19:42.189827
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse
    from .general import GeneralTransformer
    from .return_stmt import ReturnStmtTransformer
    from .raise_stmt import RaiseStmtTransformer

    text = '''
    def f(x):
        if x > 5:
            y = yield from [1]
        else:
            raise ValueError('error')
    '''
    tree = parse(text)

    gen = GeneralTransformer()
    gen.visit(tree)
    assert str(tree) == text

    add = ReturnStmtTransformer()
    add.visit(tree)

# Generated at 2022-06-21 18:19:43.160536
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() # Dummy test

# Generated at 2022-06-21 18:19:53.342083
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source, transform

    assert_equal_source(
        transform(YieldFromTransformer, 'a = yield from it'),
        '''
        let(iterable)
        iterable = iter(it)
        while True:
            try:
                a = next(iterable)
            except StopIteration as exc:
                a = exc.value
                break
        ''')

    assert_equal_source(
        transform(YieldFromTransformer, 'yield from it'),
        '''
        let(iterable)
        iterable = iter(it)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
        ''')

# Generated at 2022-06-21 18:20:01.273121
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # https://docs.python.org/3/library/typed_ast.html
    # https://greentreesnakes.readthedocs.io/en/latest/nodes.html
    # https://greentreesnakes.readthedocs.io/en/latest/checker.html
    # https://greentreesnakes.readthedocs.io/en/latest/references.html
    module = ast.Module(body=[])
    assert module == YieldFromTransformer().visit(module)

# Generated at 2022-06-21 18:20:12.915896
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('x = yield from f()')
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert str(tree) == \
"""if True:
    iterable = iter(f())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                x = exc.value
            break"""


__all__ = ['YieldFromTransformer']

# Generated at 2022-06-21 18:20:18.787484
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.Module(body= [ ast.FunctionDef(name='hello', args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]), body= [ ast.Expr(value= ast.YieldFrom(value= ast.Name(id='test', ctx=ast.Load()))) ], decorator_list=[], returns=None), ast.Expr(value=ast.Name(id='test', ctx=ast.Load())) ])
    transformer = YieldFromTransformer()
    b = transformer.visit(a)
    assert isinstance(b, ast.AST)
    assert isinstance(a, ast.AST)
    assert isinstance(a.body, list)
    assert isinstance(b.body, list)
    assert isinstance(b.body[0], ast.FunctionDef)

# Generated at 2022-06-21 18:20:26.186078
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Setup
    import ast as pyast
    from ..utils import get_code
    code = get_code(YieldFromTransformer.__module__, 'sample.py')
    tree = pyast.parse(code)
    _, mod = YieldFromTransformer().visit(tree)

    # Test
    res = pyast.dump(mod)
    expected_outcome = get_code(YieldFromTransformer.__module__,
                          'sample_expected_outcome.py')
    assert res == expected_outcome

# Generated at 2022-06-21 18:20:28.102680
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)


# Generated at 2022-06-21 18:20:28.713370
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:20:31.221969
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # assert_raises(...)
    transformer = YieldFromTransformer()
    assert transformer
    return

# Generated at 2022-06-21 18:20:41.600658
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('def a():\n\tb = yield from c')
    assert repr(YieldFromTransformer().visit(node)) == "Module(body=[FunctionDef(name='a', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Assign(targets=[Name(id='b', ctx=Store())], value=Call(func=Name(id='next', ctx=Load()), args=[Name(id='iterable', ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"
if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:20:49.861248
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # 1
    source = """
from __pypy__ import coroutine

a = 1
yield from a
"""
    generator = (i for i in range(1))  # type: ignore
    target = """from __pypy__ import coroutine;a = 1;exc = None;iterable = iter(a); while True: try: yield next(iterable) except StopIteration as exc: exc = exc; break"""
    result = YieldFromTransformer().visit(ast.parse(source))
    assert ast.dump(result) == target


# Generated at 2022-06-21 18:20:56.251139
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """def func():
        x = 10
        y = 20
        r = yield from x
        print(r)
        s = yield from y
        print(s)
    """

# Generated at 2022-06-21 18:21:07.114297
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import ast

    class TestTree(ast.AST):
        _fields = ['body']

    tree = TestTree()

    body_0 = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                        value=ast.YieldFrom(value=ast.Call(func=ast.Name(id='range',
                                                                        ctx=ast.Load()),
                                                           args=[ast.Num(n=10)],
                                                           keywords=[])))

# Generated at 2022-06-21 18:21:20.742209
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    
    # Imports and aliases
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    
    # If

# Generated at 2022-06-21 18:21:24.884106
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, BaseNodeTransformer) and isinstance(transformer, YieldFromTransformer) and isinstance(transformer, ast.NodeTransformer) # added by Tara


# Generated at 2022-06-21 18:21:32.767197
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helpers import assert_equal_with_printing, load_fixture
    from ..common import File, Run

    input = load_fixture('async_generators', 'yield_from.py')
    expected = load_fixture('async_generators', 'yield_from.expected.py')

    File.write(input.name, input.read())

    run = Run(files=[input])
    run.compiler.register_pass(YieldFromTransformer)
    run.compile()

    assert_equal_with_printing(File.read(input.name), expected.read())

# Generated at 2022-06-21 18:21:43.963809
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import transform
    code = "def foo():\n    yield from bar; yield from baz"
    transpiled_code = transform(code, YieldFromTransformer)
    expected_code = "def foo():\n    iterable = iter(bar);\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            if hasattr(exc, 'value'):\n                exc = exc.value\n            break\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            if hasattr(exc, 'value'):\n                exc = exc.value\n            break"
    assert transpiled_code == expected_code

# Generated at 2022-06-21 18:21:48.871496
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test import expect_ast

    class MockNode:
        def __init__(self, body: ast.AST) -> None:
            self.body = [body]
    expr = ast.Expr(value=ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load())))
    class MockBody:
        def __init__(self, body: ast.AST) -> None:
            self.body = body
    body = MockBody([expr])
    mock_node = MockNode(body)

    print(ast.dump(mock_node, include_attributes=True))

    def mock_node_insert_at(index, node, insertions):
        node.body[0].body.body = insertions


# Generated at 2022-06-21 18:21:59.708936
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Test(YieldFromTransformer):
        def visit_Assign(self, node: ast.Assign) -> ast.Assign:
            return node

        def visit_Expr(self, node: ast.Expr) -> ast.Expr:
            return node

        def visit_If(self, node: ast.If) -> ast.If:
            return node

    tree: ast.Module = ast.parse('def f(x):\n    if x:\n        yield from b\nb')
    expected: ast.Module = ast.parse('def f(x):\n    if x:\n        let(iterable)\n        iterable = iter(b)\n        while True:\n            try:\n                yield next(iterable)\n            except StopIteration as exc:\n                break\nb')

# Generated at 2022-06-21 18:22:10.594990
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse

    tree_before = ast.parse("""
        def test_expr():
            x = (yield from func())
            return 4
    """)
    _ = tree_before
    tree_after = ast.parse("""
        def test_expr():
            let(iterable)
            iterable = iter(func())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    x = exc.value
                    break
            return 4
    """)
    transformer = YieldFromTransformer()
    tree_transformed = transformer.visit(tree_before)
    assert astunparse.unparse(tree_transformed) == astunparse.unparse(tree_after)


# Generated at 2022-06-21 18:22:11.754268
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source
    from ..utils.helpers import is_equal_code, find_nodes

    transformer_cls = YieldFromTransformer


# Generated at 2022-06-21 18:22:13.667373
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:22:15.708796
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom()
    assert YieldFromTransformer(None)(yield_from) == yield_from


# Generated at 2022-06-21 18:22:38.918749
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()
test_YieldFromTransformer()

# Generated at 2022-06-21 18:22:44.355290
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse, ast

    result = """def fib():
    yield 0
    a = yield from fib()
    b = yield from fib()
    yield a + b
fib()"""

    tree = ast.parse(result)
    YieldFromTransformer().visit(tree)
    result = astunparse.unparse(tree)

    assert 'yield from' not in result
    assert 'fib()' in result

# Generated at 2022-06-21 18:22:45.173308
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:22:55.252132
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_unittest import run_test, get_test_snippet
    from typed_ast import ast3 as ast

    def validate_transform(transformer, code):
        module_ast = ast.parse(code)
        module_ast = transformer.visit(module_ast)
        assert module_ast is not None
        return module_ast

    transformer = YieldFromTransformer()

    code = get_test_snippet("yield_from/yield_from.py")
    expected_code = get_test_snippet("yield_from/expected_yield_from.py")

    module_ast = validate_transform(transformer, code)
    expected_ast = validate_transform(transformer, expected_code)
    run_test(module_ast, expected_ast)

    yield_from_

# Generated at 2022-06-21 18:22:56.896887
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(None)
    return transformer

# Generated at 2022-06-21 18:23:06.964501
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestYieldFromTransformer(YieldFromTransformer):
        def generic_visit(self, node):
            return node
    # Test on ast.Assign
    class TestNode():
        def __init__(self, body):
            self.body = body
    class TestAssign():
        def __init__(self, targets, value):
            self.targets = targets
            self.value = value
    class TestYieldFrom():
        def __init__(self, value):
            self.value = value

    body = [TestAssign([None], TestYieldFrom(None))]
    node = TestNode(body)
    assert YieldFromTransformer()._get_yield_from_index(node, ast.Assign) == 0


# Generated at 2022-06-21 18:23:13.404369
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    def add(x, y):
        return x + y
    def testit(i):
        return i + 1
    i = yield from add(1, 2)
    j = yield from testit(2)
    """
    node = ast.parse(inspect.getsource(test_YieldFromTransformer))
    transf = YieldFromTransformer()
    new_node = transf.visit(node)
    assert isinstance(transf._yield_from_to_while, ast.While)
    assert transf._tree_changed

# Generated at 2022-06-21 18:23:19.662854
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from .core import AutoNumber
    from ..utils.tree import ast_parse
    from .core import AutoNumberTransformer
    from .merge_assigns import MergeAssignsTransformer
    from .try_except import TryExceptTransformer
    from .try_except_yield import TryExceptYieldTransformer
    from .unpack_exceptions import UnpackExceptionsTransformer


# Generated at 2022-06-21 18:23:20.563789
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse

# Generated at 2022-06-21 18:23:21.763779
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()

# test whether visit funciton works as expected

# Generated at 2022-06-21 18:24:12.670981
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str

    tree = ast.parse("""
    def f():
        a = yield from iter(range(10))
        print(a)
        yield from iter(range(10))
        yield from iter(range(10))
    """)
    snippet.debug = True
    transformer = YieldFromTransformer()
    assert transformer.visit(tree)
    print(tree_to_str(tree))
    # assert False

# Generated at 2022-06-21 18:24:16.586031
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import build_ast
    
    YieldFromTransformer()

# Unit tests for method _get_yield_from_index and _emulate_yield_from of class YieldFromTransformer

# Generated at 2022-06-21 18:24:19.193947
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert yield_from_transformer

# Generated at 2022-06-21 18:24:20.147761
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:24:22.069671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-21 18:24:32.799922
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_tools.tests.shared import assert_transform

# Generated at 2022-06-21 18:24:33.851182
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:35.010551
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:24:35.625736
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:24:45.957613
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import run_local_tests
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        def _get_transformer(self, node: ast.AST) -> BaseNodeTransformer:
            return YieldFromTransformer(ast.parse(node))

        def test_try(self):
            node = """
            try:
                yield from iterable
            except Exception as e:
                pass
            """
            result = """
            try:
                iterable = iter(iterable)
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc_0:
                        break
            except Exception as e:
                pass
            """
            self.run(node, result, self._get_transformer)


# Generated at 2022-06-21 18:26:39.243308
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:26:45.393677
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    from ..utils.test_visitor import VisitorTestMixin, Visitor

    tree = ast.parse('x = yield from foo()')
    expected_tree = ast.parse('''
iterable0 = iter(foo())
while True:
    try:
        x = next(iterable0)
    except StopIteration as exc0:
        if hasattr(exc0, 'value'):
            x = exc0.value
        break
''')

    class Test(YieldFromTransformer, VisitorTestMixin, Visitor):
        pass

    tree = Test().visit(tree)
    assert typed_astunparse.unparse(tree) == typed_astunparse.unparse(expected_tree)

# Generated at 2022-06-21 18:26:46.941018
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:26:48.016489
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:26:48.870724
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass #TODO Write test

# Generated at 2022-06-21 18:26:58.341377
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class FakeNode:
        def __init__(self, body):
            self.body = body

    class FakeYieldFrom:
        def __init__(self, target):
            self.value = target

        def __eq__(self, other):
            return self.value == other.value

    class FakeAstNode:
        def __init__(self, target):
            self.value = FakeYieldFrom(target)

        def __eq__(self, other):
            return self.value == other.value

    class FakeAssignNode:
        def __init__(self, target):
            self.targets = [target]
            self.value = FakeAstNode(0)


# Generated at 2022-06-21 18:27:06.447171
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class TestTree(ast.AST):
        _fields = ('a', 'b')

    tree = TestTree()
    tree.a = []
    tree.b = []

    class MyTransformer(YieldFromTransformer):
        def visit_TestTree(self, node: ast.AST) -> ast.AST:
            if self.generic_visit is not None:
                tree = self.generic_visit(node)
            else:
                tree = node
            return tree

    tree = MyTransformer().visit(tree)
    assert tree.a == [] and tree.b == []


# Generated at 2022-06-21 18:27:12.515095
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import tests
    from .. import python_version
    from .test_base import NodeTestCase, NodeTransformerTestCase

    class TestYieldFromTransformer(NodeTestCase):
        transformer = YieldFromTransformer()
        target_python_version = python_version

        @tests.helper
        def assert_node(self, node):
            self.assert_node(
                node,
            )
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestYieldFromTransformer))
    return suite

# Generated at 2022-06-21 18:27:16.058458
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..baseline import transform
    from ..unittest_tools import assert_transform

    assert_transform(transform, YieldFromTransformer, 1, """
    def f():
        yield from g()
    """)

# Generated at 2022-06-21 18:27:17.389441
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()