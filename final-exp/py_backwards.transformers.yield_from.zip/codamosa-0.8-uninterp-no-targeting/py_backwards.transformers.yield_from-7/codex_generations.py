

# Generated at 2022-06-21 18:19:08.930217
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert str(YieldFromTransformer()) == '<YieldFromTransformer: 3.2>'

# Generated at 2022-06-21 18:19:16.420686
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def fun(x):
        if x == 3:
            y = yield from x

    import astunparse
    import ast
    import textwrap
    node = ast.parse(textwrap.dedent(fun.__doc__))
    node = YieldFromTransformer().visit(node)
    print(astunparse.dump(node))

    def fun(x):
        if x == 3:
            let(iterable)
            iterable = iter(x)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    y = exc.value
                    break

    node = ast.parse(textwrap.dedent(fun.__doc__))
    assert node == node

# Generated at 2022-06-21 18:19:18.115962
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _=YieldFromTransformer()

test_YieldFromTransformer()

# Generated at 2022-06-21 18:19:20.026936
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .transformer_test import _test_init
    _test_init(YieldFromTransformer)


# Generated at 2022-06-21 18:19:22.447476
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Simple number
    assert YieldFromTransformer()

    # More complex
    assert YieldFromTransformer(node=Node)

# Generated at 2022-06-21 18:19:23.471511
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass



# Generated at 2022-06-21 18:19:24.560632
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:19:27.964041
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:19:40.146089
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import copy

    code = """
    def generator():
        yield from []

    def generator2():
        yield from [1]

    def generator3():
        a = yield from [1, 2]

    def generator4():
        yield from range(100)

    def generator5():
        a = yield from range(100)
    """

    # Note: astor.to_source always add '\n' at the end

# Generated at 2022-06-21 18:19:51.967888
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Setup
    from ..utils.tree import dump
    from ..utils.source_context import SourceContext
    from .base import BaseNodeTransformer as Base
    from .base import BaseClassTreeTransformer
    from .assign_return_transformer import AssignReturnTransformer as AR
    from .function_return_transformer import FunctionReturnTransformer
    from .return_transformer import ReturnTransformer

    source = '''
for i in range(3):
    yield i
'''
    tree = ast.parse(source)
    ctx: SourceContext = SourceContext.from_tree(source, tree, parser_version=(3, 8))
    transformer = YieldFromTransformer(ctx)
    AR(ctx).visit(tree)
    tree = Base.generic_visit(AR(ctx), tree)
    tree = Base.generic_

# Generated at 2022-06-21 18:20:03.173140
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def fun(gen):
        var = yield from gen
        var2 = yield from gen
        (var3,) = yield from gen

        yield from gen
        obj.var = yield from gen
        (obj.var2,) = yield from gen
    """

    tree = ast.parse(code)
    transformed = YieldFromTransformer().visit(tree)

    assert transformed is not None

# Generated at 2022-06-21 18:20:04.916590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:20:06.545591
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse


# Generated at 2022-06-21 18:20:15.490798
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import nuitka.ast.nodes as nuitka_nodes

    from ..utils.helpers import generate_module


# Generated at 2022-06-21 18:20:26.134150
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...utils.helpers import ast_from_str
    from ...utils.tree import as_string

    before = """
        def foo():
            a = yield from foo()
            yield from foo()
    """
    after = """
        def foo():
            let(iterable)
            iterable = iter(foo())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        a = exc.value
                    break
            let(iterable)
            iterable = iter(foo())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """
    tree = ast_from_str(before)
    transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:20:37.805674
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source
    from ..utils.helpers import dumps_ast
    from ..converter import get_transformer_list

    transpile_src = Source("""
        def test():
            yield from foo
            yield from "bar"
            a = yield from [1, 2, 3]
            b, c = yield from foo
            yield from "baz"
            return a + b + c

        def test_with_return():
            yield from foo
            x = yield from foo
            if x:
                return x
    """)

# Generated at 2022-06-21 18:20:49.197458
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ironclad.compilers.astcompiler import parse_ast, compile_ast
    from ironclad.compilers.yieldfromcompiler import YieldFromTransformer

    ast_module = parse_ast("""
    from math import *
    import sys

    def a():
        x = 2
        y = yield from b() + 3
        if y == 2:
            print('Sanity')
        yield from c()

    def b():
        yield 1
        yield 2

    def c():
        yield 3
        raise StopIteration(yield from b())
    """)

    YieldFromTransformer().visit(ast_module)
    ast_module = compile_ast(ast_module, 'test', 'exec')
    exec(ast_module.body[2], globals())

# Generated at 2022-06-21 18:20:59.692682
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import astunparse
    import textwrap
    from ..utils import ast2code

    # Starting AST

# Generated at 2022-06-21 18:21:03.850164
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Check that class YieldFromTransformer is created without errors"""
    a = YieldFromTransformer()
    del a

if __name__ == "__main__":
    import sys
    import nose2
    nose2.main()

# Generated at 2022-06-21 18:21:05.288925
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-21 18:21:23.282816
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # Case 1: Handling assignments
    src = '''
    def some_method():
        a = yield from some_other_method()
        yield from last_method()
        return a
    '''
    tree = ast.parse(src)

# Generated at 2022-06-21 18:21:34.831054
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast

    try:
        from typed_ast.ast3 import YieldFrom
    except ImportError:
        YieldFrom = None

    if YieldFrom is None:
        raise TypeError

    # Save current ast3 version
    ast3_version = ast.__version__

    # Change ast3 version (because YieldFrom is available only in version 3.3+)
    ast.__version__ = '3.6'

    yield_from_transformer = YieldFromTransformer()

    class Module(ast.AST):
        """Class for testing YieldFromTransformer with ast.Module node."""
        body: List[ast.AST]
        type_ignores: List[ast.AST]


# Generated at 2022-06-21 18:21:36.243084
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    #TODO: add unit test
    pass

# Generated at 2022-06-21 18:21:38.557531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.AST()
    YieldFromTransformer.get_instance().visit(node)

# Generated at 2022-06-21 18:21:41.827046
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assertEqualAST
    from ..transpiler.registry import TranspilerNotFound

    with pytest.raises(TranspilerNotFound):
        YieldFromTransfo

# Generated at 2022-06-21 18:21:43.531681
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-21 18:21:53.496789
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''
        def f():
            yield from range(3)
    '''
    expected = '''
        def f():
            let(exc)
            let(iterable)
            iterable = iter(range(3))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    '''
    module = ast.parse(code)
    transformer = YieldFromTransformer()
    new_module = transformer.visit(module)
    generated_code = compile(new_module, filename="<ast>", mode="exec")

    ns = {}
    exec(generated_code, ns)
    gen = ns['f']()
    for i in range(3):
        assert gen.__next__() == i

# Generated at 2022-06-21 18:21:59.566587
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    tree = ast.parse('x = yield from f()')
    YieldFromTransformer().visit(tree)
    assert astor.to_source(tree) == 'let(iterable)\niterable = iter(f())\nwhile True:\n    try:\n        x = next(iterable)\n    except StopIteration as exc:\n        x = exc.value\n        break'

# Generated at 2022-06-21 18:22:10.121310
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()
    assert transformer.visit(ast.parse("""
        def f():
            a = yield from [1, 2, 3]
            yield from [1, 2, 3]
        """)) == ast.parse("""
        def f():
            let(iterable)
            iterable = iter([1, 2, 3])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        a = exc.value
                    break

            let(iterable)
            iterable = iter([1, 2, 3])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        """)

# Generated at 2022-06-21 18:22:11.464943
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('''
try:
    a
except Foo as e:
    pass
''')
    transformer = YieldFromTransformer()
    transformer.visit(node)
    assert has_keywords(node, 'from')

# Generated at 2022-06-21 18:22:44.751398
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse
    from ..utils.tree import put_in_func_body, put_in_module
    from ..utils.helpers import get_ast_nodes

    def check(code, expected_code):
        node = parse(code, version="3.6")
        node = put_in_module(node)

        tree_changed, node = YieldFromTransformer(node).visit(node)

        assert tree_changed
        assert expected_code == node

    # Case with one yield from statement
    code = """
        from __future__ import generators

        def f():
            from_future = 42
            yield from from_future
    """

# Generated at 2022-06-21 18:22:54.741757
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..base import Compiler
    from ..utils.helpers import dump_ast

    code_to_compile = """
    def foo():
        x = 1
        y = yield from bar()
        z = 2
        return y
    """
    tree = ast.parse(code_to_compile)
    YieldFromTransformer().visit(tree)
    compiled_code = Compiler().visit(tree)

# Generated at 2022-06-21 18:23:01.972635
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer.target == (3, 2)
    assert transformer._get_yield_from_index('node', 'type_') is None
    assert transformer._handle_assignments('node') == 'node'
    assert transformer._handle_expressions('node') == 'node'
    assert transformer.visit('node') == 'node'
    assert transformer.target == (3, 2)
    assert transformer._get_yield_from_index('node', 'type_') is None
    assert transformer._handle_assignments('node') == 'node'
    assert transformer._handle_expressions('node') == 'node'
    assert transformer.visit('node') == 'node'
    assert transformer.target == (3, 2)

# Generated at 2022-06-21 18:23:10.725134
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import check_code
    from ..utils.test_utils import get_test_data

    class_name = 'YieldFromTransformer'
    method_name = 'visit'
    test_data = get_test_data(class_name, method_name)

    for test_source in test_data.keys():
        tree = compile(test_source, 'test', 'exec', ast.PyCF_ONLY_AST)
        node = YieldFromTransformer().visit(tree)
        assert check_code(astor.to_source(node), test_data[test_source])

# Generated at 2022-06-21 18:23:14.195027
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        o = YieldFromTransformer()

    except TypeError as e:
        print('TypeError: ', e)
    except ValueError as e:
        print('ValueError: ', e)
    except Exception as e:
        print('Exception: ', e)

# Generated at 2022-06-21 18:23:22.493806
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    
    assert        YieldFromTransformer()._get_yield_from_index(None, None) == None
    assert        YieldFromTransformer()._emulate_yield_from(None, None) == [ast.Module(body=[])]
    assert        YieldFromTransformer()._handle_assignments(None) == None
    assert        YieldFromTransformer()._handle_expressions(None) == None
    assert        YieldFromTransformer().visit(None) == None
    assert        YieldFromTransformer().generic_visit(None) == None
    assert        YieldFromTransformer().node_transformer(None) == None
    return True



# Generated at 2022-06-21 18:23:24.068843
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(code=None, filename=None)


# Generated at 2022-06-21 18:23:25.662326
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__doc__ is not None


# Generated at 2022-06-21 18:23:36.398724
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap as tw

    code = tw.dedent('''
        def foo():
            yield from bar()
    ''')
    expected = tw.dedent('''
        def foo():
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc.value
                    break
    ''')
    tr = YieldFromTransformer()
    actual = tr(code)

    assert astor.to_source(actual) == expected

    code = tw.dedent('''
        def foo():
            a = yield from bar()
    ''')

# Generated at 2022-06-21 18:23:37.433999
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:27.368658
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import assert_result
    assert_result(YieldFromTransformer,
                  'while True:\n    pass',
                  'while True:\n    pass')
    assert_result(YieldFromTransformer,
                  'def foo():\n    a = yield from bar()',
                  'def foo():\n    iterable = iter(bar())\n'
                  '    while True:\n        try:\n            a = next(iterable)\n'
                  '        except StopIteration as exc:\n            a = exc.value\n            break')



# Generated at 2022-06-21 18:24:28.766391
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
   assert inspect.isclass(YieldFromTransformer)

# Generated at 2022-06-21 18:24:29.760112
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:24:31.053240
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:24:32.940109
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.unparse import Unparser

# Generated at 2022-06-21 18:24:33.549979
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:24:34.759599
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-21 18:24:35.773070
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  pass # yapf: disable

# Generated at 2022-06-21 18:24:37.149616
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import sys

# Generated at 2022-06-21 18:24:38.892197
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    assert isinstance(trans, YieldFromTransformer)

# Generated at 2022-06-21 18:26:37.423096
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('x = yield from y')
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.Assign)
    assert isinstance(node.body[0].value, ast.YieldFrom)

    transformer = YieldFromTransformer()
    node = transformer.visit(node)

    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.Assign)
    assert isinstance(node.body[0].targets[0], ast.Name)
    assert isinstance(node.body[0].value, ast.NameConstant)
    assert isinstance(node.body[1], ast.Assign)
    assert isinstance(node.body[1].targets[0], ast.Name)

# Generated at 2022-06-21 18:26:37.947948
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:26:44.907266
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent

    from ..utils.source import source, source_to_func
    from ..utils.sample import sample_transformed_tree
    from .mock import MockTransformation

    transformation = MockTransformation(YieldFromTransformer)

    cases = dedent("""\
    def f(x):
        yield from x
    """).split('\n')

    expected = dedent("""\
    def f(x):
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                pass
            break
    """).split('\n')

    node = source_to_func(source(cases))
    actual = sample_transformed_tree(node, transformation)
    assert source(expected) == actual

# Generated at 2022-06-21 18:26:45.640673
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-21 18:26:48.252454
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-21 18:26:57.884677
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = '''class Test(object):\n\tdef foo(self):\n\t\tdef bar():\n\t\t\tyield from []\n\t\t\tb = yield from []\n\t\t\tprint(b)'''

# Generated at 2022-06-21 18:27:08.411281
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    @snippet
    def test_assign():
        let(a)
        a = yield from b

        let(a)
        a = yield from c

    @snippet
    def test_assign_multiple_targets():
        let(a, b)
        a, b = yield from c

    @snippet
    def test_expr():
        yield from d

    @snippet
    def test_expr_multiple_times():
        yield from e
        yield from f

    @snippet
    def test_expr_in_if():
        if True:
            yield from g

    @snippet
    def test_expr_in_try():
        try:
            yield from h
        except Exception:
            pass


# Generated at 2022-06-21 18:27:15.080348
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .helper import get_ast, assert_equal_ast

    expected = get_ast('''
    def function(b):
        while True:
            try:
                while True:
                    try:
                        c = next(b)
                        yield c
                    except StopIteration as exc:
                        if hasattr(exc, 'value'):
                            exc.value
                        break
                    else:
                        continue
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc.value
                break
            else:
                continue
''').body[0]
    assert_equal_ast(YieldFromTransformer().visit(get_ast('''
    def function(b):
        yield from b
''').body[0]), expected)


# Generated at 2022-06-21 18:27:19.354962
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Tests the method visit of class YieldFromTransformer."""
    # Testing function:
    @snippet
    def test_function(value):
        let(total)
        total = 0
        while True:
            try:
                tmp1 = next(value)
            except StopIteration as exc:
                total = exc.value
                break
            else:
                total = total + tmp1
        return total

    # Creating the code
    code = snippet.test_function

    # Creating the Python 3.2 AST
    python_ast = parse(code)

    # Creating the Python 3.4 AST
    yield_from_ast = YieldFromTransformer()
    yield_from_ast.apply(python_ast)

    # Transforming the Python 3.4 AST to Python code

# Generated at 2022-06-21 18:27:29.312445
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import parse
    from ..utils.helpers import get_compiled_func
    import dis
    import sys


    def foo(x):
        (yield from x)


    tree = parse(foo.__code__, mode='exec')
    res = YieldFromTransformer().visit(tree)
    tree_compiled = get_compiled_func(tree)
    res_compiled = get_compiled_func(res)
    assert (tree_compiled is not res_compiled)
    assert (dis.dis(tree_compiled) != dis.dis(res_compiled))
    assert (dis.dis(tree_compiled) == "  9           0 LOAD_FAST                0 (x)\n                  2 YIELD_FROM              0\n                  4 RETURN_VALUE\n")