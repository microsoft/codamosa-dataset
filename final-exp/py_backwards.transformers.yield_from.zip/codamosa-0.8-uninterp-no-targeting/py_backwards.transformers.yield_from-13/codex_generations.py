

# Generated at 2022-06-21 18:19:06.409125
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:08.616786
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

# Generated at 2022-06-21 18:19:09.683431
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:10.928490
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:13.576809
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-21 18:19:24.969575
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from compiler.transformer import YieldFromTransformer
    from compiler.utils.helpers import VariablesGenerator
    from compiler.utils.tree import Node
    from typed_ast import ast3 as ast
    from typed_ast import ast3

    node = ast.Module([
        ast.FunctionDef(
            'f',
            ast.arguments(
                [], None, None, []
            ),
            [
                ast.Expr(
                    ast.YieldFrom(
                        ast.Name('g', ast3.Load())
                    )
                ),
                ast.Assign(
                    [ast.Name('x', ast3.Store())],
                    ast.YieldFrom(
                        ast.Name('g', ast3.Load())
                    )
                )
            ],
            []
        )
    ])


# Generated at 2022-06-21 18:19:25.990333
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer



# Generated at 2022-06-21 18:19:28.129550
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import transpile
    from ..utils.py33_test_base import assert_code


# Generated at 2022-06-21 18:19:40.260093
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as typed_ast
    from typed_ast.ast3 import AST as A, Assign as Ass, Expr as Ex, Attribute as Att, Name as N, Load as L, \
        Expression as E


# Generated at 2022-06-21 18:19:42.116673
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer



# Generated at 2022-06-21 18:19:59.255491
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_astunparse import unparse
    from ..utils.helpers import parse

    input_text = """
    from typing import List, Iterator

    def foo(x: int, y: List[str]) -> Iterator[str]:
        a = yield from range(x, 10)
        print(a)
        yield from y
        b = yield from [1,2,3,4,5]
        c = yield from '12345'
    """

# Generated at 2022-06-21 18:20:00.247859
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:20:11.622192
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse('''
    def foo():
        a = yield from bar()
        b = yield from foo()
    ''')
    YieldFromTransformer().visit(module)

# Generated at 2022-06-21 18:20:23.656971
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for method __init__
    def test_YieldFromTransformer__init__():
        transformer = YieldFromTransformer()
        assert transformer.target == (3, 2)
        assert transformer._tree_changed == False
    test_YieldFromTransformer__init__()

    # Test for method _get_yield_from_index
    def test_YieldFromTransformer__get_yield_from_index():
        transformer = YieldFromTransformer()
        class Node():
            def __init__(self):
                self.body = []
        node = Node()
        assert transformer._get_yield_from_index(node, ast.Assign) == None

# Generated at 2022-06-21 18:20:24.694176
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:20:27.482666
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    _input = yield_from.strip()
    expected = result_assignment.strip()
    expected = 'yield from iter(generator)'
    actual = YieldFromTransformer().visit(ast.parse(_input))
    assert ast.dump(actual) == expected

# Generated at 2022-06-21 18:20:39.233600
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Before
    try:
        yield from (x for x in range(10))
        yield from (x for x in range(10))
    except Exception as e:
        yield from (x for x in range(10))
        yield from (x for x in range(10))

    # After
    let(iterable_0, iterable_1, iterable_2, exc_0, exc_1)
    iterable_0 = iter((x for x in range(10)))
    while True:
        try:
            yield next(iterable_0)
        except StopIteration as exc_0:
            break

    iterable_1 = iter((x for x in range(10)))
    while True:
        try:
            yield next(iterable_1)
        except StopIteration as exc_1:
            break

   

# Generated at 2022-06-21 18:20:50.736189
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from astor.code_gen import to_source
    from . import register_transformers
    from .async_ import AsyncAwaitTransformer
    from .typeddict import TypedDictTransformer
    from ..utils.helpers import VariablesGenerator

    generator_var = VariablesGenerator.generate('generator_var')
    yield_from_transformed = """\
    iterable = iter(generator_var)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                var = exc.value
            break"""
    register_transformers([TypedDictTransformer, AsyncAwaitTransformer, YieldFromTransformer])

# Generated at 2022-06-21 18:21:00.904234
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')
    assert hasattr(YieldFromTransformer, '_get_yield_from_index')
    assert hasattr(YieldFromTransformer, '_emulate_yield_from')
    assert hasattr(YieldFromTransformer, '_handle_assignments')
    assert hasattr(YieldFromTransformer, '_handle_expressions')
    assert hasattr(YieldFromTransformer, 'visit')
    transformer = YieldFromTransformer()
    assert hasattr(transformer, 'target')
    assert hasattr(transformer, '_get_yield_from_index')
    assert hasattr(transformer, '_emulate_yield_from')
    assert hasattr(transformer, '_handle_assignments')

# Generated at 2022-06-21 18:21:12.110624
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tree import node, search_for_node
    from .unparse import Unparser
    from .typed_ast import parse
    from .typed_ast import AST

    source = '''
        def foo():
            yield from enumerate(range(10))
    '''

    assert search_for_node(parse(source, '<test>', 'exec'), ast.YieldFrom)

    expected = '''
        def foo():
            let(iterable)
            iterable = iter(enumerate(range(10)))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

    '''
    node = YieldFromTransformer.visit(parse(source, '<test>', 'exec'))

# Generated at 2022-06-21 18:21:24.524403
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print(YieldFromTransformer())
    

# Generated at 2022-06-21 18:21:25.544723
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:21:30.523236
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3, parse
    from .basic import BasicNodeTransformer
    from ..utils.helpers import identity
    class TreeMock(object):
        def __init__(self):
            self._body = []

        @property
        def body(self):
            return self._body

    tree = TreeMock()

# Generated at 2022-06-21 18:21:41.970373
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Node:
        pass

    class Node2:
        pass

    class Node3:
        pass

    class Node4:
        pass

    node = Node()
    node.body = [Node2()]
    node.body[0].value = Node3()

    node2 = Node()
    node2.body = [Node4()]
    node2.body[0].value = Node3()

    assert YieldFromTransformer._get_yield_from_index(node, ast.Assign) == None
    assert YieldFromTransformer._get_yield_from_index(node, ast.Expr) == None
    
    assert YieldFromTransformer._get_yield_from_index(node2, ast.Assign) == 0

# Generated at 2022-06-21 18:21:52.148541
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import ast_builder
    from .utils import ASTNodeMock, ast_source
    from .utils import transform_to_ast


# Generated at 2022-06-21 18:21:59.903423
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        trans = YieldFromTransformer(None)
        print('\nSuccessfully created instance of class YieldFromTransformer\n')
    except:
        print('\nCould not create instance of class YieldFromTransformer\n')
        return
    val = trans.target
    print('\nThe value of target is: ', val, '\n')
    snip = trans.visit(1)
    print('\nThe value of trans.visit(1) is: ', snip)


# Generated at 2022-06-21 18:22:10.817775
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source
    from ..transforms.unpacking import UnpackingTransformer
    from ..transforms.fix_missing_locations import FixMissingLocationsTransformer
    from ..transforms.resolve_lambdas import ResolveLambdasTransformer


# Generated at 2022-06-21 18:22:15.848003
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = '''
a = yield from b
    '''
    expected = '''
let(iterable)
iterable = iter(b)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break
    '''
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-21 18:22:24.618133
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from textwrap import dedent
    from ..utils.helpers import get_node 

    # Unit test for method visit
    def test_visit(self):
        code = dedent('''\
            def foo():
                a = yield from [2, 3]
            ''')
        tree = get_node(code)
        transformer = self.get_transformer()
        transformer.visit(tree)
        self.assertNotEqual(code, astor.to_source(tree))

    get_test(test_visit, YieldFromTransformer)

# Generated at 2022-06-21 18:22:36.867147
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast import parse
    from .. import transform

    tree = parse("""
    def f(x):
        yield from x
    """)
    transformed = YieldFromTransformer().visit(tree)
    assert len(transformed.body) == 1
    assert len(transformed.body[0].body) == 1
    assert len(transformed.body[0].body[0].body) == 4
    # print(transform(tree, [YieldFromTransformer]))

    tree = parse("""
    def f(x):
        a = yield from x
        b = yield from x
    """)
    transformed = YieldFromTransformer().visit(tree)
    assert len(transformed.body) == 1
    assert len(transformed.body[0].body) == 2

# Generated at 2022-06-21 18:22:59.821898
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with open(r'D:\projects\python-compiler\test_data\test_yield_from.py', 'r') as f:
        src = f.read()
    tree = ast.parse(src)
    YieldFromTransformer().visit(tree)
    assert tree

# Generated at 2022-06-21 18:23:06.774218
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astmonkey import transformers

    code = """
    def my_fun(lst):
        for item in lst:
            yield from generator()
    """
    module_node = ast.parse(code)
    transformer = YieldFromTransformer()
    transformer.visit(module_node)
    print(transformers.ParentChildNodeTransformer().visit(module_node))

# Generated at 2022-06-21 18:23:09.597112
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.converter import convert
    from .. import DEFAULT_FEATURES
    from ..visitor import Visitor
    from .transformer import Transformer


# Generated at 2022-06-21 18:23:10.848838
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = YieldFromTransformer()


# Generated at 2022-06-21 18:23:11.769375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-21 18:23:21.594475
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer.target == (3, 2)
    assert transformer._tree_changed == False
    assert transformer._get_yield_from_index(ast.Try(), ast.Expr) == None

# Generated at 2022-06-21 18:23:32.395537
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test snippet
    test_snippet = """
try:
    yield from generator
except StopIteration as exc:
    if hasattr(exc, 'value'):
        target = exc.value
"""

    yield_from_ast = ast.parse(test_snippet).body[0]
    node_ast = ast.parse(
        """
try:
    yield from generator
except StopIteration as exc:
    if hasattr(exc, 'value'):
        target = exc.value
"""
    )

    # Test snippet
    test_snippet = """
try:
    yield from generator
except StopIteration as exc:
    pass
"""

    yield_from_ast = ast.parse(test_snippet).body[0]

# Generated at 2022-06-21 18:23:33.326766
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__doc__ is not None

# Generated at 2022-06-21 18:23:44.404535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast
    import typed_ast.ast3 as ast3
    from codetransformer.transformers.yieldfrom import YieldFromTransformer
    from codetransformer.utils.testutils import format_code

    x = YieldFromTransformer()

    code = '''
    def func(generator):
        x = yield from generator
        x = yield from generator
        yield from generator
    '''


# Generated at 2022-06-21 18:23:54.126481
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_fixtures.structures import BaseTestStructure
    from .test_fixtures import must_fail_nodes, failing_node

    class TestStructure(BaseTestStructure):

        def _run_transformer(self, code: str, max_version: tuple) -> ast.AST:
            transformer = YieldFromTransformer(max_version)
            tree = transformer.visit(ast.parse(code))  # type: ignore
            assert transformer.tree_changed
            return tree

    def _run(code: str, max_version: tuple, expected: str) -> None:
        tree = TestStructure.get_ast(code, max_version,
                                     YieldFromTransformer.target)
        if tree is None:
            return

        tree = TestStructure._run_transformer(code, max_version)

# Generated at 2022-06-21 18:24:47.877402
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .unittest_tools import assert_transformed_ast

    assert_transformed_ast(
        YieldFromTransformer,
        '''
            def foo():
                yield from iter(lst)
        '''.strip(),
        '''
            def foo():
                _ = iter(lst)
                while True:
                    try:
                        yield next(_)
                    except StopIteration as _exc:
                        break
        '''.strip(),
    )


# Generated at 2022-06-21 18:24:48.928880
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from ..utils.source import source_to_unicode

# Generated at 2022-06-21 18:24:59.844453
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import mypy
    from ..typing import fixer_typing

    code = """def foo(number):
                a = 1 + number
                yield from range(5)
                b = yield from range(5)
                return a + b"""
    tree = ast.parse(code)
    tree = fixer_typing.visit(tree)
    tree = YieldFromTransformer.visit(tree)


# Generated at 2022-06-21 18:25:03.738503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import UnitTestTransformer
    import os.path
    import astor

    class TestTransformer(UnitTestTransformer):
        def __init__(self):
            super().__init__(
                YieldFromTransformer
            )

    test_transformer = TestTransformer()

# Generated at 2022-06-21 18:25:06.360584
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..linting import run_pylint
    from ..ast_processing import parse
    from ..testing import dump_ast
    from .base import NodeTransformer


# Generated at 2022-06-21 18:25:10.522175
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import astor
    from .yield_statements import YieldTransformer
    from .opt_yield_statements import OptYieldTransformer
    from .return_statements import ReturnTransformer


# Generated at 2022-06-21 18:25:11.575628
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test should be implemented!
    pass

# Generated at 2022-06-21 18:25:21.923740
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    import textwrap
    from .helpers import assert_equal_code
    from .base import TreeInstanceBuilder

    code = textwrap.dedent('''\
    def foo():
        yield from {}
    ''')

    builder = TreeInstanceBuilder()
    code1 = builder.build_ast(code.format('[]'))
    assert_equal_code(code.format('iter([])'), YieldFromTransformer().visit(code1))

    code2 = builder.build_ast(code.format('b'))
    assert_equal_code(code.format('iter(b)'), YieldFromTransformer().visit(code2))


# Generated at 2022-06-21 18:25:23.639326
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.helpers import str_ast


# Generated at 2022-06-21 18:25:25.781351
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert type(yield_from_transformer) is YieldFromTransformer


# Generated at 2022-06-21 18:27:27.625499
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .example_transformers import FormatStringTransformer

# Generated at 2022-06-21 18:27:33.599190
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

    # Check whether YieldFromTransformer is capable of handling simple yield
    # statements
    source = textwrap.dedent('''
    def func():
        yield
    ''')
    # Try to compile yield as it was yield from
    transformer = YieldFromTransformer()
    body = transformer.visit(ast.parse(source).body)
    assert transformer._tree_changed is False
    assert isinstance(body[0], ast.FunctionDef)

    # Check whether YieldFromTransformer is capable of handling simple yield
    # statement with values
    source = textwrap.dedent('''
    def func():
        yield 42
    ''')
    # Try to compile yield as it was yield from
    transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:27:35.180716
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer({})
    assert a is not None


# Generated at 2022-06-21 18:27:37.217568
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 18:27:40.606587
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Test method visit of class YieldFromTransformer"""
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast


# Generated at 2022-06-21 18:27:41.526769
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-21 18:27:42.489218
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-21 18:27:48.469338
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test_case(func: ast.AST, expect: ast.AST):
        transformer = YieldFromTransformer()
        assert transformer.visit(func) == expect

    def assert_ast(func, expect):
        test_case(ast.parse(func), ast.parse(expect))

    def assert_transformation(func, expect):
        func = ast.parse(func)
        func = YieldFromTransformer().visit(func)
        assert ast.dump(func) == ast.dump(ast.parse(expect))

    # test _handle_expressions with node.body as list

# Generated at 2022-06-21 18:27:57.612748
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """The method visit of class YieldFromTransformer should handle yield from
    in any context. As yield from is usable in any context of Python 3, it is
    tested in all possible places via this method. Assignments and expressions
    are tested separately.
    """

    class ModuleVisitor(ast.NodeVisitor):

        def __init__(self):
            self.yield_from_seen = False

        def visit_YieldFrom(self, node):
            self.yield_from_seen = True


# Generated at 2022-06-21 18:28:06.581777
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast