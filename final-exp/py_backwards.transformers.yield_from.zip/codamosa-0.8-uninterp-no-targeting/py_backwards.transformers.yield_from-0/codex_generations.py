

# Generated at 2022-06-21 18:19:01.322803
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:19:02.495245
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()
    assert a is not None


# Generated at 2022-06-21 18:19:04.068624
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__doc__ is not None


# Generated at 2022-06-21 18:19:15.076328
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_tools.passes import TransformerPass
    from ..utils.helpers import get_ast
    from ..utils.compare import compare_source

    code = """
    class Foo:
        def foo(self, bar):
            baz = yield from bar

        def bar(self, baz):
            yield from self.baz()

        def baz(self):
            yield from self.faz()
            yield from self.baz()
    """

# Generated at 2022-06-21 18:19:17.701245
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:19:28.252353
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def no_yield_from():
        yield
        yield 1
        yield 2

    def yield_from_func():
        yield from no_yield_from()
        yield 3

    def func():
        r1, r2 = yield from no_yield_from()
        r3 = yield from no_yield_from()
        return r1, r2, r3

    class Obj:
        def __init__(self):
            self.value = True

        def __iter__(self):
            for i in range(10):
                yield i

    obj = Obj()

# Generated at 2022-06-21 18:19:29.673147
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-21 18:19:33.179450
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from compile_to_ast import compile_to_ast
    from ast_pprint import dump_ast


# Generated at 2022-06-21 18:19:34.258050
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:19:42.826194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_transformer_visit import create_source_and_test_function

    source = '''
    def test_generator(x):
        try:
            yield from bar(y)
        except Exception:
            pass
        z = yield from foo(x)
        print(yield from range(y))
    '''

# Generated at 2022-06-21 18:19:57.213220
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import autoimport
    from urllib.parse import urlparse

    code = """
try:
    a = yield from None
except Exception as exc:
    pass
"""
    node = autoimport.parse(code)

    result = ast.dump(node)

# Generated at 2022-06-21 18:20:09.115960
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Mock(ast.AST):
        pass

    class Assign(Mock):
        _fields = ['targets', 'value']

    class Expr(Mock):
        _fields = ['value']

    class YieldFrom(Mock):
        _fields = ['value']

    class Try(Mock):
        _fields = ['body', 'orelse', 'finalbody']

    class If(Mock):
        _fields = ['body', 'orelse']

    class While(Mock):
        _fields = ['body', 'orelse']

    class For(Mock):
        _fields = ['body', 'orelse']

    class FunctionDef(Mock):
        _fields = ['body', 'decorator_list', 'args', 'returns']

    class Module(Mock):
        _fields

# Generated at 2022-06-21 18:20:13.561605
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    if sys.version_info >= (3, 6):
        import astor
    else:
        astor = None

    def _test(module, expected, kwargs={}):
        result = YieldFromTransformer(module, **kwargs).result
        assert astor.to_source(result) == expected


# Generated at 2022-06-21 18:20:16.923367
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""
    import astor

# Generated at 2022-06-21 18:20:27.609735
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .transformers import init_transformers
    
    transformer = YieldFromTransformer()
    init_transformers.insert(0, transformer)
    assert transformer == init_transformers[0]

# Generated at 2022-06-21 18:20:29.047277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == "YieldFromTransformer"

# Generated at 2022-06-21 18:20:30.758117
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:20:31.906536
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-21 18:20:33.418560
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)



# Generated at 2022-06-21 18:20:45.008661
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..compilation import StatementCompiler

    source_text = source(
    """
    def foo():
        a = yield from bar()

        b = 5
        c = yield from bar()
        b = 3
        yield from bar()
    """
    )

# Generated at 2022-06-21 18:20:52.305441
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.unparse import Unparser

# Generated at 2022-06-21 18:20:56.280212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("def f(): yield 1")
    node = YieldFromTransformer().visit(node)

    ast.dump(node)
    assert ast.dump(node) == "Module(body=[FunctionDef(name='f', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Yield(value=Num(n=1)))], decorator_list=[], returns=None)])"


# Generated at 2022-06-21 18:21:05.317865
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # function to test
    from typed_ast import ast3
    from ..utils.helpers import node_to_source
    from ..utils.ast import ast_to_source

    def transform_function(func: ast3.FunctionDef):
        transformer = YieldFromTransformer()
        func = transformer.visit(func)
        return func

    # before transformation
    before = """
    def fibo(n):
        a, b = 1, 1
        while n > 0:
            a, b = b, a + b
            n -= 1
            yield a
    """
    # expecting result (after transformation)
    result = """
    def fibo(n):
        a, b = 1, 1
        while n > 0:
            a, b = b, a + b
            n -= 1
            yield a
    """

# Generated at 2022-06-21 18:21:16.329869
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import ast
    import __future__

    # Input
    src = '''
        def foo(x):
            while True:
                yield from x
            return x
        '''

    # Expected output
    expected = '''
        def foo(x):
            while True:
                __EXC0__
                __ITERABLE1__
                __ITERABLE1__ = iter(x)
                while True:
                    try:
                        yield next(__ITERABLE1__)
                    except StopIteration as __EXC0__:
                        x = __EXC0__.value
                        break
            return x
        '''

    # Run test
    root = ast.parse(src)
    YieldFromTransformer.run(root)


# Generated at 2022-06-21 18:21:23.543457
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source
    from ..utils.snippet import snippet, let
    from ..utils.visitor import visit_module_body
    from ..utils.helpers import VariablesGenerator
    import typing as tp

    @snippet
    def gen():
        for i in range(4):
            yield i

    @snippet
    def loop_for(gen, x):
        for i in gen:
            x += i
        return x

    @snippet
    def loop_while(gen):
        let(iterable)
        iterable = iter(gen)
        let(result)
        result = 0

        while True:
            try:
                let(x)
                x = next(iterable)
                result += x
            except StopIteration as exc:
                result = exc.value

# Generated at 2022-06-21 18:21:28.078040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    sample_code = 'yield from [2, 3, 4]'
    result = ast.parse(sample_code)
    assert isinstance(result, ast.Expression)

    node: ast.Expression = result
    assert isinstance(node.body, ast.YieldFrom)

# Generated at 2022-06-21 18:21:29.037501
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None) is not None

# Generated at 2022-06-21 18:21:32.900452
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code: ast.Try = ast.parse('x = yield from y')

    transformed: ast.Try = YieldFromTransformer().visit(code)

    assert transformed != code

    assert transformed.body[0].value.generator == code.body[0].value.value

# Generated at 2022-06-21 18:21:34.648764
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-21 18:21:35.733005
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Generated at 2022-06-21 18:21:59.466906
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import compare_ast
    from ..utils.textwrap import dedent
    from ..utils.helpers import make_doctestable

    src = dedent("""
    def foo():
        yield from bar()

    def bar():
        yield from baz()

    def baz():
        yield 1

    value = yield from baz()

    yield from baz()
    """)

# Generated at 2022-06-21 18:22:10.361792
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # case when yield_from not covered
    tree = ast.parse(
        '''
        def f():
            return 1
        '''
    )
    YieldFromTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(name='f', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=Constant(value=1))], decorator_list=[], returns=None)])"

    # case when yield_from covered
    tree = ast.parse(
        '''
        def f():
            yield from gen
        '''
    )
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-21 18:22:18.703355
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Unit test for constructor of class YieldFromTransformer
    def _test_order(source: str, result: Optional[str]) -> None:
        tree = ast.parse(source)
        tree = YieldFromTransformer(version=3, tree=tree).transform()
        assert ast.dump(tree) == result

    _test_order("""
yield from some.iterable
yield from other_iterable
""", """
yield from some.iterable
yield from other_iterable
""")


# Generated at 2022-06-21 18:22:29.345152
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # fail if you try to use yield from outside a function or generator
    def f(): yield from [1, 2]
    tree = ast.parse(f.__code__.co_consts[0])
    with pytest.raises(LanguageError) as err:
        YieldFromTransformer().visit(tree)
    assert "try to use yield from outside a function or generator" \
        in str(err.value)

    # fail if you try to use yield from outside a function or generator
    def g(): yield from [1, 2]
    tree = ast.parse(g.__code__.co_consts[0])
    with pytest.raises(LanguageError) as err:
        YieldFromTransformer().visit(tree)

# Generated at 2022-06-21 18:22:29.933817
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:22:42.774973
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import unittest
    import textwrap

    from typed_ast import ast3 as ast
    from ..utils import tree

    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.transformer = YieldFromTransformer(sys.version_info.major, sys.version_info.minor)

        def check(self, before, after):
            before_ast = ast.parse(textwrap.dedent(before))
            after_ast = ast.parse(textwrap.dedent(after))
            self.assertTrue(self.transformer.visit(before_ast))
            self.assertEqual(tree.beautify(before_ast),
                             tree.beautify(after_ast))

    t = Test()

# Generated at 2022-06-21 18:22:50.380326
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

    def check(input_code, expected_output_code):
        input_ast = ast.parse(input_code)
        expected_output_ast = ast.parse(expected_output_code)
        actual_output_ast = YieldFromTransformer().visit(input_ast)

        assert ast.dump(actual_output_ast) == ast.dump(expected_output_ast)

    generator_function_single_context_manager = """
        def generator():
            yield from range(10)
    """


# Generated at 2022-06-21 18:22:56.483876
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    result = compile(
        '''
            def function():
                target = yield from iterable
                yield from iterable
                yield from iterable
                a, b = yield from iterable
                c, d = yield from iterable
                yield from iterable
                yield from iterable
                yield from iterable
        ''',
        filename='<input>', mode='exec')

# Generated at 2022-06-21 18:22:57.521234
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:23:03.644583
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from python_transpile.test.test_programs import _3x_test_programs as test_programs
    from python_transpile.test.test_programs import test_data

    ts = test_programs.load(test_data.suite_files[0])
    node = ts.programs[0].find(ast.Try)
    YieldFromTransformer().visit(node)



# Generated at 2022-06-21 18:23:39.505578
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing.utils import assert_equal_ast
    from .expression_unpacking import ExpressionUnpackingTransformer
    source = """
    def generator():
        yield from [1, 2, 3]
    """
    expected = """
    def generator():
        let(iterable)
        iterable = iter([1, 2, 3])
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    ExpressionUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-21 18:23:48.302991
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tree import parse
    from ..tests.test_helpers import default_options, run_transformer

    def test_case(code, expected, options=default_options):
        ast_tree = parse(code)
        new_ast = run_transformer(YieldFromTransformer, ast_tree, options)
        assert expected == astor.to_source(new_ast)


# Generated at 2022-06-21 18:23:49.640343
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import get_ast


# Generated at 2022-06-21 18:23:51.440432
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
            a = yield from b
            """
    assert YieldFromTransformer().visit(ast.parse(code))

# Generated at 2022-06-21 18:23:54.583389
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # testing the __init__ method of the class
    transformer=YieldFromTransformer()
    assert transformer.target==(3, 2)


# Generated at 2022-06-21 18:23:59.244112
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = 'result = yield from value'
    tree = ast.parse(code)
    tree = YieldFromTransformer.run(tree)
    assert compile(tree, filename='<ast>', mode='exec').co_code == b'|\x03|\x00\x00d\x00\x00e\x00\x00GHd\x01\x00S'

# Generated at 2022-06-21 18:24:00.110355
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse

# Generated at 2022-06-21 18:24:06.610428
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    transformed = transformer.visit(ast.parse(
        """
        def func():
            code = 'print("Hello")'
            while True:
                try:
                    exec(code)
                except Exception:
                    pass
                if something:
                    break
            if something:
                return
            if something:
                return something
            else:
                return something_else
        """
    ))
    assert transformed is not None

# Generated at 2022-06-21 18:24:08.476357
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO:
    # The assertion exception is not handled, should raise AssertionError
    assert False

# Generated at 2022-06-21 18:24:20.014004
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .assertions import assert_equal_source
    from .typingpy import NodeTransformer, parse

    source = """
    def func():
        some()
        yield from gen()
        yield from other()

    def gen():
        some()
        yield from nested()
        yield from other()

    def nested():
        yield from deeper()
    """


# Generated at 2022-06-21 18:25:27.223693
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..testing import (assert_transformed_ast_equal, assert_code_equal,
                           assert_transformed_source_equal, normalize)

    code = textwrap.dedent("""
        def wrapper(gen):
            try:
                while True:
                    yield next(gen)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
        """)
    tree = normalize(code)
    tree.body.pop()

    example = textwrap.dedent("""
        def test(x):
            for i in range(x):
                yield i


        def test1(x):
            y = yield from test(x)
            yield y
        """)

    example_tree = normalize(example)

# Generated at 2022-06-21 18:25:36.661262
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, a1, b1, c1, d1, e1, f1, g1, h1, i1, j1, k1, l1, m1, n1, o1, p1, q1, r1, s1 = [None]*55
    YieldFromTransformer.__init__(a)
    YieldFromTransformer.__init__(b, a)
    YieldFromTransformer.__init__(c, a, b)
    YieldFromTransformer.__init__(d, a, b, c)

# Generated at 2022-06-21 18:25:40.746376
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Test for constructor of class YieldFromTransformer')
    assert YieldFromTransformer(None)
    print('Test for constructor of class YieldFromTransformer is passed!')


# Generated at 2022-06-21 18:25:49.646385
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    Module = ast.parse('def f(x): yield from x').body[0]
    assert ast.dump(Module) == "Module(body=[FunctionDef(name='f', args=arguments(args=[arg(arg='x', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=YieldFrom(value=Name(id='x', ctx=Load())))], decorator_list=[], returns=None)])"
    # Test that yield_from is replaced with while statement
    Result = YieldFromTransformer().visit(Module)

# Generated at 2022-06-21 18:25:52.182249
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_snippets import test_YieldFromTransformer_visit as snippet
    from ..testing import assert_snippet

    assert_snippet(YieldFromTransformer, snippet)  # type: ignore

# Generated at 2022-06-21 18:25:53.094690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

    assert True

# Generated at 2022-06-21 18:25:54.266866
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    x

# Generated at 2022-06-21 18:25:55.131270
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:26:02.003600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from string import printable as all_printable
    import random
    import sys

    def gen_random_label():
        return ''.join(random.choice(all_printable) for _ in range(10))

    class YieldFromTransformer(BaseNodeTransformer):
        """Compiles yield from to special while statement."""
        target = (3, 2)

# Generated at 2022-06-21 18:26:10.279044
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try_ = ast.Try(
        body=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='value', ctx=ast.Load())))],
        handlers=[ast.ExceptHandler(
            type=None, name='exc', body=[
                ast.Expr(value=ast.YieldFrom(value=ast.Name(id='exc.value', ctx=ast.Load())))
            ])],
        orelse=[],
        finalbody=[]
    )
    result = YieldFromTransformer().visit(try_)
    assert isinstance(ast.dump(result), str)



# Generated at 2022-06-21 18:28:28.092931
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree_in = ast.parse("""
    def foo(func):
        x = yield from func()
        yield from bar()
    """)
    tree_expected = ast.parse("""
    def foo(func):
        let(iterable)
        iterable = iter(func())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    x = exc.value
                break
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    x = exc.value
                break
    """)
    tree_actual = YieldFromTransformer().visit

# Generated at 2022-06-21 18:28:32.462231
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	func = YieldFromTransformer()
	assert func._get_yield_from_index(node, type_) == None
	assert func._get_yield_from_index(node, type_) == None
	assert func._get_yield_from_index(node, type_) == None
	assert func._get_yield_from_index(node, type_) == None
	assert func._get_yield_from_index(node, type_) == None

# Generated at 2022-06-21 18:28:33.998992
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert 1

# Generated at 2022-06-21 18:28:34.501071
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:28:38.216930
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .matcher import test_transform

    source = """
            a = yield from b
            yield from c
        """
    expected = """
            let(iterable)
            iterable = iter(b)
            while True:
                try:
                    yield next(iterable)
                    a = exc.value
                except StopIteration as exc:
                    break
            let(iterable)
            iterable = iter(c)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        """
    test_transform(YieldFromTransformer, source, expected)



# Generated at 2022-06-21 18:28:39.632265
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .generic import GenericNodeTransformer
    from .helpers import unit_test_node_transform

    transform = GenericNodeTransformer(YieldFromTransformer)
    unit_test_node_transform('yield_from', transform)

# Generated at 2022-06-21 18:28:50.086314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import transform

    code = """
    def foo():
        yield from bar()
        x = yield from bar()
        a, b = yield from bar()
        yield from bar()
    """

# Generated at 2022-06-21 18:28:50.631859
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:28:58.723791
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import load
    from ..utils.checker import check_visitor
    from ..visitors.checker import Checker
    from ..visitors.ast_compare import compare_asts
    from ..utils.source import source

    one = source('''
    a = yield from b
    ''')

    two = source('''
    let(iterable)
    iterable = iter(b)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            a = exc.value
    ''')

    one = load(one)
    tree = Checker().visit(one)

    result = YieldFromTransformer().visit(tree)

    two = load(two)
    expected = Checker().visit(two)

    compare