

# Generated at 2022-06-21 18:19:10.275149
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-21 18:19:10.902003
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:13.427115
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    # Just test whether the constructor works
    x = ast.parse('x = yield from x')
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:24.393246
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    snippet_ = snippet()
    let(x)
    let(y)
    let(it)
    it = (x for x in range(5))
    y = yield from it
    expected = snippet_.get_ast()
    given = snippet(x for x in range(5)).get_ast()
    node_transformer = YieldFromTransformer()

    # Act
    node_transformer.visit(given)
    actual = given

    # Assert
    expected.body[0].value.target.id = 'it'
    expected.body[0].targets[0].id = 'y'
    assert ast.dump(expected) == ast.dump(actual)
    assert node_transformer.is_changed()


# Generated at 2022-06-21 18:19:25.401805
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:19:30.612578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.transformers import TransformerSequence
    from . import astnode, cst

    cst_node = cst.parse_module("""\
x = yield from gen()
y = yield from 1 + 2
yield from 4 + 5
    """)
    ast_node = TransformerSequence([cst.CSTTransformer(), astnode.ASTNodeTransformer(), YieldFromTransformer()]).visit(cst_node)
    print(ast_node)

# Generated at 2022-06-21 18:19:33.126209
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # create instance of the class
    obj = YieldFromTransformer()

# Generated at 2022-06-21 18:19:40.259918
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    def test():
        ret = 5
        try:
            ret = yield from func(3)
        except Exception as exc:
            ret = exc.value

    def func(a):
        return a

    import sys, io
    f = io.StringIO()
    sys.stdout = f
    print(YieldFromTransformer().visit(ast.parse(test.__code__.co_consts[0])))
    sys.stdout = sys.__stdout__
    print(f.getvalue())

test_YieldFromTransformer()

# Generated at 2022-06-21 18:19:43.644903
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__qualname__ == 'YieldFromTransformer'

# Generated at 2022-06-21 18:19:46.141271
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class A(YieldFromTransformer):
        pass
    assert issubclass(A, BaseNodeTransformer)
    

# Generated at 2022-06-21 18:20:03.358491
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
  from ..utils.examples import YieldFromExample
  from ..utils.helpers import parse, compare
  from ..test.test_target_test_case import get_test_object

  transformer = YieldFromTransformer()
  source = """some_call(x=yield from some_other_call())"""
  expected = """some_call(x=yield from some_other_call())"""
  result = transformer.visit(parse(source))
  compare(result, expected, YieldFromExample)

  source = """some_call(x=yield from some_other_call(yield from some_other_call(yield from (some_other_call()))))"""

# Generated at 2022-06-21 18:20:11.620315
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    snippet = """
    def f():
        a = yield from 1
    """
    return_code = "def f():\n    iterable = iter(1)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            a = exc.value\n            break\n"
    module = ast.parse(snippet)
    module = YieldFromTransformer().visit(module)
    assert astor.to_source(module) == return_code


# Generated at 2022-06-21 18:20:18.070625
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""def f():\n    yield from func()""")
    builder = YieldFromTransformer()
    builder.visit(tree)

    # python3 -m typed_ast.ast3 tools/tests/pep342_transform.py
    # ast.dump(tree)


# Generated at 2022-06-21 18:20:19.061731
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    p = YieldFromTransformer()


# Generated at 2022-06-21 18:20:21.253917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astor.code_gen import to_source
    import astor

    # Input

# Generated at 2022-06-21 18:20:32.581467
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_astunparse import astunparse
    import ast
    class Node:
        def __init__(self, body):
            self.body = body
    class Expr:
        def __init__(self, value):
            self.value = value
    class Assign:
        def __init__(self, targets, value):
            self.targets = targets
            self.value = value
    class Name:
        def __init__(self, id):
            self.id = id
    class YieldFrom:
        def __init__(self, value):
            self.value = value
    class Binop:
        def __init__(self, left, op, right):
            self.left = left
            self.op = op
            self.right = right

# Generated at 2022-06-21 18:20:33.553541
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): assert YieldFromTransformer()



# Generated at 2022-06-21 18:20:35.575007
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer('3.2')
    assert YieldFromTransformer('3.9')


# Generated at 2022-06-21 18:20:37.953904
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.test_utils import assert_source


# Generated at 2022-06-21 18:20:38.756121
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:20:58.170983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_code = "a = yield from (1, 2, 3)"
    expected_code = """a = None
iterable = iter((1, 2, 3))
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break
"""
    from ..utils.testing import generate_code
    assert generate_code(test_code, lambda node: YieldFromTransformer().visit(node)) == expected_code

# Generated at 2022-06-21 18:21:00.803854
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # test YieldFromTransformer.__init__
    YieldFromTransformer_0 = YieldFromTransformer()

    assert YieldFromTransformer_0 is not None


# Generated at 2022-06-21 18:21:07.636172
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    s = "def test(): yield from [a for a in range(5)]"
    expected_ast = ast.parse("def test(): iterable = iter([a for a in range(5)])\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            pass")
    result_ast = YieldFromTransformer.apply(ast.parse(s))
    assert ast.dump(result_ast) == ast.dump(expected_ast)

# Generated at 2022-06-21 18:21:18.502112
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == """Compiles yield from to special while statement."""
    assert YieldFromTransformer.target == (3, 2)
    assert YieldFromTransformer._get_yield_from_index.__name__ == '_get_yield_from_index'
    assert YieldFromTransformer._get_yield_from_index.__doc__ == None
    assert YieldFromTransformer._emulate_yield_from.__name__ == '_emulate_yield_from'
    assert YieldFromTransformer._emulate_yield_from.__doc__ == None
    assert YieldFromTransformer._handle_assignments.__name__ == '_handle_assignments'
    assert Y

# Generated at 2022-06-21 18:21:28.944463
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    visitor = YieldFromTransformer("(empty)", 0)

# Generated at 2022-06-21 18:21:35.287092
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    from ..utils.helpers import compare_asts
    from ..utils.random import random_ast
    from .. import YieldFromTransformer

    for _ in range(100):
        node = random_ast(3, 2)
        node = parse(format(node))
        node = YieldFromTransformer().visit(node)
        assert compare_asts(node, node)



# Generated at 2022-06-21 18:21:46.217042
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.asdl import asdl_parse

    code = """
    def function(a, b):
        e = yield from a
        c = yield from b + 1
    """

    module = asdl_parse(code)
    transformer = YieldFromTransformer()
    with transformer.visit_and_replace(module):
        assert False

    assert len(module.body) == 1
    function = module.body[0]
    assert len(function.body) == 4
    assert type(function.body[0]) is ast.Assign
    assert type(function.body[0].value) is ast.Call
    assert type(function.body[1]) is ast.Assign
    assert type(function.body[1].value) is ast.Call
    assert type(function.body[2]) is ast.Assign


# Generated at 2022-06-21 18:21:57.039107
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import inspect
    import unittest
    from typed_ast import ast3
    from typed_ast.ast3 import Assign, Expr, YieldFrom, FunctionDef, Module,\
        Name, AST

    def transform_test(code: str) -> str:
        """
        Method to transform code in correct form

        :param code: str
        :return: str
        """
        tree: AST = ast3.parse(code)
        node_transformer = YieldFromTransformer()
        new_tree = node_transformer.visit(tree)
        return ast3.unparse(new_tree)

    class YieldFromTransformerTest(unittest.TestCase):
        """
        Class for testing YieldFromTransformer class

        """
        # Unit test for _get_yield_from_index method

# Generated at 2022-06-21 18:21:57.626137
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-21 18:22:08.799867
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def simple(yield_from):
        yield from yield_from

    class C:
        def m(self, yf):
            yield from yf

    class D:
        def __init__(self):
            self.a = yield from gen()

        def m(self, yf):
            yield from yf

    tree = parse(simple, {'__name__': '__main__'}, mode='exec', decompile=False)
    tree_class = parse(C, {'__name__': '__main__'}, mode='exec', decompile=False)
    tree_class_multi = parse(D, {'__name__': '__main__'}, mode='exec', decompile=False)
    YieldFromTransformer().visit(tree)
    YieldFromTransformer().visit(tree_class)


# Generated at 2022-06-21 18:22:44.774840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:22:52.469304
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os
    import astor

    code = os.linesep.join([
        'def f():',
        '    x = yield from range(10)'
        '    yield from range(x)'
    ])
    root = astor.parse_file(code)
    YieldFromTransformer().visit(root)

# Generated at 2022-06-21 18:22:56.925897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import get_test_data
    from ..utils.tester import assert_transform, assert_transform_result

    transformer = YieldFromTransformer()

    for source in get_test_data('yieldfrom_transformer_test.py'):
        assert_transform(transformer, source, assert_transform_result)

# Generated at 2022-06-21 18:23:05.358713
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils.test_utils import check_transformation
    from ..test_cases import yield_from as test_cases_yield_from

    trans = YieldFromTransformer

    for module in test_cases_yield_from.get_test_cases():
        expected = dedent(f'''\
            def f():
                {module.expected}
        ''')
        tree = ast.parse(dedent(f'''
            def f():
                {module.code}
        '''))
        tree = trans.visit(tree)
        check_transformation(tree, expected)

# Generated at 2022-06-21 18:23:06.715287
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-21 18:23:16.155882
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .visit_test import make_node_visitor_test

    test_method = make_node_visitor_test(YieldFromTransformer)

    def _test(source: str, expected: str) -> None:
        test_method(source, expected)
        test_method(f'{source}\n', f'{expected}\n')

    _test('yield from a', '')
    _test('yield from a\nb', 'b')

# Generated at 2022-06-21 18:23:16.617139
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:23:27.373235
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    mod = ast.Module(body=[
        ast.If(test=ast.Name(id='True', ctx=ast.Load()),
               body=[
                   ast.Assign(targets=[ast.Name(id='test', ctx=ast.Store())],
                              value=ast.YieldFrom(value=ast.Name(id='test', ctx=ast.Load()))),
               ],
               orelse=[])
    ])
    transformer = YieldFromTransformer()
    result = transformer.visit(mod)

# Generated at 2022-06-21 18:23:35.422852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..transformers.yieldfrom import YieldFromTransformer
    global vis
    vis = YieldFromTransformer()
    f = open("visitor_tests/yieldfrom_tests/YieldFromTransformer.py", "r")
    if f.mode == 'r':
        contents = f.read()
        tree = ast.parse(contents)
        tree = vis.visit(tree)
        f = open("visitor_tests/yieldfrom_tests/YieldFromTransformer_after.py", "w")
        f.write(astor.to_source(tree))
        f.close()


# Generated at 2022-06-21 18:23:35.959901
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:15.496988
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import compile_isolated

    def test_function(input_1):
        while True:
            first = yield from input_1
            second = yield from input_1
            yield (first, second)

    ast_tree = compile_isolated(test_function, return_ast=True)
    YieldFromTransformer().visit(ast_tree)

# Generated at 2022-06-21 18:24:25.897479
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    target = (3, 2)
    # Test to emulate yield from statement in assignment operation
    def test_assign():
        before = 'a = yield from b'
        node = ast.parse(before, '<>', 'exec')
        YieldFromTransformer(target).visit(node)
        after = 'exc = None\n' + \
                'try:\n' + \
                '   iterable = iter(b)\n' + \
                '   while True:\n' + \
                '      try:\n' + \
                '         next(iterable)\n' + \
                '      except StopIteration as exc:\n' + \
                '         a = exc.value\n' + \
                '         break'
        assert ast.dump(node, include_attributes=False) == after
    test_

# Generated at 2022-06-21 18:24:36.827638
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test(s, expected):
        tree = ast.parse(s)
        YieldFromTransformer().visit(tree)
        assert ast.dump(tree) == expected

    test("@lru_cache(maxsize=None)\ndef fn():\n    yield from range(10)",
         "import functools\nimport typing\n@functools.lru_cache(maxsize=None)\ndef fn():\n    let(val)\n    let(exc)\n    val = range(10)\n    exc = StopIteration()\n    let(iterable)\n    iterable = iter(val)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            exc = exc\n            break\n")

# Generated at 2022-06-21 18:24:37.429469
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:42.402709
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_transformer import assert_transform
    assert_transform(
        """
try:
    a = yield from expression
except Exception:
    pass
""",
        """
iterable = iter(expression)
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        break
    except Exception:
        pass
""")

# Generated at 2022-06-21 18:24:52.883539
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transpile import Transpiler

    code = '''
    some_dict = dict()

    if 10 == 20:
        yield from range(10)
        some_dict['key'] = yield from range(5)
    else:
        some_dict['key'] = yield from range(20)

    def some_func(a: int) -> bool:
        yield from range(a)
        yield from range(10)
        return False
    '''


# Generated at 2022-06-21 18:25:02.849468
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from io import StringIO
    import sys
    import astor

    # Initialize some local variables
    tree = ast3.parse("""
a = (1 if 10 else 2)
b = yield from range(10)
    """)
    old_stdout = sys.stdout
    tree = YieldFromTransformer().visit(tree)
    result = astor.to_source(tree)
    sys.stdout = old_stdout
    lines = result.split('\n')
    # Check the output of to_source

# Generated at 2022-06-21 18:25:03.294700
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-21 18:25:03.800319
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-21 18:25:14.650431
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('''def foo():
    a = (yield from b)
    yield from c''')
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    expected = ast.parse('''def foo():
    let(iterable)
    iterable = iter(b)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                a = exc.value
            break
    let(iterable)
    iterable = iter(c)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break''')
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-21 18:27:05.774017
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:27:13.595466
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    if sys.version_info < (3, 3):
        return
    import astor
    ast1 = ast.parse("l = [1, 2]; l = [yield from range(3)]")
    ast2 = ast.parse("l = [1, 2]; l = [yield from range(3)]")
    ast3 = ast.parse("yield from range(3)")
    ast4 = ast.parse("yield from range(3)")
    YieldFromTransformer(None).visit(ast1)
    assert astor.to_source(ast1) == astor.to_source(ast2)
    YieldFromTransformer(None).visit(ast3)
    assert astor.to_source(ast3) == astor.to_source(ast4)

# Generated at 2022-06-21 18:27:24.474862
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tests.utils import assert_tree_equality, string_to_module

    tree = string_to_module('yield from x')
    tree = YieldFromTransformer().visit(tree)

    result_tree = string_to_module(
        '''
        let(iterable)
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
        '''
    )

    assert_tree_equality(tree, result_tree)

    tree = string_to_module('a = yield from x')
    tree = YieldFromTransformer().visit(tree)


# Generated at 2022-06-21 18:27:32.019119
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_equal_ast, assert_tree_changed

    def test_invalid_node():
        string = 'test'
        node = ast.parse(string)
        transformer = YieldFromTransformer()
        with pytest.raises(ValueError):
            transformer.visit(node)

    def test_empty_node():
        string = 'def func(): pass'
        expected = string
        node = ast.parse(string)
        transformer = YieldFromTransformer()
        assert_tree_changed(transformer, node, expected)

    def test_simple_yield_from():
        string = 'def func(): yield from test()'

# Generated at 2022-06-21 18:27:37.489686
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.codegen import to_source
    from ..utils.python_code_parser import PythonCodeParser


# Generated at 2022-06-21 18:27:47.320424
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    if ast.__version__ >= (0, 29, 0):
        import pytest
        pytest.skip('typed_ast/ast3.py has no attribute Literal', allow_module_level=True)

    from typing import cast
    from ..utils.helpers import node_to_str

    code = """\
    def function2(x: int):
        yield from range(x)

    def function3(x: int):
        y = yield from range(x)

    def function4(x: int):
        y, z = yield from range(x)
    """
    tree = ast.parse(code)

    transformer = YieldFromTransformer()
    tree = cast(ast.Module, transformer.visit(tree))
    module_body = tree.body


# Generated at 2022-06-21 18:27:56.860390
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    result = YieldFromTransformer().visit(
        ast.parse(
            """
try:
    a = (yield from iterable)
except Exception as e:
    b = e
        """
        )
    )
    assert astor.to_source(result) == (
        """try:\n"""
        """    iterable\n"""
        """    while True:\n"""
        """        try:\n"""
        """            a = next(iterable)\n"""
        """            yield a\n"""
        """        except StopIteration as exc_1:\n"""
        """            a = exc_1.value\n"""
        """            break\n"""
        """except Exception as e:\n"""
        """    b = e\n"""
    )

# Generated at 2022-06-21 18:27:58.110318
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()



# Generated at 2022-06-21 18:28:06.921481
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import Try, Expr, Assign, YieldFrom
    from typed_ast.ast3 import Dict, FunctionDef, arguments, Name
    import astor  # type: ignore

    try_ast = Try(body=[], handlers=[], finalbody=[])

    expr = Expr(value=YieldFrom(value=Name(id='gen', ctx=Name())))
    assign = Assign(targets=[Name(id='target', ctx=Name())],
                    value=YieldFrom(value=Name(id='gen', ctx=Name())))


# Generated at 2022-06-21 18:28:18.316316
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    t = YieldFromTransformer()

    # generic_visit (no yield from)
    code = 'print(1)'
    tree = ast.parse(textwrap.dedent(code))
    tree = t.visit(tree)
    assert astunparse.unparse(tree) == code, 'wrong generic_visit (no yield from)'

    # simple assign, no true indentation
    code = '''\
    a = yield from b
    '''
    code_t = '''\
    let(iterable, exc)
    iterable = iter(b)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            a = exc.value
            break
    '''