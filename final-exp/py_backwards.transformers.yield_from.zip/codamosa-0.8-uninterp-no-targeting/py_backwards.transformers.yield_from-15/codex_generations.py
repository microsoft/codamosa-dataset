

# Generated at 2022-06-21 18:19:14.073991
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import node_factory

    module = ast.parse("""yield from some_iterable""")
    YieldFromTransformer()(module)

    yielded_value = node_factory.get_first_expr_name(module.body[0])
    assert 'yield' in yielded_value
    assert 'StopIteration' in yielded_value
    assert 'iterable' in yielded_value


# Unit test of method _emulate_yield_from of class YieldFromTransformer

# Generated at 2022-06-21 18:19:25.353723
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def func1():
        yield from [1, 2, 3]
    def func2():
        yield from [1, 2, 3]
        return
    def func3():
        yield from [1, 2, 3]
        yield from [1, 2, 3]
    def func4():
        var = yield from [1, 2, 3]
    def func5():
        var1 = yield from [1, 2, 3]
        var2 = yield from [1, 2, 3]
    def func6():
        var1 = yield from [1, 2, 3]
        var2 = yield from [1, 2, 3]
        return var1, var2

# Generated at 2022-06-21 18:19:26.818530
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().visit(ast.parse("yield from x"))

# Generated at 2022-06-21 18:19:39.712266
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import io
    import unittest

    class TestYieldFromTransformerVisitMethods(unittest.TestCase):
        """Testing method visit of class YieldFromTransformer."""

        def test(self):
            code = 'def func():\n  for i in range(10): yield from foo'
            expected_code = 'def func():\n  for i in range(10):\n    iterable = iter(foo)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            break'
            tree = ast.parse(code)
            node = YieldFromTransformer().visit(tree)
            output = io.StringIO()
            ast.fix_missing_locations(node)
            ast.increment_lineno(node, 1)
           

# Generated at 2022-06-21 18:19:42.305470
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer(None)
    assert type(t) == YieldFromTransformer


# Generated at 2022-06-21 18:19:53.295314
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    code = """
    yield from list
    a = yield from list
    yield from list
    yield from list
    """
    tree = ast.parse(code)
    tree = YieldFromTransformer().visit(tree)
    code = astunparse.unparse(tree)

# Generated at 2022-06-21 18:20:05.112526
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer"""
    code = '''
    def foo():
        yield from "foobar"
    '''
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-21 18:20:07.540418
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 18:20:12.295414
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == "YieldFromTransformer"
    assert YieldFromTransformer.__qualname__ == "YieldFromTransformer"
    assert YieldFromTransformer.__doc__ is not None
    assert YieldFromTransformer.__module__ == "super_ast.transformers.yield_from"


# Generated at 2022-06-21 18:20:18.451191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import UnitTestTransformer

    source = """
        def f(a):
            a = yield from b
            b = yield from c
            c = yield from d
            return c
        """

# Generated at 2022-06-21 18:20:26.539050
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        t = YieldFromTransformer()
    except Exception as e:
        assert e
    else:
        assert t


# Generated at 2022-06-21 18:20:37.750791
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.target == (3, 2)

    ForLoop = ast.parse('for i in range(5):\n    yield from i')
    result = ast.parse('for i in range(5):\n    exc = i\n    iterable = iter(exc)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            if hasattr(exc, \'value\'):\n                exc = exc.value\n            break')

    YieldFromTransformer().visit(ForLoop.body[0])
    assert ast.dump(ForLoop) == ast.dump(result)



# Generated at 2022-06-21 18:20:49.116212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = ast.parse('a = yield from [1, 2, 3]')
    node_transformer = YieldFromTransformer()
    with pytest.raises(TypeError):
        node_transformer._emulate_yield_from(1, [1,2,3])
    node = node_transformer._emulate_yield_from(None, ast.YieldFrom(value=ast.List([ast.Num(1), ast.Num(2), ast.Num(3)])))

# Generated at 2022-06-21 18:20:59.260263
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    func_def_code = """
    def test():
        yield from (i for i in range(10))
        yield from (i for i in range(10))
    """
    func_def = parse(func_def_code)
    expected = """
    def test():
        iterable = iter(i for i in range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
        iterable = iter(i for i in range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    transformed = YieldFromTransformer().visit(func_def)
    assert expected == unparse(transformed)

# Generated at 2022-06-21 18:21:03.415255
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a = YieldFromTransformer()
        print("YieldFromTransformer unit test successful")
    except Exception as e:
        print("YieldFromTransformer unit test failed")
        print(e)


# Generated at 2022-06-21 18:21:04.054770
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-21 18:21:07.015594
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    node = parse('a = 5')
    result = YieldFromTransformer()
    result.visit(node)
    assert str(result) == 'a = 5'

# Generated at 2022-06-21 18:21:07.939093
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:21:08.836631
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:21:19.523907
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert ast.parse('def foo():\n    x = yield from gen()').body[0].body[0] == ast.parse('def foo():\n    x = None\n    iterable_1 = iter(gen())\n    while True:\n        try:\n            x = next(iterable_1)\n        except StopIteration as exc_1:\n            x = exc_1.value\n            break').body[0].body[0]
    assert ast.parse('def foo():\n    yield from gen()').body[0].body[0] == ast.parse('def foo():\n    iterable_1 = iter(gen())\n    while True:\n        try:\n            next(iterable_1)\n        except StopIteration as exc_1:\n            break').body[0].body[0]
    assert ast

# Generated at 2022-06-21 18:21:37.279686
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with open('tests/fixtures/given_test_file_for_yieldfrom_transformer.py') as file:
        test_content = file.read()
        assert len(test_content) != 0

    test_tree = ast.parse(test_content)
    YieldFromTransformer().visit(test_tree)
    module_body = test_tree.body
    
    assert module_body[3].value.func.id == 'yield_from'
    
    while_loop_body = module_body[3].value.func.args[0].body
    while_loop_body_length = len(while_loop_body)

    assert while_loop_body[-1].value.func.id == 'result_assignment'
    assert while_loop_body_length == 20

# Generated at 2022-06-21 18:21:38.655385
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-21 18:21:42.964588
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_equal_code
    from ..utils.helpers import VariablesGenerator

    src = """
    class A:
        def b(self):
            yield from []
    """
    expected = """
    class A:
        def b(self):
            {__temp0}_a = iter([])
            while True:
                try:
                    yield next({__temp0}_a)
                except StopIteration as {__temp1}:
                    if hasattr({__temp1}, 'value'):
                        {__temp0}_a = {__temp1}.value
                    break
    """

    with VariablesGenerator() as variables:
        expected = expected.format(**variables)
        assert_equal_code(src, expected, YieldFromTransformer)

# Generated at 2022-06-21 18:21:44.397401
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse, dump
    from ..utils.helpers import load_module

# Generated at 2022-06-21 18:21:50.818520
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = 'try:\n yield from range(10)\n except StopIteration as exc:\n var = exc.value'
    expected_code = 'let(iterable)\n iterable = iter(range(10))\n while True:\n try:\n yield next(iterable)\n except StopIteration as exc:\n var = exc.value\n break'
    module = ast.parse(code)
    YieldFromTransformer().visit(module)
    assert expected_code == ast.dump(module)

# Generated at 2022-06-21 18:21:53.080177
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_tree
    from ..utils.helpers import node_to_str


# Generated at 2022-06-21 18:21:55.235626
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test no assertion error is raised
    YieldFromTransformer()

# Generated at 2022-06-21 18:22:06.021615
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from pytest import raises

    tree = ast.parse("""
yield from a
yield from 1
yield from foo()
a = yield from b
f(a = yield from b)
foo = yield from bar
""")


# Generated at 2022-06-21 18:22:13.057294
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''def foo():
    a = yield from range(5)'''
    tree = ast.parse(code)
    assert len(tree.body[0].body) == 1
    tree = YieldFromTransformer().visit(tree)
    assert len(tree.body[0].body) == 3
    assert isinstance(tree.body[0].body[0], ast.Assign)
    assert isinstance(tree.body[0].body[1], ast.Assign)
    assert isinstance(tree.body[0].body[2], ast.While)

# Generated at 2022-06-21 18:22:18.917232
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse('a = yield from generator')
    node = YieldFromTransformer().visit(node)

# Generated at 2022-06-21 18:22:42.328262
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = YieldFromTransformer()
    assert yield_from is not None

# Generated at 2022-06-21 18:22:51.764826
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.parse_util import parse_ast_source, parse_ast_file
    from ..utils.tree_util import compare_trees, compare_source
    example_src = '''
            def foo():
                a = yield from b[1:2]
                c[3:4] = yield from d
                yield from e
            '''

# Generated at 2022-06-21 18:23:00.758232
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3
    import textwrap
    from ctypes import py_object

    text = textwrap.dedent("""
    def f(obj):
        yield from obj
    """)
    expected = textwrap.dedent("""
    def f(obj):
        let(iterable)
        iterable = iter(obj)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)
    result = YieldFromTransformer().visit(ast3.parse(text))
    assert expected == ast3.unparse(result).strip()

    # Test if YieldFromTransformer really works
    m = compile(result, "<test>", "single")
   

# Generated at 2022-06-21 18:23:11.768846
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tree import tree
    from ..utils.source import source

    source_ = '''\
    def f():
        yield from 1
        yield from 2
        try:
            yield from 3
        except:
            a = yield from 4
        a = yield from 5
        a = yield from 6
        yield from 7
    '''


# Generated at 2022-06-21 18:23:21.594426
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils import dump

    code = dedent('''
    def func():
        a = 1
        b = yield from [1, 2, 3]
        yield 1
        c = yield from (1, 2, 3)
        yield 2
        d = ('abc')
        yield 3
    ''')


# Generated at 2022-06-21 18:23:24.598266
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assign_yield_from = ast.parse('x = yield from [1, 2, 3]')

# Generated at 2022-06-21 18:23:25.251139
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-21 18:23:26.618038
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-21 18:23:36.970125
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import parse
    from ..utils.tree_examples import simple_function_from_kwargs
    import astunparse

    src = simple_function_from_kwargs(
        'func', 4,
        arguments=[
            ast.arg('a', None),
            ast.arg('b', None),
            ast.arg('c', None),
            ast.arg('d', None),
            ast.arg('e', None),
        ],
        body=[
            ast.Expr(ast.YieldFrom(ast.Name('e'))),
            ast.Return(ast.Name('a'))
        ]
    )

    print(astunparse.dump(ast.parse(src)))


# Generated at 2022-06-21 18:23:41.602554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import unit_test_ast
    from ..utils.source import source_to_code

    transformer = YieldFromTransformer()
    result = transformer.visit(unit_test_ast(source_to_code(YieldFromTransformer)))
    assert result is not None

# Generated at 2022-06-21 18:24:39.332307
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""
    import textwrap
    input_str = textwrap.dedent("""\
        def test():
            while True:
                yield from test_generator()
        """)
    expected_str = textwrap.dedent("""\
        def test():
            let(iterable)
            iterable = iter(test_generator())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        pass
                    break
        """)
    output_ast, _ = YieldFromTransformer.run_on_single_file(input_str)
    assert ast.dump(output_ast) == expected_str


# Generated at 2022-06-21 18:24:40.283242
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-21 18:24:41.487601
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-21 18:24:45.422431
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Unit test for constructor of class YieldFromTransformer
    node = ast.Expr(value=ast.BinOp(left=ast.Num(n=1), op=ast.Add(), right=ast.Num(n=2)))
    assert YieldFromTransformer.visit(node)

# Generated at 2022-06-21 18:24:49.409978
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer_visit = YieldFromTransformer()

    # Check if class YieldFromTransformer is created
    assert isinstance(test_YieldFromTransformer_visit, YieldFromTransformer)
    assert YieldFromTransformer.__doc__ is not None


# Generated at 2022-06-21 18:24:51.082971
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()


# Generated at 2022-06-21 18:24:52.923072
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_helper import ast_to_str
    from ..utils.helpers import dump_ast

# Generated at 2022-06-21 18:24:55.670126
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try_stmt = ast.Try()
    assert(try_stmt != None)


# Generated at 2022-06-21 18:25:04.263861
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""
    from ..visitors.ast_transformer import ASTTransformer
    from ..compile import compile_ast
    from ..utils.snippet import snippet, let
    instance_expr = ast.Expr(value=ast.Call(func=ast.Name(id='create',
                                                          ctx=ast.Load()),
                                            args=[],
                                            keywords=[]))
    instance_assign = ast.Assign(targets=[ast.Name(id='instance',
                                                   ctx=ast.Store())],
                                 value=instance_expr)
    body = let(x)
    x = 3
    body += let(y)
    y = 2
    body += let(z)
    z = ''

# Generated at 2022-06-21 18:25:15.180330
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("yield from <expr>")

    yield_from_transformer = YieldFromTransformer()
    yield_from_transformer.visit(node)

    # Assert node
    assert isinstance(node, ast.Module)
    assert hasattr(node, 'body')
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.While)
    assert hasattr(node.body[0], 'body')
    assert len(node.body[0].body) == 2
    assert isinstance(node.body[0].body[0], ast.Assign)
    assert isinstance(node.body[0].body[1], ast.Expr)
    assert isinstance(node.body[0].body[1].value, ast.Yield)

# Unit test

# Generated at 2022-06-21 18:27:25.414802
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import os

    class Entity:
        pass

    entity = Entity()


# Generated at 2022-06-21 18:27:27.087176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__.__name__ == "YieldFromTransformer"

# Generated at 2022-06-21 18:27:33.434649
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys

    if sys.version_info >= (3,2):
        from ..utils.test_utils import run_test
        from ..utils.tree import tree_from
        from ..utils.ast_utils import print_ast, compare_asts
        from .test import TestCase

        class YieldFromTestCase(metaclass=TestCase):
            @classmethod
            def transform(cls, source, **options):
                from .transformers.yield_from import YieldFromTransformer

                tree = tree_from(source, **options)
                tree = YieldFromTransformer().visit(tree)
                return print_ast(tree)

            @classmethod
            def assertTransform(cls, source, expected, **options):
                compare_asts(expected, cls.transform(source, **options))


# Generated at 2022-06-21 18:27:44.566443
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import source_to_ast
    from ..utils.helpers import compare_ast
    from ..testing import runner
    from .. import transformations

    source = """
    def example(value):
        while True:
            yield from value
    """
    transformed = """
    def example(value):
        while True:
            exc = VariablesGenerator.generate('exc')
            iterable = iter(value)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc.value
                    break
    """
    module = source_to_ast.parse(source)
    transformations.remove_brackets(module)
    transformations.parenthesize_condition(module)
    transformations.remove_returns(module)
   

# Generated at 2022-06-21 18:27:49.955412
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer.__class__.__name__ == 'YieldFromTransformer'
    assert transformer.target == (3, 2)
    assert transformer._tree_changed is False
    assert transformer.__doc__ == 'Compiles yield from to special while statement.'
    assert str(transformer) == '<YieldFromTransformer>'


# Generated at 2022-06-21 18:27:54.833991
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class MockVisitor:
        def __init__(self):
            self.n_visited = 0

        def visit(self, node: ast.AST) -> ast.AST:
            self.n_visited += 1

        def generic_visit(self, node: ast.AST) -> ast.AST:
            self.n_visited += 1

    visitor = MockVisitor()

# Generated at 2022-06-21 18:28:01.513914
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import from_code, to_code
    from ..utils.misc import add_lineno
    result = to_code(YieldFromTransformer().visit(from_code('''
        def func():
            _ = yield from 1
            _ = (yield from 1) + 2
            yield from 1

        c = (yield from 1)
        d = ((yield from 1)) + 1
        _ = not (yield from 1)
        _ = (yield from 1) and (yield from 2)
    ''')))

# Generated at 2022-06-21 18:28:06.985284
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse("""
    def func():
        a = yield from range(1, 2)
        b = yield from range(1, 2)
        yield from range(1, 2)
    """)
    YieldFromTransformer().visit(module)

# Generated at 2022-06-21 18:28:15.617880
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    testing_node = ast.parse("""def foo():
        yield from bar()""")
    actual_node = ast.dump(YieldFromTransformer().visit(testing_node))
    expected_node = ast.dump(ast.parse("""def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break"""))
    assert actual_node == expected_node

# Generated at 2022-06-21 18:28:25.083329
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    yield_from = ast.YieldFrom(ast.Name('yield_from', ast.Load()))
    assignment = ast.Assign([ast.Name('a', ast.Store())], yield_from)
    expr = ast.Expr(yield_from)
    yield_from_ast = ast.parse(yield_from.__repr__()).body[0]
    module = ast.Module(body=[
        assignment,
        expr,
        assignment,
        expr,
    ])
    transformed_module = YieldFromTransformer().visit(module)