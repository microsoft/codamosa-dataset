

# Generated at 2022-06-25 22:52:55.031693
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:52:58.391900
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return yield_from_transformer_0


# Generated at 2022-06-25 22:53:04.142520
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert callable(YieldFromTransformer)
    
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert isinstance(yield_from_transformer_1, YieldFromTransformer)



# Generated at 2022-06-25 22:53:07.576845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:10.030278
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    # Constructor call
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:12.775457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    # Call the constructor of class YieldFromTransformer
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:16.311459
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    # AssertionError: TypeError is not raised for argument 0:
    # Expected: AST
    # Actual:   int

# Generated at 2022-06-25 22:53:20.492718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert type(yield_from_transformer_0) == YieldFromTransformer
    assert type(yield_from_transformer_1) == YieldFromTransformer

# Generated at 2022-06-25 22:53:29.078790
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: Error: [Errno 2] No such file or directory: 'C:\Users\sebas\OneDrive\Escritorio\Python-Modernize\unit-test-output\test_YieldFromTransformer.py'

import typing as t

# Generated at 2022-06-25 22:53:32.670727
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer, "Unable to find class YieldFromTransformer"
    # test __init__
    assert YieldFromTransformer, "Unable to find method __init__ in class YieldFromTransformer"
    test_case_0()


# Generated at 2022-06-25 22:53:38.496451
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: implement unit test
    pass




# Generated at 2022-06-25 22:53:40.330111
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:43.881721
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('def f():\n  a = yield from x()\n  return a')
    tree = YieldFromTransformer().visit(tree)

    assert 'YieldFromTransformer' in ast.dump(tree, annotate_fields=False, include_attributes=False)


import unittest


# Generated at 2022-06-25 22:53:48.269877
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)

    assert yield_from_transformer.tree is a_s_t
    assert yield_from_transformer.target == (3, 2)



# Generated at 2022-06-25 22:53:57.424193
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # testing try-catch
    a_s_t_1 = module_0.Try(body=[module_0.Expr(value=module_0.YieldFrom(value=module_0.Str(s='1')))],handlers=[module_0.ExceptHandler(body=[module_0.Expr(value=module_0.Str(s='1'))],type=None)],orelse=[],finalbody=[])
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    yield_from_transformer_1.transform()

    # testing while
    a_s_t_2 = module_0

# Generated at 2022-06-25 22:54:00.810696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert a_s_t_0 is yield_from_transformer_0.tree

# Generated at 2022-06-25 22:54:03.042252
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return yield_from_transformer_0


# Generated at 2022-06-25 22:54:05.278327
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0, source_filename="")


# Generated at 2022-06-25 22:54:08.230883
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:54:18.010076
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    try:
        yield_from_transformer_0.visit(module_0.AST())
    except Exception as inst:
        assert isinstance(inst, AttributeError)

if __name__ == '__main__':
    import sys
    import py_compile
    import timeit
    time_tests = [
                   ("test_case_0", "test_case_0()"),
                   ("test_YieldFromTransformer", "test_YieldFromTransformer()"),
               ]
    for name, tests in time_tests:
        t = timeit.Timer(tests, "from __main__ import " + tests)

# Generated at 2022-06-25 22:54:24.627321
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  a_s_t = module_0.AST()
  yield_from_transformer = YieldFromTransformer(a_s_t)


# Generated at 2022-06-25 22:54:27.651992
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:29.468490
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:54:31.607550
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:34.489805
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:54:39.138708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.target == (3, 2))
    assert(yield_from_transformer_0._tree == a_s_t_0)
    assert(not yield_from_transformer_0._tree_changed)


# Generated at 2022-06-25 22:54:41.756636
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)
    


# Generated at 2022-06-25 22:54:48.094544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_11 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_11)
    a_s_t_2 = module_0.AST()
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_2)
    a_s_t_3 = module_0.AST()
    yield_from_transformer_3 = YieldFromTransformer(a_s_t_3)
    a_s_t_4 = module_0.AST()
    yield_from_transformer_4 = YieldFromTransformer(a_s_t_4)


# Generated at 2022-06-25 22:54:50.608930
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:55.454780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0)
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))

# Generated at 2022-06-25 22:55:08.510051
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

    # test for constructor of class YieldFromTransformer



# Generated at 2022-06-25 22:55:10.044585
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = module_0
    return_value_0 = YieldFromTransformer(module_0)


# Generated at 2022-06-25 22:55:13.010445
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:55:25.198393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(ValueError):
        YieldFromTransformer('a', 'b')
    with pytest.raises(ValueError):
        YieldFromTransformer(1.0, 1.0)
    with pytest.raises(ValueError):
        YieldFromTransformer(None, None)
    with pytest.raises(ValueError):
        YieldFromTransformer(False, False)
    with pytest.raises(ValueError):
        YieldFromTransformer(1, 1)
    with pytest.raises(ValueError):
        YieldFromTransformer('a', 1.0)
    with pytest.raises(ValueError):
        YieldFromTransformer(1.0, 1)

# Generated at 2022-06-25 22:55:29.894895
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree_changed
    assert yield_from_transformer_0.tree is a_s_t_0
    assert yield_from_transformer_0.target is (3, 2)
    assert yield_from_transformer_0.parent is None


# Generated at 2022-06-25 22:55:33.700137
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:46.153822
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(Exception):
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        a_s_t_0 = module_0.Assign(targets=[], value=None)
        yield_from_transformer_0.visit(a_s_t_0)
    with pytest.raises(Exception):
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        a_s_t_0 = module_0.Assign(targets=[], value=None)
        yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:55:47.194897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:55:48.181042
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:55:49.045281
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(module_0.AST())

# Generated at 2022-06-25 22:56:10.802194
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Note: You can only call the constructor with the `object` type.
    assert YieldFromTransformer is YieldFromTransformer

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:56:13.294079
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:56:15.273478
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:16.357057
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)


# Generated at 2022-06-25 22:56:20.445569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert_not_equals(None, yield_from_transformer_0)


# Generated at 2022-06-25 22:56:24.596265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:56:28.376737
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree is a_s_t_0
    assert yield_from_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:56:29.171703
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


# Generated at 2022-06-25 22:56:32.265648
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:34.329320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t_r_a_n_s_f_0 = YieldFromTransformer()
    t_r_a_n_s_f_1 = YieldFromTransformer(None)

# Generated at 2022-06-25 22:57:24.579056
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:57:27.248419
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        tree = ast.parse('')
        transformer = YieldFromTransformer(tree)
        assert transformer is not None
    except Exception as e:
        raise AssertionError(e)

# Unit Test for method visit of class YieldFromTransformer

# Generated at 2022-06-25 22:57:29.353130
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    print('Unit test for constructor of class YieldFromTransformer')


# Generated at 2022-06-25 22:57:30.658368
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 22:57:38.050361
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert yield_from_transformer_0.tree == a_s_t_0
    assert yield_from_transformer_0.target == (3, 2)
    assert yield_from_transformer_0._tree_changed == False

if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:57:42.671669
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    # Test for method visit
    try:
        a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    except:
        pass


# Generated at 2022-06-25 22:57:47.613011
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Verify that field tree is set to a_s_t_0
    assert yield_from_transformer_0.tree is a_s_t_0

    # Verify that field _tree_changed is set to False
    assert yield_from_transformer_0._tree_changed is False
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)



# Generated at 2022-06-25 22:57:51.109534
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # ICFG Node
    a_s_t_0 = module_0.AST() # ICFG Node
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:57:54.985431
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0._tree, module_0.AST)
    assert yield_from_transformer_0._tree == a_s_t_0
    assert yield_from_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:57:59.258056
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        yield_from_transformer_0.visit(a_s_t_0)
    except:
        assert False

# Generated at 2022-06-25 22:59:51.483262
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from unittest import mock
    mock_tree = mock.MagicMock()
    a = YieldFromTransformer(mock_tree)
    assert a.tree == mock_tree
    assert a._tree_changed == False


# Generated at 2022-06-25 22:59:52.589496
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('')
    tr = YieldFromTransformer(tree)



# Generated at 2022-06-25 22:59:56.892194
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("yield from [1,2,3]")
    transformer = YieldFromTransformer(tree)
    transformed_tree = transformer.visit(tree)
    assert str(transformed_tree) == '<_ast.Module object at 0x1028c9a90>'

test_YieldFromTransformer()

test_case_0()

# Generated at 2022-06-25 22:59:57.547385
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 23:00:00.004642
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:02.551170
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 23:00:10.067423
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    global a_s_t_0
    global yield_from_transformer_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0,context=None)
    global a_s_t_1
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    a_s_t_2 = yield_from_transformer_0.visit(a_s_t_0)
    a_s_t_3 = yield_from_transformer_0.visit(a_s_t_0)
    a_s_t_4

# Generated at 2022-06-25 23:00:15.636731
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    extend_call_0 = yield_from_transformer_0.extend(x = "the quick brown fox", y = "jumps over the lazy dog")
    get_yield_from_index_call_0 = yield_from_transformer_0._get_yield_from_index(node = a_s_t_0, type_ = "the quick brown fox")
    let_call_0 = yield_from_transformer_0.let(x = "the quick brown fox")
    generic_visit_call_0 = yield_from_transformer_0.generic_visit(node = a_s_t_0)
    visit_call_0

# Generated at 2022-06-25 23:00:16.254243
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 23:00:18.977612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:01:04.742308
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:01:07.833517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Setup
    a_s_t_0 = module_0.AST()
    # Test
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Verification
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 23:01:14.886910
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    

    # Testing using an empty AST
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

    if not hasattr(a_s_t_1, 'body'):
        raise AssertionError('AssertionError: 2: no attribute body')

    if a_s_t_1.body != []:
        raise AssertionError('AssertionError: 3: expected empty list')


    # Testing using an AST with a single return statement
    a_s_t_2 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 23:01:17.126129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 23:01:18.820257
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:01:20.266622
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Constructor should take an ast.AST as argument
    test_case_0()

# Generated at 2022-06-25 23:01:22.130906
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 23:01:24.983187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert hasattr(yield_from_transformer_0, 'a_s_t')


# Generated at 2022-06-25 23:01:25.533322
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(None)


# Generated at 2022-06-25 23:01:28.393491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert not hasattr(yield_from_transformer_0, "tree")
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    assert a_s_t_1.body == []


# Generated at 2022-06-25 23:02:33.654281
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # constructor with parameter a_s_t_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # constructor without parameter target
    yield_from_transformer_0 = YieldFromTransformer()
    # constructor without parameter a_s_t_0
    yield_from_transformer_0 = YieldFromTransformer()
    # constructor without parameter self
    yield_from_transformer_0 = YieldFromTransformer()
    # constructor with parameter tree
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(tree=a_s_t_0)
    # constructor with parameter self, a_s_t_0
    a

# Generated at 2022-06-25 23:02:38.102219
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Test that the target version is set properly
    assert yield_from_transformer_0.target == (3, 2), "Line no: -1"
    # Test that the tree_changed flag is set properly
    assert yield_from_transformer_0.tree_changed == False, "Line no: -1"


# Generated at 2022-06-25 23:02:40.218039
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 23:02:42.447517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 23:02:44.274010
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (yield_from_transformer_0._tree is a_s_t_0)


# Generated at 2022-06-25 23:02:46.674713
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast0 = ast.parse('a = yield from []')
    transform = YieldFromTransformer(ast0)
    assert isinstance(transform.ast, ast.Module)
    assert isinstance(transform.tree, ast.AST)


# Generated at 2022-06-25 23:02:47.214169
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()