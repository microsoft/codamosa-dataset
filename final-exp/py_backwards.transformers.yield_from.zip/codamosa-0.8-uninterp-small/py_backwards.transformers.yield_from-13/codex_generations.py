

# Generated at 2022-06-25 22:52:55.114787
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert True


# Generated at 2022-06-25 22:52:55.923584
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-25 22:53:06.257319
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test case 1
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Test case 2
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    # Test case 3
    a_s_t_2 = module_0.AST()
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_2)
    # Test case 4
    a_s_t_3 = module_0.AST()
    yield_from_transformer_3 = YieldFromTransformer(a_s_t_3)
    # Test case 5
    a_s_

# Generated at 2022-06-25 22:53:08.660017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:10.972256
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer.__new__(YieldFromTransformer)) == YieldFromTransformer
    test_case_0()


# Generated at 2022-06-25 22:53:13.677078
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)


test_case_0()
test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:20.694757
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    a_s_t_0.body.append(module_0.FunctionDef("foo", module_0.arguments(), module_0.suite([module_0.Assign([module_0.Name("x", module_0.Store())], module_0.YieldFrom(module_0.Name("y", module_0.Load())))]),[]))

    import GoogleTransformer
    import astor
    GoogleTransformer.do_transform(a_s_t_0)
    tmp_0 = astor.to_source(a_s_t_0)
    tmp_1 = ast.parse(tmp_0)
    import GoogleTransformer

# Generated at 2022-06-25 22:53:24.469828
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert not hasattr(YieldFromTransformer, '_input')
    assert not hasattr(YieldFromTransformer, '_tree_changed')
    assert not hasattr(YieldFromTransformer, '_visit_original')
    assert not hasattr(YieldFromTransformer, '_visit_method_cache')


# Generated at 2022-06-25 22:53:30.577375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Type error
    try:
        YieldFromTransformer('str')
        assert False
    except TypeError as e:
        assert True
    # Type warning
    from typing import get_type_hints
    hints = get_type_hints(YieldFromTransformer)
    assert hints['self'].__parameters__[0] == Type[BaseNodeTransformer]
    assert hints['tree'].__parameters__[0] == Type[ast.AST]


# Generated at 2022-06-25 22:53:32.830844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:39.318440
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print("test_YieldFromTransformer")

    test_case_0()

    # assert test

if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:42.248945
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:45.196991
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = typed_ast.ast3.AST()
    yield_from_transformer_0 = YieldFromTransformer(module_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:48.993842
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:53:52.816953
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Initialization of class variables
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Test for method visit
    test_case_0()

YieldFromTransformer()

# Generated at 2022-06-25 22:54:02.142217
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_0
    assert isinstance(module_0.__name__, str)
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)
    assert isinstance(yield_from_transformer_0.transformer, YieldFromTransformer)
    assert isinstance(yield_from_transformer_0.env, dict)
    assert isinstance(yield_from_transformer_0.visit, collections.abc.Callable)

# Generated at 2022-06-25 22:54:03.592491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  target0 = (3, 2)
  assert YieldFromTransformer(target0)


# Generated at 2022-06-25 22:54:05.575385
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:09.499095
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree == a_s_t_0
    assert yield_from_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:54:10.403286
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert test_case_0() == None

# Generated at 2022-06-25 22:54:27.173005
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # tests for YieldFromTransformer.visit
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

if __name__ == '__main__':
    import typed_ast.ast3 as ast3
    node = ast3.parse('a()')
    print(ast3.dump(node))
    #target = ast3.parse('b')
    tree_changed, node = YieldFromTransformer(node).visit(node)
    print(ast3.dump(node))

# Generated at 2022-06-25 22:54:30.312208
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)


# Generated at 2022-06-25 22:54:33.498655
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except TypeError as exc:
        assert str(exc) == 'missing 1 required positional argument: \'tree\''
    else:
        assert False


# Generated at 2022-06-25 22:54:37.066021
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:40.021460
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.Module()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:54:42.247696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:44.665969
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test case 1:
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:52.313923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Set new attribute to instance of class YieldFromTransformer
    assert not hasattr(yield_from_transformer_0, 'newAttribute')
    yield_from_transformer_0.newAttribute = 0
    assert hasattr(yield_from_transformer_0, 'newAttribute')

# def test_visit():
#     a_s_t_0 = module_0.AST()
#     yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
#     a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# def test

# Generated at 2022-06-25 22:54:55.337967
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_1)
    assert (yield_from_transformer_2 != None)


# Generated at 2022-06-25 22:54:57.230166
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 22:55:26.480942
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = ast.parse('yield from f()')
    module_1 = ast.parse('f()')
    module_2 = ast.parse('yield from f()')
    module_3 = ast.parse('yield from f()')
    module_4 = ast.parse('yield from f()')
    module_5 = ast.parse('yield from f()')
    module_6 = ast.parse('yield from f()')
    module_7 = ast.parse('yield from f()')
    module_8 = ast.parse('yield from f()')
    module_9 = ast.parse('yield from f()')
    module_10 = ast.parse('yield from f()')
    module_11 = ast.parse('yield from f()')

# Generated at 2022-06-25 22:55:31.357424
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:40.911160
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test number of parameters
    try:
        YieldFromTransformer()
        assert False
    except TypeError:
        assert True

    # Test content of instance variables
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree == a_s_t_0
    assert yield_from_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:55:48.490625
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # default value test
    yield_from_transformer_0 = YieldFromTransformer()
    assert (YieldFromTransformer.target == (3, 2))
    assert (type(YieldFromTransformer.target) == tuple)
    assert (type(yield_from_transformer_0) == YieldFromTransformer)
    assert (yield_from_transformer_0.tree is None)
    assert (yield_from_transformer_0._tree_changed is False)
    assert (yield_from_transformer_0.target == (3, 2))
    assert (yield_from_transformer_0.target == YieldFromTransformer.target)


# Generated at 2022-06-25 22:55:52.260053
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test constructor arguments
    yield_from_transformer_0 = YieldFromTransformer()

    # test return of visit
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_1.visit(a_s_t_0)

# Generated at 2022-06-25 22:55:53.215535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Normal case
    assert YieldFromTransformer(tree=None)



# Generated at 2022-06-25 22:55:57.804040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:56:04.659173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: rewrite
    return
    # try:
    #     a_s_t = ast.AST()
    #     yield_from_transformer = YieldFromTransformer(a_s_t)
    #     assert yield_from_transformer is not None
    # except Exception as e:
    #     if isinstance(e, AttributeError):
    #         print ("Why did it fail?")
    #         print (e)
    #     else:
    #         print ("Fail!")
    #         print (e)


# Generated at 2022-06-25 22:56:06.761186
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:09.123719
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # passing tree
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:54.421983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    try:
        yield_from_transformer_0.visit(a_s_t_0)
    except:
        pass


# Generated at 2022-06-25 22:56:55.369270
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer()
    assert type(result) == YieldFromTransformer

# Generated at 2022-06-25 22:56:58.492590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:56:59.195529
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:57:01.656290
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0


# Generated at 2022-06-25 22:57:02.709829
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: add tests
    assert True


# Generated at 2022-06-25 22:57:04.262733
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 22:57:06.439671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse('3')
    assert YieldFromTransformer(module)


# Generated at 2022-06-25 22:57:08.085696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:09.872528
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(None)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 22:58:57.123918
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Create default instance of YieldFromTransformer
    yield_from_transformer_0 = YieldFromTransformer()
    # Create instance of YieldFromTransformer using ast_tree parameter
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:04.246917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    target = (1, 1)

    # Test if the created object is an instance of YieldFromTransformer and BaseNodeTransformer
    assert isinstance(YieldFromTransformer(target), YieldFromTransformer)
    assert isinstance(YieldFromTransformer(target), BaseNodeTransformer)

    # Test is the variable tree_changed is False after creating the object
    assert YieldFromTransformer(target).tree_changed == False

    # Test is the variable target is set correctly after creating the object
    assert YieldFromTransformer(target).target == (1, 1)

    # Test that the constructor raises a TypeError when no argument is given
    try:
        YieldFromTransformer()
    except TypeError:
        assert True
    else:
        assert False

test_YieldFromTransformer()


# Generated at 2022-06-25 22:59:06.914154
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = None
    assert YieldFromTransformer(tree) is not None

# Generated at 2022-06-25 22:59:08.028253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:59:09.403636
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("x = y")
    transformer = YieldFromTransformer(tree)
    assert transformer.visit(tree)

# Generated at 2022-06-25 22:59:12.850843
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = YieldFromTransformer(target = (3, 2))
    assert(isinstance(a_s_t_0, YieldFromTransformer))


# Generated at 2022-06-25 22:59:22.194153
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    print(a_s_t_1)


if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:59:23.441119
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: Should be tested
    pass


# Generated at 2022-06-25 22:59:24.058375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True == True


# Generated at 2022-06-25 22:59:25.250324
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer
    with pytest.raises(TypeError):
        YieldFromTransformer(module_0.AST())


# Generated at 2022-06-25 23:00:44.480566
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 23:00:48.180114
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Create object
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Call method
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

    # Delete object
    del yield_from_transformer_0

# Generated at 2022-06-25 23:00:50.067355
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:52.760175
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-25 23:00:54.480478
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 23:00:57.951695
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 23:01:00.461617
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 23:01:06.690283
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(4.0) != None # Built-in operation 'NotEq'
    assert YieldFromTransformer([3]) != None # Built-in operation 'NotEq'
    assert YieldFromTransformer(3) != None # Built-in operation 'NotEq'
    assert YieldFromTransformer(float('inf')) != None # Built-in operation 'NotEq'
    assert YieldFromTransformer((-2147483648)) != None # Built-in operation 'NotEq'
    assert YieldFromTransformer('abc') != None # Built-in operation 'NotEq'
    assert YieldFromTransformer(4.0) != None # Built-in operation 'NotEq'
    assert YieldFromTransformer([3]) != None # Built-in operation 'NotEq'
    assert Y

# Generated at 2022-06-25 23:01:08.312165
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)

# Generated at 2022-06-25 23:01:12.163158
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    try:
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except TypeError as e:
        assert type(e) == TypeError

if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 23:02:33.287831
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 23:02:39.485660
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Verify the attributes of instance yield_from_transformer_0
    assert yield_from_transformer_0.tree == a_s_t_0
    # Verify the attributes of instance yield_from_transformer_0
    assert yield_from_transformer_0.tree == a_s_t_0
    assert yield_from_transformer_0._tree_changed == False
    assert yield_from_transformer_0._compiler is None
    assert yield_from_transformer_0.target == (3, 2)
    # Verify the behavior of method visit

# Generated at 2022-06-25 23:02:40.966390
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 23:02:43.297377
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert len(yield_from_transformer_0._context) == 0
    assert yield_from_transformer_0._tree_changed == False


# Generated at 2022-06-25 23:02:47.585995
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test Case 1:
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Test Case 2:
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Test Case 3:
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)