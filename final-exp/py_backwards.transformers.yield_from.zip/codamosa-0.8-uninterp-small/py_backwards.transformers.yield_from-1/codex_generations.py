

# Generated at 2022-06-25 22:52:54.084300
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    assert inspect.isclass(YieldFromTransformer)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert inspect.isfunction(YieldFromTransformer.__init__)
    assert inspect.isfunction(YieldFromTransformer.visit)
    assert inspect.isfunction(YieldFromTransformer.generic_visit)
    assert inspect.isfunction(YieldFromTransformer._get_yield_from_index)
    assert inspect.isfunction(YieldFromTransformer._emulate_yield_from)
    assert inspect.isfunction(YieldFromTransformer._handle_assignments)
    assert inspect.isfunction(YieldFromTransformer._handle_expressions)

# Generated at 2022-06-25 22:52:56.180092
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:00.281608
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0
    assert yield_from_transformer_0.current_scope


# Generated at 2022-06-25 22:53:04.413672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import make_pass_decorator
    from ..utils.testing import load_test_ast

    @make_pass_decorator(YieldFromTransformer)
    def transformer_pass(target):
        return target


# Generated at 2022-06-25 22:53:07.200338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ != None


# Generated at 2022-06-25 22:53:09.661780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:10.520548
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:53:11.374642
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass



# Generated at 2022-06-25 22:53:12.192257
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:14.620679
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0


# Generated at 2022-06-25 22:53:21.032736
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()

if __name__ == "__main__":
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:29.710236
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('a')
    yield_from_transformer = YieldFromTransformer(tree)

    # Constructing object using StringIO object
    # assert isinstance(yield_from_transformer.tree, StringIO), "yield_from_transformer.tree is not initialized properly."
    # assert yield_from_transformer.tree.getvalue() == 'a', "yield_from_transformer.tree is not initialized properly."
    assert isinstance(yield_from_transformer._tree_changed,
                      bool), "yield_from_transformer._tree_changed is not initialized properly."
    assert yield_from_transformer._tree_changed == False, "yield_from_transformer._tree_changed is not initialized properly."


# Generated at 2022-06-25 22:53:30.847970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:53:38.140760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t_0)
    try:
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except TypeError as exc:
        assert isinstance(exc, TypeError)
    try:
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0, a_s_t_0)
    except TypeError as exc:
        assert isinstance(exc, TypeError)


# Generated at 2022-06-25 22:53:40.003902
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:43.192881
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert not isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:48.836998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse(textwrap.dedent('''
        def foo(yf):
            a = yield from yf  # 1
            b = (yield from yf)  # 2
            c = [(yield from yf)]  # 3
            pass
        '''))
    YieldFromTransformer(tree).visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"), {})

# Generated at 2022-06-25 22:53:50.482941
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with raises(AssertionError):
        YieldFromTransformer(target=None)


# Generated at 2022-06-25 22:53:52.934588
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:55.926024
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:54:06.302339
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-25 22:54:08.612557
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # testing constructor
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:13.769289
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.generic_visit = lambda x: x
    yield_from_transformer_0.visit = lambda x: x


# Generated at 2022-06-25 22:54:16.481219
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""def test(): return 'a'""", "", "exec")

    # test __init__(tree: AST) -> None
    assert YieldFromTransformer(tree)._tree is tree



# Generated at 2022-06-25 22:54:20.216396
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:54:23.959854
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    try:
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception:
        yield_from_transformer_0 = None
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:54:26.326289
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as e:
        assert(type(e) == TypeError)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:54:29.382836
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:32.182748
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)
    assert(yield_from_transformer._tree == a_s_t)


# Generated at 2022-06-25 22:54:35.071400
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:54:53.773299
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-25 22:54:56.247211
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:55:04.346123
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    yield_from_transformer_0 = YieldFromTransformer(ast.AST())
    assert isinstance(yield_from_transformer_0, BaseNodeTransformer)
    assert hasattr(yield_from_transformer_0, 'visit')
    assert hasattr(yield_from_transformer_0, 'generic_visit')
    assert not hasattr(yield_from_transformer_0, 'visit_AST')
    assert hasattr(yield_from_transformer_0, '_handle_assignments')
    assert hasattr(yield_from_transformer_0, '_handle_expressions')

# Generated at 2022-06-25 22:55:05.152492
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:55:06.009483
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test Case #0
    test_case_0()

# Generated at 2022-06-25 22:55:07.719309
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()

    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert isinstance(yield_from_transformer_1, YieldFromTransformer)


# Generated at 2022-06-25 22:55:09.502694
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:11.710598
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("")
    yield_from_transformer = YieldFromTransformer(tree)
    assert isinstance(yield_from_transformer.tree, ast.Module)


# Generated at 2022-06-25 22:55:12.618557
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:55:17.369236
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        yield_from_transformer_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:56:01.005444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_3 = YieldFromTransformer(a_s_t_0)

# Unit tests for transform()

# Generated at 2022-06-25 22:56:05.966131
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  tree = module_0.AST()
  yield_from_transformer_0 = YieldFromTransformer(tree)
  assert isinstance(yield_from_transformer_0, YieldFromTransformer)
  assert isinstance(yield_from_transformer_0, BaseNodeTransformer)
  assert yield_from_transformer_0._tree == tree
  assert yield_from_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:56:07.037324
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:56:10.081021
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer, YieldFromTransformer)


# Generated at 2022-06-25 22:56:14.772240
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Try testing with valid arguments
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.target == (3, 2)
    assert yield_from_transformer_0._tree_changed is False
    assert yield_from_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:56:16.721755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  a_s_t_0 = module_0.AST()
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
  assert yield_from_transformer_0 is not None

# Generated at 2022-06-25 22:56:18.309170
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:56:23.066069
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Add your own test cases here
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    assert a_s_t_1 == a_s_t_0


# Generated at 2022-06-25 22:56:27.520063
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        # Test case for constructor for class YieldFromTransformer
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    except:
        assert False



# Generated at 2022-06-25 22:56:31.437922
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformer

    a_s_t_0 = ast3.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:06.744784
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))
    print("yield_from_transformer_0 =", yield_from_transformer_0)

# Generated at 2022-06-25 22:58:08.803008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:11.281835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)
    assert isinstance(yield_from_transformer, YieldFromTransformer)


# Generated at 2022-06-25 22:58:15.155926
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)
    yield_from_transformer_0_0 = YieldFromTransformer(a_s_t_0, a_s_t_1)


# Generated at 2022-06-25 22:58:16.901815
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_4 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_4)


# Generated at 2022-06-25 22:58:21.227202
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t_2)
    assert isinstance(yield_from_transformer.tree, module_0.AST)
    assert yield_from_transformer._tree_changed == None


# Generated at 2022-06-25 22:58:22.965790
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:26.131741
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)



# Generated at 2022-06-25 22:58:27.161643
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # test variable, but only call the constructor
    YieldFromTransformer(None)

# Generated at 2022-06-25 22:58:29.163055
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return