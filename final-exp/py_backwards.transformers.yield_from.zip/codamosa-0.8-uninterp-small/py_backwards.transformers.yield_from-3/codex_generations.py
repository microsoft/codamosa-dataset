

# Generated at 2022-06-25 22:52:54.790148
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        test_case_0()
    except NameError:
        pass
    # Testing constructor of class YieldFromTransformer.

    # Testing method visit()

    # Testing method _handle_assignments()

    # Testing method _handle_expressions()

# Generated at 2022-06-25 22:52:55.632416
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:52:56.736754
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:52:59.314818
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('yield from x')
    yield_from_transformer = YieldFromTransformer(tree)



# Generated at 2022-06-25 22:53:00.444671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:10.315497
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result: str = ''

# Generated at 2022-06-25 22:53:14.310032
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert yield_from_transformer_0._tree_changed == False
    assert yield_from_transformer_0._tree == None

# Generated at 2022-06-25 22:53:15.959425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer.__init__(), types.MethodType)


# Generated at 2022-06-25 22:53:19.972628
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert hasattr(yield_from_transformer_0, 'tree')
    assert hasattr(yield_from_transformer_0, '_tree_changed')


# Generated at 2022-06-25 22:53:24.946040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer((3, 2))
    assert not hasattr(YieldFromTransformer((3, 2)), "__init__")
    assert YieldFromTransformer((3, 2)).target == (3, 2)
    assert not hasattr(YieldFromTransformer((3, 2)), "target")
    assert YieldFromTransformer((3, 2)).visit is not None
    assert not hasattr(YieldFromTransformer((3, 2)), "visit")


# Generated at 2022-06-25 22:53:31.935636
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:37.956666
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Check if of instance YieldFromTransformer
    assert type(yield_from_transformer_0).__name__ == 'YieldFromTransformer'
    # Check instance of YieldFromTransformer
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:42.064708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #Test for constructor of class YieldFromTransformer
    a_s_t = None
    yield_from_transformer = YieldFromTransformer(a_s_t)
    #Test for visit function of class YieldFromTransformer
    a_s_t_2 = yield_from_transformer.visit(a_s_t)

# Generated at 2022-06-25 22:53:44.075268
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:46.824894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:49.799075
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test constructor for class YieldFromTransformer"""
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:53:53.218715
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (yield_from_transformer_0.visit(a_s_t_0) is None)


# Generated at 2022-06-25 22:53:54.401150
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None) is not None


# Generated at 2022-06-25 22:53:56.863600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:59.993832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ast = None
    _YieldFromTransformer_0 = YieldFromTransformer(_ast)

    _ast = None
    _YieldFromTransformer_1 = YieldFromTransformer(_ast)


# Generated at 2022-06-25 22:54:05.743008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None



# Generated at 2022-06-25 22:54:11.016023
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..parse import parse
    from ..analyze import analyze_ast, AnalyzeVisitor
    from ..transform import transform, BaseNodeTransformer

    path = 'tests/fixtures/YieldFromTransformer.py'

    tree = parse(path)
    visitor = AnalyzeVisitor()
    tree = analyze_ast(tree, visitor)

    # Ensure it does not raise
    YieldFromTransformer(tree)
    transform(tree, BaseNodeTransformer)
    print(tree)

# Generated at 2022-06-25 22:54:12.711495
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:54:14.941939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:16.405542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import parse
    from .base import NodeTransformerTestCase


# Generated at 2022-06-25 22:54:19.057116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:23.310647
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    assert repr(YieldFromTransformer(a_s_t_0)) == 'YieldFromTransformer(None)'
    assert YieldFromTransformer(a_s_t_0).context == a_s_t_0
    assert YieldFromTransformer(a_s_t_0).target == (3, 2)



# Generated at 2022-06-25 22:54:25.617712
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit()


# Generated at 2022-06-25 22:54:27.310370
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:36.531174
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0._get_yield_from_index(None, ast.Assign)
    yield_from_transformer_0._emulate_yield_from(None, None)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    #Test for return type of function visit
    assert(isinstance(a_s_t_1, ast.AST) or a_s_t_1 is None)
#Unit test for private method _get_yield_from_index

# Generated at 2022-06-25 22:54:47.473576
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = None
    yield_from_transformer_1 = YieldFromTransformer(node)
    assert yield_from_transformer_1 is not None


# Generated at 2022-06-25 22:54:53.269141
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0, a_s_t_0)
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_0, a_s_t_0, a_s_t_0)

# Generated at 2022-06-25 22:54:54.677700
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert (type(YieldFromTransformer(None)) == YieldFromTransformer)


# Generated at 2022-06-25 22:54:59.261736
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc = VariablesGenerator.generate('exc')
    generator = VariablesGenerator.generate('generator')
    assignment = result_assignment.get_body(exc=exc, target=None)
    yield_from_ast = yield_from.get_body(generator=generator, assignment=assignment, exc=exc)
    yield_from_transformer = YieldFromTransformer(yield_from_ast)

# Generated at 2022-06-25 22:55:02.521616
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Setup arguments for test
    tree = None
    # Setup environment for test
    yield_from_transformer = YieldFromTransformer(tree)
    # Test
    assert yield_from_transformer._tree is None
    assert yield_from_transformer._tree_changed is False


# Generated at 2022-06-25 22:55:03.464452
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-25 22:55:05.191607
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:06.662969
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    try:
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as inst:
        print(inst)


# Generated at 2022-06-25 22:55:09.110094
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """ The constructor of class YieldFromTransformer """
    yield_from_transformer_1 = YieldFromTransformer(None)
    yield_from_transformer_1 = YieldFromTransformer(None, None)

# Generated at 2022-06-25 22:55:12.618840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Test for __init__
    assert yield_from_transformer_0.tree is a_s_t_0

##### End of tests for class YieldFromTransformer #####

# Generated at 2022-06-25 22:55:39.176612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = None
        a_s_t_1 = YieldFromTransformer(a_s_t_0)
    except Exception as e:
        error_type, error_instance = sys.exc_info()[:2]
        print(error_type.__name__, ':', error_instance)
        print(e)
    else:
        print(a_s_t_1)


# Generated at 2022-06-25 22:55:46.562956
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    if isinstance(a_s_t_0, ast.AST):
        assert isinstance(YieldFromTransformer(a_s_t_0),
                          ast.NodeTransformer)
        assert YieldFromTransformer(a_s_t_0).target == (3, 2)
        assert YieldFromTransformer(a_s_t_0).context == {}
        assert YieldFromTransformer(a_s_t_0)._tree_changed == False
    else:
        pass

# Generated at 2022-06-25 22:55:50.777013
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = ast.parse('async def a() -> None:\n  return await func(5)')
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:55:52.487332
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:56.896692
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)

    assert (yield_from_transformer_0 != yield_from_transformer_1)


# Generated at 2022-06-25 22:55:59.542027
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:03.816713
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(yield_from_transformer_0)
    yield_from_transformer_2 = YieldFromTransformer(yield_from_transformer_0)



# Generated at 2022-06-25 22:56:06.511630
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:56:08.150760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:56:16.230098
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    module = ast.parse(
        """
        a = [1, 2, 3]
        b = (2, 3, 4)
        c = {}
        d = yield from a
        e = yield from b
        f = yield from c
        g = yield from a
        """
    )

    # a = [1, 2, 3]
    # b = (2, 3, 4)
    # c = {}
    # d = None
    # e = None
    # f = None
    # let(iterable_0, iterable_1, iterable_2)
    # iterable_0 = iter(a)
    # while True:
    #     try:
    #         d = next(iterable_0)
    #     except StopIteration as exc_0:
    #         if hasattr(exc_

# Generated at 2022-06-25 22:57:00.885749
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        return
    a_s_t = None
    yield_from_transformer = YieldFromTransformer(a_s_t)
    assert isinstance(yield_from_transformer, BaseNodeTransformer)


# Generated at 2022-06-25 22:57:04.149113
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    py_source_0 = 'yield from func()'
    a_s_t_0 = ast.parse(py_source_0)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0 != None)


# Generated at 2022-06-25 22:57:06.837770
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = None
    yield_from_transformer = YieldFromTransformer(a_s_t)
    assert yield_from_transformer is not None


# Generated at 2022-06-25 22:57:07.526996
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:57:09.589564
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:11.170283
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:11.825649
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:57:19.086131
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _a_s_t_0 = None
    _yield_from_transformer_0 = YieldFromTransformer(_a_s_t_0)
    _a_s_t_1 = _yield_from_transformer_0.visit(_a_s_t_0)
    pass


# Generated at 2022-06-25 22:57:22.443290
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    try:
        assert yield_from_transformer_0 is not None
    except:
        print('AssertionError')


# Generated at 2022-06-25 22:57:24.824517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:01.509467
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-25 22:59:03.541626
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:59:10.016442
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test if snippet pass compilation
    assert result_assignment(1, 2) == 2
    assert result_assignment(1) == 1

    # Test if snippet pass compilation
    assert yield_from((i*2 for i in range(3)), 1, 2) == [0, 2, 4]

    # Test if the generated method works
    y = yield_from((i*2 for i in range(3)), 1, 2)
    assert next(y) == 0
    assert next(y) == 2
    assert next(y) == 4



# Generated at 2022-06-25 22:59:14.541748
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)


# Generated at 2022-06-25 22:59:17.351196
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert True


# Generated at 2022-06-25 22:59:24.239440
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_str = None
    yield_from_transformer = YieldFromTransformer(ast_str)
    assert isinstance(yield_from_transformer, YieldFromTransformer)
    assert hasattr(YieldFromTransformer, '_handle_assignments')
    assert hasattr(YieldFromTransformer, '_handle_expressions')


# Generated at 2022-06-25 22:59:25.033166
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer(ast.AST()) is None)



# Generated at 2022-06-25 22:59:27.441977
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert_equal(yield_from_transformer_0.visit(a_s_t_0), None)

################################################################################


# Generated at 2022-06-25 22:59:29.957801
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    assert a_s_t_1 is None


# Generated at 2022-06-25 22:59:34.448423
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    root = ast.parse('''yield from obj''')
    transformer = YieldFromTransformer(root)
    assert transformer.output() == ast.parse('''
try:
    iterable = iter(obj)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
except StopIteration as exc:
    pass
''')

if __name__ == '__main__':
    test_YieldFromTransformer()