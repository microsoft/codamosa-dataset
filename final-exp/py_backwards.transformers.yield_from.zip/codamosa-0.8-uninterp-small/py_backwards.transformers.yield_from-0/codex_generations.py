

# Generated at 2022-06-25 22:52:53.916078
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:52:56.010876
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:52:56.521751
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True == True

# Generated at 2022-06-25 22:52:59.354295
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:09.499412
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit(None)
    a_s_t_0 = module_0.AST()
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1.visit(None)
    yield_from_transformer_2.visit(None)

if __name__ == '__main__':
    import sys
    import logging

# Generated at 2022-06-25 22:53:14.468578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    module_0.Assign(targets=[], value=module_0.YieldFrom(value=module_0.Name(id='', ctx=module_0.Load())))
    module_0.YieldFrom(value=module_0.Name(id='', ctx=module_0.Load()))

# Generated at 2022-06-25 22:53:20.446788
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Test exception code path.
    b_0 = YieldFromTransformer.visit(yield_from_transformer_0, a_s_t_0)

###
### Data for testing
###

YieldFromTransformer.visit.expect_result = None  # type: ignore

YieldFromTransformer.visit.expect_exception = None  # type: ignore

YieldFromTransformer.visit.expect_output = None  # type: ignore



# Generated at 2022-06-25 22:53:23.908768
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-25 22:53:24.717658
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:27.092794
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:35.617396
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:37.699489
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    assert YieldFromTransformer(a_s_t_0) # constructor call with assert


# Generated at 2022-06-25 22:53:40.395066
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:43.344337
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:53:45.976619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exception = None

    try:
        YieldFromTransformer(AST())
    except Exception as err:
        exception = err

    assert(exception == None)


# Generated at 2022-06-25 22:53:51.883180
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    Test the constructor and public methods of class YieldFromTransformer
    """
    ast0 = module_0.AST()
    yield_from_transformer = YieldFromTransformer(ast0)
    try:
        assert not yield_from_transformer.is_tree_changed()
        print('Successful: test_YieldFromTransformer 0')
    except AssertionError:
        print('Failed: test_YieldFromTransformer 0')


# Generated at 2022-06-25 22:53:52.738185
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()



# Generated at 2022-06-25 22:53:54.236889
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('yield from foo()')
    YieldFromTransformer(tree)

# Generated at 2022-06-25 22:53:57.048935
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Define source
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:58.029141
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Test for method visit

# Generated at 2022-06-25 22:54:10.178572
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:13.727359
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:15.457698
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = YieldFromTransformer(None)
    assert isinstance(module_0, YieldFromTransformer)


# Generated at 2022-06-25 22:54:19.440490
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    a_s_t_3 = yield_from_transformer_1.visit(a_s_t_2)


# Generated at 2022-06-25 22:54:23.660379
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import get_node
    import ast as ast_module
    import typing as typing_module
    a_s_t_0 = ast_module.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:54:25.070727
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.AST()
    # No error raised
    YieldFromTransformer(a)

# Generated at 2022-06-25 22:54:27.227001
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test the constructor of the class
    yield_from_transformer_1 = YieldFromTransformer(None)
    # Test the constructor of the class
    yield_from_transformer_2 = YieldFromTransformer(None)


# Generated at 2022-06-25 22:54:32.339290
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert hasattr(YieldFromTransformer, "visit")
    assert hasattr(YieldFromTransformer, "generic_visit")
    assert hasattr(YieldFromTransformer, "target")


# Generated at 2022-06-25 22:54:40.022334
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert hasattr(yield_from_transformer_0, "visit")
    assert hasattr(yield_from_transformer_0, "_emulate_yield_from")
    assert hasattr(yield_from_transformer_0, "_handle_assignments")
    assert hasattr(yield_from_transformer_0, "_handle_expressions")
    assert hasattr(yield_from_transformer_0, "_get_yield_from_index")


# Generated at 2022-06-25 22:54:47.662497
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert a_s_t_0 == yield_from_transformer_0._tree
    assert yield_from_transformer_0._tree_changed
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_1._tree == yield_from_transformer_0._tree
    assert yield_from_transformer_1._tree_changed
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_2._tree == yield_from_transformer_0._tree
    assert yield_from_transformer_

# Generated at 2022-06-25 22:55:12.798093
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Parameterized tests for constructor of class YieldFromTransformer
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert ((yield_from_transformer_0.tree is a_s_t_0) == True) 


# Generated at 2022-06-25 22:55:17.747251
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer()
    YieldFromTransformer()

# Generated at 2022-06-25 22:55:19.748524
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    test_case_0()


# Generated at 2022-06-25 22:55:20.632631
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True



# Generated at 2022-06-25 22:55:23.957426
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert isinstance(yield_from_transformer_1, YieldFromTransformer)

# Generated at 2022-06-25 22:55:31.016773
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0, ast.Try)
        a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    except Exception as e:
        print(e)
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0, ast.If)
        a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 22:55:33.426362
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Arrange
    # Act
    a_s_t_0 = test_case_0()
    # Assert
    assert a_s_t_0 is None

# Generated at 2022-06-25 22:55:39.365280
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for constructor YieldFromTransformer(tree)
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:42.445980
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:55:45.376124
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # creating object of class YieldFromTransformer.
    yield_from_transformer_0 = YieldFromTransformer(module_0.AST())

    yield_from_transformer_0.visit(module_0.AST)


# Generated at 2022-06-25 22:56:29.064468
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 22:56:35.595626
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    raise Exception("This test is expected to fail. In order to do so, please change the value of the line 66 to a non-empty string.")

if __name__ == '__main__':
    import sys
    import nose2
    nose2.main()

# Generated at 2022-06-25 22:56:38.723142
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:56:46.368064
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # TODO:
    # Remove the next line.
    # It is used just to avoid a bug in the tests.
    # Once you have done a real test,
    # remove this line.
    test_case_0()

if __name__ == '__main__':
    import typing
    import astor
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # TODO:
    # Remove the next line.
    # It is used just to avoid a bug in the tests.
    # Once you have done a real test,
   

# Generated at 2022-06-25 22:56:53.196815
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        y = YieldFromTransformer(y)
        assert False, "AssertionError: YieldFromTransformer(y) did not raise"
    except AssertionError:
        pass
    try:
        z = YieldFromTransformer(z)
        assert False, "AssertionError: YieldFromTransformer(z) did not raise"
    except AssertionError:
        pass
    try:
        a = YieldFromTransformer(a)
        assert False, "AssertionError: YieldFromTransformer(a) did not raise"
    except AssertionError:
        pass
    try:
        b = YieldFromTransformer(b)
        assert False, "AssertionError: YieldFromTransformer(b) did not raise"
    except AssertionError:
        pass

# Generated at 2022-06-25 22:57:00.099561
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import convert
    from src.compilers.yieldfrom import YieldFromTransformer
    import sys

# Generated at 2022-06-25 22:57:07.544983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.YieldFrom()
    a_s_t_2 = module_0.FunctionDef('', [], [], a_s_t_1, [])
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_2)
    a_s_t_3 = yield_from_transformer_0.visit(a_s_t_0)
    assert a_s_t_3 is a_s_t_0
    print("Passed unit test")

if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:57:07.952144
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:57:11.142567
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:57:12.019952
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = module_0.AST()
    YieldFromTransformer(tree)

# Generated at 2022-06-25 22:59:08.146039
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.target == (3, 2)
    assert isinstance(yield_from_transformer_0.tree, module_0.AST)


# Generated at 2022-06-25 22:59:09.806126
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:12.554152
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        assert False


# Generated at 2022-06-25 22:59:15.876541
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:17.973577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:23.461127
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse('')
    yield_from_transformer = YieldFromTransformer(module)
    yield_from_transformer.visit(module)

# Generated at 2022-06-25 22:59:28.977787
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(ast_0)
    except NameError:
        pass

try:
    classarg_0 = module_0.ClassDef(class_name_0, class_bases_0, class_keywords_0, class_body_0, class_decorator_list_0, class_starargs_0, class_kwargs_0)
except NameError:
    pass

try:
    raise_0 = module_0.Raise(raise_type_0, raise_inst_0, raise_tback_0)
except NameError:
    pass

try:
    withitem_0 = module_0.withitem(withitem_context_expr_0, withitem_optional_vars_0)
except NameError:
    pass


# Generated at 2022-06-25 22:59:30.416304
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:59:31.267045
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Arrange
    # Act
    # Assert
    assert 1 == 1

# Generated at 2022-06-25 22:59:34.673110
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        # test constructor
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except:
        assert False, "Unable to instantiate YieldFromTransformer."


# Generated at 2022-06-25 23:00:45.634449
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:51.928314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # Unit test for __init__() method of class YieldFromTransformer
    def test_constructor_YieldFromTransformer_0(self):
        yield_from_transformer_0 = YieldFromTransformer(None)
        assert_equal(yield_from_transformer_0.tree, None)
        assert_equal(yield_from_transformer_0.last_unique_id, 0)
        assert_equal(yield_from_transformer_0.last_unique_id_per_file, {})
        assert_equal(yield_from_transformer_0.last_unique_id_per_file, {})



# Generated at 2022-06-25 23:00:54.703526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.node == a_s_t_0)

# Generated at 2022-06-25 23:01:02.203808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test with no exception raised
    try:
        a_s_t_0 = module_0.AST()
        assert isinstance(a_s_t_0, module_0.AST)
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        assert isinstance(yield_from_transformer_0, YieldFromTransformer)
        assert isinstance(str(yield_from_transformer_0), str)
        assert isinstance(repr(yield_from_transformer_0), str)
        a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    except:
        print('Exception raised')

 
if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-25 23:01:04.234476
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert True


# Generated at 2022-06-25 23:01:05.830898
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:01:06.469862
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 23:01:09.269189
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert type(yield_from_transformer_0) == YieldFromTransformer

# Generated at 2022-06-25 23:01:13.754597
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 == yield_from_transformer_1

if __name__ == '__main__':
    test_YieldFromTransformer()
    test_case_0()

# Generated at 2022-06-25 23:01:15.123896
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    YieldFromTransformer(a_s_t_0);