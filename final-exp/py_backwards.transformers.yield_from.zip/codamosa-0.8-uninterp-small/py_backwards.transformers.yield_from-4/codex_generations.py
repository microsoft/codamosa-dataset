

# Generated at 2022-06-25 22:52:52.244017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:52:54.420713
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 22:53:00.363503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = ast.AST()
    yield_from_transformer_0 = yield_from_transformer.YieldFromTransformer(a_s_t_1)
    a_s_t_2 = ast.AST()
    yield_from_transformer_1 = yield_from_transformer.YieldFromTransformer(a_s_t_2)
    return (yield_from_transformer_0, yield_from_transformer_1)

# Generated at 2022-06-25 22:53:03.430237
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:09.157443
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None
    assert yield_from_transformer_0.target == (3, 2)


# Generated at 2022-06-25 22:53:11.333850
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:14.972366
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert a_s_t_1 == yield_from_transformer_1._ast
    assert yield_from_transformer_1._tree_changed == False


# Generated at 2022-06-25 22:53:17.524454
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test 0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:53:21.068773
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    var_0 = None
    var_1 = None
    var_0 = yield_from_transformer_0.visit(var_1)

test_case_0()
test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:25.224143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:36.213578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    name_0 = yield_from_transformer_0.module_name
    assert '' == name_0
    tree_0 = yield_from_transformer_0.tree
    assert a_s_t_0 == tree_0

# Generated at 2022-06-25 22:53:37.786677
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 22:53:43.609858
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:53:47.415744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    module_0.AST().copy(a_s_t_0, yield_from_transformer_0.tree)

# Generated at 2022-06-25 22:53:48.519325
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:50.482738
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(VariablesGenerator.generate('a_s_t_0'))
    assert True == True


# Generated at 2022-06-25 22:53:51.968545
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Run test
    test_case_0()


# Generated at 2022-06-25 22:53:55.097888
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit(a_s_t_0) # should not raise exception

# Generated at 2022-06-25 22:53:56.910835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer(module_0.AST())) == YieldFromTransformer


# Generated at 2022-06-25 22:53:59.362558
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:06.713344
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    new_ast = YieldFromTransformer()
    new_ast = new_ast.visit(new_ast)
    assert(new_ast == ast)

# Generated at 2022-06-25 22:54:16.182739
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_1 = 'a_s_t_1'
    str_2 = 'a_s_t_2'
    str_3 = 'a_s_t_3'
    str_4 = 'a_s_t_4'
    str_5 = 'a_s_t_5'
    str_6 = 'a_s_t_6'
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16

# Generated at 2022-06-25 22:54:18.216367
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj_0 = YieldFromTransformer()
    test_case_0()
    assert obj_0 != None


# Generated at 2022-06-25 22:54:19.282966
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()


# Generated at 2022-06-25 22:54:27.175593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # _get_yield_from_index
    test_YieldFromTransformer_instance = YieldFromTransformer()

    try:
        assert (test_YieldFromTransformer_instance._get_yield_from_index(test_case_0, ast.Expr) == None)
    except AssertionError:
        raise AssertionError("test_YieldFromTransformer:test_get_yield_from_index_0")

    # test_emulate_yield_from

    # test_handle_assignments

    # test_handle_expressions

    # visit

# Generated at 2022-06-25 22:54:29.667363
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'a_s_t_0'
    YieldFromTransformer()


# Generated at 2022-06-25 22:54:31.160161
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert(t is not None)


# Generated at 2022-06-25 22:54:32.338492
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tmp_0 = YieldFromTransformer()



# Generated at 2022-06-25 22:54:34.877697
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_1 = 'a_s_t_1'
    _str_2 = 'a_s_t_2'


# Generated at 2022-06-25 22:54:35.982208
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:54:44.484613
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Setup
    transformer = YieldFromTransformer()

    # Testing
    assert transformer is not None, "Unable to construct a YieldFromTransformer"

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:54:45.516845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer('YieldFromTransformer instance')


# Generated at 2022-06-25 22:54:48.015215
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'a_s_t_0'
    YieldFromTransformer_0 = YieldFromTransformer()  # constructor call
    assert YieldFromTransformer_0 is not None
# END test_YieldFromTransformer()

# Unit test to test visit()

# Generated at 2022-06-25 22:54:49.454285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().target == (3, 2)


# Generated at 2022-06-25 22:54:51.450967
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'a_s_t_0'
    var_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:54:53.574982
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'a_s_t_0'
    this_0 = YieldFromTransformer(str_0)


# Generated at 2022-06-25 22:55:01.916951
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_1: Optional[str] = 'a_s_t_1'
    str_2: Optional[str] = 'a_s_t_2'
    str_3: Optional[str] = 'a_s_t_3'
    str_4: Optional[str] = 'a_s_t_4'
    str_5: Optional[str] = 'a_s_t_5'
    str_6: Optional[str] = 'a_s_t_6'
    str_7: Optional[str] = 'a_s_t_7'
    str_8: Optional[str] = 'a_s_t_8'
    str_9: Optional[str] = 'a_s_t_9'
    str_10: Optional[str] = 'a_s_t_10'

# Generated at 2022-06-25 22:55:03.156634
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(str_0)


test_case_0()

# Generated at 2022-06-25 22:55:07.008803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert_equal(hasattr(YieldFromTransformer, '__init__'), True)
    assert_equal(hasattr(YieldFromTransformer, '__repr__'), True)
    assert_equal(hasattr(YieldFromTransformer, '__str__'), True)
    assert_equal(hasattr(YieldFromTransformer, '__format__'), True)


# Generated at 2022-06-25 22:55:17.506678
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'ret'
    str_1 = 'yield_from_transformer'
    str_2 = 'py_transformer_0'
    str_3 = 'yield_from_transformer.py'
    str_4 = 'py_transformer_1.py'
    __args0__ = {}
    __args0__['yield_from_transformer'] = YieldFromTransformer(__args0__['yield_from_transformer'])
    yield_from_transformer = __args0__.get('yield_from_transformer', __args0__['yield_from_transformer'])
    yield_from_transformer.generic_visit({'yield_from_transformer': yield_from_transformer})
    __args0__['yield_from_transformer'] = Y

# Generated at 2022-06-25 22:55:23.996508
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()


# Generated at 2022-06-25 22:55:29.376715
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Call the constructor
    assert hasattr(YieldFromTransformer, '__call__')
    obj_YieldFromTransformer = YieldFromTransformer()
    assert isinstance(obj_YieldFromTransformer, YieldFromTransformer)

    # Test __repr__
    assert hasattr(obj_YieldFromTransformer, '__repr__')
    assert obj_YieldFromTransformer.__repr__() == '<YieldFromTransformer(3, 2)>'



# Generated at 2022-06-25 22:55:31.433201
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'a_s_t_0'
    assert(YieldFromTransformer(str_0).tree == str_0)


# Generated at 2022-06-25 22:55:44.124684
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'a_s_t_0'
    str_1 = 'a_s_t_1'
    str_2 = 'a_s_t_2'
    str_3 = 'a_s_t_3'
    str_4 = 'a_s_t_4'
    str_5 = 'a_s_t_5'
    str_6 = 'a_s_t_6'

    # Test attribute _tree_changed
    yield_from_transformer = YieldFromTransformer(str_5)
    assert yield_from_transformer._tree_changed == False
    with pytest.raises(AttributeError):
        yield_from_transformer._tree_changed = str_6

    # Test method _get_yield_from_index
    yield_from_transformer = Y

# Generated at 2022-06-25 22:55:45.032690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-25 22:55:50.248282
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()
    test_YieldFromTransformer_0()
    assert test_YieldFromTransformer_1() is None
    assert test_YieldFromTransformer_2() is None

if __name__ == "__main__":
    test_case_0()
    test_YieldFromTransformer_0()
    assert test_YieldFromTransformer_1() is None
    assert test_YieldFromTransformer_2() is None

# Generated at 2022-06-25 22:55:51.071890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:55:52.289372
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:55:55.414334
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj_0 = YieldFromTransformer()
    assert obj_0._get_yield_from_index(obj_0, ast.Assign) is None
    assert obj_0._get_yield_from_index(obj_0, ast.Expr) is None
    assert obj_0._tree_changed is False

# Generated at 2022-06-25 22:55:58.292950
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert (x._tree_changed == True)


# Generated at 2022-06-25 22:56:04.949539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()



# Generated at 2022-06-25 22:56:05.781611
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()


# Generated at 2022-06-25 22:56:07.144943
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    s = YieldFromTransformer()
    test_case_0()
    return s

# Generated at 2022-06-25 22:56:07.909511
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-25 22:56:14.627783
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #
    # 
    #
    #
    str_0 = "str_0"
    str_1 = "str_1"
    ast_0 = ast.Module()
    ast_0.body = [ast.Assign(targets=[ast.Name(id=str_0, ctx=ast.Store())], value=ast.Name(id=str_1, ctx=ast.Load()))]
    ast_1 = YieldFromTransformer(source_code=None, tree=ast_0, debug_mode=False).result
    assert ast.dump(ast_0) == ast.dump(ast_1)

# Generated at 2022-06-25 22:56:18.892918
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_obj = YieldFromTransformer()
    assert test_obj.tree_changed == False
    assert test_obj.result == None
    assert test_obj.old_tree == None
    assert test_obj.new_tree == None
    assert test_obj.target == (3, 2)


# Generated at 2022-06-25 22:56:20.919211
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 22:56:22.665837
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None).__class__.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-25 22:56:32.190487
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 22:56:32.960705
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:56:40.939869
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert True


# Generated at 2022-06-25 22:56:43.750247
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = YieldFromTransformer(tree = '(9)')
    # AssertionError: expected (9) to equal (3, 2) for tree


# Generated at 2022-06-25 22:56:46.028506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('class A:pass');
    yield_from_transformer_0 = YieldFromTransformer(tree)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:56:46.495479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:56:47.604578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:56:49.189646
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:52.665096
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as inst:
        print(inst)
        print("Exception thrown in test_YieldFromTransformer")
        assert False
    assert True


# Generated at 2022-06-25 22:56:54.483303
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:56.156659
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        test_case_0()
    except:
        import traceback
        exception = traceback.format_exc()
        raise Exception(exception)

# Generated at 2022-06-25 22:56:58.282837
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:20.449407
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Create an instance of YieldFromTransformer
    yield_from_transformer_0 = YieldFromTransformer(module_0.AST())
    # Check whether the variable is an YieldFromTransformer instance
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:57:25.158915
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.target
    yield_from_transformer_0._tree_changed
    yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:57:27.101912
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:37.035598
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # verification of attributes
    assert yield_from_transformer_0._tree_changed == False
    # Check if target attribute is right
    assert yield_from_transformer_0.target == (3, 2)
    # Check if attributes are copied properly
    assert yield_from_transformer_0._tree == a_s_t_0
    # Unit test for visit
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:57:40.566527
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 22:57:42.569747
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:44.412578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:47.200081
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:57:50.825732
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit(a_s_t_0)



# Generated at 2022-06-25 22:57:54.001480
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        module_0 = ast.parse('''
                try:
                    x = yield from g
                except StopIteration as exc:
                    y = exc.value
            ''')
        yield_from_transformer_0 = YieldFromTransformer(module_0)
        assert yield_from_transformer_0 is not None
    except Exception as err:
        print(err)


# Generated at 2022-06-25 22:58:26.293647
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert False


# Generated at 2022-06-25 22:58:27.024122
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass



# Generated at 2022-06-25 22:58:28.755726
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = YieldFromTransformer(ast.parse(""))

# python -m unittest -v test_yield_from

# Generated at 2022-06-25 22:58:30.062104
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    target = (3, 2)
    yield_from_transformer_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:58:32.044088
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    YieldFromTransformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:37.056796
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc_0 = VariablesGenerator.generate('exc')
    if hasattr(exc_0, 'value'):
        target_0 = exc_0.value
    else:
        target_0 = None
    yield_from_transformer_0 = YieldFromTransformer(target_0)
    yield_from_transformer_0.visit(target_0)


# Generated at 2022-06-25 22:58:38.885810
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    AST_1 = module_0.AST()

    YieldFromTransformer_0 = YieldFromTransformer(AST_1)


test_YieldFromTransformer()
test_case_0()

# Generated at 2022-06-25 22:58:39.286402
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:58:42.036738
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Test if assert is not raised
    assert yield_from_transformer_0._tree_changed == False



# Generated at 2022-06-25 22:58:42.681719
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:59:41.899947
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:59:42.707038
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:59:43.998561
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-25 22:59:45.618221
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:47.598501
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  a_s_t_0 = module_0.AST()
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

if __name__ == '__main__':
  test_case_0()
  test_YieldFromTransformer()

# Generated at 2022-06-25 22:59:52.617559
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Running test for constructor of class YieldFromTransformer
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    #test case for line 65
    #test case for line 67
    assert(a_s_t_0 is yield_from_transformer_0.tree)
    #test case for line 68
    assert(a_s_t_0 is yield_from_transformer_0._tree)
    #test case for line 69
    assert(False is yield_from_transformer_0._tree_changed)


# Generated at 2022-06-25 22:59:56.674515
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # check if tree is not None
    assert tree is not None
    # check if YieldFromTransformer is success
    assert isinstance(YieldFromTransformer(tree), YieldFromTransformer)
    # check if class return not None
    assert tree is not None
    # check if tree is changed
    assert is_tree_changed is True

# Generated at 2022-06-25 22:59:58.741846
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:02.165157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.tests.test_transforms.module_0 import a_s_t_0
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (isinstance(yield_from_transformer_0, module_0.NodeTransformer))
    assert (isinstance(yield_from_transformer_0, object))


# Generated at 2022-06-25 23:00:06.175552
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

if __name__ == '__main__':
    test_YieldFromTransformer()
    import unittest
    unittest.main()