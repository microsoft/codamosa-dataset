

# Generated at 2022-06-25 22:52:55.778936
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:53:00.444833
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None

if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:03.503239
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:53:06.378420
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:11.570810
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = ast.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)

# Unit tests for methods of class YieldFromTransformer

# Generated at 2022-06-25 22:53:13.636756
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:14.777303
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer(tree)


# Generated at 2022-06-25 22:53:17.087506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:19.037686
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:19.774014
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:53:27.987026
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    f = open("test.txt", "a")
    f.write("test_YieldFromTransformer\n")
    f.close()


# Generated at 2022-06-25 22:53:30.557587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:36.045281
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test no.1
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

    assert a_s_t_1 is not a_s_t_0


# Generated at 2022-06-25 22:53:38.066868
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:42.108112
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    
    # Initalize a AST object
    ast_0 = module_0.AST()
    
    # Create an instance of YieldFromTransformer
    yield_from_transformer_0 = YieldFromTransformer(ast_0)
    
    # Call a method of YieldFromTransformer
    res = yield_from_transformer_0.visit(ast_0)
    
    # Assert if the result is correct
    assert res == ast_0
    
    return


# Generated at 2022-06-25 22:53:44.615577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  # Setup
  try:
    YieldFromTransformer(None)
    assert False
  except AssertionError:
    pass

  # Teardown
  tear_down()


# Generated at 2022-06-25 22:53:47.636245
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Creates empty AST node"""
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)


# Generated at 2022-06-25 22:53:50.483008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = ast.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)
    assert yield_from_transformer is not None


# Generated at 2022-06-25 22:53:54.319791
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:53:57.892855
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:54:10.178340
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 22:54:16.170749
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # default is not used
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)

    # validates that the code is compiled only once
    yield_from_transformer_1.visit(a_s_t_2)
    yield_from_transformer_1.visit(a_s_t_2)


# Generated at 2022-06-25 22:54:20.623751
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse(u'x = yield from range(10)')
    yield_from_transformer = YieldFromTransformer(module)
    module = yield_from_transformer.visit(module)
    code = compile(module, '', 'exec')

# Generated at 2022-06-25 22:54:22.470275
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        YieldFromTransformer()

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:54:29.016615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # get the AST of the test file
    a_s_t = ast.parse(test_file)
    # get the transformer
    yield_from_transformer = YieldFromTransformer(a_s_t)
    # ensure class attributes exist
    assert hasattr(yield_from_transformer, 'visit_YieldFrom')
    assert hasattr(yield_from_transformer, '_get_yield_from_index')
    assert hasattr(yield_from_transformer, '_emulate_yield_from')
    assert hasattr(yield_from_transformer, '_handle_assignments')
    assert hasattr(yield_from_transformer, '_handle_expressions')
    # ensure class attributes are of correct type

# Generated at 2022-06-25 22:54:29.909652
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: Script: Add unit tests
    pass

# Generated at 2022-06-25 22:54:33.742345
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(tree)
    assert isinstance(yield_from_transformer_0,YieldFromTransformer)

# Unit tests for visit of class YieldFromTransformer

# Generated at 2022-06-25 22:54:37.292449
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception:
        f = 0
    else:
        f = 1
    assert f



# Generated at 2022-06-25 22:54:42.288668
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    try:
        yield_from_transformer_0.visit(a_s_t_0)
    except Exception as exc:
        print(exc)
        assert False

if __name__ == "__main__":
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:54:44.566348
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)


# Generated at 2022-06-25 22:54:52.758094
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:01.156877
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    f_module_0 = (
        "def f():\n"
        + "    yield from 1\n"
        + "    yield from 2 if 3 else 4\n"
        + "    yield from 5\n"
        + "    yield from 6 if 7 else 8\n"
        + "    yield from 9\n"
        + "    yield from 10 if 11 else 12\n"
    )

# Generated at 2022-06-25 22:55:04.232571
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree == a_s_t_0

# Generated at 2022-06-25 22:55:06.860471
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Should throw TypeError for wrong argument types
    with pytest.raises(TypeError):
        YieldFromTransformer(None)
    # Should not throw error for correct argument types
    YieldFromTransformer()


# Generated at 2022-06-25 22:55:08.789689
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:55:10.699249
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:13.629291
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:19.508192
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:21.684865
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:22.516290
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    assert YieldFromTransformer

# Generated at 2022-06-25 22:55:40.959342
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.tree == a_s_t_0)
    assert(yield_from_transformer_0.tree == a_s_t_0)
    assert(not yield_from_transformer_0.tree_changed)
    assert(not yield_from_transformer_0.tree_changed)


# Generated at 2022-06-25 22:55:43.307315
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:48.742621
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    res_0 = yield_from_transformer_0.visit(a_s_t_0)
    module_0.Assign(module_0.Name('foo', module_0.Load()), module_0.Call(module_0.Name('func', module_0.Load()), [], []))

# Generated at 2022-06-25 22:55:55.088109
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from unittest import mock, TestCase
    class TestYieldFromTransformer(TestCase):
        def setUp(self):
            self.target = mock.Mock()
            self.target.target = (3, 2)
            self.tree = mock.Mock()
        def test_case_0(self):
            a_s_t_0 = mock.Mock()
            yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
            a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
            self.assertEqual(a_s_t_1, a_s_t_0)
    return TestYieldFromTransformer


# Generated at 2022-06-25 22:55:55.794594
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert 2 == 2


# Generated at 2022-06-25 22:56:04.346909
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = (module_0.YieldFrom(module_0.Name('TARGET')),)
    a_s_t_1 = (module_0.Assign(a_s_t_0, module_0.Name('EXP')),)
    a_s_t_2 = module_0.Module(body=a_s_t_1)
    yield_from_transformer_0 = YieldFromTransformer(target=(3, 2))
    a_s_t_3 = yield_from_transformer_0.visit(a_s_t_2)


# Generated at 2022-06-25 22:56:12.475836
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Assert transformations to AST for YieldFromTransformer constructor is {'YieldFromTransformer': [('A_S_T', a_s_t_0, 'a', 'a_s_t_0'), ('a_s_t', a_s_t_1, 'a', 'a_s_t_1')], 'Lambda': [], 'If': [], 'Attribute': [], 'Add': [], 'Sub': [], 'Div': [], 'Mult': [], 'Mod': [], 'Pow': [], 'LShift': [], 'RShift': [], 'BitOr': [], 'BitXor': [], 'BitAnd': [],

# Generated at 2022-06-25 22:56:15.980446
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_2 = module_0.AST()
        yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
        assert(yield_from_transformer_1.tree == a_s_t_2)
    except:
        assert(0)


# Generated at 2022-06-25 22:56:16.592761
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:56:20.136704
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert yield_from_transformer_1 is not None


# Generated at 2022-06-25 22:56:39.604533
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)

# Generated at 2022-06-25 22:56:41.741733
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    target = (a)
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:43.751480
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)


# Generated at 2022-06-25 22:56:48.620838
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('a = (yield from b)')
    target = ('yield from', ast.YieldFrom)
    target_code = 'a = (next(iter(b)))'
    expected_tree = ast.parse(target_code)
    transformer = YieldFromTransformer(tree)
    expected_tree = ast.Module(body=expected_tree.body)
    transformed_tree = transformer.visit(tree)

    assert ast.dump(transformed_tree) == ast.dump(expected_tree)
    assert transformer.tree_changed is True
    assert transformer.target == target


# Generated at 2022-06-25 22:56:53.403718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Case 0
    a_s_t_1 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)
    a_s_t_2 = yield_from_transformer_0.visit(a_s_t_1)
    # Should be:
    # a_s_t_2 = module_0.AST()
    # assert a_s_t_2 == a_s_t_2
    pass


# Generated at 2022-06-25 22:56:56.938844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    assert a_s_t_0
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:56:58.708274
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)

# Generated at 2022-06-25 22:57:02.375338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    assert(a_s_t_1 is a_s_t_0)

# Generated at 2022-06-25 22:57:03.916004
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    if __name__ == '__main__' and __package__ is None:
        yield_from_transformer_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:57:06.628461
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return

# Generated at 2022-06-25 22:57:34.848410
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

if __name__ == "__main__":
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:57:38.400038
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_1.generic_visit
    # assert YieldFromTransformer.generic_visit


# Generated at 2022-06-25 22:57:42.466415
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    target = (3, 2)
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

    assert target == yield_from_transformer_0.target


# Generated at 2022-06-25 22:57:45.098489
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = ast.Module([])
    yield_from_transformer_0 = YieldFromTransformer(module_0)
    assert yield_from_transformer_0._tree == module_0
    assert yield_from_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:57:45.554750
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-25 22:57:47.296768
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return

# Generated at 2022-06-25 22:57:50.143261
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:58.078363
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:58:02.574233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert isinstance(yield_from_transformer_1.snippets, module_0.AST)
    assert isinstance(yield_from_transformer_1.tree_changed, bool)
    assert yield_from_transformer_1.tree_changed == False


# Generated at 2022-06-25 22:58:04.679573
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:31.857960
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # All variables that are used to determine if the test is successful
    code_tree = ast.parse("def foo():\n    yield from iterable")
    foo_node = code_tree.body[0]
    yield_from_node = foo_node.body[0].value

    transformer = YieldFromTransformer(code_tree)
    transformer.visit(code_tree)
    assert isinstance(foo_node.body[0], ast.Assign)  # type: ignore
    assert isinstance(yield_from_node.ctx, ast.Load)  # type: ignore

# Generated at 2022-06-25 22:58:34.287123
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:37.356023
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except:
        assert False

    assert True



# Generated at 2022-06-25 22:58:38.911580
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # Test case #0
    test_case_0()

##########################

if __name__ == '__main__':
    # Unit test
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:58:41.639249
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_1
    a_s_t_2 = module_1.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert hasattr(yield_from_transformer_1, "visit")

# Generated at 2022-06-25 22:58:43.981132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(tree=a_s_t_0)
    return


# Generated at 2022-06-25 22:58:45.728011
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)

test_case_0()

# Generated at 2022-06-25 22:58:49.301824
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    a_s_t_1 = ast.Module([])
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_2 = ast.AST()
    a_s_t_3 = ast.Modu

# Generated at 2022-06-25 22:58:49.886316
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:58:51.245898
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:44.641248
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:59:46.049221
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:48.034187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.target == 3.2)


# Generated at 2022-06-25 22:59:55.678788
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer._tree == None
    assert YieldFromTransformer._tree_changed == False
    assert YieldFromTransformer._future_imports == None
    a_s_t_0 = module_0.AST()
    assert a_s_t_0._fields == ['body']
    assert a_s_t_0._attributes == ['lineno', 'col_offset']
    assert a_s_t_0.lineno == None
    assert a_s_t_0.col_offset == None
    assert a_s_t_0.body == []
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree == a_s_t_0
    assert yield_from_transformer_0._tree

# Generated at 2022-06-25 22:59:58.201799
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:59:59.778825
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:01.327906
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = module_0.AST()
    yield_from_transformer = YieldFromTransformer(tree)


# Generated at 2022-06-25 23:00:03.768229
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
# Unit test is not supported for class YieldFromTransformer


# Generated at 2022-06-25 23:00:06.575697
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('pass')
    transformer = YieldFromTransformer(tree)
    assert isinstance(transformer, YieldFromTransformer)


# Generated at 2022-06-25 23:00:08.900613
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:01:11.743388
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert yield_from_transformer_1._tree == a_s_t_2
    assert yield_from_transformer_1._tree_changed == False
    assert yield_from_transformer_1.target == (3, 2)


# Generated at 2022-06-25 23:01:12.894534
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = test_case_0()
    print(a_s_t)

# Generated at 2022-06-25 23:01:14.651860
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)
    instance_0 = YieldFromTransformer()
    assert isinstance(instance_0, YieldFromTransformer)
    assert isinstance(instance_0, BaseNodeTransformer)

# Generated at 2022-06-25 23:01:17.149966
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 23:01:18.235044
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = test_case_0()


# Generated at 2022-06-25 23:01:20.739114
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import test_case_0
    test_case_0.test_case_0()

if __name__ == '__main__':
    from . import test_case_0
    test_case_0.test_case_0()

# Generated at 2022-06-25 23:01:22.571149
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 23:01:24.875252
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = YieldFromTransformer()
    a_s_t_1 = YieldFromTransformer.__init__(a_s_t_0, None)

# Generated at 2022-06-25 23:01:26.134043
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return


# Generated at 2022-06-25 23:01:28.460384
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)

import typed_ast._ast3 as module_0
