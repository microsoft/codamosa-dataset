

# Generated at 2022-06-25 22:52:53.418390
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:52:55.814593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit()

# Generated at 2022-06-25 22:52:56.591901
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-25 22:53:05.216771
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for instance attribute '_tree_changed'
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Test for instance method 'visit'
    func_def_0 = module_0.FunctionDef()
    func_def_0.body = [module_0.YieldFrom()]
    func_def_0.body[0].value = module_0.Name()
    func_def_0.body[0].value.id = 'a'

    yield_from_transformer_0.visit(func_def_0)

# Generated at 2022-06-25 22:53:07.389687
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a)


# Generated at 2022-06-25 22:53:16.077878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    try:
        yield_from_transformer_0.visit(None)
    except NotImplementedError:
        pass
    try:
        yield_from_transformer_0.visit_Module(None)
    except NotImplementedError:
        pass
    try:
        yield_from_transformer_0.visit_Interactive(None)
    except NotImplementedError:
        pass
    try:
        yield_from_transformer_0.visit_Expression(None)
    except NotImplementedError:
        pass

# Generated at 2022-06-25 22:53:19.301025
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.tree == a_s_t_0)
    assert(YieldFromTransformer.target == (3, 2))


# Generated at 2022-06-25 22:53:21.176365
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:23.498407
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:31.447494
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


###############################################################################
# Output:
#
# result_assignment = let('exc', exc)
# result_assignment += let(target, 'exc.value')
#
# yield_from = let('iterable', iter)
# yield_from += while(true):
# yield_from +=     try:
# yield_from +=         yield next(iterable)
# yield_from +=     except StopIteration as 'exc':
# yield_from +=         extend(assignment)
# yield_from +=         break

# Generated at 2022-06-25 22:53:38.213041
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
    yield_from_transformer_0 = YieldFromTransformer()
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)

# Generated at 2022-06-25 22:53:39.071557
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()
    assert YieldFromTransformer()

# Generated at 2022-06-25 22:53:48.993235
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node_1 = ast.parse('x=yield from z', mode='exec')
    assert isinstance(node_1, ast.Module)
    yield_from_transformer_2 = YieldFromTransformer()
    node_3 = yield_from_transformer_2.visit(node_1)
    assert isinstance(node_3, ast.Module)
    assert node_3.body[0].value.value.elts[0].value.value.value.elts[0].target.id == 'exc'
    assert node_3.body[0].value.value.elts[0].value.value.value.elts[0].value.elts[0].value.id == 'exc'

# Generated at 2022-06-25 22:53:50.254701
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:53:52.695228
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert isinstance(yield_from_transformer, YieldFromTransformer)


# Generated at 2022-06-25 22:53:53.868950
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer() is not None)


# Generated at 2022-06-25 22:54:00.267092
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    original_node = ast.Module(body=[ast.Expr(value=ast.Call(func=ast.Name(id="print",
                                                                            ctx=ast.Load()),
                                                             args=[ast.Str(s='Hello World!')],
                                                             keywords=[]))])
    yield_from_transformer = YieldFromTransformer()
    new_node = yield_from_transformer.visit(original_node)


# Generated at 2022-06-25 22:54:02.401702
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)

# Generated at 2022-06-25 22:54:03.514794
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_1 = YieldFromTransformer()


# Generated at 2022-06-25 22:54:04.925631
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    Transformer to compile yield from to special while statement
    """
    pass


# Generated at 2022-06-25 22:54:17.963092
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()
    assert yield_from_transformer_0 is not None

test_cases = [
    test_case_0,
    test_YieldFromTransformer,
]



# Generated at 2022-06-25 22:54:20.583022
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # Constructor
    yield_from_transformer = YieldFromTransformer()
    assert (yield_from_transformer is not None)


# Generated at 2022-06-25 22:54:21.776892
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_1 = YieldFromTransformer()


# Generated at 2022-06-25 22:54:22.628654
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:54:23.773108
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  assert(str(YieldFromTransformer()) == "<YieldFromTransformer()>")

# Generated at 2022-06-25 22:54:24.590412
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 22:54:25.653840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-25 22:54:26.151755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:54:26.903248
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO:
    pass


# Generated at 2022-06-25 22:54:28.980556
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer(), 'visit')



# Generated at 2022-06-25 22:54:41.868134
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:54:42.706862
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:54:43.891929
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(3.2)


# Generated at 2022-06-25 22:54:50.008023
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    verbose = False
    if verbose:
        print("Unit test for constructor of class YieldFromTransformer")
        print("type(ast) is " + str(type(ast)))
    # type(ast) is <class '_ast.AST'>
    a_s_t_2 = ast.AST()
    if verbose:
        print("type(a_s_t_2) is " + str(type(a_s_t_2)))
    # type(a_s_t_2) is <class '_ast.AST'>
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    if verbose:
        print("type(yield_from_transformer_1) is " + str(type(yield_from_transformer_1)))
    # type

# Generated at 2022-06-25 22:54:50.991022
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:54:55.376774
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:58.441750
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
            a_s_t_0 = module_0.AST()
            yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
            assert True
    except Exception as error:
            print(error)
            assert False


# Generated at 2022-06-25 22:55:05.576061
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert_true(isinstance(yield_from_transformer_0,YieldFromTransformer))
    assert_true(hasattr(yield_from_transformer_0, '_tree_changed'))
    assert_true(hasattr(yield_from_transformer_0, 'tree'))
    assert_equal(yield_from_transformer_0._tree_changed, False)
    assert_equal(yield_from_transformer_0.tree, a_s_t_0)


# Generated at 2022-06-25 22:55:07.559784
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)


# Generated at 2022-06-25 22:55:09.390343
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:55:31.432934
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:33.775577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:39.076905
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:43.556244
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:45.711954
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:51.681758
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    in_0 = module_0.AST()
    assert repr(in_0) == repr(module_0.AST())
    assert in_0 == module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(in_0)
    assert repr(yield_from_transformer_0) == repr(YieldFromTransformer(in_0))
    assert yield_from_transformer_0 == YieldFromTransformer(in_0)
    assert yield_from_transformer_0 == yield_from_transformer_0


# Generated at 2022-06-25 22:55:54.444683
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (yield_from_transformer_0.tree == a_s_t_0)


# Generated at 2022-06-25 22:55:55.729265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)


# Generated at 2022-06-25 22:56:06.224233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

if __name__ == "__main__":
    import sys
    import inspect
    import doctest

    if len(sys.argv) == 1:
        doctest.testmod()
    else:
        for arg in sys.argv[1:]:
            try:
                module = __import__(arg)
                print(module)
            except ImportError:
                print("Can't import " + arg + " module!")
            for name in dir(module):
                if name[0] != '_':
                    item = getattr(module, name)
                    if inspect.isclass(item) and item.__module__ == module.__name__:
                        test_case_name = "test_" + module.__name__ + "_" + item.__name__

# Generated at 2022-06-25 22:56:08.151234
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:50.890352
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # arrguments type check
    with pytest.raises(TypeError):
        YieldFromTransformer(1)



# Generated at 2022-06-25 22:56:53.569524
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    a_s_t_3 = yield_from_transformer_1.visit(a_s_t_2)

# Generated at 2022-06-25 22:56:56.454901
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Unit test for method visit of class YieldFromTransformer
    test_case_0()

if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:56:58.579460
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:57:06.628514
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # body_0 is an object of class AST
    body_0 = ast.Expr(value=ast.Name(id='True', ctx=ast.Load()))
    # body_1 is an object of class AST
    body_1 = ast.Expr(value=ast.Name(id='True', ctx=ast.Load()))
    # body_2 is an object of class AST
    body_2 = ast.Expr(value=ast.Name(id='True', ctx=ast.Load()))
    # body_3 is an object of class AST
    body_3 = ast.Expr(value=ast.Name(id='True', ctx=ast.Load()))
    # body_4 is an object of class AST

# Generated at 2022-06-25 22:57:09.655708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    module_0.Module(body=[])
    yield_from_transformer_2 = YieldFromTransformer()



# Generated at 2022-06-25 22:57:10.804744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0.AST()
    YieldFromTransformer(module_0.AST())


# Generated at 2022-06-25 22:57:12.348062
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:57:19.213349
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:57:21.661259
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.target == (3, 2)


# Generated at 2022-06-25 22:59:07.875229
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree == a_s_t_0


# Generated at 2022-06-25 22:59:10.136047
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:59:14.743684
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:18.530262
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    # Asserts and raises for constructor of class YieldFromTransformer
    assert isinstance(yield_from_transformer_1, YieldFromTransformer)


# Generated at 2022-06-25 22:59:24.639872
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(a_s_t_1.body == [])
    assert(a_s_t_1.type_ignores == [])
    assert(a_s_t_1.type_comments == [])
    assert(yield_from_transformer_0.tree_changed == True)

# Generated at 2022-06-25 22:59:26.381182
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_ast = module_0.AST()
    yield_from_transformer = YieldFromTransformer(module_ast)
    assert isinstance(yield_from_transformer, YieldFromTransformer)


# Generated at 2022-06-25 22:59:28.501185
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0 is not None)


# Generated at 2022-06-25 22:59:29.931832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:32.330941
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert isinstance(yield_from_transformer_1, YieldFromTransformer)


# Generated at 2022-06-25 22:59:34.323487
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)
    assert yield_from_transformer_0 is not None
