

# Generated at 2022-06-25 22:52:48.673041
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:52:50.705367
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return yield_from_transformer_0

# Generated at 2022-06-25 22:52:53.192137
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return YieldFromTransformer(a_s_t_1)

# Generated at 2022-06-25 22:52:57.734993
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree_changed == False
    assert yield_from_transformer_0._target == (3, 2)
    assert yield_from_transformer_0._tree == a_s_t_0


# Generated at 2022-06-25 22:53:00.444248
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:03.502760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:07.478062
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test setup
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    def a_s_t_0_visit(self, a_s_t_0_node):
        return self.generic_visit(a_s_t_0_node)
    # Test setup


# Generated at 2022-06-25 22:53:09.905510
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:12.037074
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        test_case_0()
    except:
        assert False

module_0 = sys.modules['typed_ast._ast3']


# Generated at 2022-06-25 22:53:15.046720
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 22:53:22.342256
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:29.538619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: TypeError: object.__init__() takes no parameters


# Generated at 2022-06-25 22:53:32.052673
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:35.874350
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import ast
    from .base import NodeTransformer

    a_s_t_0 = ast
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:38.776558
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    if "AssertionError" in test_case_0():
        print("Unit test for constructor of class YieldFromTransformer")
        print("Passed")
    else:
        print("Unit test for constructor of class YieldFromTransformer")
        print("Failed")

# Generated at 2022-06-25 22:53:41.022517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        assert True
    except:
        assert False


# Generated at 2022-06-25 22:53:42.432322
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(module_0.AST()), YieldFromTransformer)


# Generated at 2022-06-25 22:53:42.964593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-25 22:53:43.461717
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:53:46.119123
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:53.705375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:56.052498
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:57.048620
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert test_case_0() is None

# Generated at 2022-06-25 22:53:59.500995
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:01.394085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    c = YieldFromTransformer(None)
    assert type(c) == YieldFromTransformer

# Generated at 2022-06-25 22:54:03.971078
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (yield_from_transformer_0 is not None)


# Generated at 2022-06-25 22:54:06.863424
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)



# Generated at 2022-06-25 22:54:08.940059
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:11.168827
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:15.088247
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (yield_from_transformer_0._tree_changed == False)


# Generated at 2022-06-25 22:54:26.272672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 22:54:28.938547
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_0 = None
    yield_from_transformer_0 = YieldFromTransformer(ast_0)


# Generated at 2022-06-25 22:54:32.103006
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:34.952749
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer
    my_tree = t("my_tree")
    test_YieldFromTransformer_0(my_tree)


# Generated at 2022-06-25 22:54:37.828421
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import testutils
    from ..utils.testutils import CustomTestCase
    
    with testutils.NodeTestCase(YieldFromTransformer) as base:
        with CustomTestCase(base):
            test_case_0()

# Generated at 2022-06-25 22:54:40.773682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = ast.Module([], [])
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert(not yield_from_transformer_1._tree_changed)


# Generated at 2022-06-25 22:54:44.009007
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (yield_from_transformer_0.visit(a_s_t_0) is None)


# Generated at 2022-06-25 22:54:45.834088
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = None
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        # ValueError
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 22:54:47.826422
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..trees.yield_from import tree
    from ..trees.yield_from import expected
    t = YieldFromTransformer(tree)
    assert t.visit(tree) == expected

# Generated at 2022-06-25 22:54:49.224032
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)


# Generated at 2022-06-25 22:55:07.342426
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Try to instantiate with a ast.Module subobject
    a_s_t_0 = ast.Module(body=[])
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(isinstance(yield_from_transformer_0, BaseNodeTransformer))

    # Try to instantiate with a ast.Module subobject
    a_s_t_1 = ast.Module(body=[])
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert(isinstance(yield_from_transformer_1, BaseNodeTransformer))

    # Try to instantiate with a ast.Module subobject
    a_s_t_2 = ast.Module(body=[])
    yield_from_transformer_2 = Yield

# Generated at 2022-06-25 22:55:09.212130
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:10.549832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__annotations__ == {'tree': ast.AST, '_tree_changed': bool}

# Generated at 2022-06-25 22:55:13.228583
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree is a_s_t_0


# Generated at 2022-06-25 22:55:19.314312
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Constructor for class YieldFromTransformer"""
    assert (YieldFromTransformer is not None)
    assert (YieldFromTransformer.__name__ == 'YieldFromTransformer')



# Generated at 2022-06-25 22:55:20.248352
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:55:27.215412
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import assets
    from ..utils.tree import print_tree
    from .base import UnparseTransformer
    import astor  # type: ignore

    ast_or = assets.get_ast('''
a = sum(x for x in range(100))
b = sum(x for x in range(100))''')
    tree = YieldFromTransformer(ast_or).visit(ast_or)
    print_tree(tree)
    print(astor.to_source(UnparseTransformer(ast_or).visit(ast_or)))


# Generated at 2022-06-25 22:55:28.442174
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:55:41.542718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for class YieldFromTransformer
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    def function_0():
        def function_0_0():
            return (yield from function_0_0())
        return None

# Generated at 2022-06-25 22:55:44.874849
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    logger.info("Starting: test_YieldFromTransformer")
    tree = ast.parse("yield from x")
    YieldFromTransformer(tree)
    logger.info("Successful: test_YieldFromTransformer")
    return


# Generated at 2022-06-25 22:56:09.797809
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:56:10.956334
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    print()


# Generated at 2022-06-25 22:56:12.155174
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(ast) is not None


# Generated at 2022-06-25 22:56:15.131808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    call_0 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:56:16.869180
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:56:20.176808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)

# Generated at 2022-06-25 22:56:20.919491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-25 22:56:22.666589
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    expected_result = None
    actual_result = None
    assert expected_result == actual_result



# Generated at 2022-06-25 22:56:25.909673
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree_ = None
    yield_from_transformer = YieldFromTransformer(tree_)
    assert yield_from_transformer.tree == tree_
    assert yield_from_transformer._tree_changed is False


# Generated at 2022-06-25 22:56:29.259313
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        test_case_0()
    except Exception as e:
        print("Unhandled exception in test case: ", e)
        assert False


if __name__ == '__main__':
    # Unit test for constructor of class YieldFromTransformer
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:57:19.345160
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:57:23.687881
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = ast.parse('a = yield from b')
    tree_changed_0 = False
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2, tree_changed_0)
    assert yield_from_transformer_1.tree_changed == tree_changed_0


# Generated at 2022-06-25 22:57:24.916581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test class constructor has no paramters
    assert callable(YieldFromTransformer)


# Generated at 2022-06-25 22:57:26.782429
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:28.854419
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    [a_s_t_0, yield_from_transformer_0] = test_case_0()

#### Testing #####
if __name__ == '__main__':
    test_YieldFromTransformer()
    print('Test finished succesfully')

# Generated at 2022-06-25 22:57:30.690122
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:57:35.101090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = None
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert yield_from_transformer_1._tree_changed == False
    assert yield_from_transformer_1._tree == a_s_t_2


# Generated at 2022-06-25 22:57:37.568062
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:57:39.812188
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  a_s_t_0 = None
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:57:40.993259
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Just for coverage
    YieldFromTransformer(None)

# Generated at 2022-06-25 22:59:34.647401
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:36.656234
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # First test case
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:59:38.878474
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(None)
        assert False, "Expected exception!"
    except Exception as e:
        assert str(e) == "Can't compile an AST into bytecode without an AST"

# Generated at 2022-06-25 22:59:40.786424
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = None
    transformer = YieldFromTransformer(node)
    assert transformer.node is None
    assert transformer._tree_changed is False


# Generated at 2022-06-25 22:59:42.458728
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # default values of constructor
    a_s_t_2 = None
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:59:44.253499
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    assert YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:59:47.769843
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Try with constructor argument = None
    try:
        a_s_t_0 = None
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        yield_from_transformer_0.visit(a_s_t_0)
    except Exception as e:
        print('Failed to create object')
        raise e


if __name__ == "__main__":
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:59:48.738767
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    visitor = None
    yield_from_transformer = YieldFromTransformer(visitor)


# Generated at 2022-06-25 22:59:51.325205
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  _ast = None
  for _t, _v in YieldFromTransformer(_ast).__dict__.items():
    assert not hasattr(YieldFromTransformer(_ast), _t) or _v is not None, f'Attribute {_t} has None value'


# Generated at 2022-06-25 22:59:53.767532
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
