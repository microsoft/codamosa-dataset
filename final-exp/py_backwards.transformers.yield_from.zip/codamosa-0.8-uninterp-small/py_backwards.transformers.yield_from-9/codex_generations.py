

# Generated at 2022-06-25 22:52:54.831272
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree is None
    assert yield_from_transformer_0._tree_changed is False
    assert yield_from_transformer_0.target == (3, 2)


# Generated at 2022-06-25 22:52:55.667690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


# Generated at 2022-06-25 22:53:01.679744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    mod = ast.parse('x = yield from y')
    assert mod == yield_from_transformer_0.visit(mod)
    mod = ast.parse('yield from y')
    assert mod == yield_from_transformer_0.visit(mod)


# Generated at 2022-06-25 22:53:04.784128
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:05.663732
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:08.258270
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:09.333157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:10.846091
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = None
    yield_from_transformer = YieldFromTransformer(tree)


# Generated at 2022-06-25 22:53:12.927627
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    input_0 = ast.parse('a = b')
    yield_from_transformer_0 = YieldFromTransformer(input_0)


# Generated at 2022-06-25 22:53:13.758991
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True == True

# Generated at 2022-06-25 22:53:19.400803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  a_s_t_0 = module_0.AST()
  YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:22.458264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.tree == a_s_t_0)


# Generated at 2022-06-25 22:53:29.326395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:33.784711
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformer

    a_s_t_0 = ast3.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, BaseNodeTransformer)



# Generated at 2022-06-25 22:53:37.844619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:53:42.492435
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  # Save original value of current_result
  orig_current_result = current_result

  # Setup code for testing constructor of class YieldFromTransformer
  a_s_t_0 = module_0.AST()
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
  a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
  assert a_s_t_0 == a_s_t_1


  # Restore original value of current_result
  current_result = orig_current_result

# Generated at 2022-06-25 22:53:44.760811
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:53.258362
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert "YieldFromTransformer" in repr(YieldFromTransformer)
    assert "target" in repr(YieldFromTransformer)
    assert "__init__" in repr(YieldFromTransformer)
    assert "visit" in repr(YieldFromTransformer)
    assert "generic_visit" in repr(YieldFromTransformer)
    assert "_emulate_yield_from" in repr(YieldFromTransformer)
    assert "_handle_expressions" in repr(YieldFromTransformer)
    assert "_handle_assignments" in repr(YieldFromTransformer)
    assert "_get_yield_from_index" in repr(YieldFromTransformer)


# Generated at 2022-06-25 22:53:55.593693
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:58.773559
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # Simple test to verify object initialization
    yield_from_transformer_0 = YieldFromTransformer(ast.parse('a = yield from [1, 2, 3]'))
    assert yield_from_transformer_0



# Generated at 2022-06-25 22:54:09.089217
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree_0 = module_0.AST()
    transformer_0 = YieldFromTransformer(tree_0)
    assert transformer_0.get_tree() == tree_0 and transformer_0.get_tree() == tree_0
    assert transformer_0.tree_changed() == False

# Generated at 2022-06-25 22:54:19.284010
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    
    assert yield_from_transformer_0.root == a_s_t_0
    assert yield_from_transformer_0._tree_changed == False
    assert yield_from_transformer_0.target == (3, 2)
    input_ast = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(input_ast)
    
    assert yield_from_transformer_1.root == input_ast
    assert yield_from_transformer_1._tree_changed == False
    assert yield_from_transformer_1.target == (3, 2)


# Generated at 2022-06-25 22:54:19.809266
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:54:21.434171
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)
    test_case_0()


# Generated at 2022-06-25 22:54:25.690760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

if __name__ == "__main__":
    test_YieldFromTransformer()
    test_case_0()

# Generated at 2022-06-25 22:54:31.202953
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        # Test for constructor with one argument
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as inst:
        print(inst)
        print('Constructor test for class YieldFromTransformer failed')
        return
    print('Constructor test for class YieldFromTransformer passed')


# Generated at 2022-06-25 22:54:34.091732
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse("""def foo(l):\n    yield from l""")
    YieldFromTransformer(tree)

# Generated at 2022-06-25 22:54:36.377726
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:41.682614
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_2 = module_0.Module()
    try_0 = module_0.Try(body=[], handlers=[], orelse=[])
    a_s_t_2 = module_0.AST()
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_2)
    test_case_0()
    test_YieldFromTransformer()

if __name__ == '__main__':
    import unittest

    unittest.main()

# Generated at 2022-06-25 22:54:44.665509
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:55:18.350669
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:55:20.550814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.AST()
    transform = YieldFromTransformer(tree)
    assert isinstance(transform, YieldFromTransformer)


# Generated at 2022-06-25 22:55:27.523966
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # verify that attributes are set
    assert yield_from_transformer_0.tree == a_s_t_0
    assert yield_from_transformer_0.tree_changed == False
    assert yield_from_transformer_0.recursive == True
    assert yield_from_transformer_0.target == (3, 2)
    assert yield_from_transformer_0.visit == yield_from_transformer_0.generic_visit


# Generated at 2022-06-25 22:55:30.439020
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:34.406359
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = YieldFromTransformer.__module__
    assert module_0 == 'typed_astunparse.transforms.YieldFromTransformer'
    class_0 = YieldFromTransformer.__class__
    assert class_0.__module__ == 'typed_astunparse.transforms.YieldFromTransformer'


# Generated at 2022-06-25 22:55:42.312847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Arrange
    a_s_t_0 = module_0.AST()
    # Act
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Assert
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 22:55:43.277477
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


# Generated at 2022-06-25 22:55:44.136875
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:55:45.032612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:55:52.741337
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_0 = module_0.AST()

    # Test for YieldFromTransformer(tree: ast.AST)
    yield_from_transformer_0 = YieldFromTransformer(ast_0)

    # Test for generate_with_classes(tree: ast.AST)
    result_with_classes_0 = yield_from_transformer_0.generate_with_classes(ast_0)

    # Test for generate_import_0(tree: ast.AST)
    result_import_0_0 = yield_from_transformer_0.generate_import_0(ast_0)

    # Test for generate_import_1(tree: ast.AST)
    result_import_1_0 = yield_from_transformer_0.generate_import_1(ast_0)

    # Test for generate_import_

# Generated at 2022-06-25 22:56:29.708627
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(YieldFromTransformer._transformer_tree is yield_from_transformer_0._root)

# Generated at 2022-06-25 22:56:32.923226
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer([1, 2, 3])
    assert YieldFromTransformer([])
    assert YieldFromTransformer(list())
    assert YieldFromTransformer(list(1))



# Generated at 2022-06-25 22:56:35.629194
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree: module_0.AST = module_0.AST()
    yield_from_transformer_2 = YieldFromTransformer(tree)
    assert (isinstance(yield_from_transformer_2, YieldFromTransformer))


# Generated at 2022-06-25 22:56:42.969683
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0_copy = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0 == yield_from_transformer_0_copy)
    assert(yield_from_transformer_0 is not yield_from_transformer_0_copy)
    assert(yield_from_transformer_0.target == (3,2))
    assert(yield_from_transformer_0.tree is a_s_t_0)


# Generated at 2022-06-25 22:56:45.525965
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator

    # Test for constructor
    YieldFromTransformer()

# Generated at 2022-06-25 22:56:48.576120
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    assert yield_from_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:56:50.858836
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:56:51.589002
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True == True


# Generated at 2022-06-25 22:56:58.612278
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.Try()
    a_s_t_1 = module_0.ExceptHandler(type=None, name=None, body=[])
    a_s_t_2 = module_0.Module()
    a_s_t_3 = module_0.Assign()
    a_s_t_4 = module_0.While()
    a_s_t_5 = module_0.Expr()
    a_s_t_6 = module_0.Call()
    a_s_t_7 = module_0.YieldFrom()

# Generated at 2022-06-25 22:57:00.823833
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(ast_tree=ast.parse('def foo():\n    yield from foo()'))
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 22:58:21.727066
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    AST_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(AST_1)


# Generated at 2022-06-25 22:58:27.523983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Assignment that should be done by constructor for class YieldFromTransformer
    a = module_0.AST()
    obj = YieldFromTransformer(a)
    assert obj.tree == a, f'obj.tree == {a}, f\'obj.tree == {{obj.tree}}\''
    assert obj._tree_changed == False, f'obj._tree_changed == {False}, f\'obj._tree_changed == {{obj._tree_changed}}\''
    assert obj.target == (3, 2), f'obj.target == {(3, 2)}, f\'obj.target == {{obj.target}}\''


# Generated at 2022-06-25 22:58:32.106131
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

if __name__ == "__main__":
    import sys
    import os
    import logging

    path = os.path.realpath(__file__)
    sys.path.append(os.path.dirname(os.path.dirname(path)))

    import py3c.unittestutil as unittestutil

    logging.basicConfig(level=logging.DEBUG)

    unittestutil.run(sys.argv[1:])

# Generated at 2022-06-25 22:58:34.524350
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:37.838068
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast = module_0.AST()
    yield_from_transformer = YieldFromTransformer(ast)
    assert(yield_from_transformer != None)
    assert(isinstance(yield_from_transformer, YieldFromTransformer))


# Generated at 2022-06-25 22:58:38.966770
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(module_0.AST())


# Generated at 2022-06-25 22:58:45.096233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # We need node to be declared in advance, so that we can check
    # the changes in the tree.
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.YieldFrom()
    a_s_t_4 = module_0.Expr(a_s_t_3)
    a_s_t_3.value = a_s_t_4
    a_s_t_2.body = [a_s_t_4]
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_2)
    a_s_t_5 = yield_from_transformer_0.visit(a_s_t_2)
    assert a_s_t_5.body[0].value.func.__

# Generated at 2022-06-25 22:58:46.840085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(module_0.AST())
    assert hasattr(yield_from_transformer_0, 'name')

# Generated at 2022-06-25 22:58:49.060395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:52.787207
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Create an instance
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Assign to a_s_t_1
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    # Check that a_s_t_1 equals to a_s_t_0
    assert (a_s_t_1 == a_s_t_0)


# Generated at 2022-06-25 23:02:10.129329
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # test constructor
    assert yield_from_transformer_0 is not None

# Generated at 2022-06-25 23:02:16.633375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # ast_node, a_s_t, is_lambda_func, is_top_level
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert_equal(yield_from_transformer_1.ast_node, a_s_t_2)
    assert_equal(yield_from_transformer_1.is_lambda_func, False)
    assert_equal(yield_from_transformer_1.is_top_level, False)

# Generated at 2022-06-25 23:02:21.008305
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # This test does not need the constructor to be patched
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:02:21.882415
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('yield from a')
    YieldFromTransformer(tree)

# Generated at 2022-06-25 23:02:24.601278
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_0 = ast.AST()
    assert YieldFromTransformer(ast_0)._tree == ast_0

# Generated at 2022-06-25 23:02:30.392699
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0
    assert yield_from_transformer_0.out is None


# Generated at 2022-06-25 23:02:36.635457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.Assign(targets=[module_0.Name(id='a', ctx=module_0.Store())], value=module_0.Call(func=module_0.Name(id='range', ctx=module_0.Load()), args=[module_0.Constant(value=1)], keywords=[]))
    a_s_t_3 = module_0.YieldFrom(value=a_s_t_2)
    a_s_t_4 = module_0.Expr(value=a_s_t_3)

# Generated at 2022-06-25 23:02:40.614775
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast

    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert isinstance(yield_from_transformer_0.tree, ast.AST)
    assert isinstance(yield_from_transformer_0._tree_changed, bool)
    assert isinstance(yield_from_transformer_0.target, tuple)



# Generated at 2022-06-25 23:02:42.593863
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 23:02:43.554157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(module_0.AST())
