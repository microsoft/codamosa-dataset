

# Generated at 2022-06-25 22:52:50.043813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:52:52.569782
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.AST()
    yield_from_transformer = YieldFromTransformer(a)
    assert str(type(yield_from_transformer)) == "<class 'py2to3.transformers.builtins.YieldFromTransformer'>"


# Generated at 2022-06-25 22:52:55.115556
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    a = ast.AST()
    b = YieldFromTransformer(a)
    # Test attribute ast of instance b
    assert isinstance(b.ast, ast.Module)


# Generated at 2022-06-25 22:52:57.102358
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:01.268899
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:04.412775
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:08.302631
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  try:
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
  except:
    assert False



# Generated at 2022-06-25 22:53:11.646487
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:14.663280
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:16.935556
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:25.102911
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:53:28.866530
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:31.733782
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test constructor
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:32.671533
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


# Generated at 2022-06-25 22:53:34.054573
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(ast.Module())


# Generated at 2022-06-25 22:53:36.906590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # <empty>
    a_s_t_0 = module_0.AST()
    b_t_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:38.846243
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:40.628076
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:44.296104
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Test if function visit correctly process
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:53:48.559241
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:02.140727
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('if True:\n    yield from iterable')
    __tracebackhide__ = True
    YieldFromTransformer(tree)

# Generated at 2022-06-25 22:54:03.228656
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__doc__ is not None


# Generated at 2022-06-25 22:54:05.209333
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:08.790917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:10.264531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:54:13.810151
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return

# Generated at 2022-06-25 22:54:14.645916
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    raise Exception('Exception in test')

# Generated at 2022-06-25 22:54:17.567503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None
    test_case_0()

# Generated at 2022-06-25 22:54:20.216235
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:22.391282
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:47.016907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer_0()


# Generated at 2022-06-25 22:54:49.104171
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:52.128191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer('target')
    assert yield_from_transformer_0._target == (3, 2)


# Generated at 2022-06-25 22:54:58.027504
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import get_ast
    from ..utils.sample_programs import get_test_program

    a_s_t_0 = get_ast(get_test_program('yield_from'))
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:05.809550
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test constructor
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree == a_s_t_0
    assert yield_from_transformer_0._tree_changed == False
    assert yield_from_transformer_0._strict == False
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0, True)
    assert yield_from_transformer_0._tree == a_s_t_0
    assert yield_from_transformer_0._tree_changed == False
    assert yield_from_transformer_0._strict == True


# Generated at 2022-06-25 22:55:07.777436
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:11.002826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:13.664539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:55:22.168693
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    a_s_t_2 = yield_from_transformer_0.visit(a_s_t_1)


# Generated at 2022-06-25 22:55:29.083531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test with target = (3, 2)
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Test with target = (3, 2)
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)


if __name__ == '__main__':
    import inspect
    from unittest import main
    main(module='discover_tests', argv=[inspect.getfile(inspect.currentframe())])

# Generated at 2022-06-25 22:56:12.434377
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    assert YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:14.518261
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:56:18.514120
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:56:20.292709
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(module_0.AST()) is not None

# Unit tests for _get_yield_from_index

# Generated at 2022-06-25 22:56:23.495356
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:27.331214
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:56:31.192873
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0._tree_changed == False)

# Generated at 2022-06-25 22:56:33.317416
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:36.305028
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_tests_ast = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_tests_ast)
    # test for class property target
    print(yield_from_transformer_0.target)



# Generated at 2022-06-25 22:56:38.866170
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert True


# Generated at 2022-06-25 22:58:14.698925
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:17.228263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert type(yield_from_transformer_0) == YieldFromTransformer


# Generated at 2022-06-25 22:58:19.370334
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:58:22.011890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:24.516052
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = YieldFromTransformer(a_s_t_0)

if __name__ == '__main__':
    test_YieldFromTransformer()
    test_case_0()

# Generated at 2022-06-25 22:58:24.981466
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-25 22:58:27.058138
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:58:28.239203
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer.__init__(a_s_t_0)

# Generated at 2022-06-25 22:58:30.723932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:58:31.858231
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, '__init__')


# Generated at 2022-06-25 23:02:13.929030
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)


# Generated at 2022-06-25 23:02:16.173945
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        pass
    try:
        YieldFromTransformer(None)
    except:
        pass

# Generated at 2022-06-25 23:02:21.934819
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)
    assert id(yield_from_transformer_0.context) == id(None)
    assert id(yield_from_transformer_0.tree) == id(None)
    assert yield_from_transformer_0.target == (3, 2)
    assert id(yield_from_transformer_0._tree_changed) == id(None)


# Generated at 2022-06-25 23:02:27.720921
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 23:02:30.071101
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 23:02:32.058890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 23:02:38.417436
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import PathResolver
    import os
    import sys
    import astor
    import ast
    path_resolver = PathResolver(os.path.dirname(__file__))
    python_file_name = path_resolver.get_abs_path_for_file('demo.py')
    with open(python_file_name) as f:
        python_code = f.read()
    a_s_t = ast.parse(python_code)
    import typed_ast.ast3 as typed_ast
    typed_ast_ast = typed_ast.ast3.parse(python_code)
    try:
        assert isinstance(typed_ast_ast, ast.AST), "Cannot create typed ast"
    except AssertionError as e:
        print(e)
    yield_from_

# Generated at 2022-06-25 23:02:40.678027
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.generic_visit(a_s_t_0) == a_s_t_0
