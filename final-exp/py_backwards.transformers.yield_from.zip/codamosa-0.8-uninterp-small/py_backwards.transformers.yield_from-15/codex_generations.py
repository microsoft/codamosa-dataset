

# Generated at 2022-06-25 22:52:50.608128
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:52:53.688394
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Check if the attribute tree is being set up
    assert yield_from_transformer_0.tree == a_s_t_0

# Generated at 2022-06-25 22:52:55.778470
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:52:59.508616
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:04.223347
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0.YieldFromTransformer(module_0.AST())

from ..utils.tree import get_tree
from ..utils.visitor import print_tree
from ..utils.helpers import check_equal
from ..utils.conditions import is_py3_25_or_below


# Generated at 2022-06-25 22:53:06.885826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, module_0.NodeTransformer)


# Generated at 2022-06-25 22:53:08.258932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 22:53:11.294989
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:53:16.704833
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        YieldFromTransformer(3)
    a_s_t_0 = module_0.AST()
    with pytest.raises(TypeError):
        YieldFromTransformer(a_s_t_0, 3)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:53:19.752237
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0, 'ast')
    assert(yield_from_transformer_0 != None)
    assert(yield_from_transformer_0.context == 'ast')


# Generated at 2022-06-25 22:53:35.917094
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    unit_test_a_s_t_0 = module_0.AST()
    try:
        unit_test_yield_from_transformer_0 = YieldFromTransformer(unit_test_a_s_t_0)
    except:
        pass

if __name__ == '__main__':
    import sys
    import __main__
    sys.modules[__main__.__name__] = __main__
    from main import *

    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:39.903600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0
    assert yield_from_transformer_0.target == (3, 2)
    assert yield_from_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:53:43.805918
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree == a_s_t_0
    assert yield_from_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:53:46.961261
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__module__ == 'crosswind.compilers.transformers.yield_from'

# Generated at 2022-06-25 22:53:49.285687
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = YieldFromTransformer(module_0.AST())

from astmonkey import visitors, transformers


# Generated at 2022-06-25 22:53:51.366275
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:55.097841
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    vars = VariablesGenerator.generate('vars')
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    def function_0(vars):
        pass


# Generated at 2022-06-25 22:53:57.661985
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:05.555657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    TRY_NAME, FINALLY_NAME = 'try', 'finally'
    YIELD_FROM_NAME, YIELD_FROM_TARGET = 'yield_from', 'next'
    BODY = ("try:\n"
            "  yield_from.{yield_from_name} = yield from generator\n"
            "except StopIteration as exc:\n"
            "  yield_from.{yield_from_target} = exc.value\n"
            "{finally_name}: ...")

# Generated at 2022-06-25 22:54:08.539354
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(not yield_from_transformer_0.tree_changed)


# Generated at 2022-06-25 22:54:20.703310
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:22.869828
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:24.923637
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:25.478278
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


# Generated at 2022-06-25 22:54:32.143683
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.parse('yield from a')
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    assert(str(a_s_t_1) == 'while True:\n    iterable = iter((a))\n    try:\n        yield next((iterable))\n    except StopIteration as exc:\n        pass\n        break\n')


# Generated at 2022-06-25 22:54:34.682592
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Verify that constructor fails on incorrect input type
    with pytest.raises(TypeError):
        YieldFromTransformer(1)



# Generated at 2022-06-25 22:54:38.445705
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = None
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert isinstance(yield_from_transformer_1, YieldFromTransformer)
    assert isinstance(yield_from_transformer_1.tree, ast.Module)


# Generated at 2022-06-25 22:54:42.591888
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    a_s_t_1 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert yield_from_transformer_1._orig_tree == None


# Generated at 2022-06-25 22:54:43.800960
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:44.303344
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:54:52.032343
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = None
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)


# Generated at 2022-06-25 22:54:52.955338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:54:53.770832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:54:57.760289
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_0 = None
    expected_0 = None
    # Call the function
    yield_from_transformer_0 = YieldFromTransformer(ast_0)
    # Test the results
    assert yield_from_transformer_0 is None
    assert yield_from_transformer_0.ast is None


# Generated at 2022-06-25 22:54:59.554604
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .helper import get_ast
    from .helper import compile_and_assert


# Generated at 2022-06-25 22:55:02.184875
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('x = yield from (1, 2)')
    processor = YieldFromTransformer(node)

    assert processor.visit(node) == ast.parse('x = next(iter((1, 2)))')



# Generated at 2022-06-25 22:55:09.749018
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Generating values for arguments
    a_s_t_0 = None

    # Getting the type of 'YieldFromTransformer' (line 62)
    YieldFromTransformer_236612 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 62, 17), 'YieldFromTransformer', False)
    # Calling YieldFromTransformer(args, kwargs) (line 62)
    YieldFromTransformer_call_result_236614 = invoke(stypy.reporting.localization.Localization(__file__, 62, 17), YieldFromTransformer_236612, *[a_s_t_0], **kwargs_236613)
    
    # Assigning a type to the variable 'yield_from_transformer_0' (

# Generated at 2022-06-25 22:55:11.108079
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    test_case_0()


# Generated at 2022-06-25 22:55:12.612794
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(tree=None)
    assert YieldFromTransformer(tree=None).tree == None

# Generated at 2022-06-25 22:55:18.350724
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None

    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    assert yield_from_transformer_0 != None


# Generated at 2022-06-25 22:55:28.517622
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = None
    yield_from_transformer_0 = YieldFromTransformer(tree)
    # Unit test for visit of class YieldFromTransformer
    node = None
    yield_from_transformer_1 = YieldFromTransformer(node)
    a_s_t_0 = yield_from_transformer_1.visit(node)
    assert a_s_t_0 == None

# Generated at 2022-06-25 22:55:31.152400
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:33.543428
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(None), YieldFromTransformer)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:55:34.342237
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:55:39.774636
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    fake_tree = ast.parse("""def foo():
    yield from bar()""")
    assert YieldFromTransformer(fake_tree)._tree == fake_tree

# Generated at 2022-06-25 22:55:43.432035
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Initialized a instance of class YieldFromTransformer
    yield_from_transformer_0 = YieldFromTransformer()

    # Check for the class variables
    assert yield_from_transformer_0._tree_changed is False

# Generated at 2022-06-25 22:55:45.600418
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:49.933156
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    assert a_s_t_1 is a_s_t_0


# Generated at 2022-06-25 22:55:50.790933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_2 = YieldFromTransformer(SomeType())

# Generated at 2022-06-25 22:55:51.644677
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# End test for constructor of class YieldFromTransformer


# Generated at 2022-06-25 22:56:05.668617
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = None
    expect_value = None
    assert_equal(YieldFromTransformer(tree).visit(tree), expect_value)


# Generated at 2022-06-25 22:56:06.761233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = None
    YieldFromTransformer(a)


# Generated at 2022-06-25 22:56:10.082205
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from typed_ast.ast3 import Module, Expr, Assign, FunctionDef
    from typed_ast import ast3 as ast
    from ..utils.typed_ast_pprint import typed_ast_pprint


# Generated at 2022-06-25 22:56:13.567580
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    wrap_func_to_module = ast.Module
    # Constructor
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Method visit
    a_s_t_1 = wrap_func_to_module([ast.FunctionDef('my_func', ast.arguments([], None, [], [], None, []),
                                                   [ast.Expr(ast.YieldFrom(ast.Name('iterable')))], [])])
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_1)
    assert isinstance(a_s_t_1, ast.Module)
    assert len(a_s_t_1.body) == 1
    assert isinstance

# Generated at 2022-06-25 22:56:14.807684
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:15.394663
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:56:19.113890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:56:20.331031
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)


# Generated at 2022-06-25 22:56:21.876017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)._tree == None


# Generated at 2022-06-25 22:56:25.030577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:56:51.756845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:56:52.497899
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()



# Generated at 2022-06-25 22:56:54.811866
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.target == (3, 2))


# Generated at 2022-06-25 22:56:58.645321
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.parse("").body[0]
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0._emulate_yield_from(a_s_t_0, a_s_t_0)
    return YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:56:59.904819
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    TODO:
    """
    #Nothing to test here :(
    pass


# Generated at 2022-06-25 22:57:02.541035
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    a_s_t_1 = YieldFromTransformer(a_s_t_0)

# Unit tests for method _emulate_yield_from of class YieldFromTransformer

# Generated at 2022-06-25 22:57:03.816647
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = None
    yield_from_transformer_0 = YieldFromTransformer(tree)


# Generated at 2022-06-25 22:57:08.235035
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.tree = a_s_t_0
    yield_from_transformer_0.visit(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0

# Generated at 2022-06-25 22:57:08.974085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-25 22:57:17.449202
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    a_s_t_3 = yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    a_s_t_2 = yield_from_transformer_0.generic_visit(a_s_t_0)
    return a_s_t_0, a_s_t_1, a_s_t_2, a_s_t_3


# Generated at 2022-06-25 22:58:16.121161
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import Module
    from python_minifier.yield_from.yield_from import YieldFromTransformer
    expected = Module([])
    actual = YieldFromTransformer(expected).visit(expected)
    assert expected == actual

# Generated at 2022-06-25 22:58:17.939849
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:21.067423
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    assert isinstance(YieldFromTransformer(a_s_t_0), YieldFromTransformer), "Constructor of class `YieldFromTransformer` is broken."


# Generated at 2022-06-25 22:58:21.789569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer._get_doc() is None

# Generated at 2022-06-25 22:58:24.548505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Given
    a_s_t_0 = None

    # When
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Then
    assert not hasattr(yield_from_transformer_0, 'tree')



# Generated at 2022-06-25 22:58:26.623671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:27.708896
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)
    return



# Generated at 2022-06-25 22:58:31.337069
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0
    assert yield_from_transformer_0.tree is a_s_t_0
    assert yield_from_transformer_0.target == (3, 2)
    return


# Generated at 2022-06-25 22:58:34.408442
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert type(yield_from_transformer_0) == YieldFromTransformer


# Generated at 2022-06-25 22:58:36.915846
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_tree = ast.parse(textwrap.dedent("""
    def function():
        result = yield from iterable
    """))

    YieldFromTransformer(test_tree)

# Generated at 2022-06-25 23:00:50.842484
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 23:00:51.964774
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, '__init__')


# Generated at 2022-06-25 23:00:52.694117
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): raise NotImplementedError()


# Generated at 2022-06-25 23:00:54.417069
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)


# Generated at 2022-06-25 23:00:56.151344
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(a_s_t) is not None


# Generated at 2022-06-25 23:00:57.463241
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Calling constructor
    yield_from_transformer_0 = YieldFromTransformer(None)


# Generated at 2022-06-25 23:00:59.069271
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:01:03.644096
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = (3, 3)
        a_s_t_1 = None
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)
        if (not (yield_from_transformer_0.target == a_s_t_0)):
            raise RuntimeError
        if (not (yield_from_transformer_0._tree_changed == False)):
            raise RuntimeError
    except:
        assert False


# Generated at 2022-06-25 23:01:05.273772
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:01:05.914896
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO
    pass
