

# Generated at 2022-06-25 22:52:50.613634
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 22:52:52.345859
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:52:53.920376
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)


# Generated at 2022-06-25 22:52:55.999691
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return


# Generated at 2022-06-25 22:53:05.777120
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = None
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    a_s_t_2 = None
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_2)
    a_s_t_3 = None
    yield_from_transformer_3 = YieldFromTransformer(a_s_t_3)
    a_s_t_4 = None
    yield_from_transformer_4 = YieldFromTransformer(a_s_t_4)


# Generated at 2022-06-25 22:53:07.664858
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test constructor of class YieldFromTransformer."""
    # pass
# run unit tests
test_case_0()

# Generated at 2022-06-25 22:53:11.686403
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, '_YieldFromTransformer__tree')
    assert hasattr(YieldFromTransformer, '_YieldFromTransformer__tree_changed')
    assert hasattr(YieldFromTransformer, 'result')
    assert YieldFromTransformer(ast.parse('None')).result


# Generated at 2022-06-25 22:53:16.469385
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        tree = ast.parse("""
                            def func():
                                yield from gen()
                        """)
        yield_from_transformer_0 = YieldFromTransformer(tree)
        assert yield_from_transformer_0.target == (3, 2)
    except Exception as ex:
        print('[!] Error during YieldFromTransformer::test_YieldFromTransformer(): ', ex, '\n')


# Generated at 2022-06-25 22:53:18.412455
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(ast_tree=None) is not None


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 22:53:19.672913
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)


# Generated at 2022-06-25 22:53:27.050221
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_1 = 'Test constructor of class YieldFromTransformer.'
    t_0 = YieldFromTransformer()
    return t_0


# Generated at 2022-06-25 22:53:30.603844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Executing test case 0: ', end = '')
    try:
        test_case_0()
        print('Passed.')
    except NotImplementedError:
        print('Failed (NotImplementedError).')


# Generated at 2022-06-25 22:53:32.133879
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:38.949794
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'Test constructor of class YieldFromTransformer.'
    if (((str_0) == (get_doc(YieldFromTransformer)) and (3 == YieldFromTransformer.target[0])) and (2 == YieldFromTransformer.target[1])):
        return True
    else:
        raise Exception(((('Failed test_YieldFromTransformer in module test_YieldFromTransformer\nExpected ') + (str_0)) + (' to equal '))
                        + (get_doc(YieldFromTransformer)))
        return False


# Generated at 2022-06-25 22:53:43.077158
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'Test constructor of class YieldFromTransformer.'
    yield_from_transformer = YieldFromTransformer()
    assert (yield_from_transformer.tree_changed == False)
    assert (yield_from_transformer.target_version == (3, 2))


# Generated at 2022-06-25 22:53:44.820694
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'YieldFromTransformer(BaseNodeTransformer)'
    
    pass



# Generated at 2022-06-25 22:53:46.730024
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer = YieldFromTransformer()
    assert(YieldFromTransformer)


# Generated at 2022-06-25 22:53:48.559595
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'Test constructor of class YieldFromTransformer.'
    pass


# Generated at 2022-06-25 22:53:49.600817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:52.010670
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()
    try:
        pass
    except Exception as exception_0:
        pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:53:58.449719
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None


# Generated at 2022-06-25 22:54:00.771088
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test constructor of class YieldFromTransformer."""
    str_0 = 'Test constructor of class YieldFromTransformer.'
    pass

# Generated at 2022-06-25 22:54:03.765076
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    Test = YieldFromTransformer

    exc_0 = Exception()

    # Test type of attribute _tree_changed.
    assert isinstance(Test._tree_changed, bool)

    # Test return value of constructor.
    assert isinstance(Test(), Test)


# Generated at 2022-06-25 22:54:06.671719
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert 1 == 1


if __name__ == "__main__":
    import os
    
    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-25 22:54:16.098382
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    str_0 = 'Test constructor of class YieldFromTransformer.'
    var_1 = YieldFromTransformer(0)
    assert var_1 != None, str_0 + '\nWrong result. Expected: <YieldFromTransformer at 0x106f74978>, got: {var_1.__class__}'
    assert var_1.tree == None, str_0 + '\nWrong result. Expected: None, got: {var_1.tree}'
    assert var_1.lineno == 0, str_0 + '\nWrong result. Expected: 0, got: {var_1.lineno}'
    assert var_1.col_offset == 0, str_0 + '\nWrong result. Expected: 0, got: {var_1.col_offset}'
   

# Generated at 2022-06-25 22:54:17.118750
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:54:22.429061
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
        print('Function "test_YieldFromTransformer"')
        print('\tThe test for constructor of class YieldFromTransformer has passed!')
        print()
    except Exception as e:
        print('Function "test_YieldFromTransformer"')
        print('\tThe test for constructor of class YieldFromTransformer has failed!')
        print(e)
        print()


# Generated at 2022-06-25 22:54:23.270762
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tester = YieldFromTransformer()


# Generated at 2022-06-25 22:54:24.997546
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tester = YieldFromTransformer()
    assert tester is not None, 'Failed at constructing an instance of YieldFromTransformer.'


# Generated at 2022-06-25 22:54:26.322936
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:54:35.450995
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:39.520817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.target = (3, 2)
    assert (yield_from_transformer_0.target == (3, 2))
    return


# Generated at 2022-06-25 22:54:41.793194
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:44.771319
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree is a_s_t_0


# Generated at 2022-06-25 22:54:46.347767
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(ast_0)


# Generated at 2022-06-25 22:54:48.042435
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:52.715580
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t = module_0.AST()
        YieldFromTransformer(a_s_t)
    except Exception as inst:
        print(inst)
        print("Exception thrown in testcase 0")
        raise


test_case_0()
test_YieldFromTransformer()

# Generated at 2022-06-25 22:54:56.401890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_2)
    a_s_t_3 = yield_from_transformer_0.visit(a_s_t_2)


# Generated at 2022-06-25 22:55:04.459012
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = 'a'
    b = 'b'
    c = 'c'
    d = 'd'
    
    # Test 0:
    import typed_ast.ast3 as ast
    tree = ast.parse('a = b').body[0]
    transformer = YieldFromTransformer(None)
    assert transformer.visit(tree).lineno == None
    
    # Test 1:
    import typed_ast.ast3 as ast
    tree = ast.parse('a = b').body[0]
    transformer = YieldFromTransformer(None)
    transformer.visit(tree)
    assert transformer._get_yield_from_index(tree, ast.Assign) == None
    
    # Test 2:
    import typed_ast.ast3 as ast

# Generated at 2022-06-25 22:55:07.702835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    gen_0 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:27.169865
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    import typed_ast._ast3 as module_0
    yield_from_transformer_0 = YieldFromTransformer(module_0.AST())
    try:
        assert yield_from_transformer_0._tree_changed == False
    except AssertionError:
        raise RuntimeError("expected: %s, got: %s"%(True, yield_from_transformer_0._tree_changed,))
    try:
        assert yield_from_transformer_0._tree == module_0.AST()
    except AssertionError:
        raise RuntimeError("expected: %s, got: %s"%(module_0.AST(), yield_from_transformer_0._tree,))

# Generated at 2022-06-25 22:55:33.740877
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = ast.AST()
    
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert yield_from_transformer_1 is not None

if __name__ == '__main__':
    import sys
    import logging
    import pytest
    logger = logging.getLogger(__name__)
    logging.basicConfig(level=logging.DEBUG)
    pytest.main(sys.argv)

# Generated at 2022-06-25 22:55:38.973746
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)


# Generated at 2022-06-25 22:55:43.125486
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree is a_s_t_0


# Generated at 2022-06-25 22:55:47.193894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0)
    assert(isinstance(yield_from_transformer_0, BaseNodeTransformer))


# Generated at 2022-06-25 22:55:51.309563
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(ast_0)
    yield_from_transformer_0.handler_names
    yield_from_transformer_0.body
    yield_from_transformer_0._tree
    yield_from_transformer_0._tree_changed
    yield_from_transformer_0.result


# Generated at 2022-06-25 22:55:55.947890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # File not found error
    try:
        #Reading the file
        test_file = open("test_files/test_YieldFromTransformer/test_YieldFromTransformer_constuctor.py", "r")
        read_file = test_file.read()
        test_file.close()
    except IOError as e:
        file_not_found_error(e)
        assert True == False

    ast_tree = ast.parse(read_file)
    #Expected result

# Generated at 2022-06-25 22:55:59.967121
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('yield from f()')
    t = YieldFromTransformer(tree)
    assert isinstance(t, YieldFromTransformer)


# Generated at 2022-06-25 22:56:03.230359
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(module_0.AST()) != YieldFromTransformer(module_0.AST())
    assert YieldFromTransformer(module_0.AST()).tree != YieldFromTransformer(module_0.AST()).tree


# Generated at 2022-06-25 22:56:06.548132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:56:29.133560
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for __init__ function of class YieldFromTransformer
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-25 22:56:30.780367
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:56:32.999672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer("ast")
        assert False
    except TypeError as e:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-25 22:56:34.137722
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 22:56:35.088706
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    constructor_test_0()


# Generated at 2022-06-25 22:56:36.955515
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:39.257267
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    

# Generated at 2022-06-25 22:56:41.441676
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    test_case_0()

# Generated at 2022-06-25 22:56:45.570543
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (yield_from_transformer_0._tree_changed == False)
    assert (yield_from_transformer_0.tree == a_s_t_0)



# Generated at 2022-06-25 22:56:52.294271
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_2)
    yield_from_transformer_3 = YieldFromTransformer(a_s_t_2)
    yield_from_transformer_4 = YieldFromTransformer(a_s_t_2)

# Generated at 2022-06-25 22:57:51.364084
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:57:56.765210
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert type(yield_from_transformer_1) == YieldFromTransformer
    assert yield_from_transformer_1.target == (3, 2)
    assert type(yield_from_transformer_1._tree_changed) == bool
    assert yield_from_transformer_1._tree_changed == False
    assert type(yield_from_transformer_1._tree) == module_0.AST
    assert yield_from_transformer_1._tree == a_s_t_2
    assert yield_from_transformer_1._target == (3, 2)


# Generated at 2022-06-25 22:58:00.096013
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)

# Unit tests for generic_visit method of class YieldFromTransformer

# Generated at 2022-06-25 22:58:04.200411
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(isinstance(yield_from_transformer_0, module_0.NodeTransformer))
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 22:58:10.910407
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.target == (3, 2)
    assert yield_from_transformer_0.module is a_s_t_0
    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    assert yield_from_transformer_1.target == (3, 2)
    assert yield_from_transformer_1.module is a_s_t_1

# Generated at 2022-06-25 22:58:12.911931
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return


# Generated at 2022-06-25 22:58:14.733578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:18.666618
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Testing assignment of attribute in constructor
    assert yield_from_transformer_0.tree == a_s_t_0
    # Testing assignment of attribute in constructor
    assert yield_from_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:58:26.626094
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    assert yield_from_transformer_0
    assert yield_from_transformer_0.visit
    assert yield_from_transformer_0.visit_alias
    assert yield_from_transformer_0.visit_arg
    assert yield_from_transformer_0.visit_arguments
    assert yield_from_transformer_0.visit_assert
    assert yield_from_transformer_0.visit_attribute
    assert yield_from_transformer_0.visit_binop
    assert yield_from_transformer_0.visit_boolop
    assert yield_from_transformer_0.visit_break

# Generated at 2022-06-25 22:58:28.343159
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    v_tree_0 = module_0.AST()
    YieldFromTransformer(v_tree_0)


# Generated at 2022-06-25 23:00:40.340372
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:41.796391
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Denied
    a_s_t_0 = module_0.AST()
    pass

# Generated at 2022-06-25 23:00:47.127957
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Assert
    assert hasattr(yield_from_transformer_0, 'tree')
    assert hasattr(yield_from_transformer_0, '_tree_changed')
    assert hasattr(yield_from_transformer_0, '_changed')


# Generated at 2022-06-25 23:00:48.628592
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = ast.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)

# Generated at 2022-06-25 23:00:51.963616
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    if __debug__:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 23:00:53.201826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('result = yield from gen()')
    YieldFromTransformer(tree)


# Generated at 2022-06-25 23:00:59.358378
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Check if isinstance of YieldFromTransformer
    assert(isinstance(yield_from_transformer_0, YieldFromTransformer))
    # Check tree assignment
    assert(yield_from_transformer_0.tree == a_s_t_0)
    # Check attribute tree write permissions
    try:
        yield_from_transformer_0.tree = a_s_t_0
    except:
        assert(False)


# Generated at 2022-06-25 23:01:03.739194
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_object = YieldFromTransformer()
    assert class_object.__class__.__name__ == "YieldFromTransformer"

    assert YieldFromTransformer().__class__.__qualname__ == "YieldFromTransformer.__init__"
    assert YieldFromTransformer.__doc__ == "Compiles yield from to special while statement."
    assert YieldFromTransformer.__init__.__doc__ == "Compiles yield from to special while statement."

    test_case_0()


# Generated at 2022-06-25 23:01:06.526589
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0.AST
    # assert len(YieldFromTransformer.__init__.__defaults__) == 1
    # assert YieldFromTransformer.__init__.__defaults__[0] is None
    # assert YieldFromTransformer.__defaults__ is YieldFromTransformer.__init__.__defaults__


# Generated at 2022-06-25 23:01:08.882303
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
