

# Generated at 2022-06-25 22:52:54.790571
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:52:56.807637
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:03.460303
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__init__.__annotations__ == {"self": "YieldFromTransformer", "tree": "AST", "**kwargs": "Any"}
    assert YieldFromTransformer.visit.__annotations__ == {"self": "YieldFromTransformer", "node": "AST"}
    test_case_0()


# Generated at 2022-06-25 22:53:07.358877
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(a_s_t_0, module_0.AST)
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:53:09.826815
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:10.684287
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # pass
    return


# Generated at 2022-06-25 22:53:12.774971
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:17.236600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    # Check if instance created successfully
    assert isinstance(a_s_t_0, module_0.AST) is True, "instance creation failed"
    # Check if public attribute tree is set successfully
    assert isinstance(a_s_t_0, module_0.AST) is True, "attribute tree assignment failed"


# Generated at 2022-06-25 22:53:18.111438
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:53:20.166478
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

test_case_0()

# Generated at 2022-06-25 22:53:29.453562
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Test if target attribute is set correctly at initialization of object
    assert yield_from_transformer_0.target == (3, 2)


# Generated at 2022-06-25 22:53:36.560446
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    assert isinstance(YieldFromTransformer(a_s_t_0), YieldFromTransformer), "Expected to be of type YieldFromTransformer"
    assert isinstance(YieldFromTransformer(a_s_t_0), BaseNodeTransformer), "Expected to be of type BaseNodeTransformer"
    # Falling back to default case


# Generated at 2022-06-25 22:53:37.740874
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:46.729514
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = ast.parse("def f():\n    yield from a")
    yield_from_transformer_0 = YieldFromTransformer(module_0)
    yield_from_transformer_0.visit(module_0)
    # assert module_0 == ast.parse("def f():\n    iterable = iter(a)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            pass")

    module_1 = ast.parse("def f():\n    yield from a\n    yield from b")
    yield_from_transformer_1 = YieldFromTransformer(module_1)
    yield_from_transformer_1.visit(module_1)
    # assert module_1 == ast.parse("def f():\n    iterable =

# Generated at 2022-06-25 22:53:49.406505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  a_s_t_0 = module_0.AST()
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:53.745459
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:53:54.605734
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:54:00.354457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert hasattr(yield_from_transformer_0, 'tree')
    assert hasattr(yield_from_transformer_0, '_tree_changed')
    assert isinstance(yield_from_transformer_0._tree_changed, bool)


# Generated at 2022-06-25 22:54:01.980483
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert not yield_from_transformer_0._tree_changed
    assert yield_from_transformer_0.tree is a_s_t_0


# Generated at 2022-06-25 22:54:04.858907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:16.762765
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse('a = yield from b')
    transformed = module_0.unparse(YieldFromTransformer(module).visit(module))
    assert transformed == 'a = None\nimport typing\niterable = typing.cast(typing.Iterable[typing.Any], iter(b))\nwhile True:\n\ttry:\n\t\tyield next(iterable)\n\texcept StopIteration as exc:\n\t\ta = exc.value\n\t\tbreak\n\n'

# Unit tests for YieldFromTransformer.generic_visit

# Generated at 2022-06-25 22:54:21.108850
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert a_s_t_0 == yield_from_transformer_0.tree
    assert False == yield_from_transformer_0._warnings


# Generated at 2022-06-25 22:54:22.955397
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)
    assert isinstance(YieldFromTransformer(ast.AST), YieldFromTransformer)


# Generated at 2022-06-25 22:54:24.630600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Make sure target is initialized properly.
    target = (3, 2)
    yield_from_transformer_0 = YieldFromTransformer(target)
    assert yield_from_transformer_0.target == target


# Generated at 2022-06-25 22:54:27.002124
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except:
        raise Exception


# Generated at 2022-06-25 22:54:34.091405
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('def foo():\n  a = yield from 2\n')
    YieldFromTransformer(tree)
    assert YieldFromTransformer(tree).visit(tree) == ast.parse(
        'def foo():\n  let(iterable)\n  iterable = iter(2)\n  while True:\n    try:\n      yield next(iterable)\n    except StopIteration as exc:\n      a = exc.value\n      break\n')


# Generated at 2022-06-25 22:54:36.377782
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:54:39.611795
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        assert yield_from_transformer_0
    except AssertionError:
        print('AssertionError raised')


# Generated at 2022-06-25 22:54:44.674690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('test constructor of class YieldFromTransformer')
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    print('target =', yield_from_transformer_0.target)
    print('tree_changed =', yield_from_transformer_0.tree_changed)
    print(yield_from_transformer_0)


# Generated at 2022-06-25 22:54:45.213431
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  test_case_0()

# Generated at 2022-06-25 22:54:52.457729
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    module = ast.Module(body=[])
    transformer = YieldFromTransformer(module)
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-25 22:54:54.526842
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)


# Generated at 2022-06-25 22:54:55.689733
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return


# Generated at 2022-06-25 22:54:57.759787
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:59.860563
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:55:04.155414
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	a_s_t_0 = module_0.AST()
	yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
	yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
	assert yield_from_transformer_0 is not None
	assert yield_from_transformer_1 is not None


# Generated at 2022-06-25 22:55:06.186981
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:08.161491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # Checks that type of 'a_s_t_1' is 'AST'
    assert(type(a_s_t_1) is module_0.AST)


# Generated at 2022-06-25 22:55:10.260286
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    TODO: add test cases
    """
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-25 22:55:13.230197
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

if __name__ == "__main__":
    test_YieldFromTransformer()
    test_case_0()

# Generated at 2022-06-25 22:55:21.530951
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:55:25.160893
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:27.438977
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:55:32.373249
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_0 = None
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:37.868816
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(YieldFromTransformer)


# Generated at 2022-06-25 22:55:46.564063
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    mod = YieldFromTransformer.module_ast()
    with open('./test/yield_transformer/test_YieldFromTransformer.py', 'w') as f:
        f.write(mod.dump())
    try:
        with open('./test/yield_transformer/test_YieldFromTransformer.py', 'r') as f:
            if f.read() == mod.dump():
                test_case_0()
            else:
                assert(False)
    except:
        assert(False)
    finally:
        os.remove('./test/yield_transformer/test_YieldFromTransformer.py')

# Generated at 2022-06-25 22:55:49.119969
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test with a_s_t = None
    yield_from_transformer_0 = YieldFromTransformer(None)
    assert yield_from_transformer_0.tree == None
    return


# Generated at 2022-06-25 22:55:51.539079
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0


# Generated at 2022-06-25 22:55:52.229233
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-25 22:55:54.811874
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)

# Generated at 2022-06-25 22:56:09.621049
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:56:10.926172
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

test_case_0()

# Generated at 2022-06-25 22:56:14.035040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert not hasattr(yield_from_transformer_0, '_tree_changed')

# Generated at 2022-06-25 22:56:17.974168
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 22:56:19.312602
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception:
        pass


# Generated at 2022-06-25 22:56:21.832435
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:56:28.566040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test with tree = None

    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Test with tree = <typed_ast._ast3.AST object at 0x7f3edf72e668>

    a_s_t_1 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_1)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_1)



# Generated at 2022-06-25 22:56:32.265223
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert YieldFromTransformer is YieldFromTransformer

# Generated at 2022-06-25 22:56:33.069349
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


# Generated at 2022-06-25 22:56:38.023347
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

if __name__ == '__main__':
    arg_count = len(sys.argv) - 1
    if arg_count == 0:
        unittest.main()
    else:
        exit(
            generic_test.generic_test_main(
                "yield_from_transformer.py", "yield_from_transformer.tsv",
                YieldFromTransformer, test_YieldFromTransformer))

# Generated at 2022-06-25 22:57:21.846784
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0.current_module, module_0.Module) == False
    assert yield_from_transformer_0.current_module is None
    assert yield_from_transformer_0.tree_changed == False


# Generated at 2022-06-25 22:57:25.462631
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:57:27.190297
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
  assert(True)


# Generated at 2022-06-25 22:57:29.701407
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    assert type(YieldFromTransformer(a_s_t_0)) in [YieldFromTransformer, type(YieldFromTransformer)]
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:57:33.971714
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert (isinstance(yield_from_transformer_0, YieldFromTransformer))


# Generated at 2022-06-25 22:57:35.954273
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Check that __init__() raises the correct exception on invalid inputs
    with pytest.raises(TypeError):
        YieldFromTransformer(None)

# Generated at 2022-06-25 22:57:39.365686
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert_equal(yield_from_transformer_0.tree, a_s_t_0)


# Generated at 2022-06-25 22:57:45.033966
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0 is not None)
    assert(yield_from_transformer_0.target[0] == 3)
    assert(yield_from_transformer_0.target[1] == 2)
    assert(yield_from_transformer_0.tree == a_s_t_0)
    assert(isinstance(yield_from_transformer_0, BaseNodeTransformer))


# Generated at 2022-06-25 22:57:47.547264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:57:51.504305
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    global module_0
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # Unit test for visit of class YieldFromTransformer
    global test_case_0
    test_case_0()

# Generated at 2022-06-25 22:59:15.293847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0.AST()
    YieldFromTransformer(module_0.AST())

# Unit tests for visit method of class YieldFromTransformer

# Generated at 2022-06-25 22:59:22.614607
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, BaseNodeTransformer)
    assert isinstance(yield_from_transformer_0, BaseNodeTransformer)



# Generated at 2022-06-25 22:59:24.933477
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)



# Generated at 2022-06-25 22:59:26.287173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  a_s_t_0 = module_0.AST()
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:59:27.967672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:59:30.649017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    #assert_equals(False, yield_from_transformer_0.tree_changed)
    #assert_equals(False, yield_from_transformer_0.tree_changed)


# Generated at 2022-06-25 22:59:33.437206
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.target == (3, 2))


# Generated at 2022-06-25 22:59:34.387928
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()
# -----------------

# Generated at 2022-06-25 22:59:35.381179
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: Implement constructor test here.
    assert True # Placeholder that will be removed by doctests


# Generated at 2022-06-25 22:59:35.725717
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 23:02:21.152357
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = YieldFromTransformer(target=(3, 2))

# Generated at 2022-06-25 23:02:24.467808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)

# Generated at 2022-06-25 23:02:30.022828
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = importlib.import_module('typed_ast._ast3')
    try:
        with patch('typed_ast.ast3.parse', new=my_parse):
            test_case_0()
    except:
        raise


# Generated at 2022-06-25 23:02:31.470653
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:02:33.537565
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    assert isinstance(yield_from_transformer_1, YieldFromTransformer)


# Generated at 2022-06-25 23:02:37.659524
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(module_0.AST is ast.AST)
    # Test the constructor of class YieldFromTransformer
    class TestYieldFromTransformer():
        pass
    testyieldfromtransformer_0 = TestYieldFromTransformer()
    assert(testyieldfromtransformer_0 is not None)



# Generated at 2022-06-25 23:02:39.180350
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:02:41.425714
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 23:02:43.914874
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    print(str(yield_from_transformer_0._tree._root) + " -> " + str(yield_from_transformer_0.visit(a_s_t_0)))


# Generated at 2022-06-25 23:02:48.792133
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(1)
    except TypeError:
        pass
    
    #_, a_s_t_0 = ast.parse("")
    #try:
    #    YieldFromTransformer(a_s_t_0)
    #except TypeError:
    #    pass
    
    try:
        YieldFromTransformer(a_s_t_0, 1)
    except TypeError:
        pass
    
    try:
        YieldFromTransformer(a_s_t_0, ast_node=1)
    except TypeError:
        pass
    