

# Generated at 2022-06-25 22:52:52.486846
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(YieldFromTransformer(a_s_t_0), YieldFromTransformer)


# Generated at 2022-06-25 22:52:54.710517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:04.859105
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_0.body = [module_0.Expr(value=module_0.Name(id='a', ctx=module_0.Load()))]
    module_0.Assign(targets=[module_0.Name(id='a', ctx=module_0.Store())], value=module_0.BoolOp(op=module_0.Or(), values=[module_0.Name(id='a', ctx=module_0.Load()), module_0.Name(id='a', ctx=module_0.Load())])).lineno = 6

# Generated at 2022-06-25 22:53:05.713514
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()



# Generated at 2022-06-25 22:53:09.542584
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast_helper import FileAST

    tree = FileAST('yield_from.py')
    yield_from = YieldFromTransformer(tree)
    tree = yield_from.visit(tree)
    assert tree.__repr__() == 'FileAST'

# Generated at 2022-06-25 22:53:17.778986
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert hasattr(yield_from_transformer_0, "visit_Assign")
    assert hasattr(yield_from_transformer_0, "visit_Expr")
    assert hasattr(yield_from_transformer_0, "visit")
    assert hasattr(yield_from_transformer_0, "visit_While")
    assert isinstance(YieldFromTransformer.visit_While, ast.NodeVisitor)
    assert hasattr(yield_from_transformer_0, "visit_If")

# Generated at 2022-06-25 22:53:18.804839
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)


# Generated at 2022-06-25 22:53:22.076387
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    # construct
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:53:23.194715
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)


# Generated at 2022-06-25 22:53:25.885501
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	module_0 = ast.parse('def f(): yield from a')
	a_s_t_0 = YieldFromTransformer(module_0)
	# assert a_s_t_0._tree_changed == False


# Generated at 2022-06-25 22:53:34.654412
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, object) == True
    assert issubclass(YieldFromTransformer, BaseNodeTransformer) == True
    assert isinstance(YieldFromTransformer, object) == True
    assert isinstance(YieldFromTransformer, BaseNodeTransformer) == True


# Generated at 2022-06-25 22:53:36.484140
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer()



# Generated at 2022-06-25 22:53:37.145759
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_1 = YieldFromTransformer()


# Generated at 2022-06-25 22:53:37.494539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-25 22:53:38.567934
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-25 22:53:40.396304
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Unit tests for method visit of class YieldFromTransformer

# Generated at 2022-06-25 22:53:42.139431
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # length-0 array
    assert(len(yield_from_transformer_0.__dict__) == 0)


# Generated at 2022-06-25 22:53:44.212543
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast.parse("""a = yield from [1, 2, 3]""")
    yield_from_transformer_0 = YieldFromTransformer()


# Generated at 2022-06-25 22:53:45.633093
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)


# Generated at 2022-06-25 22:53:47.732618
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()
    assert a is not None
    assert isinstance(a, YieldFromTransformer)


# Generated at 2022-06-25 22:54:02.181816
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is YieldFromTransformer, "expected %s to be %s" % (YieldFromTransformer, YieldFromTransformer)

    # Create an instance of the YieldFromTransformer class
    assert isinstance(YieldFromTransformer, type), "expected type for YieldFromTransformer, but got %s" % type(YieldFromTransformer)
    yield_from_transformer_1 = YieldFromTransformer(module_0.AST())
    assert isinstance(yield_from_transformer_1, YieldFromTransformer), "expected %s to be instance of %s" % (yield_from_transformer_1, YieldFromTransformer)

    # Create an instance of the YieldFromTransformer class with arguments

# Generated at 2022-06-25 22:54:03.856654
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:05.794548
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t)


# Generated at 2022-06-25 22:54:12.950353
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #try:
    #    YieldFromTransformer(a_s_t_0)
    #except TypeError as e:
    #    print("TypeError raised:", e)
    #else:
    #    print("No exception raised.")

    #assert True
    pass
import typed_ast._ast3 as module_0
import typed_ast._ast3 as module_1
import typed_ast.ast3 as module_2
import typed_ast._ast3 as module_3
import typed_ast.ast3 as module_4


# Generated at 2022-06-25 22:54:19.805993
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return

if __name__ == '__main__':
    import timeit
    print(timeit.repeat(setup='from __main__ import test_case_0',
                        stmt='test_case_0()',
                        number=100000))
    print(timeit.repeat(setup='from __main__ import test_YieldFromTransformer',
                        stmt='test_YieldFromTransformer()',
                        number=100000))

# Generated at 2022-06-25 22:54:22.111090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:25.973237
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as e:
        print('Exception caught in:\nyield_from_transformer_0 = YieldFromTransformer(a_s_t_0)')
        raise e


# Generated at 2022-06-25 22:54:29.342746
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    print('ok')


# Generated at 2022-06-25 22:54:31.484714
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(YieldFromTransformer(a_s_t_0), YieldFromTransformer)

# Generated at 2022-06-25 22:54:32.339132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

# Generated at 2022-06-25 22:54:44.666901
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:47.015590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # run the code
    from typed_ast._ast3 import parse
    t = YieldFromTransformer(parse('def f(): yield from None'))
    # check that the constructor is working
    assert t.tree == parse('def f(): yield from None')

# Generated at 2022-06-25 22:54:48.698587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = module_0.AST()
    assert(YieldFromTransformer(a_s_t_2).tree is a_s_t_2)


# Generated at 2022-06-25 22:54:53.112414
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.tree == a_s_t_0.tree)


# Generated at 2022-06-25 22:54:57.759963
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # AssertionError: expected type 'YieldFromTransformer', got <class 'typed_ast.transforms.YieldFromTransformer'>
    assert type(yield_from_transformer_0) == YieldFromTransformer


# Generated at 2022-06-25 22:55:05.809440
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t0 = ast.NameConstant(
        "True",
        ctx=ast.Load(),
    )
    a_s_t1 = ast.Return(
        value=a_s_t0,
    )
    a_s_t2 = ast.Expr(
        value=a_s_t1,
    )
    a_s_t3 = ast.If(
        test=a_s_t0,
        body=[
            a_s_t2,
        ],
        orelse=[],
    )
    a_s_t4 = ast.Assign(
        targets=[
            ast.Name(
                id="a",
                ctx=ast.Store(),
            ),
        ],
        value=a_s_t0,
    )
    a_

# Generated at 2022-06-25 22:55:08.923893
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # ARRANGE #
    a_s_t_0 = module_0.AST()

    # ACT #
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

    # ASSERT #
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert isinstance(yield_from_transformer_0._tree, module_0.AST)


# Generated at 2022-06-25 22:55:10.512823
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:55:22.362442
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    except:
        assert True
    # Test the initialization of parent_function attribute
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
        assert yield_from_transformer_0.parent_function == None
    except:
        assert True
    # Test the initialization of tree attribute

# Generated at 2022-06-25 22:55:26.339771
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	a_s_t_0 = module_0.AST()
	a_s_t_1 = module_0.AST()
	yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
	assert(type(yield_from_transformer_0) == YieldFromTransformer)


# Generated at 2022-06-25 22:55:53.599167
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    set_target_1 = yield_from_transformer_0.set_target(a_s_t_0)
    set_target_1 = yield_from_transformer_0.set_target(a_s_t_0)
    set_target_1 = yield_from_transformer_0.set_target(a_s_t_0)
    set_target_1 = yield_from_transformer_0.set_target(a_s_t_0)
    set_target_1 = yield_from_transformer_0.set_target(a_s_t_0)
    set_target_1 = yield_from_transformer

# Generated at 2022-06-25 22:55:57.659558
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:56:00.606909
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:56:05.324432
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0._tree_changed == False
    assert yield_from_transformer_0._tree == module_0.AST()
    assert yield_from_transformer_0._tree.body == []


# Generated at 2022-06-25 22:56:13.412743
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        yield_from_transformer_0 = YieldFromTransformer()
# main.py:1:1: C0303: Trailing whitespace (trailing-whitespace)
# main.py:2:1: C0303: Trailing whitespace (trailing-whitespace)
# main.py:3:80: C0330: Wrong hanging indentation before block (hanging-indentation)
# main.py:4:1: C0303: Trailing whitespace (trailing-whitespace)
# main.py:6:1: C0326: Exactly one space required after comma (space-after-comma)
# main.py:6:1: C0330: Wrong hanging indentation before block (hanging-indentation)
# main.py:6:1

# Generated at 2022-06-25 22:56:14.621571
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:56:18.297374
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(module_0)
    assert isinstance(yield_from_transformer_0, BaseNodeTransformer)


# Generated at 2022-06-25 22:56:26.716393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test with target of invalid type
    invalid_type_1 = set([1])

    try:
        YieldFromTransformer(invalid_type_1)
    except TypeError:
        pass
    else:
        assert False

    # Test with target of invalid type
    invalid_type_1 = {}

    try:
        YieldFromTransformer(invalid_type_1)
    except TypeError:
        pass
    else:
        assert False

    # Test with target of invalid type
    invalid_type_1 = (1, 2, 3)

    try:
        YieldFromTransformer(invalid_type_1)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 22:56:35.697919
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()
    # Test 1
    a_s_t_0 = module_0.Assign([], module_0.YieldFrom(module_0.Name('a', module_0.Load())))
    a_s_t_1 = module_0.FunctionDef('a', [], [a_s_t_0], [], None, None)
    a_s_t_2 = module_0.Module([a_s_t_1])
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_2)
    a_s_t_2.body[0] = yield_from_transformer_0.visit(a_s_t_2.body[0])
    a_s_t_4 = yield_from_transformer_0.visit_

# Generated at 2022-06-25 22:56:38.541452
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None


# Generated at 2022-06-25 22:57:34.736711
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:37.268506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = None
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert(yield_from_transformer_0.tree is None)


# Generated at 2022-06-25 22:57:40.561400
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:57:42.810004
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # No Arguments
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:44.902134
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:57:50.317884
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Make sure there is no error when calling constructor
    try:
        from typed_ast import ast3 as ast
        from ..utils.tree import insert_at
        from ..utils.snippet import snippet, let, extend
        from ..utils.helpers import VariablesGenerator
        from .base import BaseNodeTransformer
        assert True
    except:
        assert False
    ast_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(ast_0)


# Generated at 2022-06-25 22:57:54.366176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-25 22:57:58.826234
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:58:01.062291
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:58:06.608074
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)
    a_s_t_1.body.append(module_0.Expr(module_0.YieldFrom(module_0.Name('test', module_0.Load()))))
    a_s_t_2 = yield_from_transformer_0.visit(a_s_t_1)
    assert (len(a_s_t_2.body) == 1)

# Generated at 2022-06-25 23:00:07.624396
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:09.160538
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("a")
    transformer = YieldFromTransformer(tree)
    assert transformer._tree is tree
    assert transformer._tree_changed is False


# Generated at 2022-06-25 23:00:09.854489
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()


# Generated at 2022-06-25 23:00:11.598587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:14.017690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = module_0.AST()
    yield_from_transformer = YieldFromTransformer(tree)
    assert yield_from_transformer._tree == tree
    assert yield_from_transformer._tree_changed == False
    assert yield_from_transformer._self_node == None


# Generated at 2022-06-25 23:00:15.394285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    return


# Generated at 2022-06-25 23:00:22.783916
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)
    assert isinstance(yield_from_transformer_0, module_0.NodeTransformer)

    name_0 = (yield_from_transformer_0.__class__.__module__ + '.'
              + yield_from_transformer_0.__class__.__qualname__)
    expected_0 = 'typed_astunparse.backport.yield_from.YieldFromTransformer'
    assert name_0 == expected_0, (name_0, expected_0)

    attributes_0 = yield_from_transformer_0.__dict

# Generated at 2022-06-25 23:00:24.588722
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:27.066798
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    # Set up parameters
    tree = ast.AST()

    # Invoke constructor
    yield_from_transformer = YieldFromTransformer(tree)

    # Check values of attributes
    assert yield_from_transformer._tree == tree


# Generated at 2022-06-25 23:00:28.376345
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    YieldFromTransformer(a_s_t_0)
