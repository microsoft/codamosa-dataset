

# Generated at 2022-06-25 22:52:54.071032
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert 'YieldFromTransformer'



# Generated at 2022-06-25 22:52:56.144345
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.AST()
    yield_from_transformer = YieldFromTransformer(node)
    print("YieldFromTransformer instance created")


# Generated at 2022-06-25 22:53:05.038365
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # constructor test
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # field test
    assert (YieldFromTransformer.target == (3, 2))
    assert (yield_from_transformer_0._tree == a_s_t_0)
    assert (yield_from_transformer_0._tree_changed == False)
    yield_from_transformer_0.generic_visit(a_s_t_0)
    assert (a_s_t_0 == a_s_t_0)


# Generated at 2022-06-25 22:53:07.357645
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:53:12.699859
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert ((isinstance(yield_from_transformer_0, module_0.NodeTransformer)) 
        and (type(yield_from_transformer_0) is YieldFromTransformer))
    assert (a_s_t_0.target == (3, 2))


# Generated at 2022-06-25 22:53:14.776852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:17.049707
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:19.004506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:53:20.851180
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:53:25.607765
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

if __name__ == '__main__':
    module_name = 'typed_ast.transforms.yield_from'
    module_ast = __import__(module_name)
    print('AST for {} before: {}'.format(module_name, module_ast))
    YieldFromTransformer().visit(module_ast)
    print('AST for {} after: {}'.format(module_name, module_ast))

# Generated at 2022-06-25 22:53:35.096278
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = ast.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:53:38.604439
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:53:42.446045
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as e:
        print('Exception raised when initializing YieldFromTransformer')
        print(e)
    else:
        print('No exception raised when initializing YieldFromTransformer')

if __name__ == '__main__':
    test_case_0()
    test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:44.714774
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:53:52.296285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # module_0.AST() -> AST
    a_s_t_0 = module_0.AST()
    # YieldFromTransformer(AST) -> YieldFromTransformer
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # YieldFromTransformer.visit(AST) -> AST
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


if __name__ == '__main__':
    import __main__ as main
    main.test_YieldFromTransformer()

# Generated at 2022-06-25 22:53:56.289327
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    if isinstance(yield_from_transformer_0, module_0.NodeVisitor):
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-25 22:53:58.726612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)



# Generated at 2022-06-25 22:54:01.394475
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:54:02.002849
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()


# Generated at 2022-06-25 22:54:04.003100
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:19.282073
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  try:
    test_case_0()
  except:
    print('FAILED!')
  else:
    print('PASSED!')

if __name__ == '__main__':
  test_case_0()

# Generated at 2022-06-25 22:54:21.556331
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)

# Generated at 2022-06-25 22:54:24.923702
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:54:25.689916
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()

# Generated at 2022-06-25 22:54:35.451153
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    original_0 = boolean(True)
    original_1 = boolean(False)
    original_2 = boolean(True)
    original_3 = boolean(True)
    original_4 = boolean(False)
    original_5 = boolean(True)
    original_6 = integer(42)
    original_7 = integer(42)
    original_8 = integer(42)
    original_9 = boolean(False)
    original_10 = integer(42)
    original_11 = boolean(False)
    original_12 = boolean(True)
    original_13 = boolean(True)
    original_14 = boolean(False)
    original_15 = boolean(True)
    original_16 = boolean(False)
    original_17 = integer(42)
    original_18 = boolean(True)
    original_19 = boolean(True)

# Generated at 2022-06-25 22:54:38.008488
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = module_0.AST()
    yield_from_transformer = YieldFromTransformer(node)
    assert isinstance(yield_from_transformer,
                      YieldFromTransformer)


# Generated at 2022-06-25 22:54:42.095405
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test constructor of class YieldFromTransformer"""
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0 is not None
    assert yield_from_transformer_0.tree is not None


# Generated at 2022-06-25 22:54:43.589773
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .snippets import module_ast
    YieldFromTransformer(tree=module_ast)

# Generated at 2022-06-25 22:54:47.341577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a_s_t_0 = module_0.AST()
        yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    except Exception as e:
        error_msg = ("Error at line: 13: Exception: init() got an unexpected keyword argument "
                     "\'tree\'"
                     )
        assert str(e) == error_msg


# Generated at 2022-06-25 22:54:50.608569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_2 = ast.AST()
    yield_from_transformer_1 = YieldFromTransformer(a_s_t_2)
    yield_from_transformer_2 = YieldFromTransformer(a_s_t_2)


# Generated at 2022-06-25 22:55:19.606730
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    

# Generated at 2022-06-25 22:55:23.054743
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:29.013246
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_1 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_1)
    # Unit test for construction of class YieldFromTransformer
    assert type(yield_from_transformer_0).__name__ == 'YieldFromTransformer'
    # Unit test for visit of class YieldFromTransformer
    assert yield_from_transformer_0.visit(a_s_t_1) == a_s_t_1


# Generated at 2022-06-25 22:55:32.765427
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    yield_from_transformer_0.generic_visit
    yield_from_transformer_0.visit

# Generated at 2022-06-25 22:55:42.183006
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert yield_from_transformer_0.tree == a_s_t_0
    assert yield_from_transformer_0.tree_changed == False
    assert yield_from_transformer_0.target == (3, 2)

# Unit tests for method YieldFromTransformer._get_yield_from_index

# Generated at 2022-06-25 22:55:45.750141
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # initialization
    yield_from_transformer_0 = YieldFromTransformer()
    a_s_t_0 = module_0.AST()
    # method visit
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:55:51.177637
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    assert hasattr(yield_from_transformer_0, '_tree_changed')
    assert hasattr(yield_from_transformer_0, '_tree')
    assert yield_from_transformer_0._tree_changed is True
    assert yield_from_transformer_0._tree is a_s_t_0


# Generated at 2022-06-25 22:55:53.248047
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_case_0()

support_0 = ('visit_Assign', 'visit_Expr')

method_0 = ('visit_Assign', 'visit_Expr')


# Generated at 2022-06-25 22:55:53.689184
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 22:55:54.810333
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-25 22:57:39.537732
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  # Basic: constructor
  a_s_t_0 = module_0.AST()
  yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
  a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
  assert(a_s_t_1 is None)
  # Basic: create_method
  a_s_t_0 = module_0.AST()
  method = 'a_s_t'
  yield_from_transformer_1 = YieldFromTransformer(a_s_t_0)
  yield_from_transformer_1.create_method(method)
  # Basic: visit_YieldFrom
  a_s_t_0 = module_0.AST()
  yield_from_

# Generated at 2022-06-25 22:57:43.050075
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Setup
    a_s_t_0 = module_0.AST()
    # Exercise
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Verify
    assert isinstance(yield_from_transformer_0, YieldFromTransformer)


# Generated at 2022-06-25 22:57:43.813917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)


# Generated at 2022-06-25 22:57:45.585140
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t = ast.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t)

test_YieldFromTransformer()

# Generated at 2022-06-25 22:57:47.331881
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer_0 = YieldFromTransformer(None)
    assert isinstance((yield_from_transformer_0), YieldFromTransformer)

# Generated at 2022-06-25 22:57:50.143378
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:57:58.696840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse(r'''
    def f():
        a = yield from b
        c = yield from d
        yield from e
        f = yield from g''')
    transformer = YieldFromTransformer(tree)
    new_node = transformer.visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-25 22:58:00.684689
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 22:58:07.991333
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert ((YieldFromTransformer.__init__.__code__.co_varnames == ('self',
     'tree',
     'filename')
     and YieldFromTransformer.__init__.__code__.co_argcount == 3
     and YieldFromTransformer.__init__.__code__.co_consts == (None,))
     and ((YieldFromTransformer.__init__.__code__.co_flags & 0x8) != 0
     and (YieldFromTransformer.__init__.__code__.co_flags & 0x80) == 0
     and (YieldFromTransformer.__init__.__code__.co_flags & 0x4) == 0))


# Generated at 2022-06-25 22:58:13.147044
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    # Testing if the instance is created
    assert yield_from_transformer_0 != None
    # Testing if the attributes are created
    assert yield_from_transformer_0.module != None
    assert yield_from_transformer_0.tree_changed != None
    assert yield_from_transformer_0.module != None
test_YieldFromTransformer()


# Generated at 2022-06-25 23:00:51.218165
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)


# Generated at 2022-06-25 23:00:54.063771
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 23:00:54.768448
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer) == type

# Generated at 2022-06-25 23:01:00.185556
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer.generic_visit,
                      ast.NodeVisitor)
    assert YieldFromTransformer.target == (3, 2)

    current_tree = ast.parse('')
    yield_from_transformer = YieldFromTransformer(current_tree)
    assert isinstance(yield_from_transformer,
                      YieldFromTransformer)
    assert yield_from_transformer._tree_changed is False
    assert yield_from_transformer.current_tree == current_tree



# Generated at 2022-06-25 23:01:01.392363
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer(ast.AST())) == YieldFromTransformer


# Generated at 2022-06-25 23:01:04.624401
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Try to construct the instance of class YieldFromTransformer, using module._ast3.AST as parameter.
    try:
        test_case_0()
    except Exception as e:
        # If failed to construct the instance, then throw an error
        raise Exception("Failed to construct the instance of class YieldFromTransformer, using module._ast3.AST as parameter.") from e

# Generated at 2022-06-25 23:01:05.071149
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-25 23:01:07.311069
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer = YieldFromTransformer(a_s_t_0)
    assert isinstance(yield_from_transformer, YieldFromTransformer)


# Generated at 2022-06-25 23:01:13.502358
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
    a_s_t_1 = yield_from_transformer_0.visit(a_s_t_0)
    try:
        assert a_s_t_0 is not None, 'assert #1'
    except AssertionError:
        raise
    try:
        assert a_s_t_1 is not None, 'assert #2'
    except AssertionError:
        raise


# Generated at 2022-06-25 23:01:15.089403
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a_s_t_0 = module_0.AST()
    yield_from_transformer_0 = YieldFromTransformer(a_s_t_0)
