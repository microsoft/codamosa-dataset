

# Generated at 2022-06-23 23:21:11.944018
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import check_transformation
    from ..utils.snippet import snippet

    @snippet
    def test(a, b):
        a = yield from b

    @snippet
    def expected(a, b):
        let(iterable)
        iterable = iter(b)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break

    check_transformation(YieldFromTransformer, test, expected)

# Generated at 2022-06-23 23:21:19.539766
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast1
    from ..autogen.ast3 import Module as ast2
    from ..autogen.ast3 import TryExcept as ast3
    from ..autogen.ast3 import Assign as ast4
    from ..autogen.ast3 import While as ast5
    from ..autogen.ast3 import FunctionDef as ast6
    from ..autogen.ast3 import arguments as ast7
    from ..autogen.ast3 import arg as ast8
    from ..autogen.ast3 import If as ast9
    from ..autogen.ast3 import Name as ast10
    from ..autogen.ast3 import Store as ast11
    from ..autogen.ast3 import Name as ast12
    from ..autogen.ast3 import Store as ast13
    from ..autogen.ast3 import Load as ast14

# Generated at 2022-06-23 23:21:23.564560
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_code, parse_ast_module
    source = source_to_code("""
        try:
            x = y
        except Exception:
            y = x
    """)
    tree = parse_ast_module(source)
    node = YieldFromTransformer().visit(tree)
    print(ast.dump(node))

# Generated at 2022-06-23 23:21:29.453752
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.cst import parse_module
    from ..compile import get_ast
    from .common import get_expected
    for target in ('3.2', '3.4'):
        with get_expected(__file__, '_yield_from', target) as expected:
            src = parse_module(expected)
            res = get_ast(src, (YieldFromTransformer, ))
            assert expected == res

# Generated at 2022-06-23 23:21:30.039952
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:36.683973
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..optimizer import Optimizer
    from ..unparser import Unparser
    import _ast
    from ..utils import helpers
    from ..utils.helpers import Source

    class YieldFromParser(ast.NodeVisitor):
        def __init__(self):
            self.yields = list()

        def visit_YieldFrom(self, node: ast.YieldFrom):
            self.yields.append(node)

        def generic_visit(self, node):
            ast.NodeVisitor.generic_visit(self, node)


# Generated at 2022-06-23 23:21:37.610440
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:38.501806
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()



# Generated at 2022-06-23 23:21:44.160088
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import typed_astunparse

    class TestYieldFromTransformer(unittest.TestCase):
        def test_one_body_assignment(self):
            tree = ast.parse("""
                def f():
                    yield from x
                """)
            actual_tree = YieldFromTransformer().visit(tree)
            expected_code = """
                def f():
                    exc = <unknown>
                    iterable = iter(x)
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            exc = exc
                            break

                """
            self.assertEqual(typed_astunparse.unparse(actual_tree), expected_code)

        def test_one_body_assignment_with_target(self):
            tree

# Generated at 2022-06-23 23:21:53.324318
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:54.530492
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-23 23:21:59.659083
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...testing.utils import assert_type

    test = {
        'name': 'test',
        'args': [],
        'body': [],
        'decorator_list': [],
        'returns': None,
        'type_comment': None
    }

    assert_type(YieldFromTransformer().visit(ast.FunctionDef(**test)), ast.FunctionDef)

# Generated at 2022-06-23 23:22:10.128520
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    statement = """
    a = yield from b
    c = yield from d
    yield from e
    f = g
    """
    tree = ast.parse(statement)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed


# Generated at 2022-06-23 23:22:11.086307
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:19.827589
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .renamer import RenamerTransformer
    from .test_renamer import test_renamer
    from .base_node_transformer import test_base_node_transformer
    from .helpers import get_targets
    from .resolve import ResolveTransformer
    from .test_resolve import test_resolve
    from .extract_docstring import ExtractDocstringTransformer
    from .test_extract_docstring import test_extract_docstring
    from .unused_variables import UnusedVariablesTransformer
    from .test_unused_variables import test_unused_variables
    from .unused_imports import UnusedImportsTransformer
    from .test_unused_imports import test_unused_imports
    from .use_future import UseFutureTransformer

# Generated at 2022-06-23 23:22:25.884788
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer()
    import typed_astunparse
    print(typed_astunparse.dump(t.visit(
        ast.Module(
            body=[
                ast.FunctionDef(
                    name='f',
                    args=ast.arguments(
                        args=[],
                        vararg=None,
                        kwonlyargs=[],
                        kw_defaults=[],
                        kwarg=None,
                        defaults=[]
                    ),
                    body=[
                        ast.Expr(ast.YieldFrom(ast.Name(id='gen', ctx=ast.Load())))
                    ],
                    decorator_list=[],
                    returns=None
                )
            ]
        )
    )))



# Generated at 2022-06-23 23:22:30.150279
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def f():
        while True:
            a = yield from pretty_function()
            b = yield from pretty_function()
            c = yield from pretty_function()

    tr = YieldFromTransformer()
    expected = tr.visit(ast.parse(f.__code__))

# Generated at 2022-06-23 23:22:38.725016
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import get_declared_variables
    from .transformations import SequenceTransformer

    with open('tests/samples/yield_from.py') as f:
        tree = ast.parse(f.read())

    sequence = YieldFromTransformer(SequenceTransformer())
    sequence.visit(tree)

    tree = astor.to_source(tree).strip()

# Generated at 2022-06-23 23:22:42.219134
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from inspect import signature
    from typing import get_type_hints

    assert len(signature(YieldFromTransformer).parameters) == 1
    assert get_type_hints(YieldFromTransformer)['__init__'] == ()


# Generated at 2022-06-23 23:22:44.004537
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:22:45.049746
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:22:51.247983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.Assign()
    a.targets.append(ast.Name(id='a', ctx=ast.Load()))
    a.value = ast.YieldFrom()

    b = ast.Expr()
    b.value = ast.YieldFrom()
    b.value.value = ast.Call()

    c = ast.Module()
    c.body.append(a)
    c.body.append(b)

    test_YieldFromTransformer = YieldFromTransformer()
    test_YieldFromTransformer.visit(c)

# Generated at 2022-06-23 23:22:55.203607
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .compiler import compile
    from .unroller import UnrollerTransformer
    import os

    with open(os.path.join(os.path.dirname(__file__), '..',
              'tests', 'resources', 'yield_from.py')) as f:
        test_code = f.read()

    node = compile(test_code)
    node = UnrollerTransformer().visit(node)
    node = YieldFromTransformer().visit(node)

# Generated at 2022-06-23 23:23:02.499440
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import cst
    from ..utils.mock_code import make_mock_code

    trans = YieldFromTransformer()

    def make_yield_from(name, target=None):
        return ast.YieldFrom(
            value=ast.Name(id=name, ctx=ast.Load())
        )
    source = """
        if a:
            b = yield from c
        i = 1
        a = yield from b
        while True:
            d = yield from e
        def x():
            f = yield from g
    """  # noqa

# Generated at 2022-06-23 23:23:12.483545
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    import ast
    tree = ast.parse(textwrap.dedent(
        """\
        def foo():
            yield from bar()
            yield from bar()
            z = yield from bar()
            yield from bar()
            yield from bar()
        """))
    transformer = YieldFromTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 23:23:21.695564
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from collections import namedtuple
    from ..utils.tree import as_ast

    with extend(namedtuple('YieldFromTestCase',
                           ['before', 'after', 'is_changed'])):
        YieldFromTestCase = namedtuple('YieldFromTestCase',
                                       ['before', 'after', 'is_changed'])
        YieldFromTestCase(before='a = yield from iterable',
                          after='a = exc.value\n'
                                'iterable = iter(iterable)\n'
                                'while True:\n'
                                '    try:\n'
                                '        yield next(iterable)\n'
                                '    except StopIteration as exc:\n'
                                '        break\n',
                          is_changed=True)
        Yield

# Generated at 2022-06-23 23:23:22.584899
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tf = YieldFromTransformer()


# Generated at 2022-06-23 23:23:23.438300
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:23:23.945120
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(True)

# Generated at 2022-06-23 23:23:30.457164
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast import parse
    from .base import BaseNodeTransformer
    from pprint import pprint

    node = parse('''def foo(self):
        x = yield from range(5)
        y = x + 3
    ''')

    transformed = YieldFromTransformer().visit(node)
    pprint(transformed)


# Generated at 2022-06-23 23:23:33.446211
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print("Test: " + __file__)
    node_transformer = YieldFromTransformer()
    assert node_transformer is not None


# Generated at 2022-06-23 23:23:38.017588
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    y = YieldFromTransformer()
    assert y.__class__.__name__ == 'YieldFromTransformer'
    try:
        y = YieldFromTransformer(default=0)
        assert False
    except:
        assert True

# Generated at 2022-06-23 23:23:40.119969
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # It is impossible to initialize object
    # YieldFromTransformer(self, node: ast.AST) -> ast.AST
    assert True



# Generated at 2022-06-23 23:23:49.147251
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..ast_transformer import ASTTransformer
    from ..utils.ast_converter import get_ast
    from ..utils.ast_comparator import compare_ast
    from ..utils.compiled import script_from_ast
    from ..utils.source_code_modification import SourceCodeModification
    ast_transformer = ASTTransformer([YieldFromTransformer])
    transformed_ast = ast_transformer.transform(get_ast())
    assert compare_ast(transformed_ast, get_ast()) is True
    assert compare_ast(ast_transformer.transform(get_ast()), get_ast()) is True

# Generated at 2022-06-23 23:24:00.753861
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .ast_to_src import ast_to_src
    from ..utils.snippet import from_lines
    from ..utils.helpers import get_ast

    code = from_lines([
        'def function():',
        '    x = [1, 2, 3]',
        '    y = [1, 2, 3]',
        '    return x, y'
    ])

    expected = from_lines([
        'def function():',
        '    x = [1, 2, 3]',
        '    y = [1, 2, 3]',
        '    exc = VariablesGenerator.generate(\'exc\')',
        '    return x, y'
    ])

    tree = get_ast(code)
    YieldFromTransformer().visit(tree)  # type: ignore
    src

# Generated at 2022-06-23 23:24:07.903101
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_ast as sta

    expected = sta("""
    def test(o):
        exc = VariablesGenerator.generate('exc')
        iterable = iter(o)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    o = exc.value
                break

    """)
    actual = sta("""
    def test(o):
        yield from o

    """)
    transformer = YieldFromTransformer()

    assert transformer.visit(actual) == expected

# Generated at 2022-06-23 23:24:11.416752
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3

    def example():
        result = yield from gen()
        _ = yield from gen()


# Generated at 2022-06-23 23:24:12.488095
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:24:22.830840
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_equal_code

    code = '''
    def func(x=None):
       y = yield from x
       yield y

    print(func(x=(item for item in range(10))))
    '''
    expected_code = '''
    def func(x=None):
        let(iterable)
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    y = exc.value
                break
        yield y
    print(func(x=(item for item in range(10))))
    '''
    assert_equal_code(YieldFromTransformer, code, expected_code)

# Generated at 2022-06-23 23:24:23.900516
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-23 23:24:31.031944
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    from ..visitor import FileScanner

    module_code = textwrap.dedent('''\
        def foo():
            yield from x
    ''')

    tree = ast.parse(module_code)
    assert isinstance(tree, ast.Module)

    scanner = FileScanner(tree)
    assert len(list(scanner.find_nodes_by_type(ast.YieldFrom))) == 1

    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-23 23:24:40.670209
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tester import assert_transformation, assert_not_transformed
    from ..utils.tree import tree

    node = tree("""
        def f(a, b):
            x = yield from f(a, b)
            yield from f(x)
            y = yield
            if c:
                return yield from f(y)
            return y
    """)


# Generated at 2022-06-23 23:24:48.838042
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    sample_code = """
        def function(arg1):
            a = yield from arg1
            yield from arg1
            yield from arg1
            (yield from arg1)
            a = b = c = d = yield from arg1
            a, b, c, d = yield from arg1
    """


# Generated at 2022-06-23 23:24:57.123304
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    expected = ast.parse("""
    def foo():
        exc = VariablesGenerator.generate('exc')
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                target = exc.value
                break
    """)

    foo = ast.parse("""
    def foo():
        yield from generator
    """)

    visitor = YieldFromTransformer()
    foo = visitor.visit(foo)
    # ast.dump(foo)
    assert ast.dump(foo, False) == ast.dump(expected, False)



# Generated at 2022-06-23 23:25:01.022750
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.parse("x = yield from range(5)")
    b = ast.parse("""\
    y = iter(range(5))
    while True:
        try:
            yield from y
        except StopIteration as exc:
            x = exc.value
            break""")
    assert YieldFromTransformer().visit(a) == b

# Generated at 2022-06-23 23:25:11.728598
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # input data:
    YIELD = ast.YieldFrom()
    ID = ast.Name()
    ASSIGN = ast.Assign(targets=[ID], value=YIELD)
    COMPOUND = ast.Try(body=[ASSIGN])

    # expected AST

# Generated at 2022-06-23 23:25:15.146833
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from transpyler.utils import load_source_code, dump_ast
    source_code = load_source_code('isinstance')
    tree = ast.parse(source_code)
    list(YieldFromTransformer().visit(tree))
    dump_ast(tree)



# Generated at 2022-06-23 23:25:20.294477
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .examples import yield_from_for_example, expect_yield_from_for_example
    # instantiate class
    yield_from_transformer = YieldFromTransformer()
    # check attributes
    assert yield_from_transformer.target == (3, 2)
    # check method generic_visit()
    source_code = yield_from_for_example
    tree = ast.parse(source_code)
    tree = yield_from_transformer.visit(tree)
    assert ast.dump(tree) == expect_yield_from_for_example

# Generated at 2022-06-23 23:25:30.670531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""
        def a():
            yield from b()

        def b():
            yield from c()

        def c():
            return 1
    """)


# Generated at 2022-06-23 23:25:37.058117
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module_ast = ast.parse("""def foo():
    yield from bar(1)
    x = yield from bar(2)""")
    yield_from_transformer = YieldFromTransformer()
    assert yield_from_transformer.visit(module_ast) == ast.parse("""def foo():
    iterable = iter(bar(1))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break

    iterable = iter(bar(2))
    exc = None
    x = None
    while True:
        try:
            x = next(iterable)
            yield x
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                x = exc.value
            break""")

# Generated at 2022-06-23 23:25:41.215626
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Test3:
        def test(self, a, b=None, *args, **kwargs):
            c = a + b
            return c
    test1 = Test3()
    test2 = Test3()
    test3 = Test3()

# Generated at 2022-06-23 23:25:43.011347
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .unparse import Unparser
    from .tree_transformer import TreeTransformer


# Generated at 2022-06-23 23:25:44.419842
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yftr = YieldFromTransformer()


# Generated at 2022-06-23 23:25:52.804256
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..context import Context
    import textwrap

    context = Context(source='hello.py', target=(3, 2))
    transformer = YieldFromTransformer(context)
    src = textwrap.dedent("""\
        for a in b:
            for c in d:
                if a == 3:
                    a = yield from e
                    yield from f
                    return
                elif b == 3:
                    ('sssss')
                yield from g
                yield from h
                return
    """)

# Generated at 2022-06-23 23:25:54.582093
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer(3, 2).target == (3, 2)


# Generated at 2022-06-23 23:25:56.204826
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:26:02.804371
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = ast.parse('a = yield from b')
    YieldFromTransformer()(t)
    assert str(t).strip() == 'a = None\niterable = iter(b)\nwhile True:\n    try:\n        a = next(iterable)\n        yield a\n    except StopIteration as exc:\n        if hasattr(exc, \'value\'):\n            a = exc.value\n        break'

# Generated at 2022-06-23 23:26:11.549735
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)

# Unit tests for function _get_yield_from_index of class YieldFromTransformer

# Generated at 2022-06-23 23:26:22.226917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('yield from test()')

    class NodeTransformer(ast.NodeTransformer):
        def visit_YieldFrom(self, node):
            return ast.Assign(targets=[ast.Name('x', ast.Store())],
                              value=node)

        def visit_FunctionDef(self, node):
            return ast.Block(body=[node])

    tree = NodeTransformer().visit(tree)
    tree = YieldFromTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    result = compile(tree, '<test>', 'single')
    value = result.body.body[0].body[0].value
    assert isinstance(value, ast.While)
    assert value.test is None

# Generated at 2022-06-23 23:26:31.149202
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:26:40.619053
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import tree
    from typed_ast import ast3 as ast

    # Cases of correct generate of ast of test modules
    # assert_tree_equal(expected, actual, msg=None)
    # assert_tree_equal(expected, actual, msg=None)

    def assert_tree_equal(tree1: ast.AST, tree2: ast.AST, msg: str = None):
        assert tree.compare(tree1, tree2), msg

    def assert_tree_equal_code(tree1: ast.AST, code: str, msg: str = None):
        tree2 = tree.convert_from_code(code)
        assert_tree_equal(tree1, tree2, msg=msg)

    # Test cases for method visit of YieldFromTransformer

# Generated at 2022-06-23 23:26:43.293358
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_transformers import load_example_snippet

    snippet = load_example_snippet('yield_from.py')
    transformer = YieldFromTransformer()
    transformer.visit(snippet)

# Generated at 2022-06-23 23:26:53.157261
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    # Given
    source = "from typing import Generator\n" \
             "from six import raise_from\n" \
             "\n" \
             "def foo():\n" \
             "    a = yield from bar()\n" \
             "    b = yield from baz()\n" \
             "\n" \
             "def bar() -> Generator[int, None, None]:\n" \
             "    yield 42\n" \
             "\n" \
             "def baz() -> Generator[int, None, None]:\n" \
             "    raise_from(ValueError('error'), None)\n" \
             "\n" \
             "for i in foo():\n" \
             "    print(i)"
    code = astor.parse_file(source)
   

# Generated at 2022-06-23 23:26:56.969392
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Test(YieldFromTransformer):
        def visit_Expr(self, node):
            return node
    test = Test()
    test._handle_assignments(node=1)
    test._handle_expressions(node=1)
    test.visit(None)

# Generated at 2022-06-23 23:26:58.884971
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..utils.snippet import let
    from ..utils.helpers import VariablesGenerator
    from ..utils.test_utils import assert_program


# Generated at 2022-06-23 23:27:09.504584
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import sys
    sys.path.insert(0, "../")
    from ..utils.tree import lhs, cmpAst
    from ..utils.helpers import run_transformers
    from ..transformers.YieldFromTransformer import YieldFromTransformer
    from ..tree_transformer import TreeTransformer

    class TestVisit(unittest.TestCase):
        def test_YieldFromTransformer_visit(self):
            code = '''
            def foo():
                a = yield from smth()
                yield from smth()
                yield from smth()
            '''  # noqa
            tree = compile(code, '<test>', 'exec', ast.PyCF_ONLY_AST)
            tree = TreeTransformer(YieldFromTransformer()).visit(tree)
            self

# Generated at 2022-06-23 23:27:14.829633
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('yield from range(0, 10)')
    result = ast.parse('''
        let(exc)
        let(iterable)
        iterable = iter(range(0, 10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')
    transformer = YieldFromTransformer()
    assert transformer.visit(tree) == result


# Generated at 2022-06-23 23:27:26.262360
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.testing import assert_transformed

    code = textwrap.dedent("""
    a = (yield from [1, 2, 3])
    yield from range(10)
    """)


# Generated at 2022-06-23 23:27:27.263358
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:27:30.162014
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    trans = YieldFromTransformer()
    assert trans.target == (3, 2)


# Generated at 2022-06-23 23:27:34.609224
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import get_ast
    from ..utils.tree import to_src

    class Dummy(YieldFromTransformer):
        def __init__(self):
            self._tree_changed = False


# Generated at 2022-06-23 23:27:35.736183
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:36.768363
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:46.595248
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer()
    orig_program = ast.parse("""
        def foo():
            yield from bar()
    """)
    assert orig_program.body[0].body[0].value.value.id == 'bar'
    result = t.visit(orig_program)
    assert result.body[0].body[0].value.value.func.id == 'iter'
    assert result.body[0].body[0].value.value.args[0].id == 'bar'
    assert result.body[0].body[3].value.func.id == 'next'
    assert result.body[0].body[3].value.args[0].id == 'iterable'
    assert isinstance(result.body[0].body[4].value, ast.Call)

# Generated at 2022-06-23 23:27:48.627019
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:55.154143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import unparse
    import ast
    node = ast.Try(body=[ast.Expr(ast.YieldFrom(ast.Str('hello'))), ast.Expr(ast.YieldFrom(ast.Str('hi')))],handlers=[],orelse=[],finalbody=[])
    node = ast.Module(body=[node])
    node = YieldFromTransformer().visit(node)
    print(unparse(node))

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:28:04.135318
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    expected_yield_from_ast = yield_from.get_ast(
        generator=ast.Name(id='collector'),
        assignment=result_assignment.get_ast(
            exc=ast.Name(id='exc'),
            target=ast.Name(id='a')),
        exc=ast.Name(id='exc'))

    node = ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='a')], value=ast.YieldFrom(value=ast.Name(id='collector'))),
        ast.Expr(value=ast.YieldFrom(value=ast.Name(id='collector')))])

    transformer = YieldFromTransformer()
    result = transformer.visit(node)

    assert len(result.body) == 3
    assert result.body

# Generated at 2022-06-23 23:28:13.839254
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
    def function():
        yield from iterable
        x = yield from iterable
        yield from iterable
        yield from iterable
        yield from iterable
        x = yield from iterable
        
    """

# Generated at 2022-06-23 23:28:14.669808
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:28:16.991494
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test for constructor of class YieldFromTransformer."""
    YieldFromTransformer()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:28:17.766912
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass # TODO


# Generated at 2022-06-23 23:28:24.660174
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_visit import test_visit
    # TODO: Change to src.transforms.yield_from.YieldFromTransformer
    test_visit(YieldFromTransformer, 'for.py', 'for_yield_from.py')
    test_visit(YieldFromTransformer, 'while.py', 'while_yield_from.py')
    test_visit(YieldFromTransformer, 'try_except.py', 'try_except_yield_from.py')

# Generated at 2022-06-23 23:28:31.736000
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    test_case = unittest.TestCase()

    _transform = YieldFromTransformer.transform

    def transform(source: str) -> str:
        return _transform(source, version=(3, 2))

    def assert_transform(source: str, expected: str):
        test_case.assertEqual(transform(source), expected)


# Generated at 2022-06-23 23:28:41.299584
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse


# Generated at 2022-06-23 23:28:42.838191
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert False, "Test not implemented"



# Generated at 2022-06-23 23:28:46.760338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    source = source('''
try:
    a = yield from f()
except Exception as exc:
    pass
    ''')
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)


test_YieldFromTransformer()

# Generated at 2022-06-23 23:28:54.552809
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class FakeTree(ast.AST):
        def __init__(self, body):
            self.body = body

    class FakeExpr(ast.AST):
        def __init__(self, value):
            self.value = value

    class FakeAssign(ast.AST):
        def __init__(self, targets, value, expr):
            self.targets = targets
            self.value = value
            self.expr = expr

    class FakeYieldFrom(ast.AST):
        def __init__(self, value):
            self.value = value

    fake_yield_from_1 = FakeYieldFrom('receiver')
    fake_yield_from_2 = FakeYieldFrom('receiver')
    fake_yield_from_3 = FakeYieldFrom('receiver')
    fake_yield_

# Generated at 2022-06-23 23:28:55.646862
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:29:04.802964
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...helpers.python_ast import parse_ast
    from ..expand_asserts import AssertsExpander
    from ..unpack_inheritance import UnpackInheritanceTransformer
    from ..unpack_excepts import UnpackExceptTransformer
    from ..unpack_unpacking import UnpackUnpackingTransformer

    source = '''
    def function():
        a = yield from [1, 2]
    '''
    tree = parse_ast(source)
    visitor = YieldFromTransformer()
    visitor.visit(tree)

    expander = AssertsExpander()
    expander.visit(tree)

    unpack_except = UnpackExceptTransformer()
    unpack_except.visit(tree)

    unpack_unpacking = UnpackUnpackingTransformer()
    unpack_un

# Generated at 2022-06-23 23:29:08.572862
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    tree = ast.parse('def f():\n    yield from [1, 2]')
    YieldFromTransformer().visit(tree)
    print(astunparse.unparse(tree))


test_YieldFromTransformer()

# Generated at 2022-06-23 23:29:20.169803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from unittest import TestCase
    from .base import BaseUnittestTransformer
    from .async_ import AsyncTransformer
    from .try_ import TryTransformer

    class YieldFromTransformerUnittest(TestCase, BaseUnittestTransformer):
        transformer = YieldFromTransformer

        def test_transform_yield_from_simple(self):
            node = 'yield from gen'
            expected = 'while True:\n'\
                       '    try:\n'\
                       '        yield next(iterable)\n'\
                       '    except StopIteration as exc:\n'\
                       '        break'
            result = self.compile_and_decompile(node)
            self.assertEqual(result, expected)


# Generated at 2022-06-23 23:29:21.651313
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:29:29.995394
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:29:33.439338
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree_1 = ast.parse("""{'a': 1}""")
    expected_tree_1 = ast.parse("""{'a': 1}""")

# Generated at 2022-06-23 23:29:42.128485
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = """
x, y = obj.items()
"""
    expected = """
try:
    iterable = iter(obj.items())
    while True:
        try:
            x, y = next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                x, y = exc.value
            break
except (AttributeError, TypeError) as exc:
    raise TypeError(
        "object returned by 'items' must be an iterable object"
        )
"""
    tree = parse(source)
    YieldFromTransformer().visit(tree)
    compare_source(expected, tree)

# Generated at 2022-06-23 23:29:43.896496
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Method for unit testing constructor of class YieldFromTransformer."""

# Generated at 2022-06-23 23:29:45.091636
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer



# Generated at 2022-06-23 23:29:52.540585
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from pprint import pprint
    import astor

    source = '''
a = []
b = 0
c = 1

for i in a:
    b = yield from i
    c = yield from b
'''

    def node_visitor(node):
        print('\n', '-' * 5, astor.to_source(node).strip())

    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

    for node in ast.walk(tree):
        node_visitor(node)

# Generated at 2022-06-23 23:29:58.968802
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_equal_ast

    code = '''def f():
        a = 10
        b = yield from range(a)
    '''
    expected_code = '''def f():
        a = 10
        let(iterable)
        iterable = iter(range(a))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    b = exc.value
                break

    '''
    ast_tree = ast.parse(code)
    YieldFromTransformer.visit(ast_tree)
    assert_equal_ast(expected_code, ast_tree)



# Generated at 2022-06-23 23:30:00.668349
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()
    assert repr(tr) == '<YieldFromTransformer>'

# Generated at 2022-06-23 23:30:01.583257
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:12.341885
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from unpythonic import macro
    from .base import BaseNodeTransformer
    from ...syntax import macros, test, let, return_, try_, finally_, yield_from, ffi
    from ...syntax import let_syntax, for_, iterate, do
    with BaseNodeTransformer.bootstrap_static():
        @macro
        def pytest():
            """Macro that calls `test.equivalent_expr` with the given arguments."""
            return_[test.equivalent_expr(*_args)]

        with_gensym = ffi.cdef("""
            int with_gensym(void (*f)(void));
        """)

        let_syntax(test_pytest=pytest)

# Generated at 2022-06-23 23:30:22.142539
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    target = ast.parse('''
    def f(a):
        c = yield from a + b
        yield from a + b
        c = yield from a + b
        yield from a + b
        c = yield from a + b
        d = yield from a + b
    ''')

# Generated at 2022-06-23 23:30:32.204890
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # code for testing
    code = '''def foo():
        yield from range(10)
    '''
    # record changed
    tree_changed = YieldFromTransformer.is_changed(code)
    assert tree_changed == True

    # record changes for unit testing
    # python 3.4
    if sys.version_info[0:2] == (3, 4):
        # expected
        expected_changed_code = '''def foo():
    iterable = range(10)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break

'''

# Generated at 2022-06-23 23:30:40.103028
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast.ast3 as ast
    
    # Test 1
    #  Create instance of class YieldFromTransformer
    transformer = YieldFromTransformer()
    
    # Test 2
    #  Create instance of class FunctionDef
    node = ast.FunctionDef(
        name="foo",
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]),
        body=[
            ast.Expr(value=ast.YieldFrom(value=ast.Name(id="bar", ctx=ast.Load())))
        ],
        decorator_list=[],
        returns=None)
    
    #  Test 2.1
    #  Call method visit of class Yield

# Generated at 2022-06-23 23:30:46.671936
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    transform = YieldFromTransformer()
    tree = ast.parse('x = yield from 1+1')
    transform.visit(tree)
    expected = 'exc = iter(1 + 1)\nwhile True:\n    try:\n        x = next(exc)\n    except StopIteration as exc:\n        if hasattr(exc, \'value\'):\n            x = exc.value\n        break'
    assert astunparse.unparse(tree) == expected

# Generated at 2022-06-23 23:30:48.641456
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    inst = YieldFromTransformer()
    assert isinstance(inst, YieldFromTransformer)


# Generated at 2022-06-23 23:30:49.635573
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:50.266878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:30:51.196267
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:30:57.642328
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import ast2tree, tree2ast
    import astor
    assign = astor.parse("a = yield from 1").body[0]
    exp = astor.parse("yield from 1").body[0]
    exp_result = astor.parse("iterable = (yield from iter(1))"
                             " while True:"
                             " try:"
                             "     yield next(iterable)"
                             " except StopIteration as exc1:"
                             "     exc = exc1"
                             "     break")

# Generated at 2022-06-23 23:30:58.699982
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:31:06.527639
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from .helpers import get_ast, roundtrip

    code = source('''
    def func(a, b):
        c = yield from a
        return c
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    result = roundtrip(tree)

    assert result == source('''
    def func(a, b):
        let(iterable)
        iterable = iter(a)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    c = exc.value
                break
        return c
    ''')