

# Generated at 2022-06-23 23:21:07.095878
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.source import source_to_node
    from ..utils.tree import dump

    snippet = '''
try:
    a = f()
except Exception as e:
    pass
    '''

    node = source_to_node(snippet.__doc__)
    YieldFromTransformer.apply(node)
    print(astor.to_source(node))
    dump(node)

# Generated at 2022-06-23 23:21:12.194194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..test.test_utils import test_transformer
    from ..test.test_cases.test_snippets import yield_from_assignment
    from ..test.test_cases.test_snippets.yield_from_assignment import yield_from_assignment_expected

    test_transformer(YieldFromTransformer, yield_from_assignment,
                     yield_from_assignment_expected)

# Generated at 2022-06-23 23:21:19.708876
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..parser import Parser
    from ..annotate import type_inference
    from .namespace import add_namespace

    parser = Parser()
    tree = parser.parse("""
            def foo():
                x = yield from range(1)

            def bar():
                yield from range(2)
        """)
    tree = type_inference.transform(tree)
    tree = add_namespace.transform(tree)
    transformer = YieldFromTransformer(tree)
    tree = transformer.transform()

# Generated at 2022-06-23 23:21:21.809034
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:21:31.081260
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from .. import transformers

    src1 = """
        def func():
            yield from foo

        yield from foo
        """
    src2 = """
        def func():
            a = yield from foo
            yield from foo
            b = yield from foo
        
        func()
        """
    src3 = """
        def func():
            yield from foo
            yield from bar()
        """

    for src in [src1, src2, src3]:
        tree = source.parse(src)
        YieldFromTransformer().visit(tree)
        transformers.fix_missing_locations(tree)

        print(source.to_source(tree))


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:21:32.667310
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from astor.code_gen import to_source


# Generated at 2022-06-23 23:21:39.907988
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import parse

    source = "def f(x):" \
             "    y = yield from x"

    node = parse(source)
    trans = YieldFromTransformer()
    trans.visit(node)

    expected = "def f(x):" \
               "    let(iterable)" \
               "    iterable = iter(x)" \
               "    while True:" \
               "        try:" \
               "            yield next(iterable)" \
               "        except StopIteration as exc:" \
               "            y = exc.value" \
               "            break"

    assert str(node) == expected

# Generated at 2022-06-23 23:21:45.322775
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import create_node

    node = create_node(
        "while True:\n"
        "    a = yield from foo()\n"
        "    b = yield from bar()"
    )

    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:21:47.421316
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t1 = YieldFromTransformer()


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:21:49.926612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """__init__ test
    """
    transformer = YieldFromTransformer()
    assert transformer.target == (3, 2)
    assert transformer._tree_changed == False


# Generated at 2022-06-23 23:21:54.754455
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    @snippet
    def test():
        let(generator)
        generator = (x for x in 'ab')
        let(result)
        result = yield from generator
        assert result == 'a'
        let(result)
        result = yield from generator
        assert result == 'b'

    test_ast = test.get_ast()
    transformer = YieldFromTransformer()
    transformer.visit(test_ast)
    assert transformer._tree_changed is True
    assert compile(test_ast, '<test_YieldFromTransformer_visit>', 'exec')

# Generated at 2022-06-23 23:21:55.350404
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:56.625611
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft
    return yft

# Generated at 2022-06-23 23:22:06.986813
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Given
    code = """
    def foo():
        yield from bar()
    """
    expected_code_1 = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    expected_code_2 = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
    """

# Generated at 2022-06-23 23:22:07.633302
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:12.943517
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast
    import astunparse
    import textwrap
    node = ast.parse(textwrap.dedent('''
        def test():
            gen = _get_gen()
            yield from gen
    '''))
    YieldFromTransformer('_get_gen').visit(node)
    print(astunparse.unparse(node))


__transformer__ = YieldFromTransformer

# Generated at 2022-06-23 23:22:20.921299
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
        async def coro():
            yield from [1, 2, 3]

        f = yield from coro()
    """
    expected = """
        async def coro():
            let(iterable)
            iterable = iter([1, 2, 3])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

        let(iterable)
        iterable = iter(coro())
        while True:
            try:
                extend(result_assignment)
                f = next(iterable)
            except StopIteration as exc:
                break
    """
    tree = ast.parse(code)
    YieldFromTransformer.run(tree)

    assert expected == astor.to_source(tree)

# Generated at 2022-06-23 23:22:21.391054
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:21.948894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:22:22.476559
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-23 23:22:23.434000
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:22:32.551070
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3
        from typed_python_backport.modules.builtins import ast_helpers
    except ImportError:
        from typed_ast import ast3
        from typed_python._types import ast_helpers

    from astunparse import unparse
    from ..utils.snippet import parse

    # try:
    #     from typed_ast import ast3
    #     from typed_python._types import ast_helpers
    # except ImportError:
    #     from typed_ast import ast3
    #     from typed_python_backport.modules.builtins import ast_helpers


# Generated at 2022-06-23 23:22:33.445133
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:22:35.004763
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import unparse
    import astor

# Generated at 2022-06-23 23:22:38.557014
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.Try(ast.parse('yield from gen()', mode='eval').body, handlers=[], finalbody=[])
    assert isinstance(node, ast.Try)
    x = YieldFromTransformer()
    node = x.visit(node)



# Generated at 2022-06-23 23:22:41.857727
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor, logging
    logging.basicConfig(level=logging.INFO)

    YieldFromTransformer().visit(
        astor.parse_file('../examples/yield_from.py').body[0])

# Generated at 2022-06-23 23:22:50.358368
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils.source import source_to_unicode
    from .. import compile_string
    source = source_to_unicode(dedent("""
    def fib():
        yield 1
        yield 2
        yield 3
        yield 4
        yield 5
    """))
    tree = compile_string(source, 3, 2)
    transformer = YieldFromTransformer(tree)
    tree = transformer.visit(tree)
    source = source_to_unicode(dedent("""
    def fib():
        yield 1
        yield 2
        yield 3
        yield 4
        yield 5
    """))
    assert compile_string(source, 3, 2) == tree

# Generated at 2022-06-23 23:22:56.730249
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import PythonSnippetGenerator
    from ..utils.test_utils import transform

    source = """
        from test_module import test_method
        def my_function():
            test_function()
            
        def my_function():
            generator = test_method(1, 2)
            b = yield from generator
            
        def my_function():
            a = yield from test_method(1, 2)
            
        def my_function():
            c, d = yield from test_method(1, 2)
            
        def my_function():
            e, f, g = yield from test_method(1, 2)
            
        def my_function():
            a = yield from test_method(1, 2)
            c, d = yield from test_method(1, 2)
    """

# Generated at 2022-06-23 23:22:57.832636
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj is not None

# Generated at 2022-06-23 23:22:59.068263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    # Test creation of class YieldFromTransformer    
    assert transformer

# Generated at 2022-06-23 23:22:59.808659
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:23:08.449602
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import Generator
    from ..utils.helpers import load

    def yield_from_transformer(node: ast.AST) -> ast.AST:
        transformer = YieldFromTransformer()
        return transformer.visit(node)

    # Without side effects
    yield_from_transformer(load('''
        yield from x
    '''))
    # Without side effects
    yield_from_transformer(load('''
        y = yield from x
    '''))

    # With side effects

# Generated at 2022-06-23 23:23:18.435834
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Tests that the correct error is raised if the class is run on a < 2.7
    version of python."""
    import ast as py_ast
    code = (
        'def foo():'
        '    foo = yield from bar()'
        '    return foo'
    )
    tree = py_ast.parse(code)
    out = YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:23:26.764838
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helpers import transform

    def test(code):
        return transform(code, YieldFromTransformer)

    assert test('''
        def a(x):
            yield from x
    ''') == '''
        def a(x):
            let(iterable)
            iterable = iter(x)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    '''


# Generated at 2022-06-23 23:23:37.499428
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    a = '''def func_name(arg1):
        yield from some_value
        return yield from some_value
    '''
    a_expected = '''def func_name(arg1):
    let(iterable)
    iterable = iter(some_value)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                exc = exc.value
            break
    let(iterable)
    iterable = iter(some_value)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                exc = exc.value
            break
    return exc
'''

# Generated at 2022-06-23 23:23:40.201809
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Test if we can create an instance of YieldFromTransformer
    '''
    try:
        obj = YieldFromTransformer()
    except:
        assert False


# Generated at 2022-06-23 23:23:44.092096
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_fixtures.yield_from_transformer_setup import (  # pylint: disable=import-outside-toplevel
        node, expected_node)
    transformed = YieldFromTransformer().visit(node)
    assert transformed == expected_node

# Generated at 2022-06-23 23:23:55.927227
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    # Assumptions:
    # 1. YieldFromTransformer only allows type Node.
    # 2. YieldFromTransformer can only be used directly by _get_yield_from_index, _emulate_yield_from,
    #    _handle_assignments, _handle_expressions, and visit.
    # 3. YieldFromTransformer cannot be used by function that is not in the same class.
    # 4. YieldFromTransformer cannot create instance of any other class.
    # 5. YieldFromTransformer can only create instance of VariablesGenerator.
    # 6. YieldFromTransformer is designed to run automatically only once. (visit is not recursively called)
    assert issubclass(type(transformer), YieldFromTransformer)
    # Test if transformer

# Generated at 2022-06-23 23:23:57.423392
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None



# Generated at 2022-06-23 23:24:07.221230
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_support import run_test, test_program

    from .test_exceptions import test_exceptions
    from .test_try_except import test_try_except

    for example, expected in (test_exceptions + test_try_except):
        run_test(YieldFromTransformer, example, expected)


# Generated at 2022-06-23 23:24:17.480304
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..env import Environment
    env = Environment()
    module = ast.parse('''def a():
    yield from b()
    print(c)''')
    tr = YieldFromTransformer()
    tr.visit(module)
    assert len(module.body) == 1
    assert len(module.body[0].body) == 1
    function_body = ast.parse('''def a():
    let(iterable)\n    iterable = iter(b())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                c = exc.value
            break
    print(c)''').body[0].body

# Generated at 2022-06-23 23:24:26.804061
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from ..utils.helpers import get_ast

    snippet = """
        def foo(x):
            s = yield from []
            print(s)
    """

    expected = dedent("""
    def foo(x):
        let(iterable)
        iterable = iter([])
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                s = exc.value
                break
        print(s)
    """)

    module = get_ast(snippet)
    transformer = YieldFromTransformer()
    assert str(ast.fix_missing_locations(transformer.visit(module))) == expected



# Generated at 2022-06-23 23:24:27.673835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:24:29.648730
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source

# Generated at 2022-06-23 23:24:39.422462
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    with open('test_YieldFromTransformer_visit.py') as f:
        source = f.read()
    tree = ast.parse(source)

    YieldFromTransformer().visit(tree)

    code = compile(tree, '<string>', 'exec')

# Generated at 2022-06-23 23:24:40.349616
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:24:48.620059
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_astunparse import unparse
    from ..fake import FakeFile, FakeTree
    import ast
    var = FakeFile.StringIO()
    _ast = ast.parse("def foo():\n\tyield from gen")
    tree = FakeTree(target=(3, 2))
    tree.attach_fake_file(var)
    tree.patch_ast(_ast, YieldFromTransformer)
    unparse(_ast, file=var)

# Generated at 2022-06-23 23:24:52.497293
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.options import Options
    from ..utils.helpers import dump_python_source
    from ..utils.tree import parse_python_source

    code = """
        def foo():
            yield from (yield x)
    """

# Generated at 2022-06-23 23:25:01.604401
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
     import astor
     from ..utils.ast_helper import tree_to_str
     from .transformer_test_case import TransformerTestCase

     class TestYieldFromTransformer(TransformerTestCase):
         transformer = YieldFromTransformer
         target = (3, 2)


# Generated at 2022-06-23 23:25:12.030653
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_tools import ast_pprint
    from ..utils.helpers import load_ast

    from . import ConvertComprehensionsTransformer
    from . import ForLoopsTransformer
    from . import ExceptionsTransformer
    from . import GeneratorToFunctionTransformer
    from . import FunctionDefTransformer

    source = '''
    lst = [1, 2, 3]

    try:
        lst = (i for i in lst)
        lst = yield from lst
    except Exception as e:
        pass
    '''


# Generated at 2022-06-23 23:25:15.872725
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_helpers import dump
    from ..utils.ast_factory import ast_call, ast_assign, ast_expr, ast_return, ast_stmt, ast_module
    from ..utils.helpers import fake_function

    def func():
        yield_from_1 = ast_call('yield_from', 'x')
        yield_from_2 = ast_call('yield_from', 'y')
        yield_from_3 = ast_call('yield_from', 'z')
        yield_from_4 = ast_call('yield_from', 't')

        expr_yield_from = ast_expr(yield_from_1)
        expr_yield_from_2 = ast_expr(yield_from_2)

# Generated at 2022-06-23 23:25:27.277227
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

    class test_YieldFromTransformer(YieldFromTransformer):
        def fix_code(self, code_str):
            tree = ast.parse(code_str)
            self.visit(tree)
            return astor.to_source(tree)

    yield_from_transformer = test_YieldFromTransformer()
    assert yield_from_transformer.fix_code(
        """
        yield_from(1)
        """
    ) == """
        while True:
            try:
                yield next(iter(1))
            except StopIteration as exc:
                break
        """


# Generated at 2022-06-23 23:25:28.253054
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:30.552019
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import print_ast


# Generated at 2022-06-23 23:25:31.299230
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    ast.parse("""
yield from range(5)
""").body[0]

# Generated at 2022-06-23 23:25:36.459874
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    import textwrap
    from ..utils.helpers import to_source

    if ast.YieldFrom:
        source = inspect.getsource(YieldFromTransformer)
        exec(textwrap.dedent(source))

    class r:
        pass

    node = ast.parse("""
        from __future__ import braces
        a = yield from f()
        yield from f()
        """)
    transformer = YieldFromTransformer()
    source = to_source(transformer.visit(node))

    r.tb = None
    exec(source)


# Generated at 2022-06-23 23:25:46.848224
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    from ..utils.convert import convert
    from ..utils.helpers import get_ast
    module = get_ast(textwrap.dedent('''\
        def foo():
            x = yield from [1, 2, 3]
            foo = yield from [4, 5, 6]
            yield from range(10)
    '''))
    new_module = convert(module, YieldFromTransformer)

# Generated at 2022-06-23 23:25:48.227957
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .tools.test_utils import compare_source

# Generated at 2022-06-23 23:25:49.757792
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
# Construct an object of YieldFromTransformer
yieldFromTransformer = YieldFromTransformer()

# Generated at 2022-06-23 23:25:51.223629
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as python_ast
    from ..transpile import Transpiler


# Generated at 2022-06-23 23:25:53.248358
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('yield from x')
    result = YieldFromTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(result)

# Generated at 2022-06-23 23:25:54.497933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(None)
    assert transformer is not None

# Generated at 2022-06-23 23:25:55.670978
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:26:04.250467
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BasicTransformer, Transformer
    from .name import NameTransformer
    from .yield_from import YieldFromTransformer
    from .neo import NeoTransformer
    from .unused import UnusedTransformer
    from .if_exp import IfExpTransformer
    from .try2 import Try2Transformer
    from .genexp import GenExpTransformer
    from .nested_scopes import NestedScopesTransformer
    from ..utils.helpers import VariablesGenerator, CodeGenerator
    from ..utils.parser import parse
    import ast
    import astunparse


# Generated at 2022-06-23 23:26:05.603129
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import test_utils as tu


# Generated at 2022-06-23 23:26:13.100230
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import unittest
    from typed_ast.ast3 import YieldFrom
    from .TestTransformer import TestTransformer
    from .optimize import OptimizeTransformer
    from ..utils.tree import tree_to_str

    if sys.version_info[:2] < (3, 2):
        return

    def get_expected_results(get_yield_from_ast):
        body_no_yield_from = [get_yield_from_ast(YieldFrom(ast.Name('it', ast.Load()), ast.Load()))]

        body_with_yield = [ast.Yield(ast.Name('it', ast.Load()))]
        body_with_yield.extend(body_no_yield_from)


# Generated at 2022-06-23 23:26:13.637048
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:26:24.520514
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import astunparse
    from ..utils.helpers import generate_name

    class YieldFromTransformerTest(unittest.TestCase):
        def test_for(self):
            node = ast.parse('for a in range(0): yield from function()')
            expected = 'for a in range(0):\n    iterable = iter(function())\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            exc = exc.value\n            break'
            YieldFromTransformer().visit(node)
            self.assertEqual(astunparse.unparse(node), expected)

        def test_if_then(self):
            node = ast.parse('if True: yield from function()')

# Generated at 2022-06-23 23:26:32.631602
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''
            def main():
                a = 1 if True else 2
                a = yield from range(0, 3)
                yield from range(3, 10)
                yield from range(0, 5)
                return a
            '''

    node = ast.parse(code)
    transformer = YieldFromTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-23 23:26:37.348696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old


# Generated at 2022-06-23 23:26:38.592850
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Instantiating object
    _YieldFromTransformer = YieldFromTransformer()

# Generated at 2022-06-23 23:26:47.243740
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:26:48.139310
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()


# Generated at 2022-06-23 23:26:52.524959
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    import astor
    from ..utils.mock_tree import get_tree

    tree = get_tree(sys.modules[__name__])
    YieldFromTransformer().visit(tree)

    tree_str = astor.to_source(tree)

# Generated at 2022-06-23 23:26:57.421153
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node0 = ast.parse('''
    def foo():
        yield from [1, 2]
    ''')
    node1 = ast.parse('''
    def foo():
        yield from [1, 2]
    ''')
    assert YieldFromTransformer.run_on_nodes(node0, node1) == node1


# Generated at 2022-06-23 23:26:58.263708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)

# Generated at 2022-06-23 23:26:58.779958
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:27:00.256393
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import compile3to2

# Generated at 2022-06-23 23:27:05.449227
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    input_code = """
    def test(data):
        assignments = []
        while True:
            line = yield from readlines()
            try:
                line = int(line)
            except ValueError:
                continue
            else:
                assignments.append(line)

    def readlines():
        return ['3', '2']
    """

# Generated at 2022-06-23 23:27:15.211547
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..unittest import test_transformer, test_ast

    from .canonical import canonic

    code = '''
    def test(i):
        yield from i
    '''
    expected = '''
    def test(i):
        let(iterable)
        iterable = iter(i)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    '''
    test_transformer(YieldFromTransformer, code, expected)

    # Test YieldFromTransformer.visit with an empty module.
    tree = test_ast(code)
    assert canonic(tree) == canonic(expected)

    # Test that visit method doesn't change the tree if source

# Generated at 2022-06-23 23:27:22.056803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..transformer import Transformer
    from ..utils import load_source_ast

    a = '''
    def foo():
        a = yield from foo1()
    '''

    b = '''
    def foo1():
        yield "a"
        yield "b"
        yield "c"
    '''

    tree = load_source_ast('a', a)
    tree1 = load_source_ast('b', b)
    tree2 = Transformer([YieldFromTransformer()]).transform(tree)

    assert tree == tree1
    assert tree != tree2
    assert isinstance(tree2, ast.Module)
    assert len(tree2.body) == 2
    assert len(tree2.body[0].body) == 4

# Generated at 2022-06-23 23:27:32.606140
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast

    from .syntax_transform import SyntaxTransform

    from .unwrapper import Unwrapper

    from .generator_transformer import GeneratorTransformer

    from .yield_transformer import YieldTransformer

    from .helpers import get_source

    source = '''def test():
    a = yield from b
    yield from b
    yield from c
    yield from d()
    e = yield from f()'''

    tree = ast.parse(source)

    tree = SyntaxTransform(YieldFromTransformer()).visit(tree)
    tree = ast.fix_missing_locations(tree)

# Generated at 2022-06-23 23:27:41.582071
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import TreeBuilder, replace_last_lineno
    from ..utils.helpers import NodeWalker
    from ..utils.loader import StringLoader

    def test_function(a, b):
        yield from a(b())
        yield from a(b)  # Generator

    tree = TreeBuilder.build(test_function)
    tree = replace_last_lineno(tree, 1)
    loader = StringLoader()
    walker = NodeWalker(loader=loader)
    walker.walk(tree, YieldFromTransformer)

# Generated at 2022-06-23 23:27:47.401775
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import transform_compare
    from . import YieldFromTransformer

    @transform_compare(YieldFromTransformer)
    def test():
        f = (yield from range(3))
        print(f)
        b = (yield from range(4))
        print(b)
        a = (yield from range(5))
        print(a)

    test()

# Generated at 2022-06-23 23:27:48.855276
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        import typed_ast.ast3 as ast
    except ImportError:
        return

    ast_tree = ast.Module(body=[])
    YieldFromTransformer(ast_tree)
    return ast_tree

# Generated at 2022-06-23 23:27:49.823042
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer

# Generated at 2022-06-23 23:27:56.679216
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tree_utils import build_ast

    transformer = YieldFromTransformer()
    source = 'a = 3; b = yield from some_generator()'
    expected = """
a = 3
exc = 0
iterable = iter(some_generator())
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        exc = exc.value if hasattr(exc, 'value') else exc
        break
b = exc
"""
    assert build_ast(expected) == transformer.visit(build_ast(source))

# Generated at 2022-06-23 23:27:57.561792
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:28:00.258086
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Constructor
    a = YieldFromTransformer()

    assert a.target == (3, 2)
    assert a.do_optimize == False


# Unit tests for methods of class YieldFromTransformer

# Generated at 2022-06-23 23:28:02.511880
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer(None).__class__.__name__ == 'YieldFromTransformer'

# Generated at 2022-06-23 23:28:07.841183
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_base import get_test_modules
    from .test_base import transform_module_to_string

    module_name, module = get_test_modules('example', 'yield_from.py')
    transformer = YieldFromTransformer()
    module_str = transform_module_to_string(transformer, module)


# Generated at 2022-06-23 23:28:08.776786
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:28:10.131499
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(True)

# Generated at 2022-06-23 23:28:12.225104
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import common_test

    common_test.test_transform(YieldFromTransformer, 3, 2, 'yield_from')

# Generated at 2022-06-23 23:28:17.035002
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj._tree_changed == None
    assert obj._seen_yields == None
    assert obj.target == (3, 2)
    assert obj._get_yield_from_index == None
    assert obj._emulate_yield_from == None
    assert obj._handle_assignments == None
    assert obj._handle_expressions == None
    assert obj.visit == None

# Generated at 2022-06-23 23:28:27.015802
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...ast import parse
    from ...utils.testing import assert_tree

    tree = parse('a = (yield from b)')
    new_tree = YieldFromTransformer().visit(tree)
    assert_tree(new_tree, """\
    Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='yield_from', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[], starargs=None, kwargs=None))])
    """)

    tree = parse('c = d = (yield from e)')
    new_tree = YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:28:29.250433
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    import doctest
    failure_count, test_count = doctest.testmod(sys.modules[__name__])
    assert failure_count == 0

# Generated at 2022-06-23 23:28:33.722354
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse("def f(): yield from g()")
    module = YieldFromTransformer().visit(module)
    code = compile(module, '<test>', 'exec')

    gen = globals()["f"]()
    assert next(gen) == None


# Generated at 2022-06-23 23:28:38.818023
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.samples import SamplePrograms
    from .return_transformer import ReturnTransformer
    from .compound import CompoundTransformer
    from .try_except_state import TryFinallyTransformer, TryExceptTransformer
    from .for_state import ForElseTransformer, ForTransformer
    from .with_state import WithTransformer
    from .while_state import WhileTransformer


# Generated at 2022-06-23 23:28:39.736168
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:28:49.153013
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import pytest
    from typed_astunparse import unparse
    from ..unparse import Unparser
    from .test_autotransformer import transform
    from .helpers import assert_transform_equal

    class YieldTransformer(YieldFromTransformer):
        def _handle_expr_yield_from(
                self, node: ast.Expr, index: int) -> List[ast.AST]:
            return []

        def _handle_assign_yield_from(
                self, node: ast.Assign, index: int) -> List[ast.AST]:
            return []

    def do_test(src: str, expected: str):
        tree = transform(src, YieldTransformer)
        result = Unparser(tree)
        assert_transform_equal(result, expected)


# Generated at 2022-06-23 23:28:55.957516
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3
    from ..unparse import Unparser

    source = """\
    def test():
        var = yield from [1, 2, 3]
        print(var)
    """

    expected = """\
    def test():
        var = None
        iterable = iter([1, 2, 3])
        while True:
            try:
                var = next(iterable)
                yield var
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    var = exc.value
                break
        print(var)
    """

    node = ast3.parse(source, mode='exec')
    YieldFromTransformer().visit(node)
    assert Unparser(node, newline='') == expected

# Generated at 2022-06-23 23:29:02.929224
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import testutils
    module = testutils.build_module("""
    def f():
        a = yield from g()
    """)  # type: ast.Module
    YieldFromTransformer().visit(module)
    assert testutils.to_source(module) == """
    def f():
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break

    """.strip()

# Generated at 2022-06-23 23:29:11.141814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import ast_converter as converter
    from typed_astunparse import unparse

    x = converter.parse('''
async def foo(n):
    for i in range(n):
        await async_sleep(i)
        yield i
    return 0
''', python_version="3.5")
    YieldFromTransformer().visit(x)
    got = unparse(x)
    assert got == 'async def foo(n):\n    for i in range(n):\n        yield from async_sleep(i)\n        yield i\n    return 0'


# Generated at 2022-06-23 23:29:13.177685
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer.target == (3, 2)


# Generated at 2022-06-23 23:29:14.308824
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:29:15.236997
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:23.980547
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import compile_str

    compile_str('x = yield from range(10)')
    compile_str('yield from foo')
    compile_str('yield from foo().bar()')
    compile_str('yield from [foo().bar()]')
    compile_str('yield from (foo().bar())')
    compile_str('yield from {foo().bar()}')
    compile_str('yield from {foo().bar(): "baz"}')
    compile_str('yield from {1: foo().bar()}')

    with pytest.raises(TypeError):
        compile_str('yield from')

# Generated at 2022-06-23 23:29:25.498342
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).target == (3, 2)

# Generated at 2022-06-23 23:29:26.661945
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Test visit method of YieldFromTransformer."""

# Generated at 2022-06-23 23:29:36.915479
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .context import Context, Ctx
    from .unpack import UnpackTransformer
    from .scope import ScopeTransformer
    from .assignment import AssignmentTransformer
    from .expression import ExpressionTransformer
    from .boolop import BoolOpTransformer
    from .returns import ReturnTransformer
    from .jumps import BreakContinueTransformer
    from .loops import ForLoopTransformer
    from ..utils.helpers import global_context, process_global_context
    import astor
    code = '''
    def foo():
        a = yield from foo1()
        b = yield from foo2()
        yield from foo3()
        return a
    '''
    tree = ast.parse(code)
    ctx = Context()
    ctx = Ctx(ctx, tree)
    ctx = global_context(ctx)

# Generated at 2022-06-23 23:29:38.236427
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

# Generated at 2022-06-23 23:29:42.925511
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.context import Context
    from ..utils.source import Source
    from ..utils.visitor import Visitor

    src = Source("""
        def f():
            res = yield from range(3)
    """)
    ctx = Context(source=src)
    v = Visitor()
    v.run(ctx, YieldFromTransformer)

# Generated at 2022-06-23 23:29:53.202751
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from py2_7_compatibility.utils.tree import to_string
    from py2_7_compatibility.utils.py2_source import get_function_source, get_lambda_source

    function_source = get_function_source(test_1)
    YieldFromTransformer().visit(function_source)
    assert to_string(function_source) == \
        """def test_1(iterable):
    list_1 = []
    while True:
        try:
            list_1.append(next(iterable))
        except StopIteration as exc_1:
            break

    return list_1
"""

    function_source = get_function_source(test_2)
    YieldFromTransformer().visit(function_source)

# Generated at 2022-06-23 23:29:58.390386
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_base import get_ast_from_fn

    transformer = YieldFromTransformer()
    input_ = """
    def a(b, c):
        pass
    """
    expected = """
    def a(b, c):
        pass
    """
    fn = get_ast_from_fn(input_)
    transformed = transformer.visit(fn)
    assert transformer._tree_changed == False
    assert ast.dump(transformed) == expected

# Generated at 2022-06-23 23:29:59.447568
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:10.133196
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast

    # Create an instance of class YieldFromTransformer
    YieldFromTransformer()

    # Create an instance of class Name
    ast.Name(id="generator")

    # Create an instance of class YieldFrom
    ast.YieldFrom(value=ast.Name(id="generator"))

    # Create an instance of class Expr
    ast.Expr(value=ast.YieldFrom(value=ast.Name(id="generator")))

    # Create an instance of class Assign
    ast.Assign(targets=[ast.Name(id="assignment")], value=ast.YieldFrom(value=ast.Name(id="generator")))

    # Create an instance of class FunctionDef

# Generated at 2022-06-23 23:30:13.499992
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    constructor_code = YieldFromTransformer.__init__
    env = {}
    exec(constructor_code, {}, env)
    assert "super().__init__()" in env["__init__"]


# Generated at 2022-06-23 23:30:14.468574
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-23 23:30:19.584518
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    _source = "yield from 'iterator'"
    _node = ast.parse(_source).body[0]
    _transformer = YieldFromTransformer()
    _result = _transformer.visit(tree=_node)
    assert _result.__class__.__name__ == 'FunctionDef' 
    assert len(_result.body) == 4



# Generated at 2022-06-23 23:30:20.528630
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():  # noqa: D103
    YieldFromTransformer()

# Generated at 2022-06-23 23:30:22.874655
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception as e:
        assert False, "Creation failed for some reason: " + str(e)
    else:
        assert True


# Generated at 2022-06-23 23:30:29.399587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer(())
    assert isinstance(t, YieldFromTransformer)


# Unit tests for _get_yield_from_index

# Generated at 2022-06-23 23:30:32.080436
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(1, 2, 3)
    except Exception as ex:
        assert type(ex) is TypeError

# TODO: Create a unit test for visit method of class YieldFromTransformer

# Generated at 2022-06-23 23:30:39.991097
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils.parsers import get_parser
    from ..utils.ast import print_node


# Generated at 2022-06-23 23:30:50.725394
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import utils
    import os

    os.chdir(os.path.dirname(__file__))

    source = utils.load_test_input_as_ast("yield_from.py")
    source = source.body[0]  # type: ignore
    assert source.body[0].value.value == "Unhandled exception"
    assert source.body[0].value.args[0].id == "exc"
    assert source.body[1].value.value == "Unhandled exception"
    assert source.body[1].value.args[0].id == "exc"

    YieldFromTransformer().visit(source)

    assert len(source.body) == 5

    assert source.body[1].value.value == "Unhandled exception"

# Generated at 2022-06-23 23:30:55.552240
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import typed_astunparse # type: ignore

    class Tester(unittest.TestCase):
        def _test_yield_from_compiler(self, input: str, output: str,
                                      transformer: YieldFromTransformer) -> None:
            input_ast = typed_astunparse.ast_parse(input)
            output_ast = typed_astunparse.ast_parse(output)
            result = transformer.visit(input_ast)
            self.assertEqual(typed_astunparse.unparse(result),
                             typed_astunparse.unparse(output_ast))


# Generated at 2022-06-23 23:31:04.190246
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Tests snippet result_assignment
    exc = 'exc'
    target = 'target'
    assert result_assignment.get_body(exc=exc, target=target) == [
        ast.Assign(
            targets=[
                ast.Name(
                    id='target',
                    ctx=ast.Store())],
            value=ast.Attribute(
                attr='value',
                value=ast.Name(
                    id='exc',
                    ctx=ast.Load()),
                ctx=ast.Load()))]

    # Tests snippet yield_from
    generator = 'generator'
    exc = 'exc'
    assignment = 'assignment'