

# Generated at 2022-06-23 23:21:01.800829
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:21:05.029491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...utils import compile_to_ast

    tree = compile_to_ast("""
    async def foo(x):
        yield from range(x)
    """)

    yield_from_transformer = YieldFromTransformer()
    yield_from_transformer.visit(tree)

# Generated at 2022-06-23 23:21:09.363879
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:16.151500
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse('def f():\n'
                     '    yield from range(10)')
    result = 'def f():\n' \
             '    let(iterable)\n' \
             '    iterable = iter(range(10))\n' \
             '    while True:\n' \
             '        try:\n' \
             '            yield next(iterable)\n' \
             '        except StopIteration as exc:\n' \
             '            break'
    transformation = YieldFromTransformer()
    new_node = transformation.visit(node)
    assert ast.dump(new_node) == result



# Generated at 2022-06-23 23:21:23.169571
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tr = YieldFromTransformer()
    assert tr.visit(ast.parse('yield from 1')) == ast.parse('yield next(iter(1))')
    assert tr.visit(ast.parse('a = yield from 1')) == ast.parse('a = None; while True: try: a = next(iter(1)) except StopIteration as exc: a = exc.value; break')
    assert tr.visit(ast.parse('yield from 1; yield from 2')) == ast.parse('yield next(iter(1)); while True: try: yield next(iter(2)) except StopIteration as exc: exc.value; break')

# Generated at 2022-06-23 23:21:32.886905
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer()
    tree = ast.parse("""
    def f(gen):
        var = yield from gen
    def g():
        var2 = yield from gen2
        yield from gen3
        yield from gen4""")

# Generated at 2022-06-23 23:21:41.698924
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import get_ast

    # No replacements at all
    tree_1 = get_ast('def foo():\n    pass')
    transformer_1 = YieldFromTransformer()
    transformer_1.visit(tree_1)
    assert transformer_1.tree_changed is False

    # Replacing one YieldFrom
    tree_2 = get_ast('def foo():\n    x = yield from range(2)')
    transformer_2 = YieldFromTransformer()
    transformer_2.visit(tree_2)
    assert transformer_2.tree_changed is True

# Generated at 2022-06-23 23:21:51.071068
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.fake_parser import (
        FakeParser,
        FakeParserError,
        FakeCompiler,
        FakeCompilerError,
    )
    from ..utils.fake_utils import FakeUtils
    filename = "test_filename"
    options = {"fake_utils": FakeUtils()}
    parser = FakeParser()
    if_ast = parser.parse(
        """\
if True:
    x = yield from a
    y = yield from b
    if x > 3:
        yield from c
        yield from d
else:
    yield from e
"""
    )

# Generated at 2022-06-23 23:21:59.176209
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""
    def foo():
        a = yield from bar()
        yield from baz()
        yield from quux()
    """)

    tree = YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:22:00.139491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer

# Generated at 2022-06-23 23:22:01.906551
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Try, If, While, For
    pass

    # FunctionDef
    pass

    # Module
    pass

# Generated at 2022-06-23 23:22:06.173444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node_1 = ast.YieldFrom(value=ast.List(elts=[], ctx=ast.Load()))
    node = ast.Expr(value=node_1)
    YieldFromTransformer().visit(node)
    assert node.value.value.elts[0].value.value == 'exc'

# Generated at 2022-06-23 23:22:15.086518
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse('from typing import cast, Union\n'
                     'def fun1(a: int) -> Union[int, None]:\n'
                     '    yield from cast(a, int)\n'
                     'def fun2(a: int) -> Union[int, None]:\n'
                     '    yield from fun1(a)\n')
    print(ast.dump(node, annotate_fields=False, include_attributes=True))
    YieldFromTransformer().visit(node)
    for ind, line in enumerate(ast.dump(node, annotate_fields=False, include_attributes=True)
                               .splitlines()):
        print(ind + 1, line)

# Generated at 2022-06-23 23:22:15.596933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print("test YieldFromTransformer")

# Generated at 2022-06-23 23:22:22.149735
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import _ast as ast
    from tests.test_transpilers.utils import assert_program

    program_1 = """
    def foo():
        a = yield from bar()
        b = yield from bar()
    """

# Generated at 2022-06-23 23:22:23.476343
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None).target == (3, 2)

# Generated at 2022-06-23 23:22:27.318910
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Unit test for constructor of class YieldFromTransformer
    '''
    assert YieldFromTransformer().__class__.__name__ == "YieldFromTransformer"

# Generated at 2022-06-23 23:22:29.319087
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Testing constructor')
    c = YieldFromTransformer()
    assert isinstance(c, BaseNodeTransformer)


# Generated at 2022-06-23 23:22:29.888850
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:22:31.140154
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-23 23:22:38.045362
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.FunctionDef(None, 'something',
                           ast.arguments(None, None, None, None),
                           [
                               ast.Expr(ast.YieldFrom(ast.Name('test', ast.Load()))),
                               ast.Assign([ast.Name('test', ast.Store())],
                                          ast.YieldFrom(ast.Name('test', ast.Load())))
                           ], [], None)
    node = YieldFromTransformer.run(node)
    assert isinstance(node.body[0], ast.While)
    assert isinstance(node.body[1], ast.While)

# Generated at 2022-06-23 23:22:39.305864
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): #@NoSelf
    trans = YieldFromTransformer()
    assert isinstance(trans, YieldFromTransformer)

# Generated at 2022-06-23 23:22:40.242982
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()


# Generated at 2022-06-23 23:22:49.949796
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source, Assign, Expr
    from ..visitor import NodeTransformer

    if1, if2, if3, if4, if5, if6 = ifs = [
        Expr(Assign(targets=[t], value=t)) for t in range(6)
    ]
    yf1, yf2, yf3, yf4, yf5, yf6 = yfs = [
        Expr(Assign(targets=[t], value=t)) for t in range(6)
    ]


# Generated at 2022-06-23 23:22:57.899152
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..parser import parse
    t = YieldFromTransformer()

    # Handle assignment
    code = "a, b = 'a', yield from generator"
    tree = parse(code)
    tree = t.visit(tree)
    assert str(tree) == '''a, b = 'a', None
iterable = iter(generator)
while True:
    try:
        next(iterable)
    except StopIteration as exc:
        b = exc.value
        break'''

    # Handle expression
    code = "print(yield from generator)"
    tree = parse(code)
    tree = t.visit(tree)

# Generated at 2022-06-23 23:23:02.302129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  from .traversal import TraversalTransformer
  from .module import ModuleTransformer
  from .functiondef import FunctionDefTransformer

# Generated at 2022-06-23 23:23:07.564200
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import List, Callable
    from ..utils.helpers import str_ast
    from ..utils.source import Source
    from ..utils.tree import strip_lineno

    source = Source(YieldFromTransformer, globals())
    code = """
    def func(a):
        i = yield from coro()
        i += yield from coro()
    """
    node = ast.parse(code)


# Generated at 2022-06-23 23:23:13.744913
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exec('''if True:
        from typing import Iterator

        def some_func(x: int) -> Iterator[int]:
            yield from gen()
    ''')

    module = ast.parse('''if True:
        from typing import Iterator

        def some_func(x: int) -> Iterator[int]:
            yield from gen(x)
    ''')

    YieldFromTransformer().visit(module)
    assert module

# Generated at 2022-06-23 23:23:22.033166
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_ast, strip_lines
    from ..utils.target import target_to_source

    ast_node = source_to_ast("""
    def test():
        yield from foo
    """)
    expected = strip_lines("""
    def test():
        let(exc_)
        let(iter_)
        iter_ = iter(foo)
        while True:
            try:
                yield next(iter_)
            except StopIteration as exc_:
                if hasattr(exc_, 'value'):
                    None
                break
    """)
    transformer = YieldFromTransformer()
    result = transformer.visit(ast_node)
    assert target_to_source(result) == expected

# Generated at 2022-06-23 23:23:29.346208
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:23:32.233156
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Unit test for method visit of class YieldFromTransformer
    node_ = ast.Try()
    node = YieldFromTransformer().visit(node_)
    assert node is node_

# Generated at 2022-06-23 23:23:33.999559
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test = YieldFromTransformer()
    assert test


# Generated at 2022-06-23 23:23:34.495947
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:23:42.648253
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""
    def f(i):
        while True:
            if i > 0:
                i = yield from gen(i)
            else:
                break
    """)
    YieldFromTransformer().visit(tree)

    tree_result = ast.parse("""
    def f(i):
        while True:
            if i > 0:
                let(exc)
                let(iterable)
                while True:
                    iterable = iter(gen(i))
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            if hasattr(exc, 'value'):
                                i = exc.value
                            break
                    break
            else:
                break
    """)

    assert ast.dump(tree) == ast.dump

# Generated at 2022-06-23 23:23:48.442384
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():  # type: ignore
    import astor  # type: ignore
    # should transform

# Generated at 2022-06-23 23:23:49.525254
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:23:51.087826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """ Testing __init__ method of YieldFromTransformer """

    YieldFromTransformer()

# Generated at 2022-06-23 23:24:01.382441
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import make_fixture, run_test

    src = """
    test_list = ['item1', 'item2', 'item3']
    yielded = ''.join(test_list)
    """

    expected = """
    test_list = ['item1', 'item2', 'item3']
    yielded = ''
    let(iterable)
    iterable = iter(test_list)
    while True:
        try:
            yielded += next(iterable)
        except StopIteration as exc:
            break
    """

    with make_fixture(src) as (path, _):
        run_test(path, YieldFromTransformer, expected)


# Generated at 2022-06-23 23:24:08.831096
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    func = ast.FunctionDef(
        name='foo',
        body=[
            ast.Expr(value=ast.YieldFrom(value=ast.Name(id='x', ctx=ast.Load()))),
            ast.Expr(value=ast.YieldFrom(value=ast.Name(id='y', ctx=ast.Load()))),
            ast.Return(value=ast.Name(id='x', ctx=ast.Load()))
        ],
        args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    )

    tree = ast.Module(body=[func])


# Generated at 2022-06-23 23:24:12.339714
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import transformation_test

    def test_function(module):
        t = YieldFromTransformer()
        t.visit(module)
        return module

    transformation_test(test_function, 'def foo():yield from []')

# Generated at 2022-06-23 23:24:23.195035
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.fake_ast import FakeAst
    from .base import BaseTreeTransformerTestCase

    class YieldFromTransformerTest(BaseTreeTransformerTestCase):
        transformer = YieldFromTransformer


# Generated at 2022-06-23 23:24:24.612383
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:25.547230
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer())

# Generated at 2022-06-23 23:24:35.745785
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_ast_transformer
    assert_ast_transformer(YieldFromTransformer, """
        x = 1
        yield from 1
    """, """
        x = 1
        let(iterable)
        iterable = iter(1)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc_1:
                if hasattr(exc_1, 'value'):
                    x = exc_1.value
                break
    """)

# Generated at 2022-06-23 23:24:44.701239
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    method_source = "def test(test=1):\n\tb = yield from c"
    method_ast = ast.parse(method_source)
    YieldFromTransformer(method_ast).visit(method_ast)

# Generated at 2022-06-23 23:24:54.911895
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse

    def transform(module: str) -> str:
        module = ast.parse(module)
        YieldFromTransformer().visit(module)
        return astunparse.unparse(module)

    assert transform('''while True:
        y = yield from generator
    ''') == '''while True:
        let(iterable)
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    y = exc.value
                break
    '''


# Generated at 2022-06-23 23:24:59.414739
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_utils import get_test_cases
    from ..utils.validate import validate

    for source, expected in get_test_cases('test_YieldFromTransformer_visit'):
        tree = ast.parse(source)
        transformer = YieldFromTransformer()
        tree = transformer.visit(tree)
        result = validate(expected, tree)
        print(result)

# Generated at 2022-06-23 23:25:05.961498
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast
    from ..utils.helpers import VariablesGenerator

    def _emulate_yield_from(target, node):
        if hasattr(node, 'value'):
            target = node.value

    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value

    def yield_from(generator, assignment, exc):
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                result_assignment(exc, target)
                break

    def test_YieldFromTransformer_visit_in_class():
        class A(object):
            def __init__(self, arg1):
                self.var1 = arg1

# Generated at 2022-06-23 23:25:10.707085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Dummy(ast.AST):
        pass

    try_ = Dummy()
    try_.body = [Dummy(), Dummy()]

    class MockTree(ast.AST):
        body = [try_]

    mock_tree = MockTree()
    YieldFromTransformer().visit(mock_tree)

    assert {type(node) for node in mock_tree.body} == {ast.Try}
    assert {type(node) for node in mock_tree.body[0].body} == {ast.Expr}



# Generated at 2022-06-23 23:25:13.212581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3 as ast
    except ImportError as e:
        pytest.skip(e)
    x = YieldFromTransformer()
    assert x

# Generated at 2022-06-23 23:25:16.627667
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.ast_helper import compile_code

    node = compile_code('def foo():\n'
                        '    a = yield from bar()\n')
    visitor = YieldFromTransformer()
    visitor.visit(node)
    assert visitor.tree_changed()



# Generated at 2022-06-23 23:25:18.277318
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)



# Generated at 2022-06-23 23:25:29.491965
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""yield from [1, 2, 3]""")
    result = ast.dump(YieldFromTransformer().visit(tree))
    assert result == 'Module(body=[Expr(value=Yield(value=List(elts=[Num(n=1), Num(n=2), Num(n=3)], ctx=Load()))), Assign(targets=[Name(id=exc, ctx=Store())], value=Call(func=Name(id=StopIteration, ctx=Load()), args=[], keywords=[]))])'
    tree = ast.parse('x = yield from range(3)')
    result = ast.dump(YieldFromTransformer().visit(tree))

# Generated at 2022-06-23 23:25:30.752267
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def sample():
        yield from range(3)

# Generated at 2022-06-23 23:25:35.470584
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_support import run_test_visit

    source = """
    import typing as t

    class Yielder:
        def __iter__(self) -> t.Iterator:
            yield 5

        def yield_from(self) -> t.Iterator[int]:
            yield from self

    def f():
        yield from Yielder(), Yielder(), Yielder()
    """

# Generated at 2022-06-23 23:25:46.446744
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import test_helpers as helpers
    from ..test_helpers import assert_equal
    import typed_astunparse
    import ast

    source = """
    def generator():
        yield 'one'
        yield 'two'
        return 'three'

    def func():
        a = yield from generator()
        b = 'hello'
        yield from generator()
        c = 'bye'
        yield from generator()
    """

# Generated at 2022-06-23 23:25:53.211499
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from typed_ast.transforms.YieldFromTransformer import YieldFromTransformer
    code = 'def f():\n  return y'
    tree = ast.parse(code)
    tree = YieldFromTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[FunctionDef(args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Return(value=y)], decorator_list=[], name='f', return_type=None)])"



# Generated at 2022-06-23 23:26:04.155311
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test with one "yield from" expression
    code = "def foo():\n\treturn yield from it"
    tree = ast.parse(code)

    YieldFromTransformer().visit(tree)
    assert tree.body[0].body[0].value.values.body == ["iterable = iter(it)",
                                                      "while True:",
                                                      "\ttry:",
                                                      "\t\tyield next(iterable)",
                                                      "\texcept StopIteration as exc:",
                                                      "\t\treturn exc.value",
                                                      "\t\tbreak"]
    # test with yield from in variable assignment
    code = "def foo():\n\texc = yield from it"
    tree = ast.parse(code)

    YieldFromTransformer().visit(tree)


# Generated at 2022-06-23 23:26:09.456874
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_ast as sta
    from .. import compile_to_pyc
    from textwrap import dedent

    src = dedent('''\
    def foo():
        yield from bar()
    ''')
    compiled = compile_to_pyc(src)
    tree = sta(src)
    YieldFromTransformer().visit(tree)
    assert compile_to_pyc(tree) == compiled

# Generated at 2022-06-23 23:26:15.386315
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.helpers import load_from_snippets
    from ..utils.tree import dump_ast

    my_ast = load_from_snippets(['yield_from'], ast_type=ast.Try)
    print(dump_ast(my_ast))

    visitor = YieldFromTransformer()
    visitor.visit(my_ast)
    print(dump_ast(my_ast))

# Generated at 2022-06-23 23:26:16.513799
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()


# Generated at 2022-06-23 23:26:17.912335
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-23 23:26:20.733602
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert ast.parse('yield from value') == YieldFromTransformer().visit(ast.parse('yield from value'))



# Generated at 2022-06-23 23:26:21.691164
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:26:22.617270
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:26:25.710285
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Tests that yield_from gets transformed right
    tree = ast.parse('yield from [1, 2, 3]')
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-23 23:26:30.825220
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import dumps_ast

    module = ast.parse('''
    from collections import Generator
    def generator(): yield from Generator()
    def result(x): y = x
    ''')


# Generated at 2022-06-23 23:26:40.289109
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import Module, FunctionDef, Assign, Name, Load, Attribute, YieldFrom, arguments, Return, Call, Pass
    from typed_astunparse import dump


# Generated at 2022-06-23 23:26:42.362979
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    from python_ta.transforms.YieldFromTransformer import YieldFromTransformer

# Generated at 2022-06-23 23:26:43.985399
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:26:44.932640
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:26:47.666029
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import Expr, FunctionDef, Expr, Name, Load, YieldFrom, Assign, arguments
    from ..utils.helpers import get_ast


# Generated at 2022-06-23 23:26:49.092422
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer()) == YieldFromTransformer



# Generated at 2022-06-23 23:26:55.203574
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys

    try:
        from typed_ast import ast3 as ast
    except ImportError:
        # Python < 3.6
        from typed_ast import ast27 as ast

    from compile_type import CompileType
    from type_transformer import TypeTransformer
    from yield_from_transformer import YieldFromTransformer
    from not_implemented_transformer import NotImplementedTransformer


# Generated at 2022-06-23 23:27:02.803035
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_astunparse import unparse
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = YieldFromTransformer

        def test_if(self):
            a = """
if a:
    yield from b
else:
    c
            """
            b = """
if a:
    for _ in (b):
        yield next(_)
    exc = StopIteration()
    if hasattr(exc, 'value'):
        b = exc.value
else:
    c
            """
            self.assertChange(a, b)

        def test_for(self):
            a = """
for i in a:
    yield from i
            """

# Generated at 2022-06-23 23:27:03.768535
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:04.776484
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer()

# Generated at 2022-06-23 23:27:06.045017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Create object 
    YieldFromTransformer()

# Generated at 2022-06-23 23:27:13.661842
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def code():
        def f():
            yield from range(10)

    ast_tree = ast.parse(code)
    node = ast_tree.body[0].body[0].body[0]
    assert isinstance(node, ast.YieldFrom)

    transformer = YieldFromTransformer()
    transformer.visit(ast_tree)

    assert isinstance(ast_tree.body[0].body[0].body[0], ast.While)
    assert not isinstance(ast_tree.body[0].body[0].body[0], ast.YieldFrom)



# Generated at 2022-06-23 23:27:17.511636
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('def func():\n'
                     '    return lambda x: x + 5')
    tree = YieldFromTransformer().visit(tree)
    assert 'yield from' not in ast.dump(tree)

# Generated at 2022-06-23 23:27:29.157081
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse('yield from range(10)')
    tr = YieldFromTransformer()
    tr.visit(node)
    # TODO: need to fix it

# Generated at 2022-06-23 23:27:33.119010
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test.test_node_transformer import test_transformer
    test_transformer(YieldFromTransformer,
                     'yield_from.py',
                     ((3, 3), (3, 4), (3, 5)))

# Generated at 2022-06-23 23:27:38.896696
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    trans = YieldFromTransformer()
    tree = ast.parse('a = yield from (x for x in range(10))')
    tree = trans.visit(tree)
    assert b'a = exc.value' in compile(tree, filename='', mode='exec').co_code
    assert b'generator = iter(x for x in range(10))' in compile(tree, filename='', mode='exec').co_code

# Generated at 2022-06-23 23:27:40.275559
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import get_ast


# Generated at 2022-06-23 23:27:42.762495
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..utils.helpers import build_ast
    from ..main import Patcher


# Generated at 2022-06-23 23:27:44.976780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # YieldFromTransformer().visit(None)
    pass

if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:27:46.018393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer("t")

# Generated at 2022-06-23 23:27:48.044441
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import transformers

    transformer = transformers.get(__name__)()
    assert transformer is not None

# Generated at 2022-06-23 23:27:55.654399
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse as parse_ast
    from .test_ast_utils import assert_ast_equal
    assert_ast_equal(YieldFromTransformer().visit(parse_ast('f()')),
                     parse_ast('f()'))

    assert_ast_equal(YieldFromTransformer().visit(parse_ast('x = yield from 5')),
                     parse_ast('''
                        iterable = iter(5)
                        while True:
                            try:
                                yield next(iterable)
                            except StopIteration as exc:
                                x = exc.value
                                break
                     '''))

# Generated at 2022-06-23 23:27:58.101238
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    # Success
    assert type(YieldFromTransformer(tree = None)) == YieldFromTransformer


# Generated at 2022-06-23 23:28:00.427693
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Testing constructor of class YieldFromTransformer')
    yft = YieldFromTransformer(None)
    assert yft is not None


# Generated at 2022-06-23 23:28:03.702953
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__qualname__ == 'YieldFromTransformer'


# Generated at 2022-06-23 23:28:06.062151
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.copy_location(ast.parse('yield from iterable'), ast.parse('yield from iterable'))
    assert(isinstance(node, ast.AST))

# Generated at 2022-06-23 23:28:10.442441
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def func():
        yield from (1, 2, 3)
        a = yield from [1, 2, 3]

    expected = '''def func():
    iterable = iter((1, 2, 3))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                exc = exc.value
            break
    let(iterable)
    let(a)
    iterable = iter([1, 2, 3])
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                a = exc.value
            break
'''
    assert YieldFromTransformer().transform_func(func) == expected


# Generated at 2022-06-23 23:28:17.071986
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...testing import assert_program
    code = """
        def foo():
            a = yield from bar()
        def bar():
            yield 'something'
    """
    assert_program(code, code, '''
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        a = exc.value
                    break
        def bar():
            yield 'something'
    ''')



# Generated at 2022-06-23 23:28:27.054924
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.unparse import Unparser
    import typing
    import astor
    from ..compiler import compile_string

    # class X(object):
    #     def __init__(self):
    #         self.a = 1
    #         self.b = 2
    #         self.c = 3
    #
    #     def test(self):
    #         yield from self.gen_data()
    #
    #     def gen_data(self):
    #         yield from self.gen_values()
    #
    #     def gen_values(self):
    #         yield self.a
    #         yield self.b
    #         yield self.c
    #
    # def main() -> None:
    #     x = X()
    #     y = []
    #
    #     for item

# Generated at 2022-06-23 23:28:34.879526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    import textwrap

    src = textwrap.dedent('''
    async def t():
        async for i in range(10):
            await t1()
            a = await t2()
            p = await t3(a)

            await t4()
            c = a.b
    ''')

    node = ast.parse(src)
    YieldFromTransformer().visit(node)
    res = astunparse.unparse(node)

    assert res == textwrap.dedent('''
    async def t():
        async for i in range(10):
            await t1()
            a = await t2()
            p = await t3(a)

            await t4()
            c = a.b
    ''')

# Generated at 2022-06-23 23:28:35.825855
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  YieldFromTransformer()

# Generated at 2022-06-23 23:28:37.129606
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source


# Generated at 2022-06-23 23:28:38.771586
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass #TODO: Write unit test for constructor of class YieldFromTransformer


# Generated at 2022-06-23 23:28:47.933198
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from .utils import format_code
    from .example_visitor import ExampleVisitor
    source = """
        def foo():
            yield from bar()
    """
    expected = """
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """
    tree = compile(source, '<test>', 'exec', ast.PyCF_ONLY_AST)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    assert format_code(ast.unparse(tree)) == format_code(expected)

# Generated at 2022-06-23 23:28:56.167580
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from ..utils.helpers import fake_module

    code = """\
    def foo():
        print("This is a docstring")
        yield from bar()
    """
    expected = """\
    def foo():
        print("This is a docstring")
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """

    tree = fake_module(code)
    YieldFromTransformer.run_on_tree(tree)
    transformed = astunparse.unparse(tree)
    assert expected == transformed

# Generated at 2022-06-23 23:29:01.806909
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source

    source = '''
    while True:
        yield from [1,2,3]
    '''
    test_tree = ast.parse(source)

    res = YieldFromTransformer().visit(test_tree)
    res_source = to_source(res)
    assert 'yield from' not in res_source, 'No yield from left in result'

# Generated at 2022-06-23 23:29:03.209100
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()
    tree = ast.parse("""a = yield_from(1)""")
    transformer.visit(tree)

# Generated at 2022-06-23 23:29:14.266019
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    res = YieldFromTransformer().transform(
        ast.parse(dedent('''
        def foo(i):
            yield from range(i)
        ''')))


# Generated at 2022-06-23 23:29:22.233891
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from os import path
    from .test_generator import GeneratorTransformer

    this_path = path.dirname(path.abspath(__file__))
    code = path.join(this_path, 'test_data', 'yieldfrom.py')

    with open(code, 'rb') as file:
        tree = GeneratorTransformer().run(file.read())
        tree = YieldFromTransformer().run(tree)

    print(tree)


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:29:30.342130
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_tree_string
    from nuitka.optimizations.ConstantFolding import ConstantFolding
    from nuitka.optimizations.BuiltinOptimizations import BuiltinOptimizations
    from nuitka.tree.Extractions import ExpressionConversion
    from nuitka import Options
    import nuitka.tree.Building
    import nuitka.tree.Optimization
    import ast

    source = """def f():
        a = yield from g()
        yield from h()"""
    tree = source_to_ast(source)
    tree = ExpressionConversion(tree).visit(tree)
    tree = YieldFromTransformer(tree).visit(tree)
    tree = ConstantFolding(tree).visit(tree)
    tree

# Generated at 2022-06-23 23:29:31.488096
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:29:36.915351
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    from .helpers import validate_transformation
    from .test_YieldFromTransformer_visit import source_example_tree, expected_example_tree

    example_tree = parse(source_example_tree)
    expected_tree = parse(expected_example_tree)
    validate_transformation(YieldFromTransformer, example_tree, expected_tree)

# Generated at 2022-06-23 23:29:47.655974
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import patch
    from ..utils.helpers import fake_code

    root = fake_code(
        'def fake():',
        '    yield from foo()',
        '    yield from some',
        '    yield from foo()'
    )

# Generated at 2022-06-23 23:29:57.149979
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from .. import transformers  # type: ignore
    from .sympy_example import sympy_example  # type: ignore
    import copy
    import sympy

    t = transformers.YieldFromTransformer()
    a, b, c = sympy.symbols('a b c')
    nodes = t.transform_node(copy.deepcopy(sympy_example))
    # test method visit of class YieldFromTransformer
    h = nodes[0].body[1].body[0].body[1]
    assert isinstance(h, ast.Expr)
    assert isinstance(h.value, ast.Call)
    assert isinstance(h.value.func, ast.Name)
    assert h.value.func.id == 'yield_from'
    j

# Generated at 2022-06-23 23:30:07.014201
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_base import get_ast, CustomTestCase

    class Test(CustomTestCase):
        ref_module: str

        @property  # type: ignore
        @snippet
        def module(self) -> ast.Module:
            def func():
                let(exc)
                iterable = iter(generator)
                while True:
                    try:
                        yield next(iterable)
                    
                    except StopIteration as exc:
                        pass
                try:
                    yield from generator
                except StopIteration as exc:
                    pass
            func()

    t = Test(module=__name__)

# Generated at 2022-06-23 23:30:13.401996
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from test.utils import check_transformer
    check_transformer(YieldFromTransformer)

# Generated at 2022-06-23 23:30:17.629364
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('yield from [1,2,3]')
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    assert str(new_tree) == 'def __():\n    yield next(iter([]))\n'



# Generated at 2022-06-23 23:30:25.711953
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import textwrap
    from ..utils.helpers import get_transformed_ast

    source = """\
    def meth():
        a = yield from range(100)
        b = (yield from range(100))
        c = d = yield from range(100)
    """
    source = textwrap.dedent(source).strip()
    source = source.encode('UTF-8')


# Generated at 2022-06-23 23:30:29.667211
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    global  module
    module = ast.parse('from typing import List\ndef foo() -> List:\n    a = yield from [1,2,3]')
    YieldFromTransformer().visit(module)

test_YieldFromTransformer()

# Generated at 2022-06-23 23:30:30.924902
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None

# Generated at 2022-06-23 23:30:37.665272
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import setup_test_env
    setup_test_env()

    from types import ModuleType
    from typed_ast import ast3 as ast

    code = '''
    def func():
        yield from [1][0]
    '''

    mod = YieldFromTransformer().visit(ast.parse(code))

    expected = '''
    def func():
        let(iterable)
        iterable = iter([1][0])
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    '''

    from .. import typed_astunparse
    expected_ast = ast.parse(expected)
    typed_astunparse.unparse(expected_ast) == typed_astunparse.unparse(mod)

# Generated at 2022-06-23 23:30:46.719871
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
# ```
# try:
#     x = yield from gen()
# except StopIteration as exc:
#     x = exc.value
# ```
# ```
# x = None
# while True:
#     try:
#         x = next(gen())
#     except StopIteration as exc:
#         x = exc.value
# ```
# ```
# try:
#     yield from gen()
# except StopIteration as exc:
#     pass
# ```
# ```
# iterable = iter(gen())
# while True:
#     try:
#         yield next(iterable)
#     except StopIteration as exc:
#         break
# ```

# Generated at 2022-06-23 23:30:55.265596
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils.helpers import as_tuple

    lines = dedent("""
            def test():
                res1 = yield from 'a'
                res2 = yield from 'b'
                yield from 'c'
                return res1, res2
            """).strip().split('\n')


# Generated at 2022-06-23 23:31:03.804354
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    source = """
    async def coro():
        yield from 'abc'
        a = yield from 'abc'
        (yield from 'abc')
        a = (yield from 'abc')"""