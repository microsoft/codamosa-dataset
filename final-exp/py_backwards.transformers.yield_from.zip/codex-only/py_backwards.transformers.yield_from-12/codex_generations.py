

# Generated at 2022-06-23 23:21:10.639844
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import normalize_results
    from .transform import TransformResults

    for input_src, expected in normalize_results(expected_results_YieldFromTransformer_visit):
        module = ast.parse(input_src, parser='typed_ast')
        module = YieldFromTransformer().visit(module)
        assert expected == TransformResults().visit(module)

# Generated at 2022-06-23 23:21:11.627054
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = YieldFromTransformer()
    assert node is not None

# Generated at 2022-06-23 23:21:12.483029
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:13.684991
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj != None

# Generated at 2022-06-23 23:21:20.260674
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import unparse
    from astsame import same
    from astunparse import unparse as astunparse
    from ..utils.test_utils import kwargs
    original_source = """
    def foo():
        yield from range(10)
    """
    expected_source = """
    def foo():
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    expected_node = ast.parse(expected_source)
    original_node = ast.parse(original_source)
    node = YieldFromTransformer().visit(original_node)
    assert same(node, expected_node)

# Generated at 2022-06-23 23:21:29.693671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import make_named_tuple
    test_node = ast.ExceptHandler(type=None, name=None, body=None)
    test_node2 = ast.ExceptHandler(type=None, name=None, body=None)
    test_list = [test_node, test_node2]
    test_arguments = ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    test_node3 = ast.FunctionDef(name='test', args=test_arguments, body=test_list, decorator_list=[], returns=None)
    test_node4 = ast.NameConstant(value=None)

# Generated at 2022-06-23 23:21:38.748370
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    src, _ = parse_string("""
    def gen():
        yield from a
        yield from b
    gen()
    """, __name__)

    assert len(src.body) == 2
    function, _ = src.body
    assert len(function.body) == 3

    assert function.body[0].targets[0].id == 'iterable'
    assert isinstance(function.body[0].value, ast.Call)
    assert isinstance(function.body[0].value.func, ast.Name)
    assert function.body[0].value.func.id == 'iter'
    assert function.body[0].value.args[0].id == 'a'

    assert function.body[1].test.value.id == 'iterable'

# Generated at 2022-06-23 23:21:47.651558
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def check_with_assert(input_code, expected_code):
        """Tests method YieldFromTransformer.visit with assert."""
        class TestTransformer(YieldFromTransformer):
            def __init__(self):
                super().__init__()
                self.test_field = None

            def _assert_no_changes(self, root_node, old_root_node):
                if self.test_field is None:
                    self.test_field = root_node
                    return False
                elif old_root_node is not None and self.test_field == root_node:
                    assert self.test_field == old_root_node
                    return False
                else:
                    return True

        ast_tree = ast.parse(input_code)
        tree_transformer = TestTransformer()
        ast_

# Generated at 2022-06-23 23:21:49.393692
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import Any
    from ..tests.utils import assert_code


# Generated at 2022-06-23 23:21:53.986288
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    import astunparse
    source = textwrap.dedent("""
        def f():
            a = yield from b
            yield from c
            d = yield from e
            yield from f()
    """)
    tree = ast.parse(source)
    transformer = YieldFromTransformer(tree)
    new_tree = transformer.visit(tree)
    print(astunparse.unparse(new_tree))

# Generated at 2022-06-23 23:21:55.261544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None


# Generated at 2022-06-23 23:21:59.657284
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .helper_transformer import FunctionDefHelpers
    assert isinstance(YieldFromTransformer().visit(ast.parse('x', mode='eval')), ast.Expression)
    assert isinstance(YieldFromTransformer().visit(ast.parse('1', mode='eval')), ast.Expression)

# Generated at 2022-06-23 23:22:00.701697
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)

# Generated at 2022-06-23 23:22:11.086599
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from .unpacking import UnpackingTransformer
    from .compat import CompatTransformer

# Generated at 2022-06-23 23:22:12.105013
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer


# Generated at 2022-06-23 23:22:17.877842
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''Unit test for constructor of class YieldFromTransformer'''
    trans = YieldFromTransformer()
        # Unit test for method _get_yield_from_index of class YieldFromTransformer
        # Unit test for method _emulate_yield_from of class YieldFromTransformer
        # Unit test for method _handle_assignments of class YieldFromTransformer
        # Unit test for method _handle_expressions of class YieldFromTransformer
        # Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:19.788886
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from tests.test_transformers.tools import check_on_single_node
    from ..main import TransformationsApplier

    YieldFromTransformer.register()

# Generated at 2022-06-23 23:22:26.256462
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .transformer import Transformer
    from .unpacking import UnpackingTransformer
    from .decorators import DecoratorsTransformer
    from .lists import ListsTransformer
    from ..oset import OrderedSet
    # TODO: This needs a better way of generating the scope
    scope = {
        'Expr': ast.AST,
        'YieldFrom': ast.AST,
        'Assign': ast.AST,
        'Attribute': ast.AST,
        'FunctionDef': ast.AST,
        'Module': ast.AST,
    }

    def call_transformer(transformer, scope, string):
        scope, module, ast_nodes = Transformer.node_factory(
                string, scope=scope)
        ast_nodes = OrderedSet(ast_nodes)

# Generated at 2022-06-23 23:22:30.117926
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...textx import metamodel_from_str
    import textwrap
    mm = metamodel_from_str(r"""
        Name: /[a-zA-Z_][a-zA-Z_0-9]*/;
        Number: /0|[1-9][0-9]*/;

        Function: "def" Name "(" ")" ":"
            "try:" ("pass" | "yield" Number)?
            "except Exception" ":" "pass"
            "return" ("None"|(Number "," Number));

        Program[0]: Function*;
        """, ignore_case=False, debug=False,
        rule_name_split_char='[0-9]')

# Generated at 2022-06-23 23:22:31.535690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert(yield_from_transformer is not None)

# Generated at 2022-06-23 23:22:35.493032
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast

    class A(ast.AST):
        def __init__(self):
            self.a = None

    example = A()
    example.a = "Test"
    transformer = YieldFromTransformer()

    result = transformer.visit(example)
    assert result.a == "Test"

# Generated at 2022-06-23 23:22:36.339839
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer([], [])

# Generated at 2022-06-23 23:22:42.405385
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap

    test_code = """
    def start(data):
        for d in data:
            yield from d
    """
    tree = ast.parse(test_code)
    result = YieldFromTransformer().visit(tree)
    assert astor.to_source(result) == textwrap.dedent("""
    def start(data):
        while True:
            try:
                yield next(data)
            except StopIteration as exc_1:
                break
    """)

# Generated at 2022-06-23 23:22:43.575179
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:22:52.215547
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.helpers import ast_from_code, ast_to_code

    class_def = ast_from_code(textwrap.dedent("""
        class Foo:
            def bar(self):
                baz = yield from [1, 2, 3]
                waz = yield from dict(a=5, b=6)
    """), mode='exec')
    transformer = YieldFromTransformer()
    class_def = transformer.visit(class_def)


# Generated at 2022-06-23 23:22:59.168380
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    module = ast.parse("def f():\n"
                       "    for i in range(5):\n"
                       "        yield from (x for x in range(5))")
    transformer.visit(module)
    assert ast.dump(module) == transform_tree


# Generated at 2022-06-23 23:23:07.564481
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast
    tree1 = ast.parse("""
    def a():
        yield from b
    """)
    tree2 = ast.parse("""
    def l(b):
        yield from b
    """)
    tree3 = ast.parse("""
    def k():
        a = 1
        yield from b
    """)
    tree4 = ast.parse("""
    def i():
        yield from b
        yield from c
    """)

    YieldFromTransformer().visit(tree1)
    YieldFromTransformer().visit(tree2)
    YieldFromTransformer().visit(tree3)
    YieldFromTransformer().visit(tree4)


# Generated at 2022-06-23 23:23:17.628565
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast

    result_assignment_ast = ast.parse(result_assignment.as_string()).body[0]
    yield_from_ast = ast.parse(yield_from.as_string()).body[0]

# Generated at 2022-06-23 23:23:22.708763
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import FunctionDef, Load, Name, Try

    function_def = FunctionDef(
        name='n',
        args=None,
        decorator_list=[],
        body=[
            Try(
                body=[
                    Name(id='a', ctx=Load())
                ],
                handlers=[],
                orelse=[]
            )
        ]
    )
    print(function_def)

# Generated at 2022-06-23 23:23:24.008440
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""
    from .. import compile
    from ..context import Context
    from .init import InitTransformer


# Generated at 2022-06-23 23:23:24.902180
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:23:25.380629
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert 1

# Generated at 2022-06-23 23:23:35.411851
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tester import make_tests


# Generated at 2022-06-23 23:23:43.167675
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tests.test_preprocessors import assert_program
    from ..utils.source import source

    assert_program(
        YieldFromTransformer,
        source("""
        yield from some_generator
        """),
        source("""
        exc = None
        iterable = iter(some_generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
        """)
    )


# Generated at 2022-06-23 23:23:55.018686
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import textwrap
    from typed_ast import ast3 as ast, ast3_typed

    class Test(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.maxDiff = None

        def test(self, expect, *, code):
            parse = ast3_typed.parse
            ast_tree = parse(textwrap.dedent(code))
            transformer = YieldFromTransformer()
            transformed = ast.dump(ast_tree, include_attributes=True)
            expect = textwrap.dedent(expect)
            self.assertEqual(transformed, expect)

    t = Test()


# Generated at 2022-06-23 23:23:56.133533
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-23 23:24:06.328161
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    class TestCases(unittest.TestCase):
        def assertAST(self, original_code: str, expected_code: str) -> None:
            expected_node = compile(expected_code, '<string>', 'exec', ast.PyCF_ONLY_AST)
            node = compile(original_code, '<string>', 'exec', ast.PyCF_ONLY_AST)
            transformer = YieldFromTransformer()
            node = transformer.visit(node)
            self.assertEqual(ast.dump(node), ast.dump(expected_node))

        def test_simple_yield_from(self) -> None:
            original_code = '''
x = yield from (1, 2, 3)
            '''

# Generated at 2022-06-23 23:24:12.127997
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    global test_YieldFromTransformer
    print(test_YieldFromTransformer.__doc__)

    class TestYieldFromTransformer(YieldFromTransformer):
        pass

    source = """
        async def async_func():
            from_iterable(async_gen())
            yield from async_gen()
    """
    expected = """
        async def async_func():
            from_iterable(async_gen())
            let(iterable)
            iterable = iter(async_gen())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        None = exc.value
                    break
    """
    ast_tree = ast.parse(source)

# Generated at 2022-06-23 23:24:13.673933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft is not None

# Generated at 2022-06-23 23:24:14.464740
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:25.060167
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from mypy.build import parse

    # Input code
    code = '''
    def func():
        a = yield from b
    '''
    node = parse(code)

    # Run transformer
    transformer = YieldFromTransformer()
    node = transformer.visit(node)

    # Expected transformed code
    expected = '''
    def func():
        let(exc)
        let(iterable)
        iterable = iter(b)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    '''
    assert node != 0, "Transformer not visited node"
    assert transformer.tree_changed()
    assert node == parse(expected)


# Generated at 2022-06-23 23:24:30.253629
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..example import yield_from1, yield_from2
    from ast import parse
    from ..utils.helpers import get_ast
    from astunparse import dump
    from unittest.mock import Mock

    tests = [
        (yield_from1.source(), yield_from1.expected()),
        (yield_from2.source(), yield_from2.expected()),
    ]
    for test, expected in tests:
        tree = parse(test)
        node = YieldFromTransformer().visit(tree)
        assert expected == dump(node)

# Generated at 2022-06-23 23:24:40.040693
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing.utils import build_visitor_test_case
    from ..converter import StandardConverter
    from ..converter.helpers import standard_convert

    builder = build_visitor_test_case(StandardConverter.module_level_annotations +
                                      [YieldFromTransformer])
    builder.test_equal(
        input="""x = yield from y""",
        expected="""let(iterable, target_0)
iterable = iter(y)
while True:
    try:
        x = next(iterable)
    except StopIteration as exc_0:
        break""",
        locals={'y': list(range(0, 10))})

# Generated at 2022-06-23 23:24:42.067873
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.alan import to_source
    from ..utils.test_utils import assert_equal_sources

# Generated at 2022-06-23 23:24:45.243515
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transpile import transpile
    from ..testing import FileBasedTesting

    with FileBasedTesting('yield_from.py') as testing:
        testing.run_snapshot_analysis(transpile, 'yield_from.py')

# Generated at 2022-06-23 23:24:50.708146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class MyClass:
        """This is a class docstring."""
        ...

    my_obj = MyClass()
    my_obj.transformer = YieldFromTransformer()
    assert my_obj.transformer.__class__.__name__ == "YieldFromTransformer"
    assert my_obj.transformer.__doc__ == "Compiles yield from to special while statement."
    assert inspect.isclass(MyClass)



# Generated at 2022-06-23 23:24:52.080564
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t


# Generated at 2022-06-23 23:25:01.395464
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import GeneratorBasedTransformerTestCase, assert_ast_same
    from ..utils.testing import TEST_CASES_TRANSFORMERS


# Generated at 2022-06-23 23:25:03.646238
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..main import to_source
    assert to_source(YieldFromTransformer()) == __file__

# Generated at 2022-06-23 23:25:08.291025
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys

# Generated at 2022-06-23 23:25:09.515545
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import _ast

# Generated at 2022-06-23 23:25:10.778897
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:11.642610
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:25:19.096756
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('def a():\n\t1\n\tb = yield from [1, 2]\n\t2')
    tr = YieldFromTransformer()
    tree = tr.visit(tree)

# Generated at 2022-06-23 23:25:20.206902
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-23 23:25:23.597285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Tests __init__()
    assert YieldFromTransformer(3, 2) is not None

# Unit tests for get_yield_from_index()

# Generated at 2022-06-23 23:25:32.736802
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor, os, sys
    from io import StringIO
    output = StringIO()
    sys.stderr = output
    _dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, _dir + '/../')
    from test.generators.type_test_generator import TypeTestGenerator
    from transformers.type_check import TypeCheck
    from transformers.yield_from import YieldFromTransformer

    @snippet
    def test():
        yield from [1, 2, 3]

    code = test.getsource()
    print(code)
    tree = astor.parse_file("test/samples/gen_1.py")
    TypeTestGenerator.insert_class_decorator = True

# Generated at 2022-06-23 23:25:44.233300
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap

    src = textwrap.dedent("""
        def first(x):
            yield x
            yield x

        def second(x):
            yield from first(x)
            yield x

        y = second(10)
    """)

    ref = textwrap.dedent("""
        def first(x):
            yield x
            yield x

        def second(x):
            let(iterable)
            iterable = iter(first(x))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
            yield x

        y = second(10)
    """)

    tree = ast.parse(src)

# Generated at 2022-06-23 23:25:48.829201
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_nodes
    from .. import run_transformer
    from ..utils.helpers import dump

    class Collector(ast.NodeVisitor):
        def __init__(self):
            self.names: List[str] = []

        def visit_Name(self, node: ast.Name) -> None:
            self.names.append(node.id)


# Generated at 2022-06-23 23:25:57.859502
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from nope.transformers import YieldFromTransformer
    from nope.transformers.base import BaseNodeTransformer
    from nope.transformers.base import NodeTransformer
    from typed_ast.ast3 import FunctionDef, Expr, Name, Load, Attribute, Assign, \
        Str, Call
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert issubclass(YieldFromTransformer, NodeTransformer)
    assert isinstance(YieldFromTransformer.target, property)

    source = 'def f():\n yield from \'a\''
    node = ast.parse(source)
    assert isinstance(node, ast.Module)

    tt = YieldFromTransformer()
    result = tt.visit(node)


# Generated at 2022-06-23 23:26:08.444183
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .type_cheking import TypeCheckerSimulator
    from .try_except_transformer import TryExceptTransformer
    from .exceptions import ExceptionsTransformer
    from .iterators import IteratorsTransformer

    source = """
    a = -1
    def f1():
        b = yield from f2()

    def f2():
        yield 3
        yield 4
    """
    tree = ast.parse(source)
    TypeCheckerSimulator().visit(tree)
    TryExceptTransformer().visit(tree)
    ExceptionsTransformer().visit(tree)
    YieldFromTransformer().visit(tree)
    IteratorsTransformer().visit(tree)
    print(ast.dump(tree, annotate_fields=False))

# Generated at 2022-06-23 23:26:09.405857
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:26:10.276182
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:26:15.131970
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from compilertools.compilers.sympy import CompileOptimizedSympy
    from compilertools.compilers.codegen import ASTCodeGenerator
    import os
    import astor
    from types import GeneratorType
    import sympy as sp

    # given

# Generated at 2022-06-23 23:26:15.745095
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:26:24.072651
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def f():
        yield from g()
    """
    tree = ast.parse(code)
    t = YieldFromTransformer()
    t.visit(tree)

    expected_code = """
    def f():
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc_0:
                if hasattr(exc_0, 'value'):
                    exc_0 = exc_0.value
                break
    """
    expected_tree = ast.parse(expected_code)
    assert compare_ast(tree, expected_tree)

# Generated at 2022-06-23 23:26:32.364015
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Verifying YieldFromTransformer._handle_assignments method.
    simple_body = [
        ast.Assign(
            targets=[ast.Name('a', ast.Store())],
            value=ast.YieldFrom(ast.Num(1))
        ),
        ast.Expr(ast.Name('b'))
    ]

    result = YieldFromTransformer()._handle_assignments(ast.Module(body=simple_body))
    assert result.body == yield_from.get_body().body + [ast.Expr(ast.Name('b'))]


# Generated at 2022-06-23 23:26:32.976508
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-23 23:26:34.040889
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor, pprint

# Generated at 2022-06-23 23:26:40.845656
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import run_transformer_visitor_for_test, run_transformer_visitor_for_test_class, generate_parent_id

    class Test:
        def test_method(self):
            a = b = 1
            a = yield from 1
            yield from 2

    code = compile(inspect.getsource(Test.test_method), filename='<string>', mode='exec')
    expected_code = dedent('''
        def test_method(self):
            a = b = 1
            let(iterable)
            iterable = iter(1)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        a = exc.value
                    break
            yield from 2
        ''')
   

# Generated at 2022-06-23 23:26:50.522926
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from ..utils.tree import ast2tree
    from ..utils.helpers import get_ast

    ast_ = get_ast('''
        class A:
            attr = 2

        def func1():
            a = 4
            b = 5
            yield from A().attr  # a = 2
            yield from func2()
            yield from A.attr

        def func2():
            b = 3
            yield b
            yield a
            yield 5
    ''')

# Generated at 2022-06-23 23:26:51.124413
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:26:52.865015
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()
    print('Unit test for constructor of class YieldFromTransformer passed.')

# Generated at 2022-06-23 23:26:54.908820
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Coverage case
    assert repr(YieldFromTransformer)
    assert str(YieldFromTransformer)

# Generated at 2022-06-23 23:26:55.878196
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:02.513647
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from pprint import pprint
    from ..utils.ast_helpers import get_ast
    from .expression_unpacking import ExpressionUnpackingTransformer
    from .data_model import DataModelTransformer

    code = '''
while True:
    x = yield from gen()
'''
    ast_code = get_ast(code)

    pprint(ast_code)

    ast_code = ExpressionUnpackingTransformer().visit(ast_code)
    pprint(ast_code)

    ast_code = DataModelTransformer().visit(ast_code)
    pprint(ast_code)

    ast_code = YieldFromTransformer().visit(ast_code)
    pprint(ast_code)

# Generated at 2022-06-23 23:27:12.900102
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .mock_transformer import MockTransformer
    from ..utils.helpers import parse

    def transform(node, transformer=None):
        if transformer is None:
            transformer = MockTransformer()
        node = YieldFromTransformer(transformer).visit(node)
        return transformer.result, node

    result, node = transform(parse('''
        a = yield from [2]
    '''))
    assert result == '\n'
    assert node.body[0].targets[0].id == 'a'
    assert node.body[0].value.value.elts[0].n == 2

    result, node = transform(parse('''
        a = yield from [1]
        b = yield from [2]
    '''))
    assert result == '\n'

# Generated at 2022-06-23 23:27:22.910839
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap

    code = textwrap.dedent('''
    def foo(a):
        yield from a
    ''')
    expected = textwrap.dedent('''
    def foo(a):
        let(iterable)
        iterable = iter(a)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    None = exc.value
                break
    ''')
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    result = astunparse.unparse(tree)

    assert result == expected

# Generated at 2022-06-23 23:27:24.953027
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    obj._handle_assignments() == obj
    obj.visit() == obj

# Generated at 2022-06-23 23:27:36.819026
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.runner import run_local_tests
    from ..utils.nodes import from_code
    from ..utils.helpers import VariablesGenerator

    # Unit tests for method visit
    class Tester(YieldFromTransformer):
        def _get_yield_from_index(self, node, type_):
            return 0

    class AssignTester:
        def _test(self, node):
            yield_from_ast = Tester.emulate_yield_from(node.body[0].targets[0],  # type: ignore
                                                       node.body[0].value)  # type: ignore
            node.body.insert(0, yield_from_ast[0])

        def _test_insert(self, node):
            yield_from_ast = Tester.emulate_yield_

# Generated at 2022-06-23 23:27:37.708950
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:39.129673
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    print(__file__)

    import astunparse

# Generated at 2022-06-23 23:27:47.400880
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import tree_from_string
    string = """
    def func(i):
        yield from i
        """
    tree = tree_from_string(string)
    visitor = YieldFromTransformer()
    visitor.visit(tree)
    assert str(tree) == """
    def func(i):
        let(iterable)
        iterable = iter(i)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """

# Generated at 2022-06-23 23:27:56.972585
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:57.526320
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:28:00.215619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.Module([])
    assert isinstance(YieldFromTransformer(node), YieldFromTransformer)
    assert not isinstance(YieldFromTransformer(node), ast.Module)


# Generated at 2022-06-23 23:28:01.105547
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:28:02.350532
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
        assert YieldFromTransformer((3, 2)).target == (3, 2)

# Generated at 2022-06-23 23:28:03.579957
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)



# Generated at 2022-06-23 23:28:13.292928
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.codegen import codegen
    from .codegen import has_args, has_starargs, has_kwargs, get_yield_from_count, get_assignment_count

    @snippet
    def func(a, b, c, *args, **kwargs):
        let(y)
        y = yield from bar(a, b, c, *args, **kwargs)  # noqa: B009
        return y

    @snippet
    def func2(a, b, c, *args, **kwargs):
        let(y)
        y = bar(a, b, c, *args, **kwargs)  # noqa: B009
        return y


# Generated at 2022-06-23 23:28:22.677179
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.snippet import snippet, let, extend
    yield_from_transformer = YieldFromTransformer()
    test_variables = VariablesGenerator(['yield_from_transformer'])
    yield_from_transformer_var0 = test_variables.add_variable('yield_from_transformer')
    tree_0 = ast.parse("""def name_0():
    i = yield_from_transformer_var0
""")
    tree_1 = ast.parse("""def name_0():
    yield_from_transformer_var0
""")

# Generated at 2022-06-23 23:28:30.855484
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
  from typed_ast.ast3 import YieldFrom, Str, Tuple, Load, Name, Store, Bytes, Expr, Assign, FunctionDef, Module
  from tests.fixtures.transformer import test_transformer
  from typed_astunparse import unparse
  test_transformer(
    "def foo():\n  yield from b'aaa'",
    "def foo():\n  let(iterable)\n  iterable = iter(b'aaa')\n  while True:\n    try:\n      yield next(iterable)\n    except StopIteration as exc:\n      exc = exc.value",
    YieldFromTransformer,
    )

# Generated at 2022-06-23 23:28:32.377529
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:28:41.992188
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from typed_ast.transforms import YieldFromTransformer

    def test(body, expected_result):
        module = ast.Module(body=body)
        transformer = YieldFromTransformer()
        transformed = transformer.visit(module)
        assert transformed.body == expected_result

    def test_assign_0():
        body = [ast.Assign([ast.Name(id='x', ctx=ast.Store())],
                           ast.YieldFrom(value=ast.Name(id='x', ctx=ast.Load())))]

# Generated at 2022-06-23 23:28:44.193325
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = VariablesGenerator.generate('module')
    body = VariablesGenerator.generate('body')


# Generated at 2022-06-23 23:28:45.918547
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')
    assert hasattr(YieldFromTransformer, 'visit')

# Generated at 2022-06-23 23:28:53.971811
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import test_utils
    from .compile import to_source

    # expressions
    assert_equal(to_source(test_utils.get_ast('''
        def fun():
            1 + yield from a
            2 + yield from b
        ''')), '''
        def fun():
            iterable = iter(a)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        ''')

# Generated at 2022-06-23 23:28:57.501776
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    _YieldFromTransformer_visit.run_test(
        'test_data/test_YieldFromTransformer_visit.py')


if __name__ == '__main__':
    from unittest import main
    main()

# Generated at 2022-06-23 23:29:03.442916
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import roundtrip
    src = '''
        def foo(arg):
            yield from bar(arg)
    '''
    # Expected result
    expected_result = '''
        def foo(arg):
            iterable = iter(bar(arg))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    '''
    result = roundtrip(src, YieldFromTransformer)
    assert result == expected_result


# Generated at 2022-06-23 23:29:14.261023
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    import sys
    import ast
    import safeeval
    import safeeval.typedast_compat
    import safeeval.ast_transforms

    # strip python bytecode
    bytecode_modules = list(sys.modules)
    for bytecode_module in bytecode_modules:
        if bytecode_module.startswith('<frozen') or \
                bytecode_module.startswith('__pycache__'):
            del sys.modules[bytecode_module]
    names = list(sys.modules['safeeval'].__dict__)
    for name in names:
        if name.startswith('__pycache__'):
            delattr(safeeval, name)

    # test

# Generated at 2022-06-23 23:29:25.211272
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import test_numpy
    from ..utils.test_utils import transform, assert_code_equal, assert_tree_equal
    from ..utils.tree import assert_node_equal

    class TestYieldFromTransformer(YieldFromTransformer):
        def __init__(self):
            super().__init__()
            self.handled_nodes = []

        def _handle_assignments(self, node: Node) -> Node:
            if not isinstance(node, ast.Module):
                self.handled_nodes.append(node)
                return node
            return node

        def _handle_expressions(self, node: Node) -> Node:
            if not isinstance(node, ast.Module):
                self.handled_nodes.append(node)
                return node
            return node


# Generated at 2022-06-23 23:29:27.657757
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    from ayi.transformer.compiler import TransformerCompiler

    TransformerCompiler.register_transformer(YieldFromTransformer)

# Generated at 2022-06-23 23:29:28.736901
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert (YieldFromTransformer() is not None)


# Generated at 2022-06-23 23:29:39.843614
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_base import get_test_node
    from .test_base import NodeAssertions
    from .test_base import NodeTestCase
    from typed_astunparse import unparse
    from typing import List
    from typed_ast import ast3 as ast

    class Test(NodeTestCase, NodeAssertions):
        def test_simple_assignment(self):
            transformer = YieldFromTransformer()
            test_node = get_test_node("""
            asd = yield from map(ord, 'asd')
            fgh = qwe
            """)

# Generated at 2022-06-23 23:29:47.499979
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import make_ast
    transformer = YieldFromTransformer()
    ast_tree = make_ast("""
try:
    x = yield from foo(1)
except:
    pass
    """)
    case = make_ast("""
try:
    let(iterable)
    iterable = iter(foo(1))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            target = exc.value
            break
except:
    pass
""")
    assert transformer.visit(ast_tree) == case

# Generated at 2022-06-23 23:29:57.026963
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseLinter

    class Linter(BaseLinter):
        DEFAULT_TRANSFORMERS = [YieldFromTransformer]

    # Yield from in the return statement
    module_src = """def foo():
        return yield from range(10)
"""
    expected_src = """def foo():

    def generate_foo():
        for item in range(10):
            yield item

    return next(generate_foo())
"""
    Linter(module_src, expected_src)

    # Yield from in the return statement in a loop
    module_src = """def foo():
        while True:
            return yield from range(10)
"""

# Generated at 2022-06-23 23:29:58.081297
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # todo add tests
    return None



# Generated at 2022-06-23 23:30:08.425612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer

    class YieldFromTransformer(BaseNodeTransformer):
        """Compiles yield from to special while statement."""
        target = (3, 2)

        def _get_yield_from_index(self, node: ast.AST,
                                  type_: Type[Holder]) -> Optional[int]:
            if hasattr(node, 'body') and isinstance(node.body, list):  # type: ignore
                for n, child in enumerate(node.body):  # type: ignore
                    if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                        return n

            return None


# Generated at 2022-06-23 23:30:13.159085
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    if sys.version_info < (3, 2):
        return
    import astunparse
    import typed_astunparse
    from flake8_typing_extensions.transformer import TypedAstLoader

    snippet = 'def foo(): yield from [i for i in range(0, 5)]'

# Generated at 2022-06-23 23:30:14.127029
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Initialization
    pass

# Generated at 2022-06-23 23:30:16.307799
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.Module(body=[])
    # noinspection PyTypeChecker
    YieldFromTransformer(node)


# Generated at 2022-06-23 23:30:17.280959
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-23 23:30:21.345695
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try_snippet = """
try:
    a = yield from spam()
except Exception as e:
    pass
    """
    YieldFromTransformer(try_snippet, True).visit(ast.parse(try_snippet))

# Generated at 2022-06-23 23:30:23.016973
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-23 23:30:32.960416
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = YieldFromTransformer

        def test_simple_assign(self):
            code = '''
            def foo():
                a = yield from foo()
            '''
            expected_code = '''
            def foo():
                iterable = iter(foo())
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        if hasattr(exc, 'value'):
                            a = exc.value
                        break
            '''
            self.assertCodeChanged(code, expected_code)

        def test_expr_assign(self):
            code = '''
            def foo():
                self.a = yield from foo()
            '''

# Generated at 2022-06-23 23:30:40.689997
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    result = YieldFromTransformer().visit(ast.parse("""
    def foo():
        b = yield from foo()
        yield from foo()
        yield from foo()
    """))


# Generated at 2022-06-23 23:30:51.326029
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import os
    from .snippet import SnippetTransformer

    snippet = """
    def consumer():
        yield from range(3)

    def consumer2():
        yield from range(3)
    """


# Generated at 2022-06-23 23:31:01.022158
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_equal_code
    source = '''
try:
    a = yield from gen
except StopIteration as e:
    a = e.value
    b = 3
    c = 4
    def f():
        pass
'''
    expected = '''
while True:
    try:
        iterable = iter(gen)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        b = 3
        c = 4

        def f():
            pass
'''
    tree = ast.parse(source)
    Y

# Generated at 2022-06-23 23:31:01.874488
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:31:04.418457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    tree: ast.Module = parse('a = (x for x in y)\n')
    node = YieldFromTransformer().visit(tree)
    assert node != tree

# Generated at 2022-06-23 23:31:11.413740
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_snippets import yield_from as snippet_yield_from
    for snippet in yield_from, snippet_yield_from:  #type: ignore
        module = snippet.to_ast()
        for node in snippet_yield_from.get_all_transformer_nodes(module):
            YieldFromTransformer().visit(node)

        module._fields  #pylint: disable=pointless-statement
        module.body  #pylint: disable=pointless-statement
        ast.dump(module)