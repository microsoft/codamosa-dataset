

# Generated at 2022-06-23 23:21:14.087357
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # TODO: Fix tests
    pass
#     """Unit test for method visit of class YieldFromTransformer."""
#     import textwrap
#     import astor
#     from ..utils.helpers import get_ast, compile_to_ast

#     source = textwrap.dedent("""
#         def foo():
#             yield from (x for x in range(10))

#         def bar():
#             a = yield from (x for x in range(10))

#         def baz():
#             (a, b) = yield from (x for x in range(10))

#         def qux():
#             (a, b) = 1, yield from (x for x in range(10))

#         def quux():
#             yield from 1
#     """)

#     expected = text

# Generated at 2022-06-23 23:21:14.901293
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	YieldFromTransformer()

# Generated at 2022-06-23 23:21:16.451535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer(None, False, False)
    assert isinstance(t, YieldFromTransformer)


# Generated at 2022-06-23 23:21:17.450921
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    t = YieldFromTransformer()

# Generated at 2022-06-23 23:21:25.715239
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import transform
    from .base import auto_test_repr
    auto_test_repr(YieldFromTransformer)

    # Assignments
    tree = ast.parse("""
_ = yield from []
_ = yield from []
a = yield from []
b = yield from []
    """)

# Generated at 2022-06-23 23:21:35.269713
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

    code = '''
        def f():
            print(1)
            y = yield from [1, 2, 3]
    '''
    expected_code = '''
        def f():
            print(1)
            let(iterable)
            iterable = iter([1, 2, 3])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    y = exc.value
                    break
    '''  # noqa
    tree = ast.parse(code)
    tree = YieldFromTransformer().visit(tree)
    result_code = str(astor.to_source(tree))
    print(result_code)
    assert result_code == expected_code


# Generated at 2022-06-23 23:21:43.832839
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .yield_from_examples import (
        yield_from_assignment as ass,
        yield_from_function as fun,
        yield_from_generator as gen,
        yield_from_inner_function as infun,
        yield_from_nested as nest,
        yield_from_nested_generator as nestgen,
        yield_from_nested_inner_function as nestinfun,
        yield_from_nested_try as nesttry,
        yield_from_nested_while as nestwhi,
        yield_from_try as tryy,
        yield_from_while as whi,
    )
    from ..compile import to_source


# Generated at 2022-06-23 23:21:53.076253
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap

    from typed_ast import ast3 as ast

    src = textwrap.dedent("""
    def test(a):
        yield from a
    """)

    module = ast.parse(src)
    transformer = YieldFromTransformer()
    new_module = transformer.visit(module)

    assert transformer.tree_changed is True
    assert len(module.body) == 1
    method_def = module.body[0]
    assert isinstance(method_def, ast.FunctionDef)
    assert len(method_def.body) == 1
    while_stmt = method_def.body[0]
    assert isinstance(while_stmt, ast.While)
    if_stmt = while_stmt.body[0]
    assert isinstance(if_stmt, ast.If)
   

# Generated at 2022-06-23 23:21:59.464704
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test import TestCase

    x = 1
    y = 2
    z = 3
    a = x + y

    def method():
        yield from range(10)
        yield from range(10)
        x.yield_from.z

    class TestClass(TestCase):
        def test_method(self):
            @YieldFromTransformer()
            def test_method():
                yield from range(10)
                yield from range(10)
                x.yield_from.z

            test_method()

# Generated at 2022-06-23 23:22:09.937431
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test import assert_program

    assert_program(
        program="""
        def f():
            yield from (x for x in range(0))
        """,
        expected="""
        def f():
            let(exc, iterable)
            iterable = iter((x for x in range(0)))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

        """,
        tr=YieldFromTransformer,
    )


# Generated at 2022-06-23 23:22:11.320375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    YieldFromTransformer()

# Generated at 2022-06-23 23:22:20.012801
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

    #
    # def generator():
    #   yield

    def_yield = ast.FunctionDef(name='generator',
                                body=[
                                    ast.Yield(value=None,
                                              lineno=1,
                                              col_offset=4)
                                ],
                                decorator_list=[],
                                returns=None,
                                lineno=1,
                                col_offset=0)

    #
    # def func():
    #   a = yield from generator()
    #   yield


# Generated at 2022-06-23 23:22:21.528961
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    assert trans.target == (3, 2)
    assert trans.has_target_method('generic_visit')

# Generated at 2022-06-23 23:22:30.021983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    example_code = '''
    def fun():
        yield 1
        yield from func()
        print("some code")
    '''
    expected_code = '''
    def fun():
        yield 1
        iterable = iter(func())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
        print("some code")
    '''
    assert apply_transformer(YieldFromTransformer, example_code) == expected_code



# Generated at 2022-06-23 23:22:35.007378
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .helpers import expected_ast, get_ast

    def compare(snippet, expected):
        module = get_ast(snippet)
        transformer = YieldFromTransformer()
        new_module = transformer.visit(module)
        expected_module = expected_ast(expected)
        assert ast.dump(new_module) == ast.dump(expected_module)


# Generated at 2022-06-23 23:22:44.599532
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.snippet import assert_equal
    from .base import AutoNumberingTransformer
    from .base import get_tree

    tree = get_tree('def foo(): yield from range(10)')
    tree = YieldFromTransformer().visit(tree)

    tree = AutoNumberingTransformer().visit(tree)

# Generated at 2022-06-23 23:22:45.239679
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer("snippet")

# Generated at 2022-06-23 23:22:53.179257
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from ..utils.testing import assert_tree_equal, assert_tree_transformation

    tree_simple = ast.parse('''
        a = 1
        b = yield from c
        d = 2
        e = yield from f
        g = 3
    ''')


# Generated at 2022-06-23 23:22:54.925777
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert ast.parse('yield from obj') == YieldFromTransformer().visit(ast.parse('yield from obj'))



# Generated at 2022-06-23 23:22:56.643706
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..quoting import ast_to_code
    from ..utils.test_utils import transform_and_compare


# Generated at 2022-06-23 23:23:02.126305
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import test_utils
    import textwrap

    source = textwrap.dedent("""
    def f():
        a = yield from foo
        foo = yield from foo
    """)
    tree = test_utils.build_module(source)
    YieldFromTransformer.run_on_tree(tree)
    transformed = test_utils.dump_tree(tree)
    expected = textwrap.dedent("""
    def f():
        a = yield from foo
        foo = yield from foo
    """)
    assert transformed == expected


# Generated at 2022-06-23 23:23:12.023010
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    import astor

    source = (
        "try:\n"
        "    a = yield from range(5)\n"
        "except Exception as exc:\n"
        "    pass"
    )

    class YieldFromTransformerTest(unittest.TestCase):
        def test_yield_from_transformer(self):
            result = (
                "try:\n"
                "    iterable = iter(range(5))\n"
                "    while True:\n"
                "        try:\n"
                "            yield next(iterable)\n"
                "        except StopIteration as exc:\n"
                "            a = exc.value\n"
                "            break\n"
                "except Exception as exc:\n"
                "    pass"
            )
            self

# Generated at 2022-06-23 23:23:21.282561
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformerTest
    from ..utils.ast_parser import get_parser
    from ..utils.tree import print_tree
    from ..utils.helpers import dump, undump

    # Code that we want to transform
    code_1 = """\
    def foo(x):
        y = yield from func(x)
        return 1
    """
    # Transformed code that we expect
    code_2 = """\
    def foo(x):
        let(iterable, exc)
        iterable = iter(func(x))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    y = exc.value
                break
        return 1
    """
    # It is the same test in the base class

# Generated at 2022-06-23 23:23:22.498354
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    y = YieldFromTransformer()
    assert isinstance(y, BaseNodeTransformer)

# Generated at 2022-06-23 23:23:29.571005
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import cst
    from ..utils.codegen import CodeGenerator
    from ..utils.helpers import Parser, Unparser
    import textwrap

    source = """
    def foo():
        yield from 1
        yield from 2
        yield from 3
    """

    tree = Parser().parse(source)
    transformed = YieldFromTransformer().transform(tree)
    generator = CodeGenerator()
    code = generator.visit(transformed)


# Generated at 2022-06-23 23:23:39.968805
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    generator = ast.FunctionDef(name='foo',
                                args=ast.arguments(args=[], vararg=None,
                                                   kwonlyargs=[],
                                                   kw_defaults=[],
                                                   kwarg=None,
                                                   defaults=[]),
                                body=[ast.Yield(value=ast.YieldFrom(value=ast.Name(id='bar',
                                                                                   ctx=ast.Load()))),
                                      ast.Yield(value=ast.Name(id='bar', ctx=ast.Load()))],
                                decorator_list=[],
                                returns=None)


# Generated at 2022-06-23 23:23:40.582925
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:23:41.566183
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-23 23:23:44.249483
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)
    assert YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-23 23:23:56.134046
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import Try, ExceptHandler, Compare, YieldFrom, Name, Attribute, Store, Load, Eq, Call, Expr, Assign, Pass, FunctionDef, Module, Tuple
    from typed_ast.ast3 import Load, Name
    from .transformer_registry import TransformerRegistry
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    import astunparse

    with TransformerRegistry() as registry:
        transformer = registry.register(YieldFromTransformer)

# Generated at 2022-06-23 23:23:57.641215
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:23:59.215731
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)


# Generated at 2022-06-23 23:24:02.155264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast
    from pprint import pprint

    tree = ast.parse('A[0].x')
    assert isinstance(tree, ast.AST)

    pprint(tree)

# Generated at 2022-06-23 23:24:02.783093
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None


# Generated at 2022-06-23 23:24:10.263263
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    import astor as astor

    code = dedent('''\
        def foo():
            var = yield from foo()
    ''')

    node = ast.parse(code)
    transformer = YieldFromTransformer()
    optimized_node = transformer.visit(node)

    expected_code = dedent('''\
        def foo():
            iterable = None
            var = None
            iterable = iter(foo())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        var = exc.value
                    break
    ''')

    assert transformer._tree_changed
    assert astor.to_source(optimized_node) == expected_code

# Generated at 2022-06-23 23:24:21.233125
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    if (a):
        yield from b
    """
    ast_tree = ast.parse(code)
    YieldFromTransformer().visit(ast_tree)

# Generated at 2022-06-23 23:24:23.144287
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:24:30.657653
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import FunctionDef, arguments, Name, Load, Store, YieldFrom, Assign, NameConstant, Expr, Module

    source = FunctionDef(
        name='bar',
        args=arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            Assign(
                targets=[Name(id='target1', ctx=Store())],
                value=YieldFrom(value=Name(id='generator', ctx=Load()))
            ),
            Expr(value=YieldFrom(value=Name(id='generator', ctx=Load())))
        ],
        decorator_list=[],
        returns=None
    )
   

# Generated at 2022-06-23 23:24:34.272602
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""
    def f():
        a = yield from g()
        yield from g()
    """)
    transformer = YieldFromTransformer()
    node = transformer.visit(tree)
    assert node is not None

# Generated at 2022-06-23 23:24:35.212384
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-23 23:24:36.859591
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import test_transform


# Generated at 2022-06-23 23:24:44.086026
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from lib2to3 import refactor

    r = refactor.RefactoringTool(
        fixers=['libmodernize.fixes.yield_from'],
    )
    s = """\
    x = yield from range(10)
    """
    result = """\
    let(iterable)
    iterable = iter(range(10))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                x = exc.value
            break
    """
    assert r.refactor_string(s, name='file') == result

# Generated at 2022-06-23 23:24:46.523615
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transpile import Transpiler

    source = '''
    def gen():
        yield 1
        yield 2

    def func():
        a = yield from gen()
    '''

# Generated at 2022-06-23 23:24:50.115864
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()
    snippet_node = snippet.get_ast(**{})
    module = ast.parse(snippet_node)
    transformed_module = transformer.visit(module)
    assert snippet.compare(transformed_module, **{})

# Generated at 2022-06-23 23:24:51.106850
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:00.681175
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # for case:
    # def f():
    #     a = (x for x in range(10))
    #     g = yield from a
    #     return g
    yield_from = ast.YieldFrom(
        value=ast.GeneratorExp(
            elt=ast.Name(id='x', ctx=ast.Load()),
            generators=[
                ast.comprehension(
                    target=ast.Name(id='x', ctx=ast.Store()),
                    iter=ast.Call(
                        func=ast.Name(id='range', ctx=ast.Load()),
                        args=[ast.Num(n=10)],
                        keywords=[]
                    ),
                    ifs=[]
                )
            ]
        )
    )

# Generated at 2022-06-23 23:25:11.378295
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Test(ast.NodeVisitor):
        def __init__(self, YFT: YieldFromTransformer) -> None:
            self.YFT = YFT

        def test(self, node: ast.AST) -> None:
            self.YFT.visit(node)

    test = Test(YieldFromTransformer())

    # Test simple case
    module = ast.parse('a = yield from b')
    assert 'a = b' in ast.dump(module, False)
    test.test(module)
    assert 'a = b' not in ast.dump(module, False)
    assert 'a = exc.value' in ast.dump(module, False)

    # Test with empty target
    module = ast.parse('yield from b')

# Generated at 2022-06-23 23:25:19.048288
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast, parse
    from typed_ast.transforms import YieldFromTransformer

    tree = parse("""
    def func(i, j):
        yield from [i]
        yield from j
        a = yield from a
        yield from a
        yield from a
        yield from a
    """)
    t = YieldFromTransformer()
    tree = t.visit(tree)

# Generated at 2022-06-23 23:25:27.535385
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

    def test_visit(self):
        code = """
        def f():
            yield from range(2)
        """

        tree = ast.parse(code)
        YieldFromTransformer().visit(tree)
        assert astor.to_source(tree) == """
        def f():
            iterable = iter(range(2))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """



# Generated at 2022-06-23 23:25:32.742362
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.zipper import zipper

    from .helpers import (
        compare_source,
        get_nodes,
        parse,
        transform,
        zip_test_source,
    )

    source = """
    def test_before(a):
        a = yield from range(2)
        a = yield from range(3)
        yield from range(4)
        b = yield from range(5)
    """

# Generated at 2022-06-23 23:25:33.821430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass #TODO add test here


# Generated at 2022-06-23 23:25:34.733040
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:45.866509
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tests.testing import make_res_test_env
    from ..utils.helpers import flatten

    module, target = make_res_test_env(YieldFromTransformer)

    def get_names(func: str) -> List[str]:
        return [name for _, name in flatten(getattr(target, func))
                if isinstance(name, ast.Str)]

    assert get_names('func_without') == ['a', 'b', 'c']
    assert get_names('func_with') == ['a', 'b', 'c', 'd']
    assert get_names('func_with_target') == ['a', 'b', 'c', 'd']
    assert get_names('func_with_seq') == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-23 23:25:47.340139
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astunparse import dump
    from inspect import cleandoc


# Generated at 2022-06-23 23:25:55.103704
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import UnitTestCase
    from . import compile_to_ast
    from . import compare_nodes

    class TestCase(UnitTestCase[Node]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.target = compile_to_ast(self.target)
            self.result = compile_to_ast(self.result)

        def assert_result(self, result: Node) -> None:
            compare_nodes(self.result, result)

    class Test_visit(TestCase):
        target = \
'''
yield from foo
'''

# Generated at 2022-06-23 23:26:06.150473
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from pytest import raises
    from ..utils.source import source

    with raises(TypeError):
        YieldFromTransformer(1)

    with raises(TypeError):
        YieldFromTransformer(source('1'))

    assert YieldFromTransformer(source('def foo():\n\tyield from range(3)')).code == \
        "def foo():\n    exc = None\n    iterable = iter(range(3))\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            exc = exc\n            break\n\n"


# Generated at 2022-06-23 23:26:07.116579
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:26:08.029104
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-23 23:26:09.579679
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        YieldFromTransformer()

# Generated at 2022-06-23 23:26:18.552240
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    node = ast.parse("""
        def foo():
            i = 0
            while i < 3:
                yield i
                i += 1
            yield from bar()
        """)  # type: ast.AST

    with YieldFromTransformer() as transformer:
        transformer.visit(node)
    print(astunparse.dump(node))

    node = ast.parse("""
        def foo():
            i = 0
            while i < 3:
                yield i
                i += 1
            return bar()
        """)  # type: ast.AST

    with YieldFromTransformer() as transformer:
        transformer.visit(node)
    print(astunparse.dump(node))

# Generated at 2022-06-23 23:26:28.592962
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test import NodeTestCase
    from ..visitor import Unparser

    class YieldFromTransformerTest(NodeTestCase):

        _transformer = YieldFromTransformer

        def test_expr(self):
            tree = self.parse('''
                def method(gen):
                    yield from gen
            ''')
            expected = self.parse('''
                def method(gen):
                    let(iterable)
                    iterable = iter(gen)
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            break
            ''')
            self.assertTransformed(tree, expected)


# Generated at 2022-06-23 23:26:37.867443
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import textwrap
    sample_code = textwrap.dedent(
        """
        def foo():
            y = yield from bar.baz()
            yield from (1, 2, 3)
            yield from [1, 2, 3]
            yield from {1, 2, 3}
            yield from {1: 1, 2: 2}
        """
    )

# Generated at 2022-06-23 23:26:38.423088
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:26:42.155522
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse("""
    a = 'ok'
    b = yield from [1]

    class a:
        pass
    """)
    trans = YieldFromTransformer()
    transformed = trans.visit(module)
    assert 'yield from' not in ast.dump(transformed)

# Generated at 2022-06-23 23:26:49.271703
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from source_code_to_ast.python.modules.typed_ast.ast3 import parse
    from source_code_to_ast.python.modules.typed_ast.ast3 import parse as parse_typed
    from ..utils.helpers import compare_asts

    code = 'a = yield from [1]'
    expected_ast = parse('exc = StopIteration()\na = exc.value')
    typed_ast = parse_typed(code)
    typed_transformed_ast = YieldFromTransformer().visit(typed_ast)
    assert compare_asts(expected_ast, typed_transformed_ast)

    code = 'yield from [1]'
    expected_ast = parse('exc = StopIteration()')
    typed_ast = parse_typed(code)

# Generated at 2022-06-23 23:26:53.448635
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # a = yield from [1,2,3]

    # Note that autogenerated constructor did not work with initializer list
    # YieldFromTransformer()

    # but manual invocation of constructor did work
    YieldFromTransformer.__new__(YieldFromTransformer)


# Generated at 2022-06-23 23:26:58.033173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from textwrap import dedent

    example = dedent("""
    def foo():
        yield from 2
    """)
    tree = ast3.parse(example)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

    result = dedent("""
    def foo():
        iterable = iter(2)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break

    """)
    assert ast3.dump(tree) == result

# Generated at 2022-06-23 23:27:01.514320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    Tests constructor of class YieldFromTransformer

    Returns
    -------
    None

    """
    tree = ast.parse("""
    def f():
        for i in range(10):
            yield from i
    """)
    mod = YieldFromTransformer().visit(tree)



# Generated at 2022-06-23 23:27:04.685417
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:27:14.768759
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = 'def foo():\n    yield from range(10)\n    yield from range(10)\n    a = yield from range(10)\n    yield from range(10)'
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:27:19.414672
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source
    from ..utils.tokenize import tokenize
    from ..utils.parse import parse
    from ..utils.transform import transform
    from ..utils.unparse import unparse
    from ..utils.compare_ast import compare_ast

# Generated at 2022-06-23 23:27:21.020098
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with raises(Exception):
        YieldFromTransformer(None)



# Generated at 2022-06-23 23:27:26.799445
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = """
        def function():
            yield from generator1
            yield from generator2
            a = yield from generator3
            yield from generator4
            b = yield from generator5
            yield from generator6
            c = yield from generator7
            yield from generator8
    """
    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

# Generated at 2022-06-23 23:27:30.837996
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # node = ast.parse('''def foo():
    #     yield from bar()''')
    # transformer = YieldFromTransformer()
    # transformer.visit(node)
    # print(ast.dump(node))
    pass

# Generated at 2022-06-23 23:27:40.781593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import ast3 as ast
    from .base import BaseNodeTransformer
    from .variable_renaming import VariableRenamingTransformer

    class Renamer(BaseNodeTransformer):

        def visit_AST(self, node: ast.AST) -> ast.AST:
            return self.generic_visit(node)

    result = ast.parse('yield from some', '<test>', 'exec')
    from .. import ast3 as ast
    from .base import BaseNodeTransformer
    from .variable_renaming import VariableRenamingTransformer

    class Renamer(BaseNodeTransformer):

        def visit_AST(self, node: ast.AST) -> ast.AST:
            return self.generic_visit(node)

    result = ast.parse('yield from some', '<test>', 'exec')
    ast.fix_

# Generated at 2022-06-23 23:27:51.209144
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # {result = yield from x} -> while True:
    #    try:
    #      yield next
    #    except StopIteration as exc:
    #      result = exc.value
    #      break
    x = ast.Name('x', ast.Load())
    yf = ast.YieldFrom(x, ast.Load())
    a = ast.Assign([ast.Name('result', ast.Store())],
                   yf,
                   ast.Store())
    exp = ast.Expr(yf)

    ast_after = YieldFromTransformer().visit(ast.Module(body=[a, exp]))
    assert str(ast_after) == 'while True: try: yield next(iter(x)) except StopIteration as exc: result = exc.value; break'

    # {yield from x} -> while

# Generated at 2022-06-23 23:28:00.559418
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import TestBase
    from ..utils import ast_from_str
    from textwrap import dedent

    input = dedent("""\
        async def foo():
            a = yield from gen()
            b = yield from gen()
            yield from gen()
    """)


# Generated at 2022-06-23 23:28:08.273649
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import _test_transform
    from ..utils.helpers import VariablesGenerator
    import typed_astunparse
    import astunparse

    vgen = VariablesGenerator()
    a = vgen.gen('a')
    b = vgen.gen('b')
    c = vgen.gen('c')
    d = vgen.gen('d')
    e = vgen.gen('e')
    f = vgen.gen('f')
    g = vgen.gen('g')
    h = vgen.gen('h')
    i = vgen.gen('i')
    j = vgen.gen('j')


# Generated at 2022-06-23 23:28:17.691047
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..visitor import NodeTransformer, NodeTransformerError, get_node_transformer

# Generated at 2022-06-23 23:28:18.644258
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from asttokens import ASTTokens
    import astor

# Generated at 2022-06-23 23:28:28.518018
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import Try, FunctionDef, Name, Load, YieldFrom, Expr, Tuple
    import copy
    from .test_conditional_expressions import test_ConditionalExpressionTransformer_visit
    from .test_for_loops import test_ForLoopTransformer_visit
    from .test_function_arguments import test_FunctionArgumentsTransformer_visit

# Generated at 2022-06-23 23:28:32.630901
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.lextk import string_to_lextk
    from ..parser.parser import Parser
    from ..parser.context import Context
    from ..transformer.visitor import NodeTransformer


# Generated at 2022-06-23 23:28:42.301639
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.node import clean_node
    from ..utils.helpers import compilable
    from ..transforms.yield_from import YieldFromTransformer


# Generated at 2022-06-23 23:28:43.252752
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    raise NotImplementedError()

# Generated at 2022-06-23 23:28:44.599395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer("YieldFromTransformer")

# Generated at 2022-06-23 23:28:53.051903
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..output import OutputTransformer
    from ..unpack_inherit import UnpackInheritTransformer
    from ..list_comprehension import ListComprehensionTransformer
    from ..metaclass import MetaclassTransformer
    from ..backport_unittest import BackportUnittestTransformer
    from ..absolute_import import AbsoluteImportTransformer
    from ..generator_stop_iteration import GeneratorStopIterationTransformer
    from ..raise_from import RaiseFromTransformer
    from ..super_with_arg import SuperWithArgTransformer
    from ..utils.testing import set_up_before, tear_down_after, tree_to_str,\
        assert_equals

    set_up_before()

# Generated at 2022-06-23 23:28:54.343567
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()


# Generated at 2022-06-23 23:28:56.968258
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test = YieldFromTransformer()
    assert test.target == (3, 2)
    assert test._get_yield_from_index(None, None) == None

# Generated at 2022-06-23 23:28:57.887775
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-23 23:28:58.877534
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:29:06.833148
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from test.test_tools import generate_tester_from_func
    from .. import TransformFunction
    from ..utils.snippet import snippet
    from ..utils.tree import ast_parse, ast_compare

    @snippet
    def test_function():
        def yield_from_function():
            yield from (x for x in [1, 2, 3])

        class A:
            def __iter__(self):
                yield from (x for x in [4, 5, 6])

            def __init__(self):
                yield from (x for x in [4, 5, 6])

            def method(self):
                yield from (x for x in [4, 5, 6])

            async def async_method(self):
                yield from (x for x in [4, 5, 6])


# Generated at 2022-06-23 23:29:10.837307
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_utils import get_test_cases
    test_cases = get_test_cases(__name__, 'test_YieldFromTransformer')
    for test_case in test_cases:
        assert test_case.expected == test_case.actual, test_case.description

# Generated at 2022-06-23 23:29:12.548857
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-23 23:29:14.594475
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:16.290409
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import to_source


# Generated at 2022-06-23 23:29:18.180183
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer.__name__  # type: ignore

# Generated at 2022-06-23 23:29:20.509919
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

    class TestYieldFromTransformer(YieldFromTransformer):
        def visit_Assign(self, node):
            return node
        def visit_Expr(self, node):
            return node


# Generated at 2022-06-23 23:29:23.058797
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ft.fp.ast_helper import get_ast
    from pprint import pprint
    from typed_ast import ast3


# Generated at 2022-06-23 23:29:23.641516
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:29:31.127753
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.python_code_parser import PythonCodeParser
    from ..utils.helpers import compare_source

    def _check(code: str) -> str:
        tree = PythonCodeParser().parse(code)
        YieldFromTransformer().visit(tree)
        return PythonCodeParser().compile(tree)

    assert compare_source(_check('''
for i in [1, 2]:
    print(i)
    yield from test_func(i)
'''), '''
for i in [1, 2]:
    print(i)
    let(iterable)
    iterable = iter(test_func(i))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
''')


# Generated at 2022-06-23 23:29:32.580473
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    from .context import Context


# Generated at 2022-06-23 23:29:35.997794
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer(None)
    assert tr.target == (3, 2)
    assert tr._tree_changed is False
    assert tr._get_yield_from_index(None, ast.Expr) is None

# Generated at 2022-06-23 23:29:39.258582
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def foo():
        x = yield from gen()

    class X:
        def bar(self):
            yield from gen()
            yield from gen()


# Generated at 2022-06-23 23:29:45.631783
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tests import generate_source, assert_source

    source = generate_source(YieldFromTransformer,
                             "test_YieldFromTransformer_visit")
    expected_code = generate_source(YieldFromTransformer,
                                    "test_YieldFromTransformer_visit",
                                    expected=True)
    assert_source(YieldFromTransformer,
                  "test_YieldFromTransformer_visit",
                  source,
                  expected_code)

# Generated at 2022-06-23 23:29:47.899699
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Just for coverage, no need for testing
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-23 23:29:52.051511
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        node = ast.PythonAst().parse('yield from')
    except AttributeError:
        node = ast.parse('yield from')

    transformer = YieldFromTransformer()
    transformer.visit(node)

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:29:53.805615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x.target == (3, 2)



# Generated at 2022-06-23 23:30:00.913300
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import assert_source

    from ..utils import load_typed_ast

    from .unpacking import UnpackingTransformer
    from .partial_function import PartialFunctionTransformer
    from .function_defaults import FunctionDefaultsTransformer
    from .imports import ImportsTransformer

    node = load_typed_ast('a = yield from b')
    result = YieldFromTransformer(node).visit(node)
    result = UnpackingTransformer(result).visit(result)
    result = PartialFunctionTransformer(result).visit(result)
    result = FunctionDefaultsTransformer(result).visit(result)
    result = ImportsTransformer(result).visit(result)


# Generated at 2022-06-23 23:30:11.577450
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.helpers import Ast
    from .. import module


# Generated at 2022-06-23 23:30:13.353574
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:30:20.703124
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap
    # arrange
    with open('tests/data/ast/yield_from.py', 'r') as f:
        code = f.read()
    tree = ast.parse(textwrap.dedent(code))

    # act
    tree = YieldFromTransformer().visit(tree)
    result = astor.to_source(tree)

    # assert
    with open('tests/data/ast/yield_from_result.py', 'r') as f:
        code = f.read()
    assert code == result

# Generated at 2022-06-23 23:30:21.586043
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:30:31.789187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with open('tests/cases/test_yield_from.py') as f:
        tree = ast.parse(f.read())

    expected_with_open = """if __name__ == '__main__':
    def dummie():
        print('hello')
        yield from it
    it = [1, 2, 3]
    exc = VariablesGenerator.generate('exc')
    iterable = iter(dummie())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            target = exc.value
            break
    del exc
    with open('filename') as target:
        pass
"""

# Generated at 2022-06-23 23:30:32.738214
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:40.526825
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test_generator():
        yield from [1]

    node = ast.FunctionDef(name='test_generator',
                           args=ast.arguments(posonlyargs=[],
                                              args=[],
                                              vararg=None,
                                              kwonlyargs=[],
                                              kw_defaults=[],
                                              kwarg=None,
                                              defaults=[]),
                           body=[
                               ast.Expr(value=ast.YieldFrom(value=ast.List(elts=[ast.Num(n=1)],
                                                                          ctx=ast.Load()))),
                               ast.Return(value=None)
                           ],
                           decorator_list=[],
                           returns=None)

# Generated at 2022-06-23 23:30:51.196860
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def yield_from(body):
        return YieldFromTransformer(body).get_tree()

    assert yield_from([
        "a = yield from [1]",
    ]) == [
        "let(iterable_0)",
        'iterable_0 = iter([1])',
        "while True:",
        "    try:",
        "        a = next(iterable_0)",
        "    except StopIteration as exc_0:",
        "        if hasattr(exc_0, 'value'):",
        "            a = exc_0.value",
        "        break",
    ]

    # multiple expressions with yield from

# Generated at 2022-06-23 23:30:52.032352
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    

# Generated at 2022-06-23 23:30:53.386295
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..rewrite import Rewrite
    from ..api import std
    macro = Rewrite(std.core)
    assert macro.load_transformer(YieldFromTransformer)

# Generated at 2022-06-23 23:31:03.601249
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse  # type: ignore
    from textwrap import dedent
    from ..utils.codegen import as_source
    from ..utils.helpers import load_source

    transformer = YieldFromTransformer()
    tree = load_source(dedent("""\
        import typing as tp
        def function_with_yield_from() -> tp.Iterator:
            result = yield from iter(range(10))
            yield result
    """))
    transformed = transformer.visit(tree)
    obtained = astunparse.unparse(transformed)

# Generated at 2022-06-23 23:31:05.027539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.visit(YieldFromTransformer(), node=None, target=None) == None