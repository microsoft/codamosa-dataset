

# Generated at 2022-06-23 23:21:02.533723
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:09.640826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast as _ast
    import typing as _t
    if not hasattr(_t, "TYPE_CHECKING"):
        raise AssertionError
    # AssertionError is raised if the class does not have a constructor
    if not hasattr(YieldFromTransformer, "__init__"):
        raise AssertionError
    # AssertionError is raised if the class constructor has no parameters
    if len(inspect.signature(YieldFromTransformer.__init__).parameters) == 0:
        raise AssertionError
    

# Generated at 2022-06-23 23:21:17.016561
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_base import TestBase
    from .test_helpers import wrap_in_module
    from ..utils.snippet import snippet

    @snippet
    def test_1():
        def f():
            yield from g()

    @snippet
    def test_2():
        def f():
            yield from g()
            x = 20

    @snippet
    def test_3():
        def f():
            x = 20
            yield from g()

    @snippet
    def test_4():
        def f():
            x = 20
            yield from g()
            x = 30

    @snippet
    def test_5():
        def f():
            x = 20
            while True:
                yield from g()
                x = 30


# Generated at 2022-06-23 23:21:25.061863
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Example 1:
    # a = yield from x
    # should be compiled to
    # iterable = iter(x)
    # while True:
    #     try:
    #         yield next(iterable)
    #     except StopIteration as exc:
    #         a = exc.value
    #         break
    tree = ast.parse('a = yield from x')
    exp_tree = ast.parse('''
iterable = iter(x)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        a = exc.value
        break
''')
    YieldFromTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(exp_tree)

    # Example 2:
    # yield from x
    # should be compiled to

# Generated at 2022-06-23 23:21:26.572067
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:21:27.113430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-23 23:21:33.505797
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    @snippet
    def test_function(x):
        while True:
            yield from x
            print('one')
            yield from x
            print('two')
            print('three')
            yield from x

    root = ast.parse(test_function.get_source())
    transform = YieldFromTransformer()
    root = transform.visit(root)
    assert transform.is_changed() is True
    assert test_function.get_source() != root


# Generated at 2022-06-23 23:21:42.271028
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tests.utils import compile_function

    def test_module():
        let(a)
        a = 5
        yield from test_for()
        print(a)

    def test_if():
        let(a)
        if 5 > 3:
            a = 5
            yield from test_for()

    def test_try():
        let(a)
        a = 5
        try:
            yield from test_for()
        except:
            pass
        print(a)

    def test_while():
        let(a)
        a = 5
        while 5 > 3:
            yield from test_for()
            if 5 < 1:
                break
        print(a)

    def test_for():
        let(a)
        for a in range(1, 3):
            b = 3
            yield

# Generated at 2022-06-23 23:21:51.652033
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as native_ast, unittest

    class YieldFromTransformerTest(unittest.TestCase):
        def test_YieldFromTransformer_visit_Module(self):
            transformer = YieldFromTransformer()


# Generated at 2022-06-23 23:21:54.873989
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = "yield from foo"

# Generated at 2022-06-23 23:22:04.723783
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from ..utils.test_utils import MockNodeTransformer

    transformer = MockNodeTransformer(YieldFromTransformer)

    assignment = ast.parse('i = yield from t').body[0]
    expr = ast.parse('yield from t').body[0]
    try1 = ast.parse('try:\n    yield from t').body[0]
    try2 = ast.parse('try:\n    yield from t\nexcept Exception: \n    pass').body[0]
    try3 = ast.parse('try:\n    a = yield from t\nexcept Exception: \n    pass').body[0]
    function_def = ast.parse('def f():\n    yield from t').body[0]
    while_ = ast.parse('while 1:\n    yield from t').body[0]

# Generated at 2022-06-23 23:22:06.885163
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import get_ast_tree


# Generated at 2022-06-23 23:22:07.931882
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast.YieldFrom(value=None)

# Generated at 2022-06-23 23:22:09.367319
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import compile_snippet

# Generated at 2022-06-23 23:22:10.706621
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj.visit(None) == None

# Generated at 2022-06-23 23:22:19.534340
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.helpers import tree_from_str
    from ..utils.tree import multi_visit
    from .base import BaseNodeTransformer

    ast_str = """
    def bar(generator, x):
        w = yield from generator
        if w is not None:
            w += x
    """
    expected_str = """
    def bar(generator, x):
        let(iterable, exc)
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    w = exc.value
                break
        if w is not None:
            w += x
    """

# Generated at 2022-06-23 23:22:29.450983
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    exec("def test(a):\n"
         "    a = yield from b\n"
         "    yield from b\n"
         "    return a\n") in {}

    module = ast.parse("def test(a):\n"
                       "    a = yield from b\n"
                       "    yield from b\n"
                       "    return a\n")

    transformer = YieldFromTransformer()
    transformed_ast = transformer.visit(module)


# Generated at 2022-06-23 23:22:37.908370
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    suite = unittest.TestSuite()

    # test in For node
    node = ast.parse("""
    for i in range(5):
        a = yield from function_generator()
        b = yield from function_generator()
    """)
    transformer = YieldFromTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-23 23:22:38.646518
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:46.844637
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from mypy import api
    import sys

    code = '''
    def test1() -> None:
        a = 1 + 2
        b: int = a
        yield from [1, 2, 3]

    def test2() -> None:
        a = 1 + 2
        b: int = a
        yield from [1, 2, 3]
    '''

    result = api.run(['-c', code])[0]
    result = ast.parse(result)
    result = YieldFromTransformer().visit(result)
    assert result.body[1].body[-2].value.value.value.args[0].value == 1

# Generated at 2022-06-23 23:22:49.053200
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print (YieldFromTransformer().get_tree())
    import astor
    print (astor.dump_tree(YieldFromTransformer().get_tree()))

# Generated at 2022-06-23 23:22:57.177540
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    from typed_ast import ast3 as ast

    class TestMethods(unittest.TestCase):
        def setUp(self):
            self.transformer = YieldFromTransformer()

        def test_visit_simple_yield(self):
            code = 'def foo(): yield from bar()'
            tree = ast.parse(code)
            self.transformer.visit(tree)

# Generated at 2022-06-23 23:22:57.852127
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:23:04.914106
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse(
        '''
        def test():
            a = yield from test_gen()
            yield from test_gen2()
            b = (yield from test_gen3())
        '''
    )
    transformer = YieldFromTransformer()
    transformed = transformer.visit(tree)

    assert transformer.changed == True
    assert isinstance(transformed, ast.Module)
    assert len(transformed.body) == 1
    assert isinstance(transformed.body[0], ast.FunctionDef)
    assert len(transformed.body[0].body) == 7

    assert isinstance(transformed.body[0].body[0], ast.Assign)
    assert len(transformed.body[0].body[0].targets) == 1

# Generated at 2022-06-23 23:23:05.798650
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:23:10.476373
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    transformer = YieldFromTransformer()
    node = astor.parse("""def foo():
    x = yield from bar()
    y = yield from baz()
    print(y)
    """)
    transformer.visit(node)
    print(astor.to_source(node))


# Generated at 2022-06-23 23:23:18.432395
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import List
    from ..unit_test import assert_equal

    code = """
        def generator():
            yield 1
        def function():
            yield from generator()
    """
    expected = """
        def generator():
            yield 1
        def function():
            let(iterable)
            iterable = iter(generator)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """
    module, _ = ast.parse(code)
    transformer = YieldFromTransformer()
    transformer.visit(module)

    assert_equal(module, expected)


# Generated at 2022-06-23 23:23:19.093992
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:23:19.962432
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: Write unit test
    pass

# Generated at 2022-06-23 23:23:25.693682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    y = YieldFromTransformer()
    node = y.visit(ast.parse('''a = yield from b'''))
    assert ast.dump(node) == 'Module(body=[Assign(targets=[Name(id=\'a\', ctx=Store())], value=Call(func=Name(id=\'next\', ctx=Load()), args=[Call(func=Name(id=\'iter\', ctx=Load()), args=[Name(id=\'b\', ctx=Load())], keywords=[])], keywords=[]))])'

# Generated at 2022-06-23 23:23:35.912184
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    node = ast.FunctionDef(
        name='foo',
        args=ast.arguments(
            args=[]
        ),
        body=[
            ast.YieldFrom(value=ast.Name(id='x', ctx=ast3.Load()))
        ],
        returns=None,
        decorator_list=[]
    )

    tree = ast.Module(body=[
        node
    ])


# Generated at 2022-06-23 23:23:38.181465
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor; from typed_ast import ast3; from ast_helpers.transformers.yield_from import YieldFromTransformer


# Generated at 2022-06-23 23:23:39.471535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None

# Generated at 2022-06-23 23:23:40.479919
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor


# Generated at 2022-06-23 23:23:51.715722
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse("""
yield from _yield_from_()
yield from _yield_from_()
x = yield from _yield_from_()
yield from _yield_from_()
""")
    YieldFromTransformer().visit(module)

# Generated at 2022-06-23 23:23:52.785694
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:23:53.914209
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer is not None)

# Generated at 2022-06-23 23:24:04.952723
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..python import PythonTransformer
    from ..snippets import snippet
    from ..utils.graph import build_graph, apply_visitor_class
    import textwrap

    @snippet
    def my_generator():
        yield 2

    @snippet
    def py2_code():
        yield from my_generator()

    @snippet
    def py3_code():
        yield from my_generator()

    imported_snippets = {'my_generator': my_generator}
    graph = build_graph(py3_code, imported_snippets)
    graph = apply_visitor_class(graph, PythonTransformer)
    graph = apply_visitor_class(graph, YieldFromTransformer)


# Generated at 2022-06-23 23:24:13.531942
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    m = ast.parse('def f():\n'
                  '  var = yield from [0]')
    t = YieldFromTransformer()
    t.visit(m)
    assert """def f():
  let(iterable)
  iterable = iter([0])
  while True:
    try:
      var = next(iterable)
      yield var
    except StopIteration as exc:
      if hasattr(exc, 'value'):
        var = exc.value
      break""" == ast.dump(m)

    m = ast.parse('def f():\n'
                  '  yield from [0, 1]')
    t = YieldFromTransformer()
    t.visit(m)

# Generated at 2022-06-23 23:24:24.328616
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    try_stmt = ast.Try(body=[],
                       handlers=[],
                       orelse=[],
                       finalbody=[])
    expected = ast.Try(body=[],
                       handlers=[],
                       orelse=[],
                       finalbody=[])
    assert YieldFromTransformer.visit(try_stmt) == expected
    try_stmt = ast.Try(body=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='value',
                                                                         ctx=ast.Load())))],
                       handlers=[],
                       orelse=[],
                       finalbody=[])

# Generated at 2022-06-23 23:24:30.874823
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = "def foo(x):\n    y = yield from bar(x)\n    return y"
    expected_code = "def foo(x):\n    exc = 'exc'\n    iterable = iter(bar(x))\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            y = exc.value\n    return y"
    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    output_tree = transformer.visit(tree)
    output_code = compile(output_tree, filename="<ast>", mode="exec")
    assert output_code == compile(expected_code, filename="<ast>", mode="exec")

# Generated at 2022-06-23 23:24:37.714988
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..compiler import Compiler
    from ..testing import assert_compiled
    code = """
    def f():
        l = []
        while True:
            yield 1
            yield from l
            yield 3
            v = yield 4
            yield 5
            yield from g()
            yield 7

        yield from g()
        yield from g()


    def g():
        return (i for i in range(10))
    """

    Compiler.add_transformer(YieldFromTransformer)

# Generated at 2022-06-23 23:24:38.983357
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    import astor


# Generated at 2022-06-23 23:24:46.064657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast31 = ast.parse('a = yield from list(range(2))')
    tree = YieldFromTransformer(ast31)
    res = ast.dump(tree)
    assert res == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='list', ctx=Load()), args=[Call(func=Name(id='range', ctx=Load()), args=[Num(n=2)], keywords=[])], keywords=[]))])"

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:24:56.116271
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import utils

    ast_tree = utils.parse("""
        def func():
            a = yield from some_gen()
            yield from some_gen2()
            b = yield from some_gen3()
            yield from some_gen4()

        def func2():
            yield from some_gen()
            yield from some_gen2()
    """)

    transformer = YieldFromTransformer()
    transformer.visit(ast_tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-23 23:25:04.822059
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3
    except ImportError:
        return None

    from ..utils.helpers import get_node_types

    source_code = """def foo(x):\n    yield from x"""

    t = YieldFromTransformer()
    tree = ast3.parse(source_code)

    assert get_node_types(tree) == ['Module',
                                    'FunctionDef',
                                    'arguments',
                                    'arg',
                                    'Return',
                                    'Expr',
                                    'YieldFrom',
                                    'Name']

    t.visit(tree)

# Generated at 2022-06-23 23:25:06.559206
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
        subj = YieldFromTransformer()
        assert subj is not None


# Generated at 2022-06-23 23:25:16.252791
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys, os
    import ast as python_ast
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = YieldFromTransformer
        FILE = os.path.abspath(__file__)
        RELATIVE_FILE = os.path.relpath(FILE, sys.path[0])

        def test_simple(self):
            snippet = self.get_snippet('''
                                           def f():
                                               x = 1
                                               y = yield from f
                                               z = yield from h
                                           ''')

# Generated at 2022-06-23 23:25:22.217272
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import valid_ast
    from ..compiler import compile
    from . import BaseNodeTransformer
    node = compile('a = yield from b')
    transformer = YieldFromTransformer(node)
    out = transformer.visit(node)
    assert valid_ast(out)
    assert transformer._tree_changed


# Generated at 2022-06-23 23:25:23.899008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 23:25:24.572953
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:25:30.274470
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.parser import parse
    from ..utils.helpers import print_ast

    input_ = """
    def f(gen1):
        yield from gen1
    def f2(gen2):
        yield from gen2
        yield from gen1
    def f3(gen3):
        x = yield from gen3
    def f4(gen4):
        yield from gen4
        x = 1
    """

# Generated at 2022-06-23 23:25:35.074445
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import operator
    from ..utils.helpers import dict_to_ast_kwargs, node_or_str_to_ast_node
    import ast as python_ast

    class Test(unittest.TestCase):
        def test_global_context(self):
            code = \
                '''
                a = yield from func()
                '''
            tree = node_or_str_to_ast_node(code)

            expected_code = \
                '''
                let(iterable)
                iterable = iter(func())
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        a = exc.value
                        break
                '''


# Generated at 2022-06-23 23:25:44.461753
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import get_node, assert_tree
    from .yield_from_transformer import YieldFromTransformer

    node = get_node(
        """
        def f():
            yield from [0, 1]
        """
    )
    transformer = YieldFromTransformer()
    transformed = transformer.visit(node)
    assert_tree(
        transformed,
        """
        def f():
            let(iterable)
            iterable = iter([0, 1])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        """
    )



# Generated at 2022-06-23 23:25:45.543818
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:25:53.089914
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """
    Test that at least the following AST transformations occur:

        1. Replace yield from with while loop to extract generator value
        2. Accept yield from inside of loops, functions and modules
    """
    from .testutils import make_visitor_test, make_assert_tests_for_node
    import typed_ast.ast3 as ast

    # 1.
    visitor = YieldFromTransformer()
    node = ast.parse("""yield from items""")
    expected_node = ast.parse("""let(iterable)
iterable = iter(items)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            exc = exc.value
        break""")

# Generated at 2022-06-23 23:26:04.156334
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..visitor import ASTFlattener
    import textwrap

    class CodeGenerator(object):
        def __init__(self, code):
            self._count = 0
            self._code = textwrap.dedent(code)

        def generate(self):
            count = self._count
            self._count += 1
            return self._code.format(i=count)

    class CodeSource(object):
        def __init__(self, generator):
            self._generator = generator

        def get_code(self, node):
            return self._generator.generate()

    def test(input_code, expected_code):
        tree: ast.Module = ast.parse(input_code)
        transformer = YieldFromTransformer()
        tree = transformer.visit(tree)

# Generated at 2022-06-23 23:26:10.100188
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3
    except ImportError:
        return
    from ..visitor import Visitor
    from ..helpers import parse

    result = parse('a = yield from b').body[0]
    node = ast3.parse('a = yield from b')

    class Analyzer(Visitor):
        pass

    visitor = YieldFromTransformer(Analyzer())
    node = visitor.visit(node)
    # assert node is not None
    assert node.body[0] == result

# Generated at 2022-06-23 23:26:20.700808
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse as t_parse
    from typed_ast import ast3 as t_ast3
    from typed_astunparse import unparse as t_unparse
    # from astunparse import unparse as py_unparse
    code = t_parse(
        """
for i in range(3):
    try:
        yield from gen(i)
    except Exception as exc:
        print(exc)
""", mode='exec')
    YieldFromTransformer().visit(code)

# Generated at 2022-06-23 23:26:29.995971
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_helpers import check_node_equality

    expr = ast.parse('x = yield from y.z()')
    ast.fix_missing_locations(expr)

    new = YieldFromTransformer().visit(expr)
    expected = ast.parse('exc = None\niterable = iter(y.z())\n'
                         'while True:\n    try:\n        x = next(iterable)\n    '
                         'except StopIteration as exc:\n        x = exc.value\n'
                         '        break\n    except BaseException as exc:\n'
                         '        iterable.close()\n        raise exc\n'
                         'else:\n    iterable.close()')
    ast.fix_missing_locations(expected)

    assert check_node_equality(new, expected)

# Generated at 2022-06-23 23:26:35.166408
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    node = ast.Expr(value=ast.YieldFrom(value=ast.BinOp(left=ast.Name(id='a', ctx=ast.Load()),
                                                        op=ast.Add(),
                                                        right=ast.Constant(value=1, kind=None))))
    YieldFromTransformer().visit(node)
    # print(ast.dump(node))

# Generated at 2022-06-23 23:26:38.807200
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        mod = ast.parse("""
            def f(x):
                y = yield from x
                z = yield from x
                return 0
            """)
        tr = YieldFromTransformer()
        new_mod = tr.visit(mod)
        print(ast.dump(new_mod))
    except Exception as e:
        print(e)

# Generated at 2022-06-23 23:26:47.666517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import Source
    from .test_uncompyle import UncompyleBaseTestCase

    class TestYieldFromTransformer(UncompyleBaseTestCase):
        def test_yield_from(self):
            source = Source("""
                def test(arg):
                    yield from arg
                    a = yield from arg
                    foo(yield from arg)
                """)
            result = self.run_on_source(source, [YieldFromTransformer],
                                        {'target': (3, 2)})


# Generated at 2022-06-23 23:26:49.092136
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:26:58.916156
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from .test_BaseNodeTransformer import BaseNodeTransformerTestCase
    from typed_astunparse import unparse
    from typed_astunparse import dump

    class TestCase(BaseNodeTransformerTestCase):
        def test_YieldFromTransformer_visit(self):
            node = ast.parse(
                """def foo():
    yield from bar()"""
            )
            expected_node = ast.parse(
                """def foo():
    iterable = iter(bar())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            pass"""
            )
            node = YieldFromTransformer().visit(node)
            #dump(node)
            #dump(expected_node)

# Generated at 2022-06-23 23:27:09.503032
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('def foo():\n  yield from bar')
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)

    assert new_tree.body[0].body[0].body[0].body[0].target == ast.Name(id='exc',
                                                                       ctx=ast.Load())
    assert new_tree.body[0].body[0].body[0].body[2].target == ast.Name(id='exc',
                                                                       ctx=ast.Load())
    assert new_tree.body[0].body[0].body[0].body[0].value == ast.Str(s='exc')
    assert new_tree.body[0].body[0].body[0].body[2].value == ast.Str(s='exc')

#

# Generated at 2022-06-23 23:27:11.598514
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_transformer import assert_program_equal

# Generated at 2022-06-23 23:27:22.911120
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node1 = ast.parse("yield from test")
    node2 = ast.parse("yield from test")
    node3 = ast.parse("yield from test")
    node4 = ast.parse("yield from test")
    node5 = ast.parse("yield from test")
    node6 = ast.parse("yield from test")
    node7 = ast.parse("yield from test")
    node8 = ast.parse("yield from test")
    node9 = ast.parse("yield from test")
    node10 = ast.parse("yield from test")
    node11 = ast.parse("yield from test")
    node1.body[0].value = ast.Name("test", ast.Load())
    node2.body[0].value = ast.Name("test", ast.Load())
    node3

# Generated at 2022-06-23 23:27:24.507176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None



# Generated at 2022-06-23 23:27:31.351562
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import sample_tree, compile_snippet_demo
    from ..utils.tree import print_ast

    sample_tree[3].print()
    print_ast(compile_snippet_demo.get_ast(sample_tree[3]))
    print_ast(YieldFromTransformer().visit(sample_tree[3].tree))
    print_ast(sample_tree[3].tree)



# Generated at 2022-06-23 23:27:33.917053
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer."""
    v = YieldFromTransformer()
    assert v is not None

# Generated at 2022-06-23 23:27:35.513708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__init__(YieldFromTransformer, module=None)

# Generated at 2022-06-23 23:27:45.171848
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fake_ast import FakeAST

    tree = FakeAST(ast.Module,
                   body=[
                       FakeAST(ast.yield_from,
                               value=FakeAST(ast.Name, id='x')),
                       FakeAST(ast.Expr,
                               value=FakeAST(ast.yield_from,
                                             value=FakeAST(ast.Name, id='y'))),
                       FakeAST(ast.If,
                               body=[
                                   FakeAST(ast.yield_from,
                                           value=FakeAST(ast.Name, id='z'))
                               ]),
                   ])


# Generated at 2022-06-23 23:27:55.069763
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Initialization of class TreeTransformer
    transformer = YieldFromTransformer()
    assert transformer.tree is None
    assert transformer.changes == 0
    assert transformer._tree_changed is False
    assert transformer._tree_changed is False
    assert transformer.changes == 0
    # Tester of method _get_yield_from_index
    node = ast.parse('(a + 1 if a > 5 else b * 2) if c == 4 else d').body[0]
    assert transformer._get_yield_from_index(node, ast.If) is None
    node = ast.parse('yield from some_generator + 2').body[0]
    with pytest.raises(SyntaxError):
        transformer._get_yield_from_index(node, ast.Expr)
    # Tester of method _emulate_

# Generated at 2022-06-23 23:28:02.350638
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    program = """
try:
    yield from x
except Exception as e:
    pass
    """

    expected = """
try:
    let(iterable)
    iterable = iter(x)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                pass = exc.value
            break
except Exception as e:
    pass
    """

    node = ast.parse(program)
    YieldFromTransformer().visit(node)
    result = ast.unparse(node)
    print(result)
    assert result == expected

# Generated at 2022-06-23 23:28:11.274418
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import run_module
    from .. import adt

    source = "def f(x):\n    y = yield from x\n    return y"
    expected_output = "def f(x):\n    from typed_ast.ast3 import iter\n    exc = None\n    iterable = iter(x)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            if hasattr(exc, 'value'):\n                y = exc.value\n            break\n    return y"
    tree = run_module(source)
    YieldFromTransformer().visit(tree)
    output = adt.dump_tree(tree)
    assert output == expected_output

# Generated at 2022-06-23 23:28:13.628131
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    ast.parse("""def foo(something):\n    yield from something#""")


from ..tests.test_transformers import transform_and_compile


# Generated at 2022-06-23 23:28:20.721639
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_processor.ast_processor import ASTProcessor
    from ..utils.helpers import compare_ast
    from ..utils.fixtures import single_function_call_factory, insert_body, assert_suitable

    single_function_call = single_function_call_factory('yield_from(x)', 'yield from x')

# Generated at 2022-06-23 23:28:21.660012
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-23 23:28:22.803475
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:28:24.336068
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'visit')



# Generated at 2022-06-23 23:28:31.596232
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures.function import FUNCTION_YIELD_FROM_NESTED
    from ..utils.fixtures.module import MODULE_YIELD_FROM_NESTED

    result = YieldFromTransformer().visit(FUNCTION_YIELD_FROM_NESTED)
    assert isinstance(result, ast.FunctionDef)
    assert len(result.body) == 1
    assert isinstance(result.body[0], ast.While)

    result = YieldFromTransformer().visit(MODULE_YIELD_FROM_NESTED)

    assert isinstance(result, ast.Module)
    assert len(result.body) == 1
    assert isinstance(result.body[0], ast.FunctionDef)
    assert len(result.body[0].body) == 1

# Generated at 2022-06-23 23:28:37.572794
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import parse
    from .. import unparser
    from ..utils.helpers import identity_function

    code = identity_function.get_code()
    tree = parse(code)

    YieldFromTransformer().visit(tree)
    expected_tree = identity_function.get_tree()
    expected_code = identity_function.get_code()

    assert unparser.unparse(tree) == expected_code == identity_function.get_code()
    assert tree == expected_tree

# Generated at 2022-06-23 23:28:38.508793
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	assert(YieldFromTransformer())

# Generated at 2022-06-23 23:28:40.146223
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import make_tree, test_transformer

# Generated at 2022-06-23 23:28:47.683172
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test for using yield from inside function with return
    function_with_return = ast.parse("""
    def foo():
        yield from sub_function()
        return Bar
    """)
    expected_function_with_return = ast.parse("""
    def foo():
        let(iterable)
        iterable = iter(sub_function())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
        return Bar""")

    assert YieldFromTransformer().visit(function_with_return) == expected_function_with_return

    # Test for using yield from inside function without return

# Generated at 2022-06-23 23:28:55.164591
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap
    from ..transformers.base import BaseNodeTransformer

    class Dummy(BaseNodeTransformer):
        def visit_YieldFrom(self, node):
            return "Dummy"

    text = textwrap.dedent('''
    def gen():
        yield_from g()
    ''')
    tree = ast.parse(text)
    node = YieldFromTransformer().visit(tree)
    code = astor.to_source(node)
    print(code)
    assert code == textwrap.dedent('''
    def gen():
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    '''), "YieldFrom test failed"

# Generated at 2022-06-23 23:29:04.496468
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from .fix_missing_locations import FixMissingLocationsTransformer

    tree = source('from typing import List\n'
                  'def f():\n'
                  '    yield from g()\n'
                  '    if True:\n'
                  '        yield from g()\n'
                  '    while True:\n'
                  '        yield from g()\n'
                  '    for x in l:\n'
                  '        yield from g()\n'
                  '    print((yield from g()))\n'
                  '    _ = yield from g()\n'
                  '    [yield from g()]\n'
                  '    {yield from g()}\n'
                  '    yield from g()\n')


# Generated at 2022-06-23 23:29:15.435300
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from astor.code_gen import to_source
    from ..utils import ast_parse
    source = '''
    def function():
        yield from [1, 2, 3]
        a = yield from [4, 5, 6]
        b, c = yield from [7, 8, 9]
        yield from [10, 11, 12]
        print(a)
    '''
    transformed = YieldFromTransformer.run_pipeline(ast_parse(source))

# Generated at 2022-06-23 23:29:19.044966
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import UnitTest
    ut = UnitTest()
    from ..utils.ast_importer import AstImporter
    ut.test(YieldFromTransformer, AstImporter, "yield_from")

# Generated at 2022-06-23 23:29:28.224998
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.python import get_ast
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 23:29:39.209579
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from pytypeutils import assert_equivalent_types
    from typed_ast import ast3 as ast

    @assert_equivalent_types
    def check(source, expected):
        # type: (str, str) -> None
        tree = ast.parse(source)
        transformer = YieldFromTransformer()
        tree = transformer.visit(tree)
        assert expected == ast.dump(tree)

    check('''
x = (yield from [])
    ''', '''
Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='__compiled_yield_from_1', ctx=Load()), args=[List(elts=[], ctx=Load())], keywords=[]))])
    ''')


# Generated at 2022-06-23 23:29:49.598333
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast, typing
    from astmonkey import transformers, utils
    from astmonkey.visitors import BaseNodeTransformer

    # Unit test for method _get_yield_from_index
    class Test_get_yield_from_index(BaseNodeTransformer):
        # Unit test for method _get_yield_from_index
        def _get_yield_from_index(self, node: ast.AST,
                                  type_: Type[Holder]) -> Optional[int]:
            return YieldFromTransformer._get_yield_from_index(
                self,
                node,
                type_
            )

    # Unit test for method _emulate_yield_from

# Generated at 2022-06-23 23:29:58.641188
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_suite import run_python_program

    program = """
    example = [1, 2, 3]
    y = yield from example
    """
    expected_program = """
    example = [1, 2, 3]
    
    def yield_from_transformed_0():
        let(iterable_0)
        iterable_0 = iter(example)
        while True:
            try:
                yield next(iterable_0)
            except StopIteration as exc_0:
                if hasattr(exc_0, 'value'):
                    y = exc_0.value
                break
    
    for x in yield_from_transformed_0():
        pass
    """
    ast_output, _ = run_python_program(program, YieldFromTransformer)
    assert ast_output == expected

# Generated at 2022-06-23 23:30:05.332586
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    class A(YieldFromTransformer): target = (3, 8)
    a = A()
    o = ast.parse('a = yield from iter(range(10))')
    a.visit(o)
    assert o.body == ast.parse('a = iter(range(10))\nwhile True:\n    try:\n        yield next(a)\n    except StopIteration as exc:\n        a = exc.value\n        break').body

# Generated at 2022-06-23 23:30:15.632692
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()



# Generated at 2022-06-23 23:30:16.649225
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer.__init__()

# Generated at 2022-06-23 23:30:18.063060
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x is not None


# Generated at 2022-06-23 23:30:19.583967
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse


# Generated at 2022-06-23 23:30:29.446734
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""
    from astor.codegen import to_source

    if sys.version_info < (3,3): return

    def test_yield_from(input: str, expected: str) -> None:
        """Unit test function for yield from expression."""
        tree = ast.parse(input)
        YieldFromTransformer().visit(tree)
        assert to_source(tree) == expected

    test_yield_from("""
        def f():
            yield from g()
    """, """
        def f():
            let(iterable)
            iterable = iter(g())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """)


# Generated at 2022-06-23 23:30:34.522103
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class CustomTransformer(YieldFromTransformer):
        def visit_Module(self, node):
            return self.generic_visit(node)

        def visit_FunctionDef(self, node):
            return self.generic_visit(node)

        def visit_Return(self, node):
            raise Exception

    class ModuleTransformer(CustomTransformer):
        def visit_Module(self, node):
            return self.generic_visit(node)


# Generated at 2022-06-23 23:30:38.822500
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    module = ast.parse('''def f():
        a = yield from a
        yield from a
        yield from b
        yield from b
    ''')
    transformer = YieldFromTransformer()
    transformer.visit(module)

    assert module.body[0].body[0].targets[0].id == 'a'
    assert module.body[0].body[1].targets[0].id == 'b'
    assert module.body[0].body[2].targets[0].id == 'b'

# Generated at 2022-06-23 23:30:43.544281
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    try_ = ast.Try(
        body=[ast.Expr(value=ast.YieldFrom(value=ast.Call(func=ast.Name(id='foo', ctx=ast.Load()), args=[], keywords=[]))),
              ast.Return(value=ast.Num(n=2))],
        finalbody=[],
        handlers=[],
        orelse=[]
    )

    tree = ast.Module(
        body=[try_]
    )

    YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:30:45.070736
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_ = YieldFromTransformer()
    meth = class_.visit
    assert meth

# Generated at 2022-06-23 23:30:54.381632
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Testing assignment case
    tree = ast.parse('a = yield from [1, 2, 3] + x')
    expected_tree = 'a = (yield_from(iter([1, 2, 3] + x)))'
    transformer = YieldFromTransformer()
    result = transformer.visit(tree)
    assert astor.to_source(result) == expected_tree

    # Testing expression case
    tree = ast.parse('yield from [1, 2, 3]')
    expected_tree = '(yield_from(iter([1, 2, 3])))'
    transformer = YieldFromTransformer()
    result = transformer.visit(tree)
    assert astor.to_source(result) == expected_tree

    # Testing expression case inside while

# Generated at 2022-06-23 23:30:55.265046
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import ast

# Generated at 2022-06-23 23:31:03.803894
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast, unittest
    class TestCase(unittest.TestCase):
        def test(self):
            source = """
            def func():
                x = f()
                while True:
                    y = yield from g()
                    y += 1
            """
            tree = ast.parse(source)
            transformer = YieldFromTransformer()
            transformed_tree = transformer.visit(tree)
            expected = """
            def func():
                x = f()
                while True:
                    let(iterable)
                    iterable = iter(g())
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            if hasattr(exc, 'value'):
                                y = exc.value
                            break
                    y += 1
            """
            expected_tree