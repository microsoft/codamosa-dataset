

# Generated at 2022-06-23 23:21:07.095119
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.ast_builder import build

    tree = build('''
        def foo(a):
            yield from bar()
    ''')

    node = YieldFromTransformer().visit(tree)
    print(node)



# Generated at 2022-06-23 23:21:16.041600
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # pylint: disable=too-many-locals
    from ..test.test_transformer import transform

    def test_yield_from_1():
        def f():
            x = yield from [1, 2, 3]
            y = yield from (x for x in range(4))

        return transform(f, YieldFromTransformer)

    def test_yield_from_2():
        def f():
            yield from [1, 2, 3]
            yield from (x for x in range(4))

        return transform(f, YieldFromTransformer)

    test_yield_from_1.__name__ = 'f'
    test_yield_from_2.__name__ = 'f'


# Generated at 2022-06-23 23:21:22.189447
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

    transformer = YieldFromTransformer()
    root = ast.Module()

# Generated at 2022-06-23 23:21:23.048716
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer('YieldFromTransformer')

# Generated at 2022-06-23 23:21:24.978504
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert isinstance(t, YieldFromTransformer)

# Generated at 2022-06-23 23:21:34.430631
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import re, unittest
    from ..utils.helpers import get_transformed_tree, get_tree
    from .test_builtins_access import test_BuiltinsAccessTransformer_visit
    from .test_exceptions import test_ExceptionsTransformer_visit
    from .test_try_except_else import test_TryExceptElseTransformer_visit
    from .test_yield import test_YieldTransformer_visit


# Generated at 2022-06-23 23:21:35.412484
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:21:44.034484
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test import assert_tree_unchanged, assert_tree_equal, transform

    result = transform(YieldFromTransformer,
                       'x = yield from (y for y in z)')
    assert_tree_unchanged(result,
                          'x = yield from (y for y in z)',
                          'yield from (y for y in z), x = _')

    assert_tree_equal(result,
                      'x = yield from (y for y in z)',
                      'while True:\n'
                      '    try:\n'
                      '        _ = next(iter((y for y in z)))\n'
                      '        yield _\n'
                      '    except StopIteration as exc:\n'
                      '        x = exc.value\n'
                      '        break')

    assert_tree_

# Generated at 2022-06-23 23:21:44.617435
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:51.526569
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import example

    class Test(YieldFromTransformer):
        def visit_Assign(self, node: ast.Assign) -> ast.Assign:
            if isinstance(node.value, ast.YieldFrom):
                node.value.value = ast.Name(id='test', ctx=ast.Load())
            return node

    node = astor.parse_file(example('yield_from'))
    Test().visit(node)

# Generated at 2022-06-23 23:21:52.146213
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-23 23:21:53.597869
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft is not None
    assert yft._tree_changed is False


# Generated at 2022-06-23 23:21:54.877027
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None


# Generated at 2022-06-23 23:21:56.857461
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft is not None

# Unit tests for functions in YieldFromTransformer

# Generated at 2022-06-23 23:22:01.422265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    import io
    import contextlib
    @contextlib.contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = io.BytesIO()
        yield
        sys.stdout = save_stdout
    with nostdout():
        assert __name__ == "__main__"

# Generated at 2022-06-23 23:22:04.366434
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_test_case import ASTTestCase
    from py_mini_racer import py_mini_racer
    import ast
    import antlr4
    from SastBuilder import SastBuilder


# Generated at 2022-06-23 23:22:08.883085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    debug_objects = []
    # Test non-existent yield_string
    try:
        YieldFromTransformer(debug_objects)
    except Exception as e:
        assert type(e) == NotImplementedError
    # Test real yield_string
    c = YieldFromTransformer(debug_objects)
    return c

# Generated at 2022-06-23 23:22:12.989626
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    @snippet
    def test():
        def generator():
            yield 1

        def gen():
            yield from generator()

        a = yield from generator()
        yield from generator()
        return a

    check_transformation(YieldFromTransformer, test.get_tree(), test.get_result())


# Generated at 2022-06-23 23:22:18.085847
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transformers.unpack_inherited_defs import UnpackInheritedDefsTransformer
    from ..transformers.reduce_parentheses import ReduceParenthesesTransformer
    from ..transformers.decorator_to_decorator_def import DecoratorToDecoratorDefTransformer
    from ..transformers.dedent import DedentTransformer
    from ..transformers.check_syntax import CheckSyntaxTransformer
    from ..transformers.remove_unused_imports import RemoveUnusedImportsTransformer
    from ..transformers.let_keywords_be_last_in_call import LetKeywordsBeLastInCallTransformer
    from ..transformers.remove_unused_variables import RemoveUnusedVariablesTransformer
    from ..transformers.remove_unused_imports import RemoveUnusedImportsTransformer


# Generated at 2022-06-23 23:22:27.461181
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor as astor

    old_tree = ast.parse('''
        def test(l: list):
            a = b = 1

            b = yield from l

            c = 1
            c = yield from l

            return c
    ''')

# Generated at 2022-06-23 23:22:36.233862
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from .test_base import NodeTestCase

    class TestCase(NodeTestCase):
        @staticmethod
        def _get_node(text: str) -> ast.AST:
            return ast.parse(textwrap.dedent(text))

        def test_yield_from_in_expression(self):
            with self.subTest('with yield from in expression'):
                text = '''
                def x():
                    yield from a
                '''
                expected = '''
                def x():
                    iterable = iter(a)
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            break
                '''
                self.assert_node(text, expected)


# Generated at 2022-06-23 23:22:46.152714
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    generator = "def I(x): yield from x"
    snippet1 = "def I(x): return list(x)"
    snippet2 = "def I(x): yield from x; return list(x)"
    snippet3 = "def I(x): yield from x; return list(x); yield from x"
    snippet4 = "def I(x): x = yield from x; return list(x)"
    snippet5 = "def I(x): x = yield from x; return list(x); yield from x"
    snippet6 = "def I(x): yield from x; x = yield from x"

    snippets = [snippet1, snippet2, snippet3, snippet4, snippet5, snippet6]
    for snippet in snippets:
        assert snippet == compile(generator, '', 'exec').co_consts[0]
        node

# Generated at 2022-06-23 23:22:47.164503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert bool(YieldFromTransformer)



# Generated at 2022-06-23 23:22:47.706796
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-23 23:22:48.516231
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:49.412280
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:52.934463
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import assert_fresh_tree

    def test_case(tree):
        tree = YieldFromTransformer().visit(tree)
        assert_fresh_tree(tree, tree)

    test_case(ast.parse('def foo():\n    a = yield from bar()\n    b = foo.bar'))

# Generated at 2022-06-23 23:22:54.090859
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.target == (3, 2)


# Generated at 2022-06-23 23:22:56.966307
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import test
    import astor
    code = """
    def func():
        yield from [1, 2, 3, 4]
    """
    tree = ast.parse(code)
    res = astor.to_source(tree)

# Generated at 2022-06-23 23:22:59.468121
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet = yield_from.get_body(generator='generator',
                                    assignment='assignment',
                                    exc='exc')
    out = YieldFromTransformer().visit(snippet)
    assert isinstance(out, ast.While)


# Generated at 2022-06-23 23:23:07.974121
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()
    module = ast.parse("""
    def foo():
        yield from iterable
        a = yield from iterable
        yield from iterable
        yield from iterable
        a = 1
        yield from iterable
        yield from iterable
    """)

# Generated at 2022-06-23 23:23:17.340143
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    if sys.version_info[0:2] != (3, 7):
        import pytest
        pytest.skip("Skipped for non-3.7 version")

    tree = ast.parse("""
a = yield from foo()
""")
    result_tree = ast.parse("""
let(iterable)
iterable = iter(foo())
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        a = exc.value
        break
""")
    transformer = YieldFromTransformer()
    result = transformer.visit(tree)
    print(ast.dump(result))
    assert ast.dump(result) == ast.dump(result_tree)


# Generated at 2022-06-23 23:23:18.229029
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:23:21.948657
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import transformed_from_str, compare
    from ..utils.source import Source

    source = Source("""a = yield from f(1)""")
    result = transformed_from_str(source, YieldFromTransformer)

# Generated at 2022-06-23 23:23:23.477444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()

## Unit test for visit of class YieldFromTransformer

# Generated at 2022-06-23 23:23:26.971111
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transpile import Transpiler
    from ..tests.test_fixtures.simple_generator_test import module
    t = Transpiler()
    t.register_transformers(YieldFromTransformer)
    transpiled = t.visit(module)
    assert __file__.split('/')[-1] in transpiled.code

# Generated at 2022-06-23 23:23:29.137484
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from contextlib import suppress
    from ..transpile import transpile_code


# Generated at 2022-06-23 23:23:34.860839
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test import get_test_file
    from .ast_transformer import make_transformer, transform_file
    from .yield_from import YieldFromTransformer
    mod = get_test_file(__file__, 'yield_from.test')
    transformer = make_transformer(YieldFromTransformer)
    code = transform_file(transformer, mod)

# Generated at 2022-06-23 23:23:40.584874
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    import typed_astunparse
    from typed_astunparse import ast3
    from ..utils.helpers import wrap_to_function

    from ..utils.constants import INDENT

    node = wrap_to_function("a = yield from [i for i in range(5)]")
    ast.fix_missing_locations(node)
    node = YieldFromTransformer().visit(node)
    code = typed_astunparse.unparse(node)

# Generated at 2022-06-23 23:23:42.015814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft._tree_changed == False

# Generated at 2022-06-23 23:23:45.403733
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseTestTransformer

    class TestYieldFromTransformer(BaseTestTransformer):
        transformer = YieldFromTransformer

    TestYieldFromTransformer.test_codec('yield_from')

# Generated at 2022-06-23 23:23:57.057319
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_code_equal, parse_to_ast, compile_back
    from ..utils.helpers import gen_name

    node = parse_to_ast("""
        class A:
            async def foo(self, b) -> None:
                x = yield from bar(b)
                y = yield from bar(b)
                z = yield from bar(b)
        """)
    codegen = YieldFromTransformer()
    tree = codegen.visit(node)

# Generated at 2022-06-23 23:23:57.700545
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:24:01.985891
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    import astor
    example = inspect.getsource(YieldFromTransformer.visit)
    example = ast.parse(example)
    compiled = YieldFromTransformer().visit(example)
    print(astor.to_source(compiled))

# Generated at 2022-06-23 23:24:03.062121
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:24:03.961196
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # TODO: Implement test.
    ...

# Generated at 2022-06-23 23:24:08.987299
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import parse
    transformer = YieldFromTransformer()
    code = 'def f(a): return (yield from a)'
    node = parse(code)
    transformed = transformer.visit(node)
    expected = 'def f(a):\n    let(iterable)\n    iterable = iter(a)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            break'
    assert expected == transformed.body[0].body[0]

# Generated at 2022-06-23 23:24:09.860141
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:10.942347
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:15.321418
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transpiler = YieldFromTransformer()
    code = """

async def func():
    async_res = await some()
    return async_res
"""
    tree = ast.parse(code)
    transpiler.visit(tree)
    assert str(transpiler) == "YieldFromTransformer"

# Generated at 2022-06-23 23:24:17.091508
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None


# Generated at 2022-06-23 23:24:22.916898
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    from ..inplace_transformer import InplaceTransformer
    from ..utils.helpers import dump
    from ..transformers.yield_from import YieldFromTransformer
    def test_parse(code):
        tree = parse(code)
        YieldFromTransformer().visit(tree)
        return InplaceTransformer.run(tree)

    # Tests

# Generated at 2022-06-23 23:24:23.950115
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:24:26.153897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert isinstance(yield_from_transformer, YieldFromTransformer)
    assert yield_from_transformer.target == (3, 2)


# Generated at 2022-06-23 23:24:36.143118
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.generic_test import generic_test
    from ..utils.helpers import VariablesGenerator, get_ast

    test_cases = [
        (
            "from typing import List\n"
            "def test(a):\n"
            "  l: List[int] = [1, 2]\n"
            "  yield from l\n"
            "  i: int = yield from l\n"
            "  yield from range(3)\n",
        ),
    ]

    def create_transformer(target):
        return YieldFromTransformer(target)

    generic_test(test_cases, create_transformer,
                 (YieldFromTransformer, ),
                 VariablesGenerator, get_ast,
                 __file__, True)

# Generated at 2022-06-23 23:24:38.782929
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Testing for YieldFromTransformer class
    # create instance of YieldFromTransformer
    a = YieldFromTransformer()
    # create instance of ast tree
    b = ast.parse('a = b')
    a.visit(b)

# Generated at 2022-06-23 23:24:40.756939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.test_node_transformers import construct_YieldFromTransformer
    construct_YieldFromTransformer()



# Generated at 2022-06-23 23:24:48.898643
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    from flake8_typing_imports.visitors.base import BaseNodeTransformer
    from .common import BaseTestTransformerMixin, sample_code

    class TestYieldFromTransformer(YieldFromTransformer,
                                   BaseTestTransformerMixin):
        pass

    code = sample_code(
        '''
        def test_yield_from(iterator):
            target = yield from iterator
        '''
    )

    result = TestYieldFromTransformer.run_on_code(code)

# Generated at 2022-06-23 23:24:50.757160
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert repr(YieldFromTransformer) == (
        'YieldFromTransformer()')


# Generated at 2022-06-23 23:25:00.377014
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import get_node
    from ..utils.visitor import get_visit_function
    from .testing import compare_nodes, compare_source_code

    source = """
    async def example():
        x = await foo()
        y = yield from bar()
        z = await baz()
    """
    expected_source = """
    async def example():
        x = await foo()
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    y = exc.value
                break
        z = await baz()
    """
    node = get_node(source, 3)

# Generated at 2022-06-23 23:25:11.025355
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import parse, run_on_single_file, strip_source
    from ..utils.helpers import get_node
    from ..utils.codegen import to_source

    source = """
a = yield from b
yield from c
    """
    expected = """
let(iterable)
iterable = iter(b)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break
let(iterable)
iterable = iter(c)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        break
    """

    node = get_node(source, version='3.3')

# Generated at 2022-06-23 23:25:16.208246
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from ..utils.snippet import snippet
    from ..transformers import YieldFromTransformer

    @snippet
    def snippet():
        let(val)
        val = yield from range(0, 3)

    node = ast.parse(snippet)
    transformer = YieldFromTransformer()
    node = transformer.visit(node)
    assert not transformer.changed
    assert astunparse.unparse(node).strip() == snippet.strip()



# Generated at 2022-06-23 23:25:17.255878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:25:19.790926
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor


# Generated at 2022-06-23 23:25:20.841116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:25:31.083273
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:34.993665
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import transform

    source = '''
    def f():
        yield from []
    
    '''
    expected_source = '''
    def f():
        let(iterable)
        iterable = iter(iter([]))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc0:
                if hasattr(exc0, 'value'):
                    exc0 = exc0.value

                break

    '''
    @transform(YieldFromTransformer)
    def f():
        yield from []

    assert f.__source__ == expected_source



# Generated at 2022-06-23 23:25:37.225006
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)


# Generated at 2022-06-23 23:25:39.488547
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)


# Generated at 2022-06-23 23:25:41.978640
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test YieldFromTransformer constructor works."""
    assert hasattr(YieldFromTransformer, '_handle_assignments')

# Generated at 2022-06-23 23:25:42.963030
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:25:45.669243
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Unit test for constructor of class YieldFromTransformer
    YieldFromTransformer_instance = YieldFromTransformer()
    assert isinstance(YieldFromTransformer_instance, YieldFromTransformer)


# Generated at 2022-06-23 23:25:53.913666
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    ast_tree_1 = ast.parse('def foo():\n'
                           '    a = yield from gen()', mode='exec')
    ast_tree_2 = ast.parse('def foo():\n'
                           '    yield from gen()', mode='exec')
    ast_tree_3 = ast.parse('def foo():\n'
                           '    yield from [x for x in range(10)]', mode='exec')
    ast_tree_4 = ast.parse('def foo():\n'
                           '    yield from (x for x in range(10))', mode='exec')
    ast_tree_5 = ast.parse('def foo():\n'
                           '    yield from (m[:3] for m in map(str, range(10)))', mode='exec')

    tree_1 = YieldFrom

# Generated at 2022-06-23 23:25:55.786003
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.cli import compile_snippets
    compile_snippets(__file__)

# Generated at 2022-06-23 23:26:00.745790
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import run_to_ast

    tree = run_to_ast('''\
    def iterator():
        yield from [1, 2, 3]
    ''')
    YieldFromTransformer().visit(tree)
    assert 'yield from' not in str(tree)



# Generated at 2022-06-23 23:26:10.272624
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

    class Visitor(ast.NodeVisitor):
        def __init__(self, transformer: YieldFromTransformer):
            self.transformer = transformer
        def visit_Try(self, node: ast.Try):
            return self.transformer.visit(node)
        def visit_If(self, node: ast.If):
            return self.transformer.visit(node)
        def visit_While(self, node: ast.While):
            return self.transformer.visit(node)
        def visit_For(self, node: ast.For):
            return self.transformer.visit(node)
        def visit_FunctionDef(self, node: ast.FunctionDef):
            return self.transformer.visit(node)

# Generated at 2022-06-23 23:26:20.852062
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test(s1, expected):
        module = ast.parse(s1)
        module = YieldFromTransformer().visit(module)
        module = ast.fix_missing_locations(module)
        s2 = compile(module, "<test>", "exec")
        assert s2 == expected
        exec(s2)
    
    test(  # noqa
        """
        def f(x):
            while True:
                yield from x
        """,
        """
        def f(x):
            iterable = iter(x)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """
    )
    

# Generated at 2022-06-23 23:26:30.105472
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..base import BaseCompiler
    from ..visitor import Visitor
    class Visitor(Visitor): pass
    class ClassCompiler(BaseCompiler):
        def transform(self, tree: ast.AST) -> ast.AST:
            return YieldFromTransformer(self).visit(tree)
        def get_visitor(self): return Visitor
    cc = ClassCompiler()
    tree = cc.compile_code("""def foo():\n yield from (i for i in range(10))""").body[0]

# Generated at 2022-06-23 23:26:31.031964
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()
    asse

# Generated at 2022-06-23 23:26:31.961351
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer



# Generated at 2022-06-23 23:26:32.897961
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()

# Generated at 2022-06-23 23:26:33.986626
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse  # type: ignore


# Generated at 2022-06-23 23:26:37.969493
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor  # type: ignore
    tree = ast.parse('(x + 3) * 4')
    expected = ast.parse('(x + 3) * 4')
    trans = YieldFromTransformer()
    trans.visit(tree)
    assert astor.to_source(tree) == astor.to_source(expected)

# Generated at 2022-06-23 23:26:39.767701
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is YieldFromTransformer
# test_YieldFromTransformer()

# Generated at 2022-06-23 23:26:47.351034
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import textwrap
    from ..utils import generate_code
    from ..parser import PythonToPythonParser

    class YieldFromTransformerTestCase(unittest.TestCase):
        def _test(self, code_before, code_after):
            parser = PythonToPythonParser(code_before)
            parser.parse()
            tree = parser.ast

            transformer = YieldFromTransformer()
            tree = transformer.visit(tree)

            generator = generate_code(tree)
            source = ''.join(generator)

            self.assertEqual(textwrap.dedent(code_after), source)


# Generated at 2022-06-23 23:26:48.265669
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:26:53.354514
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .python_snippets import yf
    yf_ast = ast.parse(yf)
    YieldFromTransformer().visit(yf_ast)
    compiled = compile(yf_ast, '<string>', 'exec')
    out = {}
    exec(compiled, out)
    assert out['test']() == [5, 2, 3, 2]

# Generated at 2022-06-23 23:26:54.556666
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_transformed


# Generated at 2022-06-23 23:26:55.538658
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer



# Generated at 2022-06-23 23:27:02.970369
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from pytest import raises

    from typed_ast.ast3 import parse
    from .ast_transformer import ASTTransformer
    from .from_raise_to_assert import FromRaiseToAssertTransformer
    from .none_comparison import NoneComparisonTransformer
    from .raise_comparison import RaiseComparisonTransformer
    from .unused_raise import UnusedRaiseTransformer
    from .base import PythonNodeTransformer

    def transform(code):
        tree = parse(code)
        t1 = ASTTransformer().visit(tree)
        t2 = FromRaiseToAssertTransformer().visit(t1)
        t3 = RaiseComparisonTransformer().visit(t2)
        t4 = NoneComparisonTransformer().visit(t3)

# Generated at 2022-06-23 23:27:09.036278
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from astor import to_source
    from ..utils.fix_python3_unittest import FixPython3Unittest

    BaseNodeTransformer.patch_ast()
    s = """def func():
    a = yield from range(10)
    yield a"""

    tree = ast.parse(s)
    t = YieldFromTransformer()
    t.visit(tree)

# Generated at 2022-06-23 23:27:15.347129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj._tree_changed == False
    assert obj._get_yield_from_index("",3) == None
    assert obj._emulate_yield_from("","") == []
    assert obj._handle_assignments("") == ""
    assert obj._handle_expressions("") == ""
    assert obj.visit("") == ""
    assert obj.visit_TryExcept("") == ""
    assert obj.visit_ExceptHandler("") == ""
    assert obj.visit_Raise("") == ""

# Generated at 2022-06-23 23:27:20.078068
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_helpers import convert
    from .yield_transformer import YieldTransformer

    source = """
        for x in range(10):
            y = yield from gen()
    """
    expected = """
        def gen():
            yield from gen()
    """
    tree = convert(source)
    YieldFromTransformer().visit(tree)
    assert convert(expected) == tree
    YieldTransformer().visit(tree)
    # TODO: Test this
    # assert convert(expected) == tree

# Generated at 2022-06-23 23:27:21.246755
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:33.179251
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = '''
        def callable():
            x = yield from range(10)
            yield from range(x)
            a = yield from (x for x in range(x))
    '''
    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    result = transformer.visit(tree)

# Generated at 2022-06-23 23:27:37.793512
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = 'a = yield from [1];'
    expected = 'exc = None; iterable = iter([1]); while True: try: a = next(iterable); except StopIteration as exc: break;'
    compile_and_assert(code, expected, target=(3, 2))


# Generated at 2022-06-23 23:27:48.044491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile_with_transforms
    from ..utils.test_utils import assert_script_execution
    from ..utils.test_utils import assert_script_ok
    from ..utils.test_utils import assert_script_runs
    from ..utils.test_utils import source_exec

    assert source_exec('''
        def generator():
            yield 1
            yield 2
            yield 3

        def foo():
            yield from generator()

        print(foo())
    ''')
    assert_script_runs('''
        def generator():
            yield 1
            yield 2
            yield 3
        def foo():
            yield from generator()
        print(foo())
    ''')

# Generated at 2022-06-23 23:27:49.066468
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): 
    YieldFromTransformer()

# Generated at 2022-06-23 23:27:58.468595
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('a = yield from b')
    transformer = YieldFromTransformer()
    transformer.visit(node)
    assert ast.dump(node) == \
        "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='next', ctx=Load()), args=[Call(func=Name(id='iter', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[])], keywords=[]))])"

    node = ast.parse('yield from b')
    transformer = YieldFromTransformer()
    transformer.visit(node)

# Generated at 2022-06-23 23:27:59.371932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()


# Generated at 2022-06-23 23:28:02.010526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import transform
    from .test_originals import yield_from_orig as tree
    trans = transform(YieldFromTransformer, tree)
    trans.visit(tree)

# Generated at 2022-06-23 23:28:04.258403
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    e = YieldFromTransformer()
    assert isinstance(e, YieldFromTransformer)
    assert isinstance(e, BaseNodeTransformer)

# Generated at 2022-06-23 23:28:13.966268
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source


# Generated at 2022-06-23 23:28:14.934346
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()

# Generated at 2022-06-23 23:28:24.428118
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    # Unit test for method visit of class YieldFromTransformer
    class TestYieldFromTransformer(BaseNodeTransformer):
        def _get_yield_from_index(self, node: ast.AST,
                                  type_: Type[Holder]) -> Optional[int]:
            if hasattr(node, 'body') and isinstance(node.body, list):  # type: ignore
                for n, child in enumerate(node.body):  # type: ignore
                    if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                        return n

            return None

        def _emulate_yield_from(self, target: Optional[ast.AST],
                                node: ast.YieldFrom) -> List[ast.AST]:
            exc = VariablesGenerator.generate('exc')


# Generated at 2022-06-23 23:28:29.158535
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures import some_function_def, some_try_finally
    from .. import compile_source, replace_helper

    code_src = """
        def foo():
            a = yield from b
            yield from c
    """

    from ..utils.fixtures import sample_yield_from_transformer_3
    sample_yield_from_transformer_3(code_src)


# Generated at 2022-06-23 23:28:36.820061
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Test  YieldFromTransformer against correct code."""
    from ..utils.run2 import to_source
    code = """
    def generate():
        try:
            yield from range(10)
        except GeneratorExit:
            print('exit')
    """
    module = ast.parse(code)
    tr = YieldFromTransformer()
    tr.visit(module)
    source = to_source(tr.root)
    print(source)


if __name__ == '__main__':
    test_YieldFromTransformer_visit()

# Generated at 2022-06-23 23:28:38.416270
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert(t is not None)


# Generated at 2022-06-23 23:28:47.931534
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tree_compare import equal_trees

    # Test non-changed tree

# Generated at 2022-06-23 23:28:58.246938
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...tests.testing_mixin import ReplaceAssignmentsTestingMixin

    class Test(ReplaceAssignmentsTestingMixin):
        TRANSFORMER = YieldFromTransformer

        @property
        def code(self) -> str:
            return """
            def function():
                yield from range(10)
                if True:
                    yield from range(10)
                while True:
                    yield from range(10)
                    try:
                        yield from range(10)
                    finally:
                        yield from range(10)
                    for _ in range(10):
                        yield from range(10)
            """


# Generated at 2022-06-23 23:28:58.884814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:29:05.068856
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import setup_test_env

    code = """
try:
    yield from func1()
except StopIteration as exc:
    result = exc.value
    """
    tree = setup_test_env(code, YieldFromTransformer)


# Generated at 2022-06-23 23:29:16.128243
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def visit(code: str) -> str:
        node = ast.parse(code)  # type: ignore
        YieldFromTransformer().visit(node)
        return ast.unparse(node)

    assert visit('yield from a') == (
        '{\n'
        '    exc = None\n'
        '    iterable = iter(a)\n'
        '    while True:\n'
        '        try:\n'
        '            yield next(iterable)\n'
        '        except StopIteration as exc:\n'
        '            break\n'
        '}'
    )


# Generated at 2022-06-23 23:29:20.000139
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def test_0():
        try:
            pass
        except:
            pass
        return None
    YieldFromTransformer(test_0)


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:29:21.844974
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    m = ast.Module()
    c = ast.ClassDef()
    YieldFromTransformer(m, c)

# Generated at 2022-06-23 23:29:23.253638
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:30.947534
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    context = ast.parse('def a():\n'
                        '    yield from x\n'
                        '    yield from y.z\n'
                        '    a = yield from x\n'
                        '    b = x, yield from y.z')

# Generated at 2022-06-23 23:29:41.650631
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast
    from .base import BaseNodeTransformerTest

    def perform_test(self, node_class, expected):
        node = node_class()
        node = self.perform_visit(node)
        self.assertEqual(expected, ast.dump(node))

    class TestYieldFromTransformer(BaseNodeTransformerTest):

        transformer = YieldFromTransformer

        def test__get_yield_from_index(self):
            node = ast.While(ast.Compare(ast.Num(5), [], [ast.Num(3)]))
            self.assertIsNone(self.perform__get_yield_from_index(
                node, ast.Expr))

            node_body = [ast.Expr(ast.YieldFrom(ast.Num(5)))]
            node = ast.While

# Generated at 2022-06-23 23:29:51.912441
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_astunparse import unparse
    from ..utils.macros import import_typed_ast, declare_types

    import_typed_ast()

    @declare_types('ast.Module')
    class T(YieldFromTransformer):
        pass

    node = ast.parse("""
a = yield from [1, 2, 3]
yield from (yield from [1, 2, 3])
""")

# Generated at 2022-06-23 23:30:00.011416
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import Snippet, NodeTransformerSnippet, snippet_test
    from typed_ast import ast3 as ast

    class TestNodeTransformer(NodeTransformerSnippet[YieldFromTransformer]):
        def __init__(self):
            super().__init__(YieldFromTransformer)

    let(snippet)
    snippet = Snippet[Union[ast.Module, ast.FunctionDef]]()

    @snippet
    def test_assign():
        let(a)
        a = 1
        yield from b

        return a

    @snippet
    def test_expr():
        yield from b

    @snippet
    def test_assign_multiple():
        let(a, b)
        a = 1
        b = 2
        yield from c

        return a,

# Generated at 2022-06-23 23:30:07.110654
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test the method visit of class YieldFromTransformer
    with open('partridge/tests/samples/yieldfrom.py') as py_file:
        result = ast.parse(py_file.read())
    visitor = YieldFromTransformer()
    result = visitor.visit(result)
    with open('partridge/tests/samples/yieldfrom-result.py') as py_file:
        expected = ast.parse(py_file.read())
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 23:30:10.033752
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("a = yield from [1, 2, 3]")
    YieldFromTransformer().visit(node)

# Generated at 2022-06-23 23:30:20.180485
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from asttokens import ASTTokens
    from ..fixtures import yield_from
    from ..utils.helpers import print_ast
    from textwrap import dedent

    source = dedent("""
    def foo():
        a = yield from b
        b = yield from c
        yield from d
    """)
    tree = yield_from.parse(source)
    transformed = YieldFromTransformer().visit(tree)


# Generated at 2022-06-23 23:30:28.268458
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import (
        parse,
        ast3
    )
    from typed_ast import types
    from .base import BaseNodeTransformerTest
    from .base import compile_snippets
    tree = parse('def f(x: list):\n    yield from x[0]')
    assert isinstance(tree, ast3.Module)
    node = tree.body[0]
    assert isinstance(node, ast3.FunctionDef)
    # print(astor.dump_tree(node))
    snip = compile_snippets(__name__)
    trans = YieldFromTransformer(snip)
    node2 = trans.visit(node)
    assert isinstance(node2, ast3.FunctionDef)
    # print(astor.dump_tree(node2))
    tree2 = ast3

# Generated at 2022-06-23 23:30:32.038081
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse

    class TestNode(ast.AST):
        _fields = []

    original_tree = ast.parse('a = yield from [1]')

    result = astunparse.unparse(
        YieldFromTransformer().visit(original_tree)
     )
    print(result)

# Generated at 2022-06-23 23:30:39.956112
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transpilers.fake_ast import FakeASTCreator
    creator = FakeASTCreator()
    creator.yield_from = creator.create_yield_from
    creator.emulate_yield_from = creator.create_yield_from
    creator.result_assignment = creator.create_result_assignment
    creator.yield_from = creator.create_yield_from
    transformer = YieldFromTransformer(creator)
    node = creator.create_function_def()
    node = transformer.visit(node)

# Generated at 2022-06-23 23:30:41.374799
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:43.876806
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import get_ast, compare_asts
    from ..utils.tree import find_all_nodes_by_type


# Generated at 2022-06-23 23:30:53.574600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.visitor import run_visitor
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_str
    from ..utils.helpers import validate_visitor_tree
    from ..utils.transform import get_transformator
    from ..utils.helpers import compare_source

    def transform(source):
        tree = ast.parse(source)
        trans = get_transformator(YieldFromTransformer)
        new_tree = run_visitor(trans, tree)
        return node_to_str(new_tree)

    def validate(source, expected):
        new_source = transform(source)
        msg = compare_source(expected, new_source)
        assert msg is None, msg


# Generated at 2022-06-23 23:31:02.555192
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    b = ast.parse('from test import test\ndef f(x):\n    y = yield from test(x)', mode='exec')
    tree = b.body[1]
    node = ast.YieldFrom(None,'from test import test')
    index = 0
    yieldfrom_ast = ['exc', 'iterable', 'iterable = iter(from test import test)',
                     'while True:\n    try:\n        yield next(iterable)\n    except StopIteration as exc:\n        y = exc.value\n        break']
    tree.body.pop(index)
    insert_at(index, tree, yieldfrom_ast)

# Generated at 2022-06-23 23:31:12.791733
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode

    module = '''def func():
    a = yield from []
'''

    transformer = YieldFromTransformer()
    tree = ast.parse(source_to_unicode(module))
    transformer.visit(tree)
