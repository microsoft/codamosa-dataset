

# Generated at 2022-06-23 23:21:08.440432
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def foo(x: int) -> str:
        import re
        return re.sub(r'x', "y", x)
    """
    tree = ast.parse(code)
    tree = YieldFromTransformer().visit(tree)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0], ast.Import)
    assert isinstance(tree.body[0].body[1], ast.Return)

# Generated at 2022-06-23 23:21:09.268399
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-23 23:21:13.990387
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    y = ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load()))
    exp = ast.Expr(value=y)
    node = ast.Name(id='a', ctx=ast.Load())
    assign = ast.Assign(targets=[node], value=y)
    y_t = YieldFromTransformer()
    y_t.visit(exp)
    y_t.visit(assign)

# Generated at 2022-06-23 23:21:19.276656
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3

    # test_emulate_yield_from
    YieldFromTransformer()._emulate_yield_from( ast3.Name(id='x', ctx=ast3.Store()), ast3.YieldFrom( ast3.List(elts=[], ctx=ast3.Load())))
    # test_handle_assignments
    YieldFromTransformer()._handle_assignments(ast3.FunctionDef(name='f', args=ast3.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None, type_comment=None))
    # test_handle_expressions

# Generated at 2022-06-23 23:21:22.010751
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test method visit() of class YieldFromTransformer"""

    # Unit test for constructor of class YieldFromTransformer
    yield_from_transformer = YieldFromTransformer()
    assert yield_from_transformer is not None

# Generated at 2022-06-23 23:21:29.892320
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_tree

    module = ast.parse(
        '''
        def foo():
            yield from foo()
        ''')

    result = assert_tree(module, YieldFromTransformer().visit)
    expected = assert_tree(
        'def foo():\n'
        '    iterable = iter(foo())\n'
        '    while True:\n'
        '        try:\n'
        '            yield next(iterable)\n'
        '        except StopIteration as exc:\n'
        '            break\n')

    assert(result == expected)


# Generated at 2022-06-23 23:21:30.834710
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:34.924221
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..ast_converter import ASTConverter
    from ..demo_modules import demo_module1

    conv = ASTConverter(demo_module1)
    root = conv.get_root()
    transformer = YieldFromTransformer()
    transformer.visit(root)
    assert transformer.has_changed()



# Generated at 2022-06-23 23:21:42.847754
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    source = textwrap.dedent("""
    def function():
        yield from [1, 2, 3]
    """)
    result = textwrap.dedent("""
    def function():
        let(iterable)
        iterable = iter([1, 2, 3])
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)
    expected = ast.parse(result)
    node = ast.parse(source)
    transformer = YieldFromTransformer()
    transformed = transformer.visit(node)
    assert ast.dump(transformed, annotate_fields=False) == ast.dump(expected, annotate_fields=False)

# Generated at 2022-06-23 23:21:43.429890
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:45.579540
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_name = YieldFromTransformer.__name__
    assert class_name == "YieldFromTransformer"



# Generated at 2022-06-23 23:21:46.519948
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:48.964138
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        cls=YieldFromTransformer(None, None)
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-23 23:21:49.918360
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-23 23:21:56.302101
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.codegen import to_source
    from ..utils.parse import parse

    code_to_transform = '''
    def foo(x):
        def bar(y):
            yield from y + x
            tmp = yield from y
            yield from y
        yield from bar(x)
    '''


# Generated at 2022-06-23 23:21:57.295970
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:07.681635
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
  from nuitka.nodes.AssignNodes import StatementAssignmentVariable
  from nuitka.nodes.ConditionalNodes import (
    StatementConditional, ExpressionConditional
  )
  from nuitka.nodes.ContainerOperationNodes import (
    ExpressionMakeTuple, ExpressionMakeList
  )
  from nuitka.nodes.CoroutineNodes import ExpressionYieldFrom
  from nuitka.nodes.StatementNodes import (
    StatementsSequence, StatementReturn
  )
  from nuitka.nodes.YieldNodes import ExpressionYield
  from nuitka.nodes.TryNodes import StatementTryExcept
  from nuitka.tree.Builders import (
    ExpressionNodes, StatementNodes, buildNodeList
  )

  # Statement
  a = ExpressionNodes.ExpressionVariable

# Generated at 2022-06-23 23:22:17.190471
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    class Test(unittest.TestCase):

        def setUp(self):
            self.maxDiff=None
            self.transformer = YieldFromTransformer()

        def test(self):
            tree_before = ast.parse(
                'def generator():\n'
                '    a = 1\n'
                '    a = yield from it\n'
                '    a\n'
                '    yield from it\n'
                '    yield from it\n'
                '    a = 1\n'
                '    yield from it\n'
                '    a\n'
            )

# Generated at 2022-06-23 23:22:22.905760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	from typed_astunparse import unparse
	from .test_classes.test_trees import get_transformer_test_tree
	from ..visitor import get_visitor
	from .test_classes.test_visitors import test_visitor

	tree = get_transformer_test_tree('yieldfrom')
	assert tree is not None
	before = unparse(tree)
	new = get_visitor(YieldFromTransformer).visit(tree)
	after = unparse(new)
	print(after)
	test_visitor(after, 'yieldfrom')


# Generated at 2022-06-23 23:22:27.033894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        ast.parse('def test():\n    a = yield from b\n    print(a)\n')
    except Exception:
        pass
    else:
        raise AssertionError('This test should fail')

# Generated at 2022-06-23 23:22:33.192117
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""\
    try:
        a = b.c
    except (Exception, BaseException) as e:
        d = e.f
    """
                     )
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    expected = ast.parse("""\
    try:
        a = yield from b.c
    except (Exception, BaseException) as e:
        d = e.f
    """
                         )
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-23 23:22:40.682055
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.snippet import snippet
    from ..utils.helpers import ast_print, node_is_function, node_is_module
    from ..utils.tree import to_tree, edit
    from ..transformer.raw_to_ast import raw_to_ast
    from ..transformer.ast_to_raw import ast_to_raw


# Generated at 2022-06-23 23:22:48.413861
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from textwrap import dedent

    ast_source = dedent("""\
        def foo():
            a = yield from []
        """)

    class_under_test = YieldFromTransformer

    expected_ast = dedent("""\
        def foo():
            iterable = iter([])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    a = exc.value
                    break
        """)

    class_under_test.check(ast_source=ast_source,
                           expected_ast=expected_ast)

# Generated at 2022-06-23 23:22:56.310289
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    actual = snippet.test_snippet(YieldFromTransformer, """
        bar = 1
        foo = yield from range(10)
        bar = 2
        print(foo, bar)
    """)

    expected = snippet.test_snippet(YieldFromTransformer, """
        bar = 1
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    foo = exc.value
                else:
                    foo = None
                break
        bar = 2
        print(foo, bar)
    """)

    assert actual == expected, f"Expected {expected} but got {actual}"

# Generated at 2022-06-23 23:22:57.083709
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:57.867483
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)

# Generated at 2022-06-23 23:23:05.473439
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import test_transform
    import textwrap
    source = textwrap.dedent("""
    def func():
        x, y = yield from iter(range(10))

        yield from iter(range(10))
        """)

# Generated at 2022-06-23 23:23:07.127449
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__


# Generated at 2022-06-23 23:23:08.449110
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None

# Generated at 2022-06-23 23:23:18.431216
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import compile_to_ast
    from typing import List
    from ..utils.snippet import let

    let(test, result)
    @compile_to_ast
    def test():
        a = None  # type: List[str]
        a = [i for i in ['foo'] if i is not None]
        a = [i for i in ['foo']]
        a = [i for i in ['foo'] if i is None]
        a = [i for i in ['foo'] if i is None][0]
        a = [i for i in ['foo'] if i is not None][0]

    @compile_to_ast
    def result():
        a = None  # type: List[str]
        iterable = ['foo']
        a = []

# Generated at 2022-06-23 23:23:26.764912
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:23:37.500521
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:23:46.778977
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse(
        '''
        def foo(a):
            res = yield from a

        def bar(b):
            yield from b

        def baz(c):
            for d in yield from c:
                pass

        def qux(e):
            if True:
                f = yield from e

        def fug(g):
            while True:
                yield from g

        def hoge(h):
            try:
                yield from h
            except:
                pass
        '''
    )
    YieldFromTransformer().visit(node)

    for node in ast.walk(node):
        if isinstance(node, ast.YieldFrom):
            assert False

# Generated at 2022-06-23 23:23:47.482380
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:23:56.349322
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

    module_ast = ast.parse(
        """
        from typing import List, NamedTuple
        class Test(NamedTuple):
            foo: int
        def test(a: List[int], b: Test) -> bool:
            if a:
                x = a
                y = b.foo
                c = []
                c.append(yield from a)
            return True
        """)
    YieldFromTransformer().visit(module_ast)
    exec(compile(module_ast, filename="<ast>", mode="exec"))

# Generated at 2022-06-23 23:24:06.482785
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    from ..utils.ast_helpers import generate_ast
    from ..utils.unparse_helpers import unparse
    from ..tests.fixtures import make_fixture


# Generated at 2022-06-23 23:24:12.202509
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..visitor import NodeTransformer
    from ..visitor import BaseNodeTransformer
    from ..visitor import create_transformer_class

    class OptimizingTransformer(BaseNodeTransformer):
        def _visit(self, node: ast.AST) -> ast.AST:
            return self.visit(node)

    class YieldFromAnalysisTransformer(OptimizingTransformer, NodeTransformer):
        _inserted_at_for_stopiteration_exc = 0

        def _visit(self, node: ast.AST) -> ast.AST:
            return self.visit(node)


# Generated at 2022-06-23 23:24:13.336493
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:24:24.092523
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import make_dummy_tree
    from ..utils.tree import to_string

    class Dummy(object):
        _tree_changed = True

    transformer = YieldFromTransformer()
    transformer._tree_changed = Dummy._tree_changed

    def t(code: str, expected: Optional[str]) -> None:
        node, *_ = make_dummy_tree(code)
        node = transformer.visit(node)
        print(to_string(node).strip())
        assert to_string(node) == expected


# Generated at 2022-06-23 23:24:26.067488
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .node_transformer_test_template import _test_node_transformer
    _test_node_transformer(YieldFromTransformer)

# Generated at 2022-06-23 23:24:33.830427
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    code = 'a = yield from [x for x in range(5)]'
    tree = ast.parse(code)
    res_tree = YieldFromTransformer().visit(tree)

    assert astunparse.unparse(res_tree) == \
    'def __G__0():\n    iterable = iter([x for x in range(5)])\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            a = exc.value\n            break\n\na = __G__0()'

# Generated at 2022-06-23 23:24:38.603621
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.docs import assert_on_examples
    examples = [
        ('def fun():\n    yield from fun()',
         'def fun():\n    let(iterable)\n    iterable = iter(fun())\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            pass\n            break'),
    ]
    assert_on_examples(examples, YieldFromTransformer())

# Generated at 2022-06-23 23:24:47.233519
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc = VariablesGenerator.generate('exc')
    y = YieldFromTransformer()
    assert hasattr(y, 'target')
    s = ast.parse('1')
    assert isinstance(y.visit(s), ast.Module)
    s = ast.parse('yield from (x for x in range(10))')
    res = ast.parse('iterable = iter(x for x in range(10))\n'
                    'while True:\n'
                    '    try:\n'
                    '        yield next(iterable)\n'
                    '    except StopIteration as exc:\n'
                    '        break\n')
    assert isinstance(y.visit(s), ast.Module)
    assert y.visit(s) == res

# Generated at 2022-06-23 23:24:57.345730
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    src = textwrap.dedent('''\
    def func():
        yield from x
        foo = yield from x
        yield from x()
    ''')

# Generated at 2022-06-23 23:24:58.345980
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    g = YieldFromTransformer()
    assert g is not None

# Generated at 2022-06-23 23:24:59.273521
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:00.451597
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import util
    import astunparse

# Generated at 2022-06-23 23:25:11.124000
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import BaseFixture
    from .test_while import WhileFixture
    from .. import ast_transformer

    class YieldFromFixture(BaseFixture):
        tr = ast_transformer.ASTTransformer()
        tr.register_transformer(YieldFromTransformer())

        def test_for(self):
            code = '''
                def func():
                    for item in a:
                        yield from b
                    return
                '''

# Generated at 2022-06-23 23:25:13.418797
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

    class DummyVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            return node

    visitor = DummyVisitor()



# Generated at 2022-06-23 23:25:19.130553
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.examples import (
        EXAMPLE_GENERATOR_FUNCTION_YIELD_FROM_TO_YIELD,
        EXAMPLE_GENERATOR_FUNCTION_YIELD_FROM_TO_YIELD_AST,
    )
    from ..utils.compiler import compile_
    # it should convert yield from to yield
    source = EXAMPLE_GENERATOR_FUNCTION_YIELD_FROM_TO_YIELD
    tree = EXAMPLE_GENERATOR_FUNCTION_YIELD_FROM_TO_YIELD_AST
    code = compile_(source, 'exec', transformer=YieldFromTransformer)
    assert code.tree == tree

# Generated at 2022-06-23 23:25:22.370339
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:25:30.224499
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..unittesting import Source
    transformer = YieldFromTransformer()
    tree = ast.parse('yield from foo()')
    transformer.visit(tree)
    gen = Source(tree).output()
    assert gen == '\n'.join([
        'def __ytf0():',
        '    iterable = iter(foo())',
        '    while True:',
        '        try:',
        '            yield next(iterable)',
        '        except StopIteration as exc:',
        '            break',
        '',
        'for __ytf in __ytf0():',
        '    yield __ytf'
    ])

# Generated at 2022-06-23 23:25:37.018194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    yield_from_token = ast.YieldFrom()
    value = ast.Name(
       id='my_generator', ctx=ast.Load(),
    )
    yield_from_token.value = value

    assign = ast.Assign(
       targets=[
          ast.Name(
             id='x',
             ctx=ast.Store(),
          ),
       ],
       value=yield_from_token,
    )
    assign_expected = ast.Assign(
       value=ast.Name(
          id='x', ctx=ast.Load(),
       ),
       targets=[
          ast.Name(
             id='target',
             ctx=ast.Store(),
          ),
       ],
    )

# Generated at 2022-06-23 23:25:38.586544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Check the creation YieldFromTransformer
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:48.633517
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..ast_compare import EqualAST
    from ..test_utils import transform


# Generated at 2022-06-23 23:25:53.578776
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse
    from ..utils.helpers import unpythonic, compare_source

    snippet.cache_clear()
    YieldFromTransformer()(parse(unpythonic, mode='eval'))
    assert snippet.cache_info().hits == 0

    snippet.cache_clear()
    YieldFromTransformer()(parse(unpythonic, mode='exec'))
    assert snippet.cache_info().hits == 0


# Generated at 2022-06-23 23:26:04.493495
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    exc = ast.Name(id='exc', ctx=ast.Store())
    expr = ast.Expr(value=ast.YieldFrom(value=ast.Name(id='generator', ctx=ast.Load())))
    assign = ast.Assign(targets=[ast.Name(id='target', ctx=ast.Store())], value=expr.value)
    yield_from = YieldFromTransformer._emulate_yield_from(target=None, node=expr.value)
    yield_assign = YieldFromTransformer._emulate_yield_from(target=exc, node=expr.value)
    nodes = (expr, assign)
    results = (yield_from, yield_assign)
    for n, r in zip(nodes, results):
        assert str(ast.dump(n))

# Generated at 2022-06-23 23:26:12.533780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        code = """
a = yield from [x for x in range(0,10) if x%2 == 0]
"""
        tree = ast.parse(code)
        res = YieldFromTransformer().visit(tree)
        if res:
            print(res)
            print()
            res.body[0].targets[0].id
            res.body[0].value.elts[0].value.elts[0].value.args[0].n
            res.body[0].value.elts[0].value.elts[0].value.args[1].n
            res.body[0].value.elts[0].value.generators[0].target.id
    except Exception as e:
        print(repr(e))

test_YieldFromTransformer()

# Generated at 2022-06-23 23:26:23.354823
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = """
            def foo():
                result = yield from bar()
                print(result)
                yield from baz()
                b = yield from z()
                print(b)
            """

# Generated at 2022-06-23 23:26:24.644003
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:26:32.709592
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # NOTE: It seems that static method generate does not work with mock
    from unittest.mock import patch
    from ..utils.tree import ast_from_str
    from copy import copy

    test_cases = [
        ('a = yield from b',
         '(a = (next(iter((b)))) while True else StopIteration())'),
        ('(a) = yield from b',
         '(a = (next(iter((b)))) while True else StopIteration())'),
        ('yield from b',
         'yield next(iter((b))) while True else StopIteration()'),
    ]
    test_cases = [(ast_from_str(e), ast_from_str(r)) for e, r in test_cases]


# Generated at 2022-06-23 23:26:34.998232
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    f = YieldFromTransformer(variations={}, target=(3,2))
    assert f.target == (3,2)
    assert f.variations == {}


# Generated at 2022-06-23 23:26:38.287934
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse('yield from a; yield from (b); yield from (c + 42)')
    module = YieldFromTransformer().visit(module)
    assert ast.dump(module) == '<Module []>'

# Generated at 2022-06-23 23:26:43.557544
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import compile
    source = '''if a:
        b = yield from c
        d = yield from e
    '''
    ast_tree, _ = compile(source, '<test>', 'exec')
    assert type(ast_tree).__name__ == 'Module'
    node = ast_tree.body[0]
    assert type(node).__name__ == 'If'
    assert type(node.body[0]).__name__ == 'While'

# Generated at 2022-06-23 23:26:53.401791
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    tnode1 = ast.FunctionDef()
    tnode2 = ast.FunctionDef()
    tnode3 = ast.Assign()
    tnode4 = ast.Expr()
    tnode5 = ast.Yield()
    tnode6 = ast.arg()
    tnode7 = ast.YieldFrom()
    tnode8 = ast.expr()
    tnode9 = ast.Assign()
    tnode10 = ast.Expr()
    tnode11 = ast.arg()
    tnode12 = ast.Yield()
    tnode13 = ast.name()
    tnode14 = ast.expr()
    tnode15 = ast.arg()
    tnode16 = ast.Yield()
    tnode17 = ast.name()
    tnode18 = ast.expr()
    tnode

# Generated at 2022-06-23 23:27:01.869146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from unittest import TestCase
    from typed_ast.ast3 import Module, Expr, YieldFrom, Load, Name, Num, parse
    from typed_astunparse import unparse
    from ..utils.tree import print_tree

    class ConstructorTest(TestCase):
        def test(self):
            t = YieldFromTransformer()
            self.assertIsInstance(t, YieldFromTransformer)

    class GenericVisitTest(TestCase):
        def test(self):
            t = YieldFromTransformer()
            tree = parse("a = '1'")
            node = t.generic_visit(tree)
            self.assertEqual(unparse(node), 'a = \'1\'')

    class VisitTest(TestCase):
        def test(self):
            t = YieldFromTransformer()


# Generated at 2022-06-23 23:27:12.325650
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.source import source_to_ast

    code = textwrap.dedent('''
    def test(g):
        c = yield from g
    ''')
    ast_tree = source_to_ast(code)
    transformer = YieldFromTransformer()
    transform_tree = transformer.visit(ast_tree)
    assert transformer.is_changed

    expected = textwrap.dedent('''\
    def test(g):
        let(iterable)
        iterable = iter(g)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    c = exc.value
                break
    ''')
    assert expected == transform_tree.as_string()

# Generated at 2022-06-23 23:27:16.669932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast.parse('x = yield from f()', mode="exec")
    ast.parse('yield from f()', mode="exec")
    ast.parse('x = yield from f()', mode="eval")
    print("success")

test_YieldFromTransformer()

# Generated at 2022-06-23 23:27:17.718882
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-23 23:27:29.382477
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import Union
    from ..utils.snippet import snippet
    node = snippet.create_ast(
        'def foo():',
        '    result = yield from bar()',
        '    other_result = yield from baz()',
        '    yield from yet_another()'
    )
    node = YieldFromTransformer().visit(node)


# Generated at 2022-06-23 23:27:36.925571
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    from .test_base import setup_test, assert_program
    program = setup_test(YieldFromTransformer.target)

    expected_program = """
    import asyncio
    async def async_fun():
        a = asyncio.sleep(1)
        b = asyncio.sleep(2)
        return [
            x async for x in a if True,
            x async for x in b if True,
        ]
    """
    assert_program(program, expected_program)

# Generated at 2022-06-23 23:27:37.466534
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-23 23:27:45.496230
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Constructing the visitor
    from ..utils import dump_tree
    from textwrap import dedent
    from astor.codegen import to_source
    visitor = YieldFromTransformer()
    tree = ast.parse(dedent('''
    def foo():
        yield from bar()
    '''))
    visitor.visit(tree)
    assert to_source(tree) == dedent('''\
    def foo():
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                pass
                break
    ''')
    dump_tree(tree)

# Generated at 2022-06-23 23:27:47.899199
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        for __ in YieldFromTransformer():
            pass
        assert False
    except Exception:
        assert True


# Generated at 2022-06-23 23:27:57.392401
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import get_ast
    from . import assert_equal_ast

    snippet_1_text = (
        'def f():\n'
        '    yield from 1\n'
    )
    snippet_1_expected = (
        'def f():\n'
        '    let(iterable, exc)\n'
        '    iterable = iter(1)\n'
        '    while True:\n'
        '        try:\n'
        '            yield next(iterable)\n'
        '        except StopIteration as exc:\n'
        '            if hasattr(exc, \'value\'):\n'
        '                target = exc.value\n'
        '            break\n'
    )

# Generated at 2022-06-23 23:27:59.704469
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tree_transforms import create_instance
    print(create_instance(YieldFromTransformer))


# test_YieldFromTransformer()

# YieldFromTransformer()

# Generated at 2022-06-23 23:28:00.594877
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:28:04.552686
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from ..utils.visitor import UnitTestVisitor
    from ..main import compile_snippets

    snippets.load_builtins()

    compile_snippets()

# Generated at 2022-06-23 23:28:05.468888
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-23 23:28:07.366014
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.ast_compare import compare
    from ..utils.ast_builder import make_tree


# Generated at 2022-06-23 23:28:16.886689
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    exc = ast.Name(id='StopIteration', ctx=ast.Load())
    exc = ast.Call(func=exc, args=[], keywords=[])
    exc = let('exc', exc)

    g = ast.Num(n=1)
    iterable = let('iterable', ast.Call(func=ast.Name(id='iter', ctx=ast.Load()), args=[g], keywords=[]))
    exc_occured = ast.Name(id='exc_occured', ctx=ast.Load())
    exc_occured = let(exc_occured, ast.Num(n=0))
    exc_info = ast.Name(id='exc_info', ctx=ast.Load())

# Generated at 2022-06-23 23:28:17.755202
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:28:18.573479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()


# Generated at 2022-06-23 23:28:20.797251
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # single assignment in body
    t = YieldFromTransformer()

# Generated at 2022-06-23 23:28:22.307557
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield # print(YieldFromTransformer.__init__())

# Generated at 2022-06-23 23:28:30.623865
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# class YieldFromTransformer(BaseNodeTransformer):
#     """Compiles yield from to special while statement."""
#     target = (3, 2)

#     def _get_yield_from_index(self, node: ast.AST,
#                               type_: Type[Holder]) -> Optional[int]:
#         if hasattr(node, 'body') and isinstance(node.body, list):  # type: ignore
#             for n, child in enumerate(node.body):  # type: ignore
#                 if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
#                     return n

#         return None

#     def _emulate_yield_from(self, target: Optional[ast.ast.AST],
#                             node: ast.

# Generated at 2022-06-23 23:28:31.607838
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:28:41.182082
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import transform_and_compare


# Generated at 2022-06-23 23:28:50.346936
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformer
    import astor
    import six
    font = BaseNodeTransformer()
    yield_from_list = YieldFromTransformer(font)
    s = """\
    try:
        yield a
    finally:
        b
        yield from c
        d
    """
    tree = ast.parse(six.StringIO(s).read())
    tree = yield_from_list.visit(tree)
    result = astor.to_source(tree)
    delete_tring = """\
    try:
        yield a
    finally:
        b
        let(iterable)
        iterable = iter(c)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
        d
    """
    assert ast

# Generated at 2022-06-23 23:28:53.056462
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Tests for __init__ method of class YieldFromTransformer."""
    from .test_helpers import get_node
    assert get_node(YieldFromTransformer(None), 'x') is not None


# Generated at 2022-06-23 23:28:55.550633
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    assert YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'

# Generated at 2022-06-23 23:28:56.873998
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:03.363605
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    th = YieldFromTransformer

    @snippet
    def a():
        yield from b()

    result = th(a).result  # type: ignore
    assert result  # type: ignore

    @snippet
    def a():
        x = yield from b()

    result = th(a).result  # type: ignore
    assert result  # type: ignore


# Generated at 2022-06-23 23:29:06.179383
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        transformer = YieldFromTransformer()
    except AttributeError:
        raise RuntimeError('Cannot create a instance of class YieldFromTransformer')

# Generated at 2022-06-23 23:29:07.186831
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:29:18.850711
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from ..utils.exception import UnsupportedError
    from ..transpiler import transpile_code, Transpiler
    from ..tree import parse

    with pytest.raises(UnsupportedError):
        transpile_code('yield from gen()')

    assert isinstance(Transpiler(3, 2).transpile_code('yield from gen()'), str)

    to_tree = parse
    tree = to_tree(source_to_unicode('''
                    a = yield from gen()
                    b = yield from gen()
                    yield from gen()
                    yield from gen()
                    yield from gen()'''))
    YieldFromTransformer().visit(tree)
    to_source = ast.unparse

# Generated at 2022-06-23 23:29:28.075157
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typing as t
    import astor
    import astunparse
    from . import helpers
    from ..typed_astunparse import typed_astunparse
    from .mock_typed_ast import get_mock_ast

    def do_test(src, expected_src):
        mock_ast = get_mock_ast(src)
        expected_ast = get_mock_ast(expected_src)
        transformer = YieldFromTransformer()
        result = transformer.visit(mock_ast)
        assert expected_ast == result

    assert YieldFromTransformer._get_yield_from_index(None, ast.Expr) is None

    ast_to_test = """
        def test(x):
            yield from x
            yield from x
    """

# Generated at 2022-06-23 23:29:38.600921
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import compile_and_get_node

    result = compile_and_get_node('def foo():\n'
                                  '    a = yield from bar')

    assert hasattr(result, 'targets')
    assert isinstance(result.targets[0], ast.Name)
    assert isinstance(result.value, ast.Name)
    assert result.value.id == 'iter'
    assert isinstance(result.value.ctx, ast.Load)

    result = compile_and_get_node('def foo():\n'
                                  '    yield from bar')
    assert isinstance(result, ast.For)
    assert isinstance(result.target, ast.Name)
    assert isinstance(result.iter, ast.Name)

# Generated at 2022-06-23 23:29:48.992403
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tester_nodes import generic_visit_test_template
    from ..utils.tester_nodes import function_node, module_node, output_node

    yield_from = ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load()))

    # Expr
    exp = ast.Expr(value=yield_from)

# Generated at 2022-06-23 23:29:49.551863
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:29:51.347193
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.codegen import to_source
    from ..utils.compat import Parser


# Generated at 2022-06-23 23:29:56.580013
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .fixed_point import FixedPointTransformer
    from mandelbrot.ast.transformer import MandelbrotTransformer
    from ..utils.helpers import set_up_mandelbrot

    transformer = FixedPointTransformer.create(MandelbrotTransformer,
                                               YieldFromTransformer)
    module = set_up_mandelbrot()
    module = transformer.visit(module)
    assert(transformer.tree_changed)

# Generated at 2022-06-23 23:30:02.281333
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest


# Generated at 2022-06-23 23:30:10.719992
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import sys
    from ..utils.helpers import get_elapsed_time

    code = """
    def f():
        yield from [1, 2, 3]
    """

    elapsed_time = get_elapsed_time(lambda: YieldFromTransformer().visit(ast.parse(code)), repeats=10000)
    print(f'Elapsed time {elapsed_time} s')

    # 2.1.1 - 4.14 s
    # 3.2 - 3.1 s
    # 3.7 - 2.08 s
    # 3.8 - 2.06 s



# Generated at 2022-06-23 23:30:18.010120
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse('f = yield_from(g)')
    visitor = YieldFromTransformer()
    result = visitor.visit(module)

    expected = ast.parse(
        'iterable = iter(g)\n'
        'while True:\n'
        '    try:\n'
        '        yield next(iterable)\n'
        '    except StopIteration as exc:\n'
        '        f = exc.value\n'
        '        break\n'
    )
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-23 23:30:21.301184
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # type: () -> None
    from typed_ast import ast3 as ast
    from .test.test_helpers import parse, dump
    from .test.test_helpers import transform, should_not_change


# Generated at 2022-06-23 23:30:22.637442
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:32.652160
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...codegen import to_source
    from ...codegen.ast_constructors import parse, ast_from_str, ass
    from ...testing import assert_equal

    def assert_transform(source: str, expected: str):
        program = ast_from_str(source)
        result = YieldFromTransformer().visit(program)
        assert_equal(to_source(result), expected)

    assert_transform('yield from GENERATOR',
                     """iterable = iter(GENERATOR)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        break""")


# Generated at 2022-06-23 23:30:36.082071
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer().visit(ast.parse(
        """result = [i for i in range(5)]
        if result:
            for i in range(4):
                yield result[i]
        """
    ))
    assert compile(result, '<string>', 'exec')

# Generated at 2022-06-23 23:30:43.062166
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse(
        'def f():\n'
        '    yield from g()\n'
        '    yield from h()\n'
        '    a = yield from i()\n'
        '    yield from j()\n'
        '    b = yield from k()\n'
        '    yield from l()\n'
        '    (yield from m())')
    transformer = YieldFromTransformer()
    tree = transformer.visit(module)

# Generated at 2022-06-23 23:30:45.021602
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tests.helpers import transform


# Generated at 2022-06-23 23:30:54.347253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_ast, parse
    from ..utils.helpers import VariablesGenerator
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from ..compilers.ast_compiler import NodeCompiler
    from .helpers import get_function_body, print_pretty
    from .yield_from import YieldFromTransformer
    from .base import BaseNodeTransformer
    from .constructor import ConstructorTransformer
    from .helpers import get_function_body

    snippet = snippet
    let = let
    extend = extend
    VariablesGenerator = VariablesGenerator
    NodeCompiler = NodeCompiler
    get_function_body = get_function_body
    print_ast = print_ast

# Generated at 2022-06-23 23:30:57.153524
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import validate_transformer
    from ..utils.helpers import get_targets
    validate_transformer(YieldFromTransformer, get_targets('YieldFromTransformer'))

# Generated at 2022-06-23 23:31:04.100810
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)._get_yield_from_index(None, None) == None
    assert YieldFromTransformer(None, None)._emulate_yield_from(None, None) == []
    assert YieldFromTransformer(None, None)._handle_assignments(None) == None
    assert YieldFromTransformer(None, None)._handle_expressions(None) == None
    assert YieldFromTransformer(None, None).visit(None) == None