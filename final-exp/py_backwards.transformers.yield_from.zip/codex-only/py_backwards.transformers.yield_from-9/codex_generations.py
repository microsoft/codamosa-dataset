

# Generated at 2022-06-23 23:21:06.910425
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse
    tree = parse("""
    def f1():
        yield from f2()

    def f3():
        yield from f4()
    """)
    transformer = YieldFromTransformer()
    node = transformer.visit(tree)

    assert transformer.tree_changed is True
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.FunctionDef)
    assert isinstance(node.body[1], ast.FunctionDef)
    assert isinstance(node.body[0].body[0], ast.While)
    assert isinstance(node.body[1].body[0], ast.While)

# Generated at 2022-06-23 23:21:08.439876
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-23 23:21:16.956975
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest.mock
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:21:17.783623
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	# test_tree: ast.AST
	# tree_changed: bool
	pass

# Generated at 2022-06-23 23:21:18.774176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .gather import GatherTransformer


# Generated at 2022-06-23 23:21:20.236490
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .sanity_check import check_transformer

    check_transformer(YieldFromTransformer)

# Generated at 2022-06-23 23:21:22.325752
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import fix, run_local_tests, calculate_tree_changed

    run_local_tests(globals(), locals(), True)

# Generated at 2022-06-23 23:21:23.806236
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert(yield_from_transformer is not None)

# Generated at 2022-06-23 23:21:25.676242
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.validation import validate_transformer
    validate_transformer(YieldFromTransformer)

# Generated at 2022-06-23 23:21:35.185767
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helpers import parse, compare_ast, NodeTest
    from collections import deque

    class Test(NodeTest):
        target = YieldFromTransformer.target
        node = Node
        default_options = {'mode': 'func'}

        def prepare(self, tree: Node, mode: str) -> Node:
            return tree

        def update_call(self, call: ast.AST, mode: str) -> None:
            self.assertIsInstance(call.node, ast.Expr)
            self.assertIsInstance(call.node.value, ast.Call)
            self.assertIsInstance(call.node.value.func, ast.Name)
            self.assertEqual(call.node.value.func.id, 'func')


# Generated at 2022-06-23 23:21:43.799942
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import FunctionDef, Expr, Load, Call, Name, Yield, YieldFrom

    class MyYieldFromTransformer(YieldFromTransformer):
        def _get_yield_from_index(self, node, type_):
            return super()._get_yield_from_index(node, type_)

        def _emulate_yield_from(self, target, node):
            return super()._emulate_yield_from(target, node)

    yft = MyYieldFromTransformer()

# Generated at 2022-06-23 23:21:53.076998
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Test method visit of class YieldFromTransformer."""
    __tracebackhide__ = True

    tree = ast.parse("""
    def func():
        a = yield from gen()
        b = yield from gen() + 1
        yield from gen()
        yield from gen() + 1
        c = yield from gen()
    """)

# Generated at 2022-06-23 23:22:02.689311
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:13.038724
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils import get_visitor

    ast1 = ast.If(test=ast.Name(id='test'),
                  body=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='f')))],
                  orelse=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='f')))])


# Generated at 2022-06-23 23:22:19.533852
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_code_equal

    transformer = YieldFromTransformer()
    code = """
a = (yield from range(5))
b = (yield from range(3))
c = 5
    """

    tree = ast.parse(code)
    tree = transformer.visit(tree)
    compiled = compile(tree, 'test', 'exec')
    glob = {}
    exec(compiled, glob)
    assert glob['a'] == 4
    assert glob['b'] == 2
    assert_code_equal(code, str(tree), ignore_spaces=True)

# Generated at 2022-06-23 23:22:26.085332
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap

    code = textwrap.dedent("""\
    def f():
        a = yield from [i for i in range(3)]
        c = yield from b
        yield from (i for i in range(2))
    """)

# Generated at 2022-06-23 23:22:27.813441
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import get_ast


# Generated at 2022-06-23 23:22:28.747318
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:22:31.737340
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_string = "a = yield from b + c"
    tree = ast.parse(ast_string)
    YieldFromTransformer(tree).visit(tree)
    assert ast_string == astor.to_source(tree)



# Generated at 2022-06-23 23:22:32.978022
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-23 23:22:40.536368
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from stdlib_list import stdlib_list
    from localizability.utils.ast2json import dump_ast
    from localizability.utils.helpers import get_ast_from_blob
    from localizability.node_transformers.compile_yield_from import YieldFromTransformer
    import sys
    import os

    path = os.path.abspath('../..')
    sys.path.append(path)

    src = get_ast_from_blob("""
    async def async_gen():
        res = yield from foo
    """)


# Generated at 2022-06-23 23:22:50.212090
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:22:58.097045
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    def check(before, after):
        t = YieldFromTransformer()
        t.visit(before)
        assert ast.dump(before) == ast.dump(after)

    # Assign

# Generated at 2022-06-23 23:23:05.798891
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import make_node
    source = '''
        def func():
            a = yield from (i for i in range(10))
            b = yield from (i for i in range(10))
            yield from (i for i in range(10))
        '''

# Generated at 2022-06-23 23:23:15.230264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    src = """
        try:
            x = {1 : 2}[y]
        except KeyError:
            x = 3
    """
    tree = ast.parse(src)
    tree = YieldFromTransformer().visit(tree)
    expected = """
        x = __pyson__.VariablesGenerator.generate("exc")
        while True:
            try:
                __pyson__.yield_from.iterable = iter({1 : 2})
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    x = exc.value
                break
    """
    assert ast.dump(tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 23:23:17.145425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft is not None
    assert hasattr(yft, 'target')


# Generated at 2022-06-23 23:23:25.692073
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    from . import untyped_ast
    from . import untyped_ast_transformer


# Generated at 2022-06-23 23:23:26.654930
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): # IGNORE:C01111
    assert YieldFromTransformer is not None


# Generated at 2022-06-23 23:23:31.989771
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap

    from ..utils.tree import tree

    example_code = textwrap.dedent("""
        def f(a):
            yield from a
            yield from a
    """)

    expected_code = textwrap.dedent("""
        def f(a):
            let(exc)
            let(iterable)
            iterable = iter(a)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
            let(exc)
            let(iterable)
            iterable = iter(a)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """)

    tree_ = tree(example_code)
    YieldFromTransformer().visit(tree_)



# Generated at 2022-06-23 23:23:35.861405
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_helpers import assert_equal_ignore_ws
    from ..testing.test_yield_from import module
    transformer = YieldFromTransformer()
    assert_equal_ignore_ws(transformer.visit(module), module)

# Generated at 2022-06-23 23:23:36.858934
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:23:38.977681
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-23 23:23:50.001990
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """
    Tests the function visitor.visit with the class YieldFromTransformer.
    """
    from .base import make_normalizing_transformer

    if not hasattr(ast.AsyncFunctionDef, 'body'):
        pytest.skip('This test requires Python 3.6 or newer.')

    source = '''
    def foo():
        a, b = yield from [1, 2]
        yield from 1
        for x in yield from [1, 2]:
            yield x + 1
    '''

# Generated at 2022-06-23 23:23:50.659267
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:23:59.109103
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import transform

    code = """
    async def foo():
        yield from generator
    """

    tree = ast.parse(code)
    tree = transform(tree, YieldFromTransformer)

    expected = """
    async def foo():
        let(iterable)
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    pass

                break
    """
    assert ast.dump(tree) == expected



# Generated at 2022-06-23 23:24:08.296480
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.test_utils import are_asts_equals
    from ..utils.test_utils import assert_ast_is
    from ..utils.test_utils import wrap_in_module

    tree = wrap_in_module("""
        def foo():
            x = yield from bar()
            y = yield from baz()
            if True:
                m = yield from qux()
            yield from quux()
    """)


# Generated at 2022-06-23 23:24:13.286077
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from astbuilder.builder import astbuilder

    @astbuilder
    def foo():
        a = yield from range(5)

    transformer = YieldFromTransformer().visit
    expected = foo(is_transformed=True)
    actual = transformer(foo())

    assert ast.dump(expected, include_attributes=False) == ast.dump(actual, include_attributes=False)

# Generated at 2022-06-23 23:24:19.496370
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3
    except ImportError:
        pass
    else:
        tree = ast3.parse("""
        def f():
            yield from 1
        """, mode='exec')
        tree = YieldFromTransformer().visit(tree)
        gen = compile(tree, '<test>', 'exec')
        ns = {}
        exec(gen, ns)

        assert ns['f']() == 1

# Generated at 2022-06-23 23:24:24.660329
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    with open('./examples/example1.py') as f:
        src1 = f.read()
    code = astor.to_source(ast.parse(src1))
    print(YieldFromTransformer().visit(ast.parse(code)).body[0].body[1].body[0])

test_YieldFromTransformer()

# Generated at 2022-06-23 23:24:31.364964
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    module = ast.parse('''def foo(a, b, c):
    if a:
        b += a
        yield from bar(a, b)
        c = b
        yield from baz(a)
    return c''')

    actual = YieldFromTransformer.run(module)

# Generated at 2022-06-23 23:24:32.418006
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:24:41.802715
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import make_test_tree
    from ..utils.helpers import parse
    from .variables import VariableInitializationTransformer
    from .inits import InitializationTransformer
    from .lambdas import LambdaLiftingTransformer
    from .nodes import TreesExtractor
    from .functions import FunctionDefinitionsTransformer

    def test_one(src, expected, target=3.2, tree=None):
        t = make_test_tree(src, target=target, tree=tree)
        YieldFromTransformer().visit(t)
        result = parse(t)
        assert expected == result


# Generated at 2022-06-23 23:24:42.727469
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-23 23:24:43.961838
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as py_ast

# Generated at 2022-06-23 23:24:45.149452
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t

# Generated at 2022-06-23 23:24:51.394583
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.examples import yield_from_assignment, yield_from_expression

    node_transformer =  YieldFromTransformer()
    nodes_transf_assign = node_transformer.visit(ast.parse(yield_from_assignment))
    nodes_transf_exp = node_transformer.visit(ast.parse(yield_from_expression))
    return node_transformer, nodes_transf_assign, nodes_transf_exp

test_YieldFromTransformer()

# Generated at 2022-06-23 23:24:56.530197
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_python.compiler.transforms.YieldFromTransformer as YieldFromTransformer
    import typed_python.compiler.transforms.YieldFromTransformer as YieldFromTransformer
    import typed_python.compiler.transforms.YieldFromTransformer as YieldFromTransformer

# Generated at 2022-06-23 23:24:57.827406
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #  YieldFromTransformer().__init__()
    assert True


# Generated at 2022-06-23 23:24:59.047350
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).target == (3, 2)


# Generated at 2022-06-23 23:25:08.977249
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_transformers_base import TransformTestCase
    from .test_transformers_base import cleanup_consts

    class TestYieldFromTransformer(TransformTestCase):
        transformer = YieldFromTransformer
        target = (3, 7)

        def test_assignment(self):
            """Test transform of simple assignment"""
            from .test_transformers_base import compare_source

            source = '''
            def test_(test):
                a = yield from test
                return a
            '''

# Generated at 2022-06-23 23:25:09.785336
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:11.495050
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import TreeTransformer
    from ..utils.parsing import parse

# Generated at 2022-06-23 23:25:18.878560
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from ..utils.symbols import ModuleSymbolTable
    from ..utils.source import source_to_code, source_to_ast
    symbol_table = ModuleSymbolTable()

    source = dedent("""
    def test():
        a = yield from (b for b in range(3))
    """)
    source_code = source_to_code(source)
    symbol_table.visit(source_code)

    source_ast = source_to_ast(source)
    ast_tree = YieldFromTransformer().visit(source_ast)

    assert source_ast != ast_tree
    assert source_code == ast.fix_missing_locations(symbol_table.visit(ast_tree))


# Generated at 2022-06-23 23:25:20.845085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Unit test for constructor of class YieldFromTransformer')
    YieldFromTransformer()


# Generated at 2022-06-23 23:25:27.275688
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from ..utils.helpers import collect_variables

    def check(source: str, expected: str):
        node = ast.parse(source)
        node = YieldFromTransformer.run(node)
        assert astunparse.unparse(node).strip() == expected.strip()
        collect_variables(node)

    check("""
foo()
""", """
foo()
""")


# Generated at 2022-06-23 23:25:29.636037
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..compiler import compile_ast
    from ..utils.helpers import get_ast

# Generated at 2022-06-23 23:25:36.692444
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source
    from ..utils.parser import parse
    from ..utils.compare_ast import compare_ast
    source = Source("""
    def test():
        with contextlib.ExitStack() as stack:
            yield from foo()
            x = yield from foo()
            yield from foo()
        with contextlib.ExitStack() as stack:
            yield from foo()
        yield from foo()
    """)
    tree = parse(source)
    node = YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:25:41.266063
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.helpers import compare_ast
    from pprint import pprint

    class TestVisitor(ast.NodeVisitor):
        def visit(self, node):
            pass


# Generated at 2022-06-23 23:25:42.275259
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-23 23:25:44.461587
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def func(arg):
        assignment = arg.split('a')
        # body begin
        yield from assignment
        # body end


# Generated at 2022-06-23 23:25:52.147894
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.helpers import extract

    class NodeVisitor(ast.NodeVisitor):
        def __init__(self, tree):
            self.tree = tree

        def visit(self, node):
            return YieldFromTransformer(self.tree).visit(node)

    tree = ast.parse("""
    def generator():
        yield 1
        yield 2
        return 'foo'
        
    def test():
        res1 = 'def'
        res2 = 'ghi'
        yield from generator()
        res3 = 'jkl'
        yield from generator()
        res4 = 'mno'
    """)
    src = extract(NodeVisitor(tree).visit(tree))

# Generated at 2022-06-23 23:25:52.643873
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:25:57.394520
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    #assert YieldFromTransformer.__doc__ == 'Compiles yield from to special while statement.'
    instance = YieldFromTransformer()
    assert instance._lastvar == 'a'

# test_YieldFromTransformer()

# Generated at 2022-06-23 23:25:59.594534
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).tree_changed == False
    assert YieldFromTransformer(None).visit("node") == "node"

# Generated at 2022-06-23 23:26:00.820631
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-23 23:26:10.318933
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .functions import FunctionTransformer
    from .methods import MethodTransformer
    from .conditions import IfTransformer, WhileTransformer
    from .loops import ForTransformer
    from .exceptions import TryTransformer

    transformers = (MethodTransformer,
                    FunctionTransformer,
                    IfTransformer,
                    WhileTransformer,
                    ForTransformer,
                    TryTransformer,
                    YieldFromTransformer)

    code = '''
        def f(x):
            yield from g(x)

        def g(x):
            yield from h(x)

        def h(x):
            yield x
    '''

    root = ast.parse(code)
    for t in transformers:
        root = t().visit(root)
    #   print(ast.unparse(root))


# Generated at 2022-06-23 23:26:11.178571
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:26:21.820962
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import get_ast

    tree = get_ast("""
    def fun(a):
        b = yield from a
    """)

    assert tree.body[0].body == [
        ast.Assign(
            targets=[
                ast.Name(id='b', ctx=ast.Store())
            ],
            value=ast.YieldFrom(
                value=ast.Name(id='a', ctx=ast.Load())
            )
        )
    ]

    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-23 23:26:30.857448
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from astor.code_gen import to_source
    from ..utils.helpers import assert_equals_ast

    example = '''
    def test(tup):
        (a, b) = iter(tup)
        print(a, b)

        yield from [1, 2, 3]
    '''
    expected = '''
    def test(tup):
        (a, b) = iter(tup)
        print(a, b)
        get_iter = iter([1, 2, 3])
        while True:
            try:
                yield next(get_iter)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    '''
    ast_module = ast.parse(example)

# Generated at 2022-06-23 23:26:40.330811
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast
    import textwrap

    code = textwrap.dedent('''
    def foo():
        result = yield from (x for x in range(10))
        foo = yield from (x for x in range(10))
        yield from (x for x in range(10))
    ''')

    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)


# Generated at 2022-06-23 23:26:49.799486
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import NodeTransformer, NodeTransformerConfig

    tree = ast.parse('x = yield from foo()')
    transformer = YieldFromTransformer(NodeTransformerConfig(target=(3, 2)))
    assert isinstance(transformer, NodeTransformer)
    assert transformer.visit(tree).body == \
           [ast.Assign([ast.Name('x', ast.Store())], ast.List()),
            ast.FunctionDef(None, None, None, None, None, None, None)]

    tree = ast.parse('x += yield from foo()')

# Generated at 2022-06-23 23:26:59.359593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from textwrap import dedent

    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer

    class YieldFromTransformerMock(YieldFromTransformer):
        def __init__(self):
            BaseNodeTransformer.__init__(self)
            self.node = None

        def visit(self, node: ast.AST) -> ast.AST:
            self.node = node
            return node

    node = ast.parse(dedent('''
        yield from x
    '''))

    yft = YieldFromTransformerMock()
    yft.visit(node)

    assert yft.node is not None
    assert isinstance(yft.node, ast.Module)

    body = yft.node.body


# Generated at 2022-06-23 23:27:01.313485
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #yf = YieldFromTransformer()
    ast.dump(YieldFromTransformer.get_ast())

test_YieldFromTransformer()

# Generated at 2022-06-23 23:27:02.181703
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:27:09.396662
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing_utils import transform
    from ..utils.helpers import parse

    @snippet
    def test_function(a, b, c):
        if a:
            yield a
            yield from b
            yield c

    expected_function = parse(test_function.format(a=1, b=2, c=3))
    transformed_function = transform(test_function.format(a=1, b=2, c=3))
    assert transformed_function == expected_function

# Generated at 2022-06-23 23:27:10.807868
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 23:27:11.722741
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer((3, 2))

# Generated at 2022-06-23 23:27:13.295787
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.parser import parse


# Generated at 2022-06-23 23:27:14.784522
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.builder import build


# Generated at 2022-06-23 23:27:24.897098
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_node_equals
    from ..utils.source import source_to_ast

    source = """
    g = None
    result = yield from g
    """
    source = source_to_ast(source)
    source = YieldFromTransformer().visit(source)
    result = """
    let(g)
    let(result)
    let(iterable)
    iterable = iter(g)
    while True:
        try:
            result = next(iterable)
        except StopIteration as exc:
            result = exc.value
            break
    """
    result = source_to_ast(result)
    assert_node_equals(result, source)

# Generated at 2022-06-23 23:27:25.996994
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-23 23:27:26.643210
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:31.237739
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from ..utils.helpers import dump_ast
    tree = ast3.parse('a = yield from b', mode='exec')
    dump_ast(tree)
    dump_ast(YieldFromTransformer().visit(tree))

# Generated at 2022-06-23 23:27:32.892693
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast


# Generated at 2022-06-23 23:27:41.702436
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    import unittest
    import subprocess
    import textwrap
    import os
    import sys


# Generated at 2022-06-23 23:27:46.836658
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import base_test

    # In
    code = 'yield from a'
    func, info = base_test.load_ast_tree(code,
                                         target=YieldFromTransformer.target)
    # Action
    transformer = YieldFromTransformer()
    transformer.visit(func)
    # Out

# Generated at 2022-06-23 23:27:56.721467
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap
    
    source = textwrap.dedent("""
    def main():
        a, b = yield from gen()
        yield from gen()
    """)
    desired = textwrap.dedent("""
    def main():
        let(exc)
        iterable = iter(gen())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                iterable = iter(gen())
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        break
    """)
    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    result = transformer.visit(tree)

# Generated at 2022-06-23 23:28:05.547967
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer()
    tree = ast.parse("""
        @a
        def func(self):
            yield from foo()
            yield from self.a
            yield from self.b()
            yield from self.c() + 1
            foo = yield from a
            foo = [yield from b]
            foo = [yield from c] + 1
            foo = (yield from d)
            foo = (yield from e) + 1
            foo = {yield from f}
            foo = {yield from g} + 1
            foo = {yield from h: i}
            foo = {yield from j: k} + 1
    """)
    t.visit(tree)

# Generated at 2022-06-23 23:28:09.348043
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    from ..utils.source import source_to_unicode, source_to_ast

    class Test(unittest.TestCase):
        def test_yield_from_assignment(self):
            source = source_to_unicode('''
            def foo():
                result = yield from bar()
            ''')

            expected_source = source_to_unicode('''
            def foo():
                let(iterable)
                iterable = iter(bar())
                let(exc)
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        if hasattr(exc, 'value'):
                            result = exc.value
                        break
            ''')
            tree = source_to_ast(source)
            transformer = YieldFromTrans

# Generated at 2022-06-23 23:28:18.180553
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent
    from typed_astunparse import unparse
    from ..utils.fixtures.yield_from import get_code, get_expected_code
    from ..utils.compare_ast import compare_ast
    from .ast_transformer_module_unwrap import ModuleUnwrapper

    for code, expected_code in zip(get_code(), get_expected_code()):
        code = dedent(code)
        expected_code = dedent(expected_code)

        node = ast.parse(code)
        expected_node = ast.parse(expected_code)

        transformer = YieldFromTransformer()
        node = transformer.visit(node)
        node = ModuleUnwrapper().visit(node)
        result_code = unparse(node)

        assert compare_ast(expected_node, node), result

# Generated at 2022-06-23 23:28:26.540441
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import dump, unparse
    from ..utils.syntax import try_parse
    from .remove_lazy_imports import RemoveLazyImportsTransformer
    from .remove_redundant_return import RemoveRedundantReturnTransformer
    tree = RemoveLazyImportsTransformer().visit(
        RemoveRedundantReturnTransformer().visit(
            try_parse("""
        def f(x):
            y = yield from g(x)
            return y
        """)))
    tree = YieldFromTransformer().visit(tree)
    assert dump(tree) == unparse(tree).strip()

# Generated at 2022-06-23 23:28:28.228140
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""

# Generated at 2022-06-23 23:28:30.293766
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-23 23:28:40.018151
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import tree_compare

    tree_compare.compare_trees(
        """
        def f():
            yield from [1, 2, 3]
        """,
        """
        def f():
            let(iterable)
            iterable = iter([1, 2, 3])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        """
    )


# Generated at 2022-06-23 23:28:41.538924
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from lark import Tree
    from lark import Token
    YieldFromTransformer()
    assert True


# Generated at 2022-06-23 23:28:42.115216
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-23 23:28:43.126469
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse


# Generated at 2022-06-23 23:28:51.772585
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.typed_ast_utils import ast_to_source

    source = """
        class A:
            def __iter__(self):
                return self

            def __next__(self):
                yield 1
                raise StopIteration

        def foo(x):
            a = yield from A()
            yield from x
    """


# Generated at 2022-06-23 23:29:01.806846
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..testing.utils import build_visit_test_case, generate_visit_test_cases
    from ..environments.pythran_types import PythranTypesEnvironment

    node = ast.parse('def foo(a, b):\n'
                     '    c = yield from a + b\n'
                     '    d = yield from a - b')


# Generated at 2022-06-23 23:29:08.276224
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import six
    import textwrap
    from ..compile import get_ast, write_pyc

    src = textwrap.dedent("""
        def a():
            while True:
                yield 1
                yield 2
        def b():
            while True:
                yield 1
                yield 2
    """)
    module = get_ast(src)
    YieldFromTransformer().visit(module)
    code = astunparse.unparse(module)

    # We need to write the compiled file, because we are testing module level
    # code.
    six.exec_(code, write_pyc(code, __file__, 'py'))

if __name__ == '__main__':
    test_YieldFromTransformer_visit()

# Generated at 2022-06-23 23:29:19.953775
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''\
        def foo():
            def bar():
                yield from a
            yield from a
            yield from b
            a = yield from b
            yield from (yield from b)
            yield from [yield from b]
            yield from {yield from b}
            (yield from b)
            [yield from b]
            {yield from b}
        '''

# Generated at 2022-06-23 23:29:21.026967
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:29.579067
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_module = ast.parse('''
        def foo(a, b):
            yield from a
            yield from b
    ''')

    transformer = YieldFromTransformer(ast_module)
    ast_module = transformer.transform()


# Generated at 2022-06-23 23:29:31.083263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()


# Generated at 2022-06-23 23:29:33.344444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.test_node_transformer import test_NodeTransformer
    test_NodeTransformer(YieldFromTransformer, 'try-3.2')

# Generated at 2022-06-23 23:29:43.944436
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import sys
    from StringIO import StringIO

    from .base import parse_function, unparse_function

    class TestYieldFromTransformer_visit(unittest.TestCase):
        def setUp(self):
            self._stdout = sys.stdout
            sys.stdout = StringIO()

        def tearDown(self):
            sys.stdout = self._stdout

        def test_function(self):
            source = """
            def foo(a):
                tupl = (1, 2, 3)
                return a + tupl[0]
            """

            ast_obj = parse_function(source)
            transformer = YieldFromTransformer()
            r = transformer.visit(ast_obj)


# Generated at 2022-06-23 23:29:48.381439
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet_0 = yield_from.get_body(generator=node.value,
                                   assignment=assignment,
                                   exc=exc)
    snippet_1 = result_assignment.get_body(exc=exc, target=target)
    return snippet_0 + snippet_1


# Generated at 2022-06-23 23:29:57.733916
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ... import codegen, parse

    module = parse("""
        def a(x):
            yield from x
        def b(x):
            yield from x + 1

        z = c(y)
        yield from z

        def c(x):
            yield from x
            return 4

        def d(x):
            yield from x + 1
            return 4

        def e(x):
            yield from x + 1
            return 4
        z = yield from z
        """)
    result = YieldFromTransformer().visit(module)

# Generated at 2022-06-23 23:30:02.234361
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tf = YieldFromTransformer()
    tf.visit()
    tf.generic_visit()
    tf._get_yield_from_index(node=None, type_=None)
    tf._emulate_yield_from(target=None, node=None)
    tf._handle_assignments(node=None)
    tf._handle_expressions(node=None)

# Generated at 2022-06-23 23:30:03.619617
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:06.247144
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast import parse
    from pickle import loads, dumps
    from ..utils.tree import tree_to_str, compare_trees


# Generated at 2022-06-23 23:30:07.257028
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:30:12.103536
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .fixtures import fixture_test_YieldFromTransformer_visit
    from ..utils.tree import parse_to_ast

    for source, expected in fixture_test_YieldFromTransformer_visit.items():
        assert str(parse_to_ast(source, YieldFromTransformer).body[0]) == expected



# Generated at 2022-06-23 23:30:21.923870
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Parsing input
    parse_tree = ast.parse('''
    def f():
        a = yield from g()
        yield from g()
        yield from g()
        yield from g()
        return a
    ''')

# Generated at 2022-06-23 23:30:31.997540
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from textwrap import dedent

    from .. import dump, loads, loads_ast
    from ..utils.helpers import dump_ast

    code = dedent("""\
    def f(a):
        b = yield from a
        return b
    """)
    tree = loads_ast(code)
    tree = YieldFromTransformer().visit(tree)
    result = dump_ast(tree)
    result = loads(result)

    expected = dedent("""\
    def f(a):
        let(iterable)
        iterable = iter(a)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                b = exc.value
                break

        return b

    """)
    expected = loads(expected)


# Generated at 2022-06-23 23:30:35.455369
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # TODO: adjust test case and implementation
    # node1 = ...
    # node2 = ...
    # node3 = ...
    # node4 = ...
    # node5 = ...
    # node6 = ...
    # node7 = ...
    # node8 = ...
    
    # assert(False)
    pass

# Generated at 2022-06-23 23:30:42.597232
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from typed_ast import visitors
    import pickle
    from ..utils.helpers import VariablesGenerator
    gen = VariablesGenerator("a")

    before = ast.FunctionDef(name="test", args=ast.arguments(args=[], kw_onlyargs=[], kw_defaults=[], defaults=[]), body=[
        ast.Return(value=ast.YieldFrom(value=ast.Call(func=ast.Name(id='range', ctx=ast.Load()), args=[
            ast.Num(n=10)], keywords=[])))], decorator_list=[], returns=None)
    before_pickle = pickle.dumps(before)

    fn = YieldFromTransformer().visit(before)

# Generated at 2022-06-23 23:30:52.410729
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method visit of class YieldFromTransformer."""
    def code_to_function(code: str) -> ast.FunctionDef:
        """Generates function AST from snippet."""
        return ast.parse(code).body[0]

    def transform(snippet: Optional[str],
                  expected: Optional[str] = None,
                  **kwargs) -> None:
        """Performs test on snippet."""
        if snippet is None:
            return

        if expected is None:
            expected = snippet

        function = code_to_function(snippet)
        transformer = YieldFromTransformer(**kwargs)
        transformer.visit(function)
        actual = ast.unparse(function)
        assert actual == expected


# Generated at 2022-06-23 23:31:00.922123
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from py_mini_racer import py_mini_racer
    src = """
    def f():
        yield from (1, 2, 3)
    """
    expected = """
    def f():
        let(iterable)
        iterable = iter((1, 2, 3))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    ctx = py_mini_racer.MiniRacer()
    tree = ast.parse(src)
    new_tree = YieldFromTransformer(ctx).visit(tree)
    assert ast.dump(new_tree) == expected

