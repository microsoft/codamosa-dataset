

# Generated at 2022-06-23 23:21:13.970886
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .bases import NodeTransformerTestCase
    from . import ast_converter

    class YieldFromTransformerTestCase(NodeTransformerTestCase):
        transformer = YieldFromTransformer()
        target_tree = ast_converter.parse('''
            def f():
                try:
                    res = yield from range(1, 2)
                except StopIteration as exc:
                    pass
            ''')

    yield YieldFromTransformerTestCase()
    yield YieldFromTransformerTestCase(
        '''
        def f():
            try:
                res = yield from range(1, 2)
            except StopIteration as exc:
                pass

        f()
        '''
    )

# Generated at 2022-06-23 23:21:14.962254
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:15.474808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  transformer = YieldFromTransformer()
  return transformer

# Generated at 2022-06-23 23:21:22.035327
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import _ast as ast
    from ..utils.test_visitor import TestVisitor

    assign_test_case = {
        'before': ast.parse('x = yield from a'),
        'after': ast.parse('let(_iterable)\n'
                           '_iterable = iter(a)\n'
                           'while True:\n'
                           '    try:\n'
                           '        x = next(_iterable)\n'
                           '        yield x\n'
                           '    except StopIteration as exc:\n'
                           '        if hasattr(exc, \'value\'):\n'
                           '            x = exc.value\n'
                           '        break')
    }


# Generated at 2022-06-23 23:21:31.664932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_compiler import compile_
    result = compile_(YieldFromTransformer,
                      '''
                      def foo():
                          x = [1, 2, 3]
                          yield from x
                      ''')
    assert (result.strip() == '''
        def foo():
            x = [1, 2, 3]
            iterable = iter(x)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    x = exc.value
                    break
    '''.strip())

    result = compile_(YieldFromTransformer,
                      '''
                      def bar():
                          yield from {1, 2, 3}
                      ''')

# Generated at 2022-06-23 23:21:38.989740
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert ast.dump(YieldFromTransformer().visit(
        ast.parse("try:\n\tf()\nexcept:\n\tyield from g()",
                  mode='exec')),
        include_attributes=True) == \
        ast.dump(ast.parse("""
try:
    f()
except:
    let(iterable)
    iterable = iter(g())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                pass
            break
""", mode='exec'), include_attributes=True)


# Generated at 2022-06-23 23:21:40.573696
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.builtins import Builtins
    from ..utils.helpers import dump

    transformer = YieldFromTransformer(builtins=Builtins())


# Generated at 2022-06-23 23:21:42.589417
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test(abstract_syntax_tree: ast.AST) -> ast.AST:
        transformer = YieldFromTransformer()
        return transformer.visit(abstract_syntax_tree)

    # Init

# Generated at 2022-06-23 23:21:50.637081
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Code to be compiled
    code = """
async def foo():
    x = yield from x
"""
    # The expected output of the compiled code
    expected_code = """
async def foo():
    let(iterable)
    iterable = iter(x)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            x = exc.value
            break
"""
    module, output = compile_snippet(code, YieldFromTransformer)
    assert output == expected_code
    assert module.foo.__code__.co_flags & 0x0200000  # CO_ASYNC_GENERATOR


# Generated at 2022-06-23 23:21:51.435395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yieldFromTransformer = YieldFromTransformer()


# Generated at 2022-06-23 23:21:56.912690
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test case 1
    # Create a parse tree from the following Python code
    root = ast.parse(textwrap.dedent('''
    def f1():
        yield from f2()
    '''))
    # Run the YieldFromTransformer on the parse tree
    transformer = YieldFromTransformer()
    new_root = transformer.visit(root)
    # Compare
    # Note that we use ast.dump() to convert an AST to a text representation
    # because ast.NodeVisitor.visit() doesn't support comparing AST nodes

# Generated at 2022-06-23 23:21:57.931899
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer



# Generated at 2022-06-23 23:22:04.459615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for constructor of class YieldFromTransformer 
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO  # type: ignore
    from contextlib import redirect_stdout

    import astor

    for_node = ast.For(target=None, iter=None, body=None, orelse=None)
    # TODO: annotate `for_node`
    f = YieldFromTransformer()
    f.visit(for_node)



# Generated at 2022-06-23 23:22:14.824908
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test import generate_test_program

    program = generate_test_program(
        ['yield from <expr>', 'yield from <expr>', ['yield from <expr>', 'yield from <expr>']]
    )
    program = YieldFromTransformer().visit(program)

    assert isinstance(program, ast.Module)
    assert len(program.body) == 1
    assert isinstance(program.body[0], ast.FunctionDef)

    assert isinstance(program.body[0].body[0], ast.While)
    assert isinstance(program.body[0].body[1], ast.While)

    assert isinstance(program.body[0].body[0].body[0], ast.Try)

# Generated at 2022-06-23 23:22:19.422177
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.node_util import parse, compare_ast

    class TestTransformer(YieldFromTransformer):
        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
            node = self.visit(node)
            return node

        def visit_Module(self, node: ast.Module) -> ast.AST:
            node = self.visit(node)
            return node


# Generated at 2022-06-23 23:22:20.196820
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:22:22.104719
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    expr = ast.parse('yield_from_transformer = YieldFromTransformer()')
    exec(compile(expr, '<test>', 'exec'))


# Generated at 2022-06-23 23:22:23.102174
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()


# Generated at 2022-06-23 23:22:31.480868
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import transform
    import typing as tp

    tree = ast.parse('def a():\n'
                     '    x = yield from obj\n'
                     '    a = yield from obj\n'
                     '    yield from obj\n')
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    compiled = compile(transform(tree, [YieldFromTransformer]), '', 'exec')

    result = tp.cast(tp.Dict[str, tp.Any], {})
    exec(compiled, {}, result)
    result['a']()



# Generated at 2022-06-23 23:22:33.437496
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 23:22:40.381401
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    source = textwrap.dedent("""
        def f(arg):
            while True:
                yield from arg
        """)
    tree = ast.parse(source)
    node = YieldFromTransformer().visit(tree)
    result = astunparse.unparse(node)
    expected_result = textwrap.dedent("""\
        def f(arg):
            let(exc)
            iterable = iter(arg)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """)
    assert result == expected_result

# Generated at 2022-06-23 23:22:50.061731
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit(): # Unit test for method visit of class YieldFromTransformer
    transformer = YieldFromTransformer()
    module = ast.parse('[a for a in [1, 2] if True]')
    transformer.visit(module)
    assert module == ast.parse('[a for a in [1, 2] if True]')
    module = ast.parse("a = (yield from range(3))")
    transformer.visit(module)

# Generated at 2022-06-23 23:22:51.617808
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import astor
    from ast_helpers.versions import get_version


# Generated at 2022-06-23 23:22:52.487838
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:22:59.848338
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Code snippet 1, source: https://stackoverflow.com/questions/35799003/yield-from-vs-for-loop
    source_1 = """
        def foo():
            yield 'begin'
            yield from bar()
            yield 'end'


        def bar():
            yield 'middle'
    """

    # Code snippet 2, source: https://www.python.org/dev/peps/pep-0380/

# Generated at 2022-06-23 23:23:01.792644
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    expected = YieldFromTransformer()
    actual = YieldFromTransformer()
    assert expected.__dict__ == actual.__dict__
    assert str(expected) == str(actual)

# Generated at 2022-06-23 23:23:02.547902
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:23:03.778964
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:23:08.068109
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..test_utils import parse
    node = parse("""
    def g(x):
        yield from x

    def f():
        x = g([1, 2, 3])
        print(x)
    """)
    transformer = YieldFromTransformer(node)
    transformer.visit(node)
    assert transformer.changed is True

# Generated at 2022-06-23 23:23:09.043443
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse


# Generated at 2022-06-23 23:23:19.050315
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer

    from ..utils.snippet import snippet

    from ..utils.helpers import VariablesGenerator

    from typing import Union

    from typed_ast import ast3 as ast

    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]


    # Unit test for result_assignment
    @snippet
    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value


    # Unit test for yield_from
    @snippet
    def yield_from(generator, exc, assignment):
        let(iterable)
        iterable = iter(generator)

# Generated at 2022-06-23 23:23:22.328115
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import astunparse
    from ..utils.helpers import get_ast

    class TestYieldFromTransformer_visit(unittest.TestCase):
        maxDiff = None


# Generated at 2022-06-23 23:23:23.193554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:23:30.033537
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..utils.py3ast_helpers import node_to_source
    from .base import BaseNodeTransformer

    # Initialize
    target = (3, 2)
    source = '''\
        def fun():
            a = yield from [1, 2, 3]
            b = yield from [1, 2, 3]
            yield 2
            yield from 5
            c = yield from gen()
            yield from fun()
            yield 3
    '''

# Generated at 2022-06-23 23:23:35.860526
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import open_file

    module = open_file(__file__)
    transformer = YieldFromTransformer()
    module = transformer.visit(module)

    assert transformer._tree_changed is True
    transformer._tree_changed = False  # reset the flag

    module = transformer.visit(module)

    assert transformer._tree_changed is False



# Generated at 2022-06-23 23:23:43.377648
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
    x = yield from range(10)
    """
    expected = """
    let(iterable)
    iterable = iter(range(10))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            x = exc.value
            break
    """
    transformer = YieldFromTransformer()
    result = transformer.visit(ast.parse(code))
    assert expected == astor.to_source(result)

    code = """
    yield from range(10)
    """
    expected = """
    let(iterable)
    iterable = iter(range(10))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    """
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:23:55.233829
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures import normalize_ast
    from . import fix

    expected = """\
    def function():
        exc = None
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    result = exc.value
                break
        exc = None
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    result = exc.value
                break
    """

    # Unit test: YieldFromTransformer.visit
    # 1. If there is, replace occurences of yield from with correct statements.

# Generated at 2022-06-23 23:24:02.151741
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    Compiles yield from to special while statement.
    """
    actual = YieldFromTransformer().visit(ast.parse("for x in yield_from(): pass"))
    expected = ast.parse("""
    for x in iter(yield_from()):
        try:
            x = next(x)
        except StopIteration as exc:
            x = exc.value
            break
    """)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 23:24:03.876489
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = 'def function(x): yield from iter([1, 2, 3])'

# Generated at 2022-06-23 23:24:10.920143
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformerTest
    from .assign_transformer import AssignTransformer
    from .loop_transformer import LoopTransformer
    from .future_transformer import FutureTransformer
    from .function_transformer import FunctionTransformer

    class Test(BaseNodeTransformerTest):

        TRANSFORMER_CLASS = YieldFromTransformer

        def test_simple_function(self):
            code = 'def foo(): yield from x'
            module = self.to_module(code)
            assert module.body[0].body[0].value.value.body[0].value.value.elts == ['x']

        def test_simple_function_2(self):
            code = 'def foo(): x = yield from x'
            module = self.to_module(code)
            print(module)
            assert module

# Generated at 2022-06-23 23:24:12.339594
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    assert trans
    

# Generated at 2022-06-23 23:24:15.740818
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = 1
    y = True
    y = len(x)
    y = len(True)
    x = y
    return x
# End of unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:24:25.995032
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # TODO: assertExpectedNode from utils?
    from typed_ast import ast3 as ast

    code = """
try:
    foo = yield from range(10)
except Exception:
    pass
    """
    module = ast.parse(code)
    transformer = YieldFromTransformer()
    ast.fix_missing_locations(transformer.visit(module))

    expected_code = """
try:
    let(foo)
    iterable = iter(range(10))
    while True:
        try:
            foo = next(iterable)
            yield foo
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                foo = exc.value
            break
except Exception:
    pass
    """
    expected_module = ast.parse(expected_code)
    assert module

# Generated at 2022-06-23 23:24:36.322078
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    case_tree = ast.parse("""
    def foo(i, j):
        k = yield from foo(i)
        l = yield from bar(j)
        yield from bar(j)
    """, mode='exec')
    YieldFromTransformer().visit(case_tree)

# Generated at 2022-06-23 23:24:44.286970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .codegen import CodeGenerator
    import textwrap
    src = textwrap.dedent("""
        def foo():
            a = yield from bar()
            b = yield from baz()
            c = yield from qux()
            yield from zap()
            yield from zep()
    """)
    tree = ast.parse(src)
    codegen = CodeGenerator()
    codegen.visit(YieldFromTransformer().visit(tree))

# Generated at 2022-06-23 23:24:48.604388
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    trans = YieldFromTransformer(type(None))
    node = ast.parse('yield from x, yield from y').body[0]
    assert trans.visit(node) == ast.parse('yield from x; yield from y').body[0]


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-23 23:24:58.633480
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..language import compile_

    assert compile_(
        'def foo(x):\n'
        '    a = yield from x\n'
        '    return a', 3, 2
    ) == compile_(
        'def foo(x):\n'
        '    let(exc)\n'
        '    let(iterable)\n'
        '    iterable = iter(x)\n'
        '    while True:\n'
        '        try:\n'
        '            yield next(iterable)\n'
        '        except StopIteration as exc:\n'
        '            a = exc.value\n'
        '            break\n'
        '    return a', 3, 2
    )


# Generated at 2022-06-23 23:25:08.562751
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_base import NodeTestCase
    from .test_base import ExampleAST
    from .try_except_transformer import TryExceptTransformer

    ast.fix_missing_locations = lambda x: x

    # Unit tests for method visit of class YieldFromTransformer
    class YieldFromTransformerTestCase(NodeTestCase):
        def test(self):
            code = ExampleAST.EXAMPLES['multiple_yield']
            expected = ExampleAST.EXAMPLES['multiple_yield_after']
            root_node = ast.parse(code)
            root_node = TryExceptTransformer().visit(root_node)
            root_node = YieldFromTransformer().visit(root_node)
            self.check_equal(root_node, expected)

    YieldFromTransformerTestCase.run_tests

# Generated at 2022-06-23 23:25:09.167768
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pytest.skip()

# Generated at 2022-06-23 23:25:10.293255
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures import set_up_transformer

# Generated at 2022-06-23 23:25:11.616293
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:25:19.244569
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    module = ast.parse("""
    def foo(a):
        yield from a
        b = yield from a
        yield from a
        yield from a
        yield from bar(a, yield from a)
        b = yield from None
        while True:
            yield from None
    """)

# Generated at 2022-06-23 23:25:29.846922
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from .ast_helpers import get_module, get_funcdef_ast, get_yield_from_ast

    def test(code, expected):
        module = get_module(code)
        transformer = YieldFromTransformer()
        transformer.visit(module)

        actual = astor.to_source(module)
        assert actual == expected

    yield test, 'yield from 1', 'def test(): pass'
    yield test, 'yield from 1; yield from 2', 'def test(): yield from 2'
    yield test, 'yield from 1; a = 1; yield from 2', 'def test():\n    yield from 2'

# Generated at 2022-06-23 23:25:36.811075
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
    def x():
        a = yield from b()
        yield from c()
        yield from d()
    """
    tree = ast.parse(code)
    assert_equal(str(tree), dedent(code).strip())

    YieldFromTransformer.transform(tree)

# Generated at 2022-06-23 23:25:47.097866
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    code = '''
    def func():
        while True:
            yield from a
            yield from b
            yield c
            d += 1
            yield from d
            yield from [1]
            yield from {1, 2, 3}
            yield from {1:2}
            yield from ()
            yield
    '''

# Generated at 2022-06-23 23:25:48.557815
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:49.767582
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = YieldFromTransformer()
    print(node)

# Generated at 2022-06-23 23:25:50.505753
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

# Generated at 2022-06-23 23:25:50.992378
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:26:01.731165
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3
    except ImportError:
        warnings.warn("'typed_ast' is not installed, skipping the tests for YieldFromTransformer")
    else:
        from check_ast import check_module
        from ..utils.helpers import compare_blocks

        # test for run_module
        result = YieldFromTransformer().run_module(
            ast3.parse('def a():\nyield from b()\npass', mode='exec'))

# Generated at 2022-06-23 23:26:10.856703
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .context import Context
    from .testutils import make_instance, compare
    from .parser import parse
    source1 = '''foo(yield from [])'''
    source2 = '''foo(yield from a)'''
    source3 = '''foo(yield from a[yield from b])'''
    source4 = '''foo(yield from f(yield from b))'''
    source5 = '''bar = yield from a()'''
    source6 = '''yield from a'''
    source7 = '''yield from f(yield from a)'''
    source8 = '''yield from a()'''

    def parse_and_bind(s):
        return parse(s).body[0].value

    expect1 = '''foo(iter([]))'''


# Generated at 2022-06-23 23:26:21.574917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..environment import Environment
    from ..utils.source import source_to_code
    from ..compiler import compile_snippets
    import ast

    import_from_return = ast.ImportFrom(module='return', names=[
        ast.alias('tail', None),
        ast.alias('head', None)
    ], level=0)
    import_from_return.lineno = 1
    import_from_return.col_offset = 0

    yield_from_expr = ast.Expr(ast.YieldFrom(ast.Name(id='a', ctx=ast.Load())))
    yield_from_expr.lineno = 2
    yield_from_expr.col_offset = 0


# Generated at 2022-06-23 23:26:30.662517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('def f(n): return a if n else b')
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.FunctionDef)
    assert node.body[0].name == 'f'
    assert node.body[0].args.args[0].arg == 'n'

    tr = YieldFromTransformer()
    assert tr.tree_changed is False
    res = tr.visit(node)
    assert tr.tree_changed is False
    assert isinstance(res, ast.Module)
    assert len(res.body) == 1
    assert isinstance(res.body[0], ast.FunctionDef)
    assert res.body[0].name == 'f'

# Generated at 2022-06-23 23:26:40.118541
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast
    generator = YieldFromTransformer()

# Generated at 2022-06-23 23:26:43.482557
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
        print ('test_YieldFromTransformer: ok')
    except:
        print ('test_YieldFromTransformer: ERROR')

# Unit tests for method _get_yield_from_index of class YieldFromTransformer

# Generated at 2022-06-23 23:26:50.322528
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_utils import check_transformer
    from ..stubs import node_classes

    check_transformer(
        YieldFromTransformer,
        '''def foo():\n    yield from bar()\n''',
        '''def foo():\n    iterable = iter(bar())\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc1:\n            break\n''',
        node_classes=node_classes
    )


# Generated at 2022-06-23 23:26:55.538651
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from .utils import assert_node_equal, parse_source

    snippet = """
a = (yield from A)
if x == 1:
    b = (yield from B)
else:
    c = (yield from C)
"""

# Generated at 2022-06-23 23:26:56.934804
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # This test ensures that YieldFromTransformer class is instantiable
    t = YieldFromTransformer()  # type: YieldFromTransformer
    assert(t)

# Generated at 2022-06-23 23:26:58.423122
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import transformers_test

    transformers_test.test_constructor(YieldFromTransformer)

# Generated at 2022-06-23 23:27:00.397805
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test the constructor
    transformer = YieldFromTransformer()
    assert transformer is not None
    
    return True



# Generated at 2022-06-23 23:27:01.313226
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-23 23:27:04.878125
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from .fixtures import yield_from as code
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    result = astor.to_source(tree).strip()

    assert result == code.strip()

# Generated at 2022-06-23 23:27:08.410298
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test to make sure __init__() is working correctly
    a = YieldFromTransformer()
    assert (isinstance(a, BaseNodeTransformer))

# Test if the correct target is set

# Generated at 2022-06-23 23:27:11.179553
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, "name")

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:27:18.896657
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    func_def = compile('def f(): yield from range(3)', '<test>', 'exec')
    func_def = ast.parse(func_def)
    func_def = YieldFromTransformer().visit(func_def)
    func_code = compile(func_def, '<test>', 'exec')
    exec(func_code)

    lst = []
    for i in f():  # noqa
        lst.append(i)
    assert lst == [0, 1, 2]


# Generated at 2022-06-23 23:27:30.670628
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseTestTransformer
    
    class TestYieldFromTransformer(BaseTestTransformer):
        @property
        def target_ast(self) -> ast.AST:
            return ast.parse("""
                def test(x):
                    a = yield from x
                    print(a)
                    (yield from x)
                    yield from x
                """)

        @property
        def transformer(self) -> YieldFromTransformer:
            return YieldFromTransformer()


# Generated at 2022-06-23 23:27:40.726143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import Source
    from .. import compile
    from ..tree.visitor import visit, NodeTransformer
    from ..compatibility import python_version

    if python_version() > (3, 0):  # pragma: no cover
        pycode = "print('Hello, world')"
    else:  # pragma: no cover
        pycode = "print 'Hello, world'"
    source = Source(pycode)
    ast_tree = source.tree
    expected = compile(source.path, python_version(),
                       flags=ast.PyCF_ONLY_AST)
    transformed = ast_tree
    for node_transformer in (NodeTransformer, YieldFromTransformer):
        transformed = visit(transformed, node_transformer())
    assert ast.dump(transformed) == ast.dump(expected)

# Generated at 2022-06-23 23:27:51.169647
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_node_equal  # type: ignore
    from ..utils.helpers import gen_function, gen_method

    snippet_body = """
    yield from function()
    yield from method()
    yield from iterable
    """
    body = list(gen_function(snippet_body))
    body.append(gen_method(snippet_body))
    node = ast.Module(body=body)

    node = YieldFromTransformer().visit(node)  # type: ignore

# Generated at 2022-06-23 23:28:00.513678
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class MockYieldFromTransformer(YieldFromTransformer):
        def __init__(self, node: ast.AST):
            super(MockYieldFromTransformer, self).__init__(node)

        def _get_yield_from_index(self, node: ast.AST,
                                  type_: Type[Holder]) -> Optional[int]:
            return 0
        def _emulate_yield_from(self, target: Optional[ast.AST],
                                node: ast.YieldFrom) -> List[ast.AST]:
            return [ast.Expr()]

    node = ast.Module()
    assert node.body == []
    MockYieldFromTransformer(node)._handle_assignments(node)
    assert node.body == [ast.Expr(), ast.Expr()]

#

# Generated at 2022-06-23 23:28:09.997007
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import dump
    from .. import load
    from .. import ast_converter

    class TestClass:
        def test_method(self):
            t = (1, dict())
            t[1]['a'] = yield from t[0] + 1

        @classmethod
        def test_cm(cls):
            t = (1, dict())
            t[1]['a'] = yield from t[0] + 1

        @staticmethod
        def test_sm():
            t = (1, dict())
            t[1]['a'] = yield from t[0] + 1

    tree = dump(TestClass)
    YieldFromTransformer().visit(tree)
    TestClass = load(tree)

    assert TestClass.test_method.__code__.co_argcount == 1
    assert Test

# Generated at 2022-06-23 23:28:18.436698
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    import astunparse
    import textwrap
    source = '''
    def g():
        yield
    def f():
        while True:
            yield from g()
            x = 1
            yield from g()
            a = 2
    '''

    expected = '''
    def g():
        yield


    def f():
        while True:
            let(iterable)
            iterable = iter(g())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
            x = 1
            let(iterable)
            iterable = iter(g())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
            a = 2
    '''

    # Act


# Generated at 2022-06-23 23:28:19.293444
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert False

# Generated at 2022-06-23 23:28:24.807944
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.snippet import get_node

    snippet_body = """
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    target = exc.value
                break
    """

    node = get_node(snippet_body, YieldFromTransformer)

    assert not node



# Generated at 2022-06-23 23:28:31.467398
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import os
    import sys
    sys.path.append(os.path.dirname(__file__) + "/..")
    import astunparse
    import pprint
    #from ..utils.source_generator import generate_source
    #from ..utils.helpers import dump_ast
    from ..utils.helpers import cst_to_ast
    cst = ("""
    def someMethod(self, item):
        item = yield from self.someOtherMethod()
    """)
    #print(cst)
    #print(astunparse.dump(cst_to_ast(cst)))
    print(astunparse.dump(YieldFromTransformer().visit(cst_to_ast(cst))))

# Generated at 2022-06-23 23:28:38.597967
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .exceptions import TransformError
    import os, sys, ast
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import utils.helpers
    import utils.snippet
    YFT = YieldFromTransformer()
    assert type(YFT) == YieldFromTransformer
    try:
        assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    except:
        print("Class YieldFromTransformer is not a subclass of BaseNodeTransformer")

# Generated at 2022-06-23 23:28:47.420141
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import os
    from typed_ast import ast3

    with open(os.path.join(os.path.dirname(__file__), '../testdata/YieldFromTransformer_visit.py')) as pyfile:
        test_ast = ast3.parse(pyfile.read())

    class TestYieldFromTransformer(unittest.TestCase):

        def setUp(self) -> None:
            self.transformer = YieldFromTransformer()

        def test_YieldFromTransformer_visit(self):
            self.transformer.visit(test_ast)
            self.assertEqual(self.transformer.get_changed(), True)

    unittest.main()

# Generated at 2022-06-23 23:28:50.488324
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import libcst as cst
    body = cst.parse_module(
        """yield_from = YieldFromTransformer().visit(parse_module(
            code
        ))"""
    ).body
    assert body[1].value.keywords[0].value.args[0].value.value == 'yield_from.py'

# Generated at 2022-06-23 23:28:56.593986
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    import astor
    from ..compile_to_pyc import _compile_and_get_module
    from .base import get_ast, parse_to_ast, compare_asts

    template = '''
    def f():
        a = yield from b
    '''

    for snippet in [template]:
        expected_tree = get_ast(snippet)
        expected_code = typed_astunparse.unparse(expected_tree)
        tree = parse_to_ast(snippet)
        tree = YieldFromTransformer().visit(tree)
        generated_code = typed_astunparse.unparse(tree)

        compare_asts(expected_tree, tree)

        module_old = _compile_and_get_module(snippet)

# Generated at 2022-06-23 23:29:00.146044
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..utils.fake_ast import FakeAST
    from ..transformers.yield_from import YieldFromTransformer
    from ..transformers.compiler_wrapper import CompilerWrapper

# Generated at 2022-06-23 23:29:07.548349
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3
    from ..utils.fakegen import FakeGen
    cut = YieldFromTransformer()
    import sys
    if sys.version_info.minor > 5:
        module = ast3.parse('def f():\n     yield from 33\n     a = yield from [1, 2]\n     yield from (1, 2, 3)')
    else:
        module = ast3.parse('def f():\n     yield from 33\n     a = yield from (1, 2, 3)')

    module = cut.visit(module)
    fake_gen = FakeGen()
    ast3.fix_missing_locations(module)
    code = compile(module, '<test>', 'exec')
    exec(code, fake_gen.globals, fake_gen.locals)


# Generated at 2022-06-23 23:29:19.297242
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:29:28.375328
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fake_node import (
        FakeNode as AST,
        FakeTry as Try,
        FakeIf as If,
        FakeWhile as While,
        FakeFor as For,
        FakeFunctionDef as FunctionDef,
        FakeExpr as Expr,
        FakeYieldFrom as YieldFrom,
        FakeName as Name,
        FakeAssign as Assign,
        FakeModule as Module,
        FakeAttribute as Attribute,
    )

# Generated at 2022-06-23 23:29:39.416405
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import run_python_snippet
    from .. import compile_to_ast

    snippet = """
    def f():
        yield 1
        yield from g()
    """
    expected_result = """
    def f():
        yield 1
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """
    # Compile snippet by running compiler
    compiled = compile_to_ast(snippet, additional_transformers=[YieldFromTransformer()])
    # Compile snippet by running compiler
    result = run_python_snippet(snippet, compiled)

    # Check if

# Generated at 2022-06-23 23:29:49.792535
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.ast_builder import ast_from_snippet, module_to_str
    from ..utils.fake_ast import FakeAst

    snippet.init(ast3)
    ast3.AST = FakeAst
    code = """\
try:
    yield from ()
except StopIteration as exc:
    if hasattr(exc, 'value'):
        value1 = exc.value
    value2 = exc.value
"""
    tree = ast_from_snippet(code)
    transformer = YieldFromTransformer()

    result = transformer.visit(tree)

# Generated at 2022-06-23 23:29:50.799165
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:29:59.486985
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Tree:
        body = [
            ast.Expr(value=ast.YieldFrom(value=ast.Name(id='expression'))),
            ast.Assign(targets=[ast.Name(id='var', ctx=ast.Store())],
                       value=ast.YieldFrom(value=ast.Name(id='expression'))),
            ast.Expr(value=ast.YieldFrom(value=ast.Name(id='expression'))),
            ast.Assign(targets=[ast.Name(id='var', ctx=ast.Store())],
                       value=ast.YieldFrom(value=ast.Name(id='expression')))
        ]


    Tree = YieldFromTransformer().visit(Tree)
    import dis

# Generated at 2022-06-23 23:30:06.338409
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..compiler_unit_test import CompilerUnitTest
    CompilerUnitTest(
        YieldFromTransformer,
        '''
        def f():
            yield from (1,2,3)
        ''',
        '''
        def f():
            let(iterable)
            iterable = iter((1,2,3))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        '''
    )


# Generated at 2022-06-23 23:30:07.352627
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:30:08.857847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import test

# Generated at 2022-06-23 23:30:19.203372
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import textwrap
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    from typed_ast.transforms.YieldFromTransformer import YieldFromTransformer

    class YieldFromTransformerTest(unittest.TestCase):
        def _get_modified_source_code(self, source_code: str) -> str:
            """Returns a modified source code from adding new lines"""
            new_line = "\n"
            lines = source_code.splitlines()
            new_lines = [new_line + line for line in lines]
            modified_source_code = "".join(new_lines)
            return modified_source_code


# Generated at 2022-06-23 23:30:20.528910
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

    assert transformer is not None

# Generated at 2022-06-23 23:30:21.981733
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:30:24.101216
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer('YieldFromTransformer')

if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:30:25.359699
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:28.607528
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast
    try:
        YieldFromTransformer(ast.parse("""
            def f():
                yield from 1
                yield from 2
            """))
    except:
        assert False

# Generated at 2022-06-23 23:30:36.468593
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    snippet = """
    a = yield from [1, 2]
    b = 5
    """
    node = ast.parse(textwrap.dedent(snippet))
    YieldFromTransformer().visit(node)
    expected = """
    exc = None
    iterable = iter([1, 2])
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            a = exc.value
            break
    b = 5
    """
    assert astunparse.unparse(node) == textwrap.dedent(expected)
    snippet = """
    yield from [1, 2]
    b = 5
    """
    node = ast.parse(textwrap.dedent(snippet))

# Generated at 2022-06-23 23:30:46.524462
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from textwrap import dedent

    tree = ast.parse(dedent('''\
    def f():
        yield from g()
        '''))

    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)


# Generated at 2022-06-23 23:30:53.982936
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Before
    tree = ast.parse(
        """
            result = yield from generator()
        """
    )

    # After
    expected_tree = ast.parse(
        """
            exc = None
            iterable = iter(generator())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    result = exc.value
                    break
        """
    )

    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == ast.dump(expected_tree)


# Generated at 2022-06-23 23:31:04.347265
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures import (
        simple_function,
        same_line_function,
        complex_function,
        complex_function_nested_body
    )
    from ..utils.helpers import target

    # simple_function
    source = textwrap.dedent('''\
        def test():
            res = yield from test()
    ''')
    expected = textwrap.dedent('''\
        def test():
            res = None
            let(iterable)
            iterable = iter(test())
            while True:
                try:
                    res = next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        res = exc.value
                    break
    ''')
    assert target(source, YieldFromTransformer) == expected

   

# Generated at 2022-06-23 23:31:11.356273
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = '''
x = (yield from [i for i in range(10)])
    '''

    node = ast.parse(source)
    node2 = YieldFromTransformer().visit(node)