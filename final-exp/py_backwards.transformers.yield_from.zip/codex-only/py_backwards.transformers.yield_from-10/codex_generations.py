

# Generated at 2022-06-23 23:21:02.533495
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source, source_code
    from ..utils.ast import get_ast, compare_asts
    from .. import compile


# Generated at 2022-06-23 23:21:12.069239
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import parse

    # return yield from gen
    root = parse('''
    def func(gen):
        return yield from gen
    ''')  # type: ast.AST

    YieldFromTransformer().visit(root)
    assert root.body[0].body[0].body[0].body[0].target.id == 'exc'

    # yield from gen (yield from in function generator)
    root = parse('''
    def gen():
        yield from range(0)
    ''')  # type: ast.AST

    YieldFromTransformer().visit(root)
    assert root.body[0].body[0].body[0].body[0].target.id == 'exc'

    # yield from gen (yield from in generator comprehension)

# Generated at 2022-06-23 23:21:19.624558
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .index import TranspileTestCase

    class TestYieldFromTransformer(TranspileTestCase):
        def test(self):
            yield_from = ast.YieldFrom(value=ast.Constant(value=1, kind=None), ctx=None)
            expr = ast.Expr(value=yield_from, lineno=1, col_offset=1)
            fdef = ast.FunctionDef(
                name='f',
                args=ast.arguments(args=[], vararg=None, kwonlyargs=[],
                                   kw_defaults=[], kwarg=None, defaults=[]),
                body=[expr],
                decorator_list=[],
                returns=None,
                type_comment=None
            )

            tree = ast.Module(body=[fdef])
            self.check

# Generated at 2022-06-23 23:21:28.401194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_to_code
    from .base import BaseTransformerTestCase

    node = ast.parse('''
        def fn(exc):
            a = yield from b

        def fn2(exc):
            yield from b
    ''')
    case = BaseTransformerTestCase(YieldFromTransformer, node)

# Generated at 2022-06-23 23:21:29.998996
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:31.589933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    assert YieldFromTransformer() is not None

# Generated at 2022-06-23 23:21:32.895697
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    i = YieldFromTransformer()
    assert i is None


# Generated at 2022-06-23 23:21:33.869601
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = YieldFromTransformer()


# Generated at 2022-06-23 23:21:42.540587
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import typed_ast.ast3 as ast
    from ..utils.testing import VFSTestCase

    class TestYieldFromTransformer(VFSTestCase):
        def setUp(self):
            with self.mock_folder('cpython-3.2'):
                from ..transformers.buildins import FuncTransformer
                from ..transformers.variables import VariablesTransformer
                from ..transformers.exceptions import ExceptionsTransformer
                from ..transformers.from_import import FromImportTransformer
                #from ..transformers.async_await import AsyncAwaitTransformer
                from ..transformers.metaclass import MetaclassTransformer
                from ..transformers.super import SuperTransformer

# Generated at 2022-06-23 23:21:45.733281
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  from typed_ast import ast3 as ast
  class Dummy(ast.AST):
    _fields = []
    _attributes = []
    def __init__(self):
      pass
  YieldFromTransformer(Dummy())

# Generated at 2022-06-23 23:21:46.662907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print(YieldFromTransformer())


# Generated at 2022-06-23 23:21:54.731963
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""
a = yield from b
c = d + e
f = g + yield from h
""")
    trans = YieldFromTransformer()
    trans.visit(tree)
    result = ast.dump(tree).split("\n")

# Generated at 2022-06-23 23:21:56.722026
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom()
    assert isinstance(YieldFromTransformer(True, 0), YieldFromTransformer)

# Generated at 2022-06-23 23:21:57.735799
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:21:58.354459
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass

# Generated at 2022-06-23 23:21:59.322591
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:22:09.802411
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import check, check_not, check_on_fail
    from .unpacking import UnpackingTransformer
    from .function_conversion import FunctionConversion
    from .eliminate import EliminateBuiltinLocals
    from .oneline import OnelineTransformer

    input = """\
    def foo():
        one = (yield from bar())
        yield from bar(one)

    def bar():
        yield 7
        yield 8
        yield 9
    """

# Generated at 2022-06-23 23:22:18.825542
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseGeneratorVisitor
    from .base import BaseGeneratorVisitorTestHelper
    from .base import create_snippet_from_node

    # test variables
    node_str = ""
    expected_str = ""
    generated_str = ""

    for input_str, expected_str, expr_type in BaseGeneratorVisitorTestHelper.yield_from_test_cases:
        # test code
        node_str = """def a():
    yield from b()
    yield 0
    """

        node = create_snippet_from_node(node_str)
        visitor = YieldFromTransformer()
        result = visitor.visit(node)

        generated_str = BaseGeneratorVisitor.get_str(result)

        assert generated_str == expected_str



# Generated at 2022-06-23 23:22:23.795426
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    from .code_to_ast import transform

    input_code = 'a = yield from b'
    expected_code = "ex_2 = iter(b);\nwhile True:\n    try:\n        a = next(ex_2)\n    except StopIteration as ex_1:\n        a = ex_1.value\n        break"
    expected_ast = transform(expected_code)

    actual_ast = YieldFromTransformer().visit(transform(input_code))  # type: ignore

    assert actual_ast == expected_ast

# Generated at 2022-06-23 23:22:27.547863
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typetrainer.utils.tree import smart_print
    from ..utils.helpers import compile_tree
    from ..utils.parser import parse_tree


# Generated at 2022-06-23 23:22:29.186445
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Test for method visit of class YieldFromTransformer."""
    # Arrange

# Generated at 2022-06-23 23:22:37.688206
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test case 1
    source = '''
x = yield from a
'''
    expected = '''
let(iterable)
iterable = iter(a)
while True:
    try:
        next(iterable)
    except StopIteration as exc:
        x = exc.value
        break
'''
    mod = ast.parse(source)
    YieldFromTransformer().visit(mod)
    actual = ast.unparse(mod)
    assert actual.strip() == expected.strip()

    # Test case 2
    source = '''
yield from a
'''
    expected = '''
let(iterable)
iterable = iter(a)
while True:
    try:
        next(iterable)
    except StopIteration as exc:
        break
'''

# Generated at 2022-06-23 23:22:47.631194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.build_tree import build_ast

    def test1():
        i = yield from range(5)
        print(i)

    def test2():
        v, i = yield from enumerate(range(5))
        print(i)

    def test3():
        yield from range(5)

    def test4():
        v = None
        yield from range(5)

    def test5():
        yield from range(5)

    def test6():
        yield from range(5)
        yield from range(5)

    def test_func(func, expected):
        assert ast.dump(YieldFromTransformer().visit(build_ast(func))) == expected


# Generated at 2022-06-23 23:22:55.866770
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import UnitTestTransformer
    from ..lexer import PythonLexer

    lexer = PythonLexer()
    transformers = [YieldFromTransformer]
    transformer = UnitTestTransformer(transformers, lexer=lexer)

    def run(code: str, expected: str, target: str = '3.0') -> None:
        result = transformer.run(code, target=target)
        assert result.code == expected


# Generated at 2022-06-23 23:22:57.197670
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert not YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-23 23:23:00.577551
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    m = ast.parse('''
    def func():
        if x:
            yield from y
    ''')

    class ModuleTransformer(YieldFromTransformer):
        def visit_Module(self, node):
            return self.generic_visit(node)

    transformer = ModuleTransformer()
    transformer.visit(m)
    assert transformer.tree_changed

# Generated at 2022-06-23 23:23:07.056548
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:23:17.102376
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import compile_to_ast

    def f(b):
        if b:
            s = yield from g()
        else:
            s = yield from g()
        return s

    def g():
        yield 1
        yield 2


# Generated at 2022-06-23 23:23:18.000902
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TODO
    return True

# Generated at 2022-06-23 23:23:26.412931
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transform = YieldFromTransformer()
    yield_from_node = ast.YieldFrom(value=ast.Name(id="x", ctx=ast.Load()))

# Generated at 2022-06-23 23:23:27.699695
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        assert False



# Generated at 2022-06-23 23:23:37.280351
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """def a():
    yield from b()
    yield from c()
    """
    tree = ast.parse(code)
    x = YieldFromTransformer()
    x.visit(tree)
    expected_code = """def a():
    iterable = iter(b())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    iterable = iter(c())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    """
    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 23:23:39.519153
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer.__instance__ is None)
    YieldFromTransformer()
    assert(YieldFromTransformer.__instance__ is not None)

# Generated at 2022-06-23 23:23:48.927635
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from . import transform

    code = """
        def f(obj):
            x = yield from obj
            yield from obj

    """
    expected_code = """
        def f(obj):
            iterable = iter(obj)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    x = exc.value
                    break

            iterable = iter(obj)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

    """

    module = transform(code, [YieldFromTransformer])
    assert module.dumps() == expected_code

# Generated at 2022-06-23 23:24:00.468765
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def my_func(x, y):
        y = yield from x
        yield y
    """
    tree = ast.parse(code)
    tr = YieldFromTransformer()
    tr.visit(tree)


# Generated at 2022-06-23 23:24:07.437999
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("def f():\n    a = yield from range(1)\n")
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert len(tree.body[0].body) == 3
    assert isinstance(tree.body[0].body[1], ast.While)
    assert isinstance(tree.body[0].body[1].body, list)
    assert isinstance(tree.body[0].body[1].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[1].body[0].value, ast.Yield)

# Generated at 2022-06-23 23:24:09.077656
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-23 23:24:19.947458
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .testutils import transform, check_visitor
    from .helpers import decorator
    from ..utils import let

    mod = ast.Module(
        body=[
            ast.Expr(value=ast.YieldFrom(
                value=let(a)
            ))
        ]
    )
    mod = transform(YieldFromTransformer, mod)
    check_visitor(mod, 'yield_from', YieldFromTransformer)

    mod = ast.Module(
        body=[
            ast.Assign(targets=[
                let(a)
            ], value=ast.YieldFrom(
                value=let(b)
            ))
        ]
    )
    mod = transform(YieldFromTransformer, mod)
    check_visitor(mod, 'yield_from', YieldFromTransformer)

# Generated at 2022-06-23 23:24:28.878537
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit testing for the constructor of class YieldFromTransformer"""
    # Create an instance of argument
    argument = ast.arg(arg='arg', annotation=None)
    # Create an instance of arguments
    arguments = ast.arguments(args=[argument],
                              vararg=None,
                              kwonlyargs=[],
                              kw_defaults=[],
                              kwarg=None,
                              defaults=[])
    # Create an instance of keyword
    keyword = ast.keyword(arg='arg', value=None)
    # Create an instance of compare
    compare = ast.Compare(left=ast.Name(id='a', ctx=ast.Load()),
                          ops=[ast.Lt()],
                          comparators=[ast.Name(id='b', ctx=ast.Load())])
    # Create an instance

# Generated at 2022-06-23 23:24:33.980996
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    import astor
    snippet = 'def test(): yield from (a for a in [1,2,3])'
    tree = ast.parse(snippet)
    YieldFromTransformer().visit(tree)
    print(astor.to_source(tree))

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:24:43.121276
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..unit_test import assert_program

    t = YieldFromTransformer()

    tree = ast.parse("""
        def func():
            result = yield from func()
        """)

    assert_program(
        t.visit(tree),
        """
        def func():
            let(iterable)
            iterable = iter(func())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    result = exc.value
                    break
        """,
        name='test_YieldFromTransformer_visit',
        mode=ast.PyCF_ONLY_AST,
    )

    tree = ast.parse("""
        def func():
            yield from func()
        """)


# Generated at 2022-06-23 23:24:44.322243
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is YieldFromTransformer

# Generated at 2022-06-23 23:24:54.238347
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    code = textwrap.dedent("""
    def gen():
        yield from [1, 2, 3]
        yield from 'abc'
        while True:
            x = yield from range(10)
            y = yield from (1, 2, 3)
            if x == y:
                break
        try:
            yield from 'def'
        finally:
            pass
    """)
    module_node = ast.parse(code)
    node_transformed = YieldFromTransformer().visit(module_node)
    code_transformed = astunparse.unparse(node_transformed)

# Generated at 2022-06-23 23:25:00.297067
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = "def test(): \n    yield from some_generator()"
    expected = "def test():\n    let(iterable)\n    iterable = iter(some_generator())\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            break"
    parsed = ast.parse(source)
    transformed = YieldFromTransformer().visit(parsed)
    assert astor.to_source(transformed) == expected

# Generated at 2022-06-23 23:25:06.573533
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import parse

    # Body is list of ast.AST
    tree = parse("""
    def func():
        a = yield from b
        yield from c
        (yield from d)
        yield from e
    """)

    node = YieldFromTransformer().visit(tree)
    first = node.body[0].body[0]
    assert isinstance(first, ast.Assign)
    if isinstance(first.targets[0], ast.Name):
        # First yield from is in value of ast.Assign
        assert first.value.id.lower() == 'yield_from'
    else:
        assert False
    second = node.body[0].body[1]
    assert isinstance(second, ast.Assign)
    assert second.targets[0].id.lower()

# Generated at 2022-06-23 23:25:16.254039
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
    def foo(x):
        if x is 1:
            c = (yield from range(10))

            yield from bar(x, c)
        else:
            d = (yield from range(10))
    """

# Generated at 2022-06-23 23:25:27.791977
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .function_transformer import FunctionTransformer
    from .loop_transformer import LoopTransformer
    from .try_transformer import TryTransformer
    from ..core import TranspilerCore
    from ..helpers import compile_source
    from ..utils.tree import print_ast

    source = """
    def test():
        yield from (x for x in [1, 2])
    """
    test = compile_source(source, 'test', 'exec')

    core = TranspilerCore()
    core.add_transformer(YieldFromTransformer)
    core.add_transformer(FunctionTransformer)
    core.add_transformer(LoopTransformer)
    core.add_transformer(TryTransformer)
    core.add_transformer(YieldFromTransformer)
    core.compile_node(test)


# Generated at 2022-06-23 23:25:29.090017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-23 23:25:31.650615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer.target == (3, 2)
    assert transformer._tree_changed == False
    assert transformer._get_yield_from_index(0,0) == None

# Generated at 2022-06-23 23:25:33.623548
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ntt = YieldFromTransformer()
    assert isinstance(ntt, BaseNodeTransformer)
    assert ntt.name == 'YieldFromTransformer'


# Generated at 2022-06-23 23:25:44.956101
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast
    from ..transformer import Transformer
    from ..utils.misc import source

    class Test(ast.AST):
        _fields = ('body', )

        def __init__(self, body):
            self.body = body

    assignment = ast.Assign(
        targets=[ast.Name(id='a', ctx=ast.Store())],
        value=ast.YieldFrom(value=ast.Call(
            func=ast.Name(id='range', ctx=ast.Load()),
            args=[ast.Num(n=3)],
            keywords=[]))
    )


# Generated at 2022-06-23 23:25:46.100375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:49.120248
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    import astor
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import NodeTransformerLazyHelpers
    from .unpacking_transformer import UnpackingTransformer


# Generated at 2022-06-23 23:25:57.074726
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Unit test for constructor of class YieldFromTransformer
    '''
    code = compile("""
        def a(s):
            a = yield from s
            c = yield from s
            return c
    """, filename='<ast>', mode='exec')

    # Get AST of the code
    root = ast.parse(code)

    # Create object of YieldFromTransformer
    y = YieldFromTransformer()

    # Apply transformations
    y.visit(root)

    # Print resulting AST
    ast.fix_missing_locations(root)
    code2 = compile(root, filename="<ast>", mode="exec")

    # Compare code before/after transformations
    assert code2 != code

# Generated at 2022-06-23 23:26:07.825372
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..general import GeneralTransformer
    from ..utils.ast_builder import build_ast

    source = """
        def test():
            a = yield from b
            yield from c
            test(yield from d)
    """


# Generated at 2022-06-23 23:26:18.053374
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from yatypy.transpilers.yield_from import YieldFromTransformer

    code = '''
try:
    foo = yield from x
finally:
    pass
'''
    tree = ast.parse(code)
    tree = YieldFromTransformer().visit(tree)
    assert astor.to_source(tree) == '''\
try:
    iterable = iter(x)
    while True:
        try:
            foo = next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                foo = exc.value
            break
finally:
    pass
'''
    code = '''
try:
    yield from x
finally:
    pass
'''
    tree = ast.parse(code)


# Generated at 2022-06-23 23:26:20.746464
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Constructor for class YieldFromTransformer."""
    # pylint: disable=W0612
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:26:30.033537
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def test(code, expected):
        t = YieldFromTransformer()
        node = ast.parse(code)
        result = ast.dump(t.visit(node))
        assert result == expected


# Generated at 2022-06-23 23:26:31.329569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-23 23:26:32.631823
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import ast_converter

# Generated at 2022-06-23 23:26:33.298614
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

# Generated at 2022-06-23 23:26:35.192266
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit testing for YieldFromTransformer.__init__()."""
    assert callable(YieldFromTransformer)


# Generated at 2022-06-23 23:26:41.247442
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as pyast
    from ..tools import ast_to_source

    # Test tree

# Generated at 2022-06-23 23:26:48.464314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import parse

    YieldFromTransformer(parse("""
        def gen():
            yield 3
            yield from gen_nested()
        def gen_nested():
            yield 4
            yield 5
        """)).visit() == parse("""
        def gen():
            yield 3
            let(iterable)
            iterable = iter(gen_nested())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        def gen_nested():
            yield 4
            yield 5
        """)


# Generated at 2022-06-23 23:26:50.008908
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert(t._tree_changed == False)

# Generated at 2022-06-23 23:26:59.511774
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import Source
    from ..utils.node import compare_nodes
    from ..utils.compat import version_info
    from ..utils.helpers import dump_tree, load_tree

    if version_info < (3, 3):
        return

    # noinspection PyArgumentList
    expected = YieldFromTransformer().visit(load_tree('def fun():\n    yield from [1]\n'))
    actual = load_tree('def fun():\n    iterable = iter([1])\n    while True:\n        try:\n            yield next(iterable)\n'
                       '        except StopIteration as exc:\n            break\n')
    assert compare_nodes(expected, actual) is True


# Generated at 2022-06-23 23:27:09.913244
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import testing
    from ..testing import helpers
    from ..testing.assertions import assert_equal_code
    from ..utils.helpers import VariablesGenerator
    # examples for method visit of class YieldFromTransformer with argument
    # (node: ast.AST) -> ast.AST.

    # example 0, without argument
    target0 = (3, 2)
    node0 = ast.Expr(
        ast.YieldFrom(
            ast.Call(
                ast.Name('foo', ast.Load()),
                [ast.Num(1), ast.Num(2)],
                []
            )
        )
    )

# Generated at 2022-06-23 23:27:17.760396
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        def test_imports(self):
            transformer = YieldFromTransformer()
            self.assertEqual(transformer.get_import_froms(), [])

        def test_yield_from_in_other_place(self):
            body = []
            body.append(ast.Expr(value=ast.YieldFrom(value=ast.Name("a", ast.Load()))))
            body.append(ast.Expr(value=ast.YieldFrom(value=ast.Name("b", ast.Load()))))
            body.append(ast.Expr(value=ast.YieldFrom(value=ast.Name("c", ast.Load()))))


# Generated at 2022-06-23 23:27:21.020540
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node_transformer = YieldFromTransformer()
    assert isinstance(node_transformer, BaseNodeTransformer)

# Unit tests for functions defined in module yield_from_transformer.py

# Generated at 2022-06-23 23:27:23.509286
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.syntax_tree import syntax_tree, print_syntax_tree


# Generated at 2022-06-23 23:27:35.461764
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typing
    import ast
    import typed_ast.ast3 as ast3
    from asttokens import ASTTokens
    from .YieldFromTransformer import YieldFromTransformer
    from .utils.tree import print_tokens
    from .utils.parse import parse_string

    program = '''
    def f():
        a = yield from g()
        yield from g()
        yield from g()
        yield from g()
        b = a
        return a
    '''

    node = parse_string(program)
    transformer = YieldFromTransformer()
    new_node = transformer.visit(node)
    tokens = ASTTokens(program, parse=True)
    print_tokens(tokens)
    print_tokens(ASTTokens(new_node))


# Generated at 2022-06-23 23:27:37.048717
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:46.930197
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os.path
    from ..utils.source import source_to_unicode
    from ..transpile import Transpiler
    from ..modules import PythonModule

    parent_directory = os.path.dirname(os.path.realpath(__file__))
    module_path = os.path.join(parent_directory,
                               '..', 'test_data',
                               'yield_from.py')

    module = PythonModule.from_filename(module_path)
    transpiled_source = Transpiler(module, [YieldFromTransformer]).transpile()

    with open(os.path.join(parent_directory,  # type: ignore
                           '..', 'test_data',
                           'yield_from_transformed.py')) as file:
        expected_source = source_to_

# Generated at 2022-06-23 23:27:53.067957
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import parse

    code = """\
    from typing import AsyncIterator

    async def foo(arg: AsyncIterator[int]) -> None:
        value = await arg.__anext__()
        if value is not None:
            value2 = await arg.__anext__()\
    """
    module = parse(code)
    YieldFromTransformer().visit(module)

# Generated at 2022-06-23 23:28:00.468006
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal
    from .unpacking import UnpackingTransformer

    @snippet
    def func():
        let(subgen)
        subgen = (i for i in range(10))
        yield from subgen
        x = yield from subgen

    tree = func.get_ast()
    tree = UnpackingTransformer().visit(tree)
    expected = YieldFromTransformer().visit(tree)
    assert_tree_equal(expected, func.get_expected_ast())
    assert_code_equal(func, func.get_expected_code())

# Generated at 2022-06-23 23:28:09.951466
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Assign, Name, Expr, YieldFrom, Store, Module
    from ..utils.helpers import to_source
    from ..utils.tree import ast_to_tree
    import astunparse

    module = parse("""yield_from = 1\n""")
    YieldFromTransformer().visit(module)
    result = astunparse.unparse(module)
    assert result.strip() == '"""yield_from = 1\n"""'

    module = parse("""yield_from = yield from 1\n""")
    YieldFromTransformer().visit(module)
    result = astunparse.unparse(module)

# Generated at 2022-06-23 23:28:18.405032
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import dump_ast
    from ..transformers import TransformerSequence
    from ..transformers.yield_from import YieldFromTransformer
    import ast

    transformer = TransformerSequence([YieldFromTransformer])

    source = source_to_unicode("""
    class Foo:
        def __iter__(self):
            yield from range(10)
    """)
    tree = ast.parse(source)
    transformer.visit(tree)

# Generated at 2022-06-23 23:28:21.352347
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test YieldFromTransformer constructor."""
    _ = YieldFromTransformer()


# Unit tests for method _get_yield_from_index

# Generated at 2022-06-23 23:28:24.891846
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft.target == (3,2)
    assert yft.module == None
    assert yft.tree_changed == False
    assert yft._tree_changed == False


# Generated at 2022-06-23 23:28:25.862488
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()

# Generated at 2022-06-23 23:28:28.109974
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.example_ast import EXAMPLE_AST
    node = EXAMPLE_AST
    assert (YieldFromTransformer().visit(node))

# Generated at 2022-06-23 23:28:33.259279
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__module__ == __name__
    assert YieldFromTransformer.__qualname__ == __name__ + '.YieldFromTransformer'
    assert YieldFromTransformer.target == (3, 2)


# Generated at 2022-06-23 23:28:42.886615
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    class Test(unittest.TestCase):
        def test_yield_from_assignment(self):
            # yield from assignment
            node = ast.parse("x = yield from y()")
            YieldFromTransformer().visit(node)
            self.assertEqual(ast.dump(node),
                             "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='next', ctx=Load()), args=[Name(id='iterable', ctx=Load())], keywords=[]))])")

        def test_yield_from_function(self):
            # yield from call
            node = ast.parse("yield from y()")
            YieldFromTransformer().visit(node)
            self.assertE

# Generated at 2022-06-23 23:28:44.236245
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None


# Generated at 2022-06-23 23:28:49.656516
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    class TestClass(YieldFromTransformer):
        def __init__(self, node: Node):
            super().__init__(node)

    if __name__ == "__main__":
        print(astor.dump_tree(ast.parse('''
a = yield from b
''')))
        print(astor.dump_tree(TestClass(ast.parse('''
a = yield from b
'''))))


# Generated at 2022-06-23 23:28:50.600393
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:28:52.360793
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import construct_source, construct_ast, assemble_ast
    from ..node_transformation import NodeTransformation


# Generated at 2022-06-23 23:29:02.392601
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:29:05.600807
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse('yield from x')
    transformer = YieldFromTransformer()
    new_node = transformer.visit(node)
    expected_node = ast.parse('let(iterable); iterable = iter(x); while True: try: yield next(iterable) except StopIteration as exc: pass')
    assert ast.dump(new_node) == ast.dump(expected_node)



# Generated at 2022-06-23 23:29:09.647036
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import sample
    t = YieldFromTransformer()
    t.visit(sample.ast)
    if hasattr(sample, 'expected_ast'):
        expected_source = astunparse.unparse(sample.expected_ast)
    else:
        expected_source = astunparse.unparse(sample.ast)
    source = astunparse.unparse(t.visit(sample.ast))
    assert source == expected_source

# Generated at 2022-06-23 23:29:16.012086
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    snippet = """
    try:
        1
    except:
        yield from []
    """
    tree = ast.parse(snippet)
    new_tree = YieldFromTransformer().visit(tree)
    code = compile(new_tree, '', 'exec')

# Generated at 2022-06-23 23:29:17.964367
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj is not None

# Generated at 2022-06-23 23:29:22.524956
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer

    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'

    YieldFromTransformer()


# Generated at 2022-06-23 23:29:24.956141
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert_class(YieldFromTransformer, BaseNodeTransformer)
    YieldFromTransformer.__init__(YieldFromTransformer)


# Generated at 2022-06-23 23:29:26.135837
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None


# Generated at 2022-06-23 23:29:28.535184
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse as ast_parse

    def transform(tree: ast.AST) -> ast.AST:
        transformer = YieldFromTransformer()
        return transformer.visit(tree)


# Generated at 2022-06-23 23:29:39.601537
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''
    def foo():
        x = yield from bar
        try:
            yield from baz
        finally:
            yield from qux
        while True:
            yield from quux
    '''

# Generated at 2022-06-23 23:29:49.980183
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Tested(YieldFromTransformer):
        def __init__(self, *args):
            self.actual = []
            self.expected = []

        def _generic_visit(self, *args):
            self.actual.append(args)
            return None

        def _handle_assignments(self, *args):
            self.actual.append(args)
            return self.expected.pop(0)

        def _handle_expressions(self, *args):
            self.actual.append(args)
            return self.expected.pop(0)

    t = Tested()
    t.expected.append(object())
    assert t.visit(object()) is object()
    assert t.actual == [(object(),)]

    t = Tested()
    t.expected.extend([object(), object()])


# Generated at 2022-06-23 23:29:58.946495
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse

    def test(node):
        print('\n', astunparse.unparse(node))
        transformer = YieldFromTransformer()
        transformed_node = transformer.visit(node)

        print('\n', astunparse.unparse(transformed_node))

    stmt1 = ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load()))
    stmt2 = ast.YieldFrom(value=ast.Name(id='b', ctx=ast.Load()))
    test(ast.Expr(value=stmt1))
    test(ast.Expr(value=stmt2))

    new_name = ast.Name(id='target', ctx=ast.Store())

# Generated at 2022-06-23 23:29:59.800951
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:30:01.453675
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . constructor import Constructor

# Generated at 2022-06-23 23:30:02.361181
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True



# Generated at 2022-06-23 23:30:04.945325
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Initializes the generator, which will be under test.
    generator = YieldFromTransformer()
    assert generator



# Generated at 2022-06-23 23:30:15.291757
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import sys
    import ast
    import re
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    import unittest
    import os


    class TestYieldFromTransformer(unittest.TestCase):

        def setUp(self):
            self.transformer = YieldFromTransformer()
            file = os.path.join(os.path.dirname(__file__), 'input.py')
            with open(file) as f:
                source = f.read()
            self.expected_tree = ast.parse(source)

# Generated at 2022-06-23 23:30:24.119720
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class T(YieldFromTransformer):
        def _get_yield_from_index(self, node, type_):
            return 0
    
    b = ast.Module(body=[
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.YieldFrom(value=ast.Constant(value=None))),
        ast.Expr(value=ast.YieldFrom(value=ast.Constant(value=None))),
        ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=ast.YieldFrom(value=ast.Constant(value=None)))
    ])

# Generated at 2022-06-23 23:30:25.366574
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-23 23:30:33.071842
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = "yield from A()"
    new_code = "while True:\n    try:\n        yield next(iterable)\n    except StopIteration as exc:\n        if hasattr(exc, 'value'):\n            exc.value = exc.value\n        break\niterable = iter(A())"
    import re
    from typed_ast import parse
    
    assert re.sub(r"\s+", "", YieldFromTransformer().visit(parse(code)).body[0].body[0].body.value.targets[0].func.id) == re.sub(r"\s+", "", new_code)

# Generated at 2022-06-23 23:30:40.348457
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from src.frameworks.python.utils.helpers import compile_ast_node
    from inspect import cleandoc
    from typing import cast

    def check(code: str, expected: str) -> None:
        actual = cast(ast.Module, compile_ast_node(code)).body[0]
        assert expected == cleandoc(ast.unparse(actual).strip())

    check("f = yield from []", """
            def f():
                exc = VariablesGenerator.generate('exc')
                iterable = iter(exc)
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        f = exc.value
                        break
    """)


# Generated at 2022-06-23 23:30:42.243403
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.converter import Converter
    from ..utils.runner import Runner


# Generated at 2022-06-23 23:30:52.488815
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import test
    from autonameow.core.ast_compiler import compile_to_source_code
    from ..tests.utils import get_yield_from

    test(
        'yield from foo() -> (while True: yield next(iter(foo())))'
    )

    tree = ast.parse(
        'yield from foo()',
        mode='exec',
    )
    tree = YieldFromTransformer().visit(tree)
    source_code = compile_to_source_code(tree, 'YieldFromTransformer')

    expected = (
        """
        def f():
            iterable = iter(foo())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        """
    )
    assert expected in source_

# Generated at 2022-06-23 23:30:55.027979
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer(True, True)
    assert isinstance(instance, BaseNodeTransformer)
    assert instance.visit(1) == 1


# Generated at 2022-06-23 23:31:05.617947
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    sys.path.append('/Users/nathaningram/Desktop/yield_from_to_while')
    import astunparse
    from typed_astunparse import ast3unparse
    node = ast.parse('''def yf():
        yield from fn()''')
    print(type(node))
    print(type(node.body))
    print(type(node.body[0]))
    print(type(node.body[0].body))
    print(type(node.body[0].body[0]))
    transformer = YieldFromTransformer()
    print(type(transformer))
    for i, node in enumerate(node.body[0].body):
        print(i, node)
    print(astunparse.unparse(transformer.visit(node)))
   