

# Generated at 2022-06-23 23:21:07.469375
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
            def f():
                string = 'text'
                a = yield from function(string)
    """
    expected_code = """
            def f():
                string = 'text'
                let(iterable)
                iterable = iter(function(string))
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        if hasattr(exc, 'value'):
                            a = exc.value
                        break
    """
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    generated_code = astor.to_source(tree).strip()
    assert generated_code == expected_code.strip()

# Generated at 2022-06-23 23:21:08.656143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-23 23:21:17.100851
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:25.186278
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	trans = YieldFromTransformer()
	code = """a = yield from b"""
	tree = ast.parse(code)
	new_tree = trans.visit(tree)
	node = new_tree.body[0]
	iterable = node.value.body[0]
	assert iterable.targets[0].id == 'iterable'
	assert isinstance(iterable.value, ast.Call)
	for_loop = node.value.body[1]
	assert isinstance(for_loop, ast.While)
	try_statement = for_loop.body[0]
	assert isinstance(try_statement, ast.Try)
	assert isinstance(try_statement.body[0], ast.Expr)
	assert isinstance(try_statement.body[0].value, ast.Yield)
	

# Generated at 2022-06-23 23:21:28.357430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.target == (3, 2)
    YieldFromTransformer()

# Unit tests for method _get_yield_from_index of class YieldFromTransformer

# Generated at 2022-06-23 23:21:31.663463
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert isinstance(x, BaseNodeTransformer)
    assert x.target == (3, 2)
    assert x._tree_changed == False
    

# Generated at 2022-06-23 23:21:34.010240
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Testing constructor')
    try:
        YieldFromTransformer()
    except TypeError:
        print('FAILED')
    else:
        print('PASSED')

# Generated at 2022-06-23 23:21:42.694461
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import List, Union
    from typed_ast import ast3 as ast
    from ..utils.helpers import run_transformer

    source = '''\
    def test1(x):
        a = yield from x
        b = yield from x
        c = yield from x
        return a, b, c

    def test2(x):
        yield from x
        yield from x
        yield from x
    '''

# Generated at 2022-06-23 23:21:46.295755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import module
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    YieldFromTransformer(None)


# Generated at 2022-06-23 23:21:51.974392
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast, inspect, os
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)
    from ast_helper import ast_to_str
    from yapf.yapflib.yapf_api import FormatCode

# Generated at 2022-06-23 23:22:00.501974
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astor.source_repr import Source
    from .base import FakeTree
    from .fixtrans import FixTryTransformer
    from ..utils.helpers import ModuleHelper

    tree = FakeTree()
    tree.add_func(["def foo():",
                   "    return 'bar'",
                   "",
                   "def baz():",
                   "    return foo()",
                   "",
                   "def y():",
                   "    return baz()"],
                  "y")

    transforms = [FixTryTransformer, YieldFromTransformer]
    helper = ModuleHelper(transforms)
    mod = helper.transform(tree.get_root())

    source = Source(mod)
    source.put_with_spaces()

# Generated at 2022-06-23 23:22:10.847422
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # TEST 1: test if node of type Node is passed into visit
    with pytest.raises(AssertionError):
        YieldFromTransformer().visit('node')
    # TEST 2: test if node of type Node is returned by _handle_assignments
    with pytest.raises(AssertionError):
        YieldFromTransformer()._handle_assignments('node')
    # TEST 3: test if node of type Node is returned by _handle_expressions
    with pytest.raises(AssertionError):
        YieldFromTransformer()._handle_expressions('node')
    # TEST 4: test if node of type Holder is passed into _get_yield_from_index
    with pytest.raises(AssertionError):
        YieldFromTransformer()._get_yield_from_index

# Generated at 2022-06-23 23:22:12.250639
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import asttyped as ast
    

# Generated at 2022-06-23 23:22:19.839205
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as pyast
    from ..internals.transformers.yield_from import YieldFromTransformer
    node = pyast.parse(
        '''
        def test(a):
            b = (yield from a)
            c = (yield from a)
        '''
    )
    result = YieldFromTransformer().visit(node)
    assert isinstance(result, pyast.Module)
    assert len(result.body) == 1
    assert isinstance(result.body[0], pyast.FunctionDef)
    assert len(result.body[0].body) == 2
    assert isinstance(result.body[0].body[0].value, pyast.Call)


# Generated at 2022-06-23 23:22:23.762261
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..utils.helpers import get_ast
    code = """a = yield from x"""
    ast_node = get_ast(code)
    print(astor.to_source(ast_node))
    t = YieldFromTransformer()
    new_ast = t.visit(ast_node)
    print(astor.to_source(new_ast))

# Generated at 2022-06-23 23:22:33.147541
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ast_helper import ast_from_str
    node = ast_from_str('def func():\n'
                        '    yield from a\n'
                        '    yield from b\n'
                        '    c = yield from d\n')
    tr = YieldFromTransformer()
    node = tr.visit(node)
    assert astor.to_source(node) == (
            'def func():\n'
            '    yield from a\n'  # TODO: fix yield from
            '    yield from b\n'  # TODO: fix yield from
            '    c = yield from d\n'  # TODO: fix yield from
    )

# Generated at 2022-06-23 23:22:40.654608
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    import textwrap
    import unittest
    from typing import Any

    class TestYieldFromTransformer(unittest.TestCase):
        def setUp(self) -> None:
            self.transformer = YieldFromTransformer()

        def check_transform(self, before: str, after: str) -> None:
            tree = ast.parse(before)
            tree = self.transformer.visit(tree)
            self.assertEqual(astor.to_source(tree), after)


# Generated at 2022-06-23 23:22:49.031253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.transforms.YieldFromTransformer import YieldFromTransformer
    module = ast.parse("""def func(iterable):\n    yield from iterable""")
    transformer = YieldFromTransformer()
    transformer.visit(module)
    assert len(list(transformer.generic_visit(module))) == 2
    assert list(transformer.generic_visit(module))[0].value == 'func'
    assert list(transformer.generic_visit(module))[1].value == None
    transformer2 = YieldFromTransformer()
    transformer2.visit(module)

# Generated at 2022-06-23 23:22:49.916827
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:53.421895
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('def foo(): yield from bar()')
    print(ast.dump(node, include_attributes=True))

    tr = YieldFromTransformer()
    node = tr.visit(node)
    print(ast.dump(node, include_attributes=True))



# Generated at 2022-06-23 23:23:00.524057
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.example import Example
    from ..compat import py_ver
    from ..utils.base import BaseCompiler

    class MyCompiler(BaseCompiler):
        @staticmethod
        def optimize(tree):
            return YieldFromTransformer().visit(tree)


# Generated at 2022-06-23 23:23:09.373235
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3

    yieldFrom = ast3.YieldFrom()
    assert isinstance(yieldFrom, ast3.YieldFrom)
    assert yieldFrom.value is None
    assert yieldFrom.lineno is None
    assert yieldFrom.col_offset is None

    functionDef = ast3.FunctionDef(name="test")
    assert functionDef.name == "test"
    assert functionDef.args.args is None
    assert functionDef.args.vararg is None
    assert functionDef.args.kwonlyargs is None
    assert functionDef.args.kwarg is None
    assert functionDef.args.defaults is None
    assert functionDef.args.kw_defaults is None
    assert functionDef.body is None
    assert functionDef.returns is None
    assert functionDef.decorator_list is None

# Generated at 2022-06-23 23:23:11.702895
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import python_to_python_js

# Generated at 2022-06-23 23:23:14.302327
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from .. import compile_restricted, forbidden_import_ast, ast_parse
    from ..testing_helpers import assert_code_equal


# Generated at 2022-06-23 23:23:15.276739
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
# vim: et sw=4 ts=4

# Generated at 2022-06-23 23:23:20.336267
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    tree = astor.parse(r"""
if True:
    a = yield from b
    yield from c
    f(x) = yield from d
    while True:
        yield from a
    for g in h:
        yield from f(g)
    def a():
        yield from x""")
    YieldFromTransformer().visit(tree)

    print(astor.to_source(tree))


# Generated at 2022-06-23 23:23:26.303615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	target = ast.parse('yield from a')
	expected = ast.parse('''
		let(iterable)
		iterable = iter(a)
		while True:
		    try:
		        yield next(iterable)
		    except StopIteration as exc:
		        if hasattr(exc, 'value'):
					target = exc.value
		        break
	''')


	"""docstring for test_YieldFromTransformer"""
	assert YieldFromTransformer().visit(target) == expected

# Generated at 2022-06-23 23:23:31.811946
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    from typed_astunparse import unparse
    from .base import TransformerTestCase
    import unittest

    @snippet
    def try_finally():
        try:
            yield from gen()
        finally:
            print('finally')

    @snippet
    def if_else():
        if a:
            yield from gen()
        else:
            print('else')

    class TestYieldFromTransformer(TransformerTestCase):

        transformer = YieldFromTransformer

        def test_try_finally(self):
            self.assertNoChange(try_finally)

        def test_if_else(self):
            expected = if_else.get_tree()
            expected.body[1].body = YieldFromTransformer().visit(expected.body[1].body) 

# Generated at 2022-06-23 23:23:33.994465
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    e = YieldFromTransformer()
    assert isinstance(e, YieldFromTransformer)


# Generated at 2022-06-23 23:23:34.459360
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:23:42.620653
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..py2js import compile_to_js
    from ..utils.helpers import run_js
    from .base import DiscardLeftNodesTransformer

    def fib():
        a, b = 1, 1
        while True:
            a, b = b, a + b
            yield a

    def to_js(tree):
        return compile_to_js(tree, [DiscardLeftNodesTransformer, YieldFromTransformer])

    def fib_of_n(n):
        return list(yield_from(fib()).take(n))

    assert fib_of_n(0) == []
    assert fib_of_n(1) == [1]
    assert fib_of_n(2) == [1, 1]
    assert fib_of_n(3) == [1, 1, 2]

# Generated at 2022-06-23 23:23:43.665801
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    pass



# Generated at 2022-06-23 23:23:55.500499
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.snippet import to_string

    @snippet
    def assignment():
        let(a, b)
        a = 1
        b = yield from c

    @snippet
    def expression():
        let(a, b)
        a = (yield from c) + 1
        b = foo(a)

    @snippet
    def nested():
        let(a, b)
        try:
            a = 1
            b = yield from c
        except Exception:
            pass

    @snippet
    def with_func():
        let(a, b, c)
        def foo():
            yield from c
        a = 1
        b = foo()


# Generated at 2022-06-23 23:24:00.635700
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test for constructor.

    Arguments:
    ---------
    - `None`

    Return:
    ------
    - `None`

    Efffect:
    -------
    - `None`
    """

    try:
        _ = YieldFromTransformer()
    except Exception as e:
        raise e


# Generated at 2022-06-23 23:24:07.256167
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .utils import make_block
    module = make_block(
        "target = item",
        "return (yield from anything)")
    expected = make_block(
        'let(iterable)',
        'iterable = iter(anything)',
        'while True:',
        '    try:',
        '        yield next(iterable)',
        '    except StopIteration as exc:',
        '        target = exc.value',
        '        break',
        'return target')
    result = YieldFromTransformer().visit(module)
    assert result == expected

# Generated at 2022-06-23 23:24:16.126959
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = '''
try:
    yield from func()
except Exception as exc:
    pass
    '''

    ref = '''
try:
    let(iterable)
    iterable = iter(func())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            exc = exc
            break


except Exception as exc:
    pass
    '''

    compiler = Compiler()
    tree = ast.parse(source)  # type: ignore
    tree = compiler.compile_ast(tree)
    compiler.save(tree, 'out.py')
    assert compiler.dumps() == ref
test_YieldFromTransformer_visit()

# Generated at 2022-06-23 23:24:17.393360
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True
    # TODO

# Generated at 2022-06-23 23:24:22.427673
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_utils import check_node
    from .. import as_transformer
    from ..utils.source import source_code

    def transformer_test(text: str,
                         output: Optional[str] = None) -> None:
        transformer = as_transformer(YieldFromTransformer)
        check_node(text, transformer, output)


# Generated at 2022-06-23 23:24:30.339149
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Assign, Expr, YieldFrom, Name, Store, Load
    from ..utils.tree_compare import compare_ast

    code = textwrap.dedent('''
            def foo():
                yield from t
                yield from t  # yield only after return
                yield from t
                yield from t  # encode to 'while'
                yield from t
                yield from t  # return result
                yield from t
                yield from t
                yield from t
                yield from t
                yield from t
                yield from t
                yield from t
                yield from t
            ''')
    tree = ast.parse(code)

# Generated at 2022-06-23 23:24:32.766330
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import generate_code
    from .string_transformer import StringTransformer
    import astor


# Generated at 2022-06-23 23:24:42.072877
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import transform
    from ..basic import BasicTransformer
    from ..refactoring import RefactoringTransformer

    code = 'locals()["a"] = yield from [x for x in range(10)]'
    ast_ = ast.parse(code)
    expected = """\
exc = None
try:
    iterable = iter([x for x in range(10)])
    while True:
        try:
            locals()["a"] = next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                locals()["a"] = exc.value
            break
finally:
    exc = None
"""


# Generated at 2022-06-23 23:24:43.120584
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)


# Generated at 2022-06-23 23:24:53.248146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .testutils import roundtrip, transform_roundtrip, roundtrip_from_source
    from .testutils import dump, load_ast
    from .testutils import transform_dump_and_load
    from . import test_module as m
    from .testutils import parse_module, dump_module
    from .testutils import parse, dump_ast

    class MyCpy(YieldFromTransformer):
        pass

    assert isinstance(load_ast(dump_ast(MyCpy().visit(parse('1')))), ast.Module)
    assert isinstance(load_ast(roundtrip(parse('1'))), ast.Module)
    assert isinstance(load_ast(roundtrip_from_source('def f(): return')), ast.Module)

# Generated at 2022-06-23 23:24:56.871278
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast

    t = YieldFromTransformer()
    tree = ast.parse(
'''
a = yield from b
yield from c
''')

    new_tree = t.visit(tree)
    assert ast.dump(new_tree) == '''Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='yield_from', ctx=Load()), args=[Name(id='b', ctx=Load())], keywords=[], starargs=None, kwargs=None)), Expr(value=Call(func=Name(id='yield_from', ctx=Load()), args=[Name(id='c', ctx=Load())], keywords=[], starargs=None, kwargs=None))])'''

# Generated at 2022-06-23 23:24:58.695340
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_visitor import TestVisitor
    from .example import example_module
    tree = TestVisitor().visit(example_module)


# Generated at 2022-06-23 23:24:59.874018
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:25:03.853605
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Test for method visit of class YieldFromTransformer."""
    from .handlers import YieldTransformer, Handler
    from .transformer import Transformer

    from typed_ast import ast3
    from .utils.handydiff import generate_tree


# Generated at 2022-06-23 23:25:14.074245
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = ast.parse("""
        def f():
            a = yield from y
            yield from b
    """)
    YieldFromTransformer().visit(t)

# Generated at 2022-06-23 23:25:21.254106
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    program = ast.parse('''
    def foo():
        yield_from(a)
        yield_from((1 for a in b))
        yield_from(yield)
        c = yield_from(yield)
        yield_from(a + b)
        yield_from(a + b)
        if True:
            yield_from((1 for aaa in bbb))
            yield_from(123)
        elif False:
            yield_from(b)
        else:
            yield_from(c)
        for a in 0:
            yield_from(e)
        for a in 0:
            yield_from(f)
        for a in 0:
            yield_from(g)
        for a in 0:
            yield_from(h)
    ''')
    expected = ast.parse

# Generated at 2022-06-23 23:25:22.361333
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_utils import get_ast
    from ..main import get_transformed_code


# Generated at 2022-06-23 23:25:23.204129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:25:24.767907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    obj.visit("node")
    assert obj.visit("node") is None
    assert obj.visit("node") is not None


# Generated at 2022-06-23 23:25:27.535559
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():  
    class_object = YieldFromTransformer()
    assert class_object is not None
    
# Unit tests for _get_yield_from_index()
# Test for invalid input -> None should be returned

# Generated at 2022-06-23 23:25:35.448526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformerTest
    from .test_body_comprehensions import to_body_comprehensions
    from .test_module import module_node

    test = BaseNodeTransformerTest(YieldFromTransformer, module_node)
    test.test(
        '')

    test = BaseNodeTransformerTest(YieldFromTransformer,
                                   to_body_comprehensions(module_node))

# Generated at 2022-06-23 23:25:36.963213
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:38.093307
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:25:47.420001
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""
a = yield from b
print(yield from c)
""")
    expected_node = ast.parse("""
let (exc, iterable)
iterable = iter(b)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        a = exc.value
        break
let (exc, iterable)
iterable = iter(c)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        print(exc.value)
        break

""")
    node = YieldFromTransformer().visit(tree)
    assert node.body[0].body == expected_node.body[0].body

# Generated at 2022-06-23 23:25:55.176300
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..utils.tree import find_in_tree
    from .unpacking_transformer import UnpackingTransformer


# Generated at 2022-06-23 23:26:06.246755
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_transformer import run_transform
    
    def do_test(
        src: str,
        expected: str
    ):
        ast_node = ast.parse(src)
        actual = run_transform(ast_node, YieldFromTransformer)
        assert_equal(expected, actual)
    
    src = """
    def foo():
        a, b = yield from bar()
    """
    expected = """
    def foo():
        let(exc)
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                a, b = exc.value
                break
    """
    do_test(src, expected)
    

# Generated at 2022-06-23 23:26:13.406042
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # construct a AST tree
    input_str = \
"""def f():
    yield from (x*x for x in range(10))
    yield from (x*x for x in range(10))

    a = yield from (x*x for x in range(10))
    print(a)
    b = yield from (x*x for x in range(10))
    print(b)
    """
    root = ast.parse(input_str)
    # print(ast.dump(root))

    # construct a transformer
    transformer = YieldFromTransformer()

    # transform
    root_transformed = transformer.visit(root)
    # print(ast.dump(root_transformed))
    import io
    str_io = io.StringIO()
    # in Python 3.8 can use ast.Unparse to print

# Generated at 2022-06-23 23:26:15.388140
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t


# Generated at 2022-06-23 23:26:16.514120
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()

# Generated at 2022-06-23 23:26:26.117672
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..test.test_utils import run_test_for_transformer
    run_test_for_transformer(
        YieldFromTransformer(),
        code_before='''
if x:
    yield from y
else:
    print(y)

yield from z
        ''',
        code_after='''
if x:
    (iterable := iter(y))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc_0:
            break
else:
    print(y)

(iterable := iter(z))
while True:
    try:
        yield next(iterable)
    except StopIteration as exc_1:
        break
        ''')


# Generated at 2022-06-23 23:26:33.632208
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:26:34.313461
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:26:41.034026
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    with Transform('return') as tx:
        class A:
            def __iter__(self):
                return self
            def __next__(self):
                return 1
            def foo(self):
                yield from self
        a = A()
        print(next(a.foo()))


# Generated at 2022-06-23 23:26:43.109538
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import compile_snippet
    from ..utils.helpers import extract_generated_code
    import astor

# Generated at 2022-06-23 23:26:44.122091
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print (YieldFromTransformer)


# Generated at 2022-06-23 23:26:51.645183
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from asttokens import ASTTokens

    module = """def test():
                 yield from (x for x in [1, 2])
               """

    tree = ASTTokens(module, parse=True, include_attributes=True).tree
    transformer = YieldFromTransformer()
    transformed = transformer.visit(tree)
    assert str(transformed) == """def test():
    let(iterable)
    iterable = iter((x for x in [1, 2]))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            pass
            break"""

# Generated at 2022-06-23 23:26:52.631618
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:26:54.154715
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 23:27:01.738521
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    src = '''
        def yarn(x):
            yield 'foo'
            yield from baz(x)
            yield 'baz'
    '''
    tree = ast.parse(src)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

    expected_src = '''
        def yarn(x):
            yield 'foo'
            iterable = iter(baz(x))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

            yield 'baz'
    '''
    assert transformer.tree_changed is True
    actual_ast = ast.parse(expected_src)
    assert ast.dump(actual_ast) == ast.dump(tree)

# Generated at 2022-06-23 23:27:03.391762
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from pyt import module_visitor


# Generated at 2022-06-23 23:27:13.709015
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    from .testing_visitor import TestingVisitor
    from .testing_context import TestingContext

    context = TestingContext()

    class TestingYieldFromTransformer(YieldFromTransformer):
        def __init__(self, context: TestingContext):
            super().__init__()
            self.context = context

        def generic_visit(self, node: ast.AST) -> ast.AST:
            return TestingVisitor.visit_children(self, node)

    source = """
    def Foo():
        yield 1
        yield from Bar()
        yield 2
    """
    node = ast.parse(source)
    node = TestingYieldFromTransformer(context).visit(node)

# Generated at 2022-06-23 23:27:20.537731
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Source:
        def func(self):
            yield from iter([1])
    import astor
    from ..utils import get_ast
    from . import BaseNodeTransformer
    from ..scope import Scope
    from ..nodes import BaseNodeTransformer

    tree = get_ast(Source)
    scope = Scope.create(tree)
    transformer = YieldFromTransformer(scope)
    transformer.visit(tree)

# Generated at 2022-06-23 23:27:32.495277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .checker import YieldFromChecker
    from typed_astunparse import unparse

    code = '''\
    def double(x):
        yield from (i * 2 for i in range(0, x))
    '''
    expected_result = '''\
    def double(x):
        let(iterable)
        iterable = iter(iter(range(0, x)))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    '''
    ast_tree = ast.parse(code)
    checker = YieldFromChecker()
    res = checker.check(ast_tree, YieldFromTransformer)
    assert res['yield_from']

# Generated at 2022-06-23 23:27:41.532948
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.helpers import assert_equal_code

    for x in range(3):
        for y in range(3):
            src = textwrap.dedent('''\
            x = yield from foo(x)
            ''')
            if x == 0:
                src += 'y = yield from foo(y)\n'
            src += 'yield from foo(x)' * x
            src += 'yield from foo(y)' * y
            src += 'yield from foo(z)\n'


# Generated at 2022-06-23 23:27:43.638841
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:27:45.823706
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj_list = ast.parse("from . import Holder").body
    instance = YieldFromTransformer()
    instance.visit(obj_list)

# Generated at 2022-06-23 23:27:46.786334
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:27:56.638216
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:57.521361
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:28:05.762975
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class node(object):
        def __init__(self,):
            self.body = []

    class assignment(object):
        def __init__(self):
            self.value = 5
            self.targets = 6

    class child(object):
        def __init__(self,):
            self.body = []
            self.value = 5

    class exp(object):
        def __init__(self,):
            self.value = 5

    if __name__ == '__main__':
        YieldFromTransformer().visit(node)
        YieldFromTransformer().visit(assignment)
        YieldFromTransformer().visit(child)
        YieldFromTransformer().visit(exp)

# Generated at 2022-06-23 23:28:08.521022
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import pprint
    from ..translate.convert import convert
    from ..translate.make_tree import make_tree

    code = """
        def func(x):
            yield from x
            for i in range(4):
                yield from x
                a = yield from x
                yield from x
                yield from x
            yield from x
    """
    tree = make_tree(code)
    tree = YieldFromTransformer().visit(tree)
    result = convert(tree)
    pprint.pprint(result)



# Generated at 2022-06-23 23:28:17.874279
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    for type_ in [ast.If, ast.Module, ast.FunctionDef, ast.While]:
        class TestMethod(TestCase):
            def test(self):
                code = """
import importlib

a = 1
if a == 1:
    yield from range(1)
else:
    print(a)
"""
                tree = ast.parse(code)
                YieldFromTransformer().visit(tree)
                self.assertEqual(ast.dump(tree), """
<_ast.Module object at 0x7fd95e10c908>
""")
        TestMethod.__name__ = 'test_{}'.format(type_.__name__)
        TestMethod.__qualname__ = TestMethod.__name__
        TestMethod.test.__qualname__ = TestMethod.test.__qualname__
       

# Generated at 2022-06-23 23:28:27.817322
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import transform, to_source

    source = '''
    def foo():
        yield from bar()
    '''
    expected = '''
    def foo():
        exc = None
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                pass
                break
    '''
    tree = transform(source, YieldFromTransformer)
    assert to_source(tree) == expected

    source = '''
    def foo():
        yield from bar()
    '''

# Generated at 2022-06-23 23:28:38.008191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import dump
    from .. import transformers
    t = transformers.get_transformer(YieldFromTransformer)
    assert t.__class__.__name__ == 'YieldFromTransformer'
    assert t.__class__.__module__ == __name__

    # Check some of the code is in transformer
    tree_str = "[Try([Assign(targets=[Name(id='y', ctx=Store())], value=YieldFrom(value=Call(func=Name(id='foo', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))), Name(id='z', ctx=Load())], [ExceptHandler(type=None, name=None, body=[])], [])]"
    tree = ast.parse(tree_str)
    module = t.visit

# Generated at 2022-06-23 23:28:39.299922
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Test constructor of class YieldFromTransformer')


# Generated at 2022-06-23 23:28:48.752073
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_nodes import test_node_builders, yield_from_assignment, yield_from_expression, yield_from_generator_return
    from ..utils.test_visitor_utils import assert_visit_tree_with_expected_results
    from ..utils.helpers import VariablesGenerator
    var_gen = VariablesGenerator()
    test_nodes = test_node_builders(var_gen)
    print(test_nodes)

# Generated at 2022-06-23 23:28:49.964946
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..build import build_ast
    from .exceptions import ExceptionTransformer


# Generated at 2022-06-23 23:28:51.134218
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import sys
    from .ast_parser import AstParser


# Generated at 2022-06-23 23:29:01.082395
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from .base import TransformerTestCase
    from ..utils.helpers import generate_function_definition
    from ..utils.helpers import VariablesGenerator

    class TestYieldFromTransformer(TransformerTestCase):
        transformer = YieldFromTransformer
        target = '3.2'

        def test_simple(self):
            var = VariablesGenerator.generate('var')
            text = '''
            def foo():
                yield from {var}
            '''.format(var=var)
            tree = ast.parse(text)
            result = self.transform(tree)
            self.assertNotEqual(result, tree)

# Generated at 2022-06-23 23:29:03.187603
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('*'*20)
    print('Unit test for constructor of class YieldFromTransformer')
    print('*'*20)

    transformer = YieldFromTransformer(None)
    # Test that the __init__ runs correctly 
    print('Test that the __init__ runs correctly')
    print(transformer)


# Generated at 2022-06-23 23:29:04.277808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:29:05.171476
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-23 23:29:16.290450
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse('def fn():\n'
                       '    try:\n'
                       '        a, b = yield from range(10)\n'
                       '    except ValueError: pass\n'
                       '    except Exception as err: '
                       'print(err)\n'
                       '    print(a, b)\n')

    # emulate yield from
    exc = 'exc'
    assignment = result_assignment.get_body(exc=exc, target='b')
    yield_from_ast = yield_from.get_body(generator='range(10)',
                                         assignment=assignment,
                                         exc=exc)

    Transformer = YieldFromTransformer()
    Transformer.visit(module)
    assert module.body[0].body[0].body[1].value.__class__.__name

# Generated at 2022-06-23 23:29:18.180472
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:19.996587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)

# Generated at 2022-06-23 23:29:28.947314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .utils import parse
    from .test_decorator import test_function_transformer
    from .unpacking_generalization import test_UnpackingGeneralizationTransformer

    test_function_transformer(YieldFromTransformer, parse, '''
        def func():
          yield from 0 or range(5)
        ''')

    test_function_transformer(YieldFromTransformer, parse, '''
        def func():
          yield from 0 or range(5)
          yield from 1 or range(5)
        ''')

    test_function_transformer(YieldFromTransformer, parse, '''
        def func():
          yield from 0 or range(5)
          yield from 1 or range(5)
          yield from {"a": 1}
        ''')


# Generated at 2022-06-23 23:29:32.240037
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert isinstance(yield_from_transformer, BaseNodeTransformer)
test_YieldFromTransformer()

# Generated at 2022-06-23 23:29:33.580896
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()
    assert tr


# Generated at 2022-06-23 23:29:34.939156
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()
    assert tr is not None


# Generated at 2022-06-23 23:29:36.046078
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-23 23:29:46.705677
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.parse_python import parse_python_file
    from .convert_yields import YieldsToGeneratorsTransformer
    from .unroll_loops import UnrollLoopsTransformer
    from .control_flow_unroller import ControlFlowUnroller
    from .const_propagation import ConstPropagationTransformer
    from .rename_variables import RenameVariablesTransformer
    from .remove_None_returns import RemoveNoneReturns

    node = parse_python_file("test_src/test_for_yield_from.py")
    YieldsToGeneratorsTransformer().visit(node)
    UnrollLoopsTransformer().visit(node)
    ControlFlowUnroller().visit(node)
    ConstPropagationTransformer().visit(node)
    RenameVariablesTransformer

# Generated at 2022-06-23 23:29:47.702610
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)

# Generated at 2022-06-23 23:29:48.349868
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-23 23:29:57.696548
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_base import get_test_ast

    sources = [
        """
        def test(value):
            yield from [...]
        """,
        """
        def test(value):
            result = yield from [...]
        """,
        """
        def test(value):
            ... = yield from [...]
        """,
        """
        def test(value):
            result = yield from [...]
            result2 = yield from [...]
        """,
    ]

# Generated at 2022-06-23 23:30:05.820781
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_node_equal
    a = ast.parse("""
    def test():
        a = yield from test
    """)
    b = ast.parse("""
    def test():
        let(iter_var_0)
        let(exc_var_0)
        iter_var_0 = iter(test)
        while True:
            try:
                yield next(iter_var_0)
            except StopIteration as exc_var_0:
                a = exc_var_0
                break
    """)
    assert_node_equal(YieldFromTransformer().visit(a), b)

# Generated at 2022-06-23 23:30:16.165702
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import typed_astunparse
    from .unary_operator import UnaryOperatorTransformer

    class TestYieldFromTransformer(unittest.TestCase):
        def setUp(self) -> None:
            self.transformer = YieldFromTransformer()

        def test_visit(self):
            tree = ast.parse("""
    
            def func(await_value):
                await_value = await await_value
                await_value = await_value
                return await_value
            """)
            UnaryOperatorTransformer(inplace=True).visit(tree)
            self.transformer.visit(tree)


# Generated at 2022-06-23 23:30:24.766409
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..compiler import compile
    from ..compiler.compiler import Compiler

    snippet = '''def foo():
    x = yield from 1
    yield from 1
    '''

    tree = compile(snippet, __name__, 'exec')
    ast.fix_missing_locations(tree)
    Compiler.remove_asts(tree)
    new_tree = YieldFromTransformer().visit(tree)
    Compiler.restore_asts(new_tree)


# Generated at 2022-06-23 23:30:34.170245
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class_node = ast.ClassDef(name='C',
                              bases=[],
                              keywords=[],
                              body=[],
                              decorator_list=[])

# Generated at 2022-06-23 23:30:40.002715
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .base import BaseNodeTransformerTest
    from .base import get_tests, build_tree
    from .. import codegen
    from .. import fixnum
    from ..utils import helpers
    from ..utils.helpers import find_funcdef

    tests = get_tests(__name__, 'yield_from')
    transformer = YieldFromTransformer()

    for test in tests:
        tree = build_tree(test.source)
        transformer.visit(tree)
        module = codegen.to_module(tree, {'yield_from': helpers.YieldFrom()})
        func = find_funcdef(module)
        exc = helpers.StyleError
        res = str(test.expected)

        try:
            assert str(func()) == res
        except exc:
            assert str(func(1)) == res



# Generated at 2022-06-23 23:30:50.724583
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from syn.base_utils import capture
    from unittest import TestCase
    from .test_module import sample_module

    class Test(TestCase):
        maxDiff = None

        def test1(self):
            code = '''
                def func():
                    yield from foo
            '''
            result = '''
                def func():
                    let(iterable)
                    iterable = iter(foo)
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            break

            '''
            with capture(sys.stdout) as (out, _):
                mod = sample_module(code)
                Yield

# Generated at 2022-06-23 23:30:52.183699
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer()
    assert isinstance(result, YieldFromTransformer)

# Generated at 2022-06-23 23:30:52.677396
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:53.870164
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer, object)

# Generated at 2022-06-23 23:30:54.826890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # If this throws an error, we are good!
    YieldFromTransformer()

# Generated at 2022-06-23 23:30:59.508134
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import transformer_mapping  # noqa
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)

    mapping = transformer_mapping[(3, 2)]
    assert mapping == {}

    mapping = transformer_mapping[(3, 3)]
    assert mapping['YieldFromTransformer'] == YieldFromTransformer

    mapping = transformer_mapping[(3, 4)]
    assert mapping['YieldFromTransformer'] == YieldFromTransformer

    mapping = transformer_mapping[(3, 5)]
    assert mapping['YieldFromTransformer'] == YieldFromTransformer


# Generated at 2022-06-23 23:31:07.396772
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..test_data.inputs.yield_from import yield_from_inputs
    from ..test_data.outputs.yield_from import yield_from_outputs
    from ..test_data.inputs.yield_from import yield_from_tests
    from ..utils.get_modifications import get_modifications

    for i in range(len(yield_from_tests)):
        mod = YieldFromTransformer().visit(yield_from_inputs[i])
        try:
            assert ast.dump(mod) == ast.dump(yield_from_outputs[i])
        except AssertionError:
            print(get_modifications(ast.dump(mod), ast.dump(yield_from_outputs[i])))