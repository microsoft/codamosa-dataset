

# Generated at 2022-06-23 23:21:09.505462
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:11.944310
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. ast_converter import parse
    from .. ast_converter import dump_ast, restore_ast
    from ast import parse as parse_std


# Generated at 2022-06-23 23:21:12.809792
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:14.631595
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """
    Test that it compiles yield from statement
    """
    # Prepare
    import astor

# Generated at 2022-06-23 23:21:16.078203
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test transformation that emulates yield from.
    _ = YieldFromTransformer()

# Generated at 2022-06-23 23:21:16.632709
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:21:20.786879
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.Expr(value=ast.Call((), (), []))
    b = ast.Expr(value=ast.Call((), (), []))
    c = ast.Expr(value=ast.Call((), (), []))
    d = ast.Expr(value=ast.YieldFrom(ast.Name((), '', ast.Load())))

    x = ast.Module(body=[a, b, c, d])
    YieldFromTransformer().visit(x)

# Generated at 2022-06-23 23:21:25.590870
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    import textwrap
    from astmonkey import transformers

    src = textwrap.dedent('''
    def foo():
        yield from bar()
    ''')
    node = ast.parse(src)
    transformer = transformers.YieldFromTransformer()
    transformer.visit(node)
    print(astunparse.unparse(node))



# Generated at 2022-06-23 23:21:28.109022
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # testing the constructor of YieldFromTransformer
    transformer = YieldFromTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert (3, 2) == transformer.target


# Generated at 2022-06-23 23:21:29.644708
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:34.430525
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('def foo(a):\n yield from a')
    expected = ast.parse('def foo(a):\n iterable = iter(a)\n while True:\n try:\n yield next(iterable)\n except StopIteration as exc:\n pass')
    result = YieldFromTransformer()(tree)
    assert are_equal_asts(expected, result)



# Generated at 2022-06-23 23:21:36.506185
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    assert isinstance(YieldFromTransformer.__new__(
        YieldFromTransformer), YieldFromTransformer)


# Generated at 2022-06-23 23:21:41.654043
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast

    code = """\
    def foo():
        yield from iter(range(10))
        d = yield from iter(range(10))
        yield from iter(range(10))
        e = yield from iter(range(10))
    """
    node = get_ast(code)
    YieldFromTransformer().visit(node)
    assert code == compile(node, '', 'exec').co_consts[0]



# Generated at 2022-06-23 23:21:42.808664
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer().target == (3, 2))


# Generated at 2022-06-23 23:21:43.742142
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    b = YieldFromTransformer()


# Generated at 2022-06-23 23:21:47.051324
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_ast
    from ..utils.unparse import Unparser
    from ..utils import get_ast_checker
    check_ast = get_ast_checker()


# Generated at 2022-06-23 23:21:52.922187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import transforms, nodes
    from . import helpers
    from .helpers import parse

    class Optimizer:
        def __init__(self, code_str):
            self.tree = parse(code_str)
            self.optimizers = [
                transforms.YieldFromTransformer
            ]

        def run(self):
            for optimizer in self.optimizers:
                tree = optimizer().visit(self.tree)
            return helpers.unparse(tree)


# Generated at 2022-06-23 23:21:54.711848
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert_equals(YieldFromTransformer().__class__.__name__, 'YieldFromTransformer')


# Generated at 2022-06-23 23:21:59.852303
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures import use_fixtures
    from ..utils.source import source

    filename = 'YieldFromTransformer.py'

    use_fixtures(filename)

    # noinspection PyUnresolvedReferences
    import YieldFromTransformer  # isort:skip

    node = YieldFromTransformer.make_ast(source)
    assert node == YieldFromTransformer.expected_result()

# Generated at 2022-06-23 23:22:00.553553
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:22:01.519109
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:22:03.745947
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..rewriter import Rewriter
    from ..utils.helpers import get_transformer_test_cases


# Generated at 2022-06-23 23:22:05.694954
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Test(ast.AST):
        pass
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 23:22:15.387671
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import Generic, TypeVar, List
    from typed_ast import ast3 as ast
    from ..utils.helpers import source_code
    from ..utils.tree import get_child
    T = TypeVar('T')

    class Transformer(YieldFromTransformer, ast.NodeTransformer, Generic[T]):
        def visit(self, node: ast.AST) -> ast.AST:
            node = get_child(node, T)
            if node is not None:
                node = super().visit(node)
            return ast.NodeTransformer.generic_visit(self, node)

    class TestTransformer(Transformer[ast.FunctionDef]):
        pass


# Generated at 2022-06-23 23:22:21.728005
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..debug import debug_tree
    from ..utils.source import assign, yield_from as yf

    source = '''
a = yield from b + 1
c = (yield from d).f
    '''
    debug_tree(source, YieldFromTransformer)

    assert YieldFromTransformer.run_source(source) == '''
a = (let (iterable) iterable = iter(b + 1); while True: try: yield next(iterable) except StopIteration as exc: if hasattr(exc, 'value'): a = exc.value; break
c = (let (iterable) iterable = iter(d).f; while True: try: yield next(iterable) except StopIteration as exc: if hasattr(exc, 'value'): c = exc.value; break
    '''


# Generated at 2022-06-23 23:22:32.295605
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module_str = '''def fun():
                         yield from [1]
                         yield from [1] + [2]
                         x = yield from [1]
                         yield from [1] + [2]'''

    mod = ast.parse(module_str)
    YieldFromTransformer().visit(mod)


# Generated at 2022-06-23 23:22:40.038656
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.builder import make_nodes

    source = """
    from typing import List
    from data import x
    from data import y
    
    def return_y():
        return y

    def yield_from_it():
        for _ in range(10):
            yield x
            yield y

    def test():
        a = yield_from_it()
        b = yield_from_it()
        a = yield_from_it()
        b = return_y()
        b = yield_from_it()
        a = yield_from_it()
        b = return_y()
        a = yield_from_it()
        b = yield_from_it()
    """

# Generated at 2022-06-23 23:22:41.008300
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

# Generated at 2022-06-23 23:22:50.547151
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTest
    from .. import transforms
    from .utils import assert_equal_ast_node

    class TestCase(BaseNodeTest):
        target = transforms.YieldFromTransformer

        def test_yield_from(self):
            source = '''
            def test():
                yield from a
                yield from b
            '''

# Generated at 2022-06-23 23:22:51.284537
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-23 23:22:57.944221
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    from ..utils.testing import transform
    tree = transform(YieldFromTransformer, '''a = yield from foo''')
    assert typed_astunparse.unparse(tree) == 'a = (\n  let iterable\n  iterable = iter(foo)\n  while True:\n    try:\n      yield next(iterable)\n    except StopIteration as exc:\n      a = exc.value\n      break\n)\n'
    tree = transform(YieldFromTransformer, '''yield from foo''')

# Generated at 2022-06-23 23:23:05.642795
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from pprint import pprint

    from ..utils.tree import parse, dump
    from ..utils.helpers import VariablesGenerator

    VariablesGenerator.reset()

    tree = parse("""
    def f():
        g()
        h()
        yield from x
    """)
    pprint(dump(tree))

    transformer = YieldFromTransformer()
    transformer.visit(tree)

    print('changed:', transformer.changed)
    pprint(dump(tree))

    tree = parse("""
    def f():
        g()
        h()
        yield from x
    """)
    pprint(dump(tree))

    transformer = None

    def test():
        nonlocal transformer
        transformer = YieldFromTransformer()
        transformer.visit(tree)

    import cProfile

# Generated at 2022-06-23 23:23:16.131667
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import ast_utils
    from ..visitors.normalizer import Normalizer
    from ..visitors.symbol_table import SymbolTableVisitor

    def check_yield_from(code: str) -> ast.Module:
        tree = ast_utils.parse(code)
        YieldFromTransformer().visit(tree)
        SymbolTableVisitor().visit(tree)
        Normalizer().visit(tree)
        return tree

    ###########################################################################
    # Test: yield from as expression
    ###########################################################################
    code = '''
        def func():
            yield from f()
    '''
    tree = check_yield_from(code)
    rendered = ast_utils.render(tree)

# Generated at 2022-06-23 23:23:24.760170
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    from ..utils.helpers import get_node


# Generated at 2022-06-23 23:23:33.902284
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from .controlflow import ControlFlowTransformer

    source = source('''
    def foo():
        a = yield from bar()
    ''')
    expected = source('''
    def foo():
        let(iterable, exc)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    ''')

    node = ast.parse(source)
    node = YieldFromTransformer().visit(node)
    node = ControlFlowTransformer().visit(node)
    assert(ast.dump(node) == ast.dump(expected))

# Generated at 2022-06-23 23:23:42.369303
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import ast
    import copy
    class Test(unittest.TestCase):
        def _test(self, expected: ast.AST,
                  node: ast.AST):
            # return
            transformer = YieldFromTransformer()
            transformer.visit(node)
            self.assertEqual(expected, node)
            # modify
            transformer = YieldFromTransformer(modify_tree=True)
            self.assertEqual(expected, transformer.visit(node))
        ##

        def test_TypedDict(self):
            from dataclasses import dataclass, asdict
            from typing import TypedDict
            from ..utils.tree import compare_trees

            @dataclass
            class TestNode(TypedDict):
                pass


# Generated at 2022-06-23 23:23:44.892317
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .ast_helpers import get_ast, compare_asts
    from . import compile_to_ast as _


# Generated at 2022-06-23 23:23:56.567238
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """yield from ... -> while True: ... -> {try: yield next(iter(...)) except StopIteration as e: e = e.value; break}"""
    assert ast.parse("try: \n assert a \n finally: \n yield from b \n") == YieldFromTransformer().visit(ast.parse("try: \n assert a \n finally: \n yield from b \n"))
    assert ast.parse("try: \n assert a \n finally: \n yield from b \n") == YieldFromTransformer().visit(ast.parse("yield from b"))
    assert ast.parse("try: \n assert a \n finally: \n yield from b \n") == YieldFromTransformer().visit(ast.parse("try: \n yield from b \n finally: \n assert a"))

# Generated at 2022-06-23 23:23:57.641657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-23 23:24:01.033152
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class object(object):
        pass

    ast.YieldFrom(value=object())
    object().value
    object().targets
    object().body
    YieldFromTransformer(None)

# Generated at 2022-06-23 23:24:05.876378
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Imports
    # Additional test imports
    import astor
    import unittest

    # Additional test code
    test_code = '''
try:
    a = yield from [1, 2]
except ValueError as err:
    print(err)
    '''
    # Unit test
    class YieldFromTransformerTest(unittest.TestCase):
        def test_yield_from(self):
            # Arrange
            node = ast.parse(test_code)

# Generated at 2022-06-23 23:24:07.538496
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # snippet.verbose(True)
    tr = YieldFromTransformer()

# Generated at 2022-06-23 23:24:10.387991
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse(textwrap.dedent('''
    def f():
        yield from get_iterator()
    '''))
    assert not any(isinstance(n, ast.YieldFrom) for n in ast.walk(node))

# Generated at 2022-06-23 23:24:12.895314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """ Unit test for constructor of class YieldFromTransformer """
    transformer = YieldFromTransformer()
    assert transformer


# Generated at 2022-06-23 23:24:14.276382
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-23 23:24:14.892701
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:24:25.465470
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    # Tests conditions for three cases
    def test_get_yield_from_index(node: Node, type_: Type[Holder], expected: Optional[int]):
        transformer = YieldFromTransformer()
        actual = transformer._get_yield_from_index(node, type_)
        assert actual == expected

    # Example of yield from in return statement
    test_get_yield_from_index(
        ast.Module(body=[ast.FunctionDef(body=[ast.Return(value=ast.YieldFrom(value=ast.Name(id='my_gen')))])]),
        ast.Expr, 0)

    # example of yield from in if statement

# Generated at 2022-06-23 23:24:26.490357
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    import astor

# Generated at 2022-06-23 23:24:28.036239
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as pyast
    import typed_ast.ast3 as typed_ast


# Generated at 2022-06-23 23:24:29.648947
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:36.651413
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...unit_test import assert_transformation
    from ..utils.helpers import gensym
    var = gensym()

    emulated = yield_from.get_body(generator=var,
                                   assignment=[],
                                   exc='_')

    assert_transformation(
        YieldFromTransformer,
        ast.parse(f"yield from {var}"),
        emulated
    )

    assert ast.dump(YieldFromTransformer().visit(emulated[0])) == ast.dump(emulated[0])

# Generated at 2022-06-23 23:24:45.512140
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import run_transform
    from ..utils import helpers
    from .. import parse

    result = run_transform(YieldFromTransformer, """
        def foo():
            x = yield from bar()
            print(x)
        def spam():
            print(yield from bar())
        def fizz():
            yield from bar()
    """)


# Generated at 2022-06-23 23:24:55.467975
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    body = [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                       value=ast.YieldFrom(value=ast.Num(n=1)))]
    node = ast.Expr(value=ast.YieldFrom(value=ast.Num(n=1)))
    body.append(node)
    mod = ast.Module(body=body)


# Generated at 2022-06-23 23:24:59.929713
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_astunparse
    code = "def f():\n    y = yield from list()\n"
    module = ast.parse(code)
    transformer = YieldFromTransformer()
    node = transformer.visit(module)

    expected_code = "def f():\n    iterable = iter(list())\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            y = exc.value\n            break\n\n"
    result_code = typed_astunparse.unparse(node)
    assert result_code == expected_code

# Generated at 2022-06-23 23:25:01.023633
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:25:02.095320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:12.910194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    import textwrap
    from textwrap import dedent
    from ..utils.helpers import ast_to_str

    class Test(YieldFromTransformer):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.source = textwrap.dedent(inspect.getsource(self.visit))

        def _get_code(self, node):
            return ast_to_str(node)

    test = Test()
    test.transformation.logging = False

    source = test.source
    result = test._get_code(test.transformer(source))


# Generated at 2022-06-23 23:25:19.577645
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_code_transformed
    from ..utils.testing import load_code_module
    from ..utils.testing import load_code_function
    from ..utils.testing import load_code_class
    from ..utils.testing import load_code_method
    from ..utils.testing import load_code_object

    source_code = '''
    def f(bar):
        foo = yield from bar
        return foo
    '''


# Generated at 2022-06-23 23:25:28.338299
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    def test(node, expected_output):
        assert obj.visit(ast.parse(node)) == ast.parse(expected_output)
    # Test 1
    node = '''
a = yield from []
'''
    expected_output = '''
let(iterable)
iterable = iter([])
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break
'''
    test(node, expected_output)
    # Test 2

# Generated at 2022-06-23 23:25:33.160331
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test = ast.parse('yield from range(10)')
    instance = YieldFromTransformer()
    result = instance.visit(test)
    assert ast.dump(result, include_attributes=False) == 'Module(body=[Expr(value=Yield(value=Call(func=Name(id=range, ctx=Load()), args=[Num(n=10)], keywords=[])), lineno=1, col_offset=0)])'

# Generated at 2022-06-23 23:25:44.548577
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class Transformer(YieldFromTransformer):
        def __init__(self):
            super().__init__()
            self.changed = False

        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node

    tree = """
try:
    a = 1
    b = yield from c
    d = 1
except StopIteration as exc:
    pass
    """
    new_tree = """
try:
    a = 1
    let(iterable)
    iterable = iter(c)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            b = exc.value
            break
    d = 1
except StopIteration as exc:
    pass
    """
    transformer = Transformer()
    new_tree = transformer

# Generated at 2022-06-23 23:25:46.142425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)


# Generated at 2022-06-23 23:25:54.321359
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as ast_module
    import inspect
    import types

    import astunparse
    import typed_ast.ast3 as typed_ast

    from ..utils.tree import get_node
    from ..utils.helpers import VariablesGenerator


# Generated at 2022-06-23 23:25:57.181581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        assert type(YieldFromTransformer) == YieldFromTransformer
    except NameError as e:
        print(e)


# Generated at 2022-06-23 23:26:07.901685
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    assert str(result_assignment) == "if hasattr(exc, 'value'):\n    target = exc.value"
    assert str(yield_from) == "let(iterable)\niterable = iter(generator)\nwhile True:\n    try:\n        yield next(iterable)\n    except StopIteration as exc:\n        if hasattr(exc, 'value'):\n            target = exc.value\n        break"

    stmt = """
    try:
        yield from [1, 2, 3]
    except:
        pass
    """


# Generated at 2022-06-23 23:26:09.203767
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:26:10.063104
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:26:14.921696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    matcher = YieldFromTransformer()

    # Try to call method visit of class YieldFromTransformer
    node = matcher.visit(ast.YieldFrom(values=ast.YieldFrom(values=ast.YieldFrom(values=ast.Name(id='a', ctx=ast.Load())))));
    print (ast.dump(ast.Module(body=[node])));

# Generated at 2022-06-23 23:26:21.210768
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('a = yield from b')
    node = ast.parse('a = yield from b').body[0]
    assert YieldFromTransformer(None).visit(node).body == [ast.Expr(value=ast.Str('a = yield from b'))]
    assert YieldFromTransformer(None).visit(tree).body == [ast.Expr(value=ast.Str('a = yield from b'))]

# Generated at 2022-06-23 23:26:22.840845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'

# Generated at 2022-06-23 23:26:31.603491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet_x = "x = 5"
    snippet_y = "y = yield from x"

    def test_1():
        print("yield from x -> generator expression")
        x = 5
        y = (i for i in x)
        assert x == 5
        assert y == (i for i in x)
        print("yield from x -> generator expression, test passed successfully")

    def test_2():
        print("yield from x -> generator expression with target")
        x = 5
        y = 5
        y = (i for i in x)
        assert x == 5
        assert y == (i for i in x)
        print("yield from x -> generator expression with target, test passed successfully")

    def test_3():
        print("yield from x -> while expressions")
        x = 5

# Generated at 2022-06-23 23:26:33.602226
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft is not None
    assert isinstance(yft, YieldFromTransformer)

# Generated at 2022-06-23 23:26:35.655186
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.target == (3, 2)

# Generated at 2022-06-23 23:26:44.568203
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_ = YieldFromTransformer
    class_.__name__ = 'YieldFromTransformer'

    actual = str(YieldFromTransformer.__init__)
    assert actual == "def __init__(self, tree: Optional[AST]) -> None: ...\n"

    actual = str(YieldFromTransformer.visit)
    assert actual == "def visit(self, node: AST) -> AST: ...\n"

    actual = str(YieldFromTransformer._handle_assignments)
    assert actual == "def _handle_assignments(self, node: Node) -> Node: ...\n"

    actual = str(YieldFromTransformer._handle_expressions)
    assert actual == "def _handle_expressions(self, node: Node) -> Node: ...\n"


# Generated at 2022-06-23 23:26:46.945758
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Arrange
    import astor
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        import ast


# Generated at 2022-06-23 23:26:51.177641
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    c0 = YieldFromTransformer()
    assert c0.__class__.__name__ == 'YieldFromTransformer'
    assert isinstance(c0, BaseNodeTransformer)


# Unit tests for function YieldFromTransformer._get_yield_from_index

# Generated at 2022-06-23 23:26:59.205288
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer()
    print(t.visit(ast.parse('a = yield from [1,2,3]')))
    print(t.visit(ast.parse('yield from [1,2,3]')))
    print(t.visit(ast.parse('yield from [1,2,3];yield from [6,8,9]')))
    print(t.visit(ast.parse('yield from [1,2,3];a=yield from [6,8,9]')))
    print(t.visit(ast.parse('a=yield from [1,2,3];yield from [6,8,9]')))

# Generated at 2022-06-23 23:27:03.646763
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = '''
    def foo():
        result = yield from gen()
    '''
    expected = '''
    def foo():
        let(iterable)
        iterable = iter(gen())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                result = exc.value
                break
    '''

    tree = ast.parse(code)
    transform = YieldFromTransformer().visit(tree)
    result = ast.dump(transform)
    assert result == expected

# Generated at 2022-06-23 23:27:13.922378
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import Module, FunctionDef, YieldFrom, Name, Tuple, Load, Store, List, Assign, Expr, Pass
    from .base import BaseNodeTransformer

    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.target == (3, 2)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == 'Compiles yield from to special while statement.'
    assert YieldFromTransformer._fields == ('tree_changed',)
    assert YieldFromTransformer._attributes == ('tree_changed',)

    obj = YieldFromTransformer()
    assert obj.tree_changed == False


# Generated at 2022-06-23 23:27:25.342101
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap

    python = textwrap.dedent("""
        def yieldFrom(gen):
            i = yield from gen
            return i + 1
    """)

    tree = ast.parse(python)
    transformer = YieldFromTransformer()
    transformer.visit(tree);
    transformed_python = astunparse.unparse(tree)
    assert python != transformed_python


# Generated at 2022-06-23 23:27:37.186089
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:46.305861
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class TestYieldFromTransformer(YieldFromTransformer):
        def __init__(self):
            self.input =\
                ast.parse("""yield from [x for x in range(5)]""", mode='eval')
            self.output =\
                ast.parse("""
let(iterable)
try:
    iterable = iter([x for x in range(5)])
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                exc = exc.value
            break
except BaseException as exc:
    raise
                """, mode='exec')
            super().__init__()

    return TestYieldFromTransformer()

# Generated at 2022-06-23 23:27:50.957077
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test(tree: ast.AST) -> ast.AST:
        transformer = YieldFromTransformer()
        return transformer.visit(tree)

    from ..tests.test_transformers import yield_from_example

    expected = yield_from_example()
    actual = test(expected)
    assert actual == expected



# Generated at 2022-06-23 23:27:52.818490
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:56.721387
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from .utils import get_ast

    test_tree = get_ast('test/fixtures/yield_from_test.py')
    tree = YieldFromTransformer(test_tree).visit(test_tree)

# Generated at 2022-06-23 23:28:05.548835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    def test_case(node, expected):
        compiled = compile(node, '', 'exec')
        compiled_ast = ast.parse(compiled)
        result = t.visit(compiled_ast)
        result_code = compile(result, '', 'exec')
        expected_code = compile(expected, '', 'exec')
        assert result_code == expected_code

    code = """
        def foo():
            a = yield from range(1, 3)
            return a
        """

# Generated at 2022-06-23 23:28:15.114624
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import astunparse

    class TestYieldFromTransformer(unittest.TestCase):
        def test_1(self):
            code = """
                def test():
                    x = y
                """
            tree = ast.parse(code)
            transformer = YieldFromTransformer()
            new_tree = transformer.visit(tree)
            unparsed = astunparse.unparse(new_tree)
            self.assertEqual(code, unparsed)

        def test_2(self):
            code = """
                def test():
                    x = y
                    z = x + 1
                """
            tree = ast.parse(code)
            transformer = YieldFromTransformer()
            new_tree = transformer.visit(tree)

# Generated at 2022-06-23 23:28:15.957192
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:28:22.223998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .normalize_if import NormalizeIfTransformer
    from .normalize_while import NormalizeWhileTransformer
    from .normalize_for import NormalizeForTransformer
    from .normalize_try import NormalizeTryTransformer
    from .yield_from import YieldFromTransformer
    from ..utils.snippet import snippet

    code = snippet(
        '''
        def foo():
            while True:
                try:
                    yield from range(10)
                except StopIteration as exc:
                    pass
        '''
    )

    module = ast.parse(code)
    module = NormalizeIfTransformer().visit(module)
    module = NormalizeWhileTransformer().visit(module)
    module = NormalizeForTransformer().visit(module)
    module

# Generated at 2022-06-23 23:28:30.565841
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast
    from .test_base import NodeTestCase

    class YieldFromTransformerTester(NodeTestCase, YieldFromTransformer):
        pass

    code = """\
    def a():
        yield from b()
    """
    compiled = """\
    def a():
        let(iterable)
        iterable = iter(b())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """
    YieldFromTransformerTester.check_on_input(code, compiled)

    code = """\
    def a():
        yield from b(); x=2
    """

# Generated at 2022-06-23 23:28:31.125994
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:28:32.588998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # make sure that it can be instansiated
    YieldFromTransformer(None)

# Generated at 2022-06-23 23:28:42.157015
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.tree import ast_to_str
    from ..utils.source import source_to_ast

    yield_from_ast = source_to_ast(textwrap.dedent('''
        def _():
            exc = None
            iterable = iter(generator)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        target = exc.value
                    break
    '''))

    class MockNode(ast.AST):
        body = []

    node1 = MockNode()
    node2 = MockNode()
    node2.body = [ast.Expr(value=ast.YieldFrom(value=ast.Name(id='generator')))]

# Generated at 2022-06-23 23:28:49.193539
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer()
    func = """def test(a):
    b = yield from a
    return b
"""
    tree = ast.parse(func)
    transformer.visit(tree)
    expected = """def test(a):
    exc = None
    iterable = iter(a)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                b = exc.value
            break

    return b
"""
    assert ast.dump(tree, annotate_fields=False) == expected

# Generated at 2022-06-23 23:28:56.875616
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as pyast
    # Setup
    code_string = "for _ in range(5):\n    yield from some"
    expected_string = "for _ in range(5):\n    let(iterable)\n    iterable = iter(some)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            break\n"
    tree = pyast.parse(code_string)
    transformer = YieldFromTransformer()
    # Exercise
    transformer.visit(tree)
    # Verify
    assert expected_string == transformer.dump_ast(tree)

# Generated at 2022-06-23 23:28:57.997542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer



# Generated at 2022-06-23 23:28:58.992696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    f = YieldFromTransformer()
    assert f

# Generated at 2022-06-23 23:29:05.180155
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    class Src:
        node: ast.AST
        src: str

    def check(f):
        node = f.__code__
        return Src(node, source(node))

    def t1(x):
        y = yield from x

    def t2(x):
        yield from x

    def t3(x):
        y = yield from x
        return y

    def t4(x):
        a = []
        b = yield from x
        a.append(b)

    def t5(x):
        a = []
        yield from x
        a.append(b)

    for t in [t1, t2, t3, t4, t5]:
        src = check(t)
        print(src.src)

# Generated at 2022-06-23 23:29:05.768658
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:17.283939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast_toolbox import ast

    node = ast("""
        def foo():
            x = yield from [1, 2]
            yield from x
    """)

    transform = YieldFromTransformer()
    ast.fix_missing_locations(transform(node))

    expected = ast("""
        def foo():
            iterable = iter([1, 2])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    x = exc.value
                    break
            exc = None
            iterable = iter(x)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """)

    assert ast.dump(node, False) == ast.dump(expected, False)

# Generated at 2022-06-23 23:29:19.687564
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Unit test of function _get_yield_from_index()

# Generated at 2022-06-23 23:29:28.701575
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import astunparse
    from ..utils.source import Source


# Generated at 2022-06-23 23:29:29.268615
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:34.159327
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    input_ = """
    def func(a, b):
        a = yield from b
        yield from c
    """
    output_ = """
    def func(a, b):
        let(iterable)
        iterable = iter(b)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                a = exc.value
                break
        let(iterable)
        iterable = iter(c)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break

    """
    expected_node = ast.parse(output_)
    node = ast.parse(input_)
    YieldFromTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected_node)

# Generated at 2022-06-23 23:29:44.944024
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('''def f():
    a = yield from range(5)
    b = yield from range(5)
    c = yield from range(5)
    yield from range(5)
    yield from range(5)''')


# Generated at 2022-06-23 23:29:54.902202
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    #     def foo():
    #         param = yield from foo()
    #         yield from foo()

    foos = ast.Call(func=ast.Name(id='foo', ctx=ast.Load()), args=[], keywords=[])

    param = ast.Name(id='param', ctx=ast.Store())
    assign = ast.Assign(targets=[param], value=ast.YieldFrom(value=foos, ctx=ast.Load()))

    yield_from = ast.Expr(value=ast.YieldFrom(value=foos, ctx=ast.Load()))


# Generated at 2022-06-23 23:29:55.864505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-23 23:30:05.820558
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import compare_ast
    from ..antlr.Python3Lexer import Python3Lexer
    from ..antlr.Python3Parser import Python3Parser
    from ..antlr.Python3ParserListener import Python3ParserListener
    from io import StringIO
    from antlr4 import InputStream

    class TestListener(Python3ParserListener):
        def __init__(self):
            self.tree = None

        def visitTerminal(self, node):
            pass

        def visitErrorNode(self, node):
            pass

        def enterEveryRule(self, ctx):
            pass

        def exitEveryRule(self, ctx):
            pass

        def enterSingle_input(self, ctx):
            pass

        def exitSingle_input(self, ctx):
            pass


# Generated at 2022-06-23 23:30:07.209577
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.utils import compare_ast, parse_str


# Generated at 2022-06-23 23:30:13.645292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeTransformer
    class Test(BaseNodeTransformerTest):
        transformer = YieldFromTransformer()
        code = 'yield from generator'
    # It is not possible to test node transformers on Python versions below 3.3.
    # It is because TypedAst doesnt containast.YieldFrom node.
    if BaseNodeTransformer.target >= (3, 3):
        Test()


# Generated at 2022-06-23 23:30:23.076509
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..unparse import Unparser
    test_input = """
        def test(gen):
            a = yield from gen

        def test2(gen):
            yield from gen
    """
    test_expected = """
        def test(gen):
            exc = 'exc'
            iterable = iter(gen)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    a = exc.value
                    break
        
        def test2(gen):
            exc = 'exc'
            iterable = iter(gen)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    pass
                    break
    """
    u = Unparser()
    tree = ast.parse(test_input)
    Y

# Generated at 2022-06-23 23:30:33.002183
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from ..utils.tree import tree
    from ..utils.visitor import Visitor

    source1 = '''
    def f(gen):
        yield from gen
    '''
    source2 = '''
    def f(gen):
        x = yield from gen
    '''
    source3 = '''
    def f(gen):
        x = 5
        yield from gen
    '''

# Generated at 2022-06-23 23:30:33.849631
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:30:34.587169
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer

# Generated at 2022-06-23 23:30:35.348129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:30:42.529161
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import as_str

    @snippet
    def input():
        for i in range(1, 10):
            yield i
            yield from [1, 2, 3]

    @snippet
    def expected_output():
        let(iterable)
        exc = VariablesGenerator.generate('exc')
        iterable = iter(range(1, 10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    pass
                break
        iterable = iter([1, 2, 3])
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    pass
                break


# Generated at 2022-06-23 23:30:52.637449
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import cast
    from ..ast import parse, dump
    from .return_transformer import ReturnTransformer
    from .yield_transformer import YieldTransformer
    from .function_transformer import FunctionTransformer
    from .coroutine_transformer import CoroutineTransformer
    from .loop_transformer import LoopTransformer
    from .async_transformer import AsyncTransformer
    from ..utils.helpers import var_name_generator, Proxy

    def transform(code: str,
                  gen: Optional[Proxy] = None,
                  mode: str = 'function') -> str:
        tree = parse(code)
        if mode == 'function':
            tree = FunctionTransformer(gen).visit(tree)

# Generated at 2022-06-23 23:30:54.505415
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft is not None


if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:30:59.837925
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    class_ = YieldFromTransformer

    # Test of transformation of assignment
    t1 = class_('a')
    tree1 = ast.Try(body=[
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.YieldFrom(value=ast.Name(id='b', ctx=ast.Load()))),
        ast.Expr(value=ast.Name(id='a', ctx=ast.Load()))
    ], handlers=[], orelse=[], finalbody=[])
    tree1 = t1.visit(tree1)  # type:ignore # pylint: disable=no-value-for-parameter
    assert isinstance(tree1, ast.Try)
    assert len(tree1.body) == 2

# Generated at 2022-06-23 23:31:01.170219
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    import astor
