

# Generated at 2022-06-23 23:21:13.970118
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ast_factory.ast_node_factory import ASTNodeFactory

    from ast_helpers.transformator import compile_transformers

    def transform(source):
        tree = ast.parse(source)
        return compile_transformers(YieldFromTransformer).visit(tree)

    def test(source, target):
        assert target == compile(transform(source), '<test>', 'exec')

    test('result = yield from range(10)',
         'result = 0\n'
         'while True:\n'
         '    try:\n'
         '        result = next(iter(range(10)))\n'
         '    except StopIteration as exc:\n'
         '        result = exc.value\n'
         '        break\n')


# Generated at 2022-06-23 23:21:15.680531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    def test(tree):
        yft = YieldFromTransformer()
        tree = yft.visit(tree)
        print(astunparse.unparse(tree))
        print(ast.dump(tree))

# Generated at 2022-06-23 23:21:22.325692
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import _ast
    from pystan.model_code_writer.transformer import YieldFromTransformer
    from pystan.model_code_writer.utils.helpers import get_target_version

    target = get_target_version()
    node = _ast.Module([_ast.Expr(_ast.YieldFrom(_ast.Call(
        _ast.Name('something', _ast.Load()), [], [], None, None)))])

# Generated at 2022-06-23 23:21:31.951794
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from astor import dump

    source = source_to_unicode(
        """
        def test(a):
            return a

        def test2(b):
            return b

        foo = test(1) + test2(2)
        bar = test(1) + test2(2)
        """
    )

    module = ast.parse(source)
    transformation = YieldFromTransformer()
    transformed_module = transformation.visit(module)
    transformed_source = source_to_unicode(dump(transformed_module))


# Generated at 2022-06-23 23:21:40.850589
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import _ast as ast
    from ..utils.helpers import generate_code
    method = YieldFromTransformer.visit

    node = ast.FunctionDef(
      name='func',
      args=ast.arguments(args=[], vararg=None, kwarg=None, defaults=[]),
      body=[
        ast.Expr(value=ast.Call(
          func=ast.Name(id='print', ctx=ast.Load()),
          args=[ast.Str(s='Hello world!')],
          keywords=[]
        )),
        ast.Expr(value=ast.YieldFrom(value=ast.Name(id='iterable', ctx=ast.Load())))
      ],
      decorator_list=[],
      returns=None
    )

# Generated at 2022-06-23 23:21:43.295169
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(-1,'foo')
    except TypeError as te:
        assert str(te) == "__init__() takes 1 positional argument but 3 were given"
    except Exception as e:
        raise AssertionError("No exception should be raised and one was raised") from e

# Generated at 2022-06-23 23:21:43.881447
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:21:53.113670
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test first case
    result = ast.parse("yield from a")
    # should have different node address
    assert id(result) != id(YieldFromTransformer)
    assert repr(result) == 'YieldFromTransformer()'
    assert result.__str__() == 'YieldFromTransformer()'
    assert result.__doc__ == 'YieldFromTransformer()\n'
    assert result.__module__ == '__main__'

    # test second case
    result = ast.parse("a = yield from b")
    # should have different node address
    assert id(result) != id(YieldFromTransformer)
    assert repr(result) == '<_ast.Assign object at 0x0000022F46AF8C88>'

# Generated at 2022-06-23 23:21:53.843194
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yieldFromTransformer = YieldFromTransformer()

# Generated at 2022-06-23 23:21:56.219129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .asserts import get_args
    args = get_args(YieldFromTransformer)
    assert args == (BaseNodeTransformer, )

# Generated at 2022-06-23 23:21:58.401046
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .attributes import AttributesTransformer


# Generated at 2022-06-23 23:22:08.785262
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():

    import astor
    from ..utils.tree import build

    def compile_from_source(code: str, transformer: Type[BaseNodeTransformer],
                            keep_trees: bool = False) -> str:
        tree = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
        transformer(tree).run()
        if keep_trees:
            tree = transformer.get_tree()
        return astor.to_source(tree)

    # actual transformation is taken from the test_yield_from_result_binding
    code = '''
        def foo(a):
            yield from a
    '''

# Generated at 2022-06-23 23:22:16.461274
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source

    transformer = YieldFromTransformer()
    tree = source("""
    def foo():
        result = yield from generator()
        print(result)
    """)

    transformer.visit(tree)

    source_after_transformation = transformer.dump_tree()
    assert source_after_transformation == """def foo():
    let(_exc)
    _exc = None
    _iterable = iter(generator())

    while True:
        try:
            _next = next(_iterable)
        except StopIteration as _exc:
            result = _exc.value
            break

    print(result)
"""

# Generated at 2022-06-23 23:22:17.611698
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-23 23:22:18.409507
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	assert YieldFromTransformer(None, None)

# Generated at 2022-06-23 23:22:19.350519
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-23 23:22:25.963473
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from unittest import TestCase
    from ..utils.visitor import as_code

    class TestYieldFromTransformer(TestCase):
        def test_handle_expressions(self):
            from .syntax_tree_to_source_tree_transformer import SyntaxTreeToSourceTreeTransformer

            code = """try:
                yield from (i for i in range(10))
            except:
                pass"""

            tree = SyntaxTreeToSourceTreeTransformer().visit(ast.parse(code))
            transformer = YieldFromTransformer()
            tree = transformer.visit(tree)
            code_res = as_code(tree)

            self.assertIn('exc = VariablesGenerator.generate_var_name()', code_res)

# Generated at 2022-06-23 23:22:26.709613
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == "YieldFromTransformer"

# Generated at 2022-06-23 23:22:35.613191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astunparse import unparse
    from ast import parse, Name
    from .base import BaseNodeTransformer
    class YieldFromTransformer(BaseNodeTransformer):
        """Compiles yield from to special while statement."""
        target = (3, 2)

        def _get_yield_from_index(self, node: ast.AST,
                                  type_: Type[Holder]) -> Optional[int]:
            if hasattr(node, 'body') and isinstance(node.body, list):  # type: ignore
                for n, child in enumerate(node.body):  # type: ignore
                    if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                        return n

            return None


# Generated at 2022-06-23 23:22:42.926670
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .utils import compare_nodes, parse, unparser
    from .utils.utils import transpile_with_node

    examples = (
        'yield from foo()',
        'yield from foo().bar',
        'a = yield from foo()',
    )

    for example in examples:
        actual, transformer = transpile_with_node(example, YieldFromTransformer)
        actual = unparser(actual)
        expected = unparser(parse(example, mode='eval'))
        assert compare_nodes(actual, expected), '%s: %s' % (example, actual)

# Generated at 2022-06-23 23:22:44.053657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()

# Generated at 2022-06-23 23:22:44.677915
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

# Generated at 2022-06-23 23:22:52.360370
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os
    import sys
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                 '../../python')))
    from python.transforms import YieldFromTransformer
    import typed_astunparse
    from python.wrappers import tree_parse

    path = 'python/examples/yield_from.py'
    example = 'def generator():\n    try:\n        yield 1\n    except StopIteration as e:\n        pass\n'
    tree = tree_parse(example, path)
    expected = 'def generator():\n    iterable = iter(1)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            break\n'
    YieldFrom

# Generated at 2022-06-23 23:22:53.240127
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.transform import auto_transform


# Generated at 2022-06-23 23:22:53.907062
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:22:55.482804
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x == YieldFromTransformer()


# Generated at 2022-06-23 23:23:02.802081
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse('''
        def fn():
            a = yield from ()
            yield from ()  # nopep8
    ''')
    fn = module.body[0]
    transformer = YieldFromTransformer()
    module = transformer.visit(module)
    assert isinstance(module.body[0], ast.FunctionDef)
    assert module.body[0].name == 'fn'
    fn_body = module.body[0].body
    assert len(fn_body) == 4
    assignments = [
        ast.parse('iterable = tuple()').body[0],
        ast.parse('iterable = tuple()').body[0],
    ]
    assert fn_body[0] == assignments[0]
    assert fn_body[1] == assignments[1]

# Generated at 2022-06-23 23:23:12.896386
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #  def test(val):
    #      yield from val
    source = ast.parse('def test(val):\n    yield from val')
    assert len(source.body[0].body) == 1
    assert isinstance(source.body[0].body[0].value, ast.YieldFrom)

    #  def test(val):
    #      yield from val
    #      x = yield from val
    source = ast.parse('def test(val):\n    yield from val\n    x = yield from val')
    assert len(source.body[0].body) == 2
    assert isinstance(source.body[0].body[0].value, ast.YieldFrom)
    assert isinstance(source.body[0].body[1].value, ast.YieldFrom)

    #  def test(val):

# Generated at 2022-06-23 23:23:22.076782
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    yield_from_stmt = ast.YieldFrom(ast.Call(ast.Name(id='foo', ctx=ast.Load()), [], []))
    yield_from_stmt_expr = ast.Expr(value=yield_from_stmt)

    # Test case 1: if body contains yield_from stmt
    if_body = [yield_from_stmt_expr]
    if_stmt = ast.If(test=ast.Name(id='a', ctx=ast.Load()), body=if_body, orelse=[])
    if_stmt = YieldFromTransformer().visit(if_stmt)
    assert type(if_stmt.body[0]) is ast.Assign

# Generated at 2022-06-23 23:23:29.372229
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Test 1.
    # Test if it can compile yield from.
    code = """
    yield from x  # type: ignore
    """
    tree = compile(code, '', 'exec', flags=0, dont_inherit=True)
    new_tree = YieldFromTransformer().visit(tree)
    result = ast.dump(new_tree)

# Generated at 2022-06-23 23:23:39.779281
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from functools import partial
    from ..token import Token
    from ..utils.helpers import fill_ast
    from ..utils.tree import to_str

    code = """
async def foo(arg):
    yield from a
    yield from b
    yield from c
    a = yield from d
    e = yield from 42
    yield from f
    f = yield from g
    yield from h
    h = yield from 43
    yield from i
    i = yield from j
    yield from k
    k = yield from l
    yield from m
    m = yield from n
"""

    tree = fill_ast(code)
    assert to_str(tree) == code

    node = YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:23:40.722579
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:23:51.984213
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typed_ast.ast3 as ast
    from darglint.errors import YieldFromNotSupported
    from darglint.transformer.yieldfrom import YieldFromTransformer

    r1 = ast.Assign(
        targets=[ast.Name(id="a")],
        value=ast.YieldFrom(),
        type_comment=None,
    )

    r2 = ast.Assign(
        targets=[ast.Name(id="b")],
        value=ast.YieldFrom(),
        type_comment=None,
    )

    r3 = ast.Expr(
        value=ast.YieldFrom(),
    )


# Generated at 2022-06-23 23:24:03.494324
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # asignments
    module: ast.Module = ast.parse('a = yield from b;c = yield from d')  # type: ignore
    YieldFromTransformer().visit(module)

# Generated at 2022-06-23 23:24:10.713775
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse, dump, NodeTransformer
    from ..utils.helpers import convert
    from textwrap import dedent

    class TestTransformer(NodeTransformer):
        def visit_AsyncFunctionDef(self, node):
            return self.generic_visit(node)


# Generated at 2022-06-23 23:24:21.479576
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""
        def hello(generator, generator_2=None):
            value = yield from generator
            value_2 = yield from generator_2
            yield from generator
            yield from generator_2
    """)
    transform = YieldFromTransformer(tree)
    transformed_tree = transform.visit(tree)
    result = ast.dump(transformed_tree)

# Generated at 2022-06-23 23:24:22.928352
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import get_ast, dump_ast

# Generated at 2022-06-23 23:24:25.749794
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astmonkey.transformers import ParentNodeTransformer
    from ..utils import parse_to_ast
    from astmonkey import transformers

# Generated at 2022-06-23 23:24:33.423474
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    m = ast.parse('def foo():\n    x=yield from bar()\n    yield from extra')
    y=YieldFromTransformer()
    assert str(y.visit(m)) == "def foo():\n    iterable = iter(bar())\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            x = exc.value\n            break\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            break\n"

# Generated at 2022-06-23 23:24:41.171091
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import ast_test
    from . import Context, ModuleTransformer
    code = """
    x = yield from range(10)
    yield from range(10)
    """
    expected = """
    iterable = iter(range(10))
    while True:
        try:
            x = next(iterable)
            yield x
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                x = exc.value
            break
    iterable = iter(range(10))
    while True:
        try:
            next(iterable)
            yield None
        except StopIteration as exc:
            break
    """
    ctx = Context(mode=3, target=(3, 2), flags=ast_test.Flags.PY36, filename='')

# Generated at 2022-06-23 23:24:41.867998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-23 23:24:43.536556
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Test(YieldFromTransformer):
        pass
    transformer = Test()
    assert transformer.target == (3, 2)

# Generated at 2022-06-23 23:24:49.916652
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .syntax_test_cases import test_cases
    from .ast_utils import are_asts_equals, parse
    from .context import Context

    for test_case in test_cases:
        tree = parse(test_case)
        context = Context()
        new_tree = YieldFromTransformer(context).visit(tree)
        equivalent_tree = parse(test_case.replace('yield from', 'yield'))

        assert are_asts_equals(new_tree, equivalent_tree) == True

# Generated at 2022-06-23 23:24:55.467813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.test_visitors.test_YieldFromTransformer import code
    from ..visitors import ClassDefVisitor, YieldFromTransformer
    from ..utils.helpers import get_ast
    ast_tree = get_ast(code)
    ClassDefVisitor().visit(ast_tree)
    YieldFromTransformer().visit(ast_tree)
    assert str(ast_tree) == code

# Generated at 2022-06-23 23:25:02.095041
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.FunctionDef('test', [], [], [],
                        ast.Expr(ast.YieldFrom(ast.Name('a'))), None, None)
    b = ast.FunctionDef('test', [], [], [],
                        ast.Assign([ast.Name('a')], ast.Name('b')), None, None)
    new = []
    new.append(YieldFromTransformer(None, None, None).visit(a))
    new.append(YieldFromTransformer(None, None, None).visit(b))
    assert new[0].body[0].value.func.id == 'yield_from'
    assert new[1].body[0].value.func.id == 'yield_from'


# Generated at 2022-06-23 23:25:02.816673
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:11.494908
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        import astor
    except ImportError:
        print('Skip YieldFromTransformer unit test: missing astor')
        return

    # Note: do not use qualified names in the source code because it will
    # break the unit test!
    class Compiler(YieldFromTransformer):
        def __init__(self):
            super().__init__()
            self.source_code = None

        def visit_Module(self, node: ast.Module) -> ast.AST:
            self.source_code = astor.to_source(node)
            return node

    compiler = Compiler()

# Generated at 2022-06-23 23:25:13.305756
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arrange
    import typed_astunparse


# Generated at 2022-06-23 23:25:14.243430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-23 23:25:21.391932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc = VariablesGenerator.generate('exc')
    target = VariablesGenerator.generate('target')
    assignment = result_assignment.get_body(exc = exc, target = target)
    generator = VariablesGenerator.generate('generator')
    y = yield_from.get_body(generator = generator, assignment = assignment, exc = exc)

# Generated at 2022-06-23 23:25:28.037077
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    module = ast.parse("""
    def run_until_complete(coro):
        return_value = None
        result = coro.send(None)
        while True:
            try:
                return_value = yield from result
            except Exception as exc:
                result = coro.throw(exc)
                raise StopIteration
    """)
    tree = YieldFromTransformer().visit(module)
    # TODO
    pass


# Generated at 2022-06-23 23:25:35.722004
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .loop import LoopTransformer
    from .function import FunctionTransformer
    from .module import ModuleTransformer

    # Should call generic_visit
    assert YieldFromTransformer().visit(None) is None

    # Should not call generic_visit
    transformer = YieldFromTransformer()
    transformer.generic_visit = lambda _: 'TEST'
    assert transformer.visit(None) == 'TEST'

    # Should transform yield from statement to special while statement
    transformer = YieldFromTransformer()
    result = ast.parse('yield from M1')

# Generated at 2022-06-23 23:25:46.564880
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Unit test for method visit of class YieldFromTransformer
    from ..visitor import flatten, dump_tree
    from typed_ast.ast3 import parse
    from .. import typed_astunparse

    code = "def foo(): yield from bar()"
    tree = parse(code)
    dumper = dump_tree(tree)
    visitor = YieldFromTransformer()
    visitor.visit(tree)
    target = typed_astunparse.unparse(tree)
    dumper = dump_tree(tree)
    target = typed_astunparse.unparse(tree)

# Generated at 2022-06-23 23:25:50.268627
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    t = YieldFromTransformer(None)
    node = ast.parse('yield from func()')
    node_func_body = node.body[0].value.value.body[0].body
    print(node_func_body)
    t._emulate_yield_from(None, node)

# Generated at 2022-06-23 23:25:56.635676
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import compile_snippets
    from ..utils.helpers import VariablesGenerator

    compiled, = compile_snippets(YieldFromTransformer, """
    import typing
    def func(x: typing.Generator[int, None, str]) -> None:
        y = yield from x
    """)

# Generated at 2022-06-23 23:25:59.689526
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import copy
    import typing
    import inspect

    # codeStart is the section of code to be modified by the YieldFromTransformer.

# Generated at 2022-06-23 23:26:04.591402
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.parse('def function():\n yield from []')
    assert a.body[0].body[0].value.value.id == '[]'
    b = YieldFromTransformer.run(a)
    assert b.body[0].body[0].value.generator.value.id == '[]'

# Generated at 2022-06-23 23:26:09.833580
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_astunparse import dump
    from .utility import find_compile_target, run_test_node, disable_logging
    from .test_compile_transformer import build_module_from_source

    with disable_logging():
        all_targets = sorted(find_compile_target(), key=lambda t: t.version)

# Generated at 2022-06-23 23:26:15.143010
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import load_ast_tree
    from ..utils.visitor import PrintVisitor

    # assert load_ast_tree('foo') == 0
    tree = YieldFromTransformer().visit(
        load_ast_tree('"a" if True else ("b" if False else "c")')
    )
    assert PrintVisitor().visit(tree) == '"a"'



# Generated at 2022-06-23 23:26:17.873993
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..environment import Environment
    env = Environment()

    assert isinstance(env.get_node_transformer(YieldFromTransformer), YieldFromTransformer)

# Generated at 2022-06-23 23:26:19.009224
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:26:28.937235
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Tests compilation of yield from in line
    code = """
    class A:
        def func(self):
            a = yield from range(10)
    """
    module_node = ast.parse(code)
    assert isinstance(module_node, ast.Module)
    transformer = YieldFromTransformer()
    node = transformer.visit(module_node)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.ClassDef)
    assert len(node.body[0].body) == 1
    assert isinstance(node.body[0].body[0], ast.FunctionDef)
    assert len(node.body[0].body[0].body) == 2

# Generated at 2022-06-23 23:26:30.174345
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:26:31.469385
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None



# Generated at 2022-06-23 23:26:40.908990
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import NodeTransformerTestCase, astdump, YieldFromTransformer

    class Test(NodeTransformerTestCase):
        transformer = YieldFromTransformer
        method = 'visit_Module'

        def test_simple_yield_from(self):
            self.check_output("""
                def foo():
                yield from bar()
                """, """
                def foo():
                iterable = iter(bar())
                while True:
                try:
                yield next(iterable)
                except StopIteration as exc:
                break
                """)


# Generated at 2022-06-23 23:26:46.005232
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile
    from .yield_from import YieldFromTransformer
    assert not hasattr(compile, 'YieldFromTransformer')
    assert 'YieldFromTransformer' not in str(type(compile))
    YieldFromTransformer()
    assert hasattr(compile, 'YieldFromTransformer')
    assert 'YieldFromTransformer' in str(type(compile))

# Generated at 2022-06-23 23:26:56.175813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .transformer_test_util import should_not_change, pytree_to_string

    should_not_change(YieldFromTransformer, """
        def foo():
            yield from {}
    """)

    should_not_change(YieldFromTransformer, """
        def foo():
            yield from func()
    """)

    assert pytree_to_string(YieldFromTransformer, """
        def foo():
            a = yield from {}
    """) == """
        def foo():
            let(iterable)
            iterable = iter({})
            let(exc)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    a = exc.value
                    break
    """


# Generated at 2022-06-23 23:26:56.759338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer.__init__

# Generated at 2022-06-23 23:27:00.087176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    YieldFromTransformer._tree_changed = True
    YieldFromTransformer._output_file = False
    assert YieldFromTransformer._tree_changed == True
    assert YieldFromTransformer._output_file == False

# Generated at 2022-06-23 23:27:00.563976
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:27:04.819466
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import inspect
    from ..core import Compiler
    from ..utils.source import source_to_module
    from ..core.exceptions import CompileError
    from ..utils.helpers import get_free_vars

# Generated at 2022-06-23 23:27:12.558663
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('x = yield from range(10)')
    YieldFromTransformer()(node)
    expected = ast.parse('iterable = iter(range(10))\n'
                         'while True:\n'
                         '    try:\n'
                         '        x = next(iterable)\n'
                         '        yield x\n'
                         '    except StopIteration as exc:\n'
                         '        x = exc.value\n'
                         '        break')
    assert ast.dump(node) == ast.dump(expected)


# Generated at 2022-06-23 23:27:18.163092
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import get_free_function
    f = get_free_function('def f():\n    a = yield from b()')
    expected_ast = ast.parse('def f():\n    it = iter(b())\n    while True:\n        try:\n            a = next(it)\n        except StopIteration as exc:\n            a = exc.value\n            break')
    transformed = YieldFromTransformer.run_on_single_file(f)
    assert ast.dump(transformed['f'], annotate_fields=False) == ast.dump(expected_ast, annotate_fields=False)

# Generated at 2022-06-23 23:27:18.832282
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:27:22.688826
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.examples import LoaderExamples

    examples = LoaderExamples.get_ast_examples(['examples/yield_from.py'])[:1]
    YieldFromTransformer().visit(examples[0])

# Generated at 2022-06-23 23:27:23.356456
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:24.951750
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:25.675530
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()


# Generated at 2022-06-23 23:27:37.490875
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    @snippet
    def yield_from(module):
        let(function_def)

# Generated at 2022-06-23 23:27:38.639569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x._tree_changed is False

# Generated at 2022-06-23 23:27:49.161394
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def _create_module(source):
        module = ast.parse(source)
        return module, YieldFromTransformer().visit(module)

    def _assert_module(before, after):
        module, _module = _create_module(before)
        assert ast.dump(_module) == ast.dump(ast.parse(after))


# Generated at 2022-06-23 23:27:50.112696
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:27:59.414133
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import get_ast
    from ..utils.helpers import make_snippet
    tree = get_ast("""
    def foo():
        yield from bar
    """)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert make_snippet(tree) == make_snippet("""
    def foo():
        try:
            iterable = iter(bar)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        except GeneratorExit as exc:
            try:
                iterable.close()
            except:
                pass
            raise
    """)

    tree = get_ast("""
    def foo():
        a = yield from bar
    """)
    transformer = YieldFromTransformer()


# Generated at 2022-06-23 23:28:00.677772
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer_object = YieldFromTransformer()

# Generated at 2022-06-23 23:28:02.267742
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None).__dict__ == YieldFromTransformer(None, None).__dict__

# Generated at 2022-06-23 23:28:04.175742
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import test_transformer


# Generated at 2022-06-23 23:28:05.073356
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:28:08.310971
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def emulate_yield_from_test_1(num):
        gen = set()
        while True:
            try:
                yield next(gen)
            except StopIteration as exc:
                num = exc.value
            break
        return num


# Generated at 2022-06-23 23:28:16.809733
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    # TODO: test that class has methods _get_yield_from_index, generic_visit, _handle_assignments, _emulate_yield_from, visit, _handle_expressions
    node = get_ast(YieldFromTransformer)
    assert '_get_yield_from_index' in dir(node)
    assert 'generic_visit' in dir(node)
    assert '_handle_assignments' in dir(node)
    assert '_emulate_yield_from' in dir(node)
    assert 'visit' in dir(node)
    assert '_handle_expressions' in dir(node)



# Generated at 2022-06-23 23:28:22.633664
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.codegen import codegen
    from .. import compile_ast
    source = '''
    def test():
        for i in range(4):
            x = yield from other()
    '''
    tree = compile_ast(source)
    tree = YieldFromTransformer().visit(tree)
    code = codegen(tree)
    print(code)


__all__ = ['YieldFromTransformer']

# Generated at 2022-06-23 23:28:26.332003
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = '''
    def f():
        a = yield from g()
        b = yield from h()
        yield from i()
        return a + b
    '''
    node = ast.parse(code)
    YieldFromTransformer().visit(node)

# Generated at 2022-06-23 23:28:28.027954
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

    # Check for visit function
    assert callable(transformer.visit)

# Generated at 2022-06-23 23:28:29.949460
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-23 23:28:39.651276
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.FunctionDef(
        name='f',
        args=ast.arguments(
            args=[],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]),
        body=[ast.Expr(value=ast.YieldFrom(value=ast.Call(
            func=ast.Name(id='g', ctx=ast.Load()),
            args=[],
            keywords=[])))],
        decorator_list=[],
        returns=None)


# Generated at 2022-06-23 23:28:47.210075
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_code

    class_ = YieldFromTransformer
    assert_equal_code(class_, '''\
from typing import Iterator, Optional
from asyncio import sleep


async def foo(x: Optional[int]) -> Iterator[int]:
    try:
        yield from x
    except Exception as exc:
        pass
''', '''\
from typing import Iterator, Optional
from asyncio import sleep


async def foo(x: Optional[int]) -> Iterator[int]:
    iterable = iter(x)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
''')


# Generated at 2022-06-23 23:28:49.536757
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None and isinstance(YieldFromTransformer, type)
    instance = YieldFromTransformer()
    assert instance is not None and isinstance(instance, YieldFromTransformer)


# Generated at 2022-06-23 23:28:59.431586
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import assert_equal_ast
    from ..utils.snippet import let, extend
    from ..utils.code_db import code_db
    import astor
    import inspect


    class YieldFromTransformer(YieldFromTransformer):
        def transform(self, code):
            assert isinstance(code, str), 'Code must be a string'
            assert isinstance(ast.parse(code), ast.Module), 'Code must be a module'

            tree = ast.parse(code)
            self.visit(tree)

            if self._tree_changed:
                return astor.to_source(tree)

            return code

    class UnitTest(object):
        def __init__(self, code, expected):
            self.code = code


# Generated at 2022-06-23 23:29:01.124742
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transpiler = YieldFromTransformer({})
    assert isinstance(transpiler, YieldFromTransformer)

# Generated at 2022-06-23 23:29:02.894878
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Note: method visit of class YieldFromTransformer
    #       is used in python_to_python_fragment.
    #       Function test_python_to_python_fragment
    #       is used for testing method visit of class YieldFromTransformer.
    pass

# Generated at 2022-06-23 23:29:04.235555
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-23 23:29:11.288923
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Creating AST tree.
    import astor
    module = astor.parse_file(__file__)
    node = module.body[0]

    # Compiling to target Python version.
    from ..utils.driver import Code
    from ..utils.snippet_extractor import get_ast_tree_source
    YieldFromTransformer().visit(module)
    result_source = get_ast_tree_source(Code.python, module)

    assert result_source == 'def test_YieldFromTransformer_visit(): pass\n'

# Generated at 2022-06-23 23:29:22.768272
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test_case(original, expected):
        node = ast.parse(original, "<test>", "exec")
        YieldFromTransformer().visit(node)
        output = ast.dump(node)
        assert output == expected

    # Before
    test_case("yield from obj", 'Module(body=[])')
    test_case("a = yield from obj", "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='iter', ctx=Load()), args=[Name(id='obj', ctx=Load())], keywords=[]))])")
    test_case("'''\n#yield from a\n'''", "Module(body=[Expr(value=Str(s='\\n#yield from a\\n'))])")

# Generated at 2022-06-23 23:29:24.531453
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .context import Context
    x = YieldFromTransformer(Context())
    assert x is not None

# Generated at 2022-06-23 23:29:25.419255
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:29:27.846573
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import parse

# Generated at 2022-06-23 23:29:38.758814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    try_result = YieldFromTransformer().visit(ast.Try(
        body=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='a'))),
              ast.Expr(value=ast.YieldFrom(value=ast.Name(id='b'))),
              ast.Expr(value=ast.YieldFrom(value=ast.Name(id='c'))),
              ast.Expr(value=ast.YieldFrom(value=ast.Name(id='d')))],
        handlers=[],
        finalbody=[],
        orelse=[]))

# Generated at 2022-06-23 23:29:43.037591
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import ast as pyast

    def transform(code):
        module = pyast.parse(code)
        fixer = YieldFromTransformer()
        module = fixer.visit(module)  # type: ignore
        return module


# Generated at 2022-06-23 23:29:44.993696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()
    print('Unit test for constructor of class YieldFromTransformer: ok')


# Generated at 2022-06-23 23:29:47.212562
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .helpers import run_test_program
    from ..utils.helpers import get_ast


# Generated at 2022-06-23 23:29:56.826250
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from python_ta.transforms import YieldFromTransformer
    from . import tree

    class Test_YieldFromTransformer_visit(unittest.TestCase):

        def setUp(self):
            self.maxDiff = None

        def test_case_1(self):
            code = """
            def f():
                yield from 1
                yield from 2
                a = yield from 3
                b = yield from 4
            """
            tree = ast.parse(code)
            transform = YieldFromTransformer()
            transform.visit(tree)

# Generated at 2022-06-23 23:30:06.616936
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    snippet = 'yield from test; yield from test2'
    snippet = parse(snippet.lower())
    visitor = YieldFromTransformer()

    snippet = visitor.visit(snippet)

    assert isinstance(snippet, ast.Module)

    snippet = snippet.body
    assert len(snippet) == 5

    assert len(snippet[0].body) == 1
    assert isinstance(snippet[0].body[0], ast.Assign)
    assert isinstance(snippet[0].body[0].value, ast.Call)
    assert snippet[0].body[0].value.func.id == 'iter'
    assert snippet[0].body[0].value.args[0].id == 'test'

    assert len(snippet[1].body) == 1

# Generated at 2022-06-23 23:30:07.712775
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:09.654520
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os
    import sys
    import tempfile
    from io import StringIO


# Generated at 2022-06-23 23:30:11.480068
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .parser import parse
    from .unparser import Unparser


# Generated at 2022-06-23 23:30:12.429475
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-23 23:30:15.829948
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .ast_builder import build
    from .base import BaseNodeTransformer
    class TestYieldFromTransformer(YieldFromTransformer, BaseNodeTransformer):
        pass    
    TestYieldFromTransformer()


# Generated at 2022-06-23 23:30:21.813369
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    text = 'def f():\n  t = yield from g()'
    expected_text = 'def f():\n' \
                    '  iterable = iter(g())\n' \
                    '  while True:\n' \
                    '    try:\n' \
                    '      yield next(iterable)\n' \
                    '    except StopIteration as exc:\n' \
                    '      t = exc.value\n' \
                    '      break'



# Generated at 2022-06-23 23:30:31.872197
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""
        def foo(x):
            y = yield from x
            yield y
        foo(x for x in range(10))
    """, mode='eval')
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:30:33.067041
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)


# Generated at 2022-06-23 23:30:33.855581
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

# Generated at 2022-06-23 23:30:40.487123
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os
    from typed_astunparse import unparse
    from ..utils.test_utils import assert_code_equal

    test_file = os.path.join(os.path.dirname(__file__), '..', 'utils',
                             'test_files', 'yieldfrom_ast.py')
    with open(test_file) as f:
        tree = compile(f.read(), filename=test_file, mode='exec',
                       flags=ast.PyCF_ONLY_AST,
                       dont_inherit=True)

    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-23 23:30:41.472871
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:30:46.912592
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile

    def func():
        yield from a
        yield from b  # noqa

    code = compile(func)
    stmts = code.get('body')
    assert len(stmts) == 2
    assert isinstance(stmts[0], ast.While)
    assert isinstance(stmts[1], ast.While)

# Generated at 2022-06-23 23:30:48.447255
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:49.430071
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:30:54.118954
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast as to_ast

    source = source_to_unicode('''
        def foo():
            yield from bar()
            yield baz
        ''')
    expected_source = source_to_unicode('''
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

            yield baz
        ''')
    tree = to_ast(source)
    tree = YieldFromTransformer().visit(tree)
    assert expected_source == to_ast(tree)

# Generated at 2022-06-23 23:30:55.392692
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == "YieldFromTransformer"

# Generated at 2022-06-23 23:30:56.177432
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:31:04.837318
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Unit test - test AST without YieldFrom
    test_tree = ast.Module([ast.FunctionDef('f', ast.arguments(), [], [])])
    transformer = YieldFromTransformer()
    node = transformer.visit(test_tree)
    assert transformer.tree_changed() is False
    # Unit test - test AST with only YieldFrom with target
    test_tree = ast.Module([ast.FunctionDef('f', ast.arguments(), [], [
        ast.Assign(
            [ast.Name('target', ast.Store())],
            ast.YieldFrom(
                ast.Name('generator', ast.Load())
            )
        )
    ])])
    transformer = YieldFromTransformer()
    node = transformer.visit(test_tree)
    assert transformer.tree_changed() is True
