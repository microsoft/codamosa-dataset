

# Generated at 2022-06-23 23:21:08.199177
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import os
    import sys
    import astor
    if 'tests' not in os.getcwd():
        path = os.getcwd()
        # Remove last directory from current path
        path = path.rsplit('/', 1)[0]
        # Append 'tests' to current path
        path = os.path.join(path, 'tests')
        # Remove last directory from sys.path
        del sys.path[-1]
        # Append 'tests' to sys.path
        sys.path.append(path)

    import test_utils
    test_utils.export_path(path)

    from test_utils import *


# Generated at 2022-06-23 23:21:15.852520
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import assert_source_equal
    from ..tests.transformer_test_class import TransformerTest
    from ..transformers import TypingImporter, YieldFromTransformer

    code = '''
    def foo():
        x = yield from range(10)
        y = 1
        return x
    '''
    tree, messages = TransformerTest.get_parsed_tree(code)
    transformer = YieldFromTransformer(tree)
    transformer.visit()
    source, _ = TransformerTest.get_source_from_tree(transformer._tree_changed)
    assert_source_equal(code, source, TypingImporter.add_typing_imports)

# Generated at 2022-06-23 23:21:22.686864
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = ast.parse("yield from f()")
    YieldFromTransformer().visit(x)

# Generated at 2022-06-23 23:21:32.367588
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .context import Context
    from .exceptions import CompilationError
    from .exceptions import TransformError
    from .ast_converter import ASTConverter
    from ..tests.fixtures.exceptions import GeneratedFunctionError
    from ..tests.fixtures.test_classes import get_test_function_definition
    import astunparse
    import pickle
    import sys
    fd = get_test_function_definition(0)
    try:
        result = ASTConverter.get_ast(fd)
    except CompilationError as e:
        raise GeneratedFunctionError() from e
    assert isinstance(result, ast.FunctionDef)

# Generated at 2022-06-23 23:21:33.275063
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-23 23:21:42.077906
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    transformer = YieldFromTransformer(None)
    tree = ast.parse("""
    def gen():
        for i in range(5):
            yield i
    def f():
        x = yield from gen()
        yield x
        yield from gen()
        """)


# Generated at 2022-06-23 23:21:45.536118
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("yield from a")
    tree = YieldFromTransformer().visit(tree)
    assert str(tree) == \
'''
while True:
    try:
        yield next(a)
    except StopIteration as exc:
        pass
'''

# Generated at 2022-06-23 23:21:54.141621
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Prepare
    node = ast.parse("""
a = yield from [1, 2]
yield from [1, 2]
""")
    # Run
    YieldFromTransformer().visit(node)
    # Verify

# Generated at 2022-06-23 23:22:03.990698
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from ..utils.test import get_test_count, get_test_number
    from .ast_converter import ASTConverter
    from .generator_transformer import GeneratorTransformer

    get_test_count(5)

    test_node_1 = ast3.parse('yield from (i for i in range(10))')
    t = YieldFromTransformer()
    t.visit(test_node_1)

    ast_converter = ASTConverter()


# Generated at 2022-06-23 23:22:04.929950
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:22:15.260372
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_transformers import get_transformed_source
    from .test_transformers import remove_indents

    def test(source, expected):
        return remove_indents(get_transformed_source(source, [YieldFromTransformer])) == expected

    # Test for assignment
    assert test(
        '''
        def foo(generator):
            a = yield from generator
        ''',
        '''
        def foo(generator):
            let(iterable)
            iterable = iter(generator)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    a = exc.value
                    break
        ''')

# Generated at 2022-06-23 23:22:18.295164
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_helpers import generate_test_code, generate_test_code_with_error

# Generated at 2022-06-23 23:22:24.600092
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_node
    from .base import BaseUnparser
    from .best_transformer import BestTransformer
    import sys

    if sys.version_info < (3, 2):
        return

    tree = source_to_node.parse(
        """
        def x():
            yield from range(2)
            yield from range(2)
            x = yield from range(2)
            yield from range(2)
        """
    )

    transformer = YieldFromTransformer(tree)
    BestTransformer(transformer).visit(tree)
    assert transformer.tree_changed

    print(BaseUnparser(transformer.tree).unparse())



# Generated at 2022-06-23 23:22:32.765281
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
        def generator():
            yield from range(10)
    """
    tree = ast.parse(code)
    YieldFromTransformer(tree).visit(tree)
    expected_code = """
        def generator():
            let(iterable)
            iterable = iter(range(10))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """
    expected_tree = ast.parse(expected_code)
    assert ast.dump(tree, annotate_fields=False) == ast.dump(expected_tree, annotate_fields=False)


# Generated at 2022-06-23 23:22:35.330580
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(obfuscated_code='print("obfuscated_code")')

if __name__ == '__main__':
    snippet()
    test_YieldFromTransformer()

# Generated at 2022-06-23 23:22:36.798318
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test_1():
        code = 'yield from foo()'


# Generated at 2022-06-23 23:22:41.816810
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.pytest_helper import assert_node
    from ..utils import get_example_file
    from ast_utils.transformer import Context

    assert_node(get_example_file('class.py', __file__),
                YieldFromTransformer.__name__,
                context=Context(
                    target_version=tuple(map(int, YieldFromTransformer.target.split('.')))
                ))

# Generated at 2022-06-23 23:22:51.178584
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def func(x):
        a = yield from x
        b = (yield from x)
        yield from x
        yield from x
        z = (yield from x)
        (a + b)
        return z
    module = ast.parse('def func(x):\n\ta = yield from x\n\tb = (yield from x)\n\tyield from x\n\tyield from x\n\tz = (yield from x)\n\t(a + b)\n\treturn z')
    func_node = module.body[0]

# Generated at 2022-06-23 23:22:55.260852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.code_gen import code_gen
    from ..utils.build_ast import build_ast
    from .assignment_fixer import AssignmentFixer

    code = """
k = yield from a
a = yield from b
return yield from b
    """
    tree = build_ast(code)
    YieldFromTransformer().visit(tree)
    AssignmentFixer().visit(tree)
    result = code_gen(tree)

    print(result)

# Generated at 2022-06-23 23:22:56.670868
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse, dump
    from .util import _mangle


# Generated at 2022-06-23 23:23:03.857851
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typing import Generator
    from mypy import types
    from ..utils.helpers import stub_node, get_node_type
    from ..core.annotations import get_var_annotation
    import astor

    transformer = YieldFromTransformer()

    @snippet
    def f():
        let(a)
        a = yield from b
        yield a

    f_body = list(ast.unparse(x).rstrip() for x in f.get_body())
    node = f.get_ast()
    transformer.visit(node)
    result_body = list(ast.unparse(x).rstrip() for x in node.body)

# Generated at 2022-06-23 23:23:14.118367
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def f():
        a, b = yield from c
        yield from d
    """)
    expected_source = Source("""
    def f():
        let(iterable)
        let(exc)
        iterable = iter(c)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                b = exc.value
                break
        let(iterable)
        let(exc)
        iterable = iter(d)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)
    tree

# Generated at 2022-06-23 23:23:16.173897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test 1: test constructor
    tester = YieldFromTransformer()
    assert tester is not None


# Generated at 2022-06-23 23:23:24.798238
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_code, source_from_node
    from ..utils.helpers import assert_contains_code

    source = source_from_node(ast.parse("""
        def foo():
            x = yield from bar()
            yield from baz()

        def fooo():
            yield from bar()

        while True:
            yield from bar()
    """))

    code = source_to_code(source)

# Generated at 2022-06-23 23:23:32.665432
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Create source code
    source_code = """print(yield from [1, 2, 3])"""
    # Compile source code
    module: ast.Module = compile(source_code, filename="<test>", mode="exec")
    # Visit the module
    node_transformer: YieldFromTransformer = YieldFromTransformer()
    result: ast.Module = node_transformer.visit(module)
    expect(result).is_equal("""
yield_from_1 = iter([1, 2, 3])
while True:
    try:
        print(next(yield_from_1))
    except StopIteration as exc_1:
        break
""".strip())

# Generated at 2022-06-23 23:23:41.603901
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .transformer import Transformer
    from ..test._test_utils import assert_source_equal

    source = """\
    class X:
        def f(self):
            a, b = yield from abc()
            yield from defg()

            yield from cdef()
            a = yield from cdef()
    """


# Generated at 2022-06-23 23:23:46.363075
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...testing.test_transformer import test_transformer
    from .remove_unbound_local import RemoveUnboundLocalTransformer
    from .remove_None_return import RemoveNoneReturnTransformer
    test_transformer('asyncio', YieldFromTransformer, [RemoveUnboundLocalTransformer, RemoveNoneReturnTransformer])

# Generated at 2022-06-23 23:23:47.959019
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:23:59.484244
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def test_func(a):
        b = 'a'
        yield b
        if True:
            b = 'b'
            yield from a

    import io
    import astunparse
    import unittest
    from .test_utils import compare_nodes, transform

    class TestYieldFromTransformer(unittest.TestCase):
        """Tests for YieldFromTransformer."""

        maxDiff = None

        def test_yield_from_transformer(self):
            """Right transformation."""
            buff = io.StringIO()
            tree = ast.parse(inspect.getsource(test_func))
            transform(tree, YieldFromTransformer)
            astunparse.unparse(tree, buff)
            self.assertEqual(buff.getvalue(), inspect.getsource(test_func))



# Generated at 2022-06-23 23:24:08.534768
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import parse
    import typing as typ
    import astor
    iff = ast.If(
        test=[ast.Eq(
            left=ast.Name(id='f', ctx=ast.Load()),
            right=ast.Num(n=2)
        )],
        body=[ast.Assign(
            targets=[ast.Name(id='a', ctx=ast.Store())],
            value=ast.YieldFrom(
                value=ast.Name(id='b', ctx=ast.Load())
            )
        )],
        orelse=[ast.Expr(value=ast.YieldFrom(
            value=ast.Name(id='c', ctx=ast.Load())
        ))]
    )

# Generated at 2022-06-23 23:24:19.267491
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse(textwrap.dedent(
        """
        def foo(x):
            a = yield from x
            yield from x
            return b
        """)).body[0]

    expected = ast.parse(textwrap.dedent(
        """
        def foo(x):
            let(exc)
            exc = StopIteration()
            iterable = iter(x)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    a = exc.value
                    break


            let(exc)
            exc = StopIteration()
            iterable = iter(x)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

            return b
        """))

    result = YieldFrom

# Generated at 2022-06-23 23:24:27.019158
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = """
    def f(x):
        y = yield from x
        yield y + 3"""
    result = """
    def f(x):
        let(iterable)
        iterable = iter(x)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    y = exc.value
                break
        yield y + 3"""
    tree = ast.parse(result)
    transformer = YieldFromTransformer()
    assert transformer.visit(ast.parse(source)).body[0] == tree.body[0]

# Generated at 2022-06-23 23:24:37.417750
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typing as t
    import ast as p

    def test_func(lst: t.List[int]):
        while True:
            yield from (x for x in lst)

    node = p.parse(test_func.__text_signature__).body[0]

    node2 = p.parse('''
    def test_func(lst: typing.List[int]):
        let(x)
        let(iterable)
        let(exc)
        iterable = iter(lst)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    x = exc.value
                break
        ''')

    transformer = YieldFromTransformer()
    result = transformer.visit(node)

# Generated at 2022-06-23 23:24:45.592759
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ast_helper.keyword import yield_from
    from ast_helper.typing import arg_type, arg_types_match
    from ast_helper.base import BaseNodeTransformer

    class T(BaseNodeTransformer):
        target = (3, 2)

        @arg_types_match(ast.AST, ast.AST)
        @arg_type(1, ast.assign)
        def v(self, node, assign):
            yield_from_ast = yield_from(assign.value, assign.targets[0], node)
            insert_at(0, node, yield_from_ast)
            return self.generic_visit(node)


# Generated at 2022-06-23 23:24:50.995590
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = '''
    def foo():
        a = yield from [1, 2]
        yield from [3, 4]
        yield from [5, 6]
    '''

    tree = ast.parse(code)
    assert len(list(ast.walk(tree))) == 10
    with YieldFromTransformer() as transformer:
        tree = transformer.visit(tree)
    assert len(list(ast.walk(tree))) == 24

# Generated at 2022-06-23 23:24:53.227560
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..registry import register
    from ..utils.testing import get_node, get_node_str
    from ..simple_transformer import SimpleTransformer

    class TestClass(SimpleTransformer):
        pass

    register(TestClass)


# Generated at 2022-06-23 23:24:53.865811
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:02.565194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest

    import astor
    from textwrap import dedent

    from typed_astunparse import unparse

    class YieldFromTransformerTest(unittest.TestCase):
        def setUp(self):
            self.transformer = YieldFromTransformer()
            self.maxDiff = None

        def assert_convert_back(self, original_source: str,
                                expected_source: str):
            original_ast = astor.parse_file(original_source)
            expected_ast = astor.parse_file(expected_source)

            result_ast = self.transformer.visit(original_ast)
            result_source = unparse(result_ast).strip()

            expected_source = unparse(expected_ast).strip()


# Generated at 2022-06-23 23:25:03.748581
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:08.369755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import unittest.mock
    from typed_ast.ast3 import parse

    snippet = '''def f(a):
        if True:
            yield from f(a)
    '''
    tree: ast.Module = parse(snippet)
    with unittest.mock.patch('typed_astunparse'):
        YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:25:16.318980
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.e2e import module_from_str, run_module
    from .functiondef import FunctionDefTransformer
    from .makename import MakeNameTransformer
    from .basic import BasicTransformer

# Generated at 2022-06-23 23:25:20.602682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _YieldFromTransformer = YieldFromTransformer(lambda x: x)
    assert _YieldFromTransformer.target == (3, 2)

    assert _YieldFromTransformer.visit(node=None) == None


# Generated at 2022-06-23 23:25:23.990448
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:25:26.127160
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.testing import get_node
    from ..utils.ast_compare import compare_asts


# Generated at 2022-06-23 23:25:27.100544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-23 23:25:28.085322
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True


# Generated at 2022-06-23 23:25:29.679838
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()
    assert isinstance(a, YieldFromTransformer)

# Generated at 2022-06-23 23:25:36.717708
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import typing as t
    import astor
    from typed_ast import ast3
    from ..compile import CompileState

    class Prog:
        def __init__(self, state: CompileState):
            self.state = state

        def body(self) -> ast3.Module:
            self.state.variables_generator.pre_generate(
                '__iter__', ['a', 'b', 'exc', 'func', 'res', 'body', 'var', 'iterable'])

# Generated at 2022-06-23 23:25:37.814531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:42.670859
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()._get_yield_from_index(None, None) == None
    #assert YieldFromTransformer()._get_yield_from_index(None, Node) == None
    #assert YieldFromTransformer()._get_yield_from_index(None, Holder) == None

# Generated at 2022-06-23 23:25:49.240778
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
    yield from generator
    """
    expected_code = """
    iterable = iter(generator)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    """
    tree = ast.parse(code)

    transformer = YieldFromTransformer(tree)
    transformer.run()
    compiled_tree = transformer.tree

    assert transformer.tree_changed is True
    assert expected_code == compile(compiled_tree, '', 'exec').co_consts[0]


# Generated at 2022-06-23 23:25:50.068141
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-23 23:25:56.510605
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_node

    source = """
    def test(a):
        yield from a
        a = yield from b
        yield from c
        yield from d
        a = yield from e
        yield from f
    """

# Generated at 2022-06-23 23:25:57.611435
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    c = YieldFromTransformer()


# Generated at 2022-06-23 23:26:08.238599
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import compile
    from aiida_verdi.utils.aiidadb import ensure_aiida_dbenv
    ensure_aiida_dbenv()
    from aiida.orm import CalculationNode
    from typing_extensions import Final
    from ..code_additions import CodeAdditions

    class Foo(CalculationNode):
        _process_class = Final  # type: ignore
        def process(self, a: int) -> int:
            yield from self.inputs.b # type: ignore
            yield from self.inputs.c # type: ignore
            yield self.inputs.d
            return self.inputs.e

    code = compile(Foo, CodeAdditions())

# Generated at 2022-06-23 23:26:09.281495
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass #TODO


# Generated at 2022-06-23 23:26:15.040361
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """if True: yield from test"""
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    assert code.strip() == ast.dump(tree).strip()

    code = """while True: yield from test"""
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    assert code.strip() == ast.dump(tree).strip()

    code = """for i in range(10): yield from test"""
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    assert code.strip() == ast.dump(tree).strip()

    code = """def test(): yield from test"""
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:26:25.273727
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .unwrap import UnwrapTransformer
    from .goto import GotoTransformer
    from .visitor import NodeVisitHelper, NodeVisitorHelper
    from ..utils.helpers import VariablesGenerator

    variables_generator = VariablesGenerator('var')
    visitor = UnwrapTransformer(variables_generator)
    visitor = GotoTransformer(visitor, variables_generator)
    visitor = YieldFromTransformer(visitor)
    visitor = NodeVisitHelper(visitor)

    def global_test(test):
        nonlocal visitor
        visitor.nonlocal_parent = None
        test = visitor.visit(test)
        visitor = visitor.visitor
        return test

    def test(text, expected):
        nonlocal variables_generator, visitor

# Generated at 2022-06-23 23:26:26.608986
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    i = YieldFromTransformer()
    assert i.target == (3, 2)

# Generated at 2022-06-23 23:26:32.766424
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ast_helpers import parse_ast

    def should_match(snippet):
        node = parse_ast(snippet)
        YieldFromTransformer().visit(node)
        print(astor.to_source(node))

    # Should handle assignments
    snippet = """
        y = yield from [1, 2, 3]
    """
    should_match(snippet)

    # Should handle expressions
    snippet = """
        yield from generator
    """
    should_match(snippet)

# Generated at 2022-06-23 23:26:40.118071
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    src = """
        try:
            yield from []
        except StopIteration as exc:
            print(exc.value)
    """

    expected = """
        exc = None
        iterable = iter(iterable)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, "value"):
                    exc = exc.value
                break

        print(exc)
    """

    module = ast.parse(src)
    YieldFromTransformer().visit(module)
    assert ast.dump(module) == expected

# Generated at 2022-06-23 23:26:44.639364
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..base import BaseCodeGenerator
    code = "a = yield from b"
    node = BaseCodeGenerator._get_ast(code)

    transformer = YieldFromTransformer()
    transformer.visit(node)
    assert isinstance(node, ast.Module)
    assert astor.to_source(node) == "a = yield from b"

# Generated at 2022-06-23 23:26:54.813052
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    from .helpers import get_ast

    original = """def foo():
    yield from bar() + 1
    yield from bar()
    bar()
    yield from bar()
    yield from bar()
    yield from bar()
    yield from bar()
    yield from bar()"""


# Generated at 2022-06-23 23:26:55.781087
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()


# Generated at 2022-06-23 23:26:56.680540
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys

# Generated at 2022-06-23 23:27:03.671809
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import convert
    from ..ast_converters import ast_to_source
    py_code = ("foo = yield from bar",
               "",
               "def fun():",
               "    yield from 'abc'")
    py_ast = tuple(map(convert, py_code))

    kwargs = {"target": (3, 2)}
    yield assert_equal, ast_to_source(YieldFromTransformer(**kwargs).visit(py_ast[0])), \
        ("let(iterable)",
         "iterable = iter(bar)",
         "while True:",
         "    try:",
         "        foo = next(iterable)",
         "    except StopIteration as exc:",
         "        break")

# Generated at 2022-06-23 23:27:09.345463
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..conftest import to_source
    from ..compiler_data import generate_code

    ast_module = generate_code('def foo(): yield from [1, 2, 3]').tree
    YieldFromTransformer().visit(ast_module)
    new_source = to_source(ast_module).strip()

# Generated at 2022-06-23 23:27:14.720368
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse as ast_parse
    from ..utils import unparse

    tree = ast_parse('a = yield from generator')
    YieldFromTransformer().visit(tree)
    expected = """\
exc = None
iterable = iter(generator)
while True:
    try:
        next(iterable)
    except StopIteration as exc:
        a = exc.value
        break
"""
    assert unparse(tree) == expected

# Generated at 2022-06-23 23:27:26.156968
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse
    import astor

    class Mock(YieldFromTransformer):
        def generic_visit(self, node: ast.AST) -> ast.AST:
            return node

    tree = parse("def func(): yield from [1]")
    expected = parse("""def func(): 
    let(iterable)
    iterable = iter([1])
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                None = exc.value
            break
""")
    Mock().visit(tree)
    assert astor.to_source(tree) == astor.to_source(expected)


# Generated at 2022-06-23 23:27:31.237852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Unit test for constructor of class YieldFromTransformer
    '''
    #case 1: target = (3, 2)
    # expected output: target = (3, 2)
    assert YieldFromTransformer((3, 2)).target == (3, 2)


# Generated at 2022-06-23 23:27:32.890907
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ast import parse


# Generated at 2022-06-23 23:27:38.375097
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    'It tests the constructor of YieldFromTransformer'
    from .base import NodeTransformer

    # Is YieldFromTransformer a subclass of NodeTransformer?
    assert issubclass(YieldFromTransformer, NodeTransformer)

# tests:
# def test_YieldFromTransformer1():
#     'It tests the _get_yield_from_index'
#     from .base import NodeTransformer
#     node = YieldFromTransformer()
#     assert node._get_yield_from_index() is not None

# def test_YieldFromTransformer2():
#     'It tests the _emulate_yield_from'
#     from .base import NodeTransformer
#     node = YieldFromTransformer()
#     assert node._emulate_yield_from() is not None

# def

# Generated at 2022-06-23 23:27:48.860586
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helper_trees import print_tree
    import tempfile
    import os
    with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
        f.write("""
            def f():
                a = yield_from(foo())
                b = yield_from(foo())
                yield from foo()
                yield_from(123)
        """.encode());
    filename = f.name

# Generated at 2022-06-23 23:27:49.762931
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
   
    assert isinstance( YieldFromTransformer(), YieldFromTransformer )


# Generated at 2022-06-23 23:27:56.283959
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import Source
    source = Source("""
    def function1():
        flag = True
        while flag:
            flag = False
            yield from function2()
    def function2():
        yield from function3()
    def function3():
        yield from function4()
    def function4():
        yield from range(10)
    """)
    tree = source.tree
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    source.pprint()

# Generated at 2022-06-23 23:27:58.610830
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """
    Unit test for method visit of class YieldFromTransformer
    """
    # This test case MUST NOT raise any exception

# Generated at 2022-06-23 23:28:05.330898
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

    y = YieldFromTransformer(assert_tree_changed=True)
    method = y.generate_method_body(['yield_from'])

    code = '''
    yield from x
    '''
    body = ast.parse(code).body

    tree = ast.fix_missing_locations(method(body))
    assert ast.dump(tree) == \
'''
while True:
    try:
        yield next(iter(x))
    except StopIteration as exc:
        exc = exc.value
        break
'''

# Generated at 2022-06-23 23:28:06.310231
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:28:08.476086
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from ..utils.helpers import render_code
    from ..utils.codegen import CodeGenerator, DummyCodeGenerator


# Generated at 2022-06-23 23:28:17.840681
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from astor import codegen
    original_code = '''
    def generator():
        yield from 1
        yield from 2
        a = yield from 3
        b = 'eea'
        yield from 4
    '''


# Generated at 2022-06-23 23:28:26.539712
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode
    source = source_to_unicode("""
        def test():
            result = yield from generator
    """)
    expected = source_to_unicode("""
        def test():
            let(exc)
            iterable = iter(generator)
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        result = exc.value
                    break
    """)
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 23:28:34.748181
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    source = """
    def func():
        yield fomr (x for x in range(10))
        yield from (x for x in range(10))
        yield from (x for x in range(10))

        a = yield from (x for x in range(10))
        a = yield from (x for x in range(10))
    """

# Generated at 2022-06-23 23:28:36.071113
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_tree import tree


# Generated at 2022-06-23 23:28:38.963020
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    __tracebackhide__ = True
    from ..utils.examples import EXAMPLES
    from ..utils.testing import run_tests
    run_tests(YieldFromTransformer, EXAMPLES['yield_from'])

# Generated at 2022-06-23 23:28:40.290746
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        YieldFromTransformer(1)

# Generated at 2022-06-23 23:28:41.213138
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-23 23:28:42.738629
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test_utils import assert_node


# Generated at 2022-06-23 23:28:45.509228
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import test_utils
    test_utils.assert_constructor(YieldFromTransformer, [])


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 23:28:54.608275
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("def f():\n  a = yield from (1)")
    tr = YieldFromTransformer()
    tr.visit(node)
    assert ast.dump(node) == "Module(body=[FunctionDef(name='f', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='iter', ctx=Load()), args=[Tuple(elts=[Num(n=1)], ctx=Load())], keywords=[]))], decorator_list=[], returns=None)])"

# Generated at 2022-06-23 23:28:59.764970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import MockContext
    from .base import MockModule

    node = ast.parse('def f():\n    a = yield from b\n')
    transpiled_module = MockModule(MockContext())
    transformer = YieldFromTransformer(transpiled_module)
    transformer.visit(node)
    transpiled_module.verify()

# Generated at 2022-06-23 23:29:07.366477
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    original_node = ast.parse("a = yield from b")
    transformer = YieldFromTransformer()
    transformed_node = transformer.visit(original_node)

# Generated at 2022-06-23 23:29:08.420892
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-23 23:29:09.775061
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')
    YieldFromTransformer()

# Generated at 2022-06-23 23:29:21.464300
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # unit test to check if node has YieldFrom instruction
    obj = YieldFromTransformer()
    node = ast.Module([])
    # expression with YieldFrom
    expr = ast.Expr(value=ast.YieldFrom(value=ast.Num(5)))
    node.body.append(expr)
    # assignment with YieldFrom
    assign = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], 
                        value=ast.YieldFrom(value=ast.Num(5)))
    node.body.append(assign)
    # expression without YieldFrom
    expr = ast.Expr(value=ast.Num(5))
    node.body.append(expr)
    # assignment without YieldFrom

# Generated at 2022-06-23 23:29:29.902812
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:40.895931
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.tstutils import run_transformer_test
    from .. import ast_converter

    def test_transformer(node, input_code, expected_code, *,
                         non_pythonic=False):
        return run_transformer_test(ast_converter, node,
                                    YieldFromTransformer,
                                    input_code, expected_code,
                                    non_pythonic=non_pythonic)

    def visit_test(input_code, expected_code):
        return test_transformer(ast.Expr, input_code, expected_code)

    def test_yield_from_expr(input_code, expected_code):
        return visit_test(input_code, expected_code)


# Generated at 2022-06-23 23:29:51.097958
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # TODO: change to test_transformer_unit_test
    code_str = """
    def func(gen):
        yield from gen
        a = yield from gen
        yield from gen + 1
        yield from gen.a
        yield from type(gen)
    """

# Generated at 2022-06-23 23:29:59.600403
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:06.868830
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse("a = yield from [1, 2, 3]")
    expected_node = ast.parse("""
        def foo():
            let(iterable)
            iterable = iter([1, 2, 3])
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        a = exc.value
    """)
    tr = YieldFromTransformer()
    assert tr.visit(node) == expected_node

# Generated at 2022-06-23 23:30:07.953550
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:18.278948
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast

    def _test(target, yield_from, expected):
        # type: (ast.AST, ast.YieldFrom, ast.AST) -> None
        if not isinstance(yield_from, ast.YieldFrom):
            raise ValueError('yield_from value must be instance of ast.YieldFrom')

        # pylint: disable=protected-access
        actual = YieldFromTransformer()._emulate_yield_from(target, yield_from)
        assert actual == expected

    class Generator(object):
        def __iter__(self):
            yield 1
            yield 2


# Generated at 2022-06-23 23:30:25.961255
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse

    class MockModule(object):
        def __init__(self, node: ast.AST):
            self.node = node
            self._changed = False

        def wrap(self):
            return self.node

        def __setitem__(self, key: str, value: bool):
            self._changed = value

        def __getitem__(self, key: str) -> bool:
            return self._changed


    class MockContext(object):
        def __init__(self, module: MockModule):
            self.tree = module
            self._tree_changed = False

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            self.tree['changed'] = self._tree_changed



# Generated at 2022-06-23 23:30:30.579741
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3
    from .. import Compiler
    from .test_helpers import get_compiled_result
    compiler = Compiler()


# Generated at 2022-06-23 23:30:32.204860
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer.get_name()
    assert result == 'YieldFromTransformer'

# Generated at 2022-06-23 23:30:40.099941
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # Arguments of @snippet decorator.
    # name -> Result of @snippet decorator.
    # body -> Original function.

    from astunparse import unparse
    from astpretty import pprint
    from ..utils.helpers import dump_tree, load_tree
    from ..utils.tree import node_eq

    example_py_code = """
    def func1(start, stop, step):
        for i in range(start, stop, step):
            yield from func2()

        yield from range(1)
    """

    parsed_code = load_tree(example_py_code)
    YieldFromTransformer().visit(parsed_code)

# Generated at 2022-06-23 23:30:50.833964
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import unittest
    import ast as python_ast

    from ..utils.helpers import refresh_code_location

    class TestYieldFromTransformerVisitor(unittest.TestCase):
        def test_visit_yield_from_with_assignment(self):
            tree = python_ast.parse("a = yield from [1]")
            transformer = YieldFromTransformer()
            transformer.visit(tree)

            expected_tree = python_ast.parse("""
exc = None
a = None
iterable = iter([1])
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        a = exc.value
        break
            """)
            refresh_code_location(expected_tree)
            self.assertEqual(expected_tree, tree)


# Generated at 2022-06-23 23:30:59.786209
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    #
    src = textwrap.dedent('''
    def func(gen):
        foo = yield from gen
    ''')
    node = ast.parse(src)
    #
    YieldFromTransformer.run_visitor(node)
    #
    expected = textwrap.dedent('''
    def func(gen):
        foo = None
        exc = _0
        iterable = None
        iterable = iter(gen)
        while True:
            try:
                foo = next(iterable)
            except StopIteration as exc:
                foo = exc.value
                break
    ''')
    result = astunparse.unparse(node)
    assert result == expected

# Generated at 2022-06-23 23:31:07.760888
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import os
    import sys
    import astor
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_statements import test_yield_from_1
    from test_statements import test_yield_from_2
    from test_statements import test_yield_from_3
    from test_statements import test_yield_from_4
    from test_statements import test_yield_from_5
    from test_statements import test_yield_from_6
    from test_statements import test_yield_from_7
    from test_statements import test_yield_from_8
    from test_statements import test_yield_from_9
