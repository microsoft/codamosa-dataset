

# Generated at 2022-06-23 23:21:08.141878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        ast.parse('def a(b): x = yield from c')
    except SyntaxError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 23:21:15.812560
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.fake_module import FakeModule

    tree: ast.AST = FakeModule(
        'def f():\n'
        '    yield from g()'
    )
    result = YieldFromTransformer().run(tree)
    assert result == FakeModule(
        "def f():\n"
        "\titerable = iter(g())\n"
        "\twhile True:\n"
        "\t\ttry:\n"
        "\t\t\t_ = next(iterable)\n"
        "\t\t\tyield _\n"
        "\t\texcept StopIteration as exc:\n"
        "\t\t\tbreak"
    )


# Generated at 2022-06-23 23:21:16.559950
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer()) == YieldFromTransformer



# Generated at 2022-06-23 23:21:17.784802
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tnf = YieldFromTransformer()
    assert isinstance(tnf, YieldFromTransformer)


# Generated at 2022-06-23 23:21:19.018263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__.__name__ == "YieldFromTransformer"

# Generated at 2022-06-23 23:21:19.973989
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'

# Generated at 2022-06-23 23:21:20.787410
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:21:22.563107
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_ast as a

# Generated at 2022-06-23 23:21:25.796764
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.target == (3, 2)
    x = YieldFromTransformer()
    assert isinstance(x, BaseNodeTransformer)


# Generated at 2022-06-23 23:21:26.654152
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    v = YieldFromTransformer()


# Generated at 2022-06-23 23:21:27.828222
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    transformer = YieldFromTransformer()
    assert transformer


# Generated at 2022-06-23 23:21:37.265170
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import source_to_ast
    from ..utils.helpers import compare_asts
    from ..utils.snippet import get_source

    tree = source_to_ast('''\
        def test():
            result = yield from test()
    ''')

    transformed = source_to_ast('''\
        def test():
            let(iterable)
            let(exc)
            iterable = iter(test())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        result = exc.value
                    break
    ''')

    YieldFromTransformer().visit(tree)
    assert compare_asts(tree, transformed)



# Generated at 2022-06-23 23:21:46.015608
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3
    except ImportError:
        return  # typed_ast isn't installed
    from unittest import TestCase
    from zuper_typing.annotations_tricks import get_type_hints
    from inspect import signature
    from astor.ast_to_source import to_source
    import astunparse
    import astor
    from zuper_nodes.transformers.yield_from import YieldFromTransformer

    # class TestYieldFromTransformer(TestCase):
    #     def test_1(self):
    #         source = """
    #         def f(x):
    #             a = yield from g(x)
    #         """
    #         tree = ast3.parse(source)
    #         y = YieldFromTransformer()
    #

# Generated at 2022-06-23 23:21:47.002983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:21:54.897585
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.test import generate_test_code, transform, assert_transformation

    yield_from_code = generate_test_code(
        "yield from some_expression",
        settings={'target': (3, 2)}
    )
    arg_assign = generate_test_code(
        "some_value = yield from some_expression",
        settings={'target': (3, 2)}
    )
    yield_from_assign_code = generate_test_code(
        "yield from some_expression",
        settings={'target': (3, 2)}
    )


# Generated at 2022-06-23 23:22:04.722879
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import eval_code, get_ast_from_function
    from ..utils.tree import ast_to_code
    
    # Check compilation of single 'yield from' in function.
    def test_function():
        yield from range(10)
    ast_ = get_ast_from_function(test_function)
    YieldFromTransformer().visit(ast_)
    assert eval_code(ast_to_code(ast_)) == list(range(10))

    # Check compilation of single 'yield from' in generator.
    def test_generator():
        yield from range(10)
    ast_ = get_ast_from_function(test_generator, True)
    YieldFromTransformer().visit(ast_)
    assert eval_code(ast_to_code(ast_))

# Generated at 2022-06-23 23:22:15.086137
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseTransformerTestCase
    from .base import TransformerVisitor
    from .base import PyVersionMixin
    from .base import setUp
    from .base import tearDown

    # Unit test for constructor of class YieldFromTransformer
    class TestYieldFromTransformer(BaseTransformerTestCase, PyVersionMixin):

        # Unit test for visit_Expr
        def test_visit_Expr(self):
            tree = ast.parse("""foo()""")

            class TestTransformer(TransformerVisitor):
                @staticmethod
                def visit_Expr(node: ast.Expr) -> ast.AST:
                    return node

            TestTransformer.visit(tree)

        # Unit test for visit_Module

# Generated at 2022-06-23 23:22:19.881295
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import parse
    import astor

    module = parse('def test():\n    yield from (1, 2, 3)\n')
    expected = 'def test():\n    _exc = None\n    _iterable = iter((1, 2, 3))\n    while True:\n        try:\n            yield next(_iterable)\n        except StopIteration as _exc:\n            if hasattr(_exc, \'value\'):\n                _exc = _exc.value\n                break\n'

    transformer = YieldFromTransformer()
    result = transformer.visit(module)

    assert astor.to_source(result) == expected

# Generated at 2022-06-23 23:22:29.930993
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .util import generate_derived_class
    from .util import run_transformer_class
    from .util import compare_ast
    from .util import compare_source

    tree = generate_derived_class(
        '''
        def __init__(self):
            self.x = 'test'
        def __add__(self, other):
            self.x = yield from other
        '''
    )
    transformer = run_transformer_class(
        YieldFromTransformer, tree
    )

# Generated at 2022-06-23 23:22:38.271506
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def for_test(a, b):
        c = yield from a
        g = yield from b

    t = ast.parse(for_test.__code__)
    YieldFromTransformer.visit(t.body[0])

# Generated at 2022-06-23 23:22:48.196899
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..transpile import TranspileVisitor
    from ..tree import TransformError
    from ..tests.testing_utils import get_node

    code = '''
    def f(x):
        y = yield from x
        z = yield from x
    '''


# Generated at 2022-06-23 23:22:55.320713
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from .tests.utils import roundtrip
    from .tests.transformer_test_case import TransformerTestCase

    class Test(TransformerTestCase):
        transformer = YieldFromTransformer
        methodName = 'visit_FunctionDef'
        target = (3, 2)


# Generated at 2022-06-23 23:23:02.371636
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.fixtures import yield_from  # noqa: F401
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import assert_source
    from ..utils.helpers import compile_snippet

    scope = {
        'x': 1,
        'generator': (n for n in range(2))
    }

    tr_tree = compile_snippet(YieldFromTransformer, 'test_YieldFromTransformer_visit', scope)
    nm = NodeVisitor()
    nm.visit(tr_tree)


# Generated at 2022-06-23 23:23:12.347737
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class test_YieldFromTransformer_visit:
        def test_new_YieldFromTransformer_object(self):
            t = YieldFromTransformer()
            assert t is not None

        @pytest.mark.parametrize(
            'tree', [pytest.param(
                ast.parse('def gen():\n    yield from [0, 1, 2]'),
                id='yield-from-in-def'),
                pytest.param(
                    ast.parse(
                        '''def gen():
                yield from [0, 1, 2]
                print(42)'''),
                    id='yield-from-in-def-with-other-statement')])
        def test_visit(self, tree):
            tree = YieldFromTransformer().visit(tree)

            assert tree is not None

# Generated at 2022-06-23 23:23:21.571603
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..architects import Compiler
    from ..serializer import CompilerStates
    import os
    
    # Testing snippet
    snippet_ = "def method(): yield from 5"
    # Snippet will be compiled and serialized, then another compiler will be created from the last serialized state.
    # Finally outputs of both compilers will be compared.
    try:
        os.remove("state.json")
    except:
        None

    compiler = Compiler(snippet_)
    compiler.compile()
    compiler.serialize("state.json")
    
    compiler1 = Compiler(snippet_)
    compiler1.compile()
    compiler1.serialize("state1.json")
    assert CompilerStates("state.json") == CompilerStates("state1.json")


# Generated at 2022-06-23 23:23:27.005308
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse('''
    def foo():
        a = yield from bar()
    ''')
    assert YieldFromTransformer().visit(tree) == ast.parse('''
    def foo():
        exc = VariablesGenerator.generate('exc')
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    ''')

# Generated at 2022-06-23 23:23:29.228225
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing import assert_text_transforms_to


# Generated at 2022-06-23 23:23:30.426950
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:23:40.377490
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..compile import compile_string, compile_file
    from ..utils.helpers import get_node_fields
    from ..utils.compat import parse, check_ast
    from ..utils.astcompare import equal_asts

    snippet_ = 'def f():\n    yield from a'
    node = parse(snippet_, mode='exec')
    check_ast(node, is_valid_ast=True)

    _t = YieldFromTransformer()
    node = _t.visit(node) # type: ignore
    check_ast(node, is_valid_ast=True)

    snippet_ = 'def f():\n    a = yield from b'
    node = parse(snippet_, mode='exec')
    check_ast(node, is_valid_ast=True)

    _t = Y

# Generated at 2022-06-23 23:23:48.123623
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .unpacking import UnpackingTransformer
    from .generators import GeneratorTransformer
    from .context_managers import ContextManagerTransformer

    example_code = open(__file__.replace('.py', '.txt')).read()
    tree = ast.parse(example_code)
    tree = GeneratorTransformer().visit(tree)
    tree = ContextManagerTransformer().visit(tree)
    tree = UnpackingTransformer().visit(tree)
    tree = YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:23:59.646984
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import get_ast
    from ..transformers import YieldFromTransformer
    from ..utils.helpers import Filter
    from ..utils.helpers import NodeSearch
    Node = ast.AST
    source = """
    def foo():
        yield from (1, 2, 3)
    """
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    result = Filter(Filter(NodeSearch(tree).search(ast.While)).search(ast.Yield))[0].value
    assert result.args[1].ctx == ast.Load

# Generated at 2022-06-23 23:24:02.600008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    node: ast.AST = ast.parse('yield from 42')
    t.visit(node)
    assert(t._tree_changed)

# Generated at 2022-06-23 23:24:03.050700
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:24:03.778916
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:24:10.687560
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils import cst_to_ast

    cst = """
    def foo():
        a = yield from bar()
    """
    expected = """
    def foo():
        let(exc)
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    """

    ast_ = cst_to_ast(cst)
    ast_.body[0].body[0].value = YieldFromTransformer().visit(ast_.body[0].body[0].value)  # type: ignore
    assert expected == astor.to_source(ast_).strip()

# Generated at 2022-06-23 23:24:21.475194
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..testing_utils import assert_transformation

    ret_value = ast.parse("""
    def foo(bar):
        yield from bar
    """)
    ret_value_result = ast.parse("""
    def foo(bar):
        exc = (0).__class__()
        iterable = iter(bar)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                pass
            break
    """)
    assert_transformation(YieldFromTransformer, ret_value, ret_value_result)

    assign_value = ast.parse("""
    def foo(bar):
        var = yield from bar
    """)

# Generated at 2022-06-23 23:24:29.756402
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import MockModule
    from ..compile_snippets import compile_snippet, compile_all_snippets

    mod = MockModule('yield from')
    stmts = [mod.parse_snippet('yield from s')]

    print('yield from')
    print(compile_snippet(stmts, version=(3, 2)))
    print()

    mod = MockModule('yield from with result assignment')
    stmts = [mod.parse_snippet('a = yield from [1]')]

    print('yield from with result assignment')
    print(compile_snippet(stmts, version=(3, 2)))
    print()

    mod = MockModule('yield from in method')

# Generated at 2022-06-23 23:24:39.512223
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:40.441610
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:24:41.393759
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-23 23:24:43.031221
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(None)

# Unit tests for visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:44.578040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a = YieldFromTransformer()
    except:
        assert False



# Generated at 2022-06-23 23:24:51.414534
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_python.compiler.type_wrappers.wrapper import Wrapper
    from typed_python.compiler.type_wrappers.bound_method_wrapper import BoundMethodWrapper
    from typed_python.compiler.type_wrappers.refcounted_list_of_wrappers import RefcountedListOfWrappers
    from typed_python.compiler.python_ast_util import py_ast_to_string
    from typed_python.compiler.type_wrappers.compiled_method_wrapper import CompiledMethodWrapper
    from typed_python.compiler.type_wrappers.wrapper import Wrapper
    from typed_python.compiler.type_wrappers.bound_method_wrapper import BoundMethodWrapper
    from typed_python.compiler.type_wrappers.refcounted_list_of_wrappers import Refcounted

# Generated at 2022-06-23 23:24:52.945657
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:24:54.245277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # It should create an object when called
    try:
        YieldFromTransformer()
    except TypeError:
        assert False

# Generated at 2022-06-23 23:25:02.563516
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import YieldFrom, FunctionDef, Load
    from astor.codegen import to_source
    from .test_base import NodeTestCase

    class Test(NodeTestCase):
        target = YieldFromTransformer

        def test_simple(self):
            def run(node):
                node = node.body[0]
                self.check(node,
                           """
yield_from:
    iterable = iter(a)
    while True:
        exc = None
        try:
            yield next(iterable)
        except StopIteration as exc:
            pass
""")

            tree = FunctionDef(name='bar',
                               body=[YieldFrom(value=Load())])
            run(tree)

    return Test



# Generated at 2022-06-23 23:25:11.076679
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse

    code = """
        def foo():
            bar = yield from range(100)
            print(bar)
        """

    expected = """
        def foo():
            iterable = iter(range(100))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        bar = exc.value
                    break
            print(bar)
        """
    node = ast.parse(code)
    node = YieldFromTransformer().visit(node)
    result = astunparse.unparse(node)
    assert result == expected

# Generated at 2022-06-23 23:25:13.658928
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.ast_dump import ast_dump
    from .test_helpers import assert_code_equal

    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:25:14.451451
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:25:21.550363
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test YieldFromTransformer._get_yield_from_index
    x = YieldFromTransformer()
    assert x._get_yield_from_index(ast.Expr(value = ast.Num(n = 1)), ast.Assign) == None
    assert x._get_yield_from_index(ast.Expr(value = ast.Num(n = 1)), ast.Expr) == 0
    assert x._get_yield_from_index(ast.FunctionDef(name = "x", body = [ast.Expr(value = ast.Num(n = 1))]), ast.Expr) == 0

# Generated at 2022-06-23 23:25:23.106917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:30.710204
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("def function():\n    yield from range(0)")
    transformer = YieldFromTransformer()
    node = transformer.visit(node)
    assert transformer.get_source() == 'def function():\n    def result_assignment(exc):\n        if hasattr(exc, \'value\'):\n            target = exc.value\n    let(iterable)\n    iterable = iter(range(0))\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            extend(result_assignment(exc))\n            break\n'


# Generated at 2022-06-23 23:25:32.421339
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_name = YieldFromTransformer.__name__
    assert class_name == "YieldFromTransformer"
    assert YieldFromTransformer.target == (3, 2)
    YieldFromTransformer()

# Generated at 2022-06-23 23:25:35.193255
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from testing.utils import check_transformer
    check_transformer(YieldFromTransformer, YieldFromTransformer.target, 'target')


# Generated at 2022-06-23 23:25:43.010642
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
a = yield from p
"""
    result = """
let(iterable)
iterable = iter(p)
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break
"""
    from .utils import do_test
    do_test(code, result, target=(3, 2), transformer=YieldFromTransformer)



# Generated at 2022-06-23 23:25:51.697723
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import ast3 as ast

    code = '''
    import os
    import sys
    import typing
    foo = 3
    y = yield from []
    z = yield from os.path.dirname('foo')
    '''.strip()

    tree = ast.parse(code)

    transformed = YieldFromTransformer().visit(tree)


# Generated at 2022-06-23 23:25:57.608056
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast import YieldFrom
    import astor

    code = """
    def foo(bar):
        x = bar
        y = bar
        yield from x  # comment
        yield from y
        yield_from(x)
    """
    tree = ast.parse(code)
    visitor = YieldFromTransformer()
    visitor.visit(tree)
    expected_code = """
    def foo(bar):
        x = bar
        y = bar
        while True:
            try:
                yield next(iter(x))
            except StopIteration as _exc:
                break
        while True:
            try:
                yield next(iter(y))
            except StopIteration as _exc:
                break
        yield_from(x)
    """

# Generated at 2022-06-23 23:26:08.280236
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import textwrap
    from typed_astunparse import unparse
    from .remove_asserts import RemoveAssertsTransformer

    # Simple yield from.
    source = textwrap.dedent('''\
        def foo():
            while True:
                yield from bar()
    ''')
    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    expected = textwrap.dedent('''\
        def foo():
            while True:
                let (iterable)
                iterable = iter(bar())
                while True:
                    try:
                        yield next(iterable)
                    except StopIteration as exc:
                        break
    ''')
    result = unparse(tree)
    assert result == expected

    # Yield from inside try-

# Generated at 2022-06-23 23:26:18.187430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from kyu.compiler import Compiler
    from kyu.parser import parse  # type: ignore

    source = """
    def func(x: int) -> int:
        yield from [x*x, x+x]
        return x
    """
    tree = parse(source)
    assert isinstance(tree, ast.AST)
    tree = YieldFromTransformer().visit(tree)
    output = Compiler().visit(tree)
    assert output == '''
    def func(x):
        iterable = iter([x*x, x+x])
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
        return x
    '''

# Generated at 2022-06-23 23:26:21.519618
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseTreeTransformer
    from ..utils.helpers import get_node
    from ..utils.tree import compare_trees, NodeNotFound


# Generated at 2022-06-23 23:26:30.629563
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def a():
        yield from 1
        yield from 2
        yield from 3
    """
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    assert str(tree) == """
    def a():
        exc = None
        iterable = iter(1)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
        exc = None
        iterable = iter(2)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
        exc = None
        iterable = iter(3)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """

#

# Generated at 2022-06-23 23:26:32.241625
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  x = "test"
  temp = YieldFromTransformer()
  assert (True)


# Generated at 2022-06-23 23:26:33.866276
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer(1)
    assert tr.target == (3, 2)

# Generated at 2022-06-23 23:26:35.020089
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-23 23:26:36.240292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer()) == YieldFromTransformer

# Generated at 2022-06-23 23:26:42.686832
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from typed_ast.ast3 import parse
    from ..tree_compiler import TreeCompiler

    tree_compiler = TreeCompiler()
    code = 'a = yield from foo'
    node = parse(code)
    assert node.body[0].value.__class__.__name__ == 'YieldFrom'
    node = YieldFromTransformer().visit(node)
    assert node.body[0].__class__.__name__ == 'While'

# Generated at 2022-06-23 23:26:52.671013
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    import typing

    if sys.version_info >= (3, 7):
        from .test_generic import run_transformer_test
    else:
        from .test_generic import run_transformer_test_fallback as run_transformer_test

    transformer = YieldFromTransformer
    function_transformer = transformer()
    module_transformer = transformer()

    # test module
    source = '''
        y = yield from f()
        y = yield from f()
        y = yield from f()
        y = yield from g()
        y = yield from f()
    '''

# Generated at 2022-06-23 23:27:01.355325
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    # Make sure it refers to current version of ast module
    import inspect
    assert inspect.getsourcefile(ast.YieldFrom) == __file__, "astrondb depends on local version of typed-ast"

    # Test YieldFromTransformer.visit
    import astrondb.ast_helpers
    node = ast.parse("def foo(a):\n"
                     "    b = yield from a\n"
                     "    return b")
    tree = node
    assert astrondb.ast_helpers.to_source(tree) == "def foo(a):\n"\
                                                   "    b = yield from a\n"\
                                                   "    return b"
    transformer = YieldFromTransformer()
    # Method _handle_expressions

# Generated at 2022-06-23 23:27:06.880640
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    cls = YieldFromTransformer()
    assert hasattr(cls, 'target')
    assert hasattr(cls, '_tree_changed')
    assert hasattr(cls, '_emulate_yield_from')
    assert hasattr(cls, '_handle_assignments')
    assert hasattr(cls, '_handle_expressions')
    assert hasattr(cls, 'visit')

# Generated at 2022-06-23 23:27:08.406147
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..lark_utils import make_tree


# Generated at 2022-06-23 23:27:16.934754
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse

    @snippet
    def test_snippet(n):
        def inner_func():
            yield from iter(range(n))
        return inner_func

    func_src = test_snippet.get_src()
    func_ast = ast.parse(func_src)
    func_ast = YieldFromTransformer().visit(func_ast)
    ast.fix_missing_locations(func_ast)
    func_src = astunparse.unparse(func_ast)

    @snippet
    def expected_src(n):
        def inner_func():
            iterable = iter(range(n))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break

        return inner_func

    assert func_

# Generated at 2022-06-23 23:27:24.187794
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source
    from ..utils.helpers import run_transformer_on_single_file

    source = Source("""
        def foo():
            a = yield from bar()
            yield from bar()
            b = yield from bar()
    """)

    for target in [(3, 2), (3, 3)]:
        source = source.copy()
        tree = run_transformer_on_single_file(source, YieldFromTransformer(), target)
        assert tree is not None

# Generated at 2022-06-23 23:27:25.778388
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer

# Generated at 2022-06-23 23:27:37.184570
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .. import parse
    from .helpers import get_tree_diff
    sample = '''
        def function(x):
            a = yield from x
    '''
    expected = '''
        def function(x):
            var_1 = iter(x)
            while True:
                try:
                    yield next(var_1)
                except StopIteration as var_0:
                    a = var_0.value
                    break
    '''

    sample = parse(sample)
    expected = parse(expected)
    transformer = YieldFromTransformer()
    sample = transformer.visit(sample)
    diff = get_tree_diff(sample, expected)
    print([error.message for error in diff])
    assert not diff, 'Please check the errors'



# Generated at 2022-06-23 23:27:41.681591
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    def test(expected, code, **kws):
        node = ast.parse(code)
        YieldFromTransformer(**kws).visit(node)
        actual = ast.unparse(node)
        assert expected == actual, f'Failed:\n{code}\nExpected:\n{expected}\nActual:\n{actual}'


# Generated at 2022-06-23 23:27:51.891725
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from .test_unpack import UnpackTransformer
    from .test_print import PrintTransformer
    from .test_assignment import AssignmentTransformer
    from .test_augmented_assignment import AugmentedAssignmentTransformer
    from .test_branch import BranchTransformer
    from .test_control_flow import ControlFlowTransformer
    from .test_loops import LoopsTransformer

    t = UnpackTransformer()
    t = PrintTransformer()
    t = AssignmentTransformer()
    t = AugmentedAssignmentTransformer()
    t = BranchTransformer()
    t = ControlFlowTransformer()
    t = LoopsTransformer()
    t = YieldFromTransformer()
    node = ast.parse('yield from a')
    node2 = t.visit(node)

# Generated at 2022-06-23 23:27:58.468543
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    code = """
    def f():
        yield from range(10)
    """
    tr = YieldFromTransformer()
    mod = ast.parse(code)
    new_mod = tr.visit(mod)
    compiled = compile(new_mod, '<test>', 'exec')
    ns = {}
    exec(compiled, ns)
    lst = []
    for i in ns['f']():
        lst += [i]
    assert lst == list(range(10))


# Generated at 2022-06-23 23:28:00.082504
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from ..utils.codegen import code_to_ast
    

# Generated at 2022-06-23 23:28:01.316639
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:28:03.211203
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..backend import CodeBackend
    from ..utils.helpers import Parser
    from ..utils.tree import dump, load


# Generated at 2022-06-23 23:28:12.946067
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    __tracebackhide__ = True
    import pytest
    import astunparse

    def create(yield_from_node) -> ast.AST:
        return ast.parse(
            astunparse.unparse(ast.Module([
                ast.FunctionDef(
                    name='f',
                    args=ast.arguments(
                        args=[],
                        vararg=None,
                        kwonlyargs=[],
                        kw_defaults=[],
                        kwarg=None,
                        defaults=[]
                    ),
                    body=[
                        ast.Expr(yield_from_node)
                    ],
                    decorator_list=[],
                    returns=None,
                    type_comment=None
                )
            ])))

    def test(yield_from_node, expected):
        node = create(yield_from_node)

# Generated at 2022-06-23 23:28:22.306731
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    """Unit test for method _handle_expressions of class YieldFromTransformer"""
    from ..utils.source import source
    from ..utils.ast import get_ast
    from ..utils.compare_ast import compare_ast, wrap_and_convert

    tests = [
        'x = yield from y',
        'yield from x = y',
        'yield from y = x = y',
        'x = yield from y = x = y',
        'yield from 1 + 2',
        'print(1 + (yield from 2 + 1))',
        'yield from 1 + (yield from 2) + 1',
    ]

    for code in tests:
        module = wrap_and_convert(source(code))
        module = YieldFromTransformer().visit(module)
        result = get_ast

# Generated at 2022-06-23 23:28:24.936777
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    from ..utils.test_visitor import run_test
    from ..utils.test_node import TestNode

# Generated at 2022-06-23 23:28:29.528731
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = ast.parse("""
        def a():
            yield from b()
    """)
    YieldFromTransformer().visit(node)
    assert_equal("""
        def a():
            iterable = iter(b())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """, ast_to_snippet(node))



# Generated at 2022-06-23 23:28:34.989421
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    expected_result = 'while 1:\n    try:\n        pass\n    except StopIteration as exc:\n        my_var = exc.value\n'
    tree = ast.parse('my_var = yield from my_generator()')
    obj = YieldFromTransformer()
    obj.visit(tree)
    assert (expected_result == ast.unparse(tree))



# Generated at 2022-06-23 23:28:35.870149
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.source import Source
    transformer = YieldFromTransformer()

# Generated at 2022-06-23 23:28:43.986486
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    tree = ast.parse("""
a = yield from b
c = yield from d
(yield from e)
""")
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-23 23:28:52.434587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .._test_utils.test_ast import AstHelper
    from .._test_utils.visitor import NodeTransformer

    helper = AstHelper()
    code1 = '''
    a = 2
    y = yield from func(a, b)
    '''
    code2 = '''
    a = 2
    yield from func(a, b)
    '''
    code3 = '''
    if True:
        yield from func(a, b)
        yield
    '''

    tree1 = helper.parse_to_ast(code1)
    tree2 = helper.parse_to_ast(code2)
    tree3 = helper.parse_to_ast(code3)

    transformer = NodeTransformer()
    transformer.add_transformer(YieldFromTransformer())
    res1 = transformer.visit

# Generated at 2022-06-23 23:28:54.021756
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()


# Generated at 2022-06-23 23:29:03.635603
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test import test_transformer
    from inspect import cleandoc

    source = cleandoc('''
    def func():
        yield from generator
    ''')
    expected_source = cleandoc('''
    def func():
        exc = generate_variable_1
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break

    ''')
    test_transformer(YieldFromTransformer, source, expected_source, target=(3, 2))

    source = cleandoc('''
    def func():
        var = yield from generator
        var = yield from generator
        print(var)
    ''')

# Generated at 2022-06-23 23:29:04.701830
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	assert isinstance(YieldFromTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 23:29:06.420430
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..tests import transformation_cases
    transformation_cases('yieldfrom', YieldFromTransformer)



# Generated at 2022-06-23 23:29:18.132124
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ...tests import test_yield_from

    YieldFromTransformer.transform(test_yield_from)


# Generated at 2022-06-23 23:29:27.542810
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    x = 1
    y = 2
    z = 3

    tree = ast.parse(
        """
        def first():
            yield from second()
            while x:
                yield from second()

        def second():
            x = y
            yield from third()

        def third():
            yield from fourth()
            y = z

        def fourth():
            yield (1, 2)
        """, mode='exec')

    transformer = YieldFromTransformer()
    ast.fix_missing_locations(transformer.visit(tree))

    locals_ = locals()
    exec(compile(tree, __file__, 'exec'), globals(), locals_)

    assert list(locals_['first']()) == list(range(10))

# Generated at 2022-06-23 23:29:33.241771
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('\n'.join((
        'def fun():',
        '    yield from (1, 2, 3)',
        '')))
    trans = YieldFromTransformer()
    trans.visit(node)

# Generated at 2022-06-23 23:29:43.800304
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

    # Test case 1. Emulating yield from without assignment
    sample_source = """
    function_def = ast.parse("def foo():\n    yield from bar").body[0]
    """
    expected = """
    def foo():
        let(iterable)
        iterable = iter(bar)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    sample_source = astor.to_source(ast.parse(sample_source))
    expected = astor.to_source(ast.parse(expected))
    
    t = YieldFromTransformer()
    result = t.visit(exec(sample_source))

    assert expected == astor.to_source(result)

    # Test case 2. Emulating yield from

# Generated at 2022-06-23 23:29:44.993468
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-23 23:29:55.030576
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astunparse
    import textwrap
    from typing import List
    from ..utils.helpers import random_string
    from ..utils.tree import extract_from_parent
    from .base import BaseTreeTransformer

    class TestTransformer(BaseTreeTransformer):
        def _set_tree_changed(self, node: ast.AST):
            pass

        def visit(self, node: ast.AST):
            node = YieldFromTransformer.visit(self, node)  # type: ignore
            return node


# Generated at 2022-06-23 23:29:55.517119
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:29:59.008081
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    node = parse_snippet('[i for i in range(10) if i > 3]')
    node = YieldFromTransformer().visit(node)
    assert unparse(node) == 'a = list(i for i in range(10) if i > 3)\n'



# Generated at 2022-06-23 23:30:09.461598
# Unit test for method visit of class YieldFromTransformer

# Generated at 2022-06-23 23:30:10.913569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__doc__ is not None

# Generated at 2022-06-23 23:30:12.297191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
a = yield from range(5)
"""

# Generated at 2022-06-23 23:30:13.693572
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None


# Generated at 2022-06-23 23:30:18.871289
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import _ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    ###############
    # Test for constructor
    ##

    t = YieldFromTransformer()
    assert type(t) == YieldFromTransformer

    ###############
    # Test for visit function
    ##


# Generated at 2022-06-23 23:30:24.591268
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    try_body = [
        ast.Expr(ast.YieldFrom(ast.Call(ast.Name('x', ast.Load()), [], []))),
        ast.Assign([ast.Name('y', ast.Store())], ast.YieldFrom(ast.Call(ast.Name('x', ast.Load()), [], [])))
    ]
    tree = ast.Try(try_body, [],
                   [ast.ExceptHandler(None, None, [ast.Pass()])],
                   [])
    YieldFromTransformer().visit(tree)



# Generated at 2022-06-23 23:30:25.313802
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-23 23:30:34.482989
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    from ..utils.helpers import validate_ast, ast_to_str, transform_ast

    def transform(body: List[str]) -> str:
        body = '\n'.join(body)
        body = ast_to_str(transform_ast(YieldFromTransformer, body))
        body = ast_to_str(validate_ast(body))
        return body


# Generated at 2022-06-23 23:30:41.892113
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    # test_if_with_yield_from
    node = ast.If(test=ast.Name(id='condition'),
                  body=[extend(result_assignment.get_body(exc=VarName('exc'), target=VarName('target')))],
                  orelse=[])
    node.body.insert(0, extend(yield_from.get_body(generator=VarName('generator'), assignment=[], exc=VarName('exc'))))

# Generated at 2022-06-23 23:30:52.225513
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor

    class Source:
        def generator():
            yield 1
            yield 2
            yield 3

        def method():
            a = yield from generator()
            b = yield from generator()

    expected_source = Source.__dict__['method'].__code__.co_consts[2]

# Generated at 2022-06-23 23:30:54.901000
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import astor
    from .examples.yield_from import *

    tree = '''
    def foo(): 
        yield from x
        a = yield from b
        yield from y
    '''
    tree = astor.parse_tree(tree)
    trans = YieldFromTransformer()
    trans.visit(tree)
    assert astor.dump_tree(tree) == foo.get_body()

# Generated at 2022-06-23 23:31:05.473569
# Unit test for method visit of class YieldFromTransformer
def test_YieldFromTransformer_visit():
    import sys
    if sys.version_info < (3, 3):
        pytest.skip("Python 3.3+ required")

    from ..utils.testutils import assert_ast_transformed, assert_ast_not_transformed
    assert_ast_transformed(
        """
        [x for x in y]
        """,
        """
        let(iterable)
        iterable = iter(y)
        while True:
            try:
                x = next(iterable)
            except StopIteration as exc:
                break
            x
        """)