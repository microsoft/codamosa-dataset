

# Generated at 2022-06-18 00:52:24.983976
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:27.387073
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor


# Generated at 2022-06-18 00:52:28.543776
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:36.325506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump_ast(tree))

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise Exception('YieldFrom found')

    visitor = Visitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:52:46.191882
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast
    from ..utils.test_utils import get_ast_from_func
    from ..utils.test_utils import get_source_from_func

    def test_func(a):
        b = yield from a
        c = yield from a
        return b, c

    source = get_source_from_func(test_func)
    ast_ = get_ast_from_func(test_func)
    ast_ = YieldFromTransformer().visit(ast_)
    source_ = get_source_from_ast(ast_)
    assert_equal_source(source, source_)


# Generated at 2022-06-18 00:52:46.974578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:57.911458
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree

# Generated at 2022-06-18 00:53:02.811580
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:53:03.761337
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:04.699425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:10.878647
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:11.983553
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:12.810937
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:13.657098
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:20.610450
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:53:28.748145
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.compiler import compile_snippets

    compile_snippets()

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise AssertionError('YieldFrom node is not removed')

    Visitor().visit(tree)

# Generated at 2022-06-18 00:53:35.024962
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree

    source = source_to_unicode('''
        def f():
            yield from g()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_tree(new_tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:53:36.221365
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:45.379003
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_source
    from ..utils.helpers import get_source_and_ast
    from ..utils.helpers import get_ast_and_source
    from ..utils.helpers import get_source_and_ast_and_tree
    from ..utils.helpers import get_ast_and_source_and_tree
    from ..utils.helpers import get_source_and_tree
    from ..utils.helpers import get_tree_and_source
    from ..utils.helpers import get_tree_and_ast
    from ..utils.helpers import get_ast_and_tree
    from ..utils.helpers import get_tree_and_ast_and_source

# Generated at 2022-06-18 00:53:47.851995
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_tree_string
    from ..utils.helpers import get_tree_string_without_comments
    from ..utils.helpers import get_tree_string_without_comments_and_docstrings
    from ..utils.helpers import get_tree_string_without_docstrings


# Generated at 2022-06-18 00:53:58.181021
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:54:06.930408
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    print_visitor(YieldFromTransformer(), tree)
    compare_source(YieldFromTransformer(), source, """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)

# Generated at 2022-06-18 00:54:12.544073
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:18.529544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import get_ast
    from ..utils.testing import get_source
    from ..utils.testing import get_target
    from ..utils.testing import get_tree_changed
    from ..utils.testing import get_tree_unchanged
    from ..utils.testing import get_tree_changed_once
    from ..utils.testing import get_tree_changed_twice

    source = get_source(YieldFromTransformer)
    target = get_target(YieldFromTransformer)
    tree_changed = get_tree_changed(YieldFromTransformer)
    tree_unchanged = get_tree_unchanged(YieldFromTransformer)
    tree_changed_once = get_tree_changed_once(YieldFromTransformer)
    tree_changed_twice

# Generated at 2022-06-18 00:54:24.630553
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast(source("""
    def f():
        yield from g()
    """))
    YieldFromTransformer().visit(tree)
    Visitor().visit(tree)

# Generated at 2022-06-18 00:54:36.126629
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_line_by_line
    from ..utils.test_utils import assert_equal_file_by_file
    from ..utils.test_utils import assert_equal_dir_by_dir
    from ..utils.test_utils import assert_equal_dir_by_dir_with_python_files
    from ..utils.test_utils import assert_equal_dir_by_dir_with_files
    from ..utils.test_utils import assert_equal_dir_by_dir_

# Generated at 2022-06-18 00:54:38.033760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for constructor of class YieldFromTransformer
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:48.989528
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:54:50.046181
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:57.069590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import assert_equal_ast
    from ..utils.ast_builder import build_ast

    tree = build_ast("""
    def foo():
        yield from bar()
    """)

    expected = build_ast("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)

    assert_equal_ast(expected, YieldFromTransformer().visit(tree))

# Generated at 2022-06-18 00:55:27.394054
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_node
    from ..utils.source import source_to_unicode
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.count = 0

        def visit_YieldFrom(self, node):
            self.count += 1

    source = """
    def foo():
        yield from bar()
    """
    node = get_node(source)
    visitor = TestVisitor()
    visitor.visit(node)
    assert visitor.count == 1

    transformer = YieldFromTransformer()
    node = transformer.visit(node)
    assert transformer.tree_changed
    assert visitor.count == 0

    source = source_to_unicode(node)

# Generated at 2022-06-18 00:55:33.441606
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
    def foo():
        yield from bar()
    """))
    YieldFromTransformer().visit(tree)
    print(dump(tree))



# Generated at 2022-06-18 00:55:42.513422
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import ast_to_str

    source = Source("""
    def foo():
        a = yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:55:46.283314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import dump_ast
    from ..utils.tree import ast_to_source
    from ..utils.compare import compare_source


# Generated at 2022-06-18 00:55:49.319302
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:50.053931
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:54.895463
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree

    source = source_to_unicode('''
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
        b = yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:55:58.864105
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.helpers import get_func_body

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    func = get_func_body(tree, 'visit')
    YieldFromTransformer().visit(func)
    print(dump_ast(func))

# Generated at 2022-06-18 00:56:00.416229
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-18 00:56:06.715283
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
    def f():
        yield from g()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:56:57.847540
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:58.709606
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:09.089858
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_trees
    from ..utils.test_utils import assert_equal_trees_structure
    from ..utils.test_utils import assert_equal_trees_content
    from ..utils.test_utils import assert_equal_trees_structure_and_content
    from ..utils.test_utils import assert_equal_trees_content_and_order
    from ..utils.test_utils import assert_equal_trees_structure_and_content_and_order

# Generated at 2022-06-18 00:57:20.062179
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:57:30.814090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_names
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_types
    from ..utils.test_utils import get_ast_node_value
    from ..utils.test_utils import get_ast_node_values
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset
   

# Generated at 2022-06-18 00:57:33.094471
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:41.992070
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.source import source

    tree = parse(source('''
        def foo():
            yield from bar()
    '''))

    transformer = YieldFromTransformer()
    transformer.visit(tree)

    assert source(tree) == source('''
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
    ''')

# Generated at 2022-06-18 00:57:42.582656
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:43.731212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:44.535080
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:47.977925
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_to_ast
    from ..utils.helpers import print_ast
    from ..utils.snippet import snippet

    @snippet
    def test_snippet():
        let(a)
        a = yield from range(10)

    tree = parse_to_ast(test_snippet)
    print_ast(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.Assign)
    assert isinstance(tree.body[0].value, ast.Call)

# Generated at 2022-06-18 00:59:48.527263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:49.085059
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:59:49.614837
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:52.405530
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import parse

    tree = parse(source('''
        def foo():
            yield from bar()
    '''))

    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:01.795154
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 01:00:02.574225
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:08.779008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str

    ast_str = """
    def foo():
        yield from bar()
    """
    ast_ = get_ast(ast_str)
    YieldFromTransformer().visit(ast_)
    assert ast_to_str(ast_) == """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """

# Generated at 2022-06-18 01:00:11.833929
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    dump(new_tree)

# Generated at 2022-06-18 01:00:18.607375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(code)
    tree = YieldFromTransformer().visit(tree)
    assert dump(tree) == source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')