

# Generated at 2022-06-18 00:52:30.842176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_ast(tree)

# Generated at 2022-06-18 00:52:32.531878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:40.107916
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source


# Generated at 2022-06-18 00:52:47.337494
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_source

# Generated at 2022-06-18 00:52:49.284947
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:58.785143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code
    from ..utils.test_utils import assert_equal_code_with_source_and_ast
    from ..utils.test_utils import assert_equal_source_with_

# Generated at 2022-06-18 00:53:01.367383
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:02.600511
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:03.625123
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:04.604792
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:53:17.550691
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        a = yield from bar()
        b = yield from bar()
        yield from bar()
        yield from bar()
        return a + b
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:53:20.153443
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)


# Generated at 2022-06-18 00:53:26.378422
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:27.369840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:29.287113
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:37.657283
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.source import source_to_ast
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer
    from ..utils.helpers import VariablesGenerator
    from ..utils.snippet import snippet, let, extend
    from ..utils.tree import insert_at
    from ..utils.source import source_to_ast
    from ..utils.test_utils import assert_equal_ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.snippet import snippet, let, extend
    from ..utils.tree import insert_at
    from ..utils.source import source_to_ast
    from ..utils.test_utils import assert_equal_ast
    from ..utils.helpers import VariablesGenerator


# Generated at 2022-06-18 00:53:46.085635
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.helpers import get_ast_node_name

    source = """
    def f():
        yield from g()
    """
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    assert get_source(tree) == """
    def f():
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """
    assert get_ast_node_

# Generated at 2022-06-18 00:53:56.413637
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse
    import sys
    import os
    import inspect
    import astor
    import astunparse


# Generated at 2022-06-18 00:53:57.478210
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:53:58.585037
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:10.087811
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:13.832448
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:19.275129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_tree_code
    from ..utils.testing import assert_equal_tree_source
    from ..utils.testing import assert_equal_tree_ast

    # Test constructor of class YieldFromTransformer
    def test_constructor():
        YieldFromTransformer()

    # Test method visit of class YieldFromTransformer
    def test_visit():
        from ..utils.testing import assert_equal_source
        from ..utils.testing import assert_equal_ast
        from ..utils.testing import assert_equal_code
        from ..utils.testing import assert_equal_tree
       

# Generated at 2022-06-18 00:54:22.936554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = TestVisitor()
    visitor.visit(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    visitor.visit(tree)

# Generated at 2022-06-18 00:54:24.896020
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str


# Generated at 2022-06-18 00:54:26.760581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:54:32.796559
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
        def foo():
            yield from bar()
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:36.630001
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:48.567332
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compiler import compile_snippets
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    compile_snippets()

    source = source_to_unicode('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    print_tree(tree)

    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)


# Generated at 2022-06-18 00:54:55.094430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import ast_transformer
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.snippet import snippet

    with snippet:
        def foo():
            yield from bar()

    tree = get_ast(foo)
    dump(tree)
    transformer = ast_transformer.get_transformer(YieldFromTransformer)
    transformer.visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:55:21.040619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:21.657469
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:23.932063
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:55:28.102656
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.compare import compare_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    assert compare_source(YieldFromTransformer, tree)

# Generated at 2022-06-18 00:55:30.707232
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:31.581666
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:36.778200
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_FunctionDef(self, node):
            return self.generic_visit(node)


# Generated at 2022-06-18 00:55:37.622396
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:47.129897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_source

# Generated at 2022-06-18 00:55:47.900892
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:56.743907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_code
    from ..utils.helpers import get_source
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_ast
    from ..utils.helpers import get_source
    from ..utils.helpers import get_code
    from ..utils.helpers import get_tree
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_code
    from ..utils.helpers import get_source
    from ..utils.helpers import get_tree

# Generated at 2022-06-18 00:56:58.078684
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:03.610172
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:06.768583
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_node_as_string
    from ..utils.test_utils import assert_equal_code


# Generated at 2022-06-18 00:57:15.070939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            return node

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    visitor = TestVisitor()
    visitor.visit(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(to_source(tree))

# Generated at 2022-06-18 00:57:16.215891
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:19.923231
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    class Dumper(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)


# Generated at 2022-06-18 00:57:20.681975
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:31.557025
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.compat import parse

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = parse(source)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))
    assert get_ast(tree) == get_ast("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = parse(source)
    tree = YieldFromTrans

# Generated at 2022-06-18 00:57:37.501899
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_tree(new_tree)
    assert transformer.tree_changed is True
    assert get_source(new_tree) == source

# Generated at 2022-06-18 01:00:00.509385
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_target_ast

    source = Source("""
    def func():
        a = yield from b
        yield from c
        yield from d
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    target = get_target_ast(source)
    assert dump(tree) == dump(target)

# Generated at 2022-06-18 01:00:01.317488
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:04.507519
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.helpers import get_func_body
    from ..utils.helpers import get_func_args
    from ..utils.helpers import get_func_returns


# Generated at 2022-06-18 01:00:05.518344
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:11.557593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 01:00:16.801890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:17.442314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:20.070706
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        yield from bar()
        yield from baz()
    ''')
    tree = get_ast(code)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:27.926029
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.source import get_source_without_imports

    source = get_source_without_imports(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))
    print(get_source(tree))
    assert source == get_source(tree)

# Generated at 2022-06-18 01:00:29.480756
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()