

# Generated at 2022-06-18 00:52:32.022373
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast_diff
    from ..utils.helpers import get_source_code
    from ..utils.helpers import get_source_code_from_tree
    from ..utils.helpers import get_source_code_from_tree_and_back

    # Test for constructor of class YieldFromTransformer
    # Test #1. Simple test

# Generated at 2022-06-18 00:52:39.806595
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func
    from ..utils.compare import compare_asts
    from ..utils.source import Source
    from ..utils.helpers import get_func
    from ..utils.compare import compare_asts

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    func = get_func(tree, 'foo')
    transformer = YieldFromTransformer()
    new_func = transformer.visit(func)

# Generated at 2022-06-18 00:52:43.595384
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.visitor import print_ast
    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)

# Generated at 2022-06-18 00:52:49.377293
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.helpers import get_source
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_tree_str
    from ..utils.helpers import get_tree_code
    from ..utils.helpers import get_tree_source
    from ..utils.helpers import get_tree_code_str
    from ..utils.helpers import get_tree_source_str
    from ..utils.helpers import get_tree_code_source
    from ..utils.helpers import get_tree_code_source_str
    from ..utils.helpers import get_tree_code_source_str_ast


# Generated at 2022-06-18 00:52:50.596297
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:54.394587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    class Dumper(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    Dumper().visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:53:01.009708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse
    from ..utils.test_utils import transform

    source = '''
    def f():
        yield from g()
    '''
    expected = '''
    def f():
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    '''
    tree = parse(source)
    tree = transform(tree, YieldFromTransformer)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:53:02.245210
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:11.511817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_code_with_tree
    from ..utils.testing import assert_equal_code_with_source
    from ..utils.testing import assert_equal_code_with_ast
    from ..utils.testing import assert_equal_code_with_source_tree
    from ..utils.testing import assert_equal_code_with_ast_tree
    from ..utils.testing import assert_equal_code_with_source_ast
    from ..utils.testing import assert_equal_code_with_source_ast_tree
    from ..utils.testing import assert_equal_code_with_source_tree

# Generated at 2022-06-18 00:53:14.009948
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor


# Generated at 2022-06-18 00:53:25.666552
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:27.257654
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:53:33.192946
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump_ast(tree))

# Generated at 2022-06-18 00:53:36.472405
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse_to_ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet_to_ast


# Generated at 2022-06-18 00:53:37.212672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:37.947092
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:53:46.109444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source

# Generated at 2022-06-18 00:53:50.966442
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:01.964234
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import find_all
    from ..utils.helpers import get_source
    from ..utils.source import Source
    from ..utils.helpers import get_target_ast

    source = Source("""
    def f():
        a = yield from range(10)
        b = yield from range(10)
        c = yield from range(10)
        yield from range(10)
        yield from range(10)
        yield from range(10)
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed

# Generated at 2022-06-18 00:54:06.497938
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:54:18.556166
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:19.077505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:54:21.514101
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:26.601620
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.snippet import snippet

    with snippet:
        def func():
            yield from [1, 2, 3]

    tree = get_ast(func)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert get_source(tree) == get_source(func)

# Generated at 2022-06-18 00:54:37.396251
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func
    from ..utils.helpers import get_func_ast
    from ..utils.helpers import get_func_source
    from ..utils.helpers import get_source
    from ..utils.helpers import get_ast_tree
    from ..utils.helpers import get_source_tree
    from ..utils.helpers import get_func_source_tree
    from ..utils.helpers import get_func_ast_tree
    from ..utils.helpers import get_func_source_tree
    from ..utils.helpers import get_func_ast_tree
    from ..utils.helpers import get_func_source_tree
    from ..utils.helpers import get

# Generated at 2022-06-18 00:54:47.735976
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        a = yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump_ast(tree))

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise AssertionError('YieldFrom should be removed')

    visitor = Visitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:54:58.206079
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import generate_source
    from ..utils.test_utils import parse_ast

    source = generate_source(
        """
        def foo():
            x = yield from bar()
            yield from bar()
            yield from bar()
            yield from bar()
        """
    )

# Generated at 2022-06-18 00:55:07.711767
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import get_node
    from ..utils.testing import get_node_as_string
    from ..utils.testing import get_node_as_string_after_transformation

    node = get_node("""
    def foo():
        yield from bar()
    """)
    expected_node = get_node("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)
    assert_node_equal(YieldFromTransformer().visit(node), expected_node)


# Generated at 2022-06-18 00:55:11.751329
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
    def foo():
        yield from bar()
    """))
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:12.608927
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:35.938911
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:55:45.609260
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    @snippet
    def test():
        let(x)
        x = yield from range(10)

    source = Source(test)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    visitor = TestVisitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:55:46.426609
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:51.280007
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    source = get_source_from_tree(tree)
    print(source)
    assert source == get_source_from_ast(get_ast(source))

# Generated at 2022-06-18 00:55:52.033544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:59.160253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_transformation
    from ..utils.testing import assert_transformation_unchanged

    assert_transformation(
        YieldFromTransformer,
        """
        def foo():
            yield from bar()
        """,
        """
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
        """
    )


# Generated at 2022-06-18 00:56:00.778071
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:08.487028
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import ast2str
    from ..utils.helpers import compare_asts

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:56:10.282123
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:12.853796
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:57:12.120495
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:57:17.627601
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import source

    tree = get_ast(source('''
    def foo(x):
        yield from x
        yield from x
        yield from x
        yield from x
    '''))
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert transformer.tree_changed

# Generated at 2022-06-18 00:57:22.471045
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast

    code = """
    def foo():
        yield from bar()
    """

    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    assert code == compile(tree, '<test>', 'exec').co_code

# Generated at 2022-06-18 00:57:29.793528
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    assert compare_source(source, tree)

# Generated at 2022-06-18 00:57:32.079110
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
        def foo():
            yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:57:36.433846
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:57:45.471497
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.compare import compare_ast
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
   

# Generated at 2022-06-18 00:57:50.624968
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def f():
        yield from g()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:57:55.369200
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    code = source('''
    def f():
        yield from g()
    ''')

    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    assert code == compile(tree, '<test>', 'exec')

# Generated at 2022-06-18 00:57:56.100995
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:03.237670
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:04.059907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:05.034718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:11.295822
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import get_source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_ast
    from ..utils.source import get_source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_ast
    from ..utils.source import get_source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_ast
    from ..utils.source import get_source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 01:00:12.043212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:18.820150
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.compiler import compile_snippets

    compile_snippets()

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)

# Generated at 2022-06-18 01:00:22.597201
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.typing import get_type_hints

    class Dumper(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    source = Source("""
    def foo():
        yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    Dumper().visit(tree)
    print(dump(tree))
    print(get_type_hints(tree))

# Generated at 2022-06-18 01:00:24.819273
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:29.327286
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)


# Generated at 2022-06-18 01:00:30.079894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()