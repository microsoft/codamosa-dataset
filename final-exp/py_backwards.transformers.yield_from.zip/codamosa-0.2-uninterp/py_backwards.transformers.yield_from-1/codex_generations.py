

# Generated at 2022-06-18 00:52:24.128214
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:52:24.864264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:28.865206
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = parse(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:52:38.002532
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_func_body
    from ..utils.helpers import get_func_name
    from ..utils.helpers import get_func_args
    from ..utils.helpers import get_func_return
    from ..utils.helpers import get_func_decorators
    from ..utils.helpers import get_func_kwonlyargs
    from ..utils.helpers import get_func_kw_defaults
    from ..utils.helpers import get_func_vararg
    from ..utils.helpers import get_func_kwarg
    from ..utils.helpers import get_func_defaults

# Generated at 2022-06-18 00:52:46.223996
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.source import get_source
    from ..utils.snippet import snippet

    @snippet
    def test():
        let(a)
        a = yield from range(10)

    tree = get_ast(test)
    print_tree(tree)
    visitor = YieldFromTransformer()
    visitor.visit(tree)
    print_tree(tree)
    print(get_source(tree))

    @snippet
    def test():
        let(a)
        a = yield from range(10)
        print(a)

    tree = get_ast(test)
    print_tree(tree)
    visitor = YieldFromTransformer()

# Generated at 2022-06-18 00:52:47.011775
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:51.079384
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import dump
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:52:52.045386
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:52.952955
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:58.181036
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    source_from_ast = get_source_from_ast(tree)
    assert source == source_from_ast

# Generated at 2022-06-18 00:53:13.404301
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_tree_string
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
        def foo():
            yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:17.625489
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:28.747189
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_without_imports
    from ..utils.source import get_source_without_decorators

    source = get_source(YieldFromTransformer)
    source_without_imports = get_source_without_imports(YieldFromTransformer)
    source_without_decorators = get_source_without_decorators(YieldFromTransformer)

    ast_tree = get_ast(source)
    ast_tree_without_imports = get_ast(source_without_imports)
    ast_tree_without_decorators = get_ast(source_without_decorators)

    print_tree(ast_tree)


# Generated at 2022-06-18 00:53:34.335053
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode('''
    def f():
        a = yield from b
        yield from c
        yield from d
    ''')
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:39.533589
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    print_tree(tree)

    visitor = NodeTransformerVisitor(YieldFromTransformer())
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:40.192544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:41.115394
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:41.852790
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:43.438654
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:52.584826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source_to_ast
    from ..utils.helpers import dump_ast
    from ..utils.visitor import NodeVisitor

    source = """
    def foo():
        yield from bar()
    """
    tree = source_to_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert isinstance(node.test, ast.Name)
            assert node.test.id == 'True'
            assert len(node.body) == 2

# Generated at 2022-06-18 00:54:05.883377
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:14.871169
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.compare import compare_source
    from ..utils.snippet import snippet

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    assert compare_source(YieldFromTransformer, tree)

    source = get_source(YieldFromTransformer.visit)
    tree = get_ast(source)
    print_tree(tree)
    assert compare_source(YieldFromTransformer.visit, tree)

    source = get_source(YieldFromTransformer._get_yield_from_index)
    tree = get_ast(source)
    print_tree(tree)
   

# Generated at 2022-06-18 00:54:17.685245
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:19.472277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:20.488947
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:27.036452
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compat import StringIO

    source = source_to_unicode('''
    def f():
        yield from g()
    ''')
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:28.713780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:54:29.670004
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:31.026220
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:38.886030
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_tree_code
    from ..utils.testing import assert_equal_tree_source
    from ..utils.testing import assert_equal_tree_ast
    from ..utils.testing import assert_equal_tree_tree
    from ..utils.testing import assert_equal_tree_tree_code
    from ..utils.testing import assert_equal_tree_tree_source
    from ..utils.testing import assert_equal_tree_tree_ast
    from ..utils.testing import assert_equal_tree_tree_tree
    from ..utils.testing import assert_equal_tree_tree_tree_code


# Generated at 2022-06-18 00:55:04.524821
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:05.842165
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:06.665260
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:13.544363
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            print(node)

    visitor = Visitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:55:14.328013
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:18.960689
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    @snippet
    def test_snippet():
        let(x)
        x = yield from range(10)

    tree = get_ast(test_snippet)
    dump_ast(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump_ast(tree)



# Generated at 2022-06-18 00:55:25.425733
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet

    @snippet
    def test_snippet():
        let(a)
        a = (yield from range(10))

    ast_ = get_ast(test_snippet)
    YieldFromTransformer().visit(ast_)
    dump_ast(ast_)
    assert NodeVisitor().visit(ast_) == 45

# Generated at 2022-06-18 00:55:26.199916
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:31.617509
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    print_visitor(YieldFromTransformer, tree)

    source = snippet.get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    print_visitor(YieldFromTransformer, tree)

# Generated at 2022-06-18 00:55:32.478122
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:38.342635
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str


# Generated at 2022-06-18 00:56:39.118652
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:46.466210
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_node
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    def foo():
        yield from bar()
    """
    tree = get_node(source)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)
    assert source_to_unicode(tree) == """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """

# Generated at 2022-06-18 00:56:55.962486
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_msg_with_offset
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with

# Generated at 2022-06-18 00:57:02.783707
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.compare import compare_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    dump_ast(new_tree)
    assert compare_source(source, transformer)

# Generated at 2022-06-18 00:57:03.608667
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:08.517809
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast

    code = source('''
    def foo():
        yield from bar()
    ''')

    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    print_ast(tree)



# Generated at 2022-06-18 00:57:16.666839
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor

    source = Source("""
    def func():
        a = yield from range(10)
        b = yield from range(10)
    """)
    tree = get_ast(source)
    print_tree(tree)
    print_visitor(YieldFromTransformer(), tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:22.380191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    print_ast(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)

# Generated at 2022-06-18 00:57:28.150386
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeTransformerPass
    from ..utils.helpers import get_target_version

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    pass_ = NodeTransformerPass(YieldFromTransformer, get_target_version(3, 2))
    pass_.apply(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:52.799572
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast

# Generated at 2022-06-18 01:00:58.253503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:01:03.144894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree

# Generated at 2022-06-18 01:01:14.165844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node
    from ..utils.source import get_source_for_node_or_value

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

    source = get_source_for_node(YieldFromTransformer.visit)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

    source = get_source_for_node_or_value(YieldFromTransformer.visit)
    tree = get_ast(source)

# Generated at 2022-06-18 01:01:22.223703
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node
    from ..utils.source import get_source_for_node_list
    from ..utils.source import get_source_for_node_list_list

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    print(get_source_for_node(tree))
    print(get_source_for_node_list(tree.body))
    print(get_source_for_node_list_list(tree.body))

# Generated at 2022-06-18 01:01:29.921556
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import print_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)
    assert dump(tree) == dump(get_ast(Source("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)))

# Generated at 2022-06-18 01:01:34.637874
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)


# Generated at 2022-06-18 01:01:38.846452
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import source

    tree = get_ast(source('''
    def foo():
        yield from bar()
    '''))
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 01:01:47.616745
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    assert transformer.tree_changed
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.While)

# Generated at 2022-06-18 01:01:51.652993
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
        def foo():
            yield from bar()
    """))

    YieldFromTransformer().visit(tree)
    print_tree(tree)