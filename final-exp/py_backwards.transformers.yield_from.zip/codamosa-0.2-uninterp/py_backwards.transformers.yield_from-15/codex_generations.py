

# Generated at 2022-06-18 00:52:21.921945
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:22.554057
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:31.958248
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compiler import compile_snippets
    from ..utils.snippet import snippet
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compiler import compile_snippets
    from ..utils.snippet import snippet
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compiler import compile_sn

# Generated at 2022-06-18 00:52:35.952485
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import get_source
    from ..utils.tree import print_tree

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:52:46.222039
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_snippet_with_future_features
    from ..utils.test_utils import get_ast_from_snippet_with_future_features_and_fixers
    from ..utils.test_utils import get_ast_from_snippet_with_fixers
    from ..utils.test_utils import get_ast_from_snippet_with_fixers_and_future_features

    # Test for constructor of class YieldFromTransformer
    # Test #1: Test for constructor of class YieldFromTransformer
    # with future features

# Generated at 2022-06-18 00:52:47.009729
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:47.995596
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:50.492922
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:59.126169
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node
    from ..utils.source import get_source_for_node_list

    source = get_source(YieldFromTransformer)
    tree = parse_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_tree(new_tree)
    assert get_source_for_node(new_tree) == get_source_for_node(tree)
    assert get_source_for_node_list(new_tree.body) == get_source_for_node_list(tree.body)

# Generated at 2022-06-18 00:53:10.611708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.helpers import get_node_of_class

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    assert dump_ast(tree) == dump_ast(get_ast("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """))



# Generated at 2022-06-18 00:53:21.550333
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_code_equal

    code = """
    def f():
        yield from g()
    """
    expected = """
    def f():
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    assert_code_equal(expected, YieldFromTransformer().visit(ast.parse(code)))

    code = """
    def f():
        a = yield from g()
    """

# Generated at 2022-06-18 00:53:29.566405
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import dump
    from ..utils.helpers import get_ast_diff
    from ..utils.helpers import get_source_code
    from ..utils.helpers import get_source_code_from_ast

    source = """
    def foo():
        a = yield from bar()
    """
    expected = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    """
    tree = parse(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree

# Generated at 2022-06-18 00:53:35.658883
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    def foo():
        yield from bar()
    """
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    tree = visitor.visit(tree)
    print(source_to_unicode(tree))

# Generated at 2022-06-18 00:53:43.728682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import dump_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    @snippet
    def test_snippet():
        let(a)
        a = yield from range(10)
        print(a)

    @snippet
    def expected_snippet():
        let(a)
        let(exc)
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                a = exc.value
                break
        print(a)

    tree = get_ast(test_snippet)
    expected

# Generated at 2022-06-18 00:53:51.566409
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        a = yield from bar()
        b = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump_ast(tree)
    assert transformer._tree_changed is True
    assert len(NodeVisitor().visit(tree)) == 2

# Generated at 2022-06-18 00:54:02.443503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import dump_tree
    from ..utils.compat import builtins

    tree = source('''
        def foo():
            yield from range(10)
    ''')

    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_ast(tree)
    assert dump_tree(tree) == source('''
        def foo():
            let(iterable)
            iterable = iter(range(10))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
    ''')


# Generated at 2022-06-18 00:54:05.080689
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:14.303688
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import dump

# Generated at 2022-06-18 00:54:15.087059
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:26.197994
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_ast_with_code

# Generated at 2022-06-18 00:54:43.195386
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def f():
        a = yield from b
        yield from c
        yield from d
    ''')
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:51.628350
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import source
    from ..utils.compare import compare_source

    code = """
    def foo():
        a = yield from bar()
        b = yield from bar()
        yield from bar()
        yield from bar()
    """

# Generated at 2022-06-18 00:54:52.335027
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:58.638586
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.compare import compare_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    new_source = dump(new_tree)

    assert compare_source(__file__, source, new_source)

# Generated at 2022-06-18 00:54:59.370714
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:09.087112
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import dump
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import dump
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import dump
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor

# Generated at 2022-06-18 00:55:17.401326
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:55:25.847623
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == 'Compiles yield from to special while statement.'
    assert YieldFromTransformer.target == (3, 2)
    assert YieldFromTransformer._get_yield_from_index.__name__ == '_get_yield_from_index'
    assert YieldFromTransformer._emulate_yield_from.__name__ == '_emulate_yield_from'
    assert YieldFromTransformer._handle_assignments.__name__ == '_handle_assignments'
    assert YieldFromTransformer._handle_expressions.__name__ == '_handle_expressions'
    assert YieldFromTransformer.visit.__name__ == 'visit'
    assert Yield

# Generated at 2022-06-18 00:55:32.557457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_code
    from ..utils.helpers import get_ast_source
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import let
    from ..utils.snippet import extend
    from ..utils.helpers import get_ast_source
    from ..utils.tree import parse_code
    from ..utils.helpers import get_ast_source
    from ..utils.tree import parse_code
    from ..utils.helpers import get_ast_source
    from ..utils.tree import parse_code
    from ..utils.helpers import get_ast_source
    from ..utils.tree import parse_code

# Generated at 2022-06-18 00:55:41.887115
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == 'Compiles yield from to special while statement.'
    assert YieldFromTransformer.target == (3, 2)
    assert YieldFromTransformer._get_yield_from_index.__name__ == '_get_yield_from_index'
    assert YieldFromTransformer._get_yield_from_index.__doc__ == 'None'
    assert YieldFromTransformer._emulate_yield_from.__name__ == '_emulate_yield_from'
    assert YieldFromTransformer._emulate_yield_from.__doc__ == 'None'
    assert YieldFromTransformer._handle_assignments.__name__ == '_handle_assignments'


# Generated at 2022-06-18 00:56:11.981565
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    assert get_source_from_tree(tree) == get_source_from_ast(transformer.tree)

# Generated at 2022-06-18 00:56:12.634161
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:14.992816
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.visitor import print_ast


# Generated at 2022-06-18 00:56:20.189919
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func

    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))
    func = get_func(tree, 'foo')
    assert len(func.body) == 4
    assert isinstance(func.body[0], ast.Assign)
    assert isinstance(func.body[1], ast.While)
    assert isinstance(func.body[2], ast.While)

# Generated at 2022-06-18 00:56:28.173345
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse

    # Test for constructor of class YieldFromTransformer
    def test_constructor():
        YieldFromTransformer()

    # Test for method _get_yield_from_index of class YieldFromTransformer
    def test_get_yield_from_index():
        node = parse('a = yield from b')
        assert YieldFromTransformer()._get_yield_from_index(node, ast.Assign) == 0
        assert YieldFromTransformer()._get_yield_from_index(node, ast.Expr) is None

    # Test for method _emulate_yield_from of class YieldFromTransformer
    def test_emulate_yield_from():
        node = parse('a = yield from b')
        assert YieldFromTransformer()._em

# Generated at 2022-06-18 00:56:38.865354
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_func_body

    source = Source("""
    def foo():
        yield from bar()
    """)

    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert transformer._tree_changed

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert node.test.id == 'True'
            assert len(node.body) == 1
            assert isinstance(node.body[0], ast.Expr)

# Generated at 2022-06-18 00:56:42.736500
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:56:43.580393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:49.009561
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_node

    # Test for constructor of class YieldFromTransformer
    def test_constructor():
        transformer = YieldFromTransformer()
        assert_equal_node(transformer, YieldFromTransformer())

    # Test for method _get_yield_from_index of class YieldFromTransformer
    def test_get_yield_from_index():
        transformer = YieldFromTransformer()
        assert_equal_node(transformer._get_yield_from_index(ast.parse('yield from a'), ast.Expr), 0)

# Generated at 2022-06-18 00:56:56.654727
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse_to_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    @snippet
    def test_yield_from():
        let(a)
        a = yield from range(10)

    @snippet
    def test_yield_from_with_assignment():
        let(a)
        a = yield from range(10)
        let(b)
        b = yield from range(10)

    @snippet
    def test_yield_from_with_assignment_and_expression():
        let(a)
        a = yield from range(10)
        let(b)
        b = yield from range(10)
        yield from range(10)



# Generated at 2022-06-18 00:58:38.349221
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import dump_ast
    from ..utils.tree import get_ast

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print('YieldFrom')

    visitor = Visitor()
    visitor.visit(get_ast(source(YieldFromTransformer)))
    print(dump_ast(get_ast(source(YieldFromTransformer))))

# Generated at 2022-06-18 00:58:39.055091
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:41.026083
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:47.141322
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compiler import compile

    source = Source("""
    def foo():
        a = yield from bar()
        yield from baz()
    """)

    tree = get_ast(source)
    print_tree(tree)

    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

    code = compile(tree, source.path, 'exec')
    exec(code)

# Generated at 2022-06-18 00:58:53.570101
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_tree_code
    from ..utils.testing import assert_equal_tree_source
    from ..utils.testing import assert_equal_tree_ast
    from ..utils.testing import assert_equal_tree_tree
    from ..utils.testing import assert_equal_tree_tree_code
    from ..utils.testing import assert_equal_tree_tree_source
    from ..utils.testing import assert_equal_tree_tree_ast
    from ..utils.testing import assert_equal_tree_tree_tree
    from ..utils.testing import assert_equal_tree_tree_tree_code


# Generated at 2022-06-18 00:58:54.225445
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:59.666939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_to_ast

    code = """
    def foo():
        yield from bar()
    """
    expected = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """
    ast_tree = parse_to_ast(code)
    YieldFromTransformer().visit(ast_tree)
    assert_equal_code(expected, ast_tree)

    code = """
    def foo():
        a = yield from bar()
    """

# Generated at 2022-06-18 00:59:02.885578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast

    source = source('''
        def foo():
            a = yield from bar()
            yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    assert source == tree

# Generated at 2022-06-18 00:59:10.678073
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node
    from ..utils.source import get_source_for_node_list
    from ..utils.source import get_source_for_node_list_with_indent
    from ..utils.source import get_source_for_node_with_indent
    from ..utils.source import get_source_for_node_with_indent_and_new_line
    from ..utils.source import get_source_for_node_with_new_line
    from ..utils.source import get_source_for_node_with_new_line_and_indent
    from ..utils.source import get_source_for_node_with_new

# Generated at 2022-06-18 00:59:17.611727
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
        def f():
            yield from g()
    """))
    YieldFromTransformer().visit(tree)
    assert dump(tree) == source("""
        def f():
            let(iterable)
            iterable = iter(g())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
    """)

    tree = get_ast(source("""
        def f():
            a = yield from g()
    """))
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-18 01:01:04.965428
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump(tree)

# Generated at 2022-06-18 01:01:14.890578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:01:20.318296
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)

# Generated at 2022-06-18 01:01:21.088326
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:28.558609
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_func
    from ..utils.helpers import get_func_ast
    from ..utils.helpers import get_func_source
    from ..utils.helpers import get_func_source_ast
    from ..utils.helpers import get_func_source_tree
    from ..utils.helpers import get_func_source_tree_ast
    from ..utils.helpers import get_func_source_tree_ast_source
    from ..utils.helpers import get_func_source_tree_ast_source_tree
    from ..utils.helpers import get_func_source_tree_ast_source_tree_ast
    from ..utils.helpers import get_func

# Generated at 2022-06-18 01:01:36.879020
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast

# Generated at 2022-06-18 01:01:38.305157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 01:01:39.374074
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:40.429717
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:48.068493
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_code_tree
    from ..utils.testing import assert_equal_code_source
    from ..utils.testing import assert_equal_tree_source
    from ..utils.testing import assert_equal_code_tree_source
