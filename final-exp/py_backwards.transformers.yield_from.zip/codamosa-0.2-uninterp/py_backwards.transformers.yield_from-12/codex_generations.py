

# Generated at 2022-06-18 00:52:28.781935
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_ast

    source = Source("""
    def foo():
        yield from [1, 2, 3]
    """)
    tree = parse(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert get_ast(source) == tree

# Generated at 2022-06-18 00:52:29.562062
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:52:30.335756
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:31.957820
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:35.952385
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:52:43.952023
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import assert_equal_code

    code = source('''
    def foo():
        yield from bar()
    ''')

    expected = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')

    assert_equal_code(YieldFromTransformer, code, expected)



# Generated at 2022-06-18 00:52:50.575899
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    from typing import Optional, List, Type, Union
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    @snippet
    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value
    @snippet
    def yield_from(generator, exc, assignment):
        let(iterable)

# Generated at 2022-06-18 00:52:53.761327
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeTransformerVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = NodeTransformerVisitor(YieldFromTransformer())
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:00.509139
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    assert compare_ast(new_tree, snippet("""
    def f():
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """))



# Generated at 2022-06-18 00:53:10.650540
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from .base import BaseNodeTransformer
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    @snippet
    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value
    @snippet
    def yield_from(generator, exc, assignment):
        let(iterable)
        iterable = iter(generator)

# Generated at 2022-06-18 00:53:18.838707
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    assert dump(tree) != dump(new_tree)

# Generated at 2022-06-18 00:53:26.970504
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            assert node.value.id == 'a'

    tree = get_ast(source("""
    def foo():
        yield from a
    """))
    YieldFromTransformer().visit(tree)
    Visitor().visit(tree)



# Generated at 2022-06-18 00:53:36.697155
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_node_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception
    from ..utils.test_utils import assert_equal_ast_with_exception
    from ..utils.test_utils import assert_equal_node_with_exception

# Generated at 2022-06-18 00:53:37.452731
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:46.082845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import compile_snippet
    from ..utils.tree import dump
    from ..utils.source import source

    snippet = """
    def foo():
        yield from bar()
    """
    tree = compile_snippet(snippet, 'single', 'exec')
    YieldFromTransformer().visit(tree)
    assert source(tree) == """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """

    snippet = """
    def foo():
        a = yield from bar()
    """

# Generated at 2022-06-18 00:53:56.416635
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump_ast(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:54:03.956455
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        a = yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    dump_ast(tree)
    visitor = YieldFromTransformer()
    visitor.visit(tree)
    dump_visitor(visitor)
    compare_source(Source(dump_ast(tree)), source)

# Generated at 2022-06-18 00:54:10.236610
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    import unittest
    import sys
    import os
    import astor
    import astunparse
    import io
    import contextlib
    import astor
    import astunparse
    import io
    import contextlib
    import astor
    import astunparse
    import io
    import contextlib
    import astor
    import astunparse
    import io
    import contextlib
    import astor
    import astunparse
    import io
    import contextlib
    import astor
    import astunparse
   

# Generated at 2022-06-18 00:54:11.047265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:17.662300
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        YieldFromTransformer,
        """
        def foo():
            yield from bar()
        """,
        """
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """
    )


# Generated at 2022-06-18 00:54:24.603355
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_source


# Generated at 2022-06-18 00:54:33.408734
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    dump_ast(tree)
    dump_visitor(transformer)
    compare_source(__file__, source, transformer)

# Generated at 2022-06-18 00:54:37.310318
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)


# Generated at 2022-06-18 00:54:38.932356
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:47.518050
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode('''
    def foo():
        a = yield from bar()
        b = yield from baz()
        yield from qux()
    ''')
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer())
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:54.871401
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    compare_ast(tree, get_ast(get_source(YieldFromTransformer)))

# Generated at 2022-06-18 00:54:58.172491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    assert source == compile(tree, '<test>', 'exec')

# Generated at 2022-06-18 00:55:01.501527
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.source import get_source

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)


# Generated at 2022-06-18 00:55:10.046858
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump_ast(tree))
    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise Exception('YieldFrom is not allowed')
    Visitor().visit(tree)

# Generated at 2022-06-18 00:55:14.102874
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:31.107537
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_node
    from ..utils.source import Source
    from ..utils.visitor import print_tree
    from ..utils.compare import compare_source
    from ..utils.tree import get_ast

    source = Source("""
    def f():
        yield from range(10)
    """)
    node = get_node(source)
    transformer = YieldFromTransformer()
    new_node = transformer.visit(node)
    print_tree(new_node)
    assert compare_source(new_node, get_ast(source))

# Generated at 2022-06-18 00:55:33.605374
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    assert source != transformer.dump()

# Generated at 2022-06-18 00:55:42.640073
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_fields
    from ..utils.test_utils import assert_equal_attributes
    from ..utils.test_utils import assert_equal_lineno
    from ..utils.test_utils import assert_equal_col_offset
    from ..utils.test_utils import assert_equal_end_lineno
    from ..utils.test_utils import assert_equal_end_col_offset
    from ..utils.test_utils import assert_equal_bool
    from ..utils.test_utils import assert_equal_int
    from ..utils.test_utils import assert_equal_none

# Generated at 2022-06-18 00:55:44.284601
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:52.509134
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_ast_with_code

# Generated at 2022-06-18 00:55:53.364096
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:59.377762
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.snippet import snippet
    from ..utils.source import source_to_unicode

    @snippet
    def code():
        def foo():
            yield from bar()

    tree = get_ast(code)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)
    assert source_to_unicode(tree) == source_to_unicode(code)

# Generated at 2022-06-18 00:56:00.779265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:08.486742
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    @snippet
    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value
    @snippet
    def yield_from(generator, exc, assignment):
        let(iterable)
        iterable = iter(generator)

# Generated at 2022-06-18 00:56:16.857746
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_tree_with_source
    from ..utils.test_utils import assert_equal_tree_with_source_after_transformation
    from ..utils.test_utils import assert_equal_tree_with_source_after_transformation_with_target
    from ..utils.test_utils import assert_equal_tree_with_source_after_transformation_with_target_and_indent
    from ..utils.test_utils import assert_equal_tree_with

# Generated at 2022-06-18 00:56:49.268479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:56.732008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.compat import to_tuple

    source = Source("""
    def f():
        yield from range(10)
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert dump(tree) == dump(get_ast(Source("""
    def f():
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)))


# Generated at 2022-06-18 00:57:04.066364
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    source = get_source_from_ast(tree)
    print(source)

# Generated at 2022-06-18 00:57:12.058366
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import dump_ast
    from ..utils.helpers import get_ast_node
    from ..utils.helpers import get_ast_nodes
    from ..utils.helpers import get_ast_node_names
    from ..utils.helpers import get_ast_node_names_by_type
    from ..utils.helpers import get_ast_node_names_by_types
    from ..utils.helpers import get_ast_node_names_by_type_and_attr
    from ..utils.helpers import get_ast_node_names_by_type_and_attr_value
    from ..utils.helpers import get_ast_node_names_by_type_and_attr_values
    from ..utils.helpers import get_ast_node

# Generated at 2022-06-18 00:57:20.718885
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:23.086907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:23.915661
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:30.632505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    print_tree(tree)
    transformer = NodeTransformerVisitor(YieldFromTransformer())
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:31.295295
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:57:36.005274
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compat import StringIO


# Generated at 2022-06-18 00:58:54.737814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    print_visitor(YieldFromTransformer(), tree)
    compare_source(source, YieldFromTransformer, 'test_yield_from_transformer_1')

    source = Source("""
    def foo():
        yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    print_tree(tree)

# Generated at 2022-06-18 00:58:55.408627
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:58:59.082998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.helpers import compare_source
    from ..utils.helpers import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    compare_source(__file__, source, tree)

# Generated at 2022-06-18 00:59:01.345941
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast

    code = """
    def foo():
        yield from bar()
    """
    ast_tree = get_ast(code)
    YieldFromTransformer().visit(ast_tree)
    assert code == compile(ast_tree, '<test>', 'exec').co_code

# Generated at 2022-06-18 00:59:02.226289
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:10.249590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.helpers import get_ast_from_str
    from ..utils.helpers import get_ast_from_file
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_ast_from_expr
    from ..utils.helpers import get_ast_from_stmt
    from ..utils.helpers import get_ast_from_object
    from ..utils.helpers import get_ast_from_class
    from ..utils.helpers import get_ast_from_function
    from ..utils.helpers import get_ast_from_module
    from ..utils.helpers import get_ast_from_suite
    from ..utils.helpers import get_ast_

# Generated at 2022-06-18 00:59:15.541057
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerPass

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    pass_ = NodeTransformerPass(YieldFromTransformer)
    pass_.apply(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:59:19.852109
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    dump_ast(new_tree)
    assert transformer.tree_changed() is True

# Generated at 2022-06-18 00:59:26.946338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode('''
        def foo():
            yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:59:27.751020
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()