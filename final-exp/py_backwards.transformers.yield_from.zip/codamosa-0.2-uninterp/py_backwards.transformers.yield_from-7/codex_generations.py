

# Generated at 2022-06-18 00:52:32.829227
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump_ast(tree))
    visitor = Visitor()
    visitor.visit(tree)


# Generated at 2022-06-18 00:52:40.273208
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from .base import BaseNodeTransformer
    import unittest
    import sys
    import os
    import astor
    import astunparse
    import textwrap
    import io
    import contextlib
    import tempfile
    import shutil
    import random
    import string
    import re
    import types
    import inspect
    import importlib
    import unittest.mock
    import typing
    import typing_extensions
    import enum
    import dataclasses
    import functools
    import pathlib
    import abc
    import collections
    import fractions
    import numbers
    import operator
    import io

# Generated at 2022-06-18 00:52:47.441372
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast

    source = """
    def test():
        a = yield from b
        yield from c
    """
    expected = """
    def test():
        let(iterable)
        iterable = iter(b)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
        let(iterable)
        iterable = iter(c)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc.value
                break
    """
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)


# Generated at 2022-06-18 00:52:49.833908
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:57.418409
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_source

    source = source_to_unicode('''
        def foo():
            yield from bar()
    ''')
    tree = get_ast(source)
    print_tree(tree)

    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

    print_visitor(transformer, tree)

    assert compare_source(source, transformer)

# Generated at 2022-06-18 00:52:58.857478
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:53:07.682506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    @snippet
    def test_snippet():
        def foo():
            yield from bar()

    tree = get_ast(test_snippet)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:08.646279
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:12.981117
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.visitor import print_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:53:13.812172
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:29.009057
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump(tree)

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert node.test.id == 'True'
            assert node.body[0].value.func.id == 'next'
            assert node.body[0].value.args[0].id == 'iterable'
            assert node.body[1].value.func.id == 'iter'

# Generated at 2022-06-18 00:53:29.939813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:30.706451
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:37.137889
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        x = yield from bar()
        yield from baz()
        yield from qux()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:45.636317
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node
    from ..utils.source import get_source_for_node_list
    from ..utils.source import get_source_for_node_list_list

    source = """
    def foo():
        yield from bar()
    """
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-18 00:53:47.134374
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:48.365166
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:51.902683
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:53:55.590421
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor


# Generated at 2022-06-18 00:54:04.827557
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.snippet import get_snippet_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

    source = get_source(result_assignment)
    tree = get_snippet_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

    source = get_source(yield_from)
    tree = get_snippet_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:16.720486
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:18.555612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:19.078075
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:20.291217
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:54:22.404336
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast, get_code
    from ..utils.tree import print_tree, compare_trees


# Generated at 2022-06-18 00:54:23.325142
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:30.461644
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert isinstance(transformer, NodeVisitor)
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer.target == (3, 2)
    assert transformer._tree_changed == True
    assert transformer._get_yield_from_index(tree, ast.Assign) == None

# Generated at 2022-06-18 00:54:31.509628
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:54:32.942616
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:36.729606
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:54:59.338482
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor

# Generated at 2022-06-18 00:55:00.105465
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:06.192384
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
        yield from baz()
        yield from qux()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:55:10.905493
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def func():
        a = yield from range(10)
        b = yield from range(10)
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:18.442212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast
    from ..utils.compare import compare_source

    source = source('''
    def foo():
        yield from bar()
    ''')
    expected = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')

    ast_tree = get_ast(source)
    YieldFromTransformer().visit(ast_tree)
    assert compare_source(expected, print_ast(ast_tree))

    source = source

# Generated at 2022-06-18 00:55:19.113744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:21.947353
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    assert source == tree

# Generated at 2022-06-18 00:55:24.195402
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:55:25.212200
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:32.040638
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_tree_with_source
    from ..utils.test_utils import assert_equal_source_with_tree
    from ..utils.test_utils import assert_equal_code_with_tree
    from ..utils.test_utils import assert_equal_code_with_source_and_tree
    from ..utils.test_utils import assert_equal_tree_with_source_and_code
    from ..utils.test_utils import assert_equal_source_with_

# Generated at 2022-06-18 00:56:28.038739
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.context import Context
    from ..utils.compiler import compile_snippets
    compile_snippets()

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    context = Context(source)
    visitor = NodeTransformerVisitor(context)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:56:38.865645
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_code_tree
    from ..utils.testing import assert_equal_source_tree
    from ..utils.testing import assert_equal_source_code

    assert_equal_ast(YieldFromTransformer,
                     """
                     def f():
                         yield from g()
                     """,
                     """
                     def f():
                         let(iterable)
                         iterable = iter(g())
                         while True:
                             try:
                                 yield next(iterable)
                             except StopIteration as exc:
                                 break
                     """)


# Generated at 2022-06-18 00:56:43.124800
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:56:44.002845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:53.878687
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_visitor(transformer)
    print_tree(tree)
    compare_source(Source(transformer.result), source)



# Generated at 2022-06-18 00:56:56.309559
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:01.960736
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:03.263563
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:04.149231
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:10.751708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise AssertionError('YieldFrom node found')

    Visitor().visit(tree)

# Generated at 2022-06-18 00:59:24.505546
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_asts

    source_1 = source('''
    def foo():
        yield from bar()
    ''')
    expected_1 = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')
    ast_1 = get_ast(source_1)
    YieldFromTransformer().visit(ast_1)
    assert compare_asts(ast_1, get_ast(expected_1))


# Generated at 2022-06-18 00:59:25.335520
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:33.251808
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import get_snippet
    from ..utils.helpers import get_ast_from_snippet
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import compare_asts

    code = """
    def foo():
        yield from bar()
    """
    expected_code = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """
    ast_ = get_ast(code)
    expected_ast = get_ast(expected_code)
    transformer = YieldFromTransformer()
   

# Generated at 2022-06-18 00:59:39.039177
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.snippet import snippet

    @snippet
    def code():
        def foo():
            a = yield from bar()
            b = yield from baz()

    tree = get_ast(code)
    print_tree(tree)
    transformer = NodeTransformerVisitor(YieldFromTransformer())
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:59:43.415283
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source

    code = get_source(YieldFromTransformer)
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    print(get_source(tree))

# Generated at 2022-06-18 00:59:44.165311
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:50.539029
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import compile_snippet
    from ..utils.tree import dump_ast

    snippet = """
    def foo():
        yield from bar()
    """
    tree = compile_snippet(snippet, YieldFromTransformer)

# Generated at 2022-06-18 00:59:59.924041
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_source
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_source
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_source
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_source

# Generated at 2022-06-18 01:00:07.774869
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source
    from ..utils.compare import compare_ast
    from ..utils.tree import dump_ast

    source_1 = source('''
    def foo():
        yield from bar()
    ''')
    source_2 = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')
    tree_1 = get_ast(source_1)
    tree_2 = get_ast(source_2)
    transformer = YieldFromTransformer()

# Generated at 2022-06-18 01:00:10.579171
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    dump(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump(tree)