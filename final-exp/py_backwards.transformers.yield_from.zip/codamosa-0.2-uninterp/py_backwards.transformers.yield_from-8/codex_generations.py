

# Generated at 2022-06-18 00:52:36.698920
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.snippet import snippet

# Generated at 2022-06-18 00:52:42.757189
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        yield from bar()
        yield from baz()
        yield from qux()
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:52:48.916290
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer
    from .yield_from import Node
    from .yield_from import Holder
    from .yield_from import result_assignment
    from .yield_from import yield_from
    import astor
    import astunparse
    import sys
    import os
    import ast
    import astor
    import astunparse
    import sys
    import os
    import ast
    import astor
    import astunparse
    import sys
    import os

# Generated at 2022-06-18 00:52:58.754487
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    assert_equal_ast(YieldFromTransformer().visit(get_ast("""
        def foo():
            yield from bar()
    """)), get_ast("""
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """))


# Generated at 2022-06-18 00:53:10.256033
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

    source = get_source

# Generated at 2022-06-18 00:53:11.147356
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:19.082595
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import dump_ast
    from ..utils.tree import find_all_subclasses

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = ast.parse(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert dump_ast(tree) == dump_ast(ast.parse(source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')))


# Generated at 2022-06-18 00:53:21.411788
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:22.559733
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:24.482540
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:37.459403
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:53:40.770844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump


# Generated at 2022-06-18 00:53:42.213065
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:53:43.477466
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:52.607609
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.compare import compare_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source

# Generated at 2022-06-18 00:54:02.719430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree
    from ..utils.source import get_source_from_node
    from ..utils.source import get_source_from_node_tree
    from ..utils.source import get_source_from_node_tree_ast
    from ..utils.source import get_source_from_node_ast
    from ..utils.source import get_source_from_node_ast_tree
    from ..utils.source import get_source_from_node_tree_ast_tree
    from ..utils.source import get_source_from_node_tree_ast_tree_ast

# Generated at 2022-06-18 00:54:13.669601
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import make_fixture, run_test
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import parse_module
    from ..utils.snippet import snippet, let, extend

    @snippet
    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value

    @snippet
    def yield_from(generator, exc, assignment):
        let(iterable)
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                extend(assignment)
                break

    @snippet
    def test_yield_from():
        let(a)
        a = yield from range(10)
        print

# Generated at 2022-06-18 00:54:25.059618
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_source
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_node
    from ..utils.helpers import get_nodes
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_value

# Generated at 2022-06-18 00:54:25.947749
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:34.303282
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast('yield_from.py')
    print_tree(tree)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:54:52.273187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_ast_with_code
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code

# Generated at 2022-06-18 00:54:58.857691
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    source = get_source_from_ast(tree)
    print(source)


# Generated at 2022-06-18 00:55:02.022951
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:55:09.010701
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_target_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    target = get_target_ast(source)
    assert tree == target

# Generated at 2022-06-18 00:55:17.371033
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    @snippet
    def test_yield_from():
        let(a)
        a = yield from range(10)
        print(a)

    @snippet
    def test_yield_from_2():
        let(a)
        a = yield from range(10)
        print(a)
        let(b)
        b = yield from range(10)
        print(b)

    @snippet
    def test_yield_from_3():
        let(a)
        a = yield from range(10)
        print(a)
        let(b)
        b = yield from range

# Generated at 2022-06-18 00:55:19.262393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:55:19.946360
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:20.645776
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:55:29.438458
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree
    from ..utils.source import get_source_from_node
    from ..utils.source import get_source_from_node_list
    from ..utils.source import get_source_from_node_list_list
    from ..utils.source import get_source_from_node_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list_list
    from ..utils.source import get_source_from_node_

# Generated at 2022-06-18 00:55:37.314887
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    dump(tree)

# Generated at 2022-06-18 00:56:00.658348
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:01.550154
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:03.638534
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

# Generated at 2022-06-18 00:56:10.060366
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_asts
    from ..utils.snippet import snippet

    source1 = source('''
    def foo():
        yield from bar()
    ''')

    source2 = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')

    ast1 = get_ast(source1)
    ast2 = get_ast(source2)

    transformer = YieldFromTransformer()
   

# Generated at 2022-06-18 00:56:10.823923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:11.529087
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:18.472457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code
    from ..utils.test_utils import assert_equal_ast_with_ast
    from ..utils.test_utils import assert_equal_source_with_ast

# Generated at 2022-06-18 00:56:20.529819
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:25.785239
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:56:26.539133
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:18.318909
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_ast

    source = Source("""
    def foo():
        yield from bar()
    """)

    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            assert False, 'YieldFrom should be removed'

    Visitor().visit(tree)

# Generated at 2022-06-18 00:57:26.121824
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    print(get_source_for_node(tree))

# Generated at 2022-06-18 00:57:28.507505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:33.557611
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    dump(tree)
    YieldFromTransformer().visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:57:34.706148
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:36.654701
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:41.480531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast

    code = """
    def f():
        yield from range(10)
    """
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    assert code == compile(tree, '<test>', 'exec').co_code



# Generated at 2022-06-18 00:57:42.454501
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree

# Generated at 2022-06-18 00:57:43.488657
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-18 00:57:44.364920
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:34.446706
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.helpers import get_code
    from ..utils.helpers import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    code = get_code(tree)
    print(code)
    print(dump(tree))

# Generated at 2022-06-18 00:59:34.929840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:41.755449
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree

# Generated at 2022-06-18 00:59:43.117740
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:59:47.036542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:59:47.706527
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:53.671369
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code
    from ..utils.helpers import get_

# Generated at 2022-06-18 00:59:54.623670
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:03.457599
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 01:00:04.283851
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()