

# Generated at 2022-06-18 00:52:23.688277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:33.716886
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import dump_ast
    from ..utils.compare import compare_ast

    source = source_to_unicode("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    """)

# Generated at 2022-06-18 00:52:40.664697
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == 'Compiles yield from to special while statement.'
    assert YieldFromTransformer.target == (3, 2)
    assert YieldFromTransformer._get_yield_from_index.__name__ == '_get_yield_from_index'
    assert YieldFromTransformer._emulate_yield_from.__name__ == '_emulate_yield_from'
    assert YieldFromTransformer._handle_assignments.__name__ == '_handle_assignments'
    assert YieldFromTransformer._handle_expressions.__name__ == '_handle_expressions'
    assert YieldFromTransformer.visit.__name__ == 'visit'

# Unit test

# Generated at 2022-06-18 00:52:49.639171
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node

    source = """
    def f():
        a = yield from b
        yield from c
        yield from d
        yield from e
    """
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:52:51.026510
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:51.993675
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:53.278911
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:52:57.166409
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
    def foo():
        yield from bar()
    """))

    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:01.578930
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast('''
    def foo():
        yield from bar()
    ''')
    print_tree(tree)
    print('---')
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    print('---')
    Visitor().visit(tree)

# Generated at 2022-06-18 00:53:09.025253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.visitor import print_tree
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    ast_tree = get_ast(source)
    print_tree(ast_tree)
    transformer = YieldFromTransformer()
    new_ast = transformer.visit(ast_tree)
    print_tree(new_ast)
    compare_source(__file__, source, transformer._source)

# Generated at 2022-06-18 00:53:14.878865
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:21.323133
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.compat import StringIO

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            assert node.value.id == 'a'

    source = """
    def foo():
        yield from a
    """
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    TestVisitor().visit(tree)
    out = StringIO()
    dump_ast(tree, out)

# Generated at 2022-06-18 00:53:22.459756
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:24.301726
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:30.693020
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer
    from typing import Optional, List, Type, Union
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]

# Generated at 2022-06-18 00:53:32.693523
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:33.610864
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:41.680321
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.typing import get_type_hints

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.visited = False

        def visit_YieldFrom(self, node):
            self.visited = True

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed
    visitor = TestVisitor()
    visitor.visit(tree)
    assert not visitor.visited

# Generated at 2022-06-18 00:53:43.266069
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:44.144867
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:55.336074
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:04.932322
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from .base import BaseNodeTransformer
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    @snippet
    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value
    @snippet
    def yield_from(generator, exc, assignment):
        let(iterable)
        iterable = iter(generator)

# Generated at 2022-06-18 00:54:10.046065
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
        def foo():
            yield from bar()
    """))

    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:10.820287
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:11.598199
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:15.262875
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast

    src = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(src)
    YieldFromTransformer().visit(tree)
    print_ast(tree)

# Generated at 2022-06-18 00:54:22.581956
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    print(get_source_from_ast(tree))

# Generated at 2022-06-18 00:54:23.504449
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:27.652387
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:30.879570
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:54:58.362554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.typed_ast import ast3 as ast

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    source = Source("""
    def f():
        yield from range(10)
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))
    Visitor().visit(tree)

# Generated at 2022-06-18 00:54:59.077492
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:59.794242
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:00.540954
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:10.905726
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source
    from ..utils.compare import compare_ast
    from ..utils.tree import get_node_of_class

    source_1 = source('''
    def foo():
        yield from bar()
    ''')
    source_2 = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')
    tree_1 = get_ast(source_1)
    tree_2 = get_ast(source_2)
    transformer = YieldFromTransformer()

# Generated at 2022-06-18 00:55:11.994998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:12.849353
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:19.852302
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:55:23.250354
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.compare import compare_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    assert compare_source(__file__, source, tree)

# Generated at 2022-06-18 00:55:24.858049
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:11.495843
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:12.159080
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:18.965605
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import print_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_ast(tree)
    assert dump_ast(tree) == dump_ast(get_ast("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """))


# Generated at 2022-06-18 00:56:22.838577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_to_ast


# Generated at 2022-06-18 00:56:23.555850
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:24.449414
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:25.683129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:56:31.559158
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
        def f():
            yield from g()
    ''')
    tree = get_ast(source)
    assert dump(tree) == dump(get_ast(source))
    YieldFromTransformer().visit(tree)
    assert dump(tree) != dump(get_ast(source))

# Generated at 2022-06-18 00:56:32.413813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:37.763266
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.helpers import compare_asts
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_imports_and_docstrings
    from ..utils.helpers import get_code_without_docstrings


# Generated at 2022-06-18 00:58:27.503398
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:31.289072
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.helpers import get_target_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert dump_ast(tree) == dump_ast(get_target_ast(source))

# Generated at 2022-06-18 00:58:38.499446
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source
    from ..utils.compare import compare_asts
    from ..utils.tree import get_node_by_path
    from ..utils.source import get_source_by_path

    source_ast = get_ast(source)
    expected_ast = get_ast(get_source_by_path('tests/samples/yield_from_expected.py'))
    transformer = YieldFromTransformer()
    new_ast = transformer.visit(source_ast)
    assert compare_asts(expected_ast, new_ast)
    assert transformer.tree_changed()

# Generated at 2022-06-18 00:58:42.875173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:58:43.845870
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:51.290155
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source


# Generated at 2022-06-18 00:58:55.898190
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import get_tree_string

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast("""
    def foo():
        yield from bar()
    """)
    print(get_tree_string(tree))
    Visitor().visit(tree)
    YieldFromTransformer().visit(tree)
    print(get_tree_string(tree))
    Visitor().visit(tree)

# Generated at 2022-06-18 00:58:56.842912
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:58:59.678890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        a = yield from bar()
        yield from baz()
        yield from qux
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:59:03.133811
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_ast(tree)