

# Generated at 2022-06-18 00:52:24.830421
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:26.980244
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:52:27.736932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-18 00:52:28.980408
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:52:29.741401
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:35.103157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import dump_ast
    from ..utils.tree import findall_by_type
    from ..utils.snippet import snippet_to_ast
    from ..utils.source import ast_to_source
    from ..utils.helpers import get_first_argument


# Generated at 2022-06-18 00:52:46.126554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:52:51.987280
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source, source_info
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast
    from ..utils.helpers import get_target_ast
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.helpers import assert_equal_files


# Generated at 2022-06-18 00:52:57.292919
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)._get_yield_from_index(None, None) is None
    assert YieldFromTransformer(None)._emulate_yield_from(None, None) is None
    assert YieldFromTransformer(None)._handle_assignments(None) is None
    assert YieldFromTransformer(None)._handle_expressions(None) is None
    assert YieldFromTransformer(None).visit(None) is None

# Generated at 2022-06-18 00:53:00.226732
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:06.628812
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:53:07.590539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None

# Generated at 2022-06-18 00:53:12.022840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        a = yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:19.626444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import ast_to_str
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_ast_from_source
    from ..utils.source import Source
    from ..utils.tree import ast_to_str
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_ast_from_source
    from ..utils.source import Source
    from ..utils.tree import ast_to_str
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_ast_from_source
    from ..utils.source import Source
    from ..utils.tree import ast_to_str
    from ..utils.visitor import NodeVisitor

# Generated at 2022-06-18 00:53:29.190015
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_without_imports
    from ..utils.source import get_source_without_decorators
    from ..utils.source import get_source_without_docstrings
    from ..utils.source import get_source_without_comments
    from ..utils.source import get_source_without_blank_lines
    from ..utils.source import get_source_without_imports_and_decorators
    from ..utils.source import get_source_without_imports_and_docstrings
    from ..utils.source import get_source_without_imports_and_comments
    from ..utils.source import get_source_without_imports_and_blank_lines

# Generated at 2022-06-18 00:53:31.665112
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:36.063922
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:36.827085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:40.100279
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:50.829594
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.helpers import compare_source
    from ..utils.helpers import get_source
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_node
    from ..utils.helpers import get_nodes
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_body

# Generated at 2022-06-18 00:54:07.050839
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.helpers import compare_source
    from ..utils.helpers import get_source

    tree = get_ast(get_code('yield_from.py'))
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    source = get_source(tree)
    print(source)
    compare_source(source, get_code('yield_from_compiled.py'))

# Generated at 2022-06-18 00:54:15.523132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast
    from ..utils.compare import compare_source

    source_ = source('''
    def foo():
        yield from bar()
    ''')
    expected_source = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')

    ast_ = get_ast(source_)
    print_ast(ast_)
    transformer = YieldFromTransformer()
    new_ast = transformer.visit(ast_)


# Generated at 2022-06-18 00:54:16.685989
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:22.364562
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    assert source == YieldFromTransformer().visit(tree)

# Generated at 2022-06-18 00:54:23.281764
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:26.878899
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    tree = get_ast("""
    def foo():
        yield from bar()
    """)
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:37.533932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_imports_and_docstrings
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines_and_comments
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines_and_comments_and_new_lines
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines

# Generated at 2022-06-18 00:54:48.883304
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_node

    source = Source("""
    def foo():
        yield from bar()
    """)

    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:54:50.002002
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:50.902900
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:22.018759
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def test():
        yield from [1, 2, 3]
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert transformer._tree_changed is True
    assert NodeVisitor().visit(tree) == "def test():\n    iterable = iter([1, 2, 3])\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            exc = exc.value\n            break\n"

# Generated at 2022-06-18 00:55:26.741424
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast, dump_ast

    tree = get_ast(source("""
        def foo():
            yield from bar()
    """))

    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:55:27.539056
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:55:30.515847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:35.054320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:36.238672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:45.906171
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator


# Generated at 2022-06-18 00:55:49.690952
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast

    source = source('''
    def func():
        a = yield from [1, 2, 3]
        b = yield from [4, 5, 6]
        yield from [7, 8, 9]
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    assert source == tree

# Generated at 2022-06-18 00:55:55.647544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    def foo():
        yield from bar()
    """
    expected = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """
    tree = parse_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_source(expected, new_tree)



# Generated at 2022-06-18 00:55:56.744787
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:56:57.251754
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:57:01.799468
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:57:10.812173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import dump_ast
    from ..utils.tree import find_all_nodes
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast, ast_to_source

    @snippet
    def test_snippet():
        let(a)
        a = yield from range(10)

    ast_ = source_to_ast(test_snippet)
    assert dump_ast(ast_) == test_snippet

    transformer = YieldFromTransformer()
    ast_ = transformer.visit(ast_)
    assert dump_ast(ast_) == test_snippet.replace('yield from', 'yield')


# Generated at 2022-06-18 00:57:12.367529
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:20.611627
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_source
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    source = Source("""
    def test():
        yield from range(10)
    """)

    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump_ast(tree))
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:57:31.296982
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func

# Generated at 2022-06-18 00:57:36.550298
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:57:38.802827
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:46.074591
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree
    from ..utils.source import get_source_from_node
    from ..utils.source import get_source_from_node_list
    from ..utils.source import get_source_from_node_list_list
    from ..utils.source import get_source_from_node_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list_list
    from ..utils.source import get_source_from_node_

# Generated at 2022-06-18 00:57:48.213959
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
    def foo():
        yield from bar()
    ''')
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:01.133021
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)


# Generated at 2022-06-18 01:00:08.809114
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_source_with_code_and_ast
    from ..utils.test_utils import assert_equal_code_with_

# Generated at 2022-06-18 01:00:09.385576
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:10.002517
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:10.587242
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:17.305233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import dump_visitor
    from ..utils.compiler import compile

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    dump_visitor(tree)
    tree = YieldFromTransformer().visit(tree)
    dump_visitor(tree)
    dump(tree)
    compile(tree, source.path, source.mode)

# Generated at 2022-06-18 01:00:17.762681
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:18.366092
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:19.755410
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.helpers import compare_asts
    from ..utils.helpers import print_ast


# Generated at 2022-06-18 01:00:22.120607
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)