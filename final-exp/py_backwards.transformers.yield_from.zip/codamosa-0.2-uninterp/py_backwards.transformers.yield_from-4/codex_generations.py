

# Generated at 2022-06-18 00:52:27.920790
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:33.208247
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    dump_ast(new_tree)
    assert transformer._tree_changed
    assert get_source_for_node(new_tree) == source

# Generated at 2022-06-18 00:52:34.089157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:52:39.538161
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    visitor.visit(tree)

# Generated at 2022-06-18 00:52:46.894116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.compare import compare_asts

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)

    dump_ast(new_tree)

    assert compare_asts(
        Source("""
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """), new_tree)




# Generated at 2022-06-18 00:52:47.491540
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:52:54.341793
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(code)
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:52:59.287839
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import dump

    code = '''
    def f():
        a = yield from [1, 2, 3]
        b = yield from [1, 2, 3]
        yield from [1, 2, 3]
        yield from [1, 2, 3]
    '''
    tree = parse(code)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:53:08.984380
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump_ast(tree))
    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise AssertionError("YieldFrom node is not expected")
    Visitor().visit(tree)

# Generated at 2022-06-18 00:53:16.793847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_source

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            assert node.value.id == 'a'
            assert node.value.ctx == ast.Load()

    source = Source("""
    def foo():
        yield from a
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:53:24.250486
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:30.668404
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_imports_and_docstrings
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines_and_comments
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines_and_comments_and_newlines
    from ..utils.helpers import get_code_without_imports_and_docstrings_and_blank_lines_and_

# Generated at 2022-06-18 00:53:38.060895
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node_at
    from ..utils.test_utils import get_ast_node_type_at
    from ..utils.test_utils import get_ast_node_name_at
    from ..utils.test_utils import get_ast_node_attr_at
    from ..utils.test_utils import get_ast_node_attr_value_at
    from ..utils.test_utils import get_ast_node_attr_type_at
    from ..utils.test_utils import get_ast_node_attr_name_at
    from ..utils.test_utils import get_ast_node_attr_value_at
    from ..utils.test_utils import get_ast_

# Generated at 2022-06-18 00:53:44.264074
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    @snippet
    def test():
        let(a)
        a = yield from range(10)

    tree = get_ast(test)
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    print(get_source(tree))



# Generated at 2022-06-18 00:53:51.231602
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert get_source_from_ast(tree) == source
    assert dump(tree) == dump(get_ast(source))

# Generated at 2022-06-18 00:53:53.021680
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:53.960777
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:03.711443
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code

# Generated at 2022-06-18 00:54:11.237711
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = Source("""
    def foo():
        yield from bar()
        yield from baz()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:17.799187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import ast_to_source
    from ..utils.helpers import get_ast_node_name
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.helpers import get_ast_node_name
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.helpers import get_ast_node_name
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.helpers import get_ast_node_name
    from ..utils.source import source_to_ast

# Generated at 2022-06-18 00:54:24.293413
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:54:24.822876
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:27.297363
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import dump_visitor


# Generated at 2022-06-18 00:54:28.957549
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:37.664098
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import parse_ast
    from ..utils.helpers import dump_ast
    from ..utils.source import source

    code = source('''
    def foo():
        yield from bar()
    ''')
    tree = parse_ast(code)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert dump_ast(tree) == source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')

# Generated at 2022-06-18 00:54:39.274224
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:40.985946
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:43.395294
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:54:51.780711
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    # Unit test for constructor of class YieldFromTransformer
    def test_YieldFromTransformer():
        from ..utils.helpers import get_ast
        from ..utils.source import Source
        from ..utils.tree import print_tree
        from ..utils.visitor import NodeVisitor
        from ..utils.snippet import snippet
        from ..utils.helpers import VariablesGenerator

        @snippet
        def test_snippet():
            def generator():
                yield 1
                yield 2

            yield from generator()

        source = Source

# Generated at 2022-06-18 00:54:56.881961
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree

    source = """
    def foo():
        yield from bar()
    """
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:55:14.216116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump_ast(tree))

# Generated at 2022-06-18 00:55:15.570867
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:55:23.773721
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code
    from ..utils.test_utils import assert_equal_ast_with_ast
    from ..utils.test_utils import assert_equal_source_with_ast

# Generated at 2022-06-18 00:55:31.106380
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast

    source = '''
    def foo():
        a = yield from bar()
        yield from bar()
    '''
    expected = '''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                a = exc.value
                break
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    '''
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    assert expected == source

# Generated at 2022-06-18 00:55:40.803470
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            self.generic_visit(node)
            return node

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    visitor = TestVisitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:55:45.124130
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source

    tree = get_ast(source("""
        def foo():
            yield from bar()
    """))

    transformer = YieldFromTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:55:49.990544
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import dump
    from ..utils.tree import get_ast

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    Visitor().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:56.102001
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_with_offset
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_with_offset_with_exc_cls
    from ..utils.test_utils import assert_equal_code_with

# Generated at 2022-06-18 00:56:01.064052
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_for_node
    from ..utils.source import get_source_for_node_list
    from ..utils.source import get_source_for_node_list_list
    from ..utils.source import get_source_for_node_list_list_list
    from ..utils.source import get_source_for_node_list_list_list_list
    from ..utils.source import get_source_for_node_list_list_list_list_list
    from ..utils.source import get_source_for_node_list_list_list_list_list_list
    from ..utils.source import get_source_for_node_list_list

# Generated at 2022-06-18 00:56:01.922867
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:37.088657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:37.861614
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:38.680286
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:43.044309
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert transformer.tree_changed() is True

# Generated at 2022-06-18 00:56:43.888643
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:46.168920
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:55.910143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_ast_equal
    from ..utils.testing import assert_source_equal
    from ..utils.testing import assert_source_not_equal
    from ..utils.testing import assert_source_equal_to_file
    from ..utils.testing import assert_source_not_equal_to_file
    from ..utils.testing import assert_source_equal_to_file_with_options
    from ..utils.testing import assert_source_not_equal_to_file_with_options
    from ..utils.testing import assert_source_equal_to_file_with_options_and_args
    from ..utils.testing import assert_source_not_equal_to_file_with_options_and_args
    from ..utils.testing import assert_source_equal_to_file_with_args

# Generated at 2022-06-18 00:57:03.010970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            return node

    tree = get_ast('yield_from.py')
    visitor = TestVisitor()
    visitor.visit(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:11.376028
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet_to_str

    snippet_to_str(result_assignment)
    snippet_to_str(yield_from)

    code = '''
    def foo():
        yield from bar()
    '''
    tree = parse(code)
    YieldFromTransformer().visit(tree)
    assert ast_to_str(tree) == '''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    '''


# Generated at 2022-06-18 00:57:12.413233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:18.724722
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:22.874066
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_tree(new_tree)



# Generated at 2022-06-18 00:58:29.921889
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_source_with_comments
    from ..utils.test_utils import assert_equal_source_with_comments_and_spaces
    from ..utils.test_utils import assert_equal_source_with_spaces
    from ..utils.test_utils import assert_equal_source_with_spaces_and_comments
    from ..utils.test_utils import assert_equal_source_with_spaces_and_comments_and_newlines
    from ..utils.test_utils import assert_equal_source_with_spaces_and_newlines
    from ..utils.test_utils import assert_equal_

# Generated at 2022-06-18 00:58:38.100170
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet

    source = Source("""
    def f():
        a = yield from g()
        yield from h()
        yield from i()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed

    class Visitor(NodeVisitor):
        def visit_FunctionDef(self, node):
            assert node.name == 'f'
            assert len(node.body) == 3
            assert isinstance(node.body[0], ast.Assign)

# Generated at 2022-06-18 00:58:39.194592
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:58:41.183884
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:58:48.344526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:58:52.225818
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
        b = yield from bar()
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:58:52.888350
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:58:57.989729
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')

# Generated at 2022-06-18 01:01:03.113144
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.compare import compare_source
    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    compare_source(dump_ast(tree), """
    def f():
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)

# Generated at 2022-06-18 01:01:04.595414
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:05.096978
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:06.190110
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:15.474060
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_with_offset
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_with_offset_with_exc_cls
    from ..utils.test_utils import assert_equal_code_with

# Generated at 2022-06-18 01:01:16.110445
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:22.097298
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast, get_code
    from ..utils.visitor import print_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    print_ast(tree)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_ast(new_tree)
    assert get_code(new_tree) == source.replace('yield from', 'for _ in')

# Generated at 2022-06-18 01:01:23.159783
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:23.919857
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:01:33.336263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.snippet import snippet
    from ..utils.compare import compare_source
    from ..utils.helpers import get_ast_from_source

    @snippet
    def source():
        def f():
            yield from g()
            yield from h()

    @snippet
    def expected():
        def f():
            let(iterable)
            iterable = iter(g())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
            let(iterable)
            iterable = iter(h())