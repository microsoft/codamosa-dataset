

# Generated at 2022-06-18 00:52:29.673845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_func

    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump(tree)
    func = get_func(tree, 'foo')
    assert len(func.body) == 3
    assert isinstance(func.body[0], ast.Assign)
    assert isinstance(func.body[1], ast.While)
    assert isinstance(func.body[2], ast.While)

# Generated at 2022-06-18 00:52:38.714056
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_ast
    from ..utils.source import get_source
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer

# Generated at 2022-06-18 00:52:46.282940
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet
    from ..utils.tree import get_node_at
    from ..utils.helpers import VariablesGenerator

    source = Source("""
    def test(x):
        yield from x
    """)
    tree = get_ast(source)
    node = get_node_at(tree, "def test(x):")
    exc = VariablesGenerator.generate('exc')

# Generated at 2022-06-18 00:52:48.376355
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.helpers import compare_source


# Generated at 2022-06-18 00:52:58.748977
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_transformed_code
    assert_transformed_code(
        YieldFromTransformer,
        """
        def foo():
            yield from bar()
        """,
        """
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """,
    )


# Generated at 2022-06-18 00:53:06.255542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.helpers import get_func_body

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    func = get_func_body(tree, 'visit')
    YieldFromTransformer().visit(func)
    print(dump(func))

# Generated at 2022-06-18 00:53:13.657264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def f():
        yield from g()
    """)

    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert node.test.id == 'True'
            assert node.body[0].value.func.id == 'next'
            assert node.body[0].value.args[0].id == 'iterable'
            assert node.body[0].value.keywords[0].arg == 'exc'
            assert node.body[0].value.key

# Generated at 2022-06-18 00:53:17.344380
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    source = source('''
    def foo():
        a = yield from bar()
        yield from bar()
    ''')
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    assert source == compile(tree, '<test>', 'exec').co_consts[0]

# Generated at 2022-06-18 00:53:28.589166
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_ast_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code
    from ..utils.test_utils import assert_equal_source_with_ast

# Generated at 2022-06-18 00:53:36.721450
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert dump(tree) == dump(get_ast(Source("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)))

    source = Source("""
    def foo():
        a = yield from bar()
    """)
    tree = get_ast(source)
   

# Generated at 2022-06-18 00:53:48.236819
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
    ''')
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:49.668187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:58.138038
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.snippet import snippet
    from ..utils.tree import insert_at
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    from typing import Optional, List, Type, Union
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    YieldFromTransformer()


# Generated at 2022-06-18 00:53:59.828099
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:00.779563
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:54:01.698934
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:05.299682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    assert YieldFromTransformer().visit(tree) is not None

# Generated at 2022-06-18 00:54:11.238558
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print(dump_ast(tree))
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:54:15.490852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.compare import compare_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    dump(tree)
    print(compare_ast(tree, get_ast(source)))

# Generated at 2022-06-18 00:54:16.430049
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:37.638303
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_re
    from ..utils.test_utils import assert_equal_code_with_exception_re
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg_re
    from ..utils.test_utils import assert_equal_code_with

# Generated at 2022-06-18 00:54:39.273574
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:49.557934
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_source_with_exception

    # Test for method _get_yield_from_index
    def test_get_yield_from_index():
        from ..utils.test_utils import assert_equal_int
        from ..utils.test_utils import assert_equal_none
        from ..utils.test_utils import assert_equal_type
        from ..utils.test_utils import assert_equal_ast
        from ..utils.test_utils import assert_equal_source

# Generated at 2022-06-18 00:54:55.893644
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    print(get_source_from_ast(tree))

# Generated at 2022-06-18 00:54:56.638292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:57.353573
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:00.813716
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:01.761230
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:09.646739
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    import astunparse

    source = Source("""
    def foo():
        a = yield from bar()
        b = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_tree(new_tree)
    print(astunparse.unparse(new_tree))

# Generated at 2022-06-18 00:55:10.983986
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:36.163253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:55:41.424875
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree

    source = source_to_unicode('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_tree(new_tree)

# Generated at 2022-06-18 00:55:49.666060
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.helpers import get_node_type
    from ..utils.helpers import get_node_name
    from ..utils.helpers import get_node_lineno
    from ..utils.helpers import get_node_col_offset
    from ..utils.helpers import get_node_end_lineno
    from ..utils.helpers import get_node_end_col_offset
    from ..utils.helpers import get_node_ctx
    from ..utils.helpers import get_node_value
    from ..utils.helpers import get_node_body
    from ..utils.helpers import get_node_orelse
    from ..utils.helpers import get_node_final

# Generated at 2022-06-18 00:55:50.394619
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:51.091822
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:51.860596
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:55.992837
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def f():
        a = yield from b
        yield from c
        yield from d
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:56.780569
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:57.425690
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:07.237878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    @snippet
    def test_snippet():
        let(x)
        x = yield from range(10)

    @snippet
    def expected_snippet():
        let(x)
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    x = exc.value
                break

    ast_ = get_ast(test_snippet)
    expected_ast = get_

# Generated at 2022-06-18 00:56:55.963200
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_without_imports
    from ..utils.helpers import get_code_without_imports_and_docstrings
    from ..utils.helpers import assert_equal_code
    from ..utils.helpers import assert_equal_ast
    from ..utils.helpers import assert_equal_code_with_exception
    from ..utils.helpers import assert_equal_ast_with_exception
    from ..utils.helpers import assert_equal_code_with_exception_msg
    from ..utils.helpers import assert_equal_ast_with_exception_msg
    from ..utils.helpers import assert_not_equal_code
    from ..utils.helpers import assert_not_

# Generated at 2022-06-18 00:57:07.268927
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_func_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    ast_ = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(ast_)
    print(dump_ast(ast_))

# Generated at 2022-06-18 00:57:11.923764
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_node_as_string
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import get_ast_from_code


# Generated at 2022-06-18 00:57:13.010955
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:23.018136
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_module

    assert_equal_ast(
        parse_to_ast("""
        def foo():
            yield from bar()
        """),
        parse_to_ast("""
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """)
    )


# Generated at 2022-06-18 00:57:28.139018
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:57:28.965070
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:37.560162
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_target_ast
    from ..utils.helpers import get_target_source

    source = Source("""
    def func():
        a = yield from range(10)
        b = yield from range(10)
    """)


# Generated at 2022-06-18 00:57:39.329807
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:40.090164
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:02.818928
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-18 00:59:10.639573
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast

# Generated at 2022-06-18 00:59:17.598136
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.visitor import print_ast
    from ..utils.compiler import compile_snippets
    from ..utils.tree import find_all_subclasses
    from ..utils.helpers import get_func_ast

    compile_snippets()

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:59:18.093160
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:18.895162
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:28.316456
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    @snippet
    def test_yield_from():
        let(a)
        a = yield from range(10)
        print(a)

    @snippet
    def test_yield_from_in_loop():
        let(a)
        while True:
            a = yield from range(10)
            print(a)

    @snippet
    def test_yield_from_in_loop_with_try():
        let(a)

# Generated at 2022-06-18 00:59:33.216692
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    visitor = NodeTransformerVisitor(transformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:59:35.032231
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import dump_ast

# Generated at 2022-06-18 00:59:35.773999
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:59:42.153780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.helpers import get_func_body

    source = Source("""
    def f():
        a = yield from b
        yield from c
    """)

    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    dump(tree)

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert node.body[0].value.func.id == 'next'
            assert node.body[0].value.args[0].id == 'iterable'

    Visitor().visit(tree)