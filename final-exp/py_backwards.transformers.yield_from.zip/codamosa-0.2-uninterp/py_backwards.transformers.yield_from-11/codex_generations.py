

# Generated at 2022-06-18 00:52:27.905970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:29.132186
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:35.718032
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    print_visitor(YieldFromTransformer(), tree)
    compare_source(source, tree)

# Generated at 2022-06-18 00:52:46.093396
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree
    from ..utils.source import get_source_from_node
    from ..utils.source import get_source_from_node_list
    from ..utils.source import get_source_from_node_list_list
    from ..utils.source import get_source_from_node_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list
    from ..utils.source import get_source_from_node_list_list_list_list_list
    from ..utils.source import get_source_from_node_

# Generated at 2022-06-18 00:52:51.960803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            self.result = node

    source = source_to_unicode('''
    def test():
        yield from range(10)
    ''')
    tree = get_ast(source)
    visitor = TestVisitor()
    visitor.visit(tree)
    assert isinstance(visitor.result, ast.YieldFrom)

    transformer = YieldFromTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:52:56.968081
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
        yield from bar()
    """))
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:01.323472
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast('yield_from.py')
    print_tree(tree)
    Visitor().visit(tree)

    tree = YieldFromTransformer().visit(tree)
    print_tree(tree)
    Visitor().visit(tree)

# Generated at 2022-06-18 00:53:11.018257
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree

# Generated at 2022-06-18 00:53:15.226429
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    src = source('''
    def f():
        yield from g()
    ''')
    tree = get_ast(src)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:17.878187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast_from_source
    from ..utils.test_utils import get_source_from_ast


# Generated at 2022-06-18 00:53:24.526320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:53:29.216142
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast, get_code
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    @snippet
    def test_snippet():
        let(a)
        a = yield from range(10)

    tree = get_ast(test_snippet.get_body())
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    print(get_code(tree))

# Generated at 2022-06-18 00:53:35.532463
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree

    source = source_to_unicode('''
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
        yield from bar()
    ''')
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:53:36.330066
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:37.062986
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:39.201258
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_target_ast


# Generated at 2022-06-18 00:53:40.453546
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:41.336239
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:42.558277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:52.248196
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_source
    from ..utils.helpers import get_code
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_source
    from ..utils.helpers import get_code
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_source
    from ..utils.helpers import get_code
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_source
    from ..utils.helpers import get_code
    from ..utils.helpers import get_tree

# Generated at 2022-06-18 00:54:13.657219
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_lines
    from ..utils.testing import assert_equal_tokens
    from ..utils.testing import assert_equal_token_values
    from ..utils.testing import assert_equal_token_kinds
    from ..utils.testing import assert_equal_token_positions
    from ..utils.testing import assert_equal_token_end_positions
    from ..utils.testing import assert_equal_token_full_positions
    from ..utils.testing import assert_equal_token_full_end_positions
    from ..utils.testing import assert_equal_token_lines
   

# Generated at 2022-06-18 00:54:25.060755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compiler import compile_snippets
    from ..utils.helpers import get_func
    from ..utils.source import Source
    from ..utils.tree import print_tree

    compile_snippets()

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)
    func = get_func(tree, 'foo')
    assert func.body[0].value.func.id

# Generated at 2022-06-18 00:54:28.053365
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = '''
    def f():
        yield from g()
    '''
    expected = '''
    def f():
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    '''
    tree = parse_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert_equal_source(tree, expected)

# Generated at 2022-06-18 00:54:30.635320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse_ast
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:54:36.073323
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = """
    def foo():
        yield from bar()
    """
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    assert source(tree) == """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """

    code = """
    def foo():
        yield from bar()
    """
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-18 00:54:45.164817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:46.105285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:47.935184
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None

# Generated at 2022-06-18 00:54:58.360598
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:55:07.904477
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with_lineno_msg_with_offset
    from ..utils.test_utils import assert_equal_code_with_exception_msg_with

# Generated at 2022-06-18 00:55:31.450356
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:41.050704
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert dump(tree) == dump(get_ast(Source("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)))

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)

# Generated at 2022-06-18 00:55:45.380625
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:55:48.683426
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:55:54.641026
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node: ast.YieldFrom) -> None:
            print(node)

    tree = get_ast('''
    def foo():
        yield from bar()
        yield from baz()
        yield from qux()
    ''')
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    Visitor().visit(tree)

# Generated at 2022-06-18 00:56:00.450514
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:56:08.264765
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import ast_to_source

# Generated at 2022-06-18 00:56:10.176112
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:17.411307
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code

# Generated at 2022-06-18 00:56:26.865767
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast
    from ..utils.compare import compare_source

    source = source('''
    def foo():
        yield from bar()
    ''')
    expected = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    assert compare_source(dump(tree), expected)

# Generated at 2022-06-18 00:57:14.753559
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:17.161163
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:57:17.919535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:29.061328
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_regex
    from ..utils.test_utils import assert_equal_code_with_exception_regex
    from ..utils.test_utils import assert_equal_code_with_exception_type
    from ..utils.test_utils import assert_equal_code_with_exception_type_msg

# Generated at 2022-06-18 00:57:36.410992
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_node
    from ..utils.source import get_source_from_ast_node
    from ..utils.source import get_source_from_node_ast

    source = get_source(YieldFromTransformer)
    ast_ = get_ast(source)
    node = ast_.body[0]
    assert get_source_from_ast(ast_) == source
    assert get_source_from_node(node) == source
    assert get_source_from_ast_node(ast_, node) == source

# Generated at 2022-06-18 00:57:45.471706
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_asts
    from ..utils.snippet import snippet

    source = source('''
        def foo():
            yield from bar()
    ''')
    expected = source('''
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
    ''')
    ast1 = get_ast(source)
    ast2 = get_ast(expected)
    transformer = YieldFromTransformer()
    transformer.visit

# Generated at 2022-06-18 00:57:50.148323
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_to_ast
    from ..utils.test_utils import parse_to_source
    from ..utils.test_utils import parse_to_func
    from ..utils.test_utils import parse_to_module
    from ..utils.test_utils import parse_to_class
    from ..utils.test_utils import parse_to_stmt
    from ..utils.test_utils import parse_to_expr
    from ..utils.test_utils import parse_to_name
    from ..utils.test_utils import parse_to_num
    from ..utils.test_utils import parse_to_arg
    from ..utils.test_utils import parse_to_arguments

# Generated at 2022-06-18 00:57:50.882943
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:55.369388
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compat import StringIO


# Generated at 2022-06-18 00:57:56.121566
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:48.626330
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_

# Generated at 2022-06-18 01:00:58.340337
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet, let, extend

    @snippet
    def test_yield_from():
        let(a)
        a = yield from range(10)
        print(a)

    @snippet
    def test_yield_from_in_function():
        def foo():
            let(a)
            a = yield from range(10)
            print(a)

    @snippet
    def test_yield_from_in_function_with_args():
        def foo(a):
            let(b)
            b = yield from range(a)
            print(b)


# Generated at 2022-06-18 01:01:08.652923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_code
    from ..utils.source import source

    code = source('''
    def foo():
        yield from bar()
    ''')
    expected = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')
    assert_equal_code(YieldFromTransformer, code, expected)

    code = source('''
    def foo():
        yield from bar()
        yield from baz()
    ''')

# Generated at 2022-06-18 01:01:16.969947
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code

# Generated at 2022-06-18 01:01:24.414503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 01:01:33.872778
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert node.test.id == 'True'
            assert node.body[0].value.func.id == 'next'
            assert node.body[0].value.args[0].id == 'iterable'
            assert node.body[1].test.id == 'True'

# Generated at 2022-06-18 01:01:42.047377
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.ast_helpers import get_node_name, get_node_type
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_line
    from ..utils.source import get_source_lines
    from ..utils.source import get_source_column
    from ..utils.source import get_source_columns
    from ..utils.source import get_source_range
    from ..utils.source import get_source_ranges
    from ..utils.source import get_source_range_by_node
    from ..utils.source import get_source_ranges_by_node
    from ..utils.source import get_source_range_by_nodes
    from ..utils.source import get_source

# Generated at 2022-06-18 01:01:48.159602
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump_ast(tree))
    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise Exception("YieldFrom node should be removed")
    Visitor().visit(tree)

# Generated at 2022-06-18 01:01:56.605996
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.helpers import compare_asts
    from ..utils.helpers import get_function_ast
    from ..utils.helpers import get_function_body_ast
    from ..utils.helpers import get_function_body_source
    from ..utils.helpers import get_function_source
    from ..utils.helpers import get_source
    from ..utils.helpers import get_tree
    from ..utils.helpers import get_tree_source
    from ..utils.helpers import get_tree_source_without_imports
    from ..utils.helpers import get_tree_source_without_imports_and_docstrings
    from ..utils.helpers import get_tree_source_without_module_docstring
    from ..utils.helpers import get_tree_source

# Generated at 2022-06-18 01:02:03.916890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source
    from ..utils.compare import compare_ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    source_ = source('''
    def foo():
        yield from bar()
    ''')
    expected_ = source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')
    tree = get_ast(source_)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    assert compare_ast(ast_to_str(new_tree), expected_)