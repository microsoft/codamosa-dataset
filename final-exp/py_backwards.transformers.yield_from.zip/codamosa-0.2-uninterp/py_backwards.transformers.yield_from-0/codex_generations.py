

# Generated at 2022-06-18 00:52:30.994689
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import get_snippet
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    print(get_snippet(tree))

# Generated at 2022-06-18 00:52:36.324994
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source

    source = Source("""
    def func():
        a = yield from b
        yield from c
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-18 00:52:46.126814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_func_body

    source = Source("""
    def foo():
        a = yield from bar()
        yield from baz()
        yield from qux()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)

    func_body = get_func_body(tree)
    assert len(func_body) == 5
    assert isinstance(func_body[0], ast.Assign)
    assert isinstance(func_body[1], ast.While)
    assert isinstance(func_body[2], ast.While)
    assert isinstance

# Generated at 2022-06-18 00:52:46.900861
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:51.167464
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_target_version
    from ..utils.helpers import get_target_version
    from ..utils.helpers import get_target_version
    from ..utils.helpers import get_target_version

    source = Source("""
    def foo():
        x = yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer(get_target_version(3, 2))
    transformer.visit(tree)

# Generated at 2022-06-18 00:52:59.602096
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source


# Generated at 2022-06-18 00:53:05.932440
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:53:06.990202
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:14.965778
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(YieldFromTransformer,
                          'def f():\n'
                          '    yield from g()',
                          'def f():\n'
                          '    let(iterable)\n'
                          '    iterable = iter(g())\n'
                          '    while True:\n'
                          '        try:\n'
                          '            yield next(iterable)\n'
                          '        except StopIteration as exc:\n'
                          '            break')

# Generated at 2022-06-18 00:53:15.767871
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:24.437954
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:53:25.255371
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:29.287310
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump


# Generated at 2022-06-18 00:53:35.089172
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    ast_tree = get_ast(source)
    YieldFromTransformer().visit(ast_tree)
    print_tree(ast_tree)
    NodeVisitor().visit(ast_tree)

# Generated at 2022-06-18 00:53:45.155608
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print(dump_ast(tree))
    assert transformer.tree_changed is True
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0], ast.While)
    assert isinstance(tree.body[0].body[0].body[0], ast.Expr)

# Generated at 2022-06-18 00:53:45.791750
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:48.613349
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:53:57.176717
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.tree import dump
    from ..utils.visitor import dump_visitor
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    dump(tree)
    print(dump_visitor(tree))
    print(get_source(tree))

    source = snippet.get_source(yield_from)
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    dump(tree)
    print(dump_visitor(tree))
    print(get_source(tree))

# Generated at 2022-06-18 00:54:05.682847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    print_visitor(YieldFromTransformer(), tree)
    compare_source(YieldFromTransformer(), source, """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)

# Generated at 2022-06-18 00:54:06.949725
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:27.547006
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = """
    def foo():
        yield from bar()
    """
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert get_source(tree) == """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """

# Generated at 2022-06-18 00:54:35.008212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree

    source = source_to_unicode('''
    def foo(a):
        b = yield from a
        c = yield from a
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:41.134536
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:41.997074
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:44.220357
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:52.820677
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree

# Generated at 2022-06-18 00:54:54.862030
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:03.583679
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:55:08.130758
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.compare import compare_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    assert compare_source(YieldFromTransformer, tree)

# Generated at 2022-06-18 00:55:12.849840
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
    def foo():
        yield from bar()
    """))

    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:55:45.418397
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            return node

    tree = get_ast(source("""
    def foo():
        yield from bar()
    """))
    visitor = Visitor()
    visitor.visit(tree)
    assert visitor.nodes == [tree.body[0].body[0].value]

    tree = get_ast(source("""
    def foo():
        a = yield from bar()
    """))
    visitor = Visitor()
    visitor.visit(tree)
    assert visitor.nodes == [tree.body[0].body[0].value]


# Generated at 2022-06-18 00:55:51.375405
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .yield_from import YieldFromTransformer
    from ..utils.tree import ast_to_str
    from ..utils.helpers import VariablesGenerator
    import ast
    import sys
    import os
    import io
    import unittest
    import textwrap
    import contextlib
    import typing
    import copy
    import astunparse
    import astor
    import astpretty
    import asttokens
    import typed_ast.ast3 as typed_ast
    import typed_astunparse
    import typed_astor
    import typed_astpretty
    import typed_asttokens
    import typed_ast.ast3 as typed_ast
    import typed_astunparse
    import typed_astor
    import typed_astpretty
    import typed_asttok

# Generated at 2022-06-18 00:55:52.137444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:59.221531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_node
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_code_with_node
    from ..utils.test_utils import assert_equal_code_with_source_and_ast
    from ..utils.test_utils import assert_equal_code_with_source_and_node
    from ..utils.test_utils import assert_equal_code_with_ast_and_node
    from ..utils.test_utils import assert_equal_

# Generated at 2022-06-18 00:56:03.675438
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:56:10.082615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.compare import compare_source
    from ..utils.snippet import snippet

    @snippet
    def source():
        def foo():
            yield from bar()

    @snippet
    def expected():
        def foo():
            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break

    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:56:10.858445
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:17.037913
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import NodeTransformerPass
    from ..utils.helpers import dump_ast

    source_code = source('''
    def foo():
        yield from bar()
    ''')
    tree = ast.parse(source_code)
    pass_ = NodeTransformerPass(YieldFromTransformer)
    pass_.visit(tree)
    assert dump_ast(tree) == source('''
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')

# Generated at 2022-06-18 00:56:18.109011
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:20.199368
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:17.339827
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:57:18.183292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:18.946718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:24.581012
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    tree = get_ast(source("""
    def foo():
        yield from bar()
    """))

    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:26.566482
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:32.982973
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_transformed

    assert_transformed(
        YieldFromTransformer,
        """
        def f():
            yield from g()
        """,
        """
        def f():
            let(iterable)
            iterable = iter(g())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        exc = exc.value
                    break
        """,
    )


# Generated at 2022-06-18 00:57:37.621689
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_target_version
    from ..utils.helpers import get_target_version

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer(get_target_version(3, 2))
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:57:42.135299
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    dump_ast(tree)

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert isinstance(node.body, list)
            assert len(node.body) == 1
            assert isinstance(node.body[0], ast.Expr)
            assert isinstance(node.body[0].value, ast.Yield)

# Generated at 2022-06-18 00:57:48.474730
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_source

    source = '''
    def f():
        a = yield from g()
        yield from h()
        yield from i()
    '''

# Generated at 2022-06-18 00:57:54.147188
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def f():
        a = yield from b
        yield from c
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:08.944913
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree


# Generated at 2022-06-18 01:00:17.102843
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.helpers import get_func
    from ..utils.helpers import get_func_ast


# Generated at 2022-06-18 01:00:17.771425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:22.944607
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast, compare_asts


# Generated at 2022-06-18 01:00:28.914598
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    dump(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump(tree)

# Generated at 2022-06-18 01:00:35.676021
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import Source
    from ..utils.helpers import get_ast

    source = Source("""
    def foo():
        a = yield from bar()
        yield from bar()
        yield from bar()
        b = yield from bar()
        yield from bar()
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    assert source.count('yield from') == 0
    assert source.count('yield') == 6
    assert source.count('next') == 3
    assert source.count('iter') == 3
    assert source.count('StopIteration') == 3
    assert source.count('exc') == 3
    assert source.count('a = exc.value')

# Generated at 2022-06-18 01:00:36.221501
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:40.547202
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.typing import get_type_hints
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def f():
        a = yield from g()
        b = yield from h()
        yield from i()
    """)
    tree = get_ast(source)
    assert get_type_hints(tree) == {}
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-18 01:00:48.832099
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse, dump
    from ..utils.tree import find_all
    from ..utils.snippet import snippet

    @snippet
    def code():
        def foo():
            yield from bar()

    tree = parse(code)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert dump(tree) == dump(parse(code))

    @snippet
    def code():
        def foo():
            yield from bar()
            yield from baz()

    tree = parse(code)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert dump(tree) == dump(parse(code))


# Generated at 2022-06-18 01:00:56.990420
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    print(get_source_from_tree(tree))
    print(get_source_from_ast(tree))
