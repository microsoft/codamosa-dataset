

# Generated at 2022-06-18 00:52:29.563735
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.compiler import compile_snippets

    compile_snippets()

    source = Source("""
    def f():
        yield from g()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump(tree)

    class Visitor(NodeVisitor):
        def visit_While(self, node):
            assert isinstance(node.test, ast.Name)
            assert node.test.id == 'True'

    visitor = Visitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:52:38.596726
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to

# Generated at 2022-06-18 00:52:46.253829
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source


# Generated at 2022-06-18 00:52:49.229234
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:52:50.594677
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:54.000764
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    source = get_source_from_ast(tree)
    print(source)
    print(dump_ast(tree))

# Generated at 2022-06-18 00:53:01.160820
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source_without_imports
    from ..utils.source import get_source_without_decorators
    from ..utils.source import get_source_without_imports_and_decorators
    from ..utils.source import get_source_without_docstrings
    from ..utils.source import get_source_without_imports_and_docstrings
    from ..utils.source import get_source_without_decorators_and_docstrings
    from ..utils.source import get_source_without_imports_decorators_and_docstrings
    from ..utils.source import get_source_without_blank_lines
    from ..utils.source import get_

# Generated at 2022-06-18 00:53:02.387699
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:05.735236
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_func_body

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    func = get_func_body(tree, 'foo')
    transformer = YieldFromTransformer()
    transformer.visit(func)
    print_tree(func)

# Generated at 2022-06-18 00:53:14.155244
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.helpers import get_target_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    target = Source("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)
    target_ast = get_target_ast(target)
    assert dump_ast(tree)

# Generated at 2022-06-18 00:53:27.781992
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)
    compare_source(Source(tree), source)

# Generated at 2022-06-18 00:53:29.431882
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:30.270679
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:35.623560
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
        def foo():
            a = yield from bar()
            yield from baz()
            yield from qux()
    ''')
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:53:37.786239
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.helpers import get_target_ast


# Generated at 2022-06-18 00:53:40.019803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:41.034792
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:51.479595
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source
    from ..utils.test_utils import assert_equal_code_with_code
    from ..utils.test_utils import assert_equal_source_with_ast
    from ..utils.test_utils import assert_equal_code_with_ast
    from ..utils.test_utils import assert_equal_ast_with_source
    from ..utils.test_utils import assert_equal_ast_with_code

# Generated at 2022-06-18 00:53:53.258926
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:03.246159
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.compare import compare_source
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.source import get_source
    from ..utils.compare import compare_source
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.source import get_source
    from ..utils.compare import compare_source
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at

# Generated at 2022-06-18 00:54:19.744059
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_tree

    source = get_source(YieldFromTransformer)
    tree = get_tree(YieldFromTransformer)
    func = get_func(YieldFromTransformer)
    ast_ = get_ast(YieldFromTransformer)

    assert_equal_source(YieldFromTransformer, source)
    assert_equal_source(tree, source)
    assert_equal_source(func, source)
    assert_equal_source(ast_, source)


# Generated at 2022-06-18 00:54:20.726523
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:25.275310
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.visitor import dump_visitor

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    tree = dump_visitor(YieldFromTransformer, tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:29.051066
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    code = source('''
    def foo(bar):
        yield from bar
    ''')
    tree = get_ast(code)
    tree = YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:30.317381
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:36.395372
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeTransformerVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    visitor = NodeTransformerVisitor(YieldFromTransformer())
    visitor.visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:38.033688
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:48.989207
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    assert dump(tree) == dump(get_ast(Source("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """)))


# Generated at 2022-06-18 00:54:52.808443
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    print_tree(tree)
    assert tree is not None

# Generated at 2022-06-18 00:54:54.648587
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:55:28.978552
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.helpers import get_target_version
    from ..utils.source import get_source
    from ..utils.helpers import get_target_version
    from ..utils.source import get_source
    from ..utils.helpers import get_target_version
    from ..utils.source import get_source
    from ..utils.helpers import get_target_version
    from ..utils.source import get_source
    from ..utils.helpers import get_target_version
    from ..utils.source import get_source
    from ..utils.helpers import get_target_version
    from ..utils.source import get_source
    from ..utils.helpers import get_target_version

# Generated at 2022-06-18 00:55:36.754423
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_without_imports
    from ..utils.source import get_source_without_imports_and_docstrings

    source = get_source_without_imports_and_docstrings(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    source = get_source(tree)
    print(source)

# Generated at 2022-06-18 00:55:46.320563
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        a = yield from bar()
        yield from baz()
        yield from qux()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print(dump(tree))
    assert transformer._tree_changed is True

    class Visitor(NodeVisitor):
        def __init__(self):
            self.yield_from_count = 0

        def visit_YieldFrom(self, node):
            self.yield_from_count += 1

    visitor = Visitor()
    visitor.visit(tree)


# Generated at 2022-06-18 00:55:47.130620
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:53.364238
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compat import get_name

    source = source_to_unicode('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)
    assert get_name(tree.body[0].body[0].value.iter) == 'iter'

# Generated at 2022-06-18 00:55:56.889822
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)


# Generated at 2022-06-18 00:56:04.370247
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.compare import compare_source

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    print_tree(new_tree)
    compare_source(Source(new_tree), source)

# Generated at 2022-06-18 00:56:06.164264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:56:11.177725
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_ast
    from ..utils.helpers import get_ast

    code = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(code)
    YieldFromTransformer().visit(tree)
    print_ast(tree)

# Generated at 2022-06-18 00:56:17.551148
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor

    source = source_to_unicode('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeTransformerVisitor(YieldFromTransformer)
    visitor.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:17.992473
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import dump

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast('yield_from.py')
    dump(tree)
    YieldFromTransformer().visit(tree)
    dump(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:57:29.121139
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_code
    from ..utils.test_utils import get_code_from_ast

    snippet = """
    def foo():
        yield from bar()
    """
    expected = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """
    ast_snippet = get_ast_from_snippet(snippet)
    ast_expected = get_ast_from_snipp

# Generated at 2022-06-18 00:57:36.465097
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            assert node.value.id == 'a'

    source = source_to_unicode('''
    def foo():
        yield from a
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:57:38.704425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:46.025717
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_ast_from_source
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_ast_from_source
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.helpers import get_ast_from_source
    from ..utils.source import source_to_unicode
    from ..utils.tree import print

# Generated at 2022-06-18 00:57:46.623171
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:53.953868
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_tree
    from ..utils.helpers import get_ast

    source = source('''
        def foo():
            yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:57:54.652185
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:55.732836
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:56.462929
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:15.837140
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 01:00:16.538312
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:20.927096
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast(source_to_unicode('''
    def foo():
        yield from bar()
    '''))
    print_tree(tree)
    TestVisitor().visit(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 01:00:29.291608
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source
    from ..utils.compare import compare_asts

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    node = YieldFromTransformer()
    new_tree = node.visit(tree)

    assert compare_asts(tree, new_tree)
    assert dump(new_tree) == dump(get_ast(source))

# Generated at 2022-06-18 01:00:31.916576
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:32.405693
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:32.922893
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:36.919485
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.helpers import get_target_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    tree = YieldFromTransformer().visit(tree)
    target_source = get_source(YieldFromTransformer)
    target_ast = get_target_ast(target_source)
    assert dump_ast(tree) == dump_ast(target_ast)

# Generated at 2022-06-18 01:00:37.466318
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:45.625541
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.helpers import get_func_body
    from ..utils.helpers import get_func_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    assert get_func_body(get_func_ast(source, 'visit')) == get_func_body(tree)