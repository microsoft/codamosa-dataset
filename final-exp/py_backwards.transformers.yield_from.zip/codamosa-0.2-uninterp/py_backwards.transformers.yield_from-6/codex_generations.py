

# Generated at 2022-06-18 00:52:23.718513
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:24.424863
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:52:32.620507
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    from typing import Optional, List, Type, Union
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    YieldFromTransformer()


# Generated at 2022-06-18 00:52:40.157595
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import print_ast

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_ast(tree)
    assert dump_ast(tree) == dump_ast(get_ast("""
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    """))

# Generated at 2022-06-18 00:52:47.389233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.yield_from_count = 0

        def visit_YieldFrom(self, node):
            self.yield_from_count += 1

    class TestVisitor2(NodeVisitor):
        def __init__(self):
            self.yield_count = 0


# Generated at 2022-06-18 00:52:55.889046
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

    class Visitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            raise Exception('YieldFrom node is not expected')

    Visitor().visit(tree)

# Generated at 2022-06-18 00:53:02.010296
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:53:03.144994
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:53:07.540750
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump_ast(tree))

# Generated at 2022-06-18 00:53:08.460762
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-18 00:53:14.512601
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:15.343403
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:16.160072
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:21.999437
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.helpers import get_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code
    from ..utils.helpers import get_code_from_ast
    from ..utils.helpers import get_ast_from_code

# Generated at 2022-06-18 00:53:23.916412
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:30.469620
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import check_transformer
    from ..utils.test_utils import check_transformer_from_file
    from ..utils.test_utils import check_transformer_from_file_as_string
    from ..utils.test_utils import check_transformer_from_file_as_string_with_options
    from ..utils.test_utils import check_transformer_from_file_as_string_with_options_and_target
    from ..utils.test_utils import check_transformer_from_file_as_string_with_options_and_target_and_ast
    from ..utils.test_utils import check_transformer_from_file_as_string_with_options_and_target_and_ast_and_tree
    from ..utils.test_utils import check_transformer_from_file

# Generated at 2022-06-18 00:53:35.089791
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_source
    from ..utils.compare import compare_ast


# Generated at 2022-06-18 00:53:39.218481
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast


# Generated at 2022-06-18 00:53:44.290676
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast(YieldFromTransformer, '''
    def foo():
        yield from bar()
    ''')
    print_tree(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:53:45.249480
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:53:56.232232
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:03.818136
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compiler import compile_snippets

    compile_snippets()

    source = Source("""
    def test():
        yield from range(10)
    """)
    tree = get_ast(source)
    print_tree(tree)

    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_visitor(transformer, tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:06.806505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:54:15.297242
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    dump(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:54:16.056138
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 00:54:27.187760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.helpers import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get_source_code
    from ..utils.source import get

# Generated at 2022-06-18 00:54:28.858803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:54:34.160683
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:54:39.972586
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import print_tree

# Generated at 2022-06-18 00:54:49.121325
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def f():
        yield from g()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    assert dump(tree) == source('''
    def f():
        let(iterable)
        iterable = iter(g())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    exc = exc.value
                break
    ''')



# Generated at 2022-06-18 00:55:12.114724
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:55:15.644231
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump_ast(tree))

# Generated at 2022-06-18 00:55:23.441792
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    dump_ast(tree)
    assert NodeVisitor().visit(tree) == "def foo():\n    iterable = iter(bar())\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            pass\n            break\n"

# Generated at 2022-06-18 00:55:31.297942
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source
    from ..utils.source import get_source


# Generated at 2022-06-18 00:55:40.217909
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_ast
    from ..utils.test_utils import get_func_source
    from ..utils.test_utils import get_source

    # Test for method _get_yield_from_index
    def test_get_yield_from_index():
        transformer = YieldFromTransformer()
        func_ast = get_func_ast(get_func_source('def func():\n    yield from [1, 2, 3]'))
        assert transformer._get_yield_from_index(func_ast, ast.Expr) == 0
        assert transformer._get_yield_from_index(func_ast, ast.Assign) is None

    # Test for method

# Generated at 2022-06-18 00:55:45.842593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.snippet import snippet
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor

    @snippet
    def test():
        let(a)
        a = yield from range(10)

    ast_ = get_ast(test)
    print_tree(ast_)
    print_visitor(ast_, YieldFromTransformer)

# Generated at 2022-06-18 00:55:50.620764
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    print_tree(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)

# Generated at 2022-06-18 00:55:53.705626
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compat import StringIO


# Generated at 2022-06-18 00:55:58.862542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    dump_ast(tree)
    visitor = NodeVisitor()
    visitor.visit(tree)
    assert visitor.nodes_count == 14

# Generated at 2022-06-18 00:56:07.836308
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from .base import BaseNodeTransformer
    Node = Union[ast.Try, ast.If, ast.While, ast.For, ast.FunctionDef, ast.Module]
    Holder = Union[ast.Expr, ast.Assign]
    class YieldFromTransformer(BaseNodeTransformer):
        """Compiles yield from to special while statement."""
        target = (3, 2)


# Generated at 2022-06-18 00:57:02.682199
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:03.532383
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:04.956373
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:12.283774
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.helpers import get_ast

# Generated at 2022-06-18 00:57:22.375558
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import dump_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.helpers import VariablesGenerator
    from ..utils.source import Source
    from ..utils.tree import dump_ast

# Generated at 2022-06-18 00:57:23.305292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:29.892646
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import print_tree
    from ..utils.helpers import get_node

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    print_tree(tree)
    assert get_node(tree, ast.FunctionDef).name == 'foo'

# Generated at 2022-06-18 00:57:30.517214
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:31.210740
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 00:57:37.663852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.visitor import NodeVisitor
    from ..utils.tree import print_tree

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            print(node)

    tree = get_ast('yield_from.py')
    print_tree(tree)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:59:51.247360
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet, let, extend
    from ..utils.helpers import VariablesGenerator
    from .base import BaseNodeTransformer
    import astor
    import astunparse
    import sys
    import os
    import io
    import contextlib
    import unittest
    import unittest.mock
    import typing
    import astor
    import astunparse
    import sys
    import os
    import io
    import contextlib
    import unittest
    import unittest.mock
    import typing
    import astor
    import astunparse
    import sys
    import os
    import io
    import contextlib
    import unitt

# Generated at 2022-06-18 00:59:59.002596
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree
    from ..utils.source import get_source
    from ..utils.snippet import snippet
    from ..utils.compare import compare_source

    @snippet
    def source():
        def f():
            yield from g()
            yield from h()

    tree = get_ast(source)
    print_tree(tree)
    YieldFromTransformer().visit(tree)
    print_tree(tree)
    assert compare_source(get_source(tree), source)

# Generated at 2022-06-18 01:00:06.833590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_tree_with_source
    from ..utils.testing import assert_equal_tree_with_code
    from ..utils.testing import assert_equal_tree_with_source_and_code
    from ..utils.testing import assert_equal_tree_with_source_and_code
    from ..utils.testing import assert_equal_tree_with_source_and_code
    from ..utils.testing import assert_equal_tree_with_source_and_code
    from ..utils.testing import assert_equal_tree_with_source_and_code

# Generated at 2022-06-18 01:00:07.709815
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:08.460905
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-18 01:00:11.349478
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.helpers import get_ast

    source = source('''
    def foo():
        yield from bar()
    ''')
    tree = get_ast(source)
    YieldFromTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 01:00:19.101410
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.typing import get_type

    class TestVisitor(NodeVisitor):
        def visit_YieldFrom(self, node):
            self.result = node

    source = Source("""
    def foo():
        yield from bar()
    """)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 01:00:23.414729
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.helpers import get_ast
    from ..utils.compare import compare_ast
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = YieldFromTransformer

# Generated at 2022-06-18 01:00:24.961846
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-18 01:00:30.995175
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..utils.tree import dump_ast
    from ..utils.source import get_source
    from ..utils.source import get_source_from_ast

    source = get_source(YieldFromTransformer)
    tree = get_ast(source)
    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)
    dump_ast(new_tree)
    new_source = get_source_from_ast(new_tree)
    print(new_source)