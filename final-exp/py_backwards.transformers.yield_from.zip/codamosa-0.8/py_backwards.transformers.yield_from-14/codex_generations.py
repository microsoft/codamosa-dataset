

# Generated at 2022-06-12 04:25:26.119668
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    print(transformer)

# Generated at 2022-06-12 04:25:26.957277
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:25:27.957650
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:36.868262
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from typing import List

    def method_one(self):
        yield from self.method_two()

    def method_two(self):
        yield 1
        yield 2
        yield 3

    def method_three(self):
        self.var = yield from self.method_two()

    example_yield_from = YieldFromTransformer().run(ast.parse(method_one.__doc__))
    example_yield_from_two = YieldFromTransformer().run(ast.parse(method_three.__doc__))

    assert isinstance(example_yield_from, ast.Module)
    assert isinstance(example_yield_from.body[0], ast.FunctionDef)
    assert example_yield_from.body[0].name == 'method_one'

# Generated at 2022-06-12 04:25:37.738669
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:25:42.133672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.fake_ast import get_fake_ast
    from ..utils.exceptions import NoMatchFound

    mod = get_fake_ast('yield from')
    transformer = YieldFromTransformer()
    transformer.visit(mod)
    result = transformer.result()[0]
    assert result is not None
    assert result == get_fake_ast('while_yield_from')

# Generated at 2022-06-12 04:25:50.710475
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    y = yield from x
    """
    x = ast.parse(code)
    y = YieldFromTransformer()
    result = y.visit(x)

    assert len(result.body) == 1
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[0].value, ast.Call)
    assert isinstance(result.body[0].value.func, ast.Name)
    assert result.body[0].value.func.id == 'yield_from'

# Generated at 2022-06-12 04:25:51.617347
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	x = YieldFromTransformer()
	assert x

# Generated at 2022-06-12 04:25:55.416303
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.AST(col_offset=0, lineno=0)
    b = ast.AST(col_offset=1, lineno=1)
    c = ast.AST(col_offset=2, lineno=2)
    import types
    assert isinstance(YieldFromTransformer(), types.GeneratorType)

# Generated at 2022-06-12 04:25:56.029407
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-12 04:26:12.306548
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_base import create_test_module, create_test_node
    node_1_1 = create_test_node("node_1_1", ast.Expr,
                                value=create_test_node("node_1_1_0_0", ast.YieldFrom,
                                                       value=(create_test_node("node_1_1_0_0_0_0", ast.Name, id="a",
                                                                               ctx=create_test_node("node_1_1_0_0_0_0_0", ast.Load, )))))

# Generated at 2022-06-12 04:26:15.710682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .tests.utils import _test_transform
    from .tests.data.yield_from import code
    from .tests.data.yield_from import compiled

    result = _test_transform(YieldFromTransformer, code, compiled)
    assert result

# Generated at 2022-06-12 04:26:16.638390
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()

# Generated at 2022-06-12 04:26:17.668421
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:26:18.630241
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-12 04:26:21.154152
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        assert type(YieldFromTransformer()) is YieldFromTransformer
    except AssertionError:
        print('AssertionError raised in test_YieldFromTransformer')


# Generated at 2022-06-12 04:26:26.640609
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""
    def foo():
        yield from 1
    """)

    assert tree == ast.parse("""
    def foo():
        let(exc)
        let(iterable)
        iterable = iter(1)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    """)

# Generated at 2022-06-12 04:26:27.712028
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:26:29.351185
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception as e:
        print(e)

# Generated at 2022-06-12 04:26:36.516978
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from compilation.optimization.test_tree_node_transformer import get_transformer_test_generation
    class YieldFromTestGenerator(get_transformer_test_generation(YieldFromTransformer)):
        @classmethod
        def _get_test_tree_module(cls):
            return cls._yield_from_transform()

        @classmethod
        def _yield_from_transform(cls):
            return """
                def test():
                    yield from (1, 2)
                    a = yield from (1, 2)
                """


# Generated at 2022-06-12 04:26:45.023399
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast
    import astunparse

    # test YieldFromTransformer()
    t = YieldFromTransformer()
    assert t is not None


# Generated at 2022-06-12 04:26:47.162473
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:57.986317
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): # type: ignore
    from ..rewriters.yield_from import YieldFromTransformer
    from typed_ast.ast3 import parse, YieldFrom
    from ..utils.helpers import VariablesGenerator

    code = """
    def f():
        a = yield from g()
    """
    tree = parse(code)

    generator = VariablesGenerator()
    transformer = YieldFromTransformer(generator)

    transformer.visit(tree)

    assert len(tree.body[0].body) == 3
    assert isinstance(tree.body[0].body[1].value, YieldFrom)
    assert isinstance(tree.body[0].body[2].value, YieldFrom)

# Generated at 2022-06-12 04:26:58.986507
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return



# Generated at 2022-06-12 04:27:03.713897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        import ast

    a = ast.parse("def f():\n yield from range(1)")
    b = YieldFromTransformer().visit(a)
    print(ast.dump(b))


test_YieldFromTransformer()

# Generated at 2022-06-12 04:27:04.755389
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-12 04:27:15.724205
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc = ast.Name(id='exc', ctx=ast.Load())
    target = ast.Name(id='target', ctx=ast.Load())
    assert result_assignment.get_body(exc=exc, target=target,
                                      _locals=locals()) == [
        ast.Assign([target], ast.Attribute(exc, 'value', ast.Load()))
    ]
    generator = ast.Name(id='generator', ctx=ast.Load())
    assignment = [None]
    exc = ast.Name(id='exc', ctx=ast.Load())
    iterable = ast.Name(id='iterable', ctx=ast.Load())

# Generated at 2022-06-12 04:27:16.729770
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:17.745486
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:27:19.778308
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-12 04:27:31.666285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:27:32.543971
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    b = YieldFromTransformer()

# Generated at 2022-06-12 04:27:33.407768
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:34.317370
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:41.548249
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..transformer import Transformer

    transform = Transformer({YieldFromTransformer})
    code = '''
        def a():
            try:
                yield from b()
            except Exception as e:
                yield
            finally:
                pass
        '''

    result = transform(code)
    assert 'yield from' not in result

    code = 'a = yield from b()'
    result = transform(code)
    assert 'yield from' not in result

    code = 'yield from b()'
    result = transform(code)
    assert 'yield from' not in result

# Generated at 2022-06-12 04:27:42.369665
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:27:46.303510
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import dis
    code = 'def gen(): yield from iter(range(2))'
    tree = ast.parse(code)
    tr = YieldFromTransformer()
    tr.visit(tree)
    dis.dis(compile(tree, '<folder>', 'exec'))


# Generated at 2022-06-12 04:27:46.830464
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-12 04:27:48.975751
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

test_YieldFromTransformer()
# vim: ts=4 sts=4 sw=4 et:

# Generated at 2022-06-12 04:27:49.669811
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(None)
    assert transformer is not None


# Generated at 2022-06-12 04:28:18.430354
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load()))
    ast.copy_location(yield_from, ast.parse('yield from a').body[0].value)
    yield_from_ast = ast.Expr(value=yield_from)
    ast.copy_location(yield_from_ast, ast.parse('yield from a'))
    test_ast = ast.parse('raise StopIteration(a)')
    result = YieldFromTransformer()(test_ast)
    print(ast.dump(result))

# Generated at 2022-06-12 04:28:23.420080
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit testing of constructor of class YieldFromTransformer"""
    transformer = YieldFromTransformer()
    assert hasattr(transformer, '_get_yield_from_index')
    assert hasattr(transformer, '_emulate_yield_from')
    assert hasattr(transformer, '_handle_expressions')
    assert hasattr(transformer, '_handle_assignments')
    assert hasattr(transformer, 'visit')



# Generated at 2022-06-12 04:28:25.730853
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Check that `YieldFromTransformer` class exist and is of right type"""
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)


# Generated at 2022-06-12 04:28:30.314862
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .syntax_tree import SyntaxTreeToAstVisitor

    source = '''
    class A:
        def __init__(self):
            self.b = yield from self.get_b()

        def get_b(self):
            yield 10

    '''
    tree = SyntaxTreeToAstVisitor().visit(ast.parse(source))

    YieldFromTransformer().visit(tree)

# Generated at 2022-06-12 04:28:38.888339
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from textwrap import dedent
    from ..utils.source import Source
    result = Source(dedent("""
        def foo():
            a = yield from bar()
            b = yield from foo()
            c = yield from [x() for x in bar()]
            yield from bar()
    """)).tree

# Generated at 2022-06-12 04:28:40.566319
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert yield_from_transformer

# Generated at 2022-06-12 04:28:41.085511
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:28:48.220369
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import unparse
    from ..utils.helpers import get_node

    tree = get_node("""
    try:
        print(yield from [])
    finally:
        print('finally')
    """, YieldFromTransformer)

    # Check that yield from is replaced by generator expression
    result = unparse(tree).strip()
    assert result == """_i2 = iter([])\nwhile True:\n    try:\n        _yield = next(_i2)\n    except StopIteration as _exc:\n        _yield_value_1 = _exc.value\n        break\n    yield _yield"""



# Generated at 2022-06-12 04:28:49.409100
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert callable(YieldFromTransformer)

# Generated at 2022-06-12 04:28:51.011323
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:29:45.089870
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..ast_converter import ASTConverter
    import typed_ast.ast3 as ast
    ast_converter = ASTConverter()

    transform = YieldFromTransformer(ast_converter).transform


# Generated at 2022-06-12 04:29:46.330134
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transform = YieldFromTransformer()
    assert transform



# Generated at 2022-06-12 04:29:54.194732
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    import ast
    source = """
    def foo():
        a = yield from 1
        b = yield from 2
        yield from 3
    """
    print(astunparse.dump(ast.parse(source)))

# Generated at 2022-06-12 04:30:01.620923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    node = ast.parse('yield from some')
    yield_from_node = node.body[0].value
    body = t._emulate_yield_from(None, yield_from_node)
    assert isinstance(body[0], ast.Assign), 'yield from assignment'
    assert isinstance(body[1], ast.While), 'yield from while'

# Generated at 2022-06-12 04:30:03.373983
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)
    assert transformer.tree_changed == False

# Generated at 2022-06-12 04:30:07.439707
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source, source_from_tree
    from ..utils.helpers import print_tree, parse_text
    from ..utils.visitor import print_visitor

    # TODO: test class
    def test_YieldFromTransformer_constructor():
        YieldFromTransformer()

    # TODO: test visit
    def test_YieldFromTransformer_visit():
        from .rewrite_function_spec import RewriteFunctionSpecTransformer


# Generated at 2022-06-12 04:30:08.858146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # check constructor of class YieldFromTransformer
    YieldFromTransformer()


# Generated at 2022-06-12 04:30:10.758793
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # When
    try:
        YieldFromTransformer()
    except:
        assert False
    # Then
    assert True

# Generated at 2022-06-12 04:30:15.351034
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import TestCase
    class TestClass(TestCase):
        def _get_target(self) -> type:
            return YieldFromTransformer

        def test_create(self):
            target = self._get_target()
            self._test_equal(target(), target())
            self._test_equal(target(1), target(1))

    TestClass().run()

# Generated at 2022-06-12 04:30:25.093395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from textwrap import dedent
    from ..utils.source import Source
    from ..transpiler import Transpiler
    from ..visitor import NodeTransformer

    source = Source(dedent("""
    def f():
        a = yield from g()
        b = yield from g()
        print(yield from g())
    """))
    tree = source.tree
    module = Transpiler().visit(tree)
    node = module[0]
    assert isinstance(node.body[1], ast.Assign)
    node = NodeTransformer(YieldFromTransformer).visit(node)
    assert isinstance(node.body[1], ast.While)
    assert isinstance(node.body[3], ast.While)
    assert isinstance(node.body[5], ast.While)

# Generated at 2022-06-12 04:32:41.849097
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """ Check YieldFromTransformer constructor"""
    YieldFromTransformer()

# Generated at 2022-06-12 04:32:43.590412
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    YieldFromTransformer.__init__


# Generated at 2022-06-12 04:32:44.081504
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(True)

# Generated at 2022-06-12 04:32:50.683119
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import GeneratorTestCase
    from ..utils import dump

    class Test(GeneratorTestCase):
        def test_base(self):
            self.check(
                """
                def test():
                    yield from range(1)
                """,
                """
                def test():
                    let(iterable)
                    iterable = iter(range(1))
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            if hasattr(exc, 'value'):
                                exc = exc.value
                            break
                """
            )


# Generated at 2022-06-12 04:32:51.453939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:32:55.544320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test YieldFromTransformer without fail
    try:
        YieldFromTransformer()
    except Exception as e:
        assert False, "Could not create instance of YieldFromTransformer"
    # Test with fail
    try:
        YieldFromTransformer(None)
        assert False, "Should not create instance of YieldFromTransformer with None as argument"
    except Exception as e:
        pass


# Generated at 2022-06-12 04:32:57.109172
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:32:58.614132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def test():
        yield from a
    """

# Generated at 2022-06-12 04:33:05.143734
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_node = parse_ast('''
                    while True:
                      try:
                        pass
                      except Exception as e:
                        pass
                    ''')
    assert YieldFromTransformer._get_yield_from_index(ast_node, Holder) == None
    assert YieldFromTransformer._emulate_yield_from(ast_node, ast_node) == [ast_node]
    assert YieldFromTransformer._handle_assignments(ast_node) == [ast_node]
    assert YieldFromTransformer._handle_expressions(ast_node) == [ast_node]

test_YieldFromTransformer()

# Generated at 2022-06-12 04:33:13.521787
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ast_transformer import YieldFromTransformer

    class MyYieldFromTransformer(YieldFromTransformer):
        target = (3, 2)

    ast_ = ast.parse('''
        def gen():
            x = yield from [1, 2, 3]
        def gen2():
            yield from [1, 2, 3]
    ''')
    gen = MyYieldFromTransformer().visit(ast_.body[0])
    gen2 = MyYieldFromTransformer().visit(ast_.body[1])
    assert gen.body[0].value.value.value.args[0].value.body[0].value.value.func == ast.Name
    assert gen2.body[0].body[0].value.func == ast.Name