

# Generated at 2022-06-12 04:25:25.810742
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None).target == (3, 2)

# Generated at 2022-06-12 04:25:26.716016
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:27.660738
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer)

# Generated at 2022-06-12 04:25:28.623106
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    x

# Generated at 2022-06-12 04:25:29.930562
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')



# Generated at 2022-06-12 04:25:38.618774
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from pybetter.transformers.tests.test_yield_from import test_case
    import textwrap

# Generated at 2022-06-12 04:25:45.001688
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_examples import yield_from_examples, yield_from_assign_examples
    from ..utils.visitor import Visitor
    from ..utils.tree import tree
    from .. import testing

    examples = yield_from_examples + yield_from_assign_examples
    for snippet_ in examples:
        module = testing.parse_snippet(snippet_)
        transformer = YieldFromTransformer()
        tree(module)
        Visitor.apply(module, transformer)
        tree(module)

# Generated at 2022-06-12 04:25:46.672419
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:25:47.593240
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-12 04:25:50.618159
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    # just check wether the initialization works (no exception raised)
    YieldFromTransformer()


# Generated at 2022-06-12 04:25:56.898813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer
    assert callable(transformer)

# Generated at 2022-06-12 04:25:57.730299
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:26:00.499901
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """for i in range(3):
    print(i)
"""
    tree = ast.parse(code)  # type: ignore
    c = YieldFromTransformer()
    c.visit(tree)

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:26:03.539985
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    assert repr(trans).startswith("<YieldFromTransformer of 'YieldFromTransformer' objects>")

# Generated at 2022-06-12 04:26:05.071535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Arrange
    # Act
    transformer = YieldFromTransformer()

    # Assert
    assert transformer is not None

# Generated at 2022-06-12 04:26:09.272883
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.simplify import simplify
    from ..utils.tree import ast2tree
    from ..utils.compile import compile_code
    from .returns import ReturnTransformer
    from .breaks import BreakTransformer
    from .continues import ContinueTransformer


# Generated at 2022-06-12 04:26:10.871752
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_node_transformers import _test_transformer


# Generated at 2022-06-12 04:26:11.382297
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-12 04:26:13.985596
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)



# Generated at 2022-06-12 04:26:14.886516
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:26:26.370299
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import check_node

# Generated at 2022-06-12 04:26:35.356407
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import test_utils as utils

    yield_from_transformer = YieldFromTransformer()
    assert yield_from_transformer.target == (3, 2)
    # TODO
    # Drop lines with "pass"
    # Add unit tests
    yield_from_transformer = YieldFromTransformer()
    code = """
    def a(i):
        yield from i
        yield from i
    """

# Generated at 2022-06-12 04:26:39.285897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from minivm.compiler.compiler import Compiler
    from minivm.compiler.program import Program
    compiler = Compiler(Program())
    compiler.compile({
        'class': 'YieldFromTransformer',
        'options': {},
    }, 'YieldFromTransformer')

# Generated at 2022-06-12 04:26:41.064293
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True, "Test passed"

# Generated at 2022-06-12 04:26:42.094191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:43.508628
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-12 04:26:45.118761
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        YieldFromTransformer()

# Generated at 2022-06-12 04:26:47.301814
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:58.590858
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from ..rewrites import RewriteError
    transformer = YieldFromTransformer()
    try:
        transformer.visit(ast3.AST())
    except RewriteError as e:
        assert str(e) == 'YieldFromTransformer expected the AST to be a module'

# Generated at 2022-06-12 04:27:00.434682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-12 04:27:21.804378
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from tests.utils import generate, equal_ast, roundtrip_unparse
    snippet.disable_warnings()

# Generated at 2022-06-12 04:27:26.827564
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # In this test case, we test if the constructor of
    # YieldFromTransformer works as it is supposed to.

    # We first create a node for the current class,
    # and then we check if the properties _tree_changed
    # and _target_version is correct.
    sut = YieldFromTransformer()
    assert not sut._tree_changed
    assert sut.target == (3, 2)

# Generated at 2022-06-12 04:27:27.780642
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:37.055932
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    
    import inspect
    import ast

    c_spec = inspect.getfullargspec(YieldFromTransformer)
    c_args = c_spec.args
    c_defaults = c_spec.defaults
    num_c_args = len(c_args)
    assert c_args == ['self'], c_args
    assert c_defaults is None, c_defaults
    assert num_c_args == 1, num_c_args
    arg0 = c_args[0]
    annotation0 = c_spec.annotations[arg0]
    assert annotation0 == inspect._empty, annotation0
    
    
    
    attrs = vars(YieldFromTransformer)

# Generated at 2022-06-12 04:27:46.342578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Dummy0(ast.Try):
        def __init__(self):
            self.body = [] # type: ignore
            self.handlers = [] # type: ignore
            self.orelse = [] # type: ignore
            self.finalbody = [] # type: ignore
    class Dummy1(ast.If):
        def __init__(self):
            self.body = [] # type: ignore
            self.orelse = [] # type: ignore
    class Dummy2(ast.For):
        def __init__(self):
            self.body = [] # type: ignore
            self.orelse = [] # type: ignore
    class Dummy3(ast.While):
        def __init__(self):
            self.body = [] # type: ignore
            self.orelse = [] # type: ignore

# Generated at 2022-06-12 04:27:47.192755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:51.613611
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .unroller import Unroller
    from .util import parse
    from .reorder import ReorderAssignments
    from .for_loop import ForLoopTransformer
    from ..utils.helpers import debug_ast, save_ast


# Generated at 2022-06-12 04:27:52.494009
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:53.423122
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:54.816487
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:28:38.510353
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import parse
    from .. import compile_
    assert compile_(parse("a = yield from [1, 2, 3]"), 3) == \
        "a = iter([1, 2, 3]); while True: try: yield next(a); except StopIteration as exc: a = exc.value; break"

# Generated at 2022-06-12 04:28:40.166444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj.target == (3, 2)

# Generated at 2022-06-12 04:28:43.747740
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import source, source2ast
    from ..utils.checker import check
    tree = source2ast(source)
    check(tree, YieldFromTransformer)

# Generated at 2022-06-12 04:28:44.634003
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    return trans

# Generated at 2022-06-12 04:28:45.701539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    assert type(trans) == YieldFromTransformer


# Generated at 2022-06-12 04:28:54.230901
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from nd.datascience.compiler import Compiler
    from nd.datascience.compiler.nodes import parse
    from nd.datascience.compiler.visitors.visitors import YieldFromVisitor
    from nd.datascience.compiler.visitors.visitors import MutatingVisitor
    assert issubclass(MutatingVisitor, YieldFromVisitor)
    assert issubclass(YieldFromTransformer, YieldFromVisitor)
    assert issubclass(YieldFromTransformer, MutatingVisitor)
    compiler = Compiler(parse('def f():\n    yield from range(10)', mode='exec'))
    transformer = compiler.visitors.visitors.YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)
    assert transformer._get

# Generated at 2022-06-12 04:28:56.306630
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass #FIXME: Implement unit test


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-12 04:28:59.656584
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def foo():
        x = yield from [1, 2]
        yield from x + 2
        [1 for i in yield from x]
    """
    res = compile(code, '', 'exec')
    with open('test.py', 'w') as f:
        f.write(code)

# Generated at 2022-06-12 04:29:06.651393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    from ..codegen import to_source
    from .explicit_return import ExplicitReturnTransformer
    s = "def f():\n  a = (yield from g())\n  return 10"
    namespace = dict()
    tree = get_ast(s, namespace)
    assert tree.body[0].body[0].target.id == 'a'
    assert to_source(tree.body[0].body[0].value).replace("\n", "") == "iter(g())"
    tree = ExplicitReturnTransformer(32, 2).visit(
        YieldFromTransformer(32, 2).visit(tree))

# Generated at 2022-06-12 04:29:07.888836
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  yield_from_transformer = YieldFromTransformer()



# Generated at 2022-06-12 04:30:54.459250
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    ret = yield from [i for i in range(5)]
    """

    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    fixed_code = astor.to_source(tree)


# Generated at 2022-06-12 04:30:56.312854
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)

# Generated at 2022-06-12 04:30:57.369100
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()



# Generated at 2022-06-12 04:30:59.220302
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    check_transformer(YieldFromTransformer, '''
    def func():
        yield from x
        yield from y      
    ''')

# Generated at 2022-06-12 04:31:03.126128
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestClass:
        def __init__(self, file, mod=None, path=None):
            self.file = file
            self.mod = mod
            self.path = path

    test_obj = TestClass('test')
    assert test_obj


# Generated at 2022-06-12 04:31:08.784917
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def func():
        res = yield from range(5)
    """

    transformed = snippet.get_ast(code)
    expected = """
    def func():
        let(exc, iterable)
        iterable = iter(range(5))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                res = exc.value
                break
    """

    ast.fix_missing_locations(transformed)
    transformed_code = snippet.compile_module(transformed)

    assert transformed_code == snippet.get_ast(expected)


# Generated at 2022-06-12 04:31:10.442142
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except:
        return False
    return True


# assert test_YieldFromTransformer()



# Generated at 2022-06-12 04:31:18.130784
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.example import example
    from ..utils.ast import parse, dump, equal
    from .base import BaseTestCase
    

# Generated at 2022-06-12 04:31:20.220173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)
    assert YieldFromTransformer().target == (3, 2)


# Generated at 2022-06-12 04:31:21.392908
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Unit test for constructor of class YieldFromTransformer
    '''
    obj = YieldFromTransformer()