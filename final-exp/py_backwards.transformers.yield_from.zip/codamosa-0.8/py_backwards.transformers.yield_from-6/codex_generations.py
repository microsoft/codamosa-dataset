

# Generated at 2022-06-12 04:25:24.636292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)



# Generated at 2022-06-12 04:25:33.884489
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor 
    import sys
    import os
    # sys.path.extend([os.path.dirname(os.path.dirname(os.path.abspath(__file__).replace('tests', ''))), 
    #                 os.path.dirname(os.path.abspath(__file__).replace('tests', ''))])
    from typedpy import Type 
    from typedpy_ext import YieldFromTransformer as YFT

    modules = []
    modules.append(ast.parse('''
    def f():
        g()
    '''))

    modules.append(ast.parse('''
    def f():
        x = yield from g()
    '''))


# Generated at 2022-06-12 04:25:36.986740
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ....tests.testing import assert_transform, assert_transform_result, assert_rest_unchanged
    from ..utils.testing import get_used_names, should_not_change


# Generated at 2022-06-12 04:25:37.595003
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:25:39.705728
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_string = 'class YieldFromTransformer(BaseNodeTransformer):'
    assert class_string in str(YieldFromTransformer)


# Generated at 2022-06-12 04:25:41.215087
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from collections import namedtuple

# Generated at 2022-06-12 04:25:42.699360
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft._tree_changed == False


# Generated at 2022-06-12 04:25:44.155731
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-12 04:25:52.953201
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet = 'yield from [1, 2, 3]'
    expected = 'let(iterable)\n' \
               'iterable = iter([1, 2, 3])\n' \
               'while True:\n' \
               '    try:\n' \
               '        yield next(iterable)\n' \
               '    except StopIteration as exc:\n' \
               '        break'
    tree = ast.parse(snippet)
    YieldFromTransformer().visit(tree)
    assert dumps(tree, no_docstrings=True).strip() == expected

# Generated at 2022-06-12 04:25:53.955335
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:26:09.499831
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import DefaultTransformer
    from ..config import Settings
    from ..utils.source import Source

    def test_case(expected, source):
        tree = ast.parse(source)
        transformer = DefaultTransformer(Settings(), Source(source))
        transformer.visit(tree)
        result = ast.dump(tree, include_attributes=False)
        assert result == expected


# Generated at 2022-06-12 04:26:10.073898
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-12 04:26:11.197554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(not hasattr(YieldFromTransformer, '__init__'))

# Generated at 2022-06-12 04:26:11.994480
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(None)

# Generated at 2022-06-12 04:26:21.489146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast import parse, dump

    # Yield from without assignment, without with
    data = parse('yield from foo()', mode='eval')
    node = YieldFromTransformer().visit(data)
    if node is not None:
        print(dump(node))
        node.body.body[0].body.body
    assert len(node.body.body) == 1 and node.body.body[0].body.body[0].func.id == 'next' and node.body.body[0].body.body[1].func.id == 'iter'
    assert len(node.body.body[0].body.body[1].args) == 1 and node.body.body[0].body.body[1].args[0].func.id == 'foo'

    # Yield from without assignment, with with

# Generated at 2022-06-12 04:26:22.831215
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except TypeError:
        assert False
    assert True


# Generated at 2022-06-12 04:26:34.025033
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = """\
        def foo():
            a = yield from bar()
            yield from bar()
            yield from bar()
        """

# Generated at 2022-06-12 04:26:36.266759
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t1 = YieldFromTransformer()
    assert(not hasattr(t1, '_tree_changed'))


# Generated at 2022-06-12 04:26:39.057553
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils import TreeInstanceBuilder
    tree_instance_builder = TreeInstanceBuilder()
    return YieldFromTransformer(), tree_instance_builder


# Generated at 2022-06-12 04:26:43.096212
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    Ensures the YieldFromTransformer is properly intialized.
    """
    # Case 1 - without arguments
    YieldFromTransformer()

    # Case 2 - with arguments
    YieldFromTransformer(x=3)

# Generated at 2022-06-12 04:26:59.229462
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from pycropml.transpiler.transpile import Transpiler
    from pycropml.transpiler.type_inference import types
    t = Transpiler()
    mod = t.transpile("""
    def test(n):
        m = n
        yield from range(5)
        return m

    print(test(5))
    """)

# Generated at 2022-06-12 04:27:00.333923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass # FIXME: write the test

# Generated at 2022-06-12 04:27:04.426592
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import textwrap, astor
    source = textwrap.dedent("""\
        def foo():
            yield from bar()
        """)
    tree = ast.parse(source)
    YieldFromTransformer().visit(tree)
    print(astor.to_source(tree))


# Generated at 2022-06-12 04:27:06.154547
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:27:13.199221
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # init = ast.Expr(
    #     ast.Call(
    #         ast.Name('YieldFromTransformer', ast.Load()),
    #         [],
    #         []))
    assert hasattr(YieldFromTransformer, 'visit')
    assert hasattr(YieldFromTransformer, '_handle_assignments')
    assert hasattr(YieldFromTransformer, '_handle_expressions')
    assert hasattr(YieldFromTransformer, '_emulate_yield_from')

# Generated at 2022-06-12 04:27:14.956430
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)

# Generated at 2022-06-12 04:27:17.998074
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # this test checks the case when we have a yield from in the body of an assignment
    src = """
a = yield from gen()
    """

# Generated at 2022-06-12 04:27:19.199502
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:27:20.350538
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:23.512457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile_string
    code = '''
        def foo(l):
            a, b = yield from l
    '''
    compiled = compile_string(code, version=(3, 2))
    assert 'a, b = exc.value' in compiled

# Generated at 2022-06-12 04:27:54.280170
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import strip_tree
    from ..utils.snippet import let, extend

    @snippet
    def result_assignment(exc, target):
        if hasattr(exc, 'value'):
            target = exc.value

    @snippet
    def yield_from(generator, exc, assignment):
        let(iterable)
        iterable = iter(generator)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                extend(assignment)
                break


# Generated at 2022-06-12 04:27:56.947805
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == "YieldFromTransformer"
    assert YieldFromTransformer.target == (3, 2)


# Generated at 2022-06-12 04:27:57.982219
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:06.220026
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer

    class YieldFromTransformer(BaseNodeTransformer):
        """Compiles yield from to special while statement.
        test line
        """
        target = (3, 2)

        def _get_yield_from_index(self, node: ast.AST,
                                  type_: Type[Holder]) -> Optional[int]:
            if hasattr(node, 'body') and isinstance(node.body, list):  # type: ignore
                for n, child in enumerate(node.body):  # type: ignore
                    if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                        return n

            return None


# Generated at 2022-06-12 04:28:15.220157
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.visitor import get_ast, dump_ast
    from typed_astunparse import unparse
    from ..py36 import Py36Transformer
    node = get_ast('''
    def f():
        yield from [1, 2]
        return 1
    ''')
    transformer = YieldFromTransformer()
    new_node = transformer.visit(node)
    print(unparse(new_node))
    py36 = Py36Transformer()
    new_node = py36.visit(new_node)
    print(unparse(new_node))

# Generated at 2022-06-12 04:28:16.390538
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).target == (3, 2)

# Generated at 2022-06-12 04:28:24.786707
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .base import NodeTransformer
    from .base import BaseTreeTransformer
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert issubclass(YieldFromTransformer, NodeTransformer)
    assert issubclass(YieldFromTransformer, ast.NodeVisitor)
    assert issubclass(YieldFromTransformer, BaseTreeTransformer)

    from typed_astunparse.ast3 import YieldFrom
    from typed_astunparse.ast3 import Assign
    from typed_astunparse.ast3 import Module
    from typed_astunparse.ast3 import Load
    from typed_astunparse.ast3 import Name
    from typed_astunparse.ast3 import Return
    from typed_astunparse.ast3 import Num

# Generated at 2022-06-12 04:28:33.464904
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_helpers import from_string
    from ..utils.snippet import remove_arg_comments
    from ..utils.ast import dump
    from ..utils.snippet import indent
    from ..utils.helpers import VariablesGenerator

    v = VariablesGenerator()

    # ...
    snippet_1 = remove_arg_comments(result_assignment)  # removes comments
    snippet_1 = v.substitute(snippet_1, exc='exc', target='target')  # replaces arguments with values
    snippet_1 = indent(snippet_1, 2)  # indents snippet

    # ...
    snippet_2 = remove_arg_comments(yield_from)  # removes comments

# Generated at 2022-06-12 04:28:34.907676
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()
    assert tr != None


# Generated at 2022-06-12 04:28:36.011590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    assert trans


# Generated at 2022-06-12 04:29:28.634345
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..environment import Environment
    source = '''
    def foo():
        yield from [1, 2]

    for i in foo():
        print(i)

    result = [1, 2]
    yield from result

    iterable = [3, 4]
    (a, b) = yield from iterable
    '''

    environment = Environment(source)
    tree = environment.tree
    transformer = YieldFromTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-12 04:29:30.512707
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import NodeTransformerTestMixin
    NodeTransformerTestMixin.test(YieldFromTransformer)

# Generated at 2022-06-12 04:29:31.272285
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:29:33.925094
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__qualname__ == 'YieldFromTransformer'
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-12 04:29:35.710658
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    parser = ast.parse('a = yield from b + c')
    assert isinstance(YieldFromTransformer().visit(parser), ast.Module)

# Generated at 2022-06-12 04:29:36.503811
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:29:39.908716
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_code = "from typing import Generator\n" + \
        "def foo(a: int) -> Generator[str, None, int]:\n" + \
        "    yield from range(a)\n"
    module = ast.parse(test_code)

# Generated at 2022-06-12 04:29:42.522133
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .convert_for import ForTransformer
    from .convert_while import WhileTransformer
    from .convert_yield import YieldsTransformer
    import typed_astunparse
    # language=Python

# Generated at 2022-06-12 04:29:43.561069
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    YieldFromTransformer()

# Generated at 2022-06-12 04:29:44.292671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return True


# Generated at 2022-06-12 04:31:45.445161
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse

# Generated at 2022-06-12 04:31:46.089791
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()

# Generated at 2022-06-12 04:31:47.435019
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert not transformer.tree_changed


# Generated at 2022-06-12 04:31:50.181555
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

    assert x.node_transformer == YieldFromTransformer.visit
    assert x.generic_visit == YieldFromTransformer.generic_visit



# Generated at 2022-06-12 04:31:51.121516
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer.YieldFromTransformer()


# Generated at 2022-06-12 04:31:51.932448
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:31:52.645769
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:31:55.108444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-12 04:31:59.457273
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try_snippet = snippet('''
        try:
            yield from generator
        except StopIteration as exc:
            yield exc.value
    ''')
    func_snippet = snippet('''
        def func():
            yield from generator
    ''')
    generator_func_snippet = snippet('''
        def func():
            yield from (x for x in [])
    ''')
    if_snippet = snippet('''
        if x:
            yield from generator
    ''')
    try_assign_snippet = snippet('''
        try:
            x = yield from generator
        except StopIteration as exc:
            x = exc.value
    ''')

# Generated at 2022-06-12 04:32:07.266298
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer()
    assert isinstance(result, YieldFromTransformer)

# Unit tests for method visit of class YieldFromTransformer