

# Generated at 2022-06-12 04:25:24.558704
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert isinstance(t, YieldFromTransformer)

# Generated at 2022-06-12 04:25:27.569846
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    emulated_yield_from = YieldFromTransformer()
    assert emulated_yield_from.__class__.__name__ == 'YieldFromTransformer'
    assert hasattr(emulated_yield_from,'visit')

# Generated at 2022-06-12 04:25:30.013630
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    Transformer = YieldFromTransformer()
    Transformer.visit(None)

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:25:30.968985
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:39.552882
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # ==> test_code
    def func_yield_from():
        var1 = yield from [1, 2, 3]
        var2 = yield from [1, 2, 3]
    # <== test_code

    # ==> expected_code
    def func_yield_from():
        var1 = None
        iterable = iter([1, 2, 3])
        while True:
            try:
                var1 = next(iterable)
                yield var1
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    var1 = exc.value
                break
        var2 = None
        iterable = iter([1, 2, 3])

# Generated at 2022-06-12 04:25:41.073246
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()

# unit test for visit of class YieldFromTransformer

# Generated at 2022-06-12 04:25:43.161684
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print(YieldFromTransformer.__name__)
    print(YieldFromTransformer.__doc__)
    print(YieldFromTransformer.__module__)

# Generated at 2022-06-12 04:25:49.487711
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    global exc_global
    exc_global = None
    def global_exc(*args, **kwargs):
        global exc_global
        exc_global = (args, kwargs)

    def callable(*args, **kwargs):
        global exc_global
        exc_global = (args, kwargs)

    transformer = YieldFromTransformer(global_exc, callable)



# Generated at 2022-06-12 04:25:51.701085
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # In case of success no exception should be raised
    YieldFromTransformer()


# Generated at 2022-06-12 04:25:59.742218
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_helpers import assert_node_equal, dump

    src = """\
a = (yield from b)
if cond:
    a = (yield from b)
    yield from b
    yield from b
    yield from b
"""

# Generated at 2022-06-12 04:26:10.995155
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .helpers import run_transformer
    code = """
        def foo():
            yield from bar()
        """
    expected = """
        def foo():

            let(iterable)
            iterable = iter(bar())
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """
    run_transformer(code, expected, YieldFromTransformer)



# Generated at 2022-06-12 04:26:11.818032
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:21.267222
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:32.445439
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:33.165984
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return


# Generated at 2022-06-12 04:26:35.270581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.codegen import to_source
    from ..utils.helpers import parse_to_ast


# Generated at 2022-06-12 04:26:45.965129
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet_result_assignment = result_assignment.get_body(exc='exc', target='target')
    snippet_yield_from = yield_from.get_body(generator='generator', assignment=snippet_result_assignment, exc='exc')
    snippet_yield_from = ast.parse(snippet_yield_from).body[0].body
    try_node = ast.Try(body=[], finalbody=[], handlers=[],
                       orelse=[],
                       body=ast.Expr(value=ast.YieldFrom(value='generator')))

# Generated at 2022-06-12 04:26:50.935550
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('i = yield from range(3)\nfor i in range(3):\n    yield from range(3)')
    tree = YieldFromTransformer().visit(node)
    assert compile(tree, filename='<ast>', mode='exec')

# Generated at 2022-06-12 04:26:52.304244
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yieldFromTransformer = YieldFromTransformer()

# Generated at 2022-06-12 04:27:03.464396
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astpretty import pprint
    from typed_ast.ast3 import parse
    from .unpacking_transformer import UnpackingTransformer
    from .yield_transformer import YieldTransformer

    def transform(code: str) -> ast.AST:
        tree = parse(code)
        tree = UnpackingTransformer().visit(tree)
        tree = YieldTransformer().visit(tree)
        tree = YieldFromTransformer().visit(tree)
        return tree

    tree = transform('def foo():\n'
                     '    yield from gen')
    pprint(tree)
    assert tree.body[0].body[0].body[0].body[0].target.id == 'iterable'
    assert tree.body[0].body[0].body[0].body[0].value.args[0].func

# Generated at 2022-06-12 04:27:14.872505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()


# Generated at 2022-06-12 04:27:17.504105
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astor.code_gen import to_source
    from ..utils.ast_helper import ast_parse


# Generated at 2022-06-12 04:27:18.717894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:27:26.793826
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:27:36.102633
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load()))
    assignment = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())], value=yield_from)
    assign_exp = ast.Expr(value=assignment)


# Generated at 2022-06-12 04:27:37.015609
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:46.303420
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import transform

    code = '''
    def foo():
        x = yield from bar()
        yield from bar()
        yield from bar()
    '''


# Generated at 2022-06-12 04:27:56.319513
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        import ast
    from typed_ast import NodeTransformer
    # Assert instantiation and inheritance
    obj = YieldFromTransformer(print, 'typed_ast.ast3')
    assert isinstance(obj, YieldFromTransformer)
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert issubclass(YieldFromTransformer, NodeTransformer)
    # Super
    assert issubclass(super(YieldFromTransformer, obj), BaseNodeTransformer)
    assert issubclass(super(BaseNodeTransformer, obj), NodeTransformer)
    # TypeError
    with pytest.raises(TypeError):
        YieldFromTransformer()  # type: ignore

# Generated at 2022-06-12 04:27:59.500169
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_fixtures.yield_from import MODULE
    from ..engine import Engine
    engine = Engine()
    engine.register_transformer(YieldFromTransformer)
    engine.run_to_end(MODULE)

# Generated at 2022-06-12 04:28:01.242135
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()
    assert a.target==(3, 2)

# Generated at 2022-06-12 04:28:23.729947
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x=YieldFromTransformer()
    pass # TODO: write unit test



# Generated at 2022-06-12 04:28:24.825857
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.target == (3, 2)

# Generated at 2022-06-12 04:28:28.558079
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom()
    target = ast.Assign
    with pytest.raises(AttributeError, match='Neither node.body nor attribute target found'):
        YieldFromTransformer()._emulate_yield_from(yield_from, target)


# Generated at 2022-06-12 04:28:37.191881
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .fixtures import try_fixture
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .unwrap import UnwrapTransformer
    from .for_while import ForLoopTransformer
    from .function_def import InsertMiscellaneousTransformer
    from ..compiler import Compiler
    from ..utils.helpers import get_file_type
    import ast
    import sys

    with open(__file__, 'r') as f:
        _code = f.read()

    _tree = ast.parse(_code)

# Generated at 2022-06-12 04:28:38.818395
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(NotImplementedError):
        YieldFromTransformer()


# Generated at 2022-06-12 04:28:47.455153
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import _check_code
    code = """
    a = yield from foo()
    yield from bar()
    """
    result = """
    def _tmp(iterable):
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value

                break

    _tmp(iter(foo()))
    def _tmp(iterable):
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break

    _tmp(iter(bar()))
    """

    _check_code(code, result, YieldFromTransformer)

# Generated at 2022-06-12 04:28:48.357997
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)

# Generated at 2022-06-12 04:28:56.063967
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import generate_dummy_code
    from .. import UntranspileCode
    try:
        code = generate_dummy_code('''
            def generator(iterable):
                for item in iterable:
                    yield item

            def function():
                a = yield from generator([1, 2, 3])
                yield from generator([a, 4, 5])
        ''')
        async_code = UntranspileCode(code)
        async_code.add_transformer(YieldFromTransformer)
        result = async_code.transpile()
        assert result is not None
    except Exception as e:
        assert False, "Error occurred. %s" % str(e)

# Generated at 2022-06-12 04:28:57.584826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer(None, None)
    assert isinstance(instance, BaseNodeTransformer)

# Generated at 2022-06-12 04:28:58.128908
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:29:47.395144
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .constructor_test import check_constructor
    check_constructor(YieldFromTransformer)



# Generated at 2022-06-12 04:29:48.796146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer."""
    assert(YieldFromTransformer)


# Generated at 2022-06-12 04:29:49.618173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()

# Generated at 2022-06-12 04:29:52.118225
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    parser = ast.parse('def foo(): yield from [1, 2, 3]')
    transformer = YieldFromTransformer()
    transformer.visit(parser)
    eval(compile(parser, '<string>', 'exec'))

# Generated at 2022-06-12 04:30:03.375143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from itertools import chain
    from ..utils.helpers import ast_print
    from ..args_analysis.variable_validator import VariableValidator
    from ..comprehension.compiler import ComprehensionCompiler
    # noinspection PyProtectedMember
    import typed_astunparse
    import astor
    import ast

    class Mock:
        def __init__(self, *args):
            self.args = args


# Generated at 2022-06-12 04:30:06.496068
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("def func(): yield from 1 + 2")
    tree = YieldFromTransformer.run(tree)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert isinstance(tree.body[0].body[0], ast.While)

# Generated at 2022-06-12 04:30:12.132145
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == 'Compiles yield from to special while statement.'
    assert YieldFromTransformer.target == (3, 2)
    assert YieldFromTransformer._tree_changed == False
    YieldFromTransformer._tree_changed = False
    assert YieldFromTransformer._tree_changed == False



# Generated at 2022-06-12 04:30:13.703095
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(config=None, file_cache=None, debug_cache=None)

# Generated at 2022-06-12 04:30:14.884835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-12 04:30:16.138083
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer


# Generated at 2022-06-12 04:32:24.932283
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer({})
    assert hasattr(t, 'target') and isinstance(t.target, tuple)
    assert hasattr(t, 'visit') and callable(t.visit)

# Generated at 2022-06-12 04:32:26.196826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_ = YieldFromTransformer()
    assert class_

# Generated at 2022-06-12 04:32:27.910565
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer(False)
    assert isinstance(result, YieldFromTransformer)
    assert isinstance(result, BaseNodeTransformer)


# Generated at 2022-06-12 04:32:33.888805
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_unicode, source_to_ast
    from astunparse import unparse

    src = source_to_unicode(YieldFromTransformer)
    src = 'from __future__ import generators\n' + src

    ast_tree = source_to_ast(src)
    new_ast = YieldFromTransformer().visit(ast_tree)

    expected_src = source_to_unicode(YieldFromTransformer.expected_tree)
    new_src = unparse(new_ast)

    assert new_src == expected_src

# Generated at 2022-06-12 04:32:35.359817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-12 04:32:39.599878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..import test
    from .. import utils
    from .. import transformers
    from ..visitors.base import BaseVisitor

    class TestVisitor(BaseVisitor):
        def visit_FunctionDef(self, node):
            print(node.body)


# Generated at 2022-06-12 04:32:47.708084
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def foo():
        x = yield from bar()
        y = yield from baz()

    foo()
    """
    tree = ast.parse(code)
    transformer = YieldFromTransformer()
    tree = transformer.visit(tree)

    # Prints in form of string tree,
    # - decorator_list: []
    # - name: foo
    # - args: arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])
    # - body: [Assign(targets=[Name(id='x', ctx=Store())], value=Call(func=Name(id='next', ctx=Load()), args=[Call(func=Name(id='iter', ctx=Load()), args=[Name(id='bar

# Generated at 2022-06-12 04:32:48.168390
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:32:49.802487
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

if __name__ == '__main__':
    from .base import run_main
    run_main(YieldFromTransformer)

# Generated at 2022-06-12 04:32:51.630126
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer(exclude_list=list())
    assert isinstance(x, YieldFromTransformer)
