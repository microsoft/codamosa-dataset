

# Generated at 2022-06-12 04:25:24.597661
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet = ast.parse('yield from some_iterable')
    assert isinstance(YieldFromTransformer().visit(snippet), ast.While)
    assert YieldFromTransformer._tree_changed



# Generated at 2022-06-12 04:25:25.113389
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:25:26.436585
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None

# Generated at 2022-06-12 04:25:31.399539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    module_ast = astor.parse_file('tests/files/yield.py')
    module_ast = YieldFromTransformer().visit(module_ast)
    print(astor.to_source(module_ast))
    # import ctypes
    # mod = ctypes.CDLL("./my_module.so")
    # assert mod.sum_integers(1, 2) == 3

# Generated at 2022-06-12 04:25:32.361308
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-12 04:25:33.310269
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:25:41.667738
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from analyzer.ast import build_ast
    from analyzer.visitors.base import BaseVisitor
    from analyzer.state import State
    from analyzer.visitors.frame import FrameVisitor
    from analyzer.utils.helpers import VariablesGenerator
    import astor
    ast = build_ast("def foo():\n"
                    "  a = 42\n"
                    "  yield from bar()")
    visitor = BaseVisitor(State(), {}, lambda x: astor.to_source(x))
    visitor.run(ast)
    # The next line is equivalent to: visitor.frame_visitor = FrameVisitor(visitor)
    visitor.frame_visitor = FrameVisitor(visitor)
    transformer = YieldFromTransformer(visitor)
    ast = transformer.run(ast)

# Generated at 2022-06-12 04:25:43.770979
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test node has been assigned correctly
    target = (3, 2)
    transformer = YieldFromTransformer(target)
    assert transformer.target == target

# Generated at 2022-06-12 04:25:55.052268
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_node
    from .try_except import TryExceptTransformer
    from .function_def import FunctionDefTransformer
    from .yield_from import YieldFromTransformer
    from .decorator import DecoratorTransformer

    code = '''
    def test(a):
        yield from range(5)
        a = yield from range(5)
        yield from range(5)
        yield from range(5)
        b = yield from range(5)
    '''
    tree = get_node(code)
    tree = DecoratorTransformer().visit(tree)
    tree = YieldFromTransformer().visit(tree)
    tree = TryExceptTransformer().visit(tree)
    tree = FunctionDefTransformer().visit(tree)
    assert code == ast.un

# Generated at 2022-06-12 04:25:56.203116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Test constructor')
    test_transformer = YieldFromTransformer()
    assert test_transformer is not None


# Generated at 2022-06-12 04:26:03.734267
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, "__init__")



# Generated at 2022-06-12 04:26:10.786874
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer."""

    # Example code
    code = '''
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            target = exc.value
        break
'''

    # Create a transformer and apply
    transformer = YieldFromTransformer()
    tree = ast.parse(code)
    result = transformer.visit(tree)

    # Test
    assert(str(result) == str(tree))

# Generated at 2022-06-12 04:26:20.238078
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from typed_ast.ast3 import ClassDef, FunctionDef, Assign, Expr, Name, Str
    from typed_ast.ast3 import YieldFrom, Module, Str, AugAssign, Call, Load
    from typed_ast.ast3 import Subscript, NameConstant, Pass, Store, Tuple, Attribute
    from typed_ast.ast3 import List, Sub, Num
    

# Generated at 2022-06-12 04:26:21.692314
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer

# Unit tests for method visit of class YieldFromTransformer

# Generated at 2022-06-12 04:26:22.465657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:33.797506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_example1 = ast.parse(
        'def foo(b):\n'
        '    a = yield from [3,4,5]'
    )
    ast_example2 = ast.parse(
        'def foo(b):\n'
        '    yield from [3,4,5]'
    )
    ast_example3 = ast.parse(
        'def foo(b):\n'
        '    a = 3\n'
        '    yield from [3, 4, 5]'
    )
    ast_example4 = ast.parse(
        'def foo(b):\n'
        '    a = yield from [3, 4, 5]\n'
        '    print(a)'
    )

# Generated at 2022-06-12 04:26:44.484758
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  import json
  import sys, os
  # 
  concrete_path = sys.modules[__name__].__file__
  proj_path = os.path.abspath(os.path.join(os.path.dirname(concrete_path), '..', '..'))
  # 
  sys.path.append(proj_path)
  from benchmarks.general.visitor import visitor_generator_string  # pylint: disable=wrong-import-position
  from benchmarks.general.visitor import visitor_generator_unit_tests  # pylint: disable=wrong-import-position
  # 
  concrete_class = sys.modules[__name__].YieldFromTransformer
  visitor_generator_unit_tests(concrete_path, concrete_class)


# Generated at 2022-06-12 04:26:46.273718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node_transformer = YieldFromTransformer()
    assert node_transformer


# Generated at 2022-06-12 04:26:48.490939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astunparse import unparse
    from astmonkey import transformers


# Generated at 2022-06-12 04:26:50.116036
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_base import NodeTest
    NodeTest(YieldFromTransformer)

# Generated at 2022-06-12 04:27:01.430689
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:27:02.420331
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True



# Generated at 2022-06-12 04:27:03.505844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None

# Generated at 2022-06-12 04:27:04.244274
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    item = YieldFromTransformer()

# Generated at 2022-06-12 04:27:14.961408
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import FunctionDef, Module, Load, Name, Expr, While, For, If, Try

    assert YieldFromTransformer()._get_yield_from_index(Module(body=[FunctionDef(name='foo', body=[])]), ast.Expr) is None
    assert YieldFromTransformer()._get_yield_from_index(Module(body=[
        FunctionDef(body=[
            Expr(value=Load()),
            Expr(value=Name()),
            Expr(value=Load())
        ])
    ]), ast.Expr) == 1


# Generated at 2022-06-12 04:27:16.398588
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-12 04:27:17.491894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer()


# Generated at 2022-06-12 04:27:20.819413
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)
    assert instance.target == (3, 2)
    assert instance._tree_changed == False


# Generated at 2022-06-12 04:27:21.650471
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass # No need to test the constructor.

# Generated at 2022-06-12 04:27:23.049622
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)


# Generated at 2022-06-12 04:27:48.328974
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...node_transformation import NodeTransformation
    from .yield_from import YieldFromTransformer
    
    node_transformer = NodeTransformation(transformers=[YieldFromTransformer()])
    node_transformer.run_transformation([YieldFromTransformer()])


# Generated at 2022-06-12 04:27:49.250762
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:50.146463
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    y = YieldFromTransformer()


# Generated at 2022-06-12 04:27:51.530600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)



# Generated at 2022-06-12 04:27:52.414806
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:02.420931
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft._get_yield_from_index(None, ast.Assign) is None
    assert yft._get_yield_from_index(None, ast.Expr) is None
    assert yft._get_yield_from_index(ast.FunctionDef(name='abc'), ast.Expr) is None
    assert yft._get_yield_from_index(ast.FunctionDef(body=[]), ast.Expr) is None
    assert yft._get_yield_from_index(ast.FunctionDef(body=[ast.Expr(ast.YieldFrom(ast.Num(1)))]), ast.Expr) == 0

# Generated at 2022-06-12 04:28:03.297325
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:04.141224
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(None)



# Generated at 2022-06-12 04:28:05.712974
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_name = YieldFromTransformer.__name__
    assert class_name == "YieldFromTransformer"

# Generated at 2022-06-12 04:28:14.918075
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from testfixtures import compare

    class UnitTestYieldFromTransformer(YieldFromTransformer):
        def __init__(self):
            super().__init__(None)
            self._tree_changed = False
            self._changed = False

    class MockTree:
        def __init__(self):
            self.body = []

        def add_node(self, node):
            self.body.append(node)

        def insert_node(self, node, index):
            self.body.insert(index, node)

        def get_node(self, index):
            return self.body[index]

        def pop_node(self, index):
            return self.body.pop(index)

    test_tree = MockTree()


# Generated at 2022-06-12 04:29:00.961580
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)

# Generated at 2022-06-12 04:29:03.422002
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    This function tests the constructor of class YieldFromTransformer.
    """
    nodeTransformer = YieldFromTransformer()
    assert isinstance(nodeTransformer, BaseNodeTransformer)


# Generated at 2022-06-12 04:29:11.466253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .optimizer import Optimizer
    from .utils import dump_tree, load_tree, compile_snippet

    def test_transform(code: str) -> str:
        tree = load_tree(code)
        transformer = YieldFromTransformer()
        optimizer = Optimizer([transformer])
        optimizer.visit(tree)
        return dump_tree(tree)

    def assert_unchanged(code: str) -> None:
        output = test_transform(code)
        assert code == output

    def test_compiled(code: str) -> None:
        output = test_transform(code)
        compiled = compile_snippet(output, '<test>', 'exec')
        exec(compiled)

    assert_unchanged('def func():\n'
                     '    yield 1')

    test_comp

# Generated at 2022-06-12 04:29:12.729376
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Create instance of class YieldFromTransformer
    YieldFromTransformer()

# Generated at 2022-06-12 04:29:21.354657
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    # Just for type checking: we create an instance of the class and call its methods
    # The except clause is because some of the methods are abstract

# Generated at 2022-06-12 04:29:23.070589
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:29:31.733834
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..pygram import python_symbols as sympy
    from ..utils import make_fake_tree


# Generated at 2022-06-12 04:29:32.508174
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer


# Generated at 2022-06-12 04:29:40.657715
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tree_editor import TreeEditor
    from ..codegen import to_source
    from .node_transformer import NodeTransformerPipeline
    from .compats import AsyncFunctionTransformer
    from .type_annotations import TypeAnnotationTransformer
    from .constant_folding import ConstantFoldingTransformer
    from .native_iterators import NativeIteratorTransformer
    from .eval_nodes import EvalNodesTransformer
    from .return_nodes import ReturnTransformer
    from .implicit_returns import ImplicitReturnTransformer
    from .async_comprehensions import AsyncComprehensionTransformer
    from .await_nodes import AwaitTransformer
    from .import_transformer import ImportTransformer
    from .comprehensions import ComprehensionTransformer


# Generated at 2022-06-12 04:29:41.720462
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a=0
    assert(a==0)
    return


# Generated at 2022-06-12 04:31:46.594998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yieldFromTransformer = YieldFromTransformer()
    yieldFromTransformer.visit()


# Generated at 2022-06-12 04:31:47.461147
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    y = YieldFromTransformer()
    assert y is not None
    return y

# Generated at 2022-06-12 04:31:49.354985
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test case for constructor of class YieldFromTransformer."""
    YieldFromTransformer()




# Generated at 2022-06-12 04:31:50.591249
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # This is a simple unit test that
    # checks if the constructor works without errors.
    transformer = YieldFromTransformer()

# Generated at 2022-06-12 04:31:51.363673
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:31:52.131323
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)

# Generated at 2022-06-12 04:31:54.642871
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    #Arrange
    test_obj = YieldFromTransformer()
        
    #Act
    actual_result = test_obj

    #Assert
    assert actual_result is not None

# Generated at 2022-06-12 04:31:55.757548
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-12 04:31:56.417824
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:32:04.688117
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import source_to_code, source_to_ast
    from ..utils.helpers import to_source
    from ..utils.tree import dump_tree
    import astor

    code = '''
    def foo():
        result = yield from bar()
        return result
    '''
    tree = source_to_ast(code)
    assert tree is not None

    transformer = YieldFromTransformer()
    new_tree = transformer.visit(tree)

    assert astor.to_source(new_tree) == '''
    def foo():
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    result = exc.value

                break
        return result
    '''