

# Generated at 2022-06-12 04:25:25.189741
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_python import Function
    from typed_python.compiler.python_ast_to_typed_python_ast import make_typed_python_transformer
    @Function
    def f():
        yield from [1, 2]

    tree = ast.parse("f()")
    transform = make_typed_python_transformer()
    transform.visit(tree)
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-12 04:25:28.715179
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for __init__ of class YieldFromTransformer

    # __init__ of class YieldFromTransformer
    Yft = YieldFromTransformer.__new__(YieldFromTransformer)

    # assert attributes
    assert Yft.target == (3, 2)

# Generated at 2022-06-12 04:25:37.547955
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer_body = """
x = yield from range(10)
yield from range(11)
    """
    test_YieldFromTransformer_expected = """
iterable = iter(range(10))
while True:
    try:
        x = next(iterable)
        yield x
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            x = exc.value
        break

exc = exc
iterable = iter(range(11))
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            exc = exc.value
        break

"""
    tn = YieldFromTransformer()

# Generated at 2022-06-12 04:25:39.023121
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print("Testing YieldFromTransformer")
    YieldFromTransformer()


__transformer__ = YieldFromTransformer

# Generated at 2022-06-12 04:25:39.871342
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:25:40.711866
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:25:43.473344
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Unit test for constructor of class YieldFromTransformer')
    print('Check it can be created.')
    try:
        YieldFromTransformer()
        print('  Passed.')
    except:
        print('  Failed.')

# Generated at 2022-06-12 04:25:45.002054
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:25:53.469426
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...tokenizer import Tokenizer
    from ...parser import Parser
    from ...ast_transformer import ASTTransformer
    from ...unparser import Unparser
    from .yield_from import YieldFromTransformer

    assert issubclass(YieldFromTransformer, ASTTransformer)

    code = '''yield from some_iterator'''
    tree = Parser(Tokenizer(code)).parse()

    transformer = YieldFromTransformer(tree)

    node = transformer.visit(ast.parse(code))  # type: ignore


# Generated at 2022-06-12 04:26:00.812373
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump

    # Example of use YieldFromTransformer
    code = """
        def simple_generator(a):
             for i in range(a):
                 yield i

        def foo():
            x = simple_generator(5)
    """
    expected = """
        def simple_generator(a):
             for i in range(a):
                 yield i


        def foo():
            iterable = None
            iterable = iter(simple_generator(5))
            while True:
                try:
                    x = next(iterable)
                except StopIteration as exc:
                    if hasattr(exc, 'value'):
                        x = exc.value
                    break
    """

    node = source(code, 'exec')
    node = Yield

# Generated at 2022-06-12 04:26:07.169284
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:14.436991
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.ast_builder import ast_from
    from .. import visitors, visitors_classes

    assert visitors.get_visitor_class(visitors.TransformationType.COMPILATION, ast_from('''
a = 1
''')) is None

    assert visitors.get_visitor_class(visitors.TransformationType.COMPILATION, ast_from('''
yield from (x for x in x)
''')) is visitors_classes.YieldFromTransformer

    assert visitors.get_visitor_class(visitors.TransformationType.COMPILATION, ast_from('''
yield from (x for x in x)
yield
yield from (x for x in x)
''')) is visitors_classes.YieldFromTransformer


# Generated at 2022-06-12 04:26:15.898753
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).target == (3, 2)



# Generated at 2022-06-12 04:26:20.777864
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = '''def f():
        yield from range(3)'''
    tree = ast.parse(code)
    transformed = YieldFromTransformer().visit(tree)
    transformed_code = compile(transformed, '<string>', 'exec')
    exec(transformed_code)
    f = locals()['f']
    assert list(f()) == [0, 1, 2]

# Generated at 2022-06-12 04:26:21.600132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()



# Generated at 2022-06-12 04:26:32.918809
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def assert_code_equal(left, right):
        left = ast.parse(left).body[0].body
        right = ast.parse(right).body[0].body
        _ = YieldFromTransformer()
        assert _.visit(left) == right

    yield_from = ast.YieldFrom(value=ast.Name(id='bar', ctx=ast.Load()))
    assert_code_equal('''
        yield from bar
    ''', '''
        let(iterable)
        iterable = iter(bar)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')

# Generated at 2022-06-12 04:26:38.382477
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import assert_transform

    code = """
    yield from x
    """
    expected_code = """
    let(exc, iterable)
    iterable = iter(x)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    """

    assert_transform(YieldFromTransformer, code, expected_code)



# Generated at 2022-06-12 04:26:39.741215
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .fixtures import constructor_test
    constructor_test(YieldFromTransformer)

# Generated at 2022-06-12 04:26:42.986259
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..base import BaseNodeTransformer
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    # TODO add more tests


# Generated at 2022-06-12 04:26:47.579891
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..transformers.yield_from import YieldFromTransformer

    assert(repr(YieldFromTransformer()) == '<YieldFromTransformer target:(3, 2)>')
    assert(YieldFromTransformer().visit(ast.FunctionDef) is not None)
    assert(YieldFromTransformer().visit(ast.arguments) is not None)



# Generated at 2022-06-12 04:27:06.676577
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformerTest
    import astor
    import textwrap
    class Test(BaseNodeTransformerTest):
        TRANSFORMER = YieldFromTransformer
        CODE = textwrap.dedent('''\
            def f():
                a, b = 1, yield from c
                yield from d
                print(1)
                try:
                    yield from e
                except:
                    f()
                else:
                    yield from g
                finally:
                    yield from h
                while True:
                    yield from i
        ''')

# Generated at 2022-06-12 04:27:10.910702
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .lineno import LinenoTransformer
    from .context_managers import ContextManagersTransformer
    from .async_generators import AwaitTransformer, AsyncGeneratorsTransformer


# Generated at 2022-06-12 04:27:11.815034
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-12 04:27:18.825718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from ..utils import as_dict
    from .common import ExampleNodeVisitor

    class TestVisitor(ExampleNodeVisitor):
        def visit_FunctionDef(self, node):
            return YieldFromTransformer().visit(node)

        def visit_Expr(self, node):
            return YieldFromTransformer().visit(node)

    for node in [ast3.parse("def f():\n    yield from x"),
                 ast3.parse("yield from x"),
                 ast3.parse("x = yield from y"),
                 ast3.parse("yield from y + x")]:
        res = TestVisitor().visit(node)
        assert isinstance(res, ast3.FunctionDef) or isinstance(res, ast3.Expr)


# Generated at 2022-06-12 04:27:20.401907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None


# Generated at 2022-06-12 04:27:27.126794
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast_helper import ast_to_code, extract_node, parse_snippet
    from asttokens import ASTTokens
    from compat import parse

    atok = ASTTokens(parse_snippet('''
    def foo():
        a = yield from something
        b = yield from something_else
        c = yield something_else_again
    '''), parse=parse)
    mod = atok.tree
    foo = extract_node(mod, 'FunctionDef')
    assert foo is not None

# Generated at 2022-06-12 04:27:27.624380
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:27:28.449350
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:27:30.025550
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except NameError:
        assert False
    assert True

# Generated at 2022-06-12 04:27:31.469172
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..stubgen.syntax import parse


# Generated at 2022-06-12 04:27:42.256449
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:27:44.745088
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).__class__ == YieldFromTransformer
    assert isinstance(YieldFromTransformer(None), YieldFromTransformer)


# Generated at 2022-06-12 04:27:54.459918
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from textwrap import dedent
    tree = ast.parse(dedent('''
    def func(value):
        res = []
        while True:
            try:
                value = next(value)
            except StopIteration as exc:
                if res:
                    yield res
                    res = []
                else:
                    break
            else:
                res.append(value)
    '''))

# Generated at 2022-06-12 04:28:03.996405
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test for initialization
    tf = YieldFromTransformer(None, None)
    assert tf.node is None
    assert tf.parent is None
    assert tf.depth == 0
    assert tf.path == []
    assert tf.special_nodes == []
    assert tf.sp_stack == []
    assert tf.tree_changed is False
    assert tf.target == (3, 2)
    # test for get_yield_from_index
    node = ast.parse("""def f():
        a = yield from g()
        return a""")
    assert tf._get_yield_from_index(node, ast.Assign) == 0
    # test for emulate_yield_from
    target = ast.parse("a").body[0].value

# Generated at 2022-06-12 04:28:13.503693
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..converter import Converter
    from ..errors import WrongTargetError
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import tree
    from ..codegen.generator import CodeGenerator

    converter = Converter()
    valid_code = '''
    def foo():
        def bar():
            yield from baz()
    '''
    invalid_code = '''
    def foo():
        def bar():
            if True:
                yield from baz()
    '''
    invalid_code_with_stop_iteration = '''
    def foo():
        def bar():
            try:
                yield from baz()
            except StopIteration:
                pass
    '''

# Generated at 2022-06-12 04:28:21.866263
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.Module([ast.Assign([ast.Name('target', ast.Store())], ast.YieldFrom(ast.Name('generator', ast.Load())))])
    trans = YieldFromTransformer()
    ast.fix_missing_locations(trans.visit(node))
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.While)
    assert isinstance(node.body[0].body[0], ast.Expr)
    assert isinstance(node.body[0].body[0].value, ast.Yield)
    assert isinstance(node.body[0].body[0].value.value, ast.Call)
    assert isinstance(node.body[0].body[0].value.value.func, ast.Name)

# Generated at 2022-06-12 04:28:22.989215
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert(YieldFromTransformer() is not None)


# Generated at 2022-06-12 04:28:31.051708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Input
    code = """
    a, b = yield from generator
    """

    # Expected results
    expected_code = """
    let(exc)
    let(iterable)
    iterable = iter(generator)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                exc = exc.value
            a, b = exc
            break
    """

    node = ast.parse(code, mode = "exec")
    YieldFromTransformer().visit(node)

    assert astor.to_source(node).strip() == expected_code.strip()
    # astor.dump(node)



# Generated at 2022-06-12 04:28:32.180282
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit tests for constructor of class YieldFromTransformer"""
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:33.570599
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class_under_test = YieldFromTransformer()
    assert class_under_test


# Generated at 2022-06-12 04:28:55.992709
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:28:56.870883
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:58.005755
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): # TODO: implement this
    print("We should write tests for YieldFromTransformer!")

# Generated at 2022-06-12 04:29:01.961000
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from ..utils import helpers

    code = """from a import b
b = yield from c"""
    tree = ast3.parse(code)
    helpers.run_transformer_on_tree(tree, YieldFromTransformer)
    assert helpers.code_from_ast(tree) == 'from a import b\nb = yield from c'

# Generated at 2022-06-12 04:29:02.810140
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:29:08.334216
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .ast_converter import to_ast, from_ast
    from ..utils.source import source_to_unicode
    from ..utils.tree import get_as_str

    code = source_to_unicode('''
    def func():
        yield from x
        (yield from x)
        a = yield from x
    ''')
    ast_tree = to_ast(code)
    YieldFromTransformer().visit(ast_tree)


# Generated at 2022-06-12 04:29:16.891002
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:29:18.136295
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, "__init__")


# Generated at 2022-06-12 04:29:27.527629
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    data = {'name': 'John Doe', 'role': 'Customer'}
    class_, _ = trans.process("""
    def get_employees(self):
        for idx in range(10):
            yield from self.get_data(idx)

    def get_data(self, idx):
        if idx % 2 == 0:
            yield self.format_name(idx)
        else:
            yield self.format_title(idx)

    def format_name(self, idx):
        return '{}, {} {}'.format(idx, data['name'], data['role'])

    def format_title(self, idx):
        return '{}: {}'.format(idx, data['role'])
    """)
    return class_

# Generated at 2022-06-12 04:29:29.951821
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == "YieldFromTransformer"


# Generated at 2022-06-12 04:30:30.235470
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helper import generate_dummy_source
    from ..core import run_transformation_pipeline
    from .base import BaseAnnotationsTransformer
    from .async_generators import AsyncGeneratorsTransformer
    from .keyword_only_arguments import KeywordOnlyArgumentsTransformer

    for i in range(10):
        source = generate_dummy_source()
        run_transformation_pipeline(source, [
            AsyncGeneratorsTransformer,
            KeywordOnlyArgumentsTransformer,
            YieldFromTransformer,
            BaseAnnotationsTransformer,
        ])

# Generated at 2022-06-12 04:30:31.123265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:30:35.099272
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .visitor import VariableFreeVisitor

    from ..utils.helpers import fake_lib_module, fake_module

    from ..utils.source import Source

    from ..rewrite import RewriteMeta

    from ..snippets.base import BaseSnippets


# Generated at 2022-06-12 04:30:36.019389
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:30:37.193344
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:30:38.531265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  YieldFromTransformer()
  print('Unit test for class YieldFromTransformer passed')


# Generated at 2022-06-12 04:30:45.633923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import print_ast, parse_ast
    from ..tests.results import yield_from_result

    code1 = '''def foo():
    y = yield from bar()
    y = yield from bar()
    yield from bar()
    return yield from bar()
'''

    ast1 = parse_ast(code1)
    result1 = yield_from_result

    transformer = YieldFromTransformer()
    new_ast = transformer.visit(ast1)

    print('Comparing the ASTs:')
    print(print_ast(new_ast))
    print(print_ast(result1))
    assert ast.dump(new_ast) == ast.dump(result1)

# Generated at 2022-06-12 04:30:48.139226
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .fixtures import module3_2
    from ..utils import ast as astutils

    module = YieldFromTransformer(module3_2)
    assert module is not None

# Generated at 2022-06-12 04:30:49.509405
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)

# Generated at 2022-06-12 04:30:58.318270
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astroid import builder

    class_a = builder.parse('''
        class A(object):
            def __init__(self):
                self.foo = 0
                self.bar = (lambda x: x)(yield from self.get_value())

            def get_value(self):
                yield from (x for x in range(10))
    ''').body[0]

    class_b = builder.parse('''
        class B(object):
            def __init__(self):
                self.foo = 0
                self.bar = yield from self.get_value()

            def get_value(self):
                yield from (x for x in range(10))
    ''').body[0]


# Generated at 2022-06-12 04:33:04.798288
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:33:06.228707
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)


# Generated at 2022-06-12 04:33:08.948875
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # try:
    #     yf = YieldFromTransformer()
    #     print("To unit test")
    #     print(yf)
    # except Exception as e:
    #     print(e)
    pass

# Generated at 2022-06-12 04:33:13.589407
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def func():
        yield_from (x for x in (1, 2, 3))
        a = yield_from (x for x in (1, 2, 3))

    t = YieldFromTransformer()
    assert t._get_yield_from_index(func.__code__, ast.Assign) == 1
    assert t._get_yield_from_index(func.__code__, ast.Expr) == 0



# Generated at 2022-06-12 04:33:15.593173
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer(2)
        assert False,'YieldFromTransformer takes exactly 0 arguments (1 given)'
    except TypeError:
        assert True

# Generated at 2022-06-12 04:33:17.041088
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer(version="3.6")

# Generated at 2022-06-12 04:33:17.839091
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:33:22.621859
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import parse
    node = parse('a = yield from b')
    YieldFromTransformer().visit(node)
    assert YieldFromTransformer().visit(node) == 'a = yield from b'
    assert YieldFromTransformer().visit(node) != 'a = yield from b'

# Generated at 2022-06-12 04:33:26.576281
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node1 = ast.parse('yield from a')
    node2 = ast.parse('a = yield from a')
    YieldFromTransformer().visit(node1)
    YieldFromTransformer().visit(node2)
    assert node1 == ast.parse('yield from a')
    assert node2 == ast.parse('a = yield from a')


# Generated at 2022-06-12 04:33:34.499599
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.target == (3, 2)
    assert isinstance(YieldFromTransformer(None).tree_changed, bool)
    x = YieldFromTransformer(None)
    assert x.tree_changed is True
    assert isinstance(x._emulate_yield_from(None, None), list)
    assert isinstance(x._get_yield_from_index(None, None), int)
    assert isinstance(x._handle_assignments(None), ast.AST)
    assert isinstance(x._handle_expressions(None), ast.AST)
    assert isinstance(x.visit(None), ast.AST)