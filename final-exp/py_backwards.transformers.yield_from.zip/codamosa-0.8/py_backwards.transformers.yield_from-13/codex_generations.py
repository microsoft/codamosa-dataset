

# Generated at 2022-06-12 04:25:23.306919
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.ast_builder import ast_from_code, ast_to_code
    from ..utils.helpers import VariablesGenerator
    from ..utils.tree import ast_to_tree, ast_tree_to_text

# Generated at 2022-06-12 04:25:32.462940
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer("test", "test") != None
    assert YieldFromTransformer("test", [1,2,3]) != None
    assert YieldFromTransformer("test", "test")._get_yield_from_index(node="test", type_=Holder) != None
    assert YieldFromTransformer("test", [1,2,3])._get_yield_from_index(node=Node,type_=Holder) != None
    assert YieldFromTransformer("test", "test")._get_yield_from_index(node=Node,type_=Holder) != None
    assert YieldFromTransformer("test", [1,2,3])._emulate_yield_from(target=Optional[ast.AST],node="test") != None

# Generated at 2022-06-12 04:25:33.395504
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass



# Generated at 2022-06-12 04:25:41.707171
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # type: () -> None
    from ..utils.testing import assert_in, assert_not_in
    from ..utils.helpers import parse_to_ast
    import textwrap

    def check(source):
        # type: (str) -> None
        code = parse_to_ast(textwrap.dedent(source))
        res = YieldFromTransformer.run_on_code(code)
        assert_not_in('yield_from', res)

    def check_error(source):
        # type: (str) -> None
        code = parse_to_ast(textwrap.dedent(source))
        res = YieldFromTransformer.run_on_code(code)
        assert_in('yield_from', res)


# Generated at 2022-06-12 04:25:43.473735
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..transpiler import ExpressionTranspiler
    from ..utils.helpers import get_ast, dump_ast


# Generated at 2022-06-12 04:25:54.726153
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
# class YieldFromTransformer(BaseNodeTransformer):
#     """Compiles yield from to special while statement."""
#     target = (3, 2)
#
#     def _get_yield_from_index(self, node: ast.AST,
#                               type_: Type[Holder]) -> Optional[int]:
#         if hasattr(node, 'body') and isinstance(node.body, list):  # type: ignore
#             for n, child in enumerate(node.body):  # type: ignore
#                 if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
#                     return n
#
#         return None
#
#     def _emulate_yield_from(self, target: Optional[ast.AST],
#                             node: ast.

# Generated at 2022-06-12 04:25:55.576292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer()

# Generated at 2022-06-12 04:25:56.399994
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:26:01.967564
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import source_to_ast as ast_test
    from ..utils.test_utils import ast_to_source as ath_test
    node = '''def foo(gen):
    yield from gen
    yield gen
    return gen'''
    node_result = '''def foo(gen):
    let(exc, iterable)
    iterable = iter(gen)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    yield gen
    return gen'''
    ast_test = ast_test(node)
    ast_result = YieldFromTransformer().visit(ast_test)
    assert ath_test(ast_result) == node_result

# Generated at 2022-06-12 04:26:03.682168
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    c = YieldFromTransformer()


# Generated at 2022-06-12 04:26:15.293341
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try_ = ast.Try(body=[],
                   handlers=[],
                   orelse=[],
                   finalbody=[])
    try_.body.append(ast.Assign(targets=[ast.Name(id='f', ctx=ast.Store())], value=ast.Name(id='a', ctx=ast.Load())))
    try_.body.append(ast.Assign(targets=[ast.Name(id='f', ctx=ast.Store())], value=ast.Name(id='a', ctx=ast.Load())))
    assert YieldFromTransformer(try_).node == try_

    if_ = ast.If(test=ast.Name(id='a', ctx=ast.Load()), body=[], orelse=None)

# Generated at 2022-06-12 04:26:15.854449
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	pass

# Generated at 2022-06-12 04:26:21.633572
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ast_tree = ast.parse("a = yield from b")
    new_tree = YieldFromTransformer().visit(ast_tree)
    expected_tree = ast.parse("a = (lambda exc: exc.value if hasattr(exc, 'value') else None)(StopIteration(None)) while True: iterable = iter(b) while True: try: yield next(iterable) except StopIteration as exc: break")
    assert ast.dump(new_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:26:22.431086
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:26:23.927835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:31.232638
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import get_root
    from .. import Compiler
    c = Compiler(
        [get_root("testdata/source/yield_from/test_yield_from_assign.py")],
        YieldFromTransformer)
    c.compile()
    c = Compiler(
        [get_root("testdata/source/yield_from/test_yield_from_expr.py")],
        YieldFromTransformer)
    c.compile()

# Generated at 2022-06-12 04:26:32.174974
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:33.132580
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_node_transformer import get_tree


# Generated at 2022-06-12 04:26:34.359090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""



# Generated at 2022-06-12 04:26:45.296594
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Unit test for method _get_yield_from_index
    def test_get_yield_from_index(node, type_, result):
        t = YieldFromTransformer()
        assert t._get_yield_from_index(node, type_) == result

    test_get_yield_from_index(
        ast.parse('from __future__ import generator_stop\n'
                  'def foo():\n'
                  '    yield from foo()\n'
                  '    yield from bar()\n',
                  'exec'),
        ast.FunctionDef,
        0,
    )


# Generated at 2022-06-12 04:27:00.915271
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .python_inputs import YieldFrom
    from .python_trees import PythonTree
    # pylint: disable=E1120
    python_tree = PythonTree.get_class("YieldFrom")
    snippet = "yield_from = YieldFrom.get_snippet()"
    assert YieldFromTransformer().visit(YieldFrom.get_tree()) == python_tree.get_tree(snippet)

# Generated at 2022-06-12 04:27:02.370228
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()
    assert a is not None


# Generated at 2022-06-12 04:27:05.578907
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast
    from .test_base import BaseNodeTransformerTest
    from .test_yield import test_YieldTransformer
    from .test_generator_expressions import test_GeneratorExpressionsTransformer


# Generated at 2022-06-12 04:27:07.440821
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:08.768886
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None


# Generated at 2022-06-12 04:27:16.108055
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .visitor import transform
    from ..utils.helpers import ast_print
    from .helpers import parse

    tree = transform(parse("""
        async def a():
            i = (x for x in (yield from [2, 3]))
            i = yield from [2, 3]
            i = yield from
            i = (yield from)
            i = yield from [2, 3 + (yield from gen(yield from [2, 3]))]
            i = yield from [2, 3]
        """), YieldFromTransformer)
    ast_print(tree)


__all__ = ['YieldFromTransformer']

# Generated at 2022-06-12 04:27:25.165890
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc = ast.Name(id='exc', ctx=ast.Load())
    target = ast.Name(id='target', ctx=ast.Store())

# Generated at 2022-06-12 04:27:26.373487
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:27:27.385251
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
   YieldFromTransformer()


# Generated at 2022-06-12 04:27:30.758648
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor

    @snippet
    def x():
        yield from iter(range(5))
        yield from iter(range(5))

    print(astor.to_source(x))

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:27:50.331388
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-12 04:27:52.376444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import transformer
    transformer.YieldFromTransformer()

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:27:54.459554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print("Testing constructor of class YieldFromTransformer")
    YieldFromTransformer()




# Generated at 2022-06-12 04:27:55.988820
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()
    print("OK")


# Generated at 2022-06-12 04:27:57.358661
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()
    assert tr is not None

# Generated at 2022-06-12 04:27:58.384679
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer((3, 2))

# Generated at 2022-06-12 04:28:02.981274
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("from typing import Optional, List\n"
                     "def transform_from(a: int) -> Optional[int]:\n"
                     "    b = yield from [x for x in range(0, a)]\n"
                     "    return b")
    node = YieldFromTransformer().visit(node)
    assert node is not None

# Generated at 2022-06-12 04:28:03.836831
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:05.913810
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import parse_snippet
    from ..utils.helpers import get_ast_diff


# Generated at 2022-06-12 04:28:08.415847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()._tree_changed == False
    assert YieldFromTransformer().target == (3,2)

# Generated at 2022-06-12 04:28:46.925854
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()


# Generated at 2022-06-12 04:28:48.552240
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from autopep8 import YieldFromTransformer

    assert(YieldFromTransformer is not None)

# Generated at 2022-06-12 04:28:49.716311
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is YieldFromTransformer

# Generated at 2022-06-12 04:28:50.974113
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert repr(YieldFromTransformer)


# Generated at 2022-06-12 04:28:59.144239
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Variables
    line_number = 1

# Generated at 2022-06-12 04:29:00.283862
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)


# Generated at 2022-06-12 04:29:02.355897
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    import inspect
    src = inspect.getsource(YieldFromTransformer)
    tree = ast.parse(src)
    print(astor.to_source(tree))

# Generated at 2022-06-12 04:29:08.107737
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print('Executing test_YieldFromTransformer for YieldFromTransformer.')

    class Dummy:
        def __init__(self, i):
            self.i = i
        def __iter__(self):
            return self
        def __next__(self):
            if self.i == 2:
                raise StopIteration
            self.i += 1
            return self.i

    obj = Dummy(0)
    a = []
    print(type(obj))
    for x in obj:
        print(x)
        a.append(x)

    exp = []
    for x in a:
        exp.append(x)

    print(a)
    print(exp)
    assert a == exp

    print('Finished executing test_YieldFromTransformer for YieldFromTransformer.')

# Generated at 2022-06-12 04:29:08.876705
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:29:13.084875
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom()
    exc = VariablesGenerator.generate('var')
    assignment = result_assignment.get_body(exc=exc, target=yield_from)
    yield_from = yield_from.get_body(generator=yield_from,
                                     exc=exc,
                                     assignment=assignment)
    return yield_from

# Generated at 2022-06-12 04:30:59.614576
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .unpacking_transformer import UnpackingTransformer
    up = UnpackingTransformer()
    yft = YieldFromTransformer()
    import astor

    code = """
    def f():
        yield from (1, 2, 3)
        return 7, 8, 9
    """

    ast_tree = ast.parse(code)
    up.visit(ast_tree)
    yft.visit(ast_tree)
    print(astor.to_source(ast_tree))

    ast_tree = ast.parse(code)
    yft.visit(ast_tree)
    print(astor.to_source(ast_tree))

# Generated at 2022-06-12 04:31:02.302509
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('def foo():yield x; yield from foo()')
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-12 04:31:06.967572
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.target == (3,2)
    assert YieldFromTransformer._tree_changed == False
    assert YieldFromTransformer._exc is None
    assert YieldFromTransformer._assignment is None
    assert YieldFromTransformer._target is None
    assert YieldFromTransformer._generator is None
    assert YieldFromTransformer._yield_from_index is None

# Generated at 2022-06-12 04:31:12.852108
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestYieldFromTransformer:
        def __init__(self, node: ast.AST, expected: ast.AST):
            yieldfrom_transformer = YieldFromTransformer(tree=node)
            yieldfrom_transformer.visit(node)
            assert yieldfrom_transformer._tree == expected

    class EmulateYieldFrom(YieldFromTransformer):
        def _emulate_yield_from(self, target: Optional[ast.AST],
                                node: ast.YieldFrom) -> List[ast.AST]:
            return node.value.elts

    class HandleAssignments(YieldFromTransformer):
        def _handle_assignments(self, node: Node) -> Node:
            return node.value.name  # type: ignore


# Generated at 2022-06-12 04:31:20.737246
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with open(os.path.abspath(
                os.path.join(os.path.dirname(__file__),
                os.pardir, "tests/cases/yield_from_assign.py"))) as f:
        snippet = f.read()
        tree = ast.parse(snippet)
        transformer = YieldFromTransformer()
        transformer.visit(tree)
        with open(os.path.abspath(
                os.path.join(os.path.dirname(__file__),
                os.pardir, "tests/cases/res/yield_from_assign.py")), 'r') as f2:
            result = f2.read()
            assert ast.parse(result) == tree

# Generated at 2022-06-12 04:31:21.423796
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:31:23.097685
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestYieldFromTransformer(YieldFromTransformer):
        def __init__(self):
            super().__init__()

    TestYieldFromTransformer()

# Generated at 2022-06-12 04:31:25.717780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.parser import parse
    from .base import transform
    from .transforms import YieldFromTransformer

    transform(parse("yield from a"), YieldFromTransformer)

# Generated at 2022-06-12 04:31:28.355440
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..main import run_transfromer_on_tree
    from ..utils.parser import parse_module
    from .yield_from import yield_from_code

    YieldFromTransformer().visit(parse_module(yield_from_code))



# Generated at 2022-06-12 04:31:29.638140
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).__class__.__name__ == 'YieldFromTransformer'