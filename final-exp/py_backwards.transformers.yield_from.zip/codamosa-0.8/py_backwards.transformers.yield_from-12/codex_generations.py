

# Generated at 2022-06-12 04:25:21.361214
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    y = YieldFromTransformer()


# Generated at 2022-06-12 04:25:22.135219
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:25:28.668889
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.FunctionDef(name='func')
    t = YieldFromTransformer()
    assert isinstance(t, BaseNodeTransformer)
    assert hasattr(t, 'target')
    assert hasattr(t, '_get_yield_from_index')
    assert hasattr(t, '_emulate_yield_from')
    assert hasattr(t, '_handle_assignments')
    assert hasattr(t, '_handle_expressions')
    assert hasattr(t, 'visit')
    assert t.visit(node) is None

# Generated at 2022-06-12 04:25:37.502706
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  from .base import BaseNodeTransformer
  import ast
  class YieldFromTransformer(BaseNodeTransformer):
    """Compiles yield from to special while statement."""
    target = (3, 2)
    def _get_yield_from_index(self, type_: Type[Holder]) -> Optional[int]:
      return None

    def _emulate_yield_from(self, assignment):
      return None

    def _handle_assignments(self) -> Node:
      return None

    def _handle_expressions(self) -> Node:
      return None

    def visit(self, node: ast.AST) -> ast.AST:
      node = self._handle_assignments() # type: ignore
      node = self._handle_expressions() # type: ignore
      return self.generic_visit(node)

# Generated at 2022-06-12 04:25:47.430409
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_name
    from ..utils.ast_builder import build_ast
    from ..utils.tree import check_equal_ast, parse

    data = '''
    def a():
        y = yield from b()
        y = yield from (1 for a in b)
        yield from (1 for a in b)
        yield from b()
        a = 1 + (yield from b())
        b = 1 + (yield from b()) + c
    '''

# Generated at 2022-06-12 04:25:48.669147
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer()
    assert result


# Generated at 2022-06-12 04:25:52.760996
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    t.generic_visit = lambda x: x
    t._handle_assignments = lambda x: x
    t._handle_expressions = lambda x: x
    assert t.target == (3, 2)



# Generated at 2022-06-12 04:25:58.121362
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import unparse
    code = """
result = yield from foo()
"""
    expected = """
let(iterable)
iterable = iter(foo())
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            result = exc.value
        break
"""
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    assert expected == unparse(tree)

# Generated at 2022-06-12 04:26:07.268409
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  from .utils import run_transformer, create_module

  module_str = """
    def foo():
        yield from bar()

    def bar():
        return "spam"
  """
  module = create_module(module_str)
  newmodule = run_transformer(module, YieldFromTransformer)

  expected = """
    def foo():
        let(iterable)
        iterable = iter(bar())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, "value"):
                    exc = exc.value
                break

    def bar():
        return "spam"
  """
  assert newmodule == expected

# Generated at 2022-06-12 04:26:07.958762
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:22.002086
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .compiler import Compiler
    from .scope import Scope
    from .yield_from import YieldFromTransformer
    from ..compiled.typed_ast import ast3 as ast

    def make_compiler():
        scope = Scope()
        return Compiler(scope, YieldFromTransformer)

    def test_transform_yield_from():
        c = make_compiler()

        expr = c.visit(ast.parse('yield from f()'))
        assert len(expr) == 3
        assert isinstance(expr[0], ast.Assign)
        assert isinstance(expr[1], ast.Expr)
        assert isinstance(expr[2], ast.While)

        expr = c.visit(ast.parse('a = yield from f()'))
        assert len(expr) == 3
       

# Generated at 2022-06-12 04:26:23.467476
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert repr(YieldFromTransformer()) == 'YieldFromTransformer()'

# Generated at 2022-06-12 04:26:27.327408
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Source: https://github.com/machinalis/convert-annotations-to-comments/blob/master/fake_types.py

# Generated at 2022-06-12 04:26:28.596703
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return 'Unit test for constructor of class YieldFromTransformer'

# Generated at 2022-06-12 04:26:31.813441
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..basic import Compiler
    from . import YieldFromTransformer
    from .unpack import UnpackTransformer
    from .scope import ScopeTransformer


# Generated at 2022-06-12 04:26:33.630787
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except NameError as e:
        assert type(e) == NameError


# Generated at 2022-06-12 04:26:34.435205
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:42.137437
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        target = (3, 0)
        def __init__(self):
            super().__init__()
            self._tree_changed = None
            return None
    t = TestTransformer()
    assert(isinstance(t, ast.NodeTransformer))
    assert(t._tree_changed is None)
    assert(t.target == (3, 0))
    return None


# Generated at 2022-06-12 04:26:43.095568
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

# Generated at 2022-06-12 04:26:44.533522
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None

# Generated at 2022-06-12 04:27:00.434925
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())])
    b = ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())])
    c = ast.Assign(targets=[ast.Name(id='c', ctx=ast.Store())])
    d = ast.Expr(value=ast.Name(id='d', ctx=ast.Load()))
    e = ast.Expr(value=ast.Name(id='e', ctx=ast.Load()))
    f = ast.Expr(value=ast.Name(id='f', ctx=ast.Load()))
    g = ast.Assign(targets=[ast.Name(id='g', ctx=ast.Store())])
    yield

# Generated at 2022-06-12 04:27:08.237175
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from py_src.syntax import SyntaxNode
    import ast
    import pytest
    from py_src.transpilers.transpiler import Transpiler
    from py_src.transpilers.python_to_python import PythonToPython
    from py_src.transpilers.tests.helpers import assert_ast_equals

    a = SyntaxNode(ast.Assign(targets=SyntaxNode(ast.Name(id='a', ctx=ast.Store())),
                              value=SyntaxNode(ast.YieldFrom(value=SyntaxNode(ast.Name(id='b', ctx=ast.Load())))))),

# Generated at 2022-06-12 04:27:17.126761
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.snippet import snippet
    from ..utils.tree import print_ast

    @snippet
    def my_snippet():
        i = 0
        while i < 10:
            i += 1
            yield from [1, 2, 3]


# Generated at 2022-06-12 04:27:18.150392
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tf = YieldFromTransformer()


# Generated at 2022-06-12 04:27:19.069191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = YieldFromTransformer()
    assert isinstance(node, YieldFromTransformer)

# Generated at 2022-06-12 04:27:27.268377
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import get_code, tree_equal
    from ..utils.tree import parse, dump

    code = get_code('for_1.py')
    tree = parse(code)
    tree = YieldFromTransformer().visit(tree)
    tree_equal(dump(tree), get_code('for_2.py'))

    code = get_code('for_3.py')
    tree = parse(code)
    tree = YieldFromTransformer().visit(tree)
    tree_equal(dump(tree), get_code('for_4.py'))

    code = get_code('try_1.py')
    tree = parse(code)
    tree = YieldFromTransformer().visit(tree)

# Generated at 2022-06-12 04:27:30.623116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    code = '''
    def t():
        yield from range(10)
    '''
    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-12 04:27:32.658658
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import run_transformer
    from ..utils.source import source_to_code

# Generated at 2022-06-12 04:27:33.830906
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None

# Generated at 2022-06-12 04:27:43.194818
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..test_utils.test_transformer import _test_if_node_was_transformed
    from ..test_utils.test_transformer import _test_if_node_was_not_transformed

    _test_if_node_was_transformed(
        "def foo():\n    yield from (1 for _ in [])\n",
        "def foo():\n    let(iterable)\n    iterable = iter(1 for _ in [])\n    while True:",
        YieldFromTransformer
    )


# Generated at 2022-06-12 04:27:56.408092
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    transform = YieldFromTransformer()
    assert isinstance(transform, BaseNodeTransformer)


# Generated at 2022-06-12 04:28:03.562780
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestTransformer(BaseNodeTransformer):

        def visit(self, node: ast.AST) -> ast.AST:
            return node

    # Check that class YieldFromTransformer inherited only from BaseNodeTransformer
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert isinstance(YieldFromTransformer(TestTransformer(TestTransformer())), BaseNodeTransformer)
    assert isinstance(YieldFromTransformer(TestTransformer(TestTransformer())), YieldFromTransformer)
    assert issubclass(YieldFromTransformer, YieldFromTransformer)
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:04.353021
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:05.306071
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-12 04:28:06.343210
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:09.622894
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse('yield from foo(bar)')
    tr = YieldFromTransformer()
    tr.visit(module)

# Generated at 2022-06-12 04:28:11.738024
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	from py_backwards.transformers.yield_from import YieldFromTransformer
	y = YieldFromTransformer()
	assert isinstance(y, YieldFromTransformer)

# Generated at 2022-06-12 04:28:14.202429
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ps = YieldFromTransformer()
    assert isinstance(ps, YieldFromTransformer)
    assert isinstance(ps, BaseNodeTransformer)
    assert ps.target == (3, 2)


# Generated at 2022-06-12 04:28:16.316503
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class MockCompilation(object):
        pass
    node = ast.Module()
    YieldFromTransformer(MockCompilation())
    assert node is not None

# Generated at 2022-06-12 04:28:19.358469
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from tests.simplify.test_yield import c
    from ..context import Context
    from ..node_transformer import NodeTransformer
    from .. import simplify

    ctx, _scope, node = c


# Generated at 2022-06-12 04:28:48.073392
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile_string, MacroError
    from .mocks import MockASTNode
    from ..utils.snippet import macro, snippet as m
    from ..utils.macros import binary, unary, binary_or_unary
    from ..utils.helpers import tree_to_str, get_expr
    import ast as a

    m_bin = binary.get_body
    m_un = unary.get_body
    m_bin_or_un = binary_or_unary.get_body

    assert compile_string('''
a = (yield from [1])
''') == 'a = (yield from [1])'


# Generated at 2022-06-12 04:28:49.945448
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.example import example_generation
    return example_generation(YieldFromTransformer)

# Generated at 2022-06-12 04:28:51.159356
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    YieldFromTransformer()


# Generated at 2022-06-12 04:28:52.344505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x.target == (3, 2)

# Generated at 2022-06-12 04:28:55.782039
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    string = "def foo(): yield from [1,2]"
    node = ast.parse(string)
    result = YieldFromTransformer().visit(node)
    print(ast.dump(result))

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:28:57.276175
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'


# Generated at 2022-06-12 04:29:05.042356
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..ast_codegen import to_source
    from ..utils.helpers import to_visit_key

    assert to_source(YieldFromTransformer(None)._emulate_yield_from(None, None)) == \
        '{\n' \
        '    let iterable;\n' \
        '    iterable = iter(generator);\n' \
        '    while True:\n' \
        '        try:\n' \
        '            yield next(iterable);\n' \
        '        except StopIteration as exc:\n' \
        '            break;\n' \
        '}\n'


# Generated at 2022-06-12 04:29:06.067520
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    c = YieldFromTransformer
    pass



# Generated at 2022-06-12 04:29:06.879804
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:29:15.378090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .remove_asserts import RemoveAsserts
    from .remove_lambda import RemoveLambda
    from .remove_print import RemovePrint
    from .remove_docstrings import RemoveDocstrings
    from .print_to_logging import PrintToLogging
    from .if_to_while import IfToWhile
    from .loop_unrollers import ForLoopUnroller
    from .raise_to_assertions import RaiseToAssertions
    from .remove_undefined_type_comments import RemoveUndefinedTypeComments
    from .remove_type_comments import RemoveTypeComments
    from .remove_type_ignores import RemoveTypeIgnores
    from .literal_eval import LiteralEval
    from .remove_builtin_imports import RemoveBuiltinImports
    from .remove_unused_variables import RemoveUnusedVariables

# Generated at 2022-06-12 04:30:53.507888
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Assign
    assign = ast.parse("x = yield from x").body[0]
    YieldFromTransformer().transform(assign)
    expected = "x = iter(x)\nwhile True:\n\ttry:\n\t\tnext(x)\n\texcept StopIteration as exc:\n\t\tx = exc.value\n\t\tbreak"
    assert expected == ast.unparse(assign)

    # Expr
    stmt = ast.parse("yield from x").body[0]
    YieldFromTransformer().transform(stmt)
    expected = "x = iter(x)\nwhile True:\n\ttry:\n\t\tnext(x)\n\texcept StopIteration as exc:\n\t\tbreak"
    assert expected == ast.unparse(stmt)

# Generated at 2022-06-12 04:30:55.647509
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass #if YieldFromTransformer().__doc__


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 04:31:04.703450
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    generator1 = YieldFromTransformer()
    generator1._get_yield_from_index(ast.parse("""
                import yield_from
                def test():
                    yield_from
                """), ast.Assign)
    generator1._emulate_yield_from(  # type: ignore
        ast.parse("""a = yield_from.result_assignment"""),  # type: ignore
        ast.parse("""yield_from.yield_from""")  # type: ignore
    )
    generator1._handle_assignments(
        ast.parse("""def test():
                yield_from.yield_from
        """))
    generator1._handle_expressions(ast.parse("""def test():
    yield_from.yield_from
    """))

# Generated at 2022-06-12 04:31:09.603269
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Arguments: node
    YieldFromTransformer(None)
    YieldFromTransformer(False)
    YieldFromTransformer(0)
    YieldFromTransformer(0.0)
    YieldFromTransformer(0j)
    YieldFromTransformer('')
    YieldFromTransformer(())
    YieldFromTransformer([])
    YieldFromTransformer({})
    YieldFromTransformer(set())
    YieldFromTransformer(object())
    YieldFromTransformer(object)

# Generated at 2022-06-12 04:31:17.139852
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_dummy_node
    from ..utils.tree import transform_tree
    from .meta import Transformer

    s = """
    a = yield from range(10)
    yield from range(10)
    """
    node = get_dummy_node(s)
    transformer: Transformer = Transformer([YieldFromTransformer()])
    with transformer.visit_module(node) as result:
        print(ast.dump(result))
        print("Transformer:", transformer.is_changed())
        assert transformer.is_changed()
        assert len(transform_tree(result).body) == 2
        assert transform_tree(result).body[0].value.func.id == 'next'
        assert transform_tree(result).body[1].value.func.id == 'next'

# Generated at 2022-06-12 04:31:19.469708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source

    t = YieldFromTransformer()
    assert isinstance(t, ast.NodeTransformer)
    assert isinstance(t, YieldFromTransformer)

# Generated at 2022-06-12 04:31:21.934879
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..modules import py_to_py__YieldFromTransformer
    assert py_to_py__YieldFromTransformer.YieldFromTransformer.__name__ == "YieldFromTransformer"
# Unit tests for YieldFromTransformer._get_yield_from_index()

# Generated at 2022-06-12 04:31:22.383438
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-12 04:31:28.807144
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def _get_yield_from_index(node, type_):
        if hasattr(node, 'body'):
            for n, child in enumerate(node.body):
                if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                    return n
        return None

    def _emulate_yield_from(target, node):
        exc = 'exc'
        if target is not None:
            assignment = 'if hasattr(exc, "value"):\n    target = exc.value'
        else:
            assignment = ''

        return 'iterable = iter(generator)\nwhile True:\n    try:\n        yield next(iterable)\n    except StopIteration as exc:\n        ' + assignment + '\n        break'


# Generated at 2022-06-12 04:31:36.971317
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = textwrap.dedent('''
        def f(d):
            a = [0, 1, 2]
            b = []
            for x in range(3):
                a[x] = yield from d[x]
                b.append(a)
            return b
        ''')
    by_yft = YieldFromTransformer().transform(code)


# Generated at 2022-06-12 04:33:21.862379
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():  # type: () -> None
    """Disabled by default. Unit test for YieldFromTransformer."""
    import astunparse


# Generated at 2022-06-12 04:33:23.286551
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer."""
    YieldFromTransformer()

# Generated at 2022-06-12 04:33:24.101338
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()

# Generated at 2022-06-12 04:33:24.613305
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:33:25.785964
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


__all__ = ['YieldFromTransformer']

# Generated at 2022-06-12 04:33:34.357970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    emitter = YieldFromTransformer()
    def test(func_snippet, expected_func_snippet):
        my_ast = func_snippet.get_ast()
        expected_ast = expected_func_snippet.get_ast()
        emitter.visit(my_ast)
        assert(ast.dump(my_ast) == ast.dump(expected_ast))
    test_snippet = snippet(
        total = yield_from(range(5)),
    )

# Generated at 2022-06-12 04:33:35.088640
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:33:36.172107
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, BaseNodeTransformer)

# Generated at 2022-06-12 04:33:38.626806
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .res2assignments import Res2Assignments
    from .syntax_sugar import SyntaxSugarTransformer
    from .yield_from_to_return import YieldFromToReturn


# Generated at 2022-06-12 04:33:47.157864
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import compile_
    from .function_def import FunctionDefTransformer
    from .for_ import ForTransformer

    tr = YieldFromTransformer()
    # find a simple case of yield from
    tree = compile_('def foo():\n'
                    '    a = yield from bar()')

    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.FunctionDef)
    assert len(tree.body[0].body) == 1
    assert isinstance(tree.body[0].body[0], ast.Assign)
    assert isinstance(tree.body[0].body[0].value, ast.YieldFrom)

    # transform yield from to special while
    tr.visit(tree)