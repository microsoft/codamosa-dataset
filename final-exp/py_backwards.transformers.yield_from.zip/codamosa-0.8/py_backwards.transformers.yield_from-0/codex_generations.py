

# Generated at 2022-06-12 04:25:24.307095
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None

# Unit tests for _get_yield_from_index()

# Generated at 2022-06-12 04:25:33.543339
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast import get_ast
    from inspect import cleandoc
    import python_minifier.transformer.YieldFromTransformer as module

    code = cleandoc(
        """\
        def foo(a, b):
            c = yield from a
            d = yield from b
        """
    )

# Generated at 2022-06-12 04:25:34.761056
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None

# Generated at 2022-06-12 04:25:35.572672
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:25:38.300128
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Try to create object of class YieldFromTransformer
    try:
        obj = YieldFromTransformer()
    except:
        assert False

    return


# Generated at 2022-06-12 04:25:39.468844
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test_YieldFromTransformer.code = YieldFromTransformer()


# Generated at 2022-06-12 04:25:40.305486
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print(YieldFromTransformer())


# Generated at 2022-06-12 04:25:51.191919
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    klass = "YieldFromTransformer"
    node = ast.AST()
    obj = YieldFromTransformer(node)
    assert hasattr(obj, "visit"), f"{klass} has no 'visit' method"
    assert hasattr(obj, "_get_yield_from_index"), f"{klass} has no '_get_yield_from_index' method"
    assert hasattr(obj, "_emulate_yield_from"), f"{klass} has no '_emulate_yield_from' method"
    assert hasattr(obj, "_handle_assignments"), f"{klass} has no '_handle_assignments' method"

# Generated at 2022-06-12 04:25:52.514659
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).visit(None) is None



# Generated at 2022-06-12 04:26:00.220335
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t0 = ast.Try(
        body=[ast.Expr(
            value=ast.YieldFrom(
                value=ast.Name(
                    id='g1',
                    ctx=ast.Load())))],
        finalbody=[],
        handlers=[],
        orelse=[],
        type_comment=None)
    t0_ = yield_from.get_body(
        generator=ast.Name(id='g1',
                           ctx=ast.Load()),
        exc=VariablesGenerator.generate('exc'),
        assignment=[])

    t1 = ast.Assign(
        targets=[ast.Name(id='r1', ctx=ast.Store())],
        value=ast.YieldFrom(
            value=ast.Name(id='g2', ctx=ast.Load())))


# Generated at 2022-06-12 04:26:07.219393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer('', 'import ast')


# Generated at 2022-06-12 04:26:07.688454
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:26:08.616958
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:26:11.834764
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        print("typed_ast isn't installed")
        return
    t = YieldFromTransformer()
    assert isinstance(t, BaseNodeTransformer)


# Generated at 2022-06-12 04:26:12.839093
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:26:22.033079
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    text = 'abc = yield from def; ghi = yield from jkl'
    module = ast.parse(text)
    YieldFromTransformer().visit(module)
    result = ast.dump(module)
    print(result)

# Generated at 2022-06-12 04:26:33.404103
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): 
    assert not hasattr(YieldFromTransformer,'_YieldFromTransformer__tree_changed')
    assert not hasattr(YieldFromTransformer,'_YieldFromTransformer__context')
    assert not hasattr(YieldFromTransformer,'_YieldFromTransformer__options')
    x = YieldFromTransformer()
    assert hasattr(x,'_YieldFromTransformer__tree_changed')
    assert hasattr(x,'_YieldFromTransformer__context')
    assert hasattr(x,'_YieldFromTransformer__options')
    assert hasattr(x,'target')
    assert hasattr(x,'generic_visit')
    assert hasattr(x,'visit')
    assert x.target == (3,2)
    assert x.generic_visit == ast.NodeTransformer.generic_visit



# Generated at 2022-06-12 04:26:36.682572
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert not hasattr(YieldFromTransformer, "visit_Assign")
    assert not hasattr(YieldFromTransformer, "visit_Expr")
    assert hasattr(YieldFromTransformer, "visit")


# Generated at 2022-06-12 04:26:38.382555
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    store = YieldFromTransformer()

# Generated at 2022-06-12 04:26:39.740514
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t



# Generated at 2022-06-12 04:26:45.393011
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:48.400796
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)

# Generated at 2022-06-12 04:26:50.662923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert isinstance(obj, BaseNodeTransformer)


# Generated at 2022-06-12 04:26:51.594375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:26:58.987915
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from inspect import isclass, isabstract

    assert isclass(YieldFromTransformer)
    assert BaseNodeTransformer in YieldFromTransformer.__bases__

    assert hasattr(YieldFromTransformer, '__init__')
    assert hasattr(YieldFromTransformer, 'visit')
    assert hasattr(YieldFromTransformer, 'generic_visit')

    assert not isabstract(YieldFromTransformer)


# Generated at 2022-06-12 04:27:00.434217
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)


# Generated at 2022-06-12 04:27:01.872696
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-12 04:27:03.378769
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transpiler = YieldFromTransformer()
    assert transpiler is not None

# Generated at 2022-06-12 04:27:04.964104
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert yield_from_transformer.target == (3, 2)

# Generated at 2022-06-12 04:27:14.256116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    input_code = """
        def iter():
            yield 1
            yield 2

        def foo():
            yield from iter()
    """
    expected_code = """
        def iter():
            yield 1
            yield 2

        def foo():
            iterable = iter()
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    break
    """
    parse_tree = ast.parse(input_code)
    YieldFromTransformer().visit(parse_tree)
    transformed_code = astor.to_source(parse_tree)
    assert expected_code == transformed_code

# Generated at 2022-06-12 04:27:26.127163
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test for constructor of class YieldFromTransformer
    YieldFromTransformer()
    return True


# Generated at 2022-06-12 04:27:27.267219
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:27:28.096013
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(None)


# Generated at 2022-06-12 04:27:29.042745
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Generated at 2022-06-12 04:27:31.547366
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assertASTMatch

# Generated at 2022-06-12 04:27:32.065691
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:27:41.318126
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source_to_ast

    tr = YieldFromTransformer()
    ast = source_to_ast("y = yield from x")
    tr.visit(ast)

    assert "yield next(y)" in ast.body[0].body[0].body[0].body[0].value.id
    assert "yield next(y)" in ast.body[0].body[0].body[0].body[1].value.id
    assert "iter(x)" == ast.body[0].body[0].body[0].body[1].value.args[0].id
    assert ast.body[0].body[0].body[0].body[2].value.value.id == "exc"
    assert ast.body[0].body[0].body[0].body[2].value.value

# Generated at 2022-06-12 04:27:44.822479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import get_example_script, get_example_script_and_compile_ast
    script = get_example_script(YieldFromTransformer)
    script = get_example_script_and_compile_ast(script, YieldFromTransformer)

# Generated at 2022-06-12 04:27:47.435500
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Test the constructor of class YieldFromTransformer
    '''
    node_transformer = YieldFromTransformer()
    assert(isinstance(node_transformer, BaseNodeTransformer))


# Generated at 2022-06-12 04:27:49.301110
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import node_to_str

# Generated at 2022-06-12 04:28:12.497119
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
   node=ast.If(test=ast.Name(id='test'),
      body=[ast.Expr(ast.YieldFrom(value=ast.Name(id='value')))],
      orelse=[])
   exp = YieldFromTransformer()
   exp.visit(node)

# Generated at 2022-06-12 04:28:20.844622
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('''
a = yield from b
''')
    expected = ast.parse('''
let(iterable)
iterable = iter(b)
while True:
    try:
        yield next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break
''')
    t = YieldFromTransformer()
    t.visit(node)
    print('#' * 10, 'expected', '#' * 10)
    print(ast.dump(expected))
    print('#' * 10, 'result', '#' * 10)
    print(ast.dump(node))
    print('#' * 10, 'equal', '#' * 10)

# Generated at 2022-06-12 04:28:22.429488
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer(lambda x: x, 3)
    assert t


# Generated at 2022-06-12 04:28:27.285428
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..ast_utils import validate
    from .. import utils
    a = ast.parse('(a) = yield from (1, 2, 3)')
    validate(a)
    a1 = utils.compile_and_run(YieldFromTransformer, a)
    validate(a1)
    a2 = ast.parse('a = next(iter(1, 2, 3))')
    validate(a2)
    assert a1 == a2

# Generated at 2022-06-12 04:28:34.620853
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .experimental import NoopTransformer

    source = """\
    yield from f(yield from a())
    """

    expected = """\
    let(iterable, exc)
    iterable = iter(a())
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break

    let(iterable, exc)
    iterable = iter(f(iterable))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            break
    """

    assert NoopTransformer().visit(YieldFromTransformer().visit(source)) == expected

# Generated at 2022-06-12 04:28:36.714113
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft._tree_changed == False
    assert yft._info == dict()
    assert yft.target == (3, 2)

# Generated at 2022-06-12 04:28:37.946477
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None).visit(None) == None


# Generated at 2022-06-12 04:28:38.853554
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:39.923425
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:48.300909
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import AST, Try, FunctionDef, Load, Store, Name, YieldFrom, Raise, Call, Assign, Return, \
        arguments, arg, If, While, Break, For, Compare, BinOp, Gt, Eq, Add, Str, Expr, List, Attribute, Subscript, \
        Index, Name, And, Or, UnaryOp, Invert, Not, In, NotIn, Is, IsNot, Lt, GtE, LtE, NotEq, Mod, Mult, Sub, Div, \
        FloorDiv, LShift, RShift, BitOr, BitXor, BitAnd, Pow, AugAssign, UAdd, USub, UAdd, USub

    target = Return(value=Name(id='result', ctx=Load()))


# Generated at 2022-06-12 04:29:41.651813
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.FunctionDef(name='foo', decorator_list=[], args=ast.arguments(posonlyargs=[],
    args=[],
    vararg=None,
    kwonlyargs=[],
    kw_defaults=[],
    kwarg=None,
    defaults=[]),
    body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
    value=ast.YieldFrom(value=ast.Name(id='c', ctx=ast.Load()))),
    ast.Assign(targets=[ast.Name(id='b', ctx=ast.Store())],
    value=ast.YieldFrom(value=ast.Name(id='d', ctx=ast.Load())))],
    returns=None, type_comment=None)

# Generated at 2022-06-12 04:29:42.418266
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer.__init__(object)

# Generated at 2022-06-12 04:29:43.457886
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''Unit test for constructor of class YieldFromTransformer'''
    pass

# Generated at 2022-06-12 04:29:44.904547
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()



if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:29:45.856976
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:29:46.421744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): assert YieldFromTransformer()

# Generated at 2022-06-12 04:29:47.836369
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast as pyast
    a = YieldFromTransformer()
    assert a is not None

# Generated at 2022-06-12 04:29:48.607906
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


# Generated at 2022-06-12 04:29:58.618505
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    import typing
    # No error should be raised
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    # Make sure that we have correct inheritance hierarchy
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    # Check type of 'target'
    assert hasattr(YieldFromTransformer, 'target') and isinstance(YieldFromTransformer.target, property)
    # Check type of 'generic_visit'
    assert hasattr(YieldFromTransformer, 'generic_visit') and callable(getattr(YieldFromTransformer, 'generic_visit'))
    # Check type of 'visit_Module'
    assert hasattr(YieldFromTransformer, 'visit_Module') and callable

# Generated at 2022-06-12 04:30:00.786526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # test variant
    a = YieldFromTransformer()
    print(a)


# Generated at 2022-06-12 04:32:01.465090
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = """
    try:
        a = yield from b
    except C:
        pass
    """

    module = ast.parse(source)
    tree = YieldFromTransformer().visit(module)
    print(ast.dump(tree))

# Generated at 2022-06-12 04:32:08.697835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import from_source
    from .base import BaseNodeTransformer
    from .iterator_transformer import IteratorTransformer
    from .unpacking import UnpackingTransformer
    from .return_transformer import ReturnTransformer
    from .exception_transformer import ExceptionTransformer
    from ..utils.scope import Scope
    from ..utils.snippet import snippet as s
    import astor

    source = "def test(): yield from [1, 2, 3]"
    tree = from_source(source)
    scope = Scope()
    YieldFromTransformer(scope).visit(tree)
    UnpackingTransformer(scope).visit(tree)
    IteratorTransformer(scope).visit(tree)
    ReturnTransformer(scope).visit(tree)
    ExceptionTransformer(scope).visit(tree)

# Generated at 2022-06-12 04:32:10.052784
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-12 04:32:12.883588
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("x = yield from foo()")
    trans = YieldFromTransformer()
    trans.visit(node)
    assert isinstance(trans, YieldFromTransformer)


# Generated at 2022-06-12 04:32:13.556988
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:32:14.201218
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:32:17.348590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer([])
    assert YieldFromTransformer.get_transformer_kwargs([]) == dict()
    assert YieldFromTransformer.get_transformer_args([]) == []

# Unit tests for method _get_yield_from_index of class YieldFromTransformer

# Generated at 2022-06-12 04:32:20.421881
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, '_get_yield_from_index')
    assert hasattr(YieldFromTransformer, '_handle_assignments')
    assert hasattr(YieldFromTransformer, '_handle_expressions')
    assert hasattr(YieldFromTransformer, 'visit')


# Generated at 2022-06-12 04:32:21.088948
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:32:22.468939
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer
