

# Generated at 2022-06-12 04:25:19.566135
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:27.250612
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import inspect
    import typing
    # Ensure YieldFromTransformer.visit adheres to the visitor protocol
    assert "ast.AST" in typing.get_type_hints(YieldFromTransformer.visit).__annotations__.values()
    # Ensure YieldFromTransformer.visit has the right number of arguments
    argspec = inspect.getfullargspec(YieldFromTransformer.visit)
    assert argspec.args == ['self', 'node']
    assert argspec.varargs is None
    assert argspec.varkw is None
    assert argspec.defaults is None
    assert argspec.kwonlyargs == []
    assert argspec.kwonlydefaults is None
    assert argspec.annotations == {"node": "ast.AST"}

# Generated at 2022-06-12 04:25:32.635905
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    q = ast.parse("def generator(n):\n    yield from range(n)",
                  "<test>", "exec")
    assert str(YieldFromTransformer().visit(q)) == "def generator(n):\n    iterable = iter(range(n))\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            target = exc.value\n            break\n"

# Generated at 2022-06-12 04:25:38.143286
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_test_data
    from ..utils.source import Source
    source = Source('''
    def foo(a):
        yield from a
    ''')
    assert get_test_data(YieldFromTransformer, source) == '''
    def foo(a):
        let(iterable)
        iterable = iter(a)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    '''

# Generated at 2022-06-12 04:25:38.977928
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:25:49.116375
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try_ = ast.Try(
        body=[
            ast.Expr(value=ast.YieldFrom(value=ast.Name(id='xxx', ctx=ast.Load()))),
            ast.Assign(
                targets=[ast.Name(id='x', ctx=ast.Store())],
                value=ast.YieldFrom(value=ast.Name(id='xxx', ctx=ast.Load()))),
            ast.Expr(value=ast.Str(s='1')),
        ],
        handlers=[],
        orelse=[],
        finalbody=[]
    )
    print(ast.dump(try_, include_attributes=False))
    transformer = YieldFromTransformer()
    transformed = transformer.visit(try_)

# Generated at 2022-06-12 04:25:52.466744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()
    assert isinstance(tr, BaseNodeTransformer) and isinstance(tr, YieldFromTransformer)
    assert tr.target == (3, 2)



# Generated at 2022-06-12 04:25:53.815324
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    t.visit(0)
    assert True

# Generated at 2022-06-12 04:25:57.803591
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import snippets
    from ..utils.tree import parse_module

    snippets.register_snippets(globals())
    module_ast = parse_module(globals())

    transformer = YieldFromTransformer()
    result_ast = transformer.visit(module_ast)

    expected_ast = parse_module(globals())
    assert result_ast == expected_ast

# Generated at 2022-06-12 04:25:58.586744
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer()

# Generated at 2022-06-12 04:26:12.705712
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import compare_source

    compare_source(YieldFromTransformer,
                   '''
                   def function():
                       yield from 1
                   ''',
                   '''
                   def function():
                       exc = VariablesGenerator.generate('exc')
                       iterable = iter(1)
                       while True:
                           try:
                               yield next(iterable)
                           except StopIteration as exc:
                               if hasattr(exc, 'value'):
                                   exc = exc.value
                               break
                   ''')


# Generated at 2022-06-12 04:26:13.859280
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:15.988958
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:18.460451
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.parse("yield_from()")
    obj = YieldFromTransformer(yield_from)

    assert obj.target == (3, 2)

# Generated at 2022-06-12 04:26:20.699156
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def test():
        a = yield from b

    tree = ast.parse(test.__code__)
    new_tree = YieldFromTransformer().visit(tree)



# Generated at 2022-06-12 04:26:24.449442
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import types
    ast_string = '''
    def b():
        a = yield from c()'''
    YieldFromTransformer().visit(ast.parse(ast_string))
    assert isinstance(b, types.FunctionType) is True


# Generated at 2022-06-12 04:26:25.242885
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:25.553539
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:26:35.008526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def yieldFrom(y, x):
        target = yield from y
        target2 = yield from x

    tree = ast.parse(inspect.getsource(yieldFrom))
    tree = YieldFromTransformer().visit(tree)

    # Correct handling of Assign
    assert ast.dump(tree.body[0].body[0]) == "target = next(iterable)"
    assert ast.dump(tree.body[0].body[1]) == (
        "let(iterable)\n"
        "iterable = iter(y)\n"
        "while True:\n"
        "    try:\n"
        "        yield next(iterable)\n"
        "    except StopIteration as exc:\n"
        "        target = exc.value\n"
        "        break")
    # Correct handling of Expr

# Generated at 2022-06-12 04:26:36.378513
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer  # to avoid warning about no usages

# Generated at 2022-06-12 04:26:48.966535
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    
  ##############################################################################
  # YieldFromTransformer Class

  # create node
  node = ast.Expression(body=ast.YieldFrom())

  # create transformer
  transformer = YieldFromTransformer()

  # assert that _handle_assignments returns an ast.AST (i.e the base type)
  assert isinstance(transformer._handle_assignments(ast.Expression(body=ast.YieldFrom())), ast.AST)

  # assert that _handle_expressions returns an ast.AST (i.e the base type)
  assert isinstance(transformer._handle_expressions(ast.Expression(body=ast.YieldFrom())), ast.AST)

  # assert that _emulate_yield_from returns an ast.AST (i.e the base type)

# Generated at 2022-06-12 04:27:00.024431
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.python import python
    x = YieldFromTransformer()
    code = """
    def test():
        a = yield from range(2)
        a = yield from range(3)
        yield from range(4)
        yield from range(5)

    def test2():
        yield from range(4)
    """
    actual_code = python(code, x)

# Generated at 2022-06-12 04:27:04.197101
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x._get_yield_from_index(1) == None
    assert x._emulate_yield_from(1) == None
    assert x._handle_assignments(1) == None
    assert x._handle_expressions(1) == None

# Generated at 2022-06-12 04:27:07.041205
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'



# Generated at 2022-06-12 04:27:14.800847
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')
    assert hasattr(YieldFromTransformer, '_tree_changed')
    assert hasattr(YieldFromTransformer, '_get_yield_from_index')
    assert hasattr(YieldFromTransformer, '_emulate_yield_from')
    assert hasattr(YieldFromTransformer, '_handle_assignments')
    assert hasattr(YieldFromTransformer, '_handle_expressions')
    assert hasattr(YieldFromTransformer, 'visit')

if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:27:16.211127
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:27:25.245091
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import optimizer
    from ..utils import compile_source, source_to_ast
    from io import StringIO

    source = StringIO("def foo():\n"
                      "    try:\n"
                      "        a = yield from goo()\n"
                      "    except Exception as exc:\n"
                      "        pass\n"
                      "    yield from bar(a)")


# Generated at 2022-06-12 04:27:26.165391
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-12 04:27:28.214988
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test = YieldFromTransformer()
    assert isinstance(test, BaseNodeTransformer)
    assert test._tree_changed == False


# Generated at 2022-06-12 04:27:37.499424
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # data to test constructor
    input_code = """
    def return1():
        yield 1

    def return2():
        yield 2

    def return3():
        yield 3

    def ret():
        var = yield from return1()
        var2 = yield from return2()
        yield from return3()
        # var3 = yield from return1()
        print(var)
    """

    # expected output to compare the output from the constructor

# Generated at 2022-06-12 04:27:48.966111
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() != None


# Generated at 2022-06-12 04:27:52.138731
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    expected_result = ast.parse('import sys\n')
    actual_result = ast.parse('')
    c = YieldFromTransformer()
    result = c.visit(actual_result)
    assert expected_result == result


# Generated at 2022-06-12 04:28:02.128384
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..compiler import compile
    from .annotations import AnnotateTransformer
    from .lambda_ import LambdaTransformer

    def check(before: ast.AST, after: ast.AST):
        assert compile(before, transformers=[
            AnnotateTransformer,
            LambdaTransformer,
            YieldFromTransformer,
        ]) == compile(after)


# Generated at 2022-06-12 04:28:08.229249
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree1 = ast.parse("x = yield from f()")
    tree2 = ast.parse("yield from f()")
    tree3 = ast.parse("for _ in f(): f(); yield from f(); f();")
    tree4 = ast.parse("yield from [i for i in range(10)]")
    tree5 = ast.parse("yield from (i for i in range(10))")
    tree6 = ast.parse("yield from {i for i in range(10)}")
    tree7 = ast.parse("yield from {i: i for i in range(10)}")
    tree8 = ast.parse("yield from [i for i in range(10) if i % 2]")
    tree9 = ast.parse("yield from (i for i in range(10) if i % 2)")
   

# Generated at 2022-06-12 04:28:08.736116
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:09.541748
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:28:11.352658
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test first non-default constructor
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)


# Generated at 2022-06-12 04:28:12.542016
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    print(x)


# Generated at 2022-06-12 04:28:13.430655
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(None)

# Generated at 2022-06-12 04:28:16.060536
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _temp1 = YieldFromTransformer()
    assert _temp1 is not None
    assert isinstance(_temp1, YieldFromTransformer)

# Unit tests for function result_assignment() used in snippet result_assignment

# Generated at 2022-06-12 04:28:38.509832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from node_transformer.utils.helpers import node_visit
    from node_transformer.utils.test_utils import node_test_equal
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:28:47.806050
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from astor import to_source
    from . import TRY, WHILE, FOR, FUNCTION, IF, MODULE
    yield_from = "yield from <value>"
    from_test_utils = {
        'TRY': TRY.replace('[YIELD]', yield_from),
        'WHILE': WHILE.replace('[YIELD]', yield_from),
        'FOR': FOR.replace('[YIELD]', yield_from),
        'FUNCTION': FUNCTION.replace('[YIELD]', yield_from),
        'IF': IF.replace('[YIELD]', yield_from),
        'MODULE': MODULE.replace('[YIELD]', yield_from),
    }

    # test to_source from YieldFromTransformer

# Generated at 2022-06-12 04:28:49.269694
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert  transformer


# Generated at 2022-06-12 04:28:55.744997
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    node = ast.parse("""
    i = 4
    j = yield from range(i)
    """)
    transformer.visit(node)
    assert ast.dump(node) == dedent("""
    Module(body=[
        Assign(
            targets=[Name(id='i', ctx=Store())],
            value=Num(n=4)
        ),
        Assign(
            targets=[Name(id='j', ctx=Store())],
            value=Yield(value=Num(n=4))
        )
    ])
    """)

# Generated at 2022-06-12 04:28:56.569506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()



# Generated at 2022-06-12 04:29:04.490148
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .bnf import ast_for_source
    from .codegen import get_source
    from .marshaller import Marshaller
    from .normalizer import Normalizer
    from .parser import Parser
    from .bnf import bnf
    from .config import Config

    config = Config(pyversion='3.7')

    parser = Parser(bnf=bnf, start='file_input', version=config.target[0])
    source = 'x, y = yield from z'
    tree = ast_for_source(parser, source, 'exec', config.target)
    print(get_source(tree).strip())
    normalized = Normalizer().visit(tree)
    marshaller = Marshaller(target=config.target)

# Generated at 2022-06-12 04:29:06.665364
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .visitor import Visitor

    # Creating objects of the classes
    obj1 = YieldFromTransformer()
    obj2 = Visitor()

    # Calling the functions
    obj1.visit(obj2)

# Generated at 2022-06-12 04:29:15.183030
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from ..utils import tree_string_representation
    from ..main import Compiler
    from typed_astunparse import unparse
    from akimous.transformers import YieldFromTransformer

    before = 'a = yield from b'
    expected = (
        'let(iterable)\n'
        'iterable = iter(b)\n'
        'while True:\n'
        '    try:\n'
        '        next(iterable)\n'
        '    except StopIteration as exc:\n'
        '        if hasattr(exc, \'value\'):\n'
        '            a = exc.value\n'
        '        break\n'
    )
    print(expected)

# Generated at 2022-06-12 04:29:16.395553
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t


# Generated at 2022-06-12 04:29:24.449546
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')
    assert hasattr(YieldFromTransformer, 'name')
    assert hasattr(YieldFromTransformer, 'generic_visit')
    assert hasattr(YieldFromTransformer, 'visit_Module')
    assert hasattr(YieldFromTransformer, 'visit_FunctionDef')
    assert hasattr(YieldFromTransformer, 'visit_For')
    assert hasattr(YieldFromTransformer, 'visit_While')
    assert hasattr(YieldFromTransformer, 'visit_If')
    assert hasattr(YieldFromTransformer, 'visit_Try')
    YieldFromTransformer()

# Generated at 2022-06-12 04:30:16.315420
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
#_______________________________________________________________________________


# Generated at 2022-06-12 04:30:17.766151
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None
    return YieldFromTransformer


# Generated at 2022-06-12 04:30:19.018790
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import get_test_ast


# Generated at 2022-06-12 04:30:20.238161
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.target == (3, 2)
    

# Generated at 2022-06-12 04:30:22.919372
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception:
        assert False
        

# Generated at 2022-06-12 04:30:31.621963
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..py_to_py.test_utils import transform_test
    tr = YieldFromTransformer()

# Generated at 2022-06-12 04:30:38.250304
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def filename(): pass
    '''
    def func(x: int) -> int:
        y = yield from range(x)
        return y
    '''

    input_ast = ast.parse(inspect.getsource(filename))
    tree = YieldFromTransformer(input_ast, 'filename')
    tree.visit(input_ast)
    output_str = clipboard.paste()
    expected_ast = ast.parse(inspect.getsource(filename))
    assert ast.dump(expected_ast) == ast.dump(input_ast)

# Generated at 2022-06-12 04:30:46.572750
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert str(YieldFromTransformer.__doc__) == "Compiles yield from to special while statement."
    assert transformer.target == (3, 2)
    assert str(transformer._get_yield_from_index.__doc__) == "Gets the index of a yield from statement in a body of another statement."
    assert str(transformer._handle_assignments.__doc__) == "Handles assignment statements in which the right-hand side is a yield from statement."
    assert str(transformer._handle_expressions.__doc__) == "Handles expression statements in which the right-hand side is a yield from statement."
    assert str(transformer.visit.__doc__) == "Visits a node and its children. Calls the appropriate visitor method for the node if it exists."

# Generated at 2022-06-12 04:30:48.028966
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError):
        YieldFromTransformer()

# Generated at 2022-06-12 04:30:50.981255
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    assert trans._get_yield_from_index() == None 
    assert trans._emulate_yield_from() == None
    assert trans._handle_assignments() == None
    assert trans._handle_expressions() == None
    assert trans.visit() == None

# Generated at 2022-06-12 04:32:51.416773
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:32:52.183118
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): assert YieldFromTransformer(None, None)

# Generated at 2022-06-12 04:32:53.303817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  assert_equal(True, True)

# Generated at 2022-06-12 04:33:02.782531
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        import typed_astunparse
        import astunparse
        print("Successfully imported typed_astunparse and astunparse")
    except:
        print("Failed to import typed_astunparse and astunparse")
    # This is the yield from statement we want to test
    test_yield_from = ast.YieldFrom(value=ast.Name(id='result', ctx=ast.Load()))
    # Assign the yield from statement to something
    test_assign_from = ast.Assign(targets=[ast.Name(id='ret', ctx=ast.Store())], value=test_yield_from)
    # Create a module node
    test_module = ast.Module(body=[test_assign_from])
    # Parse it
    tree = YieldFromTransformer().vis

# Generated at 2022-06-12 04:33:04.347540
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-12 04:33:06.228933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()
    assert YieldFromTransformer(None)


# Generated at 2022-06-12 04:33:07.041903
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:33:13.080997
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.source import source, source_debug
    from ..utils.parser import get_parser
    from ..utils.ast import parse_ast, dump_ast

    for version in ('3.2', '3.3', '3.4', '3.5', '3.6', '3.7', '3.8'):
        print(version)
        tree = parse_ast(get_parser(version)(source))
        transformer = YieldFromTransformer()
        tree = transformer.visit(tree)
        print(source_debug(dump_ast(tree, version)))

# Generated at 2022-06-12 04:33:14.194483
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.tree import parse


# Generated at 2022-06-12 04:33:15.594793
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  y = YieldFromTransformer()
  assert(y is not None)
