

# Generated at 2022-06-12 04:25:29.444998
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class YieldFromTransformer(BaseNodeTransformer):
        """Compiles yield from to special while statement."""
        target = (3, 2)

        def _get_yield_from_index(self, node: ast.AST,
                                  type_: Type[Holder]) -> Optional[int]:
            if hasattr(node, 'body') and isinstance(node.body, list):  # type: ignore
                for n, child in enumerate(node.body):  # type: ignore
                    if isinstance(child, type_) and isinstance(child.value, ast.YieldFrom):
                        return n

            return None


# Generated at 2022-06-12 04:25:38.183019
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import dump
    from typed_ast import ast3 as ast
    from ..utils.code_gen import to_source

    # First, create an instance of the YieldFromTransformer transformer.
    yft = YieldFromTransformer()

    # Next, create an ast for the following code:
    #
    #   def test():
    #       yield from range(1)
    #
    # This uses the typed_ast library to create an ast.

# Generated at 2022-06-12 04:25:39.020852
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:39.870817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:25:41.706343
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # We need to test that the class was constructed properly here
    transformer = YieldFromTransformer()
    assert transformer is not None
    

# Generated at 2022-06-12 04:25:52.761588
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseTransformerTestCase
    from transform import transform_module

    class Test(BaseTransformerTestCase):
        TRANSFORMER = YieldFromTransformer
        DIRECT = True

        def test_yield_from_expr(self):
            self.assert_module('yield from foo()',  # type: ignore
                               '''
                               def f():
                                   let(iterable)
                                   iterable = iter(foo())
                                   while True:
                                       try:
                                           yield next(iterable)
                                       except StopIteration as exc_:
                                           break
                               ''')


# Generated at 2022-06-12 04:25:58.120867
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..testing import assert_program

    assert_program(
        'YieldFromTransformer.__init__()',
        YieldFromTransformer,
        """\
                from __future__ import generator_stop, nested_scopes, generators, division, absolute_import, with_statement, print_function, unicode_literals
                """,
        """\
                from __future__ import absolute_import, division, generators, nested_scopes, print_function, with_statement
                """)


# Generated at 2022-06-12 04:25:58.673223
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:26:00.293274
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.base import BaseProject
    transformer = YieldFromTransformer()
    project = BaseProject()
    transformer.apply_to(project)

# Generated at 2022-06-12 04:26:10.915265
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import assert_equal_source
    from typed_ast import ast3 as ast
    # -- test for assignment targets
    tree = ast.parse('a = yield from []')
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert_equal_source(transformer.root, '''
    iterable = iter([]);
    while True:
        try:
            a = next(iterable);
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                a = exc.value
            break
    ''')

    # -- test for expressions
    tree = ast.parse('yield from []')
    transformer = YieldFromTransformer()
    transformer.visit(tree)

# Generated at 2022-06-12 04:26:23.661327
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    sample = '''
yield from a
yield from b.c.d
yield from 1 + 2
yield from f(1)
yield from b[1]
yield from b[1 + 2]
yield from b[f(1)]
yield from b.y[f(1)]
yield from yield from a
yield from a + yield from b
yield from a + b.y + c(yield from f())
(yield from a)
a = yield from b
a = (yield from b)
[yield from a]
(a, yield from b)
[a, (yield from b)]
{yield from a: 1}
{yield from a: 1, 2: yield from b}
{a: yield from b, (yield from d): c}
    '''


# Generated at 2022-06-12 04:26:26.106634
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    p = ast.parse("""a = yield from b""")
    assert YieldFromTransformer().run(p)

# Generated at 2022-06-12 04:26:28.334223
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transform = YieldFromTransformer()
    assert not transform._tree_changed
    assert transform._is_executing
    return transform

# Generated at 2022-06-12 04:26:29.626425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()

test_YieldFromTransformer()

# Generated at 2022-06-12 04:26:31.330040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:35.008367
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tf = YieldFromTransformer()

# The snippet is imported as a module and run directly.
if __name__ == '__main__':
    from minitest import *

    with test(YieldFromTransformer):
        with test("constructor of class YieldFromTransformer"):
            tf = YieldFromTransformer()
            tf.must_equal(YieldFromTransformer)

# Generated at 2022-06-12 04:26:37.110242
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class TestClass(YieldFromTransformer):
        def test_method(self):
            pass

    assert isinstance(TestClass(), YieldFromTransformer)

# Generated at 2022-06-12 04:26:38.480650
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(NameError):
        YieldFromTransformer()

# Generated at 2022-06-12 04:26:48.249064
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast
    from mypy.asttotree import parse

    # test_normal_expression
    node1 = ast.Expr(value=ast.YieldFrom(value=ast.Name(id='a')))
    assert parse(YieldFromTransformer().emit(node1)) == \
        'result = None\n' \
        'exc = None\n' \
        'iterable = iter(a)\n' \
        'while True:\n' \
        '    try:\n' \
        '        (result,) = next(iterable)\n' \
        '    except StopIteration as exc:\n' \
        '        if hasattr(exc, \'value\'):\n' \
        '            result = exc.value\n' \
        '        break\n'

    # test_assignment


# Generated at 2022-06-12 04:26:50.936845
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer._tree_changed == False
    assert transformer.target == (3, 2)


# Generated at 2022-06-12 04:27:07.516026
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..parser import parse, dump
    from .python_to_python_lazy import PythonToPythonLazy

    y = YieldFromTransformer()
    text = """
    def f():
        i = yield from range(10)
    """
    tree = parse(text)
    # print("before", dump(tree))
    tree = y.visit(tree)
    # print("after", dump(tree))

    to_lazy = PythonToPythonLazy()
    tree = to_lazy.visit(tree)
    print("after", dump(tree))
    print(tree)
    # print(to_lazy.get_lazy_code())

# Generated at 2022-06-12 04:27:15.846271
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree
    from ..utils.snippet import snippet

    import copy

    # create a tree with a `yield from` statement
    def foo():
        yield from bar()
    module = tree(foo, name='foo')

    # execute the transformer
    t = YieldFromTransformer()
    t.visit(module)

    # see if the code generated by the transformer
    # looks like we expected
    code = snippet(module).strip()
    expected = snippet(foo_expected).strip()
    assert code == expected, '%r != %r' % (code, expected)


# the code generated by the transformer

# Generated at 2022-06-12 04:27:17.285991
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == "YieldFromTransformer"

# Generated at 2022-06-12 04:27:25.832625
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yf = YieldFromTransformer()
    assert yf._get_yield_from_index(1, 2) == None
    yf = YieldFromTransformer()
    assert yf._get_yield_from_index([1, 2, 3], 2) == None
    yf = YieldFromTransformer()
    assert yf._get_yield_from_index([1, 2, 3], 1) == 0
    yf = YieldFromTransformer()
    assert yf._get_yield_from_index([1, 2, 3], 2) == 1
    yf = YieldFromTransformer()
    assert yf._get_yield_from_index([1, 2, 3], 3) == 2
    yf = YieldFromTransformer()
    assert yf._get_yield_from_

# Generated at 2022-06-12 04:27:34.906388
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc = ast.Name(id='StopIteration', ctx=ast.Load())

    assert result_assignment.get_body(exc=exc, target=ast.Name(id='i', ctx=ast.Store())) == [
        ast.Assign([ast.Name(id='i', ctx=ast.Store())],
                   exc.value,
                   lineno=1,
                   col_offset=0)]

    id_iterable = ast.Name(id='iterable', ctx=ast.Store())
    id_iterable_loaded = ast.Name(id='iterable', ctx=ast.Load())
    id_generator = ast.Name(id='generator', ctx=ast.Load())
    id_exc = ast.Name(id='exc', ctx=ast.Load())

# Generated at 2022-06-12 04:27:37.093350
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    yftr = YieldFromTransformer()

# Generated at 2022-06-12 04:27:38.056167
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:27:39.934202
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(None), (YieldFromTransformer, BaseNodeTransformer))


# Generated at 2022-06-12 04:27:41.399163
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(None), YieldFromTransformer)


# Generated at 2022-06-12 04:27:42.291185
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Should not fail.
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:06.524550
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test import generate_test_ast, assert_ast
    from ..visitors.base import BaseNodeTransformer
    from ..visitors.range_transformer import RangeTransformer
    from ..visitors.comprehension_transformer import ComprehensionTransformer
    from ..visitors.generator_transformer import GeneratorTransformer
    from ..visitors.yield_from_transformer import YieldFromTransformer
    # YieldFromTransformer is tested in unit test of generators transformer
    # Target version: 3.2

# Generated at 2022-06-12 04:28:10.653297
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helper import get_ast
    from ..utils.source import Source

    # __init__
    node = get_ast(Source("""
    for i in yield_from_transformer:
        if i:
            yield from i
    """))
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:13.840803
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom()
    generator = ast.GeneratorExp()
    expr = ast.Expr(value=yield_from)
    module = ast.Module([expr])
    assert YieldFromTransformer().visit(module) == module

# Generated at 2022-06-12 04:28:14.955214
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj


# Generated at 2022-06-12 04:28:15.748700
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:17.217823
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is YieldFromTransformer, \
        "Cannot create YieldFromTransformer class"

# Generated at 2022-06-12 04:28:18.251785
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:24.561651
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    source = ("def foo(n):\n"
              "    yield from range(n)\n")
    assert YieldFromTransformer(source).result() == (
        "def foo(n):\n"
        "    iterable = iter(range(n))\n"
        "    while True:\n"
        "        try:\n"
        "            yield next(iterable)\n"
        "        except StopIteration as exc:\n"
        "            if hasattr(exc, 'value'):\n"
        "                exc = exc.value\n"
        "            break\n")


# Generated at 2022-06-12 04:28:25.656814
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test snippet"""
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:29.887671
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast_helpers import modify_ast
    from typed_ast.ast3 import parse
    module = parse('def f():\n'
                   '    x = yield from []')
    transformer = YieldFromTransformer()
    module = modify_ast(module, transformer)
    exec(compile(module, '<>', 'exec'))



# Generated at 2022-06-12 04:29:12.883562
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer is not None
    assert isinstance(transformer, YieldFromTransformer)

# Generated at 2022-06-12 04:29:14.412935
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    YieldFromTransformer()


# Generated at 2022-06-12 04:29:15.416542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:29:16.930101
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(AssertionError):
        YieldFromTransformer(None)

# Generated at 2022-06-12 04:29:18.175457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(Exception):
        YieldFromTransformer() # type: ignore

# Generated at 2022-06-12 04:29:19.310563
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is YieldFromTransformer

# Generated at 2022-06-12 04:29:20.164626
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = YieldFromTransformer()

# Generated at 2022-06-12 04:29:29.451021
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node1 = ast.Try(body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.YieldFrom(value=ast.Name(id='yield_from_test', ctx=ast.Load())))],
                    handlers=[],
                    orelse=[])
    test_node = ast.Try(body=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='yield_from_test', ctx=ast.Load())))],
                    handlers=[],
                    orelse=[])
    x = YieldFromTransformer(test_node)
    assert (x.visit_Try(node1))
    assert(x.visit_Try(test_node))

# Generated at 2022-06-12 04:29:30.045433
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:29:37.904625
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    exc = ast.Name(id="exc",ctx=ast.Load())
    target = ast.Name(id="target",ctx=ast.Load())
    assert result_assignment.get_body(exc=exc, target=target) == [
        ast.Assign(targets=[target], value=ast.Attribute(value=exc, attr='value', ctx=ast.Load())),]

    generator = ast.Name(id="generator",ctx=ast.Load())
    exc = ast.Name(id="exc",ctx=ast.Load())
    assignment = result_assignment.get_body(exc=exc, target=target)

# Generated at 2022-06-12 04:32:22.966826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(
        tree=None, file_name=None, options=None), BaseNodeTransformer)

# Generated at 2022-06-12 04:32:23.634997
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:32:27.560951
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.target == (3, 2)
    assert isinstance(YieldFromTransformer.visit, types.FunctionType)



# Generated at 2022-06-12 04:32:28.321853
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a=YieldFromTransformer()


# Generated at 2022-06-12 04:32:29.352479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)


# Generated at 2022-06-12 04:32:35.552595
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # argument is not a ast.AST
    try:
        YieldFromTransformer(1)
    except TypeError as e:
        assert(str(e) == 'invalid type')
    # argument is a ast.AST
    try:
        YieldFromTransformer(ast.AST())
    except Exception as e:
        assert(False)
    # everything is fine
    try:
        YieldFromTransformer(ast.AST()).visit(ast.AST())
    except Exception as e:
        assert(False)


# Generated at 2022-06-12 04:32:37.471294
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('(a + 1)')
    assert YieldFromTransformer(node).run() == node

# Generated at 2022-06-12 04:32:39.635401
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node_transformer = YieldFromTransformer()
    assert isinstance(node_transformer, BaseNodeTransformer)

# Example of yield from

# Generated at 2022-06-12 04:32:40.815162
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:32:45.613143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .transformers import TransformerSuite
    from .unpacking import UnpackingTransformer
    from .statements import StatementsTransformer
    from .with_item import WithItemTransformer

    assert YieldFromTransformer([
        StatementsTransformer,
        UnpackingTransformer,
        YieldFromTransformer,
        WithItemTransformer
    ]).target == (3, 2)

    assert YieldFromTransformer(TransformerSuite).target == (3, 2)

# Generated at 2022-06-12 04:34:35.300275
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:34:36.553136
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-12 04:34:37.018593
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:34:45.171093
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ast import parse
    from pprint import pprint
    from ..utils.ast_print import pretty_ast
    from .base import perform_transformation_immediate
    """
    Example usage.
    """

# Generated at 2022-06-12 04:34:46.505798
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class M(YieldFromTransformer):
        pass
    assert isinstance(M(), YieldFromTransformer)

# Generated at 2022-06-12 04:34:50.205835
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Example: YieldFromTransformer({'body': [], 'type': 'Module'})
    assert YieldFromTransformer({'body': [], 'type': 'Module'}).__class__.__name__ == 'YieldFromTransformer'



# Generated at 2022-06-12 04:34:59.089176
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .name_resolver import NameResolver
    from . import parse_ast
    from . import ast_transformer
    from .scope_resolver import ScopeResolver


# Generated at 2022-06-12 04:34:59.714782
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer(None)

# Generated at 2022-06-12 04:35:05.899238
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    import pytest
    from ..utils.snippet import snippet
    node = snippet(r'''
    def foo():
        yield from range(10)
    ''')
    node = YieldFromTransformer().visit(node)
    assert isinstance(node, ast.FunctionDef)
    assert astunparse.unparse(node) == snippet(r'''
    def foo():
        let(exc)
        let(iterable)
        iterable = iter(range(10))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                break
    ''')



# Generated at 2022-06-12 04:35:07.449949
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Test constructor of class YieldFromTransformer
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer), "Failed the test"