

# Generated at 2022-06-12 04:25:31.143052
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def func(x):
        y = yield from x
        z = yield from x

    mod = ast.parse(func.__code__)
    transformer = YieldFromTransformer()
    mod = transformer.visit(mod)

    assert isinstance(mod, ast.Module)
    assert len(mod.body) == 1
    func_def = mod.body[0]
    assert isinstance(func_def, ast.FunctionDef)
    assert len(func_def.body) == 4
    if_block, assign_y, if_block2, assign_z = func_def.body
    assert isinstance(if_block, ast.If)
    assert isinstance(assign_y, ast.Assign)
    assert isinstance(if_block2, ast.If)

# Generated at 2022-06-12 04:25:32.451849
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t is not None

# Generated at 2022-06-12 04:25:33.353155
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer

# Generated at 2022-06-12 04:25:41.706435
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import unittest
    
    class TestYieldFromTransformer(unittest.TestCase):

        def test_target(self):
            transformer = YieldFromTransformer()
            
            self.assertEqual(transformer.target, (3, 2))
        
        def test__tree_changed(self):
            transformer = YieldFromTransformer()
            
            self.assertFalse(transformer._tree_changed)
        
        def test__get_yield_from_index(self):
            transformer = YieldFromTransformer()
            node = ast.parse('x = yield from iterator')
            
            index = transformer._get_yield_from_index(node, ast.Assign)
            
            self.assertEqual(index, 0)
        

# Generated at 2022-06-12 04:25:42.854110
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()

# Generated at 2022-06-12 04:25:54.112072
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # if __name__ == '__main__':
    from ..utils.snippet import Source
    from ..utils.helpers import get_ast
    from ..stl.compiler import Compiler
    from ..stl.ast_transformer import ASTTransformer

    import os
    import astor

    source = Source(os.path.abspath(__file__))
    code = source['yield_from_test']
    code_ast = get_ast(code)
    compiler = Compiler()
    compiler.compile(code)
    compiled_ast = compiler.ast
    trans = ASTTransformer(YieldFromTransformer)
    result = trans.compile(compiled_ast)
    result = astor.to_source(result)
    expected_result = source['yield_from_test_expected_result']

# Generated at 2022-06-12 04:25:55.294017
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer_instance = YieldFromTransformer()

# Generated at 2022-06-12 04:25:55.816173
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:57.857747
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()

    yield_from_transformer.target = (3, 2)
    assert yield_from_transformer.target == (3, 2)

# Generated at 2022-06-12 04:25:58.877831
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import BaseNodeTransformer
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:07.867508
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.Expr(value=ast.YieldFrom(value=ast.Str(s="Hello world")))
    assert YieldFromTransformer().visit(node) is not None
    assert YieldFromTransformer().visit(node).__class__.__name__ == 'While'

# Generated at 2022-06-12 04:26:09.141370
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with open(__file__) as f:
        assert f


# Generated at 2022-06-12 04:26:15.543427
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from compiler.utils.tests.fixtures.case_yield_from_transformer import \
        case_assignments_transform, case_expressions_transform, \
        case_assignments_no_transform, case_expressions_no_transform, \
        case_expr_assign_transform, case_expr_assign_no_transform
    transformer = YieldFromTransformer()

    # Test for the case:
    #   a = yield from b

    assert transformer.visit(case_assignments_transform.original_ast()) == \
           case_assignments_transform.expected_ast()

    assert transformer.visit(case_assignments_no_transform.original_ast()) == \
           case_assignments_no_transform.original_ast()

    # Test for the case:
    #   yield

# Generated at 2022-06-12 04:26:16.498070
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()



# Generated at 2022-06-12 04:26:18.229191
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    print('test')
    
    

# Generated at 2022-06-12 04:26:21.935262
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import ast as _ast
    lines = ['def f():\n', '    x = yield from iter([1, 2, 3])\n', 'print(f())\n']
    lines = ''.join(lines)
    tree = YieldFromTransformer().visit(_ast.parse(lines))
    print(_ast.dump(tree))

# Generated at 2022-06-12 04:26:33.253397
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.Try(
        body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                          value=ast.YieldFrom(value=ast.Name(id='b',
                                                             ctx=ast.Load())))],
        handlers=[ast.ExceptHandler(type=ast.Name(id='Exception',
                                                  ctx=ast.Load()),
                                    name='exc',
                                    body=[])],
        orelse=[],
        finalbody=[])
    tree = YieldFromTransformer(node, print_diff=True)


# Generated at 2022-06-12 04:26:34.359444
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''test_YieldFromTransformer'''
    assert YieldFromTransformer

# Generated at 2022-06-12 04:26:45.296693
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:47.568067
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:54.064945
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from pydantic import BaseModel
    class a(BaseModel):
        b:int = None

test_YieldFromTransformer()

# Generated at 2022-06-12 04:26:59.700391
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class test:
        def test_me(self):
            x = yield from 1
            y = (yield from 2)
            z = (yield from 3)
            1 + 2
            yield from 'hello'

    x = ast.parse(inspect.getsource(test))
    y = YieldFromTransformer(0)
    y.generic_visit(x)
    print(ast.dump(x))

# Generated at 2022-06-12 04:27:02.935923
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer._tree_changed is False
    assert transformer.target == (3, 2)


# Generated at 2022-06-12 04:27:03.944832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-12 04:27:04.719336
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass


# Generated at 2022-06-12 04:27:15.724497
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import load_ast_tree
    from ..utils.visitor import Visitor
    from ..utils.testing import fix_whitespace


# Generated at 2022-06-12 04:27:24.941865
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import Module
    from detyped.utils import compile_and_load
    from .base import BaseTransformerTestCase

    class TestClass(BaseTransformerTestCase):
        def setUp(self):
            self._transformer = YieldFromTransformer()

        def test_empty_function(self):
            original = '''
                def f():
                    pass
            '''
            compiled = compile_and_load(original)
            self.assertEqual(original, compiled)

        def test_one_yield_from(self):
            original = '''
                def f():
                    result = yield from g()
            '''

# Generated at 2022-06-12 04:27:30.467161
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import assert_transformed
    from .async_ import AsyncTransformer
    from .nodes import FunctionDefTransformer
    from .statements import TryTransformer, IfTransformer
    from .expressions import YieldTransformer, UnaryOpTransformer
    from .collections import ListCompTransformer, DictCompTransformer, GeneratorExprTransformer
    from .exceptions import WithTransformer
    from .klass import ClassDefTransformer
    from .import_ import ImportTransformer
    from .arguments import ArgumentsTransformer, KeywordTransformer
    from .for_ import ForTransformer, WithItemTransformer
    from .import_from import ImportFromTransformer
    from .assignments import AssignTransformer, AugAssignTransformer
    from .operations import BinOpTransformer, BoolOpTransformer

# Generated at 2022-06-12 04:27:35.891182
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.helpers import python_to_ast
    from ..tests.helpers import ast_to_python
    import ast as pyast
    file = 'import inspect\ndef main():\n\treturn 1'
    node = python_to_ast(file)
    result = ast_to_python(node)
    test_obj = YieldFromTransformer()
    assert test_obj.visit(node) == node

# Generated at 2022-06-12 04:27:37.457093
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for YieldFromTransformer."""
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:27:46.258883
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	c = YieldFromTransformer()

# Generated at 2022-06-12 04:27:56.331391
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # First test
    module = ast.Module([
        ast.Assign([ast.Name(id='a', ctx=ast.Store())],
                   ast.YieldFrom(value=ast.Constant(value=1, kind=None)))
    ])
    expected_module = ast.Module([
        ast.Assign([ast.Name(id='a', ctx=ast.Store())],
                   ast.Constant(value=1, kind=None))
    ])

    transformer = YieldFromTransformer()
    actual_module = transformer.visit(module)
    assert actual_module == expected_module

    # Second test
    module = ast.Module([
        ast.Expr(value=ast.YieldFrom(value=ast.Constant(value=1, kind=None)))
    ])

# Generated at 2022-06-12 04:28:05.194782
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    func = compile('''def func():
    a = yield from x
    yield from x
    yield from x
    yield from x
    b = yield from x
    yield from x
''', '<test>', 'exec')
    tree = ast.parse(func.co_consts[0])
    assert type(tree.body[0].body[0].value) is not ast.YieldFrom
    assert type(tree.body[0].body[1].value) is ast.YieldFrom
    assert type(tree.body[0].body[2].value) is ast.YieldFrom
    assert type(tree.body[0].body[3].value) is ast.YieldFrom
    assert type(tree.body[0].body[4].value) is not ast.YieldFrom

# Generated at 2022-06-12 04:28:05.716005
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert 1 == 1

# Generated at 2022-06-12 04:28:12.339511
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..tests.helper import compile_snippet, assert_node_equals
    from ..utils.fixtures import path
    from ..utils.helpers import VariablesGenerator # type: ignore

    snippet_ = """
    def test(a, b):
        c = a + b
        yield from range(c)
    """

    result = compile_snippet(snippet_, YieldFromTransformer)
    with path('YieldFromTransformer'):
        assert_node_equals(result, 'result')

# Generated at 2022-06-12 04:28:13.239623
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:28:14.604948
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()

    assert yield_from_transformer is not None

# Generated at 2022-06-12 04:28:23.078393
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import fst
    from ..utils import get_tree

    code = """\
    def f():
        yield from range(0)
        yield from a
        yield from get_generator()
        a = yield from get_generator()
        (yield from get_generator())
    """

# Generated at 2022-06-12 04:28:23.880542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:28:32.579425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    from .test_base import check_node
    from .test_base import BaseNodeTransformerTest


# Generated at 2022-06-12 04:28:49.187233
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:28:51.122948
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception as e:
        assert False, e
    else:
        assert True


# Generated at 2022-06-12 04:28:52.033344
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:28:53.255715
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()



# Generated at 2022-06-12 04:28:54.373041
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    c = YieldFromTransformer()
    assert c is not None


# Generated at 2022-06-12 04:29:02.394215
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = '''
import ast
import sys
from typed_ast import ast3 as ast
from typed_ast import Type
from typed_ast.transforms import YieldFromTransformer
node = ast.parse("foo = yield from bar")
YieldFromTransformer(sys.modules[__name__]).visit(node)
print(ast.dump(node, include_attributes=True))
'''

# Generated at 2022-06-12 04:29:03.191526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:29:07.707999
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # arrange
    from typed_ast import ast3
    from .const_folding import ConstantFoldingTransformer
    from .dead_code_elimination import DeadCodeEliminationTransformer
    from .control_flow_inliner import InlineTransformer

    # act
    pass

    # assert
    assert isinstance(YieldFromTransformer().visit(ast3.parse('1+1')), ast3.Module)


# Generated at 2022-06-12 04:29:16.231421
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor  # type: ignore
    transformer = YieldFromTransformer()
    code = 'def g():\n    return (a for a in range(1, 5))\n' +\
        'def f():\n    yield from g()\n'
    tree = astor.parse_file(astor.code_to_file(code))
    transformer.visit(tree)

# Generated at 2022-06-12 04:29:18.096399
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yft = YieldFromTransformer()
    assert yft is not None
    assert isinstance(yft, BaseNodeTransformer)

# Generated at 2022-06-12 04:30:06.234768
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    def expected_node(node):
        if isinstance(node, ast.Assign):
            expected_node.n_assign = expected_node.n_assign + 1
        elif isinstance(node, ast.Expr):
            expected_node.n_expr = expected_node.n_expr + 1
        elif isinstance(node, ast.While):
            expected_node.n_while = expected_node.n_while + 1
        elif isinstance(node, ast.Str):
            expected_node.n_str = expected_node.n_str + 1
        elif isinstance(node, ast.FunctionDef):
            expected_node.n_func = expected_node.n_func + 1

# Generated at 2022-06-12 04:30:07.638501
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__.__name__ == 'YieldFromTransformer'

# Generated at 2022-06-12 04:30:16.435352
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code_string = 'x = yield from (y for y in range(5))'
    code = ast.parse(code_string)
    YieldFromTransformer().visit(code)

# Generated at 2022-06-12 04:30:17.617843
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    print(x)

# Generated at 2022-06-12 04:30:18.461468
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:30:23.286816
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    yft = YieldFromTransformer()
    assert isinstance(yft, BaseNodeTransformer)
    assert isinstance(yft, YieldFromTransformer)

# Generated at 2022-06-12 04:30:31.984599
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = ast.parse("""
        def func():
            yield from gen
            x = yield from gen
            yield from gen
            yield from gen
            g = (yield from gen)
    """)
    YieldFromTransformer().visit(a)

# Generated at 2022-06-12 04:30:32.934040
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:30:34.451859
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()._tree_changed is False


# Generated at 2022-06-12 04:30:35.716913
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-12 04:32:02.059513
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  assert True

# Generated at 2022-06-12 04:32:02.587334
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert True

# Generated at 2022-06-12 04:32:09.502268
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .generator import GeneratorTransformer
    from ..utils.cst import parse_module, get_type_inference, to_source

    module_str = '''
    def func(arg):
        yield from arg
    '''
    gt = GeneratorTransformer()
    yft = YieldFromTransformer()
    tree = parse_module(module_str)
    gt.visit(tree)
    yft.visit(tree)

# Generated at 2022-06-12 04:32:11.130905
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().target == (3, 2)

# Generated at 2022-06-12 04:32:12.612410
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    trans = YieldFromTransformer()
    node = ast.parse("")
    trans.visit(node)

# Generated at 2022-06-12 04:32:19.498169
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.snippet import snippet
    from ..utils.test_utils import should_transform, run_transformer_test
    from ..utils.helpers import get_ast

    # Unit test for method _emulate_yield_from
    def test_emulate_yield_from_assign():
        snippet_ = snippet.get_body(yield_from_object=1,
                                    yield_from_expression=1,
                                    result=None,
                                    type_=ast.YieldFrom,
                                    target=ast.Name(id='y', ctx=ast.Store()))

# Generated at 2022-06-12 04:32:20.192436
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:32:27.347708
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import assertion_message
    from ..utils.tree import expected_tree
    from ..utils.source import source2ast
    from ..utils.source_gen import ast2source
    ast_ = source2ast("""\
    def a():
        a = yield from b()
        yield from b()
        yield from b()
        yield from b()
    """)

# Generated at 2022-06-12 04:32:35.719506
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import UnitTestTransformer

    class Test(UnitTestTransformer):
        transformer = YieldFromTransformer

# Generated at 2022-06-12 04:32:38.226737
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    result = YieldFromTransformer()
    assert not hasattr(result, '_tree_changed') and not hasattr(result,'_changed')