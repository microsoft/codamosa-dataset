

# Generated at 2022-06-12 04:25:33.579311
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast.ast3 import Try
    from typed_ast.ast3 import parse
    class_node = YieldFromTransformer(parse("""\
        def foo():
            for i in range(3):
                try:
                    yield from bar()
                except Exception as e:
                    yield e
            return bar
            """).body[0])
    assert isinstance(class_node.visit(parse("""\
        def foo():
            for i in range(3):
                try:
                    yield from bar()
                except Exception as e:
                    yield e
            return bar
            """).body[0]), Try)

# Generated at 2022-06-12 04:25:34.485047
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer 


# Generated at 2022-06-12 04:25:42.738933
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .utils import get_node
    from .utils_ast3 import tree_equals

    try_stmt = get_node('''
        try:
            yield from func()
        except Exception as e:
            print(e)
        ''')

    expected_try_stmt = get_node('''
        let(iterable)
        iterable = iter(func())
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc_0:
                e = exc_0.value
                break
            except Exception as exc_0:
                e = exc_0
                print(e)
                break
    ''')

    tree_equals(YieldFromTransformer().visit(try_stmt), expected_try_stmt)

    expr_stmt = get

# Generated at 2022-06-12 04:25:43.574451
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)

# Generated at 2022-06-12 04:25:45.436762
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:46.813881
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:25:47.714888
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:25:49.021416
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # This should not raise any exception
    YieldFromTransformer()

# Generated at 2022-06-12 04:25:53.859528
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Code is valid Python 3 syntax, but not valid in Python 2.
    exec('''if 1:
        def f():
            a = yield from gen()

        def g():
            yield from gen()

        def k():
            yield from gen()
            yield from gen()
            yield from gen()
    ''')


# Generated at 2022-06-12 04:26:01.017973
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile_to_ast
    from .test_classes import _BaseTransformerTest
    from ..utils.helpers import print_ast
    import astor

    class Test(YieldFromTransformer, _BaseTransformerTest):
        transformer = YieldFromTransformer

        def test_yield_from(self):
            source = """
                def func():
                    yield from range(5)
            """
            result = """
                def func():
                    exc = {0}
                    iterable = iter(range(5))
                    while True:
                        try:
                            yield next(iterable)
                        except StopIteration as exc:
                            pass
                            break
            """.format(VariablesGenerator.generate())
            self.assertEqual(self.transform(source), result)


# Generated at 2022-06-12 04:26:14.282542
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.ast import parse_ast_tree

    # test 1
    src = 'a = yield from b'
    tree = parse_ast_tree(src)
    result = YieldFromTransformer().visit(tree)
    expected_result = parse_ast_tree('''
try:
    iterable = iter(b)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            a = exc.value
            break
except GeneratorExit:
    pass
''')
    assert result == expected_result

    # test 2
    src = 'yield from b'
    tree = parse_ast_tree(src)
    result = YieldFromTransformer().visit(tree)

# Generated at 2022-06-12 04:26:15.354493
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:22.315818
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert str(YieldFromTransformer.__doc__).strip() == 'Compiles yield from to special while statement.'
    assert str(YieldFromTransformer.target).strip() == '(3, 2)'
    yield_from_transformer._get_yield_from_index(None, None)
    yield_from_transformer._emulate_yield_from(None, None)
    yield_from_transformer._handle_assignments(None)
    yield_from_transformer._handle_expressions(None)
    yield_from_transformer.visit(None)

# Generated at 2022-06-12 04:26:33.634773
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:34.435553
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:45.387760
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import parse
    import ast
    code = """
    a = yield from range(1)
    """
    trans = YieldFromTransformer()
    assert isinstance(trans, BaseNodeTransformer)
    # get the version of ast the transformed code will use
    version = trans.target[0] * 100 + trans.target[1]
    # create a ast node object
    obj = parse(code, version=version)
    obj = trans.visit(obj)
    assert isinstance(obj, ast.Module)
    assert isinstance(obj.body, list)
    assert isinstance(obj.body[0], ast.Assign)
    assert isinstance(obj.body[1], ast.While)
    assert isinstance(obj.body[1].body, list)

# Generated at 2022-06-12 04:26:47.658059
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()



# Generated at 2022-06-12 04:26:58.986183
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    fr_exc = ast.alias(name='__future__', asname='exc')
    import_fr = ast.ImportFrom(module='__future__',
                               names=[fr_exc],
                               level=0)
    yield_from = ast.Expr(value=ast.YieldFrom(value=ast.Str(s='abc')))
    body = [import_fr, yield_from]
    mod = ast.Module(body=body)
    t = YieldFromTransformer()
    mod = t.visit(mod)

    exc_name = t.variables_generator.peek()
    assert len(exc_name) == 3
    assert exc_name[0] == 'exc'

    assert len(mod.body) == 3
    assert isinstance(mod.body[0], ast.ImportFrom)


# Generated at 2022-06-12 04:27:00.822086
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import base

    base.test_TransformerConstructor(YieldFromTransformer)


# Generated at 2022-06-12 04:27:07.576637
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .helpers import from_source
    from ..utils.tree import print_tree, compare_trees

    source = '''
        def foo():
            a = b
            a = yield from iter(foo(a))
    '''

    expected = '''
        def foo():
            a = b
            let(iterable)
            iterable = iter(foo(a))
            while True:
                try:
                    yield next(iterable)
                except StopIteration as exc:
                    a = exc.value
                    break
    '''

    tree = from_source(source, YieldFromTransformer)

    assert compare_trees(tree, from_source(expected))

# Generated at 2022-06-12 04:27:26.339266
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from .node_type_checker import NodeTypeChecker as Checker
    import itertools as it

# Generated at 2022-06-12 04:27:28.750665
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Make sure YieldFromTransformer is an instance of BaseNodeTransformer
    assert isinstance(YieldFromTransformer(None), BaseNodeTransformer)


# Generated at 2022-06-12 04:27:36.975581
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import libcst as cst
    from textwrap import dedent

    src = dedent('''
    def fun():
        a = yield from b
        yield from c
    ''')

    mod = cst.parse_module(src)
    gen = YieldFromTransformer()

    mod = gen.visit(mod)

    assert gen.is_changed() is True

    src = dedent('''
    def fun():
        a = yield from b
        while True:
            try:
                yield next(iter(c))
            except StopIteration as exc:
                pass
            break
    ''')

    mod2 = cst.parse_module(src)

    assert mod == mod2

# Generated at 2022-06-12 04:27:46.260718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..transforms.yield_from import YieldFromTransformer 
    transformer = YieldFromTransformer()

    # Unit test for method _get_yield_from_index
    def test__get_yield_from_index():
        import ast

        node1 = ast.Expr()
        node2 = ast.Assign()
        node3 = ast.Expr()
        node4 = ast.YieldFrom()
        node5 = ast.Expr()
        node6 = ast.Assign()
        node7 = ast.YieldFrom()
        node8 = ast.Expr()
        node9 = ast.Expr()
        node10 = ast.Expr()

        node1.body = [node2, node3, node4, node5, node6, node7, node8, node9, node10]


# Generated at 2022-06-12 04:27:48.391343
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Object of class YieldFromTransformer
    t = YieldFromTransformer()
    assert type(t) == YieldFromTransformer


# Generated at 2022-06-12 04:27:49.703594
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().__class__ == YieldFromTransformer


# Generated at 2022-06-12 04:27:51.056622
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(None)
    assert transformer is not None

# Generated at 2022-06-12 04:27:52.018931
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:00.218572
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_ast.ast3 as ast

    from typed_ast import ast3 as ast

    from typed_astunparse import unparse

    import astor

    t = YieldFromTransformer()
    node = ast.parse("""
    y = yield from test
    """)
    t.visit(node)
    code = astor.to_source(node)
    expected = """
    let(iterable)
    iterable = iter(test)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            y = exc.value
            break
    """
    assert code == expected

# Generated at 2022-06-12 04:28:02.703274
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except NameError:
        pass
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-12 04:28:31.678720
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        node = ast.parse("something = yield from some_gen")
        result = YieldFromTransformer().visit(node)
    except:
        assert False
    expected = ast.Module(body=[
        ast.Assign(
            targets=[ast.Name(id='something', ctx=ast.Store())],
            value=ast.Call(func=ast.Name(id='yield_from', ctx=ast.Load()),
                           args=[ast.Name(id='some_gen', ctx=ast.Load())],
                           keywords=[])
        )
    ])

    assert ast.dump(result) == ast.dump(expected)


# Generated at 2022-06-12 04:28:35.155100
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # todo: use proper type annotations to cover this function
    from typed_ast.ast3 import Module, Assign, Expr, YieldFrom, Name, Store, Load, FunctionDef, Return
    from typed_ast.compat import unicode
    from .base import TransformerTestCase


# Generated at 2022-06-12 04:28:36.011166
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() is not None

# Generated at 2022-06-12 04:28:36.928208
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:28:39.829236
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is YieldFromTransformer
    from ..utils.helpers import noop
    assert YieldFromTransformer(noop)
    assert YieldFromTransformer._get_yield_from_index
    assert YieldFromTransformer._emulate_yield_from

# Generated at 2022-06-12 04:28:40.693109
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:44.303143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert_equal(YieldFromTransformer().__class__, YieldFromTransformer)

from .base import BaseNodeTransformer


# Generated at 2022-06-12 04:28:47.589264
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from compiler.utils.compile_snippet import compile_snippet
    from compiler.compilers.yield_from import YieldFromTransformer

    nodes = compile_snippet('yield from function()')
    transformer = YieldFromTransformer()
    for node in nodes:
        node = transformer.visit(node)
    assert transformer._tree_changed is True

# Generated at 2022-06-12 04:28:49.410462
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    o = YieldFromTransformer()
    assert(isinstance(o, BaseNodeTransformer))

# Generated at 2022-06-12 04:28:50.341986
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:29:39.870673
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:29:41.043172
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    pass


# Generated at 2022-06-12 04:29:47.025146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_helpers import make_test_case, assert_container_with_items

# Generated at 2022-06-12 04:29:52.741838
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse('a = yield from b', mode='exec')
    trans = YieldFromTransformer()
    trans.visit(node)

    expected = ast.parse('''
    iterable = iter(b)
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                a = exc.value
            break
    ''', mode='exec')
    assert ast.dump(node, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-12 04:29:54.437676
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x.target is (3, 2)
    assert x._tree_changed is False


# Generated at 2022-06-12 04:30:05.449871
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from z3 import *
        from termcolor import colored
        from astor.source_repr import iter_node, dump_tree
        from ast_tools.passes.rename_globals import RenameGlobals
        from .loop_unroller import LoopUnroller
    except ImportError:
        print(colored("Missing modules for testing!!", 'red', attrs=['bold']))
        print(colored("Skipping tests!!", 'red', attrs=['bold']))
        return

    s = Solver()

    # Simple example
    tree = ast.parse("""
a = 0
while True:
    print('thing')
""")
    print(colored("Unrolled tree:", attrs=['bold']))
    v = RenameGlobals()
    v.visit(tree)
   

# Generated at 2022-06-12 04:30:07.248848
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    from ..context import Context
    from ..parser import parse


# Generated at 2022-06-12 04:30:16.001578
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse('''
y = yield from my_coroutine()
try:
    yield from other_coroutine()
except Exception as exc:
    pass
y = yield from gen()
''')
    transformer = YieldFromTransformer()
    transformer.run(tree)

# Generated at 2022-06-12 04:30:25.935342
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.helpers import get_ast
    transformer = YieldFromTransformer()
    tree = get_ast("""a = yield from b""")
    transformer.visit(tree)
    assert str(transformer.tree) == """\
let(iterable)
iterable = iter(b)
while True:
    try:
        a = next(iterable)
    except StopIteration as exc:
        if hasattr(exc, 'value'):
            a = exc.value
        break\
"""
    transformer.reset()

    tree = get_ast("""yield from b""")
    transformer.visit(tree)

# Generated at 2022-06-12 04:30:26.453372
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:32:40.806537
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ...tests.fixtures import function_yield_from_3_2
    from .fixtures import module_yield_from_3_2_compiled

    tree = function_yield_from_3_2.graft
    tree = YieldFromTransformer.run(tree)

    assert tree == module_yield_from_3_2_compiled.graft

# Generated at 2022-06-12 04:32:48.452727
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Case 1:
    # Following code should be transformed to:
    #   a = yield from yield_from(3)
    #   f()
    #
    #   while True:
    #       try:
    #           yield next(iterable)
    #       except StopIteration as exc:
    #           a = exc.value
    #           break
    #   f()
    code = '''
    a = yield from yield_from(3)
    f()
    '''
    node = ast.parse(code)
    return_node = YieldFromTransformer()(node)

# Generated at 2022-06-12 04:32:49.125178
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:32:50.015013
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from test.test_transformer import process


# Generated at 2022-06-12 04:32:51.242365
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    test = YieldFromTransformer()
    assert type(test) == YieldFromTransformer

# Generated at 2022-06-12 04:32:52.024651
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:32:53.411668
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    f = YieldFromTransformer(None)
    assert f._tree_changed

# Generated at 2022-06-12 04:32:54.192635
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-12 04:32:57.685343
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.FunctionDef(name='foo', body=[ast.Expr(value=ast.YieldFrom(value=3))], args=ast.arguments())
    transformer = YieldFromTransformer()
    _ = transformer.visit(node)

# Generated at 2022-06-12 04:32:58.613970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()
