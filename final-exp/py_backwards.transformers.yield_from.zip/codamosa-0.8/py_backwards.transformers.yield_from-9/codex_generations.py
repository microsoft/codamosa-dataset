

# Generated at 2022-06-12 04:25:25.570491
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:25:27.660143
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None)


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:25:36.624466
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..codegen import to_source, CodeGenerator
    import inspect
    import re
    import ast

    class Sample(CodeGenerator):
        def __init__(self):
            super().__init__()

        def generate(self, node: ast.AST) -> str:
            self.visit(node)
            return self.result()

        def visit_FunctionDef(self, node):
            s = 'def test_function():'
            self.result.append(s)
            self.generic_visit(node)


        def visit_Assign(self, node):
            self.generic_visit(node)
            s = '    a = b'
            self.result.append(s)

        def visit_Expr(self, node):
            self.generic_visit(node)

# Generated at 2022-06-12 04:25:37.502336
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:25:38.658718
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer() != YieldFromTransformer()

# Generated at 2022-06-12 04:25:39.827767
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    assert x != None

# Generated at 2022-06-12 04:25:40.986902
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    hasattr(YieldFromTransformer, 'visit_Module')


# Generated at 2022-06-12 04:25:51.954016
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.parse("def foo(): yield from bar()", mode='exec')
    result = YieldFromTransformer().visit(node)
    assert isinstance(result, ast.Module)
    assert len(result.body) == 1
    result = result.body[0]
    assert isinstance(result, ast.FunctionDef)
    assert result._fields == ('name', 'args', 'body', 'decorator_list', 'returns')
    assert result.name == 'foo'
    assert result.args is None
    assert result.decorator_list == []
    assert result.returns is None
    assert len(result.body) == 1
    result = result.body[0]
    assert isinstance(result, ast.While)
    assert result._fields == ('test', 'body', 'orelse')
   

# Generated at 2022-06-12 04:25:52.951804
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:00.559628
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    exc2 = ast.Name(id='exc2') # noqa: F841
    exc = ast.Name(id='exc') # noqa: F841
    target2 = ast.Name(id='target2') # noqa: F841
    target = ast.Name(id='target') # noqa: F841
    if_body = ast.If(test=ast.Name(id='test'), # noqa: F841
                     body=[ast.YieldFrom(value=ast.Name(id='A'))], # noqa: F841
                     orelse=[ast.YieldFrom(value=ast.Name(id='B'))]) # noqa: F841

# Generated at 2022-06-12 04:26:06.966963
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:26:10.894896
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    snippet = 'def test():\n    yield from range(10)'
    tree = ast.parse(snippet)
    YieldFromTransformer().visit(tree)
    assert(str(tree)) == '''def test():
    let(iterable)
    iterable = iter(range(10))
    while True:
        try:
            yield next(iterable)
        except StopIteration as exc:
            if hasattr(exc, 'value'):
                exc = exc.value
            break'''

# Generated at 2022-06-12 04:26:11.995187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    pass

# Generated at 2022-06-12 04:26:17.435210
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import utils
    from astunparse import unparse
    with open(utils.__file__[:-1], 'r') as f:
        contents = f.read()
        module = ast.parse(contents)
        YieldFromTransformer().visit(module)
        print('YieldFromTransformer() test result:\n')
        print(unparse(module))

# Generated at 2022-06-12 04:26:21.668529
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class YieldFromTransformerFake(YieldFromTransformer):
        def __init__(self, *args, **kwargs):
            tree_changed = kwargs.get('tree_changed')
            if tree_changed is not None:
                self._tree_changed = tree_changed
            return super().__init__(*args, **kwargs)

    YieldFromTransformerFake()

# Generated at 2022-06-12 04:26:31.180736
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Parser:
        def __init__(self):
            self.ast = ast
            self.transformer = YieldFromTransformer
            self.transformer.reset()

    parser = Parser()
    tree = parser.ast.parse('''
    def foo():
        yield from bar(1)
    ''')
    module = parser.transformer.visit(tree)
    if module:
        result = parser.ast.unparse(module)
        assert "for exc in iter(bar(1))" in result
        assert "yield next(exc)" in result
        assert "except StopIteration" in result
        assert "pass" in result

# Generated at 2022-06-12 04:26:34.677600
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    print(YieldFromTransformer())
    lines = 1
    branch = 1
    if lines:
        branch = 0
    EOF = "EOF"
    lines = "lines"
    branch = "branch"
    print(EOF)

if __name__ == "__main__":
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:26:36.085777
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass
#    transformer = YieldFromTransformer()
#    assert transformer

# Generated at 2022-06-12 04:26:46.672783
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ..utils.fake_ast import gen_fake_try_ast
    from ..utils.code_generator import generate
    from .for_transformer import ForTransformer
    from .function_def_transformer import FunctionDefTransformer
    from .if_transformer import IfTransformer

    # test on Try
    ast_try = gen_fake_try_ast()
    ast_try = ForTransformer().visit(ast_try)
    ast_try = IfTransformer().visit(ast_try)
    ast_try = FunctionDefTransformer().visit(ast_try)


# Generated at 2022-06-12 04:26:48.157502
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils import parse_ast, dump_ast

# Generated at 2022-06-12 04:27:02.270826
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception:
        assert False, "Unable to instantiate YieldFromTransformer"
    assert True


# Generated at 2022-06-12 04:27:03.713546
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:27:04.754819
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), YieldFromTransformer)

# Generated at 2022-06-12 04:27:08.595479
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = ast.YieldFrom()
    tr = YieldFromTransformer(node)
    assert tr.node == node
    assert tr.target == (3, 2)

# Generated at 2022-06-12 04:27:09.779543
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

# Generated at 2022-06-12 04:27:11.326914
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import typed_astunparse

# Generated at 2022-06-12 04:27:13.024720
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Test YieldFromTransformer constructor.
    """
    assert YieldFromTransformer() is not None


# Generated at 2022-06-12 04:27:14.170832
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer


# Generated at 2022-06-12 04:27:15.748876
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:27:17.132711
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    


# Generated at 2022-06-12 04:27:47.193163
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Create a fake node
    class fake_node(object):
        def __init__(self):
            self.body = [
                ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.YieldFrom(value=ast.Name(id='a', ctx=ast.Load()))),
                ast.Expr(value=a)
            ]

            self.targets = [ast.Name(id='a', ctx=ast.Store())]

    # Insert the fake node
    node = fake_node()
    # Create an object of YieldFromTransformer
    obj = YieldFromTransformer()
    # Call the visit method
    obj.visit(node)

# Generated at 2022-06-12 04:27:50.099320
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        _ = YieldFromTransformer()
    except:
        assert False, "Unable to instantiate YieldFromTransformer"
    else:
        assert True


# Generated at 2022-06-12 04:27:52.179402
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert len(transformer.targets) == 1
    assert transformer.visit is not None

# Generated at 2022-06-12 04:27:53.423065
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert 'yield from' not in str(YieldFromTransformer())

# Generated at 2022-06-12 04:28:03.416070
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    check_snippets = QA.check_snippets


# Generated at 2022-06-12 04:28:08.745639
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Testing _get_yield_from_index()
    def test_get_yield_from_index():
        test = ast.parse("""
        def my_fun():
            expr = yield from foo()
            while True:
                bar = yield from bar()
            yield from bar()
        """)
        assert YieldFromTransformer()._get_yield_from_index(test.body[0], ast.Expr) == 0
        assert YieldFromTransformer()._get_yield_from_index(test.body[0], ast.Assign) is None
        assert YieldFromTransformer()._get_yield_from_index(test.body[0].body[1], ast.Expr) is None

# Generated at 2022-06-12 04:28:09.580667
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tr = YieldFromTransformer()

# Generated at 2022-06-12 04:28:10.692109
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from snakeye.utils.tree import dump


# Generated at 2022-06-12 04:28:11.536052
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:28:12.816457
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()
    pass

# Generated at 2022-06-12 04:29:00.718122
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    obj = YieldFromTransformer()
    assert obj.__class__.__name__ == "YieldFromTransformer"

# Generated at 2022-06-12 04:29:04.806110
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.trees import trees
    import astor
    node = astor.parse(trees.yield_from.__doc__)
    YieldFromTransformer().visit(node)

    correct_ast = astor.parse(trees.yield_from.after)
    assert astor.to_source(node) == astor.to_source(correct_ast)


# Generated at 2022-06-12 04:29:06.372421
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    y = YieldFromTransformer.__new__(YieldFromTransformer)
    assert isinstance(y, YieldFromTransformer)


# Generated at 2022-06-12 04:29:09.804009
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer
    assert hasattr(YieldFromTransformer, 'visit')
    assert callable(YieldFromTransformer.visit)
    t = YieldFromTransformer()
    assert hasattr(t, 'visit')
    assert callable(getattr(t, 'visit'))

# Generated at 2022-06-12 04:29:10.304458
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:29:11.855357
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer"""
    YieldFromTransformer()



# Generated at 2022-06-12 04:29:14.145889
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    instance = YieldFromTransformer()
    assert isinstance(instance, YieldFromTransformer)
    assert isinstance(instance, BaseNodeTransformer)


# Generated at 2022-06-12 04:29:15.870416
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer.get_name()
    assert x == 'YieldFromTransformer'


# Generated at 2022-06-12 04:29:16.701959
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:29:17.897811
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert isinstance(YieldFromTransformer(), BaseNodeTransformer)

# Generated at 2022-06-12 04:33:00.349841
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:33:03.897391
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    
    c = YieldFromTransformer()
    if not isinstance(c, BaseNodeTransformer):
        print('ERROR: cannot initialize class YieldFromTransformer')
    
test_YieldFromTransformer()



# Generated at 2022-06-12 04:33:05.563969
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()
    print(x)

# Generated at 2022-06-12 04:33:06.344114
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:33:07.196562
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:33:08.988526
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    '''
    Test for YieldFromTransformer
    '''
    assert(YieldFromTransformer)


# Generated at 2022-06-12 04:33:09.862929
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:33:10.738439
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:33:12.256044
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testing import run_local_tests
    run_local_tests(YieldFromTransformer)

# Generated at 2022-06-12 04:33:14.485116
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class YieldFromTransformerTester(object):
        def __init__(self, *args, **kwargs):
            actual = YieldFromTransformer()
            expected = YieldFromTransformer()
            assert actual == expected