

# Generated at 2022-06-12 04:25:26.715427
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:25:35.798674
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .utils import make_module

    def assert_yield_from(src: str, expected: str) -> None:
        parsed = ast.parse(src)
        YieldFromTransformer().visit(parsed)
        actual = ast.dump(parsed)
        if expected != actual:
            import sys
            print('expected:')
            print(expected)
            print('actual:')
            print(actual)
        assert expected == actual


# Generated at 2022-06-12 04:25:37.330775
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert type(YieldFromTransformer()) == YieldFromTransformer


# Generated at 2022-06-12 04:25:47.265254
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import transformer, src, _compat
    from .function_definition import FunctionDefinitionTransformer
    from .return_with_none import ReturnWithNoneTransformer
    from .yield_return import YieldReturnTransformer

    # Simple case
    code = src("""
        def foo(bar):
            yield from bar
            return
    """)
    tree = _compat.parse(code)
    tree = YieldReturnTransformer().visit(tree)
    tree = transformer.transform(tree, [FunctionDefinitionTransformer,
                                        YieldFromTransformer,
                                        ReturnWithNoneTransformer])

# Generated at 2022-06-12 04:25:49.304723
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import numpy as np
    from ..test.test_utils import transform, compare_code


# Generated at 2022-06-12 04:25:58.488311
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Set up for some tests
    input_code = YieldFromTransformer()

    # Simulated cases
    code = input_code
    assert code.__class__.__name__ == "YieldFromTransformer"

    code = input_code.target
    assert code.__class__.__name__ == "Tuple"
    assert code[0] == 3
    assert code[1] == 2

    code = input_code._get_yield_from_index(node = 'node', type_ = 'type_')
    assert code.__class__.__name__ == "NoneType"

    # Cases not covered by the code
    # code = input_code._emulate_yield_from(target = 'target', node = 'node')
    # assert code.__class__.__name__ == ""

    # code = input

# Generated at 2022-06-12 04:25:59.299076
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer.__doc__ is not None

# Generated at 2022-06-12 04:26:03.495620
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.target == (3, 2)
    YieldFromTransformer()

if __name__ == '__main__':
    import pytest
    pytest.main(['--capture=no', __file__])

# Generated at 2022-06-12 04:26:04.387978
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    return YieldFromTransformer()

# Generated at 2022-06-12 04:26:07.657480
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test for constructor of class YieldFromTransformer.
    """
    node = ast.Try()
    assert YieldFromTransformer().visit(node) == node


# Generated at 2022-06-12 04:26:14.070906
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:14.623022
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer(): # FIXME
    assert True

# Generated at 2022-06-12 04:26:21.632098
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Assignments
    assert ast.parse('def foo(x): yield from x') == YieldFromTransformer().visit(
        ast.parse('def foo(x): yield from x'))

    assert ast.parse('def foo(x): bar = yield from x') == YieldFromTransformer().visit(
        ast.parse('def foo(x): bar = yield from x'))

    # Expressions
    assert ast.parse('def foo(x): yield from x').body[0] == YieldFromTransformer().visit(
        ast.parse('def foo(x): yield from x')).body[0]

# Generated at 2022-06-12 04:26:32.957691
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .minitest import BaseTestTransformer

    class TestForTransformer(BaseTestTransformer.TestTransformer):
        transform = YieldFromTransformer

        def _test_transform(self, before, after):
            self.assert_transformed_ast(before, after)

        def test_assignment(self):
            before = 'a = yield from b'
            after = '''
            let(iterable_0)
            iterable_0 = iter(b)
            while True:
                try:
                    yield next(iterable_0)
                except StopIteration as exc_0:
                    a = exc_0.value
                    break
            '''
            self._test_transform(before, after)

        def test_expression(self):
            before = 'yield from b'

# Generated at 2022-06-12 04:26:34.435878
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except TypeError:
        assert False
    assert True

# Generated at 2022-06-12 04:26:35.234318
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:41.549424
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
	exam=YieldFromTransformer()
	assert exam._tree_changed==False
	assert exam._get_yield_from_index(1,1)==None
	assert exam._emulate_yield_from(1,2)==yield_from.get_body()
	assert exam.visit(1)==exam.generic_visit()
	assert exam.generic_visit()==exam.visit()

# Generated at 2022-06-12 04:26:46.097146
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import YieldFromTransformer

    transformer = YieldFromTransformer()
    result = transformer.visit(ast.parse(ast.Module(body=[ast.Expr(value=ast.YieldFrom(value=ast.Name(id='iterable')))]))) # pass


# inherited from class YieldFromTransformer

# Generated at 2022-06-12 04:26:47.704502
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()


# Generated at 2022-06-12 04:26:59.033831
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer(2)
    assert(transformer._get_yield_from_index(ast.parse("def foo(): return 1"), ast.Expr) is None)
    assert(transformer._get_yield_from_index(ast.parse("def foo(): yield from foo"), ast.Expr) is 0)

    result = transformer._handle_assignments(ast.parse("def foo():\n    a = yield from foo").body[0])
    assert(result == ast.parse("def foo():\n    iterable = iter(foo)\n    while True:\n        try:\n            yield next(iterable)\n        except StopIteration as exc:\n            a = exc.value\n            break").body[0])


# Generated at 2022-06-12 04:27:12.499705
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .node_transformer_tests import test_constructor_of_class
    test_constructor_of_class(YieldFromTransformer)


# Generated at 2022-06-12 04:27:14.318927
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert repr(YieldFromTransformer) == "<class 'yat.transformer.yield_from.YieldFromTransformer'>"

# Generated at 2022-06-12 04:27:18.422914
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # args: self
    assert type(YieldFromTransformer()) == YieldFromTransformer
    # method visit
    from typed_ast.ast3 import FunctionDef
    from ..utils.tree import parse, roundtrip

# Generated at 2022-06-12 04:27:19.395246
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:20.593682
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()

# Generated at 2022-06-12 04:27:21.804117
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    a = YieldFromTransformer()
    assert a is not None

# Generated at 2022-06-12 04:27:23.478970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    constructor_test_helper(
        {{{}}}, # noqa E501
        YieldFromTransformer,
        (None,)
    )

# Generated at 2022-06-12 04:27:30.150527
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from textwrap import dedent
    from ..utils import run_to_ast

    source = dedent('''
    foo = yield from bar()
    ''')

    ast_tree = run_to_ast(source)
    assert type(ast_tree).__name__ == 'Module'
    assert type(ast_tree.body[0]).__name__ == 'Assign'
    assign = ast_tree.body[0]
    assert type(assign.targets[0]).__name__ == 'Name'
    assert assign.targets[0].id == 'foo'
    assert type(assign.value).__name__ == 'Call'
    assert assign.value.func.id == 'bar'
    assert type(assign.value.func.value).__name__ == 'Name'

# Generated at 2022-06-12 04:27:39.774241
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    result = yield from generator
    result, other = yield from other_generator
    """
    tree = ast.parse(code, mode='exec')
    YieldFromTransformer().visit(tree)

# Generated at 2022-06-12 04:27:40.608205
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:28:03.491500
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from_transformer = YieldFromTransformer()
    assert yield_from_transformer.target == (3, 2)

# Generated at 2022-06-12 04:28:03.999018
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:28:07.583607
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3
    t = ast3.YieldFrom()
    a = ast3.parse('yield from 2')
    assert t.value == a.body[0].value.value

# Generated at 2022-06-12 04:28:15.751496
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from . import ast_cleanup

    target = (3, 2)
    cleaner = ast_cleanup.ASTCleaner(target)
    cleaner.visit(ast.parse('yield from range(3)'))
    assert cleaner.version == target

    transformer = YieldFromTransformer(target)
    transformed = transformer.run(cleaner.code)
    assert transformer.changed

    result = ast.parse(transformed)
    assert isinstance(result, ast.Module)
    assert len(result.body) == 3
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[1], ast.While)
    assert isinstance(result.body[2], ast.Expr)
    assert isinstance(result.body[0].value, ast.Call)

# Generated at 2022-06-12 04:28:17.732008
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    t = YieldFromTransformer()

# Generated at 2022-06-12 04:28:26.234716
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = '''
    def fun():
        yield from range(3)
        a = yield from range(3)
    '''

    expected_code = '''
    def fun():
        let(iterable)
        iterable = iter(range(3))
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    '''

    tree = ast.parse(code)
    YieldFromTransformer().visit(tree)
    generated_code = compile(tree, '', 'exec')

    tree_expected = ast.parse(expected_code)
    generated_expected_code = compile(tree_expected, '', 'exec')

    assert generated_code == generated_expected_code

# Generated at 2022-06-12 04:28:34.873662
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    obj = YieldFromTransformer

    def test_attributes():
        assert YieldFromTransformer.target == (3, 2)

    def test_visit():
        assert obj.visit(obj, obj.__init__) == obj

    def test__get_yield_from_index():
        assert YieldFromTransformer._get_yield_from_index(obj, ast, ast) == None

    def test__emulate_yield_from():
        assert YieldFromTransformer._emulate_yield_from(obj, obj) == []

    def test__handle_assignments():
        assert YieldFromTransformer._handle_assignments(obj, obj) == obj

    def test__handle_expressions():
        assert YieldFromTransformer._handle_expressions(obj, obj) == obj

#

# Generated at 2022-06-12 04:28:37.113747
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a = YieldFromTransformer()
    except Exception as e:
        assert False, e
    else:
        assert True



# Generated at 2022-06-12 04:28:42.636565
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """
    Test that only nodes of type ast.Assign and ast.Expr are checked for the
    yield from statement and that those nodes with a yield from statement are
    removed and replaced by the appropriate loop.
    """

# Generated at 2022-06-12 04:28:44.262235
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()



# Generated at 2022-06-12 04:29:34.393421
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    f = open('test_20.pickle', 'rb')
    node = pickle.load(f)
    f.close()
    node = YieldFromTransformer().visit(node)
    #print("node = ", ast.dump(node))
    f = open('test_20_after.pickle', 'wb')
    pickle.dump(node, f)
    f.close()

# Generated at 2022-06-12 04:29:36.180495
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    transformer.visit(ast.parse("result = yield from x"))


# Generated at 2022-06-12 04:29:38.659853
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    node = ast.YieldFrom(1)

    transformer = YieldFromTransformer()
    assert astor.to_source(transformer.visit(node)) == 'yield from 1'

# Generated at 2022-06-12 04:29:39.471686
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:29:40.692643
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(tree_changed=False)


# Generated at 2022-06-12 04:29:41.471903
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer

# Generated at 2022-06-12 04:29:46.916471
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .test_helpers import round_trip

    code = '''
    def my_generator():
        a = yield from [1, 2, 3]
    '''
    rt_code = '''
    def my_generator():
        iterable = iter([1, 2, 3])
        while True:
            try:
                next(iterable)
            except StopIteration as exc:
                a = exc.value
                break
    '''
    tree = ast.parse(code)
    expected = ast.parse(rt_code)
    tree = YieldFromTransformer().visit(tree)
    assert round_trip(tree) == round_trip(expected)
# Unit test function test_YieldFromTransformer


# Generated at 2022-06-12 04:29:48.321660
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert isinstance(transformer, YieldFromTransformer)


# Generated at 2022-06-12 04:29:51.509728
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typing import Any
    from typed_ast import ast3 as ast

    class AnyType(Any):
        pass

    _1 = YieldFromTransformer()
    _2 = YieldFromTransformer([Node])
    _1 = YieldFromTransformer.visit(AnyType())


# Generated at 2022-06-12 04:29:53.060902
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(scale_factor=1.0, initial_state=None)


# Generated at 2022-06-12 04:32:05.090590
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with open('snippets/yield_from.py') as f:
        code = f.read()
    tree = ast.parse(code)
    before = ast.dump(tree,annotate_fields=False)
    t = YieldFromTransformer().visit(tree)
    after = ast.dump(t,annotate_fields=False)

# Generated at 2022-06-12 04:32:06.941187
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        YieldFromTransformer()
    except Exception:
        assert False, 'Failed at constructing YieldFromTransformer object.'


# Generated at 2022-06-12 04:32:08.180384
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .. import compile_to_ast, parse
    from ..utils.helpers import print_ast


# Generated at 2022-06-12 04:32:13.896927
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    nodes = [('Module', 'body'),
             ('FunctionDef', 'body'),
             ('Try', 'body'),
             ('While', 'body'),
             ('If', 'body'),
             ('For', 'body')]
    for node_type, target in nodes:
        node = ast.parse("yield from []")
        for child_node in node.body:
            setattr(child_node, target, [])
        transformer = YieldFromTransformer()
        assert getattr(transformer, 'visit_' + node_type, None) is not None
        transformer.visit(child_node)


# Generated at 2022-06-12 04:32:14.779450
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(0)

# Generated at 2022-06-12 04:32:15.535048
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None

# Generated at 2022-06-12 04:32:15.995149
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    pass

# Generated at 2022-06-12 04:32:16.817117
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    _ = YieldFromTransformer()

# Generated at 2022-06-12 04:32:23.639428
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astunparse
    import copy

# Generated at 2022-06-12 04:32:27.560425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    yield_from = ast.YieldFrom(value=ast.Name('a'))
    expr = ast.Expr(yield_from)
    assign = ast.Assign(targets=[ast.Name('b')], value=yield_from)
    mod = ast.Module(body=[expr, assign])

    node_transformer = YieldFromTransformer()
    node_transformer.visit(mod)