

# Generated at 2022-06-12 04:25:26.557149
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.transforms import YieldFromTransformer
    from astpp import dump
    # 0
    tree = ast.parse("""\
import ast, sys
with open(sys.argv[1], 'r') as f:
  tree = ast.parse(f.read())
  YieldFromTransformer().visit(tree)
  print(ast.dump(tree))
""")
    # 1 
    YieldFromTransformer().visit(tree)
    # 2
    print(dump(tree))


# Generated at 2022-06-12 04:25:33.713296
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        a = 1
    except Exception:
        a = 2
    try:
        pass
    except Exception:
        pass
    try:
        pass
    finally:
        pass
    try:
        pass
    except Exception:
        pass
    else:
        pass
    with open("D:\\filtered_data_test.csv", "w", encoding="utf-8") as writer:
        writer.write("good")
    def test():
        yield from range(10)
    try:
        yield from range(10)
    except:
        a = 1
    assert(True)

# Generated at 2022-06-12 04:25:34.601771
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer("target") == ("target")

# Generated at 2022-06-12 04:25:35.419052
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:25:36.986127
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()


# Generated at 2022-06-12 04:25:37.857006
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    mt = YieldFromTransformer()
    assert mt

# Generated at 2022-06-12 04:25:39.348936
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from pytailor.transpilers.yield_from import YieldFromTransformer
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:25:40.508816
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class A(YieldFromTransformer):
        pass

    A()

# Generated at 2022-06-12 04:25:41.706521
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer is not None


# Generated at 2022-06-12 04:25:42.853568
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert (YieldFromTransformer(None, None) is not None)

# Generated at 2022-06-12 04:25:52.614287
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None, None).tree_changed is False
    assert YieldFromTransformer(None, None).inplace is False
    assert isinstance(YieldFromTransformer(None, None).variables_generator,
                      VariablesGenerator)

# Generated at 2022-06-12 04:25:53.949214
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node_transformer = YieldFromTransformer()


# Generated at 2022-06-12 04:25:54.806817
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    x = YieldFromTransformer()

# Generated at 2022-06-12 04:25:56.845995
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = """
    def foo():
        yield from bar()
    """
    module = ast.parse(code)
    YieldFromTransformer().visit(module)
    print(ast.unparse(module))



# Generated at 2022-06-12 04:26:00.903770
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    """Unit test of YieldFromTransformer constructor. It verifies the
    correct type of the transformer by raising an exception when the
    constructor arguments are incorrect."""
    try:
        transformer = YieldFromTransformer(1, 2, 3)
    except TypeError:
        print("Type Error exception was raised as expected")
    except:
        raise AssertionError("Wrong exception was raised")
    else:
        raise AssertionError("Exception was not raised")


# Generated at 2022-06-12 04:26:02.077874
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    node = YieldFromTransformer([])
    assert node is not None

# Generated at 2022-06-12 04:26:06.766892
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with pytest.raises(TypeError) as excinfo:
        YieldFromTransformer(3.3)

    assert str(excinfo.value) == "__init__() should be called with bytecode"


# Generated at 2022-06-12 04:26:08.540168
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..driver import compile_string
    from ..checks import EvaluateTypes
    from ..transforms.yield_from import YieldFromTransformer


# Generated at 2022-06-12 04:26:15.293371
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer().visit(ast.Try(body = [], orelse = [],
    handlers = [], finalbody = [], name = None)) is not None
    assert YieldFromTransformer().visit(ast.If(test = [], body = [], orelse = [], name = None)) is not None
    assert YieldFromTransformer().visit(ast.While(test = [], body = [], orelse = [], name = None)) is not None
    assert YieldFromTransformer().visit(ast.For(target = [], iter = [], body = [], orelse = [], name = None)) is not None

# Generated at 2022-06-12 04:26:17.021403
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Check that object of class YieldFromTransformer will be created
    YieldFromTransformer()

# Generated at 2022-06-12 04:26:32.310731
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(YieldFromTransformer, BaseNodeTransformer)
    assert YieldFromTransformer.__name__ == 'YieldFromTransformer'
    assert YieldFromTransformer.__doc__ == """Compiles yield from to special while statement."""
    assert YieldFromTransformer.target == (3, 2)


# Generated at 2022-06-12 04:26:42.403857
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    tree = ast.parse("""def f():
    def g():
        yield from (yield from z)
    yield from [yield from g()]
    yield from x
    x = yield from b
    print(yield from p)""", '<test>', 'exec')
    # yield from (yield from z) to yield from z
    t = YieldFromTransformer()
    t.visit(tree)

# Generated at 2022-06-12 04:26:43.464662
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:26:44.535450
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:26:47.212292
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
  from ..utils.source import source_to_unicode
  from .unparse import Unparser
  from .unwrap_asserts import UnwrapAsserts
  from .compile import Compiler


# Generated at 2022-06-12 04:26:48.156284
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:26:59.502989
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():

    from ..utils.source import source_to_ast


# Generated at 2022-06-12 04:27:05.575084
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert hasattr(YieldFromTransformer, 'target')
    assert hasattr(YieldFromTransformer, '_get_yield_from_index')
    assert hasattr(YieldFromTransformer, '_emulate_yield_from')
    assert hasattr(YieldFromTransformer, '_handle_assignments')
    assert hasattr(YieldFromTransformer, '_handle_expressions')
    assert hasattr(YieldFromTransformer, 'visit')


# Generated at 2022-06-12 04:27:13.983033
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .transformer import Transformer

    transformer = Transformer()
    # emulate yield from
    def emulate_yield_from(generator, exc, assignment):
        # iterable = iter(generator)
        # while True:
        #     try:
        #         yield next(iterable)
        #     except StopIteration as exc:
        #         assignment
        #         break
        pass

    # result_assignment
    def result_assignment(exc, target):
        # if hasattr(exc, 'value'):
        #     target = exc.value
        pass

    assert transformer

# Generated at 2022-06-12 04:27:24.208695
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from .fixtures import example1, simple_yield_from, simple_yield_from_no_target, multiple_yield_from_in_block, nested_yield_from
    from .fixtures import simple_yield_from_in_function, simple_yield_from_in_if, simple_yield_from_in_for
    import astor

    print("Testing YieldFromTransformer...")

    # example1
    tree = ast.parse(example1)
    YieldFromTransformer().visit(tree)
    astor.dump(tree)

    # simple_yield_from
    print("Simple yield from...")
    tree = ast.parse(simple_yield_from)
    YieldFromTransformer().visit(tree)
    astor.dump(tree)

    # simple_y

# Generated at 2022-06-12 04:27:46.342618
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_astunparse import dump
    from ..transformers import get_transformer_list

    transformer_list = get_transformer_list([YieldFromTransformer])
    source = """
        import typing
        def f():
            yield from (1 for i in range(2))
            a = yield from (1 for i in range(2))
        """


# Generated at 2022-06-12 04:27:56.364618
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.fake_ast import FakeAst
    from ..utils.node import fake_node
    source = """
        def func(gen):
            a = list()
            a = yield from gen
            yield from b
            c
            yield from d
            return a
    """

# Generated at 2022-06-12 04:28:02.089548
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    module = ast.parse("def f():\n    a = yield from b")
    tree = YieldFromTransformer().visit(module)
    assert dump_ast(tree) == """
    def f():
        let(iterable)
        iterable = iter(b)
        while True:
            try:
                yield next(iterable)
            except StopIteration as exc:
                if hasattr(exc, 'value'):
                    a = exc.value
                break
    """

# Generated at 2022-06-12 04:28:03.416215
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    transformer = YieldFromTransformer()
    assert transformer

# Generated at 2022-06-12 04:28:04.249867
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:28:13.576062
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import_node = ast.parse("from typing import List")
    expr_node1 = ast.parse("x = List[int]")
    expr_node2 = ast.parse("x = List[str]")
    body_node = ast.parse("x = [1,2,'3'].append(x)")
    fdef_node = ast.parse("def f(x: int):\n    x = List[str]\n    x = [1,2,'3'].append(x)")
    if_node = ast.parse("if True:\n    x = List[str]\n    x = [1,2,'3'].append(x)")
    while_node = ast.parse("while True:\n    x = List[str]\n    x = [1,2,'3'].append(x)")


# Generated at 2022-06-12 04:28:14.383739
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    YieldFromTransformer()


# Generated at 2022-06-12 04:28:22.542792
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    from ast_helpers import parse
    p = parse('a = yield from f()')
    print(astor.to_source(p))
    q = YieldFromTransformer().visit(p)
    print(astor.to_source(q))
    assert astor.to_source(q) == ("""a = (lambda exc, target: target if hasattr(exc, "value") else None)(exc=exc, target=target)
exc = VariablesGenerator.generate("exc")
iterable = iter(f())
while True:
    try:
        next(iterable)
    except StopIteration as exc:
        (lambda exc, target: target if hasattr(exc, "value") else None)(exc=exc, target=target)
        break""")

# Generated at 2022-06-12 04:28:31.324349
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Unit test for first constructor
    def test_1():
        # Test if a line is compiled to required content
        def test_1():
            node = ast.parse(
                'yield from a')
            YieldFromTransformer().visit(node)

# Generated at 2022-06-12 04:28:36.271549
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    try:
        from ..utils.helpers import get_ast  # type: ignore
    except SyntaxError:
        return True
    str_yield_from = """
    def func():
        a = (i for i in range(10))
        b = yield from a
        yield b
    """
    tree = get_ast(str_yield_from)
    transformer = YieldFromTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True

# Generated at 2022-06-12 04:29:08.145646
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer(None)
    try:
        assert YieldFromTransformer(None, dict(allow_non_python_dialect=True))
    except TypeError:
        pass

# Generated at 2022-06-12 04:29:09.651918
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    class Test(YieldFromTransformer): pass
    assert Test() is not None


# Generated at 2022-06-12 04:29:13.483080
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # for unit testing
    code = """
l = []
for x in l:
    yield from x
    """
    node = ast.parse(code)
    node = YieldFromTransformer().visit(node)
    print(ast.dump(node))


if __name__ == '__main__':
    test_YieldFromTransformer()

# Generated at 2022-06-12 04:29:15.457614
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    with Transformer() as transformer:
        @transformer
        def _(tree):
            yield tree
    assert transformer.has_transformers() == True

# Generated at 2022-06-12 04:29:17.287425
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    "Unit test for constructor of class YieldFromTransformer"
    assert repr(YieldFromTransformer) == "<YieldFromTransformer>"

# Generated at 2022-06-12 04:29:19.883202
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    p = YieldFromTransformer()
    assert isinstance(p, BaseNodeTransformer)

# Unit tests for method _get_yield_from_index of class YieldFromTransformer

# Generated at 2022-06-12 04:29:29.497993
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    code = '''
        def foo():
            yield from [1, 2, 3]
            a = yield from [1, 2, 3]
            yield from [1, 2, 3]
    '''

# Generated at 2022-06-12 04:29:30.511022
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer()

# Generated at 2022-06-12 04:29:38.298210
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..main import transform
    from .test_base import BaseTest
    from tokenize import tokenize, untokenize
    from io import BytesIO
    
    class Test(BaseTest):
    
        @property
        def target(self):
            return YieldFromTransformer
    
    code = "yield from some_generator()"
    transformed_code = "for x in some_generator(): yield x"
    
    code = Test.string_to_tokens(code)
    transformed_code = Test.string_to_tokens(transformed_code)
    
    transform(code, [YieldFromTransformer])
    
    class Dummy:
        encoding = 'utf-8'
    my_file = BytesIO()

# Generated at 2022-06-12 04:29:42.174970
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    assert YieldFromTransformer


if __name__ == '__main__':
    from inspect import signature
    from ..utils.functions import print_object_methods

    print_object_methods(YieldFromTransformer, 'YieldFromTransformer',
                         exclude_names=['visit'])
    print(signature(YieldFromTransformer.visit))

# Generated at 2022-06-12 04:30:53.136855
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    # Construct instance
    YieldFromTransformer()

# Generated at 2022-06-12 04:31:02.510193
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    import astor
    # Instantiate class YieldFromTransformer to use it for for_loop rewrite
    # pylint: disable=no-member
    node_rewrite = YieldFromTransformer(target=(3, 2), debug=True)
    # pylint: disable=no-member
    # pylint: disable=protected-access
    # pylint: disable=unused-argument
    # pylint: disable=function-redefined
    def test(self, node, _check_body=None):
        if isinstance(node, ast.FunctionDef):
            return node_rewrite._handle_function_def(node)
        elif isinstance(node, ast.ClassDef):
            return node_rewrite._handle_class_def(node)
        elif isinstance(node, ast.Module):
            return

# Generated at 2022-06-12 04:31:03.947632
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..main import transform
    from ..parser import parse_module


# Generated at 2022-06-12 04:31:04.724170
# Unit test for constructor of class YieldFromTransformer

# Generated at 2022-06-12 04:31:05.767253
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    t = YieldFromTransformer()
    assert t


# Generated at 2022-06-12 04:31:07.746615
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.test_utils import generate_code

# Generated at 2022-06-12 04:31:09.019551
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    f = YieldFromTransformer()
    assert f is not None


# Generated at 2022-06-12 04:31:14.311032
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from ..utils.testutils import assert_equiv_src
    code = "yield from some_expression"

    node = ast.parse(code)
    YieldFromTransformer().visit(node)
    result = "exc = None\n" \
             "iterable = iter(some_expression)\n" \
             "while True:\n" \
             "    try:\n" \
             "        yield next(iterable)\n" \
             "    except StopIteration as exc:\n" \
             "        break\n"

    assert_equiv_src(node, result)

# Generated at 2022-06-12 04:31:20.765838
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    ass = ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())],
                     value=ast.YieldFrom(value=ast.Call(func=ast.Name(id='foo', ctx=ast.Load()),
                                                        args=[],
                                                        keywargs=[])))
    tr = YieldFromTransformer()
    assert ass.value.value.func.id == 'foo'
    tr.visit(ass)
    assert ass.value.value.id == 'iter'
    assert ass.value.value.args[0].func.id == 'foo'



# Generated at 2022-06-12 04:31:24.422132
# Unit test for constructor of class YieldFromTransformer
def test_YieldFromTransformer():
    from typed_ast import parse
    import inspect
    source = inspect.getsource(YieldFromTransformer)
    module = parse(source)
    with open("transformer/test_YieldFromTransformer.py", "w") as f:
        # f.write("# AUTOGENERATED CODE BY YieldFromTransformer.py\n")
        f.write(module.code)
