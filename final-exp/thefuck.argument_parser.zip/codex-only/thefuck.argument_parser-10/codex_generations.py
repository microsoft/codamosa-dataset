

# Generated at 2022-06-24 04:59:56.629072
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-24 05:00:07.884664
# Unit test for method parse of class Parser
def test_Parser_parse():
    # prepare parser
    parser = Parser()
    # given
    argv = ['thefuck', 'command', ARGUMENT_PLACEHOLDER, '-r']
    # prepare arguments
    arguments = parser._prepare_arguments(argv[1:])
    # when
    args = parser._parser.parse_args(arguments)
    # then
    assert args.repeat == True
    # given
    argv = ['thefuck', ARGUMENT_PLACEHOLDER, 'command', '-r']
    # prepare arguments
    arguments = parser._prepare_arguments(argv[1:])
    # when
    args = parser._parser.parse_args(arguments)
    # then
    assert args.repeat == True


# Generated at 2022-06-24 05:00:08.889150
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-24 05:00:16.565270
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck', 'ls', '-la']) == argparse.Namespace(a=None, alias=None, command=['ls', '-la'], d=False, debug=False, enable_experimental_instant_mode=False, force_command=None, h=False, help=False, l=None, repeat=False, r=False, shell_logger=None, v=False, version=False, y=False, yeah=False, yes=False)

# Generated at 2022-06-24 05:00:18.574943
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser_test = Parser()
    Parser_test.print_usage()

# Generated at 2022-06-24 05:00:29.075065
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    string = StringIO()
    sys.stderr = string
    parser.print_help()
    string.seek(0)

# Generated at 2022-06-24 05:00:36.140943
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Setup
    argv = ['thefuck', '-d', 'ssh', '-p', '1234', 'ARGUMENT_PLACEHOLDER', '-d']
    parser = Parser()
    # Exercise
    args = parser.parse(argv)
    # Verify
    expectedArgs = parser.parse(['thefuck', '-d', '--', 'ssh', '-p', '1234', '-d'])
    assert args == expectedArgs


# Generated at 2022-06-24 05:00:38.470172
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:00:39.407265
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:00:40.199757
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:00:45.915475
# Unit test for method parse of class Parser
def test_Parser_parse():
	# Test case 1: No placeholder
	argv = ['thefuck', 'ls', '-l']
	parsed_arguments = Parser().parse(argv)
	expected = Namespace(alias=None, debug=False, force_command=None, help=False, repeat=False,
		shell_logger=None, version=False, yes=False, command=['ls', '-l'])
	assert parsed_arguments == expected

	# Test case 2: Empty placeholder
	argv = ['thefuck', 'ls', '-l', '--']
	parsed_arguments = Parser().parse(argv)

# Generated at 2022-06-24 05:00:49.016358
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert hasattr(parser, '_parser')
    assert isinstance(parser._parser, ArgumentParser)
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-24 05:00:50.976184
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser._parser.prog = 'thefuck'
    parser.print_usage()


# Generated at 2022-06-24 05:00:55.041585
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        parser.print_usage()
    finally:
        sys.stderr = stderr
    assert sys.stderr.getvalue().startswith('usage:')


# Generated at 2022-06-24 05:00:57.317149
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-24 05:00:58.863489
# Unit test for constructor of class Parser
def test_Parser():
    """
    test to check if parser initializes.
    """
    p = Parser()
    # assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False

# Generated at 2022-06-24 05:01:02.158459
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == None

# Generated at 2022-06-24 05:01:03.828857
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)

    return parser



# Generated at 2022-06-24 05:01:11.558945
# Unit test for constructor of class Parser
def test_Parser():
    import os
    import subprocess
    from .utils import get_alias
    from .const import SHELL_LOGGER_PATH, ARGUMENT_PLACEHOLDER
    from .settings import load_settings
    from .settings import configured_alias_name, configured_repeat_times, configured_repeat_command, default_settings
    from .settings import configured_slow_commands, configured_require_confirmation

    # load settings
    load_settings(default_settings)

    # create class Parser
    parser = Parser()
    # noinspection PyUnusedLocal

# Generated at 2022-06-24 05:01:22.532344
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    test_out = StringIO()
    help_str = parser.print_usage()
    help_str = parser.print_help()
    test_out.close()

    expected_out = StringIO()
    print('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger]', file=expected_out)
    print('                [--enable-experimental-instant-mode] [-y] [-r] [-d]', file=expected_out)
    print('                [--force-command FORCE_COMMAND]', file=expected_out)
    print('                [command [command ...]]', file=expected_out)
    print('\noptional arguments:', file=expected_out)

# Generated at 2022-06-24 05:01:28.775120
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[0].dest == 'yes'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[1].dest == 'repeat'
    assert parser._parser._actions[5].dest == 'debug'

# Generated at 2022-06-24 05:01:31.992381
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-24 05:01:39.206376
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import wrap_streams
    from .runner import Runner
    from .parser import Parser
    with wrap_streams([]) as (out, err):
        p = Parser()
        p.print_usage()
        p.print_help()
        assert err.getvalue() != ''

# Generated at 2022-06-24 05:01:42.924724
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv = ['thefuck', '-h']
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue().strip() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [command [command ...]]'



# Generated at 2022-06-24 05:01:49.439316
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = 'script -r -d --force-command pwd -- /home/xueyuan'.split()
    parser = Parser()
    args = parser.parse(argv)
    assert args.repeat
    assert args.debug
    assert args.force_command == 'pwd'
    assert args.command == ['/home/xueyuan']

# Generated at 2022-06-24 05:01:55.676487
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    parser = Parser()
    #when parse doesn't have ARGUMENT_PLACEHOLDER
    result = parser.parse(['thefuck', 'sudo', 'ls'])
    assert result.command == ['ls']
    assert result.repeat is False
    assert result.yes is False
    #when parse has ARGUMENT_PLACEHOLDER
    result = parser.parse(['thefuck', 'sudo', 'ls', ARGUMENT_PLACEHOLDER, '-r', '-y'])
    assert result.command == ['sudo', 'ls']
    assert result.repeat is True
    assert result.yes is True


# Generated at 2022-06-24 05:01:58.830849
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    arg_parser = parser.parse(['thefuck', '--help'])
    if arg_parser.help:
        parser.print_help()
        assert True

# Generated at 2022-06-24 05:02:01.680934
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:02:10.698897
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck']) == parser._parser.parse_args([])
    assert parser.parse(['fuck', '-v']) == \
        parser._parser.parse_args(['-v'])
    assert parser.parse(['fuck', 'git', 'status', '-s']) == \
        parser._parser.parse_args(['--', 'git', 'status', '-s'])
    assert parser.parse(['fuck', 'git', 'status', '-s', '-v']) == \
        parser._parser.parse_args(['-v', '--', 'git', 'status', '-s'])
    assert parser.parse(['fuck', 'git', 'status', ARGUMENT_PLACEHOLDER, '-v']) == \
        parser._

# Generated at 2022-06-24 05:02:17.859999
# Unit test for method parse of class Parser
def test_Parser_parse():
    parse = Parser().parse
    assert parse([]) == (
        Namespace(alias=None, command=[], yes=False, repeat=False, debug=False))
    assert parse(['ls']) == (
        Namespace(alias=None, command=['ls'], yes=False, repeat=False, debug=False))
    assert parse(['ls', 'cd', '--', 'ls']) == (
        Namespace(alias=None, command=['ls', 'cd'], yes=False, repeat=False, debug=False))

    assert parse(['-y', 'ls']) == (
        Namespace(alias=None, command=['ls'], yes=True, repeat=False, debug=False))

# Generated at 2022-06-24 05:02:26.001069
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    with open("stderr.txt","w") as f:
        sys.stderr = f
        parser.print_usage()
        f.close()
    with open("stderr.txt","r") as f:
        assert f.read() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y] [-r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n"
        f.close()


# Generated at 2022-06-24 05:02:32.956935
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser()._prepare_arguments(['thefuck', 'pip', 'install', 'django']) == ['--', 'pip', 'install', 'django']
    assert Parser()._prepare_arguments(['thefuck', 'ls', '-alh', '{fuck}', 'ls', '-alh']) == ['ls', '-alh'] + ['--'] + ['ls', '-alh']
    assert Parser()._prepare_arguments(['thefuck', 'ls', '-alh', '{fuck}', '--', 'ls', '-alh']) == ['--', 'ls', '-alh'] + ['--'] + ['ls', '-alh']


# Generated at 2022-06-24 05:02:34.826961
# Unit test for method parse of class Parser
def test_Parser_parse():
    test_args = ['/home/yvyx/thefuck', 'echo', 'fuck']
    parser = Parser()
    parser.parse(test_args)

# Generated at 2022-06-24 05:02:36.761067
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:02:38.491936
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.format_help().count('argument') == 24

# Generated at 2022-06-24 05:02:42.127487
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # Check if parser.print_help() prints below as expected

# Generated at 2022-06-24 05:02:45.146527
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None

# Generated at 2022-06-24 05:02:46.550556
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None

# Generated at 2022-06-24 05:02:47.589577
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser().__class__.__name__ == "Parser"


# Generated at 2022-06-24 05:02:48.894841
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:02:58.342309
# Unit test for method parse of class Parser
def test_Parser_parse():
    test = Parser()
    assert test.parse(['', '-v']) == self._parser.parse_args(['-v'])
    assert test.parse(['', '-a', 'alias']) == self._parser.parse_args(['-a', 'alias'])
    assert test.parse(['', '-l', 'shell-logger']) == self._parser.parse_args(['-l', 'shell-logger'])
    assert test.parse(['', '-h']) == self._parser.parse_args(['-h'])
    assert test.parse(['', '-d']) == self._parser.parse_args(['-d'])
    assert test.parse(['', 'command']) == self._parser.parse_args(['command'])

# Generated at 2022-06-24 05:03:01.571702
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Arrange
    p = Parser()

    # Act
    p.print_help()

    # Assert
    assert True



# Generated at 2022-06-24 05:03:06.213190
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', 'ls', '-l']) == p._parser.parse_args(['--', 'ls', '-l'])

# Generated at 2022-06-24 05:03:13.753518
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # with no argument
    assert parser.parse([]) == parser._parser.parse_args([])

    # with --version
    assert parser.parse(['--version']) == parser._parser.parse_args(['--version'])

    # with --alias
    assert parser.parse(['--alias']) == parser._parser.parse_args(['--alias'])

    # with --alias and custom alias name
    assert parser.parse(['--alias', 'fuck']) == parser._parser.parse_args(['--alias', 'fuck'])

    # with --shell-logger
    assert parser.parse(['--shell-logger']) == parser._parser.parse_args(['--shell-logger'])

    # with --shell-logger and shell log file

# Generated at 2022-06-24 05:03:23.823552
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    class _args:
        def __init__(self, alias=None, shell_logger=None, debug=None, force_command=None, command=None):
            self.alias = alias
            self.shell_logger = shell_logger
            self.debug = debug
            self.force_command = force_command
            self.command = command

    argv = ['thefuck', 'git', 'status', '-uall', ARGUMENT_PLACEHOLDER, '--alias', 'fuck', '--shell-logger', '~/log']
    args = _args(alias='fuck', shell_logger='~/log', debug=None, force_command=None, command=['git', 'status', '-uall'])
    assert parser.parse(argv) == args

   

# Generated at 2022-06-24 05:03:32.572342
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    def get_parser_content(parser):
        import io
        f = io.StringIO()
        parser.print_help(f)
        return f.getvalue()

    # The same with
    # thefuck --help
    class Args:
        help = True
        shell_logger = None
        command = None
        debug = None
        alias = None
        force_command = None
        version = None

    parser = Parser()
    assert get_parser_content(parser) == get_parser_content(ArgumentParser(prog='thefuck', add_help=False))
    assert get_parser_content(parser) == get_parser_content(ArgumentParser(prog='fuck', add_help=False))

# Generated at 2022-06-24 05:03:33.304730
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-24 05:03:35.479755
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Unit test for method 'print_usage' of class Parser."""
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:03:42.444779
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .types import Settings

    out = StringIO()
    sys.stderr = out

    # Dummy Settings object with dummy fixers
    Settings(fixers=['test1', 'test2', 'test3'])
    parser = Parser()
    parser.print_usage()
    output = out.getvalue().strip()
    assert 'usage: thefuck' in output
    assert '{} [--version] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [--force-command force-command] [-y | -r] [-h]'.format(ARGUMENT_PLACEHOLDER) in output

# Generated at 2022-06-24 05:03:44.453468
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:03:45.518377
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:03:49.544039
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import io
    from helpers.utils import capture_stdout
    from helpers.utils import capture_stderr
    with capture_stderr() as stderr:
        with capture_stdout():
            parser = Parser()
            parser.print_usage()
            out = stderr.getvalue()
            assert out == parser._parser.format_usage()


# Generated at 2022-06-24 05:03:59.689294
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

# Generated at 2022-06-24 05:04:02.498236
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:04:05.864788
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # testing methods from class ArgumentParser
    parser = ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('bar')
    parser.parse_args('XXX --foo YYY'.split())
    parser.parse_args(['XXX', '--foo'])

# Generated at 2022-06-24 05:04:08.127083
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # create an instance of class Parser
    parser = Parser()
    # capture output to stdout
    pytest.raises(SystemExit, parser.print_help)


# Generated at 2022-06-24 05:04:13.804860
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['--help']) == parser.parse(['--help'])
    assert parser.parse(['--force-command', 'git commit -m "msg"']) == parser.parse(['--force-command', 'git commit -m "msg"'])
    assert parser.parse(['git', 'commit', '-m', 'msg']) == parser.parse(['git', 'commit', '-m', 'msg'])
    assert parser.parse(['--force-command', 'git commit -m "msg"', 'git', 'add', '-A', 'file.txt']) == parser.parse(['--force-command', 'git commit -m "msg"', 'git', 'add', '-A', 'file.txt'])


# Generated at 2022-06-24 05:04:15.744478
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-24 05:04:16.795395
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:17.725150
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:18.520829
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-24 05:04:28.030758
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # we should compare object attributes, not object instances
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert len(parser._parser._actions) == 9

    assert [act.option_strings for act in parser._parser._actions] == \
           [['-v', '--version'],
            ['-a', '--alias'],
            ['-l', '--shell-logger'],
            ['--enable-experimental-instant-mode'],
            ['-h', '--help'],
            ['-y', '--yes', '--yeah', '--hard'],
            ['-r', '--repeat'],
            ['-d', '--debug'],
            ['--force-command'],
            ['command']]


# Generated at 2022-06-24 05:04:33.530087
# Unit test for constructor of class Parser
def test_Parser():
    key_arguments_count = 6
    p = Parser()
    assert len(p._parser._actions) == key_arguments_count
    print('Passed unit test for constructor of class Parser!')



# Generated at 2022-06-24 05:04:34.306678
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    a = Parser()
    a.print_help()

# Generated at 2022-06-24 05:04:35.333657
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-24 05:04:45.491187
# Unit test for method print_help of class Parser
def test_Parser_print_help():
        import os
        import sys
        from io import StringIO
        from contextlib import contextmanager

        @contextmanager
        def captured_output():
            new_out, new_err = StringIO(), StringIO()
            old_out, old_err = sys.stdout, sys.stderr
            try:
                sys.stdout, sys.stderr = new_out, new_err
                yield sys.stdout, sys.stderr
            finally:
                sys.stdout, sys.stderr = old_out, old_err

        parser = Parser()
        with captured_output() as (out, err):
            parser.print_help()
        output = out.getvalue().strip()

# Generated at 2022-06-24 05:04:55.580505
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    sys.stderr.write('\n')
    parser.print_help()
    output = sys.stderr.getvalue()

# Generated at 2022-06-24 05:04:58.463071
# Unit test for constructor of class Parser
def test_Parser():
    class ParserForUT(Parser):
        pass
    parser = ParserForUT()
    assert parser._parser.description == None
    assert parser._parser.usage == None
    assert not parser._parser.add_help
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-24 05:05:04.144025
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    import io
    import unittest
    from contextlib import redirect_stdout

    # set up the test
    tmpIO = io.StringIO()
    with redirect_stdout(tmpIO):
        parser = Parser()
        parser.print_help()

    # do the test
    the_result = tmpIO.getvalue()
    # print(the_result)

# Generated at 2022-06-24 05:05:10.576501
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    #Arrange
    parser = Parser()
    #Act
    parser.print_usage()
    #Assert
    assert sys.stderr.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n"

# Generated at 2022-06-24 05:05:18.315494
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from contextlib import contextmanager
    @contextmanager
    def capture_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with capture_output() as (out, err):
        Parser().print_usage()
        assert 'usage: thefuck' in err.getvalue()


# Generated at 2022-06-24 05:05:26.069194
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert '-v' in parser._parser.format_help()
    assert '-a' in parser._parser.format_help()
    assert '--alias' in parser._parser.format_help()
    assert '-l' in parser._parser.format_help()
    assert '--shell-logger' in parser._parser.format_help()
    assert '--enable-experimental-instant-mode' in parser._parser.format_help()
    assert '-h' in parser._parser.format_help()
    assert '--help' in parser._parser.format_help()
    assert '-y' in parser._parser.format_help()
    assert '--yes' in parser._parser.format_help()
    assert '--hard' in parser._parser.format_help()

# Generated at 2022-06-24 05:05:31.714629
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from .const import USAGE
    from .utils import get_alias

    out = StringIO()

    parser = Parser()
    parser.parse([get_alias()])
    parser.print_usage(file=out)
    assert out.getvalue().startswith(USAGE)



# Generated at 2022-06-24 05:05:37.466613
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'sudo', ARGUMENT_PLACEHOLDER, '-a']) ==\
           parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-a', 'sudo'])
    assert parser.parse(['thefuck', 'sudo', ARGUMENT_PLACEHOLDER, '-a']) ==\
           parser.parse(['thefuck', '-a', 'sudo'])

# Generated at 2022-06-24 05:05:39.031335
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert type(parser.print_help())==None

# Generated at 2022-06-24 05:05:41.736854
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from contextlib import redirect_stdout
    output = StringIO()
    with redirect_stdout(output):
        # Unit test for method print_usage of class Parser
        Parser().print_usage()
    assert output.getvalue().startswith('usage: thefuck')


# Generated at 2022-06-24 05:05:44.171838
# Unit test for constructor of class Parser
def test_Parser():
    assert hasattr(Parser(), '_add_arguments')
    assert hasattr(Parser(), '_add_conflicting_arguments')
    assert hasattr(Parser(), '_prepare_arguments')


# Generated at 2022-06-24 05:05:50.311044
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import os
    import contextlib

    """
    Function to test print_usage method of class parser
    """
    #Arrange
    p = Parser()
    #Act
    with contextlib.redirect_stdout(sys.stderr):
        p.print_usage()
    sys.stderr.flush()
    #Assert
    assert os.stat(sys.stderr.fileno()).st_size > 0


# Generated at 2022-06-24 05:05:52.887596
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser._parser.prog == 'thefuck')
    assert(parser._parser.add_help == False)

# Generated at 2022-06-24 05:05:54.275049
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None

# Generated at 2022-06-24 05:06:03.890555
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    test_args = ["-v"]
    assert parser.parse(test_args).version == True

    test_args = ["-a"]
    assert parser.parse(test_args).alias == get_alias()

    test_args = ["--shell-logger", "test.log"]
    assert parser.parse(test_args).shell_logger == "test.log"

    test_args = ["--enable-experimental-instant-mode"]
    assert parser.parse(test_args).enable_experimental_instant_mode == True

    test_args = ["-h"]
    assert parser.parse(test_args).help == True

    test_args = ["-r"]
    assert parser.parse(test_args).repeat == True

    test_args = ["--repeat"]

# Generated at 2022-06-24 05:06:05.667158
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import find_app, get_all_executables_in_path
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-24 05:06:07.544862
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    help = "show this help message and exit"
    parser = Parser()
    import StringIO
    output = StringIO.StringIO()
    parser.print_help(output)
    output.seek(0)
    assert help in output.read()

# Generated at 2022-06-24 05:06:10.858674
# Unit test for method parse of class Parser
def test_Parser_parse():
    if '-v' in sys.argv:
        assert Parser().parse([''])
    else:
        assert Parser().parse(['', '-y'])


# Generated at 2022-06-24 05:06:12.617545
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None

# Generated at 2022-06-24 05:06:14.771595
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.description == 'Python command line fuckup library.'
    assert Parser()._parser.prog == 'thefuck'
    Parser()._parser.add_argument()
    assert isinstance(Parser()._parser, ArgumentParser)
    assert not issubclass(ArgumentParser, Parser)

# Generated at 2022-06-24 05:06:17.283867
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Test for valid case
    p = Parser()
    assert 'usage: thefuck' in p.print_usage()

# Generated at 2022-06-24 05:06:21.292398
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert ["def"] == p.parse(["--force-command", "def"]).command
    assert ["def"] == p.parse(["def"]).command
    assert ["def", "ghi"] == p.parse(["def", "ghi"]).command


# Generated at 2022-06-24 05:06:29.943582
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Put stderr to a buffer, and print diferent args, and test if the
    expected output is printed

    """
    args_list = [['-h'], ['-y']]
    expected_output = ['usage: thefuck [-h] [-v] [-a [custom-alias-name]] '
                       '-l SHELL_LOGGER -y -d --force-command '
                       '--enable-experimental-instant-mode command ...',
                       'usage: thefuck [-h] [-v] [-a [custom-alias-name]] '
                       '-l SHELL_LOGGER -r -d --force-command '
                       '--enable-experimental-instant-mode command ...']
    # Use multiple assert statements inside a loop
    # pylint: disable=too-many-nested-blocks

# Generated at 2022-06-24 05:06:34.556129
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    try:
        Parser().print_usage()
    finally:
        printed = sys.stderr.getvalue()
        sys.stderr.close()
        sys.stderr = old_stderr
    assert re.search(r'usage: thefuck', printed)


# Generated at 2022-06-24 05:06:35.089688
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:06:36.275590
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-24 05:06:44.110544
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    # used for tests
    import sys
    # Just for tests
    class FakeFile(object):
        def __init__(self):
            self.written_lines = []

        def write(self, line):
            self.written_lines.append(line)

    old_stderr = sys.stderr
    fake_stderr = sys.stderr = FakeFile()

    # lets run method
    parser.print_help()


# Generated at 2022-06-24 05:06:55.955240
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['script_name','the','fuck','thefuck','ls','ra'])
    assert args.command == ['the','fuck','thefuck','ls','ra']
    assert args.force_command == None
    assert args.debug == False
    assert args.repeat == False
    assert args.yes == False

    args = parser.parse(['script_name','-d','--force-command','ls','ra'])
    assert args.command == ['ls','ra']
    assert args.force_command == 'ls'
    assert args.debug == True
    assert args.repeat == False
    assert args.yes == False

    args = parser.parse(['script_name','-d','--force-command','rm','ra'])
    assert args.command == ['rm','ra']

# Generated at 2022-06-24 05:06:57.355452
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-24 05:07:03.377605
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """ Unit test for method print_help of class Parser """
    try:
        Parser().print_help()
    except Exception as e:
        print("Unit test for method print_help of class Parser failed")
        print(e)
        raise

# Generated at 2022-06-24 05:07:07.981807
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == 'Usage: thefuck [--version] [--help] [--alias [custom-alias-name]] [-l] [-d] [-y/-r] [--force-command] [--] [command [command ...]]\n'


# Generated at 2022-06-24 05:07:08.996539
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-24 05:07:11.249502
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None
    assert len(vars(parser)) == 2

# Generated at 2022-06-24 05:07:13.846378
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:07:23.918938
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._actions[5].dest == 'yes'
    assert parser._parser._actions[6].dest == 'repeat'
    assert parser._parser._actions[7].dest == 'debug'
    assert parser._parser._actions[8].dest == 'force_command'
    assert parser._parser._actions[9].dest == 'command'


# Generated at 2022-06-24 05:07:30.154322
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False
    assert p._parser._subparsers._parser_class.__name__ == '_ArgumentGroup'
    assert p._parser._subparsers.title == 'optional arguments'


# Generated at 2022-06-24 05:07:31.456081
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:07:35.191544
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'git', 'log', '--graph', '--oneline']
    args = parser.parse(argv)
    assert args.command == ['git', 'log', '--graph', '--oneline']



# Generated at 2022-06-24 05:07:38.438092
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER]) == \
        parser.parse(['thefuck'])


# Generated at 2022-06-24 05:07:43.489698
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest.mock import patch
    parser = Parser()

    with patch('sys.stderr') as mocked_stderr:
        parser.print_usage()
        mocked_stderr.write.assert_called_with(
            parser._parser.format_usage().splitlines()[0] + '\n')


# Generated at 2022-06-24 05:07:45.400388
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage == parser._parser.print_usage


# Generated at 2022-06-24 05:07:53.473281
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    output = StringIO()
    sys.stderr = output
    p = Parser()
    p.print_usage()
    output.seek(0)
    assert output.readlines() == ['usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n', '                [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n', '                [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n', '\n']


# Generated at 2022-06-24 05:07:55.539218
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert parser
    assert parser._parser

# Generated at 2022-06-24 05:07:58.577173
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.parse(['shit', '-l', 'log'])

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-24 05:07:59.490767
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:08:00.149573
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-24 05:08:07.906612
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    sys.argv = ['thefuck', '--shell-logger', 'log.txt', 'python', '--help', '&;', 'git']
    assert parser.parse(sys.argv).command == ['--help', '&;', 'git'], 'It should return right command'
    assert parser.parse(sys.argv).shell_logger == 'log.txt', 'It should return right logger file name'
    sys.argv = ['thefuck', '--shell-logger', 'log.txt', 'python', '--help']
    assert parser.parse(sys.argv).command == ['--help'], 'It should return right command'
    sys.argv = ['thefuck', '--shell-logger', 'log.txt', 'python']

# Generated at 2022-06-24 05:08:13.989180
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import io
    parser = Parser()
    old_err = sys.stderr

    try:
        out = io.StringIO()
        sys.stderr = out

        parser.print_usage()
        output = out.getvalue().strip()
        assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--] [command ...]'
    finally:
        sys.stderr = old_err



# Generated at 2022-06-24 05:08:23.592787
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
        parser._parser.parse_args(['-l'])
    assert parser.parse(['thefuck', '--', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
        parser._parser.parse_args(['--', '-l'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '--', '-l']) == \
        parser._parser.parse_args(['--', '-l'])

# Generated at 2022-06-24 05:08:35.618141
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['./thefuck', '-v']) == Namespace(debug=False,
                                                         help=False,
                                                         repeat=False,
                                                         shell_logger=None,
                                                         command=[],
                                                         alias=None,
                                                         yes=False,
                                                         version=True,
                                                         force_command=None,
                                                         enable_experimental_instant_mode=False)

# Generated at 2022-06-24 05:08:37.621661
# Unit test for constructor of class Parser
def test_Parser():
    # pylint: disable=C0103
    parser = Parser()
    assert parser
    assert parser._parser



# Generated at 2022-06-24 05:08:38.434110
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-24 05:08:44.054855
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls'])
    assert args.command == ['ls']
    assert args.debug is False
    assert args.enable_experimental_instant_mode is False
    assert args.force_command is None
    assert args.help is False
    assert args.shell_logger is None
    assert args.yes is False
    assert args.repeat is False


# Generated at 2022-06-24 05:08:45.472897
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv = ['thefuck']
    parser = Parser()
    with open('tests/output/argparser_print_usage.txt', 'r') as output:
        assert parser.print_usage() == output.read()



# Generated at 2022-06-24 05:08:52.511420
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import captured_stderr
    with captured_stderr() as stderr:
        Parser().print_usage()
    assert (stderr.getvalue().split('\n')[1] ==
            'usage: thefuck [-h] [-v] [-a [custom-alias-name]]'
            ' [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] '
            ' [-y | -r] [--force-command FORCE_COMMAND] [--] [command [command ...]]')


# Generated at 2022-06-24 05:09:02.230894
# Unit test for method parse of class Parser
def test_Parser_parse():

    #remove ARGUMENT_PLACEHOLDER and move arguments after it to beginning
    def test_1( argv, expected ):
        parser = Parser()
        parser._prepare_arguments = mock.Mock(return_value=argv)
        args = parser.parse(expected)
        assert all(getattr(args, x, '') == getattr(expected, x, '') for x in args.__dict__)

    test_1(['thefuck', ARGUMENT_PLACEHOLDER], Namespace(command=None))
    test_1(['thefuck', ARGUMENT_PLACEHOLDER, '--yes'], Namespace(command=None, yes=True))

# Generated at 2022-06-24 05:09:05.944764
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert type(Parser().print_usage()) == None


# Generated at 2022-06-24 05:09:07.085597
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    obj = Parser()
    obj.print_help()


# Generated at 2022-06-24 05:09:14.180422
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck', '--', 'some', 'args']) == \
        Namespace(command=['some', 'args'], alias=None, debug=False,
                  enable_experimental_instant_mode=False, force_command=None,
                  help=False, repeat=False, shell_logger=None, version=False,
                  yes=False)
    assert Parser().parse(['thefuck', '--version']) == \
        Namespace(command=None, alias=None, debug=False,
                  enable_experimental_instant_mode=False, force_command=None,
                  help=False, repeat=False, shell_logger=None, version=True,
                  yes=False)

# Generated at 2022-06-24 05:09:22.099610
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import StringIO
    try:
        stdout = sys.stdout
        sys.stdout = StringIO.StringIO()
        parser.print_usage()
        assert sys.stdout.getvalue() == "usage: thefuck [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n" \
                                        "              [--enable-experimental-instant-mode] [-h] [-d] [--force-command FORCE_COMMAND]\n" \
                                        "              [command [command ...]]\n"
    finally:
        sys.stdout = stdout


# Generated at 2022-06-24 05:09:23.258841
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-24 05:09:26.085022
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', '-l', 'matius@Matiuss-MacBook-Air:~$',
            '-v', '--debug', '--shell-logger', '--alias']
    parser = Parser()
    parser.parse(argv)
    assert parser.parse(argv)



# Generated at 2022-06-24 05:09:33.942504
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    
    # Case 1
    arguments = parser._prepare_arguments(['--hard', 'rm', '-f', 'FILE'])
    assert parser._parser.parse_args(arguments) == Namespace(
        debug=False,
        alias=None,
        hard=True,
        help=False,
        yes=None,
        repeat=None,
        shell_logger=None,
        enable_experimental_instant_mode=False,
        force_command=None,
        command=['rm', '-f', 'FILE'])
    
    # Case 2
    arguments = parser._prepare_arguments(['rm', '-f', 'FILE'])

# Generated at 2022-06-24 05:09:42.786017
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    pars = parser.parse(['thefuck', '', '-h', 'echo', 'hello'])
    assert pars.help == True
    assert pars.command == ['echo', 'hello']
    assert pars.force_command == None
    assert pars.debug == False
    assert pars.enable_experimental_instant_mode == False
    assert pars.alias == None
    assert pars.yes == False
    assert pars.repeat == False
    assert pars.shell_logger == None
    pars = parser.parse(['thefuck', '', '-y', 'echo', 'hello'])
    assert pars.help == False
    assert pars.command == ['echo', 'hello']
    assert pars.force_command == None
    assert pars.debug == False
    assert pars.enable_experimental_instant_mode

# Generated at 2022-06-24 05:09:44.596073
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # This code does not raise an exception and does not print anything
    parser.print_usage()



# Generated at 2022-06-24 05:09:53.590087
# Unit test for method parse of class Parser
def test_Parser_parse():
    parse = Parser().parse

    assert parse('fuck'.split()) == parse('fuck --'.split())
    assert parse('fuck'.split()) == parse('fuck -- --'.split())
    assert 'cd' in parse('fuck cd'.split()).command
    assert 'cd' in parse('fuck -- cd'.split()).command
    assert 'cd' in parse('fuck -- -- cd'.split()).command
    assert 'cd' in parse('fuck -- cd --'.split()).command
    assert 'cd' in parse('fuck -- -- cd --'.split()).command
    assert 'cd' in parse('fuck -- -- cd -r'.split()).command
    assert '-r' in parse('fuck -- -- cd -- -r'.split()).command
    assert '-r' in parse('fuck -- -- cd -r --'.split()).command