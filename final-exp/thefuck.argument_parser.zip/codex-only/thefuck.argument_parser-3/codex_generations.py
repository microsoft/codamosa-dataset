

# Generated at 2022-06-24 04:59:57.949104
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help()


if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-24 05:00:00.735254
# Unit test for constructor of class Parser
def test_Parser():

    def _test_constuctor():
        Parser()

    _test_constuctor()

# Generated at 2022-06-24 05:00:02.255272
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-24 05:00:12.285625
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER
    parser = Parser()
    # Test for normal arguments
    assert parser.parse(['thefuck', 'du', '-r']) == parser._parser.parse_args(['-r', 'du'])
    assert parser.parse(['thefuck', 'du', '-r', '-d']) == parser._parser.parse_args(['-r', '-d', 'du'])
    assert parser.parse(['thefuck', 'du', '-d', '-r']) == parser._parser.parse_args(['-r', '-d', 'du'])

# Generated at 2022-06-24 05:00:13.412281
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == ''


# Generated at 2022-06-24 05:00:14.518022
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    assert p.parse(['thefuck']).help



# Generated at 2022-06-24 05:00:15.600521
# Unit test for constructor of class Parser
def test_Parser():
    obj = Parser()
    assert isinstance(obj,Parser)


# Generated at 2022-06-24 05:00:27.540707
# Unit test for constructor of class Parser
def test_Parser():
    from mock import patch
    from thefuck.utils import get_alias
    from thefuck.const import ARGUMENT_PLACEHOLDER

    with patch('thefuck.utils.get_alias') as get_alias:
        get_alias.return_value = "fuck"

        parser = Parser()

        assert hasattr(parser._parser, '_actions')
        assert len(parser._parser._actions) == 13
        assert parser._parser._actions[0].option_strings == ['-v', '--version']

        assert hasattr(parser._parser, '_optionals')
        assert len(parser._parser._optionals._group_actions) == 4

        assert hasattr(parser._parser, '_positionals')
        assert len(parser._parser._positionals._group_actions) == 0


# Generated at 2022-06-24 05:00:28.643298
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-24 05:00:38.357499
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import _io
    sys.stderr.close()
    sys.stderr = _io.StringIO()
    Parser().print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [--version] [--alias ' \
                                    '[custom-alias-name]]\n             ' \
                                    '[--shell-logger shell-logger] [--enable-' \
                                    'experimental-instant-mode] [--help]\n    ' \
                                    '    [-y | --yes | --yeah | --hard] [-r] ' \
                                    '[-d] [--force-command force-command]\n    ' \
                                    '    [command [command ...]]\n'

# Generated at 2022-06-24 05:00:42.958632
# Unit test for constructor of class Parser
def test_Parser():
    # Capture stdout
    temp=sys.stdout
    out=StringIO()
    sys.stdout=out
    # Create a Parser object
    parser = Parser()
    # Release stdout
    sys.stdout = temp
    # Check that stdout is empty
    assert out.getvalue() == ""

# Generated at 2022-06-24 05:00:45.054234
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['thefuck', '--version'])

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-24 05:00:50.766056
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    Unit test for Parser class.

    Parser class is used to parse the command line arguments.
    The instance of Parser class is called from the main
    function in thefuck.py.

    """
    # Arrange
    parser = Parser()
    # Act
    actual = parser.parse(['--help'])
    # Assert
    assert actual.help


# Generated at 2022-06-24 05:00:53.233732
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    arguments = ['thefuck']
    parser = Parser()
    parser.parse(arguments)
    parser.print_usage()
    assert True


# Generated at 2022-06-24 05:00:55.183942
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-24 05:00:57.290420
# Unit test for method parse of class Parser
def test_Parser_parse():
    Parser_instance = Parser()
    Parser_instance.parse([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])


# Generated at 2022-06-24 05:01:05.739491
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].option_strings == ['-l', '--shell-logger']
    assert parser._parser._actions

# Generated at 2022-06-24 05:01:07.898295
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Test print help message"""
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-24 05:01:12.349002
# Unit test for method parse of class Parser
def test_Parser_parse():
   parser = Parser()
   assert parser.parse(['fuck', 'very']) == parser.parse(['fuck', 'very', ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-24 05:01:17.437407
# Unit test for method parse of class Parser
def test_Parser_parse():
    eq_(Parser().parse(['thefuck', 'echo', 'hello', ARGUMENT_PLACEHOLDER, '-h']),
        Namespace(alias=None,
                  command=['--', 'echo', 'hello'],
                  debug=False,
                  enable_experimental_instant_mode=False,
                  force_command=None,
                  help=False,
                  repeat=False,
                  shell_logger=None,
                  version=False,
                  yes=False))

# Generated at 2022-06-24 05:01:25.468411
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['', '']) == parser.parse(['', 'thefuck'])
    assert parser.parse(['', 'thefuck', '-v']) == parser.parse(['', 'thefuck', '--version'])
    assert parser.parse(['', 'thefuck', '-a', 'fuck']) == parser.parse(['', 'thefuck', '--alias', 'fuck'])
    assert parser.parse(['', 'thefuck', '-a']) == parser.parse(['', 'thefuck', '--alias'])
    assert parser.parse(['', 'thefuck']) == parser.parse(['', 'thefuck', '-l'])

# Generated at 2022-06-24 05:01:34.488371
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Test without ARGUMENT_PLACEHOLDER
    assert parser.parse(['thefuck', 'ls']) == \
        parser._parser.parse_args(['--', 'ls'])
    assert parser.parse(['thefuck', '-a']) == \
        parser._parser.parse_args(['-a'])
    assert parser.parse(['thefuck', '-a', 'alias']) == \
        parser._parser.parse_args(['-a', 'alias'])
    assert parser.parse(['thefuck', '-a', '--']) == \
        parser._parser.parse_args(['-a', '--'])
    assert parser.parse(['thefuck', '-a', 'alias', '--']) == \
        parser._parser.parse_args

# Generated at 2022-06-24 05:01:38.375180
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import TestCase
    from .utils import patch, mock

    class TestParser(TestCase):
        def setUp(self):
            super(TestParser, self).setUp()
            self.parser = Parser()

        @patch('thefuck.parser.Parser._parser.print_usage')
        def test_prints_usage(self, print_usage):
            self.parser.print_usage()
            print_usage.assert_called_once_with(sys.stderr)

    test = TestParser()
    test.setUp()
    test.test_prints_usage()

# Generated at 2022-06-24 05:01:39.020576
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:01:40.506576
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()



# Generated at 2022-06-24 05:01:41.679585
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert isinstance(p, Parser)


# Unit test of method parse

# Generated at 2022-06-24 05:01:50.677053
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test case:
    1. Test input argument that have ARGUMENT_PLACEHOLDER
    2. Test input argument that do not have ARGUMENT_PLACEHOLDER
    """
    argv1 = ['--', 'echo', 'hello', ARGUMENT_PLACEHOLDER, '-l']
    argv2 = ['-l', '-a', 'hello']
    parser = Parser()
    output1 = parser.parse(argv1)
    output2 = parser.parse(argv2)
    assert output1.shell_logger == '-l'
    assert output2.alias == 'hello'

# Generated at 2022-06-24 05:01:54.816741
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    out = StringIO()
    sys.stderr = out
    parser = Parser()
    parser.print_help()
    assert out.getvalue() != ""


# Generated at 2022-06-24 05:01:59.129409
# Unit test for method print_help of class Parser
def test_Parser_print_help():

    parser = Parser()
    assert isinstance(parser, Parser)

    # it is hard to check if print_help is called.
    # so call print_usage to make sure print_help gets called.
    parser.print_usage()

# Generated at 2022-06-24 05:02:00.479028
# Unit test for constructor of class Parser
def test_Parser():
  p = Parser()
  assert isinstance(p, Parser)


# Generated at 2022-06-24 05:02:01.790291
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)

# Generated at 2022-06-24 05:02:03.013324
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser)

# Generated at 2022-06-24 05:02:04.037348
# Unit test for method print_help of class Parser
def test_Parser_print_help():
	Parser().print_help()

# Generated at 2022-06-24 05:02:12.017479
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', '--', 'sudo', 'multiline', 'command']) == \
        Namespace(alias=None, command=['multiline', 'command'], debug=False,
                  help=False, repeat=False, shell_logger=None,
                  force_command=None,
                  enable_experimental_instant_mode=False,
                  yes=False, version=False)


# Generated at 2022-06-24 05:02:22.306649
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from unittest.mock import patch


# Generated at 2022-06-24 05:02:31.519776
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser._parser.prog=='thefuck')
    assert(parser._parser.add_help==False)
    assert(parser._parser.description==None)
    assert(parser._parser.epilog==None)
    assert(parser._parser.version==None)
    assert(parser._parser.parent==None)
    assert(parser._parser.formatter_class==argparse.HelpFormatter)
    assert(parser._parser.usage==None)
    assert(parser._parser.add_help_option==True)
    assert(parser._parser.conflict_handler=='error')
    assert(parser._parser.prefix_chars=='-')
    assert(parser._parser.fromfile_prefix_chars==None)
    assert(parser._parser.argument_default==None)

# Generated at 2022-06-24 05:02:33.082325
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert parser

# Generated at 2022-06-24 05:02:40.304760
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck']) == \
        Namespace(alias=None, debug=False, force_command=None, help=False,
                  repeat=False, shell_logger=None,
                  enable_experimental_instant_mode=False,
                  yes=False, command=[])
    assert Parser().parse(['thefuck', 'shell', 'log']) == \
        Namespace(alias=None, debug=False, force_command=None, help=False,
                  repeat=False, shell_logger=None,
                  enable_experimental_instant_mode=False,
                  yes=False, command=['shell', 'log'])

# Generated at 2022-06-24 05:02:49.256938
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    help_text = parser.print_usage()
    assert help_text.find('-v') >= 0
    assert help_text.find('--yes') >= 0
    assert help_text.find('-l') >= 0
    assert help_text.find('--shell-logger') >= 0
    assert help_text.find('-d') >= 0
    assert help_text.find('--debug') >= 0
    assert help_text.find('--force-command') >= 0
    assert help_text.find('--enable-experimental-instant-mode') >= 0
    assert help_text.find('command') >= 0


# Generated at 2022-06-24 05:02:51.825463
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # arrange
    parser = Parser()
    # act
    parser.print_usage()
    # assert
    parser.parse(['--help'])

# Generated at 2022-06-24 05:02:56.118035
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'echo', 'my_cmd', ARGUMENT_PLACEHOLDER, '--debug'])
    assert args.debug is True
    assert args.help is False
    assert args.command == ['echo', 'my_cmd']


# Generated at 2022-06-24 05:02:58.377176
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert args.command == 'ls -l'

# Generated at 2022-06-24 05:03:00.931222
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:03:10.187588
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    conf = dict(
        thefuck=dict(
            debug=False,
            repeat=False,
            wait_command=0,
            require_confirmation=False,
            env=dict(
                LANG='C',
                LC_CTYPE='C',
                LC_ALL='C',
                EDITOR='vim',
                PYTHONPATH='.')))
    out = StringIO()
    sys.stderr = out
    parser = Parser()
    parser.parse(['fuck', '-v'])
    parser.print_usage()
    output = out.getvalue().strip()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:03:11.447756
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:03:18.106866
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    import sys
    parser = Parser()
    sys.stderr = StringIO()
    parser.print_help()
    value = sys.stderr.getvalue()
    assert value
    test_string = 'usage: thefuck [-h] [-v] [-y] [-r]'
    assert test_string in value
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:03:28.288696
# Unit test for method parse of class Parser

# Generated at 2022-06-24 05:03:33.914025
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    for args in [[], ['--help'], ['--alias'], ['-a', 'xxx'], ['-a']]:
        parser = Parser()
        parser.print_help()
        assert sys.stdout.getvalue().startswith('usage: thefuck')


# Generated at 2022-06-24 05:03:42.243927
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    def parsed_args_equal(args, values):
        args = parser.parse(args.split(' '))
        assert args.alias == values['alias']
        assert args.debug == values['debug']
        assert args.force_command == values['force_command']
        assert args.help == values['help']
        assert args.repeat == values['repeat']
        assert args.shell_logger == values['shell_logger']
        assert args.version == values['version']
        assert args.yes == values['yes']
        assert args.command == values['command'].split(' ')


# Generated at 2022-06-24 05:03:45.459390
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert parser.print_help() is not None

# Generated at 2022-06-24 05:03:56.006961
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser = parser.parse(['thefuck', '-v'])
    assert parser.version == True

    parser = parser.parse(['thefuck', '-l'])
    assert parser.shell_logger == True

    parser = parser.parse(['thefuck', '-a'])
    assert parser.alias == True

    parser = parser.parse(['thefuck', '-d'])
    assert parser.debug == True

    parser = parser.parse(['thefuck', '-h'])
    assert parser.help == True

    parser = parser.parse(['thefuck', '--enable-experimental-instant-mode'])
    assert parser.enable_experimental_instant_mode == True

    parser = parser.parse(['thefuck --force-command', 'fuck'])
    assert parser

# Generated at 2022-06-24 05:03:56.553977
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:06.592199
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([]) == parser.parse(['--'])

    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])
    assert parser.parse(['thefuck', '-l', 'log.txt']) == parser.parse(['thefuck', '--shell-logger', 'log.txt'])
    assert parser.parse(['thefuck']) == parser.parse(['thefuck', '--']) == parser.parse(['thefuck'] + [ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-la']) == parser.parse(['thefuck'] + [ARGUMENT_PLACEHOLDER, 'ls', '-la'])

# Generated at 2022-06-24 05:04:07.852703
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-24 05:04:12.665069
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class FakeStream(object):
        def __init__(self):
            self.buffer = []

        def write(self, data):
            self.buffer.append(data)

        def flush(self):
            pass
    fake_stream = FakeStream()
    original_stderr = sys.stderr
    sys.stderr = fake_stream
    Parser().print_usage()
    sys.stderr = original_stderr
    assert "usage: thefuck" in ''.join(fake_stream.buffer)

# Generated at 2022-06-24 05:04:22.124413
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(["", "echo", "hello", ARGUMENT_PLACEHOLDER, "-bzhw"])
    assert result.command == ["echo", "hello"]
    assert result.bzhw == True
    assert result.force_command == None
    result = parser.parse(["", "--force-command", "fuck", "echo", "hello", ARGUMENT_PLACEHOLDER, "-bzhw"])
    assert result.command == ["echo", "hello"]
    assert result.bzhw == True
    assert result.force_command == "fuck"

# Generated at 2022-06-24 05:04:25.137473
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output
    parser = Parser()
    parser.print_help()
    assert 'thefuck' in output.getvalue()



# Generated at 2022-06-24 05:04:26.387941
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-24 05:04:31.157529
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    from io import StringIO
    import sys
    saved_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        parser.print_usage()
        output = out.getvalue().strip()
        assert output.startswith('usage:')
    finally:
        sys.stderr = saved_stderr


# Generated at 2022-06-24 05:04:42.117934
# Unit test for method parse of class Parser

# Generated at 2022-06-24 05:04:44.022272
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_usage()
    # Should not raise errors
    p.print_help()

# Generated at 2022-06-24 05:04:45.725213
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print_usage = Parser().print_usage
    assert print_usage == Parser()._parser.print_usage

# Generated at 2022-06-24 05:04:47.730323
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:54.145431
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['script',
                         '-l', 'log.log']) == parser.parse(['script',
                         '-l', 'log.log', '--', 'git', 'help'])

    assert parser.parse(['script', 'git', 'help']) == parser.parse(['script',
                         '--', 'git', 'help'])

    assert parser.parse(['script',
                         '-d', '-l', 'log.log', 'git', 'help']) == parser.parse(['script',
                         '-d', '-l', 'log.log', '--', 'git', 'help'])


# Generated at 2022-06-24 05:04:55.218619
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_usage()

# Generated at 2022-06-24 05:05:01.583739
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Without ARGUMENT_PLACEHOLDER
    res = parser.parse(['thefuck', 'ssh', 'user@host'])
    assert res.command == ['ssh', 'user@host']

    # With ARGUMENT_PLACEHOLDER
    res = parser.parse(['thefuck', 'ssh', 'user@host', 'hungry', '--', '-l'])
    assert res.command == ['ssh', 'user@host']
    assert res.login == 'hungry'
    assert not res.yes
    assert not res.repeat
    assert not res.debug
    assert not res.help

    res = parser.parse(['thefuck', 'ssh', 'user@host', 'hungry', '--', '-l', '--repeat'])

# Generated at 2022-06-24 05:05:03.529192
# Unit test for constructor of class Parser
def test_Parser():
    """Unit-test for constructor of class Parser"""
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:05:07.832169
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO

    stdout = sys.stdout
    sys.stdout = StringIO()

    parser = Parser()
    parser.print_help()

    sys.stdout = stdout



# Generated at 2022-06-24 05:05:08.654330
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:05:17.856487
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse(['executable', 'git', 'push']) == \
            parser._parser.parse_args(['--', 'git', 'push'])
    assert parser.parse(['executable', 'git', 'push', ARGUMENT_PLACEHOLDER]) == \
            parser._parser.parse_args(['--', 'git', 'push'])
    assert parser.parse(['executable', '-y', 'git', 'push']) == \
            parser._parser.parse_args(['-y', '--', 'git', 'push'])
    assert parser.parse(['executable', '-r', 'git', 'push']) == \
            parser._parser.parse_args(['-r', '--', 'git', 'push'])

# Generated at 2022-06-24 05:05:18.704441
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()



# Generated at 2022-06-24 05:05:19.509404
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:05:21.103546
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == parser._parser.print_usage(sys.stderr)


# Generated at 2022-06-24 05:05:22.127178
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-24 05:05:33.482323
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import re
    parser = Parser()
    # calling method print_usage of class Parser
    parser.print_usage()
    # capturing stdout to string
    out = sys.stdout.getvalue()
    # checking if string matches to pattern

# Generated at 2022-06-24 05:05:35.114255
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ["thefuck", "--debug"]
    parser = Parser()
    assert parser.parse(args).debug == True


# Generated at 2022-06-24 05:05:40.065658
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert(p._parser.prog == 'thefuck')
    assert(p._parser.add_help == False)
    assert(len(p._parser._actions) == 10)

# Generated at 2022-06-24 05:05:41.266085
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:05:42.056557
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-24 05:05:44.483350
# Unit test for constructor of class Parser
def test_Parser():
    """
    Test if the the parser is type(ArgumentParser)
    """
    parser = Parser()
    assert isinstance(parser, Parser)
    assert isinstance(parser._parser, ArgumentParser)

# Generated at 2022-06-24 05:05:48.826915
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sio = io.StringIO()
    backup = sys.stderr
    sys.stderr = sio
    p = Parser()
    p.print_usage()
    sys.stderr = backup
    assert sio.getvalue().startswith('usage: thefuck')


# Generated at 2022-06-24 05:05:51.851837
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
        Testing method print_help of class Parser.
    """

# Generated at 2022-06-24 05:05:56.068689
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    temp = sys.stderr
    sys.stderr = StringIO()
    parser.print_usage()
    sys.stderr.close()
    assert "usage" in sys.stderr.getvalue()
    sys.stderr = temp


# Generated at 2022-06-24 05:05:58.773349
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    arg = argv[1:]
    a = parser.parse(arg)
    print(a)



# Generated at 2022-06-24 05:06:07.712651
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    import sys
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert out.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL-LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE-COMMAND] [--yes | --repeat] [command [command ...]]\n'


# Generated at 2022-06-24 05:06:10.170848
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:06:12.061628
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_text = parser.print_help()
    assert parser.print_help() == None

# Generated at 2022-06-24 05:06:13.848670
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:06:17.154886
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['--debug', '--force-command', 'ls', '--', 'git'])
    assert args.debug == True
    assert args.force_command == 'ls'
    assert args.command == ['git']



# Generated at 2022-06-24 05:06:17.997686
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-24 05:06:27.741373
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck']) == Namespace()

    assert Parser().parse(['thefuck', '-v']) == Namespace(version=True)

    assert Parser().parse(['thefuck', '-l', '~/log.txt']) == Namespace(shell_logger='~/log.txt')

    assert Parser().parse(['thefuck', '-l']) == Namespace(shell_logger=None)

    assert Parser().parse(['thefuck', '--enable-experimental-instant-mode']) == Namespace(enable_experimental_instant_mode=True)

    assert Parser().parse(['thefuck', '-d']) == Namespace(debug=True)

    assert Parser().parse(['thefuck', '--force-command', 'echo hi']) == Names

# Generated at 2022-06-24 05:06:35.821477
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import wrap_streams
    from .const import VERSION
    from .const import VERSION_URL

    # Unit test for the print_help method
    with wrap_streams() as (stdout, stderr):
        parser = Parser()
        parser.print_help()


# Generated at 2022-06-24 05:06:37.637949
# Unit test for constructor of class Parser
def test_Parser():
	parser = Parser()
	assert parser._parser.prog == 'thefuck'
	assert parser._parser.add_help == False


# Generated at 2022-06-24 05:06:44.854348
# Unit test for method parse of class Parser
def test_Parser_parse():

    p = Parser()

    assert ['-r', '--', 'command'] == p.parse(['thefuck', '-r', 'command'])
    assert ['-r', 'command'] == p.parse(['thefuck', '-r', ARGUMENT_PLACEHOLDER, 'command'])
    assert ['-r', 'command'] == p.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-r', 'command'])
    assert ['-r', 'command'] == p.parse(['thefuck', 'command', '-r', ARGUMENT_PLACEHOLDER])
    assert ['-r', 'command'] == p.parse(['thefuck', 'command', ARGUMENT_PLACEHOLDER, '-r'])

# Generated at 2022-06-24 05:06:46.888607
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse([sys.argv[0]])


# Generated at 2022-06-24 05:06:58.105397
# Unit test for method parse of class Parser
def test_Parser_parse():
    # parse(self, argv)
    # - argv: list of command line arguments that needs to be parsed.
    parser = Parser()
    # 1) argv must not contain any arguments.
    args = parser.parse([])
    # argv is empty. It should set alias to None, command to empty list.
    assert args.alias is None
    assert args.command == []
    assert args.debug is False
    assert args.enable_experimental_instant_mode is False
    assert args.force_command is None
    assert args.help is False
    assert args.repeat is False
    assert args.shell_logger is None
    assert args.version is False
    assert args.yes is False
    # 2) argv must contain the argument "--version"
    args = parser.parse(['--version'])
   

# Generated at 2022-06-24 05:06:59.692881
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-la', '.'])
    assert args


# Generated at 2022-06-24 05:07:08.211635
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from contextlib import redirect_stderr
    f = StringIO()
    with redirect_stderr(f):
        Parser().print_usage()
    assert f.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'\
                           '              [-l shell-logger]\n'\
                           '              [--enable-experimental-instant-mode]\n'\
                           '              [-y | -r] [-d] [--force-command FORCE-COMMAND]\n'\
                           '              [command [command ...]]\n'

from contextlib import contextmanager
from unittest.mock import patch
from io import StringIO

from .rules import RulesCollection
from .shells import Shell

# Generated at 2022-06-24 05:07:16.931271
# Unit test for method parse of class Parser
def test_Parser_parse():
    Parser()
    argv_result = Parser().parse(["fuck", "git", "push"])
    assert argv_result.command == ['git', 'push']
    assert Parser().parse(["fuck", "git", "push", "--"]).command == ['git', 'push']
    assert Parser().parse(["fuck", "--alias", "alias", "git", "push"]).alias == ["alias"]
    assert Parser().parse(["fuck", "--alias", "git", "push"]).alias == ['fuck']
    assert Parser().parse(["fuck", "git", "push", "--yes"]).yes is True

# Generated at 2022-06-24 05:07:18.809078
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:07:21.432080
# Unit test for constructor of class Parser
def test_Parser():
    # Init
    parser = Parser()
    # Assert
    assert parser._parser.add_argument
    
#Unit test for _add_arguments of class Parser

# Generated at 2022-06-24 05:07:22.348398
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:07:28.199057
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ["thefuck", "--yes", "fuck"]
    assert parser.parse(argv) == parser._parser.parse_args(argv[1:])



# Generated at 2022-06-24 05:07:37.417197
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert len(p._parser.description) == 0
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help
    assert len(p._parser._positionals._group_actions) == 1
    assert p._parser._positionals._group_actions[0].dest == 'command'
    assert p._parser._positionals._group_actions[0].nargs == '*'
    assert len(p._parser._optionals._group_actions) == 8
    assert(p._parser._optionals._group_actions[0].dest == 'version' and
           p._parser._optionals._group_actions[0].action == 'store_true' and
           p._parser._optionals._group_actions[0].help ==
               "show program's version number and exit")

# Generated at 2022-06-24 05:07:38.718395
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser)

# Generated at 2022-06-24 05:07:47.463849
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-lah', '/']) == parser.parse(['thefuck', 'ls', '-lah', '/']) == parser.parse(['thefuck', 'ls', '/'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-lah', '/']) == parser.parse(['thefuck', 'ls', '/', '-lah'])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-lah', '/']) == parser.parse(['thefuck', 'ls', '-lah', '/'])


# Generated at 2022-06-24 05:07:56.728769
# Unit test for method parse of class Parser

# Generated at 2022-06-24 05:08:00.738113
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    sys.argv = ['thefuck', 'ls', '--la']
    assert( p.parse(sys.argv) == p._parser.parse_args(['--la']) )
    sys.argv = ['thefuck', ARGUMENT_PLACEHOLDER, '--', 'ls', '--la']
    assert( p.parse(sys.argv) == p._parser.parse_args(['--', 'ls', '--la']) )

# Generated at 2022-06-24 05:08:06.650216
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue().strip() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [-d] [-y | -r] [--] [command [command ...]]'


# Generated at 2022-06-24 05:08:07.995095
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()


# Generated at 2022-06-24 05:08:10.618850
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Test for method print_help of clas Parser
    """
    assert Parser().print_help() is None  # simple test to see if there are no errors


# Generated at 2022-06-24 05:08:13.542709
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser_output = parser.print_help()
    # Unit test to ensure that parser is not null
    assert parser_output is not None
    assert parser_output == 0

# Generated at 2022-06-24 05:08:23.342650
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # With placeholder
    assert parser.parse("thefuck --help").help is True
    assert parser.parse("thefuck --help".split(
    )).help is True
    assert parser.parse("thefuck {} --help".format(
        ARGUMENT_PLACEHOLDER)).help is True
    assert parser.parse("thefuck {} --help".format(
        ARGUMENT_PLACEHOLDER).split(
    )).help is True
    assert parser.parse("thefuck {} echo".format(
        ARGUMENT_PLACEHOLDER)).command == []
    assert parser.parse("thefuck {} echo".format(
        ARGUMENT_PLACEHOLDER).split(
    )).command == []

# Generated at 2022-06-24 05:08:25.092415
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    # TODO unit test to check the output

# Generated at 2022-06-24 05:08:36.162211
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    out = sys.stdout
    err = sys.stderr
    try:
        sys.stdout = sys.stderr = StringIO()
        p = Parser()
        p.print_usage()
        assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [CUSTOM-ALIAS-NAME]]\n                   [-l SHELL-LOGGER] [--enable-experimental-instant-mode]\n                   [-d] [--force-command FORCE-COMMAND] [-y | -r]\n                   [command [command ...]]\n'
    finally:
        sys.stdout = out
        sys.stderr = err

# Generated at 2022-06-24 05:08:37.024695
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-24 05:08:47.076910
# Unit test for method parse of class Parser
def test_Parser_parse():
    class Args:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    parser = Parser()

    assert parser.parse(['thefuck', '-d']) == Args(debug=True)
    assert parser.parse(['thefuck', '-da']) == Args(debug=True, alias='a')
    assert parser.parse(['thefuck', '-h']) == Args(help=True)

    assert parser.parse(['thefuck', 'echo']) == Args(command=['echo'])
    assert parser.parse(['thefuck', 'echo', ARGUMENT_PLACEHOLDER]) == \
           Args(command=['echo'])

# Generated at 2022-06-24 05:08:50.344890
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    sys.argv = ['thefuck', '-l', '--help']

    with pytest.raises(SystemExit):
        parser.parse(sys.argv)
        parser.print_help()

# Generated at 2022-06-24 05:08:52.678145
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.stderr.write = mock.MagicMock()
    parser = Parser()
    parser.print_help()
    assert sys.stderr.write.call_count > 0

# Generated at 2022-06-24 05:08:56.901885
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .main import create_parser
    create_parser().print_help()

# Generated at 2022-06-24 05:09:03.642127
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue() == (
        'usage: thefuck [--version | --alias [custom-alias-name]]\n'
        '               [--shell-logger path]\n'
        "               [--enable-experimental-instant-mode] [-h]\n"
        '               [-d] [--force-command path_to_script]\n'
        '               [command [command ...]]\n')



# Generated at 2022-06-24 05:09:06.964110
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['./thefuck', '--yes', '--', 'ls', 'faile']
    arguments = ['./thefuck', '--', 'ls', 'faile']
    assert Parser().parse(argv) == Parser()._parser.parse_args(arguments)


# Generated at 2022-06-24 05:09:12.731153
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    usage = "usage: thefuck [-a [custom-alias-name]] [-h] [-l SHELL_LOGGER] [-r]\n"
    "               [-v] [-y] [--enable-experimental-instant-mode]\n"
    "               [--force-command=FORCE_COMMAND] [--] [command [command ...]]\n"
    assert sys.stderr.getvalue() == usage

# Generated at 2022-06-24 05:09:18.952189
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import mock

    parser = Parser()
    with mock.patch.object(parser._parser, 'print_usage') as print_usage:
        parser.print_usage()
        assert print_usage.call_count == 1
        print_usage.assert_called_with(sys.stderr)


# Generated at 2022-06-24 05:09:19.455168
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()

# Generated at 2022-06-24 05:09:21.859800
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .tests.utils import Support
    with Support.mock_stdout() as stdout:
        Parser().print_help()
    assert '*' in stdout.getvalue()


# Generated at 2022-06-24 05:09:23.832791
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except:
        raise AssertionError("The print_help error")


# Generated at 2022-06-24 05:09:25.967185
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert not parser.parse([]).command
    assert ['-v'] == parser.parse(['-v']).command
    assert ['--version'] == parser.parse(['--version']).command

# Generated at 2022-06-24 05:09:27.737334
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    assert print_help method prints help-screen if --alias is passed as a argument without any value
    """
    parser = Parser()
    assert parser.print_help() is not None

# Generated at 2022-06-24 05:09:30.011424
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from contextlib import redirect_stdout
    parser = Parser()
    f = StringIO()
    with redirect_stdout(f):
        parser.print_help()
    assert("Show this help message" in f.getvalue())

# Generated at 2022-06-24 05:09:38.899383
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # arguments begin with "-" but left placeholder
    assert parser.parse(['fuck', '-l', './testlog', ARGUMENT_PLACEHOLDER]) == parser.parse(['fuck', '-l', './testlog', '--', ARGUMENT_PLACEHOLDER])

    assert parser.parse(['fuck', '-l', './testlog', ARGUMENT_PLACEHOLDER,  'ls', '-a']) == parser.parse(['fuck', '-l', './testlog', '--', 'ls', '-a', ARGUMENT_PLACEHOLDER])

    assert parser.parse(['./fuck', '-v']) == parser.parse(['./fuck', '-v', ARGUMENT_PLACEHOLDER])

    assert parser

# Generated at 2022-06-24 05:09:46.382813
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    def assert_string(out, err):
        assert err == "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n" + \
                      "               [-l SHELL_LOGGER] \n" + \
                      "               [-y | -r]\n" + \
                      "               [--debug] [--enable-experimental-instant-mode]\n" + \
                      "               [--force-command COMMAND]\n" + \
                      "               [command [command ...]]\n"


    parser = Parser()
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr

# Generated at 2022-06-24 05:09:53.714941
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    command = ['fuck', 'the', 'sys', 'admin']
    arguments = command + [ARGUMENT_PLACEHOLDER, '-y']

    parsed_arguments = parser.parse(arguments)
    eq_(parsed_arguments.command, command)
    eq_(parsed_arguments.yes, True)

    arguments = command + [ARGUMENT_PLACEHOLDER, '-y', '-d']

    parsed_arguments = parser.parse(arguments)
    eq_(parsed_arguments.command, command)
    eq_(parsed_arguments.yes, True)
    eq_(parsed_arguments.debug, True)

    arguments = command + ['-y', ARGUMENT_PLACEHOLDER, '-d']

