

# Generated at 2022-06-24 05:00:07.524832
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:00:11.404624
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    class TestParser(Parser):
        """Create our own parser so that we can test the print_usage method"""

        def __init__(self):
            super().__init__()

        def print_usage(self):
            return

    parser = TestParser()
    parser.print_usage()


# Generated at 2022-06-24 05:00:15.791836
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    Unit test for method parse of class Parser

    """
    parser = Parser()
    test_command = 'git log --oneline && cd '
    sys.argv = ['/usr/bin/thefuck', test_command]
    test_argv = sys.argv
    test_parse_args = parser.parse(test_argv)
    assert test_parse_args.command == ['--log', '--oneline', '&&', 'cd']

# Generated at 2022-06-24 05:00:18.377167
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    help_message = p.print_help()
    assert help_message != ""

# Generated at 2022-06-24 05:00:20.116980
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser


# Generated at 2022-06-24 05:00:27.438218
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # check if arguments for thefuck is added
    assert len(parser._parser._actions) == 12
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].type == 'store_true'
    assert parser._parser._actions[1].dest == 'alias'
    assert  parser._parser._actions[1].type == 'string'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert  parser._parser._actions[2].type == 'store'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert  parser._parser._actions[3].type == 'store_true'
    assert parser._parser._actions[4].dest == 'help'
    assert  parser._parser

# Generated at 2022-06-24 05:00:38.091760
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        # Parser needs sys.argv (sys.argv = sys.argv), so we need to import it in this function
        from sys import argv
        parser = Parser()
        sys.stderr = StringIO()
        parser.print_usage()
        sys.stderr.seek(0)
        usage = sys.stderr.read()
        assert usage == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' \
                        '[-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n' \
                        '               [-d] [--force-command FORCE_COMMAND]\n' \
                        '               [command]\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:00:47.415816
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(
        ['fuck', '-q', 'ls', '-lh', ARGUMENT_PLACEHOLDER, '-a'])
    assert vars(arguments) == {
        'alias': get_alias(),
        'debug': False,
        'force_command': None,
        'help': False,
        'repeat': False,
        'shell_logger': None,
        'yes': False,
        'command': ['ls', '-lh', '-a']}

    arguments = parser.parse(
        ['fuck', 'ls', '-lh', ARGUMENT_PLACEHOLDER, '-a'])

# Generated at 2022-06-24 05:00:54.737620
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'git', 'push', 'origin', 'master']) == \
        parser._parser.parse_args(['git', '--', 'push', 'origin', 'master'])
    assert parser.parse(['thefuck', 'git', '-h']) == \
        parser._parser.parse_args(['git', '--', '-h'])
    assert parser.parse(['thefuck', '--help']) == \
        parser._parser.parse_args(['--help'])
    assert parser.parse(['thefuck', '--', 'git', 'push', 'origin', 'master']) == \
        parser._parser.parse_args(['--', 'git', 'push', 'origin', 'master'])

# Generated at 2022-06-24 05:00:55.591584
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:01:00.541504
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from unittest.mock import Mock

    parser = Parser()

    # print usage
    stderr = StringIO()
    parser.print_usage = Mock()
    parser.print_usage()
    stderr.write = parser.print_usage
    parser.print_usage.assert_called_with(stderr)

    stderr.close()

# Generated at 2022-06-24 05:01:03.458884
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['fuck', '-d'])



# Generated at 2022-06-24 05:01:11.298768
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].__class__ == _HelpAction
    assert parser._parser._actions[1].option_strings == ['-v', '--version']
    assert parser._parser._actions[2].__class__ == _StoreTrueAction
    assert parser._parser._actions[2].help == "show program's version number and exit"
    assert parser._parser._actions[3].option_strings == ['-a', '--alias']
    assert parser._parser._actions[3].__class__ == _StoreConstAction
    assert parser._parser._actions[6].__class__ == _StoreAction
    assert parser._parser._actions[6].help == 'log shell output to the file'
    assert parser._parser._actions[7].__class__ == _

# Generated at 2022-06-24 05:01:14.958309
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:01:24.605713
# Unit test for method parse of class Parser
def test_Parser_parse():
    import unittest
    import sys
    from .utils import capture_output

    class TestArgs(object):
        def __init__(self, command):
            self.command = command

    class TestCase(unittest.TestCase):
        def setUp(self):
            self._parser = Parser()

        def _check_parse(self, argv):
            expected = TestArgs(command=['ls', '-la'])
            with capture_output() as (out, err):
                actual = self._parser.parse(argv)
            self.assertEqual(actual.command, expected.command)

        def _check_parse_with_alias(self, argv):
            expected = TestArgs(command=['ls', '-la'])
            with capture_output() as (out, err):
                actual = self._

# Generated at 2022-06-24 05:01:32.764254
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['thefuck', '-v', '-l', 'log_file', '--force-command', 'ls', '--', 'git', 's'])
    expected = argparse.Namespace(
        alias=get_alias(),
        command=['git', 's'],
        debug=False,
        enable_experimental_instant_mode=False,
        force_command='ls',
        help=False,
        repeat=False,
        shell_logger='log_file',
        version=True,
        yes=False)
    assert result == expected



# Generated at 2022-06-24 05:01:38.355898
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print('testing Parser.print_usage')
    _temp_stderr = sys.stderr
    Parser().print_usage()
    sys.stderr = _temp_stderr



# Generated at 2022-06-24 05:01:39.203945
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == None


# Generated at 2022-06-24 05:01:46.527630
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['-r', 'ls']) == Namespace(command=['ls'],
                                                   debug=False,
                                                   repeat=True,
                                                   shell_logger=None,
                                                   alias=None,
                                                   version=False,
                                                   yes=False,
                                                   help=False,
                                                   force_command=None,
                                                   enable_experimental_instant_mode=False)

# Generated at 2022-06-24 05:01:55.825288
# Unit test for method parse of class Parser
def test_Parser_parse():
    s = Parser()
    assert ['--'] + ['-a', '--force-command', '-r', 'ls'] == s.parse(['-a', '--force-command', '-r', 'ls'])
    assert ['--'] + ['-a', '--force-command', '-r', 'ls'] == s.parse(['-a', '--force-command', '-r', 'ls'])
    assert ['-a', '--force-command', '-r', 'ls'] == s.parse(['-a', '--force-command', '-r', ARGUMENT_PLACEHOLDER, 'ls'])

# Generated at 2022-06-24 05:01:59.369071
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    argv = sys.argv[:]
    sys.argv[1:] = ['-h']
    parser = Parser()
    parser.print_help()
    sys.argv[1:] = argv[1:]

# Generated at 2022-06-24 05:02:08.542505
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	command = ['-l', 'qwerty.txt', '--', 'rm', '-rf']
	command2 = ['-l', 'qwerty.txt', '--', 'rm', '-rf', 'qwert.txt']
	command3 = ['-l', 'qwerty.txt', 'rm', '-rf', 'qwert.txt']
	command4 = ['--', 'rm', '-rf']
	command5 = ['rm', '-rf']
	assert parser.parse(command).command == ['rm', '-rf']
	assert parser.parse(command2).command == ['rm', '-rf', 'qwert.txt']
	assert parser.parse(command3).command == ['rm', '-rf', 'qwert.txt']

# Generated at 2022-06-24 05:02:09.699676
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help()

# Generated at 2022-06-24 05:02:19.360221
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Test method print_help of class Parser"""
    import sys
    import io
    import unittest

    class Parser_print_help_TestCase(unittest.TestCase):
        def setUp(self):
            self.parser = Parser()
            self.orig_stderr = sys.stderr
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stderr = self.orig_stderr

        def test_check_print_help(self):
            """Test method print_help of class Parser"""
            self.assertRaises(SystemExit, self.parser.parse, [])
            help_string = sys.stderr.getvalue()
            self.assertIn("usage", help_string)

# Generated at 2022-06-24 05:02:21.973978
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Args:
        None

    Returns:
        None
    """
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:02:22.930848
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:02:25.625835
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 05:02:33.531553
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # Unit test for method parse
    def test_Parser_parse(arguments, expected):
        res = parser.parse(arguments.split(" "))
        assert res.__dict__ == expected.__dict__

# Generated at 2022-06-24 05:02:38.680084
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Unit test for method parse of class Parser"""
    p = Parser()
    argv = ['thefuck', 'command', ARGUMENT_PLACEHOLDER, 'argument1', 'argument2', '-v', '-d']
    p.parse(argv)

# Generated at 2022-06-24 05:02:44.994791
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser._action_groups[0]._group_actions[0].default is False
    assert p._parser._action_groups[0]._group_actions[1].default is None
    assert p._parser._action_groups[0]._group_actions[2].default is None
    assert p._parser._action_groups[0]._group_actions[3].default is False
    assert p._parser._action_groups[0]._group_actions[4].default is False
    assert p._parser._action_groups[0]._group_actions[5].default is False
    assert p._parser._action_groups[0]._group_actions[6].default is None


# Generated at 2022-06-24 05:02:50.774640
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    print_usage() method should print a usage statement to stderr
    """
    saved_stderr = sys.stderr

# Generated at 2022-06-24 05:02:56.226624
# Unit test for method parse of class Parser
def test_Parser_parse():
    import os
    os.system('/bin/echo -e "echo asdasdasd\necho $(ls\necho asdasd") > test.txt')
    argumentos = ['/usr/local/bin/thefuck', '--', 'cat', 'test.txt']
    parser = Parser()
    a = parser.parse(argumentos)

if __name__ == '__main__':
    test_Parser_parse()

# Generated at 2022-06-24 05:03:01.206613
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class Parser_for_test:
        def print_usage(self, file):
            file.write("test\n")

    p = Parser_for_test()
    assert p.print_usage() == "test\n"

# Generated at 2022-06-24 05:03:02.423617
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-24 05:03:05.278854
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    print(p._parser)


# Generated at 2022-06-24 05:03:12.723894
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', 'python', 'python', '-f']) == \
        p.parse(['thefuck', 'python', '-f', ARGUMENT_PLACEHOLDER])
    assert p.parse(['thefuck', 'python', 'python',
                    ARGUMENT_PLACEHOLDER, '-y']) == \
        p.parse(['thefuck', 'python', ARGUMENT_PLACEHOLDER, '-y'])
    assert p.parse(['thefuck', 'python', 'python',
                    ARGUMENT_PLACEHOLDER]) == \
        p.parse(['thefuck', 'python'])

# Generated at 2022-06-24 05:03:16.880731
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    test_string = "thefuck 0.3.3\n"
    sys.stderr.write(test_string)
    assert(sys.stderr.getvalue() == test_string)
    


# Generated at 2022-06-24 05:03:18.909442
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    try:
        parser.print_help()
    except SystemExit:
        pass

# Generated at 2022-06-24 05:03:29.012423
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-la']) == \
        parser._parser.parse_args(['ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER,'-d']) == \
        parser._parser.parse_args(['-d', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-d', 'foobar']) == \
        parser._parser.parse_args(['-d', 'ls', '-la', '--', 'foobar'])

# Generated at 2022-06-24 05:03:31.395344
# Unit test for constructor of class Parser
def test_Parser():
    pass


# Generated at 2022-06-24 05:03:37.924649
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    capturedOutput = io.StringIO()
    sys.stderr = capturedOutput
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert capturedOutput.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n'


# Generated at 2022-06-24 05:03:38.735485
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:03:39.256084
# Unit test for constructor of class Parser
def test_Parser():
    foo = Parser()

# Generated at 2022-06-24 05:03:47.399794
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    usage = """usage: thefuck [-h] [-v] [-a [custom-alias-name]]
                [-l SHELL-LOGGER] [--enable-experimental-instant-mode]
                [-h] [-d] [--force-command FORCE-COMMAND]
                [--yes | --repeat] [--] COMMAND [COMMAND ...]"""
    parser.print_usage()
    assert sys.stderr.getvalue() == usage + '\n'


# Generated at 2022-06-24 05:03:48.521178
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-24 05:03:52.130645
# Unit test for method parse of class Parser
def test_Parser_parse():
    expected_result = 'usage: thefuck [-h] [-v] [-y | -r] [-d] [--force-command FORCE_COMMAND] [--enable-experimental-instant-mode] [--shell-logger SHELL_LOGGER] [-a [custom-alias-name]] [command [command ...]]'
    parser = Parser()
    assert parser.parse([]) == expected_result

# Generated at 2022-06-24 05:03:55.987077
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    print(parser)

# Generated at 2022-06-24 05:04:00.798808
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ["fuck", "git", "add", "--hghj", "--sdfs", "--sadfsd"]
    assert parser.parse(argv) == argv[1:]

# Generated at 2022-06-24 05:04:03.004107
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-24 05:04:04.359428
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser._parser.format_help() == parser.print_help()



# Generated at 2022-06-24 05:04:12.372233
# Unit test for method parse of class Parser
def test_Parser_parse():
    print("test_Parser_parse")
    parser = Parser()
    args = parser.parse(['thefuck', '--version'])
    assert args.version
    args = parser.parse(['thefuck', '--alias'])
    assert args.alias == get_alias()
    args = parser.parse(['thefuck', '--help'])
    assert args.help
    args = parser.parse(['thefuck', '--debug'])
    assert args.debug
    args = parser.parse(['thefuck', '--no-shell-logger'])
    assert not args.shell_logger



# Generated at 2022-06-24 05:04:22.420437
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from unittest.mock import patch
    from .parser import Parser

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        parser = Parser()
        parser.print_usage()
        assert mock_stderr.getvalue() == """\
usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]
               [--enable-experimental-instant-mode]
               [-y | -r | -d] [--force-command FORCE_COMMAND] command ...

positional arguments:
  command               command that should be fixed
"""

# Generated at 2022-06-24 05:04:32.040074
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio
            sys.stdout = self._stdout
    with Capturing() as output:
        parser.print_usage()
    assert output[0] == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]'
    assert output[1] == '                [-l SHELL_LOGGER]'
    assert output[2] == '                [--enable-experimental-instant-mode]'

# Generated at 2022-06-24 05:04:33.114104
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-24 05:04:37.786465
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert(isinstance(p._parser, ArgumentParser))
    assert(hasattr(p._parser, 'print_help'))
    import io
    import sys

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        p.print_help()
        output = out.getvalue().strip()
        assert(output)
    finally:
        sys.stdout = saved_stdout



# Generated at 2022-06-24 05:04:38.744937
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:40.766378
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ["thefuck", "--help"]
    args = parser.parse(argv)
    assert args.help is True


# Generated at 2022-06-24 05:04:47.838312
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

    def run_test(argv):
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        parser.print_usage()
        result = sys.stdout.getvalue()
        sys.stdout.close()
        sys.stdout = old_stdout
        return result

    assert 'Usage: thefuck' in run_test([])


# Generated at 2022-06-24 05:04:48.814649
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-24 05:04:52.765329
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    t1 = ['thefuck', '--force-command']
    assert p.parse(t1).force_command is None
    t2 = ['thefuck', '--force-command', 'fuck']
    assert p.parse(t2).force_command == 'fuck'

# Generated at 2022-06-24 05:04:57.797541
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    err = StringIO.StringIO()
    sys.stderr = err
    parser.print_usage()
    output = err.getvalue().strip()
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\
 [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d]\
 [--force-command FORCE_COMMAND] [command]...'


# Generated at 2022-06-24 05:05:01.697313
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == 1

# Generated at 2022-06-24 05:05:09.680572
# Unit test for constructor of class Parser
def test_Parser():
  parser = Parser()

  args = parser.parse(['thefuck', '-v'])
  assert args.version is True

  args = parser.parse(['thefuck', '-a', 'tf' ])
  assert args.alias == 'tf'

  # --enable-experimental-instant-mode isn't available on production version
  args = parser.parse(['thefuck', '--enable-experimental-instant-mode'])
  assert args.enable_experimental_instant_mode is True

  args = parser.parse(['thefuck', '-h'])
  assert args.help is True

  args = parser.parse(['thefuck', '-d'])
  assert args.debug is True

  args = parser.parse(['thefuck', '-y'])
  assert args.yes is True

# Generated at 2022-06-24 05:05:16.351915
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    temp_stdout = io.StringIO()
    with contextlib.redirect_stdout(temp_stdout):
        parser.print_usage()
    output = temp_stdout.getvalue().strip()
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--] [command [command ...]]'


# Generated at 2022-06-24 05:05:17.818384
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # when
    parser = Parser()
    parser.print_help()
    # then
    assert True

# Generated at 2022-06-24 05:05:18.938797
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-24 05:05:28.625748
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .config import Config
    from .runner import Runner
    from .utils import get_aliases

    parser = Parser()

    # from test.py files:
    # test_command_with_fixed_arguments
    args = parser.parse(['test', 'rm', '--verbose', 'file.txt'])
    additional_args = ['--verbose']
    command = ' '.join(['rm', 'file.txt'] + additional_args)
    assert args.command == command
    assert args.commands == [('rm {}'.format(command), Runner, Config())]

    # test_running_with_given_config
    args = parser.parse(['test', '-h'])
    assert args.command == '-h', args.command
    assert args.commands == []
    assert args.help is True



# Generated at 2022-06-24 05:05:30.150625
# Unit test for constructor of class Parser
def test_Parser():
    parser=Parser()
    assert isinstance(parser,Parser)


# Generated at 2022-06-24 05:05:35.284224
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import StringIO
    parser = Parser()

    #print parser.print_help()
    assert "show program's version number and exit" in parser.print_help()
    assert "--shell-logger" in parser.print_help()

# Generated at 2022-06-24 05:05:37.619758
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-24 05:05:44.102423
# Unit test for method parse of class Parser
def test_Parser_parse():
    parse = Parser().parse
    assert parse(['thefuck', 'echo', 'fuck']) == \
           Namespace(yes=False, repeat=False, version=False, debug=False,
                     alias=None, shell_logger=None, command=['echo', 'fuck'])
    assert parse(['thefuck', 'echo', 'fuck', 'fuck1', 'fuck2']) == \
           Namespace(yes=False, repeat=False, version=False, debug=False,
                     alias=None, shell_logger=None, command=['echo', 'fuck', 'fuck1', 'fuck2'])

# Generated at 2022-06-24 05:05:54.468299
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert sys.argv == ['thefuck']
    assert parser.parse(['thefuck']) == argparse.Namespace(alias=get_alias(), debug=False, help=False, repeat=False, yes=False, command=None, shell_logger=None)
    assert parser.parse(['thefuck','aaa','bbb','--debug']) == argparse.Namespace(alias=get_alias(), debug=True, help=False, repeat=False, yes=False, command=None, shell_logger=None)

# Generated at 2022-06-24 05:05:55.414996
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-24 05:06:04.839008
# Unit test for method parse of class Parser
def test_Parser_parse():
  fake_argv = ['thefuck', '-a', 'fuck', '-y', ARGUMENT_PLACEHOLDER, 'git', 'log', '--oneline']
  test_obj = Parser()
  result = test_obj._prepare_arguments(fake_argv[1:])
  print(result)
  assert(result == ['git', 'log', '--oneline', '--', '-a', 'fuck', '-y'])

  parsed_result = test_obj.parse(fake_argv)
  print(parsed_result)
  assert(parsed_result.alias == 'fuck')
  assert(parsed_result.yes)
  assert(parsed_result.command == ['git', 'log', '--oneline'])


# Generated at 2022-06-24 05:06:09.432611
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    for func_name in [p.print_usage, p.print_help]:
        func_name()


# Generated at 2022-06-24 05:06:10.781781
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:06:12.158333
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()
    assert True

# Generated at 2022-06-24 05:06:14.234122
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser=Parser()
    output=parser.print_usage()
    assert output==parser._parser



# Generated at 2022-06-24 05:06:16.246664
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    assert p.print_usage() == None
    assert p.print_usage() == None


# Generated at 2022-06-24 05:06:22.234767
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class TestParser(Parser):
        def __init__(self):
            class TestArgumentParser(object):
                def print_help(self, stream):
                    stream.write('Usage: test_usage\n')
            self._parser = TestArgumentParser()
            self._add_arguments()
    p = TestParser()
    p.print_help()
    assert sys.stderr.getvalue().startswith('Usage: test_usage')


# Generated at 2022-06-24 05:06:23.960252
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_str = parser.print_help()
    assert isinstance(help_str, str)

# Generated at 2022-06-24 05:06:30.896158
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    out, err = sys.stdout, sys.stderr
    try :
        sys.stdout, sys.stderr = StringIO(), StringIO()

        parser = Parser()
        parser.print_usage()

        assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-y] [-r] [-d] [--force-command FORCE_COMMAND] [--] [command [command ...]]\n'
        assert sys.stdout.getvalue() == ''
    finally :
        sys.stdout, sys.stderr = out, err

# Generated at 2022-06-24 05:06:32.830476
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

# Generated at 2022-06-24 05:06:43.128222
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from cStringIO import StringIO
    from contextlib import contextmanager
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    p = Parser()
    with captured_output() as (out, err):
        p.print_usage()
    output = out.getvalue().strip()

# Generated at 2022-06-24 05:06:45.607265
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert "usage: thefuck" in _get_stderr()


# Generated at 2022-06-24 05:06:46.788418
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-24 05:06:54.690855
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    stdout = sys.stdout
    sys.stdout = open('test_Parser_print_help_output.txt', 'w')
    parser.print_help()
    sys.stdout.close()
    sys.stdout = stdout
    with open('test_Parser_print_help_output.txt', 'r') as output_file:
        output = output_file.read()
    import os
    os.system('rm test_Parser_print_help_output.txt')
    assert output is not None


# Generated at 2022-06-24 05:06:57.035765
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    help = (p.print_help() == None)
    res = True
    assert res == help


# Generated at 2022-06-24 05:07:01.445707
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv1 = ['fuck', '-y', 'ls', ARGUMENT_PLACEHOLDER, '--', '-l']
    parse1 = Parser().parse(argv1)
    assert parse1.yes == True
    assert parse1.repeat == False
    assert parse1.command == False
    assert parse1.debug == False
    assert parse1.debug == False
    assert parse1.command == ['ls']

# Generated at 2022-06-24 05:07:08.595444
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert parser._parser.prog == "thefuck"

    assert parser._parser._actions[0].dest == "version"
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[2].dest == "shell_logger"
    assert parser._parser._actions[2].help == "log shell output to the file"
    assert parser._parser._actions[3].dest == "enable_experimental_instant_mode"
    assert parser._parser._actions[3].help == "enable experimental instant mode, use on your own risk"
    assert parser._parser._actions[4].dest == "help"
    assert parser._parser._actions[4].help == "show this help message and exit"

# Generated at 2022-06-24 05:07:10.882670
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-24 05:07:11.405323
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:07:14.747433
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-24 05:07:18.478171
# Unit test for method print_help of class Parser
def test_Parser_print_help():
  p = Parser()
  with patch('thefuck.thefuck.sys.stderr.write') as stderr_write:
    p.print_help()
    assert stderr_write.called

# Generated at 2022-06-24 05:07:25.101241
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.get_default('help') == None
    assert parser._parser.get_default('debug') == None
    assert parser._parser.get_default('shell_logger') == None
    assert parser._parser.get_default('version') == None
    assert parser._parser.get_default('enable_experimental_instant_mode') == None
    assert parser._parser.get_default('force_command') == None
    assert parser._parser.get_default('command') == None
    #

# Generated at 2022-06-24 05:07:35.028112
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    # Capture sys.stderr
    old_stderr = sys.stderr
    captured_stderr = sys.stderr = StringIO()
    try:
        parser = Parser()
        parser.print_usage()
        output = captured_stderr.getvalue()
        assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' + \
        '[-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n' + \
        '             [-y | -r] [-d] [--force-command FORCE_COMMAND]\n' + \
        '             [command [command ...]]\n'
    finally:
        # Reset sys.stderr
        sys.stderr = old_

# Generated at 2022-06-24 05:07:36.509561
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .parser import Parser
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-24 05:07:42.195019
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([
        'thefuck', 'vim', 'README.rst', ARGUMENT_PLACEHOLDER, '-v']) == \
        parser.parse(['thefuck', '-v', '--', 'vim', 'README.rst'])



# Generated at 2022-06-24 05:07:45.971381
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class Stderr(object):
        def __init__(self):
            self.content = ""
        
        def write(self, string):
            self.content += string

    sys.stderr = Stderr()
    parser = Parser()
    parser.print_usage()
    assert parser._parser.format_usage() == sys.stderr.content

# Generated at 2022-06-24 05:07:50.275586
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'example_command'])
    assert arguments.command == ['example_command']
    assert arguments.debug is False
    assert arguments.force_command is None
    assert arguments.repeat is False
    assert arguments.yes is False
    assert arguments.shell_logger is None
    assert arguments.alias is None
    assert arguments.enable_experimental_instant_mode is False
    assert arguments.help is False
    assert arguments.version is False



# Generated at 2022-06-24 05:07:51.314770
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:07:52.302792
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser

# Generated at 2022-06-24 05:07:54.891974
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = ["-d","halo","fuck","--force-command=ls","-a","-vv","-l","/tmp/log"]
    print(parser.parse(args))



# Generated at 2022-06-24 05:07:56.945638
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(sys.argv)

# Generated at 2022-06-24 05:08:00.706006
# Unit test for method print_help of class Parser
def test_Parser_print_help():
	parser = Parser()
	f = open('thefuck.txt','w')
	parser.print_help(f)
	f.close()
	f = open('thefuck.txt','r')
	for line in f:
		if "usage" in line:
			print("test_Parser_print_help: Success")
			return
	print("test_Parser_print_help: Failed")


# Generated at 2022-06-24 05:08:05.950613
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_args = "thefuck -h --debug".split()
    test_parser = Parser()
    assert test_parser.parse(test_args).debug == False
    assert test_parser.parse(test_args).help == True
    test_parser.print_usag

# Generated at 2022-06-24 05:08:13.753467
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck'])
    assert args.command == []
    assert args.yes == False
    assert args.repeat == False
    assert args.debug == False
    assert args.shell_logger == None
    assert args.help == False
    assert args.force_command == None
    assert args.alias == get_alias()
    assert args.version == False
    assert args.enable_experimental_instant_mode == False

    args = parser.parse(['thefuck', 'ls', 'fuck'])
    assert args.command == ['ls', 'fuck']
    assert args.yes == False
    assert args.repeat == False
    assert args.debug == False
    assert args.shell_logger == None
    assert args.help == False

# Generated at 2022-06-24 05:08:23.454821
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(["thefuck", "something", "else", "--help"]) == Namespace(command=['--help'], debug=False, shell_logger=None, alias=None, force_command=None, repeat=False, yes=False, enable_experimental_instant_mode=False, help=False, version=False)
    assert p.parse(["thefuck", "something", "else", "--some-arg", "--", "some command"]) == Namespace(command=['--some-arg', '--', 'some command'], debug=False, shell_logger=None, alias=None, force_command=None, repeat=False, yes=False, enable_experimental_instant_mode=False, help=False, version=False)

# Generated at 2022-06-24 05:08:25.444687
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)



# Generated at 2022-06-24 05:08:26.235721
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:08:28.257308
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    argv = sys.argv
    arguments = parser._prepare_arguments(argv)
    parser._parser.parse_args(arguments)
    parser.print_help()

# Generated at 2022-06-24 05:08:29.983323
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None

# Generated at 2022-06-24 05:08:32.329030
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # it currently exits the application
    if '--quick' in sys.argv:
        return
    P = Parser()
    P.print_usage()


# Generated at 2022-06-24 05:08:34.315589
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True # if no error then it is OK

# Generated at 2022-06-24 05:08:36.290250
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:08:37.103243
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-24 05:08:38.623491
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    # In the moment, no ways to test that print_usage has been called correctly.

# Generated at 2022-06-24 05:08:40.123809
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-24 05:08:42.581779
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys, io
    sys.stdout = io.StringIO()
    Parser().print_help()
    sys.stdout.seek(0)
    print_value=sys.stdout.read()



# Generated at 2022-06-24 05:08:45.638171
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-24 05:08:48.069556
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    this_parser = Parser()
    output = this_parser.print_usage()
    assert output == None


# Generated at 2022-06-24 05:08:53.439135
# Unit test for method parse of class Parser
def test_Parser_parse():
    _parser = Parser()
    _argv = 'thefuck {} some arguments'.format(ARGUMENT_PLACEHOLDER).split()
    _args = _parser.parse(_argv)
    assert ['some', 'arguments'] == _args.command



# Generated at 2022-06-24 05:09:03.626746
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Prepares satisfied case
    backward = ['thefuck', 'command', 'arg1', 'arg2', 'arg3', '--',
                '--', 'argument', 'placeholder', '-y']
    forward = ['thefuck', 'command', 'arg1', 'arg2', 'arg3', '--',
               'argument', 'placeholder', '-y']

    # Parses satisfied case
    t1 = Parser()
    output1 = t1.parse(backward)
    output2 = t1.parse(forward)

    # Tests satisfied case
    assert output1.command == ['command', 'arg1', 'arg2', 'arg3', '--']
    assert output1.yeah
    assert not output1.debug

# Generated at 2022-06-24 05:09:07.274062
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    import sys
    import io
    sys.stderr = io.StringIO()
    p.print_usage()
    out = sys.stderr.getvalue().rstrip()
    assert out == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]'


# Generated at 2022-06-24 05:09:09.659252
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    assert out.getvalue().startswith("usage")


# Generated at 2022-06-24 05:09:15.985664
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    output = StringIO()
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-24 05:09:16.843835
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    assert a != None

# Generated at 2022-06-24 05:09:23.655443
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = StringIO()
    sys.stderr = output
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert sys.stderr
    assert output.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] '\
                                '[-l shell-logger] [--enable-experimental-instant-mode] '\
                                '[-y | -r] [-d] [--force-command FORCE_COMMAND] [--] '\
                                '[command [command ...]]\n'


# Generated at 2022-06-24 05:09:31.069452
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._action_groups[0].title == 'optional arguments'
    assert parser._parser._action_groups[1].title == 'Mode'
    assert parser._parser._action_groups[2].title == 'optional arguments'
    assert parser._parser.description == (
        'The Fuck is a magnificent app, which corrects your '
        'previous console command.')
    assert parser._parser._positionals._group_actions[0].dest == 'command'
    assert parser._parser._positionals._group_actions[0].metavar == 'command'
    assert parser._parser._positionals._group_actions[0].help == (
        'command that should be fixed')


# Generated at 2022-06-24 05:09:33.253216
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from six import StringIO

    stdout = sys.stdout
    try:
        output = StringIO()
        sys.stdout = output
        parser = Parser()
        parser.print_usage()
        assert 'usage:' in output.getvalue()
    finally:
        sys.stdout = stdout


# Generated at 2022-06-24 05:09:36.461998
# Unit test for method parse of class Parser
def test_Parser_parse():
    command = "dnf update --refresh"
    parser = Parser()
    result = parser.parse([command])
    assert result.command == command.split()

# Generated at 2022-06-24 05:09:44.743740
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	assert parser.parse(['thefuck', '--version']).version == True
	#Argument that doesn't require any value
	assert parser.parse(['thefuck', '--version', '-a']).alias == ''
	#Argument that requires a value
	assert parser.parse(['thefuck', '--version', '-a', 'test']).alias == 'test'
	#Argument that doesn't require any value and is followed by a value
	assert parser.parse(['thefuck', '--version', '-a', 'test', '--force-command']).alias == 'test'
	#Argument that doesn't require any value and is followed by a value

# Generated at 2022-06-24 05:09:53.602741
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    command = p.parse(['foo', 'bar', 'baz'])
    assert command.command == ['foo', 'bar', 'baz']
    assert not command.yes
    assert not command.repeat
    assert not command.version
    assert not command.debug
    assert not command.shell_logger
    assert not command.enable_experimental_instant_mode

    command = p.parse(['#', 'bar', 'baz'])
    assert command.command == ['bar', 'baz']
    assert not command.yes
    assert not command.repeat
    assert not command.version
    assert not command.debug
    assert not command.shell_logger
    assert not command.enable_experimental_instant_mode


# Generated at 2022-06-24 05:09:55.184080
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None


# Generated at 2022-06-24 05:09:56.693572
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None