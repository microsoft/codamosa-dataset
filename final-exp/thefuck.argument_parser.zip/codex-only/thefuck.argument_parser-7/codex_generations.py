

# Generated at 2022-06-24 04:59:56.925885
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-24 04:59:58.208274
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parse = Parser()
    parse.print_usage()


# Generated at 2022-06-24 05:00:00.122658
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-24 05:00:10.776510
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    #print(parser.parse(['-v']))
    #print(parser.parse(['-a']))
    #print(parser.parse(['-a', 'fuck']))
    #print(parser.parse(['-l', 'fuck.log']))
    #print(parser.parse(['-h']))
    #print(parser.parse(['-d']))
    #print(parser.parse(['-y']))
    #print(parser.parse(['-r']))
    #print(parser.parse(['fuck']))
    #print(parser.parse(['-a', 'fuck', '-d', 'cd', '-y', 'ls', '-l']))
    #print(parser.parse(['-a', 'fuck', '-d', 'cd', '-

# Generated at 2022-06-24 05:00:19.695859
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # no arguments
    args = parser.parse(argv=[''])
    assert args.command == []

    # simple command
    args = parser.parse(argv=['', 'ls', '-la'])
    assert args.command == ['ls', '-la']

    # command with argument placeholder
    args = parser.parse(argv=['', 'sudo', 'fuck', '-l', '$TIME'])
    assert args.command == ['fuck', '-l', '$TIME']

    # command with argument placeholder and no arguments
    args = parser.parse(argv=['', 'sudo', 'fuck', ARGUMENT_PLACEHOLDER])
    assert args.command == ['fuck']

    # command with argument placeholder and arguments after placeholder

# Generated at 2022-06-24 05:00:24.102048
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', 'f*']) == parser._parser.parse_args(['ls', 'f*'])
    assert parser.parse(['thefuck', 'git', 'rm', '--', 'f*']) == parser._parser.parse_args(['git', 'rm', '--', 'f*'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == parser._parser.parse_args(['-l', '--'])

# Generated at 2022-06-24 05:00:24.949512
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-24 05:00:25.946932
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:00:37.697992
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from thefuck import VERSION

    out = StringIO()

    Parser().print_help()


# Generated at 2022-06-24 05:00:38.918679
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:00:41.021382
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-24 05:00:42.170207
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-24 05:00:42.941258
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == None

# Generated at 2022-06-24 05:00:51.957435
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['-h']) == parser._parser.parse_args(['-h'])
    assert parser.parse(['--help']) == parser._parser.parse_args(['--help'])
    assert parser.parse(['-a']) == parser._parser.parse_args(['-a'])
    assert parser.parse(['--alias']) == parser._parser.parse_args(['--alias'])
    assert parser.parse(['--alias', 'fuck']) == parser._parser.parse_args(['--alias', 'fuck'])
    assert parser.parse(['-y']) == parser._parser.parse_args(['-y'])
    assert parser.parse(['--yes']) == parser._parser.parse_args(['--yes'])

# Generated at 2022-06-24 05:00:55.064592
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:01:01.610428
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    assert parser.print_usage() == None
    sys.stderr = sys.__stderr__

    try:
        out.seek(0)
        result = out.read()
        assert  result.startswith('usage:')
    finally:
        out.close()


# Generated at 2022-06-24 05:01:10.402287
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .config import Config
    from .utils import get_alias
    args = Parser().parse(['thefuck'])
    assert not getattr(args, 'version')
    assert not getattr(args, 'alias')
    assert not getattr(args, 'shell_logger')
    assert not getattr(args, 'enable_experimental_instant_mode')
    assert not getattr(args, 'help')
    assert not getattr(args, 'yes')
    assert not getattr(args, 'repeat')
    assert not getattr(args, 'debug')
    assert not getattr(args, 'force_command')
    assert getattr(args, 'command') == []


# Generated at 2022-06-24 05:01:16.241518
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    output = StringIO()
    test_parser = Parser()
    test_parser.print_usage(file=output)
    assert output.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n             [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n             [-d] [--force-command FORCE_COMMAND]\n             [command [command ...]]\n\n'


# Generated at 2022-06-24 05:01:16.962761
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()


# Generated at 2022-06-24 05:01:19.417378
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Method print_help of class Parser:
    """
    import sys
    parser = Parser()
    parser.print_help()
    assert parser.print_help() != None

# Generated at 2022-06-24 05:01:20.072816
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    assert a

# Generated at 2022-06-24 05:01:25.606031
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv_1 = ['thefuck', '--', 'command', 'arg']
    argv_2 = ['thefuck', '--', 'command', 'arg1', 'arg2']
    argv_3 = ['thefuck', 'arg1', 'arg2', 'command', 'arg']
    argv_4 = ['thefuck', 'arg1', 'arg2', 'command']
    argv_5 = ['thefuck', 'command', 'arg1', ARGUMENT_PLACEHOLDER, 'arg2', 'arg3']
    argv_6 = ['thefuck', ARGUMENT_PLACEHOLDER, 'arg1', 'arg2', 'command']
    argv_7 = ['thefuck', 'command', 'arg1', 'arg2', 'arg3']

# Generated at 2022-06-24 05:01:27.163590
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:01:28.671860
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-24 05:01:34.533731
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    parser = Parser().print_help()
    assert "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL-LOGGER]" in out.getvalue()


# Generated at 2022-06-24 05:01:43.390062
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser = Parser()

    # Empty arguments
    assert parser._prepare_arguments([]) == []

    # If a list contains ARGUMENT_PLACEHOLDER and an argument after,
    # move all arguments after the placeholder to the front of the list
    assert parser._prepare_arguments(
        ['/bin/echo', '-a', '/usr/lib/python3.5/site-packages',
         ARGUMENT_PLACEHOLDER, '-l', '--shell-logger=logger.txt']) == [
             '-l', '--shell-logger=logger.txt', '/bin/echo', '-a',
             '/usr/lib/python3.5/site-packages']

    # If the first argument does not start with '-', add '--' before
    assert parser._prep

# Generated at 2022-06-24 05:01:45.644577
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    result = parser.print_usage()
    assert result == parser._parser.print_usage(sys.stderr)


# Generated at 2022-06-24 05:01:49.438781
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert 1 == 1

# Generated at 2022-06-24 05:01:50.122278
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:01:50.924296
# Unit test for constructor of class Parser

# Generated at 2022-06-24 05:01:53.872864
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = ArgumentParser(prog='')
    parser.print_help(sys.stderr)

test_Parser_print_help()

# Generated at 2022-06-24 05:01:58.390453
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO

    capturedOutput = StringIO()
    sys.stderr = capturedOutput
    p = Parser()
    p.print_usage()
    assert capturedOutput.getvalue() != ''
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:01:59.943135
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-24 05:02:01.612764
# Unit test for constructor of class Parser
def test_Parser():
    from .parser import Parser

    parser = Parser()
    parser.parse(['-v'])

# Generated at 2022-06-24 05:02:02.830354
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:02:03.812302
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-24 05:02:06.144261
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        pass
    except:
        assert False



# Generated at 2022-06-24 05:02:07.122969
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():  
    parser = Parser()
    parser.print_usage()
    

# Generated at 2022-06-24 05:02:15.575095
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck']) == p._parser.parse_args([])
    assert p.parse(['thefuck', '-d', '-v', '-h']) == p._parser.parse_args(['-dvh'])
    assert p.parse(['thefuck', 'git', 'push', 'origin', 'master', ARGUMENT_PLACEHOLDER, '--porcelain']) == p._parser.parse_args(['--', '--porcelain', 'git', 'push', 'origin', 'master'])

# Generated at 2022-06-24 05:02:16.751040
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:02:20.000319
# Unit test for constructor of class Parser
def test_Parser():
    assert(len(Parser()._parser._actions) == 11)
    assert(Parser()._parser._prog == "thefuck")

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-24 05:02:29.836107
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Parser._prepare_arguments
    def _prepare_arguments(self, argv):
        return argv

    # Unit test
    parser = Parser()
    parser._prepare_arguments = _prepare_arguments
    args = parser.parse(['', '-h'])
    assert args.help

    args = parser.parse(['', '--force-command', 'ls'])
    assert args.force_command == 'ls'
    assert args.command == []

    args = parser.parse(['', 'ls', '-l'])
    assert args.force_command is None
    assert args.command == ['ls', '-l']

    args = parser.parse(['', 'f', '--', 'ls', '-l'])
    assert args.force_command is None
    assert args

# Generated at 2022-06-24 05:02:33.242671
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Test print help."""
    parser = Parser()
    parser.print_help()
    assert 1

# Generated at 2022-06-24 05:02:38.316537
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from test.utils import stdout
    from unittest.mock import patch, PropertyMock
    args = 'arguments'
    parser = ArgumentParser()
    type(parser).prog = PropertyMock(return_value='prog')
    args = parser.parse_args(args.split())
    with patch('sys.stderr', new=stdout):
        parser.print_usage()
    out, err = stdout.getvalue(), ''
    assert out == """usage: prog [-h]\n"""


# Generated at 2022-06-24 05:02:40.769572
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'which','echo','something',ARGUMENT_PLACEHOLDER]

    parser = Parser()

    args = parser.parse(argv)

    assert args.command == ['which','echo','something']

# Generated at 2022-06-24 05:02:51.200915
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from sys import stderr
    from .parser import Parser
    p = Parser()
    old_stderr = stderr
    stderr = StringIO()
    p.print_usage()
    stderr.seek(0)

# Generated at 2022-06-24 05:03:01.730749
# Unit test for constructor of class Parser
def test_Parser():
	test = Parser()._parser
	assert test._actions[0].__dict__['option_strings'] == ['-v', '--version']
	assert test._actions[1].__dict__['option_strings'] == ['-a', '--alias']
	assert test._actions[1].__dict__['const'] == 'fuck'
	assert test._actions[2].__dict__['option_strings'] == ['-l', '--shell-logger']
	assert test._actions[3].__dict__['option_strings'] == ['--enable-experimental-instant-mode']
	assert test._actions[4].__dict__['option_strings'] == ['-h', '--help']
	assert hasattr(test._actions[5], '_group_actions')
	assert test._actions[5]._group_actions[0].__

# Generated at 2022-06-24 05:03:02.647575
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:03:11.883077
# Unit test for method parse of class Parser
def test_Parser_parse():

    cmd = ['thefuck', 'ls', '--help']
    parser = Parser()
    answer = parser.parse(cmd)
    assert answer.help == True


    cmd = ['thefuck', '-h', 'ls', '--help']
    parser = Parser()
    answer = parser.parse(cmd)
    assert answer.help == True


    cmd = ['thefuck', '-a']
    parser = Parser()
    answer = parser.parse(cmd)
    if get_alias() == 'fuck':
        assert answer.alias == None
    else:
        assert answer.alias == 'fuck'


    cmd = ['thefuck', '-d']
    parser = Parser()
    answer = parser.parse(cmd)
    assert answer.debug == True


    cmd = ['thefuck', '-v']


# Generated at 2022-06-24 05:03:12.895538
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:03:20.056491
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser._actions[0].dest == 'version'
    assert p._parser._actions[1].dest == 'alias'
    assert p._parser._actions[2].dest == 'shell_logger'
    assert p._parser._actions[3].dest == 'debug'
    assert p._parser._actions[4].dest == 'force_command' 
    assert p._parser._actions[5].dest == 'command'

# Generated at 2022-06-24 05:03:29.957802
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO

    class fake_stderr(object):
        def __init__(self):
            self.data = StringIO.StringIO()

        def write(self, obj):
            self.data.write(obj)
            return

        def read(self):
            return self.data.getvalue()

    old_stderr = sys.stderr
    fstderr = fake_stderr()
    sys.stderr = fstderr
    p = Parser()
    p.print_usage()

    data = fstderr.read()

# Generated at 2022-06-24 05:03:31.853518
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # Added for testing purpose only
    parser._parser.add_argument('--test', action='store_true', help='test')
    parser.print_help()

# Generated at 2022-06-24 05:03:36.378064
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser = parser.parse([
        'thefuck',
        'ls',
        ARGUMENT_PLACEHOLDER,
        '-a',
        '--hard'
    ])
    assert parser.command[0] == 'ls'
    assert parser.hard
    assert parser.alias is None

# Generated at 2022-06-24 05:03:41.089644
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    # check the output of print_usage
    # output: usage: thefuck [-h] [-v] [-d] [-y | -r] [--force-command COMMAND]
    #                 [--shell-logger SHELL_LOGGER]
    #                 [--enable-experimental-instant-mode] [--alias [ALIAS]]
    #                 [command [command ...]]


# Generated at 2022-06-24 05:03:51.258744
# Unit test for method parse of class Parser
def test_Parser_parse():

    argv = ['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-lf', '--color=auto']
    result = Parser().parse(argv)
    assert result.command == ['ls', '-lf', '--color=auto']
    assert result.debug == False
    assert result.repeat == False
    assert result.yeah == False
    assert result.alias == get_alias()

    argv = ['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-lf', '--color=auto', '-d']
    result = Parser().parse(argv)
    assert result.command == ['ls', '-lf', '--color=auto']
    assert result.debug == True
    assert result.repeat == False
    assert result.yeah == False

# Generated at 2022-06-24 05:04:01.502661
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(shlex.split('-h'))
    assert args.help == True
    args = parser.parse(shlex.split('--version'))
    assert args.version == True
    args = parser.parse(shlex.split('--debug'))
    assert args.debug == True
    args = parser.parse(shlex.split('--enable-experimental-instant-mode'))
    assert args.enable_experimental_instant_mode == True
    args = parser.parse(shlex.split('--alias'))
    assert args.alias == get_alias()
    args = parser.parse(shlex.split('--alias fish'))
    assert args.alias == "fish"
    args = parser.parse(shlex.split('--alias zsh'))
   

# Generated at 2022-06-24 05:04:08.742085
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['-h', '--', 'cd']
    parser = Parser()
    assert parser.parse(args).help
    args = ['-h', 'cd']
    assert parser.parse(args).help

    args = ['-y', '-h', 'cd']
    assert parser.parse(args).yes
    assert parser.parse(args).help
    assert parser.parse(args).command == ['cd']

    args = ['--debug', '--', 'cd']
    assert parser.parse(args).debug
    assert parser.parse(args).command == ['cd']

    args = ['-y', '--', 'cd', '--verbose']
    assert parser.parse(args).command == ['cd', '--verbose']
    assert parser.parse(args).yes


# Generated at 2022-06-24 05:04:16.790082
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from . import resources

    sys_argv = sys.argv
    sys_stdout = sys.stdout
    sys.stdout = open('Parser_print_usage.txt', 'w')
    sys.argv = ['thefuck', '-h']
    parser = Parser()
    parser.print_usage()
    sys.argv = sys_argv
    sys.stdout = sys_stdout
    with open('Parser_print_usage.txt') as f:
        assert f.read() == resources.read('Parser_print_usage.txt')
    os.remove('Parser_print_usage.txt')


# Generated at 2022-06-24 05:04:26.388021
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import TextIOWrapper
    import sys
    import io
    sys.stderr = TextIOWrapper(io.BytesIO(), sys.stderr.encoding)
    parser = Parser()
    parser.print_usage()
    sys.stderr.seek(0)

# Generated at 2022-06-24 05:04:27.634722
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = parser.print_help()
    assert output is not None

# Generated at 2022-06-24 05:04:31.687085
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:04:32.452611
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse([''])

# Generated at 2022-06-24 05:04:42.001094
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-la'])
    assert args.command == ['ls', '-la']
    assert args.repeat == False

    args = parser.parse(['thefuck', '-r', 'ls', '-la'])
    assert args.command == ['ls', '-la']
    assert args.repeat == True

    args = parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, 'fuck', '-a'])
    assert args.command == ['ls', '-la']
    assert args.alias == 'fuck'

# Generated at 2022-06-24 05:04:45.245595
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import pytest
    import thefuck.main
    import logging
    import os
    import tempfile
    import sys
    import subprocess
    import filecmp

    thefuck.main.main(["--help"])


# Generated at 2022-06-24 05:04:55.420638
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck']) == Namespace(
        alias=True, command=None, debug=False, enable_experimental_instant_mode=False,
        force_command=None, help=False, repeat=False, shell_logger=None, version=False,
        yes=False)
    assert Parser().parse(['thefuck', 'ls']) == Namespace(
        alias=None, command=['ls'], debug=False, enable_experimental_instant_mode=False,
        force_command=None, help=False, repeat=False, shell_logger=None, version=False,
        yes=False)

# Generated at 2022-06-24 05:05:01.116539
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])

    assert parser.parse(['thefuck']) == parser.parse(['thefuck', '--'])
    assert parser.parse(['thefuck', '-r']).command == None
    assert parser.parse(['thefuck', '-r', 'vim']).command == None

    assert parser.parse(['thefuck', 'vim', 'sed', '-i']) == parser.parse(['thefuck', 'vim', 'sed', '-i', '--'])
    assert parser.parse(['thefuck', 'vim', 'sed', '-i']).command == ['vim', 'sed', '-i']

# Generated at 2022-06-24 05:05:09.957269
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    #  test case 1
    assert p.parse(['command 1','command 2','command 3','fuck']) ==\
        Namespace(command=['command', '1', 'command', '2', 'command', '3'],
                  debug=False, force_command=None, help=False,
                  shell_logger=None, yes=False, repeat=False,
                  enable_experimental_instant_mode=False, alias=None)
    # test case 2

# Generated at 2022-06-24 05:05:11.308054
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-24 05:05:20.108279
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.description is None
    assert parser._parser.epilog is None
    assert not parser._parser.add_help
    assert parser._parser.usage is None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.allow_abbrev
    assert not parser._parser.use_abbrev
    assert parser._parser._positionals == None
    assert parser._parser._optionals == None
    assert parser._parser._mutually_exclusive_groups == None
    assert parser._parser.convert_arg_line_to_args

# Generated at 2022-06-24 05:05:21.140837
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:05:22.152308
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    _parser = Parser()
    _parser.print_usage()


# Generated at 2022-06-24 05:05:28.848161
# Unit test for constructor of class Parser
def test_Parser():
    with patch('thefuck.shells.posix.and_', '&&'):
        assert Parser().parse([]) == Namespace(alias=get_alias(), debug=False,
                                               enable_experimental_instant_mode=False,
                                               force_command=None, help=False,
                                               repeat=False, shell_logger=None,
                                               version=False, yes=False, command=[])


# Generated at 2022-06-24 05:05:30.352375
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser


# Generated at 2022-06-24 05:05:39.773133
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([
        'thefuck', '--force-command', 'cd', 'cd', 'piyo']) == \
        parser._parser.parse_args(['--force-command', 'cd', 'cd', '--', 'piyo'])

    assert parser.parse([
        'thefuck', '--force-command', 'cd', '--', 'cd', 'piyo']) == \
        parser._parser.parse_args(['--force-command', 'cd', '--', 'cd', 'piyo'])


# Generated at 2022-06-24 05:05:43.666169
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-a']) == parser._parser.parse_args(['ls', '-a'])
    assert parser.parse(['thefuck', '--alias', 'fuck']) == parser._parser.parse_args(['--alias', 'fuck'])
    assert parser.parse(['thefuck', '--debug']) == parser._parser.parse_args(['--debug'])



# Generated at 2022-06-24 05:05:45.040323
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == parser.print_usage()



# Generated at 2022-06-24 05:05:55.516959
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['', '-v'])
    assert args.version

    parser = Parser()
    args = parser.parse(['', '-l', 'log_file'])
    assert args.shell_logger == 'log_file'

    parser = Parser()
    args = parser.parse(['', '-d'])
    assert args.debug

    parser = Parser()
    args = parser.parse(['', '--force-command', 'force_command'])
    assert args.force_command == 'force_command'

    parser = Parser()
    args = parser.parse(['', 'command'])
    assert args.command == ['command']

    parser = Parser()
    args = parser.parse(['', '-h'])
    assert args.help

# Generated at 2022-06-24 05:06:04.946864
# Unit test for constructor of class Parser
def test_Parser():
    p=Parser()
    #test if using arguement option '--help' will show help message
    if p._parser.parse_args(['--help']):
        p.print_help()
        assert True
    else:
        assert False
    #test if using arguement option '--version' will show version info
    if p._parser.parse_args(['--version']):
        assert p._parser.parse_args(['--version']) == '0.6.0'
    else:
        assert False
    #test if using arguement option '--alias' will get alias
    if p._parser.parse_args(['--alias']):
        assert p._parser.parse_args(['--alias']) == 'fuck'
    else:
        assert False
    #test if using arguement option '--enable

# Generated at 2022-06-24 05:06:15.506691
# Unit test for constructor of class Parser
def test_Parser():
    from .const import VERSION
    parser = Parser()
    parsed_result = parser.parse(['fuck', '-v'])
    assert parsed_result.version
    assert not parsed_result.help
    assert not parsed_result.alias
    assert not parsed_result.yeah
    assert not parsed_result.debug
    parsed_result = parser.parse(['fuck', '-a'])
    assert not parsed_result.version
    assert not parsed_result.help
    assert parsed_result.alias == 'fuck'
    assert not parsed_result.yeah
    assert not parsed_result.debug
    parsed_result = parser.parse(['fuck', '-a', 'fucker'])
    assert not parsed_result.version
    assert not parsed_result.help
    assert parsed_result.alias == 'fucker'

# Generated at 2022-06-24 05:06:20.563125
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    parser._parser.print_help()
    sys.stdout.seek(0)
    result = sys.stdout.read()
    sys.stdout = old_stdout
    assert result[-11:-1] == '[custom-alias-name]'


# Generated at 2022-06-24 05:06:22.227300
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-24 05:06:23.648180
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() != None

# test_Parser_print_usage function test for method print_usage of class Parser

# Generated at 2022-06-24 05:06:25.330546
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:06:32.434380
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-y']
    parser = Parser()
    args = parser.parse(argv)
    assert str(args.command) == "['ls', '-la']"
    assert args.yes == True
    assert args.repeat == False


# Generated at 2022-06-24 05:06:33.647033
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-24 05:06:41.901202
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    assert parser.parse(['thefuck', 'totally', 'broken', 'command']) == \
        Namespace(alias=None, debug=False, enable_experimental_instant_mode=False,
                  force_command=None, help=False, repeat=False, shell_logger=None,
                  version=False, yeah=False,
                  command=['totally', 'broken', 'command'])

    assert parser.parse(['thefuck', '-v']) == \
        Namespace(alias=None, debug=False, enable_experimental_instant_mode=False,
                  force_command=None, help=False, repeat=False, shell_logger=None,
                  version=True, yeah=False, command=[])


# Generated at 2022-06-24 05:06:42.728747
# Unit test for constructor of class Parser
def test_Parser():
    test = Parser()


# Generated at 2022-06-24 05:06:44.295104
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert parser

# Generated at 2022-06-24 05:06:46.735389
# Unit test for method print_help of class Parser
def test_Parser_print_help():
   parser = Parser()
   parser.print_help()

if __name__ == '__main__':
   test_Parser_print_help()

# Generated at 2022-06-24 05:06:50.767390
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck','vim','--','hello','world'])
    parser.parse(['thefuck','vim','--','hello','world'])
    parser.parse(['thefuck','vim','&','hello','world'])

# Generated at 2022-06-24 05:06:52.348914
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(["", "-h"])

# Generated at 2022-06-24 05:06:53.360236
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-24 05:06:54.825175
# Unit test for constructor of class Parser
def test_Parser():
    Parser()
    assert True

# Generated at 2022-06-24 05:06:58.452446
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().parse(['thefuck', '-v']) == Parser().parse(['thefuck', '--version'])
    assert Parser().parse(['thefuck', '-a']) == Parser().parse(['thefuck', '--alias'])


# Generated at 2022-06-24 05:07:01.692471
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    return p


# Generated at 2022-06-24 05:07:05.496422
# Unit test for method parse of class Parser
def test_Parser_parse():
    # To get a command line argument for usage in parse
    parser = Parser()
    # To get output into the terminal
    args = parser.parse(['--shell-logger', 'test_logger'])
    assert args.shell_logger == 'test_logger'


# Generated at 2022-06-24 05:07:07.035232
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        pass

# Generated at 2022-06-24 05:07:10.739259
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    _Parser = Parser()
    _Parser.print_usage()


# Generated at 2022-06-24 05:07:13.396787
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    return True

# Generated at 2022-06-24 05:07:23.641282
# Unit test for method parse of class Parser
def test_Parser_parse():
    a=Parser()
    assert a.parse(['fuck','git','commit'])
    assert a.parse(['fuck','git','commit','aaa'])
    assert a.parse(['fuck','git','commit','aaa','-v'])
    assert a.parse(['fuck','git','commit','aaa','-v'])
    assert a.parse(['fuck','git','commit','aaa','-y'])
    assert a.parse(['fuck','git','commit','aaa','-r'])
    assert a.parse(['fuck','git','commit','aaa','-d'])
    assert a.parse(['fuck','git','commit','aaa','-l'])
    assert a.parse(['fuck','git','commit','aaa','--force-command'])

# Generated at 2022-06-24 05:07:25.404055
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    return parser



# Generated at 2022-06-24 05:07:28.148636
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert "usage: thefuck" in Parser().print_usage()

# Generated at 2022-06-24 05:07:33.909487
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    stderr = sys.stderr
    try:
        from cStringIO import StringIO
        sys.stderr = mystderr = StringIO()
        p = Parser()
        p.print_help()
        output = mystderr.getvalue()
        if 'Debug output' not in output or 'Execute fixed command without confirmation' not in output:
            return False
        else:
            return True
    finally:
        sys.stderr = stderr

# Generated at 2022-06-24 05:07:35.194877
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:07:36.355513
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Parser().print_usage()
    print("argparser")

# Generated at 2022-06-24 05:07:40.229321
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_print = parser.print_help()
    assert isinstance(help_print, type(''))
    assert parser.print_help == parser._parser.print_help

# Generated at 2022-06-24 05:07:43.375845
# Unit test for constructor of class Parser
def test_Parser():
    parser=Parser()
    print(parser)

# Generated at 2022-06-24 05:07:53.858055
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    stderr = sys.stderr
    sys.stderr = StringIO()
    parser = Parser()
    parser.print_help()
    string = sys.stderr.getvalue()
    sys.stderr = stderr

# Generated at 2022-06-24 05:07:55.265135
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_usage() == None

# Generated at 2022-06-24 05:08:05.509252
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Command without arguments
    actual = parser.parse(['thefuck'])
    assert actual.version is False
    assert actual.alias is None
    assert actual.yes is False
    assert actual.repeat is False
    assert actual.debug is False
    assert actual.command == []

    # Command with arguments
    actual = parser.parse(['thefuck', 'arg1', 'arg2'])
    assert actual.version is False
    assert actual.alias is None
    assert actual.yes is False
    assert actual.repeat is False
    assert actual.debug is False
    assert actual.command == ['arg1', 'arg2']

    # Version
    actual = parser.parse(['thefuck', '-v'])
    assert actual.version is True
    assert actual.alias is None

# Generated at 2022-06-24 05:08:06.730206
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:08:17.405411
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .which import which

    parser = Parser()
    argv = ['./thefuck', 'sudo', 'which']
    command = parser.parse(argv).command
    assert command[0] == which('sudo')[0]
    assert command[1:] == ['which']

    argv = ['./thefuck', '-r', 'sudo', 'which']
    command = parser.parse(argv).command
    assert command[0] == which('sudo')[0]
    assert command[1:] == ['which']

    argv = ['./thefuck', ARGUMENT_PLACEHOLDER, '--', 'sudo', 'which']
    command = parser.parse(argv).command
    assert command[0] == which('sudo')[0]
    assert command[1:] == ['which']

    arg

# Generated at 2022-06-24 05:08:25.216671
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Parameters:
    #     -v
    # Expected parse_args output:
    #     Namespace(alias=None, command=[], debug=False, help=False, repeat=False, shell_logger=None, version=True, yes=False)
    # Expected output:
    #     ['fuck', '-v']
    parser = Parser()
    args = parser.parse(['fuck', '-v'])
    assert args.version
    assert not args.command
    assert not args.debug
    assert not args.help
    assert not args.repeat
    assert not args.shell_logger
    assert not args.yes
    assert not args.alias

    # Parameters:
    #     -a
    # Expected parse_args output:
    #     Namespace(alias='fuck', command=[], debug=False,

# Generated at 2022-06-24 05:08:36.834795
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER
    opt = Parser().parse('ls --all -v'.split())
    assert opt.command == 'ls --all -v'.split()
    assert opt.version is False
    assert opt.alias is get_alias()
    assert opt.shell_logger is None
    assert opt.help is False
    assert opt.yes is False
    assert opt.repeat is False
    opt = Parser().parse('ls --all -v'.split() + [ARGUMENT_PLACEHOLDER])
    assert opt.command == 'ls --all -v'.split()
    assert opt.version is False
    assert opt.alias is get_alias()
    assert opt.shell_logger is None
    assert opt.help is  False

# Generated at 2022-06-24 05:08:42.896754
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from . import settings
    from .utils import run_popen
    from .main import main
    from .const import DEFAULT_SETTINGS_PATH

    settings.load(DEFAULT_SETTINGS_PATH)
    settings.clear_history()

    parser = Parser()

    stdout, stderr = run_popen('thefuck -h')
    assert stderr
    assert 'usage: ' in stderr
    assert len(stdout) == 0

    stdout, stderr = run_popen('thefuck --help')
    assert stderr
    assert 'usage: ' in stderr
    assert len(stdout) == 0

    stdout, stderr = run_popen('thefuck -a alias')
    assert stderr
    assert 'usage: ' in stderr
    assert len

# Generated at 2022-06-24 05:08:53.852002
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from . import __version__
    from .parser import Parser

    class StderrMock:
        def __init__(self):
            self.result = ''
        def write(self, s):
            self.result += s

    stderr = StderrMock()
    sys.stderr = stderr


# Generated at 2022-06-24 05:08:57.014225
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # print the help page
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:09:06.148005
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import StringIO
    import sys
    output = StringIO.StringIO()
    old_stderr = sys.stderr
    sys.stderr = output
    parser = Parser()
    parser.print_help()
    sys.stderr = old_stderr

# Generated at 2022-06-24 05:09:07.000565
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:09:07.871250
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:09:14.223190
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'git', 'log'])
    assert(arguments.command == ['git', 'log'])

    arguments = parser.parse(['thefuck', 'git', 'log', ARGUMENT_PLACEHOLDER, '-p'])
    assert(arguments.command == ['git', 'log', '-p'])

    arguments = parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'git', 'log'])
    assert(arguments.command == ['git', 'log'])


# Generated at 2022-06-24 05:09:17.543312
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help = parser.print_help
    out, err = capsys.readouterr()
    assert help == parser._parser.print_help

# Generated at 2022-06-24 05:09:21.920201
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias
    from .parser import Parser
    parser = Parser()
    test_list = [ARGUMENT_PLACEHOLDER, get_alias(), '-y', '-r', '-d', '--']
    parser.print_usage()
    assert parser.parse(test_list)


# Generated at 2022-06-24 05:09:24.108118
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest.mock import patch
    with patch('sys.stderr') as stderr:
        Parser().print_usage()
        assert stderr.write.called


# Generated at 2022-06-24 05:09:26.901139
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    arg_parser = Parser()
    args = arg_parser.parse(['fuck', 'ls', '-la'])
    assert args.command == ['ls', '-la']
    assert args.yes == False
    assert args.repeat == False
    assert args.alias is None


# Generated at 2022-06-24 05:09:29.029820
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['thefuck', '-v'])
    assert(result.version == True)
    assert(result.debug == False)


# Generated at 2022-06-24 05:09:33.780738
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import os
    import io

    saved_stderr = sys.stderr
    try:
        out = io.StringIO()
        sys.stderr = out
        Parser().print_usage()
        output = out.getvalue().strip()
    finally:
        sys.stderr = saved_stderr
    assert output == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n                 [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n                 [-y|-r]\n                 [command [command ...]]"


# Generated at 2022-06-24 05:09:43.143761
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Parser is a class which divides the arguments inputted
    # by user into four types and return them in a Namespace object
    parser = Parser()
    #print parser.parse(['-h'])
    #print parser.parse(['--version'])
    #print parser.parse(['-v'])
    #print parser.parse(['-a', 'fuck'])
    #print parser.parse(['-l', '~/tmp.log'])
    #print parser.parse(['-d'])
    #print parser.parse(['-y'])
    #print parser.parse(['-r'])
    #print parser.parse(['--fuck', 'fuck'])
    #parser.print_usage()
    #parser.print_help()
    return 0


# Generated at 2022-06-24 05:09:52.240261
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    stdout = sys.stderr
    sys.stderr = StringIO()
    try:
        parser = Parser()
        parser.print_usage()
        assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [CUSTOM-ALIAS-NAME]] [-l SHELL-LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE-COMMAND] [--] [command [command ...]]\n'
    finally:
        sys.stderr = stdout


# Generated at 2022-06-24 05:10:02.226060
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['/path/to/fuck', 'ls']) == \
        argparse.Namespace(command=['ls'], enable_experimental_instant_mode=False, alias=None, debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    assert Parser().parse(['/path/to/fuck', 'ls', '-l', '-a']) == \
        argparse.Namespace(command=['ls', '-l', '-a'], enable_experimental_instant_mode=False, alias=None, debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)