

# Generated at 2022-06-24 04:59:57.259443
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:00:00.350818
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Check if the method print_help of Parser class is working properly
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:00:09.691101
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import SHELL_LOGGER, ENABLE_EXPERIMENTAL_INSTANT_MODE
    from .utils import suppress_output

    with suppress_output() as (out, _):
        Parser().print_usage()

    out.seek(0)

    output = out.read()
    assert '[-h] [-v] [-a [custom-alias-name]]' in output
    assert '-l {0} [-y | -r]'.format(SHELL_LOGGER) in output
    assert '[--enable-experimental-instant-mode]' in output
    assert '[--force-command] [-d] [--] [command [command ...]]' in output


# Generated at 2022-06-24 05:00:19.612564
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

    # no argument
    assert p.parse([]) == p.parse(['thefuck']) == []

    # unknown argument
    assert p.parse(['thefuck', '--unknown']) == ['--', '--unknown']

    # `-a` argument
    assert p.parse(['thefuck', '-a']) == ['--', '-a', '--alias']
    assert p.parse(['thefuck', '--alias']) == ['--', '--alias']

    # `-h` argument
    assert p.parse(['thefuck', '-h']) == ['--', '-h', '--help']
    assert p.parse(['thefuck', '--help']) == ['--', '--help']

    # arguments after placeholder

# Generated at 2022-06-24 05:00:25.654217
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'echo']) == \
        parser._parser.parse_args(['echo'])
    assert parser.parse(['thefuck', 'echo', 'helloworld']) == \
        parser._parser.parse_args(['--', 'echo', 'helloworld'])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'echo']) == \
        parser._parser.parse_args(['echo'])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'echo', 'helloworld']) == \
        parser._parser.parse_args(['--', 'echo', 'helloworld'])

# Generated at 2022-06-24 05:00:37.375261
# Unit test for constructor of class Parser
def test_Parser():
    args = Parser()
    assert args.parse(['thefuck', '--version']).command == []
    assert args.parse(['thefuck', '--alias', 'fuck']).command == []
    assert args.parse(['thefuck', '--shell-logger', 'shell_logger']).command == []
    assert args.parse(['thefuck', '--enable-experimental-instant-mode']).command == []
    assert args.parse(['thefuck', '--help']).command == []
    assert args.parse(['thefuck', '--debug']).command == []
    assert args.parse(['thefuck', '--force-command', 'force-command']).command == []
    assert args.parse(['thefuck', 'command']).command == ['command']

# Generated at 2022-06-24 05:00:46.561943
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    assert parser.parse(['thefuck', 'echo']) == \
        parser.parse(['thefuck', 'echo', '--'])

    assert parser.parse(['thefuck', '-n', 'echo']) == \
        parser.parse(['thefuck', '-n', 'echo', '--'])

    assert parser.parse(['thefuck', '--no-colors', 'echo']) == \
        parser.parse(['thefuck', '--no-colors', 'echo', '--'])

    assert parser.parse(['thefuck', '--', 'echo']) == \
        parser.parse(['thefuck', '--', 'echo', '--'])


# Generated at 2022-06-24 05:00:49.905616
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    #call the method and then test if it printed anything to the stderr
    assert sys.stderr.getvalue() != "", "usage not printed to the stderr"


# Generated at 2022-06-24 05:00:52.114102
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False



# Generated at 2022-06-24 05:00:55.387172
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True

# Generated at 2022-06-24 05:00:57.715125
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-24 05:00:59.520813
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert(parser.print_usage()) == parser._parser.print_usage(sys.stderr)

# Generated at 2022-06-24 05:01:02.516872
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-24 05:01:08.908858
# Unit test for constructor of class Parser
def test_Parser():
    from .const import ARGUMENT_PLACEHOLDER
    p = Parser()
    args = p.parse(['thefuck', '-v', ARGUMENT_PLACEHOLDER, 'python', '-c', 'print(2)'])
    assert args.version == True
    assert args.command == ['python', '-c', 'print(2)']
    try:
        p.parse(['thefuck', '-r', '-y'])
        assert False
    except SystemExit:
        pass
    p.print_usage()
    p.print_help()

# Generated at 2022-06-24 05:01:14.426416
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import sys
    captureOutput = io.StringIO()
    sys.stderr = captureOutput
    p = Parser()
    p.print_help()
    sys.stderr = sys.__stderr__
    print("print_help:", captureOutput.getvalue())
    assert "usage: thefuck" in captureOutput.getvalue()


# Generated at 2022-06-24 05:01:15.675131
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-24 05:01:16.719783
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:01:18.472731
# Unit test for method parse of class Parser
def test_Parser_parse():
  print(Parser().parse([ "thefuck", "-l", "log_file" ]))


# Generated at 2022-06-24 05:01:23.942587
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # everything is ok
    parser.parse(['thefuck', 'git', 'stash'])

    # we are using our special placeholder
    parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'git', 'stash'])

    # we have arguments after placeholder
    parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-v', 'git', 'stash'])

    # we are not using our special placeholder, but just have arguments
    parser.parse(['thefuck', '-v', 'git', 'stash'])

# Generated at 2022-06-24 05:01:30.070617
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class StringIO(StringIO):
        def __init__(self):
            StringIO.__init__(self)
            self.shown = []
        def write(self, s):
            self.shown.append(s)
    io = StringIO()
    p = Parser()
    p.print_help()
    assert "usage:" in "".join(io.shown)

# Generated at 2022-06-24 05:01:32.387738
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-24 05:01:39.325833
# Unit test for method print_help of class Parser

# Generated at 2022-06-24 05:01:41.375014
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    def test_entries():
        COMMANDS = ['git', 'git commit', 'ls -l']
        parser = Parser()
        arguments = parser.parse(COMMANDS)
        assert arguments.command == COMMANDS
    test_entries()

# Generated at 2022-06-24 05:01:44.639879
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', '-l', '--', 'git', 'push', ARGUMENT_PLACEHOLDER, 'origin', 'master']) == \
        p.parse(['thefuck', '-l', '--', 'git', 'push', '--', 'origin', 'master'])



# Generated at 2022-06-24 05:01:52.120404
# Unit test for method parse of class Parser
def test_Parser_parse():
    P = Parser()
    assert (P.parse(['yeah', 'command', '-d']) ==
            Namespace(alias=False, debug=True, command=['command', '-d']))
    assert (P.parse(['yeah', 'command', '1', ARGUMENT_PLACEHOLDER, '2', '3']) ==
            Namespace(alias=False, debug=False, command=['3', '2', '1', 'command']))
    assert (P.parse(['yeah', 'command', '1', ARGUMENT_PLACEHOLDER, '2', '3', '-d']) ==
            Namespace(alias=False, debug=True, command=['3', '2', '1', 'command']))

# Generated at 2022-06-24 05:01:55.241691
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import StringIO
    mystdout = StringIO.StringIO()
    sys.stderr = mystdout
    parser = Parser()
    parser.print_help()
    sys.stderr = sys.__stderr__
    help_msg = mystdout.getvalue()
    assert help_msg and len(help_msg) > 0

# Generated at 2022-06-24 05:02:05.982841
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == \
        parser._parser.parse_args(['--', 'ls'])
    assert parser.parse(['thefuck',  '&&', 'yes', 'ls']) == \
        parser._parser.parse_args(['--',  '&&', 'yes', 'ls'])

    assert parser.parse(['thefuck',  '&&', 'yes', 'ls']) == \
        parser._parser.parse_args(['--',  '&&', 'yes', 'ls'])

    assert parser.parse(['thefuck',  '&&', 'yes', 'ls']) == \
        parser._parser.parse_args(['--',  '&&', 'yes', 'ls'])


# Generated at 2022-06-24 05:02:14.631425
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Without placeholder
    assert parser.parse(['thefuck', 'ls', '-a']) == \
           parser._parser.parse_args(['--', 'ls', '-a'])
    # With placeholder
    assert parser.parse(['thefuck', 'sudo', '$', '-a']) == \
           parser._parser.parse_args(['-a'])
    # With placeholder but without arguments after
    assert parser.parse(['thefuck', 'sudo', '$']) == \
           parser._parser.parse_args([])
    # With placeholder but without arguments before
    assert parser.parse(['thefuck', '$', '-a']) == \
           parser._parser.parse_args(['-a'])
    # With placeholder but without arguments before and after
    assert parser.parse

# Generated at 2022-06-24 05:02:20.491037
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import is_alias_in_text
    from .const import PROGRAM
    from . import get_version
    parser = Parser()
    parser.print_usage()
    assert is_alias_in_text(parser._parser.format_usage())
    assert PROGRAM in parser._parser.format_usage()
    assert get_version() in parser._parser.format_usage()


# Generated at 2022-06-24 05:02:22.642278
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser=Parser()
    parser.print_usage()
    assert True #If it runs, it passes the test :)



# Generated at 2022-06-24 05:02:29.594816
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    from StringIO import StringIO
    import sys

    output = StringIO()
    sys.stderr = output
    parser.print_usage()
    assert output.getvalue().strip() == 'usage: thefuck [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-h] [-d] [--force-command force-command] [command [command ...]]'
    output.close()

# Generated at 2022-06-24 05:02:34.832626
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse("thefuck --enable-experimental-instant-mode -- yeah ls -la".split(" ")) == parser.parse("thefuck --yeah --enable-experimental-instant-mode ls -la".split(" "))

# Generated at 2022-06-24 05:02:40.623884
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import StringIO

    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()

    parser = Parser()
    parser.print_usage()
    output = sys.stdout.getvalue()

    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] '\
                     '[-l SHELL_LOGGER] [--enable-experimental-instant-mode] '\
                     '[-y] [-r] [-d] [--force-command FORCE_COMMAND] '\
                     '[command [command ...]]\n'

    sys.stdout = stdout


# Generated at 2022-06-24 05:02:41.720239
# Unit test for constructor of class Parser
def test_Parser():
    """
    Check for dummy
    """
    parser = Parser()

# Generated at 2022-06-24 05:02:50.376592
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out, err = capsys.readouterr()
    parser.print_usage()
    out, err = capsys.readouterr()
    assert err == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'\
                  '                [-l SHELL_LOGGER]\n'\
                  '                [--enable-experimental-instant-mode]\n'\
                  '                [-y] [-r] [-d] [--force-command FORCE_COMMAND]\n'\
                  '                [command [command ...]]\n'


# Generated at 2022-06-24 05:02:54.412294
# Unit test for method parse of class Parser
def test_Parser_parse():
    sys.argv = ['thefuck', '-a','echo','hello','world','thefuck','--', 'fuck', 'this']
    argv = Parser().parse(sys.argv)
    assert argv.alias == 'echo'
    assert argv.command == ['hello','world','fuck', 'this']

# Generated at 2022-06-24 05:03:03.296699
# Unit test for method parse of class Parser
def test_Parser_parse():
    class Args: pass

    assert Parser().parse(
        ['']).command == []
    assert Parser().parse(
        ['']).yeah is False
    assert Parser().parse(
        ['']).repeat is False
    assert Parser().parse(
        ['']).debug is False
    assert Parser().parse(
        ['']).force_command is None
    assert Parser().parse(
        ['', '-d']).command == []
    assert Parser().parse(
        ['', '-d']).yeah is False
    assert Parser().parse(
        ['', '-d']).repeat is False
    assert Parser().parse(
        ['', '-d']).debug is True
    assert Parser().parse(
        ['', '-d']).force_command is None

# Generated at 2022-06-24 05:03:12.015255
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['script-name', "command", ARGUMENT_PLACEHOLDER, "-d", "arg1", "arg2"]) == \
        p.parse(['script-name', "-d", "arg1", "arg2", "--", "command"])
    assert p.parse(['script-name', "command", ARGUMENT_PLACEHOLDER, "-d", "arg1", "arg2"]) == \
        p.parse(['script-name', "command", ARGUMENT_PLACEHOLDER, "-d", "arg1", "arg2"])

# Generated at 2022-06-24 05:03:22.760358
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['scripts/thefuck', '-l', '/log/file']) \
            == ArgumentParser().parse_args(['-l', '/log/file'])
    assert Parser().parse(['scripts/thefuck', '-l', '/log/file',
                           ARGUMENT_PLACEHOLDER, '-v']) \
            == ArgumentParser().parse_args(['-v', '-l', '/log/file'])
    assert Parser().parse(['scripts/thefuck', '--shell-logger',
                           '/log/file', '-v', ARGUMENT_PLACEHOLDER, '-y']) \
            == ArgumentParser().parse_args(['-v', '-y', '--shell-logger',
                                            '/log/file'])

# Generated at 2022-06-24 05:03:31.886612
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    sys.argv = ['thefuck']
    parser = Parser()
    help_output = parser.print_help()
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]' in help_output
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]' in help_output
    assert '[custom-alias-name] prints alias for current shell' in help_output
    assert 'command that should be fixed' in help_output
    assert 'show this help message and exit' in help_output

    sys.argv = ['thefuck', '--help']
    parser = Parser()
    help_output = parser.print_help()

# Generated at 2022-06-24 05:03:33.419242
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    # Nothing to test here


# Generated at 2022-06-24 05:03:36.977568
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    out, sys.stderr = sys.stderr, StringIO()
    Parser().print_usage()
    assert 'usage: thefuck' in sys.stderr.getvalue()
    sys.stderr = out


# Generated at 2022-06-24 05:03:39.231062
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.parse(['fuck', 'date']) == parser._parser.parse_args(['--', 'date'])


# Generated at 2022-06-24 05:03:40.643796
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser.parse(['thefuck']) == None)



# Generated at 2022-06-24 05:03:48.986101
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'git']) == parser._parser.parse_args([])
    assert parser.parse(
        ['thefuck', 'git', ARGUMENT_PLACEHOLDER, 'ls', '-lia']) == \
        parser._parser.parse_args(['ls', '-lia'])
    assert parser.parse(['thefuck', 'git', 'ls', '-lia']) == \
        parser._parser.parse_args(['--', 'ls', '-lia'])

# Generated at 2022-06-24 05:03:49.763423
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    args = Parser()
    args.print_help()

# Generated at 2022-06-24 05:03:51.264492
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert str(parser) == '<Parser>'



# Generated at 2022-06-24 05:03:55.609209
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:03:59.480817
# Unit test for constructor of class Parser
def test_Parser():
    thefuck.set_logger(thefuck.utils.create_logger())
    instance = thefuck.main.ArgumentHandler.create()
    assert isinstance(instance, Parser)

# Generated at 2022-06-24 05:04:05.486447
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    make sure every line of Parser.print_help() starts with "usage:"
    """
    from io import StringIO
    from contextlib import redirect_stdout
    f=StringIO()
    with redirect_stdout(f):
        Parser().print_help()
        print(f.getvalue().split("\n")[0])
        assert f.getvalue().split("\n")[0].startswith("usage:"), "usage:"+str(f.getvalue())

# Generated at 2022-06-24 05:04:11.670579
# Unit test for constructor of class Parser
def test_Parser():
    from .const import VERSION
    p = Parser()
    assert p._parser.prog == "thefuck"
    assert p._parser._actions[-1].dest == "version"
    assert p._parser._actions[-1].const == VERSION
    assert p._parser._actions[-1].nargs == 0
    assert p._parser._actions[-1].default == False
    assert p._parser._actions[-1].option_strings == ["-v", "--version"]
    assert p._parser._actions[-1].help.split(" ")[0] == "show"



# Generated at 2022-06-24 05:04:17.487631
# Unit test for constructor of class Parser
def test_Parser():
    def test(arg): return Parser().parse(arg)
    assert test(['--version'])
    assert test(['--alias'])
    assert test(['--alias', 'f'])
    assert test(['--enable-experimental-instant-mode'])
    assert test(['--help'])
    assert test(['--yes'])
    assert test(['--repeat'])
    assert test(['--debug'])
    assert test(['--force-command', 'fuck'])
    assert test(['fuck'])
    assert test(['--', 'fuck'])


# Generated at 2022-06-24 05:04:27.033074
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    
    # Test the output of parser
    assert parser.parse(['-v']) == -v, "Should be -v"
    assert parser.parse(['-a']) == -a, "Should be -a"
    assert parser.parse(['-l']) == -l, "Should be -l"
    assert parser.parse(['--enable-experimental-instant-mode']) == --enable-experimental-instant-mode, "Should be --enable-experimental-instant-mode"
    assert parser.parse(['-h'] or ['--help']) == -h, "Should be -h"
    assert parser.parse(['-y']) == -y, "Should be -y"
    assert parser.parse(['-r']) == -r, "Should be -r"

# Generated at 2022-06-24 05:04:37.345582
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-a', 'fuck']) == \
        parser._parser.parse_args(['-a', 'fuck'])
    assert parser.parse(['thefuck', '-v']) == \
        parser._parser.parse_args(['-v'])
    assert parser.parse(['thefuck', '-l']) == \
        parser._parser.parse_args(['-l'])
    assert parser.parse(['thefuck', 'ls', '-lh', '-d']) == \
        parser._parser.parse_args(['ls', '-lh', '-d'])
    assert parser.parse(['thefuck', 'ls', '-lh', '-d', '-a']) == \
        parser._parser.parse_args

# Generated at 2022-06-24 05:04:45.350750
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[2].option_strings == ['-l', '--shell-logger']
    assert parser._parser._actions[3].option_strings == ['-h', '--help']
    assert parser._parser._actions[4].option_strings == ['-d', '--debug']
    assert parser._parser._actions[5].option_strings == ['--force-command']
    assert parser._parser._actions[6].option_strings == ['command']


# Generated at 2022-06-24 05:04:48.667134
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Check if no error occurs, when print_usage is called.
    parser.print_usage()


# Generated at 2022-06-24 05:04:51.156869
# Unit test for method parse of class Parser
def test_Parser_parse():
    # test_Parser_parse
    Parser().parse(['thefuck', '--help'])
    Parser().parse(['thefuck', '-h'])

# Generated at 2022-06-24 05:04:58.406273
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # 1. Test for situation when ARGUMENT_PLACEHOLDER is in arguments,
    # and then special arguments are moved to the beginning of the
    # arguments.

    # Test case 1.1: only special arguments before place holder.
    argv = ["-y", "-r", "-h", ARGUMENT_PLACEHOLDER, "ls", "cd"]
    expected_parsed_arguments = ["-y", "-r", "-h", "--", "ls", "cd"]
    assert (parser.parse(argv).__dict__["_get_args"]()
            == parser._parser.parse_args(expected_parsed_arguments).__dict__["_get_args"]())

    # Test case 1.2: special arguments and common arguments before placeholder.

# Generated at 2022-06-24 05:05:08.910579
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    from itertools import islice

    # In case stdout is sys.stdout, preserve it because print_help() prints
    # its content to sys.stderr.
    real_output = sys.stdout
    sys.stdout = StringIO()

    parser = Parser()
    parser.print_help()

    # Capture stdout
    output = sys.stdout
    sys.stdout = real_output

    # Helper function to test every line
    def lines(string):
        return (line for line in string.split('\n'))

    # Delete empty lines
    lines_iter = (line for line in lines(output.getvalue()) if line)

# Generated at 2022-06-24 05:05:09.781276
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-24 05:05:18.897291
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-a', 'alias', '--', 'command']) == \
           parser.parse(['thefuck', ARGUMENT_PLACEHOLDER + '', '--alias=alias',
                         'command'])

    assert parser.parse(['thefuck', '-a', '--', 'command']) == \
           parser.parse(['thefuck', ARGUMENT_PLACEHOLDER + '', '--alias',
                         'command'])

    assert parser.parse(['thefuck', 'command']) == \
           parser.parse(['thefuck', ARGUMENT_PLACEHOLDER + '', 'command'])


# Generated at 2022-06-24 05:05:23.627014
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    target_usage = "usage: thefuck [-h] [-v] [-a [" + get_alias() + "]]" + \
            " [-l SHELL_LOGGER] [--enable-experimental-instant-mode]" + \
            " [-d] [--force-command FORCE_COMMAND]" + \
            " [--yes | --repeat] [--] command" + \
            " [command ...]"
    assert parser.print_usage() == target_usage


# Generated at 2022-06-24 05:05:25.221481
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:05:27.097164
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.parse(['-h'])



# Generated at 2022-06-24 05:05:37.577505
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # If the no arguments
    assert parser.parse([]) == parser._parser.parse_args([]), "The behavior is not correct if the no arguments"
    # If the argument is not "thefuck"

# Generated at 2022-06-24 05:05:39.543808
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.description is None

# Generated at 2022-06-24 05:05:45.219510
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    actual_string = parser.parse(['thefuck','pwd','arg_place','arg1','arg2','arg3']).command
    expected_string = ['pwd', 'arg1', 'arg2', 'arg3']
    assert actual_string == expected_string
    actual_string = parser.parse(['thefuck','input_command']).command
    expected_string = ['input_command']
    assert actual_string == expected_string
    actual_string = parser.parse(['thefuck']).command
    expected_string = []
    assert actual_string == expected_string

# Generated at 2022-06-24 05:05:46.855410
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser



# Generated at 2022-06-24 05:05:51.851983
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    arg = Parser()
    out = StringIO()
    sys.stderr = out
    arg.print_usage()
    sys.stderr.seek(0)
    assert sys.stderr.read() == 'usage: thefuck [-h] [-v] [-l SHELL_LOGGER]\n'



# Generated at 2022-06-24 05:05:59.143675
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .tests.utils import TestCase, Mock

    class TestParser(TestCase):
        def setUp(self):
            self.parser = Parser()

        def test_prints_help(self):
            parser = Parser()
            sys.stderr.write = Mock()

            parser.print_help()

            sys.stderr.write.assert_called_once_with(parser._parser.format_help())

# Generated at 2022-06-24 05:06:03.811285
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except:
        raise AssertionError("Problem with print_usage method")


# Generated at 2022-06-24 05:06:04.911508
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-24 05:06:09.432736
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    # The output is difficult to assert
    assert True


# Generated at 2022-06-24 05:06:13.751606
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest.mock import patch
    from io import StringIO
    capture = StringIO()
    with patch('sys.stderr', capture):
        Parser().print_usage()
    assert capture.getvalue() == usage_text + '\n'


# Generated at 2022-06-24 05:06:19.377879
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    f = io.StringIO()
    with mock.patch("sys.stderr", new=f):
        parser.print_usage()
    assert f.getvalue() ==  "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n                [--enable-experimental-instant-mode] [-d]\n                [--force-command FORCE_COMMAND]\n                [--yes | --repeat] [command [command ...]]\n"

# Generated at 2022-06-24 05:06:28.956385
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    from argparse import Namespace
    parser = Parser()
    assert parser.parse(['du', '--help']) == Namespace(
        alias=None,
        command=['--help'],
        debug=False,
        enable_experimental_instant_mode=False,
        force_command=None,
        help=False,
        repeat=False,
        shell_logger=None,
        version=False,
        yes=False)

# Generated at 2022-06-24 05:06:38.243130
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    test_argv1 = ['thefuck', 'python', 'asdf.py']
    test_argv2 = ['thefuck', '-l', 'log', 'python', 'asdf.py']
    test_argv3 = ['thefuck', '-l', 'log', '-h', 'python', 'asdf.py']
    test_argv4 = ['thefuck', '-h', 'python', 'asdf.py']
    test_argv5 = ['thefuck', '-a', 'python', 'asdf.py']
    test_argv6 = ['thefuck', '-a', 'fuck', 'python', 'asdf.py']
    test_argv7 = ['thefuck', 'asdf.py']

# Generated at 2022-06-24 05:06:38.787360
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()

# Generated at 2022-06-24 05:06:47.353059
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result_std = parser.parse(['thefuck', 'ls', '-l', '-h', '-a'])
    result_with_placeholder = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l', '-h', '-a'])
    result_with_force_command = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l', '-h', '-a', '--force-command', 'ls'])
    assert result_std.command == ['ls']
    assert result_std.alias is None
    assert result_std.shell_logger is None
    assert result_std.enable_experimental_instant_mode is False
    assert result_std.help is False
   

# Generated at 2022-06-24 05:06:58.348856
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-r']) == \
        parser._parser.parse_args(['-r'])
    assert parser.parse(['thefuck', '-v']) == \
        parser._parser.parse_args(['-v'])
    assert parser.parse(['thefuck', 'ls']) == \
        parser._parser.parse_args(['--', 'ls'])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args([])

# Generated at 2022-06-24 05:07:01.306268
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-24 05:07:03.044368
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    _parser = ArgumentParser(prog='thefuck')
    _parser.print_usage(sys.stderr)

# Generated at 2022-06-24 05:07:08.244682
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class ParserStub(Parser):
        def _print_usage(self):
            args = ['-v', '-h', '-d', 'command']
            self._parser.print_usage(args)
    parser = ParserStub()
    print(parser)
    return parser


# Generated at 2022-06-24 05:07:18.209028
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['./fuck.py', 'git', 'commit']) == \
        parser.parse(['./fuck.py', 'git', 'commit', '{}'])
    assert parser.parse(['./fuck.py', 'git', 'commit']) == \
        parser.parse(['./fuck.py', 'git', 'commit', '', '-m', 'message'])
    assert parser.parse(['./fuck.py', 'git', 'commit', '-m', 'message']) == \
        parser.parse(['./fuck.py', 'git', 'commit', '{}', '-m', 'message'])

# Generated at 2022-06-24 05:07:22.449907
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Check correct output of method print_usage of class Parser"""
    parser = Parser()
    stdout = sys.stdout
    stream = cStringIO.StringIO()
    try:
        sys.stdout = stream
        parser.print_usage()
        output = stream.getvalue()
    finally:
        sys.stdout = stdout
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n                  [--enable-experimental-instant-mode] [-d] [-y | -r]\n                  [--force-command FORCE_COMMAND] [--] [command [command ...]]\n', 'method print_usage of class Parser is not correct'


# Generated at 2022-06-24 05:07:25.172801
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()


# Generated at 2022-06-24 05:07:28.048712
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None


# Generated at 2022-06-24 05:07:32.680980
# Unit test for constructor of class Parser
def test_Parser():
    test_parser = Parser()
    assert len(test_parser._parser._actions) == 12
    assert test_parser._parser._actions[0].dest == 'version'
    assert test_parser._parser._actions[0]._long_opts == ['--version']
    assert test_parser._parser._actions[0]._short_opts == ['-v']



# Generated at 2022-06-24 05:07:38.982392
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', '-v'])
    parser.parse(['thefuck', '-a'])
    parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-t'])
    parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-t'])
    parser.parse(['thefuck', 'ls', '-l'])

# Generated at 2022-06-24 05:07:43.489627
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = parser._prepare_arguments(
        [
            'thefuck',
            ARGUMENT_PLACEHOLDER,
            '-l',
            'log-file',
            'ls',
            '--help'
        ])
    args = parser._parser.parse_args(argv)
    assert args.shell_logger == "log-file"
    assert args.command == ['ls', '--help']
    parser.print_help()

# Generated at 2022-06-24 05:07:50.593713
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    argv = ["thefuck", ARGUMENT_PLACEHOLDER, "--", "yes", "no"]
    p = Parser()
    parsed = p.parse(argv)
    assert (parsed.command == ["yes", "no"])
    assert (parsed.shell_logger is None)
    assert (parsed.debug is False)
    assert (parsed.force_command is None)

# Generated at 2022-06-24 05:07:57.887306
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.parse(['git', 'commit', ARGUMENT_PLACEHOLDER, '-m', 'Fixed'])
    output = StringIO()
    sys.stderr = output
    parser.print_usage()
    assert output.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n'
    sys.stderr.close()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:08:06.770547
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments_with_placeholder = [
        'echo', ARGUMENT_PLACEHOLDER, 'foo', 'bar']
    arguments_without_placeholder = [
        'echo', 'foo', 'bar']
    arguments_with_only_placeholder = [ARGUMENT_PLACEHOLDER]
    arguments_with_alias = ['-a']
    arguments_with_yes = ['-y']
    arguments_with_version = ['-v']
    arguments_with_repeat = ['-r']
    arguments_with_debug = ['-d']

    # Test arguments with placeholder
    args = parser.parse(arguments_with_placeholder)
    assert args.command == ['foo', 'bar']

    # Test arguments without placeholder

# Generated at 2022-06-24 05:08:12.328609
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    stdout = sys.stdout
    parser = Parser()

    class FakeStream:
        def __init__(self):
            self.data = ''

        def write(self, data):
            self.data += data

        def flush(self):
            pass

    sys.stdout = FakeStream()
    parser.print_usage()
    output = sys.stdout.data
    sys.stdout = stdout
    assert output.startswith("usage: thefuck")



# Generated at 2022-06-24 05:08:20.651118
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', '-v', ARGUMENT_PLACEHOLDER, 'pwd'])
    assert args.version
    assert not args.yes
    assert not args.repeat
    assert not args.debug
    assert args.command == ['pwd']

    args = parser.parse(['thefuck', '-y', '-r', '-l', '', '-d', 'pwd'])
    assert not args.version
    assert args.yes
    assert args.repeat
    assert args.shell_logger == ''
    assert args.debug
    assert args.command == ['pwd']



# Generated at 2022-06-24 05:08:23.619150
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p._add_conflicting_arguments()
    p._add_arguments()
    p.parse(['thefuck', '--version'])
    p.print_usage()
    p.print_help()

# Generated at 2022-06-24 05:08:28.919331
# Unit test for constructor of class Parser
def test_Parser():
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-24 05:08:39.031852
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-a']) == _parser.parse_args(['-a'])
    assert parser.parse(['thefuck', '--alias', 'ali']) == _parser.parse_args(['--alias', 'ali'])
    assert parser.parse(['thefuck', '--shell-logger', 'file.log']) == _parser.parse_args(['--shell-logger', 'file.log'])
    assert parser.parse(['thefuck', '--enable-experimental-instant-mode']) == _parser.parse_args(['--enable-experimental-instant-mode'])
    assert parser.parse(['thefuck', '-h', '-d']) == _parser.parse_args(['-h', '-d'])
   

# Generated at 2022-06-24 05:08:45.732225
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    expected_output = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' + \
        '[-l shell-logger] [--enable-experimental-instant-mode] ' + \
        '[--force-command force-command] [-d] ' + \
        '[-y | -r] [--] [command [command ...]]'
    assert sys.stdout.getvalue() == expected_output


# Generated at 2022-06-24 05:08:47.213194
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-24 05:08:52.637780
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .types import Settings

    parser = Parser()

    f = StringIO()
    parser.print_usage(file=f)
    assert 'usage: thefuck' in f.getvalue()
    assert '-d, --debug' in f.getvalue()

    f = StringIO()
    parser.print_help(file=f)
    assert '-d, --debug' in f.getvalue()


# Generated at 2022-06-24 05:09:03.145843
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import PRODUCT_NAME, VERSION, ALIAS
    import io
    import re

    output = io.StringIO()
    sys.stderr = output

    p = Parser()
    p.print_usage()

    prog = 'thefuck'
    usage = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command COMMAND] [command [command ...]]'


    out = output.getvalue()
    assert out.startswith(prog)
    assert re.search(usage, out)



# Generated at 2022-06-24 05:09:11.000110
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser.parse(['thefuck', ARGUMENT_PLACEHOLDER])

    assert parser.parse(['thefuck', '-h']) == parser.parse(['thefuck', '-h', ARGUMENT_PLACEHOLDER])

    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', '-l', ARGUMENT_PLACEHOLDER, 'ls'])
    assert parser.parse(['thefuck', '--shell-logger', 'log.log']) == parser.parse(['thefuck', '--shell-logger', 'log.log', ARGUMENT_PLACEHOLDER])
    

# Generated at 2022-06-24 05:09:15.243321
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import os
    import test.utils as u
    from test.utils import FakeStd

    std = FakeStd()
    sr = u.mock(std.stderr, 'write')

    parser.print_usage()
    assert sr.called
    assert sr.called_with(u'usage: thefuck [-h] [-v] [-a [custom-alias-name]]')

# Generated at 2022-06-24 05:09:16.361995
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p.__class__ == Parser


# Generated at 2022-06-24 05:09:19.639572
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    command = "foo bar baz"
    assert parser.parse(['script', command]) == parser.parse(['script', '{}', command])
    assert parser.parse(['script', '{}', command]) == argparse.Namespace(alias=None, command=[command], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yeah=False, yes=False)



# Generated at 2022-06-24 05:09:20.789098
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    a.print_usage()
    a.print_help()

# Generated at 2022-06-24 05:09:24.233793
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser != None


# Generated at 2022-06-24 05:09:30.552329
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    a = p.parse(['thefuck', 'fuck','brew','install','vim','!'])
    assert a.command == ['brew','install','vim']
    a = p.parse(['thefuck', 'fuck','brew','install','vim','!', '-v'])
    assert a.command == ['brew','install','vim']
    assert a.version == True
    a = p.parse(['thefuck', 'fuck','brew','install','vim','!', '-vv'])
    assert a.command == ['brew','install','vim']
    assert a.debug == True
    a = p.parse(['thefuck', 'fuck','brew','install','vim','!', '--alias', 'fuck'])
    assert a.command == ['brew','install','vim']
    assert a.alias == 'fuck'

# Generated at 2022-06-24 05:09:32.180399
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:09:33.510203
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:09:42.925462
# Unit test for constructor of class Parser
def test_Parser():
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias
    a = Parser()
    # Assert that the parser is being initialized with the right flags
    assert any(x.startswith("--") for x in a._parser.__dict__.values())
    assert any(x.startswith("-") for x in a._parser.__dict__.values())
    assert a._parser.add_help == False
    assert ARGUMENT_PLACEHOLDER in a._parser.__dict__['version']
    assert ARGUMENT_PLACEHOLDER in a._parser.__dict__['alias']
    assert ARGUMENT_PLACEHOLDER in a._parser.__dict__['shell_logger']

# Generated at 2022-06-24 05:09:43.914846
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:09:48.068364
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest import TestCase

    with TestCase().assertRaises(SystemExit):
        Parser().print_usage()



# Generated at 2022-06-24 05:09:58.532107
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert '-v' in parser._parser._option_string_actions
    assert '--version' in parser._parser._option_string_actions
    assert '-a' in parser._parser._option_string_actions
    assert '--alias' in parser._parser._option_string_actions
    assert '-l' in parser._parser._option_string_actions
    assert '--shell-logger' in parser._parser._option_string_actions
    assert '-h' in parser._parser._option_string_actions
    assert '--help' in parser._parser._option_string_actions
    assert '-d' in parser._parser._option_string_actions
    assert '--debug' in parser._parser._option_string_actions
    assert '--force-command' in parser._parser._option_string_actions
