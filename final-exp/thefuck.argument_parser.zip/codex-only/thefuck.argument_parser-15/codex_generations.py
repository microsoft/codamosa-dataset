

# Generated at 2022-06-24 04:59:58.036855
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == "thefuck"
    assert parser._parser._add_help is False


# Generated at 2022-06-24 05:00:09.275393
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['-a'])
    assert args.alias
    assert args.alias == get_alias()
    args = parser.parse(['-v'])
    assert args.version
    assert args.version == True
    args = parser.parse(['-l'])
    assert args.shell_logger
    assert args.shell_logger == True
    args = parser.parse(['-h'])
    assert args.help == True
    args = parser.parse(['-y'])
    assert args.yes == True
    args = parser.parse(['-r'])
    assert args.repeat == True
    args = parser.parse(['-d'])
    assert args.debug == True



# Generated at 2022-06-24 05:00:18.631149
# Unit test for method parse of class Parser

# Generated at 2022-06-24 05:00:29.107902
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Given
    parser = Parser()

    # When
    parser.print_help()

    # Then
    import sys

# Generated at 2022-06-24 05:00:40.372970
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.stdout = sys.stderr

    data = FakeStdErr()
    p = Parser()
    p.print_help()
    assert data.out.startswith('usage: thefuck')

    data = FakeStdErr()
    p = Parser()
    p.parse(['fuck', '--help'])
    assert data.out.startswith('usage: thefuck')

    data = FakeStdErr()
    p = Parser()
    p.parse(['fuck', '--help=something'])
    assert data.out.startswith('usage: thefuck')

    data = FakeStdErr()
    p = Parser()
    p.parse(['fuck', '--help=something', '--', 'echo', '-h'])
    assert data.out.start

# Generated at 2022-06-24 05:00:45.249404
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    capturedOutput = StringIO.StringIO()
    sys.stderr = capturedOutput

    parser.print_usage()
    sys.stderr = sys.__stderr__

    assert_equal(capturedOutput.getvalue().strip(),
                 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n'
                 '              [--enable-experimental-instant-mode] [-d]\n'
                 '              [--force-command FORCE_COMMAND] [-y | -r]\n'
                 '              [command [command ...]]')


# Generated at 2022-06-24 05:00:46.988658
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    parser.print_usage()

# Generated at 2022-06-24 05:00:48.931930
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert 'usage: thefuck' in parser.print_usage()


# Generated at 2022-06-24 05:00:50.806643
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser._parser

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-24 05:01:00.519728
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Unit test for method parse of class Parser
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-a', '-l'])
    assert(args.command == ['ls', '-a', '-l'])
    assert(args.debug is None)
    assert(args.force_command is None)
    args = parser.parse(['thefuck', '--debug', '--force-command', 'ls', '-a', '-l'])
    assert(args.command == ['ls', '-a', '-l'])
    assert(args.debug is True)
    assert(args.force_command == 'ls')

# Generated at 2022-06-24 05:01:07.458852
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    close_to_the_end = parser._parser.format_help().split('\n')[-4:]
    expected = '-a [custom-alias-name], --alias [custom-alias-name]', '[custom-alias-name] prints alias for current shell', '-l SHELL_LOGGER, --shell-logger SHELL_LOGGER', 'log shell output to the file'
    assert expected == close_to_the_end


# Generated at 2022-06-24 05:01:08.139414
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()



# Generated at 2022-06-24 05:01:09.066398
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-24 05:01:18.694658
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from sys import stderr
    
    # Make a copy of stderr
    _stderr = stderr
    stderr = StringIO()
    try:
        parser = Parser()
        parser.print_usage()
    except:
        print("Unexpected error:", exc_info()[0])
        raise
    
    # Restore stderr

# Generated at 2022-06-24 05:01:19.491470
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True

# Generated at 2022-06-24 05:01:21.426380
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    #given
    parser = Parser()
    parser.print_help()
    #then
    assert True


# Generated at 2022-06-24 05:01:32.198786
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck', 'prog name should be "thefuck"'
    assert parser._parser.add_help == False, 'help should not be added'
    assert parser._parser._actions[0].option_strings == ['-v', '--version'], 'first option should be -v, --version'
    assert parser._parser._actions[0].help == "show program's version number and exit", '--version description is wrong'
    assert parser._parser._actions[1].option_strings == ['-a', '--alias'], 'second option should be -a, --alias'
    assert parser._parser._actions[1].nargs == '?', '-a, --alias nargs should be ?'

# Generated at 2022-06-24 05:01:39.179203
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    actual = parser.parse(argv = ['-h'])
    assert actual.help == True
    parser = Parser()
    actual = parser.parse(argv = ['--version'])
    assert actual.version == True
    parser = Parser()
    actual = parser.parse(argv = ['--shell-logger=log_file'])
    assert actual.shell_logger == 'log_file'
    parser = Parser()
    actual = parser.parse(argv = ['--force-command', 'command'])
    assert actual.force_command == 'command'
    parser = Parser()
    actual = parser.parse(argv = ['--debug'])
    assert actual.debug == True
    parser = Parser()

# Generated at 2022-06-24 05:01:46.125757
# Unit test for method parse of class Parser
def test_Parser_parse():
    # testing scenario 1
    test_command = ['sudo','apt','get','install','vim','&&','vim','hello','world','without','ARGUMENT_PLACEHOLDER']
    p = Parser()
    fixed_argv = p._prepare_arguments(test_command)
    assert len(fixed_argv) == len(test_command)
    assert fixed_argv[-1] == test_command[-1]
    assert fixed_argv[0] == test_command[0]
    assert fixed_argv[-2] == '--'
    assert len(fixed_argv[-3]) == 2
    assert fixed_argv[-3][0] == '--'
    # testing scenario 2

# Generated at 2022-06-24 05:01:52.772190
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    expected = "usage: thefuck [-h] [--help] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y] [-r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n"
    parser = Parser()
    result = parser.print_usage()
    assert result == expected



# Generated at 2022-06-24 05:01:54.943858
# Unit test for constructor of class Parser
def test_Parser():
    try:
        Parser()
        assert True
    except:
        assert False


# Generated at 2022-06-24 05:01:56.948634
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:02:01.566600
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Test if print_help() of class Parser works
    """
    #preconditions
    parser = Parser()
    #execute command
    parser.print_help()
    #postconditions
    #if no exception is raised, the test passes


# Generated at 2022-06-24 05:02:10.637481
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO

    stdout = StringIO()
    stderr = StringIO()
    sys.stdout = stdout
    sys.stderr = stderr

    parser = Parser()
    parser.print_help()

    assert "usage: thefuck" in stderr.getvalue()
    assert "-v, --version" in stderr.getvalue()
    assert "[custom-alias-name]" in stderr.getvalue()
    assert "-l, --shell-logger" in stderr.getvalue()
    assert "--enable-experimental-instant-mode" in stderr.getvalue()
    assert "-h, --help" in stderr.getvalue()
    assert "-y, --yes, --yeah, --hard" in stderr.getvalue()

# Generated at 2022-06-24 05:02:12.935638
# Unit test for constructor of class Parser
def test_Parser():
  parser = Parser()



# Generated at 2022-06-24 05:02:14.352907
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-24 05:02:20.226424
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_main_module
    from mock import patch
    args = ['thefuck', '-h']
    parser = Parser()
    with patch('sys.stderr.write') as sys_stderr_write:
        parser.print_usage()
        sys_stderr_write.assert_called_once_with(
            get_main_module('thefuck').get_parser().usage)

# Generated at 2022-06-24 05:02:22.448119
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck']) == parser.parse(['fuck', '--'])



# Generated at 2022-06-24 05:02:31.621001
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['script', 'ls', 's']) == \
        parser._parser.parse_args(['--', 'ls', 's'])

    assert parser.parse(['script', '-l']) == \
        parser._parser.parse_args(['--', '-l'])

    assert parser.parse(['script', 'ls', ARGUMENT_PLACEHOLDER, 's']) == \
        parser._parser.parse_args(['--', 'ls', 's'])

    assert parser.parse(
        ['script', ARGUMENT_PLACEHOLDER, 'ls', '-l', 's']) == \
        parser._parser.parse_args(['--', 'ls', 's'])


# Generated at 2022-06-24 05:02:35.342307
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.stderr = StringIO()
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue() == parser._parser.format_usage()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:02:43.602278
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert (parser.parse(['', '-v']) ==
            parser.parse(['', '--version']))
    assert (parser.parse(['', '-a', 'fuck']) ==
            parser.parse(['', '--alias', 'fuck']))
    assert (parser.parse(['', '-l', '/tmp/file']) ==
            parser.parse(['', '--shell-logger', '/tmp/file']))
    assert (parser.parse(['', '-h']) ==
            parser.parse(['', '--help']))
    assert (parser.parse(['', '-y']) ==
            parser.parse(['', '--yes']))
    assert (parser.parse(['', '-y']) ==
            parser.parse(['', '--hard']))

# Generated at 2022-06-24 05:02:46.111834
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        pass
    assert False

# Generated at 2022-06-24 05:02:48.805489
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert(p)


# Generated at 2022-06-24 05:02:50.221763
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()



# Generated at 2022-06-24 05:02:58.974672
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

# Generated at 2022-06-24 05:03:08.670876
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['--xxx', '--yyy']) == \
           Namespace(alias='fuck', command=[], debug=False,
                     enable_experimental_instant_mode=False,
                     force_command=None, help=False, repeat=False,
                     shell_logger=None, version=False, yes=False)

    assert Parser().parse(['--alias', 'fck', '--xxx', '--yyy']) == \
           Namespace(alias='fck', command=[], debug=False,
                     enable_experimental_instant_mode=False,
                     force_command=None, help=False, repeat=False,
                     shell_logger=None, version=False, yes=False)

    assert Parser().parse(['--alias', '--', '--xxx', '--yyy'])

# Generated at 2022-06-24 05:03:14.837504
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Tests for method parse.
    """
    parser = Parser()
    # Test 1
    argv = ['thefuck', 'ls', '-la']
    assert parser.parse(argv).command == ['ls', '-la']
    # Test 2
    argv.append('{}')
    assert parser.parse(argv).command == ['ls']
    # Test 3
    argv = ['thefuck', '{}', 'ls', '-la']
    assert parser.parse(argv).command == ['ls', '-la']
    # Test 4
    argv = ['thefuck', '-i', 'ls', '-la']
    assert parser.parse(argv).command == ['ls', '-la']
    # Test 5

# Generated at 2022-06-24 05:03:23.935045
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    orig_stderr = sys.stderr
    sys.stderr = io.StringIO()
    arg_parser = Parser()
    arg_parser.print_usage()
    output = sys.stderr.getvalue()
    sys.stderr = orig_stderr
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' \
                     '              [-l SHELL_LOGGER]\n' \
                     '              [--enable-experimental-instant-mode]\n' \
                     '              [-y | -r] [-d] [--force-command FORCE_COMMAND]\n' \
                     '              [command [command ...]]\n\n'

# Generated at 2022-06-24 05:03:25.509146
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:03:26.738984
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None


# Generated at 2022-06-24 05:03:27.643669
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() is not None
    

# Generated at 2022-06-24 05:03:35.455174
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['./thefuck']) == parser.parse(['./thefuck', '--']) == parser.parse(['./thefuck', '-h']) == parser.parse(['./thefuck'])
    assert parser.parse(['./thefuck', '--force-command', 'echo', 'salut']) == parser.parse(['./thefuck', '--force-command=echo', 'salut'])
    assert parser.parse(['./thefuck', 'ls']).command == ['ls']
    assert parser.parse(['./thefuck', 'ls', '-la']).command == ['ls', '-la']
    assert parser.parse(['./thefuck', 'ls', '-la', 'caca']).command == ['ls', '-la', 'caca']
    assert parser

# Generated at 2022-06-24 05:03:38.389635
# Unit test for method parse of class Parser
def test_Parser_parse():
    data = ['ls', '-lh', ARGUMENT_PLACEHOLDER, '--debug']
    args = Parser().parse(data)
    assert args.debug
    assert args.command == ['ls', '-lh']

# Generated at 2022-06-24 05:03:45.533380
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import SUPPORTED_SHELLS
    from StringIO import StringIO

    out = StringIO()
    sys.stderr = out
    parser = Parser()
    parser.print_help()
    sys.stderr = sys.__stderr__

    out_string = out.getvalue()

    assert 'thefuck' in out_string
    assert '-v, --version' in out_string
    assert '-a, --alias' in out_string
    assert '-l, --shell-logger' in out_string
    assert '-y, --yes, --yeah, --hard' in out_string
    assert '-r, --repeat' in out_string
    assert '-d, --debug' in out_string
    assert '--force-command' in out_string
    assert 'command'

# Generated at 2022-06-24 05:03:48.637425
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_help()
    assert out.getvalue()[0:10] == 'usage: thef'
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:03:58.841398
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from unittest import TestCase
    from thefuck.parser import Parser
    from thefuck.utils import get_alias

    class Arguments(object):
        def __init__(self, version=False, alias=None, help=False, debug=False):
            self.version = version
            self.alias = alias
            self.help = help
            self.debug = debug
            self.shell_logger = None

        def __repr__(self):
            return ("Arguments(version={}, alias={}, help={}, debug={},"
                    " shell_logger={})"
                    "".format(self.version, self.alias, self.help,
                              self.debug, self.shell_logger))

        def __eq__(self, other):
            return self.__dict__ == other

# Generated at 2022-06-24 05:04:02.827266
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['/usr/bin/thefuck', '-y', 'docker', 'run']
    parser = Parser()
    args = parser.parse(argv)
    assert not(args.help)



# Generated at 2022-06-24 05:04:04.185535
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-24 05:04:12.154375
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .t import assert_equal

    parser = Parser()
    with assert_equal('usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'
                      '             [-l SHELL_LOGGER]\n'
                      '             [--enable-experimental-instant-mode]\n'
                      '             [-y] [-r] [-d] [--force-command FORCE_COMMAND]\n'
                      '             [--] [command [command ...]]\n') \
            as result:
        parser.print_usage()



# Generated at 2022-06-24 05:04:23.714930
# Unit test for method parse of class Parser
def test_Parser_parse():
    # `parse` should prepend command with `--`
    assert Parser().parse(['-c', 'ls']).command == ['--', 'ls']
    # `parse` should accept and rewrite `thefuck`
    assert Parser().parse(['thefuck', '-c', 'ls']).command == ['--', 'ls']
    # `parse` should accept and rewrite `tfk`
    assert Parser().parse(['tfk', '-c', 'ls']).command == ['--', 'ls']
    # `parse` should accept and rewrite `fuck`
    assert Parser().parse(['fuck', '-c', 'ls']).command == ['--', 'ls']
    # `parse` should accept and rewrite `ftk`

# Generated at 2022-06-24 05:04:28.066127
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    This method is used to test whether the print_usage
    method works correctly in class Parser
    """
    parser = Parser()
    parser.print_usage()
    assert True

# Generated at 2022-06-24 05:04:30.457361
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from .main import print_help

    output = StringIO()
    print_help(file=output)
    output = output.getvalue()
    assert 'Usage:' in output
    assert 'optional arguments:' in output

# Generated at 2022-06-24 05:04:38.510443
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser._parser.parse_args(['--help']).help
    assert parser._parser.parse_args(['--force-command', 'ls']).force_command == 'ls'
    assert parser._parser.parse_args(['-v']).version
    assert parser._parser.parse_args(['--debug']).debug
    assert parser._parser.parse_args(['--alias']).alias == get_alias()
    assert parser._parser.parse_args(['--alias', 'fuck']).alias == 'fuck'
    assert parser._parser.parse_args(['--enable-experimental-instant-mode']).enable_experimental_instant_mode == True
    assert parser._parser.parse_args(['ls', '-l']).command == ['ls', '-l']
    assert parser._

# Generated at 2022-06-24 05:04:39.840742
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:04:43.444691
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.parse(sys.argv)
    parser.print_usage()
    assert True

# Generated at 2022-06-24 05:04:53.727245
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'fuck', '--help']
    argv_expected = ['--', 'fuck', '--help']
    parser = Parser()
    assert parser.parse(argv).command == argv_expected
    argv = ['thefuck', '--help']
    argv_expected = ['--', '--help']
    assert parser.parse(argv).command == argv_expected
    argv = ['thefuck', 'fuck', 'fuck', '--']
    argv_expected = ['--', 'fuck', 'fuck', '--']
    assert parser.parse(argv).command == argv_expected
    argv = ['thefuck', 'fuck', '--fuck']
    argv_expected = ['--', 'fuck', '--fuck']
    assert parser.parse(argv).command == argv_

# Generated at 2022-06-24 05:05:02.729200
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    arguments = parser._prepare_arguments(
        ['/usr/bin/thefuck', '-V', 'fuck', '-y', './manage.py', 'runserver', '8000', ARGUMENT_PLACEHOLDER])
    parsed = parser._parser.parse_args(arguments)
    assert parsed.version == True
    assert parsed.yes == True
    assert parsed.command == ['./manage.py', 'runserver', '8000']
    assert parsed.command_script == ['fuck', '-y', './manage.py', 'runserver', '8000']


# Generated at 2022-06-24 05:05:14.106129
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import sys

    @Parser.print_help.im_func.__func__
    def print_help():
        pass

    def mock_print(*args, **kwargs):
        pass

    saved_print = Parser.print_help.im_func.__func__.__globals__['print']


# Generated at 2022-06-24 05:05:17.584586
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck','--alias','fuck','-debug','vim','add_error'])
    assert(args.debug)
    assert(args.alias == 'fuck')
    assert(args.command == ['vim','add_error'])

# Generated at 2022-06-24 05:05:18.745441
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser._parser

# Generated at 2022-06-24 05:05:19.828227
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-24 05:05:21.096944
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:05:22.852785
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-24 05:05:23.625929
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:05:25.554240
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    obj = Parser()
    obj.print_usage()


# Generated at 2022-06-24 05:05:29.879915
# Unit test for method print_help of class Parser
def test_Parser_print_help():
  from .utils import capture_output
  parser = Parser()
  with capture_output() as (out, err):
    parser.print_help()
    assert 'usage: thefuck' in err.getvalue()


# Generated at 2022-06-24 05:05:37.737337
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """test for usage print"""
    usage = """usage: thefuck [-h] [--shell-logger SHELL_LOGGER]
               [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]
               [-v] [-a [CUSTOM_ALIAS]] [-y] [-r] command ..."""
    with patch('sys.stdout', new_callable=StringIO) as stdout:
        Parser().print_usage()
        output = stdout.getvalue().strip()
    assert output == usage

test_Parser_print_usage()



# Generated at 2022-06-24 05:05:38.709916
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-24 05:05:41.113636
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = parser.print_help()
    assert output == None

# Generated at 2022-06-24 05:05:41.957590
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None


# Generated at 2022-06-24 05:05:47.555290
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['-h'])
    parser.parse(['-a'])
    parser.parse(['-l', 'test'])
    parser.parse(['--enable-experimental-instant-mode'])
    parser.parse(['--force-command', 'ls'])
    parser.parse(['ls', '-l'])
    parser.parse(['ls'])
    parser.parse(['-v'])
    parser.parse(['-d'])



if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-24 05:05:51.167088
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from .parser import Parser

    parser = Parser()
    try:
        parser.print_usage()
        raise AssertionError('Parser.print_usage should exit the program.')
    except SystemExit:
        pass


# Generated at 2022-06-24 05:06:01.716342
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import read_lines
    from .const import ArgNames
    from . import __version__
    import sys
    # set sys.stdout
    sys.stdout = open('/tmp/fff', 'w')
    Parser = Parser()
    Parser.print_help()
    lines = read_lines('/tmp/fff')
    assert lines[0].startswith('usage: thefuck')
    assert '-h, --help' in lines
    assert '-v, --version' in lines
    assert '-a, --alias' in lines
    assert '-l, --shell-logger' in lines
    assert '-y, --yes' in lines
    assert '-r, --repeat' in lines
    assert 'command' in lines
    assert '--force-command' in lines and ArgNames.force_

# Generated at 2022-06-24 05:06:08.103152
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # This is necessary for output to be properly redirected
    # See: https://stackoverflow.com/questions/16571150/how-to-capture-stdout-output-from-a-python-function-call
    real_stdout = sys.stdout
    test_stdout = StringIO()
    sys.stdout = test_stdout
    parser.print_usage()
    sys.stdout = real_stdout
    output = test_stdout.getvalue()

# Generated at 2022-06-24 05:06:10.340445
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:06:11.874772
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None

# Generated at 2022-06-24 05:06:20.371309
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '--version']) == parser.parse(
        ['thefuck', ARGUMENT_PLACEHOLDER, '--version'])
    assert parser.parse(['thefuck', 'git', 'push']) == parser.parse(
        ['thefuck', 'git', 'push'])
    assert parser.parse(['thefuck', 'git', 'push', ARGUMENT_PLACEHOLDER]) == parser.parse(
        ['thefuck', ARGUMENT_PLACEHOLDER, 'git', 'push', ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-24 05:06:22.611089
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert parser


# Generated at 2022-06-24 05:06:27.701809
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'ls', '-lh', ARGUMENT_PLACEHOLDER, '--alias', 'fuck']
    assert Parser().parse(argv) == Namespace(command=['--', 'ls', '-lh'], alias='fuck', debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)

# Generated at 2022-06-24 05:06:31.343220
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    output = io.StringIO()
    sys.stderr = output
    Parser().print_help()
    assert "usage: thefuck" in output
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:06:35.575045
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class Test_out:
        def __init__(self):
            self.out = ""
        def write(self,s):
            self.out += s
    t = Test_out()
    sys.stderr = t
    Parser().print_usage()
    sys.stderr = sys.__stderr__
    assert(len(t.out) != 0)

# Generated at 2022-06-24 05:06:43.542951
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    a = parser.parse(['', '-a'])
    assert a.alias is True
    b = parser.parse(['', '--alias'])
    assert b.alias == get_alias()
    c = parser.parse(['', '--alias=fuck'])
    assert c.alias == 'fuck'
    d = parser.parse(['', '--debug', '-a'])
    assert d.debug is True
    e = parser.parse(['', '--debug', 'hello world'])
    assert e.command == ['hello', 'world']
    f = parser.parse(['', '--debug', '--force-command', 'hello world'])
    assert f.force_command == 'hello world'

# Generated at 2022-06-24 05:06:51.472670
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    sys.stderr = StringIO()
    parser.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' \
                                    '             [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n' \
                                    '             [-y] [-r] [-d] [--force-command FORCE_COMMAND]\n' \
                                    '             [command [command ...]]\n'


# Generated at 2022-06-24 05:07:00.324614
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    all_args = ["thefuck", "--help", "--version", "--alias", "--shell-logger",
                "--enable-experimental-instant-mode", "--debug", "--force-command", "--", "ls", "--l", "l"]
    parser = Parser()
    args = parser.parse(all_args)
    assert parser.print_usage() is None
    assert args.help is True
    assert args.version is False
    assert args.alias is None
    assert args.shell_logger is None
    assert args.enable_experimental_instant_mode is False
    assert args.debug is False
    assert args.command == ['ls', '--l', 'l']



# Generated at 2022-06-24 05:07:05.541076
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # TODO
    print (parser.parse(['','-v']))
    print (parser.parse(['','-a']))
    print (parser.parse(['','-l']))
    print (parser.parse(['','--enable-experimental-instant-mode']))
    print (parser.parse(['','-h']))
    print (parser.parse(['','-d']))
    print (parser.parse(['','--force-command']))
    print (parser.parse(['','ls']))
    print (parser.parse(['','--']))
    print (parser.parse(['','--force-command','ls']))


# Generated at 2022-06-24 05:07:06.425699
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:07:08.530272
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    parser = Parser()
    parser.print_help()
    assert sys.stdout.getvalue().strip() == ''

test_Parser_print_help()

# Generated at 2022-06-24 05:07:18.333434
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_aliases, get_alias
    from .const import ARGUMENT_PLACEHOLDER
    from StringIO import StringIO
    for alias in get_aliases():
        sys.argv = ['thefuck', alias + ' ' + ARGUMENT_PLACEHOLDER]
        parser = Parser()
        with StringIO() as stderr:
            sys.stderr = stderr
            parser.print_usage()
            assert stderr.getvalue() == "usage: {alias} [-h] [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-y] [-r] [-d] [--force-command FORCE_COMMAND] command [command ...]\n".format(alias=alias)



# Generated at 2022-06-24 05:07:22.037080
# Unit test for method parse of class Parser
def test_Parser_parse():
    test_argv = ['thefuck', '-y', '--show-log', '--', 'python', 'my_script.py']
    test_argv_new = Parser()._prepare_arguments(test_argv)
    assert test_argv_new == ['--', 'python', 'my_script.py']
    args = Parser().parse(test_argv)
    assert args.command == ['python', 'my_script.py']
    assert args.yes

# Unit test case: python test_arguments.py -v (verbose)
# Unit test case: python test_arguments.py
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 05:07:24.564536
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from contextlib import redirect_stderr
    from io import StringIO
    out = StringIO()
    with redirect_stderr(out):
        Parser().print_help()
    assert 'usage: thefuck [-h]' in out.getvalue()

# Generated at 2022-06-24 05:07:34.883431
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    arguments = parser.parse([''])
    assert arguments.alias is None
    assert not arguments.yes
    assert not arguments.debug
    assert not arguments.version

    assert arguments.command == []
    assert not arguments.repeat
    assert arguments.shell_logger is None
    assert not arguments.enable_experimental_instant_mode
    assert arguments.force_command is None

    parser = Parser()
    arguments = parser.parse(['-v'])
    assert arguments.version is True

    parser = Parser()
    arguments = parser.parse(['--version'])
    assert arguments.version is True

    parser = Parser()
    arguments = parser.parse(['-a'])
    assert arguments.alias == 'fuck'

    parser = Parser()

# Generated at 2022-06-24 05:07:43.288281
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    output = out.getvalue().strip()
    assert output == """usage: thefuck [-h] [-v] [-a [custom-alias-name]]
                    [-l shell-logger] [--enable-experimental-instant-mode]
                    [-d] [--force-command FORCE-COMMAND]
                    [--yes | --repeat] [--] [command [command ...]]"""
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:07:49.504544
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [--shell-logger SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [--] [command [command ...]]\n"
    assert parser.print_usage() == output



# Generated at 2022-06-24 05:07:50.130588
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:07:58.349390
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    parser = Parser()
    parser.print_help()
    assert "Usage: thefuck [OPTIONS]" in out.getvalue()
    assert "OPTIONS" in out.getvalue()
    assert "--version" in out.getvalue()
    assert "--alias" in out.getvalue()
    assert "--shell-logger=PATH" in out.getvalue()
    assert "--enable-experimental-instant-mode" in out.getvalue()
    assert "--help" in out.getvalue()
    assert "--yes" in out.getvalue()
    assert "--debug" in out.getvalue()
    assert "--force-command=COMMAND" in out.getvalue()

# Generated at 2022-06-24 05:08:00.504263
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import wrap

    wrap.width = 80
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:08:11.453464
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Without placeholder as prefix
    result = parser.parse('thefuck a b c'.split())
    assert result.command == ['-a', 'b', 'c']

    # Without placeholder as prefix, but with arg
    result = parser.parse('thefuck -a b c'.split())
    assert result.command == ['-a', 'b', 'c']

    # With placeholder as prefix
    result = parser.parse('thefuck fuck -- a b c'.split())
    assert result.command == ['a', 'b', 'c']

    # With placeholder as prefix, but with arg
    result = parser.parse('thefuck fuck -a b c'.split())
    assert result.command == ['-a', 'b', 'c']

    # With placeholder as prefix, but with only arg

# Generated at 2022-06-24 05:08:19.732946
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    from io import StringIO
    from thefuck.main import get_parser

    out = StringIO()

    old_stderr = sys.stderr
    sys.stderr = out

    get_parser().print_help()

    sys.stderr = old_stderr

    actual = out.getvalue()
    assert(actual.startswith('usage: thefuck [options] [command]'))

# Generated at 2022-06-24 05:08:24.709369
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .utils import capture_stderr

    args = ['-v', '-a']
    parser = Parser()

    expected = """usage: thefuck [-h] [-a [custom-alias-name]] [-l SHELL_LOGGER]
               [--enable-experimental-instant-mode] [-y] [-r] [-d]
               [--force-command FORCE_COMMAND] [--] command ...
"""

    with capture_stderr(StringIO()) as stderr:
        parser.parse(args)
        parser.print_usage()

    assert stderr.getvalue() == expected


# Generated at 2022-06-24 05:08:26.130279
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_usage() is not None

# Generated at 2022-06-24 05:08:28.732923
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:08:37.823566
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'fuck', '-l']
    assert parser.parse(argv).command == ['fuck']
    assert parser.parse(argv).shell_logger == '-'
    argv = ['thefuck', 'fuck', ARGUMENT_PLACEHOLDER, '-l']
    assert parser.parse(argv).command == ['fuck']
    assert parser.parse(argv).shell_logger == '-'
    argv = ['thefuck', 'fuck', ARGUMENT_PLACEHOLDER, '-l', '-v']
    assert parser.parse(argv).command == ['fuck', '-l']
    assert parser.parse(argv).shell_logger == '-'
    assert parser.parse(argv).version == True


# Generated at 2022-06-24 05:08:43.581143
# Unit test for method parse of class Parser
def test_Parser_parse():
    #Test case with no argument
    pars = Parser()
    argv = ["thefuck"]
    args = pars.parse(argv)
    assert args.command == []
    assert args.version == False
    assert args.alias == False
    assert args.shell_logger == None
    assert args.enable_experimental_instant_mode == False
    assert args.help == False
    assert args.yes == False
    assert args.repeat == False
    assert args.debug == False
    assert args.force_command == None
    #Test case 1 with alias, debug
    argv = ["thefuck", "-a", "-d"]
    args = pars.parse(argv)
    assert args.command == []
    assert args.version == False
    assert args.alias == "fuck"

# Generated at 2022-06-24 05:08:46.488343
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Call method print_usage()
    parser.print_usage()

# Generated at 2022-06-24 05:08:55.886819
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', 'cmd', 'arg1', 'arg2']) == \
        Namespace(alias=None, command=['cmd', 'arg1', 'arg2'],
                  debug=False, force_command=None,
                  shell_logger=None,
                  enable_experimental_instant_mode=False,
                  help=None, repeat=False, yes=False)

# Generated at 2022-06-24 05:08:56.724882
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:08:57.378771
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:09:06.446780
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck', '--alias', 'fuck']) == \
           Parser().parse(['thefuck', 'fuck'])
    assert Parser().parse(['thefuck', 'fuck']) == \
           Parser().parse(['thefuck', '-a', 'fuck'])
    assert Parser().parse(['thefuck', 'fuck', '--alias', 'fuckyeah']) == \
           Parser().parse(['thefuck', 'fuck', 'fuckyeah'])
    assert Parser().parse(['thefuck', 'fuck', '-a', 'fuckyeah']) == \
           Parser().parse(['thefuck', 'fuck', 'fuckyeah'])

# Generated at 2022-06-24 05:09:07.678356
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:09:12.514095
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from test_utils import captured_stderr

    def create_test_Parser():
        parser = Parser()
        parser._parser = ArgumentParser(prog='thefuck')
        return parser

    parser = create_test_Parser()
    parser.print_usage()

    with captured_stderr() as (out, _):
        parser.print_usage()
    assert 'thefuck' in out.getvalue()
    assert parser._parser.prog in out.getvalue()



# Generated at 2022-06-24 05:09:20.348954
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert 'yes' not in parser.parse(['-a', 'fuck']).__dict__.keys()
    assert 'yes' in parser.parse(['-a', 'fuck', '-y']).__dict__.keys()

    assert 'repeat' not in parser.parse(['-a', 'fuck']).__dict__.keys()
    assert 'repeat' in parser.parse(['-a', 'fuck', '-r']).__dict__.keys()


# Unit tests for parser

# Generated at 2022-06-24 05:09:23.771368
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-24 05:09:28.833829
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    out, err = capsys.readouterr()
    assert "usage: thefuck" in out
    assert "-v, --version" in out
    assert "-a, --alias" in out
    assert "-l, --shell-logger" in out
    assert "-h, --help" in out
    assert "--debug" in out
    assert "--force-command" in out
    assert "command" in out
    assert "-y, --yes, --yeah, --hard" in out
    assert "-r, --repeat" in out

# Generated at 2022-06-24 05:09:29.671428
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:09:36.500574
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        parser.print_usage()

        # Thefuck prints usage of ArgumentParser
        # to stderr
        assert 'usage:' in sys.stderr.getvalue()
    finally:
        sys.stderr = stderr


# Generated at 2022-06-24 05:09:37.890792
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:09:38.691721
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:09:48.877550
# Unit test for method parse of class Parser
def test_Parser_parse():
    Parser().parse(['-v'])
    Parser().parse(['--alias'])
    Parser().parse(['--alias', 'fuck'])
    Parser().parse(['-y'])
    Parser().parse(['-a', 'fuck', '-y'])
    Parser().parse(['-a', 'fuck', '-y', 'echo', 'bla'])
    Parser().parse(['-a', 'fuck', '-y', 'echo', 'bla', ARGUMENT_PLACEHOLDER])
    Parser().parse(['-a', 'fuck', '-y', 'echo', 'bla', ARGUMENT_PLACEHOLDER, '-b'])
    Parser().parse(['echo', 'bla'])

# Generated at 2022-06-24 05:09:52.109271
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-24 05:09:53.467917
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser._parser