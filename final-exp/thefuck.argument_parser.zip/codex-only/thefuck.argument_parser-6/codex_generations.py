

# Generated at 2022-06-24 05:00:04.286001
# Unit test for constructor of class Parser
def test_Parser():
  print("\n###########################\n# Testing Parser(object)...\n###########################\n")
  parser = Parser()
  parser.print_usage()
  parser.print_help()
  args = parser.parse([sys.argv[0],"-l","/tmp/shell.log","--enabale-experimental-instant-mode","--force-command","git status","-h","-a","fuck"])
  print("\n###########################\n# ...Done.\n###########################\n")
  return


# Generated at 2022-06-24 05:00:07.875215
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    #Arrange
    parser = Parser()
    #Act
    parser.print_help()
    #Assert
    # tests that no exceptions are raised and that there is no stdout output

# Generated at 2022-06-24 05:00:09.858482
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser.parse(['/usr/local/bin/fuck', '-d']))

# Generated at 2022-06-24 05:00:13.433069
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:00:15.550621
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    out = StringIO()
    parser = Parser()
    parser.print_usage(file=out)
    assert 'usage:' in out.getvalue()


# Generated at 2022-06-24 05:00:17.376759
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:00:18.523883
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:00:20.344487
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:00:29.940398
# Unit test for constructor of class Parser
def test_Parser():
    def test_alias_name():
        parser = Parser()
        assert parser._parser.parse_args([
            '-a', 'new_fuck_name']).alias == 'new_fuck_name'
    
    def test_debug():
        parser = Parser()
        assert parser._parser.parse_args(
            ['-d']).debug == True

    def test_version():
        parser = Parser()
        assert parser._parser.parse_args(
            ['-v']).version == True

    def test_yes_or_repeat():
        parser = Parser()
        assert parser._parser.parse_args(
            ['-y']).yes == True
        assert parser._parser.parse_args(
            ['-r']).repeat == True

    def test_shell_logger():
        parser = Parser()


# Generated at 2022-06-24 05:00:35.786829
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    out=StringIO()
    sys.stderr=out
    #create Parser
    p=Parser()
    p.print_help()
    #check length of help
    assert out.getvalue().split('\n')[0].__len__()>40
    #check if help contains usage
    assert 'usage' in out.getvalue()



# Generated at 2022-06-24 05:00:38.733090
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:00:41.473293
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test 1 of 1
    args = Parser().parse(["fuck", "alias", "fuck"])
    assert args.alias == "fuck"

# Generated at 2022-06-24 05:00:51.046566
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import sys

    sio = io.StringIO()
    sys.stderr = sio
    parser = Parser()
    parser.print_help()
    sio.seek(0)

# Generated at 2022-06-24 05:01:02.282575
# Unit test for method parse of class Parser
def test_Parser_parse():
    class FakeParser(object):
        def __init__(self):
            self.argv = ["python3","-a","arg1","arg2","arg3","-v","-r","-y","-h","--help","-d","--debug","--enable-experimental-instant-mode","--shell-logger","--force-command","--alias"]
            self.expected = ["arg1","arg2","arg3","-v","-r","-y","-h","--help","-d","--debug","--enable-experimental-instant-mode","--shell-logger","--force-command","--alias"]
        def parse_args(self,argv):
            return self.argv[:] == self.expected
    parser = Parser()
    fakeParser = FakeParser()
    parser._parser = fakeParser
    assert parser

# Generated at 2022-06-24 05:01:03.962658
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0, Parser)


# Generated at 2022-06-24 05:01:07.533587
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from argparse import ArgumentParser
    ArgumentParser.print_usage = lambda self: 'print_usage() called'
    parser = Parser()
    parser._parser.print_usage = lambda: 'print_usage() called'
    parser.print_usage()



# Generated at 2022-06-24 05:01:13.241772
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # This is just a random way to test print_usage().
    # This test also tests print_help() method because print_help()
    # calls print_usage() which is not tested directly.
    try:
        sys.stderr = open("misc/parser_print_usage_test_output", "w")
        test_parser = Parser()
        test_parser.print_usage()
        sys.stderr.close()
        test_output = open("misc/parser_print_usage_test_output", "r")
        assert(test_output.readline() == "usage: thefuck [options] [--] "
                                        "command [command...]\n")
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:01:18.081560
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_alias
    argv = ['thefuck', 'echo', 'fuck']
    parser = Parser()
    parser.print_usage()
    parser.print_help()
    parser.parse(argv)
    assert parser.parse(argv).shell_logger, ''
    assert parser.parse(argv).force_command, None
    assert parser.parse(argv).debug, False


# Generated at 2022-06-24 05:01:19.375968
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert not Parser().print_usage()


# Generated at 2022-06-24 05:01:20.245965
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:01:21.264477
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-24 05:01:32.042339
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	argv = ['thefuck', 'command', ARGUMENT_PLACEHOLDER, 'arg', 'arg']
	last_argv = ['-d']
	help_argv = ['-h']
	alias_argv = ['-a']
	output = parser.parse(argv)
	last_output = parser.parse(last_argv)
	help_output = parser.parse(help_argv)
	alias_output = parser.parse(alias_argv)
	assert_equals(output.debug, False)
	assert_equals(output.yes, False)
	assert_equals(output.repeat, False)
	assert_equals(output.version, False)
	assert_equals(output.shell_logger, None)

# Generated at 2022-06-24 05:01:33.414289
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-24 05:01:35.267852
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p.parse(['thefuck'])
    assert p.parse(['thefuck','--shell-logger'])



# Generated at 2022-06-24 05:01:36.310708
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert p.print_help()


# Generated at 2022-06-24 05:01:43.544299
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Test print_usage of class Parser
    """
    sys.stderr = StringIO()
    parser = Parser()
    parser.print_usage()
    sys.stderr.seek(0)
    out = sys.stderr.read()
    assert out.strip() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]' \
                          ' [-l SHELL-LOGGER] [--enable-experimental-instant-mode]' \
                          ' [-y] [-r] [-d] [--force-command FORCE-COMMAND] [--] [command [command ...]]'
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:01:54.037402
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.description == 'Argument parser that can handle arguments with our special placeholder.'

    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False

    # test _add_arguments()
    # test add -v --version
    for option in ['-v', '--version']:
        for action in p._parser._option_string_actions:
            if option in action:
                assert action.type == 'store_true'
                assert action.dest == 'version'
                assert action.help == "show program's version number and exit"
                break

    # test add -a --alias

# Generated at 2022-06-24 05:01:55.708616
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from unittest.mock import patch

    f = StringIO()
    with patch('sys.stderr', f):
        parser = Parser()
        parser.print_help()
        assert 'usage: thefuck' in f.getvalue()

# Generated at 2022-06-24 05:01:59.221428
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    if(p):
        print("Parser() is OK")
    else:
        print("Parser() is NG")

if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-24 05:02:05.597935
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    parser = Parser()
    out = StringIO()
    parser.print_usage(file=out)
    content = out.getvalue()
    assert 'Usage:' in content
    assert '[-l <shell-logger>]' in content
    assert '[--enable-experimental-instant-mode]' in content
    assert '[-a [<custom-alias-name>]]' in content
    assert '[-d]' in content
    assert '[--force-command]' in content


# Generated at 2022-06-24 05:02:12.964084
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-24 05:02:14.770192
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True


# Generated at 2022-06-24 05:02:25.114859
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'command', ARGUMENT_PLACEHOLDER, '--yes', '--debug', 'arg1', 'arg2'])
    assert(args.yes == True)
    assert(args.debug == True)
    assert(args.command == ['command', 'arg1', 'arg2'])
    args = parser.parse(['thefuck', 'command', ARGUMENT_PLACEHOLDER, '--repeat', '--debug', 'arg1', 'arg2'])
    assert(args.repeat == True)
    assert(args.debug == True)
    assert(args.command == ['command', 'arg1', 'arg2'])


# Generated at 2022-06-24 05:02:28.378346
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    sys.stderr = open("test_Parser_print_usage.txt", "w+")
    parser.print_usage()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:02:32.764832
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().print_help() is None


# Generated at 2022-06-24 05:02:40.003574
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._action_groups[-1].title == 'optional arguments'
    assert len(parser._parser._action_groups) == 4
    assert parser._parser._action_groups[-1]._group_actions[-1].option_strings == ['-h', '--help']
    assert parser._parser._action_groups[-1]._group_actions[-1].help == 'show this help message and exit'
    assert parser._parser._action_groups[-1]._group_actions[-2].option_strings == ['-d', '--debug']
    assert parser._parser._action_groups[-1]._group_actions[-2].help == 'enable debug output'
    assert parser._parser._action_groups[-1]._

# Generated at 2022-06-24 05:02:43.257942
# Unit test for method parse of class Parser
def test_Parser_parse():
    import argparse
    argv = ['thefuck', '--debug', 'ls', '-l']
    parser = Parser()
    assert parser.parse(argv) == argparse.Namespace(debug=True, shell_logger=None, enable_experimental_instant_mode=False, alias=None, yes=False, help=False, version=False, command=['ls', '-l'], repeat=False, force_command=None)


# Generated at 2022-06-24 05:02:52.911605
# Unit test for method parse of class Parser
def test_Parser_parse():
    class Arguments(object):

        def __init__(self, alias=None, command='', debug=False,
                     force_command=None, help=None, shell_logger=None,
                     version=None):
            self.alias = alias
            self.command = command
            self.debug = debug
            self.force_command = force_command
            self.help = help
            self.shell_logger = shell_logger
            self.version = version

    parser = Parser()
    assert parser.parse(['thefuck', '-v', 'rm']) == Arguments(version=True)
    assert parser.parse(['thefuck', '-a']) == Arguments(alias=get_alias())

# Generated at 2022-06-24 05:03:02.739969
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Test the print_usage() function of the class Parser
    """
    usage_msg = "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n"\
        "                [--enable-experimental-instant-mode] [-l shell-logger]\n"\
        "                [-y | -r] [-d] [--force-command FORCE_COMMAND]\n"\
        "                [command [command ...]]"
    original_stderr = sys.stderr
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    mystdout = StringIO()
    sys.stderr = mystdout
    parser = Parser()
    parser.print_usage()
    assert mystdout.getvalue

# Generated at 2022-06-24 05:03:10.864815
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Check for if the argument parser handles our special placeholder.
    """
    parser = Parser()
    
    # if placeholder is not present in arguments, just as it is
    assert parser.parse(['thefuck','ls','--all','d','--help','--verbose','hi','--debug']).command == ['ls','--all','d','--help','--verbose','hi','--debug']

    # if placeholder is present, then it should return true
    assert parser.parse(['thefuck', 'ls', '--all', 'd', '--help', '--verbose', 'hi', '--debug', ARGUMENT_PLACEHOLDER, 'python', '-h']).command == ['python', '-h']

# Generated at 2022-06-24 05:03:14.617606
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    capture = StringIO()
    parser = Parser()
    parser.print_help(file=capture)
    assert 'usage: thefuck' in capture.getvalue()

# Generated at 2022-06-24 05:03:16.834776
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-24 05:03:19.187565
# Unit test for method print_help of class Parser

# Generated at 2022-06-24 05:03:20.001299
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-24 05:03:22.603793
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help is False


# Generated at 2022-06-24 05:03:23.934588
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    return parser
        

# Generated at 2022-06-24 05:03:25.886189
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), Parser)


# Generated at 2022-06-24 05:03:27.125206
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-24 05:03:29.201294
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-24 05:03:36.547889
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck']) == Namespace(alias=None, command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None,
                                                     version=False, yeah=False, yes=False)
    assert Parser().parse(['thefuck', '-v']) == Namespace(alias=None, command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None,
                                                     version=True, yeah=False, yes=False)

# Generated at 2022-06-24 05:03:38.132725
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.parse('fuck -v'.split())



# Generated at 2022-06-24 05:03:45.380618
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', '-v'])
    assert arguments.version
    assert not arguments.alias
    assert not arguments.command

    arguments = parser.parse(['thefuck', '-a'])
    assert not arguments.version
    assert arguments.alias == get_alias()
    assert not arguments.command

    arguments = parser.parse(['thefuck', '-a', 'fuck'])
    assert not arguments.version
    assert arguments.alias == 'fuck'
    assert not arguments.command

    arguments = parser.parse(['thefuck', '-l', '/dev/null', 'git', 'status'])
    assert not arguments.version
    assert not arguments.alias
    assert not arguments.debug
    assert arguments.shell_logger == '/dev/null'
    assert arguments.command

# Generated at 2022-06-24 05:03:52.603114
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'git']) == \
        parser._parser.parse_args(['--'] + ['git'])

    assert parser.parse(['thefuck', '--alias', 'tf']) == \
        parser._parser.parse_args(['--alias', 'tf'])

    assert parser.parse(['thefuck', '--debug']) == \
        parser._parser.parse_args(['--debug'])

    assert parser.parse(['thefuck', 'git', 'status', ARGUMENT_PLACEHOLDER,
                         '-a', '--debug', '--alias', 'tf']) == \
        parser._parser.parse_args(
            ['-a', '--debug', '--alias', 'tf', '--'] + ['git', 'status'])

# Generated at 2022-06-24 05:03:55.726716
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    parser.print_help()

# Generated at 2022-06-24 05:04:01.761338
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.help = 'Test Help'
    m = mock.mock_open()
    with mock.patch('thefuck.shells.thefuck.Parser.open', m, create=True):
        parser.print_help()
        m().write.assert_called_once_with(parser.help)


# Generated at 2022-06-24 05:04:08.580719
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Test case 1
    # Command:
    #   $ thefuck --help
    # Output:
    #   usage: thefuck [-h] [-v] [-a [custom-alias-name]]
    #                  [-l SHELL_LOGGER]
    #                  [--enable-experimental-instant-mode]
    #                  [-y] [-r] [-d] [--force-command FORCE_COMMAND]
    #                  [command command ...]
    #
    #   optional arguments:
    #     -h, --help            show this help message and exit
    #     -v, --version         show program's version number and exit
    #     -a [custom-alias-name], --alias [custom-alias-name]
    #                           [custom-alias-name] prints alias for current shell


# Generated at 2022-06-24 05:04:09.698300
# Unit test for constructor of class Parser
def test_Parser():
    test_parser = Parser()
    assert isinstance(test_parser, Parser)


# Generated at 2022-06-24 05:04:13.166187
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:23.841803
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # check if usage is shown if no arguments are given
    parser = Parser()

# Generated at 2022-06-24 05:04:29.922428
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO
    sys.stderr = StringIO.StringIO()
    p = Parser()
    p.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--yes] [--repeat] [--] [command [command ...]]\n'


# Generated at 2022-06-24 05:04:30.954007
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:04:32.886988
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    sys.stderr = open('/dev/null', 'w')
    Parser().parse(sys.argv)
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:04:35.907453
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from .utils import wrap_streams
    parser = Parser()
    with wrap_streams(StringIO()) as (out, err):
        parser.print_help()
        assert 'usage' in err.getvalue()

# Generated at 2022-06-24 05:04:45.728283
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    actual_output = ""

# Generated at 2022-06-24 05:04:48.482559
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Unit test for method print_help of class Parser"""
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:49.755221
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert parser._parser.print_help(sys.stderr) == None



# Generated at 2022-06-24 05:04:51.860465
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    out = StringIO()
    _Parser = Parser()
    _Parser.print_help()


# Generated at 2022-06-24 05:04:53.641245
# Unit test for constructor of class Parser
def test_Parser():
  p = Parser()
  assert isinstance(p, Parser), "It is an instance of the Parser class"


# Generated at 2022-06-24 05:05:00.412411
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    test_parser = Parser()

# Generated at 2022-06-24 05:05:04.368401
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    mock_stderr = Mock()
    real_stderr = sys.stderr
    sys.stderr = mock_stderr

    parser = Parser()
    parser.print_usage()

    assert mock_stderr.write.called
    sys.stderr = real_stderr


# Generated at 2022-06-24 05:05:06.048417
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-24 05:05:07.473189
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    return parser

parser = test_Parser()

# Generated at 2022-06-24 05:05:16.685061
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['test', 'ls'])
    parser.parse(['test', 'ls', '-l'])
    parser.parse(['test', 'ls', '--help'])
    parser.parse(['test', 'ls', '-a'])
    parser.parse(['test', 'ls', '-a', 'fuck'])
    parser.parse(['test', 'ls', '-r'])
    parser.parse(['test', 'ls', '-r', '-a'])
    parser.parse(['test', 'ls', '-r', '-a', 'fuck'])
    parser.parse(['test', 'ls', '-y'])
    parser.parse(['test', 'ls', '-y', '-a'])

# Generated at 2022-06-24 05:05:17.498346
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()



# Generated at 2022-06-24 05:05:20.899774
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    import StringIO
    import sys
    try:
        stderr = sys.stderr
        sys.stderr = StringIO.StringIO()
        parser.print_help()
        assert "usage: thefuck" in sys.stderr.getvalue()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-24 05:05:31.714627
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '--', 'ls']) == \
        parser._parser.parse_args(['--', 'ls'])
    assert parser.parse(['thefuck', 'ls']) == parser._parser.parse_args(['--', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-a', '--debug']) == \
        parser._parser.parse_args(['--', 'ls', '-a', '--debug'])
    assert parser.parse(['thefuck', 'ls', '-a', '-l', 'foo.log', '--debug']) == \
        parser._parser.parse_args(['--', 'ls', '-a', '-l', 'foo.log', '--debug'])

# Generated at 2022-06-24 05:05:40.434133
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # choose the command to use
    argv = "fuck lolcat -l my_shell.log -h".split()
    args = parser.parse(argv)
    assert args.shell_logger == "my_shell.log"
    assert args.help == True
    assert args.command == ["lolcat"]

    # choose the command to use with arguments
    argv = "fuck -- lolcat --force -F".split()
    args2 = parser.parse(argv)
    assert args2.command == ["lolcat", "--force", "-F"]

if __name__ == "__main__":
    test_Parser_parse()

# Generated at 2022-06-24 05:05:41.396033
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:05:42.861050
# Unit test for constructor of class Parser
def test_Parser():
    print('test Parser():')
    p = Parser()
    print(p._parser)


# Generated at 2022-06-24 05:05:43.505414
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:05:44.441208
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-24 05:05:50.912328
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    This unittest aims to test the functionality of parse method
    of class Parser
    """
    parser = Parser()
    args = parser.parse(['./thefuck','-v'])
    assert(args.version)
    args = parser.parse(['thefuck','-h'])
    assert(args.help)
    args = parser.parse(['thefuck','-a'])
    assert(args.alias)
    args = parser.parse(['thefuck','-a','fuck'])
    assert(args.alias == 'fuck')
    args = parser.parse(['thefuck','-l','log'])
    assert(args.shell_logger == 'log')
    args = parser.parse(['thefuck','--enable-experimental-instant-mode'])

# Generated at 2022-06-24 05:05:53.778778
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import _get_executable

    with _get_executable() as executable:
        parser = Parser()
        parser.print_help()


# Generated at 2022-06-24 05:06:03.554788
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


#print parser.parse(["thefuck", "--alias"])
#print parser.parse(["thefuck", "-a"])
#print parser.parse(["thefuck", "--shell-logger", "log"])
#print parser.parse(["thefuck", "-l", "log"])
#print parser.parse(["thefuck", "--force-command", "fuck"])
#print parser.parse(["thefuck", "-v"])
#print parser.parse(["thefuck", "--repeat"])
#print parser.parse(["thefuck", "-r"])
#print parser.parse(["thefuck", "--yes"])
#print parser.parse(["thefuck", "-y"])
#print parser.parse(["thefuck", "--debug"]

# Generated at 2022-06-24 05:06:07.321697
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from test_thefuck.utils import assert_stderr, assert_not_stderr
    from thefuck.parser import Parser

    with assert_stderr() as stderr:
        Parser().print_usage()
    assert_not_stderr(stderr)

# -----


# Generated at 2022-06-24 05:06:10.066293
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p.parse([])
    assert p.parse(['--help'])


# Generated at 2022-06-24 05:06:19.314247
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        parser = Parser()
        parser.print_help()

# Generated at 2022-06-24 05:06:26.515402
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import StringIO
    import sys
    from contextlib import contextmanager
    from .utils import capture_output
    from .parser import Parser

    @contextmanager
    def capture():
        with capture_output(stdout=True, stderr=True) as (out_std, out_err):
            yield out_err

    sys.stderr = StringIO.StringIO()
    with capture() as out:
        Parser().print_usage()
    assert out.getvalue().startswith("usage:")


# Generated at 2022-06-24 05:06:28.545306
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-24 05:06:30.424493
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-24 05:06:38.978698
# Unit test for constructor of class Parser
def test_Parser():
    from . import const
    p = Parser()
    assert p._parser.usage.__str__() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' \
                                        '              [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n' \
                                        '              [-d] [--force-command FORCE_COMMAND]\n' \
                                        '              [--yes | --yeah | --hard | -r] [command [command ...]]'
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False
    assert p._parser.actions[0].dest == 'version'
    assert p._parser.actions[0].nargs == 0
    assert p._parser.actions[0].const == None

# Generated at 2022-06-24 05:06:45.834985
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser._prepare_arguments(['--enable-experimental-instant-mode']) \
        == ['--enable-experimental-instant-mode']
    assert parser._prepare_arguments(['-y', '--']) == ['--', '-y']
    assert parser._prepare_arguments(['rm', '-rf', ARGUMENT_PLACEHOLDER, 'pwd']) == ['-rf','--','rm','pwd']
    assert parser._prepare_arguments([ARGUMENT_PLACEHOLDER, '--enable-experimental-instant-mode']) \
        == ['--enable-experimental-instant-mode']
    assert parser._prepare_arguments(['--']) == ['--']

# Generated at 2022-06-24 05:06:57.005803
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Checking the print output.
    """
    parser = Parser()

    class Capturing(list):
        def __init__(self, capture_stdout=True):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()

        def __del__(self):
            sys.stdout = self._stdout

        def get_captured(self):
            return self._stringio.getvalue().splitlines()

    with Capturing() as output:
        parser.print_usage()

    assert 'usage: thefuck' in output
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]' in output
    assert 'usage: thefuck [-l SHELL_LOGGER] [--enable-experimental-instant-mode]' in output
   

# Generated at 2022-06-24 05:06:59.635715
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    sys.stderr = StringIO()
    parser.print_help()
    result = sys.stderr.getvalue()
    sys.stderr = sys.__stderr__
    assert result, "Method print_help() doesn't work"

# Generated at 2022-06-24 05:07:01.448003
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


parser = Parser()

# Generated at 2022-06-24 05:07:03.413890
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(["thefuck", "--alias", "fuck", "--", "git", "status"])
    assert args.command == ["git", "status"]
    assert args.alias == "fuck"

# Generated at 2022-06-24 05:07:14.847454
# Unit test for method parse of class Parser

# Generated at 2022-06-24 05:07:17.586652
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'echo', 'hello', ARGUMENT_PLACEHOLDER, '--color=yes', '--alias=fuck', '--']
    assert Parser().parse(argv) == \
        Parser()._parser.parse_args(['--color=yes', '--alias=fuck', '--', 'hello'])


# Generated at 2022-06-24 05:07:18.338889
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:07:19.278225
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser._parser

# Generated at 2022-06-24 05:07:22.549947
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser._parser.format_usage().strip() == 'usage: thefuck [options]'
    assert parser._parser.format_usage().strip() != 'usage: thefuck [options] command [--] [args]'


# Generated at 2022-06-24 05:07:27.678475
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except SystemExit:
        pass


# Generated at 2022-06-24 05:07:29.299034
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p is not None
    assert p._parser is not None


# Generated at 2022-06-24 05:07:32.039567
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # this test is to make sure that the print_help is sucessful or not
    parser.print_help()


# Generated at 2022-06-24 05:07:33.686024
# Unit test for constructor of class Parser
def test_Parser():
    try:
        Parser()
        return True
    except:
        return False


# Generated at 2022-06-24 05:07:44.265063
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'ls', '-l', 'ARGUMENT_PLACEHOLDER', '--', '-a']
    assert Parser().parse(argv).command == ['ls', '-a']

    assert Parser().parse(['thefuck', 'apt-get', 'install', 'ARGUMENT_PLACEHOLDER', '--', 'git']).command == ['apt-get', 'install', 'git']

    assert Parser().parse(['thefuck', 'ls', 'ARGUMENT_PLACEHOLDER', '-a']).command == ['ls', '-a']
    assert Parser().parse(['thefuck', 'ls', '-a']).command == ['ls', '-a']
    assert Parser().parse(['thefuck', 'sudo', 'ls', '--foo'])

# Generated at 2022-06-24 05:07:45.348556
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-24 05:07:48.289463
# Unit test for constructor of class Parser
def test_Parser():
    """
    >>> parser = Parser()
    >>> parser
    <__main__.Parser instance at 0x10164a7b8>
    """


# Generated at 2022-06-24 05:07:57.220044
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

    def test_parse(argv, command, alias, shell_logger, **kwargs):
        assert p.parse(argv).command == command
        assert p.parse(argv).alias == alias
        assert p.parse(argv).shell_logger == shell_logger
        for key, val in kwargs.items():
            assert p.parse(argv).__getattribute__(key) is val

    test_parse(['fuck'], '', False, False, debug=False, force_command=None)
    test_parse(['fuck', 'ls'], 'ls', False, False, debug=False,
               force_command=None)

# Generated at 2022-06-24 05:07:58.039170
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-24 05:07:59.114718
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:08:07.365134
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # GIVEN
        # new instance of class Parser
        parser = Parser()
        # test string
        testString = "usage: thefuck [-h] [-v] [-a [custom-alias-name]] " +\
                     "[-l SHELL_LOGGER] [--enable-experimental-instant-mode] " +\
                     "[-d] [--force-command FORCE_COMMAND] [-y | -r] [--] " +\
                     "[command [command ...]]\n"
    # WHEN
        # output of method print_usage is assigned to resultString
        resultString = ""
        with patch('sys.stderr') as mock_stderr:
            parser.print_usage()
            resultString = mock_stderr.write.call_args[0][0]
    # THEN

# Generated at 2022-06-24 05:08:08.585040
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None

# Generated at 2022-06-24 05:08:14.223498
# Unit test for method parse of class Parser
def test_Parser_parse():
    class Parser():
        def __init__(self, prog='thefuck'):
            pass
        def add_argument(self, *args, **kwargs):
            pass
        def parse_args(self, args):
            return args

    parser = Parser()
    assert(parser.parse(['thefuck', '--yes', '--', 'echo', 'fuck']) == ['--yes', '--', 'echo', 'fuck'])
    assert(parser.parse(['thefuck', '-y', '--', 'echo', 'fuck']) == ['-y', '--', 'echo', 'fuck'])
    assert(parser.parse(['thefuck', 'echo', 'fuck']) == ['--', 'echo', 'fuck'])

# Generated at 2022-06-24 05:08:20.438030
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(["thefuck", "-a", "fuck", "fuck", "fuck", "fuck"])

    assert args.alias == "fuck"
    assert not args.version
    assert not args.shell_logger
    assert not args.enable_experimental_instant_mode
    assert not args.help
    assert not args.yes
    assert not args.repeat
    assert not args.debug
    assert not args.force_command
    assert args.command == ['fuck']



# Generated at 2022-06-24 05:08:25.407857
# Unit test for constructor of class Parser
def test_Parser():
    command_list = ['python3', 'wrong_command', '--abcd']
    test_parser = Parser()
    assert test_parser.parse(command_list) == Namespace(
        command=['wrong_command', '--abcd'],
        alias=None,
        debug=False,
        enable_experimental_instant_mode=False,
        force_command=None,
        help=False,
        yes=False,
        repeat=False,
        shell_logger=None,
        version=False)

# Generated at 2022-06-24 05:08:29.965433
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from contextlib import redirect_stderr
    f = StringIO()
    with redirect_stderr(f):
        Parser().print_usage()
    output = f.getvalue()

    assert(output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [--] [command [command ...]]\n')


# Generated at 2022-06-24 05:08:30.956265
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()


# Generated at 2022-06-24 05:08:32.151896
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse([])

# Generated at 2022-06-24 05:08:33.822619
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-24 05:08:36.174153
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:08:37.998789
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    import StringIO
    buffer = StringIO.StringIO()
    sys.stderr = buffer
    parser = Parser()
    parser.print_help()
    assert "Usage: thefuck" in buffer.getvalue()

# Generated at 2022-06-24 05:08:42.254454
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()._parser
    assert parser.prog == 'thefuck'
    assert parser.add_help == False


# Generated at 2022-06-24 05:08:43.552446
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:08:52.960375
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys, io
    saved_stderr = sys.stderr
    try:
        out = io.StringIO()
        sys.stderr = out
        Parser().print_help()
        output = out.getvalue().strip()
        assert output == ("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]"
                          "\nthefuck: error: argument command: expected one argument")
    finally:
        sys.stderr = saved_stderr


# Generated at 2022-06-24 05:09:02.686858
# Unit test for method parse of class Parser
def test_Parser_parse():

    #preparation
    arguments_for_testing = []
    arguments_for_testing.append(['-v'])
    arguments_for_testing.append(['-a'])
    arguments_for_testing.append(['--shell-logger'])
    arguments_for_testing.append(['--enable-experimental-instant-mode'])
    arguments_for_testing.append(['-h'])
    arguments_for_testing.append(['-y'])
    arguments_for_testing.append(['-r'])
    arguments_for_testing.append(['-d'])
    arguments_for_testing.append(['--force-command'])

# Generated at 2022-06-24 05:09:06.791942
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    #test that the method print_usage actually prints usage
    parser = Parser()
    assert parser.print_usage(formatter = lambda prog : "usage") == "usage"


# Generated at 2022-06-24 05:09:12.349680
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from thefuck.main import Parser
    f = StringIO()
    sys.stderr = f
    p = Parser()
    p.print_usage()
    sys.stderr = sys.__stderr__
    assert f.getvalue() == 'usage: thefuck [--version] [-a [custom-alias-name]] [-l shell_logger] [--enable-experimental-instant-mode] [-h] [-d] [--force-command force-command] [command [command ...]]\n'


# Generated at 2022-06-24 05:09:20.349214
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import _sys_stdout
    from .const import STDERR_WRITE_MODE

    output = _sys_stdout.getvalue()
    _sys_stdout.truncate(0)
    _sys_stdout.seek(0)
    parser = Parser()
    parser.print_usage()
    assert _sys_stdout.getvalue() != output
    _sys_stdout.truncate(0)
    _sys_stdout.seek(0)



# Generated at 2022-06-24 05:09:28.264684
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class err_mock(object):
        def write(self, arg):
            self.error = arg
    errsys = err_mock()
    sys.stderr = errsys
    parser = Parser()
    parser.print_usage()
    assert errsys.error == 'usage: thefuck [--version] [--alias [custom-alias-name]] [--shell-logger LOGGER] [--enable-experimental-instant-mode] [--help] [-d] [--force-command COMMAND] [command [command ...]]\n'

# Generated at 2022-06-24 05:09:29.402334
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:09:39.753004
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # useing sys.stdout because print_usage() uses sys.stderr prints 
    # in the terminal
    output = StringIO()
    sys.stdout = output
    parser = Parser()
    parser.print_usage()
    sys.stdout = sys.__stdout__  # get back to normal terminal
    parser_print_usage_printed = output.getvalue().strip()
    assert parser_print_usage_printed == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [--force-command FORCE_COMMAND] [-d] [--] [command [command ...]]"


# Generated at 2022-06-24 05:09:44.684054
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        print("SystemExit: can not test print_help")
    # Try this in console, you will see the help text
    parser._parser.print_help()


# Generated at 2022-06-24 05:09:46.545294
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Call the print_help method of the class Parser
    parser = Parser()
    parser.print_help()
    assert True



# Generated at 2022-06-24 05:09:52.935174
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import unittest
    from mock import Mock

    class MockStderr(object):
        def __init__(self):
            self.data = ""

        def write(self, input):
            self.data += input

    class TestParser(unittest.TestCase):
        def setUp(self):
            self.mock_stderr = MockStderr()
            self.parser = Parser()

        def tearDown(self):
            pass

        def test_print_usage(self):
            self.parser.print_usage()
            self.assertIn("usage:", self.mock_stderr.data,
                          "Usage does not match")

# Generated at 2022-06-24 05:10:01.289574
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = parser.parse(["thefuck", "--version"])
    assert_equal(argv.version, True)
    assert_equal(argv.debug, False)
    assert_equal(argv.repeat, False)
    assert_equal(argv.command, [])

    argv = parser.parse(["thefuck", "--debug", "--repeat", "test"])
    assert_equal(argv.version, False)
    assert_equal(argv.debug, True)
    assert_equal(argv.repeat, True)
    assert_equal(argv.command, ["test"])
