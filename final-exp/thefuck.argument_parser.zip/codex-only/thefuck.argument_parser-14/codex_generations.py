

# Generated at 2022-06-24 04:59:57.605036
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser,Parser)

# Generated at 2022-06-24 05:00:09.223586
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    stderr = sys.stderr
    try:
        exit_code = 0

        sys.stderr = StringIO()
        Parser().print_usage()
        print_usage = sys.stderr.getvalue()
    except SystemExit as system_exit:
        exit_code = system_exit.code
    finally:
        sys.stderr = stderr


# Generated at 2022-06-24 05:00:14.517051
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-24 05:00:18.780325
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    with mock.patch('sys.stderr.write') as stderr:
        Parser().print_usage()
    stderr.assert_called_once_with('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n')



# Generated at 2022-06-24 05:00:24.102254
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    argv = ['-h', '-d', '-l', 'shell-logger.log',
            '--force-command', 'echo', 'a b c']
    parser = Parser()
    parser.parse(argv)
    parser.print_help()
    assert True


# Generated at 2022-06-24 05:00:33.677149
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['/usr/bin/python', '-c', 'import thefuck', '-l', 'out.log',
            '--enable-experimental-instant-mode', 'echo', 'foo_bar',
            '{}', '-y', '--force-command=vim', 'test']
    expected_result = ['/usr/bin/python', '-c', 'import thefuck',
            '--enable-experimental-instant-mode',
            '--force-command=vim', '-y', '--', '-l', 'out.log', 'echo',
            'foo_bar']
    parser = Parser()
    parser_result = parser._prepare_arguments(argv)
    assert parser_result == expected_result

# Generated at 2022-06-24 05:00:44.242536
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser._parser.print_usage(sys.stderr)
    parser._parser.print_help(sys.stderr)
    parser._parser.parse_args([])
    parser._parser.parse_args(['-v'])
    parser._parser.parse_args(['--version'])
    parser._parser.parse_args(['-a'])
    parser._parser.parse_args(['--alias'])
    parser._parser.parse_args(['--alias', 'alias'])
    parser._parser.parse_args(['-y'])
    parser._parser.parse_args(['--yes'])
    parser._parser.parse_args(['--repeat'])
    parser._parser.parse_args(['-l'])

# Generated at 2022-06-24 05:00:46.898724
# Unit test for constructor of class Parser
def test_Parser():
	parser = Parser()
	return True


# Generated at 2022-06-24 05:00:56.498180
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'git', 'somearg1', 'somearg2'])
    assert args.command == ['git', 'somearg1', 'somearg2']
    args = parser.parse(['thefuck', '--yes', '-d', '--shell-logger=file', 'git', 'somearg1', 'somearg2'])
    assert args.command == ['git', 'somearg1', 'somearg2']
    assert args.debug == True
    assert args.shell_logger == 'file'
    assert args.yes == True
    args = parser.parse(['thefuck', '--', 'git', 'somearg1', 'somearg2'])
    assert args.command

# Generated at 2022-06-24 05:00:57.307350
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:01:04.627775
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(["thefuck", "git", "--version"])
    assert args.version == False
    assert args.alias == None
    assert args.shell_logger == None
    assert args.help == False
    assert args.debug == False
    assert args.yes == False
    assert args.repeat == False
    assert args.command == ["git", "--version"]

    args = parser.parse(["thefuck", "git", "--version", "&&", "ls"])
    assert args.version == False
    assert args.alias == None
    assert args.shell_logger == None
    assert args.help == False
    assert args.debug == False
    assert args.yes == False
    assert args.repeat == False

# Generated at 2022-06-24 05:01:05.844645
# Unit test for constructor of class Parser
def test_Parser():
    shell = Parser()
    assert shell

# Generated at 2022-06-24 05:01:06.701377
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().print_help() # No error

# Generated at 2022-06-24 05:01:13.496285
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    from mock import patch
    from .parser import Parser

    parser = Parser()
    with patch('sys.stderr') as stderr:
        parser.print_help()
        stderr.write.assert_called_with(parser._parser.format_help())



# Generated at 2022-06-24 05:01:17.238811
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    def mock_print_help(stream):
        assert stream == sys.stderr
        assert parser._parser == parser._parser

    parser._parser.print_help = mock_print_help
    parser.print_help()



# Generated at 2022-06-24 05:01:18.325523
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-24 05:01:19.725602
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True


# Generated at 2022-06-24 05:01:20.570529
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()


# Generated at 2022-06-24 05:01:31.713678
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Input
    arguments_list = ['thefuck','--help']
    # Expected output
    expected_output = "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n" \
                      "              [-l SHELL_LOGGER]\n" \
                      "              [--enable-experimental-instant-mode]\n" \
                      "              [-y | -r] [-d] [--force-command FORCE_COMMAND]\n" \
                      "              [command [command ...]]\n" \
                      "\n" \
                      "The Fuck - Magnificent app which corrects your previous\n" \
                      "console command.\n" \
                      "\n" \
                      "optional arguments:\n" \
                      "  -h, --help              show this help message and exit\n"

# Generated at 2022-06-24 05:01:40.766802
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    temp_sys_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        parser = Parser()
        parser.print_help()
        assert sys.stderr.getvalue().startswith("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]")
    finally:
        sys.stderr = temp_sys_stderr


# Generated at 2022-06-24 05:01:45.882732
# Unit test for method parse of class Parser
def test_Parser_parse():

    # Without ARGUMENT_PLACEHOLDER
    parser = Parser()
    assert parser.parse([__file__, '-v']) == parser._parser.parse_args(['-v'])
    assert parser.parse([__file__, '-a']) == parser._parser.parse_args(['-a'])
    assert parser.parse([__file__, '-l', 'logger']) == parser._parser.parse_args(['-l', 'logger'])
    assert parser.parse([__file__, '-y']) == parser._parser.parse_args(['-y'])
    assert parser.parse([__file__, '-r']) == parser._parser.parse_args(['-r'])

# Generated at 2022-06-24 05:01:50.025943
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-24 05:01:51.395564
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage() == print(parser._parser.print_usage())


# Generated at 2022-06-24 05:01:52.477215
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    obj = Parser()
    obj.print_help()



# Generated at 2022-06-24 05:01:53.066362
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-24 05:01:55.542674
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except SystemExit:
        pass


# Generated at 2022-06-24 05:01:58.830871
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    sys.argv = ['thefuck', '-h']
    p.parse(sys.argv) == p.print_help()

# Generated at 2022-06-24 05:02:03.761201
# Unit test for method parse of class Parser
def test_Parser_parse():
    sys.argv = ['thefuck', 'ls', '-l', '-a', '-h', 
    '-v', '-l', '-d', '-help', '-version', '-force-command=/usr/bin/ls', '-alias']
    parser = Parser()
    assert parser.parse(sys.argv)



# Generated at 2022-06-24 05:02:08.488502
# Unit test for constructor of class Parser
def test_Parser():
    P = Parser()
    # See if it's the same as the `__init__`.
    assert P._parser == ArgumentParser(prog='thefuck', add_help=False)

# Generated at 2022-06-24 05:02:09.658166
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    help = Parser().print_help()
    assert type(help) == None

# Generated at 2022-06-24 05:02:10.514683
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-24 05:02:11.343636
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-24 05:02:20.224300
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parsed_arguments = parser.parse(["/usr/bin/python3", "run.py", "git ci"])

    assert parsed_arguments.shell_logger == None
    assert parsed_arguments.debug == False
    assert parsed_arguments.enable_experimental_instant_mode == False
    assert parsed_arguments.force_command == None
    assert parsed_arguments.command == ['git', 'ci']
    assert parsed_arguments.repeat == False
    assert parsed_arguments.yes == False
    assert parsed_arguments.alias == None
    assert parsed_arguments.version == False
    assert parsed_arguments.help == False


# Generated at 2022-06-24 05:02:30.023841
# Unit test for constructor of class Parser
def test_Parser():
    from .const import VERSION
    argv0 = ['thefuck', '-v']
    argv1 = ['thefuck', '-a', 'fuck']
    argv2 = ['thefuck', '-l', 'log']
    argv3 = ['thefuck', '-h']
    argv4 = ['thefuck', '-d', '-y', 'ls']
    argv5 = ['thefuck', '-r', 'ls']
    argv6 = ['thefuck', '--shell-logger', 'log']
    argv7 = ['thefuck', '--help']
    argv8 = ['thefuck', '-y', 'ls']
    argv9 = ['thefuck', 'ls']
    argv10 = ['thefuck', 'ls', '-a']


# Generated at 2022-06-24 05:02:33.034829
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    capturedOutput = StringIO.StringIO()
    sys.stderr = capturedOutput
    parser.print_help()
    sys.stderr = sys.__stderr__
    assert "usage: thefuck" in capturedOutput.getvalue()



# Generated at 2022-06-24 05:02:35.667698
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv=['thefuck','git commint -m',ARGUMENT_PLACEHOLDER,'--parameter']
    parser=Parser()
    args=parser._prepare_arguments(argv[1:])

# Generated at 2022-06-24 05:02:37.104298
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser is not None


# Generated at 2022-06-24 05:02:37.923678
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:02:38.715583
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None

# Generated at 2022-06-24 05:02:45.548651
# Unit test for constructor of class Parser
def test_Parser():
    """
    TestParser()
    Print the help message and parsing results with different args.
    """
    
    parser = Parser()
    print('-----help message-----')
    parser.print_help()
    print()
    print('-----correct args-----')
    correct_argv = ['fuck', 'ls']
    print('argv = {} \n{}'.format(correct_argv, parser.parse(correct_argv)))

    print('-----wrong args-----')
    incorrect_argv = ['fuck', '-l', 'd', 'g', ARGUMENT_PLACEHOLDER, 'cd']
    print('argv = {} \n{}'.format(incorrect_argv, parser.parse(incorrect_argv)))
    
    
    
    

#test_Parser()

# Generated at 2022-06-24 05:02:47.037465
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None



# Generated at 2022-06-24 05:02:53.035175
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO

    _stdout = sys.stdout
    sys.stdout = _stdout = StringIO()

    parser = Parser()
    parser.print_usage()

    _stdout.seek(0)
    assert 'usage: thefuck' in _stdout.read()
    sys.stdout = _stdout



# Generated at 2022-06-24 05:02:54.701909
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    return parser

# Generated at 2022-06-24 05:03:01.900840
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    save_stdout = sys.stdout

# Generated at 2022-06-24 05:03:06.907102
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .output import print_usage
    from .settings import load_settings
    from .utils import get_alias

    settings = load_settings()
    settings.alias = get_alias(settings)
    print_usage(settings)



# Generated at 2022-06-24 05:03:09.210514
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    argv = parser._prepare_arguments(['arg1', 'arg2', 'arg3'])
    assert argv == ['arg1', 'arg2', 'arg3']



# Generated at 2022-06-24 05:03:10.023348
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p is not None

# Generated at 2022-06-24 05:03:11.671547
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-24 05:03:22.538234
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    command = 'thefuck'
    command_with_placeholder = 'thefuck {}'.format(ARGUMENT_PLACEHOLDER)

    assert parser.parse([command, '--yes']) == parser.parse([command_with_placeholder, '--yes'])
    assert parser.parse([command, '--yes', ARGUMENT_PLACEHOLDER]) == parser.parse([command_with_placeholder, '--yes'])
    assert parser.parse([command, 'git', 'branch']) == parser.parse([command_with_placeholder, 'git', 'branch'])
    assert parser.parse([command, 'git', 'branch', ARGUMENT_PLACEHOLDER]) == parser.parse([command_with_placeholder, 'git', 'branch'])

# Generated at 2022-06-24 05:03:31.720417
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    Test that parse successfully parses -v, -l, -h, and other
    command-line arguments, and sets a default for --enable-experimental-instant-mode
    """
    parser = Parser()
    # arguments with space
    args = parser.parse(["thefuck", "-v"])
    assert args.version == True
    assert args.debug == False
    assert args.shell_logger == None
    assert args.force_command == None
    assert args.command == []
    assert args.alias == None
    assert args.shell_logger == None
    assert args.yes == False
    assert args.repeat == False
    assert args.help == False
    # arguments with equals sign
    args = parser.parse(["thefuck", "-l=/tmp/log.txt"])
    assert args.shell_

# Generated at 2022-06-24 05:03:35.273874
# Unit test for constructor of class Parser
def test_Parser():
    argument_parser = Parser()
    actual_parser = ArgumentParser()
    assert actual_parser.prog == argument_parser._parser.prog
    assert actual_parser.add_help == argument_parser._parser.add_help


# Generated at 2022-06-24 05:03:39.866467
# Unit test for method print_help of class Parser
def test_Parser_print_help():

    import StringIO

    def parse(argv):
        parser = Parser()
        return parser.parse(argv)

    def capture_print(stderr):
        return StringIO.StringIO()

    argv = ['thefuck', '-h']
    stderr = capture_print('stdout')
    parse(argv)

# Generated at 2022-06-24 05:03:50.637368
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck']) == \
        Namespace(command=[], debug=False, help=False, repeat=False,
                  yes=False, force_command=None,
                  shell_logger=None, alias=None,
                  enable_experimental_instant_mode=False)
    assert Parser().parse(['thefuck', 'ls', '-l']) == \
        Namespace(command=['ls', '-l'], debug=False, help=False, repeat=False,
                  yes=False, force_command=None,
                  shell_logger=None, alias=None,
                  enable_experimental_instant_mode=False)

# Generated at 2022-06-24 05:03:52.819242
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

if __name__ == "__main__":
    test_Parser_print_help()

# Generated at 2022-06-24 05:03:56.325607
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    result = parser.print_help()
    assert result == None


# Generated at 2022-06-24 05:04:00.505258
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_output = parser.print_help()
    with open("help_output.txt", "w") as f:
        f.write(help_output)

# Generated at 2022-06-24 05:04:04.325363
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    # Create instance of class Parser()
    parser = Parser()

    # Run print_usage() and catch the result
    output = parser.print_usage()
    assert output is None


# Generated at 2022-06-24 05:04:05.082447
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:04:12.204448
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    test_obj = Parser()
    captured_output = StringIO()
    sys.stderr = captured_output
    test_obj.print_usage()
    assert captured_output.getvalue() == '''usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]
                  [--enable-experimental-instant-mode] [-y] [-r]
                  [-d] [--force-command FORCE_COMMAND]
                  [command [command ...]]
\n'''

# Generated at 2022-06-24 05:04:22.374856
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from thefuck.main import get_alias
    from io import StringIO
    import sys
    old_stdout = sys.stdout

    out = StringIO()
    sys.stdout = out
    Parser().print_usage()
    output = out.getvalue().strip()
    sys.stdout = old_stdout
    assert output == '[-h] [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [--force-command force-command] [-d] [--yes|--yeah|--hard|-y] [-r] [--] [command [command ...]]'



# Generated at 2022-06-24 05:04:24.066682
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    argv = ['--force-command', 'echo', 'fuck', '--help']
    parsed = parser.parse(argv)
    assert parsed.force_command == 'echo'
    assert parsed.help == False

# Generated at 2022-06-24 05:04:32.526185
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    a = p.parse(['thefuck', '-a', 'fuck'])
    assert a.alias == 'fuck'

    b = p.parse(['thefuck', 'fuck', '-a'])
    assert b.alias == get_alias()

    c = p.parse(['thefuck', '$(date)', 'fuck'])
    assert c.command == ['$(date)', 'fuck']

    d = p.parse(['thefuck', 'fuck'])
    assert d.command == ['fuck']

    e = p.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'fuck', 'these', 'args'])
    assert e.command == ['fuck', 'these', 'args']


# Generated at 2022-06-24 05:04:35.013487
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import capture_output
    with capture_output('stderr') as (out, _):
        Parser().print_usage()
    assert out.getvalue().startswith('usage: thefuck')


# Generated at 2022-06-24 05:04:36.667218
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    if parser._parser.__class__ != ArgumentParser:
       return 1
    else:
       return 0

# Generated at 2022-06-24 05:04:37.411969
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    return parser

# Generated at 2022-06-24 05:04:39.601310
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
# test_Parser_print_usage()


# Generated at 2022-06-24 05:04:43.401916
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)



# Generated at 2022-06-24 05:04:48.477352
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == sys.stderr.write('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [command [command ...]]\n')


# Generated at 2022-06-24 05:04:52.858319
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    argv = ['thefuck', '-v']
    parser = Parser()
    parser.parse(argv)
    with patch('thefuck.shells.get_alias', return_value='alias fuck=\'eval $(thefuck $(fc -ln -1))\'', create=True):
        assert parser.print_usage() is None



# Generated at 2022-06-24 05:04:57.566639
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    Parser().print_usage()
    assert out.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y] [-r] [-d] [--force-command FORCE_COMMAND] command ...\n'


# Generated at 2022-06-24 05:05:01.656124
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-24 05:05:07.998717
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    help_parser = Parser()
    # Print and capture the output of the help
    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    help_parser.print_help()
    out = mystdout.getvalue()
    assert len(out) > 0
    sys.stdout = old_stdout

# Generated at 2022-06-24 05:05:17.238065
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', '--verbose', 'command', ARGUMENT_PLACEHOLDER, 'arg', 'arg']
    parser = Parser()
    assert parser.parse(argv) == parser._parser.parse_args(['--', 'command', 'arg', 'arg'])

    argv2 = ['thefuck', 'command', 'arg1', 'arg2', ARGUMENT_PLACEHOLDER, 'arg', 'arg']
    assert parser.parse(argv2) == parser._parser.parse_args(['--', 'command', 'arg', 'arg'])

    argv3 = ['thefuck', '--', 'command', ARGUMENT_PLACEHOLDER, 'arg', 'arg']

# Generated at 2022-06-24 05:05:25.329159
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from . import const
    from .parser import Parser
    from .utils import get_alias

    parser = Parser()
    parser.print_help()
    assert const.PROGRAM_USAGE == u'\nUsage: thefuck [OPTIONS] [CMD [ARGS]...]\n\nOptions:\n  -h, --help\n  -v, --version\n  -a, --alias [custom-alias-name]\n  -l, --shell-logger\n  --enable-experimental-instant-mode\n  -d, --debug\n  --force-command\n  -y, --yes, --yeah, --hard\n  -r, --repeat\n'

# Generated at 2022-06-24 05:05:27.198275
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:05:31.762809
# Unit test for constructor of class Parser
def test_Parser():

    parser = Parser()
    assert(str(parser._parser) == "ArgumentParser(prog='thefuck', usage=None, description=None, formatter_class=<class 'argparse.HelpFormatter'>, conflict_handler='error', add_help=False)")


# Generated at 2022-06-24 05:05:41.315423
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_alias

    parser = Parser()
    help_alias = "[custom-alias-name] prints alias for current shell"
    help_shell_logger = "log shell output to the file"
    help_experimental_instant_mode = (
        "enable experimental instant mode, use on your own risk")
    help_help = "show this help message and exit"
    help_debug = "enable debug output"

    if get_alias() == "fuck":
        argv = (
            'fuck [-h] [-v] [-a [alias]] [-r | -y] [-l log_file] '
            '-d --enable-experimental-instant-mode command'
        )
        help_alias = help_alias.replace("custom-alias-name", "fuck")

# Generated at 2022-06-24 05:05:44.014884
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    with patch('sys.stderr.write') as error_mock:
        Parser().print_help()
        assert error_mock.call_args[0][0].startswith('usage:')


# Generated at 2022-06-24 05:05:45.448618
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True


# Generated at 2022-06-24 05:05:47.545242
# Unit test for method parse of class Parser
def test_Parser_parse():
    result = Parser().parse(['thefuck', 'ls'])
    assert result.command == ['ls']


# Generated at 2022-06-24 05:05:49.993370
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except Exception:
        assert False, 'Should not throw exception'


# Generated at 2022-06-24 05:05:51.903806
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert parser.parse(['-h'])

# Generated at 2022-06-24 05:05:55.086182
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:06:04.581709
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import sys
    parser = Parser()
    output = io.StringIO()
    sys.stderr = output
    parser.print_help()
    sys.stderr = sys.__stderr__ # reinstate sys.stderr

# Generated at 2022-06-24 05:06:07.993093
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() is not None

# Generated at 2022-06-24 05:06:10.216180
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:06:11.730739
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert len(parser._parser._actions) == 9


# Generated at 2022-06-24 05:06:20.290997
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    # Test for _prepare_arguments
    assert parser._prepare_arguments(
            ['ls', ARGUMENT_PLACEHOLDER, '-l', '-a']) ==\
            ['-l', '-a', '--', 'ls']
    assert parser._prepare_arguments(['ls', '-l', '-a']) == ['--', 'ls', '-l', '-a']
    assert parser._prepare_arguments(['ls']) == ['--', 'ls']

    # Test for _parser
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help
    assert len(parser._parser._actions) == 9

    # Test for _add_arguments
    assert parser._parser._get_positional_actions()

# Generated at 2022-06-24 05:06:24.010439
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from .const import USAGE, COMMANDS
    from .utils import wrap_command
    import sys
    out = StringIO()
    Parser().print_help()
    sys.stdout = out

# Generated at 2022-06-24 05:06:27.300974
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    print(a)
    a._add_arguments()
    print(a)
    a = Parser()
    print(a)
    a._add_arguments()
    print(a)

# Generated at 2022-06-24 05:06:36.964977
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

# Generated at 2022-06-24 05:06:38.863226
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    ouput_help = parser.print_usage()
    assert ouput_help == None


# Generated at 2022-06-24 05:06:47.352710
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # assert parser._add_arguments() == None
    # assert parser._add_conflicting_arguments() == None
    # assert parser._prepare_arguments(['fuck', 'ls', '-l']) == ['ls', '-l', '--']
    # assert parser._prepare_arguments(['fuck', 'ls', '-l', 'fuck', '-h']) == ['--help', '--']
    # assert parser.parse(['fuck', '-v']) == Namespace(alias=None, command=[], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=True, yeah=False, yes=False)
    # assert parser.parse(['fuck']) == Namespace(alias=None, command=[], debug=False,

# Generated at 2022-06-24 05:06:48.124148
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    assert parser.parse("fuck") == parse("fuck")



# Generated at 2022-06-24 05:06:49.615595
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-24 05:06:50.578834
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

test_Parser()

# Generated at 2022-06-24 05:06:51.937252
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:06:57.642810
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    tmp_file = open('tmp.txt', 'w+')
    sys.stderr = tmp_file
    Parser().print_help()
    tmp_file.seek(0)
    line = tmp_file.readline().strip()
    tmp_file.close()
    os.remove('tmp.txt')
    assert line == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]'

# Generated at 2022-06-24 05:07:01.210699
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().print_help()

# Generated at 2022-06-24 05:07:04.423983
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parse = parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-d', '--debug']).debug
    assert parse is True


# Generated at 2022-06-24 05:07:07.754229
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parse_results = parser.parse(['yeah', '--', 'manage.py', ARGUMENT_PLACEHOLDER, 'runserver'])
    assert parse_results.command == ['runserver']


# Generated at 2022-06-24 05:07:08.247164
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:07:15.244596
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import USAGE_TEXT
    from unittest.mock import patch
    from io import StringIO
    import sys
    
    parser = Parser()
    original_stderr = sys.stderr
    sys.stderr = StringIO()
    parser.print_usage()
    sys.stderr.seek(0)
    output = sys.stderr.read()
    sys.stderr = original_stderr
    assert output.strip() == USAGE_TEXT.strip()

# Generated at 2022-06-24 05:07:17.172723
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    return True


# Generated at 2022-06-24 05:07:19.000045
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    a = Parser()
    output = StringIO()
    a.print_help()

# Generated at 2022-06-24 05:07:19.640995
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-24 05:07:27.002457
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    out = StringIO()
    parser = Parser()
    parser.parse(['/usr/local/bin/fuck'])
    parser.print_help(out)

# Generated at 2022-06-24 05:07:28.147737
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:07:30.345901
# Unit test for constructor of class Parser
def test_Parser():
    # Test for place of alias arg
    p = Parser()
    assert p._parser._actions[1].option_strings == ['-a', '--alias']


# Generated at 2022-06-24 05:07:32.680708
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', '-v'])
    assert args.version is True



# Generated at 2022-06-24 05:07:36.409840
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    # monkey_patch
    old = sys.stderr
    sys.stderr = out = StringIO()
    p.print_usage()
    sys.stderr = old
    assert "usage: thefuck" in out.getvalue()


# Generated at 2022-06-24 05:07:37.626707
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()


# Generated at 2022-06-24 05:07:39.346071
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-24 05:07:48.396080
# Unit test for constructor of class Parser
def test_Parser():
    from . import const
    from .config import Config
    from .manage_shell import supported_shells, get_aliases

    aliases = get_aliases(supported_shells)
    conf = Config(aliases=aliases)
    parser = Parser()

# Generated at 2022-06-24 05:07:50.764839
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class FakeFile(object):
        def __init__(self):
            self.string = ''
        def write(self, string):
            self.string = string

    fake_file = FakeFile()
    parser = Parser()
    parser.print_help(fake_file)
    assert fake_file.string.startswith('usage: thefuck')

# Generated at 2022-06-24 05:07:51.513097
# Unit test for method print_help of class Parser
def test_Parser_print_help():           
    args = Parser()
    args.print_help()

# Generated at 2022-06-24 05:07:54.540697
# Unit test for method parse of class Parser
def test_Parser_parse():
    # given
    parser = Parser()
    # when
    parsed = parser.parse(['thefuck', 'ls', '-lah'])
    # then
    assert parsed.command == ['ls', '-lah']


# Generated at 2022-06-24 05:07:56.222764
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.prog == 'thefuck'


# Generated at 2022-06-24 05:08:03.734969
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from unittest.mock import patch

    parser = Parser()
    argv = ['thefuck', '--alias', 'fuck']
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        parser.print_usage()
        assert mock_stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] command ...\n'


# Generated at 2022-06-24 05:08:07.609408
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    f = io.StringIO()
    parser.print_help(file=f)

    assert 'show this help message' in f.getvalue().strip()



# Generated at 2022-06-24 05:08:13.485073
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    import sys
    sys.stderr = StringIO()

    parser = Parser()
    parser.print_usage()

    assert sys.stderr.getvalue() == """usage: thefuck [-y|-r] [--debug] [--force-command force-command] [--help] [--shell-logger shell-logger] [--alias [custom-alias-name]] [--enable-experimental-instant-mode] [command [command ...]]

"""
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:08:15.536420
# Unit test for method parse of class Parser
def test_Parser_parse():
    command = ['thefuck', 'fuck', 'me!', '-v']

    Parser().parse(command)



# Generated at 2022-06-24 05:08:18.662812
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'tail', '-n', '2', 'file.txt']) == parser.parse(['thefuck', 'tail', '-n', '2', 'file.txt'])


# Generated at 2022-06-24 05:08:19.357385
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None


# Generated at 2022-06-24 05:08:22.781360
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    with patch('sys.stderr') as stderr:
        result = parser.print_help()
        assert result == None


# Generated at 2022-06-24 05:08:25.301419
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse('thefuck --alias what where'.split())

    assert args.alias == 'what'
    assert args.command == ['where']

# Generated at 2022-06-24 05:08:31.123001
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    assert [], parser._prepare_arguments([])
    assert ['--', 'test'], parser._prepare_arguments(['test'])
    assert ['--'], parser._prepare_arguments(['--'])
    assert ['--', 'test', 'test'], parser._prepare_arguments(['test', 'test'])
    assert ['--', '--test', '--more-test'], parser._prepare_arguments(['--test', '--more-test'])
    assert ['--'], parser._prepare_arguments([ARGUMENT_PLACEHOLDER])
    assert ['-v'], parser._prepare_arguments([ARGUMENT_PLACEHOLDER, '-v'])

# Generated at 2022-06-24 05:08:33.011817
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

#test_Parser_print_usage()

# Generated at 2022-06-24 05:08:42.848449
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['fuck', 'wtf', '-l', '--hey', '-d', '--']
    assert parser.parse(argv).command == ['wtf', '-l', '--hey', '-d', '--']

    argv = ['fuck', 'wtf', ARGUMENT_PLACEHOLDER, '-l', '--hey', '-d']
    assert parser.parse(argv).command == ['-l', '--hey', '-d']

    argv = ['fuck', 'wtf', ARGUMENT_PLACEHOLDER, '-l', '--hey', '-d', ARGUMENT_PLACEHOLDER]

# Generated at 2022-06-24 05:08:51.263585
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import mock
    from io import StringIO
    output = StringIO()
    parser = Parser()
    # Mock print_help function to write the help message to our StringIO()
    # instance instead of stderr
    with mock.patch('argparse.ArgumentParser.print_help',
                    side_effect=lambda stream=None: parser._parser.print_help(output)):
        parser.print_help()
        # Assert that the output contains the string "thefuck"
        assert "thefuck" in output.getvalue()

# Generated at 2022-06-24 05:08:55.305663
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    temp = sys.stderr
    class _FakeFile(object):
        def write(self, text):
            self.txt = text

    sys.stderr = FakeFile = _FakeFile()
    Parser().print_help()
    help_message = FakeFile.txt
    assert '-h' in help_message
    assert '-v' in help_message
    assert '--debug' in help_message
    assert '--help' in help_message
    assert '--shell-logger' in help_message
    sys.stderr = temp

# Generated at 2022-06-24 05:08:58.034650
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """This test is designed to check the method print_usage
    of class Parser.

    """
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-24 05:09:06.964059
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from .utils import is_windows
    parser = Parser()
    buf = StringIO()
    parser.print_help(file=buf)
    buf.seek(0)
    help_text = buf.read()
    if is_windows:
        first_line_of_help_text = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n            [-l SHELL_LOGGER]\n            [--enable-experimental-instant-mode]\n            [-y | -r] [-d] [--force-command FORCE_COMMAND]\n            [command [command ...]]\n'

# Generated at 2022-06-24 05:09:09.063378
# Unit test for method print_help of class Parser
def test_Parser_print_help():

    # Create new instance of class Parser
    parser = Parser()

    # Call method print_help of class Parser
    parser.print_help()


# Generated at 2022-06-24 05:09:12.149575
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    help = []
    def mock_print_help(file):
        help.append(file.read())
    setattr(sys.stderr, "read", mock_print_help)
    p = Parser()
    p.print_help()
    assert "usage:" not in help[0]

# Generated at 2022-06-24 05:09:15.849898
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser

# Generated at 2022-06-24 05:09:17.036948
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser._parser)


# Generated at 2022-06-24 05:09:18.283605
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser();
    assert p


# Generated at 2022-06-24 05:09:18.906000
# Unit test for method parse of class Parser
def test_Parser_parse():
	assert Parser().parse(['thefuck'])

# Generated at 2022-06-24 05:09:20.639869
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None

# Generated at 2022-06-24 05:09:30.841809
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser = Parser();
    usage = parser.parse(["fuck"]);
    assert usage.version == False;
    assert usage.alias == None;
    assert usage.shell_logger == None;
    assert usage.enable_experimental_instant_mode == False;
    assert usage.help == False;
    assert usage.yes == False;
    assert usage.repeat == False;
    assert usage.debug == False;
    assert usage.command == [];

    usage = parser.parse(["fuck", "--version"]);
    assert usage.version == True;
    assert usage.alias == None;
    assert usage.shell_logger == None;
    assert usage.enable_experimental_instant_mode == False;
    assert usage.help == False;
    assert usage.yes == False;
    assert usage.repeat == False;

# Generated at 2022-06-24 05:09:32.161468
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # GIVEN
    parser = Parser()
    parser._parser._actions[8].help = 'Unit test'

    # WHEN
    parser.print_help()

# Generated at 2022-06-24 05:09:36.879001
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    stderr = sys.stderr
    out = StringIO.StringIO()
    sys.stderr = out

    parser.print_help()
    sys.stderr = stderr
    assert out.getvalue().startswith("usage: ")



# Generated at 2022-06-24 05:09:39.893645
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    output = StringIO()
    sys.stderr = output
    p.print_usage()
    sys.stderr = sys.__stderr__
    assert 'usage' in output.getvalue()
    output.close()

# Generated at 2022-06-24 05:09:48.942655
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-24 05:09:51.385031
# Unit test for method parse of class Parser
def test_Parser_parse():
    Parser().parse(['--force-command', 'ls'])

# Generated at 2022-06-24 05:09:53.303181
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    assert a._add_arguments
    assert a.parse


# Generated at 2022-06-24 05:10:02.150684
# Unit test for constructor of class Parser
def test_Parser():
    """
    Test the constructor of class Parser.
    """
    parser = Parser()

    # Private attribute _parser
    assert type(parser._parser) == ArgumentParser
    assert parser._parser.prog == 'thefuck'
    assert not parser._parser.add_help

    # Private attribute _shell_logger
    assert parser._shell_logger == None

    # Public attribute args
    assert type(parser.args) == Namespace
    assert parser.args.command == []
    assert not parser.args.version
    assert not parser.args.shell_logger
    assert not parser.args.debug
    assert not parser.args.yes
    assert not parser.args.repeat
    assert not parser.args.help