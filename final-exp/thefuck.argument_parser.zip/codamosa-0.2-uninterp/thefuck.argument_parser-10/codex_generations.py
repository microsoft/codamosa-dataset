

# Generated at 2022-06-18 06:24:56.945562
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:24:58.089307
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:08.763026
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['--', 'ls'])
   

# Generated at 2022-06-18 06:25:18.015806
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '-v'])
    assert args.version == True
    args = parser.parse(['thefuck', '-a'])
    assert args.alias == 'fuck'
    args = parser.parse(['thefuck', '-a', 'alias'])
    assert args.alias == 'alias'
    args = parser.parse(['thefuck', '-l', 'log'])
    assert args.shell_logger == 'log'
    args = parser.parse(['thefuck', '--enable-experimental-instant-mode'])
    assert args.enable_experimental_instant_mode == True
    args = parser.parse(['thefuck', '-h'])
    assert args.help == True

# Generated at 2022-06-18 06:25:24.487380
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([
        'thefuck', '-v', '-a', 'fuck', '-l', 'log', '--enable-experimental-instant-mode',
        '-h', '-d', '--force-command', 'command', 'command', 'arg1', 'arg2',
        ARGUMENT_PLACEHOLDER, 'arg3', 'arg4']) == \
        parser._parser.parse_args(['-v', '-a', 'fuck', '-l', 'log', '--enable-experimental-instant-mode',
                                   '-h', '-d', '--force-command', 'command', '--', 'command', 'arg1', 'arg2',
                                   'arg3', 'arg4'])

# Generated at 2022-06-18 06:25:25.538156
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:34.915027
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.usage == None
    assert parser._parser.epilog == None
    assert parser._parser.version == None
    assert parser._parser.formatter_class == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:25:37.404234
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:25:44.637544
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:25:56.631668
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-la']) == parser.parse(['thefuck', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la']) == parser.parse(['thefuck', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la']) == parser.parse(['thefuck', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la']) == parser.parse(['thefuck', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la']) == parser.parse(['thefuck', 'ls', '-la'])

# Generated at 2022-06-18 06:26:08.534387
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:12.822614
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None


# Generated at 2022-06-18 06:26:13.896933
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:15.816188
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:25.840516
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a']) == parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])


# Generated at 2022-06-18 06:26:33.769292
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == \
        parser._parser.parse_args(['-a', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a', '-b']) == \
        parser._parser.parse_args(['-a', '-b', '--', 'ls', '-l'])

# Generated at 2022-06-18 06:26:34.392486
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:35.027227
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:38.659001
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:26:49.082192
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '--', '--'])

# Generated at 2022-06-18 06:27:22.057939
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:27:32.237442
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])

# Generated at 2022-06-18 06:27:41.052932
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:27:52.028172
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:28:02.833011
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])

# Generated at 2022-06-18 06:28:04.415040
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:28:05.425277
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:15.464344
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:28:17.580896
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:25.296297
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', 'fuck'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', 'fuck']) == parser.parse(['thefuck', 'ls', '-l', '-a', 'fuck'])

# Generated at 2022-06-18 06:29:16.201514
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:29:17.330094
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:29:18.571413
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:29:28.096833
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['--', 'ls'])

# Generated at 2022-06-18 06:29:28.906988
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:29:30.149245
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-18 06:29:41.420665
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:29:50.056302
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-d']) == \
        parser.parse(['thefuck', '-d', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-d']) == \
        parser.parse(['thefuck', '-d', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-d']) == \
        parser.parse(['thefuck', '-d', 'ls', '-la'])

# Generated at 2022-06-18 06:29:50.648051
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:00.544033
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', 'fuck'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', 'fuck', 'fuck'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', 'fuck', 'fuck', 'fuck'])

# Generated at 2022-06-18 06:32:04.660441
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[0].default == False
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[1].default == None

# Generated at 2022-06-18 06:32:05.872640
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:32:12.406476
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser._parser.parse_args(['-v'])
    assert parser.parse(['thefuck', '-a']) == parser._parser.parse_args(['-a'])
    assert parser.parse(['thefuck', '-a', 'fuck']) == parser._parser.parse_args(['-a', 'fuck'])
    assert parser.parse(['thefuck', '-l', 'log']) == parser._parser.parse_args(['-l', 'log'])
    assert parser.parse(['thefuck', '--enable-experimental-instant-mode']) == parser._parser.parse_args(['--enable-experimental-instant-mode'])

# Generated at 2022-06-18 06:32:18.799278
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [command [command ...]]\n'


# Generated at 2022-06-18 06:32:20.466087
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-18 06:32:21.486610
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:22.823803
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-18 06:32:23.684536
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:31.839511
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'git', 'push', 'origin', 'master']) == \
        parser._parser.parse_args(['git', 'push', 'origin', 'master'])
    assert parser.parse(['thefuck', 'git', 'push', 'origin', 'master', '--', '-v']) == \
        parser._parser.parse_args(['git', 'push', 'origin', 'master', '--', '-v'])
    assert parser.parse(['thefuck', 'git', 'push', 'origin', 'master', '-v']) == \
        parser._parser.parse_args(['-v', 'git', 'push', 'origin', 'master'])

# Generated at 2022-06-18 06:32:32.811573
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
