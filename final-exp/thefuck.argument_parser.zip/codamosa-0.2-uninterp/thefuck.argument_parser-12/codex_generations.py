

# Generated at 2022-06-18 06:25:05.401129
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == parser.parse(['thefuck', 'ls', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a']) == parser.parse(['thefuck', 'ls', '-l', '-a', '--'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '--'])

# Generated at 2022-06-18 06:25:06.117999
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:13.624806
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:25:14.429167
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:15.629027
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:17.978461
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:25:19.219741
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:20.059437
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:21.090426
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:31.877827
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.version == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:25:38.534968
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:45.302218
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-d'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-d', '-h'])

# Generated at 2022-06-18 06:25:47.079516
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:58.169001
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-y'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-y', '-d'])

# Generated at 2022-06-18 06:26:07.378648
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == parser._parser.parse_args(['-a', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a', '-d']) == parser._parser.parse_args(['-a', '-d', '--', 'ls', '-l'])

# Generated at 2022-06-18 06:26:08.272264
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:09.563732
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:12.096882
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:13.683207
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-18 06:26:24.520296
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-d'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-h'])

# Generated at 2022-06-18 06:26:47.745273
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-a', '-l'])

# Generated at 2022-06-18 06:26:56.492678
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:26:57.446372
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:58.337067
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:06.664216
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:27:08.260861
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-18 06:27:16.798763
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']
    assert args.debug is False
    assert args.force_command is None
    assert args.help is False
    assert args.repeat is False
    assert args.shell_logger is None
    assert args.version is False
    assert args.yes is False
    assert args.alias is None
    assert args.enable_experimental_instant_mode is False

    args = parser.parse(['thefuck', 'ls', '-l', '--', '-a'])
    assert args.command == ['ls', '-l', '-a']
    assert args.debug is False
    assert args.force_command is None
    assert args.help is False

# Generated at 2022-06-18 06:27:17.679591
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:18.933338
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:29.993110
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-d'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-d', '-h'])

# Generated at 2022-06-18 06:27:41.351499
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:42.870775
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:44.443333
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:54.192119
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:28:04.230839
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-a', '-l'])

# Generated at 2022-06-18 06:28:14.174745
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.usage == None
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:28:23.653121
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:28:24.917539
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:36.411201
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == parser._parser.parse_args(['-a', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]) == parser._parser.parse_args(['--', 'ls', '-l'])

# Generated at 2022-06-18 06:28:37.148615
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:56.139337
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:29:06.196102
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.usage == '%(prog)s [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]'
    assert parser._parser.description == 'Correct your previous console command.'
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
   

# Generated at 2022-06-18 06:29:15.012427
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])
    assert parser.parse(['thefuck', '-a']) == parser.parse(['thefuck', '--alias'])
    assert parser.parse(['thefuck', '-a', 'fuck']) == parser.parse(['thefuck', '--alias', 'fuck'])
    assert parser.parse(['thefuck', '-l', 'log']) == parser.parse(['thefuck', '--shell-logger', 'log'])
    assert parser.parse(['thefuck', '--enable-experimental-instant-mode']) == parser.parse(['thefuck', '--enable-experimental-instant-mode'])

# Generated at 2022-06-18 06:29:16.244207
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:29:17.373215
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:29:26.996170
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True
    assert parser._parser._actions == []
    assert parser._parser._optionals._actions == []
    assert parser._parser._positionals._actions

# Generated at 2022-06-18 06:29:27.781479
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-18 06:29:32.378333
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])
    assert parser.parse(['thefuck', '-a']) == parser.parse(['thefuck', '--alias'])
    assert parser.parse(['thefuck', '-l', 'log']) == parser.parse(['thefuck', '--shell-logger', 'log'])
    assert parser.parse(['thefuck', '-h']) == parser.parse(['thefuck', '--help'])
    assert parser.parse(['thefuck', '-y']) == parser.parse(['thefuck', '--yes'])
    assert parser.parse(['thefuck', '-r']) == parser.parse(['thefuck', '--repeat'])
    assert parser

# Generated at 2022-06-18 06:29:43.997690
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-h'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-d'])

# Generated at 2022-06-18 06:29:44.513238
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:25.922958
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:26.828648
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:28.066401
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:30:29.665177
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:30:37.401959
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '-a', '-v'])

# Generated at 2022-06-18 06:30:46.748509
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:30:47.504863
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:48.238209
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:48.990737
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:50.065640
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:32:27.512582
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-d'])

# Generated at 2022-06-18 06:32:28.745090
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:32:29.542984
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:30.678921
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:32:31.940287
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:32:32.620429
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:41.722352
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[0].default == False
    assert parser._parser._actions[0].action == 'store_true'
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'

# Generated at 2022-06-18 06:32:51.384499
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-la']) == \
        parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-la']) == \
        parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', 'ls', '-la']) == \
        parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-v', '-a'])

# Generated at 2022-06-18 06:32:53.324449
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:32:54.360304
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
