

# Generated at 2022-06-18 06:24:57.562495
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:00.317462
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:25:09.957231
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:25:19.506836
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', '-l', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['-l'])

# Generated at 2022-06-18 06:25:20.616074
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:21.829010
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:23.293257
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:25:34.733678
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a']) == parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])


# Generated at 2022-06-18 06:25:42.457878
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:25:53.851886
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])
    assert parser.parse(['thefuck', '-a']) == parser.parse(['thefuck', '--alias'])
    assert parser.parse(['thefuck', '-l', 'log']) == parser.parse(['thefuck', '--shell-logger', 'log'])
    assert parser.parse(['thefuck', '-h']) == parser.parse(['thefuck', '--help'])
    assert parser.parse(['thefuck', '-y']) == parser.parse(['thefuck', '--yes'])
    assert parser.parse(['thefuck', '-y']) == parser.parse(['thefuck', '--yeah'])
    assert parser

# Generated at 2022-06-18 06:26:01.409814
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:09.204603
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[3].help == 'enable experimental instant mode, use on your own risk'

# Generated at 2022-06-18 06:26:11.688684
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:13.305116
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-18 06:26:24.202375
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'

# Generated at 2022-06-18 06:26:25.418541
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:33.465698
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser._parser.parse_args(['--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-l']) == parser._parser.parse_args(['-l', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-l', '-l']) == parser._parser.parse_args(['-l', '-l', '--', 'ls', '-l'])

# Generated at 2022-06-18 06:26:35.354067
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-18 06:26:37.169888
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:38.919157
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:51.346131
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-18 06:27:00.200583
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == \
        parser._parser.parse_args(['-a', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a', '--']) == \
        parser._parser.parse_args(['-a', '--', 'ls', '-l'])

# Generated at 2022-06-18 06:27:01.892302
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:02.773280
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:03.964401
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:04.817137
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:14.080396
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])

# Generated at 2022-06-18 06:27:15.694234
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:26.903743
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '--', '--'])

# Generated at 2022-06-18 06:27:37.200389
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])

# Generated at 2022-06-18 06:28:06.375216
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:28:08.404887
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:19.533866
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'git', 'push', 'origin', 'master'])
    assert args.command == ['git', 'push', 'origin', 'master']
    assert args.yes is False
    assert args.repeat is False
    assert args.debug is False
    assert args.shell_logger is None
    assert args.force_command is None
    assert args.enable_experimental_instant_mode is False
    assert args.alias is None
    assert args.help is False
    assert args.version is False

    args = parser.parse(['thefuck', '--yes', 'git', 'push', 'origin', 'master'])
    assert args.command == ['git', 'push', 'origin', 'master']
    assert args.yes is True
    assert args.repeat is False

# Generated at 2022-06-18 06:28:20.388655
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:26.655883
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])

# Generated at 2022-06-18 06:28:28.596284
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:29.621845
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:31.069792
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:32.438231
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:41.446487
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])

# Generated at 2022-06-18 06:29:21.745400
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:29:23.160568
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:29:24.473799
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:29:26.382458
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:29:28.159499
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:29:32.620401
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:29:34.249309
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:29:39.354779
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .const import USAGE
    from .utils import get_alias

    output = StringIO()
    sys.stderr = output
    Parser().print_usage()
    assert output.getvalue() == USAGE.format(get_alias())


# Generated at 2022-06-18 06:29:43.991243
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['-l', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['--', 'ls'])

# Generated at 2022-06-18 06:29:50.478066
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].option_strings == ['-l', '--shell-logger']

# Generated at 2022-06-18 06:32:16.473853
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:32:18.214458
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:19.512358
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:20.841843
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:32:21.803997
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:30.067483
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].nargs == '?'
    assert parser._parser._actions[1].const == get_alias()
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions

# Generated at 2022-06-18 06:32:31.906812
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:32:40.709105
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-d'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-h'])

# Generated at 2022-06-18 06:32:50.627574
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == parser.parse(['thefuck', 'ls', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '--', '-l']) == parser.parse(['thefuck', 'ls', '--', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '--', '-l', '--', '-a']) == parser.parse(['thefuck', 'ls', '--', '-l', '--', '-a', '--'])

# Generated at 2022-06-18 06:32:53.140952
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
