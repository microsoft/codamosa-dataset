

# Generated at 2022-06-18 06:24:50.459408
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:24:51.137986
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:24:52.987829
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:05.015365
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'

# Generated at 2022-06-18 06:25:05.809300
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-18 06:25:12.450306
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:25:21.592787
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].nargs == '?'
    assert parser._parser._actions[1].const == get_alias()
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions

# Generated at 2022-06-18 06:25:32.818841
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.usage == None
    assert parser._parser.epilog == None
    assert parser._parser.version == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:25:35.192794
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:25:43.536037
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].const == get_alias()
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'

# Generated at 2022-06-18 06:25:54.422128
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:04.853189
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:26:16.085921
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:26:21.259015
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])

# Generated at 2022-06-18 06:26:29.953360
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '-v'])
    assert args.version == True
    assert args.alias == None
    assert args.shell_logger == None
    assert args.enable_experimental_instant_mode == False
    assert args.help == False
    assert args.debug == False
    assert args.force_command == None
    assert args.command == []
    args = parser.parse(['thefuck', '-a'])
    assert args.version == False
    assert args.alias == get_alias()
    assert args.shell_logger == None
    assert args.enable_experimental_instant_mode == False
    assert args.help == False
    assert args.debug == False
    assert args.force_command == None
    assert args.command == []
   

# Generated at 2022-06-18 06:26:30.817105
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:40.599385
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:26:42.569482
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:43.901719
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:44.763226
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:02.771945
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:27:12.067137
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '--', '--'])

# Generated at 2022-06-18 06:27:12.778787
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:22.409418
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])

# Generated at 2022-06-18 06:27:23.893219
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:25.461358
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:26.824930
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:37.118777
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == parser._parser.parse_args(['-a', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]) == parser._parser.parse_args(['--', 'ls', '-l'])

# Generated at 2022-06-18 06:27:37.609755
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:39.553605
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:00.846075
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:02.151382
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:03.065662
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:09.017316
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:28:20.069351
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--', '--', '--'])

# Generated at 2022-06-18 06:28:21.139173
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:32.878106
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.usage == None
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.version == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True

# Generated at 2022-06-18 06:28:40.810306
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:28:42.766038
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:28:53.213229
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', ARGUMENT_PLACEHOLDER, '-l'])

# Generated at 2022-06-18 06:29:36.614572
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:29:46.111214
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-y'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-y', '-r'])

# Generated at 2022-06-18 06:29:47.524041
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-18 06:29:53.629044
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.usage == None
    assert parser._parser.version == None
    assert parser._parser.formatter_class == None
    assert parser._parser.conflict_handler == None
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.allow_abbrev == True
    assert parser._parser.parents == []
    assert parser._parser.positionals == []
    assert parser._parser.optionals == []
    assert parser._parser.subparsers

# Generated at 2022-06-18 06:29:54.555608
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:05.217263
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True

# Generated at 2022-06-18 06:30:06.302839
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-18 06:30:07.729263
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:09.034272
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:30:16.432535
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-y']) == \
        parser._parser.parse_args(['-y', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-r']) == \
        parser._parser.parse_args(['-r', '--', 'ls', '-l'])

# Generated at 2022-06-18 06:32:00.630309
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:32:08.272691
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:32:19.442683
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', ARGUMENT_PLACEHOLDER, '-l'])

# Generated at 2022-06-18 06:32:28.129152
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', '-l', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', '-l', ARGUMENT_PLACEHOLDER, 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-l', 'ls'])
    assert parser

# Generated at 2022-06-18 06:32:28.976276
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:37.144658
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._actions[5].dest == 'yes'
    assert parser._parser._actions[6].dest == 'repeat'
    assert parser._parser._actions[7].dest == 'debug'
    assert parser._parser._actions[8].dest == 'force_command'

# Generated at 2022-06-18 06:32:38.139950
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:32:48.784971
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']
    assert args.debug is False
    assert args.force_command is None
    assert args.repeat is False
    assert args.yes is False
    assert args.shell_logger is None
    assert args.alias is None
    assert args.help is False
    assert args.version is False

    args = parser.parse(['thefuck', 'ls', '-l', '--', '-a'])
    assert args.command == ['ls', '-l', '-a']
    assert args.debug is False
    assert args.force_command is None
    assert args.repeat is False
    assert args.yes is False
    assert args.shell_logger is None

# Generated at 2022-06-18 06:32:54.722398
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.usage == None
    assert parser._parser.description == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:32:56.554175
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
