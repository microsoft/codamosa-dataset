

# Generated at 2022-06-18 06:24:57.885370
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:25:08.613258
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-v', '-a'])

# Generated at 2022-06-18 06:25:09.618945
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-18 06:25:19.142055
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])

# Generated at 2022-06-18 06:25:20.291263
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:21.533021
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-18 06:25:33.120345
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:25:34.638267
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:25:43.153513
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-v', '-a'])

# Generated at 2022-06-18 06:25:54.714191
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._actions[5].dest == 'yes'
    assert parser._parser._actions[6].dest == 'repeat'
    assert parser._parser._actions[7].dest == 'debug'
    assert parser._parser._actions[8].dest == 'force_command'
    assert parser._parser._actions[9].dest == 'command'


# Generated at 2022-06-18 06:26:08.768121
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', ARGUMENT_PLACEHOLDER, '-l'])

# Generated at 2022-06-18 06:26:21.386327
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser._parser.parse_args(['ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == parser._parser.parse_args(['-a', '--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]) == parser._parser.parse_args(['--', 'ls', '-l'])

# Generated at 2022-06-18 06:26:22.323110
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:23.186270
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:31.741559
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-la']) == parser.parse(['thefuck', 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la']) != parser.parse(['thefuck', 'ls', '-la', '-a'])
    assert parser.parse(['thefuck', 'ls', '-la', '-a']) == parser.parse(['thefuck', 'ls', '-la', '-a'])
    assert parser.parse(['thefuck', 'ls', '-la', '-a']) != parser.parse(['thefuck', 'ls', '-la', '-a', '-d'])

# Generated at 2022-06-18 06:26:33.603311
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:41.909236
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])

# Generated at 2022-06-18 06:26:43.319360
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:26:53.864802
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-a', '-l'])

# Generated at 2022-06-18 06:26:54.827616
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:26:59.132929
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:00.005418
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:27:02.013948
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:03.267303
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:04.444808
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:06.664647
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:27:07.936986
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:16.524742
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == parser.parse(['thefuck', 'ls', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '--', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '-l', '--', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])

# Generated at 2022-06-18 06:27:27.279292
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:27:37.523735
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].option_strings == ['-l', '--shell-logger']

# Generated at 2022-06-18 06:27:48.840456
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:49.466084
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-18 06:27:57.163462
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a']) == parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '-h'])


# Generated at 2022-06-18 06:27:58.005798
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:27:58.993080
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:00.287392
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:01.229787
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:02.488206
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:03.732228
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:04.914851
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:28:23.036473
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:28:23.839884
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-18 06:28:35.154031
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', 'fuck'])
    assert parser.parse(['thefuck', 'ls', '-l']) != parser.parse(['thefuck', 'ls', '-l', '-a', 'fuck', '-v'])

# Generated at 2022-06-18 06:28:37.285996
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:28:44.218607
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l', ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-18 06:28:54.386601
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].help == 'log shell output to the file'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-18 06:29:03.704773
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']
    assert args.debug is False
    assert args.force_command is None
    assert args.help is False
    assert args.shell_logger is None
    assert args.version is False
    assert args.yes is False
    assert args.repeat is False
    assert args.alias is None
    assert args.enable_experimental_instant_mode is False

    args = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert args.command == ['-l']
    assert args.debug is False
    assert args.force_command is None
    assert args.help is False
    assert args.shell

# Generated at 2022-06-18 06:29:11.662423
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-v', '-a'])

# Generated at 2022-06-18 06:29:12.872304
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:29:22.780166
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.usage == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:30:03.171916
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:04.752994
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:30:13.968351
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])
    assert parser.parse(['thefuck', '-a']) == parser.parse(['thefuck', '--alias'])
    assert parser.parse(['thefuck', '-l']) == parser.parse(['thefuck', '--shell-logger'])
    assert parser.parse(['thefuck', '-h']) == parser.parse(['thefuck', '--help'])
    assert parser.parse(['thefuck', '-y']) == parser.parse(['thefuck', '--yes'])
    assert parser.parse(['thefuck', '-r']) == parser.parse(['thefuck', '--repeat'])

# Generated at 2022-06-18 06:30:22.949319
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.description == None
    assert parser._parser.usage == None
    assert parser._parser.epilog == None
    assert parser._parser.parents == []
    assert parser._parser.formatter_class == argparse.HelpFormatter
    assert parser._parser.prefix_chars == '-'
    assert parser._parser.fromfile_prefix_chars == None
    assert parser._parser.argument_default == None
    assert parser._parser.conflict_handler == 'error'
    assert parser._parser.add_help == False
    assert parser._parser.allow_abbrev == True


# Generated at 2022-06-18 06:30:33.333409
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._actions[2].option_strings == ['-l', '--shell-logger']
    assert parser._parser._actions[2].help == 'log shell output to the file'

# Generated at 2022-06-18 06:30:40.576595
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-l', '-a'])
    assert args.command == ['ls', '-l', '-a']

    args = parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a'])
    assert args.command == ['ls', '-l']

    args = parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a', '-h'])
    assert args.command == ['ls', '-l']
    assert args.help

    args = parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a', '-h', '--debug'])

# Generated at 2022-06-18 06:30:41.371895
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:42.159354
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:42.985097
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:30:51.900578
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == parser.parse(['thefuck', 'ls', '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l', '--'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a']) == parser.parse(['thefuck', 'ls', '-l', '-a', '--'])
    assert parser.parse(['thefuck', 'ls', '-l', '-a', '-v']) == parser.parse(['thefuck', 'ls', '-l', '-a', '-v', '--'])

# Generated at 2022-06-18 06:33:08.320099
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == parser.parse(['thefuck', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(['thefuck', 'ls', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == parser.parse(['thefuck', 'ls', '-a', '-l'])
    assert parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a', '-l']) == parser.parse(['thefuck', 'ls', '-a', '-l', '-l'])

# Generated at 2022-06-18 06:33:08.975286
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:33:17.706401
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])
    assert parser.parse(['thefuck', '-a']) == parser.parse(['thefuck', '--alias'])
    assert parser.parse(['thefuck', '-l']) == parser.parse(['thefuck', '--shell-logger'])
    assert parser.parse(['thefuck', '-h']) == parser.parse(['thefuck', '--help'])
    assert parser.parse(['thefuck', '-y']) == parser.parse(['thefuck', '--yes'])
    assert parser.parse(['thefuck', '-r']) == parser.parse(['thefuck', '--repeat'])

# Generated at 2022-06-18 06:33:29.203543
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER

    parser = Parser()
    alias = get_alias()
    argv = ['thefuck', '-a', alias, ARGUMENT_PLACEHOLDER, 'git', 'commit', '-m', '"test"']
    arguments = parser._prepare_arguments(argv[1:])
    parser._parser.parse_args(arguments)

    out = StringIO()
    parser.print_usage(file=out)

# Generated at 2022-06-18 06:33:38.916806
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-la']) == \
        parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-la'])
    assert parser.parse(['thefuck', 'ls', '-la']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-la'])
    assert parser.parse(['thefuck', 'ls', '-la']) == \
        parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-la'])

# Generated at 2022-06-18 06:33:39.771337
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-18 06:33:40.674487
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:33:42.484726
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-18 06:33:43.322149
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-18 06:33:44.138644
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()