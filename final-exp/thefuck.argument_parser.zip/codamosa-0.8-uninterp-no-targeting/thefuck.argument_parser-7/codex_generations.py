

# Generated at 2022-06-22 00:05:48.808418
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except SystemExit:
        pass
    assert sys.stderr
    sys.stderr.seek(0)
    print_usage_output = sys.stderr.read()
    assert print_usage_output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n                   [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n                   [--]\n                   command [command ...]\n'


# Generated at 2022-06-22 00:05:59.525286
# Unit test for constructor of class Parser
def test_Parser():
    from unittest.mock import patch
    from .const import ALIAS_ARGUMENT_HEADER
    from .utils import get_alias
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)
    with patch('argparse.ArgumentParser.add_argument') as add_argument:
        for i in range(5):
            parser._add_arguments()
            assert add_argument.call_count == i + 1

    add_argument = parser._parser.add_argument
    add_argument.assert_any_call(
        '-v', '--version',
        action='store_true',
        help="show program's version number and exit")

# Generated at 2022-06-22 00:06:00.977676
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert isinstance(p._parser, ArgumentParser)


# Generated at 2022-06-22 00:06:03.099457
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser=Parser()
    parser.print_usage()
    assert parser.print_usage()==None

# Generated at 2022-06-22 00:06:05.630809
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()
    assert True, "print_help() passed all test"


# Generated at 2022-06-22 00:06:15.613745
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Example 1:
    # input: thefuck --alias
    # output: usage: thefuck [-h] [-v] [-a [custom-alias-name]]
    #                [-l shell_logger]
    #                [--enable-experimental-instant-mode] [-d]
    #                [--force-command force_command]
    #                [-- [command [command ...]]]
    assert parser.print_usage() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n       [-l shell_logger]\n       [--enable-experimental-instant-mode] [-d]\n       [--force-command force_command]\n       [-- [command [command ...]]]\n'
    # Example 2:
    # input: thefuck

# Generated at 2022-06-22 00:06:26.775357
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'command --option']) \
           == Namespace(command=['command', '--option'],
                        force_command=None,
                        alias=get_alias(),
                        shell_logger=None,
                        debug=False,
                        yes=False,
                        repeat=False,
                        version=False,
                        help=False)

# Generated at 2022-06-22 00:06:30.657027
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from click.testing import CliRunner

    runner = CliRunner()
    result = runner.invoke(thefuck_alias.main, ['--help'])
    assert result.exit_code == 1
    asser

# Generated at 2022-06-22 00:06:34.466833
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        assert sys.stderr.getvalue().startswith("usage: thefuck")


# Generated at 2022-06-22 00:06:35.486921
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:06:52.228413
# Unit test for method parse of class Parser
def test_Parser_parse():
    
    _parser = Parser()
    _command = 'ls -l'
    _argument = '-r'

    # Case 1: Only command
    case_1 = _parser.parse(['thefuck', _command])
    assert case_1.command == _command.split()
    assert case_1.repeat == False
    assert case_1.yes == False

    # Case 2: Command
    case_2 = _parser.parse(['thefuck', _command, _argument])
    assert case_2.command == _command.split()
    assert case_2.repeat == True
    assert case_2.yes == False

    # Case 3: Command
    # case_3 = _parser.parse(['thefuck', _command, ARGUMENT_PLACEHOLDER, _argument])
    # assert case_3.command

# Generated at 2022-06-22 00:06:57.801777
# Unit test for method parse of class Parser
def test_Parser_parse():
    # GIVEN
    args = ['-v', '-a', '-h', '-d']
    # WHEN
    result = Parser().parse(args)
    # THEN
    assert result.version == True
    assert result.alias == None
    assert result.debug == True
    assert result.help == None


# Generated at 2022-06-22 00:07:08.296991
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # get the version
    arguments = parser.parse(['thefuck', '--version'])
    assert arguments.version == True
    assert arguments.alias == None
    assert arguments.help == None
    assert arguments.command == []
    # get the command alias
    arguments = parser.parse(['thefuck', '--alias'])
    assert arguments.version == None
    assert arguments.alias == 'fuck'
    assert arguments.help == None
    assert arguments.command == []
    # get the help info
    arguments = parser.parse(['thefuck', '--help'])
    assert arguments.version == None
    assert arguments.alias == None
    assert arguments.help == True
    assert arguments.command == []
    # show the obsolete help info
    arguments = parser.parse(['thefuck', 'fuck'])

# Generated at 2022-06-22 00:07:12.039962
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Arrange
    parser = Parser()
    # Act:
    parser.print_help()
    # Assert:
    assert True

# Generated at 2022-06-22 00:07:17.558510
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class Stderr:
        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

    stderr = Stderr()

    Parser().print_help(stderr)

    assert 'usage: thefuck' in stderr.text
    assert 'positional arguments' in stderr.text
    assert 'optional arguments' in stderr.text
    assert '-v, --version' in stderr.text
    assert '-a, --alias' in stderr.text
    assert '-l, --shell-logger' in stderr.text
    assert '-y, --yes, --yeah, --hard' in stderr.text
    assert '-r, --repeat' in stderr.text

# Generated at 2022-06-22 00:07:22.054385
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    import io
    import sys
    f = io.StringIO()
    sys.stderr = f
    parser.print_help()
    sys.stderr = sys.__stderr__
    assert "usage" in f.getvalue()

# Generated at 2022-06-22 00:07:23.747551
# Unit test for constructor of class Parser
def test_Parser():
	
	assert Parser()
	
# Unit test of _add_arguments() in class Parser

# Generated at 2022-06-22 00:07:27.664787
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    buffer_ = io.StringIO()
    sys.stderr = buffer_
    Parser().print_help()
    assert buffer_.getvalue() != ''
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:07:38.302979
# Unit test for method parse of class Parser
def test_Parser_parse():
    command_line_args = ['command', ARGUMENT_PLACEHOLDER, '-a']
    assert Parser().parse(command_line_args) == Namespace(command=['command'],
                                                           alias='fuck',
                                                           debug=False,
                                                           enable_experimental_instant_mode=False,
                                                           force_command=None,
                                                           help=False,
                                                           repeat=False,
                                                           shell_logger=None,
                                                           version=False,
                                                           yes=False)
    command_line_args = ['command', ARGUMENT_PLACEHOLDER, '--debug']

# Generated at 2022-06-22 00:07:43.143369
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Test print_usage of class Parser.
    """
    pic = Parser()
    pic.print_usage()
    assert sys.stderr == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'


# Generated at 2022-06-22 00:07:49.245207
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:07:49.846882
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:07:50.899578
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:07:56.731208
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help
    assert parser._parser._positionals.title == 'command that should be fixed'
    assert parser._parser._positionals.dest == 'command'
    assert parser._parser._optionals.title == 'optional arguments'
    assert parser._parser._optionals.description == ''
    assert parser._parser._optionals.default == argparse.SUPPRESS
    assert parser._parser._actions



# Generated at 2022-06-22 00:08:01.979637
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    args = p.parse(['thefuck', 'echo', ARGUMENT_PLACEHOLDER, '-y'])
    assert args.force_command == 'echo'
    assert args.yes == True


# Generated at 2022-06-22 00:08:11.792052
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert parser._parser.prog == 'thefuck'
    assert not parser._parser.add_help
    assert set(parser._parser._actions) == {
        'version', 'alias', 'help', 'debug', 'force_command', 'command',
        'shell_logger', 'repeat', 'yeah', 'yes', 'hard'}
    assert 'action' in set(parser._parser._actions['version'].__dict__)
    assert 'help' in set(parser._parser._actions['version'].__dict__)
    assert 'action' in set(parser._parser._actions['alias'].__dict__)
    assert 'const' in set(parser._parser._actions['alias'].__dict__)
    assert 'nargs' in set(parser._parser._actions['alias'].__dict__)


# Generated at 2022-06-22 00:08:12.978116
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-22 00:08:14.657410
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-22 00:08:16.396762
# Unit test for method parse of class Parser
def test_Parser_parse():
    obj = Parser()
    obj.parse(['tf', '-v'])

# Generated at 2022-06-22 00:08:26.136851
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse(['thefuck', '_', '-v']).version is True
    assert parser.parse(['thefuck', '_', '-a']).alias is get_alias()
    assert parser.parse(['thefuck', '_', '-r']).repeat is True
    assert parser.parse(['thefuck', '_', '-y']).yes is True
    assert parser.parse(['thefuck', '_', '-a', 'test']) == parser.parse(['thefuck', '_', '-a', 'test'])
    assert parser.parse(['thefuck', '_', '-a']).alias is get_alias()
    assert parser.parse(['thefuck', '_', '-l', '123']).shell_logger == '123'

# Generated at 2022-06-22 00:08:36.173648
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:08:41.907106
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', '[SOME_ARGUMENT]', 'echo', 'bla', 'bla'])
    asserteq(arguments.command, ['echo', 'bla', 'bla'])
    assert not arguments.yes
    assert not arguments.repeat
    assert not arguments.debug
    assert not arguments.alias


# Generated at 2022-06-22 00:08:44.418480
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False


# Generated at 2022-06-22 00:08:46.002607
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:08:55.036829
# Unit test for method parse of class Parser
def test_Parser_parse():
    test1 = Parser().parse(["thefuck","test1",ARGUMENT_PLACEHOLDER,"test2","test3"])
    assert test1.command == ["test2","test3"]

    test2 = Parser().parse(["thefuck","test1",ARGUMENT_PLACEHOLDER,"test2","test3","test4"])
    assert test2.command == ["--","test2","test3","test4"]

    test3 = Parser().parse(["thefuck","test1","test2","test3","test4"])
    assert test3.command == ["--","test1","test2","test3","test4"]

# Generated at 2022-06-22 00:09:06.026434
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['fuck', 'echo'])
    parser.parse(['fuck', 'echo', '--'])
    parser.parse(['fuck', '--', 'echo'])
    parser.parse(['fuck', '--', 'echo', '--'])
    parser.parse(['fuck', '--', 'echo', '--', '--'])
    parser.parse(['fuck'])
    parser.parse(['fuck', '--'])
    parser.parse(['fuck', '--', '--'])
    parser.parse(['fuck', ARGUMENT_PLACEHOLDER, 'echo'])
    parser.parse(['fuck', ARGUMENT_PLACEHOLDER, '--', 'echo'])

# Generated at 2022-06-22 00:09:14.945216
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    Test Parser object.
    """
    parser = Parser()
    #test with dummy command
    arguments = parser.parse(['thefuck', 'git', 'status', ARGUMENT_PLACEHOLDER, '--', '--all'])
    assert arguments.command[0] == 'git status --all'
    assert arguments.command[1] == '--'
    assert arguments.command[2] == '--all'
    #test for alias
    arguments = parser.parse(['thefuck', '--alias'])
    assert arguments.alias == get_alias()
    arguments = parser.parse(['thefuck', '--alias', 'test_alias'])
    assert arguments.alias == 'test_alias'
    #test for shell logger

# Generated at 2022-06-22 00:09:15.956287
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-22 00:09:17.615493
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None



# Generated at 2022-06-22 00:09:27.944883
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', '-v', 'python', '-c', 'print(42)']
    assert Parser().parse(argv).version
    argv = ['thefuck', '-y']
    assert Parser().parse(argv).yes
    argv = ['thefuck', '-r']
    assert Parser().parse(argv).repeat
    argv = ['thefuck', '-a']
    assert Parser().parse(argv).alias == get_alias()
    argv = ['thefuck', '-a', 'foo']
    assert Parser().parse(argv).alias == 'foo'
    argv = ['thefuck', '--enable-experimental-instant-mode']
    assert Parser().parse(argv).enable_experimental_instant_mode

# Generated at 2022-06-22 00:09:37.631987
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ["echo", "hello", "world"]
    print(parser.parse(argv))

if __name__ == "__main__":
    test_Parser_parse()

# Generated at 2022-06-22 00:09:38.634526
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-22 00:09:49.603088
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(["bla", "--help"])
    assert args.help == True 
    args = parser.parse(["bla", "--debug", "--version"])
    assert args.debug == True
    assert args.version == True
    assert args.help == None
    args = parser.parse(["bla", "-vh"])
    assert args.debug == None
    assert args.version == True
    assert args.help == True
    args = parser.parse(["bla", "--force-command", "pwd"])
    assert args.force_command == "pwd"
    assert args.debug == None
    assert args.version == None
    assert args.help == None

# Generated at 2022-06-22 00:09:58.848545
# Unit test for method parse of class Parser
def test_Parser_parse():
    # test if thefuck gives help message when --help is given
    argv = ['thefuck', '--help']
    assert Parser().parse(argv).help

    # test if thefuck gives version number when --version is given
    argv = ['thefuck', '--version']
    assert Parser().parse(argv).version

    # test if thefuck gives alias when --alias or -a is given
    assert Parser().parse(['thefuck', '--alias']).alias
    assert Parser().parse(['thefuck', '-a']).alias

    # test if thefuck gives custom alias when --alias is given as a
    # paramater with custom alias name
    assert Parser().parse(['thefuck', '--alias', 'fuck']).alias

# Generated at 2022-06-22 00:10:00.956708
# Unit test for method print_help of class Parser
def test_Parser_print_help():
	parser = Parser()
	assert parser.print_help() == None

# Generated at 2022-06-22 00:10:02.562197
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.get_default('shell_logger') is None

# Generated at 2022-06-22 00:10:13.028956
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.parse(['thefuck'])
    p.parse(['thefuck', '--version'])
    p.parse(['thefuck', '--alias'])
    p.parse(['thefuck', '--alias=tf'])
    p.parse(['thefuck', '--shell-logger=/tmp/cmd.log'])
    p.parse(['thefuck', '--help'])
    p.parse(['thefuck', '--no-help'])
    p.parse(['thefuck', '--debug'])
    p.parse(['thefuck', '-a', '-v', '--help'])
    p.parse(['thefuck', '-h', '-a'])
    p.parse(['thefuck', '--help', '--alias'])
    p

# Generated at 2022-06-22 00:10:24.007057
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # check that the placeholder is removed
    args = parser.parse(['thefuck', 'git', 'push', ARGUMENT_PLACEHOLDER, '-v'])
    assert args.command == ['git', 'push']
    assert args.version
    # and arguments after the placeholder are moved to the beginning
    args = parser.parse(['thefuck', 'git', 'push', ARGUMENT_PLACEHOLDER])
    assert args.command == ['git', 'push']
    # for commands without arguments we ignore the placeholder
    args = parser.parse(['thefuck', 'git', 'push', 'arg1'])
    assert args.command == ['git', 'push', 'arg1']

# Generated at 2022-06-22 00:10:34.340091
# Unit test for method parse of class Parser
def test_Parser_parse():
    arguments = Parser().parse(['thefuck', '-r', '--', 'ls', '-l'])
    assert arguments.repeat
    assert arguments.command == ['ls', '-l']

    arguments = Parser().parse(['thefuck', 'git', 'commit', '-m',
                                ARGUMENT_PLACEHOLDER, '-a', '--amend'])
    assert arguments.command == ['git', 'commit', '-m', '-a', '--amend']

    arguments = Parser().parse(['thefuck', 'git', 'commit', '-m',
                                ARGUMENT_PLACEHOLDER, '-a', '--amend', '--'])
    assert arguments.command == ['git', 'commit', '-m', '-a', '--amend', '--']

# Generated at 2022-06-22 00:10:44.163225
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'echo', 'hello', 'world'])
    assert args.command == ['echo', 'hello', 'world']
    assert not args.yes
    assert not args.repeat
    assert not args.debug
    assert not args.version
    assert not args.help
    assert args.force_command is None

    args = parser.parse(['thefuck', '--', 'echo', 'hello', 'world'])
    assert args.command == ['echo', 'hello', 'world']
    assert not args.yes
    assert not args.repeat
    assert not args.debug
    assert not args.version
    assert not args.help
    assert args.force_command is None


# Generated at 2022-06-22 00:11:03.669322
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = sys.stderr.write(str(parser.print_help))
    assert isinstance(output, str)

# Generated at 2022-06-22 00:11:05.302178
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:11:16.758828
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', '-v', 'ls', '-l']) == \
           p.parse(['thefuck', '-v', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a']) == \
           Namespace(version=True, alias=None, shell_logger=None, enable_experimental_instant_mode=False, help=False, debug=False, force_command=None, command=['ls', '-l'])

# Generated at 2022-06-22 00:11:27.225676
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_alias

    parser = Parser()
    help = parser.print_help()
    assert '-l, --shell-logger' in help
    assert 'log shell output to the file' in help
    assert '-v, --version' in help
    assert 'show program\'s version number and exit' in help

    alias = get_alias()
    assert '-a, --alias [custom-alias-name] prints alias' in help
    assert 'prints alias for current shell' in help
    assert '--enable-experimental-instant-mode' in help
    assert 'enable experimental instant mode' in help
    assert '-h, --help' in help
    assert 'show this help message and exit' in help
    assert '-d, --debug' in help
    assert 'enable debug output' in help

# Generated at 2022-06-22 00:11:28.390640
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser,Parser)

# Generated at 2022-06-22 00:11:33.429557
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    output = StringIO()
    sys.stderr = output
    parser = Parser()
    parser.print_usage()
    sys.stderr = sys.__stderr__
    output = output.getvalue()
    assert "thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]" in output


# Generated at 2022-06-22 00:11:43.181806
# Unit test for method parse of class Parser
def test_Parser_parse():
    class MockedArgumentParser():
        def __init__(self):
            pass

        def parse_args(self,args):
            return args

    class Parser():
        def __init__(self):
            self._parser = MockedArgumentParser()

        def _prepare_arguments(self, argv):
            return argv

        def parse(self, argv):
            return self._parser.parse_args(self._prepare_arguments(argv[1:]))

    parser = Parser()
    assert parser.parse(['', 'test executable', 'test1', 'test2']) == ['test1', 'test2']
    assert parser.parse(['', 'test executable', '--test arg1 arg2']) == ['--test', 'arg1', 'arg2']

# Generated at 2022-06-22 00:11:44.324516
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:11:54.477332
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_config
    from .settings import DEFAULT_SETTINGS

    config = get_config(DEFAULT_SETTINGS)
    parser = Parser()

    # Test for the help message

# Generated at 2022-06-22 00:12:04.379810
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    output = StringIO()
    parser = Parser()
    parser.print_usage(sys.stderr)
    usg = output.getvalue()
    output.close()
    assert "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]" in usg
    assert "[-y | -r] [-d] [--force-command FORCE_COMMAND] [--] [command [command ...]]" in usg
    assert "  -v, --version                   show program's version number and exit" in usg
    assert "  -a, --alias [custom-alias-name] prints alias for current shell" in usg

# Generated at 2022-06-22 00:12:49.145633
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print(Parser.print_usage.__doc__)



# Generated at 2022-06-22 00:12:49.809582
# Unit test for method parse of class Parser
def test_Parser_parse():
    pass

# Generated at 2022-06-22 00:12:51.490150
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.parse(['script'])
    assert parser.print_usage() == parser._parser.print_usage(sys.stderr)


# Generated at 2022-06-22 00:12:55.785030
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().parse(['']).usage == False
    assert Parser().parse(['', '-v']).usage == True
    assert Parser().parse(['', '-help']).usage == True
    assert Parser().parse(['', '--help']).usage == True


# Generated at 2022-06-22 00:13:05.121262
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['thefuck'])
    assert not args.command
    assert not args.alias
    assert not args.repeat
    assert not args.yes
    assert not args.help

    args = Parser().parse(['thefuck', 'ls'])
    assert args.command == ['ls']

    args = Parser().parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']

    args = Parser().parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls'])
    assert args.command == ['ls']

    args = Parser().parse(['thefuck', '-r', 'ls'])
    assert args.command == ['ls']
    assert args.repeat


# Generated at 2022-06-22 00:13:06.190772
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-22 00:13:07.275850
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()
    assert True

# Generated at 2022-06-22 00:13:12.619740
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Thefuck prints usage on -h, --help"""
    parser = Parser()
    args = parser.parse(['thefuck', '--help'])
    assert args.help == True
    assert args.version == False
    assert args.alias == None
    parser.print_usage()


# Generated at 2022-06-22 00:13:22.044567
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    with captured_output() as (out, err):
        p = Parser()
        p.print_usage()
    output = out.getvalue().strip()

# Generated at 2022-06-22 00:13:31.423884
# Unit test for method parse of class Parser

# Generated at 2022-06-22 00:14:39.489219
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    test_instance = Parser()

    out = StringIO()
    sys.stderr = out

    test_instance.print_help()
    output = out.getvalue().strip()

    sys.stderr = sys.__stderr__

    assert(output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [--] [command [command ...]]')

# Generated at 2022-06-22 00:14:49.296673
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_text = parser.print_help()

# Generated at 2022-06-22 00:14:58.254057
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER,
                           'file.txt', '-a'])
    assert args.command == ['ls', '-l']
    assert args.alias == True
    assert args.file_txt == '-a'
    assert args.debug == False

    args = Parser().parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER,
                           '-a'])
    assert args.command == ['ls', '-l']
    assert args.alias == True
    assert args.debug == False

    args = Parser().parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-22 00:15:09.105770
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-22 00:15:17.466733
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Make sure parse method works as expected"""

    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER,
                        '-v', '--force-command', 'some_command'])
    assert args.command == ['ls', '-la']
    assert args.v
    assert args.force_command == 'some_command'

# Generated at 2022-06-22 00:15:30.258004
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Default test: no argument
    args = parser.parse(['thefuck'])
    assert not args.debug
    assert not args.alias
    assert not args.shell_logger
    assert not args.enable_experimental_instant_mode
    assert not args.help
    assert not args.version
    assert not args.yes
    assert not args.repeat
    assert args.command == []

    # Test with argument
    args = parser.parse(['thefuck', '-d', 'ls'])
    assert args.debug
    assert not args.alias
    assert not args.shell_logger
    assert not args.enable_experimental_instant_mode
    assert not args.help
    assert not args.version
    assert not args.yes
    assert not args.repeat

# Generated at 2022-06-22 00:15:37.465272
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    args = ['thefuck', 'ls', '-al', '{}', '-l']
    res = vars(p.parse(args))
    assert res['command'][0] == 'ls'
    assert res['command'][1] == '-al'
    assert res['shell_logger'] == '-l'


# Generated at 2022-06-22 00:15:49.778225
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
	usage = Parser().print_usage()
