

# Generated at 2022-06-22 00:05:44.241890
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert sys.argv[0] == "setup.py"
    test_args = sys.argv[1:]
    assert p.parse(test_args)
    assert p.print_usage()
    assert p.print_help()

# Generated at 2022-06-22 00:05:47.770890
# Unit test for method parse of class Parser
def test_Parser_parse():
    # alias_type = _ShellType.default
    parser = Parser()
    assert parser.parse(['./thefuck', '--repeat', 'git', 'cll']) == \
        parser._parser.parse_args(['--repeat', 'git', 'cll'])
    assert parser.parse(['./thefuck', '--repeat', 'git', 'cll']) == \
        parser._parser.parse_args(['--repeat', 'git', '--', 'cll'])
    assert parser.parse(['./thefuck', '--repeat', 'git', 'cll', '--amend', '-f']) == \
        parser._parser.parse_args(['--repeat', 'git', '--', 'cll', '--amend', '-f'])

# Generated at 2022-06-22 00:05:50.705394
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    This test will check the print_help() method of class Parser
    """
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-22 00:06:01.058974
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(["", "-a", "-y"])
    assert args.command == []
    assert args.alias is True 
    assert args.yes is True

    args = parser.parse(["", "--alias", "fuck", "-y"])
    assert args.command == []
    assert args.alias == 'fuck' 
    assert args.yes is True

    args = parser.parse(["", "git rebase", "-y"])
    assert args.command == ['git', 'rebase']
    assert args.alias is None
    assert args.yes is True

    args = parser.parse(["", "git rebase", "--yes"])
    assert args.command == ['git', 'rebase']
    assert args.alias is None
    assert args.yes is True


# Generated at 2022-06-22 00:06:03.537574
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    try:
        PARSER.print_help()
    except SystemExit:
        pass
    else:
        assert False



# Generated at 2022-06-22 00:06:14.489312
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['fuck']) == \
        Parser()._parser.parse_args([])
    assert Parser().parse(['fuck', '-vd']) == \
        Parser()._parser.parse_args(['-vd'])
    assert Parser().parse(['fuck', '-v', '-d', 'some']) == \
        Parser()._parser.parse_args(['-vd', '--', 'some'])
    assert Parser().parse(['fuck', '77', ARGUMENT_PLACEHOLDER, '-v']) == \
        Parser()._parser.parse_args(['-v', '--', '77'])
    assert Parser().parse(['fuck', ARGUMENT_PLACEHOLDER, '-v', '77']) == \
        Pars

# Generated at 2022-06-22 00:06:22.296953
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from mock import patch
    from sys import stderr
    parser = Parser()
    parser.print_usage()
    try:
        stderr.write.assert_called_once_with('usage: thefuck [--version] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-h] [-y|-r] [-d] [--force-command force-command] [command]\n')
    except:
        raise


# Generated at 2022-06-22 00:06:24.827110
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse(['fuck', 'ls', 'cd'])
    assert parser.print_help()
    assert parser.print_usage()

# Generated at 2022-06-22 00:06:26.342001
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:06:30.606711
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser._prepare_arguments(['thefuck','ls','--','~/','~/.bashrc','~/'])  
    assert args == ['--','~/','~/.bashrc','~/']

# Generated at 2022-06-22 00:06:47.850247
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-22 00:06:48.771478
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:06:50.594831
# Unit test for constructor of class Parser
def test_Parser():
    # simple test (just to be sure)
    p = Parser()
    p.print_usage()
    p.print_help()

# Generated at 2022-06-22 00:06:53.206493
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args_for_parse = parser.parse("thefuck --placeholder ls".split())
    command = args_for_parse.command
    assert command == ["--", "thefuck", "ls"]

# Generated at 2022-06-22 00:06:55.565847
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None

# Generated at 2022-06-22 00:06:59.533934
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(sys.argv)
    parser.print_usage()
    parser.print_help()

if __name__ == '__main__':
    def main():
        test_Parser()
    main()

# Generated at 2022-06-22 00:07:05.816239
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(["thefuck","-d","--force-command","ps aux | grep bash","git","-h","--placeholder","-a","alias"])
    assert args.debug == True
    assert args.force_command == "ps aux | grep bash"
    assert args.command == ["git","-h"]
    assert args.debug == True
    assert args.alias == "alias"


# Generated at 2022-06-22 00:07:07.427467
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser._parser


# Generated at 2022-06-22 00:07:13.028484
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser
    assert parser._parser.prog == 'thefuck'
    assert not parser._parser.help
    assert parser._parser.add_help == False
    assert len(parser._parser._actions) == 11


# Generated at 2022-06-22 00:07:20.423574
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '-d', '-y', 'ls', '-l'])
    assert args.debug is True
    assert args.yes is True
    assert args.repeat is False
    assert args.command == ['ls', '-l']
    assert args.shell_logger is None
    assert args.enable_experimental_instant_mode is False

    args = parser.parse(['thefuck', '-d', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert args.debug is True
    assert args.yes is False
    assert args.repeat is False
    assert args.command == ['-l']
    assert args.shell_logger is None
    assert args.enable_experimental_instant_mode is False

# Generated at 2022-06-22 00:07:34.672099
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser._parser.parse_args(['something', 'else']).command == \
        ['something', 'else']
    assert parser._parser.parse_args(['--', 'something', 'else']).command == \
        ['something', 'else']
    assert parser._parser.parse_args(
        ['--', 'something', 'else', '--debug']).debug is True
    assert parser._parser.parse_args(['--', '--debug']).debug is True
    assert parser._parser.parse_args(['--debug']).command == []
    assert parser._parser.parse_args(['--debug']).debug is True
    assert parser._parser.parse_args(
        ['something', 'else', ARGUMENT_PLACEHOLDER]).command == \
        ['something', 'else']


# Generated at 2022-06-22 00:07:46.334232
# Unit test for constructor of class Parser
def test_Parser():
    test_instance = Parser()
    assert test_instance._parser.prog == "thefuck"
    assert test_instance._parser._actions[0].option_strings == ['-v']
    assert test_instance._parser._actions[0].dest == 'version'
    assert test_instance._parser._actions[0].help == "show program's version number and exit"
    assert test_instance._parser._actions[1].option_strings == ['-a']
    assert test_instance._parser._actions[1].dest == 'alias'
    assert test_instance._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert test_instance._parser._actions[2].option_strings == ['-l']
    assert test_instance._parser._actions[2].dest == 'shell_logger'

# Generated at 2022-06-22 00:07:48.596250
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['','-v'])
    assert args.version is True
    assert args.debug is False

# Generated at 2022-06-22 00:07:57.696374
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(('thefuck', 'fuck', 'ls'))
    assert args.command == ['ls']
    args = Parser().parse(('thefuck', 'fuck', '--', 'ls'))
    assert args.command == ['ls']
    args = Parser().parse(('thefuck', 'fuck', '--alias'))
    assert args.alias == get_alias()
    args = Parser().parse(('thefuck', 'fuck', '-h'))
    assert args.help is True
    args = Parser().parse(('thefuck', 'fuck', '-v'))
    assert args.version is True
    args = Parser().parse(('thefuck', 'fuck', '-a', 'fuck'))
    assert args.alias == 'fuck'

# Generated at 2022-06-22 00:08:07.099815
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO
    stdout_stderr = sys.stderr = StringIO.StringIO()
    Parser().print_usage()
    assert sys.stderr.getvalue() == """usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]
                 [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]
                 [--] [command...]\n"""
    sys.stderr = stdout_stderr
    stdout_stderr.close()


# Generated at 2022-06-22 00:08:14.115368
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_default_alias
    from .which import which

    vim_alias = 'fuck' if which('vim') else get_default_alias()

# Generated at 2022-06-22 00:08:24.474769
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse([])
    assert result == parser._parser.parse_args([])
    result = parser.parse(['ls'])
    assert result == parser._parser.parse_args(['ls'])
    result = parser.parse(['thefuck', 'ls'])
    assert result == parser._parser.parse_args(['ls'])
    result = parser.parse(['thefuck', 'ls', 'fuck!'])
    assert result == parser._parser.parse_args(['--', 'ls', 'fuck!'])
    result = parser.parse(['thefuck', 'ls', 'fuck!', 'fuck you!'])
    assert result == parser._parser.parse_args(['fuck you!', '--', 'ls', 'fuck!'])

# Generated at 2022-06-22 00:08:25.723882
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:08:33.986029
# Unit test for method parse of class Parser
def test_Parser_parse():
    # test pattern 1: only have --help option
    options, args = Parser().parse(['thefuck', '--help'])
    assert options.help == True and options.add_to_bash == False
    # test pattern 2: no argument and command
    options, args = Parser().parse(['thefuck'])
    assert options.add_to_bash == False
    # test pattern 3: argument(without command)
    options, args = Parser().parse(['thefuck', '!!'])
    assert options.add_to_bash == False
    # test pattern 4: argument(with command)
    options, args = Parser().parse(['thefuck', '!!', 'ls'])
    assert options.add_to_bash == False and args == ['ls']
    # test pattern 5: alias
    options, args = Parser

# Generated at 2022-06-22 00:08:44.569177
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import (
        PROG,
        AUTHOR,
        AUTHOR_EMAIL,
        REPO_URL,
        REPO_ISSUES_URL,
        LICENSE,
        VERSION,
    )
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        Parser().print_usage()

# Generated at 2022-06-22 00:09:11.865952
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class StubArgumentParser:
        def print_usage(self, file):
            file.write('B\n')
    class StubSys:
        def __init__(self):
            self.stderr = ['A']
        def stderr(self, s):
            self.stderr.append(s)

    parser = Parser()
    parser._parser = StubArgumentParser()
    sys = StubSys()
    parser.print_usage()
    assert sys.stderr == ['A', 'B\n']

# Generated at 2022-06-22 00:09:15.758317
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        parser = Parser().parse(['thefuck','--help'])
        assert parser
    except:
        print("Error in test_Parser_print_usage")
        return False
    return True



# Generated at 2022-06-22 00:09:26.729408
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_python, get_version
    from .const import __version__, SUPPORTED_SHELLS
    from .parser import Parser

    output = []

    def assert_called_with(arg):
        assert output[0] == arg

    def print_usage(arg):
        output.append(arg)

    parser = Parser()
    parser._parser.print_usage = print_usage

    parser.print_usage()

# Generated at 2022-06-22 00:09:28.458129
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser


# Generated at 2022-06-22 00:09:40.232021
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments_list = ['true', ARGUMENT_PLACEHOLDER, '--', '-d']
    arguments = parser.parse(arguments_list)
    assert not arguments.force_command
    assert arguments.debug
    assert ''.join(arguments.command) == 'true'

    arguments_list = ['--force-command', 'echo', ARGUMENT_PLACEHOLDER]
    arguments = parser.parse(arguments_list)
    assert arguments.force_command == 'echo'
    assert not arguments.command

    arguments_list = [ARGUMENT_PLACEHOLDER, '--', 'echo', '-d']
    arguments = parser.parse(arguments_list)
    assert not arguments.force_command
    assert not arguments.debug

# Generated at 2022-06-22 00:09:44.849639
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    import contextlib
    with contextlib.redirect_stderr(io.StringIO()) as stderr:
        p = Parser()
        p.print_usage()
        assert "usage" in stderr.getvalue()


# Generated at 2022-06-22 00:09:55.111096
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from sys import stderr
    from unittest.mock import patch
    with patch.object(stderr, 'write') as mock_stderr_write:
        p = Parser()
        p.print_usage()
        expected_help = StringIO("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [--] [command [command ...]]\n")
        mock_stderr_write.assert_called_once_with(expected_help.getvalue())


# Generated at 2022-06-22 00:09:57.483747
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:09:59.891856
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    #assert parser.print_help() == None



# Generated at 2022-06-22 00:10:03.056265
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck','git','status','fuck','--'])
    assert arguments.command == ['git','status','fuck']

# Generated at 2022-06-22 00:11:07.736560
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-a', '--', 'rm', '-rf', '/']).command == ['rm', '-rf', '/']
    assert parser.parse(['thefuck', '-a', '--', 'rm', '-rf', '/']).alias == get_alias()
    assert parser.parse(['thefuck', '--force-command', 'rm', '-rf', '/']).command == ['rm', '-rf', '/']
    assert parser.parse(['thefuck', '--force-command', 'rm', '-rf', '/']).force_command == 'rm'
    assert parser.parse(['thefuck', '-a', '--', 'rm', '-rf', '/']).repeat == False

# Generated at 2022-06-22 00:11:15.135854
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    try:
        args = p.parse(['thefuck', '-d', '--alias', 'alias', '--repeat', '-y', '--force-command', 'echo', ARGUMENT_PLACEHOLDER, 'sudo', '-s', 'save', 'exit', '--debug'])
        print(args)
    except BaseException as e:
        print(e)
        pass


# Generated at 2022-06-22 00:11:26.490508
# Unit test for method parse of class Parser
def test_Parser_parse():
    arg1 = ['thefuck', '--debug', '--force-command', 'ls', '--', 'ls']
    arg2 = ['thefuck', '--debug', '--force-command', 'ls', '--', 'ls', '-al']
    arg3 = ['thefuck', '--debug', '--force-command', 'ls', '-al']
    arg4 = ['thefuck', '--debug', '--force-command', 'ls', '-al']
    arg5 = ['thefuck', '--debug', '--force-command', 'ls', '-al', '--', 'ls']
    arg6 = ['thefuck', '--debug', '--force-command', 'ls']
    parser1 = Parser()
    parser2 = Parser()
    parser3 = Parser()
    parser4 = Parser()
   

# Generated at 2022-06-22 00:11:27.557154
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:11:28.771554
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:11:37.650227
# Unit test for method parse of class Parser
def test_Parser_parse():
    # --version
    parser = Parser()
    args = parser.parse(['thefuck', '--version'])
    assert args.version
    # -short alias
    args = parser.parse(['thefuck', '-a'])
    assert args.alias == get_alias()
    # --long alias
    args = parser.parse(['thefuck', '--alias'])
    assert args.alias == get_alias()
    # --long alias with arguments
    args = parser.parse(['thefuck', '--alias', 'new-alias'])
    assert args.alias == 'new-alias'
    # [-short alias] <command> [<args>]
    args = parser.parse(['thefuck', '-a', 'echo', 'a', 'b'])
    assert args.alias == get_alias()
    assert args

# Generated at 2022-06-22 00:11:43.497607
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class Fake(object):
        def __init__(self):
            self.stderr = ''

        def write(self, message):
            self.stderr += message

    FakeStdErr = Fake()
    p = Parser()
    p.print_help(file=FakeStdErr)
    assert 'opts' in FakeStdErr.stderr

# Generated at 2022-06-22 00:11:49.314881
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    stderr = sys.stderr
    sys.stderr = StringIO()
    parser.print_usage()
    usage = sys.stderr.getvalue().strip()
    expected = "usage: thefuck [-h] [-v] [-a [custom-alias-name]]"
    assert usage.startswith(expected)
    sys.stderr = stderr


# Generated at 2022-06-22 00:11:56.654522
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Testing parse with regular input
    parser = Parser()
    assert parser.parse("git commit -p".split(" ")) == parser._parser.parse_args("git commit -p".split(" "))

    # Testing parse with placeholder
    parser = Parser()
    assert parser.parse("git commit -- *.py".split(" ")) == parser._parser.parse_args("-- *.py".split(" "))

    # Testing parse with both placeholder and start with '-'
    parser = Parser()
    assert parser.parse("git commit -p -- *.py".split(" ")) == parser._parser.parse_args("-- *.py".split(" "))

# Generated at 2022-06-22 00:12:03.090375
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    import sys
    stdout_save = sys.stdout
    sys.stdout = mystdout = StringIO()
    parser=Parser()
    parser.print_help()
    output = mystdout.getvalue()
    sys.stdout = stdout_save
    assert 'usage' in output
    assert 'optional arguments' in output
    assert '-h, --help' in output
    assert '-v, --version' in output


# Generated at 2022-06-22 00:14:33.487965
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    aa = p.print_help()


# Generated at 2022-06-22 00:14:34.077661
# Unit test for constructor of class Parser
def test_Parser():
    pass

# Generated at 2022-06-22 00:14:44.493646
# Unit test for method parse of class Parser
def test_Parser_parse():
    import io
    import getpass
    import os
    import subprocess
    import tempfile
    
    # Create a placeholder file with content 'thefuck\n'
    placeholder_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    placeholder_file.write('thefuck\n')
    placeholder_file.close()
    
    # Build a argv list with random user input
    argv = ['thefuck', 'git', 'add', '--all']
    argv += ['-a', placeholder_file.name]
    argv += ['-d', '--force-command', '--']
    argv += ['command', '--arg1', 'command_arg1', '--arg2', 'command_arg2']
    
    # Create a parser and parse the argv list
    parser = Parser

# Generated at 2022-06-22 00:14:45.255637
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:14:55.313669
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser._prepare_arguments(['-v', '-h', '--shell-logger=test'])
    assert args == ['-v', '-h', '--shell-logger=test']
    args = parser._prepare_arguments(['-v', '-h', 'test', ARGUMENT_PLACEHOLDER, 'test', 'test'])
    assert args == ['test', 'test', 'test', '--', '-v', '-h']
    args = parser._prepare_arguments(['test', 'test', 'test'])
    assert args == ['--', 'test', 'test', 'test']

# Generated at 2022-06-22 00:15:01.918415
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.usage == '%(prog)s [options]'
    assert parser._parser._option_string_actions['-v'].help == "show program's version number and exit"
    assert parser._parser._option_string_actions['-a'].help == '[custom-alias-name] prints alias for current shell'
    assert parser._parser._option_string_actions['-l'].help == 'log shell output to the file'
    assert parser._parser._option_string_actions['--enable-experimental-instant-mode'].help == 'enable experimental instant mode, use on your own risk'
    assert parser._parser._option_string_actions['-h'].help == 'show this help message and exit'
    assert parser._parser._action_groups[1].title == "conflicting arguments"

# Generated at 2022-06-22 00:15:08.687483
# Unit test for constructor of class Parser
def test_Parser():
    args = Parser()
    assert args._parser.prog == 'thefuck'
    assert args._parser._actions[0].dest == 'version'
    assert args._parser._actions[1].dest == 'shell_logger'
    assert args._parser._actions[6].dest == 'yes'
    assert args._parser._actions[8].dest == 'repeat'
    assert args._parser._actions[9].dest == 'debug'
    assert args._parser._actions[10].dest == 'force_command'
    assert args._parser._actions[11].dest == 'command'


# Generated at 2022-06-22 00:15:20.700073
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck', '--alias']) == \
        Namespace(alias=get_alias(),
                  command=[],
                  debug=False,
                  enable_experimental_instant_mode=False,
                  force_command=None,
                  yes=False,
                  repeat=False,
                  shell_logger=None,
                  help=False,
                  version=False)
    assert Parser().parse(['thefuck', '--alias', 'fuck']) == \
        Namespace(alias='fuck',
                  command=[],
                  debug=False,
                  enable_experimental_instant_mode=False,
                  force_command=None,
                  yes=False,
                  repeat=False,
                  shell_logger=None,
                  help=False,
                  version=False)
    assert Parser().parse

# Generated at 2022-06-22 00:15:22.627249
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert True

# Generated at 2022-06-22 00:15:24.730501
# Unit test for constructor of class Parser
def test_Parser():
#init is incorrect.
    p = Parser()

