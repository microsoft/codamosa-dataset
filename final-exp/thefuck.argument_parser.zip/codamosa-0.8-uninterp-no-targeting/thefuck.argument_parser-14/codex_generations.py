

# Generated at 2022-06-22 00:05:49.831152
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ALIAS
    from .utils import get_alias

    parser = Parser()
    assert parser.parse(['']) == parser.parse([])
    assert parser.parse(['', '--help']) == parser.parse(['--help'])
    assert parser.parse(['', '--debug']) == parser.parse(['--debug'])
    assert parser.parse(['', '--force-command', 'echo fuck']) == \
        parser.parse(['--force-command', 'echo fuck'])
    assert parser.parse(['', 'echo fuck']) == parser.parse(['echo fuck'])
    assert parser.parse(['', '--', 'echo fuck']) == parser.parse(['--', 'echo fuck'])

# Generated at 2022-06-22 00:05:54.917859
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    _out = StringIO()
    _stream = sys.stderr
    sys.stderr = _out
    Parser().print_usage()
    sys.stderr = _stream
    _out = _out.getvalue().splitlines()
    assert _out[0].startswith("usage: thefuck")


# Generated at 2022-06-22 00:05:56.372828
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:05:58.036800
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None

# Generated at 2022-06-22 00:06:01.203777
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_aliases
    parser = Parser()
    parser.print_usage()
    aliases = get_aliases()
    if aliases:
        for alias in aliases:
            alias + ' '
    parser.print_usage()


# Generated at 2022-06-22 00:06:03.006486
# Unit test for constructor of class Parser

# Generated at 2022-06-22 00:06:03.911825
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:06:05.410156
# Unit test for method print_help of class Parser
def test_Parser_print_help():
	parser = Parser()
	help_str = parser.print_help()

# Generated at 2022-06-22 00:06:14.166427
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        parser.print_usage()
    output = fake_stderr.getvalue()
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' + \
                     '[-l shell-logger] [--enable-experimental-instant-mode] ' + \
                     '[-y] [-r] [-d] [--force-command FORCE-COMMAND] ' + \
                     '[command [command ...]]\n'


# Generated at 2022-06-22 00:06:15.942863
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:06:30.712478
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(["tack", "tack"])

# Generated at 2022-06-22 00:06:41.747185
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'ls -la']) == \
        parser.parse(['fuck', '--force-command', 'ls -la'])
    assert parser.parse(['fuck', 'ls', '-la']) == \
        parser.parse(['fuck', '--force-command', 'ls', '-la'])
    assert parser.parse(['fuck']) == \
        parser.parse(['fuck', '--force-command'])
    assert parser.parse(['fuck', '-h']) == \
        parser.parse(['fuck', '--force-command', '-h'])

# Generated at 2022-06-22 00:06:51.985397
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Test the output message of method print_help of the class Parser"""
    from .utils import _
    from .const import VERSION

# Generated at 2022-06-22 00:06:54.345368
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser


# Generated at 2022-06-22 00:06:55.801605
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:06:57.893338
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_test = Parser()
    parser_test.print_help()
    parser_test.print_usage()



# Generated at 2022-06-22 00:07:08.351598
# Unit test for constructor of class Parser
def test_Parser():
    set_alias = 'fuck'
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.print_usage == sys.stderr.write
    assert parser._parser.print_help == sys.stderr.write
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].action == 'store_true'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].nargs == '?'
    assert parser._parser._actions[1].const == get_alias()

# Generated at 2022-06-22 00:07:10.796797
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-22 00:07:12.712723
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        pass

# Generated at 2022-06-22 00:07:15.394398
# Unit test for constructor of class Parser
def test_Parser():
  assert Parser()._parser.prog == 'thefuck'
  assert Parser()._parser.add_help == False


# Generated at 2022-06-22 00:07:23.469820
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-22 00:07:24.388140
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:07:36.317542
# Unit test for constructor of class Parser
def test_Parser():
    def has_nargs(argument, nargs):
        option = getattr(argument, 'option_strings')[0]
        return option == '-l' and nargs == '?'

    def has_action(argument, action):
        option = getattr(argument, 'option_strings')[0]
        return option == '-v' and action == 'store_true'

    def has_help(argument, help_text):
        option = getattr(argument, 'option_strings')[0]
        return option == '-l' and help_text == 'log shell output to the file'

    parser = Parser()

# Generated at 2022-06-22 00:07:37.567097
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:07:49.445447
# Unit test for method parse of class Parser
def test_Parser_parse():
    import unittest

    class TestParserParseMethod(unittest.TestCase):
        def setUp(self):
            self.parser = Parser()

        def test_no_placeholder(self):
            result = self.parser.parse(['-y'])
            self.assertEqual(result.yes, True)

        def test_with_placeholder(self):
            result = self.parser.parse(['-y', 'false'])
            self.assertEqual(result.yes, True)
            self.assertEqual(result.command, ['false'])

        def test_with_placeholder_in_the_middle(self):
            result = self.parser.parse(['-y', 'false', ARGUMENT_PLACEHOLDER, 'ls'])

# Generated at 2022-06-22 00:07:56.076345
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert out.getvalue().strip() == 'usage: thefuck [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-h] [-d] [--force-command force-command] [command [command ...]]'
    out.close()


# Generated at 2022-06-22 00:08:05.451339
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    thefuck_parser = Parser()
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    thefuck_parser.print_usage()
    assert out.getvalue().strip() == '''usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y] [-r] [--] [command [command ...]]
'''


# Generated at 2022-06-22 00:08:12.041003
# Unit test for method parse of class Parser
def test_Parser_parse():
    argument = Parser()._prepare_arguments(['--foo', 'bar', 'baz'])
    assert argument == ['foo', 'bar', 'baz']
    argument = Parser()._prepare_arguments(['--foo', ARGUMENT_PLACEHOLDER, 'qux'])
    assert argument == ['foo', 'qux']
    argument = Parser()._prepare_arguments(['--foo', '--', 'bar', ARGUMENT_PLACEHOLDER, 'baz'])
    assert argument == ['foo', 'bar', '--', 'baz']

# Generated at 2022-06-22 00:08:12.823592
# Unit test for constructor of class Parser
def test_Parser():
    pass

# Generated at 2022-06-22 00:08:14.102013
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert(Parser().print_usage() == None)


# Generated at 2022-06-22 00:08:23.427533
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-22 00:08:25.888527
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.description == "Argument parser that can handle arguments with our special placeholder."


# Generated at 2022-06-22 00:08:27.749615
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', '-l']
    assert Parser().parse(argv).shell_logger is not None
    assert Parser().parse(argv).command == []


# Generated at 2022-06-22 00:08:28.191276
# Unit test for constructor of class Parser
def test_Parser():
  Parser()

# Generated at 2022-06-22 00:08:31.824754
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # test with alias and command
    assert parser.parse(['thefuck', 'fuck']) == parser._parser.parse_args(
        ['--', 'fuck'])
    # test with alias and without command
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])
    # test with option and command
    assert parser.parse(['thefuck', '-y', 'fuck']) == parser._parser.parse_args(
        ['-y', '--', 'fuck'])


# Generated at 2022-06-22 00:08:42.839740
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    # Tests that if the value of ARGUMENT_PLACEHOLDER exists in the
    # arguments list, it will be moved to the head of the list
    assert p._prepare_arguments(['some_command', ARGUMENT_PLACEHOLDER, '--debug']) == ['--debug', '--', 'some_command']
    # Tests that if the value of ARGUMENT_PLACEHOLDER does not exist in the
    # arguments list, and the first argument is not a command, the first
    # argument will be moved to the head og the list
    assert p._prepare_arguments(['some_command']) == ['--', 'some_command']
    # Tests that if the value of ARGUMENT_PLACEHOLDER does not exist in the
    # arguments list

# Generated at 2022-06-22 00:08:43.918391
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:08:55.175359
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['', '--version']) == parser.parse(['', '-v'])
    assert parser.parse(['', '--alias', 'alias-name']) == parser.parse(['', '-a', 'alias-name'])
    assert parser.parse(['', '--shell-logger', 'shell-logger-test']) == parser.parse(['', '-l', 'shell-logger-test'])
    assert parser.parse(['', '--enable-experimental-instant-mode']) == parser.parse(['', '--enable-experimental-instant-mode'])
    assert parser.parse(['', '--help']) == parser.parse(['', '-h'])
    assert parser.parse(['', '--yes']) == parser.parse

# Generated at 2022-06-22 00:08:56.363581
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:09:01.720324
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

    # Test: print usage to stderr
    out, err = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = StringIO()
    parser.print_usage()
    assert sys.stdout.getvalue().strip() == 'usage: thefuck'
    sys.stdout = out
    sys.stderr = err



# Generated at 2022-06-22 00:09:25.621057
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    from contextlib import redirect_stderr
    f = io.StringIO()
    with redirect_stderr(f):
        Parser().print_usage()
    out = f.getvalue().strip()
    assert out == """usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--] [command [command ...]]"""


# Generated at 2022-06-22 00:09:31.788099
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Given
    parser = Parser()

    # When
    parser.parse(['', '-v'])

    # Then
    parser.parse(['', '--help'])

    # When
    parser.parse(['', '-d', '-v'])

    # When
    parser.parse(['', '-d', '--help'])

    # When
    parser.parse(['', '-d', '--shell-logger=shell_log.txt'])

    # When
    parser.parse(['', '-d', '--force-command=ls'])

    # When
    parser.parse(['', '-d', 'ls'])

    # When
    parser.parse(['', '-d', 'ls', '-la'])

    # When

# Generated at 2022-06-22 00:09:36.726689
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    with patch('thefuck.main.sys.stderr') as stderr:
        parser = Parser()
        parser.print_help()
        # "print_help" actually calls "print_usage"
        stderr.write.assert_called_once()

# Generated at 2022-06-22 00:09:38.547318
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert not parser.print_usage() and False


# Generated at 2022-06-22 00:09:40.319998
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit as e:
        assert False

# Generated at 2022-06-22 00:09:52.361103
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    argv = ["-a"]
    parser.parse(argv)
    argv = ["--alias"]
    parser.parse(argv)
    argv = ["--alias", "fuck"]
    parser.parse(argv)
    argv = ["-v"]
    parser.parse(argv)
    argv = ["-d"]
    parser.parse(argv)
    argv = ["--repeat"]
    parser.parse(argv)
    argv = ["-r"]
    parser.parse(argv)
    argv = ["-yes"]
    parser.parse(argv)
    argv = ["-y"]
    parser.parse(argv)
    argv = ["-h"]
    parser.parse(argv)
    argv = ["--help"]


# Generated at 2022-06-22 00:09:53.793810
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser)


# Generated at 2022-06-22 00:09:56.527419
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from thefuck.main import get_help

    parser = Parser()
    parser.print_help()
    assert get_help() in sys.stderr.getvalue()

# Generated at 2022-06-22 00:10:07.893744
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    old_argv = sys.argv
    sys.argv = ['thefuck', '--yes', '--', 'ls', '-la']
    assert parser.parse(sys.argv).yes is True
    assert parser.parse(sys.argv).command == ['ls', '-la']
    sys.argv = ['thefuck', 'ls', '-la']
    assert parser.parse(sys.argv).command == ['ls', '-la']
    sys.argv = ['thefuck', '--', 'ls', '-la']
    assert parser.parse(sys.argv).command == ['ls', '-la']
    sys.argv = ['thefuck', 'ls', '-la', '{}', '-l']

# Generated at 2022-06-22 00:10:12.188284
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser._parser.parse_args(["git", "wrong"])
    assert args.command == ["git", "wrong"]
    args = parser._parser.parse_args(["-y"])
    assert args.yes


# Generated at 2022-06-22 00:11:03.542296
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    print(a._parser)
    a._add_arguments()
    a._add_conflicting_arguments()
    # _prepare_arguments
    print(a._prepare_arguments(['-y', '-v', 'xxx', ARGUMENT_PLACEHOLDER, '-r', '-h']))
    print(a._prepare_arguments(['-y', '-v', 'xxx', ARGUMENT_PLACEHOLDER, '-r', '-h', ARGUMENT_PLACEHOLDER, '-h']))
    print(a._prepare_arguments(['-y', '-v', 'xxx', 'ls', '-h']))
    print(a._prepare_arguments(['-h']))
    #parse


# Generated at 2022-06-22 00:11:06.774330
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    sys.argv = ['thefuck']
    parser = Parser()
    parser.parse(sys.argv)


# Generated at 2022-06-22 00:11:10.172867
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['--version'])
    assert args.version == True


# Generated at 2022-06-22 00:11:14.370056
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_version

    s = StringIO()
    parser = Parser()
    parser.print_help()
    help_content = s.getvalue()
    assert get_alias() in help_content
    assert get_version() in help_content


# Generated at 2022-06-22 00:11:15.390043
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None


# Generated at 2022-06-22 00:11:17.331062
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-22 00:11:18.250060
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:11:28.651975
# Unit test for constructor of class Parser
def test_Parser():
    """Test constructor of class Parser"""
    parser = Parser()

    parser_object = parser._parser
    assert parser_object.prog == 'thefuck'
    assert parser_object.usage == None
    assert parser_object.add_help == False
    assert parser_object._actions[0].dest == 'version'
    assert parser_object._actions[1].dest == 'alias'
    assert parser_object._actions[2].dest == 'shell_logger'
    assert parser_object._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser_object._actions[4].dest == 'help'
    assert parser_object._groups[0].title == 'conflicting arguments'
    assert parser_object._actions[5].dest == 'yes'
    assert parser_object._actions[6].dest

# Generated at 2022-06-22 00:11:35.150589
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    capturedOutput = StringIO.StringIO()
    sys.stdout = capturedOutput
    parser.print_usage()
    sys.stdout = sys.__stdout__
    assert capturedOutput.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [command [command ...]]\n'


# Generated at 2022-06-22 00:11:39.571287
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    Tests the method parse of the class Parser
    in the file thefuck/parser.py
    """
    parser = Parser()
    argv =['fuck', '--debug', '-v', '-l', 'file.log', '-h', 'ls', '-l', '-a', 'fuck']
    parser.parse(argv)


# Generated at 2022-06-22 00:13:20.352450
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-a'])
    assert args.alias is None
    assert args.yeah is False
    assert args.repeat is False
    assert args.debug is False
    assert args.shell_logger is None
    assert args.command == ['ls', '-a']


# Generated at 2022-06-22 00:13:26.586788
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .const import VERSION

    f = StringIO()
    parser = Parser()
    parser.print_usage(file=f)
    assert f.getvalue() == ("""thefuck %s

usage: thefuck [-h] [-d] [-v] [-y] [-r] [-a [custom-alias-name]]
                [-l shell-logger] [--enable-experimental-instant-mode]
                [--force-command force-command]
                [command [command ...]]
""" % VERSION)

# Generated at 2022-06-22 00:13:35.814649
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

# Generated at 2022-06-22 00:13:43.616401
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    test_argv = ['/bin/thefuck', '--yes-we-can']
    assert p.parse(test_argv).yes is True
    test_argv = ['/bin/thefuck', '--no-we-can']
    assert p.parse(test_argv) is None
    test_argv = ['/bin/thefuck', '--no-we-can', '--yeah']
    assert p.parse(test_argv).yes is True
    test_argv = ['/bin/thefuck', '--yeah', '--no-we-can']
    assert p.parse(test_argv).yes is True
    test_argv = ['/bin/thefuck', '--no-we-can', '--command', 'ls']

# Generated at 2022-06-22 00:13:45.101261
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser._parser
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-22 00:13:49.593137
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    It should only print the usage to the standard error
    """
    from StringIO import StringIO
    output = StringIO()
    sys.stdout = output
    parser = Parser()
    parser.print_usage()
    assert output.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [--] [command [command ...]]\n'

# Generated at 2022-06-22 00:13:55.052825
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['fuck', 'python', '-c', 'fuck'])
    assert arguments.command == ['python', '-c', 'fuck']
    assert arguments.debug is False
    assert arguments.repeat is False
    assert arguments.yes is False
    assert arguments.alias is None
    assert arguments.shell_logger is None
    assert arguments.debug is False
    assert arguments.enable_experimental_instant_mode is False
    assert arguments.help is False
    assert arguments.force_command is None

    arguments = parser.parse(['fuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '--debug'])
    assert arguments.command == ['ls', '-l']
    assert arguments.debug is True
    assert arguments.repeat is False

# Generated at 2022-06-22 00:14:01.772117
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == \
        parser.parse(['thefuck', '--version'])
    assert parser.parse(['thefuck', '-a']) == \
        parser.parse(['thefuck', '--alias'])
    assert parser.parse(['thefuck', '-l']) == \
        parser.parse(['thefuck', '--shell-logger'])
    assert parser.parse(['thefuck', '-y']) == \
        parser.parse(['thefuck', '--yes'])
    assert parser.parse(['thefuck', '-r']) == \
        parser.parse(['thefuck', '--repeat'])

# Generated at 2022-06-22 00:14:04.062248
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import sys
    output = io.StringIO()
    sys.stderr = output
    Parser().print_help()
    output.close()
    sys.stderr = sys.__stderr__
    assert 'Usage:' in output.getvalue()

# Generated at 2022-06-22 00:14:10.642270
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['-d', '-v', 'ls',
            '-al', 'arg1', 'arg2',
            ARGUMENT_PLACEHOLDER,
            '-a',
            '-l', '~/thefuck.log']
    assert (
        Parser().parse(args) ==
        Namespace(debug=True,
                  version=False,
                  command=['ls', 'arg1', 'arg2'],
                  alias=False,
                  shell_logger=None,
                  enable_experimental_instant_mode=False,
                  help=False,
                  repeat=False,
                  yes=False,
                  force_command=None))