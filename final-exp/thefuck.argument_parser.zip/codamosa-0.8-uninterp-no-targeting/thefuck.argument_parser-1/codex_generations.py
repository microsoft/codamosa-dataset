

# Generated at 2022-06-22 00:05:44.920206
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-22 00:05:46.033425
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:05:47.016407
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:05:58.739057
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    stdout = sys.stdout
    sys.stdout = output = StringIO()
    p.print_usage()
    sys.stdout = stdout

    assert output.getvalue().count("usage:") == 1
    assert output.getvalue().count("[-h]") == 1
    assert output.getvalue().count("[-v]") == 1
    assert output.getvalue().count("[-a [custom-alias-name]]") == 1
    assert output.getvalue().count("[-l shell-logger]") == 1
    assert output.getvalue().count("[--enable-experimental-instant-mode]") == 1
    assert output.getvalue().count("[-y | -r]") == 1
    assert output.getvalue().count("[command [command ...]]")

# Generated at 2022-06-22 00:05:59.982995
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser


# Generated at 2022-06-22 00:06:00.825388
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:12.595357
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '--help']) == \
        parser._parser.parse_args(['--help'])
    assert parser.parse(['thefuck', '--help', '--foo']) == \
        parser._parser.parse_args(['--help', '--foo'])
    assert parser.parse(['thefuck', '--help', '--', 'git']) == \
        parser._parser.parse_args(['--help', '--', 'git'])
    assert parser.parse(['thefuck', '--', '--help']) == \
        parser._parser.parse_args(['--', '--help'])
    assert parser.parse(['thefuck', '--help', '--', 'foo', 'bar']) == \
        parser._parser.parse_

# Generated at 2022-06-22 00:06:24.449616
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert "-v" in p._parser.format_help()
    assert "-l" in p._parser.format_help()
    assert "--shell-logger" in p._parser.format_help()
    assert "-a" in p._parser.format_help()
    assert "--alias" in p._parser.format_help()
    assert "-h" in p._parser.format_help()
    assert "--help" in p._parser.format_help()
    assert "-d" in p._parser.format_help()
    assert "--debug" in p._parser.format_help()
    assert "--force-command" in p._parser.format_help()
    assert "command" in p._parser.format_help()
    assert "-r" in p._parser.format_help()

# Generated at 2022-06-22 00:06:36.383943
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', 'ls', '&&', 'cd', 'wrong_dir'])
    parser.parse(['thefuck', '-d', 'ls', '&&', 'cd', 'wrong_dir'])
    parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '&&',
                  'cd', 'wrong_dir'])
    parser.parse(['thefuck', '--force-command', 'cd', 'wrong_dir'])
    parser.parse(['thefuck', '--shell-logger=/tmp/output',
                  'cd', 'wrong_dir'])
    parser.parse(['thefuck', '-a', 'fuck'])
    parser.parse(['thefuck', '--version'])

# Generated at 2022-06-22 00:06:38.243470
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog is 'thefuck'


# Generated at 2022-06-22 00:06:45.751037
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-22 00:06:46.284035
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:06:48.746702
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from thefuck.const import USAGE
    from io import StringIO
    from sys import stderr

    parser = Parser()
    with StringIO() as buf, redirect_stderr(buf):
        parser.print_usage()
        assert buf.getvalue() == USAGE + '\n'


# Generated at 2022-06-22 00:06:49.604566
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:55.845677
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Test case with placeholder and arguments after
    args_after_placeholder = [
        'thefuck', ARGUMENT_PLACEHOLDER, '-a', '-v'
    ]
    args_after_placeholder_expected = parser.parse(args_after_placeholder)
    assert args_after_placeholder_expected.alias == get_alias()
    assert args_after_placeholder_expected.version
    assert args_after_placeholder_expected.command == []

    # Test case with placeholder and arguments before
    args_before_placeholder = [
        'thefuck', '-d', '-l', 'log-file', ARGUMENT_PLACEHOLDER
    ]
    args_before_placeholder_expected = parser.parse(args_before_placeholder)

# Generated at 2022-06-22 00:06:56.821144
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser

# Generated at 2022-06-22 00:06:58.216244
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:07:02.045706
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    args = ['-h']
    parser = Parser()
    parser.parse(args)
    x = parser.print_help()
    assert 'positional arguments:' in x
    assert 'optional arguments:' in x

# Generated at 2022-06-22 00:07:10.017317
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['-a']) == Parser().parse(['--alias'])
    assert Parser().parse(['--debug']) == Parser().parse(['-d'])
    assert Parser().parse(['fuck']) == Parser().parse(['--', 'fuck'])
    assert Parser().parse(['fuck', '--version']) == Parser().parse(['--', 'fuck', '--version'])
    assert Parser().parse(['fuck', '--version']) != Parser().parse(['--', 'fuck', '-v'])
    assert Parser().parse(['fuck', '--help']) == Parser().parse(['--', 'fuck', '-h'])

# Generated at 2022-06-22 00:07:19.373594
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # noinspection PyTypeChecker
    assert parser.parse(['thefuck', '--version']) == parser.parse(['thefuck', '--version'])
    # noinspection PyTypeChecker
    assert parser.parse(['thefuck', 'echo test']) == parser.parse(['thefuck', 'echo test'])
    # noinspection PyTypeChecker
    assert parser.parse(['thefuck', '--alias', 'fuck']) == parser.parse(['thefuck', '--alias', 'fuck'])
    # noinspection PyTypeChecker
    assert parser.parse(['thefuck', '--shell-logger', 'shell.log']) == parser.parse(['thefuck', '--shell-logger', 'shell.log'])
    # noinspection PyTypeChecker


# Generated at 2022-06-22 00:07:46.438142
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].default == get_alias()
    assert parser._parser._actions[2].option_strings == ['-l', '--shell-logger']
    assert parser._parser._actions[3].option_strings == ['--enable-experimental-instant-mode']
    assert parser._parser._actions[4].option_strings == ['-h', '--help']
    assert len(parser._parser._mutually_exclusive_groups[0]._group_actions) == 2

# Generated at 2022-06-22 00:07:48.271053
# Unit test for constructor of class Parser
def test_Parser():
    test_parser = Parser()
    assert isinstance(test_parser, Parser)
    assert test_parser._parser

# Generated at 2022-06-22 00:07:55.863524
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    usage = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n'
    usage += '                [--enable-experimental-instant-mode] [-y | -r]\n'
    usage += '                [-d] [--force-command FORCE_COMMAND]\n'
    usage += '                [command [command ...]]'

    p = Parser()
    s = StringIO()
    sys.stderr = s
    p.print_usage()
    assert s.getvalue() == usage + '\n'


# Generated at 2022-06-22 00:08:07.956594
# Unit test for method parse of class Parser
def test_Parser_parse():
    # There is an argument placeholder
    assert Parser().parse(['script', 'fuck', ARGUMENT_PLACEHOLDER, 'cd', '-v'])\
        .command == 'cd'
    assert Parser().parse(['script', 'fuck', ARGUMENT_PLACEHOLDER + 'a'])\
        .command == ''
    assert Parser().parse(['script', 'fuck', 'cp' + ARGUMENT_PLACEHOLDER,\
        'asdf'])\
        .command == 'cp'
    assert Parser().parse(['script', 'fuck',\
        'cp' + ARGUMENT_PLACEHOLDER + 'a'])\
        .command == 'cp'

    # There isn't an argument placeholder

# Generated at 2022-06-22 00:08:11.966482
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(["thefuck", "--alias", "fuck"]) == argparse.Namespace(alias='fuck',
        command=[], debug=False, enable_experimental_instant_mode=False, help=False,
        repeat=False, shell_logger=None, version=False, yes=False)


# Generated at 2022-06-22 00:08:22.222712
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # with placeholder
    result = parser.parse(['script', 'command', 'arg', ARGUMENT_PLACEHOLDER, '--', '-y'])
    assert result.command == ['arg'], result.command
    assert result.yeah, True

    # without placeholder
    result = parser.parse(['script', 'command', 'arg', '--', '-y'])
    assert result.command == ['arg'], result.command
    assert result.yeah, True

    # with cases when there are no command/arguments
    result = parser.parse(['script'])
    assert result.command == [], result.command

    result = parser.parse(['script', 'command', 'arg'])
    assert result.command == ['command', 'arg'], result.command

# Generated at 2022-06-22 00:08:23.578499
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:08:30.397141
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['-a','fuck','what','the','fuck']) == Namespace(shell_logger=None, alias='fuck', yes=False, debug=False, force_command=None, repeat=False, command=['what', 'the', 'fuck'])
    assert parser.parse(['-a','fuck','what','the','fuck','what','the','fuck']) == Namespace(shell_logger=None, alias='fuck', yes=False, debug=False, force_command=None, repeat=False, command=['what', 'the', 'fuck', 'what', 'the', 'fuck'])

# Generated at 2022-06-22 00:08:32.685596
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert parser.print_help()

# Generated at 2022-06-22 00:08:36.664076
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser._parser.print_help = Mock()
    parser.print_help()
    parser._parser.print_help.assert_called_once_with(sys.stderr)


# Generated at 2022-06-22 00:09:15.483853
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    import sys

    stdout = sys.stderr
    sys.stderr = io.StringIO()
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [--alias [custom-alias-name]] [--shell-logger shell-logger] [--enable-experimental-instant-mode]\n              [-h] [-d] [--force-command force-command]\n              [--] [command [command ...]]\n'
    sys.stderr = stdout



# Generated at 2022-06-22 00:09:26.537777
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '--alias', 'fuck', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert args.alias == 'fuck'
    assert args.command == ['ls', '-l']
    args = parser.parse(['thefuck', '-r', 'ls', '-l'])
    assert args.repeat is True
    assert args.command == ['ls', '-l']
    args = parser.parse(['thefuck', '--', 'ls', '-l'])
    assert args.command == ['ls', '-l']
    args = parser.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']

# Generated at 2022-06-22 00:09:36.627180
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    stdout = StringIO()
    sys.stderr = stdout
    parser = Parser()
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert stdout.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n       [-l shell-logger]\n       [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n       [--yes | --repeat]\n       [command [command ...]]\n'


# Generated at 2022-06-22 00:09:38.001096
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-22 00:09:39.028175
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:09:41.736140
# Unit test for method parse of class Parser
def test_Parser_parse():
    # parser = Parser()
    # results = parser.parse(['thefuck', '-sdfsdf', '--', 'git', 'c'])
    # assert results.shell_logger == None
    pass

# Generated at 2022-06-22 00:09:45.375509
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        execfile("./test_Parser_print_usage.py")
    except SystemExit:
        pass
    except:
        raise


# Generated at 2022-06-22 00:09:46.365572
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:09:47.428294
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:09:48.461375
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:10:28.278216
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    pass


# Generated at 2022-06-22 00:10:29.360116
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.parse(['', '-v'])



# Generated at 2022-06-22 00:10:35.176582
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class Fake_stderr:
        def __init__(self):
            self.content = ""
        
        def write(self, content):
            self.content = self.content+content
            
    parser = Parser()
    stderr = Fake_stderr()
    parser.print_help(stderr)
    assert stderr.content
    assert "Arguments:" in stderr.content

# Generated at 2022-06-22 00:10:42.428651
# Unit test for method parse of class Parser
def test_Parser_parse():
    test_argv = ['thefuck', 'git', 'add', 'ARG', 'git', 'commit', 'ARG']
    parser = Parser()
    parsed_argv = parser._prepare_arguments(test_argv)
    assert parsed_argv == [
        'git', 'add', 'ARG', '--', 'git', 'commit', 'ARG']
    print('[+] test_Parser_parse() success.')



# Generated at 2022-06-22 00:10:52.496097
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Arguments with placeholder, after placeholder should be at the front
    assert ['cd', '..'] == parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, 'cd', '..']).command
    assert ['cd', '..'] == parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'cd', '..']).command
    assert ['ls', '-l'] == parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER]).command
    assert [] == parser.parse(['thefuck', ARGUMENT_PLACEHOLDER]).command

    # Arguments no placeholder, should add `--` before all arguments

# Generated at 2022-06-22 00:11:03.945299
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(["thefuck", "-l", "/log/path", "--", "command", "-", "arg"])
    assert result.shell_logger == "/log/path"
    assert result.command == ["command", "-", "arg"]
    assert result.repeat == False
    assert result.yes == False

    result = parser.parse(["thefuck", "-r", "command", "--", "arg"])
    assert result.shell_logger == None
    assert result.command == ["command", "--", "arg"]
    assert result.repeat == True
    assert result.yes == False

    result = parser.parse(["thefuck", "--repeat", "command", "-", "arg"])
    assert result.shell_logger == None

# Generated at 2022-06-22 00:11:06.020880
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None



# Generated at 2022-06-22 00:11:16.914632
# Unit test for method parse of class Parser
def test_Parser_parse():

    arguments = ['thefuck']
    assert Parser().parse(arguments) == Namespace(alias=None, command=[], debug=False, \
        enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, \
        shell_logger=None, version=False, yes=False)

    arguments = ['thefuck', 'ls', '-la']
    assert Parser().parse(arguments) == Namespace(alias=None, command=['ls', '-la'], debug=False, \
        enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, \
        shell_logger=None, version=False, yes=False)

    arguments = ['thefuck', '--help']

# Generated at 2022-06-22 00:11:27.358226
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import pprint
    argv = ['/bin/bash', 'cd', '.', '&&', 'ls']

# Generated at 2022-06-22 00:11:36.373410
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '-v'])
    assert args.command == [] and args.version

    args = parser.parse(['thefuck', '-a'])
    assert args.command == [] and args.alias == get_alias()

    args = parser.parse(['thefuck', '-a', 'fuck'])
    assert args.command == [] and args.alias == 'fuck'

    args = parser.parse(['thefuck', '-y', 'echo', 'test'])
    assert args.command == ['echo', 'test'] and args.yes

    args = parser.parse(['thefuck', '-r', 'echo', 'test'])
    assert args.command == ['echo', 'test'] and args.repeat


# Generated at 2022-06-22 00:13:11.432931
# Unit test for constructor of class Parser
def test_Parser():
    arg_parser = Parser()
    test_args = ['-l', 'log.txt', '--', 'gcc', '-o', 'out.o']
    expected_args = ['-l', 'log.txt', '--', 'gcc', '-o', 'out.o']
    assert(arg_parser._prepare_arguments(test_args) == expected_args)


# Generated at 2022-06-22 00:13:15.197800
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Arrange
    argv = 'thefuck --help'.split()
    parser = Parser()

    # Act
    parser.print_usage()

    # Assert
    assert parser._parser.print_usage(sys.stderr)


# Generated at 2022-06-22 00:13:16.144387
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    _parser = Parser()
    _parser.print_usage()

# Generated at 2022-06-22 00:13:25.230290
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test method parse of class Parser

    """
    # Test symbol -h
    parser = Parser()
    result = parser.parse(['', '-h'])
    assert result.help

    # Test symbol -a
    parser.print_help()
    assert get_alias() == 'fuck'
    result = parser.parse(['', '-a'])
    assert result.alias == get_alias()
    result = parser.parse(['', '-a', 'fuckery'])
    assert result.alias == 'fuckery'
    result = parser.parse(['', '-a', 'fuck'])
    assert result.alias == 'fuck'

    # Test symbol -l
    result = parser.parse(['', '-l'])
    assert result.shell_logger

    # Test symbol --
    result = parser

# Generated at 2022-06-22 00:13:26.719749
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    p = parser.print_usage()
    assert p == None



# Generated at 2022-06-22 00:13:34.323739
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'echo', 'test', '-d', '--force-command', 'ls',
            ARGUMENT_PLACEHOLDER, '--help', '-y', '-l', 'log']
    args = Parser().parse(argv)
    assert args.debug is True
    assert args.help is True
    assert args.yes is True
    assert args.force_command == 'ls'
    assert args.shell_logger == 'log'
    assert args.command == ['test', '--help', '-y', '-l', 'log']



# Generated at 2022-06-22 00:13:35.067032
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser


# Generated at 2022-06-22 00:13:39.751010
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Test method print_help of class Parser"""
    import StringIO
    std_err = StringIO.StringIO() 
    sys.stderr = std_err
    parser = Parser()
    parser.print_help()
    assert "usage" in std_err.getvalue()
    sys.stderr = sys.__stderr__
    

# Generated at 2022-06-22 00:13:41.209725
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    parser.print_help()
    assert sys.stderr.getvalue() != ""
    sys.stderr = old_stderr


# Generated at 2022-06-22 00:13:47.548957
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Given
    parser = Parser()

    # When
    # Then
    result = parser.parse(['thefuck', '--alias', 'tf'])
    assert result.alias == 'tf'
    assert result.shell_logger is None
    assert result.debug is False
    assert result.yeah is False
    assert result.repeat is False
    assert result.help is False
    assert result.version is False
    assert result.force_command is None
    assert result.command == []

    # When
    # Then
    result = parser.parse(['thefuck', '--'])
    assert result.alias == get_alias()
    assert result.shell_logger is None
    assert result.debug is False
    assert result.yeah is False
    assert result.repeat is False
    assert result.help is False
    assert result