

# Generated at 2022-06-22 00:05:40.330479
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-22 00:05:42.547756
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # Clear stderr
    sys.stdout = StringIO.StringIO()
    # Call method print hlep
    parser.print_help()

# Generated at 2022-06-22 00:05:45.031498
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    out = sys.stderr
    out.write('\n')
    p.print_usage()
    out.write('\n')
    p.print_help()
    out.write('\n')

# Generated at 2022-06-22 00:05:46.182847
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-22 00:05:57.988135
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse([''])
    assert args.command is None
    assert args.yes is False
    assert args.repeat is False
    assert args.alias is None
    assert args.version is False
    assert args.debug is False
    assert args.help is False
    assert args.shell_logger is None

    args = parser.parse(['', '-y'])
    assert args.command is None
    assert args.yes is True
    assert args.repeat is False
    assert args.alias is None
    assert args.version is False
    assert args.debug is False
    assert args.help is False
    assert args.shell_logger is None

    args = parser.parse(['', '-r'])
    assert args.command is None
    assert args.yes is False

# Generated at 2022-06-22 00:06:00.242171
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

# Generated at 2022-06-22 00:06:11.881841
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # One argument test
    expected_result = parser.parse(['thefuck', 'progname'])
    assert expected_result.command == ['progname'], \
           '''Test case failed in "test_Parser.py",
           method "test_Parser" at line 15'''

    # Multiple arguments test
    expected_result = parser.parse(['thefuck', 'progname', 'arg1', 'arg2'])
    assert expected_result.command == ['progname', 'arg1', 'arg2'], \
           '''Test case failed in "test_Parser.py",
           method "test_Parser" at line 23'''

    # Test case with placeholder

# Generated at 2022-06-22 00:06:12.807360
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:13.996137
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:15.441530
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:29.691260
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    actual = parser.parse(["-v", "command", "argument"])
    assert actual.version is True
    assert actual.command == ["command", "argument"]

    actual = parser.parse(["-d", "-y", "command", "argument"])
    assert actual.debug is True
    assert actual.yes is True
    assert actual.command == ["command", "argument"]

    actual = parser.parse(["-d", "-r", "command", "argument"])
    assert actual.repeat is True
    assert actual.command == ["command", "argument"]

    actual = parser.parse(["--force-command", "command", "argument"])
    assert actual.force_command == "command"
    assert actual.command == ["argument"]

    actual = parser.parse(["command", "argument"])


# Generated at 2022-06-22 00:06:30.760469
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:41.791964
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # `parse` should return Namespace that contains `command` without
    # arguments of thefuck and `--help` from input.
    arguments = parser.parse(['thefuck', 'git', '--help'])
    assert arguments.command == ['git', '--help']

    # `parse` should return Namespace that contains `command` with arguments
    # of thefuck and `--` before arguments of `command`.
    arguments = parser.parse(
        ['thefuck', '--yes', '-r', ARGUMENT_PLACEHOLDER, 'git', '--help'])
    assert arguments.command == ['git', '--help']
    assert arguments.yes is True
    assert arguments.repeat is True

    # `parse` should return Namespace that contains `command` with arguments
    # of `command`

# Generated at 2022-06-22 00:06:46.106400
# Unit test for constructor of class Parser
def test_Parser():
    assert hasattr(Parser(), 'parse')
    assert hasattr(Parser().parse(''), 'alias')
    assert hasattr(Parser().parse(''), 'force_command')
    assert hasattr(Parser().parse(''), 'debug')

# Generated at 2022-06-22 00:06:47.893394
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    PARSER=Parser()
    assert PARSER.print_help() != None


# Generated at 2022-06-22 00:06:49.149549
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:06:59.584414
# Unit test for method parse of class Parser
def test_Parser_parse():
    import unittest
    args = ["thefuck", "ls", "--color=no", "--", "-la", ARGUMENT_PLACEHOLDER,
            "--color=yes", "--color=never", "--no-color", "--force-color", "-G", "-g"]
    result = Parser().parse(args)
    expected = (Namespace(alias=None, command=['--color=yes', '--color=never', '--no-color', '--force-color', '-G', '-g'], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False),)
    assert result == expected


# Generated at 2022-06-22 00:07:02.952990
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        Parser().print_usage()
        assert stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' \
                                    '[-l SHELL_LOGGER] [--enable-experimental-instant-mode] ' \
                                    '[-d] [--force-command FORCE_COMMAND] ' \
                                    '[-y | -r] [--] [command [command ...]]\n'


# Generated at 2022-06-22 00:07:10.306228
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    args1 = ['thefuck', 'ls', 'sadasd']
    parser = Parser()
    orig_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        parser.print_usage()
    finally:
        out = sys.stderr.getvalue()
        sys.stderr = orig_stderr
    assert out == help_message_new_output("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n" +
             "              [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND]\n" +
             "              [command [command ...]]\n\n")


# Generated at 2022-06-22 00:07:14.388192
# Unit test for constructor of class Parser
def test_Parser():
    from .utils import get_alias
    parser = Parser()
    assert parser._parser.prog == "thefuck"
    assert parser._parser.add_help == False
    parser._parser.print_help(sys.stderr)



# Generated at 2022-06-22 00:07:20.334137
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help() # Won't print to stdout

# Generated at 2022-06-22 00:07:28.693943
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    expected = ("usage: thefuck [-h] [-v] [-a [custom-alias-name]] "
                "[-l SHELL_LOGGER] [--enable-experimental-instant-mode] "
                "[-d] [--force-command FORCE_COMMAND] [--yes] [--yeah] "
                "[--hard]\n"
                "                [-r]\n"
                "                [--] [command [command ...]]\n")
    try:
        output = parser.print_usage()
    except:
        return False
    return output == expected


# Generated at 2022-06-22 00:07:40.033066
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    def check_print_help():

        parser = Parser()
        print(parser.print_help())

        help_from_manual = sys.stderr
        help_from_manual = help_from_manual.getvalue()

        # help that you see when you run thefuck --help

# Generated at 2022-06-22 00:07:41.542154
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:07:52.661046
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse('thefuck') == parser.parse('thefuck --')
    assert parser.parse('thefuck -y') == parser.parse('thefuck -- -y')
    assert parser.parse('thefuck -r') == parser.parse('thefuck -- -r')
    assert parser.parse('thefuck -d') == parser.parse('thefuck -- -d')
    assert parser.parse('thefuck --debug') == parser.parse('thefuck -- -d')

    assert parser.parse('thefuck --placeholder') == \
        parser.parse('thefuck -- -a --placeholder')
    assert parser.parse('thefuck --placeholder') == \
        parser.parse('thefuck -- -a --placeholder')

# Generated at 2022-06-22 00:07:54.451062
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    args = Parser().parse(['-h'])
    assert args.help



# Generated at 2022-06-22 00:07:55.949609
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:08:03.434996
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # command:
    #   python3 -m test_arguments
    # output:
    #   usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]
    #                 [--enable-experimental-instant-mode] [-d] [-y] [-r] [--]
    #                 [command [command ...]]
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:08:12.579748
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    command = 'command'
    placeholder = ARGUMENT_PLACEHOLDER
    expected_result = Namespace(help=False, debug=False, alias=None, shell_logger=None, yes=False, repeat=False, enable_experimental_instant_mode=False, force_command=None, command=['command'])
    test_cases = {
        [command, placeholder, 'extra']: expected_result,
        [placeholder, 'extra', command]: expected_result,
        [command, '-y', placeholder, 'extra']: Namespace(help=False, debug=False, alias=None, shell_logger=None, yes=True, repeat=False, enable_experimental_instant_mode=False, force_command=None, command=['command'])
    }

# Generated at 2022-06-22 00:08:23.118206
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER
    from .parser import Parser
    from argparse import Namespace
    parser = Parser()
    argv = [ARGUMENT_PLACEHOLDER, '-d', '--enable-experimental-instant-mode', 'echo', '-l', 'path/to/file', '--shell-logger', 'path/to/file']
    actual = parser.parse(argv)
    expected = Namespace(alias=get_alias(), command=['echo'], debug=True, enable_experimental_instant_mode=True, force_command=None, help=False, repeat=False, shell_logger='path/to/file', version=False, yes=False)
    assert actual == expected

# Generated at 2022-06-22 00:08:27.689171
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    test_Parser = Parser()
    assert test_Parser.print_help() == None



# Generated at 2022-06-22 00:08:31.631562
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from thefuck.utils import alias

    alias = alias()
    parser = Parser()
    output = StringIO()
    sys.stderr = output
    parser.print_usage()
    actual_text = output.getvalue().strip()
    expected_text = "usage: thefuck [-h] [-y] [-a [custom-alias-name]] [-v] [-d] [-l SHELL_LOGGER] [-r] [--force-command FORCE_COMMAND] [--] command [command ...]"
    assert actual_text == expected_text


# Generated at 2022-06-22 00:08:33.203967
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:08:36.128649
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'something']) == \
        parser.parse(['fuck', '--', 'something'])

# Generated at 2022-06-22 00:08:37.774830
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:08:39.295442
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert len(parser._parser._actions) == 9


# Generated at 2022-06-22 00:08:46.929211
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[0].dest == 'yes'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[1].dest == 'repeat'
    assert parser._parser._actions[6].dest == 'debug'

# Generated at 2022-06-22 00:08:55.876394
# Unit test for constructor of class Parser
def test_Parser():
  parser = Parser()
  assert parser._parser.prog == 'thefuck'
  assert parser._parser._actions[1].dest == 'version'
  assert parser._parser._actions[2].dest == 'alias'
  assert parser._parser._actions[3].dest == 'shell_logger'
  assert parser._parser._actions[4].dest == 'enable_experimental_instant_mode'
  assert parser._parser._actions[5].dest == 'help'
  assert parser._parser._actions[6].dest == 'yes'
  assert parser._parser._actions[7].dest == 'debug'
  assert parser._parser._actions[8].dest == 'force_command'
  assert parser._parser._actions[9].dest == 'command'


# Generated at 2022-06-22 00:09:06.999382
# Unit test for method parse of class Parser
def test_Parser_parse():
    
    parser = Parser()
    assert parser._prepare_arguments(['$', 'fuck']) == ['fuck']
    assert parser._prepare_arguments(['$', 'fuck', ARGUMENT_PLACEHOLDER, '-d']) == ['-d', 'fuck']
    assert parser._prepare_arguments(['$', 'fuck', '-d']) == ['-d', 'fuck']

    assert parser.parse(['fuck']) == parser._parser.parse_args(['fuck'])
    
    # The `fuck` is removed from command and placed at the beginning.
    assert parser.parse(['$', 'fuck']) == parser._parser.parse_args(['fuck'])

    # The `fuck` is removed from command and placed at the beginning.

# Generated at 2022-06-22 00:09:10.405570
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert len(p._parser._actions) == 3
    assert len(p._parser._optionals._group_actions) == 5



# Generated at 2022-06-22 00:09:20.458420
# Unit test for constructor of class Parser
def test_Parser():
    parser=Parser()
    print(parser)
if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-22 00:09:23.197849
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser_usage = parser._parser.format_usage()
    parser.print_usage()
    assert parser_usage == sys.stderr.getvalue()


# Generated at 2022-06-22 00:09:27.944279
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['script', '-v', '-l', 'test.log', 'ls', '1', '2', "--", '-a'])
    assert args.version
    assert args.shell_logger == 'test.log'
    assert args.command == ['ls', '1', '2', '-a']


# Generated at 2022-06-22 00:09:30.145484
# Unit test for constructor of class Parser
def test_Parser():
    assert str(Parser) == '<class \'thefuck.parser.Parser\'>'

# Generated at 2022-06-22 00:09:41.115389
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

    assert p.parse([]) == Namespace(command=[], debug=False,
                                    enable_experimental_instant_mode=False,
                                    force_command=None, help=False,
                                    shell_logger=None, version=False,
                                    yeah=False, repeat=False)

    assert p.parse(['cd', ARGUMENT_PLACEHOLDER, '-l', '--', '-l']) == \
        Namespace(command=['cd', '-l'], debug=False,
                  enable_experimental_instant_mode=False,
                  force_command=None, help=False, shell_logger=None,
                  version=False, yeah=False, repeat=False)


# Generated at 2022-06-22 00:09:53.249096
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])
    assert parser.parse(['thefuck', 'ls', '-a']) == parser._parser.parse_args(['--', 'ls', '-a'])
    assert parser.parse(['thefuck', 'ls', '-a', 'command_args', ARGUMENT_PLACEHOLDER, '-d']) == parser._parser.parse_args(['-d', '--', 'ls', '-a', 'command_args'])
    assert parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER]) == parser._parser.parse_args(['--', 'ls', '-a'])

# Generated at 2022-06-22 00:10:00.212187
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    ### Arrange
    from StringIO import StringIO
    parser = Parser()

    ### Act
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        parser.print_usage()
        output = out.getvalue().strip()
    finally:
        sys.stdout = saved_stdout

    ### Assert
    assert output == """\
usage: thefuck [--help] [-v] [-a [custom-alias-name]] [-l shell-logger] \
[--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command force-command] \
command [command ...]
""", output


# Generated at 2022-06-22 00:10:02.572104
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert not p._parser.add_help


# Generated at 2022-06-22 00:10:03.497296
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:10:09.069218
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser._parser.parse_args(['--', 'ls', '-l'])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls', '-l']) == \
        parser._parser.parse_args(['ls', '-l', '--'])


# Generated at 2022-06-22 00:10:31.142369
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    # check if the class Parser is initialized properly
    assert isinstance(parser, Parser)



# Generated at 2022-06-22 00:10:33.741965
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:10:35.105457
# Unit test for constructor of class Parser
def test_Parser():
    p=Parser()
    p.parse(['-a', '--version'])

# Generated at 2022-06-22 00:10:44.608136
# Unit test for method print_usage of class Parser

# Generated at 2022-06-22 00:10:46.531538
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Arrange
    parser = Parser()
    # Act and Assert
    parser.print_usage()


# Generated at 2022-06-22 00:10:47.320520
# Unit test for constructor of class Parser
def test_Parser():
	assert Parser()


# Generated at 2022-06-22 00:10:56.622138
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        pass


if __name__ == '__main__':
    import os
    import unittest
    from mock import patch
    from thefuck.tests.utils import Mock, TestCase

    class ParserTest(TestCase):
        @patch.object(sys, 'argv', ['thefuck', '-v'])
        def test_prints_version(self):
            with self.assertRaises(SystemExit):
                Parser().parse(sys.argv)

        @patch.object(sys, 'argv', ['thefuck', '-a'])
        def test_prints_alias(self):
            with self.assertRaises(SystemExit):
                Parser().parse(sys.argv)


# Generated at 2022-06-22 00:10:58.149379
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser._parser.format_help())

# Generated at 2022-06-22 00:11:01.542314
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()

if __name__ == "__main__":
    test_Parser_print_usage()

# Generated at 2022-06-22 00:11:07.864636
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test method parse of class Parser"""
    # Test without ARGUMENT_PLACEHOLDER
    args1 = Parser().parse(['thefuck', '-h'])
    assert args1.help
    assert not args1.version
    assert not args1.alias
    assert not args1.shell_logger
    assert not args1.debug
    assert not args1.yes
    assert not args1.repeat
    assert args1.command == []
    assert args1.entry_point is None
    assert args1.help_all is False
    assert args1.match == 'approx'
    assert args1.rules == []

    # Test with ARGUMENT_PLACEHOLDER, command and arguments provided

# Generated at 2022-06-22 00:11:43.775614
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # mock object
    sys.stderr = StringIO()
    Parser().print_usage()
    assert 'usage: thefuck' in sys.stderr.getvalue()


# Generated at 2022-06-22 00:11:44.893509
# Unit test for constructor of class Parser
def test_Parser():
    args = Parser()
    print(args)


# Generated at 2022-06-22 00:11:48.268202
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['script_name', 'wrong_command'])
    assert args.command == ['wrong_command']

# Generated at 2022-06-22 00:11:57.077979
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([
        'thefuck',
        'ls',
        '-l',
        ARGUMENT_PLACEHOLDER,
        '-a',
        '-v',
        '-l']) == parser.parse([
                'thefuck',
                '-l',
                '-a',
                '-v',
                '-l',
                'ls',
                '-l'])
    assert parser.parse([
        'thefuck',
        '--repeat',
        ARGUMENT_PLACEHOLDER,
        'ls',
        '--',
        '-l']) == parser.parse([
                'thefuck',
                '--repeat',
                'ls',
                '--',
                '-l'])

# Generated at 2022-06-22 00:12:01.402233
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    import sys
    s = StringIO()
    sys.stderr = s
    Parser().print_help()
    sys.stderr = sys.__stderr__
    s.seek(0)
    assert (s.read().startswith('usage: thefuck'))
    assert ('--version' in s.read())

# Generated at 2022-06-22 00:12:11.025422
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Tests the help message of thefuck's argument parser."""
    from thefuck.manage import parse_args
    from thefuck.const import VERSION

    message = "Error: argument --shell-logger: expected one argument"
    with pytest.raises(SystemExit, match=message):
        parse_args(argv=["--shell-logger"])

    # help message

# Generated at 2022-06-22 00:12:13.586747
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()
    assert True

# Generated at 2022-06-22 00:12:22.693888
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Test the `--` case
    args = parser.parse(['thefuck', '--', 'tree'])
    assert args.command == ['tree']

    # Test the `-a` case
    args = parser.parse(['thefuck', '-a', 'tf'])
    assert args.alias == 'tf'

    # Test the `-l` case
    args = parser.parse(['thefuck', '-l', 'log.txt'])
    assert args.shell_logger == 'log.txt'

    # Test the `-yy` case
    args = parser.parse(['thefuck', '-yy', 'tree'])
    assert args.command == ['tree']
    assert args.yes == True

    # Test the `-r` case

# Generated at 2022-06-22 00:12:30.961440
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    res = subprocess.run(['python3', '-m', 'tests.utils.test_Parser'],
                         capture_output=True)  # capture_output=True => stderr
    assert res.returncode == 0
    assert res.stdout == b''
    assert res.stderr == b'usage: thefuck [-h] [-v] [-a ALIAS] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y] [-r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n'


# Generated at 2022-06-22 00:12:35.590609
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv="thefuck --yes 't' 'g' 's' 'v'"
    result=Parser()
    result_parse=result.parse(argv)
    assert_result_parse = ['t', 'g', 's', 'v']
    assert result_parse.command == assert_result_parse
    assert result_parse.yes == True
    assert result_parse.repeat == None

# Generated at 2022-06-22 00:14:05.318611
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:14:08.294735
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck','ls','--','thefuck','ls','thefuck','ls'])
    # On command line, thefuck ls -- thefuck ls thefuck ls
    # Here, args.command is ['thefuck','ls','thefuck','ls']
    assert args.command == ['thefuck','ls','thefuck','ls']

# Generated at 2022-06-22 00:14:12.808828
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '--help'])
    assert args.__dict__ == {'help': True,
                             'command': []}
    args = parser.parse(['thefuck', 'command', '--help'])
    assert args.__dict__ == {
        'help': True,
        'command': ['command', '--help']}

# Generated at 2022-06-22 00:14:18.713926
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = sys.stdout.getvalue()
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]' \
        ' [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [-y]' \
        ' [-r] [--force-command FORCE_COMMAND] [command [command ...]]'



# Generated at 2022-06-22 00:14:25.466582
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    output = StringIO()
    err = sys.stderr
    sys.stderr = output
    p.print_usage()
    sys.stderr = err
    assert output.getvalue() == ("usage: thefuck [-h] [-v] [-l SHELL_LOGGER] "
                                 "[-a [CUSTOM_ALIAS]] [-d] [-y] [-r] "
                                 "[--enable-experimental-instant-mode] "
                                 "[--force-command FORCE_COMMAND] "
                                 "[command [command ...]]\n")


# Generated at 2022-06-22 00:14:27.416551
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-22 00:14:36.285014
# Unit test for constructor of class Parser
def test_Parser():
    with patch('thefuck.main.ArgumentParser') as ArgumentParser_mock, \
            patch('thefuck.main.get_alias', return_value='fuck'):
        filename = 'thefuck'
        parser = Parser()
        assert ArgumentParser_mock.call_args_list == \
            [call(prog=filename, add_help=False)]
        parser._add_arguments()

# Generated at 2022-06-22 00:14:39.188112
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-22 00:14:48.982020
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck', 'prog is absent or incorrect'
    assert parser._parser._optionals._group_actions[0].dest == 'version', '`version` arg is absent in _parser'
    assert parser._parser._optionals._group_actions[0].action == 'store_true', '`version` arg has incorrect action'
    assert parser._parser._optionals._group_actions[1].dest == 'alias', '`alias` arg is absent in _parser'
    assert parser._parser._optionals._group_actions[1].nargs == '?' , '`alias` arg has incorrect nargs'

# Generated at 2022-06-22 00:14:49.754125
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()