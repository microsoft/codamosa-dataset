

# Generated at 2022-06-22 00:05:48.570031
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # given
    parser = Parser()

    # when
    parser.print_usage()

    # then
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n              [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n              [-y | -r]\n              [command [command ...]]\n'


# Generated at 2022-06-22 00:05:57.901602
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-a']) == parser._parser.parse_args(['ls', '-a'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-a']) == parser._parser.parse_args(['-a', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-a', ARGUMENT_PLACEHOLDER, '-a']) == parser._parser.parse_args(['-a', '--', 'ls', '-a'])

# Generated at 2022-06-22 00:06:09.090452
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Setup the arguments to be parsed
    sys.argv = ['lol'] + ['--alias', 'git']
    assert parser.parse(sys.argv).alias == 'git'
    sys.argv = ['lol'] + ['-a', 'git']
    assert parser.parse(sys.argv).alias == 'git'
    # Try to test that only one alias can be set at once
    sys.argv = ['lol'] + ['-a', 'git', '-a', 'fuck']
    assert parser.parse(sys.argv).alias == 'fuck'
    # Try to test --yes, --repeat and --debug
    sys.argv = ['lol'] + ['--yes']
    assert parser.parse(sys.argv).yes
    sys.argv = ['lol'] + ['--repeat']

# Generated at 2022-06-22 00:06:16.545357
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import re
    import sys
    import io
    import thefuck
    parser = thefuck.Parser()
    sys.stderr = io.StringIO()
    parser.print_help()
    output = sys.stderr.getvalue()
    assert re.search(re.compile('^usage:', re.M), output) is not None
    assert re.search(re.compile('\b-a\b', re.M), output) is not None
    assert re.search(re.compile('\b-d\b', re.M), output) is not None
    assert re.search(re.compile('\b--debug\b', re.M), output) is not None

# Generated at 2022-06-22 00:06:20.331283
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['/path/to/script', '--'])
    assert arguments.command == []


# Generated at 2022-06-22 00:06:31.330987
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    expected = Namespace(yes=None, repeat=False, debug=False,
                         command=[], alias=None,
                         shell_logger=None, force_command=None,
                         enable_experimental_instant_mode=False,
                         help=False, version=False)
    assert parser.parse(['thefuck']) == expected
    assert parser.parse(['thefuck', 'ls']) == expected._replace(command=['ls'])
    assert parser.parse(['thefuck', 'ls', '-l']) == expected._replace(command=['ls', '-l'])

# Generated at 2022-06-22 00:06:33.140248
# Unit test for method print_help of class Parser
def test_Parser_print_help():
  parser = Parser()
  parser.print_help()

# Generated at 2022-06-22 00:06:34.973914
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser is not None
    assert parser.print_help() is None

# Generated at 2022-06-22 00:06:36.384156
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:06:38.599397
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-22 00:06:45.357137
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:06:47.562551
# Unit test for constructor of class Parser
def test_Parser():
    # check if the argument help is added
    if Parser().parse(['--help']):
        print('true')



# Generated at 2022-06-22 00:06:51.128795
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser
    assert parser._add_arguments
    assert parser._add_conflicting_arguments
    assert parser._prepare_arguments
    assert parser.parse
    assert parser.print_usage
    assert parser.print_help


# Generated at 2022-06-22 00:06:51.876461
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-22 00:07:03.833657
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        Parser().print_usage()


# Generated at 2022-06-22 00:07:10.209389
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['--force-command', 'reboot']) == \
        parser._parser.parse_args(['--force-command', 'reboot'])
    assert parser.parse(['rm', ARGUMENT_PLACEHOLDER, '*.pyc', '*.py']) == \
        parser._parser.parse_args(['*.pyc', '*.py', '--', 'rm'])
    assert parser.parse(['rm', '*.pyc', '-rf', ARGUMENT_PLACEHOLDER, '*.py']) == \
        parser._parser.parse_args(['*.py', '--', 'rm', '*.pyc', '-rf'])

# Generated at 2022-06-22 00:07:19.390037
# Unit test for constructor of class Parser
def test_Parser():
    code = "cd /usr/bin\ncd home"
    argv = ["thefuck",code,ARGUMENT_PLACEHOLDER]
    test_parser = Parser()
    assert test_parser._prepare_arguments(argv) == [code,"--"]
    assert test_parser._prepare_arguments(["thefuck"]) == ['--']
    assert test_parser._prepare_arguments(["thefuck","-v"]) == ['-v', '--']
    assert test_parser._prepare_arguments(["thefuck","ls"]) == ['--','ls']
    assert test_parser.parse(["thefuck","ls"]).command == ["ls"]
    assert test_parser.parse(["thefuck","-v"]).version == True

# Generated at 2022-06-22 00:07:31.647630
# Unit test for method print_usage of class Parser

# Generated at 2022-06-22 00:07:32.905669
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-22 00:07:33.764975
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() != None


# Generated at 2022-06-22 00:07:46.437783
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    with open('test.txt', 'w') as f:
        sys.stderr = f
        Parser().print_help()
    with open('test.txt', 'r') as f:
        assert 'thefuck' in f.read()
    os.remove('test.txt')


# Generated at 2022-06-22 00:07:47.462600
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:07:49.748995
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert not p._parser.add_help



# Generated at 2022-06-22 00:07:51.140959
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True

# Generated at 2022-06-22 00:07:55.854578
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser._parser.prog == 'thefuck')
    assert(parser._parser.description == None)
    assert(parser._parser.epilog == None)
    assert(parser._parser.parents == [])
    assert(parser._parser.formatter_class ==
           argparse.ArgumentDefaultsHelpFormatter)
    assert(parser._parser.prefix_chars == '-')
    assert(parser._parser.fromfile_prefix_chars == None)
    assert(parser._parser.argument_default == None)
    assert(parser._parser.add_help == False)



# Generated at 2022-06-22 00:07:59.202170
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    output = sys.stderr.getvalue()

# Generated at 2022-06-22 00:08:01.328597
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-22 00:08:11.399622
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from tempfile import TemporaryFile
    from .const import VERSION

    file = TemporaryFile()
    parser = Parser()
    parser.print_usage(file=file)
    file.seek(0)

# Generated at 2022-06-22 00:08:20.160912
# Unit test for method parse of class Parser
def test_Parser_parse():
	args = ['-v', ' ', '-d', ' ', '-y', ' ', '-r', ' ', '-h', ' ', '--help', ' ',
			'--force-command', ' ', 'echo', ' ', 'fuck', ' ']
	parser = Parser()
	assert parser.parse(args).force_command == "echo"
	assert parser.parse(args).debug == True
	assert parser.parse(args).repeat == True
	assert parser.parse(args).yes == True
	assert parser.parse(args).help == True
	assert parser.parse(args).command == ["fuck"]


# Generated at 2022-06-22 00:08:20.716664
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-22 00:08:47.338684
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    args = p.parse(['thefuck', '-d', 'foo', '--bar', '-y', 'baz'])
    assert args.debug
    assert args.command == ['foo', '--bar', 'baz']
    assert not args.yes
    assert not args.repeat

    args = p.parse(['thefuck', '-d', 'foo', '--bar', '-r', 'baz'])
    assert args.debug
    assert args.command == ['foo', '--bar', 'baz']
    assert not args.yes
    assert args.repeat

    args = p.parse(['thefuck', '-d', 'foo', '--bar', 'baz'])
    assert args.debug
    assert args.command == ['foo', '--bar']

# Generated at 2022-06-22 00:08:52.760229
# Unit test for method parse of class Parser
def test_Parser_parse():
    Parser_ = Parser()
    command = ['cd', '/usr']
    alias = "fuck"
    assert Parser_._prepare_arguments([alias]) == ['--']
    assert Parser_._prepare_arguments([alias] + command) == ['--'] + command
    assert Parser_._prepare_arguments(['-a'] + [alias] + command) \
        == ['-a'] + [alias] + ['--'] + command
    assert Parser_._prepare_arguments(['-a=' + alias] + command) \
        == ['-a=' + alias] + ['--'] + command
    assert Parser_._prepare_arguments([alias, '-a', '-j'] + command) \
        == ['-a', '--', '-j'] + command
    assert Parser_

# Generated at 2022-06-22 00:09:03.511465
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from sys import stderr

    class args:
        def __init__(self):
            self.help = True

    log = ""
    def fake_print_help(self, f):
        nonlocal log
        log += f.read()

    parser = Parser()
    parser._parser.print_usage = lambda f: fake_print_help(parser, f)
    parser._parser.print_help = lambda f: fake_print_help(parser, f)
    parser._parser.parse_args = lambda _: args()

    parser.parse(["thefuck", "--help"])
    assert "optional arguments:\n" in log
    assert "positional arguments:\n" in log
    assert "  command" in log
    assert "  -h, --help" in log


# Generated at 2022-06-22 00:09:04.781061
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:09:06.026906
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None

# Generated at 2022-06-22 00:09:14.955683
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    with open('/tmp/stderr', 'w') as f:
        sys.stderr = f
        parser.print_help()

# Generated at 2022-06-22 00:09:16.554825
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:09:27.224656
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    output = io.StringIO()
    p = Parser()
    with io.StringIO() as output:
        p.print_help()

# Generated at 2022-06-22 00:09:28.768099
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    sys.stdout.write("\n")


# Generated at 2022-06-22 00:09:39.174777
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Testcase 1: command
    p = Parser()
    args = p.parse(['thefuck', 'echo', ARGUMENT_PLACEHOLDER, 'a', 'b'])
    assert args.command == ['echo', 'a', 'b']

    # Testcase 2: option
    p = Parser()
    args = p.parse(['thefuck', '-y'])
    assert args.yes

    # Testcase 3: option + command
    p = Parser()
    args = p.parse(['thefuck', '-y', 'a', 'b', 'c'])
    assert args.yes
    assert args.command == ['a', 'b', 'c']


# Generated at 2022-06-22 00:10:35.546679
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io, sys
    from .utils import get_alias

    parser = Parser()

    help_file = io.StringIO()
    sys.stderr = help_file
    parser.print_help()
    sys.stderr = sys.__stderr__

    parsed_help = help_file.getvalue()
    assert parsed_help.startswith('usage: thefuck')
    assert '-v, --version' in parsed_help
    assert '[custom-alias-name] prints alias for current shell' in parsed_help
    assert '--shell-logger LOGFILE' in parsed_help
    assert 'log shell output to the file' in parsed_help
    assert '--enable-experimental-instant-mode' in parsed_help
    assert '-h, --help' in parsed_help

# Generated at 2022-06-22 00:10:43.523063
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    with open('/dev/null', 'w') as f:
        sys.stderr = f
        Parser().print_help()
        sys.stderr = sys.__stderr__
    with StringIO() as stream:
        f = sys.stderr = stream
        Parser().print_help()
        sys.stderr = sys.__stderr__
        output = f.getvalue()
        assert output
        assert 'optional arguments:' in output
        assert 'alias' in output
        assert 'help' in output

# Generated at 2022-06-22 00:10:46.259475
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert(isinstance(p, Parser))

# Unit test to check if the arguments are passed in the correct format to the ArgumentParser object

# Generated at 2022-06-22 00:10:47.356508
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    assert p.print_usage() is not None

# Generated at 2022-06-22 00:10:51.242526
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser is not None
    assert p.parse is not None
    assert p.print_help is not None
    assert p.print_usage is not None
    assert p._add_arguments is not None
    assert p._prepare_arguments is not None

# Generated at 2022-06-22 00:10:52.285490
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == "thefuck"

# Generated at 2022-06-22 00:11:03.711317
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    print(parser.parse(['thefuck']))
    print(parser.parse(['thefuck', 'command']))
    print(parser.parse(['thefuck', '-h']))
    print(parser.parse(['thefuck', '-l', 'logfile']))
    print(parser.parse(['thefuck', '-y']))
    print(parser.parse(['thefuck', '-r']))
    print(parser.parse(['thefuck', '-a']))
    print(parser.parse(['thefuck', '-a', 'tf']))
    print(parser.parse(['thefuck', 'command', '-h', '-y']))
    print(parser.parse(['thefuck', 'command', ARGUMENT_PLACEHOLDER, '-y']))

# Generated at 2022-06-22 00:11:16.072725
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == \
        parser._parser.parse_args(['--', 'ls'])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'a', 'b']) == \
        parser._parser.parse_args(['a', 'b'])
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'a', ARGUMENT_PLACEHOLDER, 'b']) == \
        parser._parser.parse_args(['a', 'b'])

# Generated at 2022-06-22 00:11:17.129293
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), Parser)

# Generated at 2022-06-22 00:11:19.918404
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    print("\ntest_Parser_print_help()")
    p = Parser()
    p.print_help()


# Generated at 2022-06-22 00:13:09.890186
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:13:11.505359
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True


# Generated at 2022-06-22 00:13:18.145162
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser.parse(['thefuck', '--'])
    assert parser.parse(['thefuck']) == parser.parse(['thefuck', '--', '--'])
    assert parser.parse(['thefuck', 'git', 'status'])\
        == parser.parse(['thefuck', '--', 'git', 'status'])
    assert parser.parse(['thefuck', 'git', 'status'])\
        == parser.parse(['thefuck', 'git', 'status', '--'])
    assert parser.parse(['thefuck', '--', 'git', 'status', '--'])\
        == parser.parse(['thefuck', '--', 'git', 'status', '--', '--'])

# Generated at 2022-06-22 00:13:27.407464
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv1 = ['thefuck', '-v']
    argv2 = ['thefuck', '-a']
    argv3 = ['thefuck', '-a', '--']
    argv4 = ['thefuck', '-a', 'arg1', 'arg2']
    argv5 = ['thefuck', '-a', 'arg1']
    argv6 = ['thefuck', '-a', 'arg1', '--', 'command', '--', 'arg2']
    argv7 = ['thefuck', '-a', 'arg1', 'command', 'arg2']
    argv8 = ['thefuck', '-a', 'arg1', 'command', '--', 'arg2']
    argv9 = ['thefuck', 'command']

# Generated at 2022-06-22 00:13:36.103710
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['./bin/thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER, '-ll']
    assert Parser().parse(argv).command == ['ls', '-la']

    argv = ['./bin/thefuck', '-y']
    assert Parser().parse(argv) is not None

    argv = ['./bin/thefuck', '-h']
    assert Parser().parse(argv) is not None

    argv = ['./bin/thefuck', '-a']
    assert Parser().parse(argv) is not None

    argv = ['./bin/thefuck', '-v']
    assert Parser().parse(argv) is not None

    argv = ['./bin/thefuck', '-d']
    assert Pars

# Generated at 2022-06-22 00:13:37.747830
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:13:38.699152
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.prog == 'thefuck'

# Generated at 2022-06-22 00:13:39.781258
# Unit test for constructor of class Parser
def test_Parser():
    assert ArgumentParser(add_help=False).description is None


# Generated at 2022-06-22 00:13:43.118903
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import pytest
    from .env import reset_env, get_alias

    reset_env(None)
    parser = Parser()
    import pprint
    pprint.pprint(parser.print_help())


if __name__ == '__main__':
    import pytest
    from .env import reset_env, get_alias

    reset_env(None)
    parser = Parser()
    import pprint
    pprint.pprint(parser.print_help())

# Generated at 2022-06-22 00:13:46.679833
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import capture_stderr
    from .parser import Parser

    with capture_stderr() as output:
        Parser().print_help()