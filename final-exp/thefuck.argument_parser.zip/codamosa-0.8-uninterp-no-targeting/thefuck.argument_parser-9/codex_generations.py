

# Generated at 2022-06-22 00:05:58.044940
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    # redirecting output to StringIO
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    parser = Parser()
    parser.print_usage()
    test_output = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = old_stdout
    assert test_output == "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n            [-l SHELL_LOGGER]\n            [--enable-experimental-instant-mode]\n            [-y | -r] [-d] [--force-command FORCE_COMMAND]\n            [command [command ...]]\n"


# Generated at 2022-06-22 00:06:00.031839
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == "thefuck"
    assert parser._parser.description is None


# Generated at 2022-06-22 00:06:01.454113
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Method print_help of Parser should print help"""
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:03.230443
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:06:03.928936
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser().__class__ == Parser


# Generated at 2022-06-22 00:06:14.770657
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', '-v', 'ls']) == parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', '-v', 'ls', '-l']) == parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-v', '-l'])
    assert parser.parse(['thefuck', '--help']) == parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '--help'])

# Generated at 2022-06-22 00:06:25.908952
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Without ARGUMENT_PLACEHOLDER
    assert ['--force-command=1'] == Parser().parse(['-', '--force-command=1'])
    assert ['--force-command=1'] == Parser().parse(['--force-command=1'])
    assert ['--force-command=1', 'foo'] == \
        Parser().parse(['-', '--force-command=1', 'foo'])
    assert ['--force-command=1', 'foo'] == \
        Parser().parse(['--force-command=1', 'foo'])
    assert ['--force-command=1', 'foo', '--', 'bar'] == \
        Parser().parse(['--force-command=1', 'foo', '--', 'bar'])

    # With ARGUMENT_PLACE

# Generated at 2022-06-22 00:06:37.772266
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # A test case is like a unit test in normal software.
    # The test is made up of a few pieces.
    # This is the first piece of the test,
    # which compares the return of the print_usage function in Parser.
    # If the return is equal to
    # the "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n"
    # the test is considered passed, otherwise failed.
    from io import StringIO
    from .parser import Parser
    p = Parser()
    f = StringIO()
    p.print_usage(file=f)

# Generated at 2022-06-22 00:06:44.111657
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([
        'thefuck',
        'echo',
        '-h', '--help',
        ARGUMENT_PLACEHOLDER,
        '--repeat',
        'shit', 'fuck'
    ]) == parser._parser.parse_args([
        '-h', '--help',
        '--',
        '--repeat',
        'shit', 'fuck'
    ])

# Generated at 2022-06-22 00:06:49.794835
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class Stub(object):
        def __init__(self):
            self.buffer = []
        def write(self, txt):
            self.buffer.append(txt)

    Stderr = sys.stderr
    sys.stderr = Stub()

    try:
        Parser().print_usage()
        assert "optional arguments" in sys.stderr.buffer[0]
    finally:
        sys.stderr = Stderr

# Generated at 2022-06-22 00:07:02.748952
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:07:10.231046
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    sys.argv = 'thefuck --version'.split()
    assert parser.parse(sys.argv) == parser._parser.parse_args('--version'.split())
    sys.argv = 'thefuck --shell-logger=/tmp/logs'.split()
    assert parser.parse(sys.argv) == parser._parser.parse_args('--shell-logger=/tmp/logs'.split())
    sys.argv = 'thefuck --alias'.split()
    assert parser.parse(sys.argv) == parser._parser.parse_args('--alias'.split())
    sys.argv = 'thefuck --alias fuck'.split()
    assert parser.parse(sys.argv) == parser._parser.parse_args('--alias fuck'.split())

# Generated at 2022-06-22 00:07:11.790454
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-22 00:07:19.980025
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import THEFUCK_SETTINGS_DIR
    from .utils import get_alias
    from io import StringIO

    alias = get_alias()
    parser = Parser()
    old_stdout = sys.stderr
    capturedOutput = StringIO()
    sys.stderr = capturedOutput
    parser.print_usage()
    usage_expected = '''usage: thefuck [-h] [-v] [-a [{alias}]] [-l SHELL_LOGGER]
              [--enable-experimental-instant-mode] [-d]
              [--force-command COMMAND]
              [--yes | --repeat]
              [command [command ...]]
'''.format(alias=alias)
    assert capturedOutput.getvalue() == usage_expected
    sys.stderr = old_stdout

# Unit test

# Generated at 2022-06-22 00:07:21.923020
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)


# Generated at 2022-06-22 00:07:23.248406
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-22 00:07:35.213694
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Test case 1: if the args contains the argument placeholder,
    # the placeholder and the args behind it are moved to the front of the args
    args = ['--yes', 'ls', ARGUMENT_PLACEHOLDER, '-l', '-a', '-h']
    result = parser.parse(args)
    assert result.command == ['ls', '-l', '-a', '-h']
    assert result.yes is True
    assert result.repeat is False
    assert result.debug is False
    # Test case 2: if argument placeholder is not in argv,
    # and the first argument is not a option argument and is not the end,
    # the the `--` is inserted to the front of the args
    args = ['ls', '-l', '-a']
    result = parser

# Generated at 2022-06-22 00:07:39.946463
# Unit test for method parse of class Parser
def test_Parser_parse():
    from argparse import Namespace
    parser = Parser()

    argv = ['thefuck', 'git', 'cwomit', '--amend']
    expected = Namespace(alias=None, command=['git', 'cwomit', '--amend'],
                         debug=False, enable_experimental_instant_mode=None,
                         force_command=None, help=False, repeat=None,
                         shell_logger=None, version=None, yeah=None)
    assert parser.parse(argv) == expected

    argv = ['thefuck', 'git', 'cwomit', '--amend', '--', '-f']

# Generated at 2022-06-22 00:07:42.397548
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser._parser.print_usage = lambda: 'Print usage'
    assert parser.print_usage() == 'Print usage'

# Generated at 2022-06-22 00:07:44.809934
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert repr(p) == str(Parser)


# Generated at 2022-06-22 00:08:21.448962
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['python2', 'history.py', 'ls']) == \
            Namespace(command=['ls'], debug=False, log_file=None)
    assert Parser().parse(['python2', 'history.py', 'ls', '-l']) == \
            Namespace(command=['ls', '-l'], debug=False, log_file=None)
    assert Parser().parse(['python2', 'history.py', 'ls', ARGUMENT_PLACEHOLDER]) == \
            Namespace(command=[], debug=False, log_file=None)

# Generated at 2022-06-22 00:08:26.458453
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    test_argv = ['/bin/thefuck', '--debug', 'ls', ARGUMENT_PLACEHOLDER, '-h', '--help']
    assert parser.parse(test_argv).debug, 'flag debug set'
    assert parser.parse(test_argv).help, 'flag help set'
    assert parser.parse(test_argv).command, 'command set'

# Generated at 2022-06-22 00:08:27.194851
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-22 00:08:33.865374
# Unit test for method parse of class Parser
def test_Parser_parse():
    _parser = Parser()
    _parser.parse(['fuck', 'ls'])
    _parser.parse(['fuck', 'ls', '-a'])
    _parser.parse(['fuck', 'ls', '-l'])
    _parser.parse(['fuck', 'ls', '-d'])
    _parser.parse(['fuck', 'ls', '-h'])
    _parser.parse(['fuck', 'ls', '--help'])
    _parser.parse(['fuck', 'ls', '--force-command', 'ls'])


# Generated at 2022-06-22 00:08:41.295256
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import sys
    _stdout = sys.stdout
    _stderr = sys.stderr
    try:
        sys.stdout = sys.stderr = open('test_parser', 'w')
        parser.print_usage()
    finally:
        sys.stdout, sys.stderr = _stdout, _stderr
        assert open('test_parser').read()
        os.remove('test_parser')


# Generated at 2022-06-22 00:08:47.731401
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'gcc', '--version']) == parser.parse(['thefuck', 'gcc', ARGUMENT_PLACEHOLDER, '--version'])
    assert parser.parse(['thefuck', 'gcc', '--version']) == parser.parse(['thefuck', '--', 'gcc', '--version'])
    assert parser.parse(['thefuck', '--yes', 'gcc', '--version']) == parser.parse(['thefuck', 'gcc', '--version'])
    assert parser.parse(['thefuck', '--repeat', 'gcc', '--version']) == parser.parse(['thefuck', 'gcc', '--version'])

# Generated at 2022-06-22 00:08:50.531265
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    help_parser = Parser()
    help_parser.print_help()

if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-22 00:08:59.193213
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = ["thefuck", "command", "-a", "tf", "arg1", "arg2"]
    assert parser.parse(args).command == ["command", "-a", "tf", "arg1", "arg2"]
    assert parser.parse(args).shell_logger == None
    assert parser.parse(args).enable_experimental_instant_mode == None
    assert parser.parse(args).help == None
    assert parser.parse(args).yes == False
    assert parser.parse(args).repeat == False
    assert parser.parse(args).debug == False
    assert parser.parse(args).force_command == None
    assert parser.parse(args).alias == None
    assert parser.parse(args).version == None

# Generated at 2022-06-22 00:09:01.315407
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    parser.print_help()
    assert parser.print_help() == parser.print_help()



# Generated at 2022-06-22 00:09:04.249007
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None

# Generated at 2022-06-22 00:09:23.667553
# Unit test for constructor of class Parser
def test_Parser():
    test = Parser()
    assert test != None


# Generated at 2022-06-22 00:09:26.158014
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # add this print because the error get on stdout
    print(parser.print_usage())

# Generated at 2022-06-22 00:09:32.042822
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    #The method print_usage will print the usage message of the program
    usage = "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--yes | --repeat] [--] [command [command ...]]"
    sys_stderr = sys.stderr
    sys.stderr = open('UnitTestOutput','w')
    p = Parser()
    p.print_usage()
    sys.stderr.close()
    sys.stderr = sys_stderr
    with open('UnitTestOutput','r') as f:
        message = f.read()
    assert message == usage
    os.remove('UnitTestOutput')

#

# Generated at 2022-06-22 00:09:38.978940
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['', 'help', '-d', '--force-command='])
    assert result.help
    assert result.debug
    assert result.force_command == ''

    result = parser.parse(['', '--debug', '--force-command=fuck', 'ls'])
    assert result.debug
    assert result.force_command == 'fuck'
    assert result.command == ['ls']

# Generated at 2022-06-22 00:09:39.955545
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()
    

# Generated at 2022-06-22 00:09:41.235658
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == None


# Generated at 2022-06-22 00:09:42.152311
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:09:44.487002
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse([])



# Generated at 2022-06-22 00:09:46.225284
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-22 00:09:57.350517
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    import sys
    from .const import ALIAS_HELP, VERSION, ALIAS, VERSION_HELP, ALIAS_ENV

    # Get the version of thefuck
    #with io.StringIO() as buf, redirect_stdout(buf):
    #    main(['--version'])
    #    output = buf.getvalue()
    #assert output == VERSION + '\n'

    # Get help with the alias parameter
    alias_argv = ['--alias']
    with io.StringIO() as buf, redirect_stdout(buf):
        main(alias_argv)
        output = buf.getvalue()
    assert output == VERSION + '\n\n' + alias_argv[0] + ' ' + ALIAS_HELP + '\n\n' + ALIAS

# Generated at 2022-06-22 00:10:32.377950
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # create a stringIO object
    output = sys.stdout

    # redirect stdout to stringIO object
    sys.stdout = io.StringIO()

    # create a parser
    parser = Parser()
    parser.print_usage()

    # get the content of stringIO object
    actual_stdout = sys.stdout.getvalue()

    # let stdout back to screen
    sys.stdout = output

    # compare the result
    expected_stdout = "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n"
    assert actual_stdout == expected_stdout

# Unit test

# Generated at 2022-06-22 00:10:35.580968
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.stderr = StringIO()
    s = Parser()
    s.print_help()
    assert sys.stderr.getvalue().startswith('usage:')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:10:37.976139
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:10:45.338394
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    if os.getenv('SHELL') == 'zsh':
        assert parser.parse(['thefuck --', 'ls', '|', 'grep', 'f']) == \
               parser._parser.parse_args(['--', 'ls', '|', 'grep', 'f'])
        assert parser.parse(['thefuck', '--', 'ls', '|', 'grep', 'f']) == \
               parser._parser.parse_args(['--', 'ls', '|', 'grep', 'f'])

# Generated at 2022-06-22 00:10:46.492315
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:10:55.761485
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    from thefuck.types import Settings
    from thefuck.shells.bash import Bash
    parser = Parser()
    settings = Settings(
        historical_limit=3,
        wait_command=1,
        require_confirmation=False,
        repeat=False,
        no_colors=False,
        exclude_rules='',
        exclude_commands='',
        alias='fuck',
        wait_slow_command=10,
        slow_commands='',
        priority_commands='',
        history_limit=100,
        use_experimental_instant_mode=False)
    bash = Bash(settings, python_script='/usr/bin/python')
    try:
        parser.print_help()
        parser.print_usage()
    except:
        pass

# Generated at 2022-06-22 00:10:58.797465
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Test if parser prints a message with the proper format
    """
    parser = Parser()
    try:
        parser.print_usage()
    except SystemExit as e:
        assert(e.code==0)


# Generated at 2022-06-22 00:11:01.664625
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert p.print_help() == None

# Generated at 2022-06-22 00:11:03.905795
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    options = parser.parse(['thefuck', '--help'])
    assert options.help



# Generated at 2022-06-22 00:11:06.023179
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:11:59.780539
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    usage = parser.print_usage()

    assert "usage: thefuck" in usage


# Generated at 2022-06-22 00:12:02.071570
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert p.print_help() == None
    #print p.print_help()

# Generated at 2022-06-22 00:12:13.113878
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    argv = 'fuck foo'.split()
    arguments = parser.parse(argv)

    assert arguments.command == ['foo']
    assert arguments.repeat is False
    assert arguments.yes is False
    assert arguments.alias is None
    assert arguments.debug is False

    argv = 'fuck -r foo'.split()
    arguments = parser.parse(argv)

    assert arguments.command == ['foo']
    assert arguments.repeat is True
    assert arguments.yes is False
    assert arguments.alias is None
    assert arguments.debug is False

    argv = 'fuck -y foo'.split()
    arguments = parser.parse(argv)

    assert arguments.command == ['foo']
    assert arguments.repeat is False
    assert arguments.yes is True
    assert arguments.alias is None

# Generated at 2022-06-22 00:12:16.392917
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """ Test print_help method of class Parser

    EXAMPLE
    -------
    $ python3 -m pytest tests/test_parser.py
    """
    argv = ['']
    parser = Parser()
    parser.print_help(argv)
    assert parser.print_help(argv)

# Generated at 2022-06-22 00:12:22.500084
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import StringIO
    import sys
    saved_stderr = sys.stderr
    # redirect stderr to a string
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        parser = Parser()
        parser.print_help()
        out.seek(0)
        return out.read()
    finally:
        sys.stderr = saved_stderr

# Generated at 2022-06-22 00:12:32.479093
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser, "parser was not created."
    assert parser._parser.prog == "thefuck", "Program name was not set."
    
    assert parser.parse(['thefuck','--version']).version is True, "version argument not detected."
    assert parser.parse(['thefuck','--alias']).alias == get_alias(), "alias argument not detected."
    assert parser.parse(['thefuck','--shell-logger']).shell_logger is not None, "shell-logger argument not detected."
    assert parser.parse(['thefuck','--enable-experimental-instant-mode']).enable_experimental_instant_mode is True, "experimental instant mode argument not detected."
    assert parser.parse(['thefuck','--help']).help is True, "help argument not detected."


# Generated at 2022-06-22 00:12:35.302418
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    got = sys.stderr.getvalue()
    assert got.startswith("usage: thefuck")


# Generated at 2022-06-22 00:12:36.329030
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-22 00:12:37.284518
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    parser.print_usage()

# Generated at 2022-06-22 00:12:39.778268
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:14:15.862821
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    # test_add_arguments
    assert '-v' in p._parser._option_string_actions
    assert '--version' in p._parser._option_string_actions
    assert '-a' in p._parser._option_string_actions
    assert '--alias' in p._parser._option_string_actions
    assert '-l' in p._parser._option_string_actions
    assert '--shell-logger' in p._parser._option_string_actions
    assert '--enable-experimental-instant-mode' in p._parser._option_string_actions
    assert '-h' in p._parser._option_string_actions
    assert '--help' in p._parser._option_string_actions
    assert '-d' in p._parser._option_string_actions

# Generated at 2022-06-22 00:14:18.398936
# Unit test for method parse of class Parser
def test_Parser_parse():
    arguments = Parser().parse(sys.argv)
    assert arguments.command[0] == 'echo'
    assert arguments.command[1] == 'systemctl status'

# Generated at 2022-06-22 00:14:26.001585
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    orig = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        parser.print_usage()
        assert(out.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' +
                                 '              [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n' +
                                 '              [-y] [-r] [-d] [--force-command FORCE_COMMAND]\n' +
                                 '              [--] [command [command ...]]\n')
    finally:
        sys.stderr = orig


# Generated at 2022-06-22 00:14:34.703549
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    import sys
    from .const import PYTHON

    output = StringIO()
    stderr = sys.stderr
    sys.stderr = output
    try:
        p = Parser()
        p.print_usage()
    finally:
        sys.stderr = stderr
    assert output.getvalue().strip() == "usage: "+PYTHON+" -h | --help | -v | --version | --debug | -y | --yes | --yeah | --hard | -r | --repeat | -d | -l | [--force-command COMMAND] [--] [command] [ARGS]"
    output.close()


# Generated at 2022-06-22 00:14:35.552187
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()

# Generated at 2022-06-22 00:14:39.908790
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from helpers import capture_stderr
    from thefuck.main import main
    with capture_stderr(main, ['--help']) as output:
        assert 'usage: thefuck' in output
        assert 'command that should be fixed' in output


# Generated at 2022-06-22 00:14:40.585717
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-22 00:14:41.312565
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:14:50.645413
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    my_parser = Parser()
    # txt = my_parser.print_usage()
    # txt = my_parser.print_usage().splitlines()
    # txt = my_parser.print_usage().splitlines()
    txt = sys.stderr.getvalue().splitlines()
    assert txt[0:4] == [
        'usage: thefuck [-h] [-v] [-a [custom-alias-name]]',
        '                [-l SHELL_LOGGER] [--enable-experimental-instant-mode]',
        '                [-y | -r] [-d] [--force-command FORCE_COMMAND]',
        '                [command [command ...]]']

# Generated at 2022-06-22 00:14:56.408513
# Unit test for constructor of class Parser
def test_Parser():
    f = Parser()
    f._add_arguments()
    args = f.parse(['thefuck', 'echo', 'hello'])
    assert args.command == ['echo', 'hello']
    assert args.force_command is None

    args2 = f.parse(['thefuck', '--force-command', 'echo', 'hello'])
    assert args2.command == ['hello']
    assert args2.force_command == 'echo'