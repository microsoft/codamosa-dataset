

# Generated at 2022-06-22 00:05:53.533686
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from . import __version__
    from .utils import git_tag_date
    from .parser import Parser
    from .const import ALIAS_INFO, LEGACY_ALIASES_INFO, ALIAS, NO_COLOUR_ALIAS

    date = git_tag_date()
    parser = Parser()
    #result = parser.print_help()
    result = parser.print_usage()
    assert (result.__class__.__name__ == 'NoneType')

# Generated at 2022-06-22 00:05:54.698043
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-22 00:06:04.493256
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:06:09.843525
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    stream = StringIO()
    sys.stderr = stream
    parser.print_help()
    sys.stderr = sys.__stderr__
    assert stream.getvalue() != ''
    stream.close()



# Generated at 2022-06-22 00:06:12.076492
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # GIVEN
    parser = Parser()
    # WHEN
    parser.print_help()
    # THEN
    assert 1 == 1

# Generated at 2022-06-22 00:06:14.272965
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p is not None


# Generated at 2022-06-22 00:06:19.830945
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.stderr = open("/tmp/stderr.log", "a")
    p = Parser()
    argv = ["thefuck", "-d", "command", "argument"]
    p.parse(argv)
    p.print_usage()
    sys.stderr.close()


# Generated at 2022-06-22 00:06:20.432728
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-22 00:06:22.251951
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['-v'])
    assert args.version == True


# Generated at 2022-06-22 00:06:24.403434
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    print('\n=== Test for method print_help of class Parser ===')
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-22 00:06:41.331893
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(["ls"]) == p._parser.parse_args(["ls"])
    assert p.parse(["ls", ARGUMENT_PLACEHOLDER, "1", "2", "3"]) \
           == p._parser.parse_args(["1", "2", "3", "--", "ls"])
    assert p.parse(["ls", "1", "2", "3", ARGUMENT_PLACEHOLDER, "4", "5", "6"]) \
           == p._parser.parse_args(["1", "2", "3", "4", "5", "6", "--", "ls"])
    assert p.parse(["ls", "1", "2", "3", ARGUMENT_PLACEHOLDER]) \
          

# Generated at 2022-06-22 00:06:43.927246
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None
    assert parser.print_help() is None


# Generated at 2022-06-22 00:06:47.671082
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-22 00:06:53.582604
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import NAME, VERSION
    from .vendor.capture import capture

    parser = Parser()
    with capture(parser.print_usage, err=True) as output:
        assert output == 'usage: {name} [--version] [-a [custom-alias-name]] ' \
                         '[--shell-logger=SHELL-LOGGER] [--yes] [--repeat] ' \
                         ' [-d] [--force-command=FORCE-COMMAND] ' \
                         '[command [command ...]]\n'.format(name=NAME)


# Generated at 2022-06-22 00:07:05.816696
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert parser.parse(['thefuck', '-t', '-t', 'git', 'rebase']).command == ['git', 'rebase']
    assert parser.parse(['thefuck', '-t', '-t', 'git', 'rebase', '-i', 'HEAD~3']).command == ['git', 'rebase', '-i', 'HEAD~3']

    assert parser.parse(['thefuck', '--yes']).yes
    assert parser.parse(['thefuck', '--yeah']).yes
    assert parser.parse(['thefuck', '--hard']).yes

    assert parser.parse(['thefuck', '-l', 'shell_logger_file']).shell_logger == 'shell_logger_file'


# Generated at 2022-06-22 00:07:07.036261
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-22 00:07:08.346611
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:07:10.309162
# Unit test for constructor of class Parser
def test_Parser():
	assert Parser()

# Generated at 2022-06-22 00:07:11.405617
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()



# Generated at 2022-06-22 00:07:19.844480
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # standard input
    result = parser.parse(['fuck'])
    assert result.command == []
    assert result.debug is False
    assert result.enable_experimental_instant_mode is False
    assert result.help is False
    assert result.hard is False
    assert result.alias is None
    assert result.repeat is False
    assert result.shell_logger is None
    assert result.version is False
    # shell-logger
    result = parser.parse(['fuck', '-l', 'log_file'])
    assert result.shell_logger == 'log_file'
    # incorrect argument
    result = parser.parse(['fuck', '-i'])
    assert result.command == ['fuck', '-i']
    assert result.debug is False
    assert result.enable_

# Generated at 2022-06-22 00:07:34.303310
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser('thefuck')

    assert 'thefuck' == parser.prog

    assert parser._actions == []
    parser._add_arguments()
    assert len(parser._actions) == 10

# Generated at 2022-06-22 00:07:34.785892
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-22 00:07:36.316883
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser.__init__(Parser())


# Generated at 2022-06-22 00:07:42.343442
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # create a file to store stdout output
    text_trap = io.StringIO()
    # redirect stdout output to text_trap
    sys.stdout = text_trap
    parser = Parser()
    parser.print_usage()
    # restore stdout output
    sys.stdout = sys.__stdout__
    assert "usage: thefuck" in text_trap.getvalue()


# Generated at 2022-06-22 00:07:53.344138
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # Test if the arguments are being defined.
    assert parser._add_arguments.__doc__ == "Adds arguments to parser."
    assert parser._add_conflicting_arguments.__doc__ == "It's too dangerous to use `-y` and `-r` together."
    assert parser._prepare_arguments.__doc__ == "Prepares arguments by:\n\n- removing placeholder and moving arguments after it to beginning,\nwe need this to distinguish arguments from `command` with ours;\n\n- adding `--` before `command`, so our parse would ignore arguments\nof `command`."
    
    # Check if arguments are being passed to the parser without any issue

# Generated at 2022-06-22 00:08:02.744657
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    assert out.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' + \
                             '[-l shell-logger] [--enable-experimental-instant-mode] ' + \
                             '[[-y | --yeah | --hard] | [-r]] [-d] [--force-command FORCE_COMMAND] [--] ' + \
                             '[command [command ...]]\n'



# Generated at 2022-06-22 00:08:04.908790
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:08:12.911329
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['./thefuck']) ==\
        Namespace(alias=get_alias(), command=[])

    assert Parser().parse(['./thefuck', '-v']) ==\
        Namespace(alias=None, command=[], version=True)

    assert Parser().parse(['./thefuck', '-h']) ==\
        Namespace(alias=None, command=[], help=True)

    assert Parser().parse(['./thefuck', 'git', 'cmm']) ==\
        Namespace(alias=None, command=['git', 'cmm'])

    assert Parser().parse(['./thefuck', '-y', 'git', 'cmm']) ==\
        Namespace(alias=None, command=['git', 'cmm'], repeat=False, yes=True)

   

# Generated at 2022-06-22 00:08:13.821005
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:08:18.036846
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'echo', ARGUMENT_PLACEHOLDER, 'rm', '-rf', '/']
    parsed_args = parser.parse(argv)
    assert parsed_args.command == ['rm', '-rf', '/']


# Generated at 2022-06-22 00:08:55.037167
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['-h']) == parser._parser.parse_args(['-h'])
    assert parser.parse(['--help']) == parser._parser.parse_args(['--help'])
    assert parser.parse(['--yeah']) == parser._parser.parse_args(['--yeah'])
    assert parser.parse(['--echo', '123']) == parser._parser.parse_args(['--echo', '123'])
    assert parser.parse(['cat', '123']) == parser._parser.parse_args(['--', 'cat', '123'])
    assert parser.parse(['cat', '123']) == parser._parser.parse_args(['--', 'cat', '123'])



# Generated at 2022-06-22 00:08:56.893477
# Unit test for constructor of class Parser
def test_Parser():
    import argparse
    global parser
    parser = Parser()
    assert isinstance(parser._parser, argparse.ArgumentParser)


# Generated at 2022-06-22 00:08:58.602706
# Unit test for constructor of class Parser
def test_Parser():
    arg = Parser()
    assert arg is not None


# Generated at 2022-06-22 00:09:04.781423
# Unit test for constructor of class Parser
def test_Parser():
    def side_effect(*args, **kwargs):
        parser = ArgumentParser()
        parser.add_argument('--hello')
        return parser
    with mock.patch.object(ArgumentParser, '__init__',
                           side_effect=side_effect):
        assert Parser()._parser.parse_args(['--hello', 'world']).hello == 'world'


# Generated at 2022-06-22 00:09:09.358026
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    s = sys.stderr
    old_std = sys.stderr
    sys.stderr = StringIO()
    p.print_help()
    sys.stderr = old_std

# Generated at 2022-06-22 00:09:14.306759
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import StringIO

    fobj = StringIO.StringIO()
    sys.stderr = fobj
    Parser().print_usage()
    assert(fobj.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [-y] [-r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n')
    sys.stderr = sys.__stderr__


# Generated at 2022-06-22 00:09:15.806084
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser


# Generated at 2022-06-22 00:09:16.607773
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-22 00:09:27.261648
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    if parser.parse([]):
        assert False
    if parser.parse(['--help']):
        assert False

    assert parser.parse(['--version'])
    assert parser.parse(['--debug'])
    assert parser.parse(['--shell-logger', 'HELLO'])
    assert parser.parse(['--enable-experimental-instant-mode'])
    assert parser.parse(['--force-command', 'git'])
    assert parser.parse(['--force-command', 'ls', '-l', '-a'])
    assert parser.parse(['--force-command', 'ls', ARGUMENT_PLACEHOLDER, '-l', '-a'])
    assert parser.parse(['ls'])

# Generated at 2022-06-22 00:09:39.517471
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    #test 1
    assert parser.parse(['', '-a']) == Namespace(alias=None, command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    assert parser.parse(['', '-v']) == Namespace(alias=None, command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=True, yes=False)

# Generated at 2022-06-22 00:10:43.617566
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import _
    from .utils import get_alias

    parser = Parser()
    from io import StringIO
    output = StringIO()
    sys.stderr = output
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert 'Usage: {} [options]'.format(_('thefuck')) in output.getvalue()


# Generated at 2022-06-22 00:10:46.886145
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck','--debug','vim','index.html']) == \
    parser._parser.parse_args(['-d','--','vim','index.html'])


# Generated at 2022-06-22 00:10:56.153102
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import __builtin__
    for name in dir(__builtin__):
        if getattr(__builtin__, name) is getattr(sys.stderr, name):
            break
    else:
        name = 'stderr'
    class Error:
        def __init__(self):
            self.content = ''
        def write(self, content):
            self.content += content
        def __getattr__(self, name):
            return getattr(getattr(sys, name), name)
    real_stderr = getattr(sys, name)
    setattr(sys, name, Error())

# Generated at 2022-06-22 00:10:56.977053
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print(Parser().print_usage())

# Generated at 2022-06-22 00:11:00.837480
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '--debug']).debug


# Generated at 2022-06-22 00:11:02.104807
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:11:08.011159
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # expected output for the parser.print_help() function

# Generated at 2022-06-22 00:11:10.576395
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-22 00:11:11.751390
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    p = Parser()
    p.print_usage()

# Generated at 2022-06-22 00:11:15.971802
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    out = StringIO()
    err = StringIO()
    p = Parser()
    p.print_usage()
    assert err.getvalue() == "usage: thefuck [options] [command [command ...]]\n"
    # Unit test for method print_help of class Parser


# Generated at 2022-06-22 00:12:27.680443
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import cStringIO
    import sys
    old_stdout = sys.stdout

    sys.stdout = buff = cStringIO.StringIO()
    parser.print_usage()
    sys.stdout = old_stdout
    assert buff.getvalue() == \
            'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' \
            '[-l shell_logger]\n             [--enable-experimental-instant-mode] [-d]\n             ' \
            '[-y] [-r] [--] [command [command ...]]\n'


# Generated at 2022-06-22 00:12:37.102612
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', '--help', 'echo', '-la', '--version', ARGUMENT_PLACEHOLDER, '-y', '-d', '--shell-logger=/dev/null']
    args = Parser().parse(argv)

    assert args.version
    assert args.alias is None
    assert args.hello == '-la'
    assert args.shell_logger == '/dev/null'
    assert args.enable_experimental_instant_mode is False
    assert args.help
    assert args.debug
    assert args.force_command is None
    assert args.yes
    assert args.repeat is False
    assert args.command == ['echo', '-la', '--version', '-y', '-d', '--shell-logger=/dev/null']


# Generated at 2022-06-22 00:12:39.526423
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-22 00:12:41.980498
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    args = p.parse(['thefuck', 'git', 'stash'])
    assert args.command == ['git', 'stash']


# Generated at 2022-06-22 00:12:45.049750
# Unit test for constructor of class Parser
def test_Parser():
	parser = Parser()
	assert parser._parser.prog == 'thefuck', "_parser.prog should be thefuck"
	assert parser._parser.add_help is False, "_parser.add_help should be False"


# Generated at 2022-06-22 00:12:48.252689
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Runs the program with the -h option. If the program exits successfully
    then the test has passed.

    """
    import subprocess
    #command to run the program
    command = "python -m thefuck.main -h"
    output = subprocess.call(command, shell=True)
    #0 is the successful return code.
    assert output == 0

# Generated at 2022-06-22 00:12:57.348279
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', '-y', '-s', 'cd /project/test']
    ret = parser.parse(argv)
    assert ret.command == []
    assert ret.yes == True
    assert ret.shell_logger == 'cd /project/test'

    argv = ['thefuck', 'cd', '/project/test']
    ret = parser.parse(argv)
    assert ret.command == ['cd', '/project/test']
    assert ret.yes == False

    argv = ['thefuck', 'git', 'push', 'origin', 'master']
    ret = parser.parse(argv)
    assert ret.command == ['git', 'push', 'origin', 'master']
    assert ret.yes == False


# Generated at 2022-06-22 00:12:59.469023
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Unit tests for method _add_arguments of class Parser

# Generated at 2022-06-22 00:13:05.334913
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    stderr = sys.stderr
    try:
        from StringIO import StringIO
        sys.stderr = StringIO()
        parser.print_help()
        str = sys.stderr.getvalue()
        assert 'usage: thefuck' in str
        assert '-h' in str
        assert '--help' in str
        assert '-a' in str
        assert '--alias' in str
    finally:
        sys.stderr = stderr

# Generated at 2022-06-22 00:13:15.534617
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    result = parser.parse(['thefuck', 'ls'] + [ARGUMENT_PLACEHOLDER])
    assert not result.command
    assert not result.debug

    result = parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER])
    assert result.command == []
    assert not result.debug
    assert result.alias == get_alias()

    result = parser.parse(['thefuck', 'ls', '-a'])
    assert result.command == ['ls', '-a']

    result = parser.parse(['thefuck', 'ls', '--', '-a'])
    assert result.command == ['ls', '--', '-a']
