

# Generated at 2022-06-22 00:05:58.521816
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = [__file__, "arg1", ARGUMENT_PLACEHOLDER, "arg2"]
    assert parser.parse(argv) == \
        parser._parser.parse_args(["arg2", "--", "arg1"])

    argv = [__file__, "arg1", ARGUMENT_PLACEHOLDER + "s", "arg2"]
    assert parser.parse(argv) == \
        parser._parser.parse_args(["arg2", "--", "arg1"])

    argv = [__file__, "arg1", ARGUMENT_PLACEHOLDER, "arg2", ARGUMENT_PLACEHOLDER, "arg3"]
    assert parser.parse(argv) == \
        parser._parser.parse_

# Generated at 2022-06-22 00:06:03.231097
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
	from io import StringIO
	save_stdout = sys.stderr
	try:
		out = StringIO()
		sys.stderr = out
		x = Parser()
		x.print_usage()
		output = out.getvalue().split()
	finally:
		sys.stderr = save_stdout
	assert out

# Generated at 2022-06-22 00:06:03.928849
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().print_help() is None


# Generated at 2022-06-22 00:06:06.373471
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

    Parser().print_help()



# Generated at 2022-06-22 00:06:08.633928
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:06:10.218378
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-22 00:06:15.114669
# Unit test for constructor of class Parser

# Generated at 2022-06-22 00:06:16.650523
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # prepare
    parser = Parser()

    # execute
    parser.print_usage()
    # verify
    assert True

# Generated at 2022-06-22 00:06:19.982509
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == parser._parser.print_usage(sys.stderr)


# Generated at 2022-06-22 00:06:24.495927
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['', '--alias', 'fuck', 'ls', '-l'])
    assert args == parser.parse(['', '--alias', 'fuck', '--', 'ls', '-l'])
    assert 'ls' in args.command
    assert '-l' in args.command



# Generated at 2022-06-22 00:06:38.005446
# Unit test for method parse of class Parser
def test_Parser_parse():
    arguments = ["--debug", "--force-command", "hi", "echo", "hi"]
    parsed_arguments = Parser().parse(arguments)
    assert parsed_arguments.debug == True
    assert parsed_arguments.force_command == "hi"
    assert parsed_arguments.command == ["echo", "hi"]

# Generated at 2022-06-22 00:06:48.899307
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

# Generated at 2022-06-22 00:06:51.360286
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser._parser = ArgumentParser(prog="header", add_help=False)
    parser.print_help()
    sys.stderr.write("This is a test")
    parser.print_usage()


# Generated at 2022-06-22 00:07:03.125864
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck','test','test','test','test','test','test']) == parser._parser.parse_args(['--','test','test','test','test','test','test'])
    assert parser.parse(['thefuck','test','test','test','test','test','test','--force-command','test']) == parser._parser.parse_args(['--force-command','test','--','test','test','test','test','test','test'])
    assert parser.parse(['thefuck','test','test','test','test','test','test','--debug']) == parser._parser.parse_args(['--debug','--','test','test','test','test','test','test'])

# Generated at 2022-06-22 00:07:06.220230
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    result = parser.print_usage()
    if len(result)>=1:
        assert True
    else:
        assert False


# Generated at 2022-06-22 00:07:07.873341
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:07:11.403892
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True


# Generated at 2022-06-22 00:07:12.850424
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    # TODO: Add tests
    assert True

# Generated at 2022-06-22 00:07:20.374763
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser._prepare_arguments = lambda argv: ['--', 'command']
    assert parser.parse(['__thefuck__', '--', 'command']) == \
        Namespace(alias=None, command=['command'], debug=False,
                  help=False,
                  enable_experimental_instant_mode=False,
                  shell_logger=None,
                  yes=False)
    assert parser.parse(['__thefuck__', '--', 'command', ARGUMENT_PLACEHOLDER]) == \
        Namespace(alias=None, command=['command'], debug=False,
                  help=False,
                  enable_experimental_instant_mode=False,
                  shell_logger=None,
                  yes=False)

# Generated at 2022-06-22 00:07:21.417460
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:07:43.037665
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:07:45.485389
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-22 00:07:46.545109
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-22 00:07:49.244172
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from thefuck import shells

    stderr = StringIO()
    shells.get_alias = lambda: 'fuck'
    Parser().print_usage()

# Generated at 2022-06-22 00:07:50.199811
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.add_help is False

# Generated at 2022-06-22 00:07:51.629483
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None


# Generated at 2022-06-22 00:07:59.195363
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '--help']) == parser.parse(['thefuck', '--', '--help'])
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--', '-v'])
    assert parser.parse(['thefuck', '-a']) == parser.parse(['thefuck', '--', '-a'])
    assert parser.parse(['thefuck', '-a', 'fuck']) == parser.parse(['thefuck', 'fuck'])
    assert parser.parse(['thefuck', '-l', 'log']) == parser.parse(['thefuck', '--', '-l', 'log'])

# Generated at 2022-06-22 00:08:00.779275
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-22 00:08:02.177855
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None


# Generated at 2022-06-22 00:08:07.532763
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    class Parser():
        def __init__(self):
            self.parser = ArgumentParser(prog='thefuck', add_help=False)
        def print_help(self):
            self.parser.print_help(sys.stderr)
    parser = Parser()
    parser.print_help()
    assert True


# Generated at 2022-06-22 00:08:51.066883
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)


# Generated at 2022-06-22 00:08:52.411470
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:08:53.862992
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-22 00:08:55.708821
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        return True

# Generated at 2022-06-22 00:08:58.016643
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Initialize class
    parser = Parser()
    # Execute print_usage of class
    parser.print_usage()


# Generated at 2022-06-22 00:09:00.837193
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    my_args = ["-h"]
    parser = Parser()
    parser.parse(my_args)
    assert parser.print_usage() == ArgumentParser(add_help=False, prog='thefuck').print_usage()


# Generated at 2022-06-22 00:09:04.643317
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Setup
    obj = Parser()

    # Exercise
    obj.print_usage()

    # Verify and Cleanup


# Generated at 2022-06-22 00:09:05.559735
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()


# Generated at 2022-06-22 00:09:13.292258
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import StringIO, sys
    out = StringIO.StringIO()
    sys.stderr = out
    p = Parser()
    p.print_usage()
    sys.stderr = sys.__stderr__
    assert out.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\
 [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\
 [--force-command FORCE_COMMAND] [-d] [-y] [-r] [--] [command [command ...]]\n'


# Generated at 2022-06-22 00:09:18.062074
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .test_utils import check_output_with_argv_name

    output = check_output_with_argv_name('-h')
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' in output


# Generated at 2022-06-22 00:10:50.955720
# Unit test for constructor of class Parser
def test_Parser():
    # Check for command line argument of the script
    # If it is None or len(argv) is less than 2, print help message
    # Else, print the argument
    argv = sys.argv
    if argv is None or len(argv) is not 2:
        print_help()
        sys.exit(1)
    print("command line argument: " + argv[1])

# Generated at 2022-06-22 00:10:55.941766
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    args = parser.parse(['thefuck', '--', 'ls'])
    assert args.command == ['ls']

    args = parser.parse(['thefuck', 'ls'])
    assert args.command == ['ls']

    args = parser.parse(['thefuck', '--force-command', 'ls'])
    assert args.force_command == 'ls'



# Generated at 2022-06-22 00:11:05.833533
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias
    import io

    sys.stderr = io.StringIO()
    parser = Parser()
    arguments = ['-a', get_alias(), '-d', '--force-command', 'echo', 'failiure command', ARGUMENT_PLACEHOLDER, 'argument_1', 'argument_2']
    parser.parse(arguments)

# Generated at 2022-06-22 00:11:09.478386
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(["-v"])
    assert args.version == True


# Generated at 2022-06-22 00:11:10.623840
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-22 00:11:13.449333
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import ALIAS_USAGE

    parser = Parser()
    parser.print_usage()

    assert sys.stderr.getvalue().startswith(ALIAS_USAGE)


# Generated at 2022-06-22 00:11:14.643284
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.parse(['thefuck','npm'])
    p.print_usage()
    p.print_help()

# Generated at 2022-06-22 00:11:15.357187
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:11:26.676578
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Case 1: when argv does not contain '--' and does not start with '-'
    # then append '--' to argv and parse it
    parser = Parser()
    argv = ['thefuck', 'command', '--', 'command_arg1']
    args = parser.parse(argv)
    assert args.command == ['command_arg1']

    # Case 2: when argv starts with '-' then parse it without changes
    argv = ['thefuck', '--version']
    args = parser.parse(argv)
    assert args.version == True

    # Case 3: when argv contains '--' then parse it without changes
    argv = ['thefuck', '--', 'command_arg1']
    args = parser.parse(argv)
    assert args.command == ['command_arg1']

   

# Generated at 2022-06-22 00:11:33.519776
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    f = open(os.devnull, 'w')
    with patch('sys.stderr', f):
        parser = Parser()
        parser.print_usage()
        assert f.getvalue() == 'usage: thefuck [-h] [-v] [-d] [-a [CUSTOM-ALIAS-NAME]]\n                  [-l SHELL-LOGGER]\n                  [--enable-experimental-instant-mode] [-y | -r]\n                  [--force-command FORCE-COMMAND] [--]\n                  command [command ...]\n'


# Generated at 2022-06-22 00:15:32.059431
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:15:33.802057
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:15:38.353826
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Use example argument list
    argv = ['/sbin/mount.ecryptfs_private', '-f', '~/.Private']

    # Initialize a Parser instance
    parser = Parser()

    # Print hepl message
    fd = parser.print_help()

# Generated at 2022-06-22 00:15:43.227773
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    ps = Parser()
    try:
        ps.print_usage()
    except:
        assert(False)
        return
    assert(True)
