

# Generated at 2022-06-22 00:05:44.162524
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:05:44.990618
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-22 00:05:50.637758
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([""]).command == []
    assert parser.parse([" "]).command == []
    assert parser.parse(["  "]).command == []
    assert parser.parse([","]).command == []
    assert parser.parse(["--version"]).version == True
    assert parser.parse(["--alias"]).alias == "fuck"
    assert parser.parse(["--shell-logger"]).shell_logger == "shell.log"
    assert parser.parse(["--enable-experimental-instant-mode"]).enable_experimental_instant_mode == True
    assert parser.parse(["--help"]).help == True
    assert parser.parse(["--yes"]).yes == True
    assert parser.parse(["--repeat"]).repeat == True

# Generated at 2022-06-22 00:06:00.978720
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from _ast import Add
    from _ast import arguments
    import ast
    import unittest
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys

# Generated at 2022-06-22 00:06:08.837440
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    old_stderr = sys.stderr
    try:
        from StringIO import StringIO  # py2
    except ImportError:
        from io import StringIO  # py3
    sys.stderr = out = StringIO()
    try:
        parser.print_usage()
        assert out.getvalue().startswith('usage: thefuck')
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-22 00:06:11.129204
# Unit test for method parse of class Parser
def test_Parser_parse():
    sys.argv = ['thefuck', '-v']
    assert Parser().parse(sys.argv).version == True


# Generated at 2022-06-22 00:06:13.723040
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = StringIO()
    sys.stderr = output
    parser.print_usage()

    assert 'usage: thefuck' in output.getvalue()


# Generated at 2022-06-22 00:06:19.316935
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    import sys
    from unittest import mock

    parser = Parser()
    with mock.patch('sys.stderr', new_callable=StringIO) as mock_io:
        parser.print_usage()
    assert 'usage: thefuck' in mock_io.getvalue()

# Generated at 2022-06-22 00:06:23.878012
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class Params:
        def write(self, str):
            return True

    sys.stderr = Params()
    Parser.print_help('--help')
    assert sys.stderr.write == True
    Parser.print_help('-h')
    assert sys.stderr.write == True


# Generated at 2022-06-22 00:06:29.589560
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    def capture_stderr(func, *args):
        stdout, sys.stderr = sys.stderr, StringIO()
        func(*args)
        sys.stderr.seek(0)
        return sys.stderr.read()
    h = capture_stderr(Parser().print_help)
    assert '-l' in h


# Generated at 2022-06-22 00:06:33.725416
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    sys.stdout = open('/dev/null', 'w')
    Parser().print_usage()
    sys.stdout = sys.__stdout__
    assert True


# Generated at 2022-06-22 00:06:41.658612
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import StringIO
    import sys

    out = StringIO.StringIO()
    sys.stderr = out

    parser = Parser()
    parser.print_usage()
    assert out.getvalue().strip() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [-y | -r] [--force-command FORCE_COMMAND] [command [command ...]]'

    out.close()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-22 00:06:43.101231
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:06:47.711102
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'echo', 'test', ARGUMENT_PLACEHOLDER, '--debug'])
    assert args.debug == True
    assert args.command == ['echo', 'test']

# Generated at 2022-06-22 00:06:54.466025
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from . import parser
    import sys
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def redirect_io():
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        try:
            out = StringIO()
            sys.stdout = sys.stderr = out
            yield out
        finally:
            sys.stderr = old_stderr
            sys.stdout =  old_stdout

    with redirect_io() as out:
        parser().print_help()
    help_text = out.getvalue().strip()
    assert help_text.startswith('usage:') and 'thefuck' in help_text

# Generated at 2022-06-22 00:06:57.753810
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    print(parser.parse(["fuck", "--"]))
    print(parser.parse(["fuck", "pwd", ">", "ls", ARGUMENT_PLACEHOLDER, "-l"]))

# Generated at 2022-06-22 00:07:08.280602
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog is 'thefuck'
    assert parser._parser.add_help is False
    parser_action = parser._parser._actions[0]
    assert parser_action.option_strings is ['-v', '--version']
    assert parser_action.dest is 'version'
    assert parser_action.const is True
    assert parser_action.default is False
    assert parser_action.required is False
    assert parser_action.help is "show program's version number and exit"
    parser_action = parser._parser._actions[1]
    assert parser_action.option_strings is ['-a', '--alias']
    assert parser_action.dest is 'alias'
    assert parser_action.nargs is '?'
    assert parser_action.const is get_alias()
    assert parser

# Generated at 2022-06-22 00:07:11.128219
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-22 00:07:19.740498
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest import TestCase
    from io import StringIO
    from textwrap import dedent

    # Capture stderr
    def capture_stderr(function, *args, **kwargs):
        stderr = sys.stderr
        sys.stderr = StringIO()
        try:
            function(*args, **kwargs)
        finally:
            result = sys.stderr.getvalue()
            sys.stderr = stderr
        return result

    class ParserTest(TestCase):
        def test_print_usage(self):
            parser = Parser()
            stdout = capture_stderr(parser.print_usage)

# Generated at 2022-06-22 00:07:23.749545
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
        output = StringIO()
        sys.stderr = output
        Parser().print_usage()
        sys.stderr = sys.__stderr__
        assert output.getvalue() == 'usage: thefuck [-h]\n'


# Generated at 2022-06-22 00:07:32.344157
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'wrong_command', '/etc'])
    assert ['wrong_command', '/etc'] == arguments.command


# Generated at 2022-06-22 00:07:33.893177
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        pass

# Generated at 2022-06-22 00:07:35.852004
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:07:41.257100
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    fake_arg = 'fake_arg'
    assert fake_arg not in parser._parser._actions[11].option_strings
    assert fake_arg not in parser._parser._actions[11].help
    assert fake_arg in parser._parser._actions[13].option_strings
    assert fake_arg in parser._parser._actions[13].help


# Generated at 2022-06-22 00:07:48.023493
# Unit test for method parse of class Parser
def test_Parser_parse():
	from .utils import get_alias
	from .const import ARGUMENT_PLACEHOLDER
	
	
	argv = ['/usr/local/bin/fuck', ARGUMENT_PLACEHOLDER, 'echo', 'Fuck']

	p = Parser()

	p.parse(argv)
	
	assert sys.argv[1:] == ['-l', '~/.shell_logger.log']

# Generated at 2022-06-22 00:07:49.492725
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None



# Generated at 2022-06-22 00:07:55.477141
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = sys.stdout
    parser.print_usage()
    assert(output.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n              [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND]\n              [command [command ...]]\n")


# Generated at 2022-06-22 00:07:56.842177
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert isinstance(parser, Parser)

# Generated at 2022-06-22 00:07:59.863633
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-22 00:08:01.799025
# Unit test for constructor of class Parser
def test_Parser():
    # Test if it can handle arguments with our special placeholder.
    assert Parser()


# Generated at 2022-06-22 00:08:11.838148
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:08:22.113208
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', '--alias']) == \
        parser.parse(['fuck', '-a'])
    assert parser.parse(['fuck', '--help']) == \
        parser.parse(['fuck', '-h'])
    assert parser.parse(['fuck', '--debug']) == \
        parser.parse(['fuck', '-d'])
    assert parser.parse(['fuck', '--yes']) == \
        parser.parse(['fuck', '-y'])
    assert parser.parse(['fuck', '--repeat']) == \
        parser.parse(['fuck', '-r'])
    assert parser.parse(['fuck', '--version']) == \
        parser.parse(['fuck', '-v'])

# Generated at 2022-06-22 00:08:25.897427
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(["thefuck","-y","-l","-"])
    assert(args.yes)
    assert(args.shell_logger == "-")
    assert(args.debug == False)
    assert(args.enable_experimental_instant_mode == False)
    assert(args.alias == None)
    assert(args.help == False)
    assert(args.repeat == False)
    assert(args.force_command == None)
    assert(args.command == [])


# Generated at 2022-06-22 00:08:30.668362
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_alias

    argv = ['-h', '--alias']
    parser = Parser()
    args = parser.parse(argv)
    assert args.help == True
    assert args.version == False
    assert args.alias == get_alias()
    assert args.repeat == False
    assert args.command == []
    assert args.shell_logger == None
    assert args.enable_experimental_instant_mode == False
    assert args.force_command == None

# Generated at 2022-06-22 00:08:34.277745
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    with patch('sys.stderr') as stderr:
        parser.print_help()
        stderr.write.assert_called_once_with(parser._parser.format_help())



# Generated at 2022-06-22 00:08:44.696997
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # test case: no special argument
    arguments = parser.parse(['thefuck'])
    assert arguments.alias == get_alias()
    assert arguments.shell_logger is None
    assert arguments.enable_experimental_instant_mode is False
    assert arguments.help is False
    assert arguments.yes is False
    assert arguments.repeat is False
    assert arguments.debug is False
    assert arguments.force_command is None
    assert arguments.command == []

    # test case: with --alias
    arguments = parser.parse(['thefuck', '--alias'])
    assert arguments.alias == get_alias()
    assert arguments.shell_logger is None
    assert arguments.enable_experimental_instant_mode is False
    assert arguments.help is False
    assert arguments.yes is False

# Generated at 2022-06-22 00:08:55.592210
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from .utils import get_version
    # Capture the output
    orig_stderr = sys.stderr
    sys.stderr = StringIO()

    # Run the print_help method
    parser = Parser()
    parser.print_help()

    # Close the capture and reset sys.stderr
    output = sys.stderr.getvalue()
    sys.stderr.close()
    sys.stderr = orig_stderr

    # Check the output
    version = get_version()
    assert "Usage: thefuck [OPTION]... [COMMAND]" in output
    assert "show program's version number and exit" in output
    assert "[custom-alias-name] prints alias for current shell" in output
    assert "log shell output to the file" in output
   

# Generated at 2022-06-22 00:08:58.255903
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    print(p.parse(sys.argv))


if __name__ == '__main__':
    test_Parser_parse()

# Generated at 2022-06-22 00:08:59.046853
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:08:59.562586
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:09:25.241326
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', 'fuck'])
    parser.parse(['thefuck', 'fuck', 'placeholder'])
    parser.parse(['thefuck', 'fuck', 'placeholder', '--'])
    parser.parse(['thefuck', 'fuck', 'placeholder', 'arg'])

    # Try all possible options
    parser.parse(['thefuck', '--version'])
    parser.parse(['thefuck', '--alias'])
    parser.parse(['thefuck', '--alias', 'fuck'])
    parser.parse(['thefuck', '--shell-logger', 'logger.log'])
    parser.parse(['thefuck', '--enable-experimental-instant-mode'])
    parser.parse(['thefuck', '--help'])
   

# Generated at 2022-06-22 00:09:30.001606
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    out = capsys.readouterr()
    assert out == ('usage: thefuck [-h] [-v] [-a [custom-alias-name]] '
                   '[-l SHELL-LOGGER] [--enable-experimental-instant-mode] '
                   '[-d] [--force-command FORCE-COMMAND] [-y | -r] '
                   '[command [command ...]]\n', ''), \
                   'Parser.print_usage() doesn\'t print expected result.'


# Generated at 2022-06-22 00:09:38.353264
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    parser.print_usage()
    assert sys.stdout.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n             [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND]\n             [command [command ...]]\n'
    sys.stdout = old_stdout


# Generated at 2022-06-22 00:09:40.037843
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:09:42.346413
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except:
        return False
    else:
        return True


# Generated at 2022-06-22 00:09:46.365029
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # On real case we can check stderr but unittest doesn't give us a way to do it
    assert parser.print_usage() == None


# Generated at 2022-06-22 00:09:48.361455
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    out = StringIO()
    Parser().print_help()
    assert out.getvalue() == ""

# Generated at 2022-06-22 00:09:50.153130
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-22 00:09:53.742555
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out, err = capsys.readouterr()
    parser.print_usage()
    out1, err1 = capsys.readouterr()
    assert(out1!=out)


# Generated at 2022-06-22 00:10:00.899405
# Unit test for method parse of class Parser
def test_Parser_parse():
    def test(argv, inargs):
        parser = Parser()
        parser.parse(argv)
        assert parser._parser.parse_args(inargs)

    test(['', '-v'], ['-v'])
    test(['', '-a', 'ls'], ['-a', 'ls'])
    test(['', '-l', 'fuck.log'], ['-l', 'fuck.log'])
    test(['', '--enable-experimental-instant-mode'], ['--enable-experimental-instant-mode'])
    test(['', '-h'], ['-h'])
    test(['', '-y'], ['-y'])
    test(['', '--yes'], ['--yes'])

# Generated at 2022-06-22 00:10:45.631120
# Unit test for method parse of class Parser
def test_Parser_parse():
    parse = Parser().parse
    assert parse([]) == []
    assert parse(['--']) == ['--']
    assert parse(['-v']) == ['-v']
    assert parse(['xxx', ARGUMENT_PLACEHOLDER]) == ['xxx', ARGUMENT_PLACEHOLDER]
    assert parse([ARGUMENT_PLACEHOLDER, 'xxx']) == ['xxx', '--']
    assert parse(['-v', ARGUMENT_PLACEHOLDER, 'xxx']) == ['xxx', '--', '-v']
    assert parse(['xxx', '--', ARGUMENT_PLACEHOLDER, 'xxx']) == ['xxx', '--']

# Generated at 2022-06-22 00:10:54.372816
# Unit test for method parse of class Parser
def test_Parser_parse():
    input1 = ['thefuck', '-v', '--help', 'arg1', 'arg2', 'arg3', 'arg4', 'arg5', 'arg6', 'arg7', 'arg8', 'arg9', 'arg10']
    output1 = Parser().parse(input1)
    assert output1.version
    assert output1.help
    assert output1.command == []

    input2 = ['thefuck', '-v', '--help', '-d', 'arg1', 'arg2', 'arg3', 'arg4', 'arg5', 'arg6', 'arg7', 'arg8', 'arg9', 'arg10']
    output2 = Parser().parse(input2)
    assert output2.version
    assert output2.help
    assert output2.debug
    assert output2.command == []

    input

# Generated at 2022-06-22 00:10:55.402155
# Unit test for constructor of class Parser
def test_Parser():
    executable = Parser()

# Generated at 2022-06-22 00:10:56.182222
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:10:57.012745
# Unit test for constructor of class Parser
def test_Parser():
    instance = Parser()
    assert True

# Generated at 2022-06-22 00:11:03.908864
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .parser import Parser
    from .main import get_all_executables
    from .utils import get_alias
    import sys
    import os

    sys.argv = ['test']
    parser = Parser()
    parser.print_usage()
    assert os.path.isfile("/tmp/test.txt")
    os.remove("/tmp/test.txt")


# Generated at 2022-06-22 00:11:06.528218
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Make sure that it doesn't print any errors
    Parser().print_help()


# Generated at 2022-06-22 00:11:09.750298
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_obj = Parser()
    parser_obj.print_help()

parser = Parser()

# Generated at 2022-06-22 00:11:15.014638
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['fuck', 'dafucker', 'cd', 'proj', ARGUMENT_PLACEHOLDER,'-l', 'logs/fuck.log'])
    assert args.command == ['dafucker', 'cd', 'proj']
    assert args.shell_logger == 'logs/fuck.log'

# Generated at 2022-06-22 00:11:18.587585
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    sys.stderr = StringIO()
    p.print_help()
    print(repr(sys.stderr.getvalue()))
    assert "Usage: thefuck" in sys.stderr.getvalue()

# Generated at 2022-06-22 00:13:02.459951
# Unit test for constructor of class Parser
def test_Parser():
    class TestParser(Parser):
        def _add_arguments(self):
            pass
        def _add_conflicting_arguments(self):
            pass

    arguments = TestParser()._prepare_arguments([])
    assert arguments == []

    arguments = TestParser()._prepare_arguments(['<x>'])
    assert arguments == ['--', '<x>']

    arguments = TestParser()._prepare_arguments(['ls', '-l', '<x>', '<y>'])
    assert arguments == ['ls', '-l', '--', '<x>', '<y>']

# test_Parser()

# Generated at 2022-06-22 00:13:13.006538
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['--enable-experimental-instant-mode']).enable_experimental_instant_mode
    assert p.parse(['command']).command == ['command']
    assert p.parse(['--alias']).alias == get_alias()
    assert p.parse(['--force-command', '--', 'command']).force_command == '--'
    assert p.parse(['--help']).help
    assert p.parse(['--yeah']).yes
    assert p.parse(['--repeat']).repeat
    assert p.parse(['--', 'command']).command == ['command']
    assert p.parse(['--force-command', '--', '--']).force_command == '--'


# Generated at 2022-06-22 00:13:15.452490
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-22 00:13:24.176298
# Unit test for method parse of class Parser
def test_Parser_parse():
    args1 = []
    parser = Parser()
    parsed_args1 = parser.parse(args1)
    assert parsed_args1.command == []

    args2 = ["-d", "--force-command", "pwd", "-l", "log_file.log", "-v", "--alias", "fuck"]
    parser = Parser()
    parsed_args2 = parser.parse(args2)
    assert args2[0] == "-" + parsed_args2.debug
    assert args2[1] == "--force-command"
    assert args2[2] == parsed_args2.force_command
    assert args2[4] == "--shell-logger"
    assert args2[5] == parsed_args2.shell_logger
    assert args2[6] == "-" + parsed_args2.version

# Generated at 2022-06-22 00:13:33.836707
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(
        ['thefuck', 'nonexistingcommand']
        ) == Namespace(debug=False, enable_experimental_instant_mode=False, shell_logger=None, help=False, version=False, yes=False, command=['nonexistingcommand'], alias=get_alias(), repeat=False)
    assert p.parse(
        ['thefuck', '-v']
        ) == Namespace(debug=False, enable_experimental_instant_mode=False, shell_logger=None, help=False, version=True, yes=False, command=[], alias=get_alias(), repeat=False)

# Generated at 2022-06-22 00:13:34.914211
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-22 00:13:38.168940
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_file = parser.print_help()
    help_text = "%s" % help_file
    assert "usage: thefuck" in help_text and "optional arguments:" in help_text

# Generated at 2022-06-22 00:13:44.738624
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import VERSION
    from .utils import get_alias
    from io import StringIO
    my_std_err = StringIO()
    sys.stderr = my_std_err
    my_parser = Parser()
    my_parser.print_help()
    my_std_err.seek(0)
    lines = my_std_err.readlines()
    back_to_std_err = StringIO()
    sys.stderr = back_to_std_err
    assert my_std_err.getvalue()
    assert lines[0].startswith('usage: thefuck')
    assert lines[1]
    assert lines[2]
    assert lines[3]
    assert lines[4].startswith('optional arguments:')
    assert lines[5]
    assert lines[6].startsw

# Generated at 2022-06-22 00:13:46.676093
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import NORMAL_USAGE

    parser = Parser()

    assert NORMAL_USAGE in repr(parser._parser.usage)

# Generated at 2022-06-22 00:13:49.240833
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '--help', '-v', 'cd', '-r', 'pwd'])
    assert args.help
    assert args.version
    assert args.repeat
    assert args.command == ['cd', 'pwd']
