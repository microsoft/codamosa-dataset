

# Generated at 2022-06-22 00:05:50.092092
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    with supress_stderr_and_stdout():
        parser = Parser()
        parser.print_usage()


# Generated at 2022-06-22 00:06:00.556226
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse(['thefuck', '--help']).help
    assert parser.parse(['thefuck', '--debug', 'git']).debug
    assert parser.parse(['thefuck', '--alias', 'fuck']).alias == 'fuck'
    assert parser.parse(['thefuck', '--alias']).alias == get_alias()
    assert parser.parse(['thefuck', '--version']).version
    assert parser._prepare_arguments(['thefuck', 'some', '--some-arg', '--', '-some-arg', 'git']) == ['--some-arg', '--'] + ['some']
    assert parser._prepare_arguments(['thefuck', 'some', '--some-arg', 'git']) == ['--some-arg'] + ['git']

# Generated at 2022-06-22 00:06:02.113259
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:06:03.789769
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print("Executing test_Parser_print_usage()")
    Parser().print_usage()


# Generated at 2022-06-22 00:06:05.630308
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()
    assert True


# Generated at 2022-06-22 00:06:15.615468
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    Test method parse of class Parser
    """
    p = Parser()

    commands = ["ls", "ls -la", "ls --color"]
    for command in commands:
        result = p.parse(["thefuck"] + command.split())
        assert result.command == command.split()

    # Test with --help
    result = p.parse(["thefuck", "--help"])
    assert result.help is True

    # Test with verbose
    result = p.parse(["thefuck", "-a"])
    assert result.alias is "fuck"

    # Test with list of all the arguments

# Generated at 2022-06-22 00:06:23.971967
# Unit test for constructor of class Parser
def test_Parser():
    # create an instance of class Parser
    parser = Parser()

    # test case: no parameters
    assert parser._prepare_arguments(None)==None

    # test case: negative input
    assert parser._prepare_arguments(-1,'w')==[-1, 'w']

    # test case: verify the parser
    parser.parse(['-v'])

    # test case: print the help message
    parser.print_help()

    # test case
    assert parser._prepare_arguments(['-'])==['-']


# Generated at 2022-06-22 00:06:24.960874
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-22 00:06:25.714128
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:06:29.007668
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    params = ['--debug','--','echo','hello','world', ARGUMENT_PLACEHOLDER, '--debug']
    print(parser.parse(params).command)


# Generated at 2022-06-22 00:06:47.085892
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # Parsing user arguments and command line
    arguments = parser.parse(['/home/user/.local/bin/thefuck', 'echo', 'Hello', 'World!'])
    assert arguments.command == ['Hello', ARGUMENT_PLACEHOLDER, 'World!']

    # Parsing user arguments and command line with alias
    arguments = parser.parse(['/home/user/.local/bin/thefuck', '--alias', 'alias', 'echo', 'Hello', 'World!'])
    assert arguments.alias == 'alias'
    assert arguments.command == ['Hello', ARGUMENT_PLACEHOLDER, 'World!']

    # Parsing only user arguments
    arguments = parser.parse(['/home/user/.local/bin/thefuck', '--debug', '--repeat'])
    assert arguments

# Generated at 2022-06-22 00:06:51.714144
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class FakeStderr(object):
        def __init__(self):
            self.content = ''

        def write(self, content):
            self.content += content

    fake_stderr = FakeStderr()

    parser = Parser()
    parser.print_help(file=fake_stderr)

    assert fake_stderr.content, "The help message was not printed"

# Generated at 2022-06-22 00:06:52.931596
# Unit test for constructor of class Parser
def test_Parser():
  parser = Parser()
  assert type(parser) == Parser



# Generated at 2022-06-22 00:07:05.672143
# Unit test for constructor of class Parser
def test_Parser():
    test = Parser()
    assert test._parser.prog == 'thefuck'
    assert not test._parser._actions[0].help == None
    assert not test._parser._actions[1].help == None
    assert not test._parser._actions[2].help == None
    assert not test._parser._actions[3].help == None
    assert not test._parser._actions[4].help == None
    assert test._parser._actions[5].help != None
    assert not test._parser._actions[6].help == None
    assert test._parser._actions[7].help == SUPPRESS
    assert not test._parser._actions[8].help == None
    assert not test._parser._actions[9].help == None
    assert not test._parser._actions[10].help == None

# Generated at 2022-06-22 00:07:17.781724
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    stdout = StringIO()
    with stdout_redirector(stdout):
        Parser().print_help()

# Generated at 2022-06-22 00:07:29.507983
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    arguments = p.parse(['t', 'git', 'stash'])
    assert arguments.command == ['git', 'stash']
    arguments = p.parse(['t', '-y', '--', 'ls'])
    assert arguments.command == ['ls']
    assert arguments.yes is True
    arguments = p.parse(['t', '-y', '--', 'ls', '-la'])
    assert arguments.command == ['ls', '-la']
    arguments = p.parse(['t', '-y', '--', 'ls', '-la', ARGUMENT_PLACEHOLDER, 'test1', 'test2', 'test3'])
    assert arguments.command == ['test1', 'test2', 'test3', '--', 'ls', '-la']
   

# Generated at 2022-06-22 00:07:35.728638
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ["-y","-r","/usr/bin/perl", "--","--version"]
    parser = Parser()
    arg = parser.parse(argv)
    assert arg.yes == True and arg.repeat == True and arg.shell_logger == None and arg.alias == "fuck" and arg.command == ['/usr/bin/perl', '--version']



# Generated at 2022-06-22 00:07:45.117917
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    Parser().print_usage()
    sys.stdout = old_stdout
    assert mystdout.getvalue().rstrip() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y] [-r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]"


# Generated at 2022-06-22 00:07:51.092582
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    from io import StringIO
    out = StringIO()
    parser.print_usage(file=out)
    assert out.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l LOG_FILE] [--enable-experimental-instant-mode] [-y | -r] [-d]\n[--force-command CMD]\n[command [command ...]]\n'

# Generated at 2022-06-22 00:07:55.171675
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    sys.stdout.flush()
    parser.print_usage()
    assert sys.stdout.getvalue() == ''
    sys.stdout.flush()
    parser.print_usage()
    assert sys.stdout.getvalue() == ''


# Generated at 2022-06-22 00:08:14.241299
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest.mock import patch
    parser = Parser()
    with patch('thefuck.make_alias.Parser.print_usage') as print_usage:
        parser.print_usage()
        assert print_usage.called



# Generated at 2022-06-22 00:08:16.095671
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser # Parser is defined

# Generated at 2022-06-22 00:08:18.267272
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    args = ['thefuck', '--version', '-h', '-r', 'python']
    parser.parse(args)
    parser.print_help()

# Generated at 2022-06-22 00:08:27.722328
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test class Parser has a method parse."""
    p = Parser()

    assert p.parse(
        ['thefuck', 'python', 'file.py', '-v', '-a']) == \
        Namespace(
            alias=get_alias(),
            debug=False,
            enable_experimental_instant_mode=False,
            force_command=None,
            help=False,
            repeat=False,
            shell_logger=None,
            version=False,
            yes=False,
            command=['python', 'file.py', '-v', '-a'])


# Generated at 2022-06-22 00:08:38.708860
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    args = parser.parse(['fuck', 'test'])
    out = StringIO()
    sys.stdout = out
    parser.print_usage()
    out.seek(0)

# Generated at 2022-06-22 00:08:43.945205
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """This function tests method print_usage of class Parser.

    It seems it's a bit hard to make this test in a formal way.
    """
    f = open(os.devnull, 'w')
    save_stderr = sys.stderr
    sys.stderr = f
    parser = Parser()
    parser.print_usage()
    sys.stderr = save_stderr
    f.close()
    return True

# Generated at 2022-06-22 00:08:54.532818
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .arguments import parser
    import sys
    saved_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        parser.print_usage()
        output = out.getvalue().strip()
        assert output == """usage: thefuck [-h] [--shell-logger SHELL_LOGGER]
       [-d] [-y] [-r] [-a [CUSTOM-ALIAS-NAME]] [-v]
       [--enable-experimental-instant-mode]
       [--force-command FORCE-COMMAND] [command [command ...]]"""
    finally:
        sys.stderr = saved_stderr



# Generated at 2022-06-22 00:08:57.306457
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', '--help'])
    assert args.help
    args = parser.parse(['thefuck', '-h'])
    assert args.help



# Generated at 2022-06-22 00:09:09.630615
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck','ls','cd','$','ls','~','/home/keshav']), Namespace(debug=False, yes=False, repeat=False, force_command=None, command=['ls','cd','ls','~', '/home/keshav'])
    assert parser.parse(['thefuck','ls','cd','$','--','ls','~','/home/keshav']), Namespace(debug=False, yes=False, repeat=False, force_command=None, command=['ls','cd','ls','~', '/home/keshav'])

# Generated at 2022-06-22 00:09:10.873814
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage() == None


# Generated at 2022-06-22 00:09:39.277240
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:09:51.175067
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[0].dest == 'yes'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[1].dest == 'repeat'
    assert parser._parser._actions[5].dest == 'debug'

# Generated at 2022-06-22 00:09:52.675594
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # parser = Parser()
    # parser.print_help()
    pass


# Generated at 2022-06-22 00:09:56.253819
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.prog == 'thefuck'
    assert Parser()._parser.description == None
    assert Parser()._parser.epilog == None
    assert Parser()._parser.version == None


# Generated at 2022-06-22 00:09:58.544770
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:10:04.916044
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_message = 'usage: thefuck [-v] [-a [custom-alias-name]] ' + \
                   '[-l shell-logger] [--enable-experimental-instant-mode] ' + \
                   '[-h] -d [-y | -r] [--force-command force-command] command ...\n'
    parser.print_help()
    assert sys.stderr.getvalue().startswith(help_message)

# Generated at 2022-06-22 00:10:15.296859
# Unit test for constructor of class Parser
def test_Parser():
    parser=Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._actions[5].dest == 'yes'
    assert parser._parser._actions[6].dest == 'repeat'
    assert parser._parser._actions[7].dest == 'debug'
    assert parser._parser._actions[8].dest == 'force_command'
    assert parser._parser._actions[9].dest == 'command'


# Generated at 2022-06-22 00:10:16.377930
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:10:26.769919
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    from .utils import get_alias

    alias = get_alias()
    stderr = StringIO()
    parser = Parser()
    argv = ['fuck', '-h']
    parser.parse(argv)
    parser.print_help()
    output = stderr.getvalue()
    assert 'optional arguments' in output
    assert '-v, --version' in output
    assert '-a, --alias' in output
    assert '-l, --shell-logger' in output
    assert '--enable-experimental-instant-mode' in output
    assert '-h, --help' in output
    assert '-d, --debug' in output
    assert '-y, --yes, --yeah, --hard' in output
    assert '-r, --repeat' in output

# Generated at 2022-06-22 00:10:27.936223
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-22 00:11:06.601555
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'git', 'push', 'origin', 'master', '-f']) == \
           parser.parse(['thefuck', 'git push origin master -f'])
    assert parser.parse(['thefuck', 'git', 'push', 'origin', 'master',
                         ARGUMENT_PLACEHOLDER, '-f']) == \
           parser.parse(['thefuck', '-f', 'git push origin master'])

# Generated at 2022-06-22 00:11:07.389828
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-22 00:11:16.729759
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Capture stdout
    import StringIO
    old = sys.stdout
    sys.stdout = myout = StringIO.StringIO()
    Parser().print_usage()
    res = myout.getvalue()
    # Close stdout
    sys.stdout = old
    # Compare
    assert(res == "usage: thefuck [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-h] [-d] [-y] [-r] [--force-command force-command] [--] [command [command ...]]\n")


# Generated at 2022-06-22 00:11:17.977738
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-22 00:11:19.697451
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    pass


# Generated at 2022-06-22 00:11:29.121850
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['']) == Parser()._parser.parse_args([])
    assert Parser().parse(['', '-v']) == Parser()._parser.parse_args(['-v'])
    assert Parser().parse(['', ARGUMENT_PLACEHOLDER, '-v']) == Parser()._parser.parse_args(['-v'])
    assert Parser().parse(['', 'command', '-v']) == Parser()._parser.parse_args(['--', 'command', '-v'])
    assert Parser().parse(['', ARGUMENT_PLACEHOLDER, 'command', '-v']) == Parser()._parser.parse_args(['command', '-v'])

# Generated at 2022-06-22 00:11:31.545316
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True



# Generated at 2022-06-22 00:11:38.998457
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .test_utils import support_test_output
    from .utils import capture_stderr

    with support_test_output() as (stdout, stderr):
        parser = Parser()
        parser.print_usage()
        assert stderr.getvalue() == ('usage: thefuck [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n'
                                     '              [--enable-experimental-instant-mode] [-h]\n'
                                     '              [-d] [--force-command COMMAND]\n'
                                     '              [command [command ...]]\n')
        assert stdout.getvalue() == ''



# Generated at 2022-06-22 00:11:42.104012
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except:
        assert False


# Generated at 2022-06-22 00:11:49.569864
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['./some_dir/some_cmd']) == parser.parse(['./some_dir/some_cmd', '--'])
    assert parser.parse(['./some_dir/some_cmd', '-l', 'file']) == parser.parse(['--', '-l', 'file'])
    assert parser.parse(['./some_dir/some_cmd', 'ARGUMENT_PLACEHOLDER', '-l', 'file']) == parser.parse(['--', '-l', 'file'])

# Generated at 2022-06-22 00:12:09.702724
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:12:15.007733
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from subprocess import PIPE, Popen
    from os import devnull
    cmd = 'thefuck --help'.split()
    command = Popen(cmd, stdout=PIPE, stderr=PIPE)
    out, err = command.communicate()

    assert 'usage: thefuck' in err

# Generated at 2022-06-22 00:12:17.054013
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
        print("Parsing OK")
    except:
        print("Error parsing")


# Generated at 2022-06-22 00:12:27.487914
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['script_name', '--alias', 'fuck', 'echo', 'hello']) == \
        Namespace(alias='fuck', debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False, command=['echo', 'hello'])
    assert parser.parse(['script_name', '--enable-experimental-instant-mode', 'fuck', 'echo', 'hello']) == \
        Namespace(alias=None, debug=False, command=['fuck', 'echo', 'hello'], enable_experimental_instant_mode=True, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)

# Generated at 2022-06-22 00:12:29.663153
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:12:30.475637
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()



# Generated at 2022-06-22 00:12:33.393195
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from mock import Mock, patch
    print_usage = Parser().print_usage
    with patch('sys.stderr') as stderr:
        print_usage()
        stderr.write.assert_called_once()


# Generated at 2022-06-22 00:12:39.527275
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # the result will be printed to stderr
    # save stderr to a string and then test the string
    out = StringIO.StringIO()
    old_stderr = sys.stderr
    sys.stderr = out
    parser.print_usage()
    sys.stderr = old_stderr
    usage = out.getvalue()
    assert(usage == "usage: thefuck [-h]\n")


# Generated at 2022-06-22 00:12:47.666466
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .settings import parse_arguments
    from .utils import get_alias, get_closest
    from .runner import Runner
    from .shells import Shell

    args = parse_arguments(['--alias'])
    assert Runner(args).run() == 'alias {}=\'$(thefuck $(fc -ln -1))\''.format(get_alias())

    args = parse_arguments(['--help'])
    assert Runner(args).run() == 'Show this help message and exit'

    args = parse_arguments([])
    shell = Shell(args)

    pytest.raises(SystemExit, args.parse, ['--help'])
    pytest.raises(SystemExit, args.parse, ['--version'])
    pytest.raises(SystemExit, args.parse, ['--debug'])
   

# Generated at 2022-06-22 00:12:48.770708
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    argv = ['thefuck']
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-22 00:13:36.073312
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # argv[0] == 'thefuck'
    argv = ['thefuck', '-v']
    assert parser.parse(argv) == parser._parser.parse_args(argv[1:])
    # argv[0] == 'thefuck'
    # ARGUMENT_PLACEHOLDER in argv
    argv = ['thefuck', 'some command', ARGUMENT_PLACEHOLDER, 'more arguments']
    assert parser.parse(argv) == parser._parser.parse_args(argv[1:])
    # argv[0] == 'thefuck'
    # argv[1] != '-'
    # '--' in argv
    argv = ['thefuck', '--', 'some command']

# Generated at 2022-06-22 00:13:43.861535
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse([])
    assert result.command == []
    assert result.alias is None
    assert result.force_command is None
    assert result.help is False
    assert result.repeat is False
    assert result.yes is False
    assert result.debug is False

    result = parser.parse(["-d"])
    assert result.command == []
    assert result.alias is None
    assert result.force_command is None
    assert result.help is False
    assert result.repeat is False
    assert result.yes is False
    assert result.debug is True

    result = parser.parse(["-r", "ls", "--", "-al"])
    assert result.command == ["-al"]
    assert result.alias is None
    assert result.force_command is None
    assert result

# Generated at 2022-06-22 00:13:47.050454
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    # Check the default argument
    if p._parser.add_help:
        print("True")
    else:
        print("False")
    # Check that no arguments have been added so far
    if len(list(p._parser._actions)) == 0:
        print("True")
    else:
        print("False")



# Generated at 2022-06-22 00:13:50.092239
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'git', 'push', ARGUMENT_PLACEHOLDER, '-y'])
    assert args.yes
    assert args.command == ['git', 'push']

    args = parser.parse(['thefuck', '--', 'git', 'push'])
    assert args.command == ['git', 'push']

# Generated at 2022-06-22 00:13:52.105739
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    #  assert parser._parser.add_help == False
    #  assert parser._parser.prog == 'thefuck'
    return 'Unit test for constructor of class Parser is finished'


# Generated at 2022-06-22 00:13:53.785148
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    arguments = parser.parse(['thefuck','git','r','--','git','histo','--','git','rm','--cached','~/foo'])
    assert arguments.repeat

# Generated at 2022-06-22 00:13:54.331081
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    pass



# Generated at 2022-06-22 00:13:55.063324
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None


# Generated at 2022-06-22 00:14:01.771354
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Form 1:
    #   $ thefuck command1 --option1 args1 --option2 args2
    #   >> Correct order of arguments:
    #       $ thefuck -- command1 --option1 args1 --option2 args2
    parser = Parser()
    arguments = parser.parse(['thefuck', 'command1', '--option1', 'args1', '--option2', 'args2'])
    assert arguments.command == ['command1', '--option1', 'args1', '--option2', 'args2']
    assert arguments.debug is False
    
    # Form 2:
    #   $ thefuck --command command1 --option1 args1 --option2 args2
    #   >> Correct order of arguments:
    #       $ thefuck -- command1 --option1 args1 --option2 args2
    parser = Parser()

# Generated at 2022-06-22 00:14:03.050275
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Unit test for method print_help of class Parser"""
    p = Parser()
    p.print_help()

# Generated at 2022-06-22 00:15:26.181390
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser)


# Generated at 2022-06-22 00:15:30.543305
# Unit test for method print_usage of class Parser

# Generated at 2022-06-22 00:15:32.398994
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:15:35.154207
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:15:36.933839
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:15:38.689583
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['command', 'arg1', 'arg2']
    parser = Parser()
    assert parser.parse(args) == parser._parser.parse_args(args)


# Generated at 2022-06-22 00:15:41.844586
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser() 
    assert p

