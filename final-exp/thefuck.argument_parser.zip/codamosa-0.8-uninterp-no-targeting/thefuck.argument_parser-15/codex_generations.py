

# Generated at 2022-06-22 00:05:42.346782
# Unit test for constructor of class Parser
def test_Parser():
    print("test_Parser")
    parser = Parser()
    assert 'prog' in parser._parser.__dict__
    assert 'add_help' in parser._parser.__dict__
    assert '_actions' in parser._parser.__dict__
    assert '_option_string_actions' in parser._parser.__dict__
    assert '_positionals' in parser._parser.__dict__
    assert '_mutually_exclusive_groups' in parser._parser.__dict__


# Generated at 2022-06-22 00:05:48.836777
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import six
    import io

    class MockStderr(six.StringIO):
        def __init__(self):
            super(MockStderr, self).__init__()
        # Override the `write` method
        def write(self, value):
            if value != "\n" and value != "":
                super(MockStderr, self).write(value)

    p = Parser()
    # Mock `sys.stderr`
    sys.stderr = MockStderr()
    # Call the `print_help` method
    p.print_help()
    # Assert
    assert 'usage' in sys.stderr.getvalue()

# Generated at 2022-06-22 00:05:51.025939
# Unit test for constructor of class Parser
def test_Parser():

    parser = Parser()
    parser.parse(['/bin/ls','--force-command', '--'])


# Generated at 2022-06-22 00:05:54.226132
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert str(parser) == "<thefuck.parser.Parser object at 0x7f13c59f5e50>"


# Generated at 2022-06-22 00:05:55.775137
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser._parser

# Generated at 2022-06-22 00:05:57.008709
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:06:08.533844
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import contextlib

    parser = Parser()

    @contextlib.contextmanager
    def capture_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with capture_output() as (out, err):
        parser.print_usage()
    output = out.getvalue().strip()

    assert 'usage: thefuck [-h]' in output
    assert 'optional arguments:' in output
    assert '-v, --version' in output

# Generated at 2022-06-22 00:06:09.408779
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p1 = Parser()
    p1.print_usage()
    p1.print_help()

# Generated at 2022-06-22 00:06:14.266178
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'thefuck']) == \
        parser.parse(['thefuck', 'thefuck', '--', 'cd'])
    assert parser.parse(['thefuck', 'thefuck', '--alias=fuck']) == \
        parser.parse(['thefuck', 'thefuck', '--alias', 'fuck', '--', 'cd'])

# Generated at 2022-06-22 00:06:16.327682
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-22 00:06:20.280345
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:06:27.215406
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    stdout = sys.stdout.write

    try:
        sys.stdout.write = str
        assert parser.print_usage() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--] [command [command ...]]\n'
    finally:
        sys.stdout.write = stdout


# Generated at 2022-06-22 00:06:39.069801
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    stdout = sys.stdout

# Generated at 2022-06-22 00:06:49.839973
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import DESCRIPTION
    from .utils import is_win

    import sys
    import re
    import os

    text = ""

    # We need to redirect the output, so we can capture the output of print_help
    try:
        sys.stdout = out = StringIO()

        parser = Parser()
        parser.print_help()
        text = out.getvalue().strip()
    finally:
        sys.stdout = sys.__stdout__

    # Check if the help output is a least as long as the description constant
    assert len(text) >= len(DESCRIPTION), "The length of the help output is less than the length of the description constant"
    # Check if the description constant is a substring of the help output
    assert DESCRIPTION in text, "Description constant is not a substring in the output of print_help"

# Generated at 2022-06-22 00:06:55.027223
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # setup
    import mock
    import sys
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias
    
    parser = Parser()
    m_print_usage = mock.Mock()
    parser._parser.print_usage = m_print_usage
    parser._parser.error = mock.Mock()

    # execution
    parser.print_usage()
    
    # test
    assert m_print_usage.called
    assert parser._parser.error.called
    assert m_print_usage.called_with(sys.stderr)


# Generated at 2022-06-22 00:06:56.410801
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:06:57.415973
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print(Parser().parse([]).alias)

# Generated at 2022-06-22 00:06:59.436093
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    P = Parser()
    import sys, os
    P.print_help()

# Generated at 2022-06-22 00:07:08.825323
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'script', 'arg', '-v']) == \
        parser.parse(['thefuck', 'script', 'arg', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', 'script', 'arg', '-v']) == \
        parser.parse(['thefuck', 'script', 'arg', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', 'script', 'arg', '-v']) == \
        parser.parse(['thefuck', 'script', 'arg', ARGUMENT_PLACEHOLDER, '-v'])

# Generated at 2022-06-22 00:07:13.176949
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_string = parser.print_help()
    assert not help_string is None
    assert "program's version number and exit" in help_string


# Generated at 2022-06-22 00:07:23.064913
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Given - A test that needs to print the usage
    parser = Parser()
    # When - It prints the usage
    parser.print_usage()
    # Then - the usage is printed
    # There is no way to test this

# Generated at 2022-06-22 00:07:24.015437
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()

# Generated at 2022-06-22 00:07:26.463469
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert p.print_help() == None


# Generated at 2022-06-22 00:07:27.091562
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:07:28.010693
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    parser.print_help()

# Generated at 2022-06-22 00:07:31.394106
# Unit test for constructor of class Parser
def test_Parser():
    # Test if class Parser exist
    try:
        Parser()
        print("Parser exist")
    except NameError:
        print("Parser not exist")

# Test the parser

# Generated at 2022-06-22 00:07:42.186799
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-a', 'alias']).alias == 'alias'
    assert parser.parse(['thefuck', '--alias', 'alias']).alias == 'alias'
    assert parser.parse(['thefuck', '--alias', 'alias', '-v']).version \
        == parser.parse(['thefuck', '--alias', 'alias', '--version']).version
    assert parser.parse(['thefuck', '--', '-d']).command == ['-d']
    assert parser.parse(['thefuck', '--', '--debug']).command == ['--debug']
    assert parser.parse(['thefuck', '-d', '--', '-a']).command == ['-a']

# Generated at 2022-06-22 00:07:45.067516
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['fuck', '--', 'ls', '-la'])


# Generated at 2022-06-22 00:07:55.255910
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([]) == parser._parser.parse_args([])
    assert parser.parse(['arg']) == parser._parser.parse_args(['arg'])

    # Calling with placeholder
    args = parser.parse(['arg1', ARGUMENT_PLACEHOLDER, 'arg2'])
    assert args == parser._parser.parse_args([
        'arg2', '--', 'arg1'])

    # Calling with arguments after placeholder
    args = parser.parse([
        'arg1', ARGUMENT_PLACEHOLDER,
        'arg2', 'arg3', 'arg4', 'arg5'])

# Generated at 2022-06-22 00:07:56.973227
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    try:
        p.print_help()
    except SystemExit:
        pass

# Generated at 2022-06-22 00:08:17.842467
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True

# Generated at 2022-06-22 00:08:20.548808
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    assert(str(parser.print_help()).__contains__('show program'))



# Generated at 2022-06-22 00:08:21.639947
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:08:23.389320
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-22 00:08:28.520691
# Unit test for constructor of class Parser
def test_Parser():
    results = Parser()
    assert results.parse(0) == ('-v', '--version')
    assert results.parse(0) == ('-a', '--alias')
    assert results.parse(0) == ('-l', '--shell-logger')
    assert results.parse(0) == ('-h', '--help')
    assert results.parse(0) == ('-d', '--debug')
    assert results.parse(0) == ('--force-command')
    assert results.parse(0) == ('command', 'nargs')

# Generated at 2022-06-22 00:08:32.101522
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', 'python', 'ARGUMENT_PLACEHOLDER', '-h']) == \
        p.parse(['thefuck', 'python', '-h'])

# Generated at 2022-06-22 00:08:35.811714
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['-l', 'log.txt', 'ls', '-l'])
    assert args.command == ['ls', '-l']
    assert args.shell_logger == 'log.txt'

# Generated at 2022-06-22 00:08:45.168720
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from argparse import ArgumentParser
    from io import StringIO
    
    from .parser import Parser
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER

    parser = Parser()
    alias = get_alias()
    result = StringIO()
    parser._parser.print_usage = lambda file: file.write("text")

    result.write("""usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-d] [--force-command FORCE-COMMAND] [--] [command [command ...]]

F*@#ing correctly.
""")
    parser.print_usage()
    assert result == StringIO()

    result = StringIO()

# Generated at 2022-06-22 00:08:55.670497
# Unit test for constructor of class Parser
def test_Parser():
	assert (isinstance(Parser().parse(['-v']),argparse.Namespace))	
	assert (isinstance(Parser().parse(['-a']),argparse.Namespace))	
	assert (isinstance(Parser().parse(['-a','custom']),argparse.Namespace))	
	assert (isinstance(Parser().parse(['-l', 'file']),argparse.Namespace))	
	assert (isinstance(Parser().parse(['--enable-experimental-instant-mode']),argparse.Namespace))	
	assert (isinstance(Parser().parse(['-h']),argparse.Namespace))
	assert (isinstance(Parser().parse(['-y']),argparse.Namespace))
	assert (isinstance(Parser().parse(['--yeah']),argparse.Namespace))

# Generated at 2022-06-22 00:08:56.822943
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-22 00:09:14.375936
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.prog == 'thefuck'
    # assert Parser()._parser.add_help == False




# Generated at 2022-06-22 00:09:16.799847
# Unit test for method parse of class Parser
def test_Parser_parse():
    my_parser = Parser()
    assert my_parser.parse([""]) == argparse.Namespace()


# Generated at 2022-06-22 00:09:27.371547
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert len(parser._parser._actions) == 10
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].const == get_alias()
    assert parser._parser._actions[2].option_strings == ['-l', '--shell-logger']
    assert parser._parser._actions[2].dest == 'shell_logger'

# Generated at 2022-06-22 00:09:29.999713
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(["fuck"])


# Generated at 2022-06-22 00:09:33.430337
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Test that the help message that is printed is not badly formatted
    """
    parser = Parser()

# Generated at 2022-06-22 00:09:42.157088
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    from contextlib import redirect_stderr
    f = io.StringIO() # StringIO object

    parser = Parser()
    with redirect_stderr(f):
        parser.print_help()
    output = f.getvalue().strip()
    assert output == """usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [--] [command [command ...]]"""
    #print(output)


# Generated at 2022-06-22 00:09:54.353575
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import VERSION
    from .settings import HELP_URL
    from .utils import get_alias
    from .utils import get_no_colors_env
    from .utils import get_sys_executable
    from .utils import get_version
    from .utils import get_xonsh_env
    import io
    import sys

    sys.argv = ['thefuck']
    parser = Parser()
    help_text = io.StringIO()
    help_text.write('usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'
                    '              [-l SHELL_LOGGER]\n'
                    '              [--enable-experimental-instant-mode]\n'
                    '              [-y | -r] [-d] [--] [command [command ...]]\n')

# Generated at 2022-06-22 00:10:04.960238
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['thefuck', 'sudo', 'echo', 'blabla', 'echo', 'blabla', 'echo', 'blabla'])
    expected_result = Namespace(
        alias=get_alias(),
        command=['echo', 'blabla', 'echo', 'blabla', 'echo', 'blabla'],
        debug=False,
        force_command=None,
        help=False,
        repeat=False,
        shell_logger=None,
        version=False,
        yes=False)
    assert result.__dict__ == expected_result.__dict__

# Generated at 2022-06-22 00:10:15.027060
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import VERSION
    parser = Parser()
    # we need to remove the check that the terminal is a tty
    # otherwise, it will always print the usage
    parser._parser._check_value = lambda *args, **kwargs: None
    parser.print_help()
    # ensure the version is printed
    assert 'thefuck ' + VERSION in sys.stderr.getvalue()
    # ensure the version is printed
    assert '--enable-experimental-instant-mode' in sys.stderr.getvalue()
    # ensure the help is printed
    assert '--help' in sys.stderr.getvalue()

test_Parser_print_help.unittest = ['.const', '.parser', '-v', '-h']

# Generated at 2022-06-22 00:10:25.969011
# Unit test for method print_help of class Parser
def test_Parser_print_help():

    from tests.utils import CaptureStderr
    from .utils import get_alias

    with CaptureStderr() as captured:
        parser = Parser()
        parser.print_help()

        help_message = captured.stdout

    alias = get_alias()


# Generated at 2022-06-22 00:11:05.980825
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    parser = Parser()
    parser.print_usage()

    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n                 [-l SHELL_LOGGER]\n                 [--enable-experimental-instant-mode] [-d]\n                 [--force-command COMMAND] [-y | -r] [--]\n                 command [command ...]\n'



# Generated at 2022-06-22 00:11:07.168646
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:11:17.752874
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test without placeholder
    assert Parser().parse([__file__, '1', '2', '3']) == Namespace(
            alias=None,
            command=['1', '2', '3'],
            debug=False,
            enable_experimental_instant_mode=False,
            force_command=None,
            help=False,
            repeat=False,
            shell_logger=None,
            version=False,
            yes=False)

    # Test with placeholder

# Generated at 2022-06-22 00:11:19.922828
# Unit test for constructor of class Parser
def test_Parser():
    assert_that(Parser(), not_none())


# Generated at 2022-06-22 00:11:24.806485
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # should be skip 'fuck'
    expected = parse_args(['~/.config/thefuck/rules.py', '--debug', '--shell-logger'])
    assert_args(parser, ['fuck', '~/.config/thefuck/rules.py', '--debug', '--shell-logger'], expected)


# Generated at 2022-06-22 00:11:26.490898
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None


# Generated at 2022-06-22 00:11:33.638298
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest.mock import patch

    with patch('sys.stderr') as mock_stderr:
        Parser().print_usage()
        mock_stderr.write.assert_called_once_with('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n'
                                                  '               [--enable-experimental-instant-mode] [--force-command FORCE_COMMAND]\n'
                                                  '               [-y] [-r] [-d] [--] [command [command ...]]\n')


# Generated at 2022-06-22 00:11:34.429030
# Unit test for constructor of class Parser
def test_Parser():
    Parser()



# Generated at 2022-06-22 00:11:41.433142
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    out = StringIO()
    stderr = sys.stderr
    sys.stderr = out
    Parser().print_help()
    sys.stderr = stderr
    assert out.getvalue() == (
        'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] '
        '[--enable-experimental-instant-mode] [-d] [-y | -r] [--] [command ...]\n')
    out.close()


# Generated at 2022-06-22 00:11:42.462496
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:12:27.646190
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from contextlib import redirect_stderr
    from io import StringIO

    parser = Parser()

    f = StringIO()
    with redirect_stderr(f):
        parser.print_help()

    assert '--debug' in f.getvalue()
    assert '--alias' in f.getvalue()
    assert '--force-command' in f.getvalue()


# Generated at 2022-06-22 00:12:29.593595
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-22 00:12:38.332686
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    result = p.parse(['thefuck', '--', 'pytnon'])
    assert result.command == ['pytnon']
    assert result.force_command is None
    assert result.debug is False
    assert result.yes is False
    assert result.repeat is False
    assert result.help is False
    assert result.alias is None

    result = p.parse(['thefuck', '--enable-experimental-instant-mode', '--', 'pytnon'])
    assert result.command == ['pytnon']
    assert result.enable_experimental_instant_mode is True

    result = p.parse(['thefuck', '--', 'pytnon', '--foo=bar'])
    assert result.command == ['pytnon', '--foo=bar']


# Generated at 2022-06-22 00:12:39.570395
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-22 00:12:47.697229
# Unit test for method parse of class Parser
def test_Parser_parse():

    # test 1 - argument that is not present
    p = Parser()
    assert p.parse(['thefuck', 'echo', 'hello']) == \
        p._parser.parse_args(['echo', 'hello'])

    # test 2 - argument that is present
    assert p.parse(['thefuck', 'echo', 'hello' , '--yes']) == \
        p._parser.parse_args(['echo', 'hello' , '--yes'])

    # test 3 - argument that is present but with empty value
    assert p.parse(['thefuck', 'echo', 'hello' , '--yes' ]) == \
        p._parser.parse_args(['echo', 'hello' , '--yes' ])

    # test 4 - argument that is present but wrapped by placeholder

# Generated at 2022-06-22 00:12:49.873812
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = parser._prepare_arguments(['--help', ARGUMENT_PLACEHOLDER, 'ls', '1']);
    assert parser.parse(argv).help == True
    assert parser.parse(argv).command == ['ls', '1']


# Generated at 2022-06-22 00:12:56.152664
# Unit test for method parse of class Parser
def test_Parser_parse():

    args = Parser()

    result = Parser().parse([sys.argv[0], '--alias'])
    assert result.alias == get_alias()

    result = Parser().parse([sys.argv[0], '-a', 'fuck'])
    assert result.alias == 'fuck'

    result = Parser().parse(args._prepare_arguments([ARGUMENT_PLACEHOLDER, '-a', 'arg1', '--', 'ls', '-la']))
    assert result.command[0] == 'ls -la'



# Generated at 2022-06-22 00:13:05.519770
# Unit test for constructor of class Parser
def test_Parser():
    from argparse import ArgumentParser, _SubParsersAction

    parser = Parser()
    assert isinstance(parser, Parser)
    assert isinstance(parser._parser, ArgumentParser)
    assert '-v' in parser._parser._option_string_actions
    assert '-a' in parser._parser._option_string_actions
    assert '-l' in parser._parser._option_string_actions
    assert '--enable-experimental-instant-mode' in parser._parser._option_string_actions
    assert '-h' in parser._parser._option_string_actions
    assert '--yes' in parser._parser._option_string_actions
    assert '--repeat' in parser._parser._option_string_actions
    assert '-d' in parser._parser._option_string_actions

# Generated at 2022-06-22 00:13:15.656480
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(
        ['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(
        ['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '--'])
    assert parser.parse(['thefuck', 'ls', '-l']) == parser.parse(
        ['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '--', '-l'])

# Generated at 2022-06-22 00:13:24.512443
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'sudo', 'cd', '/var/log/']
    assert Parser().parse(argv).command == ['sudo', 'cd', '/var/log/']
    assert Parser().parse(argv).yes is False
    assert Parser().parse(argv).repeat is False
    assert Parser().parse(argv).debug is False
    assert Parser().parse(argv).shell_logger is None
    assert Parser().parse(argv).enable_experimental_instant_mode is False
    assert Parser().parse(argv).force_command is None

    argv = ['thefuck', 'sudo', '--', 'cd', '/var/log/']
    assert Parser().parse(argv).command == ['sudo', 'cd', '/var/log/']


# Generated at 2022-06-22 00:14:30.017357
# Unit test for method parse of class Parser
def test_Parser_parse():

    # Arrange
    parser = Parser()

    # Act
    argv = ['thefuck', 'ifconfig', '-a', ARGUMENT_PLACEHOLDER, '--', '-e']
    args = parser.parse(argv)

    # Assert
    assert args.shell_logger is None
    assert args.alias is None
    assert args.command == ['ifconfig', '-a', '--', '-e']
    assert args.debug is False

# Generated at 2022-06-22 00:14:35.629471
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    out, err = capsys.readouterr()
    p.print_usage()
    assert err.startswith("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]")


# Generated at 2022-06-22 00:14:43.205794
# Unit test for constructor of class Parser
def test_Parser():
    '''
    Test the arguments initalized in Parser
    '''

    p = Parser()
    p._add_arguments
    assert p._parser.prog == "thefuck"
    assert p._parser.usage == "thefuck [-h] [-v] [-a [custom-alias-name]]" \
                              " [-l SHELL_LOGGER] [-y --yeah]"
    assert p._parser.description == "Fuck incorrect console commands." \
                                    " And, optionally, fix them."



# Generated at 2022-06-22 00:14:45.151584
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    command_to_test = ['thefuck', '--help']
    p = Parser()
    p.parse(command_to_test)

    p.print_usage()

# Generated at 2022-06-22 00:14:55.195096
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([]) == parser.parse(['--'])
    assert parser.parse(['ls']) == parser.parse(['--', 'ls'])
    assert parser.parse(['--', 'ls']) == parser.parse(['--', '--', 'ls'])
    assert parser.parse(['ls', '-la']) == parser.parse(['--', 'ls', '-la'])
    assert parser.parse(['ls', '-la']) == parser.parse(['--', 'ls', '-la'])
    assert parser.parse(['-y', 'ls', '-la']) == parser.parse(
        ['--', '-y', 'ls', '-la'])

# Generated at 2022-06-22 00:15:01.852841
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['--debug', 'ls', '-la']
    parser = Parser()
    parsed_args = parser.parse(args)
    assert True == parsed_args.debug
    assert ['-la'] == parsed_args.command
    assert None == parsed_args.shell_logger
    args = ['--debug', '-a', 'fuck', 'ls', '-la']
    parser = Parser()
    parsed_args = parser.parse(args)
    assert True == parsed_args.debug
    assert 'fuck' == parsed_args.alias
    assert ['-la'] == parsed_args.command
    assert None == parsed_args.shell_logger
    args = ['--shell-logger', 'shell.log', 'ls', '-la']
    parser = Parser()

# Generated at 2022-06-22 00:15:09.874424
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    message = parser.print_help()

# Generated at 2022-06-22 00:15:18.504031
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    a._add_arguments()
    print("")
    print("Argument Parser print_help")
    a.print_help()
    print("")
    print("Argument Parser parse")
    print("thefuck --debug")
    print(a.parse("thefuck --debug"))
    print("thefuck --alias")
    print(a.parse("thefuck --alias"))
    print("thefuck --shell-logger")
    print(a.parse("thefuck --shell-logger"))
    print("thefuck --enable-experimental-instant-mode")
    print(a.parse("thefuck --enable-experimental-instant-mode"))
    print("thefuck --yes")
    print(a.parse("thefuck --yes"))
    print("thefuck --repeat")
    print

# Generated at 2022-06-22 00:15:21.711033
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # TODO: Use patching to test print_help methd
    pass

# Generated at 2022-06-22 00:15:31.360975
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([
        'thefuck', 'thefuck', 'ls', '-a', '-f'
    ]) == parser.parse([
        'thefuck', 'ls', '-a', '-f'
    ])
    assert parser.parse([
        'thefuck', 'thefuck', 'thefuck', 'thefuck', 'thefuck', 'thefuck', 'ls', '-a', '-f'
    ]) == parser.parse([
        'thefuck', 'ls', '-a', '-f'
    ])