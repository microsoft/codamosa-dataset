

# Generated at 2022-06-22 00:05:39.525005
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    return True

# Generated at 2022-06-22 00:05:43.394660
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    import io
    import sys
    s = io.StringIO()
    sys.stderr = s
    p.print_usage()
    sys.stderr = sys.__stderr__
    assert s.getvalue().startswith('usage: thefuck')


# Generated at 2022-06-22 00:05:45.806522
# Unit test for method parse of class Parser
def test_Parser_parse():
    res = Parser().parse(['fuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-a'])
    assert res.command == ['ls', '-l']



# Generated at 2022-06-22 00:05:50.742875
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    expected = ("usage: thefuck [-h] [-v] [-y | -r] [-h] [-l shell_logger] "
                "[-d] --force-command force_command [command [command ...]]")
    p = Parser()
    assert expected == p.print_usage()

# Generated at 2022-06-22 00:06:01.060180
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    # Capture standard output
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    parser.print_help()
    sys.stdout = old_stdout


# Generated at 2022-06-22 00:06:01.949677
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:06:05.265752
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
        parser.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])



# Generated at 2022-06-22 00:06:08.942684
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue().startswith('usage:')


# Generated at 2022-06-22 00:06:11.227216
# Unit test for constructor of class Parser
def test_Parser():
    
    p = Parser()
    print(p)


if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-22 00:06:12.223133
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:32.092845
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import DEFAULT_COMMAND_ALIAS
    parser = Parser()
    # Test case 1: if the command has its argument
    assert parser.parse(['-v']) == parser._parser.parse_args(['-v'])
    # Test case 2: if the command has its argument and alias
    assert parser.parse(['-a']) == parser._parser.parse_args(['-a'])
    assert parser.parse(['-a', DEFAULT_COMMAND_ALIAS]) == parser._parser.parse_args(['-a', DEFAULT_COMMAND_ALIAS])
    # Test case 3: if the command has its argument and alias but the alias was not defined
    assert parser.parse(['-a', '']) == parser._parser.parse_args(['-a', ''])
    # Test case

# Generated at 2022-06-22 00:06:37.005765
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Test normal usage
    result = parser.parse(["thefuck", "ls", "--all", "something", ARGUMENT_PLACEHOLDER, "-d", "-h"])
    assert result.command == ["ls", "--all", "something"]
    assert result.debug

    # Test no placeholder
    result = parser.parse(["thefuck", "ls", "--all", "something", "-d", "-h"])
    assert result.command == ["ls", "--all", "something", "-d", "-h"]
    assert not result.debug

    # Test thefuck --help
    result = parser.parse(["thefuck", "--help"])
    assert result.help

    # Test thefuck --alias
    result = parser.parse(["thefuck", "--alias"])

# Generated at 2022-06-22 00:06:42.383714
# Unit test for method parse of class Parser
def test_Parser_parse():
    # given
    parser = Parser()
    # expected
    expected = parser.parse(['./parser.py', 'command', '--', 'arg1', 'arg2'])
    # when
    actual = parser.parse(['./parser.py', '__', 'command', '--', 'arg1', 'arg2'])
    # then
    assert (expected.command == actual.command)

# Generated at 2022-06-22 00:06:45.056588
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = parser.print_help()
    assert output == Parser.print_help(parser)

# Generated at 2022-06-22 00:06:46.938667
# Unit test for constructor of class Parser
def test_Parser():
    fields = ['_parser']
    for f in fields:
        assert hasattr(Parser(), f)


# Generated at 2022-06-22 00:06:47.943132
# Unit test for method print_help of class Parser

# Generated at 2022-06-22 00:06:55.899396
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    expected = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' + \
               '[-l shell-logger] [--enable-experimental-instant-mode] ' + \
               '[-y | -r] [-d] [--force-command FORCE-COMMAND] ' + \
               '[--] [command [command ...]]\n'
    actual = StringIO()
    sys.stderr = actual
    parser = Parser()
    parser.print_usage()
    output = actual.getvalue()
    assert output == expected


# Generated at 2022-06-22 00:07:01.996572
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import test

    out, err = test(lambda: Parser().print_usage())
    assert err == 'Usage: thefuck [--enable-experimental-instant-mode] [-y | -r] [-d] [--shell-logger SHELL_LOGGER] [--force-command FORCE_COMMAND] [-a] [-h] [--] [command]\n'



# Generated at 2022-06-22 00:07:09.997657
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '--debug', '-a'])
    assert args.alias == get_alias(), 'default value for -a'
    assert args.debug, '-d'
    assert args.command == ['ls'], 'command'

    args = parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER, '--debug'])
    assert args.alias == get_alias(), 'default value for -a'
    assert args.debug, '-d'
    assert args.command == ['ls'], 'command'

    args = parser.parse(['thefuck', 'ls', '--debug', ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-22 00:07:11.303739
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-22 00:07:15.692653
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:07:21.876541
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['thefuck', "echo 'fuck'", "echo 'caca'", "echo 'test'"])
    assert args.command[0] == "echo 'fuck'"
    args = Parser().parse(['thefuck', "echo 'fuck'" , ARGUMENT_PLACEHOLDER, "echo 'caca'", "echo 'test'"])
    assert args.command[0] == "echo 'caca'"


# Generated at 2022-06-22 00:07:22.811461
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser # just in case

# Generated at 2022-06-22 00:07:24.150261
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-22 00:07:33.314662
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from sys import stderr

    out = StringIO()
    stderr.write = out.write
    stderr.flush = lambda: None

    pars = Parser()
    pars.print_usage()

    usage = out.getvalue()

    assert usage.startswith('usage: ' + pars._parser.prog)
    assert '--force-command COMMAND' in usage
    assert '[-h] [--shell-logger FILE]' in usage
    assert '[-y] [-r] [-d]' in usage
    assert '[COMMAND]' in usage


# Generated at 2022-06-22 00:07:37.301635
# Unit test for constructor of class Parser
def test_Parser():
    argv = '-v -h -a --alias=what -l what_is_it --force-command=what_is_it -d -y -r --enable-experimental-instant-mode'.split()
    Parser().parse(argv)


# Generated at 2022-06-22 00:07:45.385195
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'you', '--yes']) == \
        parser.parse(['fuck', 'you', '--', '--yes'])
    assert parser.parse(['fuck', 'you', '--', '--yes']) == \
        parser.parse(['fuck', 'you', '--yes'])
    assert parser.parse(['fuck', 'you', '--yes']) == \
        parser._parser.parse_args(['--yes'])

# Generated at 2022-06-22 00:07:47.666920
# Unit test for method parse of class Parser
def test_Parser_parse():
	return Parser().parse("fuck -a -l --enable-experimental-instant-mode --help -d helloworld")



# Generated at 2022-06-22 00:07:54.645303
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    p = parser.parse(['thefuck', 'ls', '-l'])
    assert p.debug == False
    assert p.force_command is None
    assert p.command == ['ls', '-l']

    p = parser.parse(['thefuck', 'ls', '-l', '--debug', '--force-command',
                      'python test.py'])
    assert p.debug == True
    assert p.force_command == 'python test.py'
    assert p.command == ['ls', '-l']

# Generated at 2022-06-22 00:08:06.907364
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert ('cd' == Parser().parse([__file__, 'cd']).command)
    assert ('-l' == Parser().parse([__file__, '-l']).command)
    assert ('cd' == Parser().parse([__file__, 'cd', ARGUMENT_PLACEHOLDER, '-v']).command)
    assert ([] == Parser().parse([__file__, 'cd', '-l', ARGUMENT_PLACEHOLDER, '-v']).command)
    assert ('--' == Parser().parse([__file__, 'cd', '-l', ARGUMENT_PLACEHOLDER, '--', '-v']).command)

# Generated at 2022-06-22 00:08:15.557372
# Unit test for method parse of class Parser
def test_Parser_parse():
	obj = Parser()
	command = obj.parse(sys.argv)
	assert command == 0

# Generated at 2022-06-22 00:08:19.959523
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    with patch('sys.stderr', new_callable=StringIO) as fakeOutput:
        Parser().print_help()
    help_str = fakeOutput.getvalue()
    assert "show program's version number and exit" in help_str
    assert "ignore arguments of `command`" in help_str

# Generated at 2022-06-22 00:08:20.513024
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:08:21.301084
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()


# Generated at 2022-06-22 00:08:25.648948
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert "usage: thefuck [-v] [-a [custom-alias-name]]\
 [-l shell-logger] [--enable-experimental-instant-mode] [-h]\
 [-y] [-r] [-d] [--force-command force-command] [command ...]" == parser.print_usage()


# Generated at 2022-06-22 00:08:26.454773
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser


# Generated at 2022-06-22 00:08:31.844765
# Unit test for method parse of class Parser
def test_Parser_parse():
    try:
        Parser().parse(["fuck", "some_command", "arg1", "arg2"])
        Parser().parse(["fuck", "some_command", "arg1", ARGUMENT_PLACEHOLDER, "arg2", "--", "--some-command-argument"])
        Parser().parse(["fuck", "some_command", "arg1", ARGUMENT_PLACEHOLDER, "arg2", "--", "arg3", "arg4"])
        Parser().parse(["fuck", "some_command", "--", "arg1", ARGUMENT_PLACEHOLDER, "arg2", "arg3", "arg4"])
    except:
        print("Parser.parse test failed")
        raise


# Generated at 2022-06-22 00:08:33.291047
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    return parser.print_usage()

# Generated at 2022-06-22 00:08:43.070908
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv_1 = ['thefuck', 'ls', '-la']
    argv_2 = ['thefuck', 'ls', '-la', '--', '--help', '--yeah']
    argv_3 = ['thefuck', '--', 'ls', '-la', '--help', '--yeah']
    assert parser.parse(argv_1) == parser._parser.parse_args(argv_1[1:])
    assert parser.parse(argv_2) == parser._parser.parse_args(argv_2[1:])
    assert parser.parse(argv_3) == parser._parser.parse_args(argv_3[1:])


# Generated at 2022-06-22 00:08:54.489705
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    arguments = parser._prepare_arguments(['arg1', 'arg2', '--', 'fuck', '-c', 'cmnd_args'])
    assert arguments == ['arg2', '--', 'arg1', 'fuck', '-c', 'cmnd_args']
    assert parser._parser.parse_args(arguments).command == ['arg1', 'fuck', '-c', 'cmnd_args']

    arguments = parser._prepare_arguments(['arg1', 'arg2', '--', 'fuck', 'arg3', '-c', 'cmnd_args'])
    assert arguments == ['arg2', '--', 'arg1', 'fuck', 'arg3', '-c', 'cmnd_args']

# Generated at 2022-06-22 00:09:06.677264
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from thefuck.parser import Parser
    parser = Parser()
    stderr = StringIO()
    parser.print_help(stderr)
    assert 'usage: thefuck' in stderr.getvalue()

# Generated at 2022-06-22 00:09:07.590571
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()



# Generated at 2022-06-22 00:09:15.723979
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'sudo', 'reboot'])
    assert [arguments.command, arguments.yes, arguments.repeat] == [['sudo', 'reboot'], False, False]

    arguments = parser.parse(['thefuck', 'sudo', 'reboot', '-r'])
    assert [arguments.command, arguments.yes, arguments.repeat] == [['sudo', 'reboot'], False, True]

    arguments = parser.parse(['thefuck', 'sudo', 'reboot', '#', 'fuck'])
    assert [arguments.command, arguments.yes, arguments.repeat] == [['reboot'], False, False]

    arguments = parser.parse(['thefuck', 'sudo', 'reboot', '#', 'fuck', '--', '-r'])

# Generated at 2022-06-22 00:09:16.967883
# Unit test for constructor of class Parser
def test_Parser():
    Parser()
    pass


# Generated at 2022-06-22 00:09:21.030981
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser._parser.print_help = lambda f: f.write('Help\n')
    output = StringIO()
    parser.print_help(output)
    assert output.getvalue() == 'Help\n'

# Generated at 2022-06-22 00:09:22.296164
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()  # can be removed

# Generated at 2022-06-22 00:09:23.716965
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)

# Generated at 2022-06-22 00:09:25.864145
# Unit test for constructor of class Parser
def test_Parser():
    myparser = Parser()
    myparser.parse(sys.argv)
    
    
    

# Generated at 2022-06-22 00:09:26.303760
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:09:32.096585
# Unit test for method print_help of class Parser
def test_Parser_print_help():

    import sys
    import contextlib
    from io import StringIO

    output = StringIO()

    @contextlib.contextmanager
    def capture_output():
        oldout,olderr = sys.stdout, sys.stderr
        try:
            out=[StringIO(), StringIO()]
            sys.stdout,sys.stderr = out
            yield out
        finally:
            sys.stdout,sys.stderr = oldout, olderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()

    with capture_output() as out:
        parser = Parser()
        parser.print_usage()


# Generated at 2022-06-22 00:09:51.583150
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = parser.print_help()
    assert output == None

# Generated at 2022-06-22 00:09:56.643171
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['python', '-v', 'fuck', '--debug', '--', 'ls', '-a']
    parser = Parser()
    args = parser.parse(argv)
    assert args.version, "args.version must be True"
    assert args.debug, "args.debug must be True"
    assert args.command == ['ls', '-a']

# Generated at 2022-06-22 00:10:07.965798
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()

    # Test the command line arguments

# Generated at 2022-06-22 00:10:18.804548
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    This test uses a mocking library to test the functionality which uses
    sys.stderr.write by injecting a mock object instead of the real stderr.
    sys.stderr is used by function print_usage of class Parser
    This is a unittest for method print_usage of class Parser
    """
    from mock import patch
    from StringIO import StringIO
    from argparse import ArgumentParser

    mock_argparse = StringIO()
    parser = ArgumentParser()
    with patch('sys.stderr', mock_argparse):
        parser.print_usage()


# Generated at 2022-06-22 00:10:19.631634
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:10:25.242355
# Unit test for method parse of class Parser
def test_Parser_parse():
    arguments = ['--alias=fuck', '-v', '--version', '-h', '--help', '--force-command', 'git']

    args = Parser().parse(arguments)

    assert args.version is True
    assert args.alias == 'fuck'
    assert args.help is True
    assert args.force_command == 'git'
    assert args.command == []

# Generated at 2022-06-22 00:10:26.407482
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    _Parser = Parser()
    _Parser.print_help()


# Generated at 2022-06-22 00:10:28.908472
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser is not None and isinstance(p._parser, ArgumentParser)


# Generated at 2022-06-22 00:10:39.781411
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from thefuck.utils import wrap_streams
    from contextlib import contextmanager

    @contextmanager
    def fake_streams():
        sys.stderr = StringIO()
        try:
            yield
        finally:
            sys.stderr = sys.__stderr__

    with wrap_streams():
        with fake_streams():
            parser = Parser()
            parser.print_usage()
            assert sys.stderr.getvalue()=='usage: thefuck [-h] [-v] [-a] [-l] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--yes] [--repeat] command [command ...]\n'


# Generated at 2022-06-22 00:10:42.180030
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None
    assert parser._parser is not None

if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-22 00:11:34.146623
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv = ['thefuck', '--help']
    test_std_out = StringIO()
    old_std_out = sys.stdout
    sys.stdout = test_std_out

    parser = Parser()
    parser.print_usage()
    test_std_out.seek(0)
    print (test_std_out.read())
    sys.stdout = old_std_out


# Generated at 2022-06-22 00:11:43.921631
# Unit test for method parse of class Parser

# Generated at 2022-06-22 00:11:45.043894
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
        parser = Parser()
        assert parser.print_usage() == None


# Generated at 2022-06-22 00:11:50.101398
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    expected = "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [--enable-experimental-instant-mode] [-l shell-logger] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n"
    assert Parser().print_usage() == expected

# Generated at 2022-06-22 00:11:55.786948
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'fuck', 'this']) == 1
    assert parser.parse(['fuck', 'ls', '--help']) == 2
    assert parser.parse(['fuck', 'git', 'push', '--force', '--alias']) == 3
    assert parser.parse(['fuck', '--alias']) == 4
    assert parser.parse(['fuck', '--shell-logger', './shell.log']) == 5



# Generated at 2022-06-22 00:11:57.502536
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    print (parser.print_help())

# Generated at 2022-06-22 00:12:05.827381
# Unit test for constructor of class Parser
def test_Parser():
    # Test for checking if the constructor for the class Parser creates the
    # correct object, not just any random object for the given input
    def test_Parser_for_positive_case():
        p = Parser()
        assert(p.__class__.__name__ == 'Parser')
    # Test for checking if the constructor for the class Parser creates the
    # correct object, not just any random object for the given input
    def test_Parser_for_negative_case():
        p = Parser()
        assert(p.__class__.__name__ == 'Parser1')

    test_Parser_for_positive_case()
    test_Parser_for_negative_case()

# Generated at 2022-06-22 00:12:14.709503
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Given
    argv = [
        "python",
        "-a",
        "fuck",
        "--force-command",
        "echo",
        "--",
        "some",
        "arguments",
        "with",
        "command",
        "--flag"
    ]
    parser = Parser()

    # When
    args = parser.parse(argv)

    # Then
    assert args.alias == "fuck"
    assert args.force_command == "echo"
    assert args.command == [
        "some",
        "arguments",
        "with",
        "command",
        "--flag"
    ]

# Generated at 2022-06-22 00:12:25.119007
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import BytesIO
    from thefuck.shells import Shell
    from thefuck.types import Settings
    from thefuck.main import _get_settings
    import sys

    shell = Shell()
    settings = _get_settings()

# Generated at 2022-06-22 00:12:26.411945
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:14:29.740767
# Unit test for constructor of class Parser
def test_Parser():
    argv = ['python', '/usr/bin/thefuck', 'sudo', 'ls', '-alh']
    arguments = Parser().parse(argv)
    assert arguments.shell_logger is None
    assert arguments.enable_experimental_instant_mode is None
    assert arguments.debug is None
    assert arguments.force_command is None
    assert arguments.command == ['sudo', 'ls', '-alh']


# Generated at 2022-06-22 00:14:32.930003
# Unit test for constructor of class Parser
def test_Parser():
    a_parser = Parser()
    assert a_parser.parse(['-v'])

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-22 00:14:43.420907
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([sys.argv[0], 'ls', ARGUMENT_PLACEHOLDER, '--verbose']) == parser.parse([sys.argv[0], '--', 'ls', '--verbose'])
    assert parser.parse([sys.argv[0], 'ls', '--verbose']) == parser.parse([sys.argv[0], '--', 'ls', '--verbose'])
    assert parser.parse([sys.argv[0], ARGUMENT_PLACEHOLDER, '--verbose']) == parser.parse([sys.argv[0], '--', '--verbose'])

# Generated at 2022-06-22 00:14:44.528812
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert type(p) == Parser


# Generated at 2022-06-22 00:14:45.289078
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    print (Parser().print_help())


# Generated at 2022-06-22 00:14:49.719744
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Given
    class stderr(object):
        def write(self, message):
            return True

    with patch('sys.stderr', new_callable=stderr):
        parser = Parser()

        # When
        result = parser.print_usage()

        # Then
        assert(result is True)



# Generated at 2022-06-22 00:14:57.819848
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """ Unit test for method print_usage of class Parser. """

    # create a parser object
    parser = Parser()

    # create a pseudo stdout
    sys.stderr = sys.stdout
    # call the method print_usage
    parser.print_usage()
    # test if the output is the expected one
    assert sys.stdout.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\
 [-l shell-logger] [--enable-experimental-instant-mode] [-d] [-y] [-r] [--force-command FORCE-COMMAND]\
 [--] [command [command ...]]\n'


# Generated at 2022-06-22 00:15:09.083092
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['--help']) == Namespace(help=True)
    assert parser.parse(['--version']) == Namespace(version=True)
    assert parser.parse(['--alias']) == Namespace(alias=get_alias())
    assert parser.parse(['--alias', 'fuck']) == Namespace(alias='fuck')
    assert parser.parse(['--enable-experimental-instant-mode']) == Namespace(enable_experimental_instant_mode=True)
    assert parser.parse(['--repear']) == Namespace(repeat=True)
    assert parser.parse(['--yeah']) == Namespace(yeah=True)
    assert parser.parse(['-d']) == Namespace(debug=True)

# Generated at 2022-06-22 00:15:11.972283
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    return a


# Generated at 2022-06-22 00:15:18.107348
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    text = None
    with open("log.txt", "w") as out:
        parser.print_usage()
        with open("log.txt", "r") as logfile:
            text = logfile.read()
    with open("log.txt", "w") as out:
        assert text == parser._parser.format_usage()
