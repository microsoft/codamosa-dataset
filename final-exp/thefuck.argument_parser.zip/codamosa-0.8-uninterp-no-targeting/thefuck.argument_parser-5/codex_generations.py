

# Generated at 2022-06-22 00:05:41.783452
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    stdout = sys.stderr
    sys.stderr = open('test-Parser-print-help.log', 'w')
    parser.print_usage()
    parser.print_help()
    sys.stderr.close()
    sys.stderr = stdout

# Generated at 2022-06-22 00:05:44.638820
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    args = sys.argv
    sys.argv = ['thefuck']
    Parser().print_usage()
    sys.argv = args


# Generated at 2022-06-22 00:05:50.459968
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()

	# Case 1: check that the method is able to extract the placeholder and the
	# command after it.
	args = parser.parse(['fuck', 'git', 'push', 'origin', 'master'])
	assert args.command == ['push', 'origin', 'master']
	assert args.placeholder == []

	# Case 2: check that the method is able to extract the placeholder and the
	# arguments after it.
	args = parser.parse(['fuck', 'git', 'push', 'origin', 'master', '-f'])
	assert args.command == []
	assert args.placeholder == ['-f']

	# Case 3: check that the method is able to extract the placeholder and the
	# command after it, if the command is '--'.

# Generated at 2022-06-22 00:05:53.986060
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import load_help_content
    parser = Parser()
    help_content = load_help_content()

    parser.print_help()
    print(help_content)


# Generated at 2022-06-22 00:05:55.900800
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(["thefuck"]) == None


# Generated at 2022-06-22 00:06:04.450897
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO

    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    stdout = sys.stdout
    sys.stdout = StringIO()
    parser = Parser()
    parser.print_usage()
    out = sys.stdout.getvalue().strip()
    sys.stdout = stdout
    assert out == 'usage: thefuck [-h] [-v] [-y] [-d] [-a [alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [--force-command command] [--] [command [command ...]]', out



# Generated at 2022-06-22 00:06:10.356925
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from mock import patch
    from .test_utils import assert_equals

    parser = Parser()
    with patch.object(parser._parser, 'print_usage') as print_usage:
        parser.print_usage()

    print_usage.assert_called_with(sys.stderr)


# Generated at 2022-06-22 00:06:11.696994
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    print(p)



# Generated at 2022-06-22 00:06:17.405230
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import io
    import contextlib
    p = Parser()
    @contextlib.contextmanager
    def capture():
        oldout,olderr = sys.stdout, sys.stderr
        try:
            out=[io.StringIO(), io.StringIO()]
            sys.stdout,sys.stderr = out
            yield out
        finally:
            sys.stdout,sys.stderr = oldout, olderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()
    with capture() as out:
        p.print_usage()


# Generated at 2022-06-22 00:06:28.283547
# Unit test for method parse of class Parser
def test_Parser_parse():
    # test 1
    argv = ['thefuck', 'ls', '-la']
    argv = Parser()._prepare_arguments(argv)
    assert argv == ['--', 'ls', '-la']
    # test 2
    argv = ['thefuck', 'ls', '-la', 'fuck']
    argv = Parser()._prepare_arguments(argv)
    assert argv == ['ls', '-la', 'fuck', '--']
    # test 3
    argv = ['thefuck', '-v']
    argv = Parser()._prepare_arguments(argv)
    assert argv == ['-v']
    # test 4
    argv = ['thefuck', '-a']
    argv = Parser()._prepare_arguments(argv)
   

# Generated at 2022-06-22 00:06:37.670173
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert type(p._parser) == ArgumentParser
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False
    assert type(p._parser.description) == str
    assert type(p._parser.epilog) == str


# Generated at 2022-06-22 00:06:40.922772
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['-d', '-h', 'ls', '-a', 'fuck'])
    assert args.command == ['ls', '-a', 'fuck']
    assert args.debug
    assert args.help


# Generated at 2022-06-22 00:06:47.987374
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['-l','hey','--','git','--help'])
    assert args.shell_logger == 'hey'
    assert not args.yes
    assert not args.repeat
    assert not args.help
    assert not args.debug
    assert not args.alias
    assert not args.version
    assert not args.force_command
    assert args.command == ['git', '--help']


# Generated at 2022-06-22 00:06:58.264297
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    history = ['git push origin branch', 'ls']

# Generated at 2022-06-22 00:07:01.293931
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    # parser.print_usage(sys.stderr)



# Generated at 2022-06-22 00:07:08.248430
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    f = open('thefuck-parser-testfile.help', 'w')
    Parser().print_help()
    old_stdout = sys.stdout
    sys.stdout = f
    Parser().print_help()
    sys.stdout = old_stdout
    f.close()
    error = False
    with open('thefuck-parser-testfile.help', 'r') as f:
        if len(f.readlines()) != 0:
            error = True
    os.remove('thefuck-parser-testfile.help')
    return error


# Generated at 2022-06-22 00:07:19.081814
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from cStringIO import StringIO
    from thefuck.utils import get_alias
    from thefuck.settings import load_settings
    from thefuck.shells import available_shells
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.bash import Bash
    from thefuck.shells.fish import Fish
    from thefuck.shells.tcsh import Tcsh
    from thefuck.shells.powershell import Powershell
    from thefuck.shells.xonsh import Xonsh
    alias = get_alias()
    settings = load_settings()
    disabled_rules = ', '.join(settings.get('disabled_rules', ()))
    enabled_rules = ', '.join(settings.get('rules', ()) or disabled_rules)
    parser = Parser()
    parser._parser.prog

# Generated at 2022-06-22 00:07:21.217959
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:07:22.953225
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['nothing', 'to', 'parse']) == ['nothing', 'to', 'parse']



# Generated at 2022-06-22 00:07:26.846541
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck','echo','a','esc','cd']) == parser.parse(['thefuck','echo','a','esc','cd'])


# Generated at 2022-06-22 00:07:46.805242
# Unit test for constructor of class Parser
def test_Parser():
    al= 'fuck'
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._add_arguments() == None
    assert parser._add_conflicting_arguments() == None
    assert parser._prepare_arguments([al]) == [al]
    assert parser._prepare_arguments(['-d']) == ['-d']
    assert parser._prepare_arguments([]) == []
    assert parser.print_usage() == None
    assert parser.print_help() == None
    assert parser.parse([al]) == Namespace(alias=None)

# Generated at 2022-06-22 00:07:56.472743
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # argv has ARGUMENT_PLACEHOLDER
    arguments = parser.parse(['thefuck', '-y', ARGUMENT_PLACEHOLDER, 'ls', '-l'])
    assert arguments.yes
    assert arguments.command == ['ls', '-l']

    # argv has no ARGUMENT_PLACEHOLDER but has command
    arguments = parser.parse(['thefuck', '-y', 'ls', '-l'])
    assert arguments.yes
    assert arguments.command == ['ls', '-l']

    # argv has no ARGUMENT_PLACEHOLDER, only an argument
    arguments = parser.parse(['thefuck', '-y'])
    assert arguments.yes
    assert arguments.command == []


# Generated at 2022-06-22 00:07:58.670981
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:08:01.514444
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    #Check if the method print_usage of class Parser is working fine
    _Parser = Parser()
    _Parser.print_usage()

# Generated at 2022-06-22 00:08:02.423419
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:08:10.634585
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    output = StringIO()

    parser = Parser()
    parser.print_usage(file=output)

    assert output.getvalue() == \
        'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n' \
        '              [--enable-experimental-instant-mode] [-y] [-r]\n' \
        '              [-d] [--force-command FORCE_COMMAND]\n' \
        '              [command [command ...]]\n'


# Generated at 2022-06-22 00:08:12.767363
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    testParser = Parser()
    testParser.print_usage()


# Generated at 2022-06-22 00:08:15.332336
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv.append('-d')
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-22 00:08:17.921650
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = parser.print_usage()
    assert "optional arguments" in output
    assert "usage: thefuck" in output
    assert "Show this help message and exit." in output


# Generated at 2022-06-22 00:08:27.401846
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_alias
    from io import StringIO
    from .const import ARGUMENT_PLACEHOLDER
    from src.fuck import Parser
    test_args = ['thefuck']
    test_argv = test_args + [ARGUMENT_PLACEHOLDER]

# Generated at 2022-06-22 00:08:55.176980
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    from .utils import capture
    with capture(Parser().print_usage) as output:
        Parser().print_usage()
    assert output == io.StringIO('''\
usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger]
               [--enable-experimental-instant-mode] [-y|-r] [-d]
               [--force-command force-command]
               [command [command ...]]
''')


# Generated at 2022-06-22 00:09:01.268892
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    # we can not test print_help method directly,
    # but we can test that it doesn't raise exception
    try:
        parser.print_help()
    except:
        assert False, "Exception occured in print_help()"

    # we can not test print_help method directly,
    # but we can test that it doesn't raise exception
    try:
        parser.print_usage()
    except:
        assert False, "Exception occured in print_usage()"

# Generated at 2022-06-22 00:09:12.907296
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'run', 'ls', '--', '-l']) == \
           parser._parser.parse_args(['--', 'ls', '-l'])
    assert parser.parse(['thefuck', 'run', 'ls', '--', '-l']) == \
           parser._parser.parse_args(['-l'])
    assert parser.parse(['thefuck', 'run', 'ls', '--', '-l']) == \
           parser._parser.parse_args(['--', 'ls', '--', '-l'])
    assert parser.parse(['thefuck', 'run', 'ls', '--', '-l']) == \
           parser._parser.parse_args(['-l', '--', 'ls'])


# Unit

# Generated at 2022-06-22 00:09:21.471528
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    sys.stderr = open("testParser_print_usage.txt", "w")
    p = Parser()
    p.print_usage()
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    fd = open("testParser_print_usage.txt", "r")
    content = fd.read()
    assert 'usage: thefuck' in content
    os.remove("testParser_print_usage.txt")


# Generated at 2022-06-22 00:09:22.300873
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:09:23.668068
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-22 00:09:31.136139
# Unit test for method parse of class Parser
def test_Parser_parse():
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def stdout_io(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    parser = Parser()
    sys.argv = ['true']

    assert [], parser.parse(['']).command
    assert [], parser.parse([]).command

    assert ['ls'], parser.parse(['ls']).command
    assert ['ls'], parser.parse(['ls', ARGUMENT_PLACEHOLDER]).command
    assert ['ls'], parser.parse(['ls', ARGUMENT_PLACEHOLDER, '--']).command

# Generated at 2022-06-22 00:09:39.562786
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    out = StringIO()

    parser = Parser()
    parser.print_usage(file=out)

    out.seek(0)
    assert out.read() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' \
                         '[-l SHELL_LOGGER] [--enable-experimental-instant-mode] ' \
                         '[-d] [--force-command FORCE_COMMAND] [--yes | --hard] ' \
                         '[--repeat] [command [command ...]]\n'



# Generated at 2022-06-22 00:09:46.461429
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import VERSION
    from .utils import wrap_output
    output = wrap_output('''usage: thefuck [-h] [-v] [-a [custom-alias-name]]
                  [-l shell-logger] [--enable-experimental-instant-mode]
                  [-d] [--force-command force-command]
                  [--] [command [command ...]]
''')
    assert output == Parser().print_usage()


# Generated at 2022-06-22 00:09:57.524518
# Unit test for method parse of class Parser
def test_Parser_parse():
    # first statement
    test_argv = ['fuck',
                 '-v',
                 ARGUMENT_PLACEHOLDER,
                 'rm',
                 '-rf',
                 '--',
                 'test.db']
    parser = Parser()
    assert(parser.parse(test_argv) == 'rm')
    # second statement
    test_argv = ['fuck',
                 '-v',
                 ARGUMENT_PLACEHOLDER,
                 'rm',
                 '-rf',
                 'test.db']
    parser = Parser()
    assert(parser.parse(test_argv) == 'rm')
    # third statement

# Generated at 2022-06-22 00:11:10.432468
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-22 00:11:11.701049
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None

# Generated at 2022-06-22 00:11:18.039218
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO
    sys.stderr = StringIO.StringIO()
    args = Parser()
    args.parse(["thefuck","--help"])
    args.print_usage()
    assert "usage: thefuck [-h] [-v] [-a [custom-alias-name]]" \
           " [-l SHELL_LOGGER] [--enable-experimental-instant-mode]" \
           " [-y | -r] [-d] [--force-command FORCE_COMMAND] [--] [command [command ...]]" in sys.stderr.getvalue()


# Generated at 2022-06-22 00:11:28.425456
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    def test_1():
        assert p._parser.parse_args(['--version']) == Namespace(version=True)
    def test_2():
        assert p._parser.parse_args(['-h']) == Namespace(help=True)
    def test_3():
        assert p._parser.parse_args(['-a']) == Namespace(alias=get_alias())
    def test_4():
        assert p._parser.parse_args(['-a', 'alias']) == Namespace(alias='alias')
    def test_5():
        assert p._parser.parse_args(['--force-command', 'git']) == Namespace(force_command='git')
    def test_6():
        assert p._parser.parse_args(['-d']) == Namespace

# Generated at 2022-06-22 00:11:32.101223
# Unit test for method parse of class Parser
def test_Parser_parse():
    sys.argv = ['thefuck',
                'cd', '--', 'a', 'b']
    parser = Parser()
    assert parser.parse(sys.argv) == parser._parser.parse_args(['a', 'b'])

# Generated at 2022-06-22 00:11:36.751156
# Unit test for constructor of class Parser
def test_Parser():
    # test the constructor of Parser class
    parser = Parser()
    assert isinstance(parser, Parser)

    # print help message
    user_argv = ['--help']
    parser.parse(user_argv)
    parser.print_help()

    # test version
    user_argv = ['-v']
    parser.parse(user_argv)
    parser.print_help()



# Generated at 2022-06-22 00:11:38.807947
# Unit test for constructor of class Parser
def test_Parser():
    import argparse
    parser = Parser()
    assert type(parser._parser) == argparse.ArgumentParser


# Generated at 2022-06-22 00:11:48.425460
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from thefuck.utils import wrap_streams
    import sys
    import sys
    from io import StringIO
    with wrap_streams([sys.stdout]):
        p = Parser()
        p.print_usage()
        assert sys.stdout.getvalue().strip() == \
            'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' \
            '[-l SHELL_LOGGER] [--enable-experimental-instant-mode] ' \
            '--force-command COMMAND [-y] [-r] [-d] ' \
            '[--] [command [command ...]]'


# Generated at 2022-06-22 00:11:57.233224
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class _std_out(object):
        def __init__(self):
            self.data = []
        def write(self, s):
            self.data.append(s)
        def __str__(self):
            return ''.join(self.data)

    _stdout = sys.stdout
    sys.stdout = _std_out()


# Generated at 2022-06-22 00:11:58.326021
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser,Parser)
