

# Generated at 2022-06-22 00:05:47.667212
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()



# Generated at 2022-06-22 00:05:58.871990
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    #test with one argument
    test_command = ["-h"]
    parsed_command = parser.parse(test_command)
    assert parsed_command.help
    assert parsed_command.debug == False
    assert parsed_command.shell_logger == None
    assert parsed_command.command == []
    assert parsed_command.alias == None
    assert parsed_command.force_command == None
    assert parsed_command.repeat == False
    assert parsed_command.yes == False
    assert parsed_command.version == False

    #test with multiple arguments

# Generated at 2022-06-22 00:06:00.095773
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-22 00:06:00.903021
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-22 00:06:03.320903
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.prog == 'thefuck'
    assert Parser()._parser.add_help == False


# Generated at 2022-06-22 00:06:09.722619
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    expected_help = 'Usage: thefuck [OPTIONS] [COMMAND [ARGS]...]'
    from io import StringIO
    from contextlib import redirect_stderr

    parser = Parser()
    with redirect_stderr(StringIO()) as stderr:
        parser.print_usage()
        assert expected_help in stderr.getvalue()


# Generated at 2022-06-22 00:06:11.979759
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False

# Generated at 2022-06-22 00:06:16.530215
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-a'])
    assert args.command == ['ls']
    assert args.alias == get_alias()



# Generated at 2022-06-22 00:06:18.165937
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-22 00:06:29.693580
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['script-name', 'ls'])
    assert not arguments.yes
    assert not arguments.shell_logger
    assert not arguments.debug
    assert not arguments.repeat
    assert arguments.command == ['ls']
    assert not arguments.force_command
    assert not arguments.version
    assert not arguments.alias

    arguments = parser.parse(['script-name', '-y', 'ls', '-la'])
    assert arguments.yes
    assert arguments.command == ['ls', '-la']

    arguments = parser.parse(['script-name', '-y', '-s', '-d', 'ls', '-la'])
    assert arguments.yes
    assert arguments.debug
    assert arguments.shell_logger is None

# Generated at 2022-06-22 00:06:49.108571
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from . .test.output_collector import OutputCollector
    from . .test.utils import temp_environ
    from . .test.parser_test_case import ParserTestCase

# Generated at 2022-06-22 00:06:53.135908
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    parser = Parser()
    assert parser.parse(['fuck', 'git', 'diff', ARGUMENT_PLACEHOLDER, '--', '-b', '-w']) == \
           parser._parser.parse_args(['git', 'diff', '--', '-b', '-w'])

# Generated at 2022-06-22 00:06:55.147252
# Unit test for constructor of class Parser
def test_Parser():
	assert Parser() is not None

# Generated at 2022-06-22 00:06:56.550256
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert type(p) == Parser


# Generated at 2022-06-22 00:07:00.247173
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(["thefuck", "fuck"])

# Generated at 2022-06-22 00:07:03.449989
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = sys.stderr.write
    sys.stderr.write = lambda x: None
    parser.print_help()
    sys.stderr.write = output

# Generated at 2022-06-22 00:07:09.470203
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    buffer = StringIO()
    sys.stderr = buffer
    parser.print_usage()
    sys.stderr = sys.__stderr__
    usage = buffer.getvalue()
    assert usage == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' \
                    '              [-l SHELL_LOGGER]\n' \
                    '              [--enable-experimental-instant-mode]\n' \
                    '              [-d] [-y | -r] [--] command ...\n'


# Generated at 2022-06-22 00:07:19.329785
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .main import print_help
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER

    with patch('thefuck.parser.get_alias', return_value='alias') as get_alias_mock,\
            patch('thefuck.parser.print_help') as print_help_mock:
        print_help(None)
        get_alias_mock.assert_called_with()

# Generated at 2022-06-22 00:07:22.952409
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    sys.stderr.write("Test method print_help(self) of class Parser \n")
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-22 00:07:24.217197
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:07:32.134017
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:07:43.091979
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # No arguments
    assert parser.parse([]) == parser._parser.parse_args([])
    # Arguments without placeholder
    assert parser.parse(['-d']) == parser._parser.parse_args(['-d'])
    assert parser.parse(['ls', '-a']) == parser._parser.parse_args(['ls', '-a'])
    # Arguments with placeholder
    assert parser.parse(['ls', ARGUMENT_PLACEHOLDER, '-d']) == \
        parser._parser.parse_args(['-d'])
    assert parser.parse(['ls', ARGUMENT_PLACEHOLDER, 'ls', '-a']) == \
        parser._parser.parse_args(['ls', '-a'])

# Generated at 2022-06-22 00:07:54.035807
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_aliases_path
    from .const import ALIASES
    from .config import reload_config

    parser = Parser()

    # Test for error situation:
    # If missing get_aliases_path, then should print with custom alias

    reload_config(aliases={},
              require_confirmation=False,
                  no_colors=False,
                  wait_command=10,
                  log_file_path='default',
                 
                 )
    def mock_get_aliases_path(mocked):
        # make it invalid
        return ''

    get_aliases_path_original = utils.get_aliases_path
    utils.get_aliases_path = mock_get_aliases_path

# Generated at 2022-06-22 00:07:56.621433
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['thefuck', '--yes', '--', '/bin/bash'])
    assert True

# Generated at 2022-06-22 00:07:58.826270
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()


# Generated at 2022-06-22 00:08:10.134124
# Unit test for method parse of class Parser
def test_Parser_parse():
    def check(arguments, expected):
        parsed = Parser().parse(['fuck'] + arguments)
        assert parsed.command == expected
        assert parsed.alias is None
        assert parsed.shell_logger is None
        assert not parsed.debug
        assert not parsed.help
        assert not parsed.yes
        assert not parsed.version
        assert not parsed.repeat
        assert not parsed.enable_experimental_instant_mode

    check(['alias'], [])
    check(['-a', 'alias'], [])
    check(['--alias', 'alias'], [])
    check(['--alias'], ['alias'])
    check(['-r', 'alias'], [])
    check(['-y', 'alias'], [])
    check(['-v', 'alias'], [])

# Generated at 2022-06-22 00:08:16.138700
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    stderr = sys.stderr
    output = BytesIO()
    try:
        sys.stderr = output
        parser = Parser()
        parser.print_help()
    finally:
        sys.stderr = stderr
    assert b'usage: ' in output.getvalue()

# Generated at 2022-06-22 00:08:25.264578
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # We need to specify length of list of arguments of method parse_args()
    length = len(['--', 'ls'])
    result = parser.parse(['thefuck', ARGUMENT_PLACEHOLDER , 'ls'])
    assert result.command == ['ls']
    assert result.debug == False
    assert result.force_command == None
    assert result.help == False
    assert result.alias == 'fuck'
    assert result.shell_logger == None
    assert result.enable_experimental_instant_mode == False
    assert len(result.command) == length
    assert result.yes == False
    assert result.repeat == False
    assert result.version == False



# Generated at 2022-06-22 00:08:27.502925
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    script_name = 'thefuck'
    args = ['command']
    result = parser.parse([script_name] + args)
    assert result.command == args


# Generated at 2022-06-22 00:08:32.591002
# Unit test for constructor of class Parser
def test_Parser():
    assert sys.argv == ["python", "-m", "thefuck"]
    assert sys.argv[1:] == ["-m", "thefuck"]
    parser = Parser()
    assert parser._parser.prog == "thefuck"
    assert parser._parser.add_help == False

# Generated at 2022-06-22 00:08:49.776633
# Unit test for constructor of class Parser
def test_Parser():
	my_parser = Parser()
	assert my_parser._parser.prog == 'thefuck'

# Generated at 2022-06-22 00:08:50.650383
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-22 00:08:54.919482
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()
    # stdout: 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]
    # [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]
    # [--yes | --repeat] [--] command [command ...]'


# Generated at 2022-06-22 00:08:57.095470
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    assert p.print_usage().__str__() == "usage: thefuck [options] [command]\n"


# Generated at 2022-06-22 00:08:59.992165
# Unit test for method print_help of class Parser

# Generated at 2022-06-22 00:09:11.359864
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from sys import stderr
    from unittest import TestCase, main

    from .parser import Parser

    class ParserTest(TestCase):
        def setUp(self):
            self.stdout = StringIO()
            stderr.write = self.stdout.write

        def test_prints_usage(self):
            Parser().print_help()
            self.assertTrue(self.stdout.getvalue().startswith('usage: thefuck '))

        def test_prints_version_if_version_is_true(self):
            Parser().print_help()
            self.assertTrue(self.stdout.getvalue().count('version') == 2)

    main()


# Generated at 2022-06-22 00:09:22.380789
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from . import parser
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER
    import sys
    import tempfile
    import os
    import re
    import argparse
    parser._parser = argparse.ArgumentParser(prog='thefuck', add_help=False)
    parser._add_arguments()
    stderr_file = tempfile.TemporaryFile()
    parser._parser.print_help(file=stderr_file)
    stderr_file.seek(0, os.SEEK_END)
    print_help_size = stderr_file.tell()
    align_size = (print_help_size + 1) % 80 if print_help_size > 0 else 0

# Generated at 2022-06-22 00:09:29.684052
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class FakeStderr(object):
        ''' Fake stderr file object '''
        def __init__(self):
            self.messages = []

        def write(self, message):
            self.messages.append(message)

        def get_write(self):
            return ''.join(self.messages)

    sys.stderr = FakeStderr()
    parser = Parser()
    parser.print_help()
    assert sys.stderr.get_write() == parser.parse(['thefuck', '-h']).format_help()
    # Restore stderr
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:09:38.401344
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    _old_stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        Parser().print_usage()
        assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n'
    finally:
        sys.stderr = _old_stderr


# Generated at 2022-06-22 00:09:41.830336
# Unit test for constructor of class Parser
def test_Parser():
	parser = Parser()
	argv = ['--force-command', 'ls']
	result = parser.parse(argv)
	expected_result = argparse.Namespace(alias=None, command=None, debug=False, enable_experimental_instant_mode=False, force_command='ls', help=False, repeat=False, shell_logger=None, version=False, yeah=False, yes=False)
	assert result == expected_result

# Generated at 2022-06-22 00:10:23.723551
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    expected = parser._parser.print_usage()
    actual = parser.print_usage()
    assert actual == expected

# Generated at 2022-06-22 00:10:25.560442
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except UnicodeEncodeError:
        exit('FUCK')

# Generated at 2022-06-22 00:10:26.724599
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
   parser = Parser()
   parser.print_usage()


# Generated at 2022-06-22 00:10:34.440850
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    parser = Parser()

    # Arrange
    expected_output = """usage: thefuck [-h] [-v] [-a [custom-alias-name]]
                      [-l SHELL_LOGGER]
                      [--enable-experimental-instant-mode] [-d] [-y | -r]
                      [--force-command FORCE_COMMAND]
                      [command [command ...]]
    """

    # Act
    parser.print_usage()

    # Assert
    assert expected_output == sys.stderr.getvalue().strip()

# Generated at 2022-06-22 00:10:43.794278
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_alias
    parser = Parser()
    expected_pattern = re.compile(
        r'^usage: thefuck \[\-' + get_alias() + r'\] \[-h\] \[-v\]'
        r' \[-a \[' + get_alias() + r'\]\] \[-l SHELL_LOGGER\]'
        r' \[-y\] \[-r\] \[--enable-experimental-instant-mode\]'
        r' \[--debug\] ' + ARGUMENT_PLACEHOLDER + r' \[command \.\.\.\]')
    assert (expected_pattern.match(parser.print_help()))



# Generated at 2022-06-22 00:10:46.924814
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser.subparsers == None
    assert parser._parser.version == None

# Generated at 2022-06-22 00:10:50.224003
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = '--force-command "command" --debug'
    args = parser.parse(argv.split())
    assert args.force_command == 'command'
    assert args.debug



# Generated at 2022-06-22 00:10:53.248649
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    output_file = StringIO.StringIO()
    with patch('sys.stderr', output_file):
        Parser().print_usage()
    assert 'usage: thefuck [-h] [-v] [-a [CUSTOM-ALIAS-NAME]]' in output_file.getvalue()


# Generated at 2022-06-22 00:11:04.507462
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['thefuck', '--script', 'echo', 'hello', 'world', '&&', 'echo', 'you', ARGUMENT_PLACEHOLDER, '1', '2', '3'])
    assert args.script == 'echo'
    assert args.command == ['hello', 'world', '&&', 'echo', 'you']
    assert args.debug is False
    assert args.debug is False
    assert args.force_command is None
    assert args.help is False
    assert args.shell_logger is None
    assert args.version is False
    assert args.alias is None
    assert args.yes is False
    assert args.repeat is False
    assert args.enable_experimental_instant_mode is False


# Generated at 2022-06-22 00:11:14.358247
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', 'git', 'brnch', '-l', 'file', '-v', '--alias', 'alias']

    parser = Parser()
    namespace = parser.parse(argv)

    assert namespace.command == ['git', 'brnch']
    assert namespace.shell_logger == 'file'
    assert namespace.version

    assert not namespace.repeat
    assert not namespace.debug
    assert not namespace.help
    assert not namespace.force_command
    assert not namespace.enable_experimental_instant_mode
    assert namespace.alias == 'alias'



# Generated at 2022-06-22 00:12:00.873737
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-22 00:12:05.496684
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck',
                         'cd',
                         ARGUMENT_PLACEHOLDER,
                         '--debug']) == parser.parse(['thefuck',
                                                      '--debug',
                                                      'cd'])

# Generated at 2022-06-22 00:12:13.746902
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    import sys
    sys.stderr = io.StringIO()
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n            [-l SHELL_LOGGER]\n            [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n            [command [command ...]]\n'
    sys.stderr = sys.__stderr__


# Generated at 2022-06-22 00:12:14.201697
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-22 00:12:17.156927
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert ['--'] + ['--debug'] + ['--force-command'] + ['echo'] == parser._prepare_arguments(['--debug'] + ['--force-command'] + [ARGUMENT_PLACEHOLDER] + ['echo'])
    assert [ARGUMENT_PLACEHOLDER] + ['echo'] == parser._prepare_arguments([ARGUMENT_PLACEHOLDER] + ['echo'])
    assert ['echo'] == parser._prepare_arguments(['echo'])
    assert [] == parser._prepare_arguments([])

# Generated at 2022-06-22 00:12:20.575761
# Unit test for constructor of class Parser
def test_Parser():
    P = Parser()

    assert P._parser.prog == 'thefuck'

    assert '--version' in P._parser._actions
    assert '-v' in P._parser._actions

# Generated at 2022-06-22 00:12:29.524016
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from cStringIO import StringIO

    output = StringIO()
    sys.stderr = output

    parser = Parser()
    parser.print_help()
    assert '--alias [custom-alias-name]' in output.getvalue()
    assert '--enable-experimental-instant-mode' in output.getvalue()
    assert '-h, --help' in output.getvalue()
    assert '-r, --repeat' in output.getvalue()
    assert '--shell-logger' in output.getvalue()
    assert '-v, --version' in output.getvalue()
    assert '-y, --yes, --yeah, --hard' in output.getvalue()

# Generated at 2022-06-22 00:12:38.077292
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['what', 'is', 'my', 'ip']) == \
        Namespace(alias=get_alias(),
                  command=['what', 'is', 'my', 'ip'],
                  debug=False,
                  enable_experimental_instant_mode=False,
                  help=False,
                  repeat=False,
                  shell_logger=None,
                  version=False,
                  yes=False)

# Generated at 2022-06-22 00:12:41.769255
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Parser.print_usage(None) # Trigger __init__ of Parser
    parser = Parser()
    parser.print_usage()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-22 00:12:42.876851
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-22 00:14:41.065541
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import _
    from .settings import Settings
    from . import __version__ as version

    parser = Parser()
    out = sys.stdout
    with open('./test/test_help.txt', "w") as f:
        sys.stdout = f
        parser.print_help()
        sys.stdout = out
    with open('./test/test_help.txt', encoding='utf-8') as f:
        data = f.read()
    assert _(Settings().HELP_MESSAGE) in data
    assert version in data
    assert '-a [custom-alias-name] prints alias for current shell' in data
    assert '-y, --yes, --yeah, --hard  execute fixed command without confirmation' in data


# Generated at 2022-06-22 00:14:51.214945
# Unit test for constructor of class Parser
def test_Parser():
    if __name__ == '__main__':
        from unittest import TestCase, skipIf, skipUnless, main
    else:
        from unittest2 import TestCase, skipIf, skipUnless

    argv = ['/usr/local/bin/fuck', 'echo', 'hello', 'world']

    class ParserTest(TestCase):

        def setUp(self):
            self.parser = Parser()

        @skipUnless(__name__ == '__main__',
                    'unit test not intended to be run as script')
        def test_prepare_arguments_with_argument_placeholder(self):
            args = self.parser._prepare_arguments(
                argv[:3] + [ARGUMENT_PLACEHOLDER] + argv[3:])

# Generated at 2022-06-22 00:14:53.588947
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser(['-v', '-a'])
test_Parser()

# Generated at 2022-06-22 00:15:00.674339
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck'])
    parser.parse(['thefuck', '-a'])
    parser.parse(['thefuck', '-d'])
    parser.parse(['thefuck', '-h'])
    parser.parse(['thefuck', '-l', 'log.txt'])
    parser.parse(['thefuck', '-r'])
    parser.parse(['thefuck', '-v'])
    parser.parse(['thefuck', '-y'])
    parser.parse(['thefuck', '--', 'echo', 'fuck'])
    parser.parse(['thefuck', 'fuck'])
    parser.parse(['thefuck', 'echo', 'fuck'])
    parser.parse(['thefuck', ' --alias=fucker'])
    parser

# Generated at 2022-06-22 00:15:09.512220
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['-y']) == parser._parser.parse_args(['-y'])
    assert parser.parse(['-y', '-d']) == parser._parser.parse_args(['-y', '-d'])
    assert parser.parse(['echo', ARGUMENT_PLACEHOLDER, 'foo', 'bar']) == parser._parser.parse_args(['foo', 'bar', '--', 'echo'])
    assert parser.parse(['echo', 'fake-argument', ARGUMENT_PLACEHOLDER, 'foo']) == parser._parser.parse_args(['fake-argument', 'foo', '--', 'echo'])

# Generated at 2022-06-22 00:15:12.040115
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-22 00:15:18.361721
# Unit test for method parse of class Parser
def test_Parser_parse():
    test_argv = ['thefuck', 'echo', 'foo', 'bar', ARGUMENT_PLACEHOLDER, '-y', '--log', '-h']
    expected_argv = ['--', '-y', '--log', '-h', 'echo', 'foo', 'bar']
    parser = Parser()
    assert(expected_argv == parser._prepare_arguments(test_argv))

# Generated at 2022-06-22 00:15:25.625258
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    stdout_ = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    try:
        parser = Parser()
        parser.print_help()
    except:
        assert False
    finally:
        sys.stdout.close()
        sys.stdout = stdout_

# Generated at 2022-06-22 00:15:29.312440
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .thefuck import TheFuck

    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_help()
    out.seek(0)
    assert out.read() == TheFuck.print_help()


# Generated at 2022-06-22 00:15:39.209969
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['--repeat', '--', 'lsa', '-l']
    parser = Parser()
    assert parser.parse(args) == parser._parser.parse_args(['--repeat', '--'])

    test_args = ['--', 'thefuck', '--repeat', 'lsa', '-l']
    assert parser.parse(test_args) == parser._parser.parse_args(['--repeat'])

    test_invalid_args = ['--', 'thefuck', '--repeat', '--yes', 'lsa', '-l']
    with pytest.raises(SystemExit):
        parser.parse(test_invalid_args)
