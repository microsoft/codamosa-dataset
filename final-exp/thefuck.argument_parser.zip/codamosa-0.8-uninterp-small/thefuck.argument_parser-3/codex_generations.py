

# Generated at 2022-06-26 04:29:52.774413
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Create parser object
    parser_1 = Parser()
    # Test case_0
    args_0 = parser_1.parse(['apt-get', 'install', 'python3-pip', '--version'])
    assert args_0.version == '--version'


# Generated at 2022-06-26 04:29:53.926901
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:29:55.544415
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

    assert parser


# Generated at 2022-06-26 04:29:59.834758
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:30:01.419299
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:06.913931
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print("test_Parser_print_usage start ...")

    parser_0 = Parser()
    parser_0.print_usage()
    print("test_Parser_print_usage end")


# Generated at 2022-06-26 04:30:11.531665
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser._parser.print_usage = mock.Mock(return_value = None)
    parser.print_usage()
    parser._parser.print_usage.assert_called_with(sys.stderr)


# Generated at 2022-06-26 04:30:12.661674
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:22.090826
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(['/usr/local/bin/thefuck', 'ls', '-l'])
    assert args.command == 'ls -l'
    args = parse_1.parse(['/usr/local/bin/thefuck', 'ls', '-l', '-d', '-v'])
    assert args.command == 'ls -l'
    assert args.debug == True
    assert args.version == True

# Generated at 2022-06-26 04:30:25.751270
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
   

# Generated at 2022-06-26 04:30:35.324683
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_case_0()


# Generated at 2022-06-26 04:30:43.541606
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    argv = ["fuck", "-a"]
    assert parser.parse(argv).alias is None

    argv = ["fuck", "-l", "/home/user/log.file"]
    assert parser.parse(argv).shell_logger == "/home/user/log.file"
    assert parser.parse(argv).enable_experimental_instant_mode is False

    argv = ["fuck", "--yes"]
    assert parser.parse(argv).yes is True
    assert parser.parse(argv).repeat is False

    argv = ["fuck", "-y"]
    assert parser.parse(argv).yes is True
    assert parser.parse(argv).repeat is False

    argv = ["fuck", "-r"]
    assert parser.parse(argv).yes is False

# Generated at 2022-06-26 04:30:52.947700
# Unit test for method parse of class Parser
def test_Parser_parse():
    import sys
    import os
    from subprocess import Popen, PIPE
    from .utils import load_settings, get_all_executables
    from .how_to_configure import rules
    from .utils import wrap_settings
    from .const import ALIAS, FIRST_LINE
    from .parser import Parser
    from .utils import replace_argument, replace_command
    from .utils import get_aliases
    from .const import DEFAULT_COMMAND_ORDER
    from .rules import get_command_order
    from .corrector import Corrector
    from .utils import get_history_without_current
    from .utils import get_all_matched_commands
    
    

# Generated at 2022-06-26 04:30:54.046757
# Unit test for method parse of class Parser
def test_Parser_parse():
    pass

# Generated at 2022-06-26 04:31:06.001198
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck','--version'])
    assert args.version == True

    args = parser.parse(['thefuck','--shell-logger', 'log.txt'])
    assert args.shell_logger == 'log.txt'

    args = parser.parse(['thefuck','--alias','ls'])
    assert args.alias == 'ls'

    args = parser.parse(['thefuck','--alias'])
    assert args.alias == 'fuck'

    args = parser.parse(['thefuck','--debug'])
    assert args.debug == True

    args = parser.parse(['thefuck','./test_case_Parser.py', '--repeat'])
    assert args.repeat == True


# Generated at 2022-06-26 04:31:10.644201
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser.prog == 'thefuck'
    assert parser_0._parser.add_help



# Generated at 2022-06-26 04:31:13.787928
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    res = parser_0.print_usage()
    assert res == None


# Generated at 2022-06-26 04:31:17.132551
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    c = parser_1.print_usage()
    


# Generated at 2022-06-26 04:31:20.215261
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:31:27.295187
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert type(parser) is Parser
    assert type(parser._add_arguments()) is None
    assert type(parser._add_conflicting_arguments()) is None
    assert type(parser._prepare_arguments([])) is list
    assert type(parser.parse([])) is argparse.Namespace
    assert type(parser.print_usage()) is None
    assert type(parser.print_help()) is None


# Generated at 2022-06-26 04:31:41.132049
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    res_0 = parser_0.parse(['ls', 'st'])
    assert res_0.command == ['ls', 'st']
    res_1 = parser_0.parse(['--help'])
    assert res_1.help
    res_2 = parser_0.parse(['--alias'])
    assert res_2.alias == 'fuck'
    res_3 = parser_0.parse(['-v'])
    assert res_3.version
    res_4 = parser_0.parse(['--alias', 'alias'])
    assert res_4.alias == 'alias'
    res_5 = parser_0.parse(['--alias', 'alias'])
    res_5.shell_logger == 'alias.log'


# Generated at 2022-06-26 04:31:54.309075
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()

    test_case_0()
    try:
        parser_1.parse(None)
        print("Cannot parse None")
        assert False
    except SystemExit as e:
        print(e)

    try:
        parser_1.parse(["thefuck"])
        print("Cannot parse [thefuck]")
        assert False
    except SystemExit as e:
        print(e)

    try:
        parser_1.parse(["thefuck", "--alias"])
        print("Cannot parse [thefuck, --alias]")
        assert False
    except SystemExit as e:
        print(e)


# Generated at 2022-06-26 04:32:02.990461
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    sys.argv = ['thefuck', 'git', 'commit']
    args_0 = parser_0.parse(sys.argv)
    if not hasattr(args_0, 'command'):
        print('Failed the case 0 of test_Parser_parse')
        print('The attribute command does not exist')
        print('The attribute command is : %s'%(args_0.command))
    elif not isinstance(args_0.command, list) or len(args_0.command) != 1:
        print('Failed the case 0 of test_Parser_parse')
        print('The attribute command is not a list of 1 elements')
        print('The attribute command is : %s'%(args_0.command))

# Generated at 2022-06-26 04:32:05.641511
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser._parser.format_help() == parser.print_help()


# Generated at 2022-06-26 04:32:13.955765
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser_0 = Parser()
    argv_0 = ['fuck', ARGUMENT_PLACEHOLDER, '-h']
    arguments_0 = parser_0._prepare_arguments(argv_0[1:])
    parser_0._parser.parse_args(arguments_0)
    assert True

if __name__ == '__main__':
    test_case_0()
    test_Parser_parse()

# Generated at 2022-06-26 04:32:15.430177
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:32:21.306699
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    import io
    capturedOutput = io.StringIO()  # Create StringIO object
    sys.stdout = capturedOutput  # and redirect stdout.
    sys.stderr = capturedOutput
    parser_1 = Parser()
    parser_1.print_help()
    output = capturedOutput.getvalue()  # get output
    capturedOutput.truncate(0)
    capturedOutput.seek(0)

# Generated at 2022-06-26 04:32:24.321129
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0._parser.print_usage()


# Generated at 2022-06-26 04:32:26.414270
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-26 04:32:27.826218
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0, Parser) == True


# Generated at 2022-06-26 04:32:44.868114
# Unit test for method parse of class Parser
def test_Parser_parse():
    #Case 1:
    parser_1 = Parser()
    argv_1 = ['thefuck', '-v']
    result_1 = parser_1.parse(argv_1)
    assert(result_1.command == [])
    assert(result_1.version == True)
    assert(result_1.debug == False)
    assert(result_1.alias == None)
    assert(result_1.force_command == None)
    assert(result_1.shell_logger == None)
    assert(result_1.repeat == False)
    assert(result_1.yes == False)
    assert(result_1.help == False)
    assert(result_1.enable_experimental_instant_mode == False)
    #Case 2:
    parser_2 = Parser()
    argv_

# Generated at 2022-06-26 04:32:47.391329
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    assert parser_1.print_usage() == None


# Generated at 2022-06-26 04:32:52.779551
# Unit test for constructor of class Parser
def test_Parser():
    print("test_Parser")

    parser_0 = Parser()
    parser_1 = Parser()
    parser_2 = Parser()
    assert parser_0._parser != parser_1._parser



# Generated at 2022-06-26 04:32:57.318887
# Unit test for constructor of class Parser
def test_Parser():
    # Case 0
    parser_0 = Parser()
    assert parser_0._parser.prog == 'thefuck', 'Wrong prog name'
    assert parser_0._parser.add_help == False, 'Wrong add_help flag'



# Generated at 2022-06-26 04:32:59.462637
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_usage()



# Generated at 2022-06-26 04:33:08.661006
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argv_1 = ['python3', '--force-command', 'echo', 'Hello,world']
    test_1 = parser_1.parse(argv_1)
    assert test_1.debug == False and test_1.force_command == 'echo' and test_1.command == ['Hello,world']

    parser_2 = Parser()
    argv_2 = ['python3', '--force-command', 'df']
    test_2 = parser_2.parse(argv_2)
    assert test_2.debug == False and test_2.force_command == 'df' and test_2.command == []

    parser_3 = Parser()
    argv_3 = ['python3', '--force-command', '-l', '/dev/sda']
    test

# Generated at 2022-06-26 04:33:11.027370
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # make sure that type is correct
    assert isinstance(parser, Parser)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 04:33:14.327381
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_p = Parser()
    parser_p.print_usage()


# Generated at 2022-06-26 04:33:15.763029
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() is not None


# Generated at 2022-06-26 04:33:21.992530
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_ = Parser()
    arg_ = ['/usr/local/bin/thefuck', 'sudo', 'apt-get', 'udpate',
            ARGUMENT_PLACEHOLDER, '&&', 'sudo', 'apt-get', 'install', 'pkgs']
    name_space_ = parser_.parse(arg_)
    error_log_ = open("error.log", "a")
    assert name_space_.command == ['&&', 'sudo', 'apt-get', 'install',
                                   'pkgs'], "Failed to get right command"
    assert name_space_.debug == False, "Failed to parse debug"
    assert name_space_.force_command == None, "Failed to parse force_command"
    assert name_space_.help == False, "Failed to parse help"
    assert name_

# Generated at 2022-06-26 04:33:44.289174
# Unit test for constructor of class Parser
def test_Parser():

    # Test case 0:
    test_case_0()



# Generated at 2022-06-26 04:33:47.667033
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:49.622533
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()




# Generated at 2022-06-26 04:34:01.344538
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    # parser_1 = Parser()
    # parser_1.print_usage()
    parser_1 = Parser()
    out = StringIO()
    sys.stdout = out
    print(parser_1.print_usage())
    output = out.getvalue().strip()
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]'in output
    assert 'stderr.write(self.format_help())' in output
    # testing if the parser prints a help message if no arguments are given
    assert 'error: too few arguments' in output


# Generated at 2022-06-26 04:34:13.070813
# Unit test for method parse of class Parser
def test_Parser_parse():

    # Arguments to test:
    # [+] -h
    # [+] -d
    # [+] -v
    # [+] -a
    # [+] -l
    # [+] --enable-experimental-instant-mode
    # [+] --force-command
    # [+] -y
    # [+] -r
    # [+] --yes
    # [+] --yeah
    # [+] --hard
    # [+] --repeat
    # [+] -y --repeat
    # [+] -r --yes
    # [+] --yes --hard
    # [+] --yeah --repeat

    parser_1 = Parser()
    parser_1.parse("-h")
    parser_1.parse("-d")
    parser_1.parse("-v")
    parser_1.parse("-a")
    parser_1.parse("-l")

# Generated at 2022-06-26 04:34:14.957479
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:34:15.677559
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser != None


# Generated at 2022-06-26 04:34:19.125729
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    command = 'rm -rf /'
    argv = ['fuck', command]
    parser_1.parse(argv)
    print('Done')


# Generated at 2022-06-26 04:34:22.148211
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._optionals.title == 'optional arguments'
    assert parser._parser._positionals.title == 'positional arguments'


# Generated at 2022-06-26 04:34:25.365422
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', 'git', '--', 'ls', '-al'])



# Generated at 2022-06-26 04:35:16.228539
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:21.707395
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    print (parser.parse(['thefuck', '--alias']))
    print (parser.parse(['thefuck', 'ls', '-l']))
    print (parser.parse(['thefuck', '!!']))
    print (parser.parse(['thefuck', 'sudo', 'killall', '-9', 'java']))
    print (parser.parse(['thefuck', 'git', 'add', 'appl.js']))
    print (parser.parse(['thefuck', 'git', 'st', '-s']))
    print (parser.parse(['thefuck', 'git', '--git-dir=.', 'st', '-s']))
    print (parser.parse(['thefuck', 'git', '--git-dir=./foo/bar', 'st', '-s']))

# Generated at 2022-06-26 04:35:28.308583
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Test case 0: Default Setting
    parser_0 = Parser()
    if parser_0.print_help() == None:
        print("Passed test case 0 of Parser.print_help.")
    else:
        print("Failed test case 0 of Parser.print_help.")


# Generated at 2022-06-26 04:35:31.723354
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:34.546848
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:35:39.804951
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(['df', '-h', '-a'])
    parser_1 = Parser()
    parser_1.parse(['pwd'])


# Generated at 2022-06-26 04:35:41.908326
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:35:46.280116
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:48.723538
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert type(parser_0._parser) == ArgumentParser


# Generated at 2022-06-26 04:35:50.381344
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), Parser)



# Generated at 2022-06-26 04:37:44.678908
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:37:47.611808
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1.__class__.__name__ == 'Parser'



# Generated at 2022-06-26 04:37:59.254694
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', '-']) is not None
    assert parser.parse(['fuck', 'path/to/logfile']) is not None
    assert parser.parse(['fuck']) is not None
    assert parser.parse(['fuck', '--alias']) is not None
    assert parser.parse(['fuck', '--help']) is not None
    assert parser.parse(['fuck', '--version']) is not None
    assert parser.parse(['fuck', '--debug']) is not None
    assert parser.parse(['fuck', '-y']) is not None
    assert parser.parse(['fuck', '-r']) is not None
    assert parser.parse(['fuck', '-y', '-r']) is not None

# Generated at 2022-06-26 04:38:06.769728
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse('thefuck --yes '.split(" "))
    assert args.yes
    args = parser.parse('thefuck --yes --debug '.split(" "))
    assert args.yes
    assert args.debug
    args = parser.parse('thefuck -y --debug '.split(" "))
    assert args.yes
    assert args.debug
    args = parser.parse('thefuck --debug -y '.split(" "))
    assert args.yes
    assert args.debug
    args = parser.parse('thefuck echo --yes'.split(" "))
    assert args.yes
    assert not args.debug


# Generated at 2022-06-26 04:38:08.101976
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0,Parser)


# Generated at 2022-06-26 04:38:16.888575
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(["thefuck", "git push --recurse-submodules=check", "--",]) == argparse.Namespace(alias=None, command=['git', 'push', '--recurse-submodules=check'], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    assert parser_1.parse(["thefuck", "--help"]) == argparse.Namespace(alias=None, command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=True, repeat=False, shell_logger=None, version=False, yes=False)

# Generated at 2022-06-26 04:38:19.711962
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()  # test case: if parser is not created
    parser_0.print_usage() # test case: if parser is created
    print("test case 0 of Parser method print_usage is passed")


# Generated at 2022-06-26 04:38:21.521810
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ["thefuck", "find", "--", "test.py"]
    parser_1 = Parser()
    assert parser_1.parse(argv) == parser_1._parser.parse_args(argv[1:])


# Generated at 2022-06-26 04:38:29.410117
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    result_1 = parser_1.parse(['','command','argument1','argument2'])
    assert result_1.command == ['command','argument1','argument2']
    assert result_1.debug == False
    assert result_1.enable_experimental_instant_mode == False
    assert result_1.help == False
    assert result_1.repeat == False
    assert result_1.shell_logger == None
    assert result_1.version == False
    assert result_1.yes == False



# Generated at 2022-06-26 04:38:30.598399
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), Parser)
