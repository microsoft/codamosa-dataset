

# Generated at 2022-06-26 04:29:56.174828
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:01.113309
# Unit test for constructor of class Parser
def test_Parser():
    # Test Case 0
    # Checking initialization of parser object when nothing is given
    test_case_0()


# Generated at 2022-06-26 04:30:03.384274
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0._parser.print_usage = MagicMock()
    parser_0.print_help()
    assert(parser_0._parser.print_usage.call_count == 1)


# Generated at 2022-06-26 04:30:04.213836
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None


# Generated at 2022-06-26 04:30:11.048828
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['--enable-experimental-instant-mode', '--alias'])
    parser.parse(['--yes'])
    parser.parse(['--repeat'])
    parser.parse(['--shell-logger', '--debug', '--force-command'])
    parser.parse(['-h'])
    parser.parse(['-v'])

if __name__ == '__main__':
    #test_case_0()
    test_Parser_parse()

# Generated at 2022-06-26 04:30:13.288836
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.parse(['thefuck', '-h'])
    parser_0.print_help()


# Generated at 2022-06-26 04:30:16.369983
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-26 04:30:20.374865
# Unit test for constructor of class Parser
def test_Parser():
    try:
        parser_0 = Parser()
    except:
        print("Constructor for class Parser not working")
        return False
    return True


# Generated at 2022-06-26 04:30:22.654663
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-26 04:30:26.096577
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:37.212529
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_help = Parser()
    parser_help.print_help()


# Generated at 2022-06-26 04:30:39.571814
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert (type(parser_0) == Parser)


# Generated at 2022-06-26 04:30:52.855106
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args_1 = parser_1.parse(["thefuck", "--version"])
    assert args_1.version == True

    parser_2 = Parser()
    args_2 = parser_2.parse(["thefuck", "--debug"])
    assert args_2.debug == True

    parser_3 = Parser()
    args_3 = parser_3.parse(["thefuck", "--enable-experimental-instant-mode", "--debug"])
    assert args_3.enable_experimental_instant_mode == True
    assert args_3.debug == True

    parser_4 = Parser()
    args_4 = parser_4.parse(["thefuck", "-y", "--version"])
    assert args_4.yes == True

# Generated at 2022-06-26 04:30:54.795059
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None
    parser_0.print_usage()
    parser_0.print_help()


# Generated at 2022-06-26 04:30:56.144771
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()



# Generated at 2022-06-26 04:30:58.901071
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:31:01.428147
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:08.093357
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert parser_0.parse(['thefuck', '-v']) == Namespace(version=True)
    assert parser_0.parse(['thefuck', '-l', 'foo.log']) == Namespace(shell_logger="foo.log")
    assert parser_0.parse(['thefuck', '--shell-logger', '']) == Namespace(shell_logger=None)
    assert parser_0.parse(['thefuck', '--alias']) == Namespace(alias='fuck')
    assert parser_0.parse(['thefuck', '--alias', 'f']) == Namespace(alias='f')
    assert parser_0.parse(['thefuck', '-d']) == Namespace(debug=True)

# Generated at 2022-06-26 04:31:11.943790
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 04:31:19.275331
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(['/usr/local/bin/thefuck', '--alias']) == Namespace(alias='fuck', command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    assert parser_1.parse(['/usr/local/bin/thefuck', '--alias', 'fuck']) == Namespace(alias='fuck', command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)

# Generated at 2022-06-26 04:31:52.191210
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # New parser
    parser_0 = Parser()
    # Redirect stdout to memory buffer
    buffer = StringIO()
    sys.stdout = buffer
    # Call method print_usage
    parser_0.print_usage()
    # Get buffer contents
    value = buffer.getvalue()
    # Set stdout back to screen
    sys.stdout = sys.__stdout__
    assert value == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y] [-r] [command [command ...]]\n"


# Generated at 2022-06-26 04:31:54.953672
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:31:57.893590
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    try:
        parser_1.print_usage()
    except:
        assert False, 'There should be no exception'
    assert True


# Generated at 2022-06-26 04:31:59.211790
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

# Generated at 2022-06-26 04:32:05.972646
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv_0 = ['thefuck',
              '--debug',
              'ls',
              '--all',
              ARGUMENT_PLACEHOLDER,
              'files',
              '-lh']
    parser_0 = Parser()
    arguments_0 = parser_0.parse(argv_0)
    argument_0_0 = arguments_0.debug
    assert argument_0_0 is True
    argument_0_1 = arguments_0.command
    assert argument_0_1 == ['ls', '--all']
    argument_0_2 = arguments_0
    assert argument_0_2 is not None

# Generated at 2022-06-26 04:32:10.610086
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args1 = ["-h"]
    args2 = ["ls"]
    args3 = ["ls", "--", "-l"]
    args4 = ["ls", ARGUMENT_PLACEHOLDER, "--", "-l"]
    args5 = ["ls", "-l"]

    assert(parser_1.parse(args1).help == True)
    assert(parser_1.parse(args2).command[0] == "ls")
    assert(parser_1.parse(args3).command[0] == "ls" and parser_1.parse(args3).command[1] == "--" and parser_1.parse(args3).command[2] == "-l")

# Generated at 2022-06-26 04:32:18.469562
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help is False
    argument = parser._parser._actions[0]
    assert argument.option_strings == ['-v', '--version']
    assert argument.action == 'store_true'
    assert argument.dest == 'version'
    assert argument.help == ("show program's version number and exit")
    argument = parser._parser._actions[1]
    assert argument.option_strings == ['-a', '--alias']
    assert argument.nargs == '?'
    assert argument.const == get_alias()
    assert argument.dest == 'alias'
    assert argument.help == '[custom-alias-name] prints alias for current shell'
    argument = parser._parser._actions[2]
    assert argument.option_strings

# Generated at 2022-06-26 04:32:20.582534
# Unit test for method print_help of class Parser
def test_Parser_print_help():

    parser_1=Parser()
    assert parser_1.print_help() is None

# Generated at 2022-06-26 04:32:24.249686
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['-h']
    args = parser.parse(argv)
    assert args.help is True


# Generated at 2022-06-26 04:32:26.817117
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:19.650634
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    #expected output
    #usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]
    #               [--shell-logger SHELL_LOGGER]
    #               [--enable-experimental-instant-mode] [-y | -r] [-d]
    #               [--force-command FORCE_COMMAND]
    #               [--] command ...
    #positional arguments:
    #  command
    assert parser_0.parse([sys.argv[0]]).command == []


# Generated at 2022-06-26 04:33:27.823546
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    string = "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [--] [command [command ...]]"
    parser_0.print_usage() == string



# Generated at 2022-06-26 04:33:30.788243
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:33:32.869581
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage()==None


# Generated at 2022-06-26 04:33:36.718142
# Unit test for constructor of class Parser
def test_Parser():
    """
    >>> test_case_0()
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 04:33:43.771567
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Unit test for method parse of class Parser"""
    parser_0 = Parser()
    parse_0 = parser_0.parse(['-d'])
    assert parse_0.debug == True
    parse_1 = parser_0.parse(['--debug'])
    assert parse_1.debug == True
    parse_2 = parser_0.parse(['-h'])
    assert parse_2.help == True
    parse_3 = parser_0.parse(['--help'])
    assert parse_3.help == True

    # def parse(self, argv):
    #     arguments = self._prepare_arguments(argv[1:])
    #     return self._parser.parse_args(arguments)
    
    # def _prepare_arguments(self, argv):
    #     if

# Generated at 2022-06-26 04:33:51.555001
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert repr(parser) == '<Parser: <argparse.ArgumentParser object at 0x103ef29b0>>'
    assert parser._add_arguments() != None
    assert parser._add_conflicting_arguments() != None
    assert parser._prepare_arguments != None
    assert parser.parse != None
    assert parser.print_usage() != None
    assert parser.print_help() != None


# Generated at 2022-06-26 04:33:57.122308
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser1 = Parser()
    args1 = parser1.parse(['test'])
    assert args1.command == ['test']
    assert args1.alias is None
    assert args1.debug is False
    assert args1.shell_logger is None
    assert args1.force_command is None
    assert args1.repeat is False
    assert args1.yes is False
    assert args1.help is False
    assert args1.version is False

    parser2 = Parser()
    args2 = parser2.parse(['-a'])
    assert args2.alias == 'fuck'
    assert args2.debug is False
    assert args2.shell_logger is None
    assert args2.force_command is None
    assert args2.repeat is False
    assert args2.yes is False

# Generated at 2022-06-26 04:34:00.135807
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    print('Testing Parser.print_usage')
    parser.print_usage()
    print('Test passed')


# Generated at 2022-06-26 04:34:12.820223
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Pass a valid argv as a list
    parser_1 = Parser()
    test_1 = 'thefuck --version'
    argv_1 = test_1.split()
    res_1 = parser_1.parse(argv_1)
    assert res_1.version is True
    assert res_1.shell_logger is None
    assert res_1.command == []

    # Pass a valid argv as a list with ARGUMENT_PLACEHOLDER
    parser_2 = Parser()
    test_2 = 'thefuck git status -- --color=auto'
    argv_2 = test_2.split()
    res_2 = parser_2.parse(argv_2)
    assert res_2.version is False
    assert res_2.shell_logger is None
    assert res

# Generated at 2022-06-26 04:35:06.060966
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:08.269136
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:09.466154
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:17.805621
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(['a', 'b'])
    assert not args.version
    assert not args.debug
    assert not args.repeat
    assert not args.shell_logger
    assert not args.help
    assert not args.yes
    assert not args.alias
    assert args.command == []


# Generated at 2022-06-26 04:35:19.156940
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-26 04:35:22.556703
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:26.163614
# Unit test for constructor of class Parser
def test_Parser():
    parser_test = Parser()
    assert parser_test._parser.description == 'Argument parser that can handle arguments with our special placeholder.'


# Generated at 2022-06-26 04:35:31.575287
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:35.697779
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser_0 = Parser()
    parser_0.print_usage()
    
    

# Generated at 2022-06-26 04:35:46.461095
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    with pytest.raises(SystemExit):
        parser.parse(['-v'])
        parser.parse(['-a'])
        parser.parse(['-l'])
        parser.parse(['-d'])
        parser.parse(['--force-command'])
        parser.parse(['--debug'])
        parser.parse(['--debug', '--'])
        parser.parse(['--force-command', '--'])
        parser.parse(['--debug', '--', '--force-command'])
        parser.parse(['--', '--force-command'])
        parser.parse(['--', '--debug'])
        parser.parse(['--', '-v'])

# Unit Test for Method print_help of class Parser

# Generated at 2022-06-26 04:37:44.069391
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()
    print ("Pass case 0: Create an object of class Parser")


# Generated at 2022-06-26 04:37:51.777567
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    buf = io.StringIO()
    sys.stderr = buf
    parser_1.print_help()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-26 04:37:53.274328
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:37:55.185191
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    parser_1.print_usage()


# Generated at 2022-06-26 04:37:56.853807
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    #call the method to be tested
    parser_0.print_usage()
    assert True


# Generated at 2022-06-26 04:38:06.904326
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog is 'thefuck'
    assert parser._parser.description is None
    assert parser._parser.usage is None
    assert parser._parser.epilog is None
    assert parser._parser.version is None
    assert parser._parser.formatter_class is None
    assert parser._parser.conflict_handler is 'error'
    assert parser._parser.add_help is False
    assert len(parser._parser._actions) == 11
    assert len(parser._parser._optionals._group_actions) == 13
    assert parser._parser._optionals._group_actions[0].option_strings[0] is '-v'
    assert parser._parser._optionals._group_actions[0].dest is 'version'
    assert parser._parser._optionals._group_actions[1].option_

# Generated at 2022-06-26 04:38:11.527414
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse([])
    parser_0.parse(["--enable-experimental-instant-mode"])
    parser_0.parse(["--help"])
    parser_0.parse(["--debug"])
    parser_0.parse(["--force-command"])
    parser_0.parse(["--force-command", "fuck"])
    parser_0.parse(["fuck"])

# Generated at 2022-06-26 04:38:13.290203
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:38:21.028018
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    parser.print_help()
    sys.stdout = old_stdout
    assert(mystdout.getvalue() == "usage: thefuck [-h] [-y --yeah] [-r] [-d]\n\
                                   [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n\
                                   [-a [custom-alias-name]] -v\n\
                                   [--] [command [command ...]]\n\n")


# Generated at 2022-06-26 04:38:23.960503
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()
