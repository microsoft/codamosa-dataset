

# Generated at 2022-06-26 04:29:53.365928
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Case 1
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:29:59.460214
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    assert parser_0.parse(['', 'echo', 'hello']).command == ['echo', 'hello']
    assert parser_0.parse(['', 'echo', 'hello', 'world']).command == ['echo', 'hello', 'world']
    assert parser_0.parse(['', 'echo', 'hello', ARGUMENT_PLACEHOLDER, 'world']).command == ['hello']
    assert parser_0.parse(['', 'echo', 'hello', ARGUMENT_PLACEHOLDER, 'world']).debug == False
    assert parser_0.parse(['', 'echo', 'hello', ARGUMENT_PLACEHOLDER, 'world']).yes == False

# Generated at 2022-06-26 04:30:01.152650
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-26 04:30:05.604641
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Create class object
    parser = Parser()
    # Call print_usage method
    parser.print_usage()


# Generated at 2022-06-26 04:30:08.063302
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    assert parser_1.print_usage()==None


# Generated at 2022-06-26 04:30:09.049239
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-26 04:30:11.557752
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:30:14.089858
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_1 = Parser()
    parser_0.parse(["thefuck", "ls", ".", "cd", "../"])
    parser_1.parse(["thefuck", "--force-command", "ls", "--", "."])

# Generated at 2022-06-26 04:30:17.218567
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:21.618802
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(['thefuck', '-v'])
    assert args.version == True

#Unit test for method print_usage of class Parser

# Generated at 2022-06-26 04:30:29.122134
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-26 04:30:30.877084
# Unit test for constructor of class Parser
def test_Parser():
    assert callable(test_case_0)

# Generated at 2022-06-26 04:30:36.838184
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    output = parser.parse(['fuck', '-l', 'log.file', 'command', 'arg'])
    assert output.shell_logger == 'log.file'
    assert output.command == ['command', 'arg']
    assert output.alias is None
    assert not output.debug
    assert not output.yes
    assert not output.repeat
    assert not output.force_command
    assert not output.version
    assert not output.help


# Generated at 2022-06-26 04:30:38.075298
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:41.010161
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:30:48.143854
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    _stderr_ = sys.stderr
    sys.stderr = StringIO()
    _stderr = sys.stderr
    parser_0 = Parser()
    parser_0.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' \
                                    '              [-l SHELL_LOGGER]\n' \
                                    '              [--enable-experimental-instant-mode]\n' \
                                    '              [-d] [--force-command FORCE_COMMAND]\n' \
                                    '              [--] command\n'
    sys.stderr = sys.__stderr__


# Generated at 2022-06-26 04:30:50.841141
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    params = []
    parser.parse(params)


# Generated at 2022-06-26 04:30:52.688416
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:30:53.208668
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()


# Generated at 2022-06-26 04:31:05.783968
# Unit test for method parse of class Parser
def test_Parser_parse():
    test_case_0()
    parser_1 = Parser()
    arguments_1 = parser_1.parse(['-v'])
    parser_2 = Parser()
    arguments_2 = parser_2.parse(['-h'])
    parser_3 = Parser()
    arguments_3 = parser_3.parse(['-a'])
    parser_4 = Parser()
    arguments_4 = parser_4.parse(['thefuck'])
    parser_5 = Parser()
    arguments_5 = parser_5.parse(['command'])
    parser_6 = Parser()
    arguments_6 = parser_6.parse(['command', '-l', 'stdout'])
    parser_7 = Parser()

# Generated at 2022-06-26 04:31:23.324170
# Unit test for method parse of class Parser
def test_Parser_parse():    
    parser = Parser()
    assert parser.parse(['']) == parser.parse(['', '--help'])


# Generated at 2022-06-26 04:31:25.433560
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None


# Generated at 2022-06-26 04:31:30.407961
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    print("%s" % parser_0._parser)

if __name__ == '__main__':
    test_case_0()
    test_Parser()

# Generated at 2022-06-26 04:31:34.111728
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert type(parser_1) == Parser
    print('test_Parser passed\n')


# Generated at 2022-06-26 04:31:36.112407
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:39.066800
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    list_1 = parser_1.parse(['fuck', 'echo', 'hello', 'world'])
    assert list_1.command == ['echo', 'hello', 'world']


# Generated at 2022-06-26 04:31:45.902754
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(['thefuck', 'echo', 'hello', 'world', '--']) == \
        parser_1._parser.parse_args(['echo', 'hello', 'world', '--'])
    assert parser_1.parse(['thefuck', 'echo']) == \
        parser_1._parser.parse_args(['echo'])
    assert parser_1.parse(['thefuck', '-a']) == \
        parser_1._parser.parse_args(['-a'])
    assert parser_1.parse(['thefuck', 'echo', '-r', '--', '-l', 'hello']) == \
        parser_1._parser.parse_args(['echo', '-r', '--', '-l', 'hello'])


# Generated at 2022-06-26 04:31:48.244753
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_case_0()
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:50.050078
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:52.612751
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    argv = ["", "-h"]
    parser_0 = Parser()
    parser_0.print_usage()
    assert True


# Generated at 2022-06-26 04:32:45.231405
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    assert parser_0.parse(argv = ['fuck']) == parser_0._parser.parse_args([])
    assert parser_0.parse(argv = ['fuck', '--version']) == parser_0._parser.parse_args(['--version'])
    assert parser_0.parse(argv = ['fuck', '--alias']) == parser_0._parser.parse_args(['--alias'])
    assert parser_0.parse(argv = ['fuck', '-a']) == parser_0._parser.parse_args(['-a'])
    assert parser_0.parse(argv = ['fuck', '-l', 'shell.log']) == parser_0._parser.parse_args(['-l', 'shell.log'])

# Generated at 2022-06-26 04:32:47.392149
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:32:51.744855
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(argv=['python', '-h', '--yes'])


# Generated at 2022-06-26 04:32:54.454238
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(["thefuck"])


# Generated at 2022-06-26 04:32:57.433425
# Unit test for constructor of class Parser
def test_Parser():
    # test case 0
    parser_0 = Parser()
    assert parser_0._parser == ArgumentParser(prog='thefuck', add_help=False)
    assert parser_0


# Generated at 2022-06-26 04:33:01.750361
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    parser_2 = Parser()
    assert parser_1 is not None
    assert parser_2 is not None


# Generated at 2022-06-26 04:33:04.231344
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:08.792762
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-26 04:33:10.321273
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser=Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:33:14.117913
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    global parser_0
    parser_0.print_help()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:02.022115
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['thefuck', '-h'])
    assert result.help == True


# Generated at 2022-06-26 04:35:04.288758
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser)


# Generated at 2022-06-26 04:35:06.938831
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    assert parser_1.print_help()


# Generated at 2022-06-26 04:35:08.660865
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:15.641782
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1._parser.prog == 'thefuck'
    assert parser_1._parser.add_help == False


# Generated at 2022-06-26 04:35:17.330152
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:19.754366
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:35:21.979576
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:35:30.814548
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    from StringIO import StringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        parser.print_usage()
        output = out.getvalue().strip()
        assert output == 'usage: thefuck [-h] [-v] [-y] [-r] [-d] [-a [custom-alias-name]] '\
                '[--shell-logger SHELL_LOGGER] '\
                '[--enable-experimental-instant-mode] '\
                '[--force-command FORCE_COMMAND] '\
                '[command [command ...]]'
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-26 04:35:36.531182
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args_0 = [
        'thefuck',
        'pip',
        'install',
        '--user',
        'git+git://github.com/Lokaltog/powerline.git#egg=powerline-status'
    ]
    args = parser_0.parse(args_0)
    assert args.command == ['pip',
                            'install',
                            '--user',
                            'git+git://github.com/Lokaltog/powerline.git#egg=powerline-status']
    assert args.debug is False
    assert args.enable_experimental_instant_mode is False
    assert args.force_command is None
    assert args.help is False
    assert args.repeat is False
    assert args.shell_logger is None
   