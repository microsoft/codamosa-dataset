

# Generated at 2022-06-26 04:29:58.056086
# Unit test for method parse of class Parser

# Generated at 2022-06-26 04:30:03.337985
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()

    parser_1_str = 'thefuck -v -a -l --enable-experimental-instant-mode -h -d --force-command command'
    parser_1_list = parser_1_str.split()
    parser_1_args = parser_1.parse(parser_1_list)
    print(parser_1_args)
    parser_1.print_usage()
    parser_1.print_help()



# Generated at 2022-06-26 04:30:05.357552
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:07.801141
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:10.352690
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    # parser.print_usage()

# Generated at 2022-06-26 04:30:12.625313
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:16.925783
# Unit test for constructor of class Parser
def test_Parser():
    print("\n>>> Unit test for Parser")
    test_case_0()
    print(">>> Unit test for Parser passed!")
    return True


# Generated at 2022-06-26 04:30:20.374373
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    parser_1 = Parser()
    assert parser_0 == parser_1


# Generated at 2022-06-26 04:30:28.294055
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help is False
    assert parser._parser._positionals is not None
    assert parser._parser._positionals.title == 'positional arguments'
    assert parser._parser._positionals.option_strings == []
    assert parser._parser._positionals._group_actions ==\
        parser._parser._positionals._actions
    assert parser._parser._optionals is not None
    assert parser._parser._optionals.title == 'optional arguments'
    assert parser._parser._optionals._group_actions ==\
        parser._parser._optionals._actions


# Generated at 2022-06-26 04:30:30.905061
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    Parser.print_usage(parser_1)


# Generated at 2022-06-26 04:30:40.424920
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_usage()

# Unit test fo method print_usage of class Parser

# Generated at 2022-06-26 04:30:52.855464
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(['python', '++', '--', 'python', '--help'])
    assert args.command == ['python', '--help']

    args = parser_1.parse(['python', '++', 'go'])
    assert args.command == ['go']

    args = parser_1.parse(['python', '++', '--', 'go', '--help'])
    assert args.command == ['go', '--help']

    args = parser_1.parse(['python', '++', '--', 'go', '--help'])
    assert args.command == ['go', '--help']

    args = parser_1.parse(['python', '++', '--', '--', 'go', '--help'])

# Generated at 2022-06-26 04:30:53.649266
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Test case 0
    parser_0 = Parser()
    parser_0.print_usage()

# Generated at 2022-06-26 04:30:56.276338
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:06.694936
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck','--help','--yes','--','ls','','','','','','','','','','','','','','',''])

# Generated at 2022-06-26 04:31:17.666729
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_2 = Parser()
    parser_2.parse(["thefuck", "make", "test", "ARGUMENT_PLACEHOLDER"])
	# expected result: Namespace(alias=u'/usr/local/bin/fuck', command=['make', 'test'], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yeah=False)
    parser_2.parse(["thefuck", "ARGUMENT_PLACEHOLDER", "make", "test"])	
	# expected result: Namespace(alias=u'/usr/local/bin/fuck', command=['make', 'test'], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yeah=False)
   

# Generated at 2022-06-26 04:31:28.695532
# Unit test for method parse of class Parser
def test_Parser_parse():
    # if the command is just 'thefuck'
    parser_1 = Parser()
    assert parser_1.parse([]) == parser_1._parser.parse_args([])
    assert parser_1.parse(['--version']) == parser_1._parser.parse_args(['--version'])

    # if the command is just 'thefuck some command'
    parser_2 = Parser()
    args_2 = parser_2.parse(['some', 'command'])
    correct_args_2 = parser_2._parser.parse_args(['--', 'some', 'command'])
    assert args_2.command == correct_args_2.command

    # if the command is just 'thefuck some command'
    parser_3 = Parser()

# Generated at 2022-06-26 04:31:33.294877
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    args = parser.parse(['thefuck', '--alias', 'fuck'])
    parser.print_usage()


# Generated at 2022-06-26 04:31:41.512515
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    Test case to check if the Parser class method print_usage works properly.
    The method should print Usage: thefuck [options] [command] to sys.stderr
    """

    # Create a new parser instance
    parser_0 = Parser()
    # Get current sys.stderr
    sys.stderr = old_stderr = sys.stderr
    # Save output of print_usage in a string using sys module
    sys.stderr = parser_0.print_usage()
    # Restore original sys.stderr
    sys.stderr = old_stderr

    # Test if the output of print_usage matches what we expect
    assert sys.stderr == "Usage: thefuck [options] [command]\n"



# Generated at 2022-06-26 04:31:54.306435
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()

    args = argparse.Namespace()
    args.__setattr__("v", True)
    args.__setattr__("version", False)
    args.__setattr__("a", None)
    args.__setattr__("alias", "fuck")
    args.__setattr__("l", None)
    args.__setattr__("shell_logger", None)
    args.__setattr__("enable_experimental_instant_mode", False)
    args.__setattr__("h", True)
    args.__setattr__("help", False)
    args.__setattr__("y", False)
    args.__setattr__("yes", False)
    args.__setattr__("yeah", False)
    args.__setattr__("hard", True)

# Generated at 2022-06-26 04:32:05.501099
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_parse = Parser()
    parsed_arguments = parser_parse.parse(["thefuck"])
    assert parsed_arguments.command is None
    assert parsed_arguments.alias is None
    assert parsed_arguments.debug is False
    assert parsed_arguments.force_command is None
    assert parsed_arguments.help is False
    assert parsed_arguments.shell_logger is None
    assert parsed_arguments.version is False

    parsed_arguments = parser_parse.parse(["thefuck", "git", "push"])
    assert parsed_arguments.command == ['git', 'push']
    assert parsed_arguments.alias is None
    assert parsed_arguments.debug is False
    assert parsed_arguments.force_command is None
    assert parsed_arguments.help is False
    assert parsed_

# Generated at 2022-06-26 04:32:08.946732
# Unit test for method parse of class Parser
def test_Parser_parse():
	p = Parser()
	argv = ["fuck", "--yes", "firefox"]
	result = p.parse(argv)
	assert result.group_dict()['yes'] == True


# Generated at 2022-06-26 04:32:09.974978
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse("thefuck --help")


# Generated at 2022-06-26 04:32:11.769700
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

# Generated at 2022-06-26 04:32:14.541680
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_parser_test_print_usage = Parser()
    exit_code = parser_parser_test_print_usage.print_usage()
    assert exit_code == None


# Generated at 2022-06-26 04:32:16.660777
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    print("######################print_help_pass######################")


# Generated at 2022-06-26 04:32:18.212089
# Unit test for constructor of class Parser
def test_Parser():
    pass


# Generated at 2022-06-26 04:32:19.258121
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()


# Generated at 2022-06-26 04:32:30.829386
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].action == 'store_true'
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[1].nargs == '?'
    assert parser._parser._actions[1].const == get_alias()
    assert parser._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'

# Generated at 2022-06-26 04:32:34.642720
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()

    # Test case 0
    try:
        assert parser_0
    except AssertionError:
        print('Test case 0 failed')



# Generated at 2022-06-26 04:32:40.289969
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None


# Generated at 2022-06-26 04:32:45.299558
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    f = open('./tests/Parser_print_help_output.txt', 'w')
    old_stdout = sys.stdout
    sys.stdout = f
    parser_1.print_help()
    f.close()
    f = open('./tests/Parser_print_help_expected.txt', 'r')
    expected = f.read()
    f = open('./tests/Parser_print_help_output.txt', 'r')
    output = f.read()
    assert expected == output
    sys.stdout = old_stdout
    f.close()


# Generated at 2022-06-26 04:32:48.608642
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()

# Generated at 2022-06-26 04:32:59.423324
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'ls', '-l', '-a']
    result = parser.parse(argv)
    assert result.command == ['ls', '-l', '-a']
    assert result.debug == False
    assert result.enable_experimental_instant_mode == False
    assert result.force_command == None
    assert result.help == False
    assert result.repeat == False
    assert result.shell_logger == None
    assert result.yes == False

    argv = ['thefuck', 'ls', '-l', '-a', '-d']
    result = parser.parse(argv)
    assert result.command == ['ls', '-l', '-a']
    assert result.debug == True
    assert result.enable_experimental_instant_mode

# Generated at 2022-06-26 04:33:01.892949
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:33:05.934067
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    print('\nUnit test for method print_help of class Parser')
    parser_1 = Parser()
    parser_1.print_help()
    print('Unit test end\n')


# Generated at 2022-06-26 04:33:12.424957
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    capture = io.StringIO()
    sys.stderr = capture
    parser.print_usage()
    assert capture.getvalue() == '''usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [command [command ...]]
'''
# unit test for method print_help of class Parser

# Generated at 2022-06-26 04:33:20.632709
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_help = Parser()
    assert parser_help.print_help() == """usage: thefuck [options] [command [command ...]]
    -v, --version
            show program's version number and exit
    -a, --alias [custom-alias-name]
            prints alias for current shell
    -l, --shell-logger
            log shell output to the file
    --enable-experimental-instant-mode
            enable experimental instant mode, use on your own risk
    -h, --help
            show this help message and exit
    -y, --yes, --yeah, --hard
            execute fixed command without confirmation
    -r, --repeat
            repeat on failure
    -d, --debug
            enable debug output
    command
            command that should be fixed
"""


# Generated at 2022-06-26 04:33:24.012686
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck','--version'])
    assert args.version == True


# Generated at 2022-06-26 04:33:27.408715
# Unit test for method parse of class Parser
def test_Parser_parse():
    print("Testing method parse of class Parser")

    # Case 0: input command does not have the placeholder
    parser_0 = Parser()
    actual_0 = parser_0.parse(['thefuck', 'ls', '-al'])
    expected_0 = parser_0.parse(['--', 'ls', '-al'])
    assert actual_0 == expected_0, "Case 0 Failed, expected: "+ str(expected_0) + " but get: " + str(actual_0)

    # Case 1: input command have the placeholder and arguments after placeholder
    parser_1 = Parser()
    actual_1 = parser_1.parse(['thefuck', 'ls', '-al', 'fuck', '-h', '--enable-experimental-instant-mode', 'pwd'])

# Generated at 2022-06-26 04:33:38.899405
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert type(parser_0) == Parser
    print("test_Parser:", parser_0)


# Generated at 2022-06-26 04:33:41.628573
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:44.222577
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_usage = Parser()
    parser_usage.print_usage()


# Generated at 2022-06-26 04:33:46.822747
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:33:47.715402
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()

# Generated at 2022-06-26 04:33:49.659174
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:53.247590
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_name_print_usage = Parser()
    assert parser_name_print_usage.print_usage() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell_logger] [--enable-experimental-instant-mode] [-d] [--force-command force_command] [command [command ...]]'


# Generated at 2022-06-26 04:33:56.433879
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:33:58.511244
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-26 04:34:03.666483
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def output_to(stream):
        old_stdout = sys.stdout
        sys.stdout = stream
        try:
            yield
        finally:
            sys.stdout = old_stdout

    with output_to(StringIO()) as print_out:
        parser = Parser()
        parser.print_help()

        assert 'usage: thefuck' in print_out.getvalue()
        assert 'example: thefuck -h' in print_out.getvalue()


# Generated at 2022-06-26 04:34:28.700601
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-26 04:34:33.980902
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['fuck', 'fuck', 'fuck'])
    assert args.command == ['fuck', 'fuck']
    assert args.repeat is None
    assert args.yes is None
    assert args.debug is None


# Generated at 2022-06-26 04:34:36.549532
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:34:43.005602
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	args = parser.parse(['thefuck', '-h', '-v', '-a', 'fuck', '-l', 'output.log', '-d', '-y', '--enable-experimental-instant-mode', '--force-command', 'test.txt', '--', '--help'])

	assert(args.help == True)
	assert(args.version == True)
	assert(args.alias == 'fuck')
	assert(args.shell_logger == 'output.log')
	assert(args.debug == True)
	assert(args.yes == True)
	assert(args.enable_experimental_instant_mode == True)
	assert(args.force_command == 'test.txt')
	assert(args.command == ['--help'])

	args = parser

# Generated at 2022-06-26 04:34:47.145732
# Unit test for constructor of class Parser
def test_Parser():
    # Case 0: Normal
    parser_0 = Parser()

    # Case 1: Error: no argument
    try:
        parser_1 = Parser()
    except:
        assert False


# Generated at 2022-06-26 04:34:50.594389
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    parser_0 = Parser()

# Generated at 2022-06-26 04:34:53.922600
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(sys.argv)
    assert args.force_command == None

# Generated at 2022-06-26 04:34:57.487440
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert not parser._parser._action_groups


# Generated at 2022-06-26 04:35:10.083176
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Unit test 0 - input is correct and expected args are being returned
    parser_0 = Parser()
    ns = parser_0.parse(['fuck', '-v', 'git', 'commit', '-v', '-m', '"new', 'commit"'])
    assert ns.version is True
    assert ns._get_kwargs() == {'prog': 'thefuck', 'add_help': False}
    assert ns._get_args() == ['--version']
    assert ns.command == ['git', 'commit', '-v', '-m', '"new', 'commit"']
    assert ns.debug is False
    assert ns.force_command is None
    assert ns.repeat is False
    assert ns.shell_logger is None
    assert ns.yeah is False
    assert ns.alias is None

# Generated at 2022-06-26 04:35:13.931698
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()


# Generated at 2022-06-26 04:35:37.259386
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:41.540762
# Unit test for method parse of class Parser
def test_Parser_parse():
	s = Parser()
	a = s.parse(['python', '--force-command', 'npm', 'i', 'neovim', 'pytest'])
	print("force-command: " + a.force_command)
	print("command: " + str(a.command))
	assert a.force_command == "npm"
	assert a.command == ["i", "neovim", "pytest"]



# Generated at 2022-06-26 04:35:53.015402
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1 = Parser._prepare_arguments(parser_1, argv=['fuck'])
    parser_1 = Parser._prepare_arguments(parser_1, argv=['fuck', '--alias'])
    parser_1 = Parser._prepare_arguments(parser_1, argv=['fuck', '-a'])
    parser_1 = Parser._prepare_arguments(parser_1, argv=['fuck', '--help'])
    parser_1 = Parser._prepare_arguments(parser_1, argv=['fuck', '-h'])
    parser_1 = Parser._prepare_arguments(parser_1, argv=['fuck', '--shell-logger'])
    parser_1 = Parser._prepare_

# Generated at 2022-06-26 04:35:53.823716
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-26 04:35:55.328306
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:57.500991
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser._prepare_arguments(['s', '-d', '--version', '--'])

# Generated at 2022-06-26 04:36:07.016809
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    cmdline = ['-v', '-a' , 'fuck', '-l', 'shell.log', '--enable-experimental-instant-mode', 'hello', 'world']
    parser_0.parse(cmdline)
    try:
        assert parser_0.parse(cmdline).alias == 'fuck'
        assert parser_0.parse(cmdline).shell_logger == 'shell.log'
        assert parser_0.parse(cmdline).enable_experimental_instant_mode
        assert parser_0.parse(cmdline).command == ['hello', 'world']
    except AssertionError:
        print('Unit test failed')


# Generated at 2022-06-26 04:36:09.359316
# Unit test for constructor of class Parser
def test_Parser():
    parser0 = Parser()
    assert (parser0._parser.prog == 'thefuck')
    assert (parser0._parser.add_help == False)


# Generated at 2022-06-26 04:36:11.245500
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser.prog == "thefuck"


# Generated at 2022-06-26 04:36:13.808587
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit as e:
        assert(str(e) == "")


# Generated at 2022-06-26 04:37:09.987216
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['something', '-v'])
    assert args.version == True
    assert args.debug == False
    assert args.alias == 'fuck'
    assert args.help == False
    assert args.block == False
    assert args.command == ''
    assert args.repeat == False
    assert args.yes == False
    assert args.shell_logger == None
    assert args.force_command == None


# Generated at 2022-06-26 04:37:11.273464
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() != None


# Generated at 2022-06-26 04:37:24.706424
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1._prepare_arguments(['-v', '-d', '--force-command', '-y', '--help',
                                        'testcase']) == ['-v', '-d', '--force-command', '-y', '--help',
                                                          '--', 'testcase']
    assert parser_1._prepare_arguments(['-d', '--force-command', '-y', '--help',
                                        'testcase']) == ['-d', '--force-command', '-y', '--help',
                                                          '--', 'testcase']

# Generated at 2022-06-26 04:37:28.053639
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(['thefuck', '-a', 'alias', 'ls', '-l'])
    assert args.alias == 'alias'
    assert args.command == ['ls', '-l']


# Generated at 2022-06-26 04:37:30.365344
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(['fuck', 'sudo', '-h', '--', 'echo', '-h'])


# Generated at 2022-06-26 04:37:33.433663
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    try:
        test_Parser_print_usage.fail('no inchoate')
    except AssertionError as err:
        print('AssertionError: no inchoate')
    """


# Generated at 2022-06-26 04:37:42.805262
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    args = parser_1.parse(['fuck', '-h'])
    assert args.help == True
    args = parser_1.parse(['fuck', '-v'])
    assert args.version == True
    args = parser_1.parse(['fuck', '--debug'])
    assert args.debug == True
    args = parser_1.parse(['fuck', '-d'])
    assert args.debug == True
    args = parser_1.parse(['fuck', '--force-command'])
    assert args.force_command == True
    args = parser_1.parse(['fuck', '-a'])
    assert args.alias == get_alias()
    args = parser_1.parse(['fuck', '-a', 'fuck'])

# Generated at 2022-06-26 04:37:45.258717
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    assert True


# Generated at 2022-06-26 04:37:47.428625
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1 is not None


# Generated at 2022-06-26 04:37:49.954012
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-26 04:39:40.161362
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    lst_0 = ['--version']
    parser_0.parse(lst_0)
    lst_1 = ['--help']
    parser_0.parse(lst_1)
    lst_2 = ['--debug']
    parser_0.parse(lst_2)
