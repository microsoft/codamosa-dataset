

# Generated at 2022-06-26 04:29:50.489454
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0, Parser)


# Generated at 2022-06-26 04:29:53.192974
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert isinstance(parser_1, Parser)


# Generated at 2022-06-26 04:29:57.719064
# Unit test for constructor of class Parser
def test_Parser():
    assert parser_0._parser.prog == "thefuck"
    assert parser_0._parser.add_help == False
    assert parser_0._parser.args == []
    assert parser_0._parser.usage == "thefuck [-h] [-v] [-a [custom-alias-name]]\
 [-r] [-y] [-l shell-logger] [--enable-experimental-instant-mode]\
 [--force-command FORCE_COMMAND] [-d] [command [command ...]]"


# Generated at 2022-06-26 04:30:00.825277
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)

# Generated at 2022-06-26 04:30:01.801242
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()



# Generated at 2022-06-26 04:30:05.142180
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1=Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:08.127285
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['/bin/ls', '/', '-l'])


# Generated at 2022-06-26 04:30:10.674599
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    print("Parser Constructor Test: Passed")

# Generated at 2022-06-26 04:30:14.466362
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args = parser_0.parse([])
    assert args.command == []
    assert args.alias is None
    assert args.shell_logger is None
    assert not args.enable_experimental_instant_mode
    assert not args.help
    assert not args.yes
    assert not args.repeat
    assert not args.debug


# Generated at 2022-06-26 04:30:18.961443
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Unit test for method print_usage of class Parser."""
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:22.707236
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # TODO
    case_0()

# Generated at 2022-06-26 04:30:26.103537
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:28.684799
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:32.038949
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None
    assert isinstance(parser_0, Parser)


# Generated at 2022-06-26 04:30:34.224538
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    result = Parser().print_usage()
    assert result == None



# Generated at 2022-06-26 04:30:44.279434
# Unit test for constructor of class Parser
def test_Parser():
    assert parser_0._parser.prog == 'thefuck'
    assert parser_0._parser.add_help == False
    assert parser_0._parser._actions[0].dest == 'version'
    assert parser_0._parser._actions[0].option_strings == ['-v','--version']
    assert parser_0._parser._actions[0].help == "show program's version number and exit"
    assert parser_0._parser._actions[1].dest == 'alias'
    assert parser_0._parser._actions[1].option_strings == ['-a','--alias']
    assert parser_0._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parser_0._parser._actions[2].dest == 'shell_logger'

# Generated at 2022-06-26 04:30:47.131933
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_help = Parser()
    parser_help.print_help()


# Generated at 2022-06-26 04:30:52.227543
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()
    parser_2 = Parser()
    parser_2._prepare_arguments(['-h'])
    parser_2.print_usage()


# Generated at 2022-06-26 04:30:56.105517
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO

    # make stdout an instance of StringIO
    stdout = sys.stdout
    stringIO = StringIO.StringIO()
    sys.stdout = stringIO

    # call
    parser_0 = Parser()
    parser_0.print_usage()

    # restore stdout
    sys.stdout = stdout
    return stringIO.getvalue()


# Generated at 2022-06-26 04:31:06.654238
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    parser_1.parse(['--debug'])
    parser_1.parse(['--shelllogger'])
    parser_1.parse(['-y'])
    parser_1.parse(['-d'])
    parser_1.parse(['-a'])
    parser_1.parse(['-h'])
    parser_1.parse(['--yeah'])
    parser_1.parse(['-v'])
    parser_1.parse(['--hard'])
    parser_1.parse(['-version'])
    parser_1.parse(['-alias'])
    parser_1.parse(['--shell-logger'])

# Generated at 2022-06-26 04:31:15.171336
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:20.652366
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Set up an instance of class Parser
    parser_parse = Parser()
    # Test case 1: test parse method with arguments ['--', 'command']
    argv_parse_case_1 = ['--', 'command']
    result_parse_case_1 = parser_parse.parse(argv_parse_case_1)
    assert result_parse_case_1.command == ['command']
    # Test case 2: test parse method with arguments ['--', 'command', '--', '--help']
    argv_parse_case_2 = ['--', 'command', '--', '--help']
    result_parse_case_2 = parser_parse.parse(argv_parse_case_2)
    assert result_parse_case_2.command == ['command', '--', '--help']


# Generated at 2022-06-26 04:31:23.563296
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_print_help = Parser()
    parser_print_help.print_help()


# Generated at 2022-06-26 04:31:25.891841
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:31:28.982709
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:40.352261
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    old_stderr = sys.stderr
    sys.stderr = open('out.txt', 'w')
    test_case_0()
    parser_0 = Parser()
    parser_0.print_help()
    sys.stderr.close()
    sys.stderr = old_stderr
    file = open('out.txt', 'r')

# Generated at 2022-06-26 04:31:42.861319
# Unit test for constructor of class Parser
def test_Parser():
    assert True


# Generated at 2022-06-26 04:31:46.290550
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv = ['thefuck', 'thefuck']
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:31:48.180491
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:31:49.571579
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:07.371614
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-26 04:32:18.014810
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser.prog == 'thefuck', 'Bad argument'
    assert parser_0._parser.add_help == False, 'Bad argument'
    parser_1 = Parser()
    assert parser_1._parser.prog == 'thefuck', 'Bad argument'
    assert parser_1._parser.add_help == False, 'Bad argument'
    parser_2 = Parser()
    assert parser_2._parser.prog == 'thefuck', 'Bad argument'
    assert parser_2._parser.add_help == False, 'Bad argument'
    parser_3 = Parser()
    assert parser_3._parser.prog == 'thefuck', 'Bad argument'
    assert parser_3._parser.add_help == False, 'Bad argument'
    parser_4 = Parser

# Generated at 2022-06-26 04:32:19.386309
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    args = ['--help']
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:30.886770
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test case 1
    parser_1 = Parser()
    args_1 = parser_1.parse(['thefuck','--force-command','ls','--','l','sd'])
    assert args_1.force_command == 'ls'
    assert args_1.command == ['l','sd']

    # Test case 2
    parser_2 = Parser()
    args_2 = parser_2.parse(['thefuck', '--force-command', 'ls', 'ls'])
    assert args_2.force_command == 'ls'
    assert args_2.command == ['ls']

    # Test case 3
    parser_3 = Parser()
    args_3 = parser_3.parse(['thefuck', 'ls', '--force-command', 'ls'])

# Generated at 2022-06-26 04:32:35.298578
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    sys.argv = [sys.argv[0], '--help']
    parser_0 = Parser()
    # parser_0.print_help()
    

# Generated at 2022-06-26 04:32:36.576072
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()


# Generated at 2022-06-26 04:32:38.484265
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(["thefuck", "python3", "test.py"])
    print(args)



# Generated at 2022-06-26 04:32:40.366586
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser.prog == 'thefuck'

# Generated at 2022-06-26 04:32:44.859698
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    f = io.StringIO()
    with redirect_stdout(f):
        parser.print_help()
        f.seek(0)
        output = f.read()
    assert 'tf [option] [command]' in output


# Generated at 2022-06-26 04:32:50.580475
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    assert parser_1.print_usage == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [command [command ...]]'


# Generated at 2022-06-26 04:33:24.875548
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:30.638495
# Unit test for constructor of class Parser
def test_Parser():
    """Unit test"""

    parser = Parser()
    assert (parser._parser.get_default('version') == False)
    assert (parser._parser.get_default('alias') == 'fuck')
    assert (parser._parser.get_default('shell_logger') == None)
    assert (parser._parser.get_default('enable_experimental_instant_mode') ==
            False)
    assert (parser._parser.get_default('help') == False)



# Generated at 2022-06-26 04:33:32.549882
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    print("1: ", sys.argv, "\n")
    parser_1.parse(sys.argv)


# Generated at 2022-06-26 04:33:35.829525
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Test 1: Check help of available arguments
    parser_help = Parser()
    parser_help.print_help()



# Generated at 2022-06-26 04:33:38.056021
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:33:41.114387
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

# Generated at 2022-06-26 04:33:43.766087
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:53.783440
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    #
    argv = ['process','-a','alias']
    assert parser_0.parse(argv) == parser_0._parser.parse_args(['-a','alias'])
    #
    argv = ['process','-l',"logfile"]
    assert parser_0.parse(argv) == parser_0._parser.parse_args(['-l',"logfile"])
    #
    argv = ['process','-d']
    assert parser_0.parse(argv) == parser_0._parser.parse_args(['-d'])
    #
    argv = ['process','--force-command','command','command1','command2']

# Generated at 2022-06-26 04:33:55.589874
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser



# Generated at 2022-06-26 04:33:57.428456
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    parser_2 = Parser()
    if parser_1 is parser_2:
        print('test_Parser passed')
    else:
        print('test_Parser failed')


# Generated at 2022-06-26 04:35:22.973109
# Unit test for method parse of class Parser
def test_Parser_parse():
    cmdLine = 'sudo !! -h'
    parser_1 = Parser()
    assert parser_1.parse([cmdLine])


# Generated at 2022-06-26 04:35:24.892026
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-26 04:35:27.340199
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:35:34.491615
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['thefuck', 'ls', '-a'])
    parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER, '-l'])
    parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER, '-l', '/home'])
    parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER, '-l', '/home'])


# Generated at 2022-06-26 04:35:38.062969
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.argv = ['thefuck', '--help']
    Parser().print_help()


# Generated at 2022-06-26 04:35:40.159229
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    
    # No arguments
    parser_0 = Parser()
    assert parser_0.print_help() == None



# Generated at 2022-06-26 04:35:44.592501
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:35:51.991471
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	assert parser.parse(["-h"]) == parser.parse(["--help"])
	assert parser.parse(["--shell-logger","test"]) == None
	assert parser.parse(["--force-command","test"]) == None
	assert parser.parse(["cd /home/"]) == None
	assert parser.parse(["cd /home/", ARGUMENT_PLACEHOLDER, "--force-command","test"]) == None


# Generated at 2022-06-26 04:35:53.449184
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert parser_0.print_usage() is None


# Generated at 2022-06-26 04:35:54.788233
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:39:14.200803
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse([''])
    assert not args.debug
    assert not args.alias
    assert not args.yes
    assert not args.repeat
    assert not args.enable_experimental_instant_mode
    assert args.command == []
    assert args.shell_logger is None



# Generated at 2022-06-26 04:39:26.843076
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .main import main
    from .const import ARGUMENT_PLACEHOLDER
    command = ["echo sssssssssssssssssss", "ls", "wc", "cd", "touch", "cat", "grep", "rm", "date", "du", "df", "mv", "mkdir", "chown", "chmod", "ln", "ls"]
    for i in range(10):
        command_line_arguments = [ARGUMENT_PLACEHOLDER, ""]
        command_line_arguments[1] = command[random.randint(0, 15)]
        for j in range(random.randint(0, 5)):
            command_line_arguments.append(command[random.randint(0, 6)])

# Generated at 2022-06-26 04:39:33.368866
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_parse = Parser()
    assert parser_parse.parse(["python3","-v"]) == "show program's version number and exit"
    assert parser_parse.parse(["python3","-a"]) == "[custom-alias-name] prints alias for current shell"
    assert parser_parse.parse(["python3","-l"]) == "log shell output to the file"
    assert parser_parse.parse(["python3","--help"]) == "show this help message and exit"
    assert parser_parse.parse(["python3","--debug"]) == "enable debug output"
    assert parser_parse.parse(["python3","--force_command"]) == "command that should be fixed"
    assert parser_parse.parse(["python3","--yeah"]) == "execute fixed command without confirmation"
    assert parser_parse

# Generated at 2022-06-26 04:39:35.831787
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-26 04:39:37.908406
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()
    assert True


# Generated at 2022-06-26 04:39:39.856150
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()

    assert parser_0 != None
    parser_1 = Parser()
    assert parser_1 != None


# Generated at 2022-06-26 04:39:41.408648
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
