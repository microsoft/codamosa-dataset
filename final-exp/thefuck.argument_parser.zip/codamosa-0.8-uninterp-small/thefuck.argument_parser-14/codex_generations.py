

# Generated at 2022-06-26 04:29:58.907598
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    argv_0 = ['-d', '--enable-experimental-instant-mode', 'pwd', 'thefuck', '$']
    parser_1 = Parser()
    argv_1 = ['-h', '--debug', 'ls', 'thefuck', '$']
    parser_2 = Parser()
    argv_2 = ['-v', '--force-command', 'cat', 'thefuck', '$']
    parser_3 = Parser()
    argv_3 = ['--force-command', 'grep', 'thefuck', '$']
    parser_4 = Parser()
    argv_4 = ['--shell-logger', 'cat', 'thefuck', '$']
    parser_5 = Parser()

# Generated at 2022-06-26 04:30:01.227336
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-26 04:30:07.402000
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        parser = Parser()
        parser.print_usage()
    except:
        assert 0, "There is something wrong. Please debug.\n"
    else:
        assert 1, "Parser Pass\n"



# Generated at 2022-06-26 04:30:09.906033
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-26 04:30:12.723807
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    print("Printing help for Parser\n")
    parser_1 = Parser()
    parser_1.print_help()
    print("Printing usage for Parser\n")
    parser_1.print_usage()
    print("\n")


# Generated at 2022-06-26 04:30:16.448309
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    #parser = Parser()
    parser_0 = Parser()
    parser_0.print_usage()

test_Parser_print_usage()

# Generated at 2022-06-26 04:30:18.700576
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-26 04:30:25.921467
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    arguments_0 = parser_0.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER])
    assert arguments_0.command == ['-l'] and arguments_0.repeat == False and arguments_0.force_command == None and arguments_0.shell_logger == None and arguments_0.debug == False and arguments_0.alias == None and arguments_0.help == False and arguments_0.enable_experimental_instant_mode == False and arguments_0.yeah == False and arguments_0.version == False


# Generated at 2022-06-26 04:30:32.140263
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(['-a', 'fuck', '-v', '-l', 'log', '--enable-experimental-instant-mode'])
    parser_0.parse(['-h', '--shell-logger', 'log'])


# Generated at 2022-06-26 04:30:33.360130
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:40.742715
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-26 04:30:45.056092
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-26 04:30:47.965467
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-26 04:30:55.330100
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['ls', ARGUMENT_PLACEHOLDER, '-l', '-a']) == \
        parser.parse(['ls', '-l', '-a'])
    assert parser.parse(['ls', ARGUMENT_PLACEHOLDER, '-l', '-a']) == \
        parser.parse(['ls', ARGUMENT_PLACEHOLDER, '-l', ARGUMENT_PLACEHOLDER, '-a'])



# Generated at 2022-06-26 04:30:59.220957
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    # Unit test of method print_help of class Parser
    parser_0.print_help()


# Generated at 2022-06-26 04:31:01.688388
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:31:04.540696
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    # Create a Parser object and store it in a variable
    obj = Parser()

    # Invoke the method print_usage of Parser class with the object created above
    obj.print_usage()


# Generated at 2022-06-26 04:31:09.312026
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    try:
        parser_1.parse(['-v'])
    except SystemExit:
        pass


# Generated at 2022-06-26 04:31:18.301639
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Initializing Parser
    parser_1 = Parser()
    # Testing for attribute '-v'
    argv_1 = sys.argv[1:]
    args_1 = parser_1.parse(argv_1)
    assert not args_1.version
    # Testing for attribute '-a'
    argv_2 = sys.argv[1:]
    args_2 = parser_1.parse(argv_2)
    assert not args_2.alias
    # Testing for attribute '-l'
    argv_3 = sys.argv[1:]
    args_3 = parser_1.parse(argv_3)
    assert not args_3.shell_logger
    # Testing for attribute '--enable-experimental-instant-mode'

# Generated at 2022-06-26 04:31:19.322377
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:31:32.965166
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:31:34.138479
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:31:35.459731
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 != None


# Generated at 2022-06-26 04:31:37.091674
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Create a new parser
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:31:38.275442
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', '', 'fuck'])

# Generated at 2022-06-26 04:31:42.489908
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['-l', '-v'])
    assert args.shell_logger is not None
    assert args.version is True
    assert args.alias is False


# Generated at 2022-06-26 04:31:44.321932
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    pr = Parser()
    pr.print_help()


# Generated at 2022-06-26 04:31:56.306870
# Unit test for method parse of class Parser
def test_Parser_parse():

    argv_1 = ['fuck', '--debug']
    parser_1 = Parser()
    result_1 = parser_1.parse(argv_1)
    print(result_1)

    argv_2 = ['fuck', 'cd', '--debug']
    parser_2 = Parser()
    result_2 = parser_2.parse(argv_2)
    print(result_2)

    argv_3 = ['fuck', 'cd']
    parser_3 = Parser()
    result_3 = parser_3.parse(argv_3)
    print(result_3)

    argv_4 = ['fuck', 'cd', '-l', 'fuck.log']
    parser_4 = Parser()
    result_4 = parser_4.parse(argv_4)

# Generated at 2022-06-26 04:31:57.808541
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()

# Generated at 2022-06-26 04:32:00.954725
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser.prog == 'thefuck'
    assert parser_0._parser.add_help
    assert parser_0._parser.formatter_class == argparse.RawTextHelpFormatter


# Generated at 2022-06-26 04:32:14.647550
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import DEFAULT_LOGGER
    parser = Parser()
    argv = parser.parse(['./bin/thefuck', 'python', 'w', ])
    assert 'python' in argv
    assert argv.command[0] == 'w'
    assert argv.logger == DEFAULT_LOGGER


# Generated at 2022-06-26 04:32:20.680265
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()

# Generated at 2022-06-26 04:32:23.062169
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    try:
        parser_1.print_usage()
    except TypeError:
        print("print_usage() does not need any argument")
    except:
        print("print_usage() is not working properly")


# Generated at 2022-06-26 04:32:32.577913
# Unit test for method parse of class Parser
def test_Parser_parse():
    print("Test for Parser parse method")
    parser_1 = Parser()
    args = parser_1.parse(["fuck"])
    assert args.command == [] and args.debug == False and args.force_command == None and args.shell_logger == None
    args = parser_1.parse(["fuck","apt-get"])
    assert args.command == ["apt-get"] and args.debug == False and args.force_command == None and args.shell_logger == None
    args = parser_1.parse(["fuck","apt-get","install"])
    assert args.command == ["install"] and args.debug == False and args.force_command == None and args.shell_logger == None
    args = parser_1.parse(["fuck","apt-get","install","hello"])

# Generated at 2022-06-26 04:32:34.712789
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:37.446550
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print("\nUnit test for Parser.print_usage")
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 04:32:39.321331
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:32:41.547156
# Unit test for method parse of class Parser
def test_Parser_parse():

    arguments = ["--","pwd"]
    parser = Parser()
    arguments = parser._prepare_arguments(arguments)
    parser.parse(arguments)


# Generated at 2022-06-26 04:32:43.723392
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:32:46.262251
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:09.785340
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:33:10.756313
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-26 04:33:14.881904
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_usage()
    parser_1.print_help()


# Generated at 2022-06-26 04:33:17.442887
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1._parser.prog == 'thefuck'
    assert parser_1._parser.add_help == False


# Generated at 2022-06-26 04:33:20.652480
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:31.826777
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args_1 = parser_1.parse(['-y'])
    if args_1.yes == False:
        print('Test case 1 fail')
    else:
        print('Test case 1 pass')
    args_2 = parser_1.parse(['-r'])
    if args_2.repeat == False:
        print('Test case 2 fail')
    else:
        print('Test case 2 pass')
    args_3 = parser_1.parse(['-y', '-r'])
    if args_3.repeat == False or args_3.yes == False:
        print('Test case 3 fail')
    else:
        print('Test case 3 pass')
    args_4 = parser_1.parse(['-y', '-r', 'git'])

# Generated at 2022-06-26 04:33:32.648013
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:33:41.847066
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argv_0 = parser_1.parse(["thefuck", "ls", "./1/2/3/"])
    argv_1 = parser_1.parse(["thefuck", "ls", "--", "./1/2/3/"])
    argv_2 = parser_1.parse(["thefuck", "ls", "--", "./1/2/3", ARGUMENT_PLACEHOLDER, "./4/5/6/"])
    print(argv_0)
    print(argv_1)
    print(argv_2)

if __name__ == '__main__':
    test_Parser_parse()

# Generated at 2022-06-26 04:33:53.148551
# Unit test for method parse of class Parser
def test_Parser_parse():

    # Testing Parser Class
    parser = Parser()
    sys.argv = ['thefuck','-y', 'ls', '-la']
    parse_results = parser.parse(sys.argv)
    assert parse_results.yes == True
    assert parse_results.repeat == False
    assert parse_results.shell_logger == None
    assert parse_results.debug == False
    assert parse_results.force_command == None
    assert parse_results.command == ['ls', '-la']
    assert parse_results.alias == None
    assert parse_results.help == False
    assert parse_results.version == False
    assert parse_results.enable_experimental_instant_mode == False

    # Testing Parser Class
    parser = Parser()

# Generated at 2022-06-26 04:34:01.020282
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_parse = Parser()
    parser_parse.parse(['thefuck', 'git'])
    parser_parse.parse(['thefuck', 'git', 'commit', '--fixup'])
    parser_parse.parse(['thefuck', '-v'])
    parser_parse.parse(['thefuck', '--yes'])
    parser_parse.parse(['thefuck', '--repeat'])


# Generated at 2022-06-26 04:34:46.479933
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-26 04:34:49.307433
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser.prog == 'thefuck'
    assert parser_0._parser.usage == 'thefuck [options] [<command>]'
    assert parser_0._parser.add_help == False


# Generated at 2022-06-26 04:34:59.647080
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Arrange
    parser_1 = Parser()
    parser_2 = Parser()
    parser_3 = Parser()
    parser_4 = Parser()
    # Act
    parse1 = parser_1.parse(['blah blah blah'])
    parse2 = parser_2.parse(['blah blah blah -v'])
    parse3 = parser_3.parse(['blah blah blah -v --', 'blah', 'blah'])
    parse4 = parser_4.parse(['blah blah blah --force-command', 'blah', 'blah'])
    # Assert
    assert (parse1.command == [])
    assert (parse1.debug is False)
    assert (parse1.force_command is None)
    assert (parse1.help is False)

# Generated at 2022-06-26 04:35:02.745930
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None
    print ("test_Parser: Constructor test passed.")


# Generated at 2022-06-26 04:35:04.887368
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(isinstance(parser,Parser))


# Generated at 2022-06-26 04:35:06.867004
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:35:08.628239
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:14.784617
# Unit test for constructor of class Parser
def test_Parser():
    data_init = Parser()
    assert (data_init is not None)


# Generated at 2022-06-26 04:35:16.190498
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print_usage = Parser().print_usage()


# Generated at 2022-06-26 04:35:18.146481
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(["echo hello world"])
    assert args.command == "echo hello world"


# Generated at 2022-06-26 04:36:53.219097
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:36:56.112066
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:36:57.867297
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None


# Generated at 2022-06-26 04:37:02.054429
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0
    assert parser_0._parser
    assert parser_0._parser.prog == 'thefuck'
    assert parser_0._parser.add_help is False


# Generated at 2022-06-26 04:37:04.837062
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv = "thefuck -h".split()
    parser_ = Parser()
    parser_.print_usage()


# Generated at 2022-06-26 04:37:06.126244
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()


# Generated at 2022-06-26 04:37:16.181248
# Unit test for constructor of class Parser
def test_Parser():
    import unittest
    class TestParser(unittest.TestCase):
        def test_constructor(self):
            parser_0 = Parser()

        def test_parse(self):

            # init
            parser_1 = Parser()

            # argv = [--version]
            argv_1 = ['--version']
            result_1 = parser_1.parse(argv_1)
            expected_1 = argparse.Namespace()
            expected_1.version = True
            self.assertEqual(result_1, expected_1)

            # argv = [--debug, command, --]
            argv_2 = ['--debug', 'command', '--']
            result_2 = parser_1.parse(argv_2)
            expected_2 = argparse.Namespace()
            expected_2

# Generated at 2022-06-26 04:37:19.189403
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:37:20.147008
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()



# Generated at 2022-06-26 04:37:20.988839
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()