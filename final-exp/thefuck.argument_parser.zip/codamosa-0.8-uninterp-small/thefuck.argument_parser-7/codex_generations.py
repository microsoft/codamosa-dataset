

# Generated at 2022-06-26 04:29:51.643243
# Unit test for constructor of class Parser
def test_Parser():
	test_case_0()

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-26 04:29:53.193476
# Unit test for constructor of class Parser
def test_Parser():
    parser_ = Parser()


# Generated at 2022-06-26 04:29:56.639957
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    # If the constructor fails, the parser object will be None
    if(parser_0 is None):
        print('Failed to initialize Parser object!')
    # If the constructor succeeds, the parser object will not be None
    else:
        print('Succeed in initializing Parser object!')


# Generated at 2022-06-26 04:30:01.153043
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_help = Parser()
    parser_help.print_help()


# Generated at 2022-06-26 04:30:07.932182
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_print_usage = Parser()
    parser_print_usage._parser = ArgumentParser()
    parser_print_usage._parser.print_usage = MagicMock(return_value = None)
    assert parser_print_usage.print_usage() == None


# Generated at 2022-06-26 04:30:10.483788
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:12.909555
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert not parser._parser.add_help


# Generated at 2022-06-26 04:30:15.344023
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-26 04:30:19.561157
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    argv = ["thefuck", "-e", "-l", "output.txt"]
    parser_0.parse(argv)


# Generated at 2022-06-26 04:30:26.529804
# Unit test for constructor of class Parser
def test_Parser():
    assert ('_parser' in dir(parser_0))
    assert ('_add_arguments' in dir(parser_0))
    assert ('_add_conflicting_arguments' in dir(parser_0))
    assert ('_prepare_arguments' in dir(parser_0))
    assert ('parse' in dir(parser_0))
    assert ('print_usage' in dir(parser_0))
    assert ('print_help' in dir(parser_0))

test_case_0()
test_Parser()

# Generated at 2022-06-26 04:30:30.408043
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()


# Generated at 2022-06-26 04:30:33.185847
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

# assertion test for method print_help of class Parser

# Generated at 2022-06-26 04:30:35.135908
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:36.440624
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()
    print('\n')


# Generated at 2022-06-26 04:30:43.980902
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_2 = Parser()
    parser_3 = Parser()
    parser_4 = Parser()
    parser_1.parse(['thefuck', '--shell-logger'])
    parser_2.parse(['thefuck', '--force-command', 'ls'])
    parser_3.parse(['thefuck', '--enable-experimental-instant-mode'])
    parser_4.parse(['thefuck', '--repeat'])
    parser_1.parse(['thefuck', '--version'])
    parser_2.parse(['thefuck', '--help'])
    parser_3.parse(['thefuck', '--force-command', 'ls', '--debug'])


# Generated at 2022-06-26 04:30:52.807422
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args0 = parser.parse(['-l', '--', 'sudo', 'fuck'])
    assert args0.shell_logger == None
    assert args0.command == ['sudo', 'fuck']
    assert args0.debug == False
    assert args0.force_command == None
    assert args0.help == False
    assert args0.alias == None
    assert args0.version == False
    assert args0.yeah == False
    assert args0.repeat == False
    args1 = parser.parse(['--force-command', '--', 'sudo', 'fuck'])
    assert args1.force_command == None
    assert args1.command == ['sudo', 'fuck']


# Generated at 2022-06-26 04:30:54.759325
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']



# Generated at 2022-06-26 04:30:57.821174
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Check if print_usage throws an error
    parser.print_usage()


# Generated at 2022-06-26 04:30:59.978194
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:31:05.151802
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'top -h'])
    assert args.command == ['top', '-h']
    assert args.repeat is False
    assert args.yes is False
    assert args.version is False
    assert args.help is False
    assert args.debug is False
    assert args.force_command is None



# Generated at 2022-06-26 04:31:12.013025
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    assert parser_0 != ""

# Generated at 2022-06-26 04:31:18.609172
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argv = ['-v', '-e', '--help', '1', '2', '3', '4']
    result = parser_1.parse(argv)
    expected = ['--']
    assert(result.command == expected)
    assert(result.version == True)
    assert(result.debug == False)
    assert(result.help == True)
    assert(result.shell_logger == None)


# Generated at 2022-06-26 04:31:26.747604
# Unit test for constructor of class Parser
def test_Parser():
    thefuck.shells.bash.parser = Parser()
    if thefuck.shells.bash.parser._parser and isinstance(thefuck.shells.bash.parser._parser, type(ArgumentParser())):
        print('test_Parser(thefuck/shells/bash.py) - constructor of Parser - ok')
    else:
        print('test_Parser(thefuck/shells/bash.py) - constructor of Parser - error')


# Generated at 2022-06-26 04:31:37.128782
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args = parser_0.parse(['thefuck', 'ls', '-a'])
    assert args.command == ['ls', '-a']
    args = parser_0.parse(['thefuck', 'test_ls.py', '--help'])
    assert args.command == ['test_ls.py', '--help']
    args = parser_0.parse(['thefuck', 'test_ls.py', '--help'])
    assert args.command == ['test_ls.py', '--help']


# Generated at 2022-06-26 04:31:38.543570
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()



# Generated at 2022-06-26 04:31:45.716640
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    parser_1.parse(['', '-h'])

    parser_2 = Parser()
    parser_2.parse(['', '--help'])

    parser_3 = Parser()
    parser_3.parse(['', 'command', '-v'])
    parser_3.parse(['', 'command', '--version'])
    parser_3.parse(['', 'command', '-a'])
    parser_3.parse(['', 'command', '--alias'])

    parser_4 = Parser()
    parser_4.parse(['', 'command', '-d'])
    parser_4.parse(['', 'command', '--debug'])

    parser_5 = Parser()

# Generated at 2022-06-26 04:31:47.857762
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:49.604668
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:51.162263
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:01.437884
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    namespace_0 = parser_0.parse(["thefuck", "man", "thefuck"])
    namespace_1 = parser_0.parse(["thefuck", "man", "thefuck", "--alias"])
    namespace_2 = parser_0.parse(["thefuck", "man", "thefuck", "--shell-logger", "log"])
    # check if the remaining command before "--" is parsed correctly
    assert namespace_0.command == ["man", "thefuck"]
    assert namespace_0.alias == None
    assert namespace_1.command == ["man", "thefuck"]
    assert namespace_1.alias == get_alias()
    assert namespace_2.command == ["man", "thefuck"]
    assert namespace_2.shell_logger == "log"

# Unit

# Generated at 2022-06-26 04:32:12.890857
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert  parser.parse(['--alias','fuck','ls']) == parser.parse(['ls','fuck','--'])


# Generated at 2022-06-26 04:32:15.215766
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    output = parser_0.parse(['thefuck', 'python'])
    assert(output.command == ['python'])


# Generated at 2022-06-26 04:32:16.693463
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:32:18.498034
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-26 04:32:20.656815
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1


# Generated at 2022-06-26 04:32:21.553304
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:31.030284
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    stdout=sys.stdout
    sys.stdout=open('out','w')
    fp=open('out','r+')
    parser=Parser()
    parser.print_usage()
    expected="usage: thefuck [-h] [-v] [-a [custom-alias-name]]"\
             " [-l SHELL_LOGGER] [--enable-experimental-instant-mode]"\
             " [-d] [--force-command FORCE_COMMAND] [-y] [-r]"\
             " [command [command ...]]"
    assert fp.readline()==expected+'\n',"Paser.py line no. 197"
    fp.close()
    sys.stdout=stdout


# Generated at 2022-06-26 04:32:33.719434
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:32:43.319920
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Case 0:
    parser_0 = Parser()
    parser_0.parse(["thefuck", "fuck", "fuck", "fuck", "fuck", "fuck"])

    # Case 1:
    parser_1 = Parser()
    parser_1.parse(["thefuck", "fuck", "fuck", "fuck", "fuck", "fuck", "fuck"])

    # Case 2:
    parser_2 = Parser()
    parser_2.parse(["thefuck", "-v"])

    # Case 3:
    parser_3 = Parser()
    parser_3.parse(["thefuck", "--version"])

    # Case 4:
    parser_4 = Parser()
    parser_4.parse(["thefuck", "-a"])

    # Case 5:
    parser_5 = Parser()
   

# Generated at 2022-06-26 04:32:45.659882
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:33:02.856786
# Unit test for constructor of class Parser
def test_Parser():
    """
    >>> parser = Parser()
    """
    if __name__ == "__main__":
        import doctest
        doctest.testmod(verbose=True)

# Generated at 2022-06-26 04:33:09.629672
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args = parser_0.parse(['-v'])
    assert args.version is True, "Failed to recognize -v"
    assert args.command is None, "Failed to recognize no command"

    args = parser_0.parse(['--version'])
    assert args.version is True, "Failed to recognize --version"
    assert args.command is None, "Failed to recognize no command"

    args = parser_0.parse(['--help'])
    assert args.command is None, "Failed to recognize no command"
    assert args.help is True, "Failed to recognize --help"

    args = parser_0.parse(['-h'])
    assert args.command is None, "Failed to recognize no command"

# Generated at 2022-06-26 04:33:15.339993
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parse_arg = parser_0.parse(['grep', '-r', '\S', '--', '~/git/thefuck'])

    assert parse_arg.command == ['grep', '-r', '\S', '~/git/thefuck']
    assert parse_arg.shell_logger == None
    assert parse_arg.force_command == None
    assert parse_arg.debug == False
    assert parse_arg.help == False
    assert parse_arg.version == False
    assert parse_arg.yes == False
    assert parse_arg.repeat == True
    assert parse_arg.alias == None
    assert parse_arg.enable_experimental_instant_mode == False


# Generated at 2022-06-26 04:33:17.106891
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:20.333295
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:30.639268
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    result_1 = parser_1._prepare_arguments(['fuck', ARGUMENT_PLACEHOLDER, '1', '2', '3', '4', '5'])
    assert result_1 == ['1', '2', '3', '4', '5', '--', 'fuck']

    parser_2 = Parser()
    result_2 = parser_2._prepare_arguments(['fuc', '--', 'fuck', ARGUMENT_PLACEHOLDER, '1', '2', '3', '4', '5', '6'])
    assert result_2 == ['--', 'fuc', '--']



# Generated at 2022-06-26 04:33:32.131746
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)


# Generated at 2022-06-26 04:33:34.278575
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:33:36.836777
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:38.789694
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-26 04:34:07.642425
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()



# Generated at 2022-06-26 04:34:14.304365
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = ArgumentParser(prog='thefuck', add_help=False)
    parser.print_help()


# Generated at 2022-06-26 04:34:15.350922
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:34:20.927481
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_parse = Parser()
    parser_parse.parse(['fuck', 'fuck'])
    assert parser_parse.parse(['fuck', 'fuck'])
    assert not parser_parse.parse(['fuck'])
    assert not parser_parse.parse(['fuck', 'fuck', '--version', '-a'])
    assert not parser_parse.parse(['fuck', 'fuck', '--shell-logger', 'log.txt', '--debug', '--force-command'])


# Generated at 2022-06-26 04:34:30.328243
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    fd = open("temp.txt","w+")
    sys.stderr = fd
    parser.print_usage()
    fd = open("temp.txt","r")
    assert fd.read() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n                    [-l SHELL_LOGGER]\n                    [--enable-experimental-instant-mode]\n                    [-d] --force-command FORCE_COMMAND\n                    [command [command ...]]\n'

# Generated at 2022-06-26 04:34:33.486503
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    print(parser_1.parse(['thefuck','ls','*']))

# Generated at 2022-06-26 04:34:36.747359
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:34:38.768563
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None
    assert isinstance(parser._parser, ArgumentParser)


# Generated at 2022-06-26 04:34:41.766153
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:34:49.135525
# Unit test for method parse of class Parser
def test_Parser_parse():
    correct_output_0 = Namespace(command=['echo', '3', '4'], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, yeah=False)
    parser_0 = Parser()
    argv_0 = ['echo', '3', '4']
    assert parser_0.parse(argv_0) == correct_output_0


# Generated at 2022-06-26 04:35:59.926435
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 == None, "Parsing Unicode characters in Python"

if __name__ == '__main__':
    #import pytest
    #pytest.main()
    test_Parser()

# Generated at 2022-06-26 04:36:01.237165
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None


# Generated at 2022-06-26 04:36:03.369386
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:36:12.672640
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    # Verify if Parser is of the class Parser
    assert parser_0.__class__.__name__ == 'Parser'
    # Verify the attributes of the class Parser
    parser_0.print_help()
    parser_0.print_usage()


# Generated at 2022-06-26 04:36:13.841284
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-26 04:36:19.787329
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    def mock_print_help(self, file=None):
        return file
    Parser._parser.print_help = mock_print_help
    parser = Parser()
    if parser.print_help() == sys.stderr:
        print('pass')
    else:
        print('fail')


# Generated at 2022-06-26 04:36:26.324291
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    sys.stdout = open('out.txt', 'w')
    parser_1 = Parser()
    parser_1.print_help()
    sys.stdout.close()
    sys.stdout = sys.__stdout__
    #assert (open('out.txt', 'r') == open('test_Parser_print_help.txt', 'r')) #TODO print to file


# Generated at 2022-06-26 04:36:32.982454
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    case1 = parser.parse(['thefuck', 'll', '--version'])
    assert case1.version
    assert case1.command == ['ll']
    case2 = parser.parse(['thefuck', 'ls', '--version'])
    assert case2.version
    assert case2.command == ['ls']
    case3 = parser.parse(['thefuck', 'll', '--', '--version'])
    assert not case3.version
    assert case3.command == ['--version']
    case4 = parser.parse(['thefuck', 'alias'])
    assert case4.alias


# Generated at 2022-06-26 04:36:37.588782
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:36:39.935418
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
