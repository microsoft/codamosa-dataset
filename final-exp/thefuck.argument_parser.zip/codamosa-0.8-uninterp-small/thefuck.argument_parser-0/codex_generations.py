

# Generated at 2022-06-26 04:29:59.166620
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args1 = parser_1.parse(['','python', 'main.py'])
    assert type(args1) == Namespace
    args2 = parser_1.parse(['','python', 'main.py' , '--alias'])
    assert type(args2) == Namespace
    args3 = parser_1 .parse(['','python', 'main.py' ,'--alias', 'fuck'])
    assert type(args3) == Namespace
    args4 = parser_1.parse(['','python', 'main.py' , '--shell-logger=shell_output.log'])
    assert type(args4) == Namespace
    args5 = parser_1.parse(['','python', 'main.py' , '--enable-experimental-instant-mode'])
   

# Generated at 2022-06-26 04:30:01.269169
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:30:04.685190
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()

# Generated at 2022-06-26 04:30:06.564114
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:12.579271
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n[--enable-experimental-instant-mode] [-h] [-y] [-r] [-d]\n                [--force-command FORCE_COMMAND] [command [command ...]]"
    assert parser._parser.format_usage() == output


# Generated at 2022-06-26 04:30:24.122881
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser_0 = parser.parse(["fuck", "-h"])
    assert parser_0.help == True
    parser_1 = parser.parse(["fuck", "-r"])
    assert parser_1.repeat == True
    parser_2 = parser.parse(["fuck", "-v"])
    assert parser_2.version == True
    parser_3 = parser.parse(["fuck", "-l", "path"])
    assert parser_3.shell_logger == "path"
    parser_4 = parser.parse(["fuck", "-a"])
    assert parser_4.alias == "fuck"
    parser_5 = parser.parse(["fuck", "-a", "haha"])
    assert parser_5.alias == "haha"

# Generated at 2022-06-26 04:30:30.329369
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    actual = parser._parser.parse_args(['-h'])
    assert str(actual) == "Namespace(command=[], debug=False, help=True, shell_logger=None, version=False, yes=False, repeat=False)"



# Generated at 2022-06-26 04:30:32.815796
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), Parser)
    assert Parser() is not None


# Generated at 2022-06-26 04:30:36.149378
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck','--alias','sudo','ls','--','shit'])


# Generated at 2022-06-26 04:30:38.077218
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:48.738961
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    obj = parser()
    obj.print_help()
    assert True



# Generated at 2022-06-26 04:30:54.333384
# Unit test for method parse of class Parser
def test_Parser_parse():
        # Test case 0
        # Test for argv = ['thefuck', 'python']
    parser_0 = Parser()
    try:
        parser_0.parse(['thefuck', 'python'])
        print('Test case 0 of method parse of class Parser: Pass')
    except:
        print('Test case 0 of method parse of class Parser: Fail')
        print(sys.exc_info()[0])

        # Test case 1
        # Test for argv = ['thefuck', '-v']
    parser_1 = Parser()
    try:
        parser_1.parse(['thefuck', '-v'])
        print('Test case 1 of method parse of class Parser: Pass')
    except:
        print('Test case 1 of method parse of class Parser: Fail')

# Generated at 2022-06-26 04:30:56.950791
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:30:59.662582
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-26 04:31:01.622931
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()

# Unit test of function _add_arguments

# Generated at 2022-06-26 04:31:02.626758
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:31:07.437995
# Unit test for method parse of class Parser
def test_Parser_parse():
    # test case 0
    parser_0 = Parser()
    assert parser_0.parse(["thefuck", "git", "--version"]) == Namespace(alias=False,
                                                                        command=['git', '--version'],
                                                                        debug=False,
                                                                        enable_experimental_instant_mode=False,
                                                                        force_command=None,
                                                                        help=False,
                                                                        repeat=False,
                                                                        shell_logger=None,
                                                                        version=False,
                                                                        yeah=False)


# Generated at 2022-06-26 04:31:08.925460
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    orig_stderr = sys.stderr
    sys.stderr = io.StringIO()
    parser.print_usage()
    assert sys.stderr.getvalue()
    sys.stderr = orig_stderr


# Generated at 2022-06-26 04:31:11.594601
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:15.345423
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    result = parser_0.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'sudo', 'rm', '-rf', '/'])
    assert result.command == ['sudo', 'rm', '-rf', '/']


# Generated at 2022-06-26 04:31:41.241613
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert (parser._parser is not None)
    #
    # print(parser._parser.format_help().split('\n'))
    # for action in parser._parser._actions:
    #     print(action)
    #     print(action.required)
    #     print(action.dest)
    #     print("---------------")
    help_text = parser._parser.format_usage().split("\n")
    for i in range(len(help_text)):
        if help_text[i] == "optional arguments:":
            break
    help_text_list = help_text[i+1:]
    assert (help_text_list[0].rstrip(" ").split(" ")[0] == "-v")

# Generated at 2022-06-26 04:31:43.697153
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:31:55.420998
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        parser_1.print_usage()
        output = out.getvalue().strip()
        assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' \
                         '               [-l SHELL_LOGGER]\n' \
                         '               [--enable-experimental-instant-mode]\n' \
                         '               [-d] [--force-command FORCE_COMMAND]\n' \
                         '               [-y | -r] [command [command ...]]', "Usage not displayed"
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-26 04:32:02.596367
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Testcase 0:
    arguments = parser._prepare_arguments(['fuck','ls','--','--version'])
    parser.parse(arguments)
    # Testcase 1:
    parser.parse(['fuck','ls','fuck','ls','--','--version'])
    # Testcase 2:
    parser.parse(['fuck','ls','--','--version','fuck','ls'])
    # Testcase 3:
    parser.parse(['fuck','ls','--','--version','fuck','ls','fuck','ls'])
    # Testcase 4:
    parser.parse(['fuck','ls','fuck','ls','fuck','ls'])


# Generated at 2022-06-26 04:32:07.118576
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    argv_0 = ['./thefuck', 'echo', 'hello world']
    args_0 = parser_0.parse(argv_0)
    assert(args_0.command[0] == 'echo')
    assert(args_0.command[1] == 'hello world')


# Generated at 2022-06-26 04:32:09.570152
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['fuck','-y', 'ls'])
    assert all(item in args for item in ['fuck', 'ls'])


# Generated at 2022-06-26 04:32:13.142416
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    new_argv = ['fuck', '-v']
    a = parser_0.parse(new_argv)
    assert (a.version == True) and (a.command == [])


# Generated at 2022-06-26 04:32:17.596957
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    #parser_0 = Parser()
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:32:19.000250
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:32:20.438573
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-26 04:32:59.049502
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test case for method parse of class Parser"""
    parser = Parser()

# Generated at 2022-06-26 04:33:08.548972
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    with pytest.raises(SystemExit):
        parser_0.parse(('',))
    with pytest.raises(SystemExit):
        parser_0.parse(('', '--'))
    with pytest.raises(SystemExit):
        parser_0.parse(('', '-v'))
    with pytest.raises(SystemExit):
        parser_0.parse(('', '-a'))
    with pytest.raises(SystemExit):
        parser_0.parse(('', '-l'))
    with pytest.raises(SystemExit):
        parser_0.parse(('', '--enable-experimental-instant-mode'))

# Generated at 2022-06-26 04:33:13.430615
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    result_0 = parser_0.parse(["thefuck", "apt-get", "install"])
    result_1 = parser_0.parse(["thefuck", "apt-get", "install", "ARGUMENT_PLACEHOLDER"])
    result_2 = parser_0.parse(["thefuck", "apt-get", "install", "--", "ARGUMENT_PLACEHOLDER"])
    assert result_0.command == ["apt-get", "install"]
    assert result_1.command == []
    assert result_2.command == ["apt-get", "install"]



# Generated at 2022-06-26 04:33:16.441964
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    result = parser_1.print_help()
    assert(result)



# Generated at 2022-06-26 04:33:21.271400
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print("\n*test_Parser_print_usage*")
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:22.627764
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:33:23.598131
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Unit test to make sure that the command `thefuck --alias` works fine

# Generated at 2022-06-26 04:33:30.411152
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    flag_0 = parse.parse_args(["git", "branch"])
    # flag_0 contains the information of executing "git branch"
    # parse.parse_args(argv) is a method of argparse.ArgumentParser
    # argv is converted to a list of strings
    # argv[0] is the program name, argv[1] is the filename
    return flag_0

if __name__ == "__main__":
    print(test_Parser_parse())

# Generated at 2022-06-26 04:33:31.708635
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:33:33.921106
# Unit test for constructor of class Parser
def test_Parser():
    t0 = test_case_0()

# Testing the parse function

# Generated at 2022-06-26 04:33:51.501468
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:34:03.137021
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['fuck'])
    parser_1.parse(['fuck', '-a'])
    parser_1.parse(['fuck', '-l=fuck.log'])
    parser_1.parse(['fuck', '-y'])
    parser_1.parse(['fuck', '-r'])
    parser_1.parse(['fuck', '-d'])
    parser_1.parse(['fuck', '--force-command'])
    parser_1.parse(['fuck', '-h'])
    parser_1.parse(['fuck', '--help'])
    parser_1.parse(['fuck', '-v'])
    parser_1.parse(['fuck', '--version'])

# Generated at 2022-06-26 04:34:05.822399
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:34:11.289831
# Unit test for method parse of class Parser
def test_Parser_parse():
    # set up
    parser = Parser()
    argv = ["thefuck", "--", "ls"]

    # execute
    args = parser.parse(argv)

    # assert equal
    assert args.command == ["ls"], "Parser parse() method failed"


# Generated at 2022-06-26 04:34:12.913081
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.prog == 'thefuck'


# Generated at 2022-06-26 04:34:15.408743
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    parser_2 = Parser()
    parser_2.print_help()


# Generated at 2022-06-26 04:34:18.893674
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argv = ['thefuck','ls','--', '-l']
    parsed = parser_1.parse(argv)
    print(parsed)


# Generated at 2022-06-26 04:34:20.847792
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 != None


# Generated at 2022-06-26 04:34:23.155404
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:34:24.572749
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()


# Generated at 2022-06-26 04:35:07.985973
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    test_input_0 = ['fuck','man','ls','fuck','man','ls']
    test_output_0 = parser.parse(test_input_0)
    assert (test_output_0.command == ['man', 'ls'])


# Generated at 2022-06-26 04:35:10.623156
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert type(parser_0) == Parser


# Generated at 2022-06-26 04:35:14.400176
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()
    parser_0.print_usage()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:16.971973
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:18.691099
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        p = Parser()
        p.print_usage()
    except:
        assert False

# Test for method print_help of class Parser

# Generated at 2022-06-26 04:35:23.105927
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert type(parser) == Parser
    parser.print_usage()
    parser.print_help()
    parser.parse([])


# Generated at 2022-06-26 04:35:26.029263
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

# The input argv1 = []
# There should be no error in this test case

# Generated at 2022-06-26 04:35:30.855450
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:35:32.534165
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_print = Parser()
    parser_print.print_usage()


# Generated at 2022-06-26 04:35:39.057385
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    test_argv_1 = ['thefuck', 'ls', '-l', '--', '-a']
    assert parser_1.parse(test_argv_1)

# Generated at 2022-06-26 04:37:14.922595
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck'])
    assert args.version is None
    assert args.alias is None
    assert args.shell_logger is None
    assert args.debug is None
    assert args.force_command is None
    assert args.command == []

    args = parser.parse(['thefuck', 'command', 'with', 'arguments'])
    assert args.version is None
    assert args.alias is None
    assert args.shell_logger is None
    assert args.debug is None
    assert args.force_command is None
    assert args.command == ['command', 'with', 'arguments']

    args = parser.parse(['thefuck', '-v'])
    assert args.version is True
    assert args.alias is None
    assert args.shell_logger

# Generated at 2022-06-26 04:37:20.311833
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_info = Parser()
    # assert parser_info.print_help() is not None
    help_info = parser_info.print_help()
    print(help_info)
    # assert parser_info.print_help() == None


# Generated at 2022-06-26 04:37:21.140624
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()


# Generated at 2022-06-26 04:37:22.928841
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
	# Test case 0
	parser_0 = Parser()
	parser_0.print_usage()


# Generated at 2022-06-26 04:37:24.676021
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:37:26.142497
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    assert parser_1.print_usage() == None


# Generated at 2022-06-26 04:37:33.121200
# Unit test for constructor of class Parser
def test_Parser():
    """
    test_Parser()
    Unit test for the constructor
    """
    parser_0 = Parser()
    parser_0 = Parser()
    assert parser_0 is not None
    parser_0._parser.add_argument("-r", "--repeat", action = "store_true", help = "repeat on failure")
    parser_0._parser.add_argument("-y", "--yes", "--yeah", "--hard", action = "store_true", help = "execute fixed command without confirmation")
    
    

# Generated at 2022-06-26 04:37:35.523876
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:37:43.390368
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert not parser._parser.add_help
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[2].option_strings == \
        ['-l', '--shell-logger']
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

# Generated at 2022-06-26 04:37:45.729562
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    result_1 = parser_1.parse(['', 'ls'])
    print(result_1.command)