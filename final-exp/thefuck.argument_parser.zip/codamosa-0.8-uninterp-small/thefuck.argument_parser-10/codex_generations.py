

# Generated at 2022-06-26 04:29:51.275638
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(['fuck', '--version'])


# Generated at 2022-06-26 04:29:53.300111
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:29:55.453546
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:29:57.775890
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert(type(parser_0) is Parser)


# Generated at 2022-06-26 04:30:01.241157
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:13.194779
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._positionals.title == 'Positional arguments'
    assert parser._parser._optionals.title == 'Optional arguments'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[0].dest == 'version'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[0].option_strings == ['-v','--version']
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[1].dest == 'alias'
    assert parser._parser._mutually_exclusive_groups[0]._group_actions[1].option_strings == ['-a','--alias']
    assert parser._parser._mutually_

# Generated at 2022-06-26 04:30:24.304986
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(['fuck', 'ls']) == parser_1._parser.parse_args(['fuck', 'ls'])
    assert parser_1.parse(['fuck']) == parser_1._parser.parse_args(['fuck'])
    assert parser_1.parse(['fuck', '--alias']) == parser_1._parser.parse_args(['fuck', '--alias'])
    assert parser_1.parse(['fuck', '--alias', 'alias']) == parser_1._parser.parse_args(['fuck', '--alias', 'alias'])
    assert parser_1.parse(['fuck', '-a']) == parser_1._parser.parse_args(['fuck', '-a'])

# Generated at 2022-06-26 04:30:27.533011
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:31.363355
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    parser._parser.print_help(file=open('~/ParserTest.log', 'w+'))

# Generated at 2022-06-26 04:30:33.290748
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:39.853095
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:30:45.429069
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()


# Generated at 2022-06-26 04:30:52.491958
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_print_usage = Parser()
    with captured_output() as (out, err):
        parser_print_usage._parser.print_usage(sys.stdout)
    output = out.getvalue().strip()
    assert re.match(r"usage: thefuck", output) is not None


# Generated at 2022-06-26 04:31:03.326527
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1._parser.parse_args(['-v'])
    parser_1._parser.parse_args(['-a'])
    parser_1._parser.parse_args(['-l'])
    parser_1._parser.parse_args(['--enable-experimental-instant-mode'])
    parser_1._parser.parse_args(['-h'])
    parser_1._parser.parse_args(['-y'])
    parser_1._parser.parse_args(['-r'])
    parser_1._parser.parse_args(['-d'])
    parser_1._parser.parse_args(['--force-command'])
    parser_1._parser.parse_args(['--'])

# Generated at 2022-06-26 04:31:03.907379
# Unit test for constructor of class Parser
def test_Parser():
    pass  # TODO

# Generated at 2022-06-26 04:31:08.588083
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['-y', '--force-command', 'ls', '--']
    parser = Parser()
    parser.parse(argv)


# Generated at 2022-06-26 04:31:18.045331
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Input: ["3", "3", "python", "thefuck", "--", "file.txt"]
    # Output: Namespace(repeat=False, command=['python', 'thefuck', 'file.txt'], alias=None,
    # help=False, force_command="3", yes=False, shell_logger=None)
    parser_1 = Parser()
    argv_1 = ["3", "3", "python", "thefuck", "--", "file.txt"]
    assert parser_1.parse(argv_1) == Namespace(repeat=False, command=['python', 'thefuck', 'file.txt'], alias=None,
                                               help=False, force_command="3", yes=False, shell_logger=None)

    # Input: ['--debug', 'alias', '~/bin

# Generated at 2022-06-26 04:31:20.533602
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-26 04:31:25.677552
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    a = ['-a', 'fuck', 'cd', '-l', '123', 'ls', '-v', '-h', '-y', '-d'] 
    parser_1.parse(a)


# Generated at 2022-06-26 04:31:38.668440
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args_1 = parser_1.parse(["thefuck","--help"])
    assert args_1.help == True
    args_2 = parser_1.parse(["thefuck","-v"])
    assert args_2.version == True
    args_3 = parser_1.parse(["thefuck","--alias","fuck_alias"])
    assert args_3.alias == "fuck_alias"
    args_4 = parser_1.parse(["thefuck","-a"])
    assert args_4.alias == "fuck"
    args_5 = parser_1.parse(["thefuck","--shell-logger","/tmp/shell.log"])
    assert args_5.shell_logger == "/tmp/shell.log"

# Generated at 2022-06-26 04:31:55.518115
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args_1 = parser_1.parse(['--version'])
    assert args_1.version == True
    assert args_1.alias == None
    assert args_1.shell_logger == None
    assert args_1.enable_experimental_instant_mode == None
    assert args_1.help == None
    assert args_1.yes == None
    assert args_1.debug == None
    assert args_1.force_command == None
    assert args_1.repeat == None
    assert args_1.command == []

    parser_2 = Parser()
    args_2 = parser_2.parse(['--shell-logger', 'shell_logger'])
    assert args_2.version == None
    assert args_2.alias == None
    assert args_2

# Generated at 2022-06-26 04:31:56.766043
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert True


# Generated at 2022-06-26 04:31:58.648066
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:32:02.425104
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:32:09.456972
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck', 'ls', '--help'])
    parser_1.parse(['thefuck', 'rm', '/home/kxy', '--yeah'])
    parser_1.parse(['thefuck', 'ls', '--help', '-d'])
    parser_1.parse(['thefuck', 'ls', '--', '-l'])
    parser_1.parse(['thefuck', '-a'])
    parser_1.parse(['thefuck', '-a', 'fuck'])
    parser_1.parse(['thefuck', '-l', 'shell.log'])
    parser_1.parse(['thefuck', 'rm', '/home/kxy', '--yeah', '-l', 'shell.log'])
    parser_

# Generated at 2022-06-26 04:32:11.729094
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:32:19.354115
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    print(parser.parse(['fuck']))
    print(parser.parse(['fuck', 'ls', '-la']))
    print(parser.parse(['fuck', 'ls', 'cd', 'k', '3', '2', 'f']))

# Generated at 2022-06-26 04:32:30.859589
# Unit test for constructor of class Parser
def test_Parser():
    '''
        Argument parser that can handle arguments with our special placeholder
        '''
    
    errors = []

    arguments = ["-a", "--alias", "prints alias for current shell", "-l", "--shell-logger",
    "log shell output to the file", "--enable-experimental-instant-mode", "enable experimental instant mode, use on your own risk",
    "-h", "--help", "show this help message and exit", "--", "command",
    "command that should be fixed"]
    
    parser = Parser()

    # Check if arguments have been added to parser
    try:
        parser.parse(arguments)
    except:
        errors.append("Arguments not added to parser")
    
    # Check if command is printed

# Generated at 2022-06-26 04:32:32.355098
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:32:35.909813
# Unit test for constructor of class Parser
def test_Parser():
    parser_fix = Parser()
    args = parser_fix.parse(['-v'])
    assert args.version


# Generated at 2022-06-26 04:32:58.824205
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['fuck', 'fuck'])
    parser.parse(['fuck', '--help'])
    parser.parse(['fuck', '--force-command', 'fuck'])
    parser.parse(['fuck', 'fuck', 'fuck', 'fuck'])
    parser.parse(['fuck', '--alias'])
    parser.parse(['fuck', '--alias', 'fuck'])
    parser.parse(['fuck', '--yes'])
    parser.parse(['fuck', '--repeat'])
    parser.parse(['fuck', '--shell-logger', 'fuck'])
    parser.parse(['fuck', '--enable-experimental-instant-mode'])
    parser.parse(['fuck', '--debug'])

# Generated at 2022-06-26 04:33:01.892398
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()



# Generated at 2022-06-26 04:33:03.145584
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()



# Generated at 2022-06-26 04:33:04.761417
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-26 04:33:14.175287
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    import sys

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    parser_0 = Parser()
    parser_0.print_usage()
    sys.stdout = sys.__stdout__
    assert capturedOutput.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n              [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n              [-y] [-r] [--]\n              [command [command ...]]\n'


# Generated at 2022-06-26 04:33:20.159512
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['-v', 'command'])
    parser.parse(['-a', 'custom-alias-name', 'command'])
    parser.parse(['-l', 'shell-logger', 'command'])
    parser.parse(['-y', 'command'])
    parser.parse(['-r', 'command'])
    parser.parse(['--force-command', 'command'])
    parser.parse(['command'])
    parser.parse([])

# a few test cases for method _add_conflicting_arguments of class Parser

# Generated at 2022-06-26 04:33:31.646266
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    test_case_argv = ['python', '-a', 'fuck']
    expected_command = ['python', '-a', 'fuck']
    expected_help = False
    expected_debug = False
    expected_force_command = None
    expected_alias = None
    expected_repeat = False
    expected_yeah = False
    expected_version = False
    expected_shell_logger = False
    expected_enable_experimental_instant_mode = False
    parsed = parser_1.parse(test_case_argv)
    assert parsed.command == expected_command
    assert parsed.help == expected_help
    assert parsed.debug == expected_debug
    assert parsed.force_command == expected_force_command
    assert parsed.alias == expected_alias
    assert parsed.repeat == expected_

# Generated at 2022-06-26 04:33:34.417463
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:38.442143
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    assert parser_0.parse(["python3", "--debug"]) == parser_0.parse(["python3", "--debug"])

# Generated at 2022-06-26 04:33:40.371216
# Unit test for constructor of class Parser
def test_Parser():
    parser1 = Parser()
    assert parser1
    return True


# Generated at 2022-06-26 04:33:58.859238
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck','--debug','--','ls','--help'])
    if args.debug is True:
        if args.command == ['--help']:
            print("test case 1 passed")
        else:
            print("test case 1 failed")
    else:
        print("test case 1 failed")


# Generated at 2022-06-26 04:34:00.622553
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:34:05.962167
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test whether the parse method return correct arguments"""
    parser_1 = Parser()
    args = parser_1.parse(['<original command>', '-h'])
    assert args.help == True


# Generated at 2022-06-26 04:34:08.806998
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:34:20.842271
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'git']) == parser.parse(['fuck', '--', 'git'])
    assert parser.parse(['fuck', 'cd', 'test']) == parser.parse(['fuck', '--', 'cd', 'test'])
    assert parser.parse(['fuck', 'cd', 'test', '--', 'fuck', 'cd', 'test']) == parser.parse(['fuck', '--', 'cd', 'test', '--', 'fuck', 'cd', 'test'])
    assert parser.parse(['fuck', 'cd', 'test', ARGUMENT_PLACEHOLDER, '--', 'fuck', 'cd', 'test']) == parser.parse(['fuck', '--', 'cd', 'test', '--', 'fuck', 'cd', 'test'])

# Generated at 2022-06-26 04:34:24.886141
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
    # check if file handle is not null
    # check if data is printed in desired format


# Generated at 2022-06-26 04:34:32.494405
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # case 1, argv = [thefuck]
    result = parser.parse(['thefuck'])
    assert result.debug is False
    assert result.force_command is None
    assert result.help is False
    assert result.alias is None
    assert result.command == []
    assert result.enable_experimental_instant_mode is False
    assert result.shell_logger is None
    assert result.version is False
    assert result.repeat is False
    assert result.yes is False

    # case 2, argv = [thefuck, -d]
    result = parser.parse(['thefuck', '-d'])
    assert result.debug is True
    assert result.force_command is None
    assert result.help is False
    assert result.alias is None

# Generated at 2022-06-26 04:34:33.397650
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-26 04:34:42.144148
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(['thefuck', 'ls']) == \
            parser_1.parse(['thefuck', 'ls', '-h'])
    assert parser_1.parse(['thefuck', 'ls']) == \
            parser_1.parse(['thefuck', 'ls', '--help'])
    assert parser_1.parse(['thefuck', 'ls']) == \
            parser_1.parse(['thefuck', 'ls', '-d'])
    assert parser_1.parse(['thefuck', 'ls']) == \
            parser_1.parse(['thefuck', 'ls', '--debug'])

# Generated at 2022-06-26 04:34:47.990874
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.description == None
    assert parser._parser.usage == None
    assert parser._parser.epilog == None



# Generated at 2022-06-26 04:35:20.405287
# Unit test for method print_help of class Parser

# Generated at 2022-06-26 04:35:24.750308
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck','ls','--','foo','bar','baz'])


# Generated at 2022-06-26 04:35:27.198702
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:35:31.634231
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:34.448289
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    assert(parser.print_help() == None)

# Generated at 2022-06-26 04:35:37.986190
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()


# Generated at 2022-06-26 04:35:40.344900
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    try:
        parser = Parser()
        parser.print_help()
    except:
        print("Parser_print_help: Error")


# Generated at 2022-06-26 04:35:51.964012
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0.parse(['command', 'ls']) == ['command', 'ls']
    assert parser_0.parse(['command', 'ls', '-a']) == ['command', 'ls', '-a']
    assert parser_0.parse(['command', 'ls', '-l']) == ['command', 'ls', '-l']
    assert parser_0.parse(['command', 'ls', '-v']) == ['command', 'ls', '-v']
    assert parser_0.parse(['command', 'ls', '--help']) == ['command', 'ls', '--help']

# Generated at 2022-06-26 04:35:53.663928
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:55.165376
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)
    return


# Generated at 2022-06-26 04:36:58.330418
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

if __name__=="__main__":
    test_Parser()

# Generated at 2022-06-26 04:37:00.671533
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    assert parser_1.print_help() == 1

# Generated at 2022-06-26 04:37:02.221327
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser is not None


# Generated at 2022-06-26 04:37:03.770002
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()  # Assert that an instance of the class can be constructed

# Generated at 2022-06-26 04:37:10.155240
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    redir = sys.stdout
    sys.stdout = StringIO()
    parser.print_help()
    help_str = sys.stdout.getvalue()
    sys.stdout = redir
    help_str_list = help_str.split('\n')
    lines_num = len([line for line in help_str_list if line.strip()!=''])
    assert lines_num == 14


# Generated at 2022-06-26 04:37:11.374196
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)


# Generated at 2022-06-26 04:37:16.668467
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:37:19.587040
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:37:24.510239
# Unit test for constructor of class Parser
def test_Parser():
    # assert(parser_0._parser.prog == 'thefuck')
    assert(parser_0._parser.add_help == False)
    assert(parser_0._parser.formatter_class._max_help_position == 24)
    assert(parser_0._parser.formatter_class._max_help_position == 24)
    assert(parser_0._parser.formatter_class._action_max_length == 24)
    assert(parser_0._parser.formatter_class._width == 80)


# Generated at 2022-06-26 04:37:25.640257
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    assert True