

# Generated at 2022-06-26 04:29:52.118536
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:29:53.629066
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:02.621442
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    parser_1 = Parser()
    assert parser_0 == parser_1
    assert parser_0.parse(['thefuck', 'ls']) == Namespace(alias=None,
                                                          cmd=['ls'],
                                                          debug=False,
                                                          force_command=None,
                                                          hard=False,
                                                          repeat=False,
                                                          shell_logger=None,
                                                          version=False)

# Generated at 2022-06-26 04:30:12.910407
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    print("debug")
    print("debug:", parser_1.parse("cd /doo/baa/foo/bar"))
    print("debug:", parser_1.parse("cd /doo/baa/foo/bar -a"))
    print("debug:", parser_1.parse("cd /doo/baa/foo/bar --alias"))
    print("debug:", parser_1.parse("cd /doo/baa/foo/bar --alias tfuck"))
    print("debug:", parser_1.parse("cd /doo/baa/foo/bar -v"))
    print("debug:", parser_1.parse("cd /doo/baa/foo/bar --version"))

# Generated at 2022-06-26 04:30:23.068031
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args_0 = parser_0.parse(['thefuck'])
    assert args_0.version == False
    assert args_0.alias == None
    assert args_0.shell_logger == None
    assert args_0.enable_experimental_instant_mode == False
    assert args_0.help == False
    assert args_0.yes == False
    assert args_0.repeat == False
    assert args_0.debug == False
    assert args_0.force_command == None
    assert args_0.command == []
###############################################################################

# Generated at 2022-06-26 04:30:28.037902
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()
    assert Parser()._parser
    assert Parser()._parser.add_argument
    print("The unit test for constructor of class Parser passes.")

test_case_0()
#test_Parser()

# Generated at 2022-06-26 04:30:31.969103
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
    # parser_1 = Parser()
    # parser_1.print_help()


# Generated at 2022-06-26 04:30:33.829845
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:36.435145
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:38.419713
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:55.360328
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # check the case of nothing
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])
    # check the case that argv is only 'thefuck'
    assert parser.parse(['thefuck','--debug','--force-command','ls','--','ls','--help']) == parser._parser.parse_args(['--debug','--force-command','ls','--','ls','--help'])
    # check the case that there is a placeholder
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])
    # check the case of random command
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])
    # check the case of many arguments
    assert parser.parse(['thefuck']) == parser._parser.parse

# Generated at 2022-06-26 04:30:57.953206
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-26 04:31:00.619127
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:06.133637
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # normal case
    option_0 = parser._parse_arguments(['-v'])
    assert option_0.version is True
    # special case
    option_1 = parser._parse_arguments(['git', '--', 'checkout', '-v'])
    assert option_1.version is False
    # special case
    option_2 = parser._parse_arguments(['git', '-v'])
    assert option_2.version is False



# Generated at 2022-06-26 04:31:09.512865
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:31:13.311492
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        parser_0 = Parser()
        parser_0.print_usage()
    except Exception as e:
        print('Exception occured', e)


# Generated at 2022-06-26 04:31:16.233082
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_help = Parser()
    parser_help.print_help()



# Generated at 2022-06-26 04:31:17.656673
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()



# Generated at 2022-06-26 04:31:22.722608
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    assert parser_0.parse(['thefuck', '-v']) == parser_0.parse(['thefuck', '--version'])


# Generated at 2022-06-26 04:31:24.785471
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    command = "fuck"
    argv_1 = [command, "-d"]
    parser_1.parse(argv_1)
    argv_2 = [command]
    parser_1.parse(argv_2)


# Generated at 2022-06-26 04:31:31.949104
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:31:34.438589
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    parser_1 = Parser()
    parser_2 = Parser()
    assert parser_0 is not None
    assert parser_0 is not parser_1
    assert parser_0 is not parser_2


# Generated at 2022-06-26 04:31:42.835860
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    cmd = ['ls', 'src']
    assert parser_1.parse(cmd) == parser_1._parser.parse_args(cmd[1:])

    cmd = ['fuck', 'ls', '-a']
    assert parser_1.parse(cmd) == parser_1._parser.parse_args(cmd[1:])

    cmd = ['fuck', 'ls', ARGUMENT_PLACEHOLDER, '--', '-a']
    assert parser_1.parse(cmd) == parser_1._parser.parse_args(
        ['--', '-a'] + cmd[2:2 + cmd[2:].index('--')])

# Generated at 2022-06-26 04:31:44.181232
# Unit test for constructor of class Parser
def test_Parser():
    
    assert Parser


# Generated at 2022-06-26 04:31:46.641795
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:31:57.643452
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Unit test for method print_help of class Parser
    """
    import StringIO

    from contextlib import contextmanager
    
    @contextmanager
    def captureStdOut():
        """
        Helper method that lets us capture stdout.
        """
        
        import sys, StringIO
        new_out, new_err = StringIO.StringIO(), StringIO.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
            
    my_buffer = StringIO.StringIO()
    parser_0 = Parser()

# Generated at 2022-06-26 04:32:02.370076
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:32:07.843060
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:32:09.883710
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()
    parser_1 = Parser()
    assert len(parser_1._parser.format_help()) - len('prog') == 141

# test case for parse

# Generated at 2022-06-26 04:32:17.685053
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()

    def mock_print_usage(*args, **kwargs):
        return 'thefuck [--version] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [--help] [-d] [--force-command force-command] [command]...\n'

    parser_1._parser.print_usage = mock_print_usage
    assert parser_1.print_usage() == 'thefuck [--version] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [--help] [-d] [--force-command force-command] [command]...\n'


# Generated at 2022-06-26 04:32:22.929619
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:32:25.627889
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()



# Generated at 2022-06-26 04:32:29.451983
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    sys.argv = ['thefuck', 'ssh', 'git@github.com']
    assert parser_1.parse(sys.argv) == parser_1._parser.parse_args(['--', 'ssh', 'git@github.com'])


# Generated at 2022-06-26 04:32:30.493781
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:31.964812
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:32:34.136553
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-26 04:32:36.365081
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-26 04:32:46.168818
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    result = parser_1.parse(['thefuck', 'ls', '-la'])
    assert result == parser_1._parser.parse_args(['--', 'ls', '-la'])

    parser_2 = Parser()
    result = parser_2.parse(['thefuck', '-l', 'ls', '-la'])
    assert result == parser_2._parser.parse_args(['-l', '--', 'ls', '-la'])

    parser_3 = Parser()
    result = parser_3.parse(['thefuck', 'ls', '-la', '--', '1', '2', '3'])
    assert result == parser_3._parser.parse_args(['--', 'ls', '-la'])


# Generated at 2022-06-26 04:32:50.454917
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser._parser.format_help())
    assert len(parser._parser.format_help()) > 0


# Generated at 2022-06-26 04:32:52.363817
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:58.694016
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()



# Generated at 2022-06-26 04:33:03.959824
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_parse = Parser()
    args = parser_parse.parse(['thefuck', 'git', 'push'])
    assert args.command == ['git', 'push']
    assert args.debug == False


# Generated at 2022-06-26 04:33:09.884261
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    arguments_0 = parser_0.parse(["-v"])
    # Check if not None
    if arguments_0 == None:
        print("Error: arguments_0 is None")
        return
    
    # Check if arguments_0.version is true
    if arguments_0.version != True:
        print("Error: arguments_0.version is not true")
        return
    
    # Check if arguments_0.alias is None.
    if arguments_0.alias != None:
        print("Error: arguments_0.alias is not None")
        return
    
    # Check if arguments_0.shell_logger is None.
    if arguments_0.shell_logger != None:
        print("Error: arguments_0.shell_logger is not None")
        return
    


# Generated at 2022-06-26 04:33:11.052275
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:33:14.389676
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:33:15.679553
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None
    assert parser._parser is not None
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-26 04:33:17.246100
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:33:21.118000
# Unit test for constructor of class Parser
def test_Parser():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 04:33:23.800407
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:33:24.766750
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(type(parser._parser) is ArgumentParser)


# Generated at 2022-06-26 04:33:33.091895
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_usage = Parser()
    parser_usage.print_usage()


# Generated at 2022-06-26 04:33:42.636853
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['--version'])
    parser_1.parse(['-v'])
    parser_1.parse(['--alias'])
    parser_1.parse(['-a', 'fuck'])
    parser_1.parse(['--shell-logger', 'shell.log'])
    parser_1.parse(['--enable-experimental-instant-mode'])
    parser_1.parse(['--help'])
    parser_1.parse(['-h'])
    parser_1.parse(['-d'])
    parser_1.parse(['-r'])
    parser_1.parse(['--repeat'])
    parser_1.parse(['--force-command', 'ls'])

# Generated at 2022-06-26 04:33:46.002089
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = parser.print_help()
    assert (type(output) is NoneType)


# Generated at 2022-06-26 04:33:49.917535
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    sys.stderr = io.StringIO()
    parser.print_usage()
    assert sys.stderr.getvalue().startswith('usage:')


# Generated at 2022-06-26 04:33:51.554308
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:57.116714
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	parser.parse(['-v'])
	parser.parse(['-a'])
	parser.parse(['-l'])
	assert (parser.parse(['-d']) or parser.parse(['-h']))
	assert (parser.parse(['-y']) or parser.parse(['-r']))
	parser.parse(['--'])
	parser.parse(['ls'])
	parser.parse(['ls', '-l'])
	parser.parse(['ls', '-l', '-h'])
	parser.parse(['ls', '-h', '-l'])
	parser.parse(['ls', '-h'])
	parser.parse(['ls', '-l', '-h', '-a', '-d'])

# Generated at 2022-06-26 04:34:00.691364
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(['thefuck', 'git commit', 'git commit'])
    assert args.command == ['git commit']


# Generated at 2022-06-26 04:34:03.633719
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse([])



# Generated at 2022-06-26 04:34:06.281576
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:34:08.273483
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == 0


# Generated at 2022-06-26 04:34:33.479518
# Unit test for method parse of class Parser
def test_Parser_parse():
    args_0 = ['--', 'ls', '-l']
    parser_0 = Parser()
    parser_0.parse(args_0)


# Generated at 2022-06-26 04:34:35.584534
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser is not None


# Generated at 2022-06-26 04:34:46.437829
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['-a'])
    parser.parse(['-l','shell_logger','--','command','param','1','2','3'])
    parser.parse(['-d','-a','alias','command','param','1','2','3'])
    parser.parse(['-y','command','param','1','2','3'])
    parser.parse(['--force-command','-d','--','command','param','1','2','3'])
    parser.parse(['command','param','1','2','3'])
    parser.parse(['-a','alias','command','param','1','2','3'])
    parser.parse([])
    parser.parse(['-r','command','param','1','2','3'])

# Generated at 2022-06-26 04:34:47.175330
# Unit test for constructor of class Parser
def test_Parser():
    assert 1 == 1

# Generated at 2022-06-26 04:34:48.224507
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:34:59.220316
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    argv1 = ['fuck', '3.py']
    argv2 = ['fuck', '3.py', '--']
    argv3 = ['fuck', '3.py', 'argument', '--', 'python3']
    argv4 = ['fuck', '3.py', 'argument', '--', 'python3', '-r', 'arg1', 'arg2']
    argv5 = ['fuck', '3.py', 'argument', '--', 'python3', ARGUMENT_PLACEHOLDER, '-r', 'arg1', 'arg2']
    # print(parser_0.parse(argv1))
    # print(parser_0.parse(argv2))
    # print(parser_0.parse(argv3))
    # print(parser_0

# Generated at 2022-06-26 04:35:10.463024
# Unit test for method parse of class Parser
def test_Parser_parse():
    args_0 = Parser()
    args_1 = args_0.parse(['-v'])
    assert args_1.version, "This line should never be run!"
#     print(args_0.parse(['-v']))
#     print(args_0.parse(['-a']))
    args_2 = args_0.parse(['-a', 'fuck'])
    assert args_2.alias, "This line should never be run!"
#     print(args_0.parse(['-a', 'fuck']))
#     print(args_0.parse(['-l', 'shell_logger']))
    args_3 = args_0.parse(['--enable-experimental-instant-mode'])

# Generated at 2022-06-26 04:35:17.630185
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(['-l','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test'])
    parser_0.parse(['-d','test','test','test','test','test','test','test','test','test','test','test','test','test','test','test'])


# Generated at 2022-06-26 04:35:19.496427
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    assert parser_1.print_help()

# Generated at 2022-06-26 04:35:30.639711
# Unit test for method parse of class Parser

# Generated at 2022-06-26 04:35:51.863131
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck']) == None


# Generated at 2022-06-26 04:35:57.008666
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_help = Parser()

    # Print help messages
    sys.stdout = open('test.out','w')
    parser_help.print_help()
    sys.stdout = sys.__stdout__

    # Read content of output file
    with open('test.out', 'r') as f:
        output = f.read()

    # Check if the correct message is shown
    assert 'usage: thefuck' in output
    assert 'optional arguments:' in output
    assert 'command:' in output

    # Clean up
    os.remove('test.out')



# Generated at 2022-06-26 04:35:57.988829
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser.print_help()



# Generated at 2022-06-26 04:36:02.574778
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argument_1 = ['--help']
    args = parser_1.parse(argument_1)
    # AssertionError: ArgumentParser doesn't return namespace object when no argument are passed.
    assert args == ArgumentParser(prog='thefuck', add_help=False).parse_args(argument_1)


# Generated at 2022-06-26 04:36:06.042808
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1._add_arguments() == None
    assert parser_1._add_conflicting_arguments() == None


# Generated at 2022-06-26 04:36:10.217623
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:36:11.929177
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:36:15.382719
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'pip', 'install', '-r', 'requriments.txt', '--', 'test']
    assert parser.parse(argv).command == ['test']



# Generated at 2022-06-26 04:36:19.233413
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 != None, 'Constructor for class Parser has failed'



# Generated at 2022-06-26 04:36:22.022748
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:37:10.214409
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(['thefuck','sudo','ls','--','--help'])
    assert args.command == ['sudo','ls','--help']


# Generated at 2022-06-26 04:37:11.441603
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:37:17.632509
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_p_h = Parser()
    parser_p_h.print_help()



# Generated at 2022-06-26 04:37:19.587466
# Unit test for constructor of class Parser
def test_Parser():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 04:37:24.307172
# Unit test for method parse of class Parser
def test_Parser_parse():
    # case 0:
    args = []
    parser_0 = Parser()
    parser_0.parse(args)
    assert parser_0.parse(args) == parser_0._parser.parse_args(args)
    # case 1:
    args = ['random_string']
    parser_1 = Parser()
    parser_1.parse(args)
    assert parser_1.parse(args) == parser_1._parser.parse_args(args)



# Generated at 2022-06-26 04:37:25.556022
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:37:27.463820
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    command_1 = ['fuck']
    assert parser_1.parse(command_1).command == []


# Generated at 2022-06-26 04:37:29.517199
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert type(parser_0) == Parser


# Generated at 2022-06-26 04:37:30.687942
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:37:32.606518
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:39:35.789671
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse([]) == Namespace(alias=None, command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yeah=False, yes=False)


# Generated at 2022-06-26 04:39:37.847795
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:39:46.743142
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Case 0:
    # Prepare arguments:
    #   argv = ['-l', '~/log.txt', 'rm', '~/file'];
    #   arguments = ['--', 'rm', '~/file'];
    argv_0 = ['-l', '~/log.txt', 'rm', '~/file']
    arguments_0 = ['--', 'rm', '~/file']
    parser_0 = Parser()

    assert parser_0._prepare_arguments(argv_0) == arguments_0

    # Case 1:
    # Prepare arguments:
    #   argv = ['--yeah', 'rm', '~/file', '-rf'];
    #   arguments = ['--yeah', '--', 'rm', '~/file', '-rf'];