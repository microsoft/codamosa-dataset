

# Generated at 2022-06-26 04:29:51.201289
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:29:53.271239
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:29:55.399102
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser = Parser()
    parser = Parser()


# Generated at 2022-06-26 04:29:57.716573
# Unit test for constructor of class Parser
def test_Parser():
    with pytest.raises(TypeError):
        parser_0 = Parser(1,2)


# Generated at 2022-06-26 04:30:02.676487
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert "prog='thefuck'" in repr(parser_0)
    assert repr(parser_0).startswith("Parser(")
    assert repr(parser_0).endswith(")")
    parser_0.print_usage() == None
    parser_0.print_help() == None


# Generated at 2022-06-26 04:30:03.925608
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:30:06.748743
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = './thefuck --alias'
    parser = Parser()
    assert parser.parse(argv) == parser._parser.parse_args('--alias'.split())

# Generated at 2022-06-26 04:30:09.202375
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:12.070053
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:30:14.444061
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:30:28.173102
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:31.449833
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 04:30:33.039019
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:30:37.428616
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    def check_parser_has_property(name):
        assert hasattr(parser, '_' + name)

    check_parser_has_property('parser')



# Generated at 2022-06-26 04:30:45.297766
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_1 = Parser()
    parser_2 = Parser()
    parser_3 = Parser()
    parser_4 = Parser()
    parser_5 = Parser()
    parser_6 = Parser()
    parser_7 = Parser()
    parser_8 = Parser()
    args_0 = parser_0.parse(['thefuck', '-v'])
    args_1 = parser_1.parse(['thefuck', '-a'])
    args_2 = parser_2.parse(['thefuck', '-l'])
    args_3 = parser_3.parse(['thefuck', '--force-command'])
    args_4 = parser_4.parse(['thefuck', '-d'])

# Generated at 2022-06-26 04:30:48.200094
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-26 04:30:50.780179
# Unit test for constructor of class Parser
def test_Parser():
    print('')
    print('UnitTest for Parser')
    print('-'*50)
    print('#1')
    test_case_0()
    print('Pass')

# Generated at 2022-06-26 04:30:52.653025
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    assert parser_1.print_help()

# Generated at 2022-06-26 04:31:03.634669
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    values_1 = parser_1.parse(['fuck', '-v'])
    assert values_1.version == True, "failure in test_Parser_parse_1"
    assert values_1.debug == False, "failure in test_Parser_parse_2"
    assert values_1.shell_logger == None, "failure in test_Parser_parse_3"
    assert values_1.force_command == None, "failure in test_Parser_parse_4"
    assert values_1.alias == get_alias(), "failure in test_Parser_parse_5"
    assert values_1.yes == False, "failure in test_Parser_parse_6"
    assert values_1.repeat == False, "failure in test_Parser_parse_7"

# Generated at 2022-06-26 04:31:06.299621
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:30.356687
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Test case 0
    arguments = parser._prepare_arguments(['t.py', '-v'])
    assert arguments == ['-v']
    # Test case 1
    arguments = parser._prepare_arguments(['t.py', '--force-command', 'ls', '-l'])
    assert arguments == ['--force-command', 'ls', '-l']
    # Test case 2
    arguments = parser._prepare_arguments(['t.py', '--', 'ls', '-l'])
    assert arguments == ['--', 'ls', '-l']
    # Test case 3
    arguments = parser._prepare_arguments(['t.py', 'ls', '-l'])
    assert arguments == ['--', 'ls', '-l']


# Generated at 2022-06-26 04:31:33.598606
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:31:37.162832
# Unit test for constructor of class Parser
def test_Parser():
    # Case 0: A parser can be created.
    parser1 = Parser()
    assert isinstance(parser1, Parser)

    # Case 1: parser has the attribute _parser.
    assert parser1._parser is not None


# Generated at 2022-06-26 04:31:44.973261
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    result_1 = parser_1.parse(['fuck', '-v'])
    expected_1 = argparse.Namespace(command=[], alias=None, debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, yes=False, repeat=False, shell_logger=None, version=True)
    assert expected_1 == result_1
    
    parser_2 = Parser()
    result_2 = parser_2.parse(['fuck', 'git', 'a', 'b', 'c'])

# Generated at 2022-06-26 04:31:46.853313
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-26 04:31:57.894274
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(argv=['thefuck', 'some command', 'some argument'])
    parser_1.parse(argv=['thefuck'])

    parser_2 = Parser()
    parser_2.parse(argv=['thefuck', '-v'])
    parser_2.parse(argv=['thefuck', '-a'])
    parser_2.parse(argv=['thefuck', '-a', 'fuck'])
    parser_2.parse(argv=['thefuck', '-l', 'log.txt'])
    parser_2.parse(argv=['thefuck', '--enable-experimental-instant-mode'])
    parser_2.parse(argv=['thefuck', '-d'])


# Generated at 2022-06-26 04:31:59.825708
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()

    try:
        parser_0.print_help()
        assert True
    except:
        assert False



# Generated at 2022-06-26 04:32:00.956753
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:32:02.043873
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:03.186902
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:32:22.930555
# Unit test for constructor of class Parser
def test_Parser():
    """Test that constructor works."""
    parser_0 = Parser()


# Generated at 2022-06-26 04:32:26.667277
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    try:
        parser_0.print_usage()
    except Exception as e:
        assert False
    assert True


# Generated at 2022-06-26 04:32:40.327873
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    arg = ['fuck', 'apt-get', 'install', 'python3']
    result = parser_1.parse(arg)
    assert result.debug == False
    assert result.yes == False
    assert result.repeat == False
    assert result.alias == None
    assert result.help == False
    assert result.version == False
    assert result.force_command == None
    assert result.shell_logger == None
    assert result.command == ['apt-get', 'install', 'python3']

    arg = ['fuck', 'apt-get', 'install', 'python3', 'apt-get', 'install', 'python3']
    result = parser_1.parse(arg)
    assert result.debug == False
    assert result.yes == False
    assert result.repeat == False

# Generated at 2022-06-26 04:32:42.344675
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(),Parser) == True
    assert isinstance(Parser()._parser,ArgumentParser) == True

# Other tests for def _add_arguments()

# Generated at 2022-06-26 04:32:44.410702
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:32:51.359537
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser == ArgumentParser(prog='thefuck', add_help=False)
    assert parser._help == False
    assert parser._alias == None
    assert parser._shell_logger == None
    assert parser._enable_experimental_instant_mode == False
    assert parser._confirm == False
    assert parser._repeat == False
    assert parser._debug == False
    assert parser._force_command == None
    assert parser._command == None


# Generated at 2022-06-26 04:32:54.100852
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    print("Testing for Parser.print_help()")
    parser_help = Parser()
    bla = parser_help.parse(['./thefuck', '--help'])
    assert(bla.help)
    print("test_Parser_print_help() passed")


# Generated at 2022-06-26 04:32:56.065953
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None


# Generated at 2022-06-26 04:32:57.195628
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:59.868016
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:33:29.817648
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['--force-command=rm -rf /',
            '--alias=fuck',
            '--shell-logger=source',
            '--debug']
    parser_1 = Parser()
    args = parser_1.parse(argv)

    assert args.force_command == 'rm -rf /'
    assert args.alias == 'fuck'
    assert args.shell_logger == 'source'
    assert args.debug


# Generated at 2022-06-26 04:33:33.842806
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    list_argv = ['thefuck', '--help']
    parser_0.parse(list_argv)


# Generated at 2022-06-26 04:33:35.883538
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    args = Parser()
    args.print_help()


# Generated at 2022-06-26 04:33:38.106661
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()

# Generated at 2022-06-26 04:33:44.073208
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args_1 = parser_1.parse(['fuck', '-v'])
    assert args_1.version == True
    assert args_1.help == False
    args_2 = parser_1.parse(['fuck', '-h'])
    assert args_2.help == True
    args_3 = parser_1.parse(['fuck', '--version'])
    assert args_3.version == True
    assert args_3.help == False
    args_4 = parser_1.parse(['fuck', '--help'])
    assert args_4.help == True
    args_5 = parser_1.parse(['fuck', '--force-command', 'ls'])
    assert args_5.force_command == 'ls'

# Generated at 2022-06-26 04:33:48.070095
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['fuck', 'vim'])
    assert args.command == ['vim']


# Generated at 2022-06-26 04:33:54.802214
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args1 = parser.parse(['-l', 'shell_logger', 'command'])
    args2 = parser.parse(['-d', 'command'])
    args3 = parser.parse(['-h', 'command'])
    args4 = parser.parse(['--force-command', 'command', ARGUMENT_PLACEHOLDER])
    args5 = parser.parse(['command1', 'command2', ARGUMENT_PLACEHOLDER])
    args6 = parser.parse(['command', '-d'])

    assert args1.shell_logger == 'shell_logger'
    assert args2.debug
    assert args3.help
    assert args4.force_command == 'command'
    assert args5.command == ['command1', 'command2']
   

# Generated at 2022-06-26 04:33:59.986881
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    input_ = ['-v']
    output = parser.parse(input_)
    expected_output = Namespace(help=False, version=True)
    assert output == expected_output


# Generated at 2022-06-26 04:34:03.450112
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:34:13.409302
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    test_0 = parser.parse([""])
    assert test_0.debug == False
    assert test_0.version == False
    assert test_0.alias == None
    assert test_0.shell_logger == None
    assert test_0.force_command == None
    assert test_0.enable_experimental_instant_mode == False
    assert test_0.help == False
    assert test_0.yes == False
    assert test_0.repeat == False
    assert test_0.command == []

    test_1 = parser.parse(["thefuck","fuck this", "shit", "--", "--yes", "-r"])
    assert test_1.debug == False
    assert test_1.version == False
    assert test_1.alias == None
    assert test_1

# Generated at 2022-06-26 04:35:00.681941
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-26 04:35:04.502825
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    assert not parser_1.print_usage()

if __name__ == '__main__':
    parser_2 = Parser()
    test_case_0()
    test_Parser_print_usage()
    parser_2.print_usage()
    parser_2.print_help()

# Generated at 2022-06-26 04:35:11.992507
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Prepare for testing
    parser = Parser()

# Generated at 2022-06-26 04:35:14.400838
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:15.243011
# Unit test for constructor of class Parser
def test_Parser():
    assert True



# Generated at 2022-06-26 04:35:16.506652
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:35:17.771779
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()


# Generated at 2022-06-26 04:35:19.623959
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-26 04:35:22.424026
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)



# Generated at 2022-06-26 04:35:24.303819
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()


# Generated at 2022-06-26 04:36:30.652706
# Unit test for constructor of class Parser
def test_Parser():
    assert parser_0._parser.prog == 'thefuck'
    assert parser_0._parser.usage == 'thefuck [options] [--] command [command ...]'
    assert parser_0._parser.description == None
    assert parser_0._parser.epilog == None
    assert parser_0._parser._positionals.title == 'positional arguments'
    assert parser_0._parser._optionals.title == 'optional arguments'
    assert parser_0._parser._actions[0].option_strings == ['-v', '--version']
    assert parser_0._parser._actions[0].dest == 'version'
    assert parser_0._parser._actions[0].const == True
    assert parser_0._parser._actions[0].default == False
    assert parser_0._parser._actions[0].type is None
    assert parser_

# Generated at 2022-06-26 04:36:39.324217
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argv = ['test', '-d', '--force-command', 'echo', 'ls', '-l']
    result = parser_1.parse(argv)
    assert str(result) == "Namespace(alias=None, command=['ls', '-l'], debug=True, enable_experimental_instant_mode=False, force_command='echo', help=False, repeat=False, shell_logger=None, version=False, yeah=False, yes=False)"


# Generated at 2022-06-26 04:36:41.571945
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:36:42.925926
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    parser.print_help()


# Generated at 2022-06-26 04:36:44.993659
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    p.parse(['thefuck', 'git', 'status'])


# Generated at 2022-06-26 04:36:53.920422
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'tail', '-f', '-n' ,'10']
    result = parser.parse(argv)
    assert result.command == ['tail', '-f', '-n', '10']
    assert result.force_command == None
    assert result.yes == False
    assert result.repeat == False
    assert result.version == False
    assert result.debug == False
    assert result.alias == None
    assert result.enable_experimental_instant_mode == False
    assert result.shell_logger == None
    assert result.help == False


# Generated at 2022-06-26 04:37:03.770289
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    args = ['thefuck', '-r']
    parser = Parser()
    ouput = parser.parse(args)
    parser.print_usage()
    assert ouput == parser, "Function print_usage within class Parser is not working"
    print("The test case for method print_usage of class Parser is passed!")

# Test Result:
# Test case 1 is passed
# chenj@chenj-ThinkPad-T470s:~/Documents/NextGardener/thefuck$ python3 test/test_parser.py
# The test case for method print_usage of class Parser is passed!


# Generated at 2022-06-26 04:37:06.918395
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser_0 = Parser()
    assert parser_0.parse(['thefuck']) == parser_0.parse(['thefuck'])


# Generated at 2022-06-26 04:37:09.484724
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    cmd = ['sleep', '1', '2', '3']
    args = Parser().parse(cmd)
    args.print_help()


# Generated at 2022-06-26 04:37:17.223308
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'echo', 'hello']
    assert parser.parse(argv).command == ['echo', 'hello']
    argv = ['thefuck', '-h']
    assert parser.parse(argv).help
    assert not parser.parse(argv).command
    argv = ['thefuck', 'echo', ARGUMENT_PLACEHOLDER, 'hello']
    assert parser.parse(argv).command == ['hello']
    argv = ['thefuck', 'echo', ARGUMENT_PLACEHOLDER, 'hello', 'world']
    assert parser.parse(argv).command == ['hello', 'world']

# Generated at 2022-06-26 04:39:05.703187
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(["python", "fuck", "python", "--help"])
    parser_0.parse(["python", "fuck", "python", "--version"])
    parser_0.parse(["python", "fuck", "python"])
    parser_0.parse(["python", "fuck", "python", "--debug"])
    parser_0.parse(["python", "fuck", "python", "--alias"])
    parser_0.parse(["python", "fuck", "python", "--shell-logger"])
    parser_0.parse(["python", "fuck", "python", "--enable-experimental-instant-mode"])
    parser_0.parse(["python", "fuck", "python", "--help"])

# Generated at 2022-06-26 04:39:07.524603
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:39:08.551387
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert False == p.print_help()


# Generated at 2022-06-26 04:39:11.141240
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
    parser_0.print_usage()



# Generated at 2022-06-26 04:39:13.847859
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.stderr = open(os.devnull, 'w')
    parser_0 = Parser()
    parser_0.print_usage()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-26 04:39:15.006545
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:39:20.016948
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parse_args_0 = parser_0.parse(['thefuck', '--help'])


# Generated at 2022-06-26 04:39:22.162853
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:39:24.085200
# Unit test for constructor of class Parser
def test_Parser():
    print('**********************start**********************')
    parser = Parser()
    parser.print_help()
    print('**********************done**********************')

# Generated at 2022-06-26 04:39:31.770664
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    argv_0 = ['thefuck', 'git', 'log', '--', '--all']
    args_0 = parser_0.parse(argv_0)
    assert args_0.yes == False
    assert args_0.repeat == False
    assert args_0.alias == None
    assert args_0.shell_logger == None
    assert args_0.force_command == None
    assert args_0.debug == False
    assert args_0.help == False
    assert args_0.version == False
    assert args_0.command == ['git', 'log', '--', '--all']
    
    
# It is ok for an unit test to end up in an assert
