

# Generated at 2022-06-26 04:29:55.457912
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:29:56.179127
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-26 04:30:02.107097
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()
    parser_1 = Parser()
    parser_1.print_usage()
    parser_0.print_usage()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:05.612073
# Unit test for constructor of class Parser
def test_Parser():
    # Test Case 0
    try:
        parser_0 = Parser()
    except BaseException:
        assert False


# Generated at 2022-06-26 04:30:06.681994
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['testarg'])

# Generated at 2022-06-26 04:30:09.110895
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:11.469451
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:16.706576
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck','fuck','--alias','fuck'])
    parser_1.parse(['thefuck','fuck','--shell-logger','logfile.log'])
    parser_1.parse(['thefuck','fuck','--enable-experimental-instant-mode'])
    parser_1.parse(['thefuck','fuck','--help'])
    parser_1.parse(['thefuck','fuck','--yes'])
    parser_1.parse(['thefuck','fuck','--repeat'])
    parser_1.parse(['thefuck','fuck','--debug'])
    parser_1.parse(['thefuck','fuck','--force-command','ls'])
    parser_1.parse(['thefuck','fuck','ls'])



# Generated at 2022-06-26 04:30:25.150650
# Unit test for constructor of class Parser
def test_Parser():
    command_0 = 'fuck'
    command_1 = 'fuck -v'
    command_2 = 'fuck -a'
    command_3 = 'fuck -p'
    command_4 = 'fuck -p jenkins'
    command_5 = 'fuck -h'
    command_6 = 'fuck -y'
    command_7 = 'fuck -r'
    command_8 = 'fuck -d'
    parser_0 = Parser()
    parser_1 = Parser()
    parser_2 = Parser()
    parser_3 = Parser()
    parser_4 = Parser()
    parser_5 = Parser()
    parser_6 = Parser()
    parser_7 = Parser()
    parser_8 = Parser()
    parser_0.parse([command_0])
    parser_1.parse

# Generated at 2022-06-26 04:30:29.122121
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    result = parser_1.parse(['ls', '-l'])
    assert result.command == ['ls', '-l']

# Generated at 2022-06-26 04:30:47.736857
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    def print_usage(self):
        self._parser.print_usage(sys.stderr)
    """
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:49.207108
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    test_case_0()


# Generated at 2022-06-26 04:30:56.047682
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args_0 = parser_0.parse(["fuck"])
    assert args_0.version == False
    assert args_0.alias == None
    assert args_0.shell_logger == None
    assert args_0.enable_experimental_instant_mode == False
    assert args_0.help == False
    assert args_0.yes == False
    assert args_0.repeat == False
    assert args_0.debug == False
    assert args_0.force_command == None
    assert args_0.command == []


# Generated at 2022-06-26 04:31:01.096537
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    parser_2 = Parser()
    assert parser_1._parser == parser_2._parser 
    assert parser_1 != parser_2


# Generated at 2022-06-26 04:31:04.351504
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    try:
        parser_0.print_help()
    except(SystemExit) as e:
        if e.code != 0:
            raise(e)



# Generated at 2022-06-26 04:31:09.722662
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    argv_0 = ['thefuck']
    parser_0 = Parser()
    parser_0.parse(argv_0)
    parser_0.print_help()


# Generated at 2022-06-26 04:31:18.495214
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(["thefuck"])
    parser_1.parse(["thefuck", "fuck"])
    parser_1.parse(["thefuck", "fuck"])
    parser_1.parse(["thefuck", "fuck", "--"])
    parser_1.parse(["thefuck", "fuck", "--", "hard"])
    parser_1.parse(["thefuck", "fuck", "hard"])
    parser_1.parse(["thefuck", "fuck", "hard", "--"])
    parser_1.parse(["thefuck", "fuck", "--", "hard", "--"])
    parser_1.parse(["thefuck", "fuck", "hard", "--", "hard"])

# Generated at 2022-06-26 04:31:22.723101
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
    

    
    
    
    
    
    
    
    
    

# Generated at 2022-06-26 04:31:27.721565
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(["/home/abhishek/PycharmProjects/PythonProjects/thefuck", "-v", "--alias", "--shell-logger"])
    assert result.version == True
    assert result.alias == None
    assert result.shell_logger == '/home/abhishek/.config/thefuck/shell-logger'



# Generated at 2022-06-26 04:31:31.788271
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_parse = Parser().parse
    assert parser_parse(['command']) == parser_parse(['command', 'parameter'])


# Generated at 2022-06-26 04:31:59.084543
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'grep', '*', '--color=always --color=always', ARGUMENT_PLACEHOLDER, '--enable-experimental-instant-mode'])
    assert(arguments.command == ['grep', '*', '--color=always --color=always'])
    assert(arguments.enable_experimental_instant_mode)

# Generated at 2022-06-26 04:32:02.010666
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:03.409683
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:32:07.434929
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()

# Generated at 2022-06-26 04:32:09.014115
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:32:11.265057
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:32:12.578697
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    p.parse(['-v'])

# Generated at 2022-06-26 04:32:19.593213
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    result1 = parser_1.parse(['python', '-v'])
    assert result1.command is None
    assert result1.version is True
    assert result1.enable_experimental_instant_mode is False
    assert result1.yes is False
    assert result1.debug is False
    assert result1.shell_logger is None
    assert result1.force_command is None
    assert result1.repeat is False
    assert result1.alias is None
    assert result1.help is False

    parser_2 = Parser()
    result2 = parser_2.parse(['python', '-y', '-d', '--yes'])
    assert result2.command is None
    assert result2.version is False
    assert result2.enable_experimental_instant_mode

# Generated at 2022-06-26 04:32:30.202939
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(['--version']).version == True
    assert parser_1.parse(['--alias']).alias == get_alias()
    assert parser_1.parse(['--shell-logger']).shell_logger == None
    assert parser_1.parse(['--help']).help == True
    assert parser_1.parse(['--yes']).yes == True
    assert parser_1.parse(['--debug']).debug == True
    assert parser_1.parse(['--force-command']).force_command == None
    assert parser_1.parse(['parse', '--help']).command[0] == 'parse'


# Generated at 2022-06-26 04:32:32.102807
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1 is not None


# Generated at 2022-06-26 04:33:10.756375
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0 is not None


# Generated at 2022-06-26 04:33:14.881684
# Unit test for constructor of class Parser
def test_Parser():
    assert (parser_0._parser.prog == 'thefuck')
    assert (parser_0._parser.add_help == False)


# Generated at 2022-06-26 04:33:21.705380
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser_1 = Parser()

    assert parser_1.parse(['thefuck', '-h']) == parser_1._parser.parse_args(['-h']) + argparse.Namespace(command=[])
    assert parser_1.parse(['thefuck', 'git', 'status', '-h']) == parser_1._parser.parse_args(['--', 'git', 'status', '-h']) + argparse.Namespace(command=[])
    assert parser_1.parse(['thefuck', 'git', 'status', '-h', '--']) == parser_1._parser.parse_args(['--', 'git', 'status', '-h', '--']) + argparse.Namespace(command=[])
    assert parser_1.parse(['thefuck']) == parser_1._parser.parse_

# Generated at 2022-06-26 04:33:23.868402
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args_0 = parser_1.parse(['/usr/bin/python3','--force-command=ls','-r'])
    assert args_0.repeat==True
    assert args_0.force_command=='ls'


# Generated at 2022-06-26 04:33:32.880362
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    def test_1():
        args = parser.parse(['thefuck', '--help', 'echo', '123'])
        assert args.help
        assert args.command == ['echo', '123']

    def test_2():
        args = parser.parse(['thefuck', 'echo', '123'])
        assert not args.help
        assert not args.debug
        assert not args.shell_logger
        assert not args.repeat
        assert not args.force_command
        assert args.command == ['echo', '123']

    def test_3():
        args = parser.parse(['thefuck', '--', 'echo', '123'])
        assert not args.help
        assert not args.debug
        assert not args.shell_logger
        assert not args.repeat
        assert not args

# Generated at 2022-06-26 04:33:39.184714
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.stdout = open('Parser_print_help.out','w+')
    parser_0 = Parser()
    parser_0.print_help()
    sys.stdout = sys.__stdout__
    assert filecmp.cmp('Parser_print_help.out','unit_test_output/Parser_print_help.out')


# Generated at 2022-06-26 04:33:52.239504
# Unit test for method parse of class Parser

# Generated at 2022-06-26 04:33:56.578797
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(["fuck", "ls", "|", "wc", "-l"])


# Generated at 2022-06-26 04:33:59.289958
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:34:05.022645
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    with patch('sys.stderr') as stderr:
        stderr.write = MagicMock()
        parser = Parser()
        parser.print_help()

# Generated at 2022-06-26 04:34:52.160250
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:34:58.995075
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    result_0 = parser_0.parse(['thefuck', 'fuck'])
    assert result_0.debug == False
    assert result_0.force_command == None
    assert result_0.alias == None
    assert result_0.command == ['fuck']
    assert result_0.debug == False
    assert result_0.repeat == False
    assert result_0.shell_logger == None
    assert result_0.version == False
    assert result_0.yes == False



# Generated at 2022-06-26 04:35:00.944109
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:06.610981
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import contextlib
    from StringIO import StringIO
    capturedOutput = StringIO()
    with contextlib.redirect_stdout(capturedOutput):
        parser.print_usage()
    output_string = capturedOutput.getvalue().strip()
    assert output_string == "usage: thefuck [-h] [-r] [-y] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [--force-command FORCE_COMMAND] [--] [command [command ...]]"


# Generated at 2022-06-26 04:35:08.494950
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:09.887171
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

# Generated at 2022-06-26 04:35:20.362020
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test case 0
    parser_0 = Parser()
    argv_0 = ['ls', '-l']
    args_0 = parser_0.parse(argv_0)
    assert(args_0.command[0] == 'ls')
    assert(args_0.command[1] == '-l')
    assert(args_0.repeat == False)
    assert(args_0.force_command == None)
    assert(args_0.enable_experimental_instant_mode == False)
    assert(args_0.help == False)
    assert(args_0.debug == False)

    # Test case 1
    parser_1 = Parser()
    argv_1 = ['ls', '-l', '-r']
    args_1 = parser_1.parse(argv_1)


# Generated at 2022-06-26 04:35:23.107905
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:35:29.668458
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from sys import stderr
    save_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        parser_0 = Parser()
        parser_0.print_help()
        output = out.getvalue().strip()
        assert len(output) > 0
    finally:
        out.close()
        sys.stderr = save_stderr


# Generated at 2022-06-26 04:35:36.161633
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def stdout_redirected(to=os.devnull):
        fd = sys.stdout.fileno()

        ##### assert that stdout is a tty-like file, i.e. that it is connected
        ##### to a terminal
        assert os.isatty(fd)


# Generated at 2022-06-26 04:37:13.519963
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import StringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out
        p = Parser()
        p.print_usage()
        output = out.getvalue().strip()
        assert output == 'usage: thefuck [-h] [-v] [-y] [-r] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [command [command ...]]'
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-26 04:37:23.292137
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    #TC 1.0
    out = sys.stderr
    sys.stderr = StringIO()
    parser_0 = Parser()
    parser_0.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] command ...\n'
    sys.stderr = out


# Generated at 2022-06-26 04:37:24.701934
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:37:25.948319
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:37:28.435095
# Unit test for constructor of class Parser
def test_Parser():
    # Stage 1
    try:
        parser_1 = Parser()
    except:
        print('Failed at Stage 1')
    else:
        print('Passed at Stage 1')
        

# Generated at 2022-06-26 04:37:30.688110
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser_1 = parser.parse(['--debug','--'])
    assert pytest.approx(parser_1) == 0


# Generated at 2022-06-26 04:37:31.854854
# Unit test for constructor of class Parser
def test_Parser():
    assert type(Parser()) is Parser


# Generated at 2022-06-26 04:37:33.143714
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

# Generated at 2022-06-26 04:37:42.628389
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    expected_output = Namespace(alias=None, command=['python'], debug=False, enable_experimental_instant_mode=False, help=False, repeat=False, shell_logger=None, version=False, yeah=False, yes=False)
    actual_output = parser.parse(['python'])
    assert expected_output.alias == actual_output.alias
    assert expected_output.command == actual_output.command
    assert expected_output.debug == actual_output.debug
    assert expected_output.enable_experimental_instant_mode == actual_output.enable_experimental_instant_mode
    assert expected_output.help == actual_output.help
    assert expected_output.repeat == actual_output.repeat
    assert expected_output.shell_logger == actual_output.shell

# Generated at 2022-06-26 04:37:45.259670
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    assert parser_1.print_help() is None
