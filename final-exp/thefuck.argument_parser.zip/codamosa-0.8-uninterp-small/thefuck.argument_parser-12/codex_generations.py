

# Generated at 2022-06-26 04:29:58.200433
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-26 04:30:02.421963
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    argv_0 = ['thefuck', '--debug']
    parser_0.parse(argv_0)


# Generated at 2022-06-26 04:30:06.783677
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:30:09.307658
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
    #assert 0


# Generated at 2022-06-26 04:30:16.198959
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['fuck', 'sudo', 'rm', '-rf', '$HOME', ARGUMENT_PLACEHOLDER, '-d', '--force-command', 'sudo']
    args = parser.parse(argv)
    assert args.command == ['sudo', 'rm', '-rf', '$HOME']
    assert args.debug is True
    assert args.force_command == 'sudo'
    assert args.alias == get_alias()
    assert args.help is False
    assert args.repeat is False
    assert args.yes is False
    assert args.version is False
    assert args.shell_logger is None
    assert args.enable_experimental_instant_mode is False


# Generated at 2022-06-26 04:30:20.778168
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # parser_0 = Parser()
    arguments = ['-h']
    parser_0 = Parser().parse(arguments)
    # parser_0.print_help()
    assert parser_0



# Generated at 2022-06-26 04:30:29.142676
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse([])
    parser.parse(['3'])
    parser.parse(['-a'])
    parser.parse(['-d'])
    parser.parse(['-v'])
    parser.parse(['-h'])
    parser.parse(['--debug'])
    parser.parse(['--version'])
    parser.parse(['--help'])
    parser.parse([ARGUMENT_PLACEHOLDER, '3'])
    parser.parse(['3', ARGUMENT_PLACEHOLDER, '4'])
    parser.parse(['3', ARGUMENT_PLACEHOLDER])
    parser.parse(['-h', ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-26 04:30:31.292959
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:32.024570
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-26 04:30:33.624911
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser is not None


# Generated at 2022-06-26 04:30:41.710731
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from .const import HELP_TEXT

    capturedOutput = StringIO()
    sys.stderr = capturedOutput
    Parser().print_help()
    assert capturedOutput.getvalue() == HELP_TEXT+'\n'


# Generated at 2022-06-26 04:30:43.859469
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:30:47.760607
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    try:
        parser_0 = Parser()
        parser_0.print_help()
    except SystemExit:
        assert True
    else:
        assert False


# Generated at 2022-06-26 04:30:52.010170
# Unit test for method parse of class Parser
def test_Parser_parse():
    print("\nTesting test_Parser_parse...")
    argv0 = []
    parser_0 = Parser()
    parsed_0 = parser_0.parse(argv0)
    print("parsed_0: ", parsed_0)

if __name__ == "__main__":
    print("Running Class Parser")
    #test_case_0()
    test_Parser_parse()

# Generated at 2022-06-26 04:31:02.875369
# Unit test for constructor of class Parser
def test_Parser():
    args_0 = ['thefuck', 'sudo', 'kate', ARGUMENT_PLACEHOLDER, '-h']
    args_1 = ['thefuck', 'sudo', 'kate', ARGUMENT_PLACEHOLDER]
    args_2 = ['thefuck', 'sudo']
    with patch.object(sys, 'argv', args_0) as argv:
        parser_0 = Parser()
        result_0 = parser_0.parse(argv)
        assert(result_0.alias == get_alias())
        assert(result_0.command == ['sudo', 'kate'])
        assert(result_0.enable_experimental_instant_mode == False)
        assert(result_0.help == False)
        assert(result_0.shell_logger == None)

# Generated at 2022-06-26 04:31:03.913895
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()



# Generated at 2022-06-26 04:31:05.460257
# Unit test for constructor of class Parser
def test_Parser():
    
    assert Parser()


# Generated at 2022-06-26 04:31:09.444071
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_usage()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:12.167116
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert (parser_0 != None)


# Generated at 2022-06-26 04:31:14.453108
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False



# Generated at 2022-06-26 04:31:29.595727
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['argv[0]','argv[1]',ARGUMENT_PLACEHOLDER,'argv[3]','argv[4]'])
    print(result)
    # assert result == ['argv[1]','argv[2]',ARGUMENT_PLACEHOLDER,'argv[3]','argv[4]']
    result = parser.parse(['argv[0]','argv[1]','argv[2]',ARGUMENT_PLACEHOLDER,'argv[4]','argv[5]'])
    print(result)
    assert result == ['argv[1]','argv[2]',ARGUMENT_PLACEHOLDER,'argv[4]','argv[5]']

# Generated at 2022-06-26 04:31:32.897093
# Unit test for constructor of class Parser
def test_Parser():
    parser_2 = Parser()
    assert isinstance(parser_2, Parser)


# Generated at 2022-06-26 04:31:37.057877
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._option_string_actions
    assert parser._parser._mutually_exclusive_groups



# Generated at 2022-06-26 04:31:43.141155
# Unit test for method parse of class Parser
def test_Parser_parse():
  parser_1 = Parser()
  # Testing for the case where the script has not been called
  try:
    parser_1.parse([])
  except SystemExit:
    pass
  else:
    assert False, "SystemExit Exception not raised"
  # Testing for the case where the script has been called with a command and no arguments
  assert parser_1.parse(["thefuck", "command"]) == argparse.Namespace(alias=None, command=['command'], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)
  # Testing for the case where the script has been called with a command and an argument
  assert parser_1.parse(["thefuck", "command", "argument"]) == arg

# Generated at 2022-06-26 04:31:45.893462
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    assert parser_1.print_usage() is None


# Generated at 2022-06-26 04:31:47.898122
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck'])


# Generated at 2022-06-26 04:31:49.642480
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:31:51.602422
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:56.232556
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    # test_case_0: the use of parse method with no arguments
    args_0 = ["-h"]
    sys.argv = args_0
    parser_0.parse(sys.argv)



# Generated at 2022-06-26 04:31:59.822629
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'echo', '23', '--', '--yes', '--help']
    result = parser.parse(argv)
    assert result.command == ['echo', '23', '--yes', '--help']


# Generated at 2022-06-26 04:32:14.534411
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    assert parser_0.print_help() == None

# Generated at 2022-06-26 04:32:16.085810
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:32:28.732814
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args = parser_1.parse(["thefuck", "ls", "-l"])
    print(args)
    args = parser_1.parse(["thefuck", "--"])
    print(args)
    args = parser_1.parse(["thefuck", "-y"])
    print(args)
    args = parser_1.parse(["thefuck"])
    print(args)
    args = parser_1.parse(["thefuck", "--ignore-command"])
    print(args)
    args = parser_1.parse(["thefuck", "--help"])
    print(args)


test_case_0()
test_Parser_parse()

# Generated at 2022-06-26 04:32:36.485957
# Unit test for method parse of class Parser
def test_Parser_parse():
    import sys
    parser=Parser()
    args = parser.parse(sys.argv)
    assert '--version' in args
    assert '--alias' in args
    assert '--help' in args
    assert '-l' in args
    assert 'command' in args
    assert '--debug' in args
    assert '--force-command' in args


# Generated at 2022-06-26 04:32:44.291968
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argv_0 = ["thefuck", "-v"]
    res_0 = parser_1.parse(argv_0)
    assert res_0.version == True
    
    argv_1 = ["thefuck", "-l", "file.log"]
    res_1 = parser_1.parse(argv_1)
    assert res_1.shell_logger == "file.log"
    
    argv_2 = ["thefuck", "--force-command", "command"]
    res_2 = parser_1.parse(argv_2)
    assert res_2.force_command == "command"
    
    argv_3 = ["thefuck", "-a", "alias"]
    res_3 = parser_1.parse(argv_3)
    assert res_3

# Generated at 2022-06-26 04:32:51.521241
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'thefuck', '--', 'ls', '-l'])
    assert args.version == False
    assert args.alias == None
    assert args.shell_logger == None
    assert args.enable_experimental_instant_mode == False
    assert args.help == False
    assert args.yes == False
    assert args.repeat == False
    assert args.debug == False
    assert args.command == ['ls', '-l']


# Generated at 2022-06-26 04:32:55.236233
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print('Running unit test for method print_usage of class Parser...')
    parser = Parser()
    parser.print_usage()
    print('Done\n')



# Generated at 2022-06-26 04:32:56.465825
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    test_case_0()

# Generated at 2022-06-26 04:33:07.832491
# Unit test for constructor of class Parser
def test_Parser():
    import thefuck
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help
    for action in parser._parser._actions:
        if action.dest == 'version':
            assert action.option_strings == ['-v', '--version']
            assert action.action == 'store_true'
            assert action.help == "show program's version number and exit"
        elif action.dest == 'alias':
            assert action.option_strings == ['-a', '--alias']
            assert action.nargs == '?'
            assert action.const == thefuck.utils.get_alias()
            assert action.help == '[custom-alias-name] prints alias for current shell'

# Generated at 2022-06-26 04:33:09.988212
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:23.129803
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_print_usage = Parser()
    parser_print_usage.print_usage()


# Generated at 2022-06-26 04:33:26.179304
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:27.880836
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help()==None


# Generated at 2022-06-26 04:33:36.292220
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    print(parser.parse(['/bin/thefuck', 'vim', 'script.sh']))
    print(parser.parse(['/bin/thefuck', 'vim', 'script.sh', '-l', 'in.log']))

    print(parser.parse(['/bin/thefuck', '-v']))


# Generated at 2022-06-26 04:33:39.940921
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0
    # check if a parser will be built with the correct arguments
    parser_0 = Parser()
    parser_0.print_help()
    assert parser_0


# Generated at 2022-06-26 04:33:42.797513
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:44.767300
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:33:53.148287
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    sys.argv.append("thefuck")
    sys.argv.append("git")
    sys.argv.append("push")
    sys.argv.append("--arg-2")
    sys.argv.append("arg-3")
    sys.argv.append("arg-4")
    sys.argv.append("arg-5")
    argv = sys.argv
    result = parser_0.parse(argv).command
    assert(result == ['git', 'push', '--arg-2', 'arg-3', 'arg-4', 'arg-5'])

# Generated at 2022-06-26 04:33:55.590032
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-26 04:33:58.364591
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True



# Generated at 2022-06-26 04:34:33.462807
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    try:
        parser = Parser()
        parser.print_help()
    except:
        print("Failed")
    else:
        print("Passed")


# Generated at 2022-06-26 04:34:35.584443
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser

# Generated at 2022-06-26 04:34:37.555813
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:34:43.526594
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    Test cases for Parser's method
    :parse
    """
    parser_0 = Parser()
    arguments_0 = parser_0.parse(['thefuck', '--alias'])
    assert arguments_0.alias == 'fuck'
    assert arguments_0.force_command is None
    assert arguments_0.command is None
    assert arguments_0.debug is None
    assert arguments_0.repeat is None
    assert arguments_0.help is False
    assert arguments_0.shell_logger is None
    assert arguments_0.enable_experimental_instant_mode is False
    assert arguments_0.yes is False
    assert arguments_0.version is False
    parser_1 = Parser()
    arguments_1 = parser_1.parse(['thefuck', '-h'])
    assert arguments_1

# Generated at 2022-06-26 04:34:48.583196
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['./thefuck', '--foo', '--enable-experimental-instant-mode', '-h', 'pwd'])
    assert arguments.help == True
    assert arguments.enable_experimental_instant_mode == True
    arguments = parser.parse(['./thefuck', '--force-command=pwd'])
    assert arguments.force_command == 'pwd'



# Generated at 2022-06-26 04:34:52.307504
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:35:00.359090
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._optionals._group_actions[0].dest == 'version'
    assert parser._parser._optionals._group_actions[0].choices == []
    assert parser._parser._optionals._group_actions[0].default == False
    assert parser._parser._optionals._group_actions[0].required == False
    assert parser._parser._optionals._group_actions[0].help == "show program's version number and exit"
    assert parser._parser._optionals._group_actions[1].dest == 'alias'
    assert parser._parser._optionals._group_actions[1].type == None
    assert parser._parser._optionals._group_actions[1].choices == []
    assert parser._parser._optionals._group_actions

# Generated at 2022-06-26 04:35:02.891174
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_p = Parser()
    parser_p.print_usage()



# Generated at 2022-06-26 04:35:05.106930
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-26 04:35:08.052172
# Unit test for constructor of class Parser
def test_Parser():
    cmd = Parser()
    assert str(type(cmd)) == "<class 'thefuck.parser.Parser'>"


# Generated at 2022-06-26 04:36:09.839619
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Test Case 1: test that the method will not run if command is not
    # given
    command = 'ls -l'
    result = parser.parse(command)
    assert result is None
    # Test Case 2: test that the method will run when command is
    # given and return the output
    command = 'thefuck --command ls -l'
    result = parser.parse(command)
    assert result is not None
    # Test Case 3: test that the method will not run if arguments is
    # not given
    command = 'thefuck --command'
    result = parser.parse(command)
    assert result is None
    # Test Case 4: test that the method will run when arguments is
    # given and return the output
    command = 'thefuck --command "ls -l"'

# Generated at 2022-06-26 04:36:13.304436
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    parser_0.print_usage()
    parser_0.print_help()
 
#Test case for Parser._prepare_arguments(self, argv)

# The argv list of arguments is empty

# Generated at 2022-06-26 04:36:18.098759
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.argv[1] = "-h"
    parser_0 = Parser()
    parser_0.print_help()


test_case_0()
test_Parser_print_help()

# Generated at 2022-06-26 04:36:21.612433
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

# Generated at 2022-06-26 04:36:23.588164
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:36:25.360800
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0


# Generated at 2022-06-26 04:36:33.439803
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Case 1. Input is normal and has '--enable-experimental-instant-mode'
    argv1 = ['fuck', '--enable-experimental-instant-mode', 'ls', '-al']
    args1 = parser.parse(argv1)
    assert args1.enable_experimental_instant_mode
    assert args1.command == ['ls', '-al']

    # Case 2. Input is normal and has no '--enable-experimental-instant-mode'
    argv2 = ['fuck', 'ls', '-al']
    args2 = parser.parse(argv2)
    assert not args2.enable_experimental_instant-mode
    assert args2.command == ['ls', '-al']

    # Case 3. Input is 'fuck --'
    arg

# Generated at 2022-06-26 04:36:35.182591
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-26 04:36:35.910999
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:36:40.596422
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:39:12.306632
# Unit test for constructor of class Parser
def test_Parser():
    Test = Parser()
    assert Test



# Generated at 2022-06-26 04:39:13.653145
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser_help = parser.print_help()
    assert parser_help == None

# Generated at 2022-06-26 04:39:14.838584
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:39:16.894288
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:39:20.505026
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None


# Generated at 2022-06-26 04:39:22.898629
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['--help'])
    assert (args.command == [])



# Generated at 2022-06-26 04:39:31.449890
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    tester = list()
    for test_type in range(4):
        try:
            if test_type == 0:
                parser.print_help()
                tester.append(True)
            elif test_type == 1:
                parser.print_usage()
                tester.append(True)
            elif test_type == 2:
                parser.parse(sys.argv)
                tester.append(True)
            elif test_type == 3:
                parser._prepare_arguments(sys.argv)
                tester.append(True)

        except Exception as e:
            tester.append(repr(e))

    if True not in tester:
        print ("[ X ] unit test for method print_help of class Parser failed!")

# Generated at 2022-06-26 04:39:38.741427
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    command = ['git', 'add .']
    argv = ['fuck', 'git', 'add .']
    args = parser_0.parse(argv)
    assert args.command == command

# Integration test for method parse of class Parser

# Generated at 2022-06-26 04:39:39.949491
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:39:40.864327
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()