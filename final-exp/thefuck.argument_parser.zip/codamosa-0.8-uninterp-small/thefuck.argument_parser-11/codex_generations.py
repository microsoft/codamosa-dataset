

# Generated at 2022-06-26 04:29:55.953523
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:00.402642
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:30:04.369396
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    argv = ['thefuck', 'g++', ARGUMENT_PLACEHOLDER, 'hello.cpp']
    prepared_argv = parser._prepare_arguments(argv)
    assert(prepared_argv == ['hello.cpp', '--', 'g++'])
    argv = ['thefuck']
    prepared_argv = parser._prepare_arguments(argv)
    assert(prepared_argv == ['thefuck'])


# Generated at 2022-06-26 04:30:06.553723
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:09.045162
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:11.901484
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    # Debug command for debugging.
    # print parser_0._parser
    assert isinstance(parser_0, Parser)


# Generated at 2022-06-26 04:30:19.764441
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    def mock_print_usage(stream):
        print('usage: thefuck [-h] [-v] [-y | -r] [-a [custom-alias-name]]')
    parser_0._parser.print_usage = mock_print_usage
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:29.096605
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-26 04:30:31.822614
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:37.199768
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    parser = Parser()
    parser.print_usage()
    assert sys.stdout.getvalue() == "usage: thefuck [-h] [-v]\n               [-a [custom-alias-name]] [-l SHELL_LOGGER]\n               [--enable-experimental-instant-mode] [-d]\n               [--force-command FORCE_COMMAND]\n               [command [command ...]]\n"


# Generated at 2022-06-26 04:30:49.283347
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(['thefuck','g','add','.','push','--','.']) == parser_1.parse(['thefuck','g','add','.','push','.'])
    

# Generated at 2022-06-26 04:30:53.399780
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    stderr = sys.stderr
    sys.stderr = StringIO()
    parser_0.print_usage()
    sys.stderr = stderr


# Generated at 2022-06-26 04:30:54.981746
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-26 04:30:58.202212
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:31:00.827201
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:31:07.899714
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', '-r'])
    assert args.repeat is True
    
    args = parser.parse(['thefuck', '-r', 'git', 'stash'])
    assert args.repeat is True
    assert args.command == ['git', 'stash']
    
    parser = Parser()
    args = parser.parse(['thefuck', '-y'])
    assert args.yes is True
    
    parser = Parser()
    args = parser.parse(['thefuck', '-y', 'git', 'add'])
    assert args.yes is True
    assert args.command == ['git', 'add']
    
    parser = Parser()
    args = parser.parse(['thefuck', '-d'])

# Generated at 2022-06-26 04:31:12.408251
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    pass

if __name__ == '__main__':
    # test_case_0()
    test_Parser_print_help()

# Generated at 2022-06-26 04:31:14.754852
# Unit test for constructor of class Parser
def test_Parser():
    """

    """
    parser = Parser()
    assert(parser)


# Generated at 2022-06-26 04:31:17.287388
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:31:19.696626
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)


# Generated at 2022-06-26 04:31:33.536316
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0, Parser)

    parser_1 = Parser()
    assert isinstance(parser_1, Parser)
    assert vars(parser_0) == vars(parser_1)


# Generated at 2022-06-26 04:31:35.736961
# Unit test for constructor of class Parser
def test_Parser():
  test_case_0()

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-26 04:31:42.546413
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser.parse(["thefuck"]).alias == get_alias())
    assert(parser.parse(["thefuck", "--alias"]).alias == get_alias())
    assert(parser.parse(["thefuck", "--alias", "fuck"]).alias == "fuck")
    assert(parser.parse(["thefuck", "-a"]).alias == get_alias())
    assert(parser.parse(["thefuck", "-a", "fuck"]).alias == "fuck")
    assert(parser.parse(["thefuck", "--help"]).help)
    assert(parser.parse(["thefuck", "-h"]).help)
    assert(parser.parse(["thefuck", "--version"]).version)
    assert(parser.parse(["thefuck", "-v"]).version)

# Generated at 2022-06-26 04:31:43.541826
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

# Generated at 2022-06-26 04:31:50.280046
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_01 = Parser()
    args = parser_01.parse(['thefuck', '--alias'])
    assert args.alias == get_alias()
    args = parser_01.parse(['thefuck', '--debug'])
    assert args.debug
    args = parser_01.parse(['thefuck', '--shell-logger', 'shell.log'])
    assert args.shell_logger == 'shell.log'

# Generated at 2022-06-26 04:31:53.900703
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert not parser_0.parse(['-v'])
    assert parser_0.parse(['command']).command == ''



# Generated at 2022-06-26 04:31:55.037583
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()


# Generated at 2022-06-26 04:32:00.918410
# Unit test for method parse of class Parser
def test_Parser_parse():
    print("Function_name: ", inspect.stack()[0][3])
    # Test case 1 with "init" and "--enable-experimental-instant-mode" as command
    argv1 = ["init","--enable-experimental-instant-mode"]
    parser = Parser()
    result = parser.parse(argv1)
    # Test if the result is as expected
    assert result.init == True
    assert result.enable_experimental_instant_mode == True



# Generated at 2022-06-26 04:32:02.725101
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()


# Generated at 2022-06-26 04:32:06.874589
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:32:18.784801
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:21.476711
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:32:23.896928
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser=Parser()
    parser.print_help()


# Generated at 2022-06-26 04:32:34.353536
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    file_stderr = sys.stderr
    temp = sys.stderr
    sys.stderr = open('temp.txt', 'w')
    parser.print_usage()
    sys.stderr.close()
    with open('temp.txt', 'r') as f:
        result = f.read()
    sys.stderr = file_stderr
    assert result == 'usage: thefuck [-h] [-v] [-a [CUSTOM-ALIAS-NAME]] [-l SHELL-LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE-COMMAND] [--yes] [--yeah] [--hard] [-r] [command [command ...]]\n'
    os.remove('temp.txt')

#

# Generated at 2022-06-26 04:32:36.493457
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()

# Generated at 2022-06-26 04:32:38.402067
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    try:
        parser.print_help()
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-26 04:32:40.696262
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck','sudo','fuck','me','up','g'])

# Generated at 2022-06-26 04:32:43.262868
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    parser_0 = Parser()


# Generated at 2022-06-26 04:32:52.786962
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse(["thefuck", "ls"]) == parser_1._parser.parse_args(["ls"])
    assert parser_1.parse(["thefuck", "-v"]) == parser_1._parser.parse_args(["-v"])
    assert parser_1.parse(["thefuck", "ls", ARGUMENT_PLACEHOLDER, "-la"]) == parser_1._parser.parse_args(["-la", "--", "ls"])
    assert parser_1.parse(["thefuck", "-v", ARGUMENT_PLACEHOLDER, "-l", "a"]) == parser_1._parser.parse_args(["-l", "a", "--", "-v"])

# Generated at 2022-06-26 04:32:55.024787
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()

# Generated at 2022-06-26 04:33:16.554420
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-26 04:33:21.270447
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert(parser_0)
    assert(hasattr(parser_0, '_parser'))


# Generated at 2022-06-26 04:33:24.545374
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    print('Method print_usage of class Parser is called')
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:26.912621
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:33:28.329329
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._add_arguments

# Generated at 2022-06-26 04:33:33.843970
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'ls', '-l']
    args = parser.parse(argv)
    assert args.command == ['ls', '-l']


# Generated at 2022-06-26 04:33:36.947291
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import _load_config, update_config
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:33:39.428617
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()._parser.prog == 'thefuck'
    assert Parser()._parser.add_help is False


# Generated at 2022-06-26 04:33:50.976969
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        parser_0.print_usage()
        assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n                  [--enable-experimental-instant-mode]\n                  [-d] [--force-command FORCE_COMMAND] [-y | -r]\n                  command [command ...]\n\n'
    finally:
        sys.stderr = stderr

# Generated at 2022-06-26 04:34:02.926333
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    sys.stderr = io.StringIO()
    parser_1.print_help()

# Generated at 2022-06-26 04:35:00.045661
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    command_1 = ['fuck', '--', 'ls', '-lah']
    args_1 = parser_1.parse(command_1)
    expected_1 = Namespace(debug=False, ah=None, alias=None, command=['ls', '-lah'],
                            enable_experimental_instant_mode=False, force_command=None,
                            help=False, repeat=False, shell_logger=None,
                            version=False, yeah=None, yes=None, l=None)
    assert vars(args_1) == vars(expected_1)

    parser_2 = Parser()
    command_2 = ['fuck', '--debug', '--force-command=ls', '--', 'ls', '-lah']
    args_2 = parser_2

# Generated at 2022-06-26 04:35:02.482711
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_2 = Parser()
    parser_2.print_usage()


# Generated at 2022-06-26 04:35:05.281238
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:35:07.873978
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:10.381678
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser._parser == ArgumentParser(prog='thefuck', add_help=False)



# Generated at 2022-06-26 04:35:16.853377
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args_0 = parser_0.parse(['fuck'])
    assert args_0.command == []

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-26 04:35:20.949781
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['thefuck', 'apt-get', '-y', 'install']
    arguments = parser.parse(argv)
    assert arguments.debug == False
    assert arguments.command == ['apt-get']
    assert arguments.yes == True
    assert arguments.force_command == None
    assert arguments.repeat == False
    assert arguments.debug == False
    assert arguments.help == False
    assert arguments.alias == None
    assert arguments.version == False
    assert arguments.shell_logger == None
    assert arguments.enable_experimental_instant_mode == False


# Generated at 2022-06-26 04:35:22.605701
# Unit test for constructor of class Parser
def test_Parser():
	parser_0 = Parser()


# Generated at 2022-06-26 04:35:25.098880
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert  parser != None



# Generated at 2022-06-26 04:35:26.985052
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()


# Generated at 2022-06-26 04:37:18.673038
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.description is None
    assert parser._parser.usage is None
    assert parser._parser.epilog is None
    # assert parser._parser.version == __version__
    assert parser._parser.add_help is False

    assert parser._parser._positionals._group_actions[0].dest == 'command'
    assert parser._parser._positionals._group_actions[0].metavar == 'command'
    assert parser._parser._positionals._group_actions[0].help == \
        'command that should be fixed'

    assert parser._parser._optionals._group_actions[0].dest == 'version'
    assert parser._parser._optionals._group_actions[0].action == 'store_true'
    assert parser._parser

# Generated at 2022-06-26 04:37:20.842733
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser1 = Parser()
    parser1.print_help()
    parser2 = Parser()
    parser2.print_help()


# Generated at 2022-06-26 04:37:25.216199
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    with Capturing() as output:
        parser_0.print_usage()
        assert_equal(output[0], 'usage: thefuck [-h] [-v] [--enable-experimental-instant-mode]\n                  [-l SHELL_LOGGER] [-a [ALIAS_NAME]] [-y | -r] [-d]\n                  [--force-command FORCE_COMMAND]\n                  [command [command ...]]\n')


# Generated at 2022-06-26 04:37:26.397035
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:37:28.594852
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    parser_0._parser
    return True


# Generated at 2022-06-26 04:37:32.046674
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    arguments = parser_1.parse(['', 'echo', '-a', 'test'])

    assert arguments.alias == 't'
    assert arguments.command == ['echo', '-a', 'test']



# Generated at 2022-06-26 04:37:33.274439
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:37:42.718570
# Unit test for method parse of class Parser
def test_Parser_parse():
    # parser_0: parsed arguments = ['git', 'ad', '-p'],
    #                 args.command = ['git', 'ad', '-p'],
    #                 args.yes = False,
    #                 args.repeat = False,
    #                 args.alias = None,
    #                 args.debug = False,
    #                 args.shell_logger = None,
    #                 args.force_command = None
    parser_0 = Parser()
    args = parser_0.parse(['fuck', 'git', 'ad', '-p'])
    assert args.command == ['git', 'ad', '-p']
    assert args.yes == False
    assert args.repeat == False
    assert args.alias == None
    assert args.debug == False
    assert args.shell_logger == None

# Generated at 2022-06-26 04:37:51.065998
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    import sys
    from unittest.mock import patch

    f = StringIO()
    mock_stdout = patch('thefuck.shells.feedback.sys.stdout', f)
    with mock_stdout:
        parser = Parser()
        parser.print_usage()
        mock_stdout.assert_called_once()
        assert f.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n               [-l SHELL-LOGGER]\n               [--enable-experimental-instant-mode] [-d]\n               [--force-command FORCE-COMMAND]\n               [--] [command [command ...]]\n"


# Generated at 2022-06-26 04:37:53.841106
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Create an instance of class Parser
    parser_1 = Parser()
    # Call method print_help on the instance parser_1
    parser_1.print_help()
