

# Generated at 2022-06-26 04:29:52.270954
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    assert parser_1.parse(['thefuck'])
    parser_2 = Parser()
    parser_2.print_help()
    assert parser_2.parse(['thefuck'])


# Generated at 2022-06-26 04:29:58.317202
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    stderr = sys.stderr
    try:
        sys.stderr = open("./temp_parse_help.txt", "w")
        parser_help = Parser()
        parser_help.print_help()
        sys.stderr.close()
        sys.stderr = open("./temp_parse_help.txt", "r")
        help_contents = sys.stderr.read()
        assert "usage: thefuck" in help_contents
        assert "optional arguments:" in help_contents
    finally:
        sys.stderr.close()
        sys.stderr = stderr


# Generated at 2022-06-26 04:30:03.113757
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    argv = ['/usr/local/bin/thefuck', '--help']
    parser_1.parse(argv)
    # assert parser_1._prepare_arguments(argv) == ['--', '--help']


# Generated at 2022-06-26 04:30:03.925273
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-26 04:30:13.613025
# Unit test for constructor of class Parser
def test_Parser():
    print("\nUnit test for class Parser()")
    parser = Parser()
    assert(parser._parser.prog == 'thefuck')
    assert(parser.parse(['thefuck', '-v']).version)
    assert(parser.parse(['thefuck', '-a']).alias == get_alias())
    assert(parser.parse(['thefuck', '-l', 'test.log']).shell_logger == 'test.log')
    assert(parser.parse(['thefuck', '--enable-experimental-instant-mode']).enable_experimental_instant_mode)
    assert(parser.parse(['thefuck', '-h']).help)
    assert(parser.parse(['thefuck', '-d']).debug)

# Generated at 2022-06-26 04:30:16.659385
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:30:20.105607
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(["python3.6", "--force-command", "git"])


# Generated at 2022-06-26 04:30:22.913959
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:30:26.298862
# Unit test for constructor of class Parser
def test_Parser():
    parser_test_0 = Parser()
    assert parser_test_0 != None


# Generated at 2022-06-26 04:30:29.441823
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    if 'Parser' != parser.__class__.__name__:
        return 1
    else:
        return 0


# Generated at 2022-06-26 04:30:41.988051
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1._parser.prog == "thefuck"
    assert parser_1._parser.add_help is False
    assert parser_1._parser.usage is None
    assert parser_1._parser.description is None
    assert parser_1._parser._actions[0].option_strings == ["-v", "--version"]
    assert parser_1._parser._actions[0].dest == "version"
    assert parser_1._parser._actions[0].default is False
    assert parser_1._parser._actions[0].nargs == 0
    assert parser_1._parser._actions[0].required is False
    assert parser_1._parser._actions[0].choices is None
    assert parser_1._parser._actions[0].help == "show program's version number and exit"


# Generated at 2022-06-26 04:30:44.688783
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:30:47.415773
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_print_usage = Parser()
    parser_print_usage.print_usage()



# Generated at 2022-06-26 04:30:49.505751
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()



# Generated at 2022-06-26 04:30:59.525711
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._add_arguments() == None
    assert parser_0._add_conflicting_arguments() == None
    assert parser_0._parser == ArgumentParser(prog='thefuck', add_help=False)
    assert parser_0._prepare_arguments(['fuck','ls','dir','dir','dir']) == ['dir', 'dir', 'dir', '--', 'fuck', 'ls']
    assert parser_0._prepare_arguments(['fuck','curl','dir','dir','dir']) == ['dir', 'dir', 'dir', '--', 'fuck', 'curl']
    assert parser_0._prepare_arguments(['fuck','curl','dir']) == ['dir', '--', 'fuck', 'curl']
    assert parser_0._prepare

# Generated at 2022-06-26 04:31:02.010306
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:31:04.920139
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['fuck', '--', 'command', 'arg1', 'arg2']
    args = parser.parse(argv)
    assert args.command == ['command', 'arg1', 'arg2']


# Generated at 2022-06-26 04:31:09.514871
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser = Parser()

    args = ['-a', 'fuck', '-v', '--force-command', 'test']


# Generated at 2022-06-26 04:31:16.587924
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser_1 = Parser()
	dummy_argv = ['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '--', '-l']
	expected_argv = ['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '--', '-l']
	actual_argv = parser_1.parse(dummy_argv)
	assert expected_argv == actual_argv.command


# Generated at 2022-06-26 04:31:19.623301
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:31:33.233708
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args_0 = parser_0.parse(["thefuck", "--alias", "fuck"])
    print(args_0.alias)
    assert (args_0.alias == "fuck")
    assert (args_0.command == [])


# Generated at 2022-06-26 04:31:38.077168
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['', '--yes', '--debug', '--shell-logger', '~/log', 'fuck'])
    assert args.yes == True
    assert args.debug == True
    assert args.shell_logger == '~/log'
    assert args.command == ['fuck']
    return True


# Generated at 2022-06-26 04:31:39.063210
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() is not None


# Generated at 2022-06-26 04:31:42.886805
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0, Parser)
    assert parser_0._parser.usage is not None
    assert len(parser_0._parser._actions[-4].option_strings) == 3


# Generated at 2022-06-26 04:31:46.289188
# Unit test for constructor of class Parser
def test_Parser():
    print ("\nTesting Parser")
    t_parser_0 = test_case_0()
    print ("Passed!\n")


# Generated at 2022-06-26 04:31:48.562309
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None
    assert parser.print_help() == None


# Generated at 2022-06-26 04:31:50.354327
# Unit test for method print_help of class Parser
def test_Parser_print_help():
	parser_1 = Parser()
	parser_1.print_help()
	assert True


# Generated at 2022-06-26 04:31:52.190674
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:31:54.954002
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:32:00.843776
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    parser_0.print_help()
    parser_0.print_usage()
    parser_0.parse([])
    parser_0.parse(['--shell-logger=something'])
    parser_0.parse([ARGUMENT_PLACEHOLDER])
    parser_0.parse(['--','--shell-logger=something'])
    parser_0.parse([ARGUMENT_PLACEHOLDER,'--shell-logger=something'])

# Generated at 2022-06-26 04:32:13.760718
# Unit test for constructor of class Parser
def test_Parser():
    # Test case 0
    test_case_0()
    # Test case 1


# Generated at 2022-06-26 04:32:17.634813
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()

test_case_0()

test_Parser_print_help()

# Generated at 2022-06-26 04:32:18.639191
# Unit test for constructor of class Parser
def test_Parser():
    assert(Parser())



# Generated at 2022-06-26 04:32:19.942695
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0, Parser)


# Generated at 2022-06-26 04:32:21.419882
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()

# Generated at 2022-06-26 04:32:25.143183
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == parser._parser.print_usage(sys.stderr)


# Generated at 2022-06-26 04:32:27.217118
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    parser = Parser()
    # call print_usage method
    parser.print_usage()


# Generated at 2022-06-26 04:32:30.504337
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:32:33.219567
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv = ['thefuck']
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:32:37.542711
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

    if parser._parser.print_usage != None:
        print ( parser._parser.print_usage == None )
    else:
        print ( parser._parser.print_usage != None )


# Generated at 2022-06-26 04:33:05.156985
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    result = parser_0.parse(["thefuck","-v"])
    assert type(result) == argparse.Namespace
    

# Generated at 2022-06-26 04:33:13.707884
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['-d', '-a', 'fuck', ARGUMENT_PLACEHOLDER, '-b', '-c']
    args = parser.parse(argv)
    assert args.debug is True
    assert args.alias == 'fuck'
    assert args.command == ['-b', '-c']
    assert args.force_command is None
    assert args.debug is True
    assert args.yes is False
    assert args.repeat is False
    argv = ['-d', '-a', 'fuck', ARGUMENT_PLACEHOLDER, 'ls', '-b', '-c']
    args = parser.parse(argv)
    assert args.debug is True
    assert args.alias == 'fuck'

# Generated at 2022-06-26 04:33:16.268119
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:33:17.570126
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    help_1 = parser_1.print_help()


# Generated at 2022-06-26 04:33:19.649976
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # parser_1 = Parser()
    # parser_1.print_usage()

    with pytest.raises(AttributeError):
        parser_2 = Parser()
        parser_2.print_usage()


# Generated at 2022-06-26 04:33:22.551433
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()
# Unit test end


# Generated at 2022-06-26 04:33:23.276108
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:33:26.325460
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert isinstance(parser_0, Parser)


# Generated at 2022-06-26 04:33:28.259378
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:33:31.836568
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()

    # Print usage information
    parser_1.print_usage()


# Generated at 2022-06-26 04:34:25.795010
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():

    # Initialize parser
    parser = Parser()
    assert parser is not None

    # Now try to execute print_usage
    parser.print_usage()


# Generated at 2022-06-26 04:34:29.649830
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args = parser_0.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']


# Generated at 2022-06-26 04:34:33.033514
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser is not None


# Generated at 2022-06-26 04:34:36.485241
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

# Generated at 2022-06-26 04:34:38.863869
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

# Generated at 2022-06-26 04:34:47.717287
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    res = parser_1.parse(['thefuck', 'echo', 'fuck'])
    assert res.command == ['echo', 'fuck']
    res = parser_1.parse(['thefuck', 'cat', 'fuck.py'])
    assert res.command == ['cat', 'fuck.py']
    res = parser_1.parse(['thefuck', 'python', 'fuck.py'])
    assert res.command == ['python', 'fuck.py']


# Generated at 2022-06-26 04:34:51.034005
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    parser_0.parse(["python", "fuck", "command"])


# Generated at 2022-06-26 04:35:00.100361
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser_1 = Parser()
    argv_1_0 = ["test", "--", "test", "-d"]
    flag_1_0, command_1_0 = parser_1.parse(argv_1_0)
    print(flag_1_0, " ", command_1_0)
    assert flag_1_0.command == ['-d', 'test']
    assert command_1_0 == []

    parser_2 = Parser()

# Generated at 2022-06-26 04:35:10.740821
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    
    stderr_targ = sys.stderr
    stderr_test = StringIO()
    sys.stderr = stderr_test                   # replace stderr with StringIO instance
    parser_1.print_usage()
    sys.stderr = stderr_targ                   # restore original stderr

    print(stderr_test.getvalue())
    assert stderr_test.getvalue()==("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n            [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n            [--] [command [command ...]]\n\n")


# Generated at 2022-06-26 04:35:19.641499
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import SuppressedOutput
    from .const import ALIAS
    parser = Parser()
    argv = ALIAS + ' command'
    with SuppressedOutput():
        result = parser.parse(argv)
    expected = argparse.Namespace(alias=None, command=['command'], debug=False,
                                  enable_experimental_instant_mode=False,
                                  force_command=None, help=False,
                                  repeat=False, shell_logger=None,
                                  version=False, yes=False)
    assert result == expected
    expected_argv = [ALIAS, 'command']
    assert parser._prepare_arguments(expected_argv) == ['command']

# Generated at 2022-06-26 04:37:51.322986
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser) == True


# Generated at 2022-06-26 04:37:53.648359
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        parser = Parser()
        parser.print_usage()
    except SystemExit as e:
        pass
    except:
        assert False


# Generated at 2022-06-26 04:37:55.420313
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assertion = parser.parse(['fuck', '-h'])
    assert assertion.help is True


# Generated at 2022-06-26 04:37:56.695306
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:38:06.838962
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys

    def StringIO():
        import StringIO
        return StringIO.StringIO()

    def mock_parser_print_usage(argv):
        s = StringIO()
        parser_1 = Parser()
        parser_1.print_usage(file=s)
        return s

    sys.stderr = StringIO()
    mock_parser_print_usage(['thefuck', '--alias'])
    parser_res = sys.stderr.getvalue()

# Generated at 2022-06-26 04:38:08.590382
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Testcase 0
    parser_0 = Parser()
    assert parser_0._parser.print_help(sys.stderr) is None

# Generated at 2022-06-26 04:38:10.291293
# Unit test for constructor of class Parser
def test_Parser():
    import sys
    sys.argv = [""]
    parser = Parser()


# Generated at 2022-06-26 04:38:11.937984
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    # test case 0
    # normal call
    parser_0.print_help()


# Generated at 2022-06-26 04:38:18.528272
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.print_usage()
    parser.print_help()
    parser.parse(sys.argv)
    parser = Parser()
    parser.parse(['thefuck'])

test_Parser()

# Generated at 2022-06-26 04:38:32.719235
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    assert parser_1.parse([]) == parser_1._parser.parse_args([])
    assert parser_1.parse(['thefuck']) == parser_1._parser.parse_args([])
    assert parser_1.parse(['thefuck', '--debug']) == parser_1._parser.parse_args(['--debug'])
    assert parser_1.parse(['thefuck', 'test']) == parser_1._parser.parse_args(['--', 'test'])
    assert parser_1.parse(['thefuck', 'test', 'test1']) == parser_1._parser.parse_args(['--', 'test', 'test1'])
    assert parser_1.parse(['thefuck', 'test', 'test1', '--debug']) == parser_1._parser