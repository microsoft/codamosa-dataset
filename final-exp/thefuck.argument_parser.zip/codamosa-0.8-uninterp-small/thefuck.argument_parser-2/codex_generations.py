

# Generated at 2022-06-26 04:29:53.662048
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_help = Parser()
    parser_help.print_help()



# Generated at 2022-06-26 04:29:59.792751
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0._parser.format_usage() == 'usage: thefuck [--version] [--alias [custom-alias-name]] [--shell-logger logfile] [--enable-experimental-instant-mode] [--help] [-y | -r] [-d] [--force-command command] [--] [command [command ...]]'

# Generated at 2022-06-26 04:30:06.074993
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck']) == parser.parse(['fuck', '--'])
    assert parser.parse(['fuck', 'git', 'push']) == parser.parse(['fuck', '--', 'git', 'push'])
    assert parser.parse(['fuck', ARGUMENT_PLACEHOLDER, 'ls', '-la']) == parser.parse(['fuck', '--', 'ls', '-la'])
    assert parser.parse(['fuck', '-v']) == parser.parse(['fuck', '-v', '--'])
    assert parser.parse(['fuck', '-v', ARGUMENT_PLACEHOLDER, 'ls', '-la']) == parser.parse(['fuck', '-v', '--', 'ls', '-la'])

# Generated at 2022-06-26 04:30:08.579321
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()


# Generated at 2022-06-26 04:30:12.513172
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    stderr_0 = sys.stderr
    sys.stderr = StringIO()
    parser_0.print_usage()
    assert 'usage' in sys.stderr.getvalue()
    sys.stderr = stderr_0


# Generated at 2022-06-26 04:30:24.099508
# Unit test for constructor of class Parser

# Generated at 2022-06-26 04:30:26.753175
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), Parser)


# Generated at 2022-06-26 04:30:35.693023
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    args_0 = parser_0.parse([])
    assert args_0.debug == False
    assert args_0.enable_experimental_instant_mode == False
    assert args_0.force_command == None
    assert args_0.alias == None
    assert args_0.shell_logger == None
    assert args_0.repeat == False
    assert args_0.yes == False
    assert args_0.help == False
    assert args_0.version == False
    assert args_0.command == []


# Generated at 2022-06-26 04:30:43.388632
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    answer_1 = parser_1.parse(['', '-r', '--', 'ls', '-l'])
    assert answer_1.repeat == True

    parser_2 = Parser()
    answer_2 = parser_2.parse(['', '-r', 'ls', '-l'])
    assert answer_2.repeat == True

    parser_3 = Parser()
    answer_3 = parser_3.parse(['', '-r', 'ls', '-l', '-a'])
    assert answer_3.repeat == True

# Generated at 2022-06-26 04:30:45.520823
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

# Generated at 2022-06-26 04:30:51.660510
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:30:53.394463
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # call print_help
    parser_1 = Parser()
    parser_1.print_help()


# Generated at 2022-06-26 04:30:54.981869
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-26 04:30:58.201239
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_PH = Parser()
    parser_PH.print_help()


# Generated at 2022-06-26 04:31:00.894565
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Unit test for the parser.parse() of class Parser.
    pass


# Generated at 2022-06-26 04:31:04.720137
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['--help'])
    parser_1.parse(['--debug'])
    parser_1.parse(['--hard'])
    parser_1.parse([ARGUMENT_PLACEHOLDER])



# Generated at 2022-06-26 04:31:08.663796
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['-d'])
    assert args.debug is True


# Generated at 2022-06-26 04:31:18.095456
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck', 'git'])
    parser_1.parse(['thefuck', 'git', 'log', '--format=%an', ARGUMENT_PLACEHOLDER, '-H'])
    parser_1.parse(['thefuck', 'git', 'log', '--format=%an', '-H'])
    parser_1.parse(['thefuck', 'git', 'log', '--format=%an', '-H', '--'])
    parser_1.parse(['thefuck', 'git', 'log', '--format=%an', '-H', ARGUMENT_PLACEHOLDER, '--'])

# Generated at 2022-06-26 04:31:21.877605
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    p = parser_1.parse(["sudo", "fuck", "-a", "fuck", "man", "fuck"])
    assert p.command == ["man", "fuck"]

    parser_2 = Parser()
    p = parser_2.parse(["sudo", "fuck", "-a"])
    assert p.command == []

    parser_3 = Parser()
    p = parser_3.parse(["sudo", "fuck"])
    assert p.command == []



# Generated at 2022-06-26 04:31:24.642362
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:31:31.948816
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        parser_0.print_usage()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 04:31:37.705644
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    sys.argv = ['thefuck', '--force-command', 'ls']
    sys.argv[1:] = parser_1._prepare_arguments(sys.argv[1:])
    assert parser_1.parse(sys.argv).command == ['ls']
    assert parser_1.parse(sys.argv).force_command == 'ls'


# Generated at 2022-06-26 04:31:38.450220
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_case_0()

# Generated at 2022-06-26 04:31:45.716720
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse([])
    assert arguments.__dict__ == {'debug': False, 'repeat': False,
                                  'alias': None, 'version': False, 'yes': False,
                                  'command': [], 'force_command': None, 'help': False,
                                  'shell_logger': None, 'enable_experimental_instant_mode': False}

    arguments = parser.parse(['--debug'])
    assert arguments.__dict__ == {'debug': True, 'repeat': False,
                                  'alias': None, 'version': False, 'yes': False,
                                  'command': [], 'force_command': None, 'help': False,
                                  'shell_logger': None, 'enable_experimental_instant_mode': False}

    arguments = parser.parse

# Generated at 2022-06-26 04:31:47.417313
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()

# Generated at 2022-06-26 04:31:54.067601
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck', 'ls', '-l']) == Namespace(
        alias=None,
        command=['ls', '-l'],
        debug=False,
        enable_experimental_instant_mode=False,
        force_command=None,
        help=False,
        repeat=False,
        shell_logger=None,
        version=False,
        yes=False)


# Generated at 2022-06-26 04:31:57.571414
# Unit test for constructor of class Parser

# Generated at 2022-06-26 04:31:58.917272
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # parser_0 = Parser()
    pass


# Generated at 2022-06-26 04:32:05.809733
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_parse = Parser()
    parser_parse.parse(['thefuck', '--version'])
    parser_parse.parse(['thefuck', '--debug'])
    parser_parse.parse(['thefuck', '--force-command', '--'])
    parser_parse.parse(['thefuck', '--force-command', '--', 'python'])
    parser_parse.parse(['thefuck', '--debug', '--version', '--'])
    parser_parse.parse(['thefuck', '--debug', '--version', '--', 'python'])
    parser_parse.parse(['thefuck', '-v', '--debug', '--'])
    parser_parse.parse(['thefuck', '-v', '--debug', '--', 'python'])


# Generated at 2022-06-26 04:32:09.654107
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    with patch('sys.stderr.write') as write_mock:
        parser_0 = Parser()
        parser_0.print_usage()
        write_mock.assert_called_once_with(
            'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]'
            '\n              [--enable-experimental-instant-mode] [-y] [-r]'
            ' [-d]\n              [--force-command FORCE_COMMAND]'
            ' [command [command ...]]\n')


# Generated at 2022-06-26 04:32:15.678241
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', '-a', 'fuck'])


# Generated at 2022-06-26 04:32:21.531211
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test case for empty arguments
    parser = Parser()
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])

    # Test case for 1 argument
    assert parser.parse(['thefuck', '-v']) == parser._parser.parse_args(['-v'])

    # Test case for 2 arguments
    assert parser.parse(['thefuck', '-l', 'log.txt']) == parser._parser.parse_args(['-l', 'log.txt'])

    # Test case for 3 arguments
    assert parser.parse(['thefuck', '-l', 'log.txt', '-d']) == parser._parser.parse_args(['-l', 'log.txt', '-d'])

    # Test case for placeholder with 1 argument

# Generated at 2022-06-26 04:32:32.112517
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()

    assert '-v' in parser_0._parser._get_kwargs()
    assert '--version' in parser_0._parser._get_kwargs()
    assert '-a' in parser_0._parser._get_kwargs()
    assert '--alias' in parser_0._parser._get_kwargs()
    assert '-l' in parser_0._parser._get_kwargs()
    assert '--shell-logger' in parser_0._parser._get_kwargs()
    assert '-h' in parser_0._parser._get_kwargs()
    assert '--help' in parser_0._parser._get_kwargs()
    assert '-y' in parser_0._parser._get_kwargs()
    assert '--yes' in parser_0._parser._get_kw

# Generated at 2022-06-26 04:32:40.139007
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', '--alias'])
    assert args.alias == 'fuck'

    args = parser.parse(['thefuck', '--debug'])
    assert args.debug is True

    args = parser.parse(['thefuck', '--help'])
    assert args.help is True

    args = parser.parse(['thefuck', '--yes'])
    assert args.yes is True

    parser.print_usage()

    parser.print_help()

# Generated at 2022-06-26 04:32:41.941643
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.stderr = StringIO()
    Parser().print_help()
    print(sys.stderr.getvalue())


# Generated at 2022-06-26 04:32:52.144903
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    args_1 = parser_1.parse(['command'])
    assert args_1.command == ['command']
    assert args_1.repeat is False
    assert args_1.shell_logger is None
    assert args_1.help is True
    assert args_1.version is False
    assert args_1.debug is False
    assert args_1.force_command is None

    argv_2 = ['command', 'arg1', ARGUMENT_PLACEHOLDER, 'arg2']
    args_2 = parser_1.parse(argv_2)
    assert args_2.command == ['command', 'arg1']
    assert args_2.repeat is False
    assert args_2.shell_logger is None
    assert args_2.help is True

# Generated at 2022-06-26 04:32:52.763354
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() != None

# Generated at 2022-06-26 04:33:00.539058
# Unit test for method parse of class Parser
def test_Parser_parse():
    #------------------------------------------------------------------
    parser_1 = Parser()
    #Inputs
    #argv = ["thefuck","sudo","apt-get","install","htop","&&", "apt-get","install","htop"]
    argv = ["thefuck", "sudo", "apt-get", "install", "htop", "&&", "apt-get", "install", "htop"]
    #argv = ["thefuck", "sudo", "apt-get", "install", "htop", "&&", "apt-get", "install", "htop",ARGUMENT_PLACEHOLDER,"-d","-v","--help","-a","-l","--shell-logger","--enable-experimental-instant-mode","-h","--debug","--force-command","df","df","df","df","df","df","df","df

# Generated at 2022-06-26 04:33:06.549926
# Unit test for constructor of class Parser
def test_Parser():
    # Case 0
    parser_0 = Parser()

    assert parser_0._parser.prog == 'thefuck'
    assert parser_0._parser.usage == None

    # Case 1
    parser_1 = Parser()

    assert parser_1._parser.prog == 'thefuck'
    assert parser_1._parser.usage != None



# Generated at 2022-06-26 04:33:10.722289
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    assert parser_1.print_help == Parser._parser.print_help


# Generated at 2022-06-26 04:33:22.973406
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-26 04:33:23.729377
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse("fuck -h") == 0


# Generated at 2022-06-26 04:33:28.750871
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    test_run = parser_0.print_help()
    assert(test_run == None) # 1. Parser class is not calling exit()
    assert(type(test_run) == type(None)) # 2. return type is NoneType


# Generated at 2022-06-26 04:33:32.109781
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:34.783000
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:33:36.718208
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert callable(parser.print_help)

# Generated at 2022-06-26 04:33:43.774748
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # case 0:
    argv=["thefuck", "git", "push", "origin", "master"]
    result = parser.parse(argv)
    assert result.command == ['git', 'push', 'origin', 'master']
    assert result.alias is None
    assert result.yes is False
    assert result.repeat is False

    # case 1:
    argv=["thefuck", "--", "git", "push", "origin", "master"]
    result = parser.parse(argv)
    assert result.command == ['git', 'push', 'origin', 'master']
    assert result.alias is None
    assert result.yes is False
    assert result.repeat is False

    # case 2:

# Generated at 2022-06-26 04:33:47.106682
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:49.346838
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:33:52.137856
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:34:07.573629
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser().parse('thefuck --help'.split(' '))
    print("\n\n##### print_help() ######\n")
    print(parser)
    Parser().print_help()

# Generated at 2022-06-26 04:34:18.338633
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_0 = Parser()
    assert parser_0.parse(['thefuck', '-d']) == parser_0.parse(['thefuck', '--debug'])
    assert parser_0.parse(['thefuck', '-a']) == parser_0.parse(['thefuck', '--alias'])
    assert parser_0.parse(['thefuck', '-y']) == parser_0.parse(['thefuck', '--yes'])


# Generated at 2022-06-26 04:34:24.834262
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser = Parser()

    # Case 1: test_argv = ['/usr/local/bin/thefuck', 'ls']
    test_argv_1 = ['/usr/local/bin/thefuck', 'ls']
    args_1 = parser.parse(test_argv_1)
    assert args_1.command == ['ls']
    assert args_1.shell_logger == None
    assert args_1.enable_experimental_instant_mode == False
    assert args_1.help == False
    assert args_1.yes == False
    assert args_1.repeat == False
    assert args_1.debug == False

    # Case 2: test_argv = ['/usr/local/bin/thefuck', 'ls', '-r']

# Generated at 2022-06-26 04:34:28.565567
# Unit test for method print_help of class Parser

# Generated at 2022-06-26 04:34:32.511500
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:34:34.996383
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None
    parser_0 = Parser()
    test_case_0()


parser = Parser()


if __name__ == '__main__':

    args = parser.parse(sys.argv)
    print(args)

# Generated at 2022-06-26 04:34:42.482010
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser = Parser()


# Generated at 2022-06-26 04:34:47.481666
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    parser_1.parse(['thefuck', 'command'])

    parser_2 = Parser()
    parser_2.parse(['thefuck', 'command', ARGUMENT_PLACEHOLDER, 'arg'])


# Generated at 2022-06-26 04:34:49.646203
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert p.print_help() == None


# Generated at 2022-06-26 04:34:51.755534
# Unit test for constructor of class Parser
def test_Parser():
    parser_0 = Parser()
    assert parser_0


# Generated at 2022-06-26 04:35:15.694524
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), Parser)



# Generated at 2022-06-26 04:35:17.367672
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-26 04:35:19.841410
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser) == True


# Generated at 2022-06-26 04:35:24.825109
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_1 = Parser()
    parser_1.print_help()
    parser_1._parser.print_help(sys.stdout)


# Generated at 2022-06-26 04:35:28.406659
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_help = Parser().print_usage()
    assert test_help is None, 'Failed to display help'


# Unit for method print_help of class Parser

# Generated at 2022-06-26 04:35:32.269102
# Unit test for constructor of class Parser
def test_Parser():

    parser_0 = Parser()
    parser_0.print_help()

    parser_1 = Parser()
    parser_1.print_help()



# Generated at 2022-06-26 04:35:36.929164
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_0 = Parser()
    parser_0.print_help()

#Unit test for method print_usage of class Parser

# Generated at 2022-06-26 04:35:39.398743
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:35:52.186928
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser_1 = Parser()
    # parser_1.parse(['thefuck', 'ls', '-a'])
    parser_1.parse(['thefuck', 'ls', '-a'])
    parser_1.parse(['thefuck', 'ls', '-a', '-l', '-r'])
    parser_1.parse(['thefuck', 'ls', '-a', '-l', '-r', '--help'])
    parser_1.parse(['thefuck', 'ls', '-a', '-l', '-r', '--debug'])
    parser_1.parse(['thefuck', 'ls', '-a', '-l', '-r', '-d'])


# Generated at 2022-06-26 04:35:53.895438
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:37:01.822222
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    try:
        parser_0.print_usage()
    except:
        print("error")
    assert True


# Generated at 2022-06-26 04:37:03.771209
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_1 = Parser()
    parser_1.print_usage()


# Generated at 2022-06-26 04:37:05.649695
# Unit test for method print_help of class Parser
def test_Parser_print_help():

    parser = Parser()
    parser.print_help()


# Generated at 2022-06-26 04:37:06.757754
# Unit test for constructor of class Parser
def test_Parser():
    test_case_0()

# Generated at 2022-06-26 04:37:08.690092
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:37:10.728917
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert parser_1._parser.prog == 'thefuck'
    assert parser_1._parser.add_help == False


# Generated at 2022-06-26 04:37:14.084274
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print('\nTesting print_usage of class Parser')
    parser_0 = Parser()
    parser_0.print_usage()


# Generated at 2022-06-26 04:37:16.821899
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.__class__ == Parser


# Generated at 2022-06-26 04:37:17.669353
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None


# Generated at 2022-06-26 04:37:21.283415
# Unit test for constructor of class Parser
def test_Parser():
    parser_1 = Parser()
    assert(len(parser_1._parser._actions) == 11)
    assert(parser_1._parser.prog == 'thefuck')
    assert(parser_1._parser.add_help == False)



# Generated at 2022-06-26 04:39:45.223246
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # check usage with command
    sys.argv = ['/usr/bin/thefuck', 'fib']
    parser_0 = Parser()
    parser_0.print_usage()
    # check usage without command
    sys.argv = ['/usr/bin/thefuck']
    parser_0 = Parser()
    parser_0.print_usage()

