

# Generated at 2022-06-12 09:49:52.621972
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
        parser.parse(['thefuck', 'ls', '-l'])



# Generated at 2022-06-12 09:49:56.106932
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.stderr = open(os.devnull, 'w')
    parser = Parser()
    assert parser.print_usage() is None
    sys.stderr = sys.__stderr__


# Generated at 2022-06-12 09:49:57.495261
# Unit test for constructor of class Parser
def test_Parser():
    result = Parser()

# Generated at 2022-06-12 09:50:01.797174
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ["thefuck", "ls", "-la", "--all", "--", "etc", "tmp"]
    parser = Parser()
    assert parser.parse(argv).command == ["etc", "tmp"]
    assert parser.parse(argv).all
    assert not parser.parse(argv).version

# Generated at 2022-06-12 09:50:05.284528
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    s = StringIO()
    sys.stderr = s

    parser = Parser()
    parser.print_help()
    result = s.getvalue()

    sys.stderr = sys.__stderr__

    assert 'usage: thefuck' in result

# Generated at 2022-06-12 09:50:10.800023
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import _prepare_arguments
    from mock import patch
    patch('thefuck.utils._prepare_arguments').start()
    _prepare_arguments.return_value = ['alias', '-d', '--debug', 'command']
    from thefuck.parser import Parser
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-12 09:50:11.811820
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser=Parser()
    parser.print_help()

# Generated at 2022-06-12 09:50:16.294946
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(["   ld   ", "-a", ARGUMENT_PLACEHOLDER, "--force-command", "git", "status", "&&", "git", "add", "-A"])
    assert arguments.force_command == "git status && git add -A"

# Generated at 2022-06-12 09:50:22.046779
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    orig_print_usage = parser._parser.print_usage
    orig_print_help = parser._parser.print_help
    try:
        parser._parser.print_usage = lambda f: ''
        parser._parser.print_help = lambda f: ''
        parser.print_usage()
        parser.print_help()
    finally:
        parser._parser.print_usage = orig_print_usage
        parser._parser.print_help = orig_print_help

# Generated at 2022-06-12 09:50:32.345703
# Unit test for constructor of class Parser
def test_Parser():
    from thefuck.utils import get_alias
    assert Parser._add_arguments.__name__ == '_add_arguments'
    assert Parser._add_conflicting_arguments.__name__ == '_add_conflicting_arguments'
    assert Parser._prepare_arguments.__name__ == '_prepare_arguments'
    assert Parser.parse.__name__ == 'parse'
    assert Parser.print_usage.__name__ == 'print_usage'
    assert Parser.print_help.__name__ == 'print_help'
    assert Parser.__init__.__name__ == '__init__'
    parser = Parser()
    assert len(vars(parser._parser.parse_args([])).keys()) > 0

# Generated at 2022-06-12 09:50:39.449063
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    expected_args = parser._parser.parse_args(['command'])
    args = parser.parse(['thefuck', 'command'])
    assert args.command == expected_args.command


# Generated at 2022-06-12 09:50:45.780122
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def capture(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, StringIO()
        command(*args, **kwargs)
        sys.stdout.seek(0)
        yield sys.stdout.read()
        sys.stdout = out

    parser = Parser()
    with capture(parser.print_help) as output:
        assert len(output) > 0



# Generated at 2022-06-12 09:50:51.137818
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .config import Config
    from .utils import suppress_stdout

    with suppress_stdout():
        parser = Parser()
        assert '[custom-alias-name]' in parser.print_usage()

        config = Config()
        config.clear()
        config.update({'manual_mode': False})
        parser = Parser()
        assert '[custom-alias-name]' not in parser.print_usage()



# Generated at 2022-06-12 09:50:52.605460
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:51:03.095590
# Unit test for constructor of class Parser
def test_Parser():
    print ("Test Parser class...")
    _parser = Parser()
    _parser.parse([''])
    _parser.parse(["", "--version"])
    _parser.parse(["", "--help"])
    _parser.parse(["", "--debug"])
    _parser.parse(["", "--shell-logger"])
    _parser.parse(["", "--yes"])
    _parser.parse(["", "--repeat"])
    _parser.parse(["", "--force-command"])
    _parser.parse([""])
    _parser.parse(["", ARGUMENT_PLACEHOLDER])
    _parser.parse(["", "--version"])
    _parser.parse(["", "--help"])

# Generated at 2022-06-12 09:51:04.531879
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-12 09:51:06.223758
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:51:10.901009
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    output = StringIO.StringIO()
    sys.stderr = output
    Parser().print_help()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 09:51:14.014312
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p._add_arguments()
    assert p
    assert p._parser
    assert p._parser.add_argument
    assert p._add_conflicting_arguments
    assert p._prepare_arguments

# Generated at 2022-06-12 09:51:14.882755
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.print_help()

# Generated at 2022-06-12 09:51:25.444418
# Unit test for constructor of class Parser
def test_Parser():
    assert(Parser())

# Generated at 2022-06-12 09:51:28.372158
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    f = StringIO()
    Parser().print_usage(file=f)
    assert 'usage: thefuck' in f.getvalue()


# Generated at 2022-06-12 09:51:29.337009
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:51:34.360447
# Unit test for method parse of class Parser
def test_Parser_parse():
    # When
    parser = Parser()
    command = 'flake8'
    args = ['/bin/thefuck', '-d', '--', command]
    result = parser.parse(args)

    # Then
    assert result.debug == True
    assert result.command == [command]


# Generated at 2022-06-12 09:51:37.275796
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().parse([]).help == False
    assert Parser().parse(['-h']).help == True
    assert Parser().parse(['--help']).help == True


# Generated at 2022-06-12 09:51:38.982158
# Unit test for constructor of class Parser
def test_Parser():
  assert Parser(prog = 'thefuck', add_help = False)

# Generated at 2022-06-12 09:51:46.673623
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Test for method print_usage() of class Parser"""
    from StringIO import StringIO
    from .utils import which
    
    # Create a string buffer
    sio = StringIO()
    # Redirect stdout to string buffer
    sys.stdout = sio
    # Run method print_usage()
    Parser().print_usage()
    # Recover stdout
    sys.stdout = sys.__stdout__
    
    # Compare output to an expected string
    assert sio.getvalue() == ''

# Generated at 2022-06-12 09:51:48.006666
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)


# Generated at 2022-06-12 09:51:50.003825
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'


# Generated at 2022-06-12 09:51:55.841875
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    #argv = ['fuck', '-d', '--', 'git', 'status']
    argv = ['fuck', '/home/julien/Documents/CityEngine/cityengine/bin/cebatch.sh', '-d', '--', 'git', 'status']
    print("argv")
    print(argv)
    print("parse")
    print(parser.parse(argv))

test_Parser_parse()

# Generated at 2022-06-12 09:52:22.998897
# Unit test for constructor of class Parser
def test_Parser():
    from .utils import mock, get_alias
    get_alias_mock = mock.patch('thefuck.parser.get_alias').start()
    get_alias_mock.return_value = 'tf'
    sys.argv = ['thefuck', '--alias=fuck']
    assert Parser().parse(sys.argv).alias == 'fuck'
    sys.argv = ['thefuck', '-a']
    assert Parser().parse(sys.argv).alias == 'tf'
    sys.argv = ['thefuck', '-a=fuck']
    print(sys.argv)
    assert Parser().parse(sys.argv).alias == 'fuck'
    mock.patch('thefuck.parser.get_alias').stop()

# Generated at 2022-06-12 09:52:31.711994
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from mock import patch
    from thefuck.shells import get_supported_shells
    parser = Parser()
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        parser.print_usage()
        assert stderr.getvalue() == (
            'Usage: thefuck [-h] [-v] [-a [{shell}]] [-l SHELL_LOGGER] '
            '[-y] [-r] [-d] [--enable-experimental-instant-mode] '
            '[--force-command FORCE_COMMAND] [command [command ...]]\n')



# Generated at 2022-06-12 09:52:39.120447
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser._parser.parse_args([])
    assert (parser.parse(['thefuck', '-v']) ==
            parser._parser.parse_args(['-v']))
    assert (parser.parse(['thefuck', '--debug']) ==
            parser._parser.parse_args(['--debug']))
    assert (parser.parse(['thefuck', '--alias']) ==
            parser._parser.parse_args(['--alias']))
    assert (parser.parse(['thefuck', '--alias', 'fuck']) ==
            parser._parser.parse_args(['--alias', 'fuck']))

# Generated at 2022-06-12 09:52:46.653079
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    parser = Parser()
    old_stderr = sys.stderr
    sys.stderr = stringio = StringIO()
    try:
        parser.print_help()
    finally:
        sys.stderr = old_stderr
    assert u'usage: thefuck [-h] [-v] [-a [custom-alias-name]]' \
           u' [-l SHELL_LOGGER] [--enable-experimental-instant-mode]' \
           u' [-y | -r] [-d] [--force-command FORCE_COMMAND]' \
           u' [command [command ...]]' in stringio.getvalue()
    assert u'help' in stringio.getvalue()
    assert u'show this help message and exit' in stringio.getvalue()
   

# Generated at 2022-06-12 09:52:57.470037
# Unit test for constructor of class Parser
def test_Parser():
    parserObj = Parser()
    assert parserObj._parser.prog == 'thefuck'
    assert parserObj._parser._actions[0].dest == 'version'
    assert parserObj._parser._actions[0].help == "show program's version number and exit"
    assert parserObj._parser._actions[0].option_strings == ['-v', '--version']
    assert parserObj._parser._actions[0].nargs == 0
    assert parserObj._parser._actions[1].dest == 'alias'
    assert parserObj._parser._actions[1].const == get_alias()
    assert parserObj._parser._actions[1].help == '[custom-alias-name] prints alias for current shell'
    assert parserObj._parser._actions[1].option_strings == ['-a', '--alias']

# Generated at 2022-06-12 09:52:58.675979
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:53:03.436887
# Unit test for constructor of class Parser
def test_Parser():
    def check_in_argparse_class(arg):
        assert arg in dir(ArgumentParser)

    p = Parser()
    check_in_argparse_class('add_argument')
    check_in_argparse_class('add_mutually_exclusive_group')
    check_in_argparse_class('parse_args')
    check_in_argparse_class('print_usage')


# Generated at 2022-06-12 09:53:14.448705
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck', 'MATLAB']) \
           == Parser().parse(['thefuck', '--', 'MATLAB'])
    assert Parser().parse(['thefuck', 'git', 'branch', '--merged']) \
           == Parser().parse(['thefuck', 'git', 'branch', '--merged', '--'])
    assert Parser().parse(['thefuck', 'MATLAB', ARGUMENT_PLACEHOLDER, '--']) \
           == Parser().parse(['thefuck', 'MATLAB', '--'])
    assert Parser().parse(['thefuck', 'MATLAB', ARGUMENT_PLACEHOLDER]) \
           == Parser().parse(['thefuck', 'MATLAB', '--'])

# Generated at 2022-06-12 09:53:23.602363
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args, command = parser.parse(['thefuck'])
    assert args.command == []
    assert command == []

    args, command = parser.parse(['thefuck', 'command'])
    assert args.command == ['command']
    assert command == []

    args, command = parser.parse(['thefuck', 'command', '1', '2'])
    assert args.command == ['command', '1', '2']
    assert command == []

    args, command = parser.parse(['thefuck', 'command', '--option', '1', '2', ARGUMENT_PLACEHOLDER, '3'])
    assert args.command == ['command', '--option', '1', '2']
    assert command == ['3']

# Generated at 2022-06-12 09:53:27.454621
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import io
    import sys
    buf = io.StringIO()
    sys.stderr = buf
    parser.print_usage()
    sys.stderr = sys.__stderr__
    buf.close()

# Generated at 2022-06-12 09:54:11.315747
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-12 09:54:11.871077
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-12 09:54:13.751879
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.get_prog_name() == 'thefuck'


# Generated at 2022-06-12 09:54:20.642160
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import sys

    stderr_backup = sys.stderr

# Generated at 2022-06-12 09:54:25.646330
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # `thefuck --help` prints help
    p = Parser()
    p.print_help()
    p.print_help = lambda: print('Not printed')
    p.parse(['thefuck', '--help'])
    # after `thefuck --help` prints help


# Generated at 2022-06-12 09:54:27.599699
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    #assert parser._parser.description == 'Tool to correct your previous console command'



# Generated at 2022-06-12 09:54:28.591706
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-12 09:54:37.799697
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """This is a unit test function for Parser class.
    Function print_help is tested with different combination of arguments.
    """
    # Test with:
    # 1. --version
    # 2. --alias
    # 3. --shell-loger
    # 4. Help command
    args_test1 = ['-v', '-a', 'test1', '-l', 'test2', '--help']
    args_test1_parsed = ['--version', '--alias', 'test1',
                         '--shell-logger', 'test2', '--help']
    #Test with:
    # 1. --version
    # 2. --alias
    # 3. --shell-loger
    # 4. Help commad missing
    # expect error message

# Generated at 2022-06-12 09:54:38.899042
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser is not None


# Generated at 2022-06-12 09:54:41.763494
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO

    old_stderr = sys.stderr
    stderr = StringIO()
    sys.stderr = stderr

    parser = Parser()
    parser.print_help()

    assert stderr.getvalue()
    sys.stderr = old_stderr

# Generated at 2022-06-12 09:56:17.025097
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['fuck']) == Parser().parse(['fuck', 'ls', '-l'])

# Generated at 2022-06-12 09:56:25.098454
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse(['thefuck'])
    assert parser.parse(['thefuck', 'git'])
    assert parser.parse(['thefuck', 'git', 'add'])
    assert parser.parse(['thefuck', 'git', 'add', '.'])
    assert parser.parse(['thefuck', 'git', 'add', '.', '-v'])
    assert parser.parse(['thefuck', 'git', 'add', '.', '-v', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'git', 'add', '.', ARGUMENT_PLACEHOLDER, '-v'])
    assert parser.parse(['thefuck', '--help'])
    assert parser.parse(['thefuck', '--version'])

# Generated at 2022-06-12 09:56:34.684771
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    args = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-a', '-l'])
    assert args.command == ['ls']
    assert args.alias is True
    assert args.shell_logger is None
    assert args.force_command is None
    assert args.debug is False
    assert args.repeat is False
    assert args.yes is False

    args = parser.parse(['thefuck', 'ls', '-a', '-l', '-t', '-v'])
    assert args.command == ['ls', '-a', '-l', '-t', '-v']
    assert args.alias is None
    assert args.shell_logger is None
    assert args.force_command is None
    assert args.debug is False

# Generated at 2022-06-12 09:56:37.701895
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import ALIAS_ARGS
    try:
        sys.argv = ['thefuck', ALIAS_ARGS['fish']]
    except KeyError:
        pass
    else:
        p = Parser()
        p.print_help()

# Generated at 2022-06-12 09:56:44.366357
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from unittest import mock
    from contextlib import redirect_stdout
    from .const import VERSION

    def change_argv(func):
        def tmp(*args, **kwargs):
            with mock.patch('sys.argv', ['thefuck', '--version']):
                return func(*args, **kwargs)
        return tmp

    @change_argv
    def test_print_usage():
        parser = Parser()
        parser.parse(sys.argv)
        f = StringIO()
        with redirect_stdout(f):
            parser.print_usage()

# Generated at 2022-06-12 09:56:45.408562
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # TODO

# Generated at 2022-06-12 09:56:49.253594
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    out = StringIO()
    sys.stdout = out
    parser.print_help()
    output = out.getvalue().strip()
    sys.stdout = sys.__stdout__
    assert output

# Generated at 2022-06-12 09:56:54.558782
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck'])
    assert not args.command
    assert not args.debug
    assert not args.force_command
    assert not args.yes
    assert not args.repeat
    assert not args.shell_logger
    assert not args.alias
    assert not args.enable_experimental_instant_mode

    args = parser.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']
    assert not args.debug
    assert not args.force_command
    assert not args.yes
    assert not args.repeat
    assert not args.shell_logger
    assert not args.alias
    assert not args.enable_experimental_instant_mode


# Generated at 2022-06-12 09:56:55.454880
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:56:58.998440
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Arrange
    p = Parser()
    # Act
    args = p.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-y', 'ls', '-l'])
    # Assert
    assert args.yes
    assert args.command == ['ls', '-l']