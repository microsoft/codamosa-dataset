

# Generated at 2022-06-12 09:49:50.844666
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:49:55.025090
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import tempfile
    import os
    from .utils import get_alias

    with tempfile.TemporaryFile(mode='w+') as temp:
        parser = Parser()
        parser.print_usage(file=temp)
        temp.seek(0)

        content = temp.read()
    assert 'Usage: thefuck' in content



# Generated at 2022-06-12 09:49:56.727365
# Unit test for method parse of class Parser
def test_Parser_parse():
    a=Parser()
    print(a.parse(sys.argv))


# Generated at 2022-06-12 09:50:04.228506
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import io
    import fcntl
    out_stream = io.StringIO()
    err_stream = io.StringIO()
    sys.stderr = err_stream
    parser = Parser()
    parser.print_usage()
    assert err_stream.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--yes | --repeat] [command [command ...]]\n"


# Generated at 2022-06-12 09:50:06.472048
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:50:10.307836
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Unit test for method print_help of class Parser"""
    # Arrange
    parser = Parser()
    # Act
    output = parser.print_help()
    # Assert
    assert output == None
    return "test_Parser_print_help passed"

# Generated at 2022-06-12 09:50:11.708444
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-12 09:50:20.628981
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from unittest.mock import Mock
    from thefuck.main import get_alias
    p = Parser()
    out = StringIO()
    with Mock(wraps=p._parser, prog='thefuck', add_help=False) as wrap:
        wrap.print_help.return_value = None
        p._add_arguments()
        p.print_help()
        wrap.print_usage.assert_called_with(out)
    out.seek(0)
    assert out.read() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] '\
        '[-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] '\
        '[--force-command FORCE_COMMAND] command ...\n'

# Generated at 2022-06-12 09:50:28.788755
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest.mock import patch
    from io import StringIO
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        Parser().print_usage()
        assert stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y|-r] [-d] [--force-command F_COMMAND] [command [command ...]]\n'


# Generated at 2022-06-12 09:50:30.110554
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    args = Parser()
    assert args.print_help() is None

# Generated at 2022-06-12 09:50:43.828723
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    parser = Parser()
    assert parser.print_help() is None
    # in Linux stderr:
    # usage: thefuck [-h] [-v] [--shell-logger SHELL_LOGGER]
    #                [--enable-experimental-instant-mode] [-y | -r]
    #                [--force-command FORCE_COMMAND]
    #                [command [command ...]]
    #
    # optional arguments:
    #   -h, --help            show this help message and exit
    #   -v, --version         show program's version number and exit
    #   --shell-logger SHELL_LOGGER
    #                         log shell output to the file
    #   --enable-experimental-instant-mode
    #                         enable experimental instant mode, use on your own
    #

# Generated at 2022-06-12 09:50:45.074237
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:50:51.969244
# Unit test for constructor of class Parser
def test_Parser():
    test_parser = Parser()
    print(test_parser)
    print(test_parser._parser)
    print(test_parser._add_arguments())
    print(test_parser._add_conflicting_arguments())
    print(test_parser._prepare_arguments(['-a']))
    print(test_parser.parse(['-a']))
    print(test_parser.print_usage())
    print(test_parser.print_help())

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-12 09:50:55.646868
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    s = StringIO()
    _parser = Parser()
    _parser.print_usage(file=s)
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l' in s.getvalue()



# Generated at 2022-06-12 09:51:05.913245
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    from unittest.mock import patch
    parser = Parser()
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        parser.print_help()

# Generated at 2022-06-12 09:51:11.713379
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    from StringIO import StringIO
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    assert out.getvalue() == ('usage: thefuck [-h] [-v] [-a [custom-alias-name]] '
                              '[-l SHELL_LOGGER] [-d] [-y] [-r] [--] COMMAND...\n')


# Generated at 2022-06-12 09:51:13.162141
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()
    assert True


# Generated at 2022-06-12 09:51:16.573736
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['thefuck', '--alias', 'fuck'])
    assert str(args) == "Namespace(alias='fuck', command=[], debug=False, help=False, repeat=False, shell_logger=None, version=False, yes=False)"


# Generated at 2022-06-12 09:51:26.392368
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', '-a']) == parser.parse(['fuck', '--alias'])
    assert parser.parse(['fuck', '--alias', 'change_command']) == parser.parse(['fuck', '--alias=change_command'])
    assert parser.parse(['fuck', '-l', '//tmp/fuck-shell.log']) == parser.parse(['fuck', '--shell-logger', '//tmp/fuck-shell.log'])
    assert parser.parse(['fuck', '-h']) == parser.parse(['fuck', '--help'])
    assert parser.parse(['fuck', '--force-command', 'ls']) == parser.parse(['fuck', '--force-command=ls'])

# Generated at 2022-06-12 09:51:34.819414
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    p = Parser()
    out = StringIO()
    sys.stderr = out
    p.print_usage()
    sys.stderr = sys.__stderr__
    assert out.getvalue() == 'usage: thefuck [--force-command SCRIPT] ' \
                             '[--shell-logger FILENAME] [-v] ' \
                             '[-a [custom-alias-name]] [-l] ' \
                             '[-h] [-d] [-y | -r] [--] [command [command ...]]\n'


# Generated at 2022-06-12 09:51:47.005368
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:51:50.205931
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.parse(['thefuck', '-v'])
    assert parser.print_usage() == parser._parser.print_usage(sys.stderr)


# Generated at 2022-06-12 09:51:52.799257
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['fuck', 'git', 'add', ARGUMENT_PLACEHOLDER, '--'] + ['-f', '-n'])

# Generated at 2022-06-12 09:51:54.284472
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert 'usage: thefuck' in parser.print_usage()

# Generated at 2022-06-12 09:51:58.114958
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    oldstdout = sys.stdout
    sys.stdout = StringIO()
    parser.print_help()
    sys.stdout.seek(0)
    assert sys.stdout.read() != ''
    sys.stdout = oldstdout

# Generated at 2022-06-12 09:52:00.064486
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert 'Prog: thefuck' == parser._parser.prog



# Generated at 2022-06-12 09:52:01.664377
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # make sure print_help do not crash
    Parser().print_help()


# Generated at 2022-06-12 09:52:04.130977
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    print(parser.parse(['', ARGUMENT_PLACEHOLDER, 'python', 'README.md']))

# Generated at 2022-06-12 09:52:06.265643
# Unit test for constructor of class Parser
def test_Parser():
	parser = Parser()
	return True
#test_Parser() #is this needed?

#test_parse()


# Generated at 2022-06-12 09:52:18.448932
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from contextlib import contextmanager
    from io import StringIO
    from unittest.mock import patch


# Generated at 2022-06-12 09:52:32.822322
# Unit test for constructor of class Parser
def test_Parser():
    test_Parser_prepare_arguments()
    test_Parser_parse()
    test_Parser_print_usage()

# Unit test of function prepare_arguments()

# Generated at 2022-06-12 09:52:39.504288
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    from . import utils
    from .utils import get_alias
    from .loader import get_available_rules

    parser = Parser()

    def test_help(output):
        assert any(s in output for s in (
            '-l', '--shell-logger',
            '-y', '--yes', '--yeah', '--hard',
            '-r', '--repeat'))
        assert 'show this help message and exit' in output

# Generated at 2022-06-12 09:52:40.515750
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()

# Generated at 2022-06-12 09:52:41.208997
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-12 09:52:47.625098
# Unit test for method print_help of class Parser

# Generated at 2022-06-12 09:52:52.024562
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    sys.stderr = open('/dev/null', 'wb')
    parser.print_usage()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-12 09:52:59.736496
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = [
        'fuck', 'ls', '-l', '--', '-a', '--alias', '--version', '-v',
        ARGUMENT_PLACEHOLDER, '-d', '-r', '--debug', '--repeat',
        '--enable-experimental-instant-mode', '-y', '--yes', '-h', '--help',
        '--force-command', '--force-command-value', '--shell-logger',
        '--shell-logger-value'
    ]

    parser = Parser()
    parsed = parser.parse(argv)

    assert parsed.command == ['ls', '-l', '--', '-a']

    assert parsed.alias == get_alias()
    assert parsed.alias is not None

    assert parsed.version is None

# Generated at 2022-06-12 09:53:00.896482
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-12 09:53:12.087200
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    This is a Unit test for method print_help of class Parser
    """
    import cStringIO

    def assert_print_help_is_called(argv):
        return

    def assert_print_usage_is_called(argv):
        return

    class MockSys:
        def __init__(self, my_parser):
            self.stdout = cStringIO.StringIO()
            self.stderr = cStringIO.StringIO()

    class MockArgumentParser:
        def __init__(self, my_parser):
            self.print_help = assert_print_help_is_called

        def parse_args(self, argv):
            return

    my_parser = Parser()
    my_parser._parser = MockArgumentParser(my_parser)
    sys.stderr

# Generated at 2022-06-12 09:53:19.225986
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	parser.parse(['fuck'])
	parser.parse(['fuck', '-v'])
	parser.parse(['fuck', '-a'])
	parser.parse(['fuck', '-l'])
	parser.parse(['fuck', '--enable-experimental-instant-mode'])
	parser.parse(['fuck', '-h'])
	parser.parse(['fuck', '-d'])
	parser.parse(['fuck', '--force-command'])
	parser.parse(['fuck', 'command'])

	parser.parse(['fuck', ARGUMENT_PLACEHOLDER, '-v'])
	parser.parse(['fuck', '-v', ARGUMENT_PLACEHOLDER])
	

# Generated at 2022-06-12 09:53:53.480906
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == \
           parser.parse(['thefuck', '{}', 'ls', '-l']) == \
           parser.parse(['thefuck', 'ls', '{}', '-l']) == \
           parser.parse(['thefuck', 'ls', '-l', '{}']) == \
           parser.parse(['thefuck', '{}', 'ls', '{}', '-l']) == \
           parser.parse(['thefuck', 'ls', '{}', '-l', '{}'])
    assert parser.parse(['thefuck', '-l', 'ls', '-l']) != \
           parser.parse(['thefuck', 'ls', '-l'])

# Generated at 2022-06-12 09:53:57.159361
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(
        ['thefuck', '-y', ARGUMENT_PLACEHOLDER, 'echo', 'hi']) == \
        parser.parse(['thefuck', '-y', '--', 'echo', 'hi'])



# Generated at 2022-06-12 09:54:01.228851
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    parser = Parser()
    argv = ['thefuck', ARGUMENT_PLACEHOLDER, '--', 'command']
    assert parser.parse(argv) == parser.parse(['thefuck', 'command'])


# Generated at 2022-06-12 09:54:02.941447
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except:
        assert False

# Generated at 2022-06-12 09:54:13.511231
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import get_alias
    from .config import load_config

    parser = Parser()
    config = load_config()
    alias = config.get('alias')
    assert parser.parse(['fuck', 'vim']) == parser.parse(['fuck', '--', 'vim'])
    assert parser.parse(['fuck', '-h']) == \
        parser._parser.parse_args(['-h'])
    assert parser.parse(['fuck', '--debug']) == \
        parser._parser.parse_args(['--debug'])
    assert parser.parse(['fuck', '-yy', '-r']) == \
        parser._parser.parse_args(['-yy', '-r'])

# Generated at 2022-06-12 09:54:14.036084
# Unit test for method print_help of class Parser
def test_Parser_print_help():
	pass

# Generated at 2022-06-12 09:54:20.812349
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import CUSTOM_SUDO_ALIAS
    from .utils import get_alias
    Parser().parse(['thefuck', '-a'])
    Parser().parse(['thefuck', '-a', get_alias()])
    Parser().parse(['thefuck', '-a', 'aliase'])
    Parser().parse(['thefuck', '-l', '/tmp/log.txt'])
    Parser().parse(['thefuck', '/usr/bin/ls', '-la'])
    Parser().parse(['thefuck', 'echo "something"'])
    Parser().parse(['thefuck', '-y', 'echo "something"'])
    Parser().parse(['thefuck', '--repeat', 'echo "something"'])

# Generated at 2022-06-12 09:54:31.403760
# Unit test for method parse of class Parser
def test_Parser_parse():
    thefuck_cmd = 'thefuck'
    parser = Parser()
    # test arguments
    args = parser.parse([thefuck_cmd])
    assert vars(args) == {'command': [],
                          'debug': False,
                          'force_command': None,
                          'repeat': False,
                          'yes': False,
                          'alias': None,
                          'shell_logger': None,
                          'enable_experimental_instant_mode': False,
                          'help': False,
                          }
    args = parser.parse([thefuck_cmd, '-h'])

# Generated at 2022-06-12 09:54:32.702374
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:54:34.441116
# Unit test for constructor of class Parser
def test_Parser():
    test_Parser = Parser()
    assert isinstance(test_Parser, Parser)



# Generated at 2022-06-12 09:55:49.681848
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() is None


# Generated at 2022-06-12 09:56:00.222048
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import VERSION
    import StringIO
    import sys

    sys.stderr = StringIO.StringIO()
    Parser().print_help()
    out = sys.stderr.getvalue()

    assert "usage: thefuck [-v | -a <custom-alias-name> | -l <file> | -h | -d | --force-command <command> ] [--] [<command>...]" in out
    assert "thefuck: error: unrecognized arguments: <file>" in out
    assert "thefuck: error: unrecognized arguments: <command>" in out
    assert "[custom-alias-name] prints alias for current shell" in out
    assert "show this help message and exit" in out
    assert "--yes, --yeah, --hard" in out
    assert "--repeat" in out

# Generated at 2022-06-12 09:56:01.748994
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([__file__, '--verbose']).verbose


# Generated at 2022-06-12 09:56:03.535988
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser._parser, ArgumentParser)


# Generated at 2022-06-12 09:56:05.110467
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()

    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:56:05.845676
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:56:13.511146
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    error_stream = io.StringIO()
    parser = Parser()
    parser.print_help(file=error_stream)
    error_stream.seek(0)
    res = error_stream.read()
    assert 'usage: thefuck [-h]' in res
    assert 'Arguments:' in res
    assert '-h, --help' in res
    assert '-h, --help' in res
    assert '--force-command' in res
    assert '-d, --debug' in res
    assert '-v, --version' in res
    assert 'optional arguments:' in res
    assert '-y, --yes' in res
    assert 'show program\'s version number and exit' in res
    assert '-r, --repeat' in res
    assert 'positional arguments:' in res


# Generated at 2022-06-12 09:56:22.544759
# Unit test for method parse of class Parser
def test_Parser_parse():
    #Test for get_alias() and parse(argv)
    p = Parser()
    assert p.parse(['./thefuck', 'git', 'commit']) == p._parser.parse_args(['--', 'git', 'commit'])
    assert p.parse(['./thefuck',
    ARGUMENT_PLACEHOLDER, '--alias', 'fuck', 'git', 'commit']) == p._parser.parse_args(
    ['--alias', 'fuck', '--', 'git', 'commit'])
    assert p.parse(['./thefuck', ARGUMENT_PLACEHOLDER, '--alias', 'git', 'commit']) == p._parser.parse_args(
    ['--alias', get_alias(), '--', 'git', 'commit'])

# Generated at 2022-06-12 09:56:23.584988
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()
    assert 1

# Generated at 2022-06-12 09:56:32.435041
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'wrong command']) == \
        parser.parse(['fuck', '--', 'wrong command'])
    assert parser.parse(['fuck', 'wrong command', 'second']) == \
        parser.parse(['fuck', '--', 'wrong command', 'second'])
    assert parser.parse(['fuck', 'wrong command', ARGUMENT_PLACEHOLDER]) == \
        parser.parse(['fuck', '--', 'wrong command'])
    assert parser.parse(['fuck', 'wrong command', 'second',
                        ARGUMENT_PLACEHOLDER, 'third']) == \
        parser.parse(['fuck', '--', 'wrong command', 'second', 'third'])

# Generated at 2022-06-12 09:59:40.367277
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    args = p.parse(['thefuck', 'git', 'push', 'master'])
    assert args.command == ['git', 'push', 'master']


# Generated at 2022-06-12 09:59:45.602188
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser().parse(["-v", "-a", "-l", "--enable-experimental-instant-mode", "-d", "-y", "--force-command", "--", "command"])
    assert p.version and p.alias and p.shell_logger is not None and p.debug and p.yes and p.force_command and p.command[0] == "command"

