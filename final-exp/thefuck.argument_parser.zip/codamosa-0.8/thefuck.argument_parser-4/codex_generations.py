

# Generated at 2022-06-12 09:49:52.330632
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Arrange

    # Act
    parser = Parser()
    parser.print_usage()

    # Assert
    # Nothing to assert

# Generated at 2022-06-12 09:49:55.023405
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # when
    result = parser.parse(['thefuck', '-d'])

    # then
    assert result.debug



# Generated at 2022-06-12 09:50:01.162473
# Unit test for method parse of class Parser
def test_Parser_parse():
    expected = ArgumentParser().parse_args(['--force-command', 'echo', 'hello'])
    assert Parser().parse(['fuck', '--force-command', 'echo', 'hello']).command == expected.command
    expected = ArgumentParser().parse_args(['--force-command', 'echo', 'hello', 'world'])
    assert Parser().parse(['fuck', '--force-command', 'echo', 'hello', 'world']).command == expected.command

# Generated at 2022-06-12 09:50:08.252229
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # The function will print the usage of function to stderr
    # So we use a StringIO to save the usage to string
    from StringIO import StringIO
    origin_stderr = sys.stderr
    sys.stderr = StringIO()
    parser = Parser()
    parser.print_usage()
    sys.stderr.seek(0)
    usage = sys.stderr.read()
    assert usage == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n                  [-l SHELL_LOGGER]\n                  [--enable-experimental-instant-mode] [-y] [-r]\n                  [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n'
    sys.stderr = origin_stderr



# Generated at 2022-06-12 09:50:09.356410
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:50:13.675502
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .test_utils import mock
    from .const import VERSION
    parser = Parser()
    stderr = mock.Mock()
    parser.print_usage(stderr)
    stderr.write.assert_called_once_with('thefuck {}\n'.format(VERSION))


# Generated at 2022-06-12 09:50:15.339635
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert(parser.print_help())



# Generated at 2022-06-12 09:50:18.954571
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['fuck', 'my', 'command', ARGUMENT_PLACEHOLDER, 'var1', 'var2']
    args = Parser().parse(argv)
    assert args.command == ['command', 'var1', 'var2']


# Generated at 2022-06-12 09:50:22.243429
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    import mock

    parser = Parser()
    parser.print_help()
    sys.stderr.write = mock.Mock()
    parser.print_help()
    assert sys.stderr.write.called

# Generated at 2022-06-12 09:50:25.258020
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(["-v"])
    parser.parse(["-a"])
    parser.parse(["-d"])
    parser.parse(["--force-command"])

# Generated at 2022-06-12 09:50:36.163116
# Unit test for method parse of class Parser
def test_Parser_parse():
    # assert with all the possible values for argv
    for args_list in [['-v'],
                      ['-a'], ['-a', 'fuck'],
                      ['-l', 'path/to/shell.log'],
                      ['--enable-experimental-instant-mode'],
                      ['-h'],
                      ['-y'], ['-r'],
                      ['-d'],
                      ['--force-command', 'ls'],
                      ['--', 'ls'],
                      ['ls'],
                      ['ls', '-l']]:  # [-v, -a, -a <alias>, -l <file>, -h, -y, -r, -d, -- <command>, <command>]
        p = Parser()
        args = p.parse(['thefuck'] + args_list)
        assert args.version

# Generated at 2022-06-12 09:50:38.517587
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'

# Generated at 2022-06-12 09:50:42.981413
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['-v', '--debug', '--shell-logger', 'file', '-y', 'ls', 'file']
    parser = Parser()
    res = parser.parse(args)
    assert res.command == ['ls', 'file']
    assert res.version == True
    assert res.shell_logger == 'file'
    assert res.debug == True
    assert res.yes == True


# Generated at 2022-06-12 09:50:45.686302
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    output = StringIO()
    Parser().print_usage(file=output)
    assert 'usage: thefuck' == output.getvalue().strip()


# Generated at 2022-06-12 09:50:55.648582
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(["fuck", "echo", "hello", "world"]) == "hello world"
    assert p.parse(["fuck", "echo", "--help"]) == "fuck: error: unrecognized arguments: --help"

# Generated at 2022-06-12 09:50:57.010854
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-12 09:50:58.479749
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'

# Generated at 2022-06-12 09:51:07.946659
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    def test_parse(argv, expected_command, expected_options):
        sys.argv = ['thefuck'] + argv
        options = parser.parse(sys.argv)
        command = options.command
        del options.command
        assert command == expected_command
        assert options == expected_options
    #
    #
    test_parse(
        [], [],
        Namespace(alias=None, debug=False, enable_experimental_instant_mode=False, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    )

# Generated at 2022-06-12 09:51:08.824211
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:51:17.086354
# Unit test for constructor of class Parser
def test_Parser():
    class Res():
        def __init__(self, s):
            self.stderr = s

    p = Parser()
    assert p._parser.prog == "thefuck"

    sys.stderr = Res("")
    p.print_help()
    assert 'thefuck' in sys.stderr.stderr
    assert 'show program' in sys.stderr.stderr
    assert 'execute fixed' in sys.stderr.stderr
    assert '[custom-alias-name]' in sys.stderr.stderr
    assert 'command that should' in sys.stderr.stderr
    assert '--enable-experimental-instant-mode' in sys.stderr.stderr

    sys.stderr = Res("")
    p.print_usage()
   

# Generated at 2022-06-12 09:51:34.206435
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse(['thefuck'])
    assert parser.parse(['thefuck', '-a'])
    assert parser.parse(['thefuck', '-a', 'fuck'])
    assert parser.parse(['thefuck', '-l'])
    assert parser.parse(['thefuck', '-l', 'logger'])
    assert parser.parse(['thefuck', '--help'])
    assert parser.parse(['thefuck', '-y'])
    assert parser.parse(['thefuck', '-r'])
    assert parser.parse(['thefuck', '--repeat'])
    assert parser.parse(['thefuck', '--yes'])
    assert parser.parse(['thefuck', '-d'])

# Generated at 2022-06-12 09:51:37.577602
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        parser = Parser()
        parser.print_help()
        assert 'usage: thefuck' in stderr.getvalue()

# Generated at 2022-06-12 09:51:39.251301
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:51:40.629306
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None


# Generated at 2022-06-12 09:51:43.901552
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    #   parser.parse() should have arguments which are
    #   specified in the function _add_arguments() of class Parser
    assert(len(parser._parser._actions) > 1)

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-12 09:51:53.651663
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'git', 'push', 'origin',
                         ARGUMENT_PLACEHOLDER, '--force'])
    assert args.command == ['git', 'push', 'origin']
    assert args.force_command == '--force'

    args = parser.parse(['thefuck', '-a', 'fuck'])
    assert args.alias == 'fuck'

    args = parser.parse(['thefuck', 'git', 'push', 'origin',
                         ARGUMENT_PLACEHOLDER, '--', '--force'])
    assert args.command == ['git', 'push', 'origin', '--']
    assert args.force_command == '--force'



# Generated at 2022-06-12 09:51:56.203481
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'echo', '!f'])
    assert arguments.command == ['echo', '!f']


# Generated at 2022-06-12 09:51:58.947536
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # test normal case
    parser = Parser()
    parser.print_usage()
    # test case with argument
    parser.print_usage(sys.stdout)


# Generated at 2022-06-12 09:52:04.784279
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '-v'])
    assert args.version == True
    args = parser.parse(['thefuck', '-vvvvvvvvv'])
    assert args.version == False
    args = parser.parse(['thefuck', '-vvvvvvvvv', 'git', 'commit'])
    assert args.version == False
    assert args.command == ['git', 'commit']

# Generated at 2022-06-12 09:52:09.016619
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    captured_output = StringIO.StringIO()
    sys.stdout = captured_output
    parser.print_help()
    sys.stdout = sys.__stdout__
    assert 'usage: thefuck' in captured_output.getvalue()




# Generated at 2022-06-12 09:52:33.209595
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    main_parser = Parser()
    assert '-v --version' in main_parser.print_help()
    assert '-a --alias' in main_parser.print_help()
    assert '-l --shell-logger' in main_parser.print_help()
    assert '--enable-experimental-instant-mode' in main_parser.print_help()
    assert '-h --help' in main_parser.print_help()
    assert '-y --yes --yeah --hard' in main_parser.print_help()
    assert '-r --repeat' in main_parser.print_help()
    assert '-d --debug' in main_parser.print_help()
    assert '--force-command' in main_parser.print_help()
    assert 'command' in main_parser.print_help()


# Generated at 2022-06-12 09:52:39.649779
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].default == False
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].nargs == '?'
    assert parser._parser._actions[1].const == get_alias()
    assert parser._parser._actions[2].dest == 'shell_logger'
    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[4].dest == 'help'
    assert parser._parser._actions[4].default == False
    assert parser._parser._actions[5].dest == 'yes'

# Generated at 2022-06-12 09:52:42.445433
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'cd', 'ls']) == parser.parse(['fuck', 'cd', ARGUMENT_PLACEHOLDER, 'ls'])

# Generated at 2022-06-12 09:52:51.472525
# Unit test for constructor of class Parser
def test_Parser():
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias

    parser = Parser()
    assert parser.parse(['fuck'])
    assert parser.parse(['fuck', '-v'])
    assert parser.parse(['fuck', '-a'])
    assert parser.parse(['fuck', '-a', get_alias()])
    assert parser.parse(['fuck', '-l', '1'])
    assert parser.parse(['fuck', '-h'])
    assert parser.parse(['fuck', '-d'])
    assert parser.parse(['fuck', '-y'])
    assert parser.parse(['fuck', '-r'])
    assert parser.parse(['fuck', 'echo', 'test'])

# Generated at 2022-06-12 09:52:58.464907
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    default_argv = ['thefuck', '-h', '--', 'echo', '123']
    assert parser.parse(default_argv) == parser._parser.parse_args(default_argv[1:])

    new_argv = ['thefuck', '-h', 'echo', '123']
    new_argv.insert(new_argv.index('echo'), ARGUMENT_PLACEHOLDER)
    assert parser.parse(new_argv) == parser._parser.parse_args(new_argv[1:])


if __name__ == '__main__':

    test_Parser_parse()

# Generated at 2022-06-12 09:53:03.978403
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import StringIO

    stream = StringIO.StringIO()
    sys.stderr = stream
    Parser().print_usage()
    assert stream.getvalue() == """usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [--yes] [--repeat] command ...

"""


# Generated at 2022-06-12 09:53:14.909549
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'echo'])
    assert not hasattr(args, 'alias')
    assert not args.help
    assert not args.version
    assert not args.debug
    assert not args.yes
    assert not args.repeat
    assert args.command == ['echo']

    args = parser.parse(['thefuck', 'echo', 'fuck'])
    assert args.command == ['fuck']

    args = parser.parse(['thefuck', '--alias', 'fuck'])
    assert args.alias == 'fuck'

    args = parser.parse(['thefuck', ARGUMENT_PLACEHOLDER,
                                'echo', 'fuck'])
    assert args.command == ['echo', 'fuck']


# Generated at 2022-06-12 09:53:17.979553
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # It should print usage to stderr
    out = StringIO()
    with patch("sys.stderr", out):
        Parser().print_usage()
    assert out.getvalue().startswith("usage: thefuck ")


# Generated at 2022-06-12 09:53:28.683012
# Unit test for method print_help of class Parser

# Generated at 2022-06-12 09:53:29.632613
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:54:01.183619
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert "usage: thefuck [--version]" in out.getvalue()



# Generated at 2022-06-12 09:54:02.550250
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:54:09.361846
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # TODO: It does not work on some environments (win?)
    from io import StringIO
    from unittest.mock import patch
    from .parser import Parser

    output = StringIO()
    parser = Parser()

    with patch('thefuck.parser.sys.stderr', new=output):
        parser.print_usage()

    assert '[-h]' in output.getvalue()
    assert '[--version]' in output.getvalue()


# Generated at 2022-06-12 09:54:17.959331
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([
        'thefuck', '-y', '--', 'git', '--version']) == argparse.Namespace(
                force_command='git --version', yes=True, debug=False,
                enable_experimental_instant_mode=False, repeat=False,
                shell_logger=None, alias=None, command=[])
    assert parser.parse([
        'thefuck', '--', 'git', '--version']) == argparse.Namespace(
                force_command='git --version', yes=False, debug=False,
                enable_experimental_instant_mode=False, repeat=False,
                shell_logger=None, alias=None, command=[])

# Generated at 2022-06-12 09:54:28.848680
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    new_argv = parser._prepare_arguments(['-y', 'make', 'test', ARGUMENT_PLACEHOLDER,'-f', 'wut'])
    args = parser._parser.parse_args(new_argv)
    assert type(args) is argparse.Namespace
    assert args.yes is True
    assert args.command == ['make', 'test']
    assert args.debug is False
    assert args.force_command is None
    assert args.help is False
    assert args.repeat is False
    assert args.shell_logger is None
    assert args.version is False
    # Argv list without placeholder
    new_argv = parser._prepare_arguments(['-y', 'make', 'test', '-f', 'wut'])
    args

# Generated at 2022-06-12 09:54:38.073604
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class Mock(object):
        def __init__(self):
            self.output = []
        def write(self, text):
            self.output.append(text)
        @property
        def text(self):
            return ''.join(self.output)
    parser = Parser()
    mock = Mock()
    parser.print_help(mock)
    text = mock.text
    assert text == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-d] [-l SHELL_LOGGER]'
    assert len(parser._parser._actions) == 6  # check if the number of arguments matches our expectation
    parser._parser._actions = parser._parser._actions[:2]  # let's remove the arguments except -h and -v
    parser.print_usage(mock)

# Generated at 2022-06-12 09:54:42.592400
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    out = StringIO()
    sys.stderr = out
    parser = Parser()
    parser.print_usage()
    assert out.getvalue().startswith('usage: thefuck')
    sys.stderr = sys.__stderr__


# Generated at 2022-06-12 09:54:52.809696
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Capture stderr
    save_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        parser.print_usage()
        output = out.getvalue().strip()
    finally:
        sys.stderr = save_stderr
    assert(output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger]\n'
           '              [--enable-experimental-instant-mode] [-d]\n'
           '              [--force-command FORCE-COMMAND] [--]\n'
           '              [command [command ...]]')


# Generated at 2022-06-12 09:55:03.515360
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from .settings import TYPE_CORRECTED
    from .settings import (
        PRIORITY_NORMAL, PRIORITY_LOWEST, PRIORITY_LOWER, PRIORITY_LOW,
        PRIORITY_HIGHEST, PRIORITY_HIGHER, PRIORITY_HIGH)

    # create and set up buffer
    sys.stderr = StringIO()
    expected = 'usage: arg_test [-h] [-v] [-a [custom-alias-name]] [--shell-logger SHELL_LOGGER] [--enable-experimental-instant-mode] [-l] [-y | -r] [--force-command FORCE_COMMAND] [--] [command [command ...]]'
    # call function
    parser = Parser()

# Generated at 2022-06-12 09:55:04.468175
# Unit test for constructor of class Parser
def test_Parser():
    # Under construction
    return


# Generated at 2022-06-12 09:55:43.625874
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    output = StringIO()
    old_stderr = sys.stderr
    sys.stderr = output
    parser.print_help()
    sys.stderr = old_stderr

# Generated at 2022-06-12 09:55:44.067326
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:55:46.818379
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parse = Parser()
    with pytest.raises(SystemExit) as pytest_e:
        parse.print_usage()
        assert pytest_e.value.code == 2

# Unit tests for method print_help of class Parser

# Generated at 2022-06-12 09:55:51.897524
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser.parse(['thefuck', '--'])
    assert parser.parse(['thefuck', 'git', 'status']) == parser._parser.parse_args(['--', 'git', 'status'])
    assert parser.parse(['thefuck', '--alias', 'fuck']) == parser._parser.parse_args(['--alias', 'fuck'])
    assert parser.parse(['thefuck', '--help']) == parser._parser.parse_args(['--help'])
    assert parser.parse(['thefuck', 'git', 'status']) == parser._parser.parse_args(['--', 'git', 'status'])

# Generated at 2022-06-12 09:55:53.265396
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None

# Generated at 2022-06-12 09:55:55.653297
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['C:\\Python34\\Scripts\\thefuck.exe', 'fuck'])
    print(args)

# Generated at 2022-06-12 09:56:05.110079
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        Parser().print_help()

# Generated at 2022-06-12 09:56:05.851100
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:56:07.944243
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # prepare function inputs for the function
    # we are testing in class Parser
    args = ['-h', '--help']

    # create an instance of the class we are testing
    parser = Parser()

    # call the function we are testing from class Parser
    parser.parse(args)



# Generated at 2022-06-12 09:56:11.476422
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    args = p.parse(['thefuck', '--debug', '--force-command', 'rm', '-rf', '.', '/tmp'])
    assert args.debug
    assert args.force_command == 'rm'
    assert args.command == ['-rf', '.', '/tmp']

# Generated at 2022-06-12 09:57:10.829590
# Unit test for constructor of class Parser
def test_Parser():
	obj = Parser()
	assert obj
	assert obj._parser


# Generated at 2022-06-12 09:57:20.708825
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    sys.argv = ['thefuck', '--version']
    args = parser.parse(sys.argv)
    assert args.version == True
    sys.argv = ['thefuck', '--help']
    args = parser.parse(sys.argv)
    assert args.help == True
    sys.argv = ['thefuck', '--debug']
    args = parser.parse(sys.argv)
    assert args.debug == True
    sys.argv = ['thefuck', '--force-command', 'ls']
    args = parser.parse(sys.argv)
    assert args.force_command == 'ls'
    sys.argv = ['thefuck', '--shell-logger', 'test.log']
    args = parser.parse(sys.argv)
    assert args

# Generated at 2022-06-12 09:57:25.082599
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    test_stderr_file = open("test_stderr_file", "w")
    try:
        parser.print_usage()
    except IOError as e:
        assert(e.args[1] == 'stdout buffer overflow')
    finally:
        test_stderr_file.close()


# Generated at 2022-06-12 09:57:26.061309
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:57:36.470744
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Testing method print_help of class Parser
    """
    from .utils import prepare_arguments, parse_arguments
    from .const import SETTINGS_PATH
    from . import settings
    import os
    import sys
    import re
    import tempfile
    import shutil
    from .utils import which
    import subprocess
    from .utils import get_alias

    if sys.platform == 'darwin':
        alias = 'fuck'
    elif sys.platform.startswith('win'):
        alias = 'fuck.exe'
    else:
        alias = 'fuck'

    # Test with argument -h
    try:
        with prepare_arguments('-h'):
            parse_arguments()
    except SystemExit as e:
        pass
    except BaseException as e:
        raise AssertionError

# Generated at 2022-06-12 09:57:38.211276
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-12 09:57:41.175745
# Unit test for method print_help of class Parser
def test_Parser_print_help():
	import StringIO
	import sys
	output = StringIO.StringIO()
	sys.stderr = output
	my_Parser = Parser()
	my_Parser.print_help()
	sys.stderr = sys.__stderr__

# Generated at 2022-06-12 09:57:49.373665
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    arguments = parser._prepare_arguments(['-l', 'tmp.log', 'command', '-v', '-h'])
    assert arguments == ['command', '-v', '-h', '--', '-l', 'tmp.log']
    arguments = parser._prepare_arguments(['-l', 'tmp.log', 'command', 'arg', ARGUMENT_PLACEHOLDER, '-v', '-h'])
    assert arguments == ['-v', '-h', '--', 'command', 'arg']
    arguments = parser._prepare_arguments(['-l', 'tmp.log', 'command', '-v', ARGUMENT_PLACEHOLDER, '-a', 'fuck'])
    assert arguments == ['-v', '--', 'command']


# Generated at 2022-06-12 09:57:58.032698
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'

    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[1].nargs == '?'
    assert parser._parser._actions[1].const == get_alias()

    assert parser._parser._actions[2].dest == 'shell_logger'

    assert parser._parser._actions[3].dest == 'enable_experimental_instant_mode'

    assert parser._parser._actions[4].dest == 'help'

    assert parser._parser._mutually_exclusive_groups[0]._group_actions[0].dest == 'yes'

# Generated at 2022-06-12 09:58:01.572331
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    capturedOutput = StringIO.StringIO()
    sysout = sys.stdout
    sys.stdout = capturedOutput
    parser.print_help()
    sys.stdout = sysout
    text = capturedOutput.getvalue()
    assert text.find('usage:') != -1