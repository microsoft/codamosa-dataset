

# Generated at 2022-06-12 09:49:50.694208
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:49:52.328571
# Unit test for constructor of class Parser
def test_Parser():
    test_data = Parser()
    assert repr(test_data) == "<Parser (test_Parser)>"


# Generated at 2022-06-12 09:50:02.615005
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import _get_exe_name
    from types import ModuleType
    from .const import __version__, ALIAS, REQUIREMENTS
    import sys
    import os
    testmodule = ModuleType('testmodule')
    testmodule.__version__ = __version__
    testmodule.ALIAS = ALIAS
    testmodule.REQUIREMENTS = REQUIREMENTS
    sys.modules['thefuck'] =  testmodule
    EXE_NAME = _get_exe_name()
    PARSER = Parser()
    STDERR = sys.stderr
    STDERR_BACKUP = STDERR
    STDERR = open(os.devnull, 'w')
    try:
        PARSER.print_help()
    finally:
        STDERR.close()
        sys.stderr = STDERR_BACKUP

# Generated at 2022-06-12 09:50:14.527226
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert ['ls', '-l'] == parser.parse(['thefuck', 'ls', '-l']).command
    assert ['ls', '-l'] == parser.parse(['thefuck', 'ls', '-l', '-v']).command
    assert ['ls', '-l'] == parser.parse(['thefuck', 'ls', '-l', '--debug']).command
    assert ['ls', '-l'] == parser.parse(['thefuck', 'ls', '-l', '--debug', '--alias']).command
    assert ['ls', '-l'] == parser.parse(['thefuck', 'ls', '-l', '--debug', '--alias', 'fuck']).command

# Generated at 2022-06-12 09:50:20.034038
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['--alias']
    parser = Parser()
    args = parser.parse(argv)
    assert args.alias == 'fuck'
    assert args.command == []
    argv = ['-a','fuck','--','ls','','','-l','','pwd']
    parser = Parser()
    args = parser.parse(argv)
    assert args.alias == 'fuck'
    assert args.command == ['ls','','','-l','','pwd']



# Generated at 2022-06-12 09:50:23.534041
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    with StringIO() as buf, redirect_stdout(buf):
        Parser().print_usage()
        usage = buf.getvalue()
        assert 'usage: thefuck' in usage


# Generated at 2022-06-12 09:50:32.193113
# Unit test for method print_usage of class Parser
def test_Parser_print_usage(): # pylint: disable=W0613, C0111
    print_org = sys.stdout
    file = open('file.txt', 'w')
    sys.stdout = file
    parser = Parser()
    parser.print_usage()
    sys.stdout = print_org
    file.close()
    file_read = open('file.txt')
    str_usage = file_read.read()
    file_read.close()
    assert "usage: thefuck" in str_usage
    assert "[-h]" in str_usage
    assert "[--force-command COMMAND]" in str_usage
    assert "command ..." in str_use


# Generated at 2022-06-12 09:50:41.293562
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    temp_out = StringIO()
    sys.stderr = temp_out
    parser = Parser()
    parser.print_help()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 09:50:51.139426
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['/tmp/thefuck', 'ls', '-l']) == parse_args([
        'ls', '-l'])
    assert parser.parse(['/tmp/thefuck', 'ls', ARGUMENT_PLACEHOLDER,
        '-l']) == parse_args(['-l', 'ls'])
    assert parser.parse(['/tmp/thefuck', 'ls', ARGUMENT_PLACEHOLDER,
        '-l']) == parse_args(['-l', 'ls'])
    assert parser.parse(['/tmp/thefuck', 'ls', ARGUMENT_PLACEHOLDER,
        '-l']) == parse_args(['-l', 'ls'])

# Generated at 2022-06-12 09:51:01.382961
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Create input value
    argv = ['command', 'arg1', 'arg2']

    # Create output values

# Generated at 2022-06-12 09:51:15.285444
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    test that the function print_help of the class Parser print the help in the stderr
    """

    parser = Parser()

    with patch('sys.stderr') as stderr:
        parser.print_help()
        assert stderr.write.call_args_list[0] == call('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL-LOGGER]\n' +
                                                      '[--enable-experimental-instant-mode] [-d] [--force-command FORCE-COMMAND]\n' +
                                                      '[-y | -r] [--] [command [command ...]]')
        assert stderr.write.call_args_list[1] == call('\n')
        assert stderr.write.call_

# Generated at 2022-06-12 09:51:17.737826
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    # raise Exception(parser.print_usage())

if __name__ == '__main__':
    test_Parser_print_usage()

# Generated at 2022-06-12 09:51:21.238498
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
  from mock import patch
  from StringIO import StringIO
  usage_text = StringIO()

  with patch('sys.stderr', usage_text):
    Parser().print_usage()

  assert "usage: thefuck" in usage_text.getvalue()


# Generated at 2022-06-12 09:51:22.623989
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', '--help'])

# Generated at 2022-06-12 09:51:24.107008
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()


parser = Parser()

# Generated at 2022-06-12 09:51:25.134883
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-12 09:51:26.583692
# Unit test for method print_help of class Parser
def test_Parser_print_help():
   parser = Parser()
   parser.print_help()


# Generated at 2022-06-12 09:51:37.276992
# Unit test for method parse of class Parser
def test_Parser_parse():
    # --command-without-placeholder should be ignored
    assert Parser().parse(['--command-without-placeholder', ARGUMENT_PLACEHOLDER, '--', 'command', 'with', 'args']).command == ['with', 'args']

    # command with args should not be ignored
    assert Parser().parse(['command', 'with', 'args', ARGUMENT_PLACEHOLDER, '--command-without-placeholder', '--', 'command', 'with', 'args']).command == ['command', 'with', 'args']

    # --command-without-placeholder should be ignored
    assert Parser().parse(['--', '--command-without-placeholder', ARGUMENT_PLACEHOLDER, 'command', 'with', 'args']).command == ['with', 'args']

    # --command

# Generated at 2022-06-12 09:51:42.382247
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse([
        'thefuck', '--alias', 'fuck', 'command',
        ARGUMENT_PLACEHOLDER, '-v', '-a', '--', '--version'])
    assert arguments.alias == 'fuck'
    assert arguments.version
    assert arguments.command == ['command', '--version']

# Generated at 2022-06-12 09:51:46.073422
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser._parser = object()
    parser._parser.print_help = lambda x: x
    assert parser._parser.print_help.__name__ == '<lambda>'
    assert parser.print_help() == sys.stderr

# Generated at 2022-06-12 09:52:01.106358
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Check if arg place holder is found in argv
    argv = ['script', '-a', ARGUMENT_PLACEHOLDER, 'git', 'remote', 'add', 'origin', 'git@github.com:user/repo.git', 'git@github.com:user/repo.git']
    assert Parser().parse(argv).command == ['git', 'remote', 'add', 'origin', 'git@github.com:user/repo.git', 'git@github.com:user/repo.git']
    # Check if arg place holder is not found in argv
    argv = ['script', 'git', 'remote', 'add', 'origin', 'git@github.com:user/repo.git', 'git@github.com:user/repo.git']

# Generated at 2022-06-12 09:52:10.119279
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import get_alias

    parser = Parser()

    # When we have a placeholder
    assert parser.parse(['command', 'foo'] + ['{}'.format(ARGUMENT_PLACEHOLDER)] + ['bar', 'baz']) == parser._parser.parse_args(['bar', 'baz', 'command', 'foo'])

    # When we do not have a placeholder
    assert parser.parse(['command', 'foo']) == parser._parser.parse_args(['--', 'command', 'foo'])

    # When we ask for help
    assert parser.parse(['command', 'foo', '--help']) == parser._parser.parse_args(['command', 'foo', '--help'])

    # When we ask for help and we have a placeholder

# Generated at 2022-06-12 09:52:10.726231
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:52:15.975747
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import capture_stderr
    parser = Parser()
    with capture_stderr() as err:
        parser.print_usage()
    assert err.getvalue() == 'Usage: thefuck [options] [command [arg [arg ...]]]\n'


# Generated at 2022-06-12 09:52:17.556302
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    return parser.print_help()

# Generated at 2022-06-12 09:52:19.515873
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['fuck'])
    assert arguments.debug is False
    assert arguments.force_command is None
    assert arguments.command == []



# Generated at 2022-06-12 09:52:21.076942
# Unit test for constructor of class Parser
def test_Parser():
    instance = Parser()
    assert isinstance(instance, Parser)

test_Parser()

# Generated at 2022-06-12 09:52:31.769972
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from thefuck import main
    from thefuck.shells import Shell
    from thefuck.types import Settings
    from thefuck.utils import which
    from thefuck.utils import is_tool_installed
    from thefuck.log import logger
    from thefuck.debug import set_debug
    from thefuck.debug import is_debug_enabled
    from thefuck.decorators import suppress_after_timeout
    from thefuck.config import get_all_executables
    from thefuck.config import get_all_support_tools
    from thefuck.config import reload_config
    from thefuck.config.git_config import GitConfig
    from thefuck.config.json_config import JSONConfig
    from thefuck.config.no_config import NoConfig
    from thefuck.config.py_config import PyConfig

# Generated at 2022-06-12 09:52:39.174023
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    import unittest.mock
    #create fake output
    s = StringIO()
    #create fake stdout
    with unittest.mock.patch('sys.stdout', s):
        a = Parser()
        a.print_usage()
        #create fake help string
        b = StringIO()
        b.write('usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n')
        b.write('               [-l SHELL_LOGGER]\n')
        b.write('               [--enable-experimental-instant-mode] [-d]\n')
        b.write('               [--force-command FORCE_COMMAND]\n')
        b.write('               [command [command ...]]\n')

# Generated at 2022-06-12 09:52:43.012986
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['thefuck', '--yes', '--', 'command', '--a', 'b', 'c']
    assert Parser().parse(argv).command == 'command'
    assert Parser().parse(argv).a == 'b'
    assert Parser().parse(argv).c is True


# Generated at 2022-06-12 09:52:58.408067
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    thefuck.shells.get_settings = lambda: {'require_confirmation': 'false'}
    parser = Parser()
    parser.parse(['run'])

    if parser.print_usage()=="usage: run [-h] [-v] [-a [custom-alias-name]]\
 [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [--force-command FORCE_COMMAND]\
 [--debug] [-y | -r] [command [command ...]]":
        print('test_Parser_usage_print done')
    else:
        print('test_Parser_usage_print not done')


# Generated at 2022-06-12 09:53:01.588040
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = ['thefuck', 'grep', '-r', '--', '-n']
    args = parser.parse(arguments)
    assert args.repeat
    assert not args.yes
    assert args.command == ['grep', '-n']


# Generated at 2022-06-12 09:53:03.050604
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:53:12.237089
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ["thefuck", "--version"]
    assert Parser().parse(argv).version == True
    assert Parser().parse(argv).force_command == None
    assert Parser().parse(argv).command == []
    assert Parser().parse(argv).shell_logger == None
    assert Parser().parse(argv).enable_experimental_instant_mode == False
    assert Parser().parse(argv).debug == False
    assert Parser().parse(argv).help == False
    assert Parser().parse(argv).repeat == False
    assert Parser().parse(argv).yes == False


# Generated at 2022-06-12 09:53:13.736907
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser._parser.print_help(sys.stderr)

# Generated at 2022-06-12 09:53:14.662272
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() is not None


# Generated at 2022-06-12 09:53:19.164622
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    sys_stderr = sys.stderr
    try:
        import StringIO
        sys.stderr = StringIO.StringIO()
        parser.print_usage()
        assert 'thefuck' in sys.stderr.getvalue()
    finally:
        sys.stderr = sys_stderr


# Generated at 2022-06-12 09:53:24.760009
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    """
    usage: thefuck [-h] [-d] [-v] [-a [custom-alias-name]]
                  [--enable-experimental-instant-mode] [-l SHELL_LOGGER]
                  [-y | -r] [--force-command FORCE_COMMAND] [command [command ...]]
    """


# Generated at 2022-06-12 09:53:35.857561
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['', '--force-command', 'echo', 'fuck'])
    assert args.force_command == 'echo'
    assert args.command == ['fuck']
    assert not args.debug
    assert not args.help
    assert not args.repeat
    assert not args.yes
    assert args.alias is None

    args = parser.parse([''])
    assert args.force_command is None
    assert args.command == []
    assert not args.debug
    assert not args.help
    assert not args.repeat
    assert not args.yes
    assert args.alias is None

    args = parser.parse(['', '-d'])
    assert args.force_command is None
    assert args.command == []
    assert args.debug
    assert not args.help
   

# Generated at 2022-06-12 09:53:40.293705
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    import sys, re
    sys.stderr.write = StringIO()
    sys.argv = ["-a"]
    Parser().print_usage()
    assert re.search(r'usage:.*thefuck', sys.stderr.write.getvalue())


# Generated at 2022-06-12 09:54:02.502130
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias
    from .parser import Parser
    from .utils import which

    alias = get_alias()
    argv_template = 'thefuck {} {} --yes --debug -v --shell-logger log.txt {} -- cd'

    parser = Parser()
    # Parse arguments with ARGUMENT_PLACEHOLDER
    parsed = parser.parse(argv_template.format(ARGUMENT_PLACEHOLDER, alias, alias).split())
    assert parsed.alias == alias
    assert parsed.shell_logger == 'log.txt'
    assert parsed.force_command == alias
    assert parsed.yes is True
    assert parsed.debug is True
    assert parsed.version is True

# Generated at 2022-06-12 09:54:12.080796
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    import sys

    stderr = sys.stderr
    sys.stderr = StringIO()
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-v] [-a [custom-alias-name]] ' + \
        '[-l shell-logger] [--enable-experimental-instant-mode] [-h]\n' + \
        '              [-y | -r] [-d] [--force-command force-command]\n' + \
        '              [command [command ...]]\n'
    sys.stderr = stderr



# Generated at 2022-06-12 09:54:19.614213
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['./fuck']) == \
           Parser().parse(['./fuck', '--']) == \
           Parser().parse(['./fuck', '--', '--']) == \
           Parser().parse(['./fuck', '-a']) == \
           Parser().parse(['./fuck', '-y', '-r']) == \
           Parser().parse(['./fuck', '-a', 'fuck']) == \
           Parser().parse(['./fuck', '-a', 'fuck', '-y']) == \
           Parser().parse(['./fuck', '-a', 'fuck', '-r']) == \
           Parser().parse(['./fuck', '-a', 'fuck', '-y', '-r'])

# Generated at 2022-06-12 09:54:27.712877
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    sys.stdout = StringIO()
    try:
        parser.print_usage()
        assert sys.stdout.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n             [--enable-experimental-instant-mode] [-y] [-r]\n             [-d] [--force-command FORCE_COMMAND]\n             [command [command ...]]\n"
    finally:
        sys.stdout = sys.__stdout__

# Generated at 2022-06-12 09:54:29.099509
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:54:30.991052
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == parser._parser.print_help(sys.stderr)



# Generated at 2022-06-12 09:54:35.856759
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import patch

    with patch('sys.stderr.write') as write:
        parser = Parser()
        parser.print_usage()
        # Check if the "usage" text is printed to the terminal
        assert write.called
        args, kwargs = write.call_args
        assert "usage: thefuck" in args[0]



# Generated at 2022-06-12 09:54:37.408861
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    try:
        Parser().print_help()
    except SystemExit:
        pass


# Generated at 2022-06-12 09:54:40.869785
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Empty argv list
    p = Parser()
    sys.stderr = open('/dev/null', 'w')
    p.print_usage()

    # With argv list
    p = Parser()
    sys.stderr = open('/dev/null', 'w')
    p.print_usage()

# Generated at 2022-06-12 09:54:48.519046
# Unit test for method parse of class Parser
def test_Parser_parse():
    c = Parser()

    # Test of empty argument
    assert not c.parse([])
    
    # Test of None argument
    assert not c.parse([None])
    
    # Test of one argument
    assert c.parse(['--debug'])
    
    # Test of two argument 
    assert c.parse(['--debug','--debug'])
    
    # Test of wrong argument of two argument
    assert not c.parse(['-d','--d'])

# Generated at 2022-06-12 09:55:19.223368
# Unit test for constructor of class Parser
def test_Parser():
    #1. given
    #2. when
    parser = Parser()
    #3. then
    assert parser is not None


# Generated at 2022-06-12 09:55:26.721474
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['prog', 'echo', 'hello', ARGUMENT_PLACEHOLDER, '--', '-n', '-v']) == \
           parser.parse(['prog', ARGUMENT_PLACEHOLDER, '--', 'echo', 'hello', '-n', '-v'])
    assert parser.parse(['prog', 'echo', 'hello', '--', '-n', '-v']) == \
           parser.parse(['prog', '--', 'echo', 'hello', '-n', '-v'])

# Generated at 2022-06-12 09:55:28.921717
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()
    # check if print_usage() works
    sys.stderr.getvalue()



# Generated at 2022-06-12 09:55:38.945533
# Unit test for method print_help of class Parser

# Generated at 2022-06-12 09:55:44.449959
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser_help = parser.print_help()
    with open("test_parser.txt","w") as f:
        sys.stdout = f
        parser.print_help()
    with open("test_parser.txt","r") as f:
        assert f.read() == parser_help


if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-12 09:55:48.949779
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    sio = StringIO()
    sys.stdout = sio
    parser.print_help()
    sys.stdout = sys.__stdout__
    assert 'Usage:' in sio.getvalue()
    assert 'Options:' in sio.getvalue()
    assert '-a, --alias' in sio.getvalue()
    assert '--enable-experimental-instant-mode' in sio.getvalue()


# Generated at 2022-06-12 09:55:51.799670
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.parse(["", "--hello", "--world"])

if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-12 09:56:00.020811
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'echo', 'hi']) == parser.parse(['thefuck', 'echo', 'hi'])
    assert parser.parse(['thefuck', 'echo', 'hi', '--', 'and', 'adios']) == parser.parse(['thefuck', 'echo', 'hi', '--', 'and', 'adios'])
    assert parser.parse(['thefuck', 'echo', 'hi', ARGUMENT_PLACEHOLDER, 'and', 'adios']) == parser.parse(['thefuck', 'echo', 'hi', '--', 'and', 'adios'])

# Generated at 2022-06-12 09:56:01.267629
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_ = Parser()
    parser_.print_help()

# Generated at 2022-06-12 09:56:02.192351
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:57:01.531201
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None

# Generated at 2022-06-12 09:57:02.724460
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-12 09:57:10.912499
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
    > assert Parser().parse(['--alias']) ==
    Namespace(alias='eval $(thefuck $(fc -ln -1))',
    command=[],
    debug=False,
    force_command=None,
    help=False,
    repeat=False,
    shell_logger=None,
    version=False,
    yes=False)
    """

    assert Parser().parse(['--alias']) == Namespace(alias='eval $(thefuck $(fc -ln -1))', command=[], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)

test_Parser_parse()

# Generated at 2022-06-12 09:57:13.888909
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    out = StringIO()
    parser = Parser()
    parser.prin

# Generated at 2022-06-12 09:57:16.125875
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    test_arguments = ["--alias", "--debug", '/bin/ls']
    assert parser.parse(test_arguments) == test_arguments

# Generated at 2022-06-12 09:57:17.518241
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None


# Generated at 2022-06-12 09:57:19.633500
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.usage == '%(prog)s [options] [command]'

# Generated at 2022-06-12 09:57:20.707115
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-12 09:57:31.242772
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .which import which
    from .utils import which_app
    from .notify import notify
    from .settings import Config, load_config, clear_cache
    from .main import get_valid_full_script_name
    from .main import get_valid_script_names
    from .utils import wrap_settings
    from .main import is_pip_installed
    from .main import is_python_package_installed
    from .main import is_installed
    from .main import get_all_executables
    from .main import get_new_aliases
    from .main import get_priority
    from .main import get_valid_commands
    from .main import get_aliases
    from .main import get_scripts_dir
    from .main import get_config_dir
    from .main import get_version

# Generated at 2022-06-12 09:57:32.994436
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    assert a is not None
    assert isinstance(a, Parser)



# Generated at 2022-06-12 09:59:43.634782
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

    parser.print_usage()
    assert sys.stderr.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n"



# Generated at 2022-06-12 09:59:52.257114
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    old_stdout = sys.stdout
    import StringIO
    sys.stdout = StringIO.StringIO()
    parser = Parser()
    parser.print_usage()
    result = sys.stdout.getvalue()
    sys.stdout = old_stdout