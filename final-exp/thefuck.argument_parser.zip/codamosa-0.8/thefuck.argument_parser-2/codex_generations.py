

# Generated at 2022-06-12 09:49:48.799263
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser() is not None


# Generated at 2022-06-12 09:49:49.660279
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:49:50.530567
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None

# Generated at 2022-06-12 09:49:56.492343
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['fuck', 'ls', 'some_file', ARGUMENT_PLACEHOLDER, '-l']) == \
        argparse.Namespace(alias=None, command=['ls', 'some_file'], debug=False,
                           help=False, repeat=False, force_command=None,
                           yes=False, shell_logger=None,
                           enable_experimental_instant_mode=False, version=False)

# Generated at 2022-06-12 09:50:05.800164
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    out = Parser.print_help(parser)

# Generated at 2022-06-12 09:50:12.654214
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from .utils import wrap_streams
    argument_parser = Parser()
    with wrap_streams() as (stdout, stderr):
      argument_parser.print_usage()
    assert stdout.getvalue() == ''
    assert stderr.getvalue() == 'usage: thefuck [-h] [-y | -r] [-d] [--force-command FORCE_COMMAND]\n            [command [command ...]]\n'


# Generated at 2022-06-12 09:50:14.280827
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser()._parser, ArgumentParser)


# Generated at 2022-06-12 09:50:15.672192
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:50:25.405603
# Unit test for method parse of class Parser
def test_Parser_parse():
    parse = Parser().parse
    assert parse(['fuck', '--force-command', 'ls', '-l']) == \
           parse(['fuck', 'ls -l', '--force-command'])
    assert parse(['fuck', 'ls', '--', '-l', '-a']) == \
           Namespace(alias=None, command=['ls', '-l', '-a'],
                     debug=False, enable_experimental_instant_mode=False,
                     force_command=None,
                     help=False, shell_logger=None,
                     repeat=False, version=False, yeah=False, yes=False)

# Generated at 2022-06-12 09:50:27.390393
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:50:47.805383
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert '--yes' in parser._parser._option_string_actions
    assert '--repeat' in parser._parser._option_string_actions
    assert '--debug' in parser._parser._option_string_actions
    assert '--enable-experimental-instant-mode' in parser._parser._option_string_actions
    assert '--force-command' in parser._parser._option_string_actions
    assert '--version' in parser._parser._option_string_actions
    assert '--alias' in parser._parser._option_string_actions
    assert '--shell-logger' in parser._parser._option_string_actions
    assert '-h' in parser._parser._option_string_actions
    assert '--help' in parser._parser._option_string_actions
    assert '-v' in parser._

# Generated at 2022-06-12 09:50:49.366478
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert parser is not None

# Generated at 2022-06-12 09:50:51.396779
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert  parser.parse(['--debug']) == parser._parser.parse_args(['--debug'])


# Generated at 2022-06-12 09:50:52.428365
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:50:55.310737
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parsed_args = parser.parse(['thefuck','ls','tests','--','--help'])
    assert parsed_args.command == ['--help']



# Generated at 2022-06-12 09:51:05.698335
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-12 09:51:07.929313
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['--version'])
    assert result.version



# Generated at 2022-06-12 09:51:16.495452
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    import io
    sys.stderr = file = io.StringIO()
    parser = Parser()
    parser.print_help()
    sys.stderr = sys.__stderr__
    output = file.getvalue()

# Generated at 2022-06-12 09:51:17.698190
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:51:26.082013
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    dummy_std_error = open('/dev/null', 'w')
    try:
        parser = Parser()

        # get output of print_usage()
        sys.stderr = dummy_std_error
        parser.print_usage()
        output = dummy_std_error.buffer.getvalue()

        # check output
        assert 'usage: thefuck' in output, 'unexpected usage string'
        assert '-h, --help' in output, 'usage string should include help'
        assert '-v, --version' in output, 'usage string should include version'
    finally:
        dummy_std_error.close()
        sys.stderr = sys.__stderr__

# Generated at 2022-06-12 09:51:45.913283
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.description is None
    assert parser._parser.add_help
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.usage is None

# Generated at 2022-06-12 09:51:46.828057
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser



# Generated at 2022-06-12 09:51:47.736071
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:51:48.767896
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    return p._parser

# Generated at 2022-06-12 09:51:59.434367
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser._parser.parse_args()
    assert parser.parse(['thefuck', '-v']) == parser._parser.parse_args(['-v'])
    assert parser.parse(['thefuck', '--debug']) == parser._parser.parse_args(['--debug'])
    assert parser.parse(['thefuck', '-v', '--debug']) == parser._parser.parse_args(['-v', '--debug'])
    assert parser.parse(['thefuck', '--alias', 'fuck']) == parser._parser.parse_args(['--alias', 'fuck'])
    assert parser.parse(['thefuck', 'ls']) == parser._parser.parse_args(['--', 'ls'])

# Generated at 2022-06-12 09:52:08.849484
# Unit test for constructor of class Parser
def test_Parser():

    import sys
    import argparse

    # Saving stdout to suppress prints caused by sys.stderr
    stdout_save = sys.stdout
    sys.stdout = sys.stderr

    class FakeParser:
        """Fake ArgumentParser class to control add_argument calls."""

        def __init__(self):
            # Saves calls of add_argument
            self.args = []

        def add_argument_old(self, *args, **kwargs):
            self.args.append((args, kwargs))

        def add_argument(self, *args, **kwargs):
            self.args.append((args, kwargs))

        def add_mutually_exclusive_group(self):
            return self

    fake_parser = FakeParser()

    # Parser.__init__()
    Parser._add

# Generated at 2022-06-12 09:52:19.829616
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # 1
    args = parser.parse(['./fuck'])
    assert args.version is False
    assert args.shell_logger is None
    assert args.debug is False
    assert args.alias is None
    assert args.yes is False
    assert args.repeat is False
    assert args.command == []

    # 2
    args = parser.parse(['./fuck', '-v'])
    assert args.version is True
    assert args.shell_logger is None
    assert args.debug is False
    assert args.alias is None
    assert args.yes is False
    assert args.repeat is False
    assert args.command == []

    # 3
    args = parser.parse(['./fuck', '-l', 'log.txt'])
    assert args.version is False

# Generated at 2022-06-12 09:52:24.076544
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import subprocess
    test_ = subprocess.Popen(['thefuck', '--help'], stdout=subprocess.PIPE)
    out, err = test_.communicate()
    print(out.decode('utf-8'))

if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-12 09:52:25.559821
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    _parser = Parser()
    _parser.print_usage()


# Generated at 2022-06-12 09:52:35.677557
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    assert parser.parse(['./thefuck', 'ls', '-l']) == parser.parse(['./thefuck', 'ls', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['./thefuck', '-a']) == parser.parse(['./thefuck', ARGUMENT_PLACEHOLDER, '-a'])

    assert parser.parse(['./thefuck', 'git', 'ch']) == parser.parse(['./thefuck', '--', 'git', 'ch'])
    assert parser.parse(['./thefuck', 'git', 'ch', ARGUMENT_PLACEHOLDER, '-a']) == parser.parse(['./thefuck', '-a', '--', 'git', 'ch'])

# Generated at 2022-06-12 09:53:14.661859
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()



# Generated at 2022-06-12 09:53:16.501980
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert(p._parser.prog == 'thefuck')
    assert(p._parser.add_help == 0)


# Generated at 2022-06-12 09:53:17.893063
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:53:28.594003
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        sys.stderr.write = MagicMock()
        parser = Parser()
        parser.print_usage()
        sys.stderr.write.assert_has_calls([
            call('usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'
                 '               [-l SHELL_LOGGER]\n'
                 '               [--enable-experimental-instant-mode] [-y] [-r]\n'
                 '               [-d] [--force-command FORCE_COMMAND]\n'
                 '               command [command ...]\n'),
            call('\n')])
    finally:
        sys.stderr.write = sys.stderr.write


# Unit test fpr method print_help of class Parser

# Generated at 2022-06-12 09:53:35.496160
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()
    expected_output = "usage: thefuck [-h] [-v] [-a [custom-alias-name]]" \
                      " [-l SHELL_LOGGER] [--enable-experimental-instant-mode]" \
                      " [--force-command FORCE_COMMAND] [-d] [-y | -r] [--] [command [command ...]]\n"
    assert expected_output == sys.stderr.getvalue()

# Generated at 2022-06-12 09:53:45.336899
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    test_argv = ['/bin/thefuck', 'cd', '..', 'ls', '-l', '/usr/local/bin/thefuck', 'git', 'add', '.', 'git', 'commit', '-m', '"#SOME_COMMENT#"']
    result = parser.parse(test_argv)
    output = (['../', 'ls', '-l', '/usr/local/bin/thefuck', 'git', 'add', '.', 'git', 'commit', '-m', '"#SOME_COMMENT#"'], ['--'])
    if output == (result.command, result.cmd):
        return 1
    return 0

# Generated at 2022-06-12 09:53:53.330779
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    sysargv = sys.argv
    sys.argv = ['thefuck']
    parser.parse(sys.argv)
    assert(sys.argv == ['thefuck'])
    sys.argv = ['thefuck', '-v']
    parser.parse(sys.argv)
    assert(parser._parser.parse_args(['-v']) == sys.argv)
    sys.argv = ['thefuck', '-d']
    parser.parse(sys.argv)
    assert(parser._parser.parse_args(['-d']) == sys.argv)
    sys.argv = ['thefuck', '-a']
    parser.parse(sys.argv)
    assert(parser._parser.parse_args(['-a']) == sys.argv)

# Generated at 2022-06-12 09:53:59.030096
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    #test case 1
    parser._parser.add_argument(
        '-y', '--yes', '--yeah', '--hard',
        action='store_true',
        help='execute fixed command without confirmation')
    assert parser._parser.parse_args(['--yeah']).yes == True
    #test case 2
    parser.print_help()
    #test case 3
    parser.print_usage()

# Generated at 2022-06-12 09:54:09.633991
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        parser.print_usage()

# Generated at 2022-06-12 09:54:14.242714
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['command', 'test'])
    assert arguments.command == ['test']
    arguments = parser.parse(['command', 'test', ARGUMENT_PLACEHOLDER,
                              'test1', 'test2'])
    assert arguments.command == ['test', 'test2', 'test1']


# Generated at 2022-06-12 09:55:21.262025
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:55:24.326259
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['the-fuck', 'echo']) == parser.parse(['the-fuck', 'echo', '--'] + [ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-12 09:55:25.202902
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:55:27.254884
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    out = capture_stderr(parser.print_help)
    assert 'usage: thefuck' in out
    assert 'tf' not in out


# Generated at 2022-06-12 09:55:38.052008
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from cStringIO import StringIO
    output = StringIO()
    sys.stderr = output

    # Parser with no arguments
    Parser().parse([]).print_usage()
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]' \
           '\n               [-y | -r]' \
           '\n               [-d] [--enable-experimental-instant-mode] ' \
           '\n               [--force-command FORCE_COMMAND] [--] [command [command ...]]' \
        in output.getvalue()

    # Parser with arguments
    Parser().parse(['--help', '--alias', 'tf']).print_usage()

# Generated at 2022-06-12 09:55:46.402498
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse([
        '/bin/thefuck', '-v', '-a', 'fuck', '-l', '~/tmp/log.txt',
        '-y', '-d', '--force-command', 'blah', 'pip', 'install', 'django'])
    assert args.version is True
    assert args.alias == 'fuck'
    assert args.shell_logger == '~/tmp/log.txt'
    assert args.yes is True
    assert args.repeat is False
    assert args.debug is True
    assert args.force_command == 'blah'
    assert args.command == ['pip', 'install', 'django']


# Generated at 2022-06-12 09:55:49.775361
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .main import parser

    saved_stderr = sys.stderr
    sys.stderr = stderr = io.StringIO()
    try:
        parser.parse([])
    finally:
        sys.stderr = saved_stderr
    assert stderr.getvalue() == 'usage: thefuck [-h] [-v] [--alias [custom-alias-name]]\n'

# Generated at 2022-06-12 09:55:50.455253
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:55:59.445649
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p.parse(['-v']) == None
    assert p.parse(['-a']) == None
    assert p.parse(['-l']) == None
    assert p.parse(['--disable-experimental-instant-mode']) == None
    assert p.parse(['-h']) == None
    assert p.parse(['-d']) == None
    assert p.parse(['--force-command']) == None
    assert p.parse(['command']) == None
    assert p.parse(['-y']) == None
    assert p.parse(['-r']) == None


# Generated at 2022-06-12 09:56:04.641360
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser._add_arguments()
    parser._add_conflicting_arguments()
    parser._prepare_arguments(['command', 'arg1', 'arg2', ARGUMENT_PLACEHOLDER, 'arg3', 'arg4'])
    parser._prepare_arguments(['command', 'arg1', 'arg2', '--', 'arg3', 'arg4'])



# Generated at 2022-06-12 09:57:17.103923
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    p = Parser()
    old_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        p.print_help()
        output = out.getvalue().strip()
        assert "optional arguments:" in output
        assert "show this help message and exit" in output
    finally:
        sys.stdout = old_stdout


# Generated at 2022-06-12 09:57:17.979582
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-12 09:57:23.826347
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    args = parser.parse(
        ['thefuck', 'ls', 'read', '-l | grep', ARGUMENT_PLACEHOLDER, 'ERROR'])
    assert args.command == ['ls', 'read', '-l | grep', 'ERROR']

    args = parser.parse(['thefuck', 'ls'])
    assert args.command == ['ls']

    args = parser.parse(['thefuck', 'ls', 'read', '-l | grep', 'ERROR'])
    assert args.command == ['ls']

# Generated at 2022-06-12 09:57:34.298318
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', '--alias', 'fuck', 'Command', 'name'])
    assert args.alias == 'fuck'
    assert args.command == ['Command', 'name']

    args = parser.parse(['thefuck', 'git', 'diff', 'origin/master'])
    assert args.command == ['git', 'diff', 'origin/master']

    args = parser.parse(['thefuck', 'git', 'diff', 'origin/master', '--', '-f'])
    assert args.command == ['git', 'diff', 'origin/master', '-f']

    args = parser.parse(['thefuck', '$(brew --prefix)', '$PATH', '--', '-f'])

# Generated at 2022-06-12 09:57:42.234735
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser
    assert p.parse(['-v'])
    assert p.parse(['-a'])
    assert p.parse(['-l'])
    assert p.parse(['-h'])
    assert p.parse(['-d'])
    assert p.parse(['--force-command'])
    assert p.parse([''])
    assert p.parse(['-y'])
    assert p.parse(['-r'])
    assert p.parse(['--yes'])
    assert p.parse(['--yeah'])
    assert p.parse(['--hard'])
    assert p.parse(['--repeat'])

    assert not p.parse(['-z'])
    assert not p.parse(['--f'])

# Generated at 2022-06-12 09:57:50.866555
# Unit test for method parse of class Parser
def test_Parser_parse():
    from thefuck.rules.git_push import match, get_new_command
    parser = Parser()
    command = ['git', 'push', 'origin', 'tar']
    assert parser.parse(['thefuck', 'git', '--force-command', 'origin', 'tar', 'pushed', 'successfully']).command == command
    assert parser.parse(['thefuck', 'git', '--force-command', 'origin', 'tar', ARGUMENT_PLACEHOLDER, 'pushed', 'successfully']).command == command
    assert parser.parse(['thefuck', 'git', '--force-command', 'origin', 'tar', ARGUMENT_PLACEHOLDER, 'pushed', 'successfully']).yes == True

# Generated at 2022-06-12 09:57:59.389337
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    # class name
    assert parser.__class__.__name__ == 'Parser'

    # method
    assert [m for m in dir(parser) if m[0] != '_'] == ['parse', 'print_help', 'print_usage']

    # argument
    assert parser._parser.__class__.__name__ == 'ArgumentParser'

    # options

# Generated at 2022-06-12 09:58:02.298505
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'fuck', 'sudo', '-y']) == \
           parser.parse(['thefuck', 'fuck', 'sudo', '-y', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'fuck', 'ls', '-la']) == \
           parser.parse(['thefuck', 'fuck', 'ls', '-la', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['thefuck', 'fuck', 'ls', '-la']) != \
           parser.parse(['thefuck', 'fuck', 'ls', '-la', '-y'])

# Generated at 2022-06-12 09:58:03.077469
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-12 09:58:07.746610
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import pytest
    from mock import patch
    from .parser import Parser

    with patch('sys.stderr', new=pytest.StringIO()) as stderr:
        parser = Parser()
        parser.print_usage()
        assert 'usage: thefuck' in stderr.getvalue()
