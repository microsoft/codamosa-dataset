

# Generated at 2022-06-12 09:49:55.942996
# Unit test for constructor of class Parser
def test_Parser():
    import argparse
    from .const import ARGUMENT_PLACEHOLDER

    class FakeArgumentParser(argparse.ArgumentParser):

        def __init__(self):
            self.args = []

        def add_argument(self, *args, **kwargs):
            self.args.append(args[0])

        def add_mutually_exclusive_group(self):
            return self

        def parse_args(self, args):
            return args

        def print_usage(self, file=sys.stdout):
            pass

        def print_help(self, file=sys.stdout):
            pass

    parser = Parser()
    parser._parser = FakeArgumentParser()
    parser._add_arguments()


# Generated at 2022-06-12 09:50:05.427738
# Unit test for constructor of class Parser

# Generated at 2022-06-12 09:50:12.892536
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER, '-la', '-l'])
    assert args.command == ['ls', '-l']
    assert len(args.__dict__) == 7
    args = parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER])
    assert args.command == ['ls']
    assert len(args.__dict__) == 7



# Generated at 2022-06-12 09:50:14.525326
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:50:20.710879
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print_usage_help = """\
usage: thefuck [-h] [-v] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-a [CUSTOM_ALIAS_NAME]] [-y | -d | -r] [--force-command FORCE_COMMAND] [--] command ...\
"""
    parser = Parser()
    parser.print_usage()
    usage = sys.stdout.getvalue()
    sys.stdout.seek(0)
    sys.stdout.truncate()
    assert print_usage_help == usage



# Generated at 2022-06-12 09:50:24.702052
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_help()
    out.seek(0)
    output = out.read()
    sys.stderr = sys.__stderr__
    assert "usage:" in output

# Generated at 2022-06-12 09:50:25.835052
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()


# Generated at 2022-06-12 09:50:34.839809
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO

    # Capture stdout
    sys_stdout = sys.stdout
    sys.stdout = StringIO()

    thefuck.shells.get_alias = lambda shell: None
    parser = Parser()
    parser.print_usage()
    assert sys.stdout.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n" \
                                    "              [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n" \
                                    "              [-d] [--force-command FORCE_COMMAND]\n" \
                                    "              [--] [command [command ...]]\n\n"

    # Reset stdout
    sys.stdout = sys_stdout


# Generated at 2022-06-12 09:50:43.202910
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']) == \
           parser._parser.parse_args(['--', 'ls'])
    assert parser.parse(['thefuck', '--help', 'ls']) == \
           parser._parser.parse_args(['--help', '--', 'ls'])
    assert parser.parse(['thefuck', 'ls', '-l', '--color']) == \
           parser._parser.parse_args(['--', 'ls', '-l', '--color'])
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l', '--color']) == \
           parser._parser.parse_args(['-l', '--color', '--', 'ls'])

# Generated at 2022-06-12 09:50:45.556106
# Unit test for constructor of class Parser
def test_Parser():
    d = Parser()
    assert type(d) == Parser
    assert type(d._parser) == ArgumentParser


# Generated at 2022-06-12 09:50:53.776207
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    arguments = parser._parser.parse_args(["-d"])
    assert arguments.debug == True

# Generated at 2022-06-12 09:50:55.891202
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['./thefuck', ARGUMENT_PLACEHOLDER, '--debug', 'command'])

# Generated at 2022-06-12 09:51:04.117016
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .thefuck import TheFuck
    from io import StringIO
    f = StringIO()
    sys.stderr = f
    parser = Parser()
    parser.print_usage()
    assert f.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n          [-l shell-logger]\n          [--enable-experimental-instant-mode]\n          [-d] [--force-command FORCE_COMMAND]\n          [-y | -r]\n          [command [command ...]]\n'


# Generated at 2022-06-12 09:51:14.358121
# Unit test for method parse of class Parser
def test_Parser_parse():
    import sys
    import os
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.parser = Parser()

        def test_should_remove_placeholder_and_move_arguments_to_beginning(self):
            self.assertEqual(
                self.parser._prepare_arguments(
                    ['-v', '--', 'ls', '-l', ARGUMENT_PLACEHOLDER, 'src']),
                ['-v', '--ls', '-l', 'src'])


# Generated at 2022-06-12 09:51:15.640696
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:51:22.096522
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    sys.stderr = open('sys.stderr.log', 'w')
    my_parser = Parser()
    my_parser.print_usage()
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    log = open('sys.stderr.log', 'r')
    stderr_content = log.read()
    log.close()

# Generated at 2022-06-12 09:51:23.761716
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.stderr.write("")


# Generated at 2022-06-12 09:51:34.566677
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import VERSION
    from .utils import is_alias
    from .utils import get_alias
    from .utils import get_version
    from .utils import get_history_file
    from .utils import get_log_file
    from .utils import get_shell_logger
    from .utils import get_settings
    from .utils import get_searcher
    from .utils import get_corrector
    from thefuck.shells import get_shell
    from thefuck.rules import get_rules
    from thefuck.log import log, log_file
    from mock import Mock, patch, call
    import copy
    import sys
    import os
    import sys
    args = ["--version"]
    parser = Parser()
    parser_parse_args = parser._parser.parse_args(args)
    #parser.parse

# Generated at 2022-06-12 09:51:44.177278
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'vim', 'file']) == \
        parser._parser.parse_args(['vim', 'file'])
    assert parser.parse([
        'thefuck', '--force-command', 'vim', 'file', '--option']) == \
        parser._parser.parse_args(['--force-command', 'vim', 'file', '--option'])
    assert parser.parse(['thefuck', '--', 'vim', 'file', '--option']) == \
        parser._parser.parse_args(['--', 'vim', 'file', '--option'])
    assert parser.parse(['thefuck', '--force-command', 'vim', 'file', ARGUMENT_PLACEHOLDER, '--option']) == \
        parser._parser

# Generated at 2022-06-12 09:51:45.794475
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert(parser.print_usage() == None)


# Generated at 2022-06-12 09:51:54.232822
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert 1


# Generated at 2022-06-12 09:52:04.566432
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-12 09:52:10.841326
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    result = StringIO()
    parser = Parser()
    parser.print_usage(file=result)
    result_string = result.getvalue()
    assert result_string == 'Usage: thefuck [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n' \
                           '             [-h] [-y] [-r] [--force-command FORCE_COMMAND]\n            [--debug]\n            [command ...]\n' \
                           'thefuck: error: too few arguments\n'

# Generated at 2022-06-12 09:52:13.811955
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help is False


# Generated at 2022-06-12 09:52:20.748171
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['./thefuck', 'ls', '-l'])
    parser.parse(['./thefuck', 'git', '-l'])
    parser.parse(['./thefuck', 'git', '--alias', 'fuck'])
    parser.parse(['./thefuck', 'git', '--alias'])
    parser.parse(['./thefuck', 'git', '--alias', 'fuck', '--debug', '--help'])
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-12 09:52:27.174358
# Unit test for method parse of class Parser
def test_Parser_parse():
    # prepare
    argv = ['fuck', '-d', 'ls', '--color=yes', ARGUMENT_PLACEHOLDER, '-a', '-y', '--', '-lh']

    # test
    result = Parser().parse(argv)

    assert result.command == ['-lh']
    assert result.debug is True
    assert result.alias is None
    assert result.yes is True
    assert result.repeat is False
    assert result.help is False



# Generated at 2022-06-12 09:52:35.382353
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias
    from io import StringIO
    # pipe_stdout to a string
    output = StringIO()
    sys.stdout = output
    # create and parse arguments
    parser = Parser()
    parser.parse(['./thefuck',ARGUMENT_PLACEHOLDER,'cat','file'])
    # return to stdout
    sys.stdout = sys.__stdout__
    # print and return output
    parser.print_usage()
    return output.getvalue()

# Generated at 2022-06-12 09:52:35.859735
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-12 09:52:42.528639
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Test Parser.print_help() returns default parser output when help asked
    """
    parser = Parser()
    
    # lets modify the original stderr
    prev_stderr = sys.stderr
    sys.stderr = open('/dev/stdout', 'w')

    parser.print_help()
    
    # restore the changes
    sys.stderr.close()
    sys.stderr = prev_stderr

# Generated at 2022-06-12 09:52:46.327200
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True

if __name__ == '__main__':
    test_Parser_print_usage()

# Generated at 2022-06-12 09:53:03.978573
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    assert ('usage: thefuck [-h] [-v] [-a [custom-alias-name]]'
            in p.print_help())


# Generated at 2022-06-12 09:53:04.978301
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().print_help() == None

# Generated at 2022-06-12 09:53:15.684584
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck']) == Namespace(command=[], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    assert Parser().parse(['thefuck', '--alias', ARGUMENT_PLACEHOLDER, 'git', 'push']) == Namespace(alias='git', command=['push'], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    assert Parser().parse(['thefuck', 'git', 'push']) == Namespace(command=['git', 'push'], debug=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False)


# Generated at 2022-06-12 09:53:16.584792
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-12 09:53:20.272777
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert ['fuck', '--', './manage.py', 'migrations'] == parser.parse(['fuck', './manage.py', 'migrations', ARGUMENT_PLACEHOLDER]).command


# Generated at 2022-06-12 09:53:24.137717
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .test_utils import wrap_streams
    with wrap_streams() as (stdout, stderr):
        Parser().print_usage()
    assert 'usage: thefuck' in stderr.getvalue()


# Generated at 2022-06-12 09:53:25.341710
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()


# Generated at 2022-06-12 09:53:26.296578
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == None

# Generated at 2022-06-12 09:53:33.387259
# Unit test for method parse of class Parser
def test_Parser_parse():
    # In this test we check for the parser parsing the arguments.
    testArgumentParser = Parser()
    output = testArgumentParser.parse(['thefuck', '--version'])
    expected = Namespace(alias=None, command=[], debug=False,
              enable_experimental_instant_mode=False, force_command=None,
              help=False, repeat=False, shell_logger=None, version=True, yes=False)
    assert (output == expected)



# Generated at 2022-06-12 09:53:34.682847
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-12 09:54:07.191598
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    result = sys.stderr.getvalue()
    assert "help" in result

# Generated at 2022-06-12 09:54:09.139454
# Unit test for method parse of class Parser
def test_Parser_parse():
  a = Parser()
  args = a.parse(["python3","c"])
  print(args)

# Generated at 2022-06-12 09:54:16.054646
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([sys.executable, 'fuck']) == parser._parser.parse_args([])
    assert parser.parse([sys.executable, 'fuck', '-v']) == parser._parser.parse_args(['-v'])
    assert parser.parse([sys.executable, 'fuck', 'laa']) == parser._parser.parse_args(['--', 'laa'])
    assert parser.parse([sys.executable, 'laa', 'fuck', '--', '-v']) == parser._parser.parse_args(['-v'])

# Generated at 2022-06-12 09:54:27.103726
# Unit test for method parse of class Parser

# Generated at 2022-06-12 09:54:31.482850
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()

    with patch('sys.stderr', new_callable=StringIO) as mocked_stderr:
        parser.print_usage()

    mocked_stderr.seek(0,0)
    text = mocked_stderr.read()
    assert re.search('usage: thefuck', text)


# Generated at 2022-06-12 09:54:40.354753
# Unit test for method print_usage of class Parser

# Generated at 2022-06-12 09:54:46.558317
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from .parser import Parser

    stdout = StringIO()

    p = Parser()
    p.print_help()
    assert stdout.getvalue() == ""

    p = Parser()
    p.print_help(stdout)
    assert stdout.getvalue() != ""



# Generated at 2022-06-12 09:54:47.938255
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck'])
    assert args.command is None # Test if the command is empty


# Generated at 2022-06-12 09:54:48.752721
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser)


# Generated at 2022-06-12 09:54:54.062874
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '--debug']) == \
           parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '--debug'])
    assert parser.parse(['thefuck', '--debug', 'vim', 'test']) == \
           parser.parse(['thefuck', 'vim', 'test', ARGUMENT_PLACEHOLDER, '--debug'])



# Generated at 2022-06-12 09:56:04.596957
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .capture import Capture

    with Capture() as output:
        Parser().print_usage()

    assert 'usage: thefuck' in output.stdout



# Generated at 2022-06-12 09:56:12.071185
# Unit test for constructor of class Parser
def test_Parser():
    # instance
    a = Parser().parse
    # noinspection PyBroadException
    try:
        a(['-v'])
    except Exception:
        assert False
    # noinspection PyBroadException
    try:
        a(['-a'])
    except Exception:
        assert False
    # noinspection PyBroadException
    try:
        a(['-l'])
    except Exception:
        assert False
    # noinspection PyBroadException
    try:
        a(['--force-command'])
    except Exception:
        assert False
    # noinspection PyBroadException
    try:
        a(['--enable-experimental-instant-mode'])
    except Exception:
        assert False
    # noinspection PyBroadException

# Generated at 2022-06-12 09:56:21.237756
# Unit test for method print_help of class Parser

# Generated at 2022-06-12 09:56:22.649300
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    try:
        p = Parser()
        p.print_help()
        return True
    except Exception as e:
        return False

# Generated at 2022-06-12 09:56:24.091527
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # parser.print_help()

    print('Test passed!')

if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-12 09:56:24.740379
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:56:25.924206
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:56:29.302892
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    from io import StringIO
    from contextlib import redirect_stdout
    with redirect_stdout(StringIO()) as out:
        parser.print_help()
        output = out.getvalue().strip()
        assert len(output) != 0

# Generated at 2022-06-12 09:56:30.880084
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:56:34.207031
# Unit test for constructor of class Parser
def test_Parser():
    sys.argv = ["python", "-a", "fuck", "--alias", "--yes", "--debug", "git", "--", "push", "origin", "master"]
    parser = Parser()

    assert parser is not None


# Generated at 2022-06-12 09:59:28.809778
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    parser.print_help()
    #We just want to make sure that this function can be executed twice
    #without any error

# Generated at 2022-06-12 09:59:31.269189
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help
    assert parser._parser.allow_abbrev


# Generated at 2022-06-12 09:59:38.005117
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    sys.stderr = open("test_Parser_print_help.txt", "w")
    p = Parser()
    p.print_help()
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    f = open("test_Parser_print_help.txt", "r")
    s = f.read()
    f.close()
    os.remove("test_Parser_print_help.txt")
    assert s.startswith("usage: thefuck ")
    assert " -h, --help" in s
    assert " -v, --version" in s

# Generated at 2022-06-12 09:59:46.662650
# Unit test for method parse of class Parser
def test_Parser_parse():
    # --------------------------------------------------------
    # Check parser's method parse
    parser = Parser()
    # --------------------------------------------------------
    # Run parse on command 'command with arguments'
    command = ['thefuck', 'command', 'with', 'arguments']
    parsed_command = parser.parse(command)
    assert parsed_command.command == ['command']
    assert parsed_command.args == ['with', 'arguments']
    # --------------------------------------------------------
    # Run parse on command 'command --arg1 --arg2'
    parsed_command = parser.parse(['thefuck', 'command', '--arg1', '--arg2'])
    assert parsed_command.command == ['command']
    assert len(parsed_command.args) == 2
    assert parsed_command.args[0] == '--arg1'