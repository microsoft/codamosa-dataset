

# Generated at 2022-06-12 09:49:54.695868
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .const import ALIAS_CONFIG_TEMPLATE
    from .utils import get_alias

    alias = get_alias()
    alias = alias or ALIAS_CONFIG_TEMPLATE
    output = StringIO()
    parser = Parser()
    parser.print_usage(file=output)
    assert output.getvalue().strip() == \
        'usage: thefuck [-h] [-v] [-a [{}]] [-l SHELL_LOGGER]\n' \
        '              [--enable-experimental-instant-mode] [-d]\n' \
        '              [-y | -r] [--force-command FORCE_COMMAND] [command [command ...]]'.format(alias)



# Generated at 2022-06-12 09:49:56.060164
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None


# Generated at 2022-06-12 09:50:05.491502
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # no arguments (just thefuck)
    assert 'usage:' in parser.parse([''])
    # no arguments (thefuck command)
    assert 'usage:' in parser.parse(['command'])
    # -v and thefuck
    assert '0.0.0' in parser.parse(['', '-v'])
    # --version and thefuck
    assert '0.0.0' in parser.parse(['', '--version'])
    # -a and thefuck
    assert parser.parse(['', '-a']).alias == get_alias()
    # -a custom_alias and thefuck
    assert parser.parse(['', '-a', 'custom_alias']).alias == 'custom_alias'
    # -l and thefuck

# Generated at 2022-06-12 09:50:10.406796
# Unit test for constructor of class Parser
def test_Parser():
    parser_ = Parser()
    args = parser_._parser.parse_args(['--alias', 'fuck'])
    assert args.alias == 'fuck'
    args = parser_._parser.parse_args(['--', 'ls', '-a'])
    assert args.command == ['ls', '-a']


# Generated at 2022-06-12 09:50:14.525814
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse([sys.executable, 'fuck', '--force-command',
                           ARGUMENT_PLACEHOLDER, 'echo', '$USER'])
    assert args.command == ['echo', '$USER']



# Generated at 2022-06-12 09:50:21.877669
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['python', 'script', 'command_1', '-v']) == parser.parse(['python', 'script', 'command_1', '-v', 'fuck'])
    assert parser.parse(['python', 'script', 'command_1', '-v']) == parser.parse(['python', 'script', 'command_1', '-v', 'hey', 'fuck'])
    assert parser.parse(['python', 'script', 'command_1', '-v']) == parser.parse(['python', 'script', 'command_1', '-v', 'fuck', 'hey'])

# Generated at 2022-06-12 09:50:32.232622
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    args = parser.parse(["-a"])
    assert args.alias == get_alias()

    args = parser.parse(["-a", "fuck"])
    assert args.alias == "fuck"

    args = parser.parse(["--debug"])
    assert args.debug

    args = parser.parse(["--force-command", "git add ."])
    assert args.force_command == "git add ."

    args = parser.parse(["-d", "git add ."])
    assert args.debug
    assert args.command == ["git", "add", "."]

    args = parser.parse(["-d", "git add .", ARGUMENT_PLACEHOLDER, "--force-command", "git add ."])
    assert args.debug

# Generated at 2022-06-12 09:50:41.326923
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # create a reference
    f = sys.stderr

# Generated at 2022-06-12 09:50:42.488910
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:50:50.648117
# Unit test for method parse of class Parser
def test_Parser_parse():

    class MockArgumentParser(object):
        def parse_args(self, argv):
            return argv

        def print_usage(self, f):
            self.called_print_usage = True

        def print_help(self, f):
            self.called_print_help = True

    parser = MockArgumentParser()
    parser_class = Parser
    parser_class._parser = parser
    arguments = parser_class().parse(['foo', 'bar', 'baz'])
    assert arguments == ['foo', 'bar', 'baz']
    assert parser.called_print_usage
    assert parser.called_print_help

# Generated at 2022-06-12 09:50:59.938622
# Unit test for method parse of class Parser
def test_Parser_parse():
    parse_instance = Parser()
    parser_result = parse_instance.parse(['', '-v', 'status'])
    assert parser_result.debug is None
    assert parser_result.repeat is None
    assert parser_result.yes == False



# Generated at 2022-06-12 09:51:04.475952
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert len(parser._parser._actions) == 10
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'alias'
    assert parser._parser._actions[2].dest == 'shell_logger'


# Generated at 2022-06-12 09:51:07.799845
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except:
        assert False
    assert True

# unit test for method print_help of class Parser

# Generated at 2022-06-12 09:51:08.698548
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-12 09:51:15.487466
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser._prepare_arguments(['thefuck', '-v'])
    assert parser.parse(arguments).version

    arguments = parser._prepare_arguments(['thefuck', 'ls', '-l'])
    assert parser.parse(arguments).command == ['--', 'ls', '-l']

    arguments = parser._prepare_arguments(['thefuck', 'ls', '-l', '-a'])
    assert parser.parse(arguments).alias == get_alias()
    assert parser.parse(arguments).command == ['--', 'ls', '-l']

# Generated at 2022-06-12 09:51:22.919897
# Unit test for method parse of class Parser
def test_Parser_parse():
    arguments = ['-l', 'shell.log', 'git', 'push',
                 ARGUMENT_PLACEHOLDER, '-h']
    parser = Parser()
    args = parser.parse(arguments)

    assert args.command == ['git', 'push']
    assert args.alias == get_alias()
    assert args.shell_logger == 'shell.log'
    assert args.debug is False
    assert args.yes is False
    assert args.repeat is False
    assert args.force_command is None

    arguments = ['-h']
    args = parser.parse(arguments)

    assert args.help is True



# Generated at 2022-06-12 09:51:24.828872
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    exit_code = Parser().print_help()
    assert exit_code==0


# Generated at 2022-06-12 09:51:28.515295
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Unit test for method print_help of class Parser"""
    parser = Parser()
    sys.stdout = open('/tmp/test_Parser_print_help.txt', 'w')
    parser.print_help()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 09:51:39.599740
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    args = p.parse('fuck'.split())
    assert args.command == []
    assert args.debug == False

    args = p.parse('fuck echo'.split())
    assert args.command == ['echo']
    assert args.debug == False

    args = p.parse('fuck test --debug'.split())
    assert args.command == ['test']
    assert args.debug == True

    args = p.parse('fuck printf z z'.split())
    assert args.command == ['printf z z']
    assert args.debug == False

    args = p.parse('fuck --debug printf z z'.split())
    assert args.command == ['printf z z']
    assert args.debug == True

    args = p.parse('fuck --debug printf z z -- -z'.split())

# Generated at 2022-06-12 09:51:40.629140
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:52:02.237313
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_alias
    from .parser import Parser
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import wrap_stream
    from six.moves import StringIO
    import sys

    # Unit testing Parser print_help
    stdout = StringIO()
    sys.stdout = stdout

# Generated at 2022-06-12 09:52:03.491946
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:52:04.512242
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:52:05.811975
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None


# Generated at 2022-06-12 09:52:07.028579
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert type(parser) == Parser


# Generated at 2022-06-12 09:52:15.728923
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import tempfile, os, io
    fd, path = tempfile.mkstemp()
    os.close(fd)
    f = io.open(path, mode='w', encoding='utf-8')
    parser = Parser()
    try:
        parser.print_help(file=f)
        f.close()
        with open(path, encoding='utf-8') as f:
            help = f.read()
            assert len(help) > 0
    finally:
        os.remove(path)


# Generated at 2022-06-12 09:52:17.323790
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:52:22.726185
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parse = parser.parse(['thefuck', 'command', 'arg1', 'arg2', '--opt1', '--opt2',  ARGUMENT_PLACEHOLDER, 'arg3'])
    assert parse.command == ['command', 'arg1', 'arg2', '--opt1', '--opt2']
    assert parse.yes == False
    assert parse.repeat == False
    assert parse.shell_logger == None
    assert parse.debug == False
    assert parse.help == False

# Generated at 2022-06-12 09:52:23.647052
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:52:24.594324
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:53:33.495829
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser._actions[0].dest == '_version'
    assert p._parser._actions[0].help == "show program's version number and exit"
    assert p._parser._actions[0].option_strings == ['-v', '--version']
    assert p._parser._actions[0].nargs == 0
    assert p._parser._actions[0].default == False
    assert p._parser._actions[0].const == None
    assert p._parser._actions[0].choices == None
    assert p._parser._actions[0].required == False

    # Test add_arguments
    p._add_arguments()
    assert p._parser._actions[5].dest == '_alias'

# Generated at 2022-06-12 09:53:39.665458
# Unit test for constructor of class Parser
def test_Parser():
    from sys import stdout, stderr
    p = Parser()
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False
    p._parser.print_usage(stdout)
    p._parser.print_help(stdout)
    q = Parser()
    assert q._parser.prog == 'thefuck'
    assert p._parser.add_help == False
    q._parser.print_usage(stderr)
    q._parser.print_help(stderr)


# Generated at 2022-06-12 09:53:44.105196
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert len(parser._parser._actions) == 8
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help is False
    assert get_alias() is not None


# Generated at 2022-06-12 09:53:49.425133
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .tests.utils import support_file
    import io
    import sys

    argv = ['thefuck', '-h']
    capture = io.StringIO()  # Create an in-memory filelike object
    sys.stdout = capture     # Switch out the regualr stdout
    parser = Parser()
    parser.parse(argv)
    parser.print_help()
    assert len(capture.getvalue()) > 1


# Generated at 2022-06-12 09:53:55.941083
# Unit test for method parse of class Parser
def test_Parser_parse():

    test_Parser_parse.test_number += 1

    parser = Parser()
    argv = ['/usr/bin/thefuck',
            '--yes',
            '--shell-logger',
            '/tmp/shell.log',
            '--',
            'echo',
            'hello',
            'world',
            '--force-command',
            'rebase']

    result_args = parser.parse(argv)

    assert result_args.command == ['echo', 'hello', 'world', '--force-command',
                                   'rebase']
    assert result_args.yes is True
    assert result_args.debug is False
    assert result_args.shell_logger == '/tmp/shell.log'
    assert result_args.help is False


# Generated at 2022-06-12 09:54:06.650960
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck',
                         './test.py', 'argument placeholder',
                         '--', 'ls', '-la']) == \
        Namespace(alias=None, command_script=None,
                  force_command=None, debug=False,
                  help=False, shell_logger=None, yes=False,
                  repeat=False, version=False,
                  command=['ls', '-la'])


# Generated at 2022-06-12 09:54:16.173598
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck']) == parser.parse(['fuck', '--'])
    assert parser.parse(['fuck', '--', 'echo', '$PATH']) == \
        parser.parse(['fuck', 'echo', '$PATH'])
    assert parser.parse(['fuck', 'echo', '$PATH']) == \
        parser.parse(['fuck', 'echo', '$PATH', '--'])
    assert parser.parse(['fuck', 'echo', '$PATH', '--']) == \
        parser.parse(['fuck', 'echo', '$PATH', '--', '--'])

# Generated at 2022-06-12 09:54:27.144925
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert(parser.parse(['', ARGUMENT_PLACEHOLDER, 'git', '-h'])
            == parser.parse(['', 'git', '-h']))
    assert(parser.parse(['', '', ARGUMENT_PLACEHOLDER, 'git', '-h'])
            == parser.parse(['', '', 'git', '-h']))
    assert(parser.parse(['', ARGUMENT_PLACEHOLDER, 'git', '-h']).command
            == ['git', '-h'])
    assert(parser.parse(['', 'git', '-h']).command == [])
    assert(parser.parse(['', '-r']).repeat == True)

# Generated at 2022-06-12 09:54:31.733677
# Unit test for method parse of class Parser
def test_Parser_parse():
    Parser = Parser()
    assert Parser.parse(['thefuck', '-r', 'cat']) == ['thefuck', '-r', 'cat']
    assert Parser.parse(['thefuck', 'cat']) == ['thefuck', 'cat']
    assert Parser.parse(['thefuck', 'cat', '1', '2', '3']) == ['thefuck', 'cat', '1', '2', '3']
    assert Parser.parse(['thefuck', '-r', 'cat', '1', '2', '3']) == ['thefuck', '-r', 'cat', '1', '2', '3']

# Generated at 2022-06-12 09:54:33.823454
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser._parser.prog == 'thefuck')


# Generated at 2022-06-12 09:54:51.208911
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    parser = Parser()
    parser.print_help()
    output = sys.stderr.getvalue()
    print(output)
    sys.stderr = old_stderr


if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-12 09:54:52.767895
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser._parser = ArgumentParser(prog='thefuck')
    parser.print_help()

# Generated at 2022-06-12 09:54:55.380328
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    with patch('sys.stderr'):
        Parser().print_usage()


# Generated at 2022-06-12 09:54:57.279495
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['-v'])


if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-12 09:55:07.932627
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from mock import patch
    from .utils import stderr

    with patch('sys.stderr', stderr):
        Parser().print_help()


# Generated at 2022-06-12 09:55:14.479269
# Unit test for method parse of class Parser

# Generated at 2022-06-12 09:55:19.223584
# Unit test for constructor of class Parser
def test_Parser():
        parser1 = Parser()
        parser1.parse(["whatfuck.py", "--debug", "echo", "-n", "--verbose"])

if __name__ == "__main__":
    test_Parser()

# Generated at 2022-06-12 09:55:26.435426
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    output = StringIO()
    parser = Parser()
    parser.print_usage(file=output)
    assert output.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'\
        '                [-l shell-logger] [--enable-experimental-instant-mode]\n'\
        '                [-d] [--force-command FORCE-COMMAND]\n'\
        '                [command [command ...]]\n\n'



# Generated at 2022-06-12 09:55:37.448685
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    def assert_equal(argv, correct_argv):
        args = parser.parse(argv.split())
        assert sum(1 for arg in correct_argv if not arg.startswith('--') and getattr(args, arg)) == 1

    assert_equal('fuck', ['-l'])
    assert_equal('fuck -v', ['-v', '-l'])
    assert_equal('fuck -a', ['-a', '-l'])
    assert_equal('fuck -h', ['-h', '-l'])
    assert_equal('fuck -d', ['-d', '-l'])
    assert_equal('fuck -y', ['-y', '-l'])
    assert_equal('fuck -r', ['-r', '-l'])
    assert_equal

# Generated at 2022-06-12 09:55:39.401181
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # GIVEN
    parser = Parser()
    # WHEN
    # THEN
    parser.print_usage()


# Generated at 2022-06-12 09:56:13.093815
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l', '-a']) == parser._parser.parse_args(['ls', '-l', '-a'])


# Generated at 2022-06-12 09:56:14.510036
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:56:23.173909
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-v']) == argparse.Namespace(
        alias=None, command=[],
        debug=False, force_command=None,
        help=False, repeat=False, shell_logger=None,
        version=True, yes=False
    )
    assert parser.parse(['thefuck', '--shell-logger', '~/.shell_logger']) == argparse.Namespace(
        alias=None, command=[], debug=False,
        force_command=None, help=False,
        repeat=False,
        shell_logger='~/.shell_logger',
        version=False, yes=False
    )
    assert parser.parse(['thefuck', '-l', '~/.shell_logger']) == argparse.Names

# Generated at 2022-06-12 09:56:31.391039
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .shells import Shell
    from .env import Env
    from .conf import Config

    class fake_parser:
        class fake_args:
            pass

        @staticmethod
        def parse_args(arguments):
            args = fake_parser.fake_args()
            if arguments == ['-l', 'log']:
                args.shell_logger = 'log'
            elif arguments == ['--force-command', 'forced_command', 'command']:
                args.force_command = 'forced_command'
            else:
                args.command = arguments

            args.alias = None
            args.debug = False
            args.help = False
            args.repeat = False
            args.yeah = False
            args.version = False
            args.enable_experimental_instant_mode = False

            return args

   

# Generated at 2022-06-12 09:56:32.624268
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-12 09:56:34.245210
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Call print_usage of class Parser
    p = Parser()
    p.print_usage()


# Generated at 2022-06-12 09:56:35.131868
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:56:36.471341
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:56:37.387092
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()



# Generated at 2022-06-12 09:56:38.821211
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    return p

print(test_Parser())



# Generated at 2022-06-12 09:57:23.745969
# Unit test for method parse of class Parser
def test_Parser_parse():
    import os
    os.chdir('/home/nini')
    parser = Parser()
    parser.parse(['fuck', 'python', '-V'])
    parser.parse(['fuck', '-r', '-v', 'python', '-V'])
    parser.parse(['fuck', '-d', 'python', '-V'])
    parser.parse(['fuck', '-a', 'fuck'])
    parser.parse(['fuck', '-h'])
    parser.parse(['fuck', '-l', 'logging.txt', 'python', '-V'])

# Generated at 2022-06-12 09:57:25.241618
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    args = ['--help']
    p = Parser()
    p.parse(args)
    p.print_usage()

# Generated at 2022-06-12 09:57:26.567704
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser.__init__()


# Generated at 2022-06-12 09:57:33.912357
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    f = open('test_usage_file', 'w')
    sys.stderr = f
    x = Parser()
    x.print_usage()
    f.close()
    f = open('test_usage_file', 'r')
    test_code = f.read()
    f.close()
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]' in test_code
    import os
    os.remove('test_usage_file')


# Generated at 2022-06-12 09:57:35.030345
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser != 0


# Generated at 2022-06-12 09:57:36.997179
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    arg_parser = Parser()
    assert arg_parser.parse(['', '-a']).alias == get_alias()


# Generated at 2022-06-12 09:57:38.684089
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    cmd = 'python -m thefuck'
    parser = Parser()
    assert cmd in parser.print_usage()


# Generated at 2022-06-12 09:57:45.317555
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .config import Config
    from .application import Application
    from .utils import replace_argument, get_closest
    from .utils import get_aliases
    import re
    test_config = Config(load_only=['rules', 'script_type'])
    test_config.no_colors = True
    test_config.wait_slow_command = None
    test_config.require_confirmation = True
    test_config.rules = [{'name': 'gitpush',
                          'match': 'git push',
                          'get_new_command': lambda: 'echo "fuck"',
                          'side_effect': None,
                          'priority': 9001,
                          'datetime': None,
                          'enabled': True}]
    test_config.script_type = 'sh'
    test_

# Generated at 2022-06-12 09:57:48.784652
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Prepare
    output = StringIO()
    p = Parser()
    # exercise
    p.print_help()
    # verify
    assert 'usage: thefuck' in output.getvalue()
    assert '-d, --debug' in output.getvalue()



# Generated at 2022-06-12 09:57:49.653190
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:59:30.397085
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser=Parser()
    parser.print_help()
    parser.print_usage()



# Generated at 2022-06-12 09:59:32.188668
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Make a new instance
    parser = Parser()
    # Run the unit test
    parser.print_help()

# Generated at 2022-06-12 09:59:33.147990
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser.parse([]) is not None

# Generated at 2022-06-12 09:59:42.251170
# Unit test for method parse of class Parser
def test_Parser_parse():

    assert Parser().parse(['fuck', 'git', 'status']) ==\
        argparse.Namespace(alias=None, command=['git', 'status'],
                           debug=False, enable_experimental_instant_mode=False,
                           help=False, repeat=False, shell_logger=None,
                           version=False, yes=False)

    assert Parser().parse(['fuck', 'git', 'status', '-v']) ==\
        argparse.Namespace(alias=None, command=['git', 'status', '-v'],
                           debug=False, enable_experimental_instant_mode=False,
                           help=False, repeat=False, shell_logger=None,
                           version=False, yes=False)
