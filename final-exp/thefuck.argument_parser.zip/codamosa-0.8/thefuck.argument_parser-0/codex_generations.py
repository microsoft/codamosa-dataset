

# Generated at 2022-06-12 09:49:55.898703
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'echo ']) == parser.parse(['thefuck'])
    assert parser.parse(['thefuck', 'echo']) == parser.parse(['thefuck'])
    assert parser.parse(['thefuck', '--', 'echo']) == parser.parse(['thefuck', 'echo'])
    assert parser.parse(['thefuck', '-l', 'logfile', 'echo']) == parser.parse(['thefuck', 'echo'])
    assert parser.parse(['thefuck', '--force-command', 'echo hi', 'echo']) == parser.parse(['thefuck', 'echo', 'hi'])

# Generated at 2022-06-12 09:49:58.019546
# Unit test for constructor of class Parser
def test_Parser():
    try:
        Parser()
    except:
        return False
    return True

# Unit test that checks add_arguments of class Parser

# Generated at 2022-06-12 09:49:59.410363
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert(parser != None)



# Generated at 2022-06-12 09:50:00.623369
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-12 09:50:01.646352
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:50:06.834020
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    stdout = sys.stderr
    sys.stderr = StringIO()
    parser.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command force-command] [command [command ...]]\n'
    sys.stderr = stdout


# Generated at 2022-06-12 09:50:10.658012
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    argv = ['/Users/zhengming/.pyenv/versions/3.4.3/bin/python', 'thefuck']
    parser = Parser()
    parser.print_help()
    print("Help message")
    args = parser.parse(argv)
    print(args)

# Generated at 2022-06-12 09:50:12.940689
# Unit test for constructor of class Parser
def test_Parser():
        testObj = Parser()
        testObj.parse(['','test','test2'])
        testObj.print_usage()

# Generated at 2022-06-12 09:50:14.573656
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:50:18.674065
# Unit test for method parse of class Parser
def test_Parser_parse():
    test_cmd = '/bin/ls blah.txt'
    test_argv = test_cmd.split() + [ARGUMENT_PLACEHOLDER, '--help']
    parser = Parser()
    assert parser.parse(test_argv) == parser.parse(test_cmd.split() + ['--', '--help'])

# Generated at 2022-06-12 09:50:23.626187
# Unit test for method print_help of class Parser
def test_Parser_print_help():
  parser = Parser()
  parser.print_help()

# Generated at 2022-06-12 09:50:24.950837
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True

# Generated at 2022-06-12 09:50:27.330309
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-12 09:50:28.402571
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().print_help() is None

# Generated at 2022-06-12 09:50:35.990584
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', 'python']) == (
        parser._parser.parse_args(['python']))
    assert parser.parse(['fuck', 'python', '--help']) == (
        parser._parser.parse_args(['--', 'python', '--help']))
    assert parser.parse(['fuck', '--']) == (
        parser._parser.parse_args(['--']))
    assert parser.parse(['fuck', '--', 'python']) == (
        parser._parser.parse_args(['--', 'python']))
    assert parser.parse(['fuck', 'python', ARGUMENT_PLACEHOLDER, '--help']) == (
        parser._parser.parse_args(['--help', '--', 'python']))
    assert parser

# Generated at 2022-06-12 09:50:37.279454
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:50:44.029532
# Unit test for method parse of class Parser
def test_Parser_parse():
    class FakeArgumentParser(object):
        def parse_args(self, argv):
            return argv

        def print_usage(self, stream):
            print('USAGE', file=stream)

        def print_help(self, stream):
            print('HELP', file=stream)

    fake_parser = FakeArgumentParser()
    parser = Parser()
    parser._parser = fake_parser
    assert parser.parse(['thefuck', '-v']) == ['-v']
    assert parser.parse(['thefuck', '--version']) == ['--version']
    assert parser.parse(['thefuck', '--help']) == ['--help']
    assert parser.parse(['thefuck']) == []

# Generated at 2022-06-12 09:50:46.368578
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    print("-------------- test_Parser_print_usage --------------")
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:50:48.239865
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    with pytest.raises(SystemExit):
        Parser().print_usage()


# Generated at 2022-06-12 09:50:49.412120
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-12 09:50:58.522000
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == ArgumentParser(prog='thefuck', add_help=False).print_usage(sys.stderr)


# Generated at 2022-06-12 09:51:03.551885
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    opt = p._parser.format_help()

    o = sys.stdout
    sys.stdout = cStringIO.StringIO()
    p.print_usage()
    out = sys.stdout.getvalue()
    sys.stdout = o

    assert opt == out



# Generated at 2022-06-12 09:51:12.282830
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = StringIO()
    old_stderr = sys.stderr
    sys.stderr = output

    parser.print_usage()
    output.seek(0)
    message = output.read()

    sys.stderr = old_stderr
    assert message == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y |-r] [--] [command [command ...]]\n"


# Generated at 2022-06-12 09:51:17.142568
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .mocks import FakeStderr
    stderr = FakeStderr()
    parser = Parser()
    parser.print_usage()
    assert stderr.buffer == 'usage: thefuck [--alias custom-alias-name] ' \
                            '[--debug]\n          [--enable-experimental-instant-mode]\n          [--no-spawn-unsafe-shell] [-h] (-y | -r)\n          [command [command ...]]\n'


# Generated at 2022-06-12 09:51:19.092024
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'thefuck', '']) == parser.parse(['thefuck'])

# Generated at 2022-06-12 09:51:21.109714
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_Parser = Parser()
    result = test_Parser.print_usage()
    assert isinstance(result,None)


# Generated at 2022-06-12 09:51:22.004719
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:51:32.962538
# Unit test for method parse of class Parser
def test_Parser_parse():
    # test with alias --t
    parser = Parser()
    arguments = parser.parse(['thefuck', '--t', 'ls', '--ll'])
    assert arguments.command == ['ls', '--ll']
    assert arguments.alias == 't'
    assert not arguments.yes and not arguments.repeat
    assert not arguments.debug and not arguments.shell_logger
    assert not arguments.version and not arguments.help
    assert not arguments.force_command
    assert not arguments.enable_experimental_instant_mode

    # test with alias --foo, 'ls --ll' is command
    arguments = parser.parse(['thefuck', '--foo', 'ls', '--ll'])
    assert arguments.command == ['ls', '--ll']
    assert arguments.alias == 'foo'
    assert not arguments.yes and not arguments

# Generated at 2022-06-12 09:51:35.645193
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_message = parser.print_help()
    assert isinstance(help_message, ),"Parser.print_help is not returning help_message"

# Generated at 2022-06-12 09:51:37.380056
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except SystemExit:
        pass

# Generated at 2022-06-12 09:51:51.616643
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


parser = Parser()

# Generated at 2022-06-12 09:51:54.280751
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    for help_message in parser._parser.format_help().splitlines()[:5]:
        assert help_message == ""


# Generated at 2022-06-12 09:51:55.645615
# Unit test for constructor of class Parser
def test_Parser():
    obj = Parser()
    assert (obj._parser.format_help())

# Generated at 2022-06-12 09:52:05.910417
# Unit test for method parse of class Parser
def test_Parser_parse():
    # test for argument_placeholder
    test_args = ['thefuck', 'placeholder', 'command', 'wrong', '--option']
    parser = Parser()
    args_test = parser.parse(test_args)
    assert (args_test.command == ['command', 'wrong', '--option'])

    # test for command starting with '-'
    test_args = ['thefuck', '--', 'command', 'wrong', '--option']
    parser = Parser()
    args_test = parser.parse(test_args)
    assert (args_test.command == ['command', 'wrong', '--option'])

    # test for command starting with '--'
    test_args = ['thefuck', '--', '--command', 'wrong', '--option']
    parser = Parser()

# Generated at 2022-06-12 09:52:12.306363
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert _parse_with_arguments([]) == ('', [])
    assert _parse_with_arguments(['-a']) == ('', [])
    assert _parse_with_arguments(['--alias']) == ('', [])
    assert _parse_with_arguments(['--alias', 'fuck']) == ('fuck', [])
    assert _parse_with_arguments(['-v']) == ('', ['-v'])
    assert _parse_with_arguments(['-a', '-v']) == ('', ['-a', '-v'])
    assert _parse_with_arguments(['--alias', 'fuck', '-v']) == \
        ('fuck', ['-v'])

# Generated at 2022-06-12 09:52:22.356644
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Ensure that the parser help message is correct.
    """
    parser = Parser()
    output = sys.stderr
    parser.print_help()

# Generated at 2022-06-12 09:52:31.518006
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = StringIO()
    stderr = sys.stderr
    sys.stderr = output
    parser.print_usage()
    # sys.stderr.write(output.getvalue())
    assert output.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n                [--enable-experimental-instant-mode] [-y | -r]\n                [-d] [--force-command FORCE_COMMAND] [--]\n                [command [command ...]]\n\n"
    sys.stderr = stderr


# Generated at 2022-06-12 09:52:33.111549
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True

# Generated at 2022-06-12 09:52:34.398798
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser._parser)


parser = Parser()

# Generated at 2022-06-12 09:52:43.893297
# Unit test for method print_help of class Parser

# Generated at 2022-06-12 09:53:13.828594
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-12 09:53:14.746264
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:53:20.076231
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    s = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n'
    x = Parser()
    x.print_usage()
    assert sys.stderr.getvalue() == s


# Generated at 2022-06-12 09:53:21.533952
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:53:22.578054
# Unit test for constructor of class Parser
def test_Parser():
    a=Parser()
    print(a)

# Generated at 2022-06-12 09:53:29.676389
# Unit test for method parse of class Parser
def test_Parser_parse():
	test_arg_1 = 'thefuck --force-command \'ls -lha\''
	test_arg_2 = 'thefuck'
	test_arg_3 = 'thefuck -r --force-command \'ls -lha\''
	p = Parser()
	p.parse(test_arg_1.split())
	p.parse(test_arg_2.split())
	p.parse(test_arg_3.split())

if __name__ == '__main__':
	test_Parser_parse()

# Generated at 2022-06-12 09:53:37.042242
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    if sys.stdout.encoding == 'UTF-8':
        assert '--debug' in parser.print_help()
        # print_help() in Python 3.5 and 3.6 returns None
        if sys.version_info < (3, 7):
            assert 'ВКЛЮЧИТЬ' in parser.print_help()
    else:
        assert '--debug' in parser.print_help()
        assert 'Enable' in parser.print_help()



# Generated at 2022-06-12 09:53:48.390077
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test for correct result
    test_argv1 = [
        'thefuck', 'cd', '~/Downloads', ARGUMENT_PLACEHOLDER,
        '-v', '--alias', 'fuck', '--', 'test_argv1']
    test_parser1 = Parser()
    test_result1 = test_parser1.parse(test_argv1)
    assert test_argv1[4:] + test_argv1[3:4] == test_result1.command
    assert test_result1.alias == 'fuck'
    assert test_result1.version == True
    assert test_result1.yes == False
    assert test_result1.repeat == False

    # Test for correct result

# Generated at 2022-06-12 09:53:49.261804
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:53:49.964677
# Unit test for constructor of class Parser
def test_Parser():
    assert isinstance(Parser(), object)
    assert Parser()


# Generated at 2022-06-12 09:54:39.861628
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import get_alias

    parser = Parser()
    args = parser.parse([
        'thefuck',
        '-y', '--alias', 'fuck',
        ARGUMENT_PLACEHOLDER,
        'cd', 'some_path'])
    assert args.yes

    args = parser.parse([
        'thefuck',
        '--alias', 'fuck',
        ARGUMENT_PLACEHOLDER,
        'cd', 'some_path'])
    assert args.alias == get_alias()

    args = parser.parse([
        'thefuck',
        '--alias', 'fuck',
        ARGUMENT_PLACEHOLDER,
        'cd', 'some_path'])
    assert args.alias == 'fuck'


# Generated at 2022-06-12 09:54:51.871248
# Unit test for constructor of class Parser
def test_Parser():
    from .const import ARGUMENT_PLACEHOLDER

    # For version
    parser_version = Parser()
    argv_version = ['python', '-v']
    argv_version_sh = ['bash', '-c', 'fuck']
    options_version = parser_version.parse(argv_version)
    options_version_sh = parser_version.parse(argv_version_sh)
    assert options_version.version == True
    assert options_version.command == None

    # For alias
    parser_alias = Parser()
    argv_alias = ['python', '-a', 'tf']
    options_alias = parser_alias.parse(argv_alias)
    assert options_alias.alias == 'tf'
    assert options_alias.command == None

# Generated at 2022-06-12 09:54:53.038683
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-12 09:55:03.564357
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Test: without any options
    parser = Parser()
    args = parser.parse([__name__])
    assert args.help is False
    assert args.alias is None
    assert args.enable_experimental_instant_mode is False
    assert args.debug is False
    assert args.shell_logger is None
    assert args.force_command is None
    assert args.command == []
    assert args.yes is False
    assert args.repeat is False

    # Test: with options
    args = parser.parse(['--help'])
    assert args.help is True

    args = parser.parse(['--alias'])
    assert args.alias == get_alias()

    args = parser.parse(['--debug'])
    assert args.debug is True


# Generated at 2022-06-12 09:55:04.517215
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:55:05.798733
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    obj = Parser()
    assert obj.print_usage() == None


# Generated at 2022-06-12 09:55:06.670918
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:55:12.745607
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    import sys

    output = io.StringIO()
    sys.stderr = output
    parser = Parser()
    parser.print_usage()
    sys.stderr = sys.__stderr__

    assert output.getvalue() == 'usage: thefuck [--version] [--alias [custom-alias-name]] [--shell-logger LOG] [--enable-experimental-instant-mode] [--help] [-d] [--force-command CMD] [command [command ...]]\n'

# Generated at 2022-06-12 09:55:24.368834
# Unit test for method parse of class Parser
def test_Parser_parse():

    parser = Parser()
    # Empty argument
    assert parser.parse([]) == None
    # Has an argument with ARGUMENT_PLACEHOLDER
    assert parser.parse(['thefuck', 'git', 'add', '-p', '', '-a', '', ARGUMENT_PLACEHOLDER]) ==  parser._prepare_arguments(['git', 'add', '-p', '', '-a', '', ARGUMENT_PLACEHOLDER])
    # Has an argument without ARGUMENT_PLACEHOLDER
    assert parser.parse(['thefuck', '-v']) == parser._prepare_arguments(['-v'])
    # Has an argument with ARGUMENT_PLACEHOLDER and an argument without ARGUMENT_PLACEHOLDER
    assert parser

# Generated at 2022-06-12 09:55:28.904936
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class StdErrMock(object):
        def __init__(self):
            self.msg = ''

        def write(self, msg):
            self.msg = msg

    std_err_mock = StdErrMock()

    sys.stderr = std_err_mock
    parser = Parser()
    parser.print_usage()
    assert 'thefuck [OPTIONS] [COMMAND [ARGS]...]\n' in std_err_mock.msg



# Generated at 2022-06-12 09:56:52.217487
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-12 09:57:00.609974
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['', '--alias', 'fuck', 'wrong_command']) == \
        argparse.Namespace(alias='fuck', command=['wrong_command'])
    assert Parser().parse(['', 'wrong_command', '--alias', 'fuck']) == \
        argparse.Namespace(alias='fuck', command=['wrong_command'])
    assert Parser().parse(['', '--alias', 'fuck', 'wrong_command', ARGUMENT_PLACEHOLDER, '-l', 'logfile']) == \
        argparse.Namespace(alias='fuck', command=['wrong_command'], shell_logger='logfile')
    assert Parser().parse(['', '--alias', 'fuck', 'wrong_command', ARGUMENT_PLACEHOLDER]) == \
        arg

# Generated at 2022-06-12 09:57:10.291765
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    args = parser.parse(['--repeat'])

    assert args.repeat == True
    assert args.yes == False
    assert args.debug == False
    assert args.help == False
    assert args.command == []

    args = parser.parse(['--yeah'])

    assert args.repeat == False
    assert args.yes == True
    assert args.debug == False
    assert args.help == False
    assert args.command == []

    args = parser.parse([])

    assert args.repeat == False
    assert args.yes == False
    assert args.debug == False
    assert args.help == False
    assert args.command == []

    args = parser.parse(['-h'])

    assert args.repeat == False
    assert args.yes == False
    assert args.debug == False


# Generated at 2022-06-12 09:57:20.213927
# Unit test for method parse of class Parser
def test_Parser_parse():
  # test 1
  p = Parser()
  #parsed_test1 = p.parse(['thefuck','--version'])
  #assert(parsed_test1.version == True)
  
  # test 2
  parsed_test2 = p.parse(['thefuck', ARGUMENT_PLACEHOLDER]) 
  assert(parsed_test2.command == [])
  
  # test 3
  parsed_test3 = p.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'cd', '~/']) 
  assert(parsed_test3.command == ['cd','~/'])
  
  # test 4

# Generated at 2022-06-12 09:57:22.866879
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Unit test for method print_usage of class Parser"""
    # Arrange
    parser = Parser()
    # Act
    parser.print_usage()
    # Assert
    assert True

# Generated at 2022-06-12 09:57:27.505802
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck','ls','--help']) == 'Namespace(command=[\'ls\', \'--help\'], debug=False, enable_experimental_instant_mode=False, help=False, repeat=False, shell_logger=None, version=False, yes=False)'

# Generated at 2022-06-12 09:57:29.242247
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert sys.stderr.read()

# Generated at 2022-06-12 09:57:32.241366
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    help = parser.print_help()

    assert help == parser._parser.print_help(sys.stderr)

# Generated at 2022-06-12 09:57:33.071689
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-12 09:57:34.837578
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Given
    parser = Parser()

    # When
    parser.print_help()

    # Then
    # No exception

