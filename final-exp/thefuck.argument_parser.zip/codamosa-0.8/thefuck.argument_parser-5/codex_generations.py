

# Generated at 2022-06-12 09:49:44.639867
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None

# Generated at 2022-06-12 09:49:47.294538
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Unit test for method print_help of class Parser"""
    from io import StringIO
    output = StringIO()
    Parser().print_help(output)
    assert output.getvalue() != ''



# Generated at 2022-06-12 09:49:50.030807
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_args

    args = get_args([])
    parser = Parser()
    parser.print_help()

    assert isinstance(parser, Parser) == True



# Generated at 2022-06-12 09:49:50.974101
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser

# Generated at 2022-06-12 09:50:00.725983
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # helper function
    def catch_print(func, args):
        out, err = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = StringIO(), StringIO()
        func(*args)
        out = sys.stdout.getvalue()
        err = sys.stderr.getvalue()
        sys.stdout, sys.stderr = out, err
        return out, err
    parser = Parser()
    out, err = catch_print(parser.print_help, [])
    assert err
    assert 'usage: thefuck' in err
    assert '-v' in err
    assert 'show program' in err
    assert '-a' in err
    assert '[custom-alias-name]' in err
    assert '-l' in err

# Generated at 2022-06-12 09:50:08.009635
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parsed = parser.parse(['fuck'])
    assert parsed.command == []
    assert not parsed.debug
    assert not parsed.force_command
    assert not parsed.help
    assert not parsed.repeat
    assert not parsed.shell_logger
    assert not parsed.version
    assert not parsed.yes

    parsed = parser.parse(['fuck', 'ls'])
    assert parsed.command == ['ls']
    assert not parsed.debug
    assert not parsed.force_command
    assert not parsed.help
    assert not parsed.repeat
    assert not parsed.shell_logger
    assert not parsed.version
    assert not parsed.yes

    parsed = parser.parse(['fuck', 'ls', '-l'])
    assert parsed.command == ['ls', '-l']
    assert not parsed.debug

# Generated at 2022-06-12 09:50:10.658300
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    This method is created because we are using a parser class 
    """
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-12 09:50:11.622528
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-12 09:50:17.818795
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from thefuck.manager import TheFuckManager
    from thefuck.runner import run
    from thefuck.shells import Bash
    from thefuck.main import create_parser
    from thefuck.config import Config
    from thefuck.types import Settings
    from types import SimpleNamespace
    mgr = TheFuckManager(Bash(), Config(), SimpleNamespace(), [])
    parser = create_parser(mgr, Settings(load_tuples={}))
    parser.print_usage()
    assert True

# Generated at 2022-06-12 09:50:28.356658
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck']) == parser.parse([
        'thefuck', '--echo', 'Yo']) == parser.parse(
            ['thefuck', '--echo', 'Yo', 'thefuck', '--echo', '--', 'Yo'])
    assert parser.parse(['thefuck', '--echo', 'Yo', ARGUMENT_PLACEHOLDER, '--', 'Yo']) == parser.parse(
            ['thefuck', ARGUMENT_PLACEHOLDER, '--echo', 'Yo', '--', 'Yo']) == parser.parse(
                ['thefuck', ARGUMENT_PLACEHOLDER, '--echo', 'Yo', 'Yo', '--', 'Yo'])

# Generated at 2022-06-12 09:50:41.016802
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Given
    parser = Parser()
    # When
    result = parser.parse(["thefuck", ARGUMENT_PLACEHOLDER, "pytnon", "--help"])
    # Then
    assert result.debug == False
    assert result.enable_experimental_instant_mode == False
    assert result.force_command == None
    assert result.help == True
    assert result.hard == False
    assert result.shell_logger == None
    assert result.repeat == False
    assert result.yes == False
    assert result.alias == get_alias()
    assert result.version == False
    assert result.command == ["pytnon"]



# Generated at 2022-06-12 09:50:50.827635
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .types import Settings
    parser = Parser()
    settings = parser.parse(['--enable-experimental-instant-mode','--force-command','ls','--','cd','test','--','l','--'])

# Generated at 2022-06-12 09:51:01.039213
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from . import __version__
    from .utils import capture_stderr, get_alias
    from .parser import print_usage

    def arguments_example():
        return [
            '--help',
            '--version',
            '--alias',
            '--enable-experimental-instant-mode',
            '--shell-logger',
            '--force-command',
            '--debug',
            '-h',
            '-v',
            '-a',
            '-y',
            '-r',
            'command',
        ]

    class MockArgs:
        def __init__(self, argv):
            self.argv = argv
            self.yes = False
            self.repeat = False
            self.alias = None
            self.debug = False
            self.enable_experimental_

# Generated at 2022-06-12 09:51:03.501877
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._subparsers is None



# Generated at 2022-06-12 09:51:04.859238
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-12 09:51:14.795469
# Unit test for method parse of class Parser
def test_Parser_parse():
    from thefuck.conf import settings

    class Dummy(object):
        pass
    args = Dummy()
    args.alias = settings.alias
    args.help = False
    args.shell_logger = None
    args.debug = False
    args.enable_experimental_instant_mode = False
    args.force_command = False

    parser = Parser()

    args = parser.parse(['thefuck', '--enable-experimental-instant-mode'])
    assert args.command == []
    assert args.alias is settings.alias
    assert args.enable_experimental_instant_mode

    args = parser.parse(
        ['thefuck', '--alias', 'whatever', '--enable-experimental-instant-mode'])
    assert args.alias == 'whatever'
    assert args.enable_exper

# Generated at 2022-06-12 09:51:16.004128
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-12 09:51:16.810787
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-12 09:51:17.697989
# Unit test for constructor of class Parser
def test_Parser():
	
	p = Parser()

# Generated at 2022-06-12 09:51:18.620208
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-12 09:51:25.846813
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Create object
    thefuck_parser = Parser()
    # Call the method
    thefuck_parser.print_usage()



# Generated at 2022-06-12 09:51:27.623821
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help = parser.print_help()
    assert help is not None

# Generated at 2022-06-12 09:51:38.700236
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class Stream:
        def __init__(self):
            self.content = ""

        def write(self, str):
            self.content += str

        def get_content(self):
            return self.content

    out = Stream()
    sys.stderr = out
    parser = Parser()
    parser.print_help()
    content = sys.stderr.get_content()
    from src.parser import __version__
    assert "thefuck {0}".format(__version__) in content
    assert "usage: thefuck [-h] [-v] [-a [custom-alias-name]]" in content
    assert "                     [-l SHELL_LOGGER]" in content
    assert "                     [--enable-experimental-instant-mode]" in content

# Generated at 2022-06-12 09:51:39.934592
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:51:47.179433
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        parser.print_help()
        result = stderr.getvalue()

# Generated at 2022-06-12 09:51:48.965213
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    args = p.parse(sys.argv)
    print(args)

# Generated at 2022-06-12 09:51:51.022972
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    #TODO: Check that the arguments are correctly added
    return parser

# Generated at 2022-06-12 09:51:55.333175
# Unit test for constructor of class Parser
def test_Parser():
	a = Parser()
	if not isinstance(a._parser,ArgumentParser):
		raise ValueError("The type of a._parser is not ArgumentParser")
	if not isinstance(a,Parser):
		raise ValueError("The type of a is not Parser")


# Generated at 2022-06-12 09:52:05.591931
# Unit test for method parse of class Parser
def test_Parser_parse():
  assert Parser().parse(['thefuck','cd','~'])==Namespace(command=['cd','~'], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=False, yes=False, alias=None)
  assert Parser().parse(['thefuck','--version'])==Namespace(command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=True, yes=False, alias=None)

# Generated at 2022-06-12 09:52:06.420880
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser is not None


# Generated at 2022-06-12 09:52:20.850545
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        p = Parser()
        p.print_help()
        output = out.getvalue().strip()
        assert 'usage: thefuck' in output
        assert '-y, --yes, --yeah, --hard' in output
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-12 09:52:22.968244
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)
    assert isinstance(parser, object)

    

# Generated at 2022-06-12 09:52:24.310210
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert(True)

# Generated at 2022-06-12 09:52:35.079445
# Unit test for constructor of class Parser
def test_Parser():
    from .utils import which, get_alias
    from .log import create_logger
    from .utils import wrap_stream
    from .utils import wrap_color_for_stream
    from .settings import get_settings, get_support_directories
    from .mutable_settings import load_settings
    from .settings import save_settings
    from .git import git_support_enabled
    from thefuck.rules.git_support import attempt_with_git
    print("Test Parser()")
    p = Parser()
    print("Test Method parse()")
    print("Testing function parse():")
    parsed_args = p.parse("thefuck")
    print("Testing function parse() over")
    print("Test Method print_usage()")
    print("Testing function print_usage():")
    print("Before calling print_usage()")
   

# Generated at 2022-06-12 09:52:36.784367
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert Parser.__init__(parser) is None
    assert parser._parser is not None



# Generated at 2022-06-12 09:52:39.168002
# Unit test for constructor of class Parser
def test_Parser():
    a = Parser()
    assert a.__class__ == Parser

# Generated at 2022-06-12 09:52:42.977036
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.description == None
    assert parser._parser.usage == None
    assert parser._parser._positionals.title == 'positional arguments'
    assert parser._parser._optionals.title == 'optional arguments'

# Generated at 2022-06-12 09:52:45.684298
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # call the method print_usage
    parser.print_usage()


# Generated at 2022-06-12 09:52:46.936911
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    s = Parser()
    s.print_usage()
    assert True


# Generated at 2022-06-12 09:52:48.307060
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert b'thefuck' in parser.print_usage()

# Generated at 2022-06-12 09:53:12.136398
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    output = p.print_help()
    assert output == sys.stderr

# Generated at 2022-06-12 09:53:14.006267
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        Parser().print_usage()
    except SystemExit:
        pass

# Generated at 2022-06-12 09:53:19.726018
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from .parser import Parser

    saved_stderr = sys.stderr
    sys.stderr = my_stderr = StringIO()
    parser = Parser()
    parser.print_usage()
    output = my_stderr.getvalue()
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'
    '           [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n'
    '           [-y | -r] [-d] [--force-command FORCE_COMMAND]\n'
    '           [command [command ...]]\n'
    sys.stderr = saved_stderr

# Generated at 2022-06-12 09:53:21.233210
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser();
    assert(parser != None)


# Generated at 2022-06-12 09:53:32.137202
# Unit test for method parse of class Parser
def test_Parser_parse():
    import sys

    # Case 1
    argv = ['x', 'h', 'e', 'l', 'l', 'o']
    parser = Parser()
    args = parser.parse(argv)
    assert args.command == ['hell', 'o']
    assert args.debug == False

    # Case 2
    argv = ['x', '--', 'h', 'e', 'l', 'l', 'o']
    parser = Parser()
    args = parser.parse(argv)
    assert args.command == ['h', 'e', 'l', 'l', 'o']
    assert args.debug == False

    # Case 3
    argv = ['x', '--force-command', 'h', 'e', 'l', 'l', 'o']
    parser = Parser()

# Generated at 2022-06-12 09:53:38.351268
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from contextlib import redirect_stdout
    from io import StringIO
    with redirect_stdout(StringIO()) as stdout:
        Parser().print_usage()
        assert stdout.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [command [command ...]]\n'


# Generated at 2022-06-12 09:53:44.670190
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.description is None
    assert parser._parser.usage is None
    assert parser._parser.formatter_class.__name__ == 'HelpFormatter'
    assert parser.print_usage()
    assert parser.print_help()

# Generated at 2022-06-12 09:53:45.763629
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:53:48.771562
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import _io

    stream = _io.StringIO()

    parser = Parser()
    parser.print_help()
    parser.print_help(stream)
    parser.print_help('help')

    assert len(stream.getvalue()) > 0

# Generated at 2022-06-12 09:53:49.962966
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:54:37.952706
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.stderr.write = MagicMock()
    parser = Parser()
    parser.print_usage()
    sys.stderr.write.assert_called_once_with('usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'
                                             '               [-l SHELL-LOGGER]\n'
                                             '               [--enable-experimental-instant-mode]\n'
                                             '               [-y | -r] [-d] [--force-command FORCE-COMMAND]\n'
                                             '               [command [command ...]]\n')


# Generated at 2022-06-12 09:54:38.789783
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-12 09:54:39.644327
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-12 09:54:51.619089
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['fuck', '-v']) == Namespace(version=True, command=[])
    assert Parser().parse(['fuck', '-v', 'ls']) == Namespace(version=True, command=['ls'])
    assert Parser().parse(['fuck', '-v', 'ls', '-a']) == Namespace(version=True, command=['ls', '-a'])
    assert Parser().parse(['fuck', '-v', '-a', 'ls', '-la']) == Namespace(version=True, alias='fuck', command=['ls', '-la'])
    assert Parser().parse(['fuck', 'ls', ARGUMENT_PLACEHOLDER, '-v']) == Namespace(version=True, command=['ls'])

# Generated at 2022-06-12 09:54:58.173176
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    class StdErr(object):
        def __init__(self):
            self.data = []

        def write(self, value):
            self.data.append(value)

    err = StdErr()
    sys.stderr = err
    parser.print_help()

# Generated at 2022-06-12 09:54:59.904776
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    print(p.print_usage())

test_Parser_print_usage()

# Generated at 2022-06-12 09:55:03.084405
# Unit test for method parse of class Parser
def test_Parser_parse():
    _argv = ['fuck', 'fuck', 'fuck']
    parser = Parser()
    parser.parse(_argv)
    assert parser._parser.command == ['fuck']


# Generated at 2022-06-12 09:55:12.298153
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    # 1
    argv = ['thefuck', 'vim', '--version']
    parsed_argv = parser._prepare_arguments(argv)
    assert ['--'] + argv[1:] == parsed_argv
    assert ['vim', '--version'] == parser.parse(argv).command

    # 2
    argv = ['thefuck', 'vim', '--']
    parsed_argv = parser._prepare_arguments(argv)
    assert ['--'] + argv[1:] == parsed_argv
    assert ['vim', '--'] == parser.parse(argv).command

    # 3
    argv = ['thefuck', 'vim', 'somefile.py']
    parsed_argv = parser._prepare_arguments(argv)

# Generated at 2022-06-12 09:55:23.518491
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO
    from . import __version__
    import sys
    sys.stderr = output = StringIO()
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:55:24.666070
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-12 09:57:01.562956
# Unit test for constructor of class Parser
def test_Parser():
	parser = Parser()
	assert parser._parser != None

# Generated at 2022-06-12 09:57:11.045300
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

# Generated at 2022-06-12 09:57:15.948265
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'cd', '~', ARGUMENT_PLACEHOLDER, 'ls'])
    assert args.command == ['cd', '~']
    assert args.debug is False
    assert args.force_command == ['ls']



# Generated at 2022-06-12 09:57:18.354193
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    try:
        parser.print_usage()
    except Exception:
        raise AssertionError('Exception was raised in print_usage()')

# Generated at 2022-06-12 09:57:23.054845
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_parser = Parser()
    if (sys.version_info.major > 2):
        assert(test_parser._parser.format_usage() ==
               "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n"
               "               [-l SHELL_LOGGER] [--enable-experimental-instant-mode]\n"
               "               [-y | -r] [-d] [--force-command FORCE_COMMAND]\n"
               "               [command [command ...]]\n")

# Generated at 2022-06-12 09:57:24.632367
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert not parser._parser == None


# Generated at 2022-06-12 09:57:25.860324
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    assert Parser().print_help() is None


# Generated at 2022-06-12 09:57:36.307194
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck']) == parser._parser.parse_args([])
    assert parser.parse(['fuck', 'echo', 'fuck']) == parser._parser.parse_args(['--', 'echo', 'fuck'])
    assert parser.parse(['fuck', 'eval', 'echo', 'fuck']) == parser._parser.parse_args(['--', 'eval', 'echo', 'fuck'])
    assert parser.parse(['fuck', 'fuck', 'fuck', ARGUMENT_PLACEHOLDER, 'echo', 'fuck']) == parser._parser.parse_args(['echo', 'fuck'])
    assert parser.parse(['fuck', 'fuck', 'fuck', ARGUMENT_PLACEHOLDER, 'eval', 'echo', 'fuck']) == parser._parser.parse_

# Generated at 2022-06-12 09:57:37.773011
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert(True)



# Generated at 2022-06-12 09:57:44.731565
# Unit test for method parse of class Parser
def test_Parser_parse():
    test_args = ['-l', '--enable-experimental-instant-mode', '-y', '-d', '--',
                'command', 'arg1', 'arg2'] + [ARGUMENT_PLACEHOLDER] +\
                ['the', 'fuck', 'command']

    parser = Parser()
    args = parser.parse(test_args)

    assert(args.shell_logger == '--enable-experimental-instant-mode')
    assert(args.force_command == 'the fuck command')
    assert(args.command == ['command', 'arg1', 'arg2'])
    assert(args.debug is True)
    assert(args.yes is True)
    assert(args.version is False)
    assert(args.repeat is False)
    assert(args.alias is None)
