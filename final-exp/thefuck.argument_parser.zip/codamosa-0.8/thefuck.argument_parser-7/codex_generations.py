

# Generated at 2022-06-12 09:50:01.257653
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Argument with placeholder
    parser = Parser()
    argument_list = [
        'fuck',
        '-v',
        '-a',
        'alias',
        '-l',
        'shell-logger',
        '--enable-experimental-instant-mode',
        '-h',
        '--force-command',
        'force-command',
        '--',
        'test-placeholder',
        'test',
        'test',
        'test',
        'test',
        'test',
        'test',
        'test',
        'test',
        'test',
        'test',
        'test',
        ARGUMENT_PLACEHOLDER,
        'test1',
        'test2',
        'test3'
    ]
    parsed_argument_list

# Generated at 2022-06-12 09:50:05.764987
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    class stderr:
        def __call__(self, *args, **kwargs):
            pass

    stderr.write = lambda x: None

    setattr(sys, 'stderr', stderr)

    parser.print_help()
    parser.print_usage()


if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-12 09:50:07.282256
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
	parser = Parser()
	parser.print_usage()


# Generated at 2022-06-12 09:50:08.675498
# Unit test for constructor of class Parser
def test_Parser():
    arg_parser = Parser()
    assert arg_parser


# Generated at 2022-06-12 09:50:14.427578
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse([
        'thefuck', 'pytnon', '--debug', 'command', ARGUMENT_PLACEHOLDER,
        '--alias=fuck'])
    assert "pytnon" == args.command[0]
    assert args.alias == 'fuck'
    assert args.debug
    assert "command" == args.command[1]



# Generated at 2022-06-12 09:50:19.664650
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    cmd = "ls -a"
    cmd_split = cmd.split()
    option = "--yes"
    option_no = "--no"
    res = parser.parse(["thefuck", "--", option] + cmd_split)
    assert res.command == cmd and res.yes

    res = parser.parse(["thefuck", option_no] + cmd_split)
    assert res.command == cmd and not res.yes

# Generated at 2022-06-12 09:50:22.244317
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        raise Exception("test_Parser_print_help() failed")



# Generated at 2022-06-12 09:50:23.725182
# Unit test for constructor of class Parser
def test_Parser():
    testCase = Parser()
    testCase._parser
    assert testCase

# Generated at 2022-06-12 09:50:33.504631
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    output = StringIO()
    p = Parser()
    p._parser = ArgumentParser(prog='thefuck')
    p.print_usage(output=output)

# Generated at 2022-06-12 09:50:41.977132
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['-v', '--debug'])
    assert args.version == True
    assert args.debug == True
    assert not args.command

    args = parser.parse(['thefuck'])
    assert args.command == ['thefuck']

    args = parser.parse(['thefuck', '-v', '--debug'])
    assert args.command == ['thefuck', '-v', '--debug']

    args = parser.parse(['thefuck', '-v', '--debug', ARGUMENT_PLACEHOLDER, '-l', '--shell-logger'])
    assert args.command == ['thefuck', '-v', '--debug']
    assert args.shell_logger == '-l'

# Generated at 2022-06-12 09:50:53.065671
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert sys.stderr.getvalue().endswith('\n\n')

# Generated at 2022-06-12 09:50:54.334966
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:51:04.789677
# Unit test for constructor of class Parser
def test_Parser():
    # Create a arg parser
    arg_parser = Parser()
    # Create a arguments
    arguments = arg_parser._prepare_arguments(['--version'])
    # Use parse_args method in class ArgumentParser to parse the arguments
    arguments = arg_parser._parser.parse_args(arguments)
    # Check the argument 'version' if it is equal True
    assert arguments.version == True
    # Create another arguments
    arguments = arg_parser._prepare_arguments(['--shell-logger', 'shell.log'])
    # Use parse_args method in class ArgumentParser to parse the arguments 
    arguments = arg_parser._parser.parse_args(arguments)
    # Check the argument 'shell-logger' if it is equal 'shell.log'
    assert arguments.shell_logger == 'shell.log'


# Generated at 2022-06-12 09:51:08.023204
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert (p)
    # TODO: Remove this exception and test the conditions
    # raise Exception("Need to write unit tests for Parser")


# Generated at 2022-06-12 09:51:10.766306
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.description is None
    assert parser._parser.usage is None
    assert parser._parser.add_help

# Generated at 2022-06-12 09:51:12.930817
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-12 09:51:13.767969
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-12 09:51:22.811367
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()

    assert p.parse([]) is not None

    assert p.parse(['thefuck']) is not None

    assert p.parse(['thefuck', 'ls']) is not None

    assert p.parse(['thefuck', '-a']) is not None

    assert p.parse(['thefuck', ARGUMENT_PLACEHOLDER, '--help']) is not None

    assert p.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '--help']) is not None

    assert p.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-a']) is not None

    assert p.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-d']) is not None

    assert p

# Generated at 2022-06-12 09:51:24.255463
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:51:35.014629
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # Test for arguments, that starts with `-`
    assert parser.parse(['thefuck', 'git', '--no-pager', 'diff', '-p']) == parser._parser.parse_args(['--', 'git', '--no-pager', 'diff', '-p'])
    # Test for alias
    assert parser.parse(['thefuck']) == parser._parser.parse_args(['--'])
    # Test for case, where we have placeholder
    assert parser.parse(['thefuck', 'git', 'diff', 'fuck', 'git', 'log']) == parser._parser.parse_args(['git', 'log'])
    # Test for case, where we don't have placeholder

# Generated at 2022-06-12 09:51:51.212150
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-12 09:52:01.455847
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['-v']) == parser.parse(['-v', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['-v']).v == parser.parse(['-v', ARGUMENT_PLACEHOLDER]).v
    assert parser.parse(['-v']) == parser.parse(['--version', ARGUMENT_PLACEHOLDER])
    assert parser.parse(['-v']).v == parser.parse(['--version', ARGUMENT_PLACEHOLDER]).v
    assert parser.parse(['-a']) == parser.parse(['-a', ARGUMENT_PLACEHOLDER])

# Generated at 2022-06-12 09:52:09.879982
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Create a string buffer
    stream = StringIO.StringIO()

    # Save the default stderr
    defaultStdErr = sys.stderr

    # Set the string buffer as the new stderr
    sys.stderr = stream

    # Run the method to test
    Parser().print_help()

    # Set back the default stderr
    sys.stderr = defaultStdErr

    # Verify result
    if stream.getvalue().find('[-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]') != 0:
        print('Error Parser_print_help 1')

if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-12 09:52:10.812816
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:52:12.280596
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:52:16.862711
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    with CaptureOutput() as capturer:
        Parser().print_usage()
    
    assert "usage: thefuck [-h] [--debug] [-y | -r] [-v]" \
           in capturer.stdout



# Generated at 2022-06-12 09:52:20.243471
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # It is said in the docs of ArgumentParser that if add_help=False,
    # print_help() won't work, so we need to add help in this test case
    parser = Parser()
    parser._parser.add_argument(
        '-h', '--help',
        action='store_true',
        help='show this help message and exit')
    parser.print_help()

# Generated at 2022-06-12 09:52:30.895519
# Unit test for method parse of class Parser
def test_Parser_parse():
    pars = Parser()
    argv = pars.parse(['--alias', 'fuck', 'fuck'])
    assert argv.alias == 'fuck'
    assert argv.command == ['fuck']
    argv = pars.parse(['fuck'])
    assert argv.command == ['fuck']
    argv = pars.parse(['--alias', 'fuck', '--debug', 'fuck'])
    assert argv.debug == True
    assert argv.alias == 'fuck'
    assert argv.command == ['fuck']
    argv = pars.parse(['--debug'])
    assert argv.debug == True
    assert argv.alias == get_alias()
    assert argv.command == []
    argv = pars.parse(['--debug', '--alias', 'fuck', 'fuck'])
    assert arg

# Generated at 2022-06-12 09:52:36.451481
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import ALIASES, ALIASES_TO_SHELLS
    from .utils import get_alias
    from io import StringIO
    import sys

    argv = StringIO()
    sys.stdout = argv
    Parser().print_usage()
    sys.stdout = sys.__stdout__
    print(argv.getvalue())
    assert "usage: thefuck [options] [command [args ...]]" in argv.getvalue()

# Generated at 2022-06-12 09:52:39.105496
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Given
    parser = Parser()

    # When
    parser.print_usage()



# Generated at 2022-06-12 09:53:09.211863
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

# Generated at 2022-06-12 09:53:17.939691
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '--debug', 'ls', '-la']) == \
        parser._parser.parse_args(['--debug', 'ls', '-la'])

    assert parser.parse(['thefuck', '--help']) == \
        parser._parser.parse_args(['--help'])

    assert parser.parse(['thefuck', 'ls', '-la', ARGUMENT_PLACEHOLDER]) == \
        parser._parser.parse_args(['ls', '-la'])

    assert parser.parse(['thefuck', 'ls', '-la', '-r']) == \
        parser._parser.parse_args(['ls', '-la', '-r'])


# Generated at 2022-06-12 09:53:20.410302
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # It should show help message
    parser = Parser()
    try:
        parser.print_help()
    except SystemExit:
        assert True
    else:
        assert False

# Generated at 2022-06-12 09:53:24.899252
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Parser's print_help method should print help to stdout.
    """
    import sys
    from cStringIO import StringIO
    out = StringIO()
    sys.stderr = out
    Parser().print_help()
    assert out.getvalue().startswith('usage')


# Generated at 2022-06-12 09:53:27.702074
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    parser = Parser()
    parser.print_usage()
    assert sys.stdout.getvalue().startswith('usage: thefuck [-h]')


# Generated at 2022-06-12 09:53:28.875962
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-12 09:53:30.235109
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None

# Generated at 2022-06-12 09:53:36.850201
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Arrange
    p = Parser()

    # Act
    p.print_usage()

    # Assert
    expected = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL-LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE-COMMAND] [--] [command [command ...]]\n'
    assert sys.stderr.getvalue() == expected



# Generated at 2022-06-12 09:53:47.497037
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(
        ['-a', '--force-command', 'ls', ARGUMENT_PLACEHOLDER,
         'command', '-l', '--debug'])
    parser.parse([ARGUMENT_PLACEHOLDER, 'command', '-l', '--debug'])
    parser.parse(['--force-command', 'ls'])
    parser.parse(['--force-command', 'ls', ARGUMENT_PLACEHOLDER,
                  'command', '-l', '--debug'])
    parser.parse(['command', '-l', '--debug'])


if __name__ == '__main__':
    test_Parser_parse()

# Generated at 2022-06-12 09:53:48.433703
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p == p

# Generated at 2022-06-12 09:54:36.243061
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import SUPPORTED_SHELLS
    parser = Parser()
    usage = parser.print_usage()
    expected = 'Usage: thefuck [-h] [-v] [-a [{}]] [--shell-logger SHELL_LOGGER] [--enable-experimental-instant-mode] [--force-command FORCE_COMMAND] [-y | -r] [--debug] [command [command ...]]'.format(' | '.join(SUPPORTED_SHELLS))
    assert usage == expected

# Generated at 2022-06-12 09:54:36.784938
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    pass

# Generated at 2022-06-12 09:54:37.990387
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser


# Generated at 2022-06-12 09:54:49.734207
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # Test for _parser.prog
    assert parser._parser.prog == 'thefuck'
    # Test for _parser.add_help
    assert parser._parser.add_help == False
    # Test for argparse.ArgumentParser.format_help
    help_msg = parser._parser.format_help()
    assert 'show program\'s version number and exit' in help_msg
    # Test for argparse.ArgumentParser.format_usage
    usage_msg = parser._parser.format_usage()
    assert 'thefuck' in usage_msg
    assert '\n  -v, --version' in usage_msg
    assert '\n  -a, --alias [custom-alias-name]' in usage_msg

# Generated at 2022-06-12 09:54:57.063032
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    with mock.patch('sys.stderr') as stderr:
        parser.print_usage()
        # stderr.write.assert_called_with('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y|-r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n')
        stderr.write.assert_called_with('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]\n')

# Generated at 2022-06-12 09:55:00.045880
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # Initialize the object
    parser = Parser()
    # Test print_usage
    try:
        parser.print_usage()
        return True
    except:
        return False


# Generated at 2022-06-12 09:55:02.070779
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([]) == parser._parser.parse_args([])



# Generated at 2022-06-12 09:55:03.853650
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-12 09:55:11.050962
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import capture_output
    with capture_output() as (out, err):
        Parser().print_help()
    assert 'usage: thefuck' in out.getvalue()
    assert '-v' in out.getvalue()
    assert '-a' in out.getvalue()
    assert '-l' in out.getvalue()
    assert '-h' in out.getvalue()
    assert '-d' in out.getvalue()
    assert '-y' in out.getvalue()
    assert '-r' in out.getvalue()

# Generated at 2022-06-12 09:55:22.734600
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import wrap_streams
    from StringIO import StringIO
    with wrap_streams():
        Parser().print_help()

# Generated at 2022-06-12 09:56:18.452139
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['thefuck', 'sudo', 'apt-get', 'install', 'vim', ARGUMENT_PLACEHOLDER, '-y', '--force-command', 'echo'])
    assert result.command == ['sudo', 'apt-get', 'install', 'vim']
    assert result.yes
    assert result.force_command == 'echo'

    result = parser.parse(['thefuck', 'vim', ARGUMENT_PLACEHOLDER, '--force-command', 'echo'])
    assert result.command == ['vim']
    assert not result.yes
    assert result.force_command == 'echo'

    result = parser.parse(['thefuck', 'echo', 'foobar'])
    assert result.command == ['echo', 'foobar']

# Generated at 2022-06-12 09:56:25.607949
# Unit test for method parse of class Parser
def test_Parser_parse():
    """Test function for method parse Parser class

    """
    import os
    cmd = "dpkg --configure -a"
    argv=['thefuck', cmd]
    # check if argv was returned by method parse of class Parser
    expected=argv[1:]
    parser = Parser()
    # check if exit status of the method parse is 1
    assert parser.parse(argv) == parser._parser.parse_args(expected)
    os.system('dpkg --configure -a')
    assert os.system('dpkg --configure -a') == 0, "Function test_Parser_parse failed"
    print("Function test_Parser_parse passed")
    argv=['thefuck', cmd]
    # check if argv was returned by method parse of class Parser
    expected=argv[1:]
    parser

# Generated at 2022-06-12 09:56:34.128083
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import _
    parser = Parser()
    msg = _("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger]\n"
            "                [--enable-experimental-instant-mode] [-d]\n"
            "                [--force-command FORCE-COMMAND]")
    if sys.version_info.major == 2:
        assert parser._parser.format_usage().split('thefuck') == [msg], \
            msg + ' is incorrect usage message'
    else:
        assert parser._parser.format_usage().replace('thefuck', '') == _(msg), \
            msg + ' is incorrect usage message'

# Generated at 2022-06-12 09:56:35.060531
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-12 09:56:39.327531
# Unit test for constructor of class Parser
def test_Parser():
    #Test for ArgumentParser
    test_arg_parser = ArgumentParser(prog='test', add_help=False)
    assert_arg_parser = Parser()._parser
    assert (test_arg_parser.prog == assert_arg_parser.prog) and (test_arg_parser.add_help == assert_arg_parser.add_help)


# Generated at 2022-06-12 09:56:42.222846
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    s = StringIO.StringIO()
    sys.stderr = s
    p.print_usage()
    sys.stderr = sys.__stderr__
    assert 'usage: thefuck' in s.getvalue()



# Generated at 2022-06-12 09:56:42.970036
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser


# Generated at 2022-06-12 09:56:54.494434
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    text_output = get_help_output(Parser().print_help)
    assert text_output.startswith('usage: thefuck [')
    assert '-v' in text_output
    assert '--version' in text_output
    assert '-a' in text_output
    assert '--alias' in text_output
    assert '-l' in text_output
    assert '--shell-logger' in text_output
    assert '--enable-experimental-instant-mode' in text_output
    assert '-h' in text_output
    assert '--help' in text_output
    assert '-d' in text_output
    assert '--debug' in text_output
    assert '--force-command' in text_output
    assert 'command' in text_output
    assert '-y' in text_

# Generated at 2022-06-12 09:56:55.663178
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
  parser = Parser()
  parser.print_usage()



# Generated at 2022-06-12 09:56:59.186895
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class FakeArgParser(object):
        def __init__(self, *args, **kwargs):
            pass

        def print_usage(self, *args, **kwargs):
            pass

        def print_help(self, *args, **kwargs):
            pass

    assert Parser._parser == FakeArgParser

# Generated at 2022-06-12 09:58:42.171976
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['script', '-d', '--command', 'fuck', '--', 'ls', '-l']
    expected = ['ls', '-l']
    parser = Parser()
    parsed = parser.parse(argv)
    actual = parsed.command

    assert(actual == expected)

# Generated at 2022-06-12 09:58:48.097775
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    std_err = []
    for line in sys.stderr:
        std_err.append(line)
    parser.print_help()
    std_err_new = []
    for line in sys.stderr:
        std_err_new.append(line)
    assert std_err != std_err_new


# Generated at 2022-06-12 09:58:50.120797
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except IOError:
        # Redirection of output is handled in main.py
        pass

# Generated at 2022-06-12 09:58:53.191630
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert hasattr(parser, '_parser')
    assert isinstance(parser._parser, ArgumentParser)
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False


# Generated at 2022-06-12 09:58:53.975979
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:58:57.532700
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['--version'])
    parser.parse(['--alias'])
    parser.parse(['-d'])
    parser.parse(['--force-command', 'ls'])
    parser.parse(['ls'])
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-12 09:58:59.875753
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    out=StringIO()
    parser = Parser()
    parser.print_usage(file=out)
    assert 'usage: thefuck' in out.getvalue()


# Generated at 2022-06-12 09:59:05.086586
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser._add_arguments())
    print(parser._add_conflicting_arguments())
    arguments = parser._prepare_arguments(sys.argv)
    print(parser._parser.parse_args(arguments))
    print(parser.print_usage())
    print(parser.print_help())


if __name__ == '__main__':
    test_Parser()


__all__ = ('Parser',)

# Generated at 2022-06-12 09:59:07.297381
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'

# Generated at 2022-06-12 09:59:08.103223
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()
