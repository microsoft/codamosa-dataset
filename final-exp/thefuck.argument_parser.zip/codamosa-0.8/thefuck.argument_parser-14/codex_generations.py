

# Generated at 2022-06-12 09:49:54.509026
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # test case: no argument
    assert parser.parse([]).command == []
    # test case: normal case
    assert parser.parse(['--', 'ls', '-l']).command == \
        ['ls', '-l']
    # test case: have placeholder
    assert parser.parse(['--', 'ls', '-l', ARGUMENT_PLACEHOLDER, '-e']).command == \
        ['ls', '-l']
    # test case: have placeholder, but it is the last one
    assert parser.parse(['ls', ARGUMENT_PLACEHOLDER, '-e']).command == \
        ['ls']
    # test case: have placeholder, and it is the first one

# Generated at 2022-06-12 09:49:55.822078
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:49:57.593003
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()
    # verify that this doesn't error out

# Generated at 2022-06-12 09:50:01.452891
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import mock
    from .parser import Parser
    parser = Parser()
    parser._parser = mock.Mock()
    parser.print_help()
    parser._parser.print_help.assert_called_with(sys.stderr)


# Generated at 2022-06-12 09:50:08.368531
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .shell import Shell
    parser = Parser()
    # Just a lil hack to make the test more obvious
    parser._parser.print_help = print

    # with --force-command
    parser.parse([
        'thefuck.py',
        '--yes',
        '--force-command',
        'echo',
        'foo'])
    parser.parse([
        'thefuck.py',
        '--force-command',
        'echo',
        'foo'])
    parser.parse([
        'thefuck.py',
        'tset',
        '--force-command',
        'echo',
        'foo'])
    # with alias
    if 'fuck' in get_alias():
        parser.parse([
            'thefuck.py',
            '--alias'])

# Generated at 2022-06-12 09:50:09.826855
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser(), "constructor doesn't work"


# Generated at 2022-06-12 09:50:16.295153
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    argv = ['thefuck']
    output = Parser().parse(argv)
    assert output.command == []
    assert output.alias is None
    assert output.shell_logger is None
    assert output.yes is False
    assert output.repeat is False
    assert output.debug is False
    assert output.force_command is None
    assert output.version is False
    assert output.help is False
    assert output.enable_experimental_instant_mode is False


# Generated at 2022-06-12 09:50:21.171701
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import StringIO
    stdout = sys.stderr
    try:
        sys.stderr = StringIO.StringIO()
        parser = Parser()
        parser.print_help()
    finally:
        stdout = sys.stderr

    assert 'usage:' in sys.stderr.getvalue()
    assert 'optional arguments:' in sys.stderr.getvalue()


# Generated at 2022-06-12 09:50:31.725058
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    # arguments before placeholder
    sys.argv = ['fuck', '-l', 'shell.log', ARGUMENT_PLACEHOLDER, 'pwd']
    assert p.parse(sys.argv).command == ['pwd']

    sys.argv = ['fuck', '-l', 'shell.log', ARGUMENT_PLACEHOLDER, 'ls', '-a']
    assert p.parse(sys.argv).command == ['ls', '-a']

    # we expect correct code
    sys.argv = ['fuck', '-l', 'shell.log', ARGUMENT_PLACEHOLDER,
                'ls', '-a', '||', 'echo', '"$?"']

# Generated at 2022-06-12 09:50:38.677487
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.stderr = open("test_output.txt","w")
    sys.argv = ['thefuck', 'command', '-h']
    Parser().print_usage()
    sys.stderr.close()

    sys.stderr = open("answer.txt","r")
    answer = sys.stderr.readline().strip()

    sys.stderr = open("test_output.txt","r")
    test_output = sys.stderr.readline().strip()

    assert answer == test_output


# Generated at 2022-06-12 09:50:41.832205
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:50:42.698962
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:50:43.962630
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert isinstance(p, Parser)

# Generated at 2022-06-12 09:50:47.903217
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import io
    import sys

    s = io.StringIO()
    sys.stderr = s

    parser.print_usage()

    output = s.getvalue()
    assert "usage: thefuck" in output


# Generated at 2022-06-12 09:50:50.914885
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as f:
        parser = Parser()
        parser.print_usage(file=f)
        assert f.tell() > 0



# Generated at 2022-06-12 09:51:00.135206
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['', '-d', '--force-command', 'git', 'commit', '-m', 'fix'])
    assert args.debug is True
    assert args.force_command == 'git'
    args = parser.parse(['', '--force-command', 'git', '--', 'commit', '-m', 'fix'])
    assert args.force_command == 'git'
    assert args.command == ['commit', '-m', 'fix']
    args = parser.parse(['', '--force-command', 'git', 'commit', '-m', 'fix'])
    assert args.force_command == 'git'
    assert args.command == ['commit', '-m', 'fix']

# Generated at 2022-06-12 09:51:09.451279
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['fuck', 'date'])
    assert args.command == ['date']
    assert args.repeat is None
    assert args.alias is None
    assert args.yes is None
    assert args.debug is None

    alias = 'fuck'
    args = parser.parse([alias, 'date', '--repeat'])
    assert args.command == ['date']
    assert args.repeat is True
    assert args.alias is None
    assert args.yes is None
    assert args.debug is None

    args = parser.parse([alias, 'date', ARGUMENT_PLACEHOLDER,
                         '--repeat', ARGUMENT_PLACEHOLDER, '-v'])
    assert args.command == ['-v']
    assert args.repeat is True
    assert args

# Generated at 2022-06-12 09:51:12.642211
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    parsed_arguments = p.parse(sys.argv)
    assert parsed_arguments.version
    assert type(parsed_arguments) == argparse.Namespace
    assert parsed_arguments.debug == None

# Generated at 2022-06-12 09:51:19.074765
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck', '-v'])
    assert args.version == True
    assert args.alias == None
    parser = Parser()
    args = parser.parse(['thefuck', '-a'])
    assert args.alias == get_alias()
    parser2 = Parser()
    args2 = parser2.parse(['thefuck', '--alias', 'my-name'])
    assert args2.alias == 'my-name'
    parser = Parser()
    args = parser.parse(['thefuck', '-l'])
    assert args.shell_logger == None
    parser = Parser()
    args = parser.parse(['thefuck', '--shell-logger', 'foo'])
    assert args.shell_logger == 'foo'
   

# Generated at 2022-06-12 09:51:29.059739
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER, '-la']) == \
    Namespace(command=[], debug=False, enable_experimental_instant_mode=False, help=False,
              repeat=False, shell_logger=None, yes=False, alias=None)
    assert parser.parse(['thefuck', '-v']) == \
    Namespace(command=[], debug=False, enable_experimental_instant_mode=False, help=False,
              repeat=False, shell_logger=None, yes=False, version=True, alias=None)

# Generated at 2022-06-12 09:51:35.592117
# Unit test for constructor of class Parser
def test_Parser():
    # Arrange
    _parser = Parser()

    # Assert
    assert isinstance(_parser._parser, ArgumentParser)


# Generated at 2022-06-12 09:51:39.888821
# Unit test for constructor of class Parser
def test_Parser():
    stderr = sys.stderr
    sys.stderr = sys.stdout
    p = Parser()
    assert p != None
    assert p.__class__ == Parser
    p.print_usage()
    sys.stderr = stderr
    pass


# Generated at 2022-06-12 09:51:42.747783
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # setup
    parser = Parser()
    # test
    parser.print_usage()
    with pytest.raises(SystemExit):
        parser.print_help()


# Generated at 2022-06-12 09:51:53.046416
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    from StringIO import StringIO
    out = StringIO()
    sys.stderr = out
    parser.print_help()

# Generated at 2022-06-12 09:51:54.523701
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:51:55.943885
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert (Parser().print_usage() == None)


# Generated at 2022-06-12 09:51:58.257784
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    result = parser.print_help
    assert type(result) == type(None)



# Generated at 2022-06-12 09:52:02.819279
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    actual = parser.parse(['sudo', 'rm', '-rf', '/', ARGUMENT_PLACEHOLDER, '--', '-v'])
    expected = argparse.Namespace()
    expected.command = ['sudo', 'rm', '-rf', '/']
    expected.debug = False
    expected.help = False
    expected.repeat = False
    expected.shell_logger = None
    expected.version = False
    expected.yes = False
    expected.force_command = None
    expected.alias = None
    expected.enable_experimental_instant_mode = False
    assert(expected.command == actual.command)
    assert(expected.debug == actual.debug)
    assert(expected.help == actual.help)
    assert(expected.repeat == actual.repeat)
   

# Generated at 2022-06-12 09:52:04.303909
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    args = Parser()
    args.print_usage()



# Generated at 2022-06-12 09:52:11.646222
# Unit test for method parse of class Parser
def test_Parser_parse():
    import unittest
    class ParserTest(unittest.TestCase):
        def test_Parser_parse(self):
            import sys
            import os
            parser = Parser()
            args = parser.parse(['eggs'])
            sys.argv = ['eggs']
            args = parser.parse(sys.argv)
            self.assertEqual(args.command[0], 'eggs')
            args = parser.parse(['ls', ARGUMENT_PLACEHOLDER, '-a'])
            self.assertEqual(args.command[0], 'ls')
            self.assertEqual(args.command[1], '-a')
            args = parser.parse(['ls', '-a', ARGUMENT_PLACEHOLDER, '-l'])
            self.assertE

# Generated at 2022-06-12 09:52:32.430706
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['/home/user/.virtualenvs/thefuck3-rOwml1/bin/fuck', '-v'])
    assert args == parser._parser.parse_args(['-v'])
    args = parser.parse(['/home/user/.virtualenvs/thefuck3-rOwml1/bin/fuck', 'wget', '--version'])
    assert args == parser._parser.parse_args(['--', 'wget', '--version'])
    args = parser.parse(['/home/user/.virtualenvs/thefuck3-rOwml1/bin/fuck', 'wget', '--version', '--help'])

# Generated at 2022-06-12 09:52:33.548302
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:52:43.045200
# Unit test for method print_usage of class Parser

# Generated at 2022-06-12 09:52:45.683952
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    assert parser.parse([])


# Generated at 2022-06-12 09:52:55.488274
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    f = StringIO()
    sys.stderr = f
    Parser().print_usage()
    sys.stderr = sys.__stderr__
    output = f.getvalue()
    assert 'usage: thefuck' in output
    assert '[custom-alias-name] prints alias for current shell' in output
    assert '--enable-experimental-instant-mode' in output
    assert '--help' in output
    assert '[-h] [-v] [-a] [-l] [--enable-experimental-instant-mode] [--force-command]' in output
    assert '[-y] [-r] [-d] [--] [command [command ...]]' in output


# Generated at 2022-06-12 09:52:59.138369
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['thefuck', 'ls', '-a', ARGUMENT_PLACEHOLDER, '-l']
    parser = Parser()
    assert parser.parse(args) == parser._parser.parse_args(['-l', '--', 'ls', '-a'])



# Generated at 2022-06-12 09:52:59.890080
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:53:01.050019
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser


# Generated at 2022-06-12 09:53:10.652931
# Unit test for constructor of class Parser
def test_Parser():
    arg1 = 'arg1'
    arg2 = 'arg2'
    arg3 = 'arg3'
    argv = [arg1, arg2, arg3]
    parser = Parser()
    parser.print_usage()
    parser.print_help()
    args = parser.parse(argv)
    assert(args.command[0] == arg1)
    assert(args.command[1] == arg2)
    assert(args.command[2] == arg3)
    assert(args.debug == False)
    assert(args.force_command is None)
    assert(args.repeat == False)
    assert(args.yes == False)

# Generated at 2022-06-12 09:53:13.921558
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import mock, patch
    from .const import USAGE_MESSAGE

    with patch('argparse.ArgumentParser.print_usage', mock()):
        Parser().print_usage()
        assert sys.stderr.getvalue() == USAGE_MESSAGE


# Generated at 2022-06-12 09:53:44.010173
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Test case for method print_help of class Parser"""
    import sys
    import io
    from contextlib import redirect_stdout
    from .parser import Parser

    saved_sys_stdout = sys.stdout
    try:
        out = io.StringIO()
        with redirect_stdout(out):
            parser = Parser()
            parser.print_help()
        output = out.getvalue().strip()
    finally:
        sys.stdout = saved_sys_stdout
    assert "usage: thefuck [-h] [-v] [-a [custom-alias-name]]" in output
    assert "-r, --repeat" in output

# Generated at 2022-06-12 09:53:48.346846
# Unit test for method parse of class Parser
def test_Parser_parse():
    assert Parser().parse(['thefuck', 'echo']) == \
           Parser().parse(['thefuck', 'echo'])
    assert Parser().parse(['thefuck', 'echo', ARGUMENT_PLACEHOLDER]) == \
           Parser().parse(['thefuck', 'echo'])


# Generated at 2022-06-12 09:53:49.545346
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser._parser.print_help()

# Generated at 2022-06-12 09:53:50.690086
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:54:01.610627
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert vars(parser.parse(['', 'command'])) == {
        'debug': False, 'force_command': None, 'command': ['command'],
        'shell_logger': None, 'repeat': False, 'alias': None, 'help': False,
        'version': False, 'enable_experimental_instant_mode': False,
        'yeah': False, 'yes': False}


# Generated at 2022-06-12 09:54:09.226065
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    argparseerror = None
    try:
        with redirect_stderr(io.StringIO()) as stderr:
            p = Parser()
            p.print_help()
    except SystemExit as e:
        argparseerror = e
    if not isinstance(argparseerror, SystemExit) or argparseerror.code != 0:
        print("argparseError is not instance of SystemExit exception or code is different as 0")
        print("argparseError: ", argparseerror)
        raise argparseerror


# Generated at 2022-06-12 09:54:09.809819
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-12 09:54:10.681234
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:54:13.914134
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]' in [line for line in sys.stderr.getvalue().split('\n') if line][0]


# Generated at 2022-06-12 09:54:20.138061
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['--force-command', 'ls', '-l']) == argparse.Namespace(command=['-l'], enable_experimental_instant_mode=False, shell_logger=None, force_command='ls', debug=False, alias=None, yes=False, repeat=False, help=False, version=False)
    assert parser.parse(['ls', '-l']) == argparse.Namespace(command=['-l'], enable_experimental_instant_mode=False, shell_logger=None, force_command=None, debug=False, alias=None, yes=False, repeat=False, help=False, version=False)

# Generated at 2022-06-12 09:55:26.286974
# Unit test for method parse of class Parser
def test_Parser_parse():
    try:
        import StringIO
    except ImportError:
        import io as StringIO  # pylint: disable=import-error

    argv1 = ['thefuck', 'git', 'push']
    parser1 = Parser()
    out1 = parser1.parse(argv1)
    assert out1.command == ['git', 'push']

    argv2 = ['thefuck', 'git', 'push', 'origin', 'master']
    parser2 = Parser()
    out2 = parser2.parse(argv2)
    assert out2.command == ['git', 'push', 'origin', 'master']

    argv3 = ['thefuck', 'git', 'push']
    parser3 = Parser()
    out3 = parser3.parse(argv3)

# Generated at 2022-06-12 09:55:37.261472
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'echo', 't'])
    assert args.command == ['echo', 't']

    args = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l'])
    assert args.command == ['ls', '-l']

    args = parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l', ARGUMENT_PLACEHOLDER, '-h'])
    assert args.command == ['ls', '-l', '-h']

    args = parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '-y', '-d'])

# Generated at 2022-06-12 09:55:38.244078
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser  # construct successfully

# Generated at 2022-06-12 09:55:46.958720
# Unit test for method parse of class Parser
def test_Parser_parse():
    def _do_test(args, expected):
        args_expected = ['thefuck'] + expected
        out = Parser().parse(args)
        assert out.command == args_expected
    _do_test(['thefuck'], [])
    _do_test(['thefuck', ARGUMENT_PLACEHOLDER, '1', '2'], ['1', '2'])
    _do_test(['thefuck', '1', '2'], ['1', '2'])
    _do_test(['thefuck', '-y'], ['-y'])
    _do_test(['thefuck', ARGUMENT_PLACEHOLDER, '1', '2', '3', '4'], ['1', '2', '3', '4'])

# Generated at 2022-06-12 09:55:54.650331
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .const import ARGUMENT_PLACEHOLDER
    args = [
        'thefuck', '--force-command', 'lol', '--', 'git', 'log', '--pam'
    ]
    assert Parser().parse(args).command == ['git', 'log', '--pam']

    args = [
        'thefuck', '--force-command', 'lol', '--', 'git', 'log', '--pam',
        ARGUMENT_PLACEHOLDER, '--am'
    ]
    assert Parser().parse(args).co

# Generated at 2022-06-12 09:56:04.314311
# Unit test for constructor of class Parser
def test_Parser():
    # if --help is used, help message will be printed
    parser = Parser()
    args = parser.parse(['thefuck', '--help'])
    assert args.help

    # if -v is used, version will be printed
    parser = Parser()
    args = parser.parse(['thefuck', '-v'])
    assert args.version

    # if no argument is given,
    # command will be empty and `command` arg will be True
    parser = Parser()
    args = parser.parse(['thefuck'])
    assert args.command == []
    assert args.help

    # if -y is given, `--yeah` will be True
    parser = Parser()
    args = parser.parse(['thefuck', '-y'])
    assert args.yeah

    # if -r is given,

# Generated at 2022-06-12 09:56:09.723302
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['', '-v']).version \
        == parser.parse(['', '--version']).version \
        == True

    parser.parse(['', '-a']).alias == None
    parser.parse(['', '-a', 'test']).alias == 'test'
    parser.parse(['', '--alias']).alias == None
    parser.parse(['', '--alias', 'test']).alias == 'test'

    parser.parse(['', '-l']).shell_logger == None
    parser.parse(['', '-l', 'test']).shell_logger == 'test'
    parser.parse(['', '--shell-logger']).shell_logger == None

# Generated at 2022-06-12 09:56:10.845178
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    p.print_usage()


# Generated at 2022-06-12 09:56:12.571255
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    try:
        Parser().print_usage()
        Parser().print_help()
    except SystemExit:
        assert False
    assert True

# Generated at 2022-06-12 09:56:21.632818
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from unittest.mock import patch

    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        parser = Parser()
        parser.print_help()

# Generated at 2022-06-12 09:58:40.475203
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert len(parser._parser.description) == 0
    assert len(parser._parser.epilog) == 0


# Generated at 2022-06-12 09:58:41.547910
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    result = parser.print_help()
    assert result is None

# Generated at 2022-06-12 09:58:43.443844
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p.parse(['--debug'])


# Generated at 2022-06-12 09:58:45.678973
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:58:54.049729
# Unit test for method parse of class Parser
def test_Parser_parse():
    a = Parser()
    assert(a.parse(["thefuck", "make", "--version"]) == Namespace(
        alias=None,
        command=['make', '--version'],
        debug=False,
        enable_experimental_instant_mode=False,
        force_command=None,
        help=False,
        repeat=False,
        shell_logger=None,
        version=False,
        yes=False))

# Generated at 2022-06-12 09:58:55.269534
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_usage()
    parser.print_help()
    print('success')

# Generated at 2022-06-12 09:58:58.622508
# Unit test for constructor of class Parser
def test_Parser():
    class_parser = Parser()
    assert_equals(class_parser._add_arguments(), None)
    assert_equals(class_parser._add_conflicting_arguments(), None)
    assert_equals(class_parser._prepare_arguments("ls"), ['--'])

# Generated at 2022-06-12 09:59:06.333707
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    errout = sys.stderr
    try:
        sys.stderr = open("/dev/null", "w")
        p = Parser()
        p.print_help()
        sys.stderr.close()

        sys.stderr = open("/dev/null", "w")
        p = Parser()
        p.print_usage()
        sys.stderr.close()

        sys.stderr = open("/dev/null", "w")
        p = Parser()
        p._add_arguments()
        sys.stderr.close()
    finally:
        sys.stderr = errout

# Generated at 2022-06-12 09:59:08.067425
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'


# Generated at 2022-06-12 09:59:09.214448
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == None

