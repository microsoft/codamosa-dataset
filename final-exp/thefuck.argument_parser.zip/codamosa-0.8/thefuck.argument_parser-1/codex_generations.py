

# Generated at 2022-06-12 09:49:53.164150
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    #assert(isinstance(p._parser, _argparse.ArgumentParser), True)
    #assert(p._parser.prog, 'thefuck')
    #assert(p.add_help, False)
    pass

# Generated at 2022-06-12 09:49:57.878149
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    sys.stderr = buffer = io.StringIO()
    parser = Parser()
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert buffer.getvalue() == 'Usage: thefuck [OPTIONS] [COMMAND [ARG] ...]\n'


# Generated at 2022-06-12 09:50:00.039578
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

# Generated at 2022-06-12 09:50:02.425572
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # create parser instance
    thefuck_parser = Parser()

    # test print_usage
    thefuck_parser.print_usage()

# Generated at 2022-06-12 09:50:03.560093
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:50:06.303827
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-12 09:50:07.332442
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser

# Generated at 2022-06-12 09:50:15.485119
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert __name__ != '__main__'
    out = StringIO.StringIO()
    sys.stderr = out
    p = Parser()
    p.print_usage()
    sys.stderr = sys.__stderr__
    assert out.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n                   [-l SHELL_LOGGER]\n                   [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n                   [command [command ...]]\n"



# Generated at 2022-06-12 09:50:25.305240
# Unit test for method parse of class Parser
def test_Parser_parse():

    parse = Parser().parse

# Generated at 2022-06-12 09:50:28.546371
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    argv = ['thefuck', '-a', '--', 'echo']
    parser.parse(argv)
    parser.print_help()

# Generated at 2022-06-12 09:50:35.974458
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Function set of module sys is mocked to check if the help message
    # is print
    with patch('sys.stderr', new=StringIO()) as stderr:
        parser = Parser()
        parser.print_help()
        assert 'usage: thefuck' in stderr.getvalue()

# Generated at 2022-06-12 09:50:38.021140
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:50:44.287436
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(sys.argv) == parser._parser.parse_args(sys.argv[1:])
    assert parser.parse(['fuck']) == parser._parser.parse_args(['--'])
    assert parser.parse(['fuck', 'git']) == parser._parser.parse_args(
        ['--', 'git'])
    assert parser.parse(['fuck', '--debug']) == parser._parser.parse_args(
        ['--debug'])
    assert parser.parse(['fuck', ARGUMENT_PLACEHOLDER, '--debug']) == parser._parser.parse_args(
        ['--debug'])
    assert parser.parse(['fuck', 'git', ARGUMENT_PLACEHOLDER, '--debug']) == parser._parser.parse

# Generated at 2022-06-12 09:50:49.605705
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['script.py', 'ls', '-la']) == parser.parse(['script.py', 'ls', '-la'])
    assert parser.parse(['script.py', 'cd', 'python-thefuck']) == parser.parse(['script.py', 'cd', 'python-thefuck'])



# Generated at 2022-06-12 09:50:58.287228
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from thefuck.utils import wrap_streams
    from io import StringIO
    argv = ['thefuck', '-v']
    with wrap_streams() as (out, err):
        Parser().parse(argv)
        assert err.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n' \
                                 '             [-l SHELL_LOGGER]\n' \
                                 '             [--enable-experimental-instant-mode]\n' \
                                 '             [-y] [-r] [-d] [--force-command FORCE_COMMAND]\n' \
                                 '             command ...\n'


# Generated at 2022-06-12 09:50:59.638231
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:51:08.748315
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    command_1 = ['thefuck', 'cd', '~/some/dir', '-r']
    command_2 = ['thefuck', 'cd', '~/some/dir', '-r', ARGUMENT_PLACEHOLDER, '-l']
    command_3 = ['thefuck', 'cd', '~/some/dir', '-r', ARGUMENT_PLACEHOLDER, '-l', '-h']

    expected_1 = parser.parse(command_1)
    expected_2 = parser.parse(command_2)
    expected_3 = parser.parse(command_3)

    result_1 = parser.parse(['thefuck', '--', 'cd', '~/some/dir', '-r'])

# Generated at 2022-06-12 09:51:11.851829
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parser.parse(['thefuck', '-v'])
    parser.parse(['thefuck', '-v', '--', 'ls'])
    parser.parse(['thefuck', '-v', 'ls'])
    parser.parse(['thefuck', 'ls'])

# Generated at 2022-06-12 09:51:16.154559
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', 'ls']) == p.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '--debug'])
    assert p.parse(['thefuck', 'ls', '-l']) == p.parse(['thefuck', 'ls', '-l', ARGUMENT_PLACEHOLDER, '--debug'])

# Generated at 2022-06-12 09:51:23.365325
# Unit test for constructor of class Parser
def test_Parser():
    import mock
    from StringIO import StringIO

    stderr = StringIO()
    with mock.patch('thefuck.shells.get_alias', return_value='alias fuck = eval $(thefuck $(fc -ln -1))'):
        parser = Parser()
        parser.print_usage(stderr)
        assert 'thefuck' in stderr.getvalue()
        parser.print_help(stderr)
        assert 'thefuck' in stderr.getvalue()
        assert '-a [custom-alias-name] prints alias for current shell' in stderr.getvalue()



# Generated at 2022-06-12 09:51:35.982561
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Trick for mock sys.stderr.write
    sys.stderr.write = lambda x: x

    # Expect the result
    expected = 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL-LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE-COMMAND] [--] [command [command ...]]\n'
    re_result = parser.print_usage()
    assert re_result == expected


# Generated at 2022-06-12 09:51:43.502043
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .main import Parser
    from .utils import capture

    parser = Parser()

    with capture() as captured:
        parser.print_usage()

    assert captured.output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'\
                              '             [-l shell-logger]\n'\
                              '             [--enable-experimental-instant-mode]\n'\
                              '             [-y | -r] [-d] [--force-command COMMAND]\n'\
                              '             [command [command ...]]\n'



# Generated at 2022-06-12 09:51:46.239063
# Unit test for constructor of class Parser
def test_Parser():
    # Unit test for constructor of class Parser
    out, err = capsys.readouterr()
    assert Parser()
    out, err = capsys.readouterr()
    assert out == ''


# Generated at 2022-06-12 09:51:47.564088
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
	parser = Parser()
	parser.print_usage()


# Generated at 2022-06-12 09:51:51.674487
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    if (parser.parse(['-a']) == 'fuck'):
        return True

# Generated at 2022-06-12 09:51:53.939552
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser._add_conflicting_arguments()
    parser._add_arguments()



# Generated at 2022-06-12 09:52:04.220679
# Unit test for method parse of class Parser
def test_Parser_parse():
    class TestParser(Parser):
        def __init__(self):
            return

        def _add_arguments(self):
            return

    parser = TestParser()

    assert parser.parse(['thefuck', 'command'])        == \
           parser._parser.parse_args(['command'])
    assert parser.parse(['thefuck', '--alias'])        == \
           parser._parser.parse_args(['--alias'])
    assert parser.parse(['thefuck', '--shell-logger', \
                         'file.log'])                  == \
           parser._parser.parse_args(['--shell-logger', 'file.log'])
    assert parser.parse(['thefuck', '--help'])         == \
           parser._parser.parse_args(['--help'])
    assert parser.parse

# Generated at 2022-06-12 09:52:07.029110
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    try:
        parser = Parser()
        parser.print_usage()
    except SystemExit:
        pass
    # parser is not None
    assert(parser is not None)


# Generated at 2022-06-12 09:52:08.845289
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None

# Generated at 2022-06-12 09:52:11.772904
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print("test Parser: pass")

# Append test function into test_module_dict
from . import test_module_dict
test_module_dict['test_Parser'] = test_Parser

# Generated at 2022-06-12 09:52:24.966717
# Unit test for method parse of class Parser

# Generated at 2022-06-12 09:52:26.777311
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Print usage
    parser.print_usage()


# Generated at 2022-06-12 09:52:28.331177
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()


# Generated at 2022-06-12 09:52:37.331188
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    ## 3 cases
    ## case 1. with ARGUMENT_PLACEHOLDER and command
    args1 = parser.parse(["fuck", "fuck this", "rm", "--", "this", "is", "a", "test"])
    assert args1.command == ["fuck this", "rm", "--", "this", "is", "a", "test"]

    ## case 2. w/o ARGUMENT_PLACEHOLDER and with command
    args2 = parser.parse(["fuck", "fuck this", "rm", "this", "is", "a", "test"])
    assert args2.command == ["fuck this", "rm", "this", "is", "a", "test"]

    ## case 3. w/o ARGUMENT_PLACEHOLDER and w/o

# Generated at 2022-06-12 09:52:39.528716
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    list=[1,2,3]
    assert Parser().print_help()

# Generated at 2022-06-12 09:52:40.141195
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-12 09:52:41.080465
# Unit test for constructor of class Parser
def test_Parser():
    p1 = Parser()
    assert(p1 != None)



# Generated at 2022-06-12 09:52:48.652482
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    import StringIO
    expectedResult = ("usage: thefuck [-h] [-v] [-a [custom-alias-name]] "
                      "[-l SHELL_LOGGER] [--enable-experimental-instant-mode] "
                      "[-y|-r] [-d] [--force-command FORCE_COMMAND] "
                      "[command [command ...]]")
    parser = Parser()
    sys.stdout = sio = StringIO.StringIO()
    parser.print_usage()
    assert(expectedResult == sio.getvalue().split()[3])


# Generated at 2022-06-12 09:52:56.011987
# Unit test for method parse of class Parser
def test_Parser_parse():
    Parser().parse([''])
    Parser().parse(['thefuck'])
    Parser().parse(['thefuck', '--debug'])
    Parser().parse(['thefuck', '--debug', '--', 'ls', '-l'])
    Parser().parse(['thefuck', '--', 'ls', '-l'])
    Parser().parse(['thefuck', 'ls', '-l'])

# Generated at 2022-06-12 09:52:57.208174
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert isinstance(parser, Parser)



# Generated at 2022-06-12 09:53:17.809686
# Unit test for method parse of class Parser
def test_Parser_parse():
    fake_parser = Parser()
    result_1 = fake_parser.parse(['thefuck', 'vim'])
    assert result_1.command == ['vim']

    result_2 = fake_parser.parse(['thefuck', 'vim', '-c', 'q'])
    assert result_2.command == ['-c', 'q']

    result_3 = fake_parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'vim'])
    assert result_3.command == ['vim']

    result_4 = fake_parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'vim', '-c', 'q'])
    assert result_4.command == ['-c', 'q']


# Generated at 2022-06-12 09:53:26.107066
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    # In Python 2 will print to sys.stderr
    # In Python 3 will print to sys.stdout or sys.stderr
    parser = Parser()
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = out = StringIO()
    sys.stderr = err = StringIO()
    parser.print_usage()
    sys.stdout = stdout
    sys.stderr = stderr
    assert 'usage: thefuck' in out.getvalue() or 'usage: thefuck' in err.getvalue()



# Generated at 2022-06-12 09:53:27.799761
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None

# Generated at 2022-06-12 09:53:38.048777
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'ls', '-l'])
    assert arguments.command == ['ls', '-l']
    assert not arguments.debug
    assert not arguments.enable_experimental_instant_mode
    assert not arguments.help
    assert not arguments.alias
    assert not arguments.hard
    assert not arguments.repeat
    assert not arguments.shell_logger
    assert not arguments.version
    assert not arguments.force_command

    arguments = parser.parse(['thefuck', 'ls', '-l', '--debug'])
    assert arguments.command == ['ls', '-l']
    assert arguments.debug
    assert not arguments.enable_experimental_instant_mode
    assert not arguments.help
    assert not arguments.alias
    assert not arguments.hard

# Generated at 2022-06-12 09:53:49.626369
# Unit test for method parse of class Parser
def test_Parser_parse():
    argv = ['python', 'fuck', 'git', 'push', ARGUMENT_PLACEHOLDER,
            '--force-command', 'ls', '-h', '--', '--all']
    args = Parser().parse(argv)
    assert args.force_command == 'ls'
    assert args.command == ['--all']
    assert args.debug is False
    assert args.help is False
    assert args.yes is False
    assert args.repeat is False

    argv = ['python', 'fuck', 'git', 'push', ARGUMENT_PLACEHOLDER,
            '--', '--all']
    args = Parser().parse(argv)
    assert args.force_command is None
    assert args.command == ['--all']
    assert args.debug is False

# Generated at 2022-06-12 09:53:50.163661
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:53:54.520765
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['thefuck'])
    assert not args.version
    assert not args.alias
    assert not args.enable_experimental_instant_mode
    assert not args.help
    assert not args.debug

# Generated at 2022-06-12 09:53:55.374340
# Unit test for constructor of class Parser
def test_Parser():
    assert len(Parser()._parser._actions) == 7

# Generated at 2022-06-12 09:54:01.017488
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert sys.stderr.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n              [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n              [command [command ...]]\n'


# Generated at 2022-06-12 09:54:07.238468
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p
    assert p._parser
    assert len(p._parser._actions)
    # Unit test for method _add_arguments
    test_add_arguments(p)
    # Unit test for method _add_conflicting_arguments
    test_add_conflicting_arguments(p)
    # Unit test for method _prepare_arguments
    test_prepare_arguments(p)


# Generated at 2022-06-12 09:54:41.539447
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from .utils import get_alias
    from .settings import get_settings
    from .const import ALIAS
    from .utils import get_version

    orig_stdout = sys.stdout
    parser = Parser()
    sys.stdout = output = StringIO()
    parser.print_usage()
    sys.stdout = orig_stdout
    output.seek(0)
    stdout = output.read()
    alias = get_alias()
    set_alias = get_settings().set_alias

# Generated at 2022-06-12 09:54:42.677063
# Unit test for constructor of class Parser
def test_Parser():
    parser=Parser()
    return parser

# Generated at 2022-06-12 09:54:53.484011
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .app import run_command
    from .utils import get_command_from_history
    assert Parser().parse(
        ['thefuck', 'sudo', '-y', '--', 'ls', '-l']) == run_command.parse_args(
            ['thefuck', 'ls', '-l'])
    assert Parser().parse(
        ['thefuck', 'sudo', '--', 'ls', '-l']) == run_command.parse_args(
            ['thefuck', 'ls', '-l'])
    assert Parser().parse(
        ['thefuck', '-y', '--', 'ls', '-l']) == run_command.parse_args(
            ['thefuck', 'ls', '-l'])

# Generated at 2022-06-12 09:54:55.134268
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    test_parser = Parser()
    test_parser.print_help()



# Generated at 2022-06-12 09:54:56.101595
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() == None

# Generated at 2022-06-12 09:54:58.474559
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    Parser_print_usage_output = parser.print_usage()
    assert Parser_print_usage_output == sys.stderr


# Generated at 2022-06-12 09:55:01.352520
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser_ = Parser()
    help_info = parser_.print_help()
    assert help_info == parser_.print_usage()

if __name__ == "__main__":
    test_Parser_print_help()

# Generated at 2022-06-12 09:55:02.838321
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:55:05.672657
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO

    output = StringIO()

    parser = Parser()
    parser.print_help(file=output)

    assert 'show this help message and exit' in output.getvalue()

# Generated at 2022-06-12 09:55:10.043148
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from io import StringIO

    out = StringIO()
    sys.stderr = out
    parser = Parser()
    parser.print_help()
    assert out.getvalue().startswith("Usage: thefuck [--version]\n")
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 09:56:13.896934
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from contextlib import closing
    from cStringIO import StringIO
    with closing(StringIO()) as f:
        parser = Parser()
        parser.print_help(f)
        assert 'arguments that should be fixed' in f.getvalue()

# Generated at 2022-06-12 09:56:15.275388
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert repr(parser) == '<Parser>'

# Generated at 2022-06-12 09:56:16.471534
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:56:18.375141
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:56:25.554613
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.description == 'Argument parser that can handle arguments with our special placeholder.'
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.add_help == False
    assert parser._parser._actions[0]._option_string == '-v'
    assert parser._parser._actions[1]._option_string == '--version'
    assert parser._parser._actions[2]._option_string == '-a'
    assert parser._parser._actions[3]._option_string == '--alias'
    assert parser._parser._actions[4]._option_string == '-l'
    assert parser._parser._actions[5]._option_string == '--shell-logger'

# Generated at 2022-06-12 09:56:27.998715
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    pass
    """
    parser = Parser()
    f = StringIO()
    parser.print_help(f)
    assert 'usage: thefuck' in f.getvalue()
    """

# Generated at 2022-06-12 09:56:30.557938
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # Given
    parser = Parser()

    # When
    output = parser.print_help()

    # Then
    assert output == parser.print_help()

# Generated at 2022-06-12 09:56:32.203902
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser.print_usage(Parser())


# Generated at 2022-06-12 09:56:34.564970
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert_that(parser.parse(['argv', '--yes', 'no_command']), is_('yes'))


# Generated at 2022-06-12 09:56:40.688421
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    with patch("sys.stderr"):
        parser.print_usage()
        sys.stderr.write.assert_called_with("usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger] [--enable-experimental-instant-mode]\n"
                                            "              [-y | -r] [-d] [--force-command FORCE_COMMAND]\n"
                                            "              [command [command ...]]\n")

# Generated at 2022-06-12 09:59:27.678106
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import io
    import sys
    sys.stderr = io.StringIO()
    Parser().print_help()

# Generated at 2022-06-12 09:59:34.204258
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    class StdErrObject:
        def __init__(self):
            self.data = []

        def write(self, data):
            self.data.append(data)

    class Parser(object):
        def __init__(self):
            self._parser = ArgumentParser()

        def print_help(self, file=None):
            file.write('{}\n{}\n{}\n'.format('The Fuck - a magnificent app.',
                                             'version 3.14.1',
                                             'usage: thefuck command'))

    parser = Parser()
    err = StdErrObject()
    parser.print_help(err)

# Generated at 2022-06-12 09:59:36.634920
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_string = parser.print_help()
    assert len(help_string.split('\n')) == 64

# Generated at 2022-06-12 09:59:39.417421
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    test_argv = 'thefuck -a z'
    test_argv_list = test_argv.split(" ")
    test_Parser = Parser()
    test_Parser.parse(test_argv_list)
    test_Parser.print_usage()



# Generated at 2022-06-12 09:59:40.556146
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-12 09:59:42.039721
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:59:44.589785
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_help()
    sys.stderr = sys.__stderr__
    assert out.getvalue()