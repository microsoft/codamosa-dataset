

# Generated at 2022-06-12 09:50:02.573159
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    result = parser.parse(['script_name', '-d', '--force-command'])
    assert result.debug is True
    assert result.force_command is None
    assert result.command == []

    result = parser.parse(['script_name', '-d', '--force-command', 'test'])
    assert result.debug is True
    assert result.force_command == 'test'
    assert result.command == []

    result = parser.parse(['script_name', 'git', 'commit'])
    assert result.debug is None
    assert result.force_command is None
    assert result.command == ['git', 'commit']

    result = parser.parse(['script_name', 'git', 'commit', '--', '-a'])
    assert result.debug is None
   

# Generated at 2022-06-12 09:50:04.005120
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:50:08.816762
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    output = StringIO()
    parser = Parser()
    parser.print_usage(file=output)
    assert 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]' in output.getvalue()


# Generated at 2022-06-12 09:50:09.872935
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-12 09:50:11.237951
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser is not None


# Generated at 2022-06-12 09:50:12.747505
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:50:14.429278
# Unit test for constructor of class Parser
def test_Parser():
    x = Parser()
    return isinstance(x, Parser)

# Generated at 2022-06-12 09:50:19.936961
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
     from StringIO import StringIO
     parser = Parser()
     out = StringIO()
     sys.stdout = out
     parser.print_usage()
     assert out.getvalue() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y] [-r] [--] [command [command ...]]\n"


# Generated at 2022-06-12 09:50:22.147290
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Test if we can print_usage of Parser Class"""
    p = Parser()
    assert p.print_usage() is not None


# Generated at 2022-06-12 09:50:32.419674
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p = Parser()
    assert p._parser.description == 'Argument parser that can handle arguments with our special\n    placeholder.\n\n'
    assert p._parser.usage == '%(prog)s [-v] [-a [custom-alias-name]] [-l shell-logger]\n                   [--enable-experimental-instant-mode] [-h] [-d]\n                   [--force-command force-command] [command [command ...]]'
    assert p._parser.prog == 'thefuck'
    assert p._parser.add_help == False
    assert p._parser._actions[0].option_strings == ['-v', '--version']
    assert p._parser._actions[0].dest == 'version'
    assert p._parser._actions[0].const == None
   

# Generated at 2022-06-12 09:50:53.293089
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    parsed_arguments = parser.parse(['thefuck', 'git commit', '-am', ARGUMENT_PLACEHOLDER, 'message'])
    assert parsed_arguments.command == ['git', 'commit', '-am', 'message']

    parsed_arguments = parser.parse(['thefuck', 'git commit', ARGUMENT_PLACEHOLDER, '-am', 'message'])
    assert parsed_arguments.command == ['git', 'commit', '-am', 'message']

    parsed_arguments = parser.parse(['thefuck', '--debug', 'git commit', ARGUMENT_PLACEHOLDER, '-am', 'message'])
    assert parsed_arguments.command == ['git', 'commit', '-am', 'message']
    assert parsed_arg

# Generated at 2022-06-12 09:51:03.835001
# Unit test for method parse of class Parser
def test_Parser_parse():
  #Test constructor
  print("\nTest constructor.\n")
  parser = Parser()
  assert parser != None


  #Test method _add_arguments
  print("\nTest method _add_arguments.\n")
  parser = Parser()
  assert parser._parser.print_help == None


  #Test method _add_conflicting_arguments
  print("\nTest method _add_conflicting_arguments.\n")
  parser = Parser()
  assert parser._parser.print_help == None


  #Test method _prepare_arguments
  print("\nTest method _prepare_arguments.\n")
  parser = Parser()
  assert parser._parser.print_help == None


# Generated at 2022-06-12 09:51:04.978658
# Unit test for constructor of class Parser
def test_Parser():
    Parser()
    print("Parser constructor test OK")

# Generated at 2022-06-12 09:51:11.898433
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[1].dest == 'debug'
    assert parser._parser._actions[2].dest == 'force_command'
    assert parser._parser._actions[3].dest == 'command'
    assert parser._parser._actions[4].dest == 'alias'
    assert parser._parser._actions[5].dest == 'shell_logger'
    assert parser._parser._actions[6].dest == 'enable_experimental_instant_mode'
    assert parser._parser._actions[7].dest == 'help'
    assert parser._parser._actions[8].dest == 'yes'


# Generated at 2022-06-12 09:51:18.756301
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    sys.stdout.write('Table of argument,argument help and argument action\n')
    sys.stdout.write('argument,argument help,argument action\n')
    sys.stdout.write('-v,--version,store_true\n')
    sys.stdout.write('-a,--alias,nargs=? const=get_alias()\n')
    sys.stdout.write('-l,--shell-logger,store\n')
    sys.stdout.write('--enable-experimental-instant-mode,store_true\n')
    sys.stdout.write('-h,--help,store_true\n')
    sys.stdout.write('-y,--yes,--yeah,--hard,store_true\n')

# Generated at 2022-06-12 09:51:21.882676
# Unit test for method parse of class Parser
def test_Parser_parse():
    arguments = Parser().parse(['thefuck', 'brew', 'remove', 'git', 'git', '--', '--verbose'])
    assert arguments.command == ['brew', 'remove', 'git', 'git', '--verbose']


# Generated at 2022-06-12 09:51:29.757471
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import cStringIO
    import sys

    capturedOutput = cStringIO.StringIO()           # Create StringIO object
    sys.stderr = capturedOutput                     #  and redirect stdout.

    parser.print_usage()
    sys.stderr = sys.__stderr__                     # Reset redirect.

    output = capturedOutput.getvalue().strip()
    assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y] [-r]'



# Generated at 2022-06-12 09:51:33.572318
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '-l']) == parser._parser.parse_args(['ls', '-l'])


# Generated at 2022-06-12 09:51:41.102628
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import io
    import sys
    parser = Parser()
    output = io.StringIO()
    sys.stderr = output
    parser.print_usage()
    output_content = output.getvalue()
    assert output_content == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] ' \
        '[-l shell_logger] [--enable-experimental-instant-mode] [-d] ' \
        '[--force-command force_command] [--] [-y | -r] [command [command ...]]\n'


# Generated at 2022-06-12 09:51:42.382307
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:52:04.511356
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:52:05.756478
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    #print parser.print_help()


# Generated at 2022-06-12 09:52:06.654203
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    print(parser)

# Generated at 2022-06-12 09:52:07.501355
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    Parser().print_usage()

# Generated at 2022-06-12 09:52:11.187698
# Unit test for method parse of class Parser
def test_Parser_parse():
#    Parser._prepare_arguments(Parser, argv)
    parsed = Parser().parse('thefuck -- -a fuck')
#     assert parsed.command == 'fuck'
   
    assert parsed.command == ['fuck']

# Generated at 2022-06-12 09:52:12.284800
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:52:17.256901
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help_text = parser.print_help()
    # help_text = parser.print_help().replace('\n', ' ')
    assert 'Options:' in help_text and '-h, --help' in help_text


# Generated at 2022-06-12 09:52:24.317143
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # given
    class StdOut(object):
        def __init__(self):
            self.value = ""
        def write(self, value):
            self.value = value
    stdout = StdOut()
    sys.stderr = stdout
    parser = Parser()

    # when
    parser.print_usage()

    # then

# Generated at 2022-06-12 09:52:35.079125
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['fuck', 'fuck you', ARGUMENT_PLACEHOLDER, '-y'])
    assert args.command == ['fuck', 'you']
    assert args.yes == True
    assert args.repeat == False
    assert args.debug == False
    assert args.force_command == None
    assert args.shell_logger == None
    assert args.enable_experimental_instant_mode == False

    args = Parser().parse(['fuck', 'fuck', ARGUMENT_PLACEHOLDER, 'you', '-y'])
    assert args.command == ['fuck', 'you']
    assert args.yes == True
    assert args.repeat == False
    assert args.debug == False
    assert args.force_command == None
    assert args.shell_logger == None
   

# Generated at 2022-06-12 09:52:41.986158
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    argv = ['./thefuck', 'command', ARGUMENT_PLACEHOLDER, 'argument']
    expected_parse_args_argv = ['argument', '--', 'command']
    with patch.object(parser._parser, 'parse_args',
                      return_value=None) as mock_parse_args:
        parser.parse(argv)
    assert mock_parse_args.call_args[0] == (expected_parse_args_argv,)


# Generated at 2022-06-12 09:53:04.112428
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:53:05.812095
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()
    assert True


# Generated at 2022-06-12 09:53:07.170335
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()


# Generated at 2022-06-12 09:53:08.131511
# Unit test for constructor of class Parser
def test_Parser():
    obj_parser = Parser()


# Generated at 2022-06-12 09:53:17.753732
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # empty argument
    assert parser.parse([]) == parser._parser.parse_args([])

    # command with arguments
    assert parser.parse(['git', 'push']) == parser._parser.parse_args(['--', 'git', 'push'])

    #
    assert parser.parse(['--alias', 'fuck', 'git', 'push']) == parser._parser.parse_args(['--alias', 'fuck', '--', 'git', 'push'])

    # place holder
    assert parser.parse(['--', ARGUMENT_PLACEHOLDER, 'git', 'push']) == parser._parser.parse_args(['git', 'push'])

    # place holder with arguments

# Generated at 2022-06-12 09:53:23.866829
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    stderr = sys.stderr

    try:
        from cStringIO import StringIO
        sys.stderr = StringIO()
        parser = Parser()
        parser.print_usage()
        assert sys.stderr.getvalue().startswith('usage: thefuck')
        assert sys.stderr.getvalue().endswith('thefuck [command]\n')
    finally:
        sys.stderr = stderr


# Generated at 2022-06-12 09:53:29.390663
# Unit test for method parse of class Parser
def test_Parser_parse():
	parser = Parser()
	print(parser.parse(['fuck', '-d', 'err0r']))
	print(parser.parse(['fuck', 'ls', '-lha', ARGUMENT_PLACEHOLDER, '-d', 'err0r']))

if __name__ == '__main__':
	test_Parser_parse()

# Generated at 2022-06-12 09:53:32.278743
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    match_obj = re.search(r'usage: thefuck ', parser.print_usage())
    assert match_obj is not None


# Generated at 2022-06-12 09:53:33.210438
# Unit test for constructor of class Parser
def test_Parser():
    instance = Parser()


# Generated at 2022-06-12 09:53:40.872106
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .const import VERSION
    from .utils import get_alias
    from io import StringIO
    from sys import stderr

    out = StringIO()
    stderr.write = out.write
    parser = Parser()
    parser.print_usage()
    actual = out.getvalue()

# Generated at 2022-06-12 09:54:24.310206
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    import sys
    sys.stderr.write('-- usage')
    assert sys.stderr.getvalue() == '-- usage'


# Generated at 2022-06-12 09:54:27.919142
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser.prog == 'thefuck'
    assert parser._parser.formatter_class == argparse.RawTextHelpFormatter
    assert parser._parser.add_help


# Generated at 2022-06-12 09:54:28.969066
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:54:38.186743
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .thefuck import TheFuckArgumentParser
    parser = TheFuckArgumentParser()
    assert parser.parse(['./thefuck']) == parser._parser.parse_args([])
    assert parser.parse(['./thefuck', '--alias', 'fuck']) == parser._parser.parse_args(['--alias', 'fuck'])
    assert parser.parse(['./thefuck', '-y', 'ls']) == parser._parser.parse_args(['-y', 'ls'])
    assert parser.parse(['./thefuck', 'ls']) == parser._parser.parse_args(['ls'])
    assert parser.parse(['./thefuck', '--', 'ls']) == parser._parser.parse_args(['--', 'ls'])

# Generated at 2022-06-12 09:54:43.514366
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    from contextlib import contextmanager
    @contextmanager
    def stdoutIO():
        old = sys.stdout
        sys.stdout = StringIO()
        yield sys.stdout
        sys.stdout = old

    with stdoutIO() as s:
        Parser().print_usage()
    output = s.getvalue()

# Generated at 2022-06-12 09:54:52.885904
# Unit test for method parse of class Parser
def test_Parser_parse():
    _parser = Parser()
    _argv = ['--enable-experimental-instant-mode', 'echo', ARGUMENT_PLACEHOLDER, 'fuck']
    _args = _parser.parse(_argv)
    assert _args.enable_experimental_instant_mode
    assert _args.command == ['echo', 'fuck']
    assert len(_args.command) == 2
    _argv = ['--alias', ARGUMENT_PLACEHOLDER, 'fuck']
    _args = _parser.parse(_argv)
    assert _args.alias is not None
    assert _args.command == ['fuck']
    assert len(_args.command) == 1

# Generated at 2022-06-12 09:55:03.515790
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_aliases

    parser = Parser()
    parser.print_help()
    assert '-a, --alias' in sys.stderr.getvalue()
    assert '-v, --version' in sys.stderr.getvalue()
    assert '-l, --shell-logger' in sys.stderr.getvalue()
    assert '--enable-experimental-instant-mode' in sys.stderr.getvalue()
    assert '-d, --debug' in sys.stderr.getvalue()
    assert '--force-command' in sys.stderr.getvalue()
    assert '-y, --yes, --yeah, --hard' in sys.stderr.getvalue()
    assert '-r, --repeat' in sys.stderr.getvalue()
   

# Generated at 2022-06-12 09:55:12.555608
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

# Generated at 2022-06-12 09:55:13.332549
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()


# Generated at 2022-06-12 09:55:14.478385
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser._parser is not None

# Generated at 2022-06-12 09:56:37.618710
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from mock import call
    from textwrap import dedent
    from .utils import wrap_in_namespace
    from .parser import Parser
    from .const import VERSION, THEFUCK_SRC

    parser = Parser()
    with wrap_in_namespace(alias='fuck', debug=True):
        parser.print_help()


# Generated at 2022-06-12 09:56:44.323089
# Unit test for method parse of class Parser
def test_Parser_parse():
    from .utils import create_alias
    from .const import DEFAULT_ALIAS
    from .config import DEFAULT_SETTINGS
    from .main import get_settings
    
    # make a backup
    settings = get_settings()
    old_alias = settings.get('alias')
    
    # test for alias
    settings.set('alias', 'zs')
    prefix = create_alias(settings, DEFAULT_SETTINGS)
    parser = Parser()
    options = parser.parse([prefix+'zs thefuck'])
    assert options.alias == 'zs'
    options = parser.parse([prefix+'zs thefuck -a'])
    assert options.alias == 'zs'
    options = parser.parse([prefix+'zs thefuck -a zs'])

# Generated at 2022-06-12 09:56:45.366778
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser

# Generated at 2022-06-12 09:56:46.819898
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert isinstance(Parser().parse([]), argparse.Namespace)



# Generated at 2022-06-12 09:56:48.388857
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None

# Generated at 2022-06-12 09:56:59.187225
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['fuck','-v'])
    assert(args.version == True)
    args = parser.parse(['fuck','-a','x'])
    assert(args.alias == 'x')
    args = parser.parse(['fuck','-a'])
    assert(args.alias == get_alias())
    args = parser.parse(['fuck','-l','x'])
    assert(args.shell_logger == 'x')
    args = parser.parse(['fuck','-d'])
    assert(args.debug == True)
    args = parser.parse(['fuck','-r'])
    assert(args.repeat == True)
    args = parser.parse(['fuck','-y'])
    assert(args.yes == True)
    args = parser.parse

# Generated at 2022-06-12 09:57:05.406846
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    out = StringIO()
    sys.stderr = out
    parser.print_usage()
    assert out.getvalue().split('\n')[0] == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND] [-y | -r] [--] command ...'


# Generated at 2022-06-12 09:57:06.798053
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:57:13.977382
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from contextlib import contextmanager
    from io import StringIO
    from six import PY2
    import sys
    @contextmanager
    def stdoutIO():
        # A context manager to capture stdout.
        import sys
        old = sys.stdout
        sys.stdout = io = StringIO()
        yield io
        sys.stdout = old

    parser = Parser()

    with stdoutIO() as s:
        parser.print_help()
    output = s.getvalue().strip()


# Generated at 2022-06-12 09:57:14.990317
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-12 09:59:26.313221
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:59:32.579752
# Unit test for method parse of class Parser
def test_Parser_parse():
    class FakeParser(object):
        def __init__(self):
            pass

        def parse_args(self, args):
            return args

    parser = Parser()
    parser._parser = FakeParser()
    assert parser.parse(['thefuck', '--force-command', 'fuck']) == ['--force-command', 'fuck']
    assert parser.parse(['thefuck', 'fuck']) == ['--', 'fuck']
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'fuck', '--option']) == ['fuck', '--option', '--']
    assert parser.parse(['thefuck']) == []

# Generated at 2022-06-12 09:59:41.598505
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', '-y', 'ls']).yes is True
    assert parser.parse(['thefuck', '--yes', 'ls']).yes is True
    assert parser.parse(['thefuck', '--repeat', 'ls']).repeat is True
    assert parser.parse(['thefuck', '--yeah', 'ls']).yes is True
    assert parser.parse(['thefuck', '--hard', 'ls']).yes is True
    assert parser.parse(['thefuck', '--shell-logger', '/tmp/shell.log',
                                 'ls']).shell_logger == '/tmp/shell.log'
    assert parser.parse(['thefuck', 'ls']).command == ['ls']

# Generated at 2022-06-12 09:59:50.357603
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    
    args = parser.parse(['thefuck', 'ls'])
    assert 'ls' == args.command[0]
    assert False == args.debug
    assert False == args.d
    assert False == args.help
    assert None == args.shell_logger
    assert False == args.force_command
    assert False == args.debug
    assert False == args.help
    assert None == args.shell_logger
    assert False == args.force_command
    assert False == args.yes
    assert False == args.repeat
    
    args = parser.parse(['thefuck', 'ls', '-v'])
    assert 'ls' == args.command[0]
    assert True == args.version
    assert False == args.debug
    assert False == args.help