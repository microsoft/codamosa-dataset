

# Generated at 2022-06-12 09:49:52.932380
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert "Show this help message and exit." in parser._parser.print_help(True)

# Generated at 2022-06-12 09:49:54.657244
# Unit test for constructor of class Parser
def test_Parser():
    from .parser import Parser
    Parser()



# Generated at 2022-06-12 09:49:56.396411
# Unit test for constructor of class Parser
def test_Parser():
	p = Parser()
	print(p)
	print(p._parser)



# Generated at 2022-06-12 09:49:58.163331
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert isinstance(parser.print_help, types.MethodType)


# Generated at 2022-06-12 09:49:59.495354
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:50:03.038132
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    out = StringIO()
    sys.stderr = out
    Parser().print_usage()
    sys.stderr = sys.__stderr__
    assert 'usage: thefuck' in out.getvalue()


# Generated at 2022-06-12 09:50:14.573512
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = Parser().parse(['script', '-l', '~/foo.log', '-a', 'fuck', '-v'])
    assert args.shell_logger == '~/foo.log'
    assert args.alias == 'fuck'
    assert args.version == True
    args = Parser().parse(['script', '-l', '~/foo.log', '-a', 'fuck', '--', 'ls', '-a', '-l'])
    assert args.shell_logger == '~/foo.log'
    assert args.alias == 'fuck'
    assert args.command == ['ls', '-a', '-l']
    args = Parser().parse(['script', '-l', '~/foo.log', '-a', 'fuck', '--', 'ls'])

# Generated at 2022-06-12 09:50:16.392190
# Unit test for constructor of class Parser
def test_Parser():
    from . import Parser
    p = Parser.Parser()
    assert p


# Generated at 2022-06-12 09:50:26.437106
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls']).command == []
    assert parser.parse(['thefuck', 'ls', '-l']).command == ['-l']
    assert parser.parse(
        ['thefuck', '-o', 'abra', 'dev/null', '--', 'ls']).command == ['-o', 'abra', 'dev/null']
    assert parser.parse(
        ['thefuck', '-o', 'abra', 'dev/null', '--', 'ls', '-l']).command == ['-o', 'abra', 'dev/null', '-l']
    assert parser.parse(
        ['thefuck', '--force-command', 'ls']).command == []

# Generated at 2022-06-12 09:50:35.153124
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_alias
    from .const import ALIAS, ARGUMENT_PLACEHOLDER
    parser = Parser()
    help_msg_file_name = "help_msg.txt"
    old_stdout = sys.stdout
    help_msg_file = open(help_msg_file_name, 'w')
    sys.stdout = help_msg_file
    parser.print_help()
    help_msg_file.close()
    sys.stdout = old_stdout
    help_msg = open(help_msg_file_name).read()
    assert (ARGUMENT_PLACEHOLDER in help_msg)
    assert ("-v, --version" in help_msg)
    assert ("--help show this help message and exit" in help_msg)

# Generated at 2022-06-12 09:50:48.437018
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(["-v"])
    parser.parse(["-a"])
    parser.parse(["-l"])
    parser.parse(["--enable-experimental-instant-mode"])
    parser.parse(["-h"])
    parser.parse(["-d"])
    parser.parse(["--force-command"])
    parser.parse(["command"])
    parser.parse(["python"])
    parser.parse(["-y"])
    parser.parse(["-r"])

    try:
        parser.parse(["-q"])
    except Exception:
        print("Parser success")

if __name__ == '__main__':
    test_Parser()

# Generated at 2022-06-12 09:50:58.429409
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()

    # Test for arguments like '--alias', '--debug'
    assert parser._parser._actions[0].option_strings == ['-v', '--version']
    assert parser._parser._actions[0].dest == 'version'
    assert parser._parser._actions[0].metavar == None
    assert parser._parser._actions[0].type == None
    assert parser._parser._actions[0].choices == None
    assert parser._parser._actions[0].required == False
    assert parser._parser._actions[0].default == False
    assert parser._parser._actions[0].help == "show program's version number and exit"
    assert parser._parser._actions[0].nargs == 0
    assert parser._parser._actions[1].option_strings == ['-a', '--alias']
    assert parser._parser

# Generated at 2022-06-12 09:51:07.913025
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .utils import get_alias
    from .const import ARGUMENT_PLACEHOLDER

    def get_output(*args):
        stderr = StringIO()
        Parser().parse(args).print_usage(stderr)
        return stderr.getvalue()

    assert gets_usage(get_output('fuck', 'edit'))
    assert gets_usage(get_output('fuck', '-h'))
    assert gets_usage(get_output('fuck'))
    assert gets_usage(get_output('fuck', '--alias'))

    assert gets_usage(get_output(get_alias(), 'edit'))
    assert gets_output(get_output(get_alias(), ARGUMENT_PLACEHOLDER, 'edit'))

# Generated at 2022-06-12 09:51:08.824051
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:51:10.133836
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() == None


# Generated at 2022-06-12 09:51:12.239482
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    # Test if no errors occur while parsing an empty string.
    parser.parse([])


# Generated at 2022-06-12 09:51:18.919100
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck', 'ls'])
    assert arguments.command == ['ls']
    arguments = parser.parse(['thefuck', 'ls', '-l'])
    assert arguments.command == ['ls', '-l']
    arguments = parser.parse(['thefuck', 'ls', '$(pwd)', '-l'])
    assert arguments.command == ['$(pwd)', '-l']
    arguments = parser.parse(['thefuck', 'ls', '-l', '$(pwd)'])
    assert arguments.command == ['$(pwd)']
    arguments = parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, '$(pwd)'])
    assert arguments.command == ['$(pwd)']

# Generated at 2022-06-12 09:51:19.524920
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-12 09:51:21.881979
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser=Parser()
    arguments = parser.parse(["","arguments"])
    assert arguments.command == []

#Unit test for method print_help of class Parser

# Generated at 2022-06-12 09:51:24.827846
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    args = parser.parse(['--debug', '--alias', 'fuck'])
    assert args.debug
    assert args.alias == 'fuck'


# Generated at 2022-06-12 09:51:38.845353
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from contextlib import redirect_stdout

    test_parser = Parser()
    f = StringIO()
    argv = ["command", "-v"]
    with redirect_stdout(f):
        test_parser.print_usage()
    s = f.getvalue()
    assert "usage: thefuck" in s


# Generated at 2022-06-12 09:51:40.960327
# Unit test for constructor of class Parser
def test_Parser():
	p = Parser()
	p.parse(['tag', '--help'])
	p.print_usage()
	p.print_help()

# Generated at 2022-06-12 09:51:47.604238
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    # File which syscall to read
    import sys
    PIPE_FILE_FD = sys.stderr.fileno()
    # syscall to read the file
    import os
    PIPE_FILE = os.fdopen(PIPE_FILE_FD)
    # Buffer to store the string
    import io
    PIPE_FILE_BUFFER = io.StringIO()
    # Get the system call read from file descriptor
    import fcntl
    PIPE_FLAGS = fcntl.fcntl(PIPE_FILE_FD, fcntl.F_GETFD)
    # Create a new file descriptor which has the same read function
    PIPE_FD = os.dup(PIPE_FILE_FD)
    # use the new file descriptor to read the file
    P

# Generated at 2022-06-12 09:51:50.541336
# Unit test for constructor of class Parser
def test_Parser():
    test_parser = Parser()
    print('test_parser:')
    print(test_parser)
    print('')
    
    

# Generated at 2022-06-12 09:51:51.967328
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser._add_arguments()


# Generated at 2022-06-12 09:51:53.361886
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:51:55.552186
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert str(parser.parse_args(['--version'])) == 'Namespace(version=True)'


# Generated at 2022-06-12 09:51:56.159928
# Unit test for constructor of class Parser
def test_Parser():
    Parser()

# Generated at 2022-06-12 09:51:58.115041
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.parse(sys.argv).command[0] != '--'

# Generated at 2022-06-12 09:52:00.357514
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert (parser.parse(['-a']) ==
            parser._parser.parse_args(['-a']))


# Generated at 2022-06-12 09:52:21.324871
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    out = p.parse(['thefuck', 'echo', 'fuck', 'arg', '--', 'command', 'arg'])
    assert out.command == ['command', 'arg']
    assert out.debug is False
    assert out.force_command is None
    out = p.parse(['thefuck', 'echo', 'fuck', 'arg', '--', 'command', '-y'])
    assert out.command == ['command', '-y']
    out = p.parse(['thefuck', 'echo', 'fuck', 'arg', '--', 'command', '-r'])
    assert out.command == ['command', '-r']
    out = p.parse(['thefuck', 'echo', 'fuck', 'arg', '--', 'command', '-d'])

# Generated at 2022-06-12 09:52:22.245336
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()



# Generated at 2022-06-12 09:52:30.602646
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    out = StringIO()
    sys.stderr = out
    p.print_usage()
    assert out.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]]\n'\
                             '                   [-l SHELL_LOGGER]\n'\
                             '                   [--enable-experimental-instant-mode]\n'\
                             '                   [-y | -r] [-d] [--force-command FORCE_COMMAND]\n'\
                             '                   [command [command ...]]\n'

# Generated at 2022-06-12 09:52:33.354321
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    arguments = parser.parse(['thefuck'])
    assert arguments.command == []
    assert arguments.yes is None
    assert arguments.repeat is None


# Generated at 2022-06-12 09:52:39.695492
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()

    # Run the method
    parser.print_help()

    # Check if the method returns the correct result

# Generated at 2022-06-12 09:52:47.004266
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    try:
        parser.parse(['thefuck', '-a', 'alias_name'])
    except SystemExit as e:
        assert e.code == 0
    try:
        parser.parse(['thefuck', '-v'])
    except SystemExit as e:
        assert e.code == 0
    try:
        parser.parse(['thefuck', '-y'])
    except SystemExit as e:
        assert e.code == 2
    try:
        parser.parse(['thefuck', '-h'])
    except SystemExit as e:
        assert e.code == 0
    try:
        parser.parse(['thefuck', '-r'])
    except SystemExit as e:
        assert e.code == 2

# Generated at 2022-06-12 09:52:57.022799
# Unit test for constructor of class Parser
def test_Parser():
    parser=Parser()
    assert parser._parser._actions[0].help=="show program's version number and exit"
    assert parser._parser._actions[1].help=="[custom-alias-name] prints alias for current shell"
    assert parser._parser._actions[2].help=="log shell output to the file"
    assert parser._parser._actions[4].help=="show this help message and exit"
    assert parser._parser._actions[5].title=='Mutually exclusive arguments'
    assert parser._parser._actions[6].help=='repeat on failure'
    assert parser._parser._actions[9].help=='enable debug output'
    assert parser._parser._actions[10].help=='command that should be fixed'

# Generated at 2022-06-12 09:53:02.358112
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    This function tests presence of all options and commands 
    """
    import sys
    import StringIO
    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    Parser().print_help()
    captured_output = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = stdout

    option_list = ['-v', '-a', '-l', '-h', '-d', '--force-command']
    for option in option_list:
        assert option in captured_output

# Generated at 2022-06-12 09:53:13.872023
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse( ['/path/to/script.py']) == parser._parser.parse_args( [])
    assert parser.parse( ['/path/to/script.py', 'ls']) == parser._parser.parse_args( ['-h'])
    assert parser.parse( ['/path/to/script.py', 'ls']) == parser._parser.parse_args( ['-r'])
    assert parser.parse( ['/path/to/script.py', 'ls']) == parser._parser.parse_args( ['-y'])
    assert parser.parse( ['/path/to/script.py', 'ls']) == parser._parser.parse_args( ['-a'])
    assert parser.parse( ['/path/to/script.py', 'ls']) == parser._

# Generated at 2022-06-12 09:53:19.989308
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .main import fuck
    from .utils import get_alias
    from .utils import symlink_to_bin_folder
    from .utils import delete_symlink_in_bin_folder

    # create an alias
    alias_name = 'tf'
    alias = get_alias(alias_name)
    fake_stdout = StringIO()
    sys.stdout = fake_stdout
    fuck(['--alias', alias_name])
    sys.stdout = sys.__stdout__
    alias = alias.replace('!', '\!')  # escape the bang sign

    # create a symlink
    with open('./tests/bin/fuck', 'w') as file:
        file.write(alias)

# Generated at 2022-06-12 09:53:44.338188
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    t = Parser()
    t.print_help()
    pass



# Generated at 2022-06-12 09:53:52.208898
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import get_closest

    def mock_print_usage(self, file=None):
        self._usage = (
            'usage: thefuck [-v | -a | -l | -h | -y | -r | -d | --force-command COMMAND] [--] [command [command ...]]\n')

    with patch.object(ArgumentParser, 'print_usage', mock_print_usage):
        parser = Parser()
    parser.print_usage()
    assert parser._parser._usage == 'usage: thefuck [-v | -a | -l | -h | -y | -r | -d | --force-command COMMAND] [--] [command [command ...]]\n'



# Generated at 2022-06-12 09:53:53.831740
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser is not None


# Generated at 2022-06-12 09:53:55.289234
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # No parameter
    parser = Parser()
    parser.print_help()



# Generated at 2022-06-12 09:53:57.066214
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    assert p


# Generated at 2022-06-12 09:53:58.074550
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()
    assert True


# Generated at 2022-06-12 09:54:03.410157
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l" \
            " shell-logger] [--enable-experimental-instant-mode] [-d] [-y]" \
            " [-r] [--force-command FORCE-COMMAND] [command [command ...]]" \
            in parser.print_usage()


# Generated at 2022-06-12 09:54:06.603160
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    print(p)
    print(p._parser)
    print(p.parse)
    print(p.print_usage)
    print(p.print_help)


# Generated at 2022-06-12 09:54:11.868960
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # before = sys.stderr
    with open('./test_Parser_print_help.txt', 'w+') as f:
        sys.stderr = f
        parser.print_help()
    with open('./test_Parser_print_help.txt', 'r') as f:
        f.read()



# Generated at 2022-06-12 09:54:14.746626
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'thefuck', '--', '--help', '--debug'])
    assert args.command == ['thefuck', '--help']
    assert args.debug is True


# Generated at 2022-06-12 09:55:04.815756
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """
    The test passes if there is no exception thrown
    
    """
    parser = Parser()
    parser.print_usage()



# Generated at 2022-06-12 09:55:05.799135
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    Parser().print_help()

# Generated at 2022-06-12 09:55:06.670384
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()

# Generated at 2022-06-12 09:55:13.161384
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    usage = "usage: thefuck [-h] [-v] [-a [CUSTOM-ALIAS-NAME]]\n" \
            "                [-l SHELL-LOGGER]\n" \
            "                [--enable-experimental-instant-mode] [-d]\n" \
            "                [--force-command DEBUG_COMMAND]\n" \
            "                [command [command ...]]"
    with captured_stderr() as stderr:
        parser.print_usage()
        assert stderr.getvalue() == usage


# Generated at 2022-06-12 09:55:24.870262
# Unit test for method parse of class Parser
def test_Parser_parse():
    import sys
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias
    class FakeArgumentParser(object):
        def __init__(self):
            pass
        def add_argument(self,*args,**kwargs):
            pass
        def add_mutually_exclusive_group(self):
            return []
        def parse_args(self,arguments):
            return arguments
    class FakeParser(object):
        def _prepare_arguments(self,argv):
            return argv
        def _add_arguments(self):
            pass
        def _add_conflicting_arguments(self):
            pass
    class FakeUtils(object):
        def get_alias(self,*args):
            return 1
    sys.modules['argparse'] = Fake

# Generated at 2022-06-12 09:55:25.782713
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser != None

# Generated at 2022-06-12 09:55:36.618282
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', ARGUMENT_PLACEHOLDER]) == argparse.Namespace(alias=get_alias(), command=[], debug=False, enable_experimental_instant_mode=False, help=False, repeat=False, shell_logger=None, version=False, yes=False)
    assert parser.parse(['thefuck', 'uname', ARGUMENT_PLACEHOLDER]) == argparse.Namespace(alias=get_alias(), command=[], debug=False, enable_experimental_instant_mode=False, help=False, repeat=False, shell_logger=None, version=False, yes=False)

# Generated at 2022-06-12 09:55:45.803701
# Unit test for method parse of class Parser
def test_Parser_parse():
    from io import StringIO
    from contextlib import redirect_stdout
    p = Parser()
    assert p.parse(['--debug', 'ls -lah /tmp']) == \
        p._parser.parse_args(
            p._prepare_arguments(['--debug', 'ls -lah /tmp']))
    assert p.parse(['cd ~', '&&', 'mkdir test', 'cd', 'test']) == \
        p._parser.parse_args(
            p._prepare_arguments(
                ['cd ~', '&&', 'mkdir test', 'cd', 'test']))

# Generated at 2022-06-12 09:55:51.474026
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    assert parser
    parser.parse(['thefuck', '-v'])
    parser.parse(['thefuck', '-a', 'fuck'])
    parser.parse(['thefuck', '-a'])
    parser.parse(['thefuck', '-l', 'shell.log'])
    parser.parse(['thefuck', '-h'])
    parser.parse(['thefuck', '-y'])
    parser.parse(['thefuck', '-r'])
    parser.parse(['thefuck', '--enable-experimental-instant-mode'])
    parser.parse(['thefuck', '-d'])
    parser.parse(['thefuck', '--force-command', 'ls'])
    parser.parse(['thefuck', 'ls'])

# Generated at 2022-06-12 09:55:52.747382
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:57:58.647872
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .utils import get_aliases

    expected = open('../README.md').read()
    parser = Parser()
    for alias in get_aliases():
        if alias != get_aliases()[0]:
            expected = expected.replace('_(' + alias + ')', alias)
    assert parser.print_help() == expected

# Generated at 2022-06-12 09:57:59.748621
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-12 09:58:01.389981
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-12 09:58:10.596222
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    assert p.parse(['thefuck', '-v']) == Namespace(command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=True, yes=False)
    assert p.parse(['thefuck', '--version']) == Namespace(command=[], debug=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=True, yes=False)

# Generated at 2022-06-12 09:58:12.985765
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    try:
        parser.print_help()
        print("Pass")
    except:
        print("Fail")
    return


# Generated at 2022-06-12 09:58:14.917922
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()
    parser.parse(['thefuck', 'ls', '-l'])


# Generated at 2022-06-12 09:58:22.616471
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    args = parser.parse(['thefuck'])
    assert args.force_command is None
    assert args.command == []

    args = parser.parse(['thefuck', 'ls'])
    assert args.command == ['ls']

    args = parser.parse(['thefuck', 'ls', '-l'])
    assert args.command == ['ls', '-l']

    args = parser.parse(['thefuck', '--', 'ls', '-l'])
    assert args.command == ['ls', '-l']

    args = parser.parse(['thefuck', ARGUMENT_PLACEHOLDER, 'ls'])
    assert args.command == []

    args = parser.parse(['thefuck', '--force-command', 'ls'])
    assert args.force_command

# Generated at 2022-06-12 09:58:23.675029
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    p = Parser()
    assert p.print_usage() == None


# Generated at 2022-06-12 09:58:24.436621
# Unit test for constructor of class Parser
def test_Parser():
    parser = Parser()


# Generated at 2022-06-12 09:58:33.496686
# Unit test for constructor of class Parser
def test_Parser():
    p = Parser()
    p._parser.parse_args(['-v'])
    p._parser.parse_args(['--version'])
    p._parser.parse_args(['-a'])
    p._parser.parse_args(['--alias'])
    p._parser.parse_args(['-a', 'root'])
    p._parser.parse_args(['--alias', 'root'])
    p._parser.parse_args(['-h'])
    p._parser.parse_args(['--help'])
    p._parser.parse_args(['-y'])
    p._parser.parse_args(['--yes'])
    p._parser.parse_args(['--yeah'])
    p._parser.parse_args(['--hard'])
    p._parser.parse