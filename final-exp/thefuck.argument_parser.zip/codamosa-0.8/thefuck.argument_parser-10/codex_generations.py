

# Generated at 2022-06-12 09:49:48.435167
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() is None


# Generated at 2022-06-12 09:49:49.331119
# Unit test for constructor of class Parser
def test_Parser():
    Parser()


# Generated at 2022-06-12 09:49:55.662324
# Unit test for method parse of class Parser
def test_Parser_parse():
    obj = Parser()
    
    # test case: [thefuck, --yes]
    argv = ['thefuck', '--yes']
    actual = obj.parse(argv)
    assert actual.yes == True
    assert actual.debug == False
    assert actual.command == []

    # test case: [thefuck, --debug]
    argv = ['thefuck', '--debug']
    actual = obj.parse(argv)
    assert actual.debug == True
    assert actual.force_command == None
    assert actual.command == []

    # test case: [thefuck, --shell-logger, /dev/null]
    argv = ['thefuck', '--shell-logger', '/dev/null']
    actual = obj.parse(argv)

# Generated at 2022-06-12 09:50:05.213453
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([]) == parser.parse(['thefuck'])
    assert parser.parse(['thefuck']) == parser.parse(['thefuck', '--'])
    assert parser.parse(
        ['thefuck', '--force-command']) == parser._parser.parse_args(
        ['--force-command'])
    assert parser.parse([
        'thefuck', 'pip', 'install', '--user', 'ARGUMENT_PLACEHOLDER',
        'requests']) == parser._parser.parse_args(
        ['requests', '--', 'pip', 'install', '--user'])
    parser = Parser()

# Generated at 2022-06-12 09:50:09.214339
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['', 'ls']).command == ['ls']
    assert parser.parse(['--debug', 'ls']).debug
    assert parser.parse(['-d', 'ls']).debug



# Generated at 2022-06-12 09:50:19.045282
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    class StderrCatcher(object):
        def __init__(self):
            self.message = ''

        def write(self, message):
            self.message += message

    class ArgumentParserMock(object):
        def __init__(self):
            self.print_usage_called = False
            self.print_usage_args = []

        def print_usage(self, file):
            self.print_usage_called = True
            self.print_usage_args.append(file)

    stderr_catcher = StderrCatcher()
    parser = ArgumentParserMock()
    parser_wrapper = Parser()
    parser_wrapper._parser = parser

    parser_wrapper.print_usage()

    assert parser.print_usage_called
    assert parser.print_usage_args == [sys.stderr]

# Generated at 2022-06-12 09:50:27.862791
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    sys.argv = ['']
    parser = Parser()
    capturedOutput = StringIO.StringIO()
    sys.stderr = capturedOutput
    parser.print_usage()
    sys.stderr = sys.__stderr__
    usage = """usage: thefuck [-h] [-v] [-l SHELL_LOGGER]
                  [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]
                  [-y] [-r] [-a [ALIAS]] [--] [command [command ...]]
    """
    assert usage == capturedOutput.getvalue()[:-1]


# Generated at 2022-06-12 09:50:32.593042
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    usage = parser.print_usage()
    assert (usage == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] "
            "[-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-d] "
            "[-y | -r] [--force-command FORCE_COMMAND] [command [command ...]]")


# Generated at 2022-06-12 09:50:34.425519
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    help = parser.print_help()
    assert type(help) is NoneType


# Generated at 2022-06-12 09:50:42.892819
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from .const import VERSION
    from textwrap import dedent
    from .utils import get_echo_command, get_alias
    from .utils import as_script, relpath


# Generated at 2022-06-12 09:50:54.873608
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse([
        'thefuck', '--debug', '--repeat', 'git', 'lg', '--count=5'])
    assert args.debug is True
    assert args.repeat is True
    assert args.command == ['git', 'lg', '--count=5']

    assert parser.parse([
        'thefuck', '--yeah', 'mix', 'g', '-u']) == \
        parser.parse([
        'thefuck', '--yes', 'mix', 'g', '-u'])


# Generated at 2022-06-12 09:51:00.244143
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    import io
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    capturedOutput = StringIO()
    sys.stderr = capturedOutput
    parser.print_usage()
    sys.stderr = sys.__stderr__
    assert "usage: thefuck" in capturedOutput.getvalue()


# Generated at 2022-06-12 09:51:09.451134
# Unit test for method parse of class Parser
def test_Parser_parse():
    """
        Unit test for method parse of class Parser
    """
    from .const import ARGUMENT_PLACEHOLDER
    from .utils import get_alias

    parser = Parser()
    args = parser.parse(['thefuck','find','','-r','-d'])
    assert args.repeat == True
    assert args.debug == True
    assert args.force_command is None
    assert args.command == ['find','find']

    args = parser.parse(['thefuck','-l','/tmp/log.txt','find','','-r','-d'])
    assert args.shell_logger == '/tmp/log.txt'

    args = parser.parse(['thefuck','-a'])
    assert args.alias == get_alias()

# Generated at 2022-06-12 09:51:17.440355
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Parser tests
    parser = Parser()
    parser.parse(['thefuck', 'python', '--help'])

    parser.parse(['thefuck', 'python', '--help', '--', 'my', 'args'])
    parser.parse(['thefuck', 'python', '--help', 'my', 'args'])
    parser.parse(['thefuck', 'python', 'my', 'args', '--help'])
    parser.parse(['thefuck', 'python', 'my', '--help', 'args'])

    parser.parse(
        ['thefuck', 'python', '--help', 'my', 'args', ARGUMENT_PLACEHOLDER,
         'my', 'args'])


# Generated at 2022-06-12 09:51:27.385092
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(
        ['./bin/thefuck', '$', 'git', 'config', '--global', 'user.name']) ==\
        argparse.Namespace(alias='fuck', debug=False, help=False, shell_logger=None,
                            repeat=False, yes=False,
                            force_command=None,
                            command=['./bin/thefuck', 'git', 'config', '--global', 'user.name'])

# Generated at 2022-06-12 09:51:38.475670
# Unit test for constructor of class Parser
def test_Parser():
    _Parser = Parser()
    _Parser._add_arguments()
    assert(str(_Parser._parser.parse_args(['--version'])) == "Namespace(command=[], debug=False, debug_logger=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=True)")
    assert(str(_Parser._parser.parse_args(['-v'])) == "Namespace(command=[], debug=False, debug_logger=False, enable_experimental_instant_mode=False, force_command=None, help=False, repeat=False, shell_logger=None, version=True)")

# Generated at 2022-06-12 09:51:46.388671
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()

    def call_parse(argv):
        return parser._prepare_arguments(argv)

    assert call_parse(['thefuck', ARGUMENT_PLACEHOLDER,
                       'python', '-c', 'print("hi")']) == \
        ['python', '-c', 'print("hi")', '--']
    assert call_parse(['thefuck', '--alias', ARGUMENT_PLACEHOLDER,
                       'python', '-c']) == \
        ['python', '-c']
    assert call_parse(['thefuck', 'python', ARGUMENT_PLACEHOLDER,
                       '-c', 'print("hi")']) == \
        ['python', '-c', 'print("hi")', '--']


# Generated at 2022-06-12 09:51:53.988312
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    from StringIO import StringIO

    parser = Parser()

    # Capture the stdout for this test
    orig_stdout = sys.stdout
    sys.stdout = StringIO()

    parser.print_help()
    output = sys.stdout.getvalue().strip()

    # Restore stdout
    sys.stdout = orig_stdout

    assert output.startswith('usage: thefuck')
    assert len(output.splitlines()) == 11
    assert output.endswith('  -h, --help            show this help message and exit')


# Generated at 2022-06-12 09:51:58.994704
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    P = Parser()
    outfile = StringIO.StringIO()
    sys.stderr = outfile
    P.print_help()
    outfile.seek(0)
    assert "usage:" in outfile.read()
    assert "[custom-alias-name]" in outfile.read()
    assert "repeat on failure" in outfile.read()


# Generated at 2022-06-12 09:52:00.878756
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    out = sys.stderr
    sys.stderr = cStringIO.StringIO()
    Parser().print_help()
    result = sys.stderr
    sys.stderr = out
    assert 'usage:' in result.getvalue()


# Generated at 2022-06-12 09:52:06.778499
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # Parser object was created, but help message was not
    # actually shown before
    parser.print_usage()
    parser.print_help()

# Generated at 2022-06-12 09:52:08.684696
# Unit test for constructor of class Parser
def test_Parser():
    _parser = Parser()

# Generated at 2022-06-12 09:52:09.628020
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:52:11.824921
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    assert parser.print_help() == parser._parser.print_help(sys.stderr)


# Generated at 2022-06-12 09:52:21.033153
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', '*']) == parser._parser.parse_args(['--', 'ls', '*'])
    assert parser.parse(['thefuck', 'ls', '*']) == parser._parser.parse_args(['ls', '*'])
    assert parser.parse(['thefuck', 'ls', '*'] + [ARGUMENT_PLACEHOLDER] + ['--yes', '--debug']) == parser._parser.parse_args(['--', '--yes', '--debug']) + parser._parser.parse_args(['ls', '*'])


# Generated at 2022-06-12 09:52:28.483911
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from .utils import _StringIO
    out = _StringIO()
    p = Parser()
    p.print_usage(file=out)
    assert out.get() == "usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER]\n               [--enable-experimental-instant-mode] [-d] [--force-command FORCE_COMMAND]\n               [-y | -r]\n               command [command ...]\n\n"


# Generated at 2022-06-12 09:52:37.414207
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['', 'this', 'command'])
    assert args.command == ['this', 'command']

    args = parser.parse([
        '', 'this', '--', 'command', 'with', 'args', 'and',
        ARGUMENT_PLACEHOLDER, 'and', 'even', 'more', 'arguments'])
    assert args.command == ['this', '--', 'command', 'with', 'args']

    args = parser.parse(['', 'this', 'command', ARGUMENT_PLACEHOLDER, 'arg'])
    assert args.command == ['this', 'command', 'arg']

    args = parser.parse(['', 'this', 'command', 'with', 'arg'])

# Generated at 2022-06-12 09:52:41.553006
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    with open('thefuck/tests/output/parser_help') as fd:
        parser.print_help()
        output = fd.read()
        assert sys.stderr.getvalue() == output

# Generated at 2022-06-12 09:52:50.662747
# Unit test for method parse of class Parser
def test_Parser_parse():
    args = ['placeholder', 'command', "cat", "-n", "placeholder", "--yes"]
    assert Parser().parse(args) == Parser().parse(['--'] + args)

    args = ['placeholder', 'command', "cat", "-n", "placeholder", "--yes"]
    expected_args = ['-y', '--', 'command', "cat", "-n"]
    assert Parser().parse(args).yes == True
    assert Parser().parse(['--'] + args).yes == True
    assert Parser().parse(['placeholder'] + args) == Parser().parse(expected_args)

    args = ['command', "cat", "-n"]
    assert Parser().parse(args) == Parser().parse(['--'] + args)


# Generated at 2022-06-12 09:52:57.932805
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from thefuck.utils import wrap_streams
    from StringIO import StringIO

    with wrap_streams(StringIO('a b'), StringIO()) as (input, output):
        Parser().print_usage()
        assert output.getvalue() == 'usage: thefuck [-h] [-v] [-a [<custom-alias-name>]] [-l <shell-logger>] [--enable-experimental-instant-mode] [-h] [-d] [--force-command <force-command>] [--] [<command> ...]\n'


# Generated at 2022-06-12 09:53:13.551376
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO

    parser = Parser()
    output = StringIO()
    sys.stderr = output
    parser.print_usage()
    assert output.getvalue() == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] '\
                                '[-l shell-logger] [--enable-experimental-instant-mode] [-d] [--force-command force-command] [-y | -r] [command [command ...]]\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 09:53:14.787306
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:53:24.759688
# Unit test for method print_help of class Parser

# Generated at 2022-06-12 09:53:34.534339
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from unittest.mock import patch
    from . import utils
    from .parser import Parser
    parser = Parser()
    with patch('sys.stderr', new=utils.StringIO()) as stderr:
        parser.print_usage()
        stderr.seek(0)
        assert stderr.read() == ('usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger] '
                                 '[--enable-experimental-instant-mode] [-d] [--force-command force-command]\n'
                                 '       [--] [command [command ...]]\n')


# Generated at 2022-06-12 09:53:36.625405
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    user_input = ["python3", "fuck", "fuck", "fuck"]
    parser.parse(user_input)
    parser.print_usage()


# Generated at 2022-06-12 09:53:38.180296
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from mock import patch
    parser = Parser()
    parser.print_usage()
    assert patch('sys.stderr').write.called

# Generated at 2022-06-12 09:53:40.733308
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()



# Generated at 2022-06-12 09:53:41.937338
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    assert Parser().print_usage() is None

# Generated at 2022-06-12 09:53:44.669053
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'echo'])
    assert args.command == ['echo']


# Generated at 2022-06-12 09:53:52.961908
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    import sys
    import io
    
    output = io.StringIO()
    sys.stdout = output
    Parser().print_help()

    output = output.getvalue()
    sys.stdout = sys.__stdout__

    assert 'thefuck [OPTIONS]' in output
    assert 'Usage:' in output
    assert '~$ thefuck' in output
    assert '-v, --version' in output
    assert '~$ thefuck --version' in output
    assert '-a, --alias' in output
    assert '~$ thefuck --alias' in output
    assert '-l, --shell-logger' in output
    assert '--enable-experimental-instant-mode' in output
    assert '-h, --help' in output
    assert '-d, --debug' in output

# Generated at 2022-06-12 09:54:17.210139
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER, '-l']) == \
           parser.parse(['thefuck', 'ls'])._get_args() + \
           parser._parser.parse_args(['-l'])._get_args()

    assert parser.parse(['thefuck', 'ls', ARGUMENT_PLACEHOLDER]) == \
           parser.parse(['thefuck', 'ls'])._get_args()

    assert parser.parse(['thefuck', 'ls', '-l']) == \
           parser.parse(['thefuck'])._get_args() + \
           parser._parser.parse_args(['--', 'ls', '-l'])._get_args()


# Generated at 2022-06-12 09:54:18.831359
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    assert parser.print_usage() is None


# Generated at 2022-06-12 09:54:20.035820
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    p = Parser()
    p.print_help()

# Generated at 2022-06-12 09:54:22.824662
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    # We call method parse with empty list of arguments to get empty namespace
    arguments = Parser().parse([])
    # We call method print_help of parser of class Parser
    Parser().print_help()



# Generated at 2022-06-12 09:54:27.672290
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    sys.argv = ['fuck', '--alias', 'ls']
    args = parser.parse(sys.argv)
    assert args.alias == 'ls'
    # assert parser.parse(['fuck', '--enable-experimental-instant-mode'])

# Generated at 2022-06-12 09:54:37.065871
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    res = parser.parse([])
    assert res.alias == get_alias()
    res = parser.parse(['-l', 'somefile'])
    assert res.shell_logger == 'somefile'
    res = parser.parse(['-l', 'somefile', '-v'])
    assert res.shell_logger == 'somefile'
    assert res.version == True
    res = parser.parse(['-v', '-l', 'somefile'])
    assert res.shell_logger == 'somefile'
    assert res.version == True
    res = parser.parse(['-v', '-h'])
    assert res.help == True
    assert res.version == True
    #simulate thefuck placeholder
    res = parser.parse(['$', 'ls'])

# Generated at 2022-06-12 09:54:39.469606
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['thefuck', 'something', 'wrong'])
    assert args.command == ['something', 'wrong']



# Generated at 2022-06-12 09:54:51.440741
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    """Test print usage of object Parser"""
    from io import StringIO
    from .parser import Parser
    from .const import ARGS
    parser = Parser()
    for arg in ARGS:
        saved_stderr = sys.stderr
        try:
            out = StringIO()
            sys.stderr = out
            parser.parse(arg)
            output = out.getvalue().strip()
            assert output == 'usage: thefuck [-h] [-v] [-a [custom-alias-name]] [-l SHELL_LOGGER] [--enable-experimental-instant-mode] [-y | -r] [-d] [--force-command FORCE_COMMAND] [command [command ...]]'
        finally:
            sys.stderr = saved_stderr



# Generated at 2022-06-12 09:54:57.694551
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse(['fuck', '-h']) == parser._parser.parse_args(['-h'])
    assert parser.parse(['fuck', 'cmd', '-h']) == parser._parser.parse_args(['--', 'cmd', '-h'])
    assert parser.parse(['fuck', 'cmd', ARGUMENT_PLACEHOLDER, 'arg1']) == parser._parser.parse_args(['arg1', '--', 'cmd'])
    assert parser.parse(['fuck', 'cmd', ARGUMENT_PLACEHOLDER, 'arg1', 'arg2']) == parser._parser.parse_args(['arg1', 'arg2', '--', 'cmd'])

# Generated at 2022-06-12 09:54:59.770238
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    # if we reach here it means nothing has failed
    parser.print_help()


# Generated at 2022-06-12 09:55:40.826155
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    # Getting the output of print_usage method of parser,
    # and saving it to a file to compare with expected_output.txt
    with open('test/test_output/test_Parser_print_usage.txt', 'w') as f:
        old_stdout = sys.stdout
        sys.stdout = f  # Changing the stdout to f
        parser.print_usage()
        sys.stdout = old_stdout

    with open('test/expected_output/expected_Parser_print_usage.txt', 'r') as f:
        expected_output = f.read()
        with open('test/test_output/test_Parser_print_usage.txt', 'r') as f:
            output = f.read()
            assert output == expected_output


# Generated at 2022-06-12 09:55:43.122079
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    parser.print_usage()


# Generated at 2022-06-12 09:55:46.716029
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """Unit test for method print_help of class Parser"""
    p = Parser()
    assert p.print_help() != None

"""
If this file is executed, it will run the unit tests above.
"""
if __name__ == '__main__':
    test_Parser_print_help()

# Generated at 2022-06-12 09:55:47.981547
# Unit test for constructor of class Parser
def test_Parser():
    obj = Parser()
    assert isinstance(obj._parser, ArgumentParser)


# Generated at 2022-06-12 09:55:51.322286
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    prefix = 'usage: '
    parser.print_usage()
    sys.stderr.seek(0)
    usage = sys.stderr.read()
    assert usage.startswith(prefix)


# Generated at 2022-06-12 09:56:01.582621
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """
    Test that print_help of class Parser
    prints help as expected
    """
    p = Parser()
    stdout = sys.stdout
    sys.stdout = StringIO()
    p.print_help()
    sys.stdout.seek(0)
    res = sys.stdout.read()
    sys.stdout = stdout
    print("Testing print_help")

# Generated at 2022-06-12 09:56:02.551868
# Unit test for constructor of class Parser
def test_Parser():
    assert Parser()

# Generated at 2022-06-12 09:56:10.298484
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    args = parser.parse(['script', 'git', 'co', 'master'])
    assert args.command == ['git', 'co', 'master']
    assert args.help is False

    args = parser.parse(['script', 'git', 'co', 'master', ARGUMENT_PLACEHOLDER, '--', '--help'])
    assert args.command == ['git', 'co', 'master', '--']
    assert args.help is True

    args = parser.parse(['script', 'git', 'co', 'master', ARGUMENT_PLACEHOLDER, '--', '--debug'])
    assert args.command == ['git', 'co', 'master', '--']
    assert args.debug is True


# Generated at 2022-06-12 09:56:19.450111
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    # without command
    assert parser.parse(['fuck', '-a']) == parser._parser.parse_args(['-a'])
    assert parser.parse(['fuck', '-l', '/dev/null']) == parser._parser.parse_args(['-l', '/dev/null'])
    assert parser.parse(['fuck', '--yes']) == parser._parser.parse_args(['--yes'])
    assert parser.parse(['fuck', '--repeat']) == parser._parser.parse_args(['--repeat'])
    # with command
    assert parser.parse(['fuck', '-a', 'ls']) == parser._parser.parse_args(['-a', '--', 'ls'])

# Generated at 2022-06-12 09:56:23.513046
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    parser = Parser()
    output = StringIO()
    sys.stderr = output
    parser.print_usage()

    # Check that parser prints usage
    assert 'usage: thefuck' in output.getvalue()
    # Check that parser doesn't print help
    assert 'usage: thefuck' in output.getvalue()
    assert 'optional arguments:' not in output.getvalue()


# Generated at 2022-06-12 09:57:44.633251
# Unit test for method parse of class Parser
def test_Parser_parse():
    p = Parser()
    p.parse(['thefuck', 'help', '-r', '-y', '--', '--help'])
    p.parse(['thefuck', '-r', '-y', '--', '--help'])
    p.parse(['thefuck', '--help', '-r', '-y', '--', '--help'])
    p.parse(['thefuck', '-r', '-y', '--help'])
    p.parse(['thefuck', '--help'])
    p.parse(['thefuck', '-h'])
    p.parse(['thefuck', 'help', 'some command'])
    p.parse(['thefuck', 'some command'])
    p.parse(['thefuck', 'git', 'push'])
    p.parse

# Generated at 2022-06-12 09:57:48.663179
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    _parser = Parser()
    _output = StringIO()
    _out = sys.stderr
    sys.stderr = _output
    try:
        _parser.print_help()
    finally:
        sys.stderr = _out
    # The expected output should not be empty
    assert len(_output.getvalue()) > 0

# Generated at 2022-06-12 09:57:50.298248
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    P = Parser()
    assert(P.print_usage()==None)


# Generated at 2022-06-12 09:57:57.852465
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """test for print_help() of Parser class"""
    parser = Parser()

    class StdErr(StringIO):
        """StdErr is a replacement for sys.stderr"""
        def getvalue(self):
            return self.buf


    stderr = sys.stderr
    sys.stderr = StdErr()

    parser.print_help()
    parser.print_usage()

    help_content = sys.stderr.getvalue()

    assert len(help_content) != 0, "print_help() didn't print anything"
    assert 'usage:' in help_content, "print_usage() doesn't work"

    sys.stderr = stderr

# Generated at 2022-06-12 09:58:00.832394
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output
    Parser().print_usage()
    sys.stderr = sys.__stderr__

    assert "usage: thefuck" in output.getvalue()

# Generated at 2022-06-12 09:58:09.722109
# Unit test for method parse of class Parser
def test_Parser_parse():
    # Testcase 1: argv = '--alias --debug --repeat'
    p = Parser()
    argv = ['--alias', '--debug', '--repeat']
    args = p.parse(argv)
    expected = Namespace(alias=get_alias(), debug=True, repeat=True)
    #print(vars(args), vars(expected))
    assert vars(args) == vars(expected)

    # Testcase 2: argv = '--alias --debug --repeat --' + ARGUMENT_PLACEHOLDER
    p = Parser()
    argv = ['--alias', '--debug', '--repeat', '--' + ARGUMENT_PLACEHOLDER]
    args = p.parse(argv)

# Generated at 2022-06-12 09:58:19.511780
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    """This test checks if help will be printed

    """

# Generated at 2022-06-12 09:58:20.320617
# Unit test for method print_help of class Parser
def test_Parser_print_help():
    parser = Parser()
    parser.print_help()

# Generated at 2022-06-12 09:58:28.101611
# Unit test for method parse of class Parser
def test_Parser_parse():
    parser = Parser()
    assert parser.parse([]) == parser.parse(['--'])
    assert parser.parse(['fuck']) == parser.parse(['--', 'fuck'])
    assert parser.parse(['fuck', '--', '-f']) == parser.parse(['--', 'fuck', '-f'])
    assert parser.parse(['fuck', ARGUMENT_PLACEHOLDER, '--', '-f']) == parser.parse(['--', 'fuck', '-f'])
    assert parser.parse(['fuck', ARGUMENT_PLACEHOLDER, '-f']) == parser.parse(['--', 'fuck', '-f'])

# Generated at 2022-06-12 09:58:36.366963
# Unit test for method print_usage of class Parser
def test_Parser_print_usage():
    from io import StringIO
    from .test_utils import mock_popen, SearchResult
    from thefuck.utils import replace_argument

    parser = Parser()

    output = StringIO()
    parser.print_usage(file=output)
    assert replace_argument(
        output.getvalue(), 'fuck') == 'usage: fuck [-h] [-v] [-a [custom-alias-name]] [-l shell-logger]\n'\
        '            [--enable-experimental-instant-mode] [-y | -r] [-d]\n'\
        '            [--force-command COMMAND]\n'\
        '            [command [command ...]]\n'

