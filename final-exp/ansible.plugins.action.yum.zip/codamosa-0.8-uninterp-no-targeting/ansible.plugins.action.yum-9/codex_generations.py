

# Generated at 2022-06-21 03:21:17.099668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    :return:
    '''
    action = ActionModule(None, None, None, None, None, None)
    assert action._supports_async
    assert action._supports_check_mode

# Generated at 2022-06-21 03:21:22.115743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test the constructor of class ActionModule
    :return: None
    '''
    print("Testing ActionModule constructor")
    action_module = ActionModule(None, None)
    assert action_module is not None
    assert action_module._supports_async is True
    assert action_module._supports_check_mode is True
    print("Passed!")



# Generated at 2022-06-21 03:21:25.577743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check parameters
    action = ActionModule()

    # Check return value
    assert action.run() == None

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-21 03:21:26.110726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:35.501491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing all the required objects
    mock_task = Mock()
    mock_task.args = {}
    mock_task.async_val = None
    mock_task.delegate_facts = None
    mock_task.delegate_to = None

    mock_wrap_async = Mock()

    mock_execute_module = Mock()
    mock_execute_module.return_value = None

    mock_remove_tmp_path = Mock()

    mock_connection = Mock()
    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = 'tmpdir'

    mock_templar = Mock()

    mock_shared_loader_obj = Mock()
    mock_shared_loader_obj.module_loader = Mock()
    mock_shared_loader_obj.module_loader.has_plugin.return_value

# Generated at 2022-06-21 03:21:40.001114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    # Initialize data to be used
    action_base = ActionBase()
    # Create object of class ActionModule
    obj = ActionModule(action_base)
    # Test for function run
    module = obj.run()

# Generated at 2022-06-21 03:21:42.739722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-21 03:21:50.693107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def get_env(name, value):
        return dict(name=name, value=value)

    a = ActionModule(task=dict(args={}), connection='connection', play_context=dict(), loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
    assert a._supports_check_mode is True
    assert a._supports_async is True
    assert a._task == dict(args={})
    assert a._connection == 'connection'
    assert a._play_context == dict()
    assert a._loader == 'loader'
    assert a._templar == 'templar'
    assert a._shared_loader_obj == 'shared_loader_obj'


# Generated at 2022-06-21 03:21:51.440615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return

# Generated at 2022-06-21 03:22:01.432875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    #test case: test_ActionModule_run_with_module_use
    result = action_module.run()
    assert result['failed'] == False
    #test case: test_ActionModule_run_with_module_use_delegate
    result = action_module.run()
    assert result['failed'] == False
    #test case: test_ActionModule_run_with_module_use_backend
    result = action_module.run()
    assert result['failed'] == False
    #test case: test_ActionModule_run_with_module_use_and_use_backend
    result = action_module.run()
    assert result['failed']

# Generated at 2022-06-21 03:22:13.088371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    with open('/tmp/test.yml', 'w') as testfile:
        testfile.write("""
        - name: test
          hosts: localhost
          tasks:
            - name: test yum3 vs yum4
              yum:
                name: vim
                state: present
              delegate_to: 127.0.0.1""")

    task_vars = {}
    tmp = None
    module_args = {
        'name': 'vim',
        'state': 'latest',
        'use_backend': 'auto',
        'delegate_to': '127.0.0.1'
    }

# Generated at 2022-06-21 03:22:22.481860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.module_utils._text import to_bytes

    module_return_value = dict(
        rc=0,
        stdout="",
        stderr="",
        start=1,
        end=2,
        delta=1,
        msg="",
        changed=True,
        results={"ansible_facts": {"pkg_mgr":"yum"}},
        ansible_facts={"pkg_mgr": "yum"},
    )

    module_execution_results = namedtuple("module_execution_results", "result")
    module_execution_results.result = module_return_value


# Generated at 2022-06-21 03:22:23.626845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-21 03:22:32.250548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    w = ActionModule()
    w.check_mode = False
    w.async_val = False
    w.runner = MockRunner()

    # Test with use_backend=yum
    w.task = {'args': {'name': 'vim', 'use_backend': 'yum'}}
    w._shared_loader_obj.module_loader.has_plugin = Mock(return_value=True)
    w._execute_module = Mock(return_value={'failed': False})
    w.run(tmp='/tmp', task_vars={})
    w._execute_module.assert_called_with(module_name='ansible.legacy.yum', module_args={}, task_vars={}, wrap_async=False)

    # Test with use_backend=yum4
    w.task

# Generated at 2022-06-21 03:22:34.572922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:22:44.929055
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:22:47.296505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:22:49.444767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None)
    assert module._supports_check_mode == True
    assert module._supports_async == True


# Generated at 2022-06-21 03:22:59.767962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test 1, a valid call with a use_backend argument
    _task_args = {
            "name": "openssh-server",
            "state": "present",
            "use_backend": "yum"
    }
    _task = dict(
            action=dict(module="yum", args=_task_args)
    )
    _task_vars = dict()
    _tmpdir = 'tmpdir'
    _display = Display()

    _action_module = ActionModule(_task, _task_vars, _tmpdir, _display)
    _result = _action_module.run(None, None)
    assert(_result == {'msg': "Could not find a yum module backend for ansible.legacy.yum."})

    # test 2, a valid call with a use_backend argument

# Generated at 2022-06-21 03:23:03.635723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This function tests ActionModule class constructor
    """
    module = ActionModule(task=None, connection=None,
                          play_context=None, loader=None,
                          templar=None, shared_loader_obj=None)
    assert module._supports_check_mode is True
    assert module._supports_async is True
    assert module.name is not None
    assert module.name is not ''
    assert module.short_description is not None
    assert module.short_description is not ''
    assert module.description is not None
    assert module.description is not ''

# Generated at 2022-06-21 03:23:27.393431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            delegate_to='server',
            async_val=10,
            action=dict(
                delegate_to='server',
                async_val=10,
            )
        ),
        connection=dict(
            _shell=dict(
                tmpdir='/tmp/spam'
            )
        )
    )

    assert isinstance(action_module, ActionModule)
    assert action_module.task == dict(
        delegate_to='server',
        async_val=10,
        action=dict(
            delegate_to='server',
            async_val=10,
        )
    )
    assert action_module._connection._shell.tmpdir == '/tmp/spam'
    assert action_module._task.delegate_to == 'server'

# Generated at 2022-06-21 03:23:37.201733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    from ansible_collections.ansible.legacy.plugins.actions.yum import ActionModule as y
    import pytest
    import os

    action_module = y()
    task_vars = {'ansible_pkg_mgr': 'dnf'}

    with pytest.raises(AnsibleActionFail) as exc:
        action_module.run(tmp=None, task_vars=task_vars)

    os.environ["ANSIBLE_PKG_MGR"] = "dnf"

    with pytest.raises(AnsibleActionFail) as exc:
        action_module.run(tmp=None, task_vars=task_vars)


# Generated at 2022-06-21 03:23:46.919665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = {'host_vars': None, 'playbook_path': "/fake/playbook/path", 'playbook_dir': "/fake/playbook/dir", 'play_context': None}
    config.update({'connection': "local", 'remote_user': "fake_user", 'private_key_file': None, 'timeout': 10, 'ssh_common_args': "", 'ssh_extra_args': "", 'sftp_extra_args': "", 'scp_extra_args': "", 'become': True, 'become_method': "sudo", 'become_user': "fake_user", 'become_pass': None, 'become_exe': None, 'become_flags': '-H', 'become_ask_pass': False, 'verbosity': 0, 'check': False})

# Generated at 2022-06-21 03:23:57.407315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import shutil
    import tempfile
    import json
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    ansible_dir = os.path.dirname(os.path.dirname(test_dir))

    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    from ansible.plugins.action import ActionBase

    from ansible.plugins import loader as plugin_loader

    from ansible.module_utils.common.removed import removed

    from ansible.module_utils import basic

    from ansible.errors import AnsibleActionFail


# Generated at 2022-06-21 03:24:02.613552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    module_name = "ansible.legacy.yum"
    module_args = dict()
    actmod = ActionModule(task=dict(), connection=dict(), play_context=dict(), share_loader_obj=dict(),
                          load_fragment=dict(), templar=dict(), loader=dict())
    actmod.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-21 03:24:07.193688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(
        task=dict(action=dict(module='test_actionmodule'), args=dict(test='test_actionmodule_arg')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert actionmodule

# Generated at 2022-06-21 03:24:09.417957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = __import__('ansible.plugins.action.yum')
    assert module.ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:24:11.572155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action is not None

# Generated at 2022-06-21 03:24:13.492938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runme = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert runme

# Generated at 2022-06-21 03:24:19.707602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json


# Generated at 2022-06-21 03:24:48.489601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.yum import ActionModule
    obj = ActionModule(
        task = dict(action = dict()),
        connection = dict(),
        play_context = dict(),
        loader = None,
        templar = None,
        shared_loader_obj = None
    )
    assert obj is not None

# Generated at 2022-06-21 03:24:49.711503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule('test', {}, False), ActionModule)

# Generated at 2022-06-21 03:24:57.510801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(delegate_to='localhost', delegate_facts=False, delegate_vars=False)
    args = dict(use_backend=dict(default='auto', type='str', raw=True), use=dict(type='bool', raw=True, default=None))
    action = ActionModule(task, args=args, templar=None, shared_loader_obj=None, connection=None, play_context=None, loader=None,
                          templar_args=None, delegated_vars=None)
    assert action.task_vars == {'ansible_distribution': 'Fedora'}
    assert action.delegate_to == 'localhost'
    assert action.delegate_facts == False
    assert action.delegate_vars == False
    assert action._task.async_val == False
   

# Generated at 2022-06-21 03:25:09.314635
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test with valid set of parameters
    actionm = ActionModule(task=dict(), connection=dict(),
                           play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # test with empty task
    actionm = ActionModule(task=None, connection=dict(),
                           play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # test with empty connection
    actionm = ActionModule(task=dict(), connection=None,
                           play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # test with empty play_context

# Generated at 2022-06-21 03:25:18.458437
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:25:29.633009
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()
    module._task=dict(
        delegate_facts=True,
        async_val=None,
        role=None
    )
    module._loader=None
    module._templar=None
    module._connection=None
    module._play_context=None
    module._shared_loader_obj=None

    # test with assumption 'use_backend' is not in self._task.args
    module._execute_module=lambda module_name, module_args, task_vars, wrap_async: module_name
    module._task.args=dict(
        use='auto',
        use_backend='auto'
    )
    module._ansible_version=dict(
        full=2.4
    )

# Generated at 2022-06-21 03:25:30.768583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task.args = {'use': 'yum', 'name': 'httpd'}
    action.run()

# Generated at 2022-06-21 03:25:34.403956
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:25:40.168226
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    myMock = MagicMock()
    myMock.delegate_to = 'foo'
    myMock.delegate_facts = False
    myMock.args = {}

    testActionModule = ActionModule()
    testActionModule._templar = MagicMock()
    testActionModule._task = myMock
    testActionModule._connection = MagicMock()
    testActionModule._connection.tmpdir = '/tmp'
    testActionModule._shared_loader_obj = MagicMock()
    testActionModule._shared_loader_obj.module_loader.has_plugin.return_value = True
    testActionModule._execute_module = MagicMock()
    testActionModule._remove_tmp_path = MagicMock()

    # test case 1
    myMock.args = {'use': 'auto'}
   

# Generated at 2022-06-21 03:25:48.753086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_uri = "ansible.builtin.yum"
    test_task_args = {"action": "install","name": "foo"}
    test_connection = None
    test_play_context = None
    test_loader = None
    test_templar = None
    test_shared_loader_obj = None

    test_object = ActionModule(
        task=None, connection=test_connection, play_context=test_play_context, loader=test_loader,
        templar=test_templar, shared_loader_obj=test_shared_loader_obj)
    assert isinstance(test_object, ActionModule)

    test_object = ActionModule(
        task=None, connection=None, play_context=None, loader=None,
        templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 03:26:43.499504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    import ansible.modules
    import random
    import string

    fake_hostname = "fakehostname"
    fake_path = "/tmp"
    fake_module = "fakemodule"
    fake_module_args = {"fakekey": "fakevalue"}
    fake_task_vars = {"fakekey": "fakevalue"}

    fake_tmp_path = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(6))
    fake_async_val = "fakeasyncval"
    fake_failed = "fakefailed"
    fake_msg = "fakemsg"

# Generated at 2022-06-21 03:26:53.263106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes

    # module_utils/command.py
    def shell_command_direct(cmd, prompt=None, answer=None, sendonly=False, check_rc=False, executable=None, data=None,
                             binary_data=False, path_prefix=None, cwd=None, in_data=None, encoding='utf-8', prompt_retry_check=True):
        return {'rc': 0, 'stdout': '', 'stderr': ''}

    # action_plugin/action.py
    def async_wrapper(task_vars, tmp):
        return True

    # ansible.module_utils.facts/hardware.py
    def get_distribution():
        return 'Fedora'

    # ansible.module_utils.facts.hardware.

# Generated at 2022-06-21 03:26:59.344698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_args = {
        "use": "yum"
    }
    mock_loader = None
    mock_task = MagicMock()
    mock_connection = MagicMock()

    yum_am = ActionModule(mock_task, mock_connection, mock_loader, mock_args)

    assert yum_am is not None
    assert yum_am._task is not None
    assert yum_am._connection is not None
    assert yum_am._loader is None
    assert isinstance(yum_am, ActionBase)


# Generated at 2022-06-21 03:27:06.223030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests.mock import patch
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.yum_select import ActionModule

    with patch.object(ActionBase, 'run' , return_value={'ansible_facts': {'pkg_mgr': 'yum3'}}):
        action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        result = action_module.run(tmp=None, task_vars=None)

    assert result['failed'] == False
    assert result['msg'] == "All items completed"

# Generated at 2022-06-21 03:27:16.736388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    import ansible.plugins.loader

    class MockActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            del tmp  # tmp no longer has any effect

            # Carry-over concept from the package action plugin
            if 'use' in self._task.args and 'use_backend' in self._task.args:
                raise AnsibleActionFail("parameters are mutually exclusive: ('use', 'use_backend')")

            return super(MockActionBase, self).run(tmp, task_vars)


# Generated at 2022-06-21 03:27:18.192468
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True

# Generated at 2022-06-21 03:27:29.479152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is a stub test case to allow content of the action plugin to be
    # developed and tested.
    # This should be replaced with a more comprehensive test case.
    myTest_module_name = 'ansible.module_name'
    myTest_module_args = {'name': 'json'}
    myTest_tmp = '/tmp/tmp123'
    myTest_task_vars = {'foo': 'bar'}
    myTest_task = {'async_val': 0, 'delegate_to': False, 'delegate_facts': False, 'args': myTest_module_args}

    action = ActionModule()
    action._shared_loader_obj = None
    action._task = myTest_task
    action._templar = None
    action._connection = None


# Generated at 2022-06-21 03:27:30.149244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:27:36.181233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We just need a display object for ActionModule.__init__
    display = Display()
    task = {
        "args": {
            "name": "httpd",
            "state": "latest",
            "use_backend": "auto"
        },
        "delegate_to": "127.0.0.1",
        "delegate_facts": True,
        "action": "yum"
    }
    mock_connection = {
        "_shell": {
            "tmpdir": "/path/to/mocktmpdir"
        },
    }

    test = ActionModule(task, display, [], mock_connection)
    assert test._connection == mock_connection
    assert test._task == task

# Generated at 2022-06-21 03:27:45.004517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # mock_self
    mock_self = {
        "_supports_check_mode":True,
        "_supports_async":True,
        "_task":{
            'async_val':False,
            'delegate_to': '',
            'delegate_facts': True,
            'args': {'name': 'yum'}
        },
        "_remove_tmp_path":False,
        "_execute_module":{
            'failed': False,
            'ansible_facts': {'pkg_mgr': 'auto'}
        },
        "_templar":{
            'template': 'auto'
        },
        "_shared_loader_obj":{
            'module_loader': {
                'has_plugin': True
            }
        }
    }

# Generated at 2022-06-21 03:29:23.608683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test ActionModule
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 03:29:32.819921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    module = ActionModule()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    tqm = None

# Generated at 2022-06-21 03:29:38.534335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task_vars = {
        'pkg_mgr': 'dnf',
        'ansible_pkg_mgr': 'dnf'}
    test_tmp = 'temp'
    test_display = Display()
    test_actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_task = {}
    test_task['args'] = {'list': 'foo', 'name': 'bar'}
    test_actionmodule._task = test_task
    test_actionmodule._shared_loader_obj = {}
    test_actionmodule._templar = {}
    test_actionmodule.run(test_tmp, test_task_vars)

# Generated at 2022-06-21 03:29:49.290040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.yum import ActionModule as ActionModule_yum
    from ansible.plugins.action.yum import VALID_BACKENDS as VALID_BACKENDS_yum

    #create the object and call its method
    a = ActionModule_yum(None, ImmutableDict(dict(ANSIBLE_MODULE_ARGS={'name': 'test', 'state': 'present'})), None)
    result = a.run(None, ImmutableDict(dict(ansible_facts=dict(pkg_mgr='yum'))))
    assert result['failed'] == False
    assert result['msg'] == ""
    assert result['ansible_facts'] == {'pkg_mgr': 'yum'}

# Generated at 2022-06-21 03:29:51.265619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:29:53.662063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    assert True

# Generated at 2022-06-21 03:30:02.577763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import yaml

    yaml.warnings({'YAMLLoadWarning': False})

# Generated at 2022-06-21 03:30:11.342570
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Dummy context object for Response._load_context()
    context = dict()

    # Dummy task object for Response._load_context()
    task = dict()

    # Dummy Response object for ActionBase._execute_module()
    response = dict()
    response['_connection'] = dict()
    response['_connection']['_shell'] = dict()
    response['_connection']['_shell']['tmpdir'] = dict()
    response['_task'] = dict()
    response['_task']['args'] = dict()
    response['_task']['args'] = dict()
    response['_task']['async_val'] = dict()

    # Dummy task object for ActionBase._execute_module()
    response['_task']['async_val'] = dict()

# Generated at 2022-06-21 03:30:14.229959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    module_name = 'yum'
    args = dict()
    wrap_async = None
    task_vars = dict()
    templar = object()
    action_module = ActionModule(None, task_vars, None)

# Generated at 2022-06-21 03:30:17.188553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert action is not None