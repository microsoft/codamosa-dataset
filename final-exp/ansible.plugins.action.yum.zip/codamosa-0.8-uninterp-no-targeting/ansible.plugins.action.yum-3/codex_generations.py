

# Generated at 2022-06-21 03:21:21.203453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend.", 'task': {'args': {'name': 'httpd-tools'}, 'name': 'yum'}}
    action_module_obj = ActionModule(task=dict(args=dict(name='httpd-tools'), name='yum'), connection=None, shared_loader_obj=dict(_shared_loader_obj={'_loader': {'has_plugin': lambda module: False}, 'module_loader': {'has_plugin': lambda module: True}}))

# Generated at 2022-06-21 03:21:28.800547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule(loader=None, shared_loader_obj=None, templar=None, connection=None)

    # Create a test task
    task = {'action': {'__ansible_module__': 'yum', 'use': 'auto'}, 'args': {'name': 'nginx'}}

    # Test case for 'auto' backend detection via template
    task_vars = {}
    task_vars['ansible_pkg_mgr'] = 'yum4'
    assert am.run(task_vars=task_vars, task=task) == {'failed': False, 'changed': False, 'msg': "", 'rc': 0}

    # Test case for 'auto' backend detection via facts
    task_vars = {}

# Generated at 2022-06-21 03:21:39.359111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unit_test
    import tempfile
    import os
    import shutil

    # Arrange
    module = 'ansible.legacy.yum'
    module_args = '{"name":"httpd","state":"absent"}'
    tmpfd, tmpfile = tempfile.mkstemp()
    os.close(tmpfd)
    os.remove(tmpfile)
    tmpdir = tempfile.mkdtemp()

    action_plugin = unit_test.create_action_plugin(ActionModule, 'ansible.plugins.action.yum', module, module_args, tmpdir)

    # Act
    action_plugin.run(tmpdir, {})

    # Assert
    assert(action_plugin._uses_shell)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-21 03:21:46.404505
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tmp=None
    task_vars={'ansible_pkg_mgr': 'yum4'}

    #action.run(tmp=None, task_vars=None)

    #import ipdb;ipdb.set_trace()

    res = ActionModule().run(tmp,task_vars)
    assert 'ansible_facts' in res
    assert res['ansible_facts']['pkg_mgr']=='yum4'
    #import ipdb;ipdb.set_trace()
    #print ("res = %s" % res)



# Generated at 2022-06-21 03:21:48.910689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an action module object
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 03:21:53.695251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""

    # test with no dictionary
    action_module = ActionModule("test_arg", {"action_plugin_args": "test_arg2"}, True, True)

    # test with no dictionary
    action_module = ActionModule("test_arg", {}, True, True)

# Generated at 2022-06-21 03:22:03.215191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fact_subset = dict(
        ansible_pkg_mgr="yum",
        ansible_yum=dict(installed=[]),
        ansible_dnf=dict(installed=[])
    )
    def get_setup_facts(filter, gather_subset):
        return dict(
            ansible_facts=dict(
                ansible_pkg_mgr="yum",
                ansible_yum=dict(installed=[]),
                ansible_dnf=dict(installed=[])
            )
        )
    display.debug = lambda *args: None
    am = ActionModule(task=dict(args=dict(state="present"), delegate_facts=True), connection=dict(), play_context=dict())

# Generated at 2022-06-21 03:22:06.765773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None,
                                 connection=None,
                                 templar=None,
                                 shared_loader_obj=None
                                 )
    print(action_module.run(
        tmp=None,
        task_vars=None))


# Generated at 2022-06-21 03:22:09.270889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # test that it works with a single backend module
    module.run({'test': {}})

    # test that alternate backend module works
    module.run({'test': {'use_backend': 'yum4'}})

# Generated at 2022-06-21 03:22:10.620526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({}, {})

# Generated at 2022-06-21 03:22:26.673606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_vars = {'ansible_facts': {'pkg_mgr': 'yum3'}}
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum3'}}
    tmp = '/tmp/.ansible'

    mod = ActionModule()
    mod.task_vars = task_vars
    mod._task.args = {'use': "auto", '_ansible_pipeline': False}

    assert mod._task.args.get('use') == 'auto'
    assert mod.task_vars == task_vars

    # Test where ansible_facts is not present in task_vars
    task_vars['ansible_facts'] = {}
    mod.task_vars = task_vars
    result = mod.run(tmp, task_vars)

# Generated at 2022-06-21 03:22:27.796008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, dict(), dict(), {}) is not None

# Generated at 2022-06-21 03:22:29.544445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:22:32.855244
# Unit test for constructor of class ActionModule
def test_ActionModule():

    a = ActionModule()

    # Check for value of instance variable TRANSFERS_FILES
    assert a.TRANSFERS_FILES == False, "Expected value is False, but got {}".format(a.TRANSFERS_FILES)


# Generated at 2022-06-21 03:22:34.647896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation of class ActionModule without arguments
    action_module_instance = ActionModule()

    assert action_module_instance is not None

# Generated at 2022-06-21 03:22:38.075695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule(None, None)
    assert module._supports_check_mode == True
    assert module._supports_async == True

# Generated at 2022-06-21 03:22:38.981246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:22:39.665403
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert True

# Generated at 2022-06-21 03:22:49.337204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display = Display()
    display.debug = lambda x: None
    task_args = {
            'state': 'installed',
            'name': 'yum',
            'use_backend': 'auto',
            'ansible_pkg_mgr': 'yum'
    }
    task_vars = {
        'hostvars': {
            'hostname': {
                'ansible_facts': {
                    'pkg_mgr': 'yum3'
                }
            }
        }
    }
    action_module = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-21 03:22:49.917642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:23:06.028176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Tests for the behavior of method run in class ActionModule.
    '''
    # TODO: The unit tests should go into a separate file.
    # TODO: Provide more unit tests.

    import ansible.executor.task_result

    display = Display()
    task_vars = {}
    tmp = None

    # Invalid backends.
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)
    display.display(result)
    assert result['failed'] is True
    assert result.get('msg') is not None

    # Collection backends.

# Generated at 2022-06-21 03:23:13.831078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    playbook = dict(
        hosts=dict(
            all=dict(
                gather_facts=False,
                tasks=[
                    dict(
                        name="test",
                        yum=dict(
                            name='httpd'
                        )
                    )
                ]
            )
        ),
        vars=dict(
            ansible_pkg_mgr='yum'
        )
    )
    task = PlaybookExecutor._task_from_play(playbook['hosts']['all'], playbook, 'all', None)
    task_vars = {}
    display = Display()

    res = ActionModule(task, display).run(task_vars=task_vars)

# Generated at 2022-06-21 03:23:14.719363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('init', 'arg')

# Generated at 2022-06-21 03:23:16.450335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test instantiation of class ActionModule
    module = ActionModule()
    assert module

# Generated at 2022-06-21 03:23:27.591256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeAnsibleModule(object):
        class FakeAnsibleModuleRunner(object):
            def __init__(self):
                self._async = 0
        def __init__(self):
            self.runner = self.FakeAnsibleModuleRunner()
    fake_ansible_module = FakeAnsibleModule()
    fake_ansible_module.params = {'use': 'auto', 'use_backend': 'yum'}

    class FakeTask(object):
        def __init__(self):
            self.async_val = None
            self.args = None

        @property
        def async_val(self):
            return self._async_val

        @async_val.setter
        def async_val(self, value):
            self._async_val = value


# Generated at 2022-06-21 03:23:37.378670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_text
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    display = Display()
    loader = None
    play_context = PlayContext(loader=loader, display=display, options=dict(connection='local', module_path=None, forks=10, become=None, become_method=None, become_user=None, check=False, diff=False))
    tmpdir = None

# Generated at 2022-06-21 03:23:46.974033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = MagicMock()
    action_module._task.args = dict(name=["foo"])
    action_module._task.async_val = None
    action_module._task.delegate_to = None
    action_module._task.delegate_facts = None
    action_module._shared_loader_obj = MagicMock()
    # check for yum-dnf-plugin installation
    action_module._shared_loader_obj.module_loader.has_plugin.return_value = False

    # Case 1: run method with use argument set to yum
    action_module._task.args['use'] = 'yum'
    assert action_module.run()

# Generated at 2022-06-21 03:23:57.480422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing with mock
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    def _load_name_to_path_map(self):
        return {'ansible.module_push.module_name': 'path.to.module'}

    mock_module_utils = type('module_utils', (object,), {'_load_name_to_path_map': _load_name_to_path_map})

    setattr(mock_module_utils, 'ANSIBLE_MODULE_ARGS', ImmutableDict({'foo': 'bar'}))
    setattr(mock_module_utils, 'ANSIBLE_MODULE_UTILS_PATH', 'path/to/module_utils')

    mock_ansible_module = type

# Generated at 2022-06-21 03:24:02.648878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # Creates object of class ActionModule
        am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        # Executes method run of class ActionModule with arguments tmp, task_vars
        am.run(tmp=None, task_vars=None)
    except (AnsibleActionFail, TypeError):
        pass

# Generated at 2022-06-21 03:24:12.047310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #import libraries for unit test
    import sys
    import unittest

    #import mock library
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    from unittest.mock import DEFAULT

    #import module to be tested
    from ansible.plugins.action import ActionModule

    #mock objects
    class MockDisplay:
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            return
        def vvv(self, msg, host=None):
            return
        def debug(self, msg):
            return
        def vvvv(self, msg, host=None):
            return

    # test-cases for ActionModule.run()
    # create

# Generated at 2022-06-21 03:24:26.893212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Not yet implemented")

# Generated at 2022-06-21 03:24:28.045331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()

# Generated at 2022-06-21 03:24:30.022492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)



# Generated at 2022-06-21 03:24:38.402968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    task_vars = dict()
    task_vars["ansible_facts"] = dict()
    task_vars["ansible_facts"]["pkg_mgr"] = "yum"
    result = am.run(task_vars=task_vars)
    assert(result["invocation"]["module_name"] == "ansible.legacy.yum")
    task_vars = dict()
    task_vars["ansible_facts"] = dict()
    task_vars["ansible_facts"]["pkg_mgr"] = "dnf"
    result = am.run(task_vars=task_vars)
    assert(result["invocation"]["module_name"] == "ansible.legacy.dnf")

# Generated at 2022-06-21 03:24:48.847237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule.
    """
    import sys
    import os

    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.runner import Runner
    from units.mock.plugins import ModuleTestCase

    class TestYumActionModule(ModuleTestCase):
        """
        Test case for method run of class ActionModule.
        """

        def setUp(self):
            """
            Setup method for unit test class TestYumActionModule.
            """

            super(TestYumActionModule, self).setUp

# Generated at 2022-06-21 03:24:49.418338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:24:57.331268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager

    am = ActionModule()

    # Assume valid
    assert am._validate_pkg_name('yum') == 'yum'

    # Assume failure
    assert not am._validate_pkg_name('yum4')

    # Neither yum3 or yum4 is available
    task_vars = dict(ansible_facts=dict(pkg_mgr='auto'))
    assert am._validate_pkg_name('auto', task_vars) == 'auto'

    task_vars['ansible_facts'] = dict()


# Generated at 2022-06-21 03:25:02.414956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = dict(
        args=dict(
            use='yum'
        )
    )
    action = ActionModule(None, mock_task, None)
    assert action._task.args.get('use') == 'yum'


# Generated at 2022-06-21 03:25:06.796116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys

# Generated at 2022-06-21 03:25:07.848360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-21 03:25:34.575911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run = ActionModule.run
    assert run(self=None, tmp=None, task_vars=None)

# Generated at 2022-06-21 03:25:35.623093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:25:37.296330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    y = ActionModule()
    assert x != y

# Generated at 2022-06-21 03:25:37.804380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:25:46.532841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = dict(name="dnf")
    module._connection = "mock"
    module._shared_loader_obj = "mock"
    module._templar = "mock"
    module._task.delegate_facts = True
    module._task.async_val = True
    facts = dict(
        ansible_facts=dict(
            pkg_mgr="dnf"
        )
    )
    with patch("ansible.plugins.action.yum3_vs_yum4.display") as mock_display:
        with patch.object(ActionBase, '_execute_module') as mock_execute_module:
            mock_execute_module.return_value = facts
            result = module.run()

# Generated at 2022-06-21 03:25:47.768710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('name', {'backend' : 'dnf'}, {})

# Generated at 2022-06-21 03:25:55.669310
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # The issues caused by the below statements are resolved
    # in test/unit/modules/test_yum.py
    # ansible.plugins.loader.action_loader.get("yum/yum_common")

    # For module dnf
    class FakeModule1():
        def run(self, tmp=None, task_vars=None):
            return None

    # For module yum
    class FakeModule2():
        def run(self, tmp=None, task_vars=None):
            return None

    # Initialize resource objects
    class Fake_ActionBase():
        def __init__(self):
            self._shared_loader_obj = Fake_SharedLoader()
            self._task = Fake_Task()

    class Fake_Task():
        def __init__(self):
            self.args = dict()


# Generated at 2022-06-21 03:25:57.140071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_BACKENDS == frozenset(['yum', 'yum4', 'dnf'])

# Generated at 2022-06-21 03:25:57.612538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:26:01.547943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    # method absent in ActionModule
    assert not hasattr(action_module, 'setup')
    assert not hasattr(action_module, 'exit')

    assert hasattr(action_module, 'run')
    assert not hasattr(action_module, 'run_command')
    assert hasattr(action_module, 'TRANSFERS_FILES')

# Generated at 2022-06-21 03:26:55.753212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for ActionModule constructor.
    """
    connection = None
    task = None
    loader = None
    temp_action = ActionModule(connection, task, loader)
    assert temp_action

# Generated at 2022-06-21 03:26:58.257250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Execute constructor of class ActionModule
    test_action_module = ActionModule('test', {}, False, False)

    assert test_action_module.module_name == 'test'

# Generated at 2022-06-21 03:26:59.202335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #  FIXME: fails until a full mock of all of the objects is created
    assert False

# Generated at 2022-06-21 03:26:59.666800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-21 03:27:01.662178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:27:03.006164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 03:27:08.484989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action='yum', async_val=300, args={'install': 'nginx'}, async_jid='123456789.123456'),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action is not None
    assert action._task.async_val == 300

# Generated at 2022-06-21 03:27:09.061413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:27:17.995334
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.yum_select import ActionModule

    tmp = None
    result = None
    task_vars = None

    def _execute_module(module_name, module_args, task_vars):

        if module_name in ['ansible.legacy.setup', 'ansible.legacy.yum4']:
            return ImmutableDict(failed=False, ansible_facts=dict(pkg_mgr=module_name))
        else:
            return ImmutableDict(failed=False, ansible_facts=dict(pkg_mgr='ansible.legacy.yum'))

    def _remove_tmp_path(tmpdir):
        raise NotImplementedError

    # Case: No provider

# Generated at 2022-06-21 03:27:18.787974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-21 03:29:04.570211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(True)

# Generated at 2022-06-21 03:29:05.264734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_obj = ActionModule()

# Generated at 2022-06-21 03:29:06.841220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module=ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 03:29:15.048736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''

    my_task_vars = dict()
    action = ActionModule()
    action._task = dict()
    action._task.async_val = False
    action._task.args = dict()
    action._task.delegate_facts = None
    action._task.delegate_to = None
    action._shared_loader_obj = None

    # Test with no argument given - should execute correctly
    result = action.run(tmp=None, task_vars=my_task_vars)
    assert result['ansible_facts']['pkg_mgr'] == 'yum'
    assert 'ansible_facts' in result

    #Test with argument 'use' as yum4 - should execute correctly
    action._task.args = dict()
   

# Generated at 2022-06-21 03:29:24.994685
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # remove test_ActionModule_run from the stack trace
    import traceback
    et, ev, tb = sys.exc_info()
    traceback.clear_frames(tb)

    # Patches
    # configure modules directories
    import ansible.module_utils
    old_modules_paths = ansible.module_utils._MODULES_PATH

    # Make sure no other plugins are loaded
    old_names = ansible.plugins.module_loader._module_cache.keys()
    from ansible.plugins import module_loader
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), 'modules'))

    # test for successful execution of the yum3 module

# Generated at 2022-06-21 03:29:34.178879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    temp_connection = MockConnection()
    temp_task = MockTask()
    temp_task.async_val = True
    temp_task.delegate_to = "local"
    temp_task.delegate_facts = True
    temp_task._ds = dict()
    temp_task.args = dict()
    temp_task.args['use'] = 'auto'
    temp_task.args['name'] = "tree"

    temp_layout_loader = MockLoader()
    temp_layout_loader.dir_contents = dict()

    temp_shared_loader_obj = MockLoader()
    temp_shared_loader_obj.dir_contents = dict()

# Generated at 2022-06-21 03:29:39.536225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Connection:
        module_implementation_preferences = ['shell', 'paramiko', 'winrm', 'ssh']
        def get_option(self, *args, **kwargs):
            return None
        def __init__(self):
            self._shell = ConnectionShell()

        class ConnectionShell:
            tmpdir = '/tmp'

    class Task:
        async_val = None
        delegate_to = None

        def __init__(self):
            self.args = {'use': 'auto'}

        def __setitem__(self, key, value):
            setattr(self, key, value)

    class PlayContext:
        pass

    class TaskExecutor:
        pass


# Generated at 2022-06-21 03:29:50.132749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Trivial unit test to show how to perform testing on ActionModule.run
    method. This test is not part of unit-test/__init__.py suite

    Usage: make ansible-test-collection-yum TAGS=unit-test EXTRA_VAR="test_name=test_ActionModule_run"

    """
    # Create the module
    action_module = ActionModule()
    # Get the task content
    action_module._task = dict(name="yum", args=dict(name="cowsay", state="absent"))
    # Get the connection

# Generated at 2022-06-21 03:29:50.655568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:29:51.163583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()