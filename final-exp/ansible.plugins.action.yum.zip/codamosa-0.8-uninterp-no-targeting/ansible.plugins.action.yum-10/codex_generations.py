

# Generated at 2022-06-21 03:21:18.336948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pm = ActionModule('yum', 'a', 'b', 'c', 'd', 'e', 'f')
    assert hasattr(pm, '_supports_check_mode')
    assert hasattr(pm, '_supports_async')
    assert hasattr(pm, '_task')
    assert hasattr(pm, '_shared_loader_obj')
    assert hasattr(pm, '_connection')
    assert hasattr(pm, '_play_context')
    assert hasattr(pm, '_loader')
    assert hasattr(pm, '_templar')

# Generated at 2022-06-21 03:21:19.390633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:21.011631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule(None, None))

# Run test
test_ActionModule()

# Generated at 2022-06-21 03:21:21.645060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:22.164590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:29.480138
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest

    import ansible.plugins.action as action
    from ansible.plugins.action.yum import _execute_module
    from ansible.plugins.action.yum import _remove_tmp_path
    from ansible.plugins.action.yum import ActionModule
    from ansible.plugins.action.yum import display

    class UnitTestYum(unittest.TestCase):
        def test_ActionModule_run_auto_01(self):
            self.assertEqual(
                action._execute_module({'use': 'auto'}),
                {'failed': True, 'msg': 'Could not find a yum module backend for auto.'}
            )


# Generated at 2022-06-21 03:21:34.930075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants
    ansible.constants.HOST_KEY_CHECKING = False
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    module = 'ansible.legacy.yum'

    if not module == 'ansible.legacy.yum':
        assert 1 == 1
    else:
        assert 1 == 1

# Generated at 2022-06-21 03:21:35.505338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:36.825847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:37.542984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 03:21:48.981810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task={'action': {'module': 'yum', 'args': {'name': 'httpd', 'use': 'yum4'}},
              'args': {'name': 'httpd', 'use': 'yum4'},
              'async_val': False})
    assert action_module.run(task_vars={})['module_name'] == 'dnf'

# Generated at 2022-06-21 03:21:55.007847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=dict(), play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 03:22:04.028916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_action = object()
    mock_self = object()
    mock_self._task = object()
    mock_self._task.args = {'use': None, 'use_backend': None}
    mock_self._task.delegate_to = None
    mock_self._task.delegate_facts = True

    # Mock method _execute_module
    mock_display = object()
    mock_display.debug = object()
    mock_self._execute_module = object()
    mock_self._execute_module.side_effect = [{'ansible_facts': {'pkg_mgr': 'yum'}},
                                             {'ansible_facts': {'pkg_mgr': 'yum4'}}]
    # Mock method _templar
    mock_templar = object()
    mock_

# Generated at 2022-06-21 03:22:12.868561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class InnerTask:
        def __init__(self, async_val, delegate_to, delegate_facts, use, use_backend):
            self.async_val = async_val
            self.delegate_to = delegate_to
            self.delegate_facts = delegate_facts
            self.valid = use or use_backend
            if self.valid:
                self.args = {use: 'use', use_backend: 'use_backend'}[True]

        def _get_args(self):
            return dict(a='a', ansible_facts='ansible_facts', use='use', use_backend='use_backend')

    class InnerModuleLoader:
        def __init__(self):
            self.module_loader = self


# Generated at 2022-06-21 03:22:20.429950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Create a fake task dictionary
  task_dict = {}
  # Create a fake task object to pass in to the method
  task = type('', (), {'async_val': False, 'args': {}, '_remove_tmp_path': lambda self, x: None})()
  # Create a fake connection object to pass in to the method
  connection = type('', (), {'_shell': type('', (), {'tmpdir': 'test_path'})()})()

  # Call the method with the fake objects
  # Should return an empty dictionary and not throw an exception
  assert ActionModule(task, connection).run() == {}

# Generated at 2022-06-21 03:22:25.944477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            argspec=dict(),
            async_val=None,
            args={
                'use': 'yum4'
            }
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 03:22:26.749720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 03:22:27.359269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule('test')
    assert x is not None

# Generated at 2022-06-21 03:22:29.771722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Tests for constructor.
    """
    action_module = ActionModule()

    assert action_module.VALID_BACKENDS == ('yum', 'yum4', 'dnf')

# Generated at 2022-06-21 03:22:32.779118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None)
    assert action._supports_check_mode is True
    assert action._supports_async is True
    assert action.VALID_BACKENDS == ("yum", "yum4", "dnf")

# Generated at 2022-06-21 03:22:52.051191
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    mod = ActionModule()

    # No delegation, use setup result
    mod._task.args = {'use': 'auto'}
    mod._task.delegate_to = None
    mod._task.delegate_facts = True
    mod._templar = None
    mod._shared_loader_obj = None
    mod._connection = None
    mod._execute_module = lambda a, b, c, d=None: {'ansible_facts': {'pkg_mgr': 'yum'}}
    mock = {
        'result': {
            'ansible_facts': {'pkg_mgr': 'yum'},
            'changed': False,
            'msg': 'msg'
        },
        'json': None
    }

    # Testing
    result = mod.run()

    # Assert

# Generated at 2022-06-21 03:22:53.059021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 03:23:02.060176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The test class
    class Testclass(object):
        class MockModuleReturn(object):
            def __init__(self):
                self.return_value = {}
        class MockTask(object):
            def __init__(self):
                self.args = {}
        class MockTemplar(object):
            def __init__(self, loader):
                self.loader = loader
            def template(self, item):
                return self.loader.template(item)
        class MockLoader(object):
            def __init__(self):
                self.vars = {}
            def get_basedir(self, play=None):
                return "foo/bar"
            def template(self, item):
                return item
            def set_vars(self, variables):
                self.vars = variables

# Generated at 2022-06-21 03:23:09.126890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create class object
    # NOTE: AnsibleActionFail, ActionBase, and Display classes are imported
    # at the top of this module
    ut_action_module = ActionModule()
    assert ut_action_module

    # Test __init__ function
    assert isinstance(ut_action_module._supports_check_mode, bool)
    assert isinstance(ut_action_module._supports_async, bool)
    assert ut_action_module.TRANSFERS_FILES == False


# Generated at 2022-06-21 03:23:12.834095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object of class ActionModule
    test_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Access a protected member variable of class ActionModule
    test_obj._templar = None
    assert test_obj._templar is None
    assert test_obj.TRANSFERS_FILES is False

# Generated at 2022-06-21 03:23:15.565429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert hasattr(action, '_task')
    assert isinstance(action._task, dict)
    assert hasattr(action, '_shared_loader_obj')

# Generated at 2022-06-21 03:23:18.172707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for run method of class ActionModule'''
    # Unit test for class method run
    # assertEqual(a, b)
    pass

# Generated at 2022-06-21 03:23:22.408431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Unit test for constructor of class ActionModule')
    action_module = ActionModule(connection=None, task=None,
                                 runner_debug=True)

    if action_module:
        print("action module is not null")

    assert action_module is not None

# Generated at 2022-06-21 03:23:26.125955
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    with pytest.raises(AnsibleActionFail) as excinfo:
        ActionModule().run()

    assert "parameters are mutually exclusive" in str(excinfo.value)

# Generated at 2022-06-21 03:23:31.891117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return am_instance

if __name__ == "__main__":
    test_am = test_ActionModule()
    print(test_am._supports_check_mode)

# Generated at 2022-06-21 03:23:58.474430
# Unit test for constructor of class ActionModule
def test_ActionModule():

    ###
    # Test with no args and check for all default values
    ###
    a = ActionModule()

    assert a._supports_check_mode is True
    assert a._supports_async is True

    assert a.TRANSFERS_FILES is False
    assert a.NO_LOG is False

# Generated at 2022-06-21 03:24:08.404917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_data = {
        'action': {
            'args': {
                'state': 'latest',
                'name': 'vim',
            }
        }
    }

    class Shell:
        def __init__(self):
            self.tmpdir = '/tmp/test'

    class Connection:
        def __init__(self):
            self._shell = Shell()

    class Task:
        def __init__(self):
            self.args = {
                'state': 'latest',
                'name': 'vim',
            }
            self.delegate_to = None
            self.delegate_facts = False
            self.async_val = False

    class Loader:
        module_loader = None

    class SharedPluginLoaderObj:
        loader = None


# Generated at 2022-06-21 03:24:15.985626
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # a test class to mock the common module class
    class TestActionModule():

        def __init__(self,):
            self._task = self
            self.args = {}
            self.delegate_to = None
            self.delegate_facts = None

        def __getitem__(self, item):
            return self.__dict__[item]

        def __setitem__(self, key, value):
            self.__dict__[key] = value

        @property
        def async_val(self,):
            return False

    # a test class to mock the pluginloader
    class Test_PluginLoader():

        def has_plugin(self, module):
            return True

    # a test class to mock the common shell class

# Generated at 2022-06-21 03:24:21.213849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = ActionModule()
    y = ActionModule()
    z = ActionModule()
    result1 = x.run()
    result2 = y.run()
    result3 = z.run()

    assert result1 == result2
    assert result2 == result3

# Generated at 2022-06-21 03:24:32.545210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    task_vars = dict()
    tmp = 'tmp'
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['pkg_mgr'] = 'auto'
    task_vars['ansible_facts']['pkg_mgr_type'] = 'yum'
    result = module.run(tmp, task_vars)
    assert result == {'failed': True, 'msg': ('Could not detect which major revision of yum is in use, which is required to determine module backend.', 'You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})')}

# Generated at 2022-06-21 03:24:37.004945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup mocks
    tmp_path = "/path/to/tmp"
    task_vars = {
        "ansible_facts": {
            "pkg_mgr": "yum",
        }
    }

    # setup action plugin
    action = ActionModule()
    action._connection = MockConnection()
    action._shared_loader_obj = MockSharedLoaderObj()

    action._task.args = {
        'use': 'yum',
    }

    result = action.run(tmp_path, task_vars)
    assert result['failed'] is False
    assert result['module_name'] == "ansible.legacy.yum"

    action._task.args = {
        'use_backend': 'yum',
    }

    result = action.run(tmp_path, task_vars)

# Generated at 2022-06-21 03:24:39.566071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    test_instance = ActionModule()
    test_result = test_instance.run()
    assert test_result == {'failed': False, 'changed': False, 'ansible_facts': {'pkg_mgr': 'yum'}}

# Generated at 2022-06-21 03:24:49.413339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    factory = ActionModule.factory
    ansible_mod = factory(None, None)
    assert ansible_mod is not None

    # Test inherance of super class
    assert isinstance(ansible_mod, ActionModule)
    assert isinstance(ansible_mod, ActionBase)

    # Test __doc__

# Generated at 2022-06-21 03:24:50.457018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:24:55.430220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task.args = {'use': 'test-actionmodule'}
    facts = action_module._execute_module(
        module_name="ansible.legacy.setup", module_args=dict(filter="ansible_pkg_mgr", gather_subset="!all"),
        task_vars={})
    facts = facts.get("ansible_facts", {}).get("ansible_pkg_mgr", "auto")
    assert facts == 'test-actionmodule'

# Generated at 2022-06-21 03:25:49.030336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    from ansible.utils import plugin_docs
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action.yum import ActionModule

    sys.path.append(os.path.join(plugin_docs.__path__[0], '..', '..'))

    #Inject Python modules into system path
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + '/../')

    from ansible.utils.display import Display
    from ansible.plugins.action import ActionBase
    from ansible.compat.tests.mock import patch, mock_open, MagicMock

# Generated at 2022-06-21 03:25:49.679699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:25:51.080563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-21 03:25:52.725216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule({}, {}, None, None, None)
    assert isinstance(x, ActionBase)
    assert isinstance(x, ActionModule)



# Generated at 2022-06-21 03:25:54.086575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result1 = ActionModule()
    assert result1.TRANSFERS_FILES == False


# Generated at 2022-06-21 03:25:54.526765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:25:55.511387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    assert action_module

# Generated at 2022-06-21 03:26:02.671267
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestActionModule(ActionModule):
        '''
        Simply override run method to test it.
        See https://github.com/jctanner/ansible-module-test/issues/18
        '''
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)
    test_action_module = TestActionModule(
        task=dict(args=dict(use='auto')),  # main without yum module
        connection=dict(module_name='yum', module_args=dict()),
        play_context=dict(check_mode=True),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    # Test1: no use, no use_backend,

# Generated at 2022-06-21 03:26:08.669536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test function run()"""
    # Setup some test values
    tmp = None
    task_vars = None

    # Create an instance of the class to test
    actionmodule = ActionModule(tmp, task_vars)

    # Run the run() method of the class and verify
    result = actionmodule.run(tmp, task_vars)
    assert result == {'failed': True, 'msg': 'Action module is a stub'}



# Generated at 2022-06-21 03:26:11.615179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test w/o specific constructor parameters
    obj = ActionModule(None, None)
    if hasattr(obj, '_shared_loader_obj'):
        assert isinstance(obj._shared_loader_obj, object)
    else:
        assert False

# Generated at 2022-06-21 03:27:50.898603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 1
    # Test if object is created with the constructor
    module = ActionModule()
    assert module

    # Test case 2
    # Test if object is created with the constructor
    module = ActionModule(ob=None, task_vars=None)
    assert module

    # Test case 3
    # Test if object is created with the constructor
    module = ActionModule(ob=None, task_vars=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

    # Test case 4
    # Test the run functionality
    tmp = None
    task_vars = test_ActionModule.task_vars

# Generated at 2022-06-21 03:27:56.957494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.parsing.vault import VaultLib
    from ansible.context import context
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-21 03:27:59.202296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.environ['ANSIBLE_STRATEGY'] = 'debug'
    os.environ['ANSIBLE_LOG_PATH'] = '/tmp/ansible.log'
    display = Display()
    action = ActionModule(display)
    assertFalse(action.run(tmp=None, task_vars=None))

# Generated at 2022-06-21 03:28:00.911314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule(task=dict(), connection=None,
                        play_context=None, loader=None,
                        templar=None, shared_loader_obj=None))

# Generated at 2022-06-21 03:28:05.321172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 03:28:06.003011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-21 03:28:07.663106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This only tests if the class can be instantiated.
    assert ActionModule({}, {}) is not None

# Generated at 2022-06-21 03:28:15.122656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.module_utils.six import BytesIO

    from ansible.action.yum import ActionModule

    class MyModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(MyModule, self).__init__(*args, **kwargs)
            self._shell = None

    collection_loader = AnsibleCollectionLoader()

    tmpdir = tempfile.mkdtemp(prefix='ansible_test_')
    shutil.copytree('test/support/test_module_data/module_data/pkg_mgr', tmpdir + '/module_data/pkg_mgr')


# Generated at 2022-06-21 03:28:21.757838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Running unit tests for ActionModule")
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    # Create a mock task
    # pylint: disable=too-many-locals
    task = Mock()
    task.action = 'yum'
    task.args = dict(name='vim', state='latest')
    task.async_val = None
    task.delegate_to = None
    task.delegate_facts = None
    task.notify = []
    task.register = None
    task.run_once = False
    task.until = None
    task.retries

# Generated at 2022-06-21 03:28:24.236590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate and run the action module
    action = ActionModule(None, None)
    result = action.run()

    # Test returned data
    assert result['failed'] is True
    assert result['msg'] == "Action module 'yum' not implemented on target host"