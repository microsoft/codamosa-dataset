

# Generated at 2022-06-21 03:21:13.545550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:16.386790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, {}, {}, {})
    assert mod._supports_check_mode is True
    assert mod._supports_async is True

# Generated at 2022-06-21 03:21:16.951222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:26.438148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with good data
    data = dict(
        _ansible_parsed_args=dict(
            use='yum',
        ),
    )
    test = ActionModule(data)
    assert test._task.args['use'] == 'yum'

    # Test with good data
    data = dict(
        _ansible_parsed_args=dict(
            use_backend='yum4',
        ),
    )
    test = ActionModule(data)
    assert test._task.args['use_backend'] == 'yum4'

    # Test with invalid data
    data = dict(
        _ansible_parsed_args=dict(
            use='auto',
        ),
    )

# Generated at 2022-06-21 03:21:36.097479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing with a basic yum task
    task_args = {'name': 'httpd', 'state': 'latest'}

    action = ActionModule(task=dict(action='yum', args=task_args, delegate_to='127.0.0.1'),
                          connection=dict(user='root', become='true', become_user='root', become_method='sudo',
                                          ansible_ssh_host='192.168.1.1', ansible_ssh_port='22', ansible_ssh_pass=''),
                          task_vars={'ansible_facts': {'pkg_mgr': 'RPM'}})


# Generated at 2022-06-21 03:21:38.057991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__dict__['run'].__code__.co_argcount == 3

# Generated at 2022-06-21 03:21:48.088766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import unittest
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.vars import VariableManager
    executable = sys.executable

    class TestTaskResult(TaskResult):
        def __init__(self):
            self.result = {}

    class TestPlayContext(object):
        def __init__(self):
            self.become = False
            self.become_user = None
            self.become_method = 'sudo'
            self.check_mode = False
            self.prompt = None
            self

# Generated at 2022-06-21 03:21:55.008632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            action=dict(
                module_name="yum",
                args=dict(
                    name=['emacs', 'telnet'],
                    state='installed'
                )
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module is not None

# Generated at 2022-06-21 03:22:02.349996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yum_action_module = ActionModule(
        task=dict(args=dict(name=["firefox"], state="present", use_backend="yum4"), async_val=None,
                  templar=None, delegate_to=None))
    assert yum_action_module.run(
        tmp=None, task_vars=dict(ansible_pkg_mgr="yum")
    ) == {
        '_ansible_no_log': False,
        'changed': False,
        'msg': '',
        'results': ['firefox is already installed'],
    }

# Generated at 2022-06-21 03:22:05.466587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionBase
    actionBase = ActionBase()

    # Create an instance of class ActionModule
    actionModule = ActionModule(actionBase._task, actionBase._connection, actionBase._play_context, actionBase._loader, actionBase._templar, actionBase._shared_loader_obj)
    assert actionModule is not None

# Generated at 2022-06-21 03:22:14.520630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule.__class__.__name__ == "ActionModule"

# Generated at 2022-06-21 03:22:16.519066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of the class under test
    module = ActionModule()
    assert module._supports_check_mode
    assert module._supports_async

# Generated at 2022-06-21 03:22:26.171883
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class test_args:

        def __init__(self):
            self.use = 'auto'
            self.name = 'vim'

    class test_task:

        def __init__(self):
            self.args = test_args()

    class test_connection:

        def __init__(self):
            self._shell = test_shell()

    class test_shell:

        def __init__(self):
            self.tmpdir = '/tmp'

    class test_module_loader:

        def __init__(self):
            self.has_plugin = lambda x: True

    class test_loader:

        def __init__(self):
            self.module_loader = test_module_loader()


# Generated at 2022-06-21 03:22:26.726757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-21 03:22:34.528768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case to test if the backend is auto
    #  setup the variables
    action = ActionModule({}, {}, {})
    action._task = {
        'args': {'use_backend': 'auto'}
    }
    action._templar = {
        'template': lambda x: action._task['args']['use_backend']
    }
    assert action._task['args']['use_backend'] == 'auto'

    #  result should have the backend yum3
    result = action.run(None, None)
    assert 'ansible_facts' in result
    assert isinstance(result.get('ansible_facts', {}).get('pkg_mgr','auto'), str)

    # test case to test if the backend is yum3
    #  setup the variables
    action = ActionModule

# Generated at 2022-06-21 03:22:39.022659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make an object of class ActionModule
    action_module_obj = ActionModule()
    # Finding parent class object using __base__
    action_base_obj = action_module_obj.__class__.__base__
    # Inheritance test
    assert action_base_obj in action_module_obj.__class__.__bases__

# Generated at 2022-06-21 03:22:48.945712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, None)

    # test valid backend module names
    assert am._run({"use": "yum"}, None) == am._run({"use_backend": "yum"}, None)
    assert am._run({"use": "yum4"}, None) == am._run({"use_backend": "yum4"}, None)
    assert am._run({"use": "dnf"}, None) == am._run({"use_backend": "dnf"}, None)

    # test 'use' and 'use_backend' as mutually exclusive params
    try:
        am._run({"use": "yum", "use_backend": "yum"}, None)
        assert False
    except AnsibleActionFail:
        pass

    # test 'use' and 'use_backend' as mutually exclusive params

# Generated at 2022-06-21 03:22:59.407466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 03:22:59.843836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:23:09.809779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    module_path = os.path.join(tmpdir, 'ansible/plugins/actions')

    loader = DictDataLoader({})
    c = Connection(module_path=module_path)
    p = PluginLoader('./plugins', 'action',  None, connection=c)
    tqm = None

    t = Task(
        dict(action=dict(__ansible_action__=ActionModule)),
        task_loader=loader,
        connection=c,
        play_context=PlayContext(),
        loader=loader,
        shared_loader_obj=p,
        tmpdir=tmpdir,
    )

    shutil.rmtree(tmpdir)
    return t

# Generated at 2022-06-21 03:23:24.404174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule(None, {}), 'run')

# Generated at 2022-06-21 03:23:28.628630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 03:23:38.147924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    hostname = "host.example.org"
    connection = mock.MagicMock()
    connection.host = "host.example.org"
    loader = mock.MagicMock()
    variable_manager = mock.MagicMock()
    data = dict(action=dict(module='yum', args=dict()))
    task = mock.MagicMock()
    task.args = dict()
    task.async_val = False
    task.delegate_to = None
    task.delegate_facts = False
    task._role = None
    play_context = mock.MagicMock()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = hostname

# Generated at 2022-06-21 03:23:47.387018
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # replace os.isatty with the mock method
    def mock_isatty(fd):
        return False

    mock_module = type('module', (object,), {'__file__': __file__})()
    mock_module.ANSIBLE_MODULE_ARGS = {'use_backend': 'yum'}

# Generated at 2022-06-21 03:23:48.575927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule.'''
    data = {}

# Generated at 2022-06-21 03:23:56.470181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {'use': 'auto'}
    module._task.delegate_to = None
    module._task.delegate_facts = True
    module._task.async_val = None
    task_vars = {}
    module._templar = None
    module._shared_loader_obj = None
    
    result = module.run(tmp=None, task_vars=task_vars)
    assert result['ansible_facts']['pkg_mgr'] == 'yum4'

# Generated at 2022-06-21 03:24:06.019166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_provider


# Generated at 2022-06-21 03:24:07.155460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    assert True

# Generated at 2022-06-21 03:24:09.333640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 03:24:15.133004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit Test for method run of class ActionModule
    '''
    _task = {}
    _task['action'] = 'yum'
    _task['args'] = {}
    _task['async_val'] = False 
    _task['async_status'] = None
    _task['delegate_to'] = None
    _task['delegate_facts'] = False

    _connection = 'localhost'
    _tmp = '/tmp'
    _task_vars = {}

    am = ActionModule(_task, _connection, _tmp)
    am.run(_tmp, _task_vars)

# Generated at 2022-06-21 03:24:51.261385
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:24:58.207702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ast

    action_module = ActionModule()

    # Test validate_use_backend_yum3_yum4_with_use
    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum'
        }
    }

# Generated at 2022-06-21 03:25:09.635065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''


# Generated at 2022-06-21 03:25:18.733779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest

    mock_task = MagicMock(spec=dict)
    mock_task.args = {
        'name': "httpd",
        'state': "latest",
        }
    mock_task.async_val = 0

    mock_display = MagicMock(spec=Display)

    mock_loader_obj = MagicMock(spec=dict)
    mock_loader_obj.module_loader = MagicMock(spec=dict)
    mock_loader_obj.module_loader.has_plugin.return_value = True

    mock_connection = MagicMock(spec=dict)
    mock_connection._shell = MagicMock(spec=dict)
    mock_connection._shell.tmpdir = "/tmp/tmp_path"

    mock_install_handler = MagicMock(spec=dict)


# Generated at 2022-06-21 03:25:29.926369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display = Display()
    import re
    import ast
    test_action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_action._task.args = {'name': ['zsh'], 'state': 'absent'}
    test_action._task.args = {'use_backend': 'auto'}
    test_action._task.args = {'name': ['zsh'], 'state': 'absent'}
    test_action._task.args = {'use_backend': 'yum4', 'name': ['zsh'], 'state': 'absent'}

    pkg_mgr = {"changed": False, "ansible_facts": {"pkg_mgr": "yum4"}}

# Generated at 2022-06-21 03:25:32.018482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' test_actionmodule_run.py: Unit test for method run of class ActionModule '''

    # TODO: Test needs to be implemented

# Generated at 2022-06-21 03:25:38.487124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_actionModule = ActionModule()
    def _execute_module(module_name=None, module_args=None, task_vars=None, wrap_async=False):
        return  {
            'failed': False,
            'msg': "working",
            'changed': True,
        }

    test_actionModule._execute_module = _execute_module
    result = test_actionModule.run(None, None)
    assert result ==  {
            'failed': True,
            'msg': ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                    "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})"),
        }


# Generated at 2022-06-21 03:25:45.084893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            args=dict(
                use_backend='dnf',
                name="httpd",
                state="present",
            ),
            async_val="0",
            delegate_to="127.0.0.1",
            delegate_facts="True",
        ),
        connection=dict(cur_path_bytes='/tmp', cur_lang='en'),
        task_vars=dict(
            ansible_facts=dict(pkg_mgr="dnf", ansible_pkg_mgr="dnf"),
        ),
        templar=None,
        shared_loader_obj=None,
    )

    module.run()

# Generated at 2022-06-21 03:25:53.552988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.six import PY3

    action_module_obj = ActionModule()
    try:
        if PY3:
            assert action_module_obj.run(tmp=None, task_vars=None)
        else:
            action_module_obj.run(tmp=None, task_vars=None)
    except Exception:
        pass

    # Assert PY3 Exception
    if PY3:
        with pytest.raises(AnsibleActionFail) as excinfo:
            action_module_obj.run(tmp=None, task_vars=None)
        assert "parameters are mutually exclusive: ('use', 'use_backend')" in str(excinfo.value)

# Generated at 2022-06-21 03:25:56.023422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._connection._shell.tmpdir == "/tmp"
    assert a.TRANSFERS_FILES == False
    assert a._supports_check_mode == True
    assert a._supports_async == True

# Generated at 2022-06-21 03:26:47.559901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:26:55.430346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            args=dict(
                use="yum",
                list=dict(
                    state="installed",
                ),
            ),
            async_val=True,
            delegate_to="localhost",
            delegate_facts=True,
        ),
        connection=dict(
            _shell=dict(tmpdir="/tmp"),
        ),
        templar=dict(),
        loader=dict(
            has_plugin=lambda _:True,
        ),
        shared_loader_obj=dict(
            module_loader=dict(
                has_plugin=lambda _:True,
            ),
        ),
    )

    assert module.run(task_vars=dict())


# Generated at 2022-06-21 03:27:00.864862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Starting test_ActionModule_run")
    fail_msg = "Test failed with exception"
    display = Display()
    try:
        # instantiate module
        am = ActionModule(None, display)
        # create module args
        args = dict(name='httpd', state='latest')
        results = am.run(None, args)
        assert results['failed'] == False
    except Exception as e:
        print("Exception during test_ActionModule_run: %s" % e)
        assert False, fail_msg
    print("Test complete")

# Generated at 2022-06-21 03:27:03.745211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name='yum',
                              module_args=dict(name='kde-l10n-Chinese', state='present'))))

# Generated at 2022-06-21 03:27:04.191001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:27:10.035080
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:27:18.551431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing empty values for arguments of method run of class ActionModule and calling it.
    # This should return status False and msg "Could not detect which major revision of yum is in use, which is required to determine module backend. You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend"
    status = ActionModule.run(ActionModule, None, None)
    msg = status.get("msg")
    assert msg[0] == "Could not detect which major revision of yum is in use, which is required to determine module backend." and msg[1] == "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend"

    # Initializing empty values for arguments of method run of class ActionModule and

# Generated at 2022-06-21 03:27:20.329750
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # noqa
    '''Unit test for method run of class ActionModule'''
    pass  # TODO: Implement. Not necessary for automated testing

# Generated at 2022-06-21 03:27:28.637311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    s = ("parameters are mutually exclusive: ('use', 'use_backend')")
    t = ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
         "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend")
    u = "Could not find a yum module backend for"
    for a in [s, t, u]:
        assert a in ActionModule.run('')

# Generated at 2022-06-21 03:27:29.793146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._task.args == dict()

# Generated at 2022-06-21 03:29:18.016885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test the method run of class ActionModule"""

    def execute_module(*args, **kwargs):
        return {}

    class DataHolder:
        pass

    data = DataHolder()
    data.task_vars = {}
    data.execute_module = execute_module

    class TaskHolder:
        pass

    task = TaskHolder()
    task.async_val = None
    task.args = {}
    task.async_val = "test_async_val"

    class TestActionModule(ActionModule):
        def _execute_module(self, *args, **kwargs):
            return data.execute_module(*args, **kwargs)

    result = TestActionModule(task, data).run(task_vars=data.task_vars)


# Generated at 2022-06-21 03:29:22.643124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule."""
    if __name__ == '__main__':
        import json
        import shlex
        tmp = "/tmp"
        task_vars = {"ansible_facts": {"pkg_mgr": "auto"}}
        args = shlex.split("")
        test_action_module = ActionModule({"args": args}, tmp, task_vars)

# Generated at 2022-06-21 03:29:32.066119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(
            args=dict(
                ansible_facts=dict(pkg_mgr="dnf"),
                delegate_to="test_delegate_to_hostname",
                delegate_facts=False,
                use_backend=True,
                use="yum",
                ),
            async_val='async_val',
            delegate_to='delegate_to',
            delegate_facts='delegate_facts',
            vars=dict(),
        ),
        connection=dict(
            _shell=dict(tmpdir='/tmp'),
        ),
        _templar=dict(),
        _shared_loader_obj=dict(
            module_loader=dict(
                has_plugin=lambda module: True
            ),
        ),
    )

    # Tests are still being

# Generated at 2022-06-21 03:29:34.070161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:29:39.467633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def execute_module(module_name, module_args, task_vars):
        module_backend = {'failed': True,
                          'msg': "Could not find a yum module backend for ansible.legacy.yum."}
        return module_backend

    display = Display()
    # mock the display object
    def vvvv(msg):
        pass
    display.vvvv = vvvv

    # mock templar.template
    def template(template, **kwargs):
        return "yum"

    # mock _execute_module method
    class _execute_module:
        def __init__(self, module_name, module_args, task_vars, wrap_async):
            pass
    ActionModule._execute_module = _execute_module

    # mock the execute_module method
    Action

# Generated at 2022-06-21 03:29:50.058905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # make a fake module
    module = ActionModule(
        task=dict(name='foo', args={}),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # make a fake set of results
    results = dict(
        ansible_facts=dict(pkg_mgr='yum'),
        changed=False,
        failed=True,
        )

    # make a fake execute_module
    i = 0
    def execute_module(module_name, module_args, task_vars=None, wrap_async=None):
        nonlocal i
        i += 1
        if i == 1:
            assert module_name == 'ansible.legacy.yum'
            return results

# Generated at 2022-06-21 03:29:56.412292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare names for parameters and attributes of object ActionModule
    a_module = "ansible.legacy.yum"
    tmp = None
    task_vars = [
        "{{ansible_facts.pkg_mgr}}",
        "{{ansible_facts.pkg_mgr}}",
        "{{hostvars['%s']['ansible_facts']['pkg_mgr']}}" % a_module
    ]
    side_effect = [
        Exception,
        "yum3",
        "yum3"
    ]
    # Declare and initialize the object ActionModule
    action_module = ActionModule()

    # Mock methods and attributes of object action_module

# Generated at 2022-06-21 03:29:58.873064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 03:30:08.530886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """

    module = ActionModule(
        {
            'name': 'foo',
            'args': {},
            'async': 1,
            'async_val': None
        },
        loader=None,
        shared_loader_obj=None,
        path_loader=None,
        templar=None,
        atoms_loader=None
    )

    result = module.run(tmp=None,task_vars=None)

    assert(result['failed']==True)
    assert(result['msg'][0] == "Could not detect which major revision of yum is in use, which is required to determine module backend.")

# Generated at 2022-06-21 03:30:10.881287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_path = "/path/to/dir/"
    yum = create_ansible_mock(ActionModule)
    yum._execute_module = ActionBase._execute_module
    yum.run(my_path)