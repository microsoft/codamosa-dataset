

# Generated at 2022-06-21 03:21:14.400913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:24.491725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # define the data used to construct the action
    # this data is the same data that is normally provided by the ansible engine
    # when run in a playbook
    task = {"action": "yum", "args": {"name": "openssl"}}
    task_vars = {"ansible_facts": {"pkg_mgr": "auto"}}
    display = Display()
    connection = Connection()
    connection._shell = Shell()
    connection._shell.tmpdir = "/tmp/test-module"

    # construct the action module
    yma = ActionModule(task=task, connection=connection, task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)
    yma._task.async_val = False

    # run the action module
    result = yma.run()

   

# Generated at 2022-06-21 03:21:27.805905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display.debug("Unit test for method run of class ActionModule.")
    x = ActionModule(loader=None, connection=None, _play_context=None, 
                    task=None, shared_loader_obj=None)
    x.run("tmp", "task_vars")
    display.debug("\nUnit test for method run of class ActionModule finished.")

# Generated at 2022-06-21 03:21:38.435725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', use='yum3', conf_file='/foo.conf')),
        connection=dict(module_name='shell'),
        play_context=dict(diff=False, check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    action_module._task.delegate_to = None
    action_module._task.delegate_facts = False

    result = action_module.run(tmp=None, task_vars={})

    # assert key of 'failed'
    assert 'failed' in result
    # assert key of 'changed'
    assert 'changed' in result
    # assert value of 'changed' is False
    assert result['changed'] is False
    #

# Generated at 2022-06-21 03:21:41.731106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create the target object
    am = ActionModule()

    # Assert our target creates the expected object
    assert am.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))

# Generated at 2022-06-21 03:21:50.113686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    import pytest

    loader = DataLoader()
    group = Host(name="all")
    group.vars = HostVars(hostname="localhost", ansible_facts={})
    inventory = InventoryManager(loader=loader, sources=["localhost"])

# Generated at 2022-06-21 03:21:55.504844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define arguments for the constructor to test
    args = {'use_backend': 'auto', 'use': 'auto', 'name': 'test_name'}
    # Instantiate an object for the class to test
    obj = ActionModule(args)
    # Run assertion to determine if the result obtained is as expected
    assert obj._task.args['use'] == 'auto'

# Generated at 2022-06-21 03:22:04.424038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.connection import ConnectionBase
    from ansible.inventory.host import Host
    from ansible.plugins.loader import action_loader, connection_loader

    class MockVarsModule:
        def __init__(self, setup_result):
            self.FAILED_RESULT = {}
            self.SUCCESS_RESULT = setup_result

        def fail_json(self, *args, **kwargs):
            return self.FAILED_RESULT

        def exit_json(self, *args, **kwargs):
            return self.SUCCESS_RESULT


# Generated at 2022-06-21 03:22:12.915735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1st test : plugin 'use' parameter is set
    # 1st test 1st subtask : 'use' parameter is set to 'yum'
    # 1st test 1st subtask 1st assert
    m_result = dict()
    m_result.update({'failed': False, 'msg': '', 'module_args': {'use': 'yum'}})
    # 1st test 1st subtask 2nd assert
    m_result.update({'changed': False, 'msg': ''})
    # 1st test 2nd subtask : 'use' parameter is set to 'dnf'
    # 1st test 2nd subtask 1st assert
    m_result.update({'failed': False, 'msg': '', 'module_args': {'use': 'dnf'}})
    # 1st test 2nd subtask 2

# Generated at 2022-06-21 03:22:14.907040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ == '''Action plugin handler for yum3 vs yum4(dnf) operations.'''

# Generated at 2022-06-21 03:22:22.409405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _ = ActionModule(None, None, None)

# Generated at 2022-06-21 03:22:31.327935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    import json

    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.json import to_json

    task_vars = dict()

    # test good case
    module_args = json.loads(to_json(dict(name="vim", state="installed", use="yum")))
    set_module_args(module_args)
    task_vars['ansible_facts'] = dict()
    output = StringIO()
    task = ActionModule(task_vars=task_vars)
    result = task.run(task_vars=task_vars)
    assert result['failed']

# Generated at 2022-06-21 03:22:38.076113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.module_utils.basic import AnsibleModule

    task_args = dict(name='ansible', state='latest', use='yum3')
    task_vars = dict(ansible_pkg_mgr='yum3')
    inject = dict(task_vars=task_vars)

    am = ActionModule(task=dict(args=task_args, async_val=42), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:22:48.197350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule

    # Inject mocks
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    class MockTask:
        def __init__(self, args={}, delegate_to='', delegate_facts=False, async_val=0):
            self.args = args
            self.delegate_to = delegate_to
            self.delegate_facts = delegate_facts
            self.async_val = async_val

    # Test with args 'auto', backends dnf and yum
    variable_manager = VariableManager()

# Generated at 2022-06-21 03:22:58.846597
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def runner(module, task_vars):
        import ansible.plugins.action.yum as yum
        action = yum.ActionModule(
            {
                "use": module,
                "_ansible_verbosity": 3,
                "ignore_errors": True,
                "playbook_dir": '/playbook/dir'
            },
            0, {})
        am = yum.ActionBase(action._shared_loader_obj,
                            action._connection,
                            '/playbook/path',
                            action._play_context,
                            action._loader,
                            action._templar,
                            action._task._role)

        am.am_running_on_delegate = True
        return am.run(None, task_vars)

    # Test non-delegate/non-auto run()

# Generated at 2022-06-21 03:23:04.374735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.play_iterator import PlayIterator
    import ansible
    import json
    import unittest
    import mock

    # create the mock class to replace our Executor's run.

# Generated at 2022-06-21 03:23:05.213760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:23:08.803252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    module = ActionModule(connection=None, task_vars=dict(), loader=None)
    assert module.run(tmp=None, task_vars=dict()) is not None

# Generated at 2022-06-21 03:23:12.370119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.yum import ActionModule
    mod = ActionModule()
    assert mod.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))
    try:
        mod.run()
    except Exception as e:
        assert False, "ActionModule.run() threw an exception: %r" % e

# Generated at 2022-06-21 03:23:20.019624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_list = ['localhost', 'test.example.com', '10.1.2.3']
    ma = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert ma
    assert hasattr(ma, 'run') == True
    assert ma._task is None
    assert ma._connection is None
    assert ma._play_context is None
    assert ma._loader is None
    assert ma._templar is None
    assert ma._shared_loader_obj is None


# Generated at 2022-06-21 03:23:44.101762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_path = os.path.join(fixture_path, 'unsupported/detect_yum.yml')
    mock_runner_obj = create_mock_runner(fixture_path, task_vars={'ansible_facts': {'pkg_mgr': 'yum'}})
    task_vars = get_task_vars(mock_runner_obj)
    action_obj = ActionModule(mock_runner_obj, task_vars=task_vars)

    # action module returns result in a dictionary
    result = action_obj.run(task_vars=task_vars)

    assert result.get('msg') == ('Could not detect which major revision of yum is in use, which is required to determine module backend.',)
    assert result.get('failed') == True

# Generated at 2022-06-21 03:23:54.655363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock input
    module = "yum"
    tmp = "ansible_temp_dir"
    task_vars = {}
    tmp = "ansible_temp_dir"

    class Display:
        def __init__(self):
            self.display = ""
        def debug(self, value):
            return
        def vvvv(self, value):
            return

    display = Display()

    class Task:
        def __init__(self):
            self.args = {'use': module, 'present': 'Foo'}
            self.async_val = "1"
            self.delegate_to = ""
            self.delegate_facts = False

    class Plugins:
        def __init__(self):
            self.module_loader = ""


# Generated at 2022-06-21 03:24:04.365864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_result = {
        'parsed': True,
        '_ansible_no_log': False,
        '_ansible_verbose_always': True,
        '_ansible_parsed': True,
        '_ansible_no_log_values': ['redacted'],
        'failed': True,
        'msg': ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})"),
    }

    # test_result1 is when module is set to auto

# Generated at 2022-06-21 03:24:08.120925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except Exception as e:
        print('ActionModule constructor test failed with error %s ' % str(e))
        assert False


# Generated at 2022-06-21 03:24:15.750282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Checks if all possible combinations of the use and use_backend
    parameters are working
    '''
    module_args = {'use': 'yum4', 'name': 'git'}
    # always use the fixture loader
    loader_fixture = 'ansible-base.plugins.action.yum.loader_fixture'  # pylint: disable=invalid-name
    task = {'async': 10, 'args': module_args}
    display_mock_fixture = 'ansible-base.plugins.action.yum.display_mock_fixture'  # pylint: disable=invalid-name


# Generated at 2022-06-21 03:24:20.331782
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    yum_action_mod = ActionModule()

    yum_action_mod._connection = MockConnection()
    yum_action_mod._task = MockTask()
    yum_action_mod._loader = MockLoader()
    yum_action_mod._step = MockStep()
    yum_action_mod._play_context = MockPlayContext()
    yum_action_mod._shared_loader_obj = MockSharedLoaderObj()

    assert yum_action_mod.run(task_vars={}) == {
        'failed': False,
        'msg': 'successfully ran'
    }

# Mock class for Connection

# Generated at 2022-06-21 03:24:31.881797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Unit test for method run of class ActionModule")
    tmp = False
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}
    action_module = ActionModule(
        task=dict(args=dict(use_backend='auto')), tmp=tmp, task_vars=task_vars)
    result = action_module.run(tmp, task_vars)
    print("Result: %s" % result)
    if result['ansible_facts']['pkg_mgr'] == 'yum':
        print("Unit test for method run of class ActionModule passed")
    else:
        print("Unit test for method run of class ActionModule failed")


# Generated at 2022-06-21 03:24:32.315810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:24:34.045435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 03:24:36.317529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am is not None

# Generated at 2022-06-21 03:25:10.880534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args = {'use': 'auto', 'use_backend': 'auto'}
    assert(ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None).run(task_vars={'ansible_pkg_mgr': 'auto'}))
    assert(ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None).run(task_vars={'ansible_pkg_mgr': 'yum'}))

# Generated at 2022-06-21 03:25:19.599853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    mock_module_utils_basic = Mock()
    module_res = dict(
        failed=False,
        msg="msg",
        rc=0
    )
    mock_module_utils_basic.AnsibleModule = Mock(return_value=module_res)

    _mock_ansible_module = Mock()
    _mock_ansible_module.params = dict()

    import ansible.plugins.action.yum


# Generated at 2022-06-21 03:25:21.523204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    action_module_obj = ActionModule()
    assert action_module_obj._supports_check_mode is True
    assert action_module_obj._supports_async is True


# Generated at 2022-06-21 03:25:32.816920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleActionFail
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils import basic
    import ansible.modules.package_manager.dnf.params


    # mock the Display class
    Display = Display
    mocked_display = Display()
    mocked_display.debug = Display.debug
    mocked_display.vvvv = Display.vvvv
    mocked_display.v = Display.v
    mocked_display.warning = Display.warning


    task_vars = dict(pkg_mgr='yum')


# Generated at 2022-06-21 03:25:37.722535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task={"action": {"__ansible_module__": "yum"}},
                          connection={"_shell": {"tmpdir": "/tmp"}},
                          loader={"module_loader": {"has_plugin": lambda x: True}},
                          templar={"template": lambda x: "yum"},
                          shared_loader_obj={"module_loader": {"has_plugin": lambda x: True}})
    assert action.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 03:25:46.532575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock the ActionBase._execute_module method
    import sys
    import mock
    #sys.modules['ansible.plugins.action.ActionBase'] = mock.Mock(ActionBase)
    # sys.modules['ansible.plugins.action'] = mock.Mock(ActionBase)
    sys.modules['ansible.legacy.yum'] = mock.Mock()
    sys.modules['ansible.legacy.dnf'] = mock.Mock()

    import json
    def mock_prepare_writeable_dir(self, dirname):
        print(dirname)
        return '/tmp'


# Generated at 2022-06-21 03:25:48.276719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.VALID_BACKENDS == ('yum', 'yum4', 'dnf')
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:25:49.612067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, {}, {}, None)
    assert module is not None

# Generated at 2022-06-21 03:25:57.170606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-21 03:25:57.641748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:26:45.383424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:26:53.955132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    import ansible.modules.packaging.yum
    module_tmp_path = ansible.modules.packaging.yum.__file__.replace('__init__.py', '')
    playbook_path = "./test/integration/ansible-test-inventory/test_playbooks/"

    am = ActionModule(task=dict(args=dict()), play_context=None, new_stdin=None)

# Generated at 2022-06-21 03:27:02.377462
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test with valid inputs
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp'
    module = ActionModule(connection=connection, task_vars=dict(ansible_pkg_mgr='yum'))
    facts = module._execute_module(module_name='ansible.legacy.setup', module_args=dict(filter='ansible_pkg_mgr', gather_subset='!all'), task_vars=dict())

    new_module_args = dict()
    new_module_args['name'] = ['nginx']
    new_module_args['state'] = 'present'

    result = module.run(task_vars=dict(ansible_pkg_mgr='yum'))
    assert result['ansible_facts'] == {'pkg_mgr': 'yum'}

   

# Generated at 2022-06-21 03:27:02.934123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:27:04.160785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(runner=None)
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:27:10.733717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the run method of class ActionModule
    """
    tmp = None
    task_vars = None

    action_module = ActionModule()
    result = action_module.run(tmp, task_vars)

    assert result['failed']
    assert result['msg'] == "Could not detect which major revision of yum is in use, which is required to determine module backend. You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend"

# Generated at 2022-06-21 03:27:18.775739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hosts = [{'ansible_connection': 'smart', 'ansible_user': 'user'}]
    tasks = [{'yum': {'name': 'Package', 'state': 'absent', 'use_backend': 'yum3'}}]
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum4'}}
    action = ActionModule(tasks[0], hosts[0], None)
    result = action.run(None, task_vars)
    assert result.get('failed') == False
    assert result.get('msg') == None
    assert result.get('ansible_facts').get('pkg_mgr') == 'yum4'

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 03:27:19.412181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:27:20.970318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common._collections_compat import Mapping
    assert issubclass(ActionModule, Mapping)

# Generated at 2022-06-21 03:27:24.864248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_plugin = ActionModule(None, dict(name='action_plugin'),
                                 dict(task=dict(args=dict(name='test_name'))))
    assert action_plugin.run()

# Generated at 2022-06-21 03:29:04.452415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert action_module
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-21 03:29:12.045392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test:
    #  - Only accepts kwargs for args
    #  - Sets instance vars from kwargs
    #  - Sets instance vars from entry_point
    action = ActionModule(action_args=dict(name="test", test=1), action_entry_point_args=dict(name="entry_point"))

    assert action._task.args.get('name', 'action') == 'test'
    assert action._task.args.get('test', 'action') == 1
    assert action._task.entry_point.get('name', 'action') == 'entry_point'
    assert action._task.action._shared_loader_obj is None

# Generated at 2022-06-21 03:29:13.086618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert action.run() == {}

# Generated at 2022-06-21 03:29:15.965788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test the constructor of ActionModule class")
    action_mod = ActionModule(action_name="yum", task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_mod._task.action == "yum"


# Generated at 2022-06-21 03:29:25.024908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile

    from ansible.errors import AnsibleActionFail
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.utils.display import Display

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a task result object.
    task_result = TaskResult(host=None, task=None, return_data=dict())

    # Create a object for the action plugin module.
    action_module = ActionModule(
        task=None, connection=None, _play_context=None, loader=None, templar=None,
        shared_loader_obj=None
    )

    # Create a object for the AnsibleModule class.
    ansible_module = Ans

# Generated at 2022-06-21 03:29:31.188297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    task = Task()
    task.args = {'use': "auto"}
    task.async_val = 34
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action.run(tmp=None, task_vars=dict(ansible_facts=dict(pkg_mgr="auto")))

# Generated at 2022-06-21 03:29:33.381399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '_execute_module'), "Class ActionModule has no attribute _execute_module"
    assert hasattr(ActionModule, 'run'), "Class ActionModule has no attribute run"

# Generated at 2022-06-21 03:29:34.501196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(None, None)
    assert obj._connection is None
    assert obj._task is None



# Generated at 2022-06-21 03:29:35.658334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(1,2,3,4,5,6)
    assert obj is not None

# Generated at 2022-06-21 03:29:46.051501
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    module = ActionModule('_task.args', '_connection', '_play_context', 'loader', 'templar', '_shared_loader_obj')
    module._task.args = dict(use='yum', name='httpd')
    module._task.async_val = None
    module._task.delegate_facts = None
    module._task.delegate_to = None

    # Execute
    result = module.run()
    assert result['module_name'] == 'ansible.legacy.yum'

    module._task.args = dict(use='dnf', name='httpd')
    result = module.run()
    assert result['module_name'] == 'ansible.legacy.dnf'

    module._task.args = dict(use='auto', name='httpd')
   