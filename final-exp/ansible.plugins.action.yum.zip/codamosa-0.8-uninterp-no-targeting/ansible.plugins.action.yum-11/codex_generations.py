

# Generated at 2022-06-21 03:21:21.560845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    # Test 1: set use to auto, no delegate facts and no delegate to, pkg_mgr to yum
    module = ActionModule()
    module._task = AnsibleTask()
    module._task.args = {'use': 'auto', 'name': 'foo'}  # type: ignore
    module._task.delegate_facts = False
    module._task.async_val = 100
    module._templar = FakeTemplar()
    module._templar.template = Mock(return_value="yum")
    module._execute_module = Mock()
    module._execute_module.return_value = {'failed': False, 'ansible_facts': {'pkg_mgr': 'yum'}}
    result = module.run(None, None)

# Generated at 2022-06-21 03:21:22.997621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(), dict())
    assert isinstance(am, ActionModule)



# Generated at 2022-06-21 03:21:29.978753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from collections import namedtuple
    from ansible.utils.vars import combine_vars

    class MyExecutor:
        def __init__(self):
            self._shell = namedtuple('Shell', ['tmpdir'])('/tmp')
            self._loader = namedtuple('Loader', [])('')

    class MyPlayContext:
        def __init__(self):
            self.connection = MyExecutor()

    class MyTask:
        def __init__(self, args):
            self.async_val = None

# Generated at 2022-06-21 03:21:41.282486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import pytest
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a mock for _execute_module
    def mock_execute_module(module_name, module_args, task_vars=None, wrap_async=None, tmp=None):
        return {"msg": "Ran {}".format(module_name)}

    # Create a mock for _remove_tmp_path
    def mock_remove_tmp_path(path):
        pass

    # Create a temporary playbook file

# Generated at 2022-06-21 03:21:41.858186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:21:45.984365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_args=dict(use='yum'))),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 03:21:52.053577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module="yum", args=dict(name="httpd", state="present", use="yum4")))
    shared_loader_obj = None
    def _load_name_to_path_mapping():
        return {'ansible.legacy.yum4': 'ansible/legacy/plugins/modules/yum4.py'}
    action_base_obj = ActionBase(task, shared_loader_obj, _load_name_to_path_mapping, None)
    obj = ActionModule(task, shared_loader_obj, action_base_obj)

# Generated at 2022-06-21 03:21:56.746838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(None, {})
    assert a.run({}, {'ansible_facts': {'pkg_mgr': 'yum'}}) == {
        'changed': False,
        'failed': False,
        'ansible_facts': {'pkg_mgr': 'yum'}
    }

# Generated at 2022-06-21 03:22:04.864355
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:22:08.050625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(args=dict()),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None) is not None

# Generated at 2022-06-21 03:22:17.757679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task.args = {}
    action_module._task.async_val = False
    action_module._shared_loader_obj = None
    action_module._connection = None
    action_module._execute_module = None
    action_module._remove_tmp_path = None
    action_module._templar = None

    assert action_module.run() == {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend."}
    assert action_module._task.async_val == False

# Generated at 2022-06-21 03:22:21.212783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None)
    assert module._shared_loader_obj is None
    assert module._task is None
    assert module._connection is None
    assert module._play_context is None
    assert module._loader is None
    assert module._templar is None

# Generated at 2022-06-21 03:22:22.077861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test logic of ActionModule._run()
    pass

# Generated at 2022-06-21 03:22:30.942801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeModule:
        def __init__(self):
            self.argument_spec = {}
            self.supports_check_mode = True
            self.supports_async = True
            self.connection = FakeModule()
            self.connection.become = FakeModule()
            self.connection.become.exe_command = 'become_method'
            self.set_options = FakeModule()
            self.set_options.run_command = 'run_command'
            self.remove_tmp_path = FakeModule()
            self.remove_tmp_path.run_command = 'remove_tmp_path'

    class FakeExecutorObj:
        def __init__(self):
            self.module_loader = FakeModule()
            self.module_loader.has_plugin = FakeModule()

# Generated at 2022-06-21 03:22:37.126202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    hostvars = dict()
    task_vars['hostvars'] = hostvars
    hostvars = dict(ansible_pkg_mgr='dnf')
    tmp = '/tmp'
    action = ActionModule(
        task=dict(
            args=dict(
                use='dnf',
            ),
        ),
        connection=dict(
            _shell=dict(
                tmpdir='/tmp',
            ),
        ),
        task_vars=task_vars,
    )
    result = action.run(tmp, task_vars)
    assert result['failed'] == False

# Generated at 2022-06-21 03:22:37.827160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 03:22:47.949868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.plugins.loader import shared_loader_obj

    local_facts = Facts(dict(ansible_pkg_mgr='auto'))
    task_vars = dict(ansible_facts=local_facts.get_facts())

    module = ActionModule(dict(use='auto'),
                          shared_loader_obj=shared_loader_obj,
                          task_vars=task_vars)

    result = module.run(task_vars=task_vars)
    assert result

    module = ActionModule(dict(use_backend='auto'),
                          shared_loader_obj=shared_loader_obj,
                          task_vars=task_vars)

    result = module.run(task_vars=task_vars)
    assert result

# Generated at 2022-06-21 03:22:52.976469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    facts = {
        "ansible_facts": {
            "pkg_mgr": "dnf"
        }
    }
    result = action_module.run(facts)
    assert result.get('failed') == True
    assert result.get('msg') == "parameters are mutually exclusive: ('use', 'use_backend')"

# Generated at 2022-06-21 03:22:55.994919
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    assert module is not None
    assert module.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))


# Generated at 2022-06-21 03:22:57.714927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:23:13.771568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the run function of class ActionModule.
    """
    module = ActionModule(
        task=dict(action=dict(module_name='yum', module_args=dict(state='installed', name='zsh'))),
        connection=None, task_vars=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )
    module.run()

# Generated at 2022-06-21 03:23:14.689275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(Task(), Connection(), PlayContext())

# Generated at 2022-06-21 03:23:26.502446
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_action = ActionModule(
        task=dict(action=dict(module_name='yum', args=dict(name='foo'))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        share_loader_obj=dict()
    )

    mock_execute_module = mock_action._execute_module
    with patch.object(ActionBase, '_execute_module') as mock_execute_module:
        mock_execute_module.return_value = dict(failed=False)
        mock_execute_module.return_dict = dict()
        mock_execute_module.return_dict['ansible_facts'] = dict(pkg_mgr='yum')
        assert mock_action.run() == dict(failed=False, pkg_mgr='yum')

# Generated at 2022-06-21 03:23:37.001184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mm = ActionModule(task=dict(args=dict(use='yum')))
    assert mm.run()['msg'] == ("Could not find a yum module backend for yum", "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")
    mm = ActionModule(task=dict(args=dict(use='yum3')))
    assert mm.run()['msg'] == ("Could not find a yum module backend for yum3", "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")
    mm = ActionModule(task=dict(args=dict(use='dnf')))

# Generated at 2022-06-21 03:23:46.839344
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an object of class ActionModule
    action_module = ActionModule()

    class ConnectionMock:
        def _shell_no_block(self, cmd):
            pass

    class TaskMock:
        def __init__(self):
            self.async_val = None
            self.args = {}

    class ModuleLoaderMock:
        def has_plugin(self, module):
            pass

    action_module._shared_loader_obj = ModuleLoaderMock()
    action_module._task = TaskMock()
    action_module._connection = ConnectionMock()

    # Execute run method of class ActionModule with args {'state': 'installed', 'name': 'httpd'} and facts.
    # This should return execution results

# Generated at 2022-06-21 03:23:47.676832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert VALID_BACKENDS

# Generated at 2022-06-21 03:23:54.149737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    connection =  None
    task = None
    task_vars = None
    loader = None
    templar = None

    action = ActionModule(connection=connection,
                          task=task,
                          task_vars=task_vars,
                          loader=loader,
                          templar=templar)

    assert (action.TRANSFERS_FILES == False)

# Generated at 2022-06-21 03:24:03.555640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_mock = ActionModule(task=dict())
    module_mock._shared_loader_obj = Mock()
    module_mock._execute_module = Mock()

    # 1. test case - module explicitly set to yum -> run yum module
    module_mock._task.args = dict()
    module_mock._templar = Mock()
    module_mock._task.args['use'] = 'yum'
    module_mock._shared_loader_obj.module_loader.has_plugin.return_value = True
    module_mock._task.delegate_to = None
    module_mock._task.delegate_facts = False
    module_mock._task.async_val = False

# Generated at 2022-06-21 03:24:06.533198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    target = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert hasattr(target, 'TRANSFERS_FILES')


# Generated at 2022-06-21 03:24:09.418482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()

    # TODO: All tests are not covered. Please add more tests.
    assert action_module_instance.run() == {}

# Generated at 2022-06-21 03:24:39.624014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The following should raise AnsibleActionFail given mutually exclusive parameters are present.
    action = ActionModule(dict(
        use=None,
        use_backend=None,
        name='test',
        args=dict(
            use='yum',
            use_backend='auto'
        )
    ), {})
    assert action.run() is not None
    assert action.run()['failed'] is True
    assert action.run()['msg'] == "parameters are mutually exclusive: ('use', 'use_backend')"

# Generated at 2022-06-21 03:24:41.536523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of ActionModule
    action_module = ActionModule()

    # Check the instance
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 03:24:43.618701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()

    # TODO: mock this up
    pass

# Generated at 2022-06-21 03:24:44.294061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:24:52.566448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module_args = dict(
        name="libssl",
        state="latest",
        use="yum3"
    )
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.run(
        task_vars=dict(
            ansible_facts=dict(pkg_mgr="yum", some_fact="some fact"))
    )
    action_module.run(
        task_vars=dict(
            ansible_facts=dict(pkg_mgr="dnf", some_fact="some fact"))
    )

# Generated at 2022-06-21 03:24:53.688607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('setup', 'localhost', 'root', '', '', 'yum', '', '', '/tmp')
    assert action is not None

# Generated at 2022-06-21 03:25:00.989358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['nginx'])),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module.TRANSFERS_FILES == False
    assert action_module._connection == None
    assert action_module._task == dict(args=dict(name=['nginx']))

# Generated at 2022-06-21 03:25:04.502647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='yum', module_args=dict(name='dummy', state='installed')))
    )

    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:25:05.389872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 03:25:05.881046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:25:55.255028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:26:02.412331
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test the ctor when pkg_mgr is 'auto' and and use_backend is not specified
    test_subject = ActionModule(
        task=dict(
            args=dict(
                name="firefox",
                state="latest",
            )
        ),
        connection=dict(
            hosts=['localhost'],
            vars=dict(ansible_pkg_mgr="yum3")
        )
    )

    assert test_subject.run()['failed'] is False

    # Test the ctor when pkg_mgr is 'auto' and use_backend is 'auto'

# Generated at 2022-06-21 03:26:11.932068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args= {
        'name': 'ansible',
        'use_backend': 'dnf',
        'async': 10,
        'delegate_to': 'remote',
        'delegate_facts': True,
        'cacheonly': False,
        'confirm': False,
        'disable_gpg_check': False,
        'disablerepo': '',
        'enablerepo': '',
        'exclude': '',
        'installroot': ''
    }

# Generated at 2022-06-21 03:26:13.536594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 03:26:19.876974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    module_path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/packaging/os/yum.py')
    if os.path.exists(module_path):
        os.remove(module_path)

    if 'ansible.legacy.yum' in sys.modules:
        del(sys.modules["ansible.legacy.yum"])

    if 'ansible.legacy.dnf' in sys.modules:
        del(sys.modules["ansible.legacy.dnf"])

    if 'ansible.legacy.yum4' in sys.modules:
        del(sys.modules["ansible.legacy.yum4"])


# Generated at 2022-06-21 03:26:28.105367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock objects
    task_vars = "task_vars"
    yum_test = ActionModule()
    yum_test._shared_loader_obj = "loader_obj"
    yum_test._connection = "connection"
    yum_test._connection._shell = "shell"
    yum_test._connection._shell.tmpdir = "tmpdir"
    yum_test._task = "task"
    yum_test._task.args = "args"
    yum_test._task.async_val = None
    yum_test._task.delegate_to = None
    yum_test._task.delegate_facts = True

    # Mock objects for use with the dnf plugin

# Generated at 2022-06-21 03:26:33.708512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {'ansible_pkg_mgr': 'yum'}
    p = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    p._connection = None
    p._templar = None
    p._task = None
    assert p.run(None, task_vars) == {
        'failed': False,
        'changed': False
    }



# Generated at 2022-06-21 03:26:41.719272
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.yum import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Borrowed from test/units/modules/utils/test_module_utils.py#L761-L786
    class TestModule(object):
        ''' this is a test module for AnsibleModule '''
        def __init__(self, argument_spec):
            self.params = AnsibleModule(
                argument_spec=argument_spec,
                supports_check_mode=True
            ).params

    # Borrowed from test/units/modules/utils/test_module_utils.py#L789-L796

# Generated at 2022-06-21 03:26:42.302112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-21 03:26:45.282863
# Unit test for constructor of class ActionModule
def test_ActionModule():
   ac = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:28:25.134767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=1, connection=2, play_context=3, loader=4, templar=5, shared_loader_obj=6)
    assert actionModule is not None

# Generated at 2022-06-21 03:28:33.869098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    import unittest.mock as mock
    from ansible.module_utils.ansible_release import __version__

    from ansible.plugins.action.yum import ActionModule

    action = ActionModule({})
    action._shared_loader_obj = mock.Mock()
    action._execute_module = mock.Mock(return_value=dict())

    action.run(task_vars=dict(ansible_version=dict(full=__version__)))
    # test with no args
    assert action._execute_module.call_count == 0

    class ModuleReturnValues:

        def __init__(self, name):
            self.name = name
            self.args = dict()


# Generated at 2022-06-21 03:28:44.875841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    import ansible.plugins.action.yum as yum

    yum.VALID_BACKENDS = frozenset(('yum', 'yum4', 'dnf'))

    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum'
        }
    }

    tmp = '/tmp/ansible-tmp-1540879271.0-259938791238219'


# Generated at 2022-06-21 03:28:53.153808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test run() of class ActionModule."""
    from ansible.module_utils.facts.system.pkg_mgr import PackageManagerFactCollector
    from ansible.module_utils.facts import FACT_CACHE

    # Cleanup FACT_CACHE
    del FACT_CACHE["ansible_pkg_mgr"]

    # Set the default for PackageManagerFactCollector.
    PackageManagerFactCollector._default_pkg_mgr = 'yum'

    # Get an instance of the class
    action = ActionModule()
    action.connection = None
    action._task = None

    # Test run, with auto detection of package manager
    assert action.run() == {'failed': True, 'msg': "No task specified"}

    # Test run, with explicit 'yum' specification

# Generated at 2022-06-21 03:28:56.753650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.yum as yum_action
    a = yum_action.ActionModule(task={'async': 10, 'delegate_to': 'myhost',
                                      'args': {'use': 'yum4'},
                                      'delegate_facts': True,
                                      'name': 'run a yum or dnf command'})
    assert a.TRANSFERS_FILES == False
    assert a._task.async_val == 10

# Generated at 2022-06-21 03:28:58.699331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None, None, None)
    assert module

# Generated at 2022-06-21 03:29:00.967046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a test object to test the methods
    test = ActionModule()
    # check the result of empty run method, should return an empty
    # dictionary
    assert(test.run() == {})

# Generated at 2022-06-21 03:29:10.447166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # setting up variables for test case
    facts = {
        'pkg_mgr': 'yum'
    }
    module_path = {
        "ansible.legacy.yum": {"path": "$ANSIBLE_MODULE_UTILS"}
    }
    task = {
        "args": {
            'name': 'test-package'
        }
    }
    # loading the ActionModule class for unit testing
    action_loader = ActionModule()
    # setup func
    action_loader.setup(task, connection={})
    # load func
    action_loader._shared_loader_obj.module_loader.modules = module_path
    # run func
    result = action_loader.run(None, {'ansible_facts': facts, '_ansible_no_log': False})
    # assert the result for the

# Generated at 2022-06-21 03:29:17.108911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import unfrackpath

    ansible_facts = {
        'pkg_mgr': 'yum4'
    }

    module_args = {
        'use': 'auto'
    }

    integration_test_data = {
        'tmp': unfrackpath('$ANSIBLE_TMPDIR'),
        'task_vars': {
            'ansible_facts': ansible_facts
        }
    }

    action_module = ActionModule()

    result = action_module._execute_module(
        module_name='ansible.legacy.setup', module_args=dict(filter="ansible_pkg_mgr", gather_subset="!all"),
        task_vars=integration_test_data['task_vars']
    )


# Generated at 2022-06-21 03:29:25.413631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'auto',
        },
    }
    from ansible.plugins.action.yum import ActionModule
    import ansible.module_utils.yum
    import ansible.module_utils.yum4