

# Generated at 2022-06-21 03:21:13.445975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(dict(action=dict(module_name="test", use_backend="yum")))
    assert obj is not None

# Generated at 2022-06-21 03:21:22.811544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import module_loader
    action_module = ActionModule(
        task=dict(args={'state': 'installed'}),
        connection='connection',
        play_context=dict(check_mode=True),
        loader=module_loader,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module._task.args['state'] == 'installed'
    assert action_module._connection == 'connection'
    assert action_module.play_context.check_mode is True


# Generated at 2022-06-21 03:21:29.868517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a dummy ansible.module_utils.basic.Basic class object
    module_utils = Basic(verbosity=False, no_log=False,
                         _ansible_builtin_add_host=None,
                         _ansible_module_named_args=None,
                         _ansible_module_args=None,
                         _ansible_self_args=None)

    # Create a dummy ansible.plugins.action.ActionBase class object
    action_base = ActionBase(connection=None,
                             play_context=None,
                             loader=None,
                             templar=None,
                             shared_loader_obj=None)

    # Create a dummy ansible.playbook.play_context.PlayContext class object
    play_context = PlayContext()

    # Create a dummy ansible.utils.display.Display class

# Generated at 2022-06-21 03:21:33.669395
# Unit test for constructor of class ActionModule
def test_ActionModule():

    yum_action_module = ActionModule()

    assert hasattr(yum_action_module, 'run')
    assert hasattr(yum_action_module, '_execute_module')
    assert hasattr(yum_action_module, '_execute_module')

# Generated at 2022-06-21 03:21:44.306620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.six import string_types
  from ansible.module_utils.six.moves import StringIO

  from ansible.plugins.action.yum import test_support
  from ansible.plugins.action.yum.test_support import (
      get_env_setup, get_test_config, get_test_modules
  )


# Generated at 2022-06-21 03:21:47.682107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert isinstance(module, ActionModule)
    assert isinstance(module, ActionBase)
    assert module.TRANSFERS_FILES is False


# Generated at 2022-06-21 03:21:59.645419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.virtual.yum import YumFactCollector
    from unittest.mock import patch
    from ansible.module_utils._text import to_text

    # Note that this is not a complete simulation of the environment.
    # It is enough for the purposes of testing this method.
    # See test_yum.py for full environment tests

    module_params = dict(name=['ansible'])
    connection_params = dict(diff_peek=('ansible'))
    connection = FakeConnection(connection_params)
    ActionModule = get_ActionModule(connection)

    # Some of the code in the implementation of this method will run on the
    # controller, but we are only testing the remote code, so this part is
    # mocked out:
    tmp = None

# Generated at 2022-06-21 03:22:06.755183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    import re
    import datetime
    import tempfile
    import shutil
    import unittest

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    import ansible.utils.display
    import ansible.utils.template
    import ansible.utils.vars
    import ansible.errors
    import ansible.constants
    import ansible.plugins.action

    class FakeModule(ansible.plugins.action.ActionBase):
        def __init__(self, super_class):
            self.async_val = None
            self._supports_async = None

            self._connection = None
            self._play_context = None
            self._loader = None
            self._tem

# Generated at 2022-06-21 03:22:10.571813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict()
    result = dict()
    result['failed'] = False

    action_module_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    new_result = action_module_instance.run(tmp=None, task_vars=None)

    assert new_result['failed'] == result['failed']

# Generated at 2022-06-21 03:22:11.095624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:22:18.358399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:22:27.563618
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct a mock object for the connection
    connection = MagicMock()

    # Construct a mock object for the action base
    action_base = ActionBase()

    # Construct a mock object for the task
    task = MagicMock()

    # Get a test instance of action module
    action_module = ActionModule(connection, action_base, task)

    # Construct a mock object for the templar
    templar = MagicMock()

    # Inject the mock object into the instance variable
    action_module._templar = templar

    # Construct a mock object for the loader
    loader = MagicMock()

    # Construct a mock object for the shared loader
    shared_loader = MagicMock()

    # Inject the mock object into the instance variable
    shared_loader.module_loader = loader
    action_module._shared_

# Generated at 2022-06-21 03:22:29.918490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module


# Generated at 2022-06-21 03:22:33.470510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name='yum', module_args=dict())),
        connection=dict(),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-21 03:22:35.160224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:22:35.726091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-21 03:22:39.504448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Pass an empty task to the ActionModule::run method.  This is to verify
    the run method executes properly.
    :return:
    """

    import json
    module_args = {"use": "yum"}
    host_vars = {"ansible_pkg_mgr": "yum"}

    mod = ActionModule(task=dict(action=dict(module_args=module_args)), connection=None, play_context=None, loader=None,
                       templar=None, shared_loader_obj=None)

    result = mod.run(task_vars=host_vars)

    display.display(json.dumps(result))

# Generated at 2022-06-21 03:22:46.047884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = None
    runner = None
    shared_loader_obj = None
    task = None
    connection = None
    templar = None
    display = None
    action_plugin = ActionModule(loader=loader, runner=runner, shared_loader_obj=shared_loader_obj, task=task,
                                 connection=connection, templar=templar, display=display)
    assert action_plugin._supports_check_mode is True
    assert action_plugin._supports_async is True

# Generated at 2022-06-21 03:22:53.473438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    :return:
    """
    try:
        # Instatiate ActionModule object
        action_module = ActionModule()
        # Execute run method of ActionModule object
        action_module.run()
        # Check if object is instance of class ActionModule
        assert isinstance(action_module, ActionModule)
        # Check if result is not None
        assert action_module.run() is not None
    except Exception:
        # AssertionError if object not instance of class ActionModule
        assert isinstance(action_module, ActionModule)
        # AssertionError if result is None
        assert action_module.run() is not None
    else:
        print('Success: test_ActionModule')


# Generated at 2022-06-21 03:22:58.327677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'use': 'yum'}
    action = ActionModule(dict(module_args=module_args), dict(action='yum', module_name='yum'))
    action.setup_task()
    # Can't verify output because these are functions that can't be run in unittests

# Generated at 2022-06-21 03:23:11.877844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure that the constructor is non-private
    action_plugin = ActionModule('/tmp', 'yum')
    assert action_plugin is not None

# Generated at 2022-06-21 03:23:22.689563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule({}, {}, 'delegate_to')
    action_plugin._task.args = {'use': 'auto'}

    # Testing the yum3 and yum4(dnf) auto-detection
    actual_result = action_plugin.run({}, {'ansible_facts': {'pkg_mgr': 'yum'}})
    expected_result = {'ansible_facts': {'pkg_mgr': 'yum'}}
    assert actual_result == expected_result

    actual_result = action_plugin.run({}, {'ansible_facts': {'pkg_mgr': 'dnf'}})
    expected_result = {'ansible_facts': {'pkg_mgr': 'dnf'}}
    assert actual_result == expected_result

    # Testing the invalid module name

# Generated at 2022-06-21 03:23:31.118115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the defaults
    module = ActionModule()
    assert module._supports_async == True
    assert module._supports_check_mode == True
    module._supports_check_mode = False
    module._supports_async = False
    # Test if the modules are set correctly.
    assert module._supports_async == False
    assert module._supports_check_mode == False

    # Test for run
    module._task.args = {}
    module._task.delegate_to = None
    module._task.delegate_facts = None
    tmp = None
    task_vars = None
    result = module.run(tmp, task_vars)

    assert result['failed'] == False

    # Test for run when module is not auto

# Generated at 2022-06-21 03:23:43.454329
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:23:46.716296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None


if __name__ == "__main__":
    action = ActionModule(None, None, None, None, None)
    print(action)
    print(action.run())

# Generated at 2022-06-21 03:23:48.495214
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:23:53.189304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(tmp=None, task_vars=None)

    assert isinstance(action, ActionBase)
    assert action._supports_check_mode == True
    assert action._supports_async == True

# Generated at 2022-06-21 03:24:02.091427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Create a mock for the module and run test against it.
    # The code below just shows how to call the actual code.
    from ansible.plugins.action.yum import ActionModule
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import sys

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    sys.argv = ['']
    set

# Generated at 2022-06-21 03:24:03.555475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-21 03:24:04.207773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:24:38.058912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test that when the requested yum module backend is not installed and
       when the yum module backend is not valid,
       that the yum action plugin returns the expected error message.
    """

    from ansible.plugins.loader import action_loader
    from ansible.utils.context_objects import AnsibleContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes

    class TestDisplay:
        verbosity = 2

    display = TestDisplay()

    # remove the yum3 and yum4 module backends
    action_loader.remove_directory(to_bytes('/etc/ansible/roles/test_role/library/ansible/legacy/yum'))

# Generated at 2022-06-21 03:24:43.350957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = MockConnection()
    action = ActionModule(conn, 'task_uuid', 'display')
    assert action._shared_loader_obj.module_loader.has_plugin('ansible.legacy.yum') is True
    assert action._shared_loader_obj.module_loader.has_plugin('ansible.legacy.dnf') is True
    # Test yum4 without yum
    assert action._shared_loader_obj.module_loader.has_plugin('ansible.legacy.yum4') is False
    # Test run()
    result = action.run(task_vars=[])
    assert 'failed' not in result
    assert 'msg' not in result
    assert result['ansible_facts'] == {'pkg_mgr': 'yum'}
    assert result['changed'] is False
    assert result

# Generated at 2022-06-21 03:24:53.105888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import json
    from ansible.plugins.action.yum import ActionModule
    from ansible.plugins.action.package_common import ActionModule as ActionModulePackageCommon
    from ansible.plugins.loader import modules_loader
    from ansible.plugins.loader import action_loader
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    # Declare the class instance for the unit test
    am = ActionModule()
    # Set attributes for the unit test
    am._shared_loader_obj = modules_loader
    am._task = None
    am._templar = None
    am._connection = None
    if PY2:
        am._shell = None
    else:
        am._task.async_val = None

    # Simulate that

# Generated at 2022-06-21 03:24:53.583384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:24:56.152824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule()
    test_action_module._task = {'args': {"use_backend": ''}}
    test_action_module.run('')

# Generated at 2022-06-21 03:25:07.134564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as loader_module

    class FakeConnection:
        class FakeShell:
            def __init__(self):
                self.tmpdir = '/tmp/test'

        def __init__(self):
            self._shell = self.FakeShell()

    class FakeTask:
        def __init__(self):
            self.args = dict(foo=42)
            self.async_val = False

    class FakePlayContext:
        def __init__(self):
            self.check_mode = False

    class FakeLoader:
        def __init__(self):
            self.module_loader = loader_module.ModuleLoader()

    class FakeTemplar:
        def __init__(self):
            self.template = lambda x: x


# Generated at 2022-06-21 03:25:17.164934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Verify the class ActionModule with param module = 'auto' and self._task.delegate_to = '127.0.0.1'
    """
    # Create an instance of class ActionModule for unit test
    action_mock_object = ActionModule()

    # Set the values for variables used in unit test
    action_mock_object.runner = {'args': {'use': 'auto'}}
    action_mock_object._task = {'delegate_to': '127.0.0.1'}
    action_mock_object._task.args = {'use': 'auto'}
    action_mock_object._task.args.update = {'use': 'auto', 'use_backend': None}

# Generated at 2022-06-21 03:25:18.120144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None)

# Generated at 2022-06-21 03:25:19.345955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule('test', dict(), False, dict(), 'test')
    assert actionModule

# Generated at 2022-06-21 03:25:24.315598
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:26:11.814530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:26:18.638656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dictionaries for creating a module object
    module_args = dict(
        name=['vim-enhanced', 'httpd'],
        state='present',
        use='auto',
    )

    module_args_yum3 = dict(
        name=['vim-enhanced', 'httpd'],
        state='present',
        use='yum',
    )

    module_args_yum4 = dict(
        name=['vim-enhanced', 'httpd'],
        state='present',
        use='dnf',
    )

    t = dict(register='shell_out')
    t_vars = dict(
        ansible_pkg_mgr=None,
    )

    # Create a module object
    module = ActionModule(None, module_args, t, t_vars)
   

# Generated at 2022-06-21 03:26:22.706543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action = ActionModule(
            task=dict(
                async_val=True,
                args=dict(
                    use_backend='auto',
                ),
            ),
            connection=dict(),
            play_context=dict(),
            loader=dict(),
            templar=dict(),
            shared_loader_obj=dict(),
        )
        assert True
    except Exception:
        assert False, "ActionModule constructor raised Exception unexpectedly!"

# Generated at 2022-06-21 03:26:28.592221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = Task()
    test_connection = Connection()
    test_play = Play()
    test_playcontext = PlayContext()
    test_loader = DataLoader()
    test_variable_manager = VariableManager()
    test_ActionModule = ActionModule(task=test_task,
                                     connection=test_connection,
                                     play=test_play,
                                     play_context=test_playcontext,
                                     loader=test_loader,
                                     variable_manager=test_variable_manager)
    assert test_ActionModule is not None

# Generated at 2022-06-21 03:26:37.172089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    task_vars = dict()

    # Case 1: Use auto as default value
    module = ActionModule(task=dict(),connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)
    assert module.run(task_vars=task_vars)[0] == dict()

    # Case 2: Use yum3 as use_backend value
    task_vars['ansible_facts'] = dict(pkg_mgr="yum")
    module = ActionModule(task=dict(args=dict(use_backend='yum3')),connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)

# Generated at 2022-06-21 03:26:38.423122
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:26:44.020677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # From test/units/plugins/action/test_yum_dnf.py
    import sys
    import mock
    import ansible.utils.display
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

    # Init unit test
    action_obj = ActionModule({})
    action_obj._supports_async = True
    action_obj._supports_check_mode = True

    # Mock loader
    mock_loader = mock.MagicMock()
    action_obj._shared_loader_obj = mock_loader
    mock_loader.module_loader.has_plugin.return_value = False

    # Mock task
    mock_task = mock.MagicMock()
    mock_task.async_val = False


# Generated at 2022-06-21 03:26:48.172292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    assert module._supports_check_mode
    assert module._supports_async
    assert module.VALID_BACKENDS == VALID_BACKENDS
    assert module.TRANSFERS_FILES == False
    assert module.NO_TARGET_SYSTEM_WARNING == True

# Generated at 2022-06-21 03:26:56.791990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_display = type('MockDisplay', (object,), {'debug': lambda *a, **kw: None})()
    monkeypatch.setattr(ActionModule, '_remove_tmp_path', lambda *a, **kw: None)
    monkeypatch.setattr(ActionModule, '_execute_module', lambda *a, **kw: ({}, ""))
    monkeypatch.setattr(ActionModule, '_shared_loader_obj', type('MockLoaderObj', (object,), {
        'module_loader': type('MockModuleLoader', (object,), {'has_plugin': lambda *a, **kw: True})
    })())
    monkeypatch.setattr(ActionModule, '_templar', type('MockTemplar', (object,), {'template': lambda *a, **kw: 'auto'})())


# Generated at 2022-06-21 03:26:58.160986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-21 03:28:38.374242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule

    Unit test for testing the __init__ method of class ActionModule
    """
    # Test with a null object for the module argument
    test_task = ActionModule(mock.MagicMock())

    # Testing the object attributes.
    assert test_task.TRANSFERS_FILES is False
    assert test_task._supports_check_mode is True
    assert test_task._supports_async is True

# Code for the unit test to be run

# Generated at 2022-06-21 03:28:48.104490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    import ansible.plugins.action.yum

    context.CLIARGS = {'changed-when': 'changed', 'fail_on_undefined_vars': 'True'}
    display = Display()
    display.verbosity = 3


# Generated at 2022-06-21 03:28:55.989549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.playbook import Playbook

# Generated at 2022-06-21 03:28:58.983667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=unused-variable
    t = ActionModule()
    # pylint: enable=unused-variable

# Generated at 2022-06-21 03:29:08.022675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def dict_merge(x, y):
        z = x.copy()
        for k, v in y.items():
            if k in z and isinstance(v, dict):
                z[k] = dict_merge(z[k], v)
            else:
                z[k] = v
        return z

    def get_args(super_class):
        return dict_merge(super(ActionBase, super_class).run({}, {}), super_class._execute_module({}, {}, {}))

    def get_module_name(module):
        if module == 'yum4':
            return 'dnf'
        return module

    def get_module_path(module):
        return 'ansible.legacy.' + module


# Generated at 2022-06-21 03:29:09.421875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 03:29:13.086073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {
        'task': {
            'args': {
                'use': 'yum'
            }
        }
    }
    module = ActionModule(data, 'connection', 'loader', 'templar')

    assert module.run()['action'] == 'dnf'
    assert module.run()['context']['environment'] == None

# Generated at 2022-06-21 03:29:13.885145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None


# Generated at 2022-06-21 03:29:14.606779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run(None, None) == None

# Generated at 2022-06-21 03:29:18.797825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(connection=None,
                     templar=None,
                     task_vars=dict(pkg_mgr="yum"))
    assert x