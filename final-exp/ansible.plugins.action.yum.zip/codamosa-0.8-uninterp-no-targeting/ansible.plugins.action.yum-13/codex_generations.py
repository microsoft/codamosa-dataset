

# Generated at 2022-06-21 03:21:16.823916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit tests for the run() method of the ActionModule class'''

    # TODO: What should the mocked API look like for executing modules?
    # What should the API look like for access to tmp?
    # What should the API look like for access to task_vars?
    # What should the API look like for access to Display?
    # What should the API look like for access to templar, _execute_module, and _remove_tmp_path?

# Generated at 2022-06-21 03:21:18.195764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    The most basic test for the run method.
    '''
    pass

# Generated at 2022-06-21 03:21:27.202155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TaskObject:
        async_val = None
        delegate_to = None
        delegate_facts = None

    class ActionModuleObject(ActionModule):
        _task = TaskObject()

        def run(self, tmp=None, task_vars=None):
            self._task.async_val = self._task.async_val
            self._task.delegate_to = self._task.delegate_to
            self._task.delegate_facts = self._task.delegate_facts
            return super(ActionModuleObject, self).run(tmp, task_vars)

    # test with different module values (use_backend)
    for module in ['auto', 'yum', 'dnf']:
        action_module_object = ActionModuleObject()
        action_module_object._task.args = {}
        action_

# Generated at 2022-06-21 03:21:28.161895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:21:38.599326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # TODO: real tests
    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task_name = "yum"

# Generated at 2022-06-21 03:21:42.909541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    validate = {
        'use': 'auto',
        'use_backend': 'auto',
        'name': 'asdf',
    }

    module = ActionModule(validate, {})
    assert module.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))

# Generated at 2022-06-21 03:21:44.422075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))

# Generated at 2022-06-21 03:21:51.639400
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    import tempfile
    import shutil

    pmf = PkgMgrFacts()
    pmf.collect(None)
    pkgmgr = pmf.get_facts()['pkg_mgr']

    am = ActionModule()
    tmpdir = tempfile.mkdtemp()

    am._templar = None
    am._shared_loader_obj = None
    am._task = None
    am._connection = None
    am.run(tmp=tmpdir, task_vars=None)

    am._task = None
    am.run(tmp=tmpdir, task_vars={})

    am._task = 'task'
    am._task.args = dict()

# Generated at 2022-06-21 03:22:01.549981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We're going to patch ActionModule here to make sure we can
    # validate that the module will run the correct backend module.
    # This is done by patching the _execute_module method, but this
    # method is also a property (i.e. not a function).
    #
    # In order to do this we need to create a class with the same
    # functionality as the property and patch that.
    class MockExecuteModule:
        def __init__(self):
            self.module_name = None
            self.module_args = None

        def __call__(self, module_name, module_args, task_vars, wrap_async):
            self.module_name = module_name
            self.module_args = module_args
            return {'changed':False, 'failed':False}


# Generated at 2022-06-21 03:22:01.947048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:22:13.894358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import os
    import tempfile
    import unittest

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils._text import to_bytes
    from ansible.modules.packaging.language.yum import ActionModule
    from ansible.utils import context_objects as co
    from ansible.utils.vars import merge_hash

    fake_system_module_args = dict(path=dict(default='/usr/bin:/bin:/usr/sbin:/sbin'), use=dict(default='auto'))

    def _get_temp_dir(system_module_args=None):
        if system_module_args is None:
            system_module_args = {}


# Generated at 2022-06-21 03:22:14.916866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO(bregman): Validate instantiation of class ActionModule
    pass

# Generated at 2022-06-21 03:22:15.506836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:22:25.234540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import yum_base
    assert isinstance(yum_base, Mapping)

    import pkgutil
    import ansible
    import ansible.plugins.action.yum
    import ansible.plugins.action.dnf
    import ansible.plugins.action.yum3_base
    import ansible.plugins.action.yum4_base

    assert isinstance(yum_base, Mapping)
    assert isinstance(ansible.plugins.action.yum, pkgutil._Loader)
    assert isinstance(ansible.plugins.action.dnf, pkgutil._Loader)


# Generated at 2022-06-21 03:22:29.466427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Auto-detected backend should not be specified by user
    try:
        am = ActionModule(
            dict(
                _task=dict(
                    args=dict(
                        use_backend="yum",
                        use="dnf"
                    )
                )
            )
        )
    except AnsibleActionFail as e:
        return True
    assert False

# Unit tests for run method

# Generated at 2022-06-21 03:22:30.558976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, {})
    assert module != None

# Generated at 2022-06-21 03:22:32.700495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    :return:
    '''
    module = ActionModule()
    module.run()

# Generated at 2022-06-21 03:22:43.145435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display = Display()
    display.debug = True
    action_module = ActionModule()
    # localhost = 'localhost'
    # localhost = '127.0.0.1'
    localhost = ''
    print("lovalhost = '%s'" % localhost)
    action_module._shared_loader_obj.module_loader.has_plugin = lambda module: True  # always return True

# Generated at 2022-06-21 03:22:45.890466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module

# Generated at 2022-06-21 03:22:50.827256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), None, None, 'yum') is not None
    assert ActionModule(dict(), None, None, 'ansible.legacy.yum')._task.action == 'yum'
    assert ActionModule(dict(), None, None, 'ansible.legacy.dnf')._task.action == 'yum'
    assert ActionModule(dict(), None, None, 'ansible.legacy.foo') is None
    assert ActionModule(dict(), None, None, None) is None

# Generated at 2022-06-21 03:23:12.529732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for the method run of class ActionModule '''

    # Test setup
    import collections
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.action import yum_select

    module_mock = MagicMock(
        spec=yum_select.ActionModule)

# Generated at 2022-06-21 03:23:15.243715
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

# Generated at 2022-06-21 03:23:27.002398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(async_val=None, async_jid=None, delegate_to=None, delegate_facts=None, args=dict(), register=None,
                  environment=dict(), when=None, run_once=None, notify=None, become=None, become_user=None,
                  become_method=None, become_flags=None, no_log=None, timeout=None, delegate_to_host=None,
                  delegate_facts_host=None, diff=None, warn=False, loop=None, loop_args=None, use=None,
                  use_backend=None),
        connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am._task.async_val is None

# Generated at 2022-06-21 03:23:37.084109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    expected_result_run_use_backend = {
        "failed": True,
        "msg": "parameters are mutually exclusive: ('use', 'use_backend')"
    }
    result_run_use_backend = action_module._execute_module(
        module_name="yum",
        module_args={'use': 'yum', 'use_backend': 'dnf'}
    )
    assert result_run_use_backend == expected_result_run_use_backend

    expected_result_run_use_invalid_backend = {
        "failed": True,
        "msg": "parameters are mutually exclusive: ('use', 'use_backend')"
    }
    result_run_use_invalid_backend = action_module._execute

# Generated at 2022-06-21 03:23:46.840311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object1 = {"module": "yum", "args": {'use_backend': 'yum4'}}
    test_object2 = {"module": "yum", "args": {'use': 'yum3'}}
    task_vars1 = {'ansible_facts': {'pkg_mgr': 'yum4'}}
    task_vars2 = {'ansible_facts': {'pkg_mgr': 'yum'}}
    tmp_path1 = '/var/tmp/ansible-tmp-1498483366.83-261875469807399'
    tmp_path2 = '/var/tmp/ansible-tmp-1498483366.83-261875469807400'


# Generated at 2022-06-21 03:23:57.298317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run from inside the Ansible repo
    import ansible.constants
    ansible.constants.HOST_KEY_CHECKING = False

    # We need to use Ansible Templates here to ensure that we pick up any action plugin symlinks
    # that may be installed in the local Ansible repo.
    import ansible.plugins
    action_plugin_dir = ansible.plugins.__path__[0]
    module_utils_dir = os.path.join(action_plugin_dir, "..", "module_utils")

    from ansible.galaxy.api import GalaxyAPI
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    from ansible.module_utils.common.process import get_bin_path


# Generated at 2022-06-21 03:23:59.800243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(USE_BACKEND='auto',
                             ANSIBLE_MODULE_ARGS={}),
                        ansible.plugins.action.action_base.TaskBase()
                       )


# Generated at 2022-06-21 03:24:08.365076
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    am = ActionModule()

    am._task = type('FauxTask', (object,), dict(
        async_val=False,
        delegate_to='',
        delegate_facts=True,
        args=dict(
            use='auto')))

    am._execute_module = type('FauxExecuteModule', (object,), dict(
        return_value=dict(
            ansible_facts=dict(
                pkg_mgr='yum'))))

    assert am.run()['ansible_facts']['pkg_mgr'] == 'yum'
    assert am.run()['ansible_facts']['changed'] == False



# Generated at 2022-06-21 03:24:15.410998
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test = ActionModule()
    result = test.run(task_vars=dict(ansible_pkg_mgr='dnf'))
    assert result.get('result') == dict(msg='Could not find a yum module backend for ansible.legacy.dnf. You may need to install yum and/or python2-dnf-plugins-core on the target hosts')

    result = test.run(task_vars=dict(ansible_facts=dict(pkg_mgr='dnf')))
    assert result.get('result') == dict(msg='Could not find a yum module backend for ansible.legacy.dnf. You may need to install yum and/or python2-dnf-plugins-core on the target hosts')

# Generated at 2022-06-21 03:24:21.014462
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.facts.system.pkg_mgr import PackageManagerFactCollector

    def _execute_module(module_name=None, module_args=None, task_vars=None, wrap_async=None):
        if module_name == 'ansible.legacy.setup':
            if module_args.get('filter') == "ansible_pkg_mgr":
                facts = PackageManagerFactCollector().populate()
                return dict(ansible_facts=dict(pkg_mgr=facts.name))
            else:
                return dict(failed=True, msg="module_args error")

# Generated at 2022-06-21 03:24:48.328712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    a = ActionModule()
    assert isinstance(a, ActionModule)


# Generated at 2022-06-21 03:24:56.490102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            async_val=50,
            delegate_to='foo',
            delegate_facts=True,
            args=dict(
                use='auto',
                use_backend='auto',
            )
        ),
        connection=dict(
            _shell=dict(
                tmpdir='/a/b/c'
            )
        ),
        shared_loader_obj=dict(
            module_loader=dict(
                has_plugin=lambda x: x == 'ansible.legacy.yum'
            )
        )
    )
    res = module.run()
    assert res['changed'] is False
    assert res['failed'] is False
    assert res['ansible_facts'] == {'pkg_mgr': 'yum'}


# Generated at 2022-06-21 03:25:07.811734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This function is called from unit test file

    from ansible.plugins.action.yum import ActionModule
    from ansible.plugins.loader import action_loader

    my_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'hacking', 'env-setup')
    if os.path.exists(my_path):
        ansible_module_utils = os.path.join(my_path, 'lib')
        ansible_test_data = os.path.join(my_path, 'test', 'units', 'module_utils')
        ansible_test_data_yum = os.path.join(my_path, 'test', 'units', 'modules', 'extras', 'yum')
        ansible_test_data_dnf = os.path

# Generated at 2022-06-21 03:25:17.713742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate ActionModule with parameters required for _execute_module()
    mock = {}
    mock['_supports_check_mode'] = True
    mock['_supports_async'] = True
    mock['_task'] = {"args": {}}
    mock['_connection'] = {"_shell": {"tmpdir": ""}}
    mock['_shared_loader_obj'] = {"module_loader": {"_module_cache": {"name": "yum"}}}
    mock['_templar'] = {"template": lambda a: None}
    mock['_execute_module'] = lambda a, b, c, d=None, e=None: {'ansible_facts': {'pkg_mgr': "yum3"}}

# Generated at 2022-06-21 03:25:20.659600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: This is only testing a "return" type or similar - should be providing
    # mock objects for all args and ensure return is correct, with no exceptions raised
    action = ActionModule()
    action._task.args = {}
    result = action.run()
    assert result == {"changed": False, "failed": False, "msg": "No module name specified"}

# Generated at 2022-06-21 03:25:21.688453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action = ActionModule()
    result = test_action.run()
    assert result == 'examples'

# Generated at 2022-06-21 03:25:25.756966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.path import unfrackpath
    from ansible.vars.manager import VariableManager

    ##########################################################################
    #
    # !!! THIS IS A HACK !!!
    #
    # This is how the `unfrackpath` function is implemented in Ansible
    # 2.9.x for most tests.  In Ansible 2.10.x, the way `unfrackpath`
    # is implemented was changed to use `os.path.expanduser` but this
    # change is not reflected in the current Ansible 2.10.x unit tests.
    #
    # The change in Ansible 2.10.x was released in this commit:
    # <https://github.com/ansible/ansible/commit/

# Generated at 2022-06-21 03:25:26.272393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:25:32.148300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionBase)
    assert hasattr(action, 'run')
    assert action.run != None
    assert hasattr(action, '_supports_async')
    assert action._supports_async == True
    assert hasattr(action, '_supports_check_mode')
    assert action._supports_check_mode == True


# Generated at 2022-06-21 03:25:34.943421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake ansible action plugin
    display = Display()
    fake_loader = {}
    actions = ActionModule(display=display, loader=fake_loader)
    assert actions._supports_check_mode is True
    assert actions._supports_async is True

# Generated at 2022-06-21 03:26:29.939174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define values
    tmp = None
    task_vars = None

    # Create an instance of the ActionModule class
    action_module = ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )

    # Get the method run of the class ActionModule
    action_module_run = action_module.run(tmp=tmp, task_vars=task_vars)

    # Check if the result is a dictionary
    assert isinstance(action_module_run, dict)



# Generated at 2022-06-21 03:26:30.514555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:26:31.403933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(a='b', c='d')

# Generated at 2022-06-21 03:26:40.211812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}

    class ActionModule_run_test(ActionModule):

        def run(self, tmp=None, task_vars=None):
            return super(ActionModule_run_test, self).run(tmp, task_vars)

    # Test with invalid backend
    test1 = ActionModule_run_test()
    test1._task.args = {'use_backend': 'yum5'}
    result = test1.run()
    assert result['failed']

    # Test using ansible_facts
    test2 = ActionModule_run_test()
    test2._task.args = {}
    test2._templar.template = lambda s: 'yum'
    result = test2.run()
    assert result['ansible_facts']['pkg_mgr'] == 'yum'

    # Test

# Generated at 2022-06-21 03:26:42.675125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task = MockTask()
    action._connection = MockConnection()
    action._shared_loader_obj = None
    action._templar = MockTemplar()
    assert action.run(tmp=None, task_vars=None) is not None


# Generated at 2022-06-21 03:26:47.037746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object of class ActionModule
    obj = ActionModule()

    # Check if obj is an instance of class ActionModule
    assert isinstance(obj, ActionModule)

    # Check if obj is an instance of class ActionBase
    assert isinstance(obj, ActionBase)

# Generated at 2022-06-21 03:26:49.222701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(name="fake_mod", action=dict(name="yum_action"), shared_loader_obj=dict(), task_loader=dict())


# Generated at 2022-06-21 03:26:51.090910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._supports_check_mode == True
    assert ActionModule._supports_async == True


# Generated at 2022-06-21 03:26:51.861223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)

# Generated at 2022-06-21 03:26:54.422294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(module) == ActionModule


# Generated at 2022-06-21 03:28:45.442584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    import sys

    sys.path.append('/ansible/lib')
    sys.path.append('/ansible/lib/ansible')
    sys.path.append('/ansible/lib/ansible/modules')
    sys.path.append('/ansible/lib/ansible/modules/packaging')

    import pkg_resources
    pkg_resources.require('ansible')

    import unittest
    import ansible.modules
    import ansible.plugins
    import ansible.plugins.action

    import ansible.legacy
    import ansible.legacy.plugins.action.package

    from ansible.inventory.host import Host

    from ansible.legacy.plugins.action.package import ActionModule

    from ansible.module_utils.six import PY

# Generated at 2022-06-21 03:28:53.614583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actions = {}
    def run_main(task_vars=None):
        action = ActionModule(task={"args": {'use': 'yum'}, 'action': 'yum'}, connection=None, play_context=None,
                              loader=None, templar=None, shared_loader_obj=None)
        return action.run(tmp=None, task_vars=task_vars)

    def run_delegate_to(task_vars=None):
        action = ActionModule(task={"args": {'use': 'yum'}, 'action': 'yum', 'delegate_to': 'test_host'},
                              connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:28:56.160923
# Unit test for constructor of class ActionModule
def test_ActionModule():
  facts = {}
  actionmodule = ActionModule(loader=None,connection=None,shared_loader_obj=None,templar=None,task_vars=facts)
  assert actionmodule._supports_check_mode == True
  assert actionmodule._supports_async == True


# Generated at 2022-06-21 03:29:00.523375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = dict(name="testhost")
    task = dict(name="testtask", action=dict(module="yum"))
    play_context = dict(become=False)
    tmp = "/tmp"
    actionModule = ActionModule(task, play_context, tmp, host)
    assert actionModule is not None

# Generated at 2022-06-21 03:29:01.006362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:29:02.198400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-21 03:29:04.066625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t_module = ActionModule()
    assert t_module.VALID_BACKENDS == ('dnf', 'yum')

# Generated at 2022-06-21 03:29:05.149183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 03:29:13.997373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import tempfile
    from ansible.module_utils.facts.system.pkg_mgr import Facts
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template.template import Templar

    class FakeTask():
        def __init__(self, delegate_to=None, delegate_facts=False, async_val=True):
            self.delegate_to = delegate_to
            self.delegate_facts = delegate_facts
            self.async_val = async_val
            self.args = dict()

    class FakeAnsibleModule():
        def __init__(self, tmp, task_vars):
            self._shared_loader_obj = action_loader

# Generated at 2022-06-21 03:29:22.298212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as plugin_loader
    from ansible.playbook.task import Task

    module_loader = plugin_loader._find_action_plugin('yum')
    assert module_loader.__name__ == "yum"
    assert issubclass(module_loader, ActionModule)
    action_plugin_obj = module_loader(Task(), dict())

    assert action_plugin_obj is not None
    assert action_plugin_obj._supports_check_mode is True
    assert action_plugin_obj._supports_async is True