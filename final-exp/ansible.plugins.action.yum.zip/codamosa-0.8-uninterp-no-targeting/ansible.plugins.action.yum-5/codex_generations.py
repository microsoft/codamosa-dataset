

# Generated at 2022-06-21 03:21:22.357698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = MockConnection()
    loader = MockLoader()
    templar = MockTemplar()
    display = MockDisplay()
    task_vars = dict()

    action_module = ActionModule(connection, loader, templar, task_vars)
    assert not action_module._supports_check_mode
    assert not action_module._supports_async

    action_module = ActionModule(connection, loader, templar, task_vars, check_mode=True, async_timeout=42)
    assert action_module._supports_check_mode
    assert action_module._supports_async

    # test for backward compatibility
    action_module = ActionModule(connection, loader, templar, task_vars, check_mode=True, async_timeout=42)
    assert action_module._supports_

# Generated at 2022-06-21 03:21:22.890130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:29.937931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    sys.path.append("..")

    # test options
    options = {
        "argv": ['ansible-playbook',
                 '--tags', 'always',
                 '--extra-vars', '@test/integration/targets/package/ansible_facts.json',
                 'test/integration/targets/package/test_yum.yml']}

    # test direct call with connection
    from ansible.plugins.loader import ac_plugin_loader
    loader_obj = ac_plugin_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

# Generated at 2022-06-21 03:21:30.974677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:38.387861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    connection = MagicMock()
    display = MagicMock()
    action_base = ActionBase(connection, display)
    action_module = ActionModule(connection, display, action_base._loader, action_base._templar, action_base._shared_loader_obj)
    assert(action_module._supports_async == True)
    assert(action_module._supports_check_mode == True)
    assert(action_module.TRANSFERS_FILES == False)

# Generated at 2022-06-21 03:21:48.389951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._supports_check_mode = True
    module._supports_async = True

    # yum4/dnf is not available
    module._task = {
        'args': {
            'use': 'yum4'
        },
        'async_val': None,
        'delegate_to': None,
        'delegate_facts': True,
    }
    result = module.run(tmp=None, task_vars=None)
    assert result['failed']
    assert result['msg'] == "Could not find a yum module backend for dnf."

    # yum4/dnf is available

# Generated at 2022-06-21 03:21:53.110087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        action = dict(
            module = "yum"
        ),
        args = dict()
    )
    task_vars = dict()
    am = ActionModule(task, task_vars)
    assert am is not None


# Generated at 2022-06-21 03:22:02.718392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import contextlib

    @contextlib.contextmanager
    def backups(obj, attr):
        orig_val = getattr(obj, attr)
        try:
            yield
        finally:
            setattr(obj, attr, orig_val)

    with mock.patch('ansible.plugins.action.yum_select.ActionBase.run') as run_mock, \
            mock.patch('ansible.plugins.action.yum_select.VALID_BACKENDS') as VALID_BACKENDS_mock:

        action_base_mock = mock.MagicMock()
        run_mock.return_value = action_base_mock
        VALID_BACKENDS_mock.return_value = ('yum', 'dnf')


# Generated at 2022-06-21 03:22:05.194820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 03:22:13.526271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    facts = {'pkg_mgr': 'dnf'}
    setup_gather_facts = {
        'ansible_facts': {
            'ansible_local': {
                'facts': facts
            }
        }
    }
    module = {
        'use': 'uninstall'
    }
    module_args = {
        'transport': 'ssh',
        'remote_user': 'user1',
        'remote_pass': 'password1',
        'remote_port': '22',
        'remote_addr': '1.1.1.1',
    }
    new_module_args = {
        'use': 'uninstall'
    }
    class_inst = ActionModule()
    class_inst._execute_module = lambda module_name, module_args, task_vars: setup_g

# Generated at 2022-06-21 03:22:28.885336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader

    # Manually create a task to pass to the ActionModule to bypass internal
    # Ansible loader utils.

    task_vars = dict(self=dict(module_name="yum"), delegate_to="localhost", delegate_facts=False)

    task = ImmutableDict({
       "action": "yum",
       "async": 300,
       "async_val": False,
       "args": dict(
           use="yum3",
           name="cowsay",
           state="present"),
       "delegate_to": "localhost",
       "delegate_facts": False,
       "loop": "{{ test_loop }}"})

    # Create the action module.
    action

# Generated at 2022-06-21 03:22:29.178541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:22:34.980856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a base connection
    connection = Connection(module_name='yum')
    # Create a delegate
    delegate_to = Delegate()
    # Create a module_utils
    module_utils = ModuleUtils()
    # Create a task
    task = Task()
    # Create a task_vars
    task_vars = TaskVars()

    # Create a base action plugin
    action_module = ActionModule(
        connection=connection,
        _task=task,
        delegate=delegate_to,
        module_utils=module_utils,
        task_vars=task_vars)
    action_module.module_name = 'yum'
    action_module.action_name = 'yum'

    # Test if action_module.run() returns a dictionary with a key 'failed' and value 'True'


# Generated at 2022-06-21 03:22:39.705074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._task.action == 'yum'
    assert action_module._task.name == 'yum'

# Generated at 2022-06-21 03:22:42.685554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Make sure we can initialize the class
    """
    TaskModule = ActionModule('test', {}, True, None, None)

# Generated at 2022-06-21 03:22:43.565745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES is False

# Generated at 2022-06-21 03:22:45.345865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actual = ActionModule()
    assert actual is not None
    assert actual._supports_check_mode is True
    assert actual._supports_async is True

# Generated at 2022-06-21 03:22:49.116281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Check
    assert action_module._supports_check_mode
    assert action_module._supports_async

# Generated at 2022-06-21 03:22:59.519730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule():
        class MockArgs(object):
            pass
        args = MockArgs()
        args.package = 'mock_package'
        args.name = 'mock_name'
        args.state = 'mock_state'
        delegate_to = None
        delegate_facts = None

    class MockTask(object):
        class MockTemplar(object):
            def template(self, string):
                return "mock_template"

        class MockArgs(object):
            pass

        args = MockArgs()
        async_val = None
        templar = MockTemplar()
        delegate_to = None
        delegate_facts = None


# Generated at 2022-06-21 03:23:00.997005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-21 03:23:24.710471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.package import package as package_action

    # Inner class ActionModule for testing private methods
    class ActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            # Set supported params
            self._supports_check_mode = True
            self._supports_async = True

        def _execute_module(self, module_name, module_args, task_vars=None, wrap_async=None):
            '''
            Test method to execute module without executing it
            '''
            if module_name == 'ansible.legacy.yum':
                mod = package_action

# Generated at 2022-06-21 03:23:31.278999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action='test'),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(module_loader=dict(has_plugin=VALID_BACKENDS.__contains__),),
    )
    assert action.run(tmp=None, task_vars=None) == {
        'ansible_facts': {'pkg_mgr': 'auto'},
        'invocation': {'module_args': {'use': 'auto'}},
        'changed': False,
        'skip_reason': 'Conditional result was False',
        'skipped': True
    }

# Generated at 2022-06-21 03:23:36.245228
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test init method
    action_module = ActionModule(None, None, None)
    assert action_module.TRANSFERS_FILES == False
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-21 03:23:46.341374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_module = AnsibleModule(
        argument_spec=dict(
            use=dict(type='str', default='auto'),
            use_backend=dict(type='str', default='auto'),
            name=dict(type='str', default='test-name'),
            state=dict(type='str', default='test-state'),
            user=dict(type='str', default='test-user'),
            force=dict(type='bool', default=True),
            installroot=dict(type='str', default='test-installroot')
        )
    )

    # Unit test for case when module is invalid, i.e. neither yum nor dnf

# Generated at 2022-06-21 03:23:56.670934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    import json
    import io

    # TODO: fix test to use testing infrastructure

    # test_data is a dict of dicts where the key is the input json to the action plugin and the value is the expected outcome
    test_data = dict()

    test_data['auto_test_no_delegate_no_facts'] = {
        'test_input': dict(action=dict(module='yum', args=dict(use='auto'))),
        'test_outcome': dict(ansible_facts=dict(pkg_mgr='yum'), changed=False, failed=False, skipped=False)
    }


# Generated at 2022-06-21 03:23:58.713418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        m = ActionModule()
        assert False, "Unable to load its constructor"
    except Exception as e:
        assert True, "Failed to load its constructor"

# Generated at 2022-06-21 03:23:59.635498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(None, None, None)

# Generated at 2022-06-21 03:24:09.490338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock task_vars value
    task_vars = {
        "ansible_facts": {
            "pkg_mgr": "dnf"
        }
    }

    # create mock object
    mock_self = type("mock_self", (object,), {
        "_task": type("mock_task", (object,), {
            "async_val": False,
            "args": {"use": "auto"}
        }),
        "_templar": type("mock_templar", (object,), {
            "template": lambda *args, **kwargs: "dnf"
        }),
        "run": ActionModule.run
    })()

    # test case 1: dnf backend
    res = mock_self.run(task_vars=task_vars)
    assert res

# Generated at 2022-06-21 03:24:16.830609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the class under test
    action_module = ActionModule(
        task=dict(action=dict(module_name='yum', module_args=dict(use='auto'))),
        connection=dict(module_name='yum', module_args=dict(use='auto')),
        play_context=dict(check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Test method 'run'
    # Inputs:
    # Outputs:
    # Action:
    result = action_module.run(tmp=None, task_vars=None)
    # Assertions:
    # Check the result is a dict
    assert isinstance(result, dict)
    # Check failed is a False
    assert result.get('failed')

# Generated at 2022-06-21 03:24:19.049132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run(tmp='/tmp', task_vars=dict())

# Generated at 2022-06-21 03:24:53.444009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible import context
    from ansible.context import CLIContext

    from ansible.plugins.action import ActionBase

    ActionBase._shared_loader_obj = context._shared_loader_obj
    ActionBase._task_vars = dict()
    ActionBase._templar = CLIContext()

    from ansible.plugins.action.packaging.yum import ActionModule

    temp_vars = dict()
    task_vars = dict()

    adhoc_options = dict()

    temp_vars.update(dict(ansible_pkg_mgr = 'yum'))
    task_vars.update(dict(ansible_pkg_mgr = 'yum'))

    context.CLIARGS = adhoc_options

# Generated at 2022-06-21 03:24:59.571419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import module_utils_loader
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    from ansible import context

    display = Display()
    context.CLIARGS = {'diff': False}

    yum_action = action_loader.get('yum',
                           class_only=True)
    mm = module_utils_loader.module_utils_loader.get_module_utils()
    task_vars = dict(
        ansible_facts=dict(
            pkg_mgr=None
        ),
        ansible_facts_cache={}
    )

    # For testing, use the local dnf module
    yum_action.backend = 'ansible.legacy.dnf'

    # For auto, we need a way

# Generated at 2022-06-21 03:25:02.687814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None
    assert am._supports_check_mode is True
    assert am._supports_async is True


# Generated at 2022-06-21 03:25:13.026093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    hostvars = HostVars(loader=loader, inventory=inv_manager)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

# Generated at 2022-06-21 03:25:20.793759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager()
    loader_obj = DataLoader()
    action_plugin = ActionModule(
        task=None,
        connection=None,
        _play_context=None,
        loader=loader_obj,
        templar=None,
        shared_loader_obj=None)
    action_plugin.run(task_vars=dict(pkg_mgr='test'))
    action_plugin.run(task_vars=None)
    action_plugin.run(tmp='test', task_vars=None)

# Generated at 2022-06-21 03:25:25.117972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x._supports_check_mode is True
    assert x._supports_async is True



# Generated at 2022-06-21 03:25:26.299047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    :return: Dummy test result
    '''
    assert True

# Generated at 2022-06-21 03:25:29.753797
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(None, None)
    assert(VALID_BACKENDS == frozenset(('dnf', 'yum', 'yum4')))

# Generated at 2022-06-21 03:25:30.162356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:25:34.177083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use_backend='yum', state='present', name='httpd')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 03:26:31.363276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test case for method run of class ActionModule
    '''
    fake_loader_obj = {}
    fake_loader_obj['module_loader'] = {'has_plugin': lambda x: True}
    action_module_obj = ActionModule(loader=fake_loader_obj,
                                     task={'args': {'use': 'yum'}},
                                     connection={'_shell': {'tmpdir': '/tmp/fake_tmp'}},
                                     templar=None,
                                     shared_loader_obj=None)
    action_module_obj._remove_tmp_path = lambda x: True
    action_module_obj._execute_module = lambda x, y, z, wrap_async=None: {'failed': False}
    result = action_module_obj.run()

# Generated at 2022-06-21 03:26:33.118287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    # TODO
    pass



# Generated at 2022-06-21 03:26:34.761108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test that the constructor is not throwing any errors
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-21 03:26:38.692210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the test class
    action_module = ActionModule()

    # Create the result object
    result = {"ansible_facts": {"pkg_mgr": "yum4"}}

    # Test the logic of the run method
    assert action_module.run(tmp=None, task_vars=None) == result


# Generated at 2022-06-21 03:26:39.704820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 03:26:43.273664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module_name="yum", module_args={"name": "test", "state": "present"})),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module._supports_check_mode
    assert module._supports_async

# Generated at 2022-06-21 03:26:45.099307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 03:26:45.759825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:26:48.112000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_result = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(),
                              templar=dict(), shared_loader_obj=dict())
    return True

# Generated at 2022-06-21 03:26:56.762404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Sequence
    import collections

    fake_task = collections.namedtuple('fake_task', ['args', 'delegate_to', 'delegate_facts', 'async_val'])
    fake_connection = collections.namedtuple('fake_connection', ['_shell'])
    fake_shell = collections.namedtuple('fake_shell', ['tmpdir'])
    fake_loader = collections.namedtuple('fake_loader', ['module_loader'])
    fake_loader_obj = collections.namedtuple('fake_loader_obj', ['plugin_list'])


# Generated at 2022-06-21 03:28:45.630132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Using "from mock import patch" will not work because the plugin being tested is a legacy
    # collection, so we need to use the mock library shipped with ansible in the lib directory
    from unit.mock import patch
    from ansible.plugins.action import ActionModule
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager

    display = Display()
    module_args = {'use_backend': 'auto'}

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test that when fact pkg_mgr is yum(3), action plugin will use yum3 as module backend

# Generated at 2022-06-21 03:28:53.759065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test whether adding a config file works."""

    # file_name="test_ActionModule.py"
    # TEST_DIR="test_directory"

    # os.mkdir(TEST_DIR)
    # with open(file_name, "w") as f:
    #     f.write("Test config file for pytest\n")
    # f.close()

    # data = "action module"
    pkgmgr = "yum"

    # test_file = open(file_name, "w")
    # test_file.write(data)

    pkg_mgr = {'ansible_pkg_mgr': pkgmgr}
    raw_facts = {'ansible_facts': pkg_mgr}

    # assert test_ActionModule(self, pkgmgr) == raw_facts



# Generated at 2022-06-21 03:28:59.331951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that initializer sets instance variables
    action_module = ActionModule('test', {})
    assert action_module._task.action == 'test'
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    action_module = ActionModule('test', {'test': 'test_var'})
    assert action_module._task.args == {'test': 'test_var'}



# Generated at 2022-06-21 03:29:04.682932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None, new_stdin=None, add_before_run=None,
                          module_name=None, module_path=None, module_args=None, task_vars=None, wrap_async=None)
    assert not action._supports_async
    assert action._supports_check_mode
    assert not action.TRANSFERS_FILES

# Generated at 2022-06-21 03:29:05.933690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for the class ActionModule
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-21 03:29:10.707877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert action.run() == {
        'failed': True,
        'msg': ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")}



# Generated at 2022-06-21 03:29:17.259794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit tests for ActionModule class"""

    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    module_name = 'yum'
    task_vars = dict()

    # pylint: disable=protected-access
    class MockPlaybookExecutor(PlaybookExecutor):
        def __init__(self):
            self.tqm = MockTaskQueueManager()

    class MockTaskQueueManager(object):
        def __init__(self):
            self.hostvars = dict()

        def get_vars(self, play=None, host=None, task=None, include_delegate_to=False):
            return

# Generated at 2022-06-21 03:29:18.552645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')


test_ActionModule()

# Generated at 2022-06-21 03:29:27.802295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock data
    import mock
    m_module_name = "m_backend"
    m_module_args = {'foo': 'bar'}
    m_task_vars = {'foo': 'bar'}
    m_result = {'foo': 'bar'}
    m_tmp = '/tmp/m_tmp'

    # mock object
    m_request_class = mock.MagicMock(spec=dict)
    m_task_class = mock.MagicMock()
    m_task_class.args = m_module_args
    m_task_class.delegate_to = None
    m_task_class.async_val = False
    m_task_class.delegate_facts = True

    m_connection_class = mock.MagicMock()
    m_connection_class._shell

# Generated at 2022-06-21 03:29:32.289411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    # test the default values of the class
    assert 'ansible.legacy.yum' == module._task.args.get('use', module._task.args.get('use_backend', 'auto'))
    assert VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))