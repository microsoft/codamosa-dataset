

# Generated at 2022-06-21 03:21:21.360256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test case tests the instantiation of class ActionModule
    """
    def test_recursive():
        temp_action_obj = ActionBase()
        temp_action_obj._task.action = 'pkg'
        temp_action_obj._task.args = {'use_backend': 'yum', 'name': 'test-pkg'}
        temp_action_obj._task.delegate_to = 'localhost'
        temp_action_obj._task.delegate_facts = False
        temp_action_obj._connection = None

        ansible_obj = AnsibleActionModule()
        ansible_obj._shared_loader_obj = None

        ansible_obj._task = temp_action_obj._task
        ansible_obj._connection = temp_action_obj._connection
        ansible_obj._templar = temp

# Generated at 2022-06-21 03:21:21.884013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:21:24.146983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:21:29.375791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import StringIO
    stdout = StringIO()
    conn = "local"
    task = "command"
    args = {"use_backend": "yum4"}
    ds = "%Y-%m-%d %H:%M:%S"
    now = datetime.now().strftime(ds)
    am = ActionModule(task, conn, args, stdout)
    task_vars = {"ansible_pkg_mgr": "yum"}

    result = am.run(task_vars=task_vars)
    # assert(result)

# Generated at 2022-06-21 03:21:32.105974
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Construct action module object
    obj = ActionModule()

    # Unit test: check unsupported parameter in run method
    obj.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 03:21:40.643097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({}, {'ansible_pkg_mgr': 'yum'}, display, {})
    module.run()

    module = ActionModule({'use': 'auto'}, {'ansible_pkg_mgr': 'yum'}, display, {})
    module.run()

    module = ActionModule({'use': 'auto'}, {'ansible_pkg_mgr': 'dnf'}, display, {})
    module.run()

    module = ActionModule({'use': 'auto'}, {'ansible_pkg_mgr': 'slurm'}, display, {})
    module.run()

# Generated at 2022-06-21 03:21:48.975361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(
            names='test_names',
            args=dict(
                name='test_name'
            ),
            async_val='test_async_val',
            async_val1='test_async_val1',
        ),
        connection=dict(
            conn_params='test_conn_params',
            _shell='test__shell'
        ),
        play_context=dict(
            check_mode='test_check_mode',
            verbosity='test_verbosity'
        ),
        loader='test_loader',
        templar='test_templar',
        shared_loader_obj='test_shared_loader_obj'
    )



# Generated at 2022-06-21 03:22:00.014437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Stub functions here
    class my_action_base():
        def _execute_module(self, module_name, module_args, task_vars):
            return (0, '', '')
        def _remove_tmp_path(self, path):
            return

    # Stub classes here
    class my_action_plugin():
        _shared_loader_obj = None
        class _task():
            def __init__(self):
                self.async_val = None
        class _connection():
            def __init__(self):
                self._shell = None
                self._shell.tmpdir = None
        def __init__(self):
            self._task = my_action_plugin._task()
            self._connection = my_action_plugin._connection()

    # Test case here
    action_plugin = my_action_

# Generated at 2022-06-21 03:22:00.792720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:22:03.994861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In python2.7, unittest.mock is not part of the standard library.
    # We need to directly import it from the unittest module to mock
    # for in python2.7
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from ansible.plugins.action import ActionModule

    # Mock the task.args.copy() method to return a custom dict
    with patch.object(ActionModule, 'run', return_value={'failed': False, 'msg': 'Test'}) as mock_module:
        mock_module.assert_called_with()

# Generated at 2022-06-21 03:22:21.212763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with delegate_to
    test_args = dict(delegate_to="localhost", use="yum")
    test_ActionModule = ActionModule()
    test_ActionModule._task = FakeTask()
    test_ActionModule._task.args = test_args
    test_ActionModule.run(tmp=None, task_vars={"hostvars": {"localhost": {"ansible_facts": {"pkg_mgr": "yum"}}}})

    # Test without delegate_to
    test_args = dict(use="yum")
    test_ActionModule = ActionModule()
    test_ActionModule._task = FakeTask()
    test_ActionModule._task.args = test_args

# Generated at 2022-06-21 03:22:26.711750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run({"use": "yum3"})
    module.run({"use": "yum4"})
    module.run({"use": "yum"})
    module.run({"use": "dnf"})
    try:
        module.run({"use": "invalid"})
        raise
    except Exception as e:
        assert(isinstance(e, AnsibleActionFail))

# Generated at 2022-06-21 03:22:34.503195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import merge_hash

    # Let's first setup a minimal PlayContext to test with
    play_context = PlayContext()
    play_context.connection = "local"
    play_context.check_mode = False
    play_context.remote_addr = "localhost"

    action_module = ActionModule(task=None, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None)

    # if use_backend is not set, then a failed task is returned

# Generated at 2022-06-21 03:22:35.272632
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()


# Generated at 2022-06-21 03:22:36.021067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a

# Generated at 2022-06-21 03:22:42.988445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    # Test the _supports_async property
    assert True == action_module._supports_async
    # Test the _supports_check_mode property
    assert True == action_module._supports_check_mode
    # Test the TRANSFERS_FILES attribute
    assert False == action_module.TRANSFERS_FILES
    # Test the run() method
    assert 0 == action_module.run()

# Generated at 2022-06-21 03:22:45.350975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


if __name__ == '__main__':
    import sys
    from ansible.module_utils.basic import AnsibleModule

    AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            state=dict(required=True),
            use_backend=dict(),
            use=dict(),
        )
    ).exit_json(**test_ActionModule_run())

# Generated at 2022-06-21 03:22:45.855844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:22:52.596776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule """

    task_vars = {}
    args = {'name': 'foo'}
    result = {}
    facts = {'ansible_facts': {'pkg_mgr': 'auto'}}

    # initialize reference to ActionBase class
    reference = ActionBase(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # create instance of class ActionModule
    instance = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # comparison of instance variables with reference
    assert instance._task == reference._task
    assert instance._connection == reference._connection
    assert instance._play_context == reference._play_context

# Generated at 2022-06-21 03:22:56.347749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''

    result = ActionModule.run(ActionModule(), None, None)
    assert(result['failed'])
    assert(result['msg'] == "parameters are mutually exclusive: ('use', 'use_backend')")

# Generated at 2022-06-21 03:23:19.308277
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:23:22.123135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This test is to test method run of class ActionModule.
    :return: None
    """
    # TODO
    pass

# Generated at 2022-06-21 03:23:30.723532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.action import ActionBase

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    action_base = ActionBase()
    action_base._shared_loader_obj = loader
    action_base._task.args['name'] = 'test'
    action_base._task.args['state'] = 'absent'
    action_base._task.action = 'test'


# Generated at 2022-06-21 03:23:38.681144
# Unit test for constructor of class ActionModule
def test_ActionModule():
  ''' unit testing for ActionModule(ActionBase) constructor '''
  module = ActionModule('task', 'play_context', 'loader', 'templar', 'shared_loader_obj')
  print("type :: ", type(module))
  print("vars(module) :: ", vars(module))
  print("dir(module) :: ", dir(module))
  print("module.__dict__ :: ", module.__dict__)
  #assert action == None


# Generated at 2022-06-21 03:23:47.673792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_run_mock_connection:
        def _shell(self):
            return _shell_mock
    class _shell_mock:
        def tmpdir(self):
            return '/tmp/ansible'
    #
    def _execute_module_mock(module_name, module_args, task_vars):
        return {'_ansible_facts': {'pkg_mgr': 'yum'}}
    #
    def _loader_mock(module):
        return True
    #
    class _ActionModule_run_mock:
        def __init__(self):
            self._templar = _templar_mock()
            self._task = _mock_task()
            self._connection = ActionModule_run_mock_connection()
            self._shared_loader_obj

# Generated at 2022-06-21 03:23:58.106469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible
    from ansible.module_utils.six.moves import builtins
    args = {'name': ['tree'], 'use_backend': 'yum'}
    loader = ansible.parsing.dataloader.DataLoader()
    task_vars = dict()
    tmp = None
    execute_mock = builtins.__dict__['exec']

    def get_module_mock(module_name, *args, **kwargs):
        if module_name == 'ansible.legacy.yum':
            return ansible.modules.legacy.yum.YumModule(*args, **kwargs)
        return ansible.modules.legacy.setup.SetupModule(*args, **kwargs)


# Generated at 2022-06-21 03:23:59.321400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert 'run' in dir(am)



# Generated at 2022-06-21 03:24:09.224620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {} # variables to pass to the module
    task_args = {} # arguments to the module

    # instantiate a mock class for the connection
    class MockConnection:
        class MockShell:
            tmpdir = ''
        _shell = MockShell()
    connection = MockConnection()

    # instantiate a mock class for the options
    class MockOptions:
        def __init__(self, value):
            self.connection = value

    # instantiate a mock class for the loader
    class MockLoader:
        def __init__(self, shell):
            self._shell = shell
            self._connection = connection
            self._options = MockOptions(connection)

        def get_basedir(self, path):
            abspath = path.split('/')
            return '/'.join(abspath[:-1])


# Generated at 2022-06-21 03:24:11.973753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=None, connection=None, play_context=None, loader=None,
        templar=None, shared_loader_obj=None
    )
    assert action_module.run() is None

# Generated at 2022-06-21 03:24:13.093251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tm = ActionModule()
    assert tm is not None
    assert isinstance(tm, ActionBase)

# Generated at 2022-06-21 03:24:50.908829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        'test',
        {
            'use': 'dnf',
            '_ansible_verbosity': 3,
            '_ansible_syslog_facility': 'LOG_USER',
            '_ansible_socket': '/tmp/test'
        },
        'test_play',
        {
            'foo': 'bar',
            'bam': 'doh'
        })

    assert action._task.async_val == 'poll'
    assert action._task.args['use'] == 'dnf'
    assert action._task.args['_ansible_verbosity'] == 3
    assert action._task.args['_ansible_syslog_facility'] == 'LOG_USER'
    assert action._task.args['_ansible_socket'] == '/tmp/test'

#

# Generated at 2022-06-21 03:24:59.213926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for ActionModule constructor
    '''
    #print("\n * id = %s, vars = %s, loader = %s, templar = %s, connection = %s, play_context = %s, shared_loader_obj = %s, \n *         action_loader = %s, remote_user = %s, remote_addr = %s, task = %s, loader_cache = %s, shell = %s, tmpdir = %s \n" %
    #      (id(my_action), my_action.vars, my_action.loader, my_action.templar, my_action.connection, my_action.play_context,
    #       my_action.shared_loader_obj, my_action.action_loader, my_action._remote_user, my_action._remote

# Generated at 2022-06-21 03:25:06.902693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ansible.legacy.yum' == ActionModule.__module__
    assert 'ActionModule' == ActionModule.__name__
    assert isinstance(ActionModule.VALID_BACKENDS, frozenset)
    assert 'yum' in ActionModule.VALID_BACKENDS
    assert 'yum4' in ActionModule.VALID_BACKENDS
    assert 'dnf' in ActionModule.VALID_BACKENDS
    assert 3 == len(ActionModule.VALID_BACKENDS)
    assert True == ActionModule.TRANSFERS_FILES



# Generated at 2022-06-21 03:25:17.046774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up a dict for simulating the needed values to be passed to
    # a _execute_module call
    test_vars = {
        '_ansible_tmpdir': '/tmp/ansible-tmp',
        'ansible_pkg_mgr': 'yum3',
        'hostvars': {
            'delegatedhost': {
                'ansible_facts': {
                    'pkg_mgr': 'yum3'
                }
            }
        }
    }

    # Mock the ActionBase.run method of the ActionModule class so that
    # we can test its run method (which is not directly tested by
    # test/units/modules/packaging/test_yum.py)

# Generated at 2022-06-21 03:25:19.766169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Instantiate the class without fail
    '''
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am is not None

# Generated at 2022-06-21 03:25:22.682362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(connection=None,
                                 _play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)
    assert action_module.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:25:23.377142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    action = ActionModule()
    assert isinstance(action, ActionBase)

# Generated at 2022-06-21 03:25:26.333452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(no_log=False, args=dict(key="val", use="yum")), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 03:25:31.087733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from iso8601 import parse_date
    from mock import patch
    from datetime import timedelta, datetime
    import time
    a = ActionModule()
    a.run(task_vars={'ansible_pkg_mgr': "yum4"})

# Generated at 2022-06-21 03:25:38.065221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import unittest
    from ansible.modules.packaging.os import yum

    # yum module is yum4, the class is the yum4 class of the module
    class Mock_yum4:
        class Module(yum.Module):
            pass
    # yum module is yum, the class is the yum class of the module
    class Mock_yum:
        class Module(yum.Module):
            pass

    # Test Case: yum backend is yum3

# Generated at 2022-06-21 03:26:32.424410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:26:35.841342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES == False
    assert module._supports_check_mode == True
    assert module._supports_async == True
    assert VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))

# Generated at 2022-06-21 03:26:36.346119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:26:43.128404
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import inspect
    # Grab all of the method definitions from the class
    method_list = inspect.getmembers(ActionModule, predicate=inspect.ismethod)

    # Ensure that we can construct an object with no arguments
    obj = ActionModule()

    # Validate that the object matches up with what we expect
    class_method_list = list()
    for method_name, method in method_list:
        if method_name not in ('run',):
            class_method_list.append(method_name)
    class_method_set = set(class_method_list)

    obj_method_list = list()
    for method_name, method in inspect.getmembers(obj, predicate=inspect.ismethod):
        obj_method_list.append(method_name)

# Generated at 2022-06-21 03:26:45.238494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:26:53.885205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display = Display()
    class MockTask(object):
        def __init__(self):
            self.args = {'name': 'test_result_ActionModule_run', 'version': '3.3'}

        def delegate_to(self):
            display.debug("delegate_to called")

        def delegate_facts(self):
            display.debug("delegate_facts called")

        def async_val(self):
            display.debug("async_val called")

    class MockModules(object):
        def __init__(self):
            self.module_loader = MockModuleLoader()
            self.module_loader.has_plugin = True

    class MockModuleLoader(object):
        def has_plugin(self):
            display.debug("has_plugin called")


# Generated at 2022-06-21 03:26:55.252041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor
    module = ActionModule()
    assert(module)

# Generated at 2022-06-21 03:26:55.832883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 03:27:04.027668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test ActionModule.run()

    Args:
        None

    Returns:
        None

    Raises:
        AssertionError if any of the tests fail
    """
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleActionFail
    from ansible.utils.display import Display
    from ansible.plugins.action.package_manager import ActionModule

    module_class = ActionModule
    action_base_class = ActionBase
    display_class = Display
    ansible_action_fail_class = AnsibleActionFail

    display.debug("Test: setup entity definitions")
    action_plugin = action_base_class()
    action_plugin._supports_check_mode = True
    action_plugin._supports_async = True

    action_plugin._task = {}
    action

# Generated at 2022-06-21 03:27:14.699935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''

    # Import module and function to test
    from ansible.plugins.action import ActionModule
    from ansible.module_utils import basic

    # Create a class that derives from class ActionModule and includes a method run
    class ActionModuleTest(ActionModule):
        '''
        Class that derives from class ActionModule and includes a method run
        '''

        def run(self, tmp=None, task_vars=None):
            '''
            Included method run.
            '''

            # Transfer return value from method ActionModule.run to return value
            # of method run
            return super(ActionModuleTest, self).run(tmp, task_vars)
    # Create object for class ActionModuleTest, run method and assert results
    action_mod_test = ActionModule

# Generated at 2022-06-21 03:29:03.769898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:29:12.581624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy class for testing
    class Dummy:
        pass

    # Dummy tmp
    tmp = None

    # Dummy task_vars
    task_vars = None

    # Dummy module
    module = "yum"

    # Dummy module_args
    module_args = {}

    # Dummy fake_module_path
    fake_module_path = "fake_module_path"

    # Dummy task
    task = Dummy()
    task.args = {
        "use": module,
    }

    # Dummy templar
    templar = Dummy()

    # Dummy module_loader
    module_loader = Dummy()
    module_loader.has_plugin = lambda arg: arg.endswith(module)

    # Dummy shared_loader_obj
    shared_loader_

# Generated at 2022-06-21 03:29:18.100892
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # instance that used to call os.path.expanduser("\~/.ansible/tmp")
  ansible_module = AnsibleModule(
    argument_spec=dict(
      use=dict(required=False, default='auto', choices=['auto', 'yum', 'yum4', 'dnf']),
      use_backend=dict(required=False, default='auto', choices=['auto', 'yum', 'yum4', 'dnf'])
    ),
    supports_check_mode=True)

# Generated at 2022-06-21 03:29:18.635785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:29:19.400969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:29:23.643382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    collectionroot = "/ansible-test/test"
    module = "yum"
    task = dict(action=dict(module=module))
    tmp = "/tmp"
    task_vars = dict()
    action_module = ActionModule(tmp, task_vars, collectionroot, task)
    result = action_module.run(tmp, task_vars)
    print(result)

# Generated at 2022-06-21 03:29:32.850800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    class Connection(object):
        def __init__(self):
            self._shell = None

        def set_shell(self, shell):
            self._shell = shell

        def _remove_tmp_path(self, path):
            pass
    class Shell(object):
        def __init__(self):
            self.tmpdir = None
            self.path_tmpdir = None

        def _create_tmp_path(self):
            self.tmpdir = "tmp"
            self.path_tmpdir = "path"
            return self.tmpdir


# Generated at 2022-06-21 03:29:34.547580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = {
        'use': 'yum'
    }
    mock_action = ActionModule(dict(module_args=module_args), {})
    mock_action._execute_module = lambda *args: {{'ansible_facts': {'pkg_mgr': 'auto'}}}

    mock_action.run()  # should not raise an exception

# Generated at 2022-06-21 03:29:38.368904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a class object
    module_obj = ActionModule()

    # Check if the class object is able to access a member variable
    x = module_obj.TRANSFERS_FILES
    assert x == False

    # Check if the class object is able to access a method
    test_tmp = None
    test_task_vars = None
    y = module_obj.run(test_tmp, test_task_vars)
    assert y == None

# Generated at 2022-06-21 03:29:41.247469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {}, {}, {})
    assert action is not None


if __name__ == '__main__':
    # Run the test case
    test_ActionModule()