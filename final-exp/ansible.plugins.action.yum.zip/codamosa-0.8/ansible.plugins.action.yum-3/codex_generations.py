

# Generated at 2022-06-11 13:04:59.849623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask(object):
        def __init__(self):
            self.args = dict()
            self.async_val = True
            self.delegate_facts = False
            self.delegate_to = None
        def __getattr__(self, name):
            if name == 'async_val':
                return True

    # To avoid update the global args with testing args, clean it after every run
    old_args = ActionBase._global_action_args.copy()

    # create an instance without any argument
    # will use the default arguments set in the global variable
    yum_action = ActionModule(FakeTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert yum_action._task.args == ActionBase._global_action_args

# Generated at 2022-06-11 13:05:00.856603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 13:05:09.357029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing variables
    hostvars = {'yum_backend_test': {'ansible_facts': {'pkg_mgr': 'auto'}}}
    tmp = None
    task_vars = {'hostvars': hostvars}
    # Setting up ActionModule
    actmod = ActionModule()
    # Setting up variables for run method
    actmod._task.async_val = False
    actmod._task.args = {'use': 'auto'}
    actmod._connection._shell.tmpdir = '/tmp/ansible_tmp'
    # Running run method
    result = actmod.run(tmp, task_vars)
    # Printing result returned by run method
    print(result)
    # Asserting success case

# Generated at 2022-06-11 13:05:20.646428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {
        'localhost': {
            'ansible_facts': {
                'pkg_mgr': 'yum'
            }
        }
    }
    module_name = 'ansible.legacy.yum'
    module_args = {
        'name': 'ansible'
    }
    fact_module = 'ansible.legacy.setup'
    fact_module_args = {
        'filter': 'ansible_pkg_mgr',
        'gather_subset': '!all'
    }
    task_vars = {
        'hostvars': hostvars
    }
    task_vars['hostvars']['localhost']['ansible_facts']['pkg_mgr'] = 'yum'
    mock_task = Mock()
    mock_task

# Generated at 2022-06-11 13:05:21.236099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:05:32.114051
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # use mock classes to get assert equivalent of assertRaisesRegexp
    class mock_task():
        args=dict()
    class mock_templar():
        def template(self, template):
            if template.startswith('{{hostvars'):
                return 'hostvars'
            return 'auto'
    class mock_action():
        def __init__(self):
            self._task = mock_task()
            self._templar = mock_templar()
            self.action_result = dict()
        def run(self, tmp=None, task_vars=None):
            self.action_result = module_action.run(self, tmp, task_vars)

# Generated at 2022-06-11 13:05:40.063922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")

    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    import mock

    # Initialize class ActionModule for testing
    cls = ActionModule(None)

    # Define types of variables
    module_name = None
    action_plugin_path = None
    module_path = None
    task_vars = None

    # Define values of variables
    module_name = 'yum'
    action_plugin_path = '/path/to/action_plugins'
    module_path = '/path/to/modules'
    _load_name_to_path_mappings = {'yum': 'ansible.legacy.yum'}

# Generated at 2022-06-11 13:05:50.835633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import unittest
    #import pdb; pdb.set_trace()
    sys.path.append('/usr/share/ansible')
    sys.modules['ansible'] = mock.MagicMock()
    sys.modules['ansible.errors'] = mock.MagicMock()
    sys.modules['ansible.module_utils'] = mock.MagicMock()
    sys.modules['ansible.module_utils.parsing.dataloader'] = mock.MagicMock()
    sys.modules['ansible.module_utils.basic'] = mock.MagicMock()
    sys.modules['ansible.module_utils.facts'] = mock.MagicMock()
    sys.modules['ansible.module_utils.facts.system'] = mock.MagicMock()
    sys.modules

# Generated at 2022-06-11 13:06:00.742420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(name=['bash', 'openssh-server'], state='latest', use='auto')
    module = ActionModule(task=dict(args=args))
    result = module.run(task_vars=dict(ansible_facts=dict(pkg_mgr="dnf")))
    assert result.get('msg') == "dnf is not installed"

    result = module.run(task_vars=dict(ansible_facts=dict(pkg_mgr="yum")))
    assert result.get('msg') == "yum is not installed"

    args = dict(name=['bash', 'openssh-server'], state='latest', use='auto')
    module = ActionModule(task=dict(args=args))
    result = module.run(task_vars=dict())

# Generated at 2022-06-11 13:06:07.627852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_instance = ActionModule(None, {})

    # testing edge case when a module is specified in args
    # valid module is yum || dnf || auto
    test_module = 'auto'
    module = ActionModule_instance._task.args.get('use', ActionModule_instance._task.args.get('use_backend', 'auto'))
    test_result = {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend."}
    assert module == test_module
    assert test_result == ActionModule_instance.run(None, None)['failed']

# Generated at 2022-06-11 13:06:15.028866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 13:06:25.085417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat import mock
    from ansible.plugins.action.yum import ActionModule
    from ansible.utils.display import Display
    from ansible.executor.task_result import TaskResult

    display = Display()
    display.display = mock.MagicMock(return_value=None)

    action = ActionModule()

    # 1st test case: 'use_backend' in task.args and 'use' in task.args
    action._task = mock.MagicMock()
    action._task.args = {'use': 'auto', 'use_backend': 'yum'}
    action._task.delegate_to = None
    action._task.delegate_facts = None
    action._task.async_val = None

    # 1st test case: 'use_backend' in task.args

# Generated at 2022-06-11 13:06:36.615400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import json
    import os


# Generated at 2022-06-11 13:06:44.416790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import mock
    module = ActionModule(
        task=dict(args=dict(name=['git'])),
        connection=mock.Mock(),
        play_context=mock.Mock(),
        loader=mock.Mock(),
        templar=mock.Mock(),
        shared_loader_obj=mock.Mock(),
    )
    module._execute_module.return_value = dict(name=['git'])
    assert module.run() == dict(name=['git'])



# Generated at 2022-06-11 13:06:45.687944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() is not None

# Generated at 2022-06-11 13:06:46.580397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError


# Generated at 2022-06-11 13:06:47.147244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 13:06:48.624428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 13:06:58.312591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for ActionModule class
    """
    action_module = ActionModule()

    with pytest.raises(AnsibleActionFail):
        action_module.run()

    # test empty module
    action_module._task.args = {'use': None, 'use_backend': None}
    with pytest.raises(AnsibleActionFail):
        action_module.run()

    # test invalid module
    action_module._task.args = {'use': 'foo', 'use_backend': 'bar'}
    with pytest.raises(AnsibleActionFail):
        action_module.run()

    # test valid module
    action_module._task.args = {'use': 'yum3', 'use_backend': 'yum4'}
    action_module.run()

# Generated at 2022-06-11 13:07:09.075834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assume that ansible.legacy.setup module is available
    from ansible.plugins.loader import module_loader
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import action_loader

    task = DummyTask()
    action = ActionModule(task, DummyConnection())

    # Get ansible.module_utils.common.run_command
    run_command = module_loader.find_plugin('ansible.legacy.command', '_run_command')

    # and monkey-patch it with a dummy implementation
    import ansible.module_utils.common

# Generated at 2022-06-11 13:07:26.997069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Init class object
    test_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Get uninitialized attributes
    attrs = vars(test_obj)

    # Check attributes are initialized
    assert len(attrs) == 2

# Generated at 2022-06-11 13:07:29.565920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module=ActionModule(None, None)
  module.task=None
  result = module.run(None)
  print(result)

# Generated at 2022-06-11 13:07:35.684627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts import get_facts
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    context.CLIARGS = {}
    context._init_global_context(**context.CLIARGS)

    assert True

# Generated at 2022-06-11 13:07:37.116970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    module = actionModule.run()
    assert 'failed' in module

# Generated at 2022-06-11 13:07:45.197272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for ActionModule.
    """
    _inject = {}
    _inject['connection'] = FakeConnection()
    _inject['display'] = Display()
    _inject['task'] = FakeTask()
    _inject['loader'] = DictDataLoader({})
    _inject['templar'] = FakeTemplar()
    _inject['task_queue_manager'] = None
    _inject['shared_loader_obj'] = FakeSharedLoaderObj()

    am = ActionModule(_inject)
    assert am is not None



# Generated at 2022-06-11 13:07:46.370418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 13:07:47.383524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 13:07:49.717712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Test attributes of the instance
    assert action_module.TRANSFERS_FILES == False
    assert action_module._supports_async == True
    assert action_module._supports_check_mode == True


# Generated at 2022-06-11 13:07:56.856463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_object = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task = dict()
    task["args"] = dict()
    task["args"]['use_backend'] = 'yum'
    task_vars = dict()
    tmp = None
    action_module_object.run(tmp, task_vars)


# Generated at 2022-06-11 13:07:57.930072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x

# Generated at 2022-06-11 13:08:29.984601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import Mock, patch
    from ansible.plugins.action import ActionBase

    from ansible.executor.task_result import TaskResult

    MockBase = Mock()

    class MockTask(object):
        def __init__(self, async_val):
            self.async_val = async_val
            self.notified_by = dict()
            self.run_once = False
            self.no_log = False
            self.register = 'shell_out'
            self.action = dict()
            self.args = dict()
            self.changed_when = None
            self.failed_when = None
            self.dep_chain = None


# Generated at 2022-06-11 13:08:40.404561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  _ActionBase = ActionBase()
  _ActionBase.display = Display()
  _ActionModule = ActionModule(_ActionBase)
  task_vars = {
    "ansible_facts": {
      "pkg_mgr": "yum"
    }
  }
  _ActionModule._task.args = {
    "use": "auto"
  }

  _ActionModule._task.delegate_to = None
  assert _ActionModule.run(tmp=None, task_vars=task_vars)
  _ActionModule._task.args = {
    "use": "auto"
  }
  _ActionModule._task.delegate_to = "abc123"
  assert _ActionModule.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-11 13:08:43.364377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_module_args():
        t = ActionModule()
        t._task = Mock()
        t._task.args = {}
        t.run(None, {})
        assert t.run(None, None)

# Generated at 2022-06-11 13:08:43.990590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 13:08:52.136671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible
    import ansible.modules.legacy.yum

    module = ansible.modules.legacy.yum.ActionModule()

    # yum3
    assert module.run({}, {'ansible_pkg_mgr': 'yum'}) == dict(module='ansible.legacy.yum')

    # yum4
    assert module.run({}, {'ansible_pkg_mgr': 'dnf'}) == dict(module='ansible.legacy.dnf')

    # dnf
    assert module.run({}, {'ansible_pkg_mgr': 'dnf'}) == dict(module='ansible.legacy.dnf')

    # Attempt to load non-existent Ansible module

# Generated at 2022-06-11 13:08:52.968606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass  # No unit tests

# Generated at 2022-06-11 13:08:53.870777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

# Generated at 2022-06-11 13:09:04.237442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display

    display = Display()

    class ActionModule_instance(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            # initialize our super class
            super(ActionModule_instance, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

    # define test variables:
    #
    # _task is the dict that normally would be created in the yum module
    # and then passed to the class ActionModule higher up in the hierarchy

# Generated at 2022-06-11 13:09:12.209942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _args = dict(
        name='bash',
        state='present'
    )
    action = ActionModule(None, dict(
        _ansible_date_time=dict(),
        _ansible_no_log=False,
        _ansible_verbosity=2,
        _ansible_version=dict(
            string='2.6.3',
            full=dict(
                major=2,
                minor=6,
                patch=3,
                serial=10003003,
                debug=False
            ),
            major=2,
            minor=6,
            patch=3,
            serial=10003003,
            debug=False
        ),
        use='yum'
    ), _args, 'plugin', 'action')
    return action

if __name__ == '__main__':
    action

# Generated at 2022-06-11 13:09:22.199861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, None)
    module.set_loader = None
    module.set_task = None
    module.set_connection = None
    module.set_play_context = None

    module._task.args = {}
    assert module.run(None, None)['msg'] == ("Could not detect which major revision of yum is in use, which is required to determine module backend.", "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")

    module._task.args = {'use': 'non-existent'}
    assert module.run(None, None)['msg'] == "Could not find a yum module backend for non-existent."

    module._task.args = {'use_backend': 'yum'}

# Generated at 2022-06-11 13:10:14.599536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert not module.TRANSFERS_FILES, 'TRANSFERS_FILES should be False'
    assert module._supports_check_mode, '_supports_check_mode should be True'
    assert module._supports_async, '_supports_async should be True'

# Generated at 2022-06-11 13:10:24.089422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import unittest

    class ActionModule_Test(unittest.TestCase):

        def test_ActionModule_1(self):
            # Constructor test 1
            am = ActionModule(
                task=dict(
                    async_val=None,
                    delegate_facts=True,
                    delegate_to=None,
                    noop=False,
                    poll=0,
                    sudo=False,
                    sudo_user=None,
                    become=False,
                    become_method=None,
                    become_user=None,
                    become_flags=None,
                    tags=[],
                    run_once=False,
                    args=dict(use="dnf")
                )
            )
            self.assertEqual(am._supports_check_mode, True)

# Generated at 2022-06-11 13:10:26.960469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    am = ansible.plugins.action.ActionModule()
    am._supports_check_mode = True
    am._supports_async = True

# Generated at 2022-06-11 13:10:29.446428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-11 13:10:30.026631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 13:10:37.757488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock = MagicMock()
    mock_module_backend_installed = mock.return_value.module_loader.has_plugin

    mock_module_backend_installed.return_value = True
    mock_module_backend_installed.return_value = True

    mock_module_args = {}

    mock_delegate_to = 'host'

    module = ActionModule(mock, mock_module_args, mock_module_backend_installed, mock_delegate_to)
    module.run()

    assert mock_module_backend_installed.called

# Generated at 2022-06-11 13:10:42.093425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing the constructor of the class ActionModule")
    action_module = ActionModule(connection=None,
                                 task=None,
                                 shared_loader_obj=None,
                                 templar=None,
                                 environment=None)
    print("Test completed")

# test_ActionModule()

# Generated at 2022-06-11 13:10:42.682761
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True

# Generated at 2022-06-11 13:10:45.528248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Instantiate the ActionModule class and call the run method"""
    action_module = ActionModule(task=dict())
    action_module.run(task_vars=dict())

# Generated at 2022-06-11 13:10:52.466536
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 13:12:41.205181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    class MockActionModule(ActionModule):
        '''
        Mock class for the AnsibleActionModule object
        '''
        def __init__(self, task_args, task_vars=None):
            self._task = task_args
            self._templar = MockTemplar(task_vars)
            self._shared_loader_obj = SharedPluginLoaderObj()
            self._connection = MockConnection(self._task['delegate_to'])

        def run(self, tmp=None, task_vars=None):
            '''
            Method to test the run method of the AnsibleActionModule class
            '''
            return super(MockActionModule, self).run(tmp, task_vars)


# Generated at 2022-06-11 13:12:50.714190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test whether ActionModule().run() is working
    '''

    # make a module object
    module = ActionModule()

    # Set up test conditions
    # The following are test cases for testing ActionModule().run
    #
    # Note: The value of 'use_backend' and 'use' is used in the test case 'name'
    #
    # The following keys are used in the following test cases:
    #   'args'                     - args to be used in the run() method
    #   'expected_module_name'     - expected module name to be used for executing the backend action plugin
    #   'expected_module_args'     - expected module args to be used for executing the backend action plugin
    #   'delegate_to'              - simulate the case where the host where the task runs is different from the host the task targets


# Generated at 2022-06-11 13:12:53.784485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor without parameters
    action_module = ActionModule()
    assert action_module is not None
    assert action_module.name() == 'yum'
    assert action_module.version() == '0.0.1'

# Generated at 2022-06-11 13:13:03.331872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {}
    task_vars = {'hostvars': hostvars}
    action_module = ActionModule()
    action_module._task.args = {'use': 'auto'}
    action_module._task.delegate_to = None
    action_module._task.delegate_facts = None
    action_module._templar.template._fail_on_undefined_errors = False
    result = action_module.run(None, task_vars)
    assert 'failed' in result and result['failed'] == True
    assert 'msg' in result

    hostvars = {'yum_test': {'ansible_facts': {'pkg_mgr': 'yum'}}}
    task_vars = {'hostvars': hostvars}
    action_module = ActionModule()


# Generated at 2022-06-11 13:13:10.293253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.context import CLIContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import PluginLoader
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.playbook_executor import PlaybookExecutor
    from tests.common.mock.socket_connection import SocketConnection
    from ansible.executor.task_executor import TaskExecutor
    import ansible.constants as C
    import json
    import pytest

# Generated at 2022-06-11 13:13:11.077621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 13:13:21.017833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _get_class_instance(func):
        from ansible.plugins.action import ActionBase
        from ansible.plugins.action.yum import ActionModule
        class TestOne(ActionBase):
            pass
        class TestTwo(ActionModule):
            pass
        class TestThree(TestTwo):
            def run(self, *args, **kwargs):
                return func(*args, **kwargs)
        return TestThree()

    def _get_task_mock():
        task_mock = MagicMock()
        task_mock.async_val = False
        task_mock.args = dict(use_backend="yum")
        task_mock.delegate_facts = False
        return task_mock

    # test to verify the use case where use_backend is in the args.

# Generated at 2022-06-11 13:13:31.965369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import MagicMock
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.action.yum import ActionModule

    # Initializing the arguments required to construct the object of class ActionModule
    task_vars = dict()
    loader = plugin_loader
    display = Display()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    host = MagicMock()
    host.name = "hostname"
    host.get_vars.return_value = dict()
    host

# Generated at 2022-06-11 13:13:32.500870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-11 13:13:39.291503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run method of class ActionModule")

    mock_task = Mock(spec=dict)
    mock_task.args = dict()
    mock_task.args['package_name'] = 'testpackage'
    mock_task.args['state'] = 'present'

    mock_task.args['use_backend'] = 'yum4'
    # create an instance of type ActionModule
    action = ActionModule()
    action._task = mock_task
    # apply the run method
    result = action.run(tmp=None, task_vars=None)

    # verify if the result is as expected
    if result['changed'] == True:
        print("PASS")
    else:
        print("FAIL")
        assert (False)


from ansible.playbook.task import Task