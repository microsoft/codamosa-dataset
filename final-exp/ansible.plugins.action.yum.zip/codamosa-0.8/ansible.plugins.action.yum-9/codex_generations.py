

# Generated at 2022-06-11 13:05:01.265038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    facts = Facts({})
    actionModule = ActionModule(None, None)

    def mock_get_task_vars():
        return {'ansible_facts': facts.items()}

    actionModule.get_task_vars = mock_get_task_vars

    module = actionModule.run(None, None)
    assert module['failed'] == True
    assert module['msg'] == "new_module_args is not a dictionary"

    module = actionModule.run(None, {'ansible_pkg_mgr': 'yum3'})
    assert module['failed'] == False

    module = actionModule.run(None, {'ansible_pkg_mgr': 'yum4'})
    assert module['failed'] == False

# Generated at 2022-06-11 13:05:02.714196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(1, 2, 3, 4) is not None

# Generated at 2022-06-11 13:05:07.580069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test raised exception
    test_args = {'use': 'bad_backend'}
    obj = ActionModule(task={"args": test_args})
    assert obj.run()['failed']

    # Test good instantiation
    test_args = {'use': 'yum'}
    obj = ActionModule(task={"args": test_args})
    assert not obj.run()['failed']

# Generated at 2022-06-11 13:05:18.961565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import become_loader, module_loader

    become_loader.add_directory(dict(path=['/usr/local/lib/python2.7/site-packages/ansible/plugins/become']))
    module_loader.add_directory(dict(path=['/usr/local/lib/python2.7/site-packages/ansible/plugins/modules']))


# Generated at 2022-06-11 13:05:28.166953
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ansible_facts = {
        'pkg_mgr': 'auto'
    }
    yum_action_plugin = ActionModule(
        {
            'use': 'auto',
            'use_backend': 'auto'
        }, ansible_facts
    )

    res = yum_action_plugin.run({}, {})
    assert res['failed'] == True
    assert res['msg'] == ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                          "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")

# Generated at 2022-06-11 13:05:28.787108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:05:33.005642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.plugins.loader import action_loader

    action = action_loader.get('yum', class_only=True)

    # No module specified
    args = dict()
    result = action.run(task_vars='task_vars', **args)

    assert result.get('failed')

# Generated at 2022-06-11 13:05:33.900495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-11 13:05:34.558111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fixme: Unittesting
    pass

# Generated at 2022-06-11 13:05:36.993079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the class
    testModule = ActionModule(None, None, None, None, None)
    # Check the object have all the proper value
    assert testModule.VALID_BACKENDS == ('yum', 'yum4', 'dnf')

# Generated at 2022-06-11 13:05:46.316857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockActionBase(ActionBase):
        def __init__(self, connection):
            self._connection = connection
    module = ActionModule(MockActionBase('connection'))
    assert module is not None

# Generated at 2022-06-11 13:05:57.067267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars

    # method to test run method dependency
    def _execute_module(module_name=None, module_args=None, task_vars=None, wrap_async=None):
        return combine_vars(task_vars, {})

    test_case = dict(
        _task=dict(
            args=dict(
                use_backend='yum'
                )
            ),
        _shared_loader_obj=dict(
            module_loader=dict(
                has_plugin=lambda module: True
                )
            ),
        _execute_module=_execute_module
    )

    action_module = ActionModule()
    action_module.__dict__.update(test_case)

# Generated at 2022-06-11 13:06:01.266406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with a valid module
    module = ActionModule(dict(use="yum4"))
    # test with a not valid module
    module = ActionModule(dict(use="pip"))
    assert "Could not detect which major revision of yum is in use, which is required to determine module backend." in module.run().get("msg")

# Generated at 2022-06-11 13:06:10.860858
# Unit test for constructor of class ActionModule
def test_ActionModule():
  import os.path
  from ansible.playbook.play_context import PlayContext
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  pm = PlaybookExecutor([os.path.join(os.path.dirname(__file__), 'test_action_module.yml')])
  pm._read_vault_password_file = lambda: 'ansible'
  pm._tqm._terminated = True
  pm._tqm._stdout_callback = lambda *x: True
  pm._tqm._stats = lambda: {'skipped': {}, 'ok': {}, 'changed': {}, 'failures': {}, 'processed': {}}

# Generated at 2022-06-11 13:06:19.025935
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test object initialization
    action = ActionModule()

    # test attributes of class object
    assert(action._supports_check_mode == True)
    assert(action._supports_async == True)
    assert(action.TRANSFERS_FILES == False)
    assert(action.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf')))
    assert(type(action.display) == Display)

    return

# Generated at 2022-06-11 13:06:22.050438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()
    module.run(tmp="temp", task_vars="taskvars")

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 13:06:23.455445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode
    assert action_module._supports_async

# Generated at 2022-06-11 13:06:30.897020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {'use_backend': 'yum'}
    module._task.async_val = False
    module._templar = None
    module._supports_check_mode = True
    module._shared_loader_obj = None
    module._templar = None
    module._connection = None
    module._templar = None
    module._supports_async = True
    module._action = None
    module._task.delegate_to = None
    result = module.run()

# Generated at 2022-06-11 13:06:42.218459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.modules.packaging.package.yum import HAS_YUM
    from ansible.modules.packaging.package.dnf import HAS_DNF

    original_yum = HAS_YUM
    original_dnf = HAS_DNF

    HAS_YUM = True
    HAS_DNF = True
    module = ActionModule()
    module.set_runner(MagicMock(run_async=True, connection=MagicMock(container=None)))
    task = MagicMock()
    task.async_val = False
    module._task = task

    module._task.args = {'name': "test"}

# Generated at 2022-06-11 13:06:50.667705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class OptionsModule(object):
        verbosity = 0
        action_plugins = None
    class Options(object):
        module_path = None
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        remote_user = 'root'
        private_key_file = None
        connection = 'smart'
        timeout = 10
        ssh_common_args = None
        sftp_extra_args = None
        scp_extra_args = None
        ssh_extra_args = None
        verbosity = 0
        syntax = None
        start_at_task = None
        accelerate = True
        accelerate_ipv6 = True
    class Task(object):
        async_val = None
        _role = None
        _role_name = None

# Generated at 2022-06-11 13:07:03.567479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 13:07:04.596748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 13:07:12.859103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up the test
    module = ActionModule()

    # run the test
    assert module.run() == {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend. You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})", 'module_stdout': '', 'module_stderr': ''}

    # run the test
    assert module.run() == {'failed': True, 'msg': "Could not find a yum module backend for ansible.legacy.yum4.", 'module_stdout': '', 'module_stderr': ''}

    # run the test

# Generated at 2022-06-11 13:07:24.186604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    import os
    import sys
    import tempfile
    import json
    import pytest
    from ansible_collections.ansible.community.tests.unit.plugins.modules.utils import set_module_args

    display = Display()
    sys.path.append(os.path.curdir)
    (fd, test_file) = tempfile.mkstemp()
    os.close(fd)
    os.unlink(test_file)


# Generated at 2022-06-11 13:07:35.188418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with minimal data to provide maximum coverage for ActionModule.run().
    # Even then this is only a small fraction of the coverage
    # that can be achieved by running the action module.

    # NOTE: We do not test this with delegation, because delegation is
    #       irrelevant if the remote system uses a yum3 or yum4 backend.

    # Test with an empty module_args
    task = dict(args=dict())
    connection = {}
    display = {}
    templar = MagicMock()
    shared_loader_obj = MagicMock()
    mock_module = MagicMock()

    am = ActionModule(task, connection, templar, shared_loader_obj)
    am._display = display
    am._execute_module = lambda m, ma, t, wrap_async=False: ma  # noop
    am

# Generated at 2022-06-11 13:07:44.827935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = Connection()  # get a dummy connection
    task = Task()  # get a dummy task
    task.async_val = 'A'
    task.args = {}
    # prepare a facts object
    facts = {
        'ansible_facts': {'pkg_mgr': 'yum'},
        'ansible_proc_facts': {'pkg_mgr': 'yum'},
    }

    # run the method
    am = ActionModule(conn, 'dummy_task', tmp=None, task_vars=facts)
    res = am.run()

    # check the result
    assert (res == {'ansible_facts': {'pkg_mgr': 'yum'}})
    assert (am._task.async_val == 'A')
    assert (am._task.args == {})

# Generated at 2022-06-11 13:07:55.870241
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import mock
    import distutils.version
    assert hasattr(distutils.version, "StrictVersion")
    import sys
    import os

    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    import collections
    collections_mock = mock.MagicMock()
    collections_mock.__getitem__.side_effect = lambda x, y: collections.__dict__[y]
    builtins.__dict__['collections'] = collections_mock

    hasattr_mock = mock.MagicMock()
    hasattr_mock.has_attr = lambda x, y: True
    builtins.__dict__['hasattr'] = hasattr_mock

    os_mock = mock.MagicMock()
    os_mock

# Generated at 2022-06-11 13:08:02.089045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    test_action_module = TestActionModule(
        task=dict(args=dict(use_backend='yum')), connection=dict(), play_context=dict(),
        loader=None, templar=None, shared_loader_obj=None
    )

    assert test_action_module._task.args['use_backend'] == 'yum'

# Generated at 2022-06-11 13:08:02.948687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 13:08:14.336378
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()
    display.verbosity = 2

    # Patch away the modules_path
    monkeypatch_ActionModule_run = (
        lambda self, tmp=None, task_vars=None:
        unfrackpath("/home/bmacan/Projekti/ansible/test/units/module_utils/ansible_collections/ansible/os_family/dnf.py")
    )

    monkeypatch_ActionModule_load_action_plugin = lambda self, action: None

# Generated at 2022-06-11 13:08:39.392335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module is not None)

# Generated at 2022-06-11 13:08:43.549859
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert ActionModule(
      task=dict(action=dict(module_name='yum', module_args=dict(name='httpd',state='present'))),
      connection=dict(),
      play_context=dict(),
      loader=dict(),
      templar=dict(),
      shared_loader_obj=dict())

# Generated at 2022-06-11 13:08:49.517095
# Unit test for constructor of class ActionModule
def test_ActionModule():    
    mock_action = ActionModule(
                task = dict(action = dict(module_name = 'yum', module_args = dict(state='installed', name='ansible')),
                            async_val =  False,
                            delegate_to = None,
                            delegate_facts = None
                            )
                )

    assert mock_action.run() == {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend."}



# Generated at 2022-06-11 13:08:59.762364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''unit test for method run of class ActionModule'''
    import pytest
    from mock import Mock, patch

    action_module = ActionModule()

    mock_run_result = {"failed": False}

    mock_module_loader_obj = Mock()
    mock_module_loader_obj.has_plugin.return_value = True

    task_vars = {}
    tmp = None

    # yum3 backend
    mock_task = Mock()
    mock_task.args = {"use_backend": "yum"}
    mock_templar = Mock()
    mock_shell = Mock()
    mock_shell.tmpdir = '/tmp'
    mock_connection = Mock()
    mock_connection._shell = mock_shell

    action_module._shared_loader_obj = mock_module_loader_obj


# Generated at 2022-06-11 13:09:09.186734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # hostvars is a dict of dicts. The key is the host name and the value is defined by the _get_host_vars function
    hostvars = {'somehost': {'pkg_mgr': 'dummy'}}
    # loader is an object with a _get_host_vars method that returns hostvars
    loader = type('', (object,), {'_get_host_vars': lambda self, host: hostvars[host]})()
    # inventory is an object with a loader property
    inventory = type('', (object,), {'loader': loader})()

    # Make a task, import the yum action plugin and instantiate the yum action plugin object
    task = type('', (object,), {'delegate_to': 'somehost', 'delegate_facts': True})()
    ActionModule_

# Generated at 2022-06-11 13:09:11.951013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test the constructor of ActionModule
    """

    am = ActionModule()

    assert am is not None
    assert am._supports_check_mode is True
    assert am._supports_async is True


# Generated at 2022-06-11 13:09:12.689816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 13:09:17.701856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    os.chdir(test_dir)

    _action_plugins_path = os.path.join(os.getcwd(), 'action_plugins')
    os.makedirs(_action_plugins_path)


# Generated at 2022-06-11 13:09:18.275550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:09:29.247047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\nUnit test start")

    # Initialization
    test_module_arguments = {
        "use" : "auto",
        "name": "nginx",
        "state": "latest"
    }
    test_task_vars = {
        "ansible_facts": {
            "pkg_mgr": "yum",
            "ansible_pkg_mgr": "yum"
        }
    }
    test_instance = ActionModule()

    print("\nTest execution")
    test_instance._task.args = test_module_arguments
    result_run = test_instance.run(
        tmp="/tmp", task_vars=test_task_vars)

    # This "test" is not really a test, it just verifies that the method
    # can be executed without raising an exception

# Generated at 2022-06-11 13:10:18.665490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None) is not None

# Generated at 2022-06-11 13:10:19.692447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 13:10:26.671186
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 13:10:28.101061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.yum as yum
    assert yum

# Generated at 2022-06-11 13:10:38.795532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # ansible.legacy.yum and ansible.legacy.dnf modules need to be loaded
    # before we can test this class
    import ansible.legacy.yum
    import ansible.legacy.dnf

    loader = DataLoader()

    # Set up the inventory
    inventory = InventoryManager(loader=loader, sources='')

    # Set up the variables
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()

    # Set up the test
    temp

# Generated at 2022-06-11 13:10:48.351260
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_plugin = ActionModule()

    # test RETURN attribute in class ActionModule instance action_plugin
    assert isinstance(action_plugin.RETURN, dict)
    assert not action_plugin.RETURN
    assert action_plugin.RETURN == {}

    # test TRANSFERS_FILES attribute in class ActionModule instance action_plugin
    assert isinstance(action_plugin.TRANSFERS_FILES, bool)
    assert action_plugin.TRANSFERS_FILES == False
    assert not action_plugin.TRANSFERS_FILES

    # test _supports_async attribute in class ActionModule instance action_plugin
    assert isinstance(action_plugin._supports_async, bool)
    assert action_plugin._supports_async == True
    assert not action_plugin._supports_async

    # test _supp

# Generated at 2022-06-11 13:10:56.121471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for the action plugin module run method"""

    module = ActionModule()
    task_vars = {
        'ansible_pkg_mgr': 'yum',
        'hostvars': {
            'localhost': {
                'ansible_facts': {
                    'pkg_mgr': 'yum'
                }
            }
        }
    }

    # Test 'auto' detection
    result = module.run(task_vars=task_vars)
    assert result['ansible_facts']['pkg_mgr'] == 'yum'
    assert result['invocation']['module_name'] == 'yum'

    # Test 'auto' detection with failed delegation
    result = module.run(task_vars=task_vars, tmp='/does/not/exist')

# Generated at 2022-06-11 13:10:57.004048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 13:11:06.094476
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # AnsibleModuleTestCase was only added in Ansible 2.9
    try:
        from ansible.testing.mock import patch
        AMTC = patch('ansible.module_utils.basic.AnsibleModule')
        amtc = AMTC.start()
        amtc.return_value = None
    except:
        pass

    hostvars = {
        "somehost": {
            "ansible_facts": {
                "pkg_mgr": "yum"
            }
        }
    }

    # Test for the constructor of class ActionModule
    module = ActionModule({}, {})
    assert module
    assert isinstance(module, ActionModule)

    # test for _execute_module
    # TODO: need to mock the module

# Generated at 2022-06-11 13:11:15.174493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the class object
    class_obj = ActionModule()
    class_obj._task = dict()
    class_obj._task['async_val'] = 3
    class_obj._task['args'] = dict()
    class_obj._task['args']['use'] = 'yum'
    class_obj._task['delegate_facts'] = False
    class_obj._task['delegate_to'] = '127.0.0.1'
    class_obj._task_vars = dict()
    class_obj._shared_loader_obj = dict()
    class_obj._shared_loader_obj['module_loader'] = dict()
    class_obj._shared_loader_obj['module_loader']['has_plugin'] = 'yum'
    class_obj._execute_module = 'yum'
   

# Generated at 2022-06-11 13:13:05.179911
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 13:13:07.726000
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    assert module._supports_check_mode
    assert module._supports_async
    assert module.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))

# Generated at 2022-06-11 13:13:16.720255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class __module__:
        def __init__(self):
            self.params = {
                'name': 'python3-sh',
                'state': 'present',
            }

    class __task__:
        def __init__(self):
            self.args = __module__().params
            self.delegate_to = None
            self.delegate_facts = None
            self.async_val = 0

    class __playbook__:
        def __init__(self):
            self.become = True
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.remote_user = 'root'

    class __loader__:
        def __init__(self):
            self.basedir = 'root'


# Generated at 2022-06-11 13:13:17.315807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 13:13:27.741270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run action method.

    Test run method sets the backend to use based on the host facts
    """
    import json
    from ansible.module_utils.six import StringIO

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test for module yum3 selected
    temp_stdout = StringIO()
    temp_stdout.seek(0)

    facts = {
        "ansible_facts": {
            "pkg_mgr": "yum"
        }
    }
    args = dict(
        use_backend="auto"
    )


# Generated at 2022-06-11 13:13:37.089036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = None

    # Test 1
    a = ActionModule()
    tmp = "/tmp"
    task_vars = dict(
        ansible_pkg_mgr='yum',
        ansible_facts=dict(pkg_mgr='yum4', ansible_pkg_mgr='yum4')
    )
    a._task.args = dict(use='auto')
    a._task.delegate_facts = False
    try:
        results = a.run(tmp, task_vars)
    except Exception as e:
        print("Exception in run of ActionModule: " + str(e))
    finally:
        assert results['failed'] == False
        assert results['msg'] == "TASK [yum : Ensure packages are installed."

# Generated at 2022-06-11 13:13:38.464415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate an object of class ActionModule and assert that it is the correct class
    assert type(ActionModule()) == ActionModule


# Generated at 2022-06-11 13:13:42.221585
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Construct a mock TaskExecutor
    fake_task_executor = TaskExecutor()

    # Create an instance of ActionModule class
    am = ActionModule(connection=None, task_executor=fake_task_executor)

    # Assert that ActionModule instance was created
    assert am is not None

# Generated at 2022-06-11 13:13:46.967395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(
            uuid='f6b4bb69-46a1-4bde-9c73-42e4f07f1e40',
            action='yum',
            args={},
            async_val=False,
            delegate_to='remote'
        )
    )
    assert action._task['action'] == 'yum'

# Generated at 2022-06-11 13:13:57.992854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    # Build test args
    action_args = dict(
        use="auto"
    )

    # Build test task
    test_task = TaskInclude.load(
        dict(
            include='test_action_module_test',
        )
    )
    test_task._parent = Block
    test_task._role = None
    test_task.loop = None
    test_task.args = action_args
    test_task.vars = dict()
    test_task.default_vars = dict()
    test_task.action = 'yum'

    # Build test action_module