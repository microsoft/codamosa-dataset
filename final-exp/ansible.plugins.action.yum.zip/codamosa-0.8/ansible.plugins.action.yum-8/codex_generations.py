

# Generated at 2022-06-11 13:04:57.133740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test parameters
    tmp = None
    task_vars = dict(ansible_facts=dict(pkg_mgr='yum'))

    action_module = ActionModule()
    action_module.C.HOST_KEY_CHECKING = False

    # Test run
    result = action_module.run(tmp, task_vars)

    # Assertions
    assert 'ansible_facts' in result
    assert 'pkg_mgr' in result['ansible_facts']
    assert result['ansible_facts']['pkg_mgr'] == 'yum'

# Generated at 2022-06-11 13:05:07.259577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Check the implementation of run() method of the ActionModule class.
    """
    # mock the ansible module call
    def run(self, tmp=None, task_vars=None):
        return {'failed': False, 'msg': ""}

    # mock the template execution
    def template(self, template):
        return "dnf"

    # mock the execute_module
    def execute_module(self, module_name, module_args, task_vars=None, wrap_async=None):
        return {'failed': True, 'msg': ""}

    # mock the has_plugin method
    def has_plugin(self, module):
        return True

    # Instantiate the ActionModule class and set the mocked objects
    module = ActionModule()
    module._execute_module = execute_module

# Generated at 2022-06-11 13:05:18.620036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class DummyModule:
        def __init__(self, task=None):
            self.task = task

    class DummyTask:
        def __init__(self, args=None):
            self.args = args

    class DummyConnection:
        def __init__(self, tmpdir=None):
            self.tmpdir = tmpdir

        def _shell(self):
            return self

    class DummyShell:
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

    ansible_connection = DummyConnection(tmpdir="ansible")
    dummy_shell = DummyShell(tmpdir="ansible")
    ansible_connection._shell = lambda: dummy_shell

# Generated at 2022-06-11 13:05:29.729477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the yum action plugin

    # Test yum4 backend selection experience with different args
    import json
    import unittest

    class TestActionModule_Run(unittest.TestCase):
        def runTest(self):
            display = Display()
            display.verbosity = 4
            result = ActionModule.run(
                None, {
                    'use_backend': 'yum4',
                    'args': '',
                    'module': None,
                    'items': [],
                    'name': None,
                    'package': None,
                    'state': None
                },
                {'ansible_facts': {
                    'pkg_mgr': 'yum'
                }})

# Generated at 2022-06-11 13:05:36.230410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'yum'
    connection = MagicMock()
    task_vars = {}
    loader = MagicMock()
    tmp = None
    task_path = None
    runner = MagicMock()
    task = Mock()

    # test the constructor
    yum_module = ActionModule(
        connection=connection, task_vars=task_vars, loader=loader, tmp=tmp,
        task_path=task_path, module_name=module_name, runner=runner, task=task)
    assert yum_module.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-11 13:05:37.910739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO create a unit test to test the method run of class ActionModule
    pass


# Generated at 2022-06-11 13:05:39.237709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert type(action) == ActionModule

# Generated at 2022-06-11 13:05:44.167878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_constructor():
        am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        assert am._supports_check_mode
        assert am._supports_async
        assert am._connection is None
        assert am._task is None

    test_constructor()

# Generated at 2022-06-11 13:05:55.034490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test config
    test_hostname = 'localhost'
    test_username = 'user1'
    test_password = 'secret'
    test_module_path = '/path/to/modules'
    test_module_name = 'test_module'
    test_module_path_yum = '/path/to/yum'
    test_module_name_yum = 'yum'
    test_module_path_dnf = '/path/to/dnf'
    test_module_name_dnf = 'dnf'
    test_module_args_yum = {
        'name': 'tux',
        'state': 'present',
    }

# Generated at 2022-06-11 13:05:58.342605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiation
    my_plugin = ActionModule()
    # Test run method
    my_plugin.run(tmp = None, task_vars = None)
    # Test is an instance of the class
    assert isinstance(my_plugin, ActionModule)

# Generated at 2022-06-11 13:06:15.760702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.context_objects import AnsibleContext

    # mostly taken from test_action_plugin.py and test_backend_plugin.py
    mytask = {
        'args': {
            'name': 'example',
            'state': 'present'
        },
        'action': {
            '__ansible_module__': 'yum'
        }
    }
    mytask_vars = {
        'ansible_facts': {
            'pkg_mgr': 'auto'
        }
    }

# Generated at 2022-06-11 13:06:25.391019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up class instance for test
    action_module = ActionModule()

    # set up class variables for run
    action_module._supports_check_mode = True
    action_module._supports_async = True

    # set up variables for run test
    tmp = None
    task_vars = {"ansible_facts": {"pkg_mgr": "yum"}}

    # run test: should pass
    result = action_module.run(tmp, task_vars)
    assert result["skipped"] == True
    assert result["msg"] == "By default the yum action will delegate to the yum module or the dnf module."

    # test use_backend argument
    action_module._task.args = {"use_backend": "yum"}

# Generated at 2022-06-11 13:06:37.004222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(
        name='tree',
        state='present',
        use='auto_detect'
    )
    task_vars = dict(ansible_facts=dict(pkg_mgr='yum'), hostvars=dict())

    # EXECUTED: self._execute_module(
    #             module_name=module, module_args=new_module_args, task_vars=task_vars, wrap_async=self._task.async_val)
    # module = yum
    # module_args=args
    # task_vars=task_vars
    # wrap_async=False
    # ActionBase.__init__(
    #   self=ActionBase,
    #   connection=self._connection,
    #   play_context=self._play_context,
    #

# Generated at 2022-06-11 13:06:47.182279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test the Ansible Action Module class
    '''
    from ansible.module_utils._text import to_bytes

    task_vars = dict()
    module_name = 'yum'
    module_args = dict()

    action = ActionModule(None, task_vars=task_vars, task_uuid=None)

    try:
        module = action._resolve_action_module(module_name, module_args)
    except SystemExit:
        pass
    else:
        raise 'SystemExit should have been raised'

    module_args = dict(
        use_backend='yum4',
        name='gcc',
    )

    module = action._resolve_action_module(module_name, module_args)

    assert module == 'ansible.legacy.dnf'



# Generated at 2022-06-11 13:06:53.621601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    playbook_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../test/lib/ansible_test/_data/playbooks/contact-us/')
    os.chdir(playbook_path)

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['../../../test/lib/ansible_test/_data/inventory/hosts'])

# Generated at 2022-06-11 13:06:57.195887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()


if __name__ == '__main__':
    # import time
    # time.sleep(1)  # delay running the unit test to allow log file to be created.
    test_ActionModule()

# Generated at 2022-06-11 13:07:07.201094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    actmod = ActionModule()

    # Unit test should use same tasks, ds, connection_loader and templar
    # as the object itself
    actmod._shared_loader_obj = actmod.loader

    # Create a mock templar to return a known string
    actmod._templar = MockTemplar('test_in_templar')

    # Create a mock task
    actmod._task = MockTask()

    # Create a Mock connection
    actmod._connection = MockConnection()

    # Run the run() method of ActionModule
    result = actmod.run()
    assert result == {u'failed': False, u'changed': True}


# Generated at 2022-06-11 13:07:08.753669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('test', {}, {}, [], {})
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-11 13:07:11.626896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize action plugin object ActionModule for testing
    obj = ActionModule(0, None, None)
    val = obj.VALID_BACKENDS
    assert (val == ('yum', 'yum4', 'dnf'))

# Generated at 2022-06-11 13:07:13.782842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''
    action_module = ActionModule()
    # TODO: need to add more tests
    assert action_module

# Generated at 2022-06-11 13:07:32.406002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of the class with all valid arguments
    action_module = ActionModule(
        task=dict(action=dict(module_name="yum", module_args=dict(command="list")), async_val=0, async_jid="",
                  delegate_to="somehost", delegate_facts=False),
        connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # validate
    assert action_module

# Generated at 2022-06-11 13:07:39.872045
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 13:07:51.019096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {'_ansible_parsed': True, 'action': 'yum', 'delegate_facts': True, 'delegate_to': 'localhost', 'async': 86400, 'async_status_dir': '/tmp/async_status/939', 'async_wait': 10, 'use': 'yum4', '_ansible_check_mode': True, '_ansible_debug': True}
    results = {'failed': True, 'msg': 'Could not detect which major revision of yum is in use, which is required to determine module backend.\nYou should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})'}
    ansible = ActionModule(data)

# Generated at 2022-06-11 13:07:53.941229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert action_module.TRANSFERS_FILES == False, "The default value of TRANSFERS_FILES should be False"

# Generated at 2022-06-11 13:08:00.873507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(
        task=dict(action=dict(module_name='yum'), args=dict(name=['vim', 'cowsay'], state='installed')))
    assert actionmodule is not None
    assert actionmodule._task is not None
    assert actionmodule._task.action is not None
    assert actionmodule._task.action.module_name == 'yum'
    assert actionmodule._task.args['name'] == ['vim', 'cowsay']
    assert actionmodule._task.args['state'] == 'installed'

# Generated at 2022-06-11 13:08:09.764222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.yum as a_p_a_yum
    import ansible.plugins.action.dnf as a_p_a_dnf
    import ansible.plugins.action.yum as a_p_a_yum

    module = a_p_a_yum.ActionModule()
    module.VALID_BACKENDS = VALID_BACKENDS
    module.run()

    module = a_p_a_dnf.ActionModule()
    module.VALID_BACKENDS = VALID_BACKENDS
    module.run()

    module = a_p_a_yum.ActionModule()
    module.VALID_BACKENDS = VALID_BACKENDS
    module.run()

# Generated at 2022-06-11 13:08:21.094370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.strategy import StrategyBase

# Generated at 2022-06-11 13:08:29.386657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = {'ansible_facts': {'pkg_mgr': 'yum'}}
    task_vars = {'ansible_pkg_mgr': 'dnf'}

# Generated at 2022-06-11 13:08:31.775882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    trans_files = am.TRANSFERS_FILES
    assert trans_files == False

# Generated at 2022-06-11 13:08:32.753597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert True

# Generated at 2022-06-11 13:09:00.946045
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module = ActionModule({'ansible_facts': {'pkg_mgr': 'auto'}}, {'delegate_to': 'ansible2_delegated', 'delegate_facts': False}, True)
  assert action_module.VALID_BACKENDS == ('yum', 'yum4', 'dnf')

# Generated at 2022-06-11 13:09:01.891360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-11 13:09:07.585550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                use=None,
                use_backend=None
            )
        ),
        connection=dict(
            _shell=dict(
                tmpdir=''
            )
        ),
        templar=None,
        task_vars=dict(),
        loader=None,
        shared_loader_obj=None,
        path_lookup=False
    )

    assert action_module is not None

# Generated at 2022-06-11 13:09:08.354955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    return 1

# Generated at 2022-06-11 13:09:17.614544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(mock_loader, sources=['localhost'])
    mock_variable_manager = VariableManager(mock_loader, mock_inventory)

# Generated at 2022-06-11 13:09:25.854270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange and act
    am = ActionModule()
    am._task = object() 
    am._task.async_val = False

    try:
        am.run(task_vars={'ansible_facts': {'pkg_mgr': "yum4"}})
    except AnsibleActionFail as aaf:
        # Assert
        assert 'use' not in am._task.args
        assert 'use_backend' in am._task.args
        assert 'auto' not in am._task.args
        assert am._task.delegate_to is None


test_ActionModule_run()

# Generated at 2022-06-11 13:09:30.093225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None,
                                 templar=None, shared_loader_obj=None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True


# Generated at 2022-06-11 13:09:34.210126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Defined variables
    tmp = None
    task_vars = None
    module = None
    # Delete any existing instance of ActionModule
    ActionModule.__bases__ = tuple()
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Test method run of class ActionModule
    action_module.run(tmp, task_vars)

# Generated at 2022-06-11 13:09:34.675502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 13:09:44.579814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock as mock
    from ansible.plugins.action.yum import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    import copy

    # Mock class for connection
    class MockConnection():
        'Ansible Connection Mock class'

        def __init__(self):
            'constructor'
            self._shell = MockShell()

        def _remove_tmp_path(self):
            'remove a temporary path we created'
            pass

    # Mock class for AnsibleModule
    class MockAnsibleModule():
        'Ansible Module Mock class'

        def __init__(self):
            'constructor'
            self.params = {'use_backend': 'auto'}
            self.delegate_to = ''
            self.delegate_facts = True
            self

# Generated at 2022-06-11 13:10:42.212112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule.
    """
    import ansible.plugins.action
    from ansible.plugins.action.yum import ActionModule

    action_module_object = ActionModule(
        task={"args": {"use_backend": "yum"}},
        connection={"_shell": "some_value"},
        play_context={"become": True},
        loader=None,
    )

    # return value of method run is used to set result attribute of action_module_object
    # setting result attribute of action_module_object is necessary for assertEqual
    action_module_object.run()

    assert action_module_object.result["failed"] == True
    assert action_module_object.result["msg"] == "Could not find a yum module backend for legacy_yum."

    action

# Generated at 2022-06-11 13:10:50.780055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_self = Mock()

    # The first element of each tuple is a dict of the args that will be passed
    # to the run method. The second element is a Mock action plugin that will
    # be returned by the _execute_module method. The third element is an
    # expected dict that will be returned by the run method.

    # test with use = auto, ansible_pkg_mgr = yum, and delegate_to = localhost
    run_args = dict(
        use = 'auto',
        name = 'ansible-doc'
    )

    async_value = False

    task_vars = dict(
        ansible_pkg_mgr = 'yum',
        ansible_facts = dict(
            pkg_mgr = None
        )
    )

    mock_action = Mock()


# Generated at 2022-06-11 13:10:51.517285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 13:10:52.770567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test executed very fast, so it should be considered for future unit tests.
    pass

# Generated at 2022-06-11 13:11:02.142382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Test that the module runs successfully when using a valid YUM backend
  task = {
    'name': 'test',
    'action': {
      'module': 'yum',
      'args': {
        'name': 'httpd',
        'state': 'present',
        'use_backend': 'yum'
      }
    }
  }

  class Connection:
    def _shell_wrap(self, cmd, tmp=None):
      return {}


# Generated at 2022-06-11 13:11:11.066710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = "local"
    module_name = "ansible.builtin.yum"
    module_args = {
        "use_backend":"yum"
    }
    tmp = None
    inject = {}
    wrap_async = False
    task_uuid = None
    task_vars = {}
    loader = None
    variable_manager = None
    loader_cache = {}

    action_module = ActionModule()
    action_module.setup(connection, module_name, module_args, inject, task_uuid, tmp, task_vars, loader, variable_manager, loader_cache, wrap_async)
    action_module.run(tmp, task_vars)
    action_module.teardown()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 13:11:19.968626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define variables used for initializing ActionModule class
    module_name = "ansible.builtin.yum"
    module_args = dict()
    task = dict()
    inject = dict()
    connection = dict()
    play_context = dict()
    loader = dict()
    templar = dict()
    shared_loader_obj = dict()

    # Define empty object of class ActionModule
    obj = ActionModule(module_name, module_args, task, inject, connection, play_context, loader, templar, shared_loader_obj)

    # Test getters
    assert not isinstance(obj.task, dict)
    assert not isinstance(obj.connection, dict)

    assert isinstance(obj.task, dict)
    assert isinstance(obj.connection, dict)


# Generated at 2022-06-11 13:11:22.717385
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    val = yum.ActionModule.run(self, tmp, task_vars)

    # Check if val is a instance of dict
    assert isinstance(val, dict)
    print("Test Case test_ActionModule_run completed")


# Generated at 2022-06-11 13:11:25.309233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 13:11:34.206857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Import module locally to avoid affecting other tests
    from ansible_collections.ansible.community.plugins.action.yum import ActionModule
    module = ActionModule(dict(
        delegate_to="127.0.0.1",
        use="yum4",
    ), load_from_file=False, task_uuid='test_uuid')
    module._shared_loader_obj.module_loader.has_plugin = Mock(return_value=True)
    module._execute_module = Mock(return_value=dict(failed=False, ansible_facts=dict(pkg_mgr="yum4")))
    result = module.run(task_vars=dict(ansible_facts=dict(pkg_mgr="yum3")))

# Generated at 2022-06-11 13:13:23.160588
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # pylint: disable=missing-docstring, unsubscriptable-object, no-member
    from ansible.compat.tests.mock import patch, Mock
    from ansible.plugins.action.yum import ActionModule
    from ansible.plugins.action.yum import VALID_BACKENDS as vb
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    am = ActionModule({"ANSIBLE_MODULE_ARGS": {"name": ["foo", "bar"], "state": "present"}}, display=display)

    # test run with use_backend present
    with patch.object(ActionModule, 'run', return_value={}) as mock_run:
        am.run(task_vars={})
        assert mock_run.called

# Generated at 2022-06-11 13:13:33.626677
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case 1: run without delegate_to and delegate_facts
    # Test case 1.1: run with auto and yum using facts: {'ansible_pkg_mgr': 'auto'}
    # Expected result: run dnf module
    # get facts by executing the ansible.legacy.setup module
    facts = {
        'ansible_facts': {
            'pkg_mgr': 'auto'
        },
        'changed': False,
        'invocation': {
            'module_args': {
                'filter': 'ansible_pkg_mgr',
                'gather_subset': '!all'
            }
        }
    }

    task_vars = {}

# Generated at 2022-06-11 13:13:34.955495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Testcase function for ActionModule.run
    """
    pass

# Generated at 2022-06-11 13:13:40.898610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    m = ActionModule()
    m.runner = RunnerMock(execution_result={"cmd": "ansible-yum -m dnf -a 'use_backend=yum' 127.0.0.1"})
    m._task = TaskMock()
    m._templar = TemplarMock()
    m._shared_loader_obj = SharedLoaderMock()
    m._connection = ConnectionMock()

    # Test
    result = m.run()

    # Assert

# Generated at 2022-06-11 13:13:42.376846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert type(am) == ActionModule

# Generated at 2022-06-11 13:13:42.915750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 13:13:53.381910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()

    # We don't have the final class here. Instead of mocking, we just
    # generate some fake data.
    am._connection = {'_shell': {'tmpdir': '/tmp'}}
    am._task = {'args': {'use': 'yum4'}, 'delegate_to': False, 'async_val': True}

    result = am.run(tmp=None, task_vars=None)

    assert result == {'failed': True, 'msg': ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                                              "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")}

# Generated at 2022-06-11 13:14:02.701226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of ActionModule class
    module = ActionModule()

    # create mock of the class
    mock_task = Mock()

    # mock the params sent by the user
    mock_task.args = {'name': 'ansible',
                      'use_backend': 'yum'}

    # mock the return value of method run of class ActionBase
    mock_task.async_val = False

    # mock the return value of method execute_module of class ActionBase
    mock_task.execute_module.return_value = {'rc': 0,
                                             'stdout': '',
                                             'stderr': '',
                                             'stdout_lines': [],
                                             'stderr_lines': []
                                             }

    # mock the return value of method set_runner_params of class Play

# Generated at 2022-06-11 13:14:05.304123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    unit test for constructor of class ActionModule
    :return:
    '''
    module = ActionModule()
    assert isinstance(module._task, dict)


# Generated at 2022-06-11 13:14:05.823354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()