

# Generated at 2022-06-11 13:04:58.872861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.play
    from ansible.utils.context_objects import AnsibleContext
    from ansible.utils.display import Display
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-11 13:05:08.259562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock up objects for the module to act on
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}
    task = {'args': {'use': 'yum4'}}
    connection = {'_shell': {'tmpdir': '/tmp/tmp.gwSJb0hmhJ'}}

    # Create an instance of the class, run the method, and check the output
    am = ActionModule(task, connection)
    result = am.run(task_vars)

# Generated at 2022-06-11 13:05:11.041595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    mod = ansible.plugins.action.yum.ActionModule()
    mod.run()

# Generated at 2022-06-11 13:05:13.405355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 13:05:24.359448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Build the arguments for the run method
    action_module = ActionModule()
    args = []
    args.append({'use_backend': 'yum'})
    args.append({'use_backend': 'auto'})
    args.append({'use_backend': 'yum4'})
    args.append({'use_backend': 'ansible.legacy.yum'})
    args.append({'use': 'dnf'})
    args.append({'use': 'auto'})
    args.append({'use': 'ansible.legacy.dnf'})
    args.append({'use': 'ansible.legacy.yum'})
    args.append({})
    m_dict = {'ansible_facts': {'pkg_mgr': 'yum'}}
    args

# Generated at 2022-06-11 13:05:33.760735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'name': 'httpd'}
    host_vars = {}
    action_module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run(tmp=None, task_vars=host_vars) == {'failed': True,
                                                                'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend.",
                                                                'msg': "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend)}"
                                                               }

# Generated at 2022-06-11 13:05:38.654517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(
        task=dict(name="yum", action="yum3"),
        connection=dict(user="root", host="localhost", port=22, password="redhat"),
        play_context=dict(become=True, become_method="sudo", become_user="root"),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert isinstance(test_module, ActionModule)

# Generated at 2022-06-11 13:05:39.242694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:05:41.780361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
     Unit test method that tests the functionality of method run of class ActionModule.
    """
    pass


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 13:05:52.563800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    expected_results = {
        "module": "ansible.legacy.yum",
        "status": True,
        "invocation": {
            "module_args": {
                "enablerepo": "debug",
                "use": "yum",
                "name": "vim-enhanced"
            },
            "module_name": "yum"
        },
        "result": {
            "results": [
                {
                    "repo": "fedora",
                    "status": "False"
                },
                {
                    "repo": "fedora-debuginfo",
                    "status": "True"
                }
            ]
        }
    }
    test_module = ActionModule()

# Generated at 2022-06-11 13:06:02.045501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = "action_test"
    shared_loader_obj = None
    templar = None
    connection = None
    play_context = None
    loader = None
    am = ActionModule(task, connection, play_context, shared_loader_obj, templar, loader)
    assert am is not None

# Generated at 2022-06-11 13:06:12.070383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display


# Generated at 2022-06-11 13:06:20.580318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate class
    i = ActionModule()
    i.transfers_files = False
    i.supports_async = True
    i.supports_check_mode = True

    # declare variables
    tmp = None
    task_vars = dict()

    # run method
    result = i.run(tmp, task_vars)
    assert result.get('failed') == True
    assert result.get('msg') == "parameters are mutually exclusive: ('use', 'use_backend')"

# Generated at 2022-06-11 13:06:27.609678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.plugins.action import ActionModule

    class Connection:
        class _shell:
            tmpdir = 'path_tmp_shell'

        def _remove_tmp_path(self, path):
            pass

        def _execute_module(self, module_name=None, module_args=None, task_vars=None):
            return dict(
                ansible_facts=dict(
                    pkg_mgr='yum3'
                )
            )

    class Task:
        name = 'dummy'
        async_val = False
        delegate_to = None


# Generated at 2022-06-11 13:06:39.287021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import filter_loader

    display = Display()
    module_loader = filter_loader(UnsafeProxy, 'ansible.legacy')
    host = Host('testhost')
    variables = VariableManager()
    variables.set_host_variable(host, 'ansible_facts', {'ansible_pkg_mgr': 'dnf'})
    task = type('task', (), {'args': {'use_backend': 'yum'}, 'async_val': 330})()

# Generated at 2022-06-11 13:06:40.936983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict())
    assert module is not None

# Generated at 2022-06-11 13:06:42.686052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(action=dict(yum=None)))
    assert action_module is not None

# Generated at 2022-06-11 13:06:50.770257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_mod = ActionModule()

    task = dict(
        args=dict(
            use_backend='auto',
        ),
    )
    action_mod._task = task
    task_vars=dict(
        ansible_pkg_mgr='dnf',
    )

    result = action_mod.run(task_vars=task_vars)
    assert result['module_name'] == 'ansible.legacy.dnf'
    assert 'ansible_facts' not in result

    result = action_mod.run(task_vars=task_vars)
    assert result['module_name'] == 'ansible.legacy.dnf'
    assert result['ansible_facts']['pkg_mgr'] == 'dnf'

# Generated at 2022-06-11 13:06:56.307488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule(
        task=dict(args=dict(name=['nginx'], state='present')),
        connection=dict(module_name='yum'),
        play_context=dict(check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert test_object is not None

# Generated at 2022-06-11 13:07:07.494117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Case 1: With all values
    task = {'args': {'a': 1, 'b': 2}, 'async_val': 5, 'delegate_facts': True, 'delegate_to': 'xyz', 'action': 'meta'}
    task_vars = {'ansible_pkg_mgr': 'yum'}
    tmp = '/tmp'
    result = action_plugin.run(tmp, task_vars)
    # Case 2: With default values

# Generated at 2022-06-11 13:07:31.959217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import inspect
    import mock
    import json
    # Getting the path of python file for adding it to sys.path
    filename = inspect.getframeinfo(inspect.currentframe()).filename
    path = os.path.dirname(os.path.abspath(filename))
    sys.path.append(path)
    from ansib_unit_test_case import AnsibleUnitTestCase, setup_mocks, tear_down_mocks

    class TestActionModule(AnsibleUnitTestCase):
        def setUp(self):
            self.set_default_args()
            self.module = ActionModule()
            self.set_default_args()
            setup_mocks(self)

        def tearDown(self):
            tear_down_mocks(self)


# Generated at 2022-06-11 13:07:37.392902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult

    result = TaskResult(host=dict(name='localhost'), task=dict(args=dict(use='yum')))
    action = ActionModule(task=dict(args=dict(use='yum')), connection=None, play_context=None, loader=None,
                          templar=None, shared_loader_obj=None)
    action.run(task_vars=dict(), tmp=None) == result

# Generated at 2022-06-11 13:07:41.656456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=dict(check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module._supports_check_mode is True

# Generated at 2022-06-11 13:07:52.691735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import makedirs_safe
    from ansible.plugins import module_loader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.display import Display
    from ansible.plugins.loader import filter_loader
    import tempfile
    import os
    import shutil
    import sys

    # Set the Ansible plugin directory
    plugin_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'plugins')

    # Set some variables
    sys.modules['ansible.module_utils.facts.system.distribution'] = __import__('ansible.module_utils.facts.system.distribution')
    tmpdir = tempfile.mkdtemp()
    makedirs_safe(tmpdir)


# Generated at 2022-06-11 13:07:56.100033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #constructor for class ActionModule
    action_module = ActionModule('task', 'connection', 'play_context', 'loader', 'templar', 'shared_loader_obj')
    assert action_module is not None

# Generated at 2022-06-11 13:07:57.042279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:07:58.818404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # filename = 'test_action_plugin_yum_constructor.yml'
    pass


# Generated at 2022-06-11 13:08:05.210526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    # setup plugin loader
    action_loader.add_directory('./lib/ansible/plugins/action')

    # setup default display
    display = Display()
    display.verbosity = 1

    # setup plugin
    action = action_loader.get('yum', task=None, connection='local', play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # tests

    # test1: test mutual exclusion of 'use' and 'use_backend' parameters
    method = action.run

# Generated at 2022-06-11 13:08:13.741402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test of the constructor of the ActionModule class.
    '''
    import ansible.plugins.action
    a = ansible.plugins.action.ActionModule(None, None, None, None, None)
    assert a._supports_check_mode is True
    assert a._supports_async is True
    assert a.TRANSFERS_FILES is False
    assert a._connection is None
    assert a._task is None
    assert a._templar is None
    assert a._loader is None
    assert a._shared_loader_obj is None

# Generated at 2022-06-11 13:08:15.564607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(load_fixture("yum_actions_yum_base.json"), dict())


# Generated at 2022-06-11 13:08:49.888764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    setattr(module, '_task', {'args': {'use_backend': 'yum'}, 'async_val': None})
    setattr(module, '_shared_loader_obj', {'module_loader': {'has_plugin': True}})
    setattr(module, '_execute_module', {'module_name': 'ansible.legacy.yum', 'module_args': {'use_backend': 'yum', 'pkg': 'git'}, 'task_vars': '', 'wrap_async': None})
    setattr(module, 'TRANSFERS_FILES', False)
    result = module.run()
    assert result == {'failed': True, 'msg': "Could not find a yum module backend for ansible.legacy.yum."}

# Generated at 2022-06-11 13:08:54.466152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('test', {}, {}, {})
    assert action._shared_loader_obj.module_loader.has_plugin('dnf') is True
    action = ActionModule('test', {}, {'use_backend': 'yum'}, {})
    assert action._shared_loader_obj.module_loader.has_plugin('yum') is True

# Generated at 2022-06-11 13:08:57.265370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x.VALID_BACKENDS == frozenset(['yum', 'yum4', 'dnf'])

# Generated at 2022-06-11 13:09:06.835174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that ActionModule works as expected with a pre-defined or
    # dynamically generated _task.args
    from ansible.playbook.task import Task

    from ansible.plugins.loader import become_loader, action_loader

    def _task_args(args):
        # Update _task.args for the ActionModule object
        task = Task()
        task.args = args
        return task

    # Test no 'use' or 'use_backend' is given
    assert 'yum3' == _ActionModule(action_loader,
                                   become_loader,
                                   _task_args(dict())
                                   )._module()
    # Test 'use' is given with 'yum3'

# Generated at 2022-06-11 13:09:09.817759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Constructor of ActionModule class should return instance of itself"""
    action_module = ActionModule(None, None, None, None)
    assert isinstance(action_module, ActionModule)


# Unit tests for run method of class ActionModule

# Generated at 2022-06-11 13:09:19.490896
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test for method run of class ActionModule
    module = ActionModule (
        task = dict(
            async_val = None,
            delegate_to = None,
            delegate_facts = None,
            noop_val = False,
            register = 'yum',
            run_once = False
        ),
        connection = dict(
            _shell = dict(
                tmpdir = None
            )
        ),
        loader = dict(
            _shared_loader_obj = None
        ),
        templar = None,
        shared_loader_obj = None,
        _ansible_version = "2.9.9",
        _supports_async = True,
        _supports_check_mode = True,
        _syntax_check_skip = None
    )


# Generated at 2022-06-11 13:09:21.508538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule(None, None, None, None)


# Generated at 2022-06-11 13:09:28.558091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    facts = dict()
    facts.update({'pkg_mgr': "yum"})
    generic_action_module = ActionModule(
        {"use_backend": "yum4"},
        "yum",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        ""
    )
    generic_action_module.run(facts)

# Generated at 2022-06-11 13:09:35.242500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='yum', module_args=dict(name='zsh'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action._templar
    assert action._supports_check_mode
    assert action._supports_async
    assert action._task.action['module_name'] == 'yum'
    assert action._task.action['module_args']['name'] == 'zsh'
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-11 13:09:37.237825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None)
    assert action._task.args is None


# Generated at 2022-06-11 13:10:32.910338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionbase_mock = Mock()
    actionbase_mock.run.return_value = {'ansible_facts': {'pkg_mgr': 'yum'}}
    actionmodule_mock = ActionModule(actionbase_mock, task_vars={'pkg_mgr': 'yum'}, task=_task_mock)
    assert actionmodule_mock.run() == {'ansible_facts': {'pkg_mgr': 'yum'}}


# Generated at 2022-06-11 13:10:35.579396
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    assert module

# Generated at 2022-06-11 13:10:36.256830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 13:10:42.172538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.VALID_BACKENDS = frozenset(('yum', 'yum4', 'dnf'))
    action_instance = ActionModule()
    result = action_instance.run(task_vars={'ansible_facts': {'pkg_mgr': 'yum4'}})
    print(result)


# call the unit test for method run of class ActionModule
test_ActionModule_run()

# Generated at 2022-06-11 13:10:50.751525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action as action
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from collections import namedtuple
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible import context

# Generated at 2022-06-11 13:10:59.569518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test run method
    # 1. case: use yum command
    # 2. case: use dnf command
    # 3. case: auto detect yum or dnf
    def _get_data(case):
        if case == "use_yum":
            task_args = {'use': 'yum', 'name': 'kernel'}
            module_args = {'name': 'kernel'}
            expected_module_name = 'ansible.legacy.yum'
        elif case == "use_dnf":
            task_args = {'use': 'dnf', 'name': 'kernel'}
            module_args = {'name': 'kernel'}
            expected_module_name = 'ansible.legacy.dnf'
        elif case == "auto_detect":
            task_args

# Generated at 2022-06-11 13:11:00.639793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Add test here
    return None

# Generated at 2022-06-11 13:11:04.912592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule().run(task_vars=dict(ansible_pkg_mgr="dnf", ansible_facts=dict(pkg_mgr="yum3")))
    display.debug("result: %s" % result)
    assert result.get('ansible_facts') == {'pkg_mgr': 'dnf'}

# Generated at 2022-06-11 13:11:13.885918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock facts: {'ansible_pkg_mgr': "yum4"}
    # Mock task: {'use':"auto"}
    # Mock task_vars: {'hostvars': {'test_delegate_to': {'ansible_facts': {'pkg_mgr': "yum"}}}}
    import io
    import json
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    import ansible.constants as C
    C.HOST_KEY_CHECKING = False

    display = Display()


# Generated at 2022-06-11 13:11:16.099170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert action.run(None, None) == {"failed": True, "msg": "Action plugin for ActionModule plugin not implemented."}, 'Unexpected output'

# Generated at 2022-06-11 13:13:03.372841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # If the method called runs without an error
    assert(ActionModule.run is not None)

# Generated at 2022-06-11 13:13:05.442796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Tests for plugin ActionModule.run"""

    # Setup
    m = ActionModule(None, None)

    # Execute

    # Verify

    # Cleanup

# Generated at 2022-06-11 13:13:11.400223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This function creates a mock task and action plugin object, and then calls the run method of the action plugin
    object.

    The plugin object would be as follows.
    ActionModule Object:
        _task = Mock Task Object
        _shared_loader_obj = Mock SharedLoaderObject Object
        _templar = Mock Templar Object
        _connection = Mock Connection Object

    The mock task object would be as follows.
    Task Object:
        args = {}
        async_val = None
        delegate_to = None
        delegate_facts = None
        delegate_options = None
        name = "yum"

    Returns:
        Returns a dictionary of result.
    """
    import sys
    import unittest.mock as mock

    mock_task_obj = mock.Mock()
    mock_task_obj.args = dict()
   

# Generated at 2022-06-11 13:13:21.410158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = "tests/fixtures/test_yum_action_module.py"
    task_vars = {'ansible_facts': {'pkg_mgr': 'dnf'}}
    acm = ActionModule(tmp, tmp, task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)
    res = acm.run(task_vars=task_vars)
    assert 'ansible_facts' in res

    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}
    acm = ActionModule(tmp, tmp, task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 13:13:25.741324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, path=None,
                                 connection_info=None,
                                 words=['yum', 'foo', 'bar', '=', 'foobar'],
                                 data=None,
                                 task_uuid=None)
    assert action_module

# Generated at 2022-06-11 13:13:27.741903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.run('tmp', 'task_vars')['failed', False]

# Generated at 2022-06-11 13:13:31.091599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of ActionModule class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 13:13:33.900557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use="yum4")))
    assert action_module._task.args.get('use', "yum3") == "yum4"

# Generated at 2022-06-11 13:13:42.300732
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    task = Task()
    block = Block(play=Play().load({'name': 'test_play', 'hosts': 'localhost', 'gather_facts': 'no'}))
    task._parent = block
    task._role = None

    # yum action plugin with no module arguments
    task.args = {}
    tqm = None
    result = action_loader.get('yum', task, tqm).action._execute_module(module_name='test.test', module_args={}, task_vars={})

# Generated at 2022-06-11 13:13:43.483160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(), dict())
    assert am is not None
