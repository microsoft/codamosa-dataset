

# Generated at 2022-06-11 13:04:54.716044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    try:
        action_module = ActionModule()
    except Exception:
        assert False

    # Test with required arguments
    try:
        action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    except Exception:
        assert False


# Generated at 2022-06-11 13:05:01.213130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {'a': {'ansible_facts':{'pkg_mgr':'yum4'}}}
    module_args = {'use':'auto', 'delegate_to':'a'}
    task_vars = {'hostvars':hostvars}
    am = ActionModule()
    result = am.run(tmp=None, task_vars=task_vars)
    assert result['module'] == 'ansible.legacy.dnf'

# Generated at 2022-06-11 13:05:02.663189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}, None, None, None, None)

# Generated at 2022-06-11 13:05:03.672734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod

# Generated at 2022-06-11 13:05:07.687638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}
    result['ansible_facts'] = {'pkg_mgr': 'yum4'}
    result['msg'] = "Could not detect which major revision of yum is in use, which is required to determine module backend."
    assert (ActionModule.run(ActionModule(),tmp=None,task_vars=None) == result)

# Generated at 2022-06-11 13:05:18.617663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # this is the default value which is set in the main run method
    assert VALID_BACKENDS == ('yum', 'yum4', 'dnf')

    assert ActionModule.TRANSFERS_FILES is False

    # TODO: Mock the ActionBase run method and see if ActionModule.run() returns the expected result
    # TODO: Mock self._task.args.get('use') to check how it is handled by ActionModule.run()
    # TODO: Mock self._task.args.get('use_backend') to check how it is handled by ActionModule.run()
    # TODO: Mock self._templar.template() to check how it is handled by ActionModule.run()
    # TODO: Mock self._execute_module() to check how it is handled by ActionModule.run()

# Generated at 2022-06-11 13:05:25.332082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic

    args = {'use': 'yum4'}
    ActionModule._shared_loader_obj = basic.AnsibleModuleLoader()
    test_action = ActionModule(task={"args": args}, connection='connection', play_context='play_context',
                               loader='loader', templar='templar', shared_loader_obj=ActionModule._shared_loader_obj,
                               final_loader=False)
    assert test_action.run()

# Generated at 2022-06-11 13:05:35.358482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import Include
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI
    from ansible.plugins.loader import find_plugin

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, [], variable_manager)

# Generated at 2022-06-11 13:05:38.232657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(connection=None,
                            task_vars={},
                            loader=None,
                            templar=None,
                            shared_loader_obj=None,
                            cache=None)

# Generated at 2022-06-11 13:05:39.537474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj.TRANSFERS_FILES == False

# Generated at 2022-06-11 13:05:56.545822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = {
        "ansible_facts": {
            "pkg_mgr": "yum",
        },
    }

    task = {
        "async": 0,
        "async_val": 0,
        "args": {},
        "delegate_facts": 1,
        "delegate_to": None,
        "loop": [],
        "no_log": False,
        "poll": 0,
        "register": "",
        "run_once": False,
        "tags": [],
    }

    # Patch the module loader so that it returns an action plugin
    # object in this case.
    class ModuleLoader:
        def has_plugin(self, module):
            return True
    loader = ModuleLoader()
    class _SharedLoaderObj:
        _module_loader = loader

   

# Generated at 2022-06-11 13:06:00.179297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({"name": "yum", "args": {"use_backend": "yum4"}}, {}, {}, {})
    result = module.run(None, None)
    assert result['msg'] == "Could not find a yum module backend for yum4."

# Generated at 2022-06-11 13:06:06.614568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    # invocation with valid parameters

# Generated at 2022-06-11 13:06:19.139724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {
        'testhost.example.com': {'ansible_facts': {'pkg_mgr': 'yum4'}},
    }
    display = Display()
    display.verbosity = 2

    task = {
        'args': {
            'name': 'test-package',
            'use': 'auto',
        },
        'async': 3,
        'delegate_facts': False,
        'delegate_to': 'testhost.example.com',
        'delegate_vars': False,
    }
    tmp = '/tmp/test-ansible-tmp'

    # test when querying host facts
    am = ActionModule(task, display, tmp)
    result = am.run(tmp, hostvars)


# Generated at 2022-06-11 13:06:28.080138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = MockConnection()
    conn._shell.tmpdir = 'tmpdir'

    mod = ActionModule(task=MockTask(), connection=conn, play_context=MockPlayContext())

    delattr(mod, '_display')  # don't want the display to be created
    delattr(mod, '_task')  # don't want display.deprecated to create a warning about missing _task

    display.verbosity = 4

    # yum/dnf module does not have "use_backend" key in args

# Generated at 2022-06-11 13:06:39.993879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.yum as action_yum
    import ansible.module_utils.yum_utils as yum_utils
    import ansible.module_utils.basic as basic
    import sys

    # Setup fake AnsibleModule
    module_name = 'ansible.legacy.yum'
    module_args = dict()
    module_args['name'] = 'dummy_name'
    module_args['use'] = 'yum3'
    module_args['state'] = 'present'
    module_args['disablerepo'] = ['dummy_repo1', 'dummy_repo2']
    module_args['enablerepo'] = ['dummy_repo3']

    yum_utils.HAS_RPM = False
    basic._ANSIBLE_ARGS = None
    sys

# Generated at 2022-06-11 13:06:49.171338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task={'args': {'use_backend': 'auto'}})

    # pylint: disable=W0212
    module._shared_loader_obj = convert_to_class('_shared_loader_obj', {})
    module._shared_loader_obj.module_loader = convert_to_class('module_loader', {})

    # test method has_plugin of class module_loader
    def has_plugin(x):
        return x in VALID_BACKENDS
    module._shared_loader_obj.module_loader.has_plugin = convert_to_class('has_plugin', has_plugin)

    # test method run of class ActionBase
    def run(x, y):
        return {}
    module.run = convert_to_class('run', run)

    module._execute_module = convert

# Generated at 2022-06-11 13:06:59.219508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake ActionPlugin object
    action_plugin = ActionBase()

    # Create a fake task object
    fake_task = {
        'args': {
            'use': 'yum'
        }
    }

    # Create a fake connection_loader object
    class ConnectionLoaderModule(object):
        def __init__(self):
            self.name = 'connection_loader'

    connection_loader = ConnectionLoaderModule()

    # Create a fake shared_loader_module object
    class SharedLoaderModule(object):
        def __init__(self):
            self.name = 'shared_loader_module'

    shared_loader_module = SharedLoaderModule()

    # Create a fake task_loader object
    class TaskLoaderModule(object):
        def __init__(self):
            self.name = 'task_loader'

    task

# Generated at 2022-06-11 13:07:07.284818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = type('test_dict', (object,), {})
    try:
        a = ActionModule(t, 'test_task')
    except TypeError as e:
        assert str(e) == "ActionBase() takes exactly 3 arguments (2 given)"
    t.args = {}
    a = ActionModule(t, 'test_task')
    assert a.run()
    t.args = {'use': 'yum'}
    assert a.run()
    t.args = {'use_backend': 'yum'}
    assert a.run()

# Generated at 2022-06-11 13:07:07.825744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:07:28.319458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize new instance of ActionModule
    mod = ActionModule()
    print(mod)
    # Display the module
    print(mod.__repr__())
    # Print the valid_backends
    print(mod.VALID_BACKENDS)
    # Print the transfer_files
    print(mod.TRANSFERS_FILES)
    # Print the supports_check_mode
    print(mod._supports_check_mode)
    # Print the supports_async
    print(mod._supports_async)


# Generated at 2022-06-11 13:07:37.798535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.action.yum import ActionModule

    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test with no backend specified, should default to using "auto"
    actionModule._task = Mock(args=dict())
    result = actionModule.run(tmp=None, task_vars=None)

    # Assert there is no module_name
    assert 'module_name' not in result

    # Assert module_args is a dict with 2 keys ('use', 'use_backend')
    assert isinstance(result['module_args'], MutableMapping)

# Generated at 2022-06-11 13:07:48.840567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_connection = Mock()
    mock_connection._shell.tmpdir = "tmp"

    mock_task = Mock()
    mock_loader = Mock()
    mock_variable_manager = Mock()
    mock_play_context = Mock()

    mock_play_context.check_mode = True
    mock_play_context.no_log = False
    mock_play_context.network_os = "network_os"

    mock_variable_manager.extra_vars = dict()

    yum_action_plugin = ActionModule(mock_connection, mock_task, mock_variable_manager, mock_loader, mock_play_context, ['test_task'], False)

    # return value of constructor when async_val is False
    yum_action_plugin._task.async_val = False
    assert yum_action_plugin

# Generated at 2022-06-11 13:07:59.752022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(action=dict(call=dict()), delegate_to='localhost', async_val=5000, register='my_result'),
        connection=dict(host='localhost', port=22, user='default', password='dummy', ssh_args=dict(timeout=5000)),
        loader=dict(), play_context=dict(remote_addr=dict(), password='', port=22, user='default'),
        new_stdin='', remote_user='default', connection_user='default', become=False, become_user='root',
        check_mode=True, diff=False)
    action_module._supports_async = True
    action_module._supports_check_mode = True
    action_module._shared_loader_obj = False

# Generated at 2022-06-11 13:08:05.293968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = {'args': {'x':1}, 'async_val':2, 'delegate_facts':3, 'delegate_to':4,
                 '_connection': {'_shell': {'tmpdir': 5}}}
    am = ActionModule(mock_task, 6)
    assert am._task.async_val == 2
    assert am._task.delegate_facts == 3
    assert am._task.delegate_to == 4
    assert am._connection._shell.tmpdir == 5

# Generated at 2022-06-11 13:08:16.486205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options(object):
        def __init__(self):
            self.connection = 'mock'
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.diff = False
            self.private_key_file = '~/.ssh/id_rsa'

    class Task(object):
        def __init__(self):
            self.action = 'yum'
            self.args = {}
            self.async_val = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.delegate_facts = False
            self.delegate_to = None
            self.deprecations = []

# Generated at 2022-06-11 13:08:20.481876
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 13:08:28.985392
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.yum as yum
    action_plugin = yum.ActionModule(None, '', '', '')

    # Test module auto
    module = 'auto'
    v = action_plugin.run(tmp=None, task_vars=dict(ansible_pkg_mgr=module))
    assert v['msg'] == "Could not detect which major revision of yum is in use, which is required to determine module backend."

    # Test module yum3
    module = 'yum'
    v = action_plugin.run(tmp=None, task_vars=dict(ansible_pkg_mgr=module))
    assert v['_ansible_module_name'] == 'ansible.legacy.yum'

    # Test module dnf
    module = 'dnf'

# Generated at 2022-06-11 13:08:39.611500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Test to make sure 'auto' backend doesn't throw an exception if no
    # facts are available.
    #
    # This is currently tested in the 'yum' integration tests, but was
    # not working there reliably. It's good to have a unit test for
    # this.
    #
    # The code in the yum3ActionModule doesn't currently detect when it's
    # running in unit tests. See the code:
    #   module = self._templar.template("{{ansible_facts.pkg_mgr}}")
    #   if module not in VALID_BACKENDS:
    #
   

# Generated at 2022-06-11 13:08:49.251455
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 13:09:24.332346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase

    sys.modules['ansible'] = type('MockModule', (object,), {})()
    sys.modules['ansible.module_utils.basic'] = type('MockModuleUtils', (object,), {})()
    sys.modules['ansible.module_utils.facts'] = type('MockFacts', (object,), {})()
    sys.modules['ansible.module_utils.facts.system'] = type('MockFactsSystem', (object,), {})()
    sys.modules['ansible.module_utils.parsing.convert_bool'] = type('MockConvertBool', (object,), {})()
    sys.modules

# Generated at 2022-06-11 13:09:34.099250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.pkg_mgr import PKG_MGRS
    from ansible.module_utils.facts.system.platform import PLATFORM_FACTS
    from ansible.module_utils.facts import default_fact_exchange
    from ansible.module_utils.facts import fact_cache
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    

# Generated at 2022-06-11 13:09:37.294491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys

    module = sys.modules[__name__]
    plug = ActionModule()
    assert action == 'yum'  # action name
    assert module.ActionModule == 'yum'  # name of class ActionModule

# Generated at 2022-06-11 13:09:38.599155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {}
    assert ActionModule(None, module_args, None)

# Generated at 2022-06-11 13:09:48.029446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.package_manager import ActionModule
    from ansible.module_utils._text import to_bytes
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    display = Display()
    display.verbosity = 2

    try:
        import ansible.modules.package_manager as yum_module
        ansible_package_manager = yum_module
    except ImportError:
        import ansible.modules.yum as yum_module
        ansible_package_manager = yum_module

    module = "fake_module"

# Generated at 2022-06-11 13:09:49.178249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Can't instantiate the class directly
    pass


# Generated at 2022-06-11 13:09:58.657984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.errors import AnsibleParserError
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group


# Generated at 2022-06-11 13:10:02.085126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {}, {}, None)

    assert action._supports_async
    assert action._supports_check_mode
    assert action.VALID_BACKENDS == VALID_BACKENDS
    assert action.TRANSFERS_FILES is False

# Generated at 2022-06-11 13:10:12.674146
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock task_vars
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['pkg_mgr'] = 'auto'
    task_vars['ansible_sourced_facts_cache'] = dict()
    task_vars['ansible_sourced_facts_cache']['pkg_mgr'] = 'yum4'
    task_vars['ansible_sourced_facts_cache']['ansible_pkg_mgr'] = 'yum4'
    task_vars['ansible_pkg_mgr'] = 'yum4'
    task_vars['ansible_delegate_to'] = None
    task_vars['ansible_delegate_facts'] = True

    # Mock module_loader

# Generated at 2022-06-11 13:10:18.121597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._uses_shell is True  # private member (True)
    assert ActionModule.version_requirement is False  # private member (True)
    assert ActionModule.DEFAULT_TIMEOUT == 10     # private member (10)
    assert ActionModule._template_dir is not None  # private member (None)
    assert ActionModule.BYPASS_HOST_LOOP is True   # private member (False)
    assert ActionModule._transfer_strategy is None  # private member (None)
    assert ActionModule.INTERNAL_PARAMETERS is not None  # private member (None)
    assert type(ActionModule._internal_params) is frozenset  # private member (None)
    assert ActionModule.REQUIRED_API_VERSION == '2.0'  # private member (None)
    assert ActionModule._return_content

# Generated at 2022-06-11 13:11:16.178033
# Unit test for constructor of class ActionModule
def test_ActionModule():

    def t_run(_self=None, tmp=None, task_vars=None):
        _self._supports_check_mode = True
        _self._supports_async = True

        result = run_ActionBase_run(_self, tmp, task_vars)
        del tmp  # tmp no longer has any effect

        # Carry-over concept from the package action plugin
        if 'use' in _self._task.args and 'use_backend' in _self._task.args:
            raise AnsibleActionFail("parameters are mutually exclusive: ('use', 'use_backend')")

        module = _self._task.args.get('use', _self._task.args.get('use_backend', 'auto'))


# Generated at 2022-06-11 13:11:16.841121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 13:11:24.532371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test success
    res = {}
    res['ansible_facts'] = {'pkg_mgr': 'yum'}
    m = ActionModule()
    m._execute_module = lambda mn, ma, t, w: res
    #res = m._execute_module = MagicMock()
    #res.return_value = {'failed': False}
    m._shared_loader_obj = lambda: m
    m.has_plugin = lambda m: True
    assert m.run({}, {}) == {'failed': False, 'ansible_facts': {'pkg_mgr': 'yum'}}

    # test failure
    res = {}
    res['ansible_facts'] = {'pkg_mgr': 'yum'}
    m = ActionModule()

# Generated at 2022-06-11 13:11:26.583975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This method will test the constructor of class ActionModule
    :return:
    """
    action = ActionModule()
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-11 13:11:35.674714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Constructing a mock object for ansible.plugins.action.ActionBase
    mock_ActionBase = MagicMock()
    # Constructing a mock object for ansible.utils.display.Display
    mock_Display = MagicMock()
    # Constructing a mock object for ansible.plugins.action.ActionBase.run
    mock_run = MagicMock()
    # assigning the mock_ActionBase.run as the mock_run
    mock_ActionBase.run = mock_run
    # declaring the return_value of the mock_run as {'ansible_pkg_mgr': 'auto'}
    mock_run.return_value = {'ansible_pkg_mgr': 'auto'}
    # declaring the return_value of the mock_run as {'ansible_pkg_mgr': 'yum4'}
    mock_

# Generated at 2022-06-11 13:11:36.501313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-11 13:11:45.775925
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 13:11:47.049853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-11 13:11:50.467054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule. """

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-11 13:11:59.934997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run of ActionModule() by setting the various yum backend modules
    to available and not available.
    """
    # create a map of various modules to the 3 cases of False, True and Exception
    # the key in each map is the module name and the value is the returned value
    # when that module's has_plugin method gets called.
    # The value will be a tuple with:
    # 0: return value when the module is expected to be available,
    # 1: return value when the module is not expected to be available,
    # 2: exception when the module is not expected to be available.

# Generated at 2022-06-11 13:13:44.678993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'use_backend': 'auto'}
    action_module = ActionModule(None, module_args, True, None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

# Generated at 2022-06-11 13:13:55.517546
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    # Case 1: run() with use='yum4'
    task = dict({"name":"yum", "action":{"module":"yum", "args":{"use":"yum4"}}})
    module._task = task
    tmp = dict()
    task_vars = dict()
    result_1 = module.run(tmp, task_vars)

    # Case 2: run() with use='dnf'
    task = dict({"name":"yum", "action":{"module":"yum", "args":{"use":"dnf"}}})
    module._task = task
    result_2 = module.run(tmp, task_vars)

    # Case 3: run() with use='yum'

# Generated at 2022-06-11 13:13:59.266917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.display import Display
    display = Display()
    module = ActionModule(tmp='/tmp', task_vars={'test_var': 'test_value'})
    assert module is not None, "Unable to instantiate ActionModule object"

# Generated at 2022-06-11 13:14:00.171968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.run({})

# Generated at 2022-06-11 13:14:00.983480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 13:14:10.885517
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 13:14:13.877477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(use='yum4')
    task_vars = dict()
    yum_action = ActionModule(task,  task_vars)
    assert isinstance(yum_action, ActionModule)

# Generated at 2022-06-11 13:14:22.569214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for run method of ActionModule.
    """
    # TODO: implement this unit test for method run of class ActionModule
    # this unit test should, at minimum, cover the following statements:
    # 1. when module is 'auto' and facts is not available, then raise AnsibleActionFail
    # 2. when module is 'auto' and facts is available, then module = facts.get("ansible_facts", {}).get("ansible_pkg_mgr", "auto")
    # 3. when module is invalid, then raise AnsibleActionFail
    # 4. when module is 'auto', then result = self._execute_module
    # 5. when module is dnf, then self._execute_module
    # 6. when module is yum, then self._execute_module
    # 7. when self._task.async_val

# Generated at 2022-06-11 13:14:31.829655
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Construct a mock task which passes in all of the arguments that would be required
    task_args = {'use': 'yum', 'use_backend': 'dnf'}
    task_manager = mock.MagicMock()
    task_manager._task = mock.MagicMock()
    task_manager._task._datacache = mock.MagicMock()
    task_manager._task.args = task_args
    task_manager._task.delegate_to = 'localhost'
    task_manager._task.delegate_facts = 'no'

    # Set up the module action as a mock and mock the return value of the execute module
    module_action = mock.MagicMock()
    module_action._execute_module.return_value = {'failed': False}

    # Construct the ActionModule and assert that the run function returns the correct

# Generated at 2022-06-11 13:14:40.263530
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create a validator to use in the test.
    from ansible.utils.sentinel import Sentinel

    # Test various values for use_backend.

    # Empty string for use_backend is acceptable.
    module = ActionModule(Sentinel(
        module_args={'use_backend': ''}), Sentinel())

    # Non-empty strings are acceptable.
    module = ActionModule(Sentinel(
        module_args={'use_backend': 'yum'}), Sentinel())
    module = ActionModule(Sentinel(
        module_args={'use_backend': 'yum4'}), Sentinel())
    module = ActionModule(Sentinel(
        module_args={'use_backend': 'dnf'}), Sentinel())

    # Non-strings are acceptable.