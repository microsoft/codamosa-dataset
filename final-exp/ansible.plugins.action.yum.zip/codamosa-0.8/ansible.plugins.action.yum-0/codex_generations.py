

# Generated at 2022-06-11 13:04:51.584552
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-11 13:04:55.377139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = {}
    task_vars = {"ansible_pkg_mgr": "yum"}
    am = ActionModule(m, task_vars)
    x = am.run()
    assert x["module_name"] == "yum"

# Generated at 2022-06-11 13:05:05.936848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    # patching machinery for am.run
    am._task = DummyClass()
    am._task.args = {'use': 'auto'}
    am._task.delegate_to = 'test'
    am._templar = DummyClass()
    am._templar.template = lambda x: "auto"
    am._execute_module = lambda x, y, z: {
        'ansible_facts': {'pkg_mgr': 'yum'}
    }
    am._shared_loader_obj = DummyClass()
    am._shared_loader_obj.module_loader = DummyClass2()
    am._shared_loader_obj.module_loader.has_plugin = lambda x: True
    # execute method run of class ActionModule
    res = am.run()
    #

# Generated at 2022-06-11 13:05:06.660320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 13:05:18.224988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from units.compat import unittest

    class TestActionModule(unittest.TestCase):

        def setUp(self):

            self._loader = DictDataLoader({})
            self._shared_loader_obj = None


# Generated at 2022-06-11 13:05:19.236236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t

# Generated at 2022-06-11 13:05:27.374253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test ActionModule constructor"""
    def check_module_deprecation(msg, module_name, module_args, templar):
        return msg

    task_vars = {}
    inject = {}

    playbook_vars = {}
    task_vars['playbook_vars'] = playbook_vars

    task = {'action': {'module_args': ''}, 'async_val': False}

    action_module = ActionModule(task, inject,
                                 check_module_deprecation=check_module_deprecation)

    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-11 13:05:36.657304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test class ActionModule run method'''

    module_path = 'ansible.legacy.yum'

    module_args = '''
name: python-pip
state: latest
'''


# Generated at 2022-06-11 13:05:37.177889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 13:05:47.227968
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def run(module, tmp=None, task_vars=None):
        task_vars = task_vars or dict()
        return module.run(tmp, task_vars)

    from ansible.module_utils.facts.hardware.base import Hardware

    hardware = Hardware()  # Hardware is a mock object
    hardware.pkg_mgr = 'yum'
    facts = dict(pkg_mgr=hardware.pkg_mgr)

    module = ActionModule(dict(
        action=dict(
            args=dict(
                use_backend='yum'
            )
        ),
        async_val=False
    ))  # ActionModule is a mock object

    # Simulate what the yum module would do if the remote system is running yum

# Generated at 2022-06-11 13:06:03.106618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test ActionModule.run method"""
    inp = {"use": "auto"}
    test = {"ansible_facts": {"pkg_mgr": "yum"}}
    result = {"ansible_facts": {"pkg_mgr": "yum"}, 'failed': False, 'changed': False}

    # Create the object
    am = ActionModule(None, inp, None, None, None, None, None, None, None)
    # Modify attributes needed for the test
    am._task.delegate_facts = False
    am._task.delegate_to = None
    am._task.args['use'] = 'auto'
    am._shared_loader_obj.module_loader.has_plugin = lambda module: True

# Generated at 2022-06-11 13:06:07.195111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run = ActionModule(task=dict(args=dict()), connection=MockConnection()).run
    assert run(tmp=None, task_vars=None) == dict(
        changed=False,
        skipped=True,
        msg='Using the \'auto\' backend for the yum action plugin. You should explicitly set the backend.')



# Generated at 2022-06-11 13:06:11.037136
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = AnsibleActionModule("/path/to/my/ansible/yum.py")
    assert module.__class__.__name__ == 'AnsibleActionModule'
    assert module._connection.__class__.__name__ == 'Connection'

# Generated at 2022-06-11 13:06:13.076932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None)
    assert action is not None, "Unable to instantiate ActionModule"



# Generated at 2022-06-11 13:06:14.334590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 13:06:23.962447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule(object):
        def __init__(self):
            self.params = {'use': 'yum4'}
    action = ActionModule(MockModule())
    # test_ActionModule()
    assert action.run(task_vars={'ansible_facts': {'pkg_mgr': 'yum4'}}, tmp=None) == {'failed': True,
                                                                                       'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend.",
                                                                                       'msg': "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})"}

# Generated at 2022-06-11 13:06:24.701437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 13:06:29.941991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with yum backend
    action_module_run = ActionModule.run
    setattr(ActionModule, 'run', lambda x, tmp=None, task_vars=None: dict(failed=False, msg="yum"))
    ret = action_module_run(ActionModule, tmp=None, task_vars={'ansible_pkg_mgr': 'yum'})
    assert ret['failed'] is False
    assert ret['msg'] == "yum"

    # Test with dnf backend
    ret = action_module_run(ActionModule, tmp=None, task_vars={'ansible_pkg_mgr': 'dnf'})
    assert ret['failed'] is False
    assert ret['msg'] == "dnf"

    # Test with auto

# Generated at 2022-06-11 13:06:31.590308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod != None


# Generated at 2022-06-11 13:06:42.414307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(
        async_val=1,
        async_jid=1,
        action=dict(),
        args=dict(use_backend='yum'),
        delegate_to='foo',
        delegate_facts=True,
        delegate_to_host="foo",
        delegate_to_ip="127.0.0.1",
        delegate_from="bar",
        delegate_from_host="bar",
        delegate_from_ip="127.0.0.2",
        run_once=True
    ), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action._shared_loader_obj.module_loader.has_plugin("ansible.legacy.yum")

# Generated at 2022-06-11 13:07:06.337965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # These values are set intentionally, not to test the actual values of these parameters
    mock_connection = { "conn_type": "test_conn_type", "remote_addr": "test_remote_addr" }
    mock_action_base = {
        "_task": {
            "async_val": "test_async_val",
            "args": {
                "use": "yum3",
                "use_backend": "yum4",
                "module_extra_arg": "module_extra_val"
            },
            "delegate_to": "test_delegate_to",
            "delegate_facts": "test_delegate_facts"
        }
    }

# Generated at 2022-06-11 13:07:13.737014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''unit test for ActionModule.run'''
    action_module = ActionModule()
    action_module._remove_tmp_path = lambda a: None
    action_module._connection = object()
    action_module._connection._shell = object()
    action_module._connection._shell.tmpdir = "/a/tmp/dir"
    action_module._shared_loader_obj = object()

    class FakeModuleLoader:
        ''' Fake a module_loader for testing'''
        def has_plugin(self, module):
            if module in 'ansible.legacy.yum':
                return True
            return False

    action_module._shared_loader_obj.module_loader = FakeModuleLoader()

    # Fail without facts
    task = dict(args=dict(name='vim-minimal'))

# Generated at 2022-06-11 13:07:25.400457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(a=1, b=2, c=3), dict(d=4, e=5, f=6))
    action._load_name = "action_module"
    action._task.action = "action_module"
    action._connection = dict(module_name="ping")
    action._task.args = dict(module_name="ping")
    action._task.async_val = 333
    action._task.delegate_to = "localhost"
    action._shared_loader_obj = dict(module_loader=dict(has_plugin=lambda x: True))


# Generated at 2022-06-11 13:07:36.134322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule

    '''

    module = ActionModule()

    # run tests in various combinations of use_backend and use
    for use_backend in (None, "yum4", "yum"):
        for use in (None, "yum4", "yum", "some_other_thing"):
            # let use_backend take precedence over use
            # set up task args in order of precedence
            task_args = dict()
            if use_backend:
                task_args['use_backend'] = use_backend
            if use:
                task_args['use'] = use

            # Get the results from module.run
            result = module.run(task_args)
            assert result['failed']
            assert result['msg']

    # run tests to ensure

# Generated at 2022-06-11 13:07:43.547474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule(
        task={
            'BEGIN': [],
            'END': [],
            'name': 'yum',
            'ignore_errors': False,
            'when': True,
            'args': {
                'name': 'httpd',
                'use_backend': 'auto',
            },
        }, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )
    assert test
    assert test.TRANSFERS_FILES == False



# Generated at 2022-06-11 13:07:45.589971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_plugin = ActionModule(None, None)
    action_plugin.run(None, None) 


# Generated at 2022-06-11 13:07:46.464004
# Unit test for constructor of class ActionModule
def test_ActionModule():
   test_task = None
   result = ActionModule(test_task, tmp=None, task_vars=None)
   assert result != None

# Generated at 2022-06-11 13:07:54.945769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_facts=dict(pkg_mgr="yum"))
    module_args = dict(
        name=['foo'],
        state="absent",
        use="auto")
    module = ActionModule(
        task=dict(
            args=module_args),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    result = module.run(
        task_vars=task_vars)
    assert result['module_name'] == 'ansible.legacy.yum'

# Generated at 2022-06-11 13:07:58.440239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=None, play_context=None, loader=None,
                          templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 13:08:05.058552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    action_module = ActionModule()
    task_vars = dict(ansible_managed="Ansible managed",
                     ansible_version="2.2.2.0")

    action_module._shared_loader_obj = AnsibleLoader()
    action_module._task = AnsibleTask()
    action_module._connection = AnsibleConnection()
    action_module._templar = AnsibleTemplar()
    action_module._play_context = PlayContext()

# Generated at 2022-06-11 13:08:31.191625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-11 13:08:39.349785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yum_action_module = ActionModule.ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(),
                                                  templar=dict(), shared_loader_object=dict())
    assert yum_action_module is not None
    assert yum_action_module.loader is not None
    assert yum_action_module.task == {}
    assert yum_action_module.templar is not None
    assert yum_action_module.shared_loader_object is not None
    assert yum_action_module.connection == {}
    assert yum_action_module.play_context == {}

# Generated at 2022-06-11 13:08:49.006463
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    from ansible.module_utils.facts.system.base import BaseFactCollector

    class myBaseFactCollector(BaseFactCollector):
        name = 'pkg_mgr'

    exception = None

# Generated at 2022-06-11 13:08:59.244301
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_module_args = dict(
        name=['vim-enhanced'],
        state='present'
    )
    mock_task_vars = dict(
        ansible_facts=dict(
            pkg_mgr='auto'
        )
    )
    mock_tmp = None
    mock_Display = 'Display'
    action_base_module = ActionBase()
    action_base_module.display = mock_Display
    action_base_module._supports_check_mode = True
    action_base_module._supports_async = True

    action_module = ActionModule()
    action_module._task = action_base_module._task
    action_module._shared_loader_obj = action_base_module._shared_loader_obj
    action_module._task_vars = mock_task_v

# Generated at 2022-06-11 13:09:03.904178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    action_in = {}
    action_out = mod.run(tmp=None, task_vars=None)
    action_expected_out = dict()
    assert action_out == action_expected_out

# Generated at 2022-06-11 13:09:11.994756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from Units.Mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import ActionModuleComponent, ActionModule
    import json

    class MockConnection:
        # Mock connection class and its methods

        def __init__(self, *args):
            # Rather than use this as a connection, we just store the args so we can
            # check they were properly passed in
            self.args = args

    class MockDisplay:
        # Mock Display class and its methods

        def __init__(self, *args):
            self.args = args


# Generated at 2022-06-11 13:09:19.276008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='yum', args=dict(src='http://www.example.com/'))),
        connection=dict(host='localhost', port=22, username='ansible', password='ansible', private_key_file='/tmp/ansible'),
        play_context=dict(become_method='sudo', become_user='root', become=True, verbosity=2),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-11 13:09:21.633989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert 'auto' == module.run(None, None)['ansible_facts']['pkg_mgr']

# Generated at 2022-06-11 13:09:30.755384
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test without expected args
    element = dict(
        _task=dict(
            args=dict()
        )
    )

    x = ActionModule(element)
    assert x.run() == dict(
        failed=True,
        msg="('use', 'use_backend')"
    )

    # Test with correct use_backend
    element = dict(
        _task=dict(
            args=dict(
                use_backend='yum'
            )
        )
    )

    x = ActionModule(element)
    assert x.run() == dict(
        ansible_facts=dict(
            pkg_mgr='yum'
        )
    )

# Generated at 2022-06-11 13:09:36.016786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict(
        args=dict(
            use_backend="auto"
        )
    )
    _task_vars = dict()
    _result = dict()

    display.verbosity = 4
    # test doesn't work with run_once enabled
    action_mod = ActionModule(task=_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_mod.run(task_vars=_task_vars)
    assert result == _result

# Generated at 2022-06-11 13:10:33.997495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a task
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    task = Task()
    task._role = Role()
    task._block = Block()
    task.name = "test task"
    task.args = dict(module_name='test', module_args='test args')

    host = Host(name="test host")

# Generated at 2022-06-11 13:10:44.634599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import ansible
    module_name = 'ansible.builtin.yum'
    module = sys.modules[module_name]
    sys.modules[module_name] = None
    test_module = __import__(module_name, fromlist=[module_name])
    sys.modules[module_name] = module
    yum = ansible.plugins.action.yum.ActionModule(
        task=ansible.playbook.task.Task(
            action=dict(
                action='ansible.builtin.yum',
                args=dict(
                    name='some-package',
                    state='present',
                ),
                module_name='ansible.builtin.yum',
            ),
        ),
    )

    def _templar(string):
        return string

    yum._tem

# Generated at 2022-06-11 13:10:45.535209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:10:48.312475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({}, {})
    assert isinstance(action, ActionModule)
    assert action._supports_check_mode, "action must support check_mode"
    assert action._supports_async, "action must support async"

# Generated at 2022-06-11 13:10:49.092798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 13:10:53.733001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test to check that the run() method of ActionModule correctly handles the cases
    where the yum module would fail without this action plugin
    """

    # Run the run() method of ActionModule to see if we can change the backend to yum4
    module = ActionModule()
    module.DEFAULT_TMP_PATH = '/tmp'
    result = module.run(task_vars={'ansible_pkg_mgr': 'auto'})
    assert result['failed'] == False

# Generated at 2022-06-11 13:11:03.229771
# Unit test for constructor of class ActionModule
def test_ActionModule():

    def my_execute_module():
        return dict(my_execute_module=1)

    fake_loader = dict(
        module_loader=dict(
            has_plugin=lambda x: True,
        ),
        shared_loader_obj=dict(
            module_utils=dict(
            ),
            _load_name_to_path_map=lambda: dict(),
        ),
    )
    fake_task = dict(
        async_val=False,
        delegate_to=None,
        delegate_facts=False,
        args=dict(
            use_backend=None,
            use=None,
        ),
    )



# Generated at 2022-06-11 13:11:10.348627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Loads action plugin
    module = ActionModule()
    # Set up a mock task object
    task = AnsibleTask()
    # call run function with mock object
    result = module.run(task_vars=None, tmp=None)
    # check if results are as expected
    assert result.get('failed') == True
    assert result.get('msg') == \
        ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
         "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")


# Generated at 2022-06-11 13:11:10.924771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:11:11.833823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Noting to do yet
    pass

# Generated at 2022-06-11 13:13:02.742347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test _execute_module
    params = {'use_backend': 'yum'}
    params_copy = params.copy()
    assert ActionModule._execute_module(module_name='ansible.legacy.yum', module_args=params, task_vars={}, wrap_async=0) == {'failed': True, 'msg': "Could not find a yum backend module for yum."}
    assert params == params_copy

    # test run(): module = yum (yum3)
    params = {'use': 'yum3'}
    assert ActionModule.run(task_vars={}, tmp=None, **params) == {'failed': True, 'msg': "Could not find a yum module backend for ansible.legacy.yum3."}

# Generated at 2022-06-11 13:13:09.926113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''test_ActionModule_run tests the method run of class ActionModule'''
    import sys
    module_name = "ansible.legacy.yum"
    module_args = {'name': 'httpd'}
    module_kwargs = {"task_vars": {'_ansible_no_log': True}}
    if sys.version_info[:2] > (2, 6):
        module_kwargs['_ansible_no_log'] = True

    import ansible.plugins.action.yum as yum
    action_module = yum.ActionModule()
    display.verbosity = 4
    result = action_module.run(task_vars=module_kwargs, module=module_name, module_args=module_args)
    if result:
        display.display(result)

# Generated at 2022-06-11 13:13:10.790951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({}, {}).run()

# Generated at 2022-06-11 13:13:12.299443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._supports_check_mode
    assert am._supports_async

# Generated at 2022-06-11 13:13:13.344773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_obj = ActionModule()

# Generated at 2022-06-11 13:13:14.797246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert isinstance(x, ActionModule)


# Generated at 2022-06-11 13:13:15.890106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-11 13:13:26.304349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_object = ActionModule(task=None, connection=None, play_context=None, loader=None,
                                        templar=None, shared_loader_obj=None)
    # Valid values for 'module'
    module = 'auto'
    assert action_module_object._task.args == {}
    assert action_module_object._task.delegate_to == None
    # 'ansible.legacy.setup' module is not present in directory '/home/ansible/ansible/lib/ansible/modules/legacy'

# Generated at 2022-06-11 13:13:36.035290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.yum as yum
    from ansible.plugins.action.yum import ActionModule

    # Create a test object
    action_module = yum.ActionModule(
        {'_ansible_verbosity': 3, '_ansible_check_mode': False},
        {},
        {'module_name': 'yum', 'module_args': {'use': None,},})
    # Create a test object
    action_module1 = ActionModule(
        {'_ansible_verbosity': 3, '_ansible_check_mode': False},
        {},
        {'module_name': 'yum', 'module_args': {'use': 'yum3',},})
    # Create a test object

# Generated at 2022-06-11 13:13:41.326358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockAnsibleModule:
        def __init__(self):
            self.args = {
                'use': 'yum',
            }

    class MockAnsibleAction:
        def __init__(self):
            self.args = {
                'use': 'yum',
            }

    class MockAnsibleTemplar:
        def __init__(self):
            self.res = {
                'package_name': 'ansible',
                'use': 'yum',
            }

        def template(self, var):
            return self.res[var]

    class MockAnsibleExecutor:
        def __init__(self):
            pass

        def run_async(self, name, args, tmp, task_vars):
            return None
