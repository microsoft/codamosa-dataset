

# Generated at 2022-06-11 13:05:02.329907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.errors
    import ansible.playbook.play_context
    import ansible.utils.display

    class MockDisplay(ansible.utils.display.Display):
        def __init__(self, *args, **kwargs):
            self.display_msg_calls = 0
            self.display_debug_calls = 0
            self.display_vvvv_calls = 0

        def display(self, msg, *args, **kwargs):
            if msg.startswith('Failed to get Ansible Module system facts'):
                self.display_msg_calls += 1

        def debug(self, msg, *args, **kwargs):
            if msg.startswith('Facts'):
                self.display_debug_calls += 1


# Generated at 2022-06-11 13:05:10.049638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.network_os = 'auto'
    play_context.remote_addr = '127.0.0.1'

    # dummy task object
    task = Task()
    task.action = 'yum'
    task.async_val = 42
    task.args = {'name': 'vim-enhanced'}

    # dummy action plugin without module_loader
    def load_module_source(module_name):
        return ''

    action_plugin = action_loader.get('yum', loader=load_module_source, play_context=play_context)


# Generated at 2022-06-11 13:05:21.280959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_Action_Base_member_run = ActionBase.run
    ActionBase.run = lambda *args, **kwargs: None

    test_var = dict()
    test_task = dict(args=dict())
    test_inst = ActionModule(
        task=test_task, connection=None, play_context=None, loader=None,
        templar=None, shared_loader_obj=None)
    test_tmp = None
    test_task_vars = None

    test_inst._execute_module = lambda *args: None # pylint: disable=protected-access
    test_inst._supports_async = True


# Generated at 2022-06-11 13:05:23.015055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Just run the code within the constructor to ensure no exceptions.
    _ = ActionModule(None, None)


# Generated at 2022-06-11 13:05:23.676612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:05:24.265476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:05:33.045920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        connection=None,
        _task={"args": {"use_backend": "yum"}},
        _play_context={},
        _loader=None,
        _templar=None,
        _shared_loader_obj=None)

    assert action_module is not None

    action_module = ActionModule(
        connection=None,
        _task={"args": {"use": "yum"}},
        _play_context={},
        _loader=None,
        _templar=None,
        _shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-11 13:05:41.642901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Verify all the main attributes of class ActionModule are set correctly
    assert 'ActionModule' in globals()

    actionModule = globals()['ActionModule']
    assert actionModule.__name__ == 'ActionModule'

# Generated at 2022-06-11 13:05:52.420563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import yaml
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager

    mock_loader = Mock()
    mock_loader.module_loader = mock_loader
    mock_loader.has_plugin.return_value = True

    def load_module(self, module_name, *args, **kwargs):
        module = Mock()
        module.run.return_value = {'hi': 'bye'}
        return module

    def load_module_fail(self, module_name, *args, **kwargs):
        raise Exception("FAILED")

    mock_loader.module_loader.load_module.side_effect = load_module
    mock_loader.module_loader.fail_module.side_effect = load_module_fail

    mock_task = MagicMock()


# Generated at 2022-06-11 13:05:53.432958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 13:06:07.144022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock all imported python modules
    # import modules to run unit test
    from ansible.utils.display import Display

    from ansible.plugins.action.yum import ActionModule

    from .mock_base_class import MockBaseClass

    from .mock_template import MockTemplar

    from .mock_task_vars import MockTaskVars

    # create mock objects
    display = MockBaseClass()
    a = MockBaseClass()
    template = MockTemplar()
    task_vars = MockTaskVars()

    # create object and set required instance variables
    yum_action_module = ActionModule(a, task_vars, templar=template, display=display)

    # set required attributes
    yum_action_module._task.async_val = None
    yum_action_module._

# Generated at 2022-06-11 13:06:19.895728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    import ansible.modules

    # Setup - create a dummy ansible.cfg and copy the test module into the module_utils directory
    if not os.path.exists(os.path.join(os.path.dirname(__file__), 'module_utils')):
        os.mkdir(os.path.join(os.path.dirname(__file__), 'module_utils'))
    if not os.path.exists(os.path.join(os.path.dirname(__file__), 'module_utils/yum')):
        os.mkdir(os.path.join(os.path.dirname(__file__), 'module_utils/yum'))

# Generated at 2022-06-11 13:06:25.828619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = type('', (object,), {'async_val': False, 'args': {}, 'delegate_to': None, 'delegate_facts': False})
    mock_loader = type('', (object,), {'module_loader': type('', (object,), {'has_plugin': True})})

    the_module = ActionModule(
        task=mock_task, connection=None, play_context=None, loader=mock_loader, templar=None, shared_loader_obj=None
    )
    assert the_module is not None


# Generated at 2022-06-11 13:06:27.897365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    :Summary: Test Constructor of class ActionModule
    '''
    assert ActionModule

# Generated at 2022-06-11 13:06:39.785839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    import pytest
    import os
    import sys

    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, host, loader, variable_manager, passwords=None, stdout_callback=None):
            self._host = host
            self._loader = loader
            self._variable_manager = variable_manager
            self._passwords = passwords

# Generated at 2022-06-11 13:06:49.016553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup input values
    # Necessary to allow this test to run without ansible.module_utils.yum
    setattr(ActionModule, '_execute_module', lambda self, **kwargs: {'failed': False})
    setattr(ActionModule, '_remove_tmp_path', lambda self, **kwargs: {})
    setattr(ActionModule, '_supports_check_mode', True)
    setattr(ActionModule, '_supports_async', True)
    setattr(Display, 'debug', lambda self, **kwargs: {})
    setattr(Display, 'vvvv', lambda self, **kwargs: {})

    tmp = None

# Generated at 2022-06-11 13:06:50.740666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 13:07:01.067408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display = Display()

    class FakeTemplar:
        def template(self, input):
            if 'ansible_pkg_mgr' in input:
                return 'yum4'
            return 'dnf'

    class FakeTask:
        args = {'name': ['vim'], 'state': 'latest', 'disable_gpg_check': False, 'use': 'yum'}
        async_val = False

    templar = FakeTemplar()
    task = FakeTask()

    action_plugin = ActionModule(task, templar, display)

    module = action_plugin.run(None, None)

    assert module['failed'] is False
    assert module['msg'] == "All items completed"


# Generated at 2022-06-11 13:07:02.463609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct the class with parameters values
    am = ActionModule(task={"args": {"a": "b"}}, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._task.args['a'] == 'b'

# Generated at 2022-06-11 13:07:03.657327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('', {}, {}, '')

# Generated at 2022-06-11 13:07:27.431996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule constructor with valid arguments
    action_module = ActionModule(
        {"module_name": "test_module_name",
         "module_args": {"test_module_arg1": "test_module_args1_value",
                         "test_module_arg2": "test_module_args2_value"},
         "task_vars": {'test_task_var1': 'test_task_var1_value',
                       'test_task_var2': 'test_task_var2_value'}},
        load_frm_file=False)

    # Test ActionModule constructor with invalid arguments

# Generated at 2022-06-11 13:07:37.359283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation
    a = ActionModule()

    # setting vars
    s = {}
    s['action.yum'] = '/home/my/work/home/yum'
    s['action.dnf'] = '/home/my/work/home/dnf'

    # test member variable
    assert a._shared_loader_obj.module_loader.has_plugin(s) == False
    assert a._task.args.get('use') == 'auto'
    assert a._task.args.get('use_backend') == 'auto'
    assert a._task.delegate_to not in VALID_BACKENDS
    assert len(a.VALID_BACKENDS) == 2
    assert 'yum' in a.VALID_BACKENDS
    assert 'dnf' in a.VALID_BACKENDS

# Generated at 2022-06-11 13:07:39.768286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None)
    assert module.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))

# Generated at 2022-06-11 13:07:50.968547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def mock_execute_module(*args, **kwargs):
        return {
            "msg": "Successfully executed a test module",
        }

    from ansible.plugins.loader import action_loader
    import ansible.plugins.action
    import ansible.module_utils.yum
    import ansible.plugins.action.yum

    mock_task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum',
        },
    }

    am = ansible.plugins.action.yum.ActionModule(task=None, connection=None, play_context=None, loader=action_loader, templar=None, shared_loader_obj=None)
    am._execute_module = mock_execute_module
    

# Generated at 2022-06-11 13:07:52.304179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() is ''

# Generated at 2022-06-11 13:08:02.192498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_loader = DictDataLoader(
        {
            'vars/main.yml': '''
            ---
            ansible_facts:
              pkg_mgr: yum
            ...
            ''',
        }
    )
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    passwords = {}
    variable_manager.extra_vars = {"host": "localhost", "group": "test"}
    variable_manager.set_inventory(fake_inventory)
    # Set settings to enable yum action plugin to work
    display.verbosity = 10
    display.deprecated_warnings = False
    # Execute action plugin

# Generated at 2022-06-11 13:08:09.601375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = {
        'ip6tables_version': 42
    }
    module_name = "ansible_facts.ip6tables_version"
    templar = Display()
    args_use_backend = dict(use_backend="yum")
    task = Display(args=args_use_backend)
    module = ActionModule(args=task, connection=None, _play_context=None, loader=None,
                          templar=templar, shared_loader_obj=None)
    module.run(task_vars=hostvars)

# Generated at 2022-06-11 13:08:20.914191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments to ActionModule
    tmp = None
    task_vars = None
    # Return value of ActionModule.run
    result = True
    # Return value of method run of class ActionBase
    result_run_AB = True
    # Return value from _execute_module
    result_ex_mod = {'failed': True}
    # Return value of _execute_module for the case where a module
    # that does not exist is referenced
    result_AB_non_existent = {'failed': True, 'msg': "Could not find a yum module backend for ansible.legacy.yum3.yum3.yum3."}
    # Return value from pkg_mgr after calling the facts module
    result_pkg_mgr = "yum"
    # Return value from _execute_module with use = None
    result

# Generated at 2022-06-11 13:08:24.077239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(name=["foo"])), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None


# Generated at 2022-06-11 13:08:27.772612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    ActionModule run method unit test
    '''
    tmp = tempfile.TemporaryDirectory()

    with tempfile.NamedTemporaryFile() as tf:
        with open(tf.name, 'w') as tf_file:
            tf_file.write("""#!/bin/bash
                            echo -n '{"ansible_facts": {"pkg_mgr": "auto"}}'
                        """)
        os.chmod(tf.name, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)

        # set up mocks
        m = MagicMock(spec=ActionBase, wraps=ActionBase())
        m._task = MagicMock()
        m._task.args = {}
        m._display = MagicMock(spec=Display, wraps=Display())


# Generated at 2022-06-11 13:09:00.713748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    from unittest.mock import MagicMock
    import pytest
    ansible_vars = {u'ansible_facts': {u'pkg_mgr': u'yum'}}
    vars_manager = MagicMock(return_value=ansible_vars)
    loader_mock = MagicMock()
    display_mock = MagicMock()
    play_context = PlayContext()

# Generated at 2022-06-11 13:09:01.337721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:09:10.330157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.action.yum import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils._text import to_text


# Generated at 2022-06-11 13:09:14.110786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor for class ActionModule
    '''
    assert ActionModule.__doc__ == """Handler for yum3/yum4 selection prior to handing off to yum or dnf module backends.""", \
        "Constructor for class ActionModule failed."


# Unit tests for method run

# Generated at 2022-06-11 13:09:17.568202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=dict(), connection='connection', play_context=dict(), loader='loader',
                                templar='templar', shared_loader_obj='shared_loader_obj')
    assert actionModule is not None

# Generated at 2022-06-11 13:09:18.855315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_ActionModule = ActionModule()
    assert my_ActionModule is not None

# Generated at 2022-06-11 13:09:21.969433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_msg = "ActionModule constructor not working properly"
    # Test if the constructor throws  error
    try:
        ActionModule()
    except:
        pytest.fail(assert_msg)
    assert True

# Generated at 2022-06-11 13:09:24.008548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(add_option=None).__init__(add_option=None) == None


# Generated at 2022-06-11 13:09:26.141308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(ActionModule, 1, 2, 3, 4, 5)
    assert a

# Generated at 2022-06-11 13:09:28.995278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor object of the class ActionModule
    obj_ActionModule = ActionModule()

    # Test function run() with assert
    assert obj_ActionModule.run()

# Generated at 2022-06-11 13:10:17.009170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 13:10:25.467580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self, _args):
            self.args = _args
            self.task_vars = None
    class Connection:
        def __init__(self):
            self.ec2_host_info = None
            self.shell_plugin = None
            self.host = None
    class AnsibleModule:
        def __init__(self, args, _connection, _task):
            self.args = args
            self.connection = _connection
            self.task = _task
    scope = {'action': None, 'display': None, 'task': None}

    result = ActionModule.run_with_connection(scope, AnsibleModule({'use': 'yum'}, Connection(), Task({'use': 'yum'})))
    assert 'ansible_facts' in result

# Generated at 2022-06-11 13:10:35.628925
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 13:10:46.296648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule

    module = ActionModule(None, None)
    
    module._task = DummyTaskBase()
    module._task.args = {'use_backend': 'yum'}
    
    _result = module.run(None, None)

    assert _result['failed'] is False
    assert _result['msg'] == 'yum'

    module._task.args = {'use_backend': 'dnf'}
    
    _result = module.run(None, None)
    assert _result['failed'] is False
    assert _result['msg'] == 'dnf'

    module._task.args = {'use_backend': 'xxx'}
    
    _result = module.run(None, None)
    assert _result['failed'] is True



# Generated at 2022-06-11 13:10:52.859762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(None, dict())
    args = dict(
        module='foo_module',
        state='present',
        name='foo',
        use_backend='yum'
    )
    result = action_module.run(None, dict(), **args)

    assert result['failed'] == True
    assert 'msg' in result
    assert result['msg'] == ('Could not detect which major revision of yum is in use, which is required to determine module backend.'
                             'You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})')


# Generated at 2022-06-11 13:11:00.809611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests.mock import patch

    from ansible.compat.tests.mock import mock_open
    m = mock_open()
    with m, patch("ansible.executor.process.plugins.action.yum.open", m, create=True) as m:
        action = ActionModule()
        action.run(task_vars={'ansible_facts': {'pkg_mgr': 'yum'}})
        action.run(task_vars={'ansible_facts': {'pkg_mgr': 'dnf'}})
        action.run(task_vars={'ansible_facts': {}})

# Generated at 2022-06-11 13:11:09.855070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.action.yum import ActionModule
    from ansible.errors import AnsibleActionFail
    from ansible.utils.display import Display
    from ansible.constants import DEFAULT_TIMEOUT
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.common.process import get_bin_path
    import json
    import os
    import collections



# Generated at 2022-06-11 13:11:18.841170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock connection object
    conn = Connection('/dev/null')

    # create a mock task object
    task = Task('test')

    # create a mock action object
    action = ActionModule(task, conn, '/dev/null', '/dev/null', '/dev/null')

    result = action.run(task_vars={})
    assert result.get('failed') is False

    action._task.args['use'] = ['yum']
    result = action.run(task_vars={})
    assert result.get('failed') is True

    action._task.args['use'] = ['yum4']
    result = action.run(task_vars={})
    assert result.get('failed') is False
    assert 'ansible_facts' in result

# Generated at 2022-06-11 13:11:26.067012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.action as action_plugins
    import ansible.plugins.connection.ssh as conn_ssh
    import ansible.plugins.shell.sh as shell_sh
    import ansible.plugins.connection.connection as conn_connection
    import ansible.utils.plugin_docs as plugin_docs

    # load plugins
    option_class = None
    plugin_loader.add_directory('./plugins/action')
    plugin_loader.add_directory('./plugins/connection')
    plugin_loader.add_directory('./plugins/shell')
    plugin_loader.load_all()


# Generated at 2022-06-11 13:11:35.164455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""

    # Create an instance of class ActionModule
    am = ActionModule()

    # Create an instance of class TaskExecutor
    class TaskExecutor():
        """Class TaskExecutor."""

        def __init__(self):
            """Constructor of class TaskExecutor."""

            # Initialise variable _task
            self._task = None

            # Initialise variable args
            self.args = None

    # Create an instance of class TaskExecutor
    te = TaskExecutor()

    # Assign value to variable _task
    te._task = 'yum'

    # Assign value to variable args
    te.args = {"use": "auto", "name": "vim"}

    # Assign value to variable _task
    am._task = te

    # Assign value to variable _

# Generated at 2022-06-11 13:13:14.244225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None).run == ActionModule.run

# Generated at 2022-06-11 13:13:24.657080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup object vars
    class AnsibleModuleFake(object):

        def __init__(self):
            self.args = dict(use_backend='auto')

        @property
        def module_name(self):
            return 'ansible.legacy.yum'

    class TaskFake(object):

        def __init__(self):
            self.args = dict()
            self.async_val = 0
            self.delegate_to = None
            self._role = None

    class ActionBaseFake(ActionBase):

        def __init__(self):
            self._task = TaskFake()
            self._connection = None
            self._play_context = None
            self._loader = None
            self._shared_loader_obj = None
            self._templar = None
            self._task_vars = dict

# Generated at 2022-06-11 13:13:28.647333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(task=MagicMock())

    with pytest.raises(AnsibleActionFail) as e:
        mod.run(task_vars={})

    assert "parameters are mutually exclusive: ('use', 'use_backend')" in str(e.value)

# Generated at 2022-06-11 13:13:33.218129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = dict(args=dict(use='auto'))
    module.run(None, dict(ansible_facts={'pkg_mgr': 'yum'}))

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 13:13:34.674617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_module_spec=False)
    assert module.run is not None

# Generated at 2022-06-11 13:13:41.517382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a task having a use_backend argument
    task_args = {'use_backend': 'yum'}
    am = ActionModule()
    am._task = MockClass()
    am._task.async_val = 'async'
    am._task.args = task_args
    am.run()

    # Test with a task having a use argument
    task_args = {'use': 'yum'}
    am = ActionModule()
    am._task = MockClass()
    am._task.async_val = 'async'
    am._task.args = task_args
    am.run()



# Generated at 2022-06-11 13:13:51.914160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run: checks ActionModule.run()
    # Inputs:
    #    cls - ActionModule class
    #    given_args - arguments to ActionModule.run()
    #
    # Returns:
    #    returns output from ActionModule.run()
    #
    # Side effects:
    #    None
    #
    # Assumptions/Limitations:
    #    None.
    #
    # Test Steps:
    #    1. Initialize ActionModule object.
    #    2. Call ActionModule.run()
    #    3. Check returned output

    cls = ActionModule()
    # test cases
    given_args = {
        'use_backend': 'yum',
        'name': 'cifs-utils',
    }

# Generated at 2022-06-11 13:14:01.709000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._task.async_val = False
    action_module._task.args = {'name': 'ansible', 'state': 'latest'}
    action_module._task.delegate_facts = True
    action_module._task.delegate_to = 'host1'
    action_module._templar.template = lambda text: 'yum3'
    action_module._connection._shell.tmpdir = '/tmp/test'
    action_module._templar.template = lambda text: 'yum3'
    action_module._execute_module = lambda **kwargs: {'result': [], 'failed': False}
    action_module._remove_tmp_path = lambda tmpdir: None

# Generated at 2022-06-11 13:14:05.526734
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct the object
    obj = ActionModule()
    obj._task.delegate_facts = True
    obj._task.async_val = False
    # test run() with args: tmp=None, task_vars=None

    assert(obj.run() == None)

# Generated at 2022-06-11 13:14:08.952221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    #Failed as backend is not supported
    assert module.run(tmp=None, task_vars=None) == {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend."}