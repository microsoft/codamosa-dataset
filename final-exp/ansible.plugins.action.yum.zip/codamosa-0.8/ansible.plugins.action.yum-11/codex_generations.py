

# Generated at 2022-06-11 13:04:51.528718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ret = ActionModule.run(tmp = None, task_vars={})
    assert ret.get('failed') is False
    assert ret.get('ansible_facts') is not None

# Generated at 2022-06-11 13:04:52.965921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    pass

# Generated at 2022-06-11 13:04:57.530957
# Unit test for constructor of class ActionModule
def test_ActionModule():
        # Happy path
        am = ActionModule()
        am = ActionModule(task={'args': {'use': 'yum'}})

        # Sad path
        try:
            am = ActionModule(task={'args': {'use': 'invalid'}})
            assert False
        except:
            pass


# Generated at 2022-06-11 13:04:59.257543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = None
    ActionModule().run(module)


# Generated at 2022-06-11 13:05:08.469024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import json

    hostvars = dict(ansible_facts=dict(pkg_mgr='dnf'))
    facts = dict(ansible_facts=dict(pkg_mgr='dnf', ansible_pkg_mgr='dnf'))

    # Create a mock class of ansible.plugins.action.ActionBase
    class ActionBaseMock(object):
        def __init__(self, _):
            self._supports_check_mode = True
            self._supports_async = False
            self.results = dict()
            self.results['ansible_facts'] = hostvars['ansible_facts']

        def run(self, tmp=None, task_vars=None):
            return self.results


# Generated at 2022-06-11 13:05:19.736873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.module_utils.urls
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    display = Display()

    class FakeRunner:  # make a fake Runner class to add task delegate_to
        def __init__(self, connection, loader, variable_manager, task, play_context, result,
                     shared_loader_obj, inventory_manager):
            self._task = task
            self._connection = connection

    class FakeTask:  # make a fake task class
        def __init__(self):
            self.args = {'use_backend': 'yum'}


# Generated at 2022-06-11 13:05:28.585832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Fail when the 'use_backend' and 'use' keywords are both present
    # in the task args
    try:
        result = ActionModule({
            'use': 'yum',
            'use_backend': 'yum',
        })
    except Exception as result:
        pass

    assert isinstance(result, AnsibleActionFail)

    # Pass when the 'use' keyword is present in the task args
    try:
        result = ActionModule({
            'use': 'yum',
        })
    except Exception as result:
        pass

    assert result is None
    assert isinstance(result, type(None))

# Generated at 2022-06-11 13:05:30.340023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-11 13:05:30.910183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   pass

# Generated at 2022-06-11 13:05:38.179995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Result should be dict with keys:
        ansible_module_name
        ansible_module_args
        ansible_module_result
        ansible_module_status
        ansible_module_backup
    '''
    ret = ActionModule(task=dict(
        delegate_to='someserver',
        action="yum",
        args=dict(
            name=['tmux'],
            state='present'),
        async_val=10,
        action_plugins=[]
    ))
    assert ret.action == 'yum'
    assert ret.module_name == 'ansible.legacy.dnf'
    assert ret.action_plugins == []
    assert ret._task.delegate_to == 'someserver'
    assert ret._task.async_val == 10
    assert ret._

# Generated at 2022-06-11 13:05:55.274327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    task_vars = dict(ansible_facts=dict(pkg_mgr="yum4"))

    # Setup tasks
    mock_task = MagicMock()
    mock_task.args = dict(use_backend="auto", test_arg="test")
    mock_task.async_val = None
    mock_task.delegate_to = None

    # Setup module
    mock_module = MagicMock()
    mock_module.params = dict(use_backend="auto")

    # Setup ansible module runner
    mock_runner = MagicMock()
    mock_runner.run.return_value = dict(
        failed=False,
        msg="Failed")

    # Setup module loader
    mock_loader = MagicMock()

# Generated at 2022-06-11 13:05:59.281873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(pkg=['tmux'], state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    assert module

# Generated at 2022-06-11 13:06:01.625988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = {}
    results['ansible_facts'] = {}
    results['ansible_facts']['pkg_mgr'] = 'auto'
    assert ActionModule.run({},{'ansible_facts':{'pkg_mgr':'auto'}}) == results

# Generated at 2022-06-11 13:06:02.161899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:06:06.902649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a basic test for the class constructor"""
    t = ActionModule()
    assert hasattr(t, '_task')
    assert hasattr(t, '_connection')
    assert hasattr(t, '_play_context')
    assert hasattr(t, '_loader')
    assert hasattr(t, '_templar')
    assert hasattr(t, '_shared_loader_obj')

# Generated at 2022-06-11 13:06:19.541943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock
    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.errors import AnsibleActionFail
    from ansible.plugins.action.yum import ActionModule
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 13:06:20.832496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(isinstance(action_module, ActionBase))

# Generated at 2022-06-11 13:06:21.381678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:06:28.094812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'ansible.legacy.ActionModule'
    mock_module_loader = 'ansible.module_utils.module_loader.ModuleLoader'
    mock_shared_loader_obj = 'ansible.module_utils.module_loader.ModuleLoader.shared_loader'
    mock_templar = 'ansible.parsing.vault.VaultLib.template'
    mock_display = 'ansible.utils.display.Display.debug'
    mock_EXECUTE_MODULE = 'ansible.module_utils.basic.AnsibleModule.execute_module'

    class MockModuleLoader(object):
        def has_plugin(self, plugin):
            return True

    class MockSharedLoaderObj():
        def __init__(self, module_loader_obj):
            self._module_loader = module_loader_obj

# Generated at 2022-06-11 13:06:28.702041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 13:06:43.726118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: There is no unit test for ActionModule.run().  We should write it.
    # TODO: This module needs a unit test, but there is only a functional test atm.
    pass

# Generated at 2022-06-11 13:06:51.665390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    results = {'ansible_facts': {'pkg_mgr': 'yum4'}, 'msg': "ActionModule:execute", 'rc': 0, 'invocation': {}, 'changed': True, 'failed': False}

    # Setup mocks
    action_module = ActionModule()
    mock_display = Mock()
    mock_display.vvvv.return_value = True
    action_module.display = mock_display
    mock_templar = Mock()
    mock_templar.template.side_effect = ["yum4"]
    action_module._templar = mock_templar
    mock_task = Mock()
    mock_task.async_val = False
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = False
   

# Generated at 2022-06-11 13:06:56.358429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the class
    module = ActionModule()
    # Check if the object is an instance of the class ActionModule
    assert isinstance(module, ActionModule)
    # Check if the task is an instance of the class ActionModule
    assert isinstance(module._task, ActionModule)


# Generated at 2022-06-11 13:07:03.360992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule """

    task_args = dict(use='auto')
    task_vars = dict()
    action_module = ActionModule(task=task_args, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)

    assert result is not None

# Generated at 2022-06-11 13:07:04.745788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    results = module.run()

# Generated at 2022-06-11 13:07:12.902439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for ActionModule method run
    '''

    tmp = '/tmp/test_ActionModule_run'

    # create the tmp directory if not there
    if not os.path.exists(tmp):
        os.makedirs(tmp)

    # create a temporary file for testing
    tmp_fh = tempfile.NamedTemporaryFile(prefix='ansible-tmp-tmppo', delete=False)

    # Define a mock task template
    task_tmpl = {
        'name': 'Test ActionModule',
        'action': {
            '__ansible_module__': 'yum',
            '__ansible_arguments__': {
                'use_backend': 'dnf',
                'state': 'latest',
                'name': 'kernel'
            }
        }
    }



# Generated at 2022-06-11 13:07:24.243264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyBase
    import json
    import pytest
    import sys
    import os
    import tempfile

    class TestStrategy(StrategyBase):
        pass

    display = Display()

    loader = DataLoader()
    results_callback = None

    inventory = Inventory

# Generated at 2022-06-11 13:07:35.231075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule.

        :return:
            None
    '''

    # create a mock class object and mock module object
    mock_class_obj = type('ActionModule', (object,), {'run': ActionModule.run})
    mock_module_obj = type('module', (object,), {'NO_LOG': False, '_diff': False, '_connection': '_connection'})

    # set up the return values
    mock_class_obj.VALID_BACKENDS = VALID_BACKENDS
    mock_class_obj._templar = type('templar', (object,), dict(template='template'))
    mock_class_obj._connection = type('connection', (object,), dict(tmpdir='tmpdir'))

# Generated at 2022-06-11 13:07:40.743905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test that run triggers a failure with a specific message when
    # the 'use' param is provided as well as the 'use_backend' param
    am = ActionModule()
    am._task = Task()
    am._task.args = {'use': 'yum4', 'use_backend': 'dnf'}
    with pytest.raises(AnsibleActionFail) as e:
        am.run()
    assert "parameters are mutually exclusive" in str(e)



# Generated at 2022-06-11 13:07:43.896877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(),
                        templar=dict(), shared_loader_obj=dict()).__class__ is ActionModule

# Generated at 2022-06-11 13:08:08.940652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    assert ActionModule is not None

# Generated at 2022-06-11 13:08:14.069756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        am = ActionModule(None, None, None, None)
    except Exception as err:
        raise AssertionError("ActionModule constructor raised an exception: %s" % err)
    if not isinstance(am, ActionModule):
        raise AssertionError("ActionModule constructor did not return an ActionModule object!")

# Generated at 2022-06-11 13:08:15.119252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Hello")



# Generated at 2022-06-11 13:08:19.853337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    TaskVars = {
        'inventory_hostname':'test',
        'ansible_user':'test',
        'ansible_facts':{
            'pkg_mgr':False
        }
    }
    tmp = None
    acm = ActionModule(TaskVars)
    acm.run(tmp,TaskVars)

# Generated at 2022-06-11 13:08:22.575051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        {
            "args": {
                "foo": "bar"
            },
            "async": "10000",
            "delegate_to": "localhost"
        }
    )

# Generated at 2022-06-11 13:08:23.586814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 13:08:30.567277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    # get a fake args
    args = dict()

    # get a fake templar
    templar = "Templar"

    # get a fake display
    display = "Display"

    # get a fake task
    task = "Task"

    # get a fake action_base
    action_base = "ActionBase"

    # get a fake delegation
    delegation = "Delegation"

    # get a fake loader
    loader = "Loader"

    # get a fake connection
    connection = "Connection"

    # get a temporary directory
    tmpdir = "/tmp/ansible"

    # create a ActionModule object

# Generated at 2022-06-11 13:08:32.704948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule(None, None, None, None)
    assert test_object is not None

# Generated at 2022-06-11 13:08:35.828292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        pass
    t = TestActionModule(None, None, None, None, None, None, None, None)
    # test defaults
    assert t._task_vars == {}

# Generated at 2022-06-11 13:08:37.604251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(ActionBase, 'fake_action', 'fake_play', 'play_context')

# Generated at 2022-06-11 13:09:26.369103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    assert a

# Generated at 2022-06-11 13:09:27.666334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule().run()

# Generated at 2022-06-11 13:09:31.951719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(action=dict())
    task['args'] = dict(name='mypackage', state='latest')
    tmp = "/tmp"
    task_vars = dict()
    am = ActionModule()
    am.task = task
    result = am.run(tmp, task_vars)
    assert result['module_name'] == 'yum'

# Generated at 2022-06-11 13:09:35.543817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule(
        task=dict(args=dict(use="dnf", name="httpd")),
        connection=dict(host='localhost'),
        play_context=dict(remote_addr='127.0.0.1'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    return test


# Generated at 2022-06-11 13:09:45.034599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    yum action plugin module constructor should return an instance of ActionModule
    """
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(loader=loader, sources='localhost,')


# Generated at 2022-06-11 13:09:47.087774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='package1'))
    )
    assert action_module is not None

# Generated at 2022-06-11 13:09:50.584417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(
        module='yum',
        args=dict(),
    ))
    sut = ActionModule(task, 'test_host', {'task': task})
    assert sut is not None
    assert sut._supports_check_mode
    assert sut._supports_async

# Generated at 2022-06-11 13:09:53.665544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ constructor test """
    my_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert my_obj

# Generated at 2022-06-11 13:10:03.004951
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import imp
    import json
    import os

    from ansible.modules.legacy.packaging.os import yum
    from ansible.module_utils._text import to_bytes

    # Set module args and connection info
    module = yum.ActionModule()

    # Load and execute the yum action plugin
    module.run(task_vars=dict(ansible_connection='local', ansible_python_interpreter='python3.6'))

    # Gather task results and assert
    result = module.run_command(['python3.6', '-c',
                                 'import os; print(json.dumps(dict(ansible_facts=dict(pkg_mgr=os.getenv(\'PACKAGE_MANAGER\')))))'])

# Generated at 2022-06-11 13:10:09.165783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task, target = get_task_and_target_for_module('yum')
    # Execute method run with minimum valid arguments (yum3, yum4 and auto params)
    # and expect that it returns a valid result python dict
    result = yum_module.run(task, target)
    assert type(result) is dict
    assert 'failed' not in result
    assert 'changed' in result
    assert 'msg' in result


# Generated at 2022-06-11 13:11:58.144569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.yum import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestActionModule(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_without_failure(self):
            action = ActionModule()

            assert to_text(action) == "Yum action plugin"
            assert isinstance(action, ActionBase)
            assert isinstance(action._display, Display)

# Generated at 2022-06-11 13:12:02.445359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task_vars = dict()
    mock_task = dict()
    mock_shell = dict()
    j = ActionModule(connection=None, task=mock_task, shell=mock_shell, templar=None, shared_loader_obj=None)
    j.run(tmp=None, task_vars=mock_task_vars)

# Generated at 2022-06-11 13:12:03.896495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    acm = ActionModule()
    return acm

# Generated at 2022-06-11 13:12:05.158159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure we get an object from the constructor
    assert ActionModule()

# Generated at 2022-06-11 13:12:05.856132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 13:12:15.314471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    # tests for run() when the module == 'auto'
    task = dict()
    task['args'] = {}
    task['async'] = None
    task['async_val'] = None
    task['connection'] = None
    task['delegate_facts'] = True
    task['delegate_to'] = None
    task['delegate_to_action'] = 'test'
    task['loop'] = None
    task['notify'] = None
    task['register'] = None
    task['tags'] = None
    task['until'] = None
    task['vars'] = None
    task['when'] = None

    assert am.run(task_vars=dict()) == {'failed': False, 'msg': 'Skipped'}

    task['args']['use_backend']

# Generated at 2022-06-11 13:12:17.065633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: need to port tests over
    # This is just to get coverage of the run method
    a = ActionModule(task=dict(action=dict(module_name='yum', module_args=dict())))
    a.run(task_vars=dict())

# Generated at 2022-06-11 13:12:20.194658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test setup
    fake_args = { "use": "yum" }
    # Test
    result = ActionModule(fake_args)
    # Validation
    assert isinstance(result.run(), dict)

# Generated at 2022-06-11 13:12:23.747382
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create test object
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, shared_loader_obj=None, templar=None, ansible_version_info=[])

    # execute run function and test for expected result
    pass

# Generated at 2022-06-11 13:12:29.430496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys

    # https://github.com/ansible/ansible/pull/55475/files
    if (sys.version_info[0] == 2):
        from ansible.compat.tests.mock import patch
    else:
        from unittest.mock import patch

    from ansible.plugins.action import ActionBase

    with patch.object(ActionBase, '_execute_module', return_value={'ansible_facts': {'pkg_mgr': 'yum'}}):
        yum_action_module = ActionModule()
        yum_action_module.run(task_vars={'ansible_facts': {'pkg_mgr': 'yum'}})