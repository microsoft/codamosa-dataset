

# Generated at 2022-06-11 13:04:53.595814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict(failed=False, msg='')
    try:
        obj = ActionModule(None, None)
    except Exception as e:
        result['failed'] = True
        result['msg'] = "Failed to instantiate ActionModule (%s)" % str(e)
    return result

# Generated at 2022-06-11 13:05:04.113688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Instantiate ActionModule
    #
    module = ActionModule(
    )

    #
    # Define test cases
    #
    test_cases = [
        {
            'input': {
                'args': dict(use='yum4')
            },
            'asserts': {
                'module_name': 'ansible.legacy.dnf',
                'async_val': False
            }
        },
    ]

    #
    # Run test cases
    #
    for test_case in test_cases:
        result = module.run(**test_case['input'])
        assert test_case['asserts']['module_name'] == result['module_name']
        assert test_case['asserts']['async_val'] == result['async_val']

# Generated at 2022-06-11 13:05:04.942564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 13:05:16.701311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get the class object
    module_class = ActionModule()

    # Create new instance of class object
    module_instance = module_class()

    # Sample task_vars
    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum'
        }
    }

    # Sample args for method run.
    # yum command: yum install -y package1 package2
    args = {
        "name": [
            "package1",
            "package2"
        ],
        "state": "present",
        "disable_gpg_check": False
    }

    # Invoke the method run
    response = module_instance.run(task_vars=task_vars, tmp=None, **args)

    # Assert response

# Generated at 2022-06-11 13:05:22.233489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tested on python 2.6
    module = ActionModule()
    module._connection = Connection()
    module._connection.run = MagicMock(return_value={'msg': '', 'failed': False, 'changed': False, 'invocation': {'module_name': 'setup', 'module_args': '', 'module_lang': '',}})

    # run method with exiting module
    module.run()

# Generated at 2022-06-11 13:05:32.332913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(args=dict(name='test')), connection=dict())
    assert hasattr(module, '_shared_loader_obj')
    assert hasattr(module, '_templar')
    assert hasattr(module, '_task')
    assert hasattr(module, '_task_vars')
    assert hasattr(module, '_connection')
    assert hasattr(module, '_play_context')
    assert hasattr(module, '_loader')
    assert hasattr(module, '_find_needle')
    assert hasattr(module, '_lookup_plugin')
    assert hasattr(module, '_templar')
    assert hasattr(module, '_shared_loader_obj')

# Generated at 2022-06-11 13:05:40.376682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for run method of class ActionModule"""
    display = Display()
    action = ActionModule(task={"args": {}})
    action._connection = connection

    display.vvvv = mock.Mock()
    display.debug = mock.Mock()
    action._remove_tmp_path = mock.Mock()

    ############################################
    # Testing the use of the use_backend option

    # Test yum3 backend
    action._execute_module = mock.Mock()
    action.run(task_vars={"ansible_pkg_mgr": "yum"})
    action._execute_module.assert_called_with('ansible.legacy.yum', {}, task_vars={"ansible_pkg_mgr": "yum"}, wrap_async=None)

    # Test yum

# Generated at 2022-06-11 13:05:41.871677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    assert True == True

# Generated at 2022-06-11 13:05:44.068081
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mymodule = ActionModule()
    mymodule._display.display("hello world")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 13:05:54.905579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    from ansible.compat.tests import Mock

    from ansible.plugins.action.yum import ActionModule
    import ansible.utils.encrypt as encrypt
    from ansible.plugins.loader import action_loader

    mock_task = Mock()
    mock_task.args = dict(state='present', name='rsyslog')
    mock_task.delegate_to = 'localhost'
    mock_task.async_val = 10
    mock_task.action = 'yum'
    mock_task.loop = 'localhost'
    mock_task._role = None
    mock_task._role_params = None

    mock_loader = action_loader.ActionBase()

    mock_connection = Mock()
    mock_connection._shell = Mock()

# Generated at 2022-06-11 13:06:01.797180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 13:06:02.341917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 13:06:04.652626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_mock = Mock()
    ansible_mock.METHOD1(1)
    ansible_mock.METHOD2(2)
    return ansible_mock

# Generated at 2022-06-11 13:06:16.206378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.path import unfrackpath

    task_args = {"name": "bash"}

    module_args = task_args.copy()

    basedir = '~/ansible'
    tmp_path = '~/ansible/tmp'
    module_path = '~/ansible/modules'
    module_name = 'ansible.legacy.yum'

    module_args['packages'] = ['ansible', 'jboss-eap-jdk8']
    host_vars = {}

    display_args = {}


# Generated at 2022-06-11 13:06:24.251585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create dummy module
    module = "test_dnf"
    actionBase = ActionBase()

    # initilize the class ActionModule
    yumModule = ActionModule(actionBase._connection, actionBase._play_context, actionBase._task, actionBase._loader,
                             actionBase._templar, actionBase._shared_loader_obj)

    # Unit test for method run of class ActionModule
    mockTaskArgs = {"use": "yum4"}

    result = yumModule.run(None, None, mockTaskArgs)

    assert result['module_name'] == "ansible.legacy.dnf"



# Generated at 2022-06-11 13:06:25.748355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._shared_loader_obj is not None
    assert action._task_vars is None

# Generated at 2022-06-11 13:06:29.069999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_import_ansible_legacy_yum():
        from ansible.legacy.plugins.actions.yum import ActionModule
        return ActionModule

    assert test_import_ansible_legacy_yum()

# Generated at 2022-06-11 13:06:31.068024
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    mytest = {
        'module': module
    }

# Generated at 2022-06-11 13:06:33.713216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 13:06:41.039969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()

    task_object = {"args": {"use_backend": "auto"}}
    action_module_instance._task = task_object

    ansible_facts = {"ansible_pkg_mgr": "yum4"}
    task_vars = {"ansible_facts": ansible_facts}

    module = action_module_instance.run(None, task_vars)

    assert module["ansible_facts"]["pkg_mgr"] == "yum4"

# Generated at 2022-06-11 13:06:56.004620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    return 0


# Generated at 2022-06-11 13:07:07.242810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.test.units.modules.utils as utils
    import ansible.test.units.mock.ansible_modulet_utils as amu

    mod = utils.get_ansible_module('./lib/ansible/plugins/action/yum.py')

    # set up mock
    argspec = {'use_backend': {'required': False, 'type': 'str', 'default': 'auto'}}
    amu.create_mock_module(mod, argspec)

    # set up class instance
    a = ActionModule(mod)
    a._shared_loader_obj = None
    a._task = FakeYumTask({'use_backend': 'auto'})

    # add a fake module which we can use to confirm what module was called.
    a._templar = FakeTempl

# Generated at 2022-06-11 13:07:09.421717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module._task.args == {}

# Generated at 2022-06-11 13:07:19.278288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case #1:
    # Transferring yum3 to yum3
    # AnsibleActionFail is thrown
    # ansible_pkg_mgr is yum
    # use is not in task.args
    # use_backend is auto
    # use_backend is yum
    # use_backend is not in task.args
    # use is auto
    # AnsibleActionFail excepted
    m = ActionModule({'use_backend': 'auto'}, 'not used')
    m.run(None, {'ansible_facts': {'pkg_mgr': 'yum'}})
    # m.run()

    # Test case #2:
    # Transferring yum to dnf
    # AnsibleActionFail is thrown
    # ansible_pkg_mgr is yum
    # use

# Generated at 2022-06-11 13:07:25.094003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use='yum4')),
        connection=dict(module_name='yum4'),
        task_vars=dict(pkg_mgr='yum4'),
        templar=dict()
    )
    print(action_module)  # to get rid of "not used" message

# Generated at 2022-06-11 13:07:35.848887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.errors

    module = ansible.plugins.action.yum.ActionModule(
        task=ansible.plugins.task.Task(
            connection=ansible.plugins.connection.Connection(None),
            play_context=ansible.plugins.play_context.PlayContext(directory=None, play_path=None, remote_addr='localhost'),
            loader=ansible.plugins.loader.PluginLoader(),
        )
    )
    setattr(module, '_task', ansible.plugins.task.Task(
        connection=ansible.plugins.connection.Connection(None),
        play_context=ansible.plugins.play_context.PlayContext(directory=None, play_path=None, remote_addr='localhost'),
        loader=ansible.plugins.loader.PluginLoader(),
    ))


# Generated at 2022-06-11 13:07:36.949880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    return

# Generated at 2022-06-11 13:07:47.921799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raw_yml = """
    - name: run action plugin yum3 vs yum4
      yum:
        - name:
          - vim
        - enablerepo:
          - epel
        - use: auto
        - state: present
    """
    raw_args = {'ANSIBLE_MODULE_ARGS': {'enablerepo': ['epel'], 'name': ['vim'], 'state': 'present', 'use': 'auto'}}
    raw_task = ActionModule._task_class()
    raw_loader = ActionModule._loader_class()
    raw_shared_loader_obj = ActionModule._shared_loader_class()


# Generated at 2022-06-11 13:07:58.906870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = dict(action_plugins=["yum"])
    t = dict(args=dict(use_backend="yum", name="ansible", state="latest"))
    inv = dict(modules=[dict(name='setup')])
    p = ActionModule(task=t, connection=c, play_context=PlayContext(check_mode=False, diff_mode=False), loader=None, templar=None, shared_loader_obj=ModuleLoader(), collection_loader=None, variable_manager=VariableManager(loader=None, inventory=Inventory(loader=C.loader, variable_manager=VariableManager(loader=None)), version_info=C.__version_info__), all_vars=dict(), no_log=False)
    res = p.run(tmp=None, task_vars=inv)

# Generated at 2022-06-11 13:08:00.280517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task={'args': {'use': 'yum'}})
    module.run()

# Generated at 2022-06-11 13:08:29.366982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule

    my_class = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert my_class is not None

# Generated at 2022-06-11 13:08:31.776000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({'use': 'yum'}, {})
    assert action.module == 'yum'

# Generated at 2022-06-11 13:08:34.511354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-11 13:08:36.311603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(load_config_defer=False, task_vars=dict())
    assert mod

# Generated at 2022-06-11 13:08:45.915473
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import tempfile

    display.verbosity = 99
    display.debug_level = 99

    # initialization work
    with tempfile.NamedTemporaryFile() as jsonfile:
        jsonfile.write(b'{"ansible_facts": {"pkg_mgr": "yum"}}')
        jsonfile.flush()
        # test work

# Generated at 2022-06-11 13:08:46.964060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    del action_module

# Generated at 2022-06-11 13:08:47.530085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 13:08:51.126568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with all inputs
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True

    result = action_module.run(tmp=None, task_vars=None)
    assert result


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 13:08:52.726801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule with all possible configuration
    module = ActionModule()
    assert module != None


# Generated at 2022-06-11 13:09:03.147299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method _run of class ActionModule'''

    # Dummy result.
    result = {}

    # Dummy args of the method.
    args = {'name': "test_package"}

    # Dummy task variables.
    task_vars = {'ansible_pkg_mgr': "dnf", 'ansible_facts': {'pkg_mgr': "dnf"}}

    # Dummy task.
    class Task:
        '''Dummy task class'''
        def __init__(self, args, async_val=False, delegate_to="", delegate_facts=False):
            self.args = args
            self.async_val = async_val
            self.delegate_facts = delegate_facts
            self.delegate_to = delegate_to

    # Create a dummy task object.

# Generated at 2022-06-11 13:10:04.748124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule


# Generated at 2022-06-11 13:10:06.844307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

    assert a.__class__ is ActionModule


# Generated at 2022-06-11 13:10:16.836788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    mock = {
        'new_module_args': {},
        'changed': False,
        '_ansible_no_log': False,
        '_ansible_verbose_always': True,
        'failed': False,
        '_ansible_parsed': True,
        'invocation': {
            'module_args': {
                'use': 'yum',
                'use_backend': 'yum4',
                'name': 'kernel',
            }
        },
        '_ansible_module_name': 'yum',
        '_ansible_syslog_facility': 'LOG_USER',
        'state': 'installed',
        '_ansible_module_implementation': {
        },
    }

# Generated at 2022-06-11 13:10:22.629031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: This unit test is work in progress
    task = dict(
        action=dict(module='action_plugin.yum4')
    )
    task_vars = dict()
    tmp = None

    am = ActionModule(task, tmp, task_vars)
    result = am.run(tmp, task_vars)

    assert result['failed'] is False, \
        "Failed to execute the yum ansible module"

# Generated at 2022-06-11 13:10:25.491203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, None, None, None)
    assert act.TRANSFERS_FILES == False



# Generated at 2022-06-11 13:10:30.572514
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    d = {}
    d['module_name'] = 'ansible.legacy.yum'
    d['module_args'] = dict() 
    d['module_args']['use'] = 'auto'
    d['task_vars'] = dict()

    a = ActionModule(d)
    res = a.run(None, d)
    return res

# Generated at 2022-06-11 13:10:33.010145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(runner=None, task=None)
    assert a is not None
    assert a.VALID_BACKENDS == ('yum', 'yum4', 'dnf')

# Generated at 2022-06-11 13:10:43.512258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Validates the Yum ActionPlugin's backend and action handling.
    '''

    from ansible.plugins import action as action_plugins
    from ansible.plugins.loader import action_loader
    from ansible_collections.ansible.community.plugins.module_utils.facts.pkg_mgr.yum import Facts as yumFacts

    # Wrap ansible.plugins.action.ActionBase.run so we can manipulate task_vars
    def wrapped_run(self, tmp=None, task_vars=None):
        task_vars['ansible_facts']['pkg_mgr'] = 'yum'
        return super(ActionModule, self).run(tmp, task_vars)


# Generated at 2022-06-11 13:10:51.617797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up a fake task, with all the required variables
    mock_task = type('MockTask', (object, ), {'args': {}, 'async_val': False, 'delegate_facts': True, 'delegate_to': None})()
    # set up a fake shared_loader_obj
    mock_shared_loader_obj = type('MockSharedLoaderObj', (object, ), {'module_loader': True})()
    # set up the class and the necessary variables for testing the run method
    test_instance = ActionModule(mock_task, mock_shared_loader_obj)

    # cases where the autodetection fails, which are still valid if a use_backend != auto is provided
    # autodetection fails, and a valid use_backend != auto is provided, returns the requested module
    test_instance._

# Generated at 2022-06-11 13:10:53.503287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(None, None, None, None, None)
    assert actionmodule

# Unit tests for run method of class ActionModule

# Generated at 2022-06-11 13:12:40.832815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-11 13:12:50.384669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            async_val=None,
            async_timeout=3600,
            action=dict(
                module='yum',
                args=dict(
                    name=['foo', 'bar'],
                    state='present',
                    use='dnf',
                ),
            ),
            delegate_to='foo',
            delegate_facts=False,
        ),
        connection={
            '_shell': {
                'tmpdir': '/tmp/',
                '_shell_plugin': None,
            },
        },
        templar={},
        shared_loader_obj={
            'module_loader': {
                'has_plugin': lambda x: True,
            },
        },
    )

    # Test execution of the module

# Generated at 2022-06-11 13:12:51.539186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a_plugin = ActionModule()
    assert not a_plugin

# Generated at 2022-06-11 13:12:53.667758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 13:13:00.415487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given a dict of execution and system context
    context = dict(task_vars=dict(ansible_facts=dict(pkg_mgr='yum')))
    # When a ActionModule instance is created with a dict as task parameters
    action_module = ActionModule(dict(args=dict(use='yum')), context=context)
    # Then assert the run method returns a dict, with the following key/value pairs
    assert action_module.run() == dict(ansible_facts=dict(pkg_mgr='yum'))

# Generated at 2022-06-11 13:13:04.377024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_actionmodule = ActionModule()
    my_actionmodule._task = {"args":
                             {"use_backend": "yum",
                              "name": "kernel",
                              "state": "installed",
                              "use": "yum"}}
    my_actionmodule._connection = "fake_connection"
    my_actionmodule.run()

# Generated at 2022-06-11 13:13:09.126801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(None, task_vars=[])
    assert obj._supports_check_mode == True
    assert obj._supports_async == True
    assert obj._task is None
    assert obj._templar is None
    assert obj._loader is None
    assert obj._shared_loader_obj is None
    assert obj._action is None
    assert obj._connection is None
    assert obj._play_context is None
    assert obj._task_vars == []
    assert obj._tmp is None


# Generated at 2022-06-11 13:13:13.673437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-11 13:13:14.300007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 13:13:14.955315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass