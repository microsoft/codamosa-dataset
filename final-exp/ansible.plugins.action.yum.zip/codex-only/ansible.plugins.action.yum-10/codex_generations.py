

# Generated at 2022-06-23 09:00:25.886280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleActionFail
    from ansible.utils.display import Display
    display = Display()
    task_vars = dict()

    def _execute_module(module_name=None, module_args=None, task_vars=None, wrap_async=None):
        return dict(failed=False, changed=False)

    class ActionModule_task(object):
        async_val = None
        args = dict()
        delegate_to = None
        delegate_facts = True

    class ActionModule_connection(object):
        class ActionModule_shell(object):
            tmpdir = "/tmp/asd"

        _shell = ActionModule_shell()


# Generated at 2022-06-23 09:00:27.472446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.TRANSFERS_FILES is False

# Generated at 2022-06-23 09:00:28.786110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:00:34.566894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.yum as yum
    import ansible.plugins.loader as loader
    import ansible.plugins.connection.local as local
    import ansible.plugins.action as action
    import ansible.playbook.play as play
    import ansible.playbook.task as task
    import ansible.playbook.role as role
    import ansible.playbook.block as block
    import ansible.playbook.handler as handler
    import ansible.playbook.handler_task as handler_task
    import ansible.playbook.included_file as included_file
    import ansible.playbook.play_context as play_context
    import ansible.playbook.task_include as task_include
    import ansible.template as template
    import ansible.utils.vars as vars

# Generated at 2022-06-23 09:00:39.578850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule Class")
    obj = ActionModule(connection=None, temporal=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert True

# Generated at 2022-06-23 09:00:41.436783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() != 0

# Generated at 2022-06-23 09:00:43.608252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    am.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 09:00:47.428074
# Unit test for constructor of class ActionModule
def test_ActionModule():

    t = ActionModule()
    assert t.TRANSFERS_FILES == False

    t = ActionModule()
    assert t._supports_check_mode == True

    t = ActionModule()
    assert t._supports_async == True

# Generated at 2022-06-23 09:00:56.709452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock as mock
    from ansible.module_utils.common.collections import ImmutableDict

    # Use string since it is json-serializable
    from ansible.executor import task_result

    mm = mock.mock_open()

    task_vars = {
        'hostvars': {},
        'vars': {'ansible_facts': {}, 'pkg_mgr': 'auto'},
        'ansible_facts': {'pkg_mgr': 'auto'},
        'ansible_check_mode': True
    }

    # Run the method
    with mock.patch('ansible.plugins.action.yum') as mocked:
        mock_module = mocked.ActionModule.return_value

# Generated at 2022-06-23 09:01:08.908305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test imoports
    import os
    import pytest
    import ansible.module_utils.yum

    # set up fixtures
    params = {'name': 'openssh-server'}

    # set up mocks
    tmpdir = '/dev/null'

    # create a mock_TaskExecutor, mock_Task to be used in the module
    class mock_Task:
        def __init__(self):
            self.async_val = None
            self.args = params
            self.delegate_facts = True
            self.delegate_to = None

    class mock_TaskExecutor:
        def __init__(self):
            self._shell = ansible.module_utils.yum.TaskExecutor(tmpdir)
            self._task = mock_Task()

    # test when yum backend is used

# Generated at 2022-06-23 09:01:14.267460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None


# Generated at 2022-06-23 09:01:22.025182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.yum import ActionModule

    module = ActionModule()

    def mock_templar(template):
        if (template == "{{hostvars['some_delegated_host']['ansible_facts']['pkg_mgr']}}"):
            return 'yum3'
        elif (template == "{{ansible_facts.pkg_mgr}}"):
            return 'yum4'
        else:
            return ''


# Generated at 2022-06-23 09:01:33.092429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # construct a mock task, since this module is called from a handler
    mock_task = type('task', (object,), {})
    mock_task.args = {'name': 'bash'}
    mock_task.delegate_to = None
    mock_task.delegate_facts = True
    mock_task.async_val = False

    # construct a mock task action plugin to use for mocking
    class ActionModuleMock(ActionModule):
        def run(self, tmp=None, task_vars=None):
            super(ActionModuleMock, self).run(tmp, task_vars)

    # mock a connection and setup module arguments
    mock_connection = type('connection', (object,), {})
    mock_connection.module_implementation_preferences = "yum"

# Generated at 2022-06-23 09:01:42.815892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_display = Display()
    mock_display.verbosity = 4
    mock_task = {
        'args': {
            'use': 'auto'
        }
    }
    mock_action_base = ActionBase(task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module = ActionModule(task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 09:01:46.251557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.__doc__

# Generated at 2022-06-23 09:01:55.132098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit testing for method 'run' of class ActionModule"""

    ver = 2

    from ansible.modules.legacy.package_facts import YumInfo
    yi = YumInfo()
    yi._ansible_version = ver
    yi._display = display

    yi._task = {
        "args": {
            "state": "absent",
            "name": "something",
            "packages": [
                "everything"
            ]
        },
        "delegate_to": None,
        "versioned_args": False
    }
    yi._task_vars = {
        "ansible_facts": {
            "pkg_mgr": "dnf"
        }
    }
    yi._tmp = None
    yi._supports_check_mode = True
    yi._

# Generated at 2022-06-23 09:01:56.198021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(10, 20, 30)

# Generated at 2022-06-23 09:02:00.994102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = dict(args=dict(use_backend='yum'))
    fake_task = dict(args=dict(use='yum'))
    fake_task = dict(args=dict(use_backend='dnf'))
    fake_task = dict(args=dict(use='dnf'))
    fake_task = dict(args=dict(use_backend='auto'))
    fake_task = dict(args=dict(use='auto'))

# Generated at 2022-06-23 09:02:08.655130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.set_loader(None)
    action_module._task = object()

    # Test case #1
    mock_module_cls = Mock()

    action_module._shared_loader_obj = Mock()
    action_module._shared_loader_obj.module_loader = mock_module_cls

    mock_module_cls.has_plugin = Mock(return_value=True)

    action_module._execute_module = Mock()
    with pytest.raises(AnsibleActionFail):
        action_module.run()

    assert action_module._execute_module.call_count == 1

# Generated at 2022-06-23 09:02:15.008032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Running unit test for class ActionModule")
    import ansible.plugins.loader

    action_module = ansible.plugins.loader.ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module == ActionModule.__dict__["__init__"](action_module)


# Generated at 2022-06-23 09:02:21.016475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(None, None)
    module = 'test'
    task_vars = {
        'a': '12',
        'b': '13'
    }
    tmp = '/tmp/test'

    ret = m.run(tmp, task_vars)
    assert ret == {
        'failed': False,
        'changed': False
    }

# Generated at 2022-06-23 09:02:23.788842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # mock module to avoid module not found error
        import ansible.modules.legacy.system.yum
    except:
        pass
    # mock module to avoid module not found error
    import ansible.module_utils.facts.system.pkg_mgr

    # mock variables
    tmp = None
    task_vars = dict()

    action_plugin = ActionModule()
    result = action_plugin.run(tmp, task_vars)

    assert result == dict()

# Generated at 2022-06-23 09:02:27.709244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #pylint: disable=undefined-variable
    '''Unit test for method run of class ActionModule'''
    _ = ActionModule(None, None)

# Generated at 2022-06-23 09:02:36.294740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.packaging.os import yum
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY2

    args = dict(
        use_backend='yum',
        name='httpd',
    )
    args.update(basic.parse_kv(kvargs=args))
    action_module = ActionModule(task=dict(action=dict(args=args), async_val=None, async_poll_interval=1),
                                 connection=None,
                                 play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)

# Generated at 2022-06-23 09:02:37.133908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:02:48.992164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Connection:
        class _shell:
            tmpdir = '/home/tmp'
        def _remove_tmp_path(self, tmpdir):
            pass
    class MockTask:
        class _ds:
            no_log = 'no_log'
        def __init__(self):
            self.async_val = 'async_val'
            self.delegate_facts = 'delegate_facts'
            self.args = {'use_backend': 'some_value',
                         'use': 'some_value',
                         'key': 'some_value'
                         }
            self._ds = self._ds()
        def delegate_to(self):
            return 'delegate_to'
        def copy(self):
            return self.args

# Generated at 2022-06-23 09:03:01.656205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils import module_docs
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.plugins import get_all_plugin_loaders
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    import ansible.plugins.action as action
    import ansible.utils.sentinel
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_proxy
    import six
    import sys

    # The following code is required to gather the data to be injected into the
    # testing function of the fixture.
    # 1. Create an instance of the AnsibleModule class with the following
    #    arguments:
    #    1.

# Generated at 2022-06-23 09:03:05.685083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.yum_select
    action_obj = ansible.plugins.action.yum_select.ActionModule(
        task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert action_obj is not None

# Generated at 2022-06-23 09:03:13.100986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_source = dict(
        name="roles, include_vars, and vars_files test play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(
            action=dict(
                __ansible_action_plugin_class__='ActionModule',
                use="yum",
                name=["vim", "vim-enhanced"],
                state="installed",
                enablerepo="epel",
            ),
            register="output",
        )],
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=Loader())

# Generated at 2022-06-23 09:03:18.895156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test action module '''
    obj = ActionModule()
    assert VALID_BACKENDS == obj.VALID_BACKENDS
    assert obj.TRANSFERS_FILES == False

# Generated at 2022-06-23 09:03:19.514128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule())

# Generated at 2022-06-23 09:03:22.351269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({},{})
    module.run()

# Generated at 2022-06-23 09:03:32.660725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(connection=None, task_vars=None, loader=None, templar=None, shared_loader_obj=None)
    # test mutually exclusive parameters
    action._task.args = {'use': 'yum4', 'use_backend': 'yum3'}
    action._task.delegate_to = None
    action._task.delegate_facts = None
    result = action.run(tmp=None, task_vars=None)
    assert 'failed' in result
    assert result['failed'] is True
    assert 'msg' in result
    assert result['msg'] == "parameters are mutually exclusive: ('use', 'use_backend')"

    # test fact-less run

# Generated at 2022-06-23 09:03:42.504058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    import ansible.constants
    import ansible.plugins
    import ansible.utils.plugin_docs
    import ansible.utils.display
    import ansible.utils.path
    import ansible.utils.vars
    import ansible.template

    # Initialize for the test
    if os.getenv('ANSIBLE_INVENTORY'):
        ansible.constants.DEFAULT_HOST_LIST = os.getenv('ANSIBLE_INVENTORY')
    local_host = ansible.inventory.host.Host(name="localhost")
    local_host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    ansible.inventory.host.Inventory._hosts_list = [local_host]
    ansible.constants.HOST_KEY_CHECK

# Generated at 2022-06-23 09:03:49.015022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for class ActionModule'''
    action_module = ActionModule()

    assert isinstance(action_module, object)
    assert isinstance(action_module, ActionBase)
    assert 'Transfers_Files' not in action_module.__dict__


# Generated at 2022-06-23 09:03:51.187178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, 'ansible.legacy.yum')

# Generated at 2022-06-23 09:03:59.725079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test case1: yum module throws exception if both 'use' and 'use_backend' is
            used in task args
    """
    am1 = ActionModule()
    task1 = MockTask()
    task1.args = {'use': 'auto', 'use_backend': 'auto'}
    am1._task = task1
    try:
        am1.run()
    except AnsibleActionFail:
        pass
    else:
        assert False

    """
    Test case2: yum module automatically figures out the use_backend if it is
            not specified in task args
    """
    am2 = ActionModule()
    task2 = MockTask()
    task2.args = {}
    am2._task = task2
    am2._execute_module = MockExecuteModule()
    am2._

# Generated at 2022-06-23 09:04:01.606795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod is not None


# Generated at 2022-06-23 09:04:02.222888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 09:04:11.494229
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 09:04:16.587675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule(MockTask(), MockExecutor(), MockShell(), MockTemplar())
    assert isinstance(test_object, ActionModule)

# Mock class for unit testing

# Generated at 2022-06-23 09:04:26.561648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult

    # Constructing a task
    task = Task()
    task._role = None
    task.action = 'yum'
    task.args = {'name': 'vim'}
    play_context = PlayContext()
    task._role = None
    result = TaskResult(host=play_context.remote_addr, task=task)

    # Constructing an ActionModule object
    am = ActionModule(task, play_context, shared_loader_obj=None,
                      task_vars=[{'ansible_facts': {}}])
    result2 = am.run(task_vars={'ansible_facts': {}})


# Generated at 2022-06-23 09:04:29.610256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, object)

# Generated at 2022-06-23 09:04:30.762588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:04:38.906881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation
    action_module = ActionModule(
        task=dict(action=dict(module_name='yum')),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None
    assert action_module.task == dict(action=dict(module_name='yum'))
    assert action_module.connection == dict()
    assert action_module.play_context == dict()

    # check that _shared_loader_obj is used by templar
    action_module.templar._shared_loader_obj = "shared_loader_obj"
    assert action_module.templar._loader == "shared_loader_obj"

# Generated at 2022-06-23 09:04:50.186593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    action_module = ActionModule()
    result = {}
    module = "yum4"
    # Test if the module is not in VALID_BACKENDS

# Generated at 2022-06-23 09:04:51.052511
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert(True)

# Generated at 2022-06-23 09:04:51.593995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:04:55.241616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # module = ActionModule()
    # result = module.run(tmp='', task_vars=None)
    # print(result)
    pass



# Generated at 2022-06-23 09:05:06.546403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible
    # Task that can be called from Playbook
    task = ansible.playbook.task_include.TaskInclude()
    # Connection that can be used to connect to the target host
    connection = ansible.plugins.connection.local.Connection()
    # Clone of module class yum
    yum = ansible.plugins.action.yum.ActionModule(task, connection, ansible._vars)
    # Module arguments
    task.args = dict(effect='install', use='yum')
    # Result of calling run method of class ActionModule
    result = yum.run(None, None)
    # Assert the result type
    assert isinstance(result, dict)
    # Assert the Result

# Generated at 2022-06-23 09:05:19.012541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import yum
    yum_obj = yum.YumBase()
    action_obj = ActionModule(connection=None,
                              runner_config=None,
                              loader=None,
                              templar=None,
                              shared_loader_obj=None)
    action_obj._task = {"args": {}}
    result = action_obj.run(tmp=None, task_vars=None)
    assert result['failed'] == False
    assert result['msg'] == 'yum3 module does not have a run() method'
    action_obj._task = {"args": {"confirm": False, "name": None, "state": "latest"}}
    result = action_obj.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result

# Generated at 2022-06-23 09:05:27.300977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_display = Mock(Display())
    mock_task = Mock(ActionBase)
    mock_task.args = {}
    mock_task.args['use'] = "auto"
    mock_loader_obj = Mock(ActionBase)
    mock_loader_obj.module_loader.has_plugin.return_value = True
    mock_module = Mock(ActionModule)
    mock_module.run.return_value = "yo"
    mock_module.run(tmp=None, task_vars=None)
    assert mock_module.run.return_value == "yo"

# Generated at 2022-06-23 09:05:33.037497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    def mock_display_debug(msg):
        print(msg)

    def mock__execute_module(module_name, module_args, task_vars, wrap_async):
        return {
            'changed': True,
        }

    setattr(ActionModule, '_execute_module', mock__execute_module)
    setattr(Display, 'debug', mock_display_debug)
    module = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # Act
    result = module.run(tmp=None, task_vars=None)

    # Assert
    assert result['changed']

    # Arrange

# Generated at 2022-06-23 09:05:41.934229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # check whether the module throws error on a failure
    action_module_obj=ActionModule()
    task_vars=dict(ansible_pkg_mgr='auto')
    #create a new templar object
    templar_obj=dict()
    from ansible.template import Templar
    templar_obj = Templar(loader=dict(), variables=task_vars)
    action_module_obj._templar = templar_obj
    #create a task object
    from ansible.playbook.task import Task
    task_obj = Task()
    task_obj.async_val = None
    task_obj.notify = []
    task_obj.tags = []
    task_obj.args = dict(use='auto')
    action_module_obj._task = task_obj
    result = action_

# Generated at 2022-06-23 09:05:42.717591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 09:05:52.962816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Mock task
    class MockTask(Task):
        def __init__(self, async_val=True, delegate_to='', delegate_facts='', args=dict()):
            self.async_val = async_val
            self.delegate_to = delegate_to
            self.delegate_facts = delegate_facts
            self.args = args

    # Mock ActionBase._execute_module

# Generated at 2022-06-23 09:05:54.161168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}).TRANSFERS_FILES == False

# Generated at 2022-06-23 09:05:56.056174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 09:05:58.185991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialization
    obj = ActionModule()

    # TODO: Check if object is of required type
    obj.run()


# Generated at 2022-06-23 09:06:00.610949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action is not None

# Generated at 2022-06-23 09:06:01.254127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:06:11.982776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for no 'use_backend' parameter when 'use' is present
    def mock_execute_module(module_name, module_args=None, task_vars=None, wrap_async=None):
        # We don't need the actual logic of the module
        return {}

    action_module = ActionModule()
    action_module._execute_module = mock_execute_module
    action_module._task.args = {'use': 'yum'}
    try:
        action_module.run()
    except AnsibleActionFail as e:
        assert 'mutually exclusive' in str(e)

    # Test for success on the yum (yum3) backend
    action_module._task.args = {'use_backend': 'yum'}

# Generated at 2022-06-23 09:06:14.674576
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass

# Generated at 2022-06-23 09:06:24.681544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader, fragment_loader
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import with_metaclass

    # ActionLoader class constructs metadata for all the action plugins
    if action_loader is None:
        action_loader = ActionModule()

    #  FragmentLoader loads the plugin fragments
    if fragment_loader is None:
        fragment_loader = ActionModule()

    # ActionBase is a metaclass that constructs the ActionModule class
    # with the correct loader and baseclass
    if not hasattr(ActionBase, '_declared_plugins'):
        ActionBase._add_action_plugin(action_loader, fragment_loader, 'yum', 'ActionModule', 'ansible.plugins.action')
        assert 'yum' in ActionBase._declared_plugins

# Generated at 2022-06-23 09:06:34.207484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import sys
    import tempfile
    import unittest
    import yaml

    from ansible import constants as C
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from io import StringIO

    # Required for Ansible 2.8 - Ansible Modules were moved to collections
    sys.modules['ansible.modules.package_manager.yum'] = None


# Generated at 2022-06-23 09:06:38.794116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(legacy_templar=None, module_name=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am is not None

# Generated at 2022-06-23 09:06:49.337032
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # instantiate ActionModule class
    import ansible
    testclass = ActionModule()

    # ------------------------------------------------------------------
    # test for auto backend detection
    # ------------------------------------------------------------------
    # AnsibleCollection() returns a new ActionModule object with
    # a pkg_mgr of yum3
    testclass.run(task_vars={'ansible_facts': {'pkg_mgr': 'yum3'}})

    # AnsibleCollection() returns a new ActionModule object with
    # a pkg_mgr of yum4
    testclass.run(task_vars={'ansible_facts': {'pkg_mgr': 'yum4'}})

    # AnsibleCollection() returns a new ActionModule object with
    # a pkg_mgr of dnf

# Generated at 2022-06-23 09:06:52.231157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 09:06:55.130329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print(module.run(tmp=None, task_vars=None))


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 09:06:57.945315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am
    assert am.TRANSFERS_FILES is False



# Generated at 2022-06-23 09:07:12.694403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    mock_task_vars = {
        'ansible_facts': {
           'pkg_mgr': 'auto'
        }
    }
    mock_task_args = {
        'use': 'auto',
        'state': 'present'
    }

    mock_tmpdir = '/tmp/ansible/action_plugin'
    mock_task = ActionModule.ActionModule(task=mock_task_args)
    mock_task._remove_tmp_path = lambda *args, **kwargs: None

# Generated at 2022-06-23 09:07:13.728479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:07:16.480510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.removed import removed_module

    assert removed_module

# Generated at 2022-06-23 09:07:18.117801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor for class ActionModule
    """
    assert ActionModule()

# Generated at 2022-06-23 09:07:29.208098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #mock AnsibleModule obj
    import ansible.modules.package_manager.yum   #noqa #pylint: disable=C0413
    data = dict(yum=ansible.modules.package_manager.yum.ActionModule(
        dict(use='auto', name='vim', state='present', want_archive=False),
        dict(
            ansible_check_mode=False,
            ansible_facts=dict(pkg_mgr='yum')
        ),
        "login",
    ))
    ansible_facts = data['yum'].run(None, dict())
    assert ansible_facts['ansible_module_name'] == 'yum'
    assert ansible_facts['ansible_facts']['pkg_mgr'] == 'yum'

# Generated at 2022-06-23 09:07:36.795851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test run() method of class ActionModule
    #
    # When use = auto and package_manager = yum3 (yum), the result should be
    # the yum module.
    #
    # Args:
    #   tmp (dict)
    #   task_vars (dict)
    #
    # Returns:
    #   result (dict)

    # create an instance of the class
    action_module = ActionModule()

    # create a dictionary for tmp
    tmp = {}

    # create a dictionary for task_vars
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum3'}}

    # create a dictionary for result
    result = {'ansible_facts': {'pkg_mgr': 'yum3'}}

    # test
    assert action_module

# Generated at 2022-06-23 09:07:46.653999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    from ansible.plugins.task.yum import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.six import PY3

    mod = ActionModule('setup', {'gather_subset': 'all'})
    assert(isinstance(mod, ActionModule))

    if PY3:
        assert(mod.VALID_BACKENDS == frozenset({'yum', 'yum4', 'dnf'}))
    else:
        assert(mod.VALID_BACKENDS == set([u'yum', u'yum4', u'dnf']))


# Generated at 2022-06-23 09:07:58.219823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os

    path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_utils/log_plays.py')
    module_utils_log_plays = imp.load_source('module_utils.log_plays', path)

    path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_utils/six/__init__.py')
    module_utils_six = imp.load_source('module_utils.six', path)

    path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_utils/urls.py')
    module_utils_urls = imp.load_source('module_utils.urls', path)


# Generated at 2022-06-23 09:08:01.402079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    action = action_loader.get('yum', class_only=True)
    action._connection = object()

    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 09:08:07.686259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.facts.collector import set_file_content
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.plugins.action.yum import ActionModule
    from ansible.utils.display import Display
    from ansible.utils.display import DisplayOptions
    from ansible.vars.manager import VariableManager
    from io import StringIO

    # Setup
    display_options = DisplayOptions()
    display_options.verbosity = 5
    display = Display(options=display_options)
    temp_dir = "/tmp/ansible_test"

# Generated at 2022-06-23 09:08:08.710053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "ActionModule" == ActionModule.__name__

# Generated at 2022-06-23 09:08:17.957180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['pkg_mgr'] = 'yum'
    task_args = dict()
    task_args['use_backend'] = 'auto'
    action_module._task = MockTask()
    action_module._task.args = task_args
    action_module._task.async_val = False
    action_module._shared_loader_obj = MockSharedLoader()
    action_module._shared_loader_obj.module_loader = MockModuleLoader()
    action_module._shared_loader_obj.module_loader.has_plugin = MockHasPlugin()
    action_module._execute_module = MockExecuteModule()
    task_vars

# Generated at 2022-06-23 09:08:22.284825
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 09:08:25.388321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(action)

# Unit tests of class ActionModule

# Generated at 2022-06-23 09:08:33.256450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    from ansible.executor.task_executor import TaskExecutor
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    class Task(mock.MagicMock):
        async_val = Sentinel
        args = dict(
            use='yum3',
        )
        _shared_loader_obj = mock.MagicMock()
        _shared_loader_obj.module_loader = mock.MagicMock()

    display = Display()
    task_executor = TaskExecutor(display=display, task=Task)
    a = ActionModule(task_executor=task_executor)
    assert a

# Generated at 2022-06-23 09:08:45.722306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    methods = [k for k, v in globals().items() if isinstance(v, types.FunctionType) and k.startswith('test_')]
    assert 'test_ActionModule_run' in methods

    # test
    module = ActionModule(1, None, None, None, None)
    module._task.args.update({'use': 'auto'})
    module._execute_module = lambda *a, **kw: {}
    result = module.run(None, None)
    assert 'ansible_facts' not in result

    # test
    module._task.args.update({'use': 'dnf'})
    module._execute_module = lambda *a, **kw: {'failed': True}
    result = module.run(None, None)
    assert result['failed']

# Generated at 2022-06-23 09:08:57.601138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    from ansible.inventory.host import Host
    from ansible.playbook.block import Block


# Generated at 2022-06-23 09:08:59.960958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t._supports_check_mode is True
    assert t._supports_async is True

# Generated at 2022-06-23 09:09:00.416065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:09:07.470886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.set_shell_type('csh')
    module.set_loader(DictDataLoader({}))
    module.set_connection_type('ssh')

    action = module.run(tmp='/tmp/ansible')
    assert action == {'msg': {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend."},
                      'failed': True}

    action = module.run(tmp='/tmp/ansible', task_vars={'ansible_pkg_mgr': 'yum'})
    assert action == {'ansible_facts': {'pkg_mgr': 'yum'}, 'msg': None, 'failed': False}


# Generated at 2022-06-23 09:09:08.583209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 09:09:10.034897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {})


# Generated at 2022-06-23 09:09:14.336638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=dict(args=dict(use=dict(), use_backend=dict())))
    assert actionModule.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))



# Generated at 2022-06-23 09:09:24.091440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    module = ActionModule()
    module._shared_loader_obj = DataLoader()
    display = Display()
    module._supports_check_mode = True
    module._supports_async = True
    templar = None
    result = {'failed': True, 'msg': "Could not find a yum module backend for %s." % templar}
    module_args = {'name': 'pipejury'}
    inventory = InventoryManager(loader=module._shared_loader_obj, sources='')

# Generated at 2022-06-23 09:09:35.843939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit-test for testing method run of class ActionModule """

    import sys
    from mock import Mock, MagicMock, patch
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action.yum import ActionModule

    sys.modules['ansible'] = MagicMock()
    sys.modules['ansible.module_utils.six'] = Mock()
    sys.modules['ansible.module_utils.six.StringIO'] = StringIO
    sys.modules['ansible.module_utils.facts.collector'] = MagicMock()
    sys.modules['ansible.module_utils.facts.collector'].FactsCollector = MagicMock()

    mock_module_args = dict(
        state='latest',
    )

    mock_task = Mock()
    mock_task.args = mock

# Generated at 2022-06-23 09:09:45.151744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule for coverage
    '''
    #We create an instance of the class ActionModule to test
    action_mod = ActionModule()

    # We create two dictionaries, one containing args and action_plugin_args and the other containing ansible_facts
    args = {"use": "yum4"}
    facts = {"ansible_facts": {"pkg_mgr": "auto"}}

    # We create a TaskExecutionResult to test the method run with
    results = AnsibleActionResult(action_mod, "test_hostname", "yum", args, "test_task", "test_task_copy", ansible_facts=facts)
    
    # Call to method run to test it
    action_mod.run(tmp=None, task_vars=results)

# Generated at 2022-06-23 09:09:55.481404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Constructor of class ActionModule """
    module = ActionModule(
        task=dict(action=dict(module='yum', args=dict(name='httpd', state='present', use_backend='yum3'))),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert module is not None

# Generated at 2022-06-23 09:09:58.749511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

    # test __str__ method return value
    assert isinstance(a.__str__(), str)

# Generated at 2022-06-23 09:10:10.614610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up
    display_set = Display()
    display_set._verbosity = 10
    display.verbosity = display_set._verbosity

    module_backend_options = [
        "dnf",
        "yum4",
        "yum",
        "auto",
        "auto_1",
        "auto_2",
        "auto_3",
        "auto_4",
        "auto_5",
    ]
    task_args = {}
    task_vars = {}

# Generated at 2022-06-23 09:10:13.330643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    assert action_module.run()

# Generated at 2022-06-23 09:10:13.955747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:10:15.312565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Provided sample code of an author for testing purposes.
    pass

# Generated at 2022-06-23 09:10:16.270984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
