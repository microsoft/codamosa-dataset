

# Generated at 2022-06-23 09:00:25.860039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup object for run method
    host = '127.0.0.1'
    user = 'root'
    connection = 'ssh'
    runner_cache = dict(host_record=host,)
    transport = 'ssh'
    become = False
    become_method = 'sudo'
    become_user = 'root'
    become_pass = None
    check = 'check'
    args = dict(update_cache=False, name='ansible', state='present', list=True, security=True)
    _executor = 'async'
    tqm = 'tqm'
    _async_workers = 2
    _async_notify = ['me', ]
    _async_poll_interval = 1
    display = Display()
    fake_task = 'fake_task'

# Generated at 2022-06-23 09:00:36.801951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    from ansible.plugins.loader import find_plugin
    import os

    class Host:
        name = "localhost"

    class TaskResult:
        def __init__(self, host, result):
            self._host = host
            self._result = result

        def get_host(self):
            return self._host


# Generated at 2022-06-23 09:00:37.605628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 09:00:45.483123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(
        task=dict(args=dict(name="yum", state="present", use_backend="yum"), async_val=False),
        connection=dict(module_name="yum", _shell=dict(tmpdir="")),
        play_context=dict(become=False),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(module_loader=dict())
    )
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-23 09:00:55.402201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock configuration and set config.connection to 'local'
    mock_config = MockConfig()
    mock_config.connection = 'local'

    # Create a mock configuration
    mock_loader = MockLoader()

    # Create a mock shared plugin loader
    mock_shared_plugin_loader = MockSharedPluginLoader()

    # Create a mock task
    mock_task = Mock()
    mock_task.action = 'yum'
    mock_task.args = dict()
    mock_task.async_val = 0
    mock_task.delegate_to = None
    mock_task.delegate_facts = None

    # Create a mock connection
    mock_connection = Mock()
    mock_connection._play_context = mock_config
    mock_connection._shell = Mock()

# Generated at 2022-06-23 09:00:58.413848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode is True
    assert module._supports_async is True

# Generated at 2022-06-23 09:01:10.139520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m_task = MockTask()
    m_task.async_val = False
    m_task.delegate_to = 'localhost'
    m_task.delegate_facts = True
    m_templar = None
    m_loader = MockLoader()

    cls = ActionModule('', m_task, '', '', {}, m_templar, m_loader)

    assert cls._supports_check_mode is True
    assert cls._supports_async is True
    assert cls._loader is m_loader
    assert cls._templar is m_templar
    assert cls._shared_loader_obj is m_loader
    assert cls._task is m_task
    assert cls._connection is None
    assert cls._task_vars is None


# Mock class for

# Generated at 2022-06-23 09:01:17.438067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Validate test provides valid backend.
    facts = {'ansible_pkg_mgr': 'auto'}
    for backend in VALID_BACKENDS:
        facts['ansible_pkg_mgr'] = backend
        module = ActionModule(None,
                              {"ansible_facts": facts, "use_backend": "auto", "args": {"name": "httpd"}},
                              None,
                              None,
                              {"task_vars": {}})
        assert module._task.args["use_backend"] == backend
        assert module._task.args["use"] == backend

    # Validate criteria for success of run

# Generated at 2022-06-23 09:01:18.043730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 09:01:20.087523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES == False
    return module


# Generated at 2022-06-23 09:01:30.321994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from collections import namedtuple, OrderedDict
    import re


# Generated at 2022-06-23 09:01:35.671971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test args argument
    args = dict(
        install='foo',
        repositories='some_yum_repo',
        state='some_yum_state',
        use='some_use',
        use_backend='some_use_backend',
    )
    target = dict(
        name='foo',
    )
    module = ActionModule(load_name='foo', params=args, task=target)
    assert module.run()['failed'] == False

# Generated at 2022-06-23 09:01:37.091393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 09:01:38.409660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-23 09:01:41.261817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing with package, yum
    module = ActionModule()
    assert module.VALID_BACKENDS == ('yum', 'yum4', 'dnf')



# Generated at 2022-06-23 09:01:46.003961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule(
            {'name': "", "args": {}, '_ansible_check_mode': True, '_ansible_no_log': True, 'async': 0}, {})
        assert action_module
    except:
        assert False, 'ActionModule class constructor failed'


# Generated at 2022-06-23 09:01:54.946414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    task = Task()
    task.delegate_to = 'test'
    task.rollback = False
    task.args = {'name': ['cowsay'], 'state': 'latest'}

    class MockLoaderObj:
        def module_loader(self, *args):
            class MockModuleLoader:
                def has_plugin(self, *args):
                    return True
            return MockModuleLoader()
    class MockModule:
        def __init__(self, *args, **kwargs):
            self._task = task,
            self._task_vars = task_vars
            self._loader = MockLoaderObj()

        def run(self, *args, **kwargs):
            return {"changed": True}

    action = ActionModule()
    action._task = task

# Generated at 2022-06-23 09:01:55.995417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    print(module)

# Generated at 2022-06-23 09:01:59.040375
# Unit test for constructor of class ActionModule
def test_ActionModule():
  a = ActionModule()
  print(a)

# Generated at 2022-06-23 09:01:59.582532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 09:02:09.329571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    def tearDown():
        '''
        Clean up.
        '''

        # Remove the temporary directory
        shutil.rmtree(tmpdir)

    # Create a mock action
    mock_action = Mock()

    # Create a mock task
    mock_task = Mock()

    # Set autospec to True
    mock_task.configure_mock(autospec=True)

    # Create a mock module
    mock_module = Mock()

    # Set autospec to True
    mock_module.configure_mock(autospec=True)

    # Set value of return_value to [{}]

# Generated at 2022-06-23 09:02:09.934112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 09:02:16.526203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method _run of class ActionModule.
    """
    # Test 1 - Check if a result is returned
    yum_action_module = ActionModule()
    yum_action_module._task.args = dict(use_backend="yum")
    yum_action_module._task.delegate_to = "localhost"
    yum_action_module._task.delegate_facts = True
    yum_action_module._task.async_val = True
    result = yum_action_module.run()
    assert result

# Generated at 2022-06-23 09:02:19.280255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() == "I am not a real unit test"

# Generated at 2022-06-23 09:02:30.435628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-23 09:02:32.888783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 09:02:40.626933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action

    # Create an instance of the action module

# Generated at 2022-06-23 09:02:42.953204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action as action
    from ansible.plugins.action.yum import ActionModule
    action_module = ActionModule(None, None)
    assert action_module == action.ActionModule #TODO add additional unit test logic


# Generated at 2022-06-23 09:02:52.200588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import PY3
    import ansible.plugins.action.yum

    ansible.plugins.action.yum.Display = Display
    sentinel = Sentinel()
    sentinel.connection = sentinel

    module = ansible.plugins.action.yum.ActionModule(sentinel, sentinel)

# Generated at 2022-06-23 09:02:59.167955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule(
        task=dict(action=dict(host=None, port=None, connection='smart', use_backend='auto')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_plugin



# Generated at 2022-06-23 09:02:59.586825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:03:03.310303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test run method of class ActionModule.'''
    pass

# Generated at 2022-06-23 09:03:09.327389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task_vars = dict()
    mock_task_vars['pkg_mgr'] = "yum"
    action_plugin = ActionModule(dict(), mock_task_vars)
    mock_tmp = "/ansible/tmp"
    assert action_plugin.run(tmp=mock_tmp, task_vars=mock_task_vars) == {'ansible_facts': {'pkg_mgr': u'yum'}}

# Generated at 2022-06-23 09:03:21.811424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test fixture
    import ansible.plugins.action
    from ansible.plugins.action.yum import ActionModule
    from ansible.errors import AnsibleActionFail
    from ansible.utils.display import Display
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.module_utils._text import to_bytes

    display = Display()
    module_vars = dict(yum='yum', pkgmgr='yum')
    task_vars = dict(ansible_pkg_mgr='yum', ansible_facts=module_vars)

    # create instance of class ActionModule
    # return instance of class ActionModule

# Generated at 2022-06-23 09:03:32.368901
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Dict for creating the module object
    argument_spec = dict()

    # Create a new instance of AnsibleModule
    module = AnsibleModule(argument_spec=argument_spec)

    # creating a new action plugin object
    action_plugin_obj = ActionModule(
        task=module.params,
        connection=module.params,
        play_context=module.params,
        loader=module.params,
        templar=module.params,
        shared_loader_obj=module.params)

    # Creating a Ansible Action Fail object
    action_fail_obj = AnsibleActionFail()

    # Creating a object for Ansible Display Class
    display_obj = Display()

    # Create static information
    tmp = '/tmp'
    task_vars = dict()
    task_vars['ansible_facts'] = dict()

# Generated at 2022-06-23 09:03:39.453826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test ActionModule::run')
    display = Display()
    display.verbosity = 1
    module = ActionModule()
    # if ansible_pkg_mgr is either `yum` or `dnf`, it will fall back to the
    # use_backend parameter if present.

# Generated at 2022-06-23 09:03:42.808338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    module = "yum3"
    try:
        assert(action_module._execute_module(module, None, test=True) == module)
    except:
        raise Exception("ActionModule._execute_module() has not passed a unit test")

# Generated at 2022-06-23 09:03:56.011925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json  # noqa
    import os.path  # noqa
    import tempfile  # noqa
    import shutil  # noqa
    import sys  # noqa

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display

        display = Display()

    from ansible.module_utils._text import to_bytes  # noqa
    from ansible.plugins.action import ActionBase  # noqa
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText  # noqa

    display.verbosity = 4

    # noinspection PyAttributeOutsideInit

# Generated at 2022-06-23 09:04:07.945990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes

    module_name = 'yum'

    def _execute_module(module_name=None, module_args=None, task_vars=None, wrap_async=None):
        '''
        Execute moduele with given args
        '''
        module_args = dict()
        return dict({"test": "test"})

    def _templar(template):
        '''
        Return templar
        '''
        return None

    def _remove_tmp_path(path):
        '''
        Remove tmp dir
        '''
        pass

    def _display_debug(module):
        '''
        Display debug
        '''
        pass


# Generated at 2022-06-23 09:04:10.838654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-23 09:04:18.032710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    (param1, param2, param3, param4) = (None, {}, {}, {})
    module = ActionModule(param1, param2, param3, param4)
    # test_case_1
    def test_case_1():
        print("Running test case 1")
        module._execute_module = MagicMock()
        module._execute_module.return_value = {'failed': False}
        module._shared_loader_obj = MagicMock()
        module._task = MagicMock()
        module._task.args = {'use_backend': 'auto'}
        module._task.delegate_to = None
        module._task.delegate_facts = False
        module.run()
        #assert module._execute_module.has_been_called()

    # test_case_2

# Generated at 2022-06-23 09:04:20.338747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    # test for attributes of object
    assert am.TRANSFERS_FILES == False
    assert isinstance(am._supports_check_mode, bool)
    assert isinstance(am._supports_async, bool)
    # test for return of method
    assert isinstance(am._execute_module, object)

# Generated at 2022-06-23 09:04:21.721684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    assert hasattr(module, 'run')

# Generated at 2022-06-23 09:04:25.581153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(),
        templar=dict(), shared_loader_obj=dict())
    assert module is not None

# Generated at 2022-06-23 09:04:33.931372
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task = {"module_name": "yum",
            "args": {"use_backend": "yum", "module_args": {"name": "package-name"}}}
    task_vars = {"hostvars": {"hostname": {"ansible_facts": {"pkg_mgr": "yum"}}}}

    result = {}
    result.update({"failed": False, "changed": True, "msg": "No package matching 'package-name' is available"})

    action = ActionModule()

    assert action.run(task, task_vars) == result

# Generated at 2022-06-23 09:04:45.394417
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ansible_facts = {'ansible_pkg_mgr': 'auto'}
    hostvars = {'test_host': {'ansible_facts': {'pkg_mgr': 'auto'}}}
    templar = FakeTemplar(ansible_facts, hostvars)

    am = ActionModule(module_args=dict(use='auto'), templar=templar)
    am.run(task_vars=dict(hostvars=hostvars))

    templar = FakeTemplar(ansible_facts, hostvars)
    am = ActionModule(module_args=dict(use='yum3'), templar=templar)
    am.run(task_vars=dict(hostvars=hostvars))


# Generated at 2022-06-23 09:04:51.092031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    # Create test instance
    ansible_module_instance = ActionModule()
    # Check type of instance
    assert isinstance(ansible_module_instance, ActionModule)
    # Check subtype of instance
    assert isinstance(ansible_module_instance, ActionBase)
    # Check the value of the instance
    assert ansible_module_instance.get_name() == 'yum'
    # Check if instance is a valid action plugin
    assert ansible_module_instance.verify_file('')

# Generated at 2022-06-23 09:05:00.673883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    import json
    import textwrap

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import call, patch
    from ansible.errors import AnsibleActionFail
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display

    def _flush_and_read(handle):
        handle.flush()
        return handle.read()

    def _write_and_close(handle, data):
        # Needed when the context manager exits
        handle.write(data.encode("utf-8"))
        handle.close()

    class YumModule(object):

        def __init__(self, module_name):
            self.module_name = module_name


# Generated at 2022-06-23 09:05:10.526554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dnf_module = 'ansible.legacy.dnf'
    yum_module = 'ansible.legacy.yum'
    action_module = ActionModule()
    action_module._task.args = {'use': 'dnf'}
    action_module.run()
    assert action_module._execute_module.call_args[0][0] == 'ansible.legacy.dnf'
    assert action_module._remove_tmp_path.call_count == 2
    action_module.run()
    assert action_module._execute_module.call_args[0][0] == 'ansible.legacy.dnf'
    assert action_module._remove_tmp_path.call_count == 4
    action_module._task.args = {'use': 'yum'}

# Generated at 2022-06-23 09:05:11.131258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:05:13.370363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert am is not None

# Generated at 2022-06-23 09:05:22.679078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestConnection(object):
        def __init__(self, tmpdir):
            self._shell = dict(tmpdir=tmpdir)

    class TestDisplay(object):
        verbosity = 2

    class TestTask(object):
        async_val = True
        delegate_to = 'remote'
        delegate_facts = False
        args = dict(use_backend='auto')

    class TestTaskVars(object):
        i_am_a_dict = 'i_am_a_dict'

    class TestLoader(object):
        def get_basedir(self, *args, **kwargs):
            return 'basedir'

        def has_plugin(self, module_name):
            if module_name == "ansible.legacy.setup":
                return True

            return False


# Generated at 2022-06-23 09:05:26.604016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #ActionModule.run not fully tested because it's mostly a glue module
    class ActionBaseFake:
        def run(self, tmp=None, task_vars=None):
            return self
    module_action_fake = ActionBaseFake()
    module_action_fake.task_vars = {'ansible_facts': {'pkg_mgr': 'dnf'}}
    module_action_fake.task_vars['ansible_facts']['pkg_mgr'] = 'yum'
    module_action_fake.task_vars['ansible_facts']['pkg_mgr'] = 'yum'
    module_action_fake.task_vars['ansible_facts']['pkg_mgr'] = 'yum'

# Generated at 2022-06-23 09:05:27.728946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for the method run of class ActionModule
    pass

# Generated at 2022-06-23 09:05:39.729989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum3'}}
    loader, cls, datastore = None, None, dict()
    action_module = ActionModule(loader=loader, templar=cls, shared_loader_obj=loader, action_base=cls)
    package_args = {'name': ['kernel'], 'state': 'present'}
    action_module._task = cls()
    action_module._task.args = package_args
    action_module._task_vars = task_vars
    action_module._connection = cls()
    action_module._templar = cls(loader=loader, variables=task_vars)
    action_module._shared_loader_obj = loader
    result = action_module.run()

# Generated at 2022-06-23 09:05:47.705263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(args=dict()), connection=dict(play_context=dict(check_mode=False)), loader=None, templar=None, shared_loader_obj=None)
    assert action.run() == {'failed': True, 'msg': "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})", 'changed': False}

# Generated at 2022-06-23 09:05:55.924491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    import tempfile
    import ansible.utils.display

    from ansible.errors import AnsibleActionFail

    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible import context
    from ansible.utils.path import unfrackpath

    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes

    from ansible_collections.ansible.legacy.plugins.action.yum import ActionModule

    context._init_global_context(['ansible-playbook'])

    display = Display()

    class AnsibleActionFail_mock(AnsibleActionFail):
        pass

    class ActionBase_mock(ActionBase):
        pass

   

# Generated at 2022-06-23 09:05:58.696930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule(dict(), remote_user='root', task_vars=dict(ansible_python_interpreter='/usr/bin/python3.6', ansible_pkg_mgr='yum4')).run()

# Generated at 2022-06-23 09:06:10.776540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.plugins import action_loader

    class FakeActionModule:

        def run(self):
            return 123

    class FakeActionBase:

        def run(self):
            return 'something'

        @property
        def _loader(self):
            return action_loader

        def _execute_module(self):
            return 123

    class FakeModuleLoader:

        def has_plugin(self, mod_name):
            return mod_name == 'ansible.legacy.yum'

        def get(self, mod_name, *args, **kwargs):
            return FakeActionModule()

    class FakeModuleLoaderNoPlugin:

        def has_plugin(self, mod_name):
            return mod_name == 'ansible.legacy.yum'


# Generated at 2022-06-23 09:06:12.468300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(args=dict(name='apache', state='present', use_backend='yum')),
        connection=None,
    )
    assert module._execute_module == module.run

# Generated at 2022-06-23 09:06:17.999002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule({}, {}, False, False, '/home/cat/packerbuild/ansible', True, None)
    assert module

# Test if AnsibleActionFail is raised when user provides both use and use_backend arguments

# Generated at 2022-06-23 09:06:22.418624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with undefined variable
    module_args = dict(
        package='yum3',
        state='present',
    )
    module = ActionModule(
        dict(
            _task=dict(),
            _connection=dict(),
            _play_context=dict(),
            _loader=dict(),
            _templar=dict(),
            _shared_loader_obj=dict(),
            _task_vars=dict(),
            _ansible_version=dict(),
        ),
        module_args,
    )
    module.run(tmp=None, task_vars=None)

    # Test with defined variable
    module_args = dict(
        package='yum3',
        state='present',
    )

# Generated at 2022-06-23 09:06:33.315873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    M = type('TestModule', (object,), {'run': ActionModule.run})
    m = M()

    result = m.run(tmp=None, task_vars={'ansible_facts': {'pkg_mgr': 'yum4'}})
    assert result['module_name'] == 'ansible.legacy.dnf'

    t = type('Task', (object,), {'args': {'use': 'yum'}})
    m2 = M()
    m2._task = t
    result = m2.run(tmp=None, task_vars={'ansible_facts': {'pkg_mgr': 'dnf'}})
    assert result['module_name'] == 'ansible.legacy.yum'


# Generated at 2022-06-23 09:06:44.155866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a simple task
    task = dict(
        action=dict(
            module='yum',
            args=dict(name='ansible', state='present')
        ),
        register='shell_out'
    )

    # create a simple task with delegate_to
    task_with_delegate = dict(
        action=dict(
            module='yum',
            args=dict(name='ansible', state='present')
        ),
        register='shell_out',
        delegate_to='localhost'
    )

    # create a simple task with delegate_to and use_backend

# Generated at 2022-06-23 09:06:45.341515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)


# Generated at 2022-06-23 09:06:47.153185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-23 09:06:48.010885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    return am.run()

# Generated at 2022-06-23 09:06:54.653103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test

    # mock task_vars
    task_vars = dict()

    # mock tmp
    tmp = "tmp"

    # mock self.connection
    self.connection = dict()

    # mock self.connection._shell
    self.connection._shell = dict()

    # mock tmpdir
    self.connection._shell.tmpdir = 'tmpdir'

    # mock _remove_tmp_path
    def _remove_tmp_path(self, tmpdir):
        ''' mocked method '''
        return None
    self._remove_tmp_path = _remove_tmp_path

    # mock _execute_module
    def _execute_module(self, *args, **kwargs):
        ''' mocked method '''
        return dict(failed=False)
    self._execute_module = _execute_module

    #

# Generated at 2022-06-23 09:06:58.798202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test must be run as root
    if os.geteuid() != 0:
        print("Unit tests must be run as root")
        sys.exit(1)
    # No unit test for now


# Generated at 2022-06-23 09:06:59.945253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.TRANSFERS_FILES == False

# Generated at 2022-06-23 09:07:09.084429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a 'mock' for the task that this action plugin is supposed to execute
    test_task = MockYumTask()

    # The "mock" task object needs to have a value for the delegate_to argument
    # so that the method _execute_module() returns something
    test_task.delegate_to = 'localhost'

    # Create a 'mock' for the ActionBase class
    test_action = MockActionBase()

    # Create a 'mock' for the Display class - this way we can verify that
    # the method vvvv() has been called.
    display = MockDisplay()

    test_action._display = display
    test_action._task = test_task

    # Create a 'mock' for the AnsibleModule class
    test_ansible_module = MockAnsibleModule()

    # Set the '

# Generated at 2022-06-23 09:07:19.428077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit tests for method run
    '''

    action_module = ActionModule()
    action_module._task = type('namespace', (object,), {
        'args' : {
            'use' : 'yum',
            }
        })
    action_module._shared_loader_obj = None

    # Return values to mock module functions
    mock_execute_module =  {'failed': True, 'msg': "missing required arguments: pkg..."}

# Generated at 2022-06-23 09:07:21.618525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule()
    assert act._supports_check_mode is True
    assert act._supports_async is True

# Generated at 2022-06-23 09:07:25.729411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.yum

    action_mod = ansible.plugins.action.yum.ActionModule(None, {}, {}, None, None)

    assert action_mod is not None, "Unable to create ActionModule instance"

# Generated at 2022-06-23 09:07:34.903091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the ActionModule class for the run method
    # Run the plugin with blank arguments
    action = ActionModule()
    assert action.run(task_vars=dict(ansible_pkg_mgr='yum'))['ansible_facts']['pkg_mgr'] == 'yum'

    # Run the plugin with a use_backend argument set to yum4
    action = ActionModule(
        task=dict(args=dict(use_backend='yum4')),
        connection=dict(module='yum'),
        task_vars=dict(ansible_pkg_mgr='yum3'))
    assert action.run(task_vars=dict(ansible_pkg_mgr='yum'))['ansible_facts']['pkg_mgr'] == 'yum'

    # Run the plugin

# Generated at 2022-06-23 09:07:38.289563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict())
    assert module._supports_check_mode == True
    assert module._supports_async == True

# Generated at 2022-06-23 09:07:38.882119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 09:07:39.874837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action

# Generated at 2022-06-23 09:07:50.345251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.context_objects import Context
    from ansible.module_utils.facts.system.distribution import Distribution
    import json

    # Create a fake loader
    fake_loader = module_loader
    fake_loader.get_all_plugin_loaders = lambda: (object(),)

    # Create a fake display
    fake_display = Display()

    # Create fake variable manager, inventory manager, and distribution.
    fake_variable_manager = VariableManager()
    fake_inventory_manager = InventoryManager(loader=fake_loader, sources='localhost')
    fake_distribution = Distribution()

    # Create a fake context
   

# Generated at 2022-06-23 09:07:53.808515
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule()

    assert action.TRANSFERS_FILES == False
    assert action._supports_check_mode
    assert action._supports_async

# Generated at 2022-06-23 09:08:03.589858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = dict(
        use = "yum4",
        name = "katello-agent",
        state = "absent",
    )

# Generated at 2022-06-23 09:08:15.215624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = Host("localhost")
    host.facts = dict(ansible_pkg_mgr="yum")
    ansible = Ansible(host)
    ansible.vars = dict(use_backend='yum4', use='yum3')
    task = Task(dict(args=ansible.vars))
    task_copy = task.copy()
    task_copy.args.pop('use_backend')
    task_copy.args.pop('use')
    am = ActionModule(task, host, ansible=ansible)
    assert am.run() == {
        'failed': True,
        'msg': ("parameters are mutually exclusive: ('use', 'use_backend')"),
    }

    host = Host("localhost")
    host.facts = dict(ansible_pkg_mgr="yum")

# Generated at 2022-06-23 09:08:20.111210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils
    ansible.utils.plugins.ActionModule = ActionModule
    test_module = ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    return test_module

# Generated at 2022-06-23 09:08:27.677531
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 09:08:38.901317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.context import CLIARGS

    # set up test variables
    my_vars = dict(
        ansible_pkg_mgr="auto",
        hostvars=dict(bogus=dict(ansible_facts=dict(pkg_mgr='yum')))
    )
    my_args = dict(use="yum")

    my_args2 = dict(use="auto")
    my_args3 = dict(use="yum3")

    # set up test class

# Generated at 2022-06-23 09:08:47.058870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule

    # Initialization: test_module_action_run
    task_args = dict(use='yum')

    # Run code to be tested
    test_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result_args = test_obj._execute_module(module_name='ansible.legacy.yum', module_args=task_args)

    # Assertion
    assert result_args['invocation']['module_name'] == 'yum'
    assert result_args['invocation']['module_args'] == dict(use='yum')
    assert result_args['invocation']['module_style'] == 'old'

# Generated at 2022-06-23 09:08:48.297251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 09:08:51.227317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == "ActionModule"
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-23 09:08:53.736667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule.run.__name__ == 'run'

# Generated at 2022-06-23 09:08:57.996622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(use_backend="yum")),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    module.run(tmp=None, task_vars=dict())

# Generated at 2022-06-23 09:09:04.339712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None


# Generated at 2022-06-23 09:09:16.964464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display = Display()
    display.verbosity = 4
    display.display("[DEPRECATION WARNING]: The yum module is deprecated, use the dnf module instead", color='blue')

    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import merge_hash

    # mock task
    task = {}
    task['async'] = None
    task['notify'] = []
    task['delegate_to'] = None
    task['delegate_facts'] = None
    task['become'] = None
    task['become_user'] = None
    task["connection"] = "ssh"


# Generated at 2022-06-23 09:09:22.263222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = '/var/tmp'
    task_vars = {
        'ansible_facts': {'pkg_mgr':  "yum4"}
    }
    task = {}
    task['data'] = {}
    task['data']['args'] = {'use': 'yum4'}
    result = ActionModule.run(tmp, task_vars, task)

    assert result['changed'] == True

# Generated at 2022-06-23 09:09:22.786558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:09:28.941434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializes parameters for constructor
    my_ActionBase = {'args': dict(use='auto'),
                     'delegate_to': None,
                     'async_val': '',
                     'delegate_facts': None}

    # Mocks class Display
    Display.debug = Mock(return_value="Debug")
    Display.vvvv = Mock(return_value="vvvv")

    # Mocks class ActionBase
    ActionBase._execute_module = Mock(return_value="Backend module execution")
    ActionBase._remove_tmp_path = Mock(return_value=None)
    ActionBase._shared_loader_obj.module_loader.has_plugin = Mock(return_value=True)
    ActionBase._templar.template = Mock(return_value="auto")

    # Initializes class ActionModule
    my_yum_

# Generated at 2022-06-23 09:09:30.477227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    assert False

# Generated at 2022-06-23 09:09:31.104398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:09:39.462740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test the method run of class ActionModule.

    The method run is the entry point for Ansible. For a unit test we need
    to mock this method for the coverage report and catching errors of the
    method.
    Bug https://github.com/ansible/ansible/issues/58072
    """
    assert_msg = 'ActionModule.run should return a result as dictionary'
    # Create a instance of class ActionModule
    action = ActionModule()
    # Call the method run of class ActionModule
    run = action.run()
    assert isinstance(run, dict), assert_msg

# Generated at 2022-06-23 09:09:41.445594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='yum', use='yum3'))
    action = ActionModule(task, {})
    assert action

# Generated at 2022-06-23 09:09:45.640216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    import ansible.plugins.action.yum

    ActionModule.run(None, None)

    assert ansible.plugins.action.yum.VALID_BACKENDS

# Generated at 2022-06-23 09:09:47.605469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(('ansible.legacy.yum', 'playbook', '/etc/ansible/ansible.cfg', {}))

# Generated at 2022-06-23 09:09:48.923528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

# Generated at 2022-06-23 09:09:58.391674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    meta = {"hello": "world"}
    task = {"hello": "world"}
    shared_loader_obj = {"hello": "world"}
    connection = {"hello": "world"}
    play_context = {"hello": "world"}

    action_module = ActionModule(
        task=task,
        connection=connection,
        play_context=play_context,
        loader=None,
        templar=None,
        shared_loader_obj=shared_loader_obj)

    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-23 09:10:10.408727
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Task:
        async_val = False
        delegate_to = False
        delegate_facts = False

        def __init__(self, args):
            self.args = args

    class Connection:
        def __init__(self, shell):
            self._shell = shell

    class Shell:
        tmpdir = "/tmp"

        def __init__(self):
            self.tmpdir = "/tmp"

    class PlayContext:
        check_mode = False
        network_os = "linux"

    class Display:
        verbosity = 2

        def vvvv(self, msg, host=None):
            print("vvvv: " + msg)

        def debug(self, msg, host=None):
            print("debug: " + msg)


# Generated at 2022-06-23 09:10:15.452910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection=None, task_vars=None, loader=None, templar=None, shared_loader_obj=None)
    assert module._supports_check_mode
    assert module._supports_async
    assert module.TRANSFERS_FILES == False