

# Generated at 2022-06-17 10:18:03.371964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:18:04.372350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 10:18:06.959679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:18:09.510043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:18:09.885276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:18:19.264991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a task
    task = {
        'args': {
            'use': 'yum'
        }
    }

    # Set the task to the instance of ActionModule
    action_module._task = task

    # Create a result
    result = {
        'failed': False,
        'msg': ''
    }

    # Set the result to the instance of ActionModule
    action_module._result = result

    # Create a task_vars
    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum'
        }
    }

    # Create a tmp
    tmp = '/tmp'

    # Call the method run of class ActionModule

# Generated at 2022-06-17 10:18:21.710420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:18:33.678207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock facts collector
    facts_collector = MockFactsCollector()

    # Create a mock pkg_mgr fact collector
    pkg_mgr_fact_collector = MockPkgMgrFactCollector()

# Generated at 2022-06-17 10:18:36.940220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:18:48.412695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid backend
    module = ActionModule()
    module._task.args = {'use_backend': 'yum'}
    module._task.delegate_to = 'localhost'
    module._task.delegate_facts = True
    module._shared_loader_obj.module_loader.has_plugin = lambda x: True
    module._execute_module = lambda x, y, z: {'ansible_facts': {'pkg_mgr': 'yum'}}
    result = module.run(task_vars={'hostvars': {'localhost': {'ansible_facts': {'pkg_mgr': 'yum'}}}})
    assert result['ansible_facts'] == {'pkg_mgr': 'yum'}

    # Test with an invalid backend
    module = ActionModule()
   

# Generated at 2022-06-17 10:19:05.806702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid module
    module = ActionModule(
        task=dict(
            args=dict(
                use='yum',
            ),
        ),
    )
    assert module.run()['module_name'] == 'ansible.legacy.yum'

    # Test with invalid module
    module = ActionModule(
        task=dict(
            args=dict(
                use='invalid',
            ),
        ),
    )
    assert module.run()['failed']

    # Test with valid module
    module = ActionModule(
        task=dict(
            args=dict(
                use='yum4',
            ),
        ),
    )
    assert module.run()['module_name'] == 'ansible.legacy.dnf'

    # Test with invalid module

# Generated at 2022-06-17 10:19:13.742308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task_obj = MockTask()
    # Create a mock connection object
    conn_obj = MockConnection()
    # Create a mock loader object
    loader_obj = MockLoader()
    # Create a mock display object
    display_obj = MockDisplay()
    # Create a mock templar object
    templar_obj = MockTemplar()
    # Create a mock action plugin object
    action_plugin_obj = ActionModule(task_obj, conn_obj, loader_obj, display_obj, templar_obj)
    # Create a mock task_vars object
    task_vars = dict()
    # Create a mock tmp object
    tmp = None
    # Call the run method of the action plugin object
    result = action_plugin_obj.run(tmp, task_vars)
    #

# Generated at 2022-06-17 10:19:14.643443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:19:24.565590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.yum as yum
    import ansible.plugins.action.dnf as dnf
    import ansible.plugins.action.yum_base as yum_base
    import ansible.plugins.action.dnf_base as dnf_base
    import ansible.plugins.action.yum_repository as yum_repository
    import ansible.plugins.action.dnf_repository as dnf_repository
    import ansible.plugins.action.yum_repository_set as yum_repository_set
    import ansible.plugins.action.dnf_repository_set as dnf_repository_set
    import ansible.plugins.action.yum_version as yum_version
    import ansible.plugins.action

# Generated at 2022-06-17 10:19:37.231630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name="yum",
            module_args=dict(
                name=["httpd", "mod_ssl"],
                state="present",
                use_backend="yum4"
            )
        ),
        async_val=42,
        delegate_to="localhost",
        delegate_facts=True,
        args=dict(
            name=["httpd", "mod_ssl"],
            state="present",
            use_backend="yum4"
        )
    )

    # Create a mock task_vars

# Generated at 2022-06-17 10:19:40.218133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:19:42.945655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:19:49.569873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['httpd'], state='present')),
        connection=dict(host='localhost'),
        play_context=dict(check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module._task.args == dict(name=['httpd'], state='present')
    assert action_module._connection.host == 'localhost'
    assert action_module._play_context.check_mode is True
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

# Generated at 2022-06-17 10:20:01.755225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    display.verbosity = 4

    class ActionModule(ActionBase):

        TRANSFERS_FILES = False


# Generated at 2022-06-17 10:20:12.475416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'yum'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = {}

    # Test the run method
    result = action_module.run(task_vars=task_vars)

    # Assert the result
    assert result == {'failed': False, 'changed': False, 'msg': 'Hello World'}

# Unit

# Generated at 2022-06-17 10:20:28.487610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:20:37.021033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = type('task', (object,), {'args': {'use': 'yum4'}})()
    # Create a mock loader
    loader = type('loader', (object,), {'module_loader': type('module_loader', (object,), {'has_plugin': lambda self, module: True})()})()
    # Create a mock templar
    templar = type('templar', (object,), {'template': lambda self, template: 'yum4'})()
    # Create a mock connection
    connection = type('connection', (object,), {'_shell': type('_shell', (object,), {'tmpdir': '/tmp'})()})()
    # Create a mock display

# Generated at 2022-06-17 10:20:42.239053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:20:45.402820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 10:20:49.650043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use='auto')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 10:20:53.250874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:20:55.071392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:20:59.402279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:21:08.905386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action_module = ActionModule()
    action_module._task.args = {}
    action_module._task.delegate_to = None
    action_module._task.delegate_facts = None
    action_module._task.async_val = None
    action_module._shared_loader_obj.module_loader.has_plugin = lambda x: True
    action_module._execute_module = lambda x, y, z, w: {'failed': True, 'msg': 'Could not detect which major revision of yum is in use, which is required to determine module backend.'}
    result = action_module.run(None, None)
    assert result['failed'] is True

# Generated at 2022-06-17 10:21:18.681122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    # Create a fake task object
    task_args = dict(
        use_backend='yum',
        name='httpd',
        state='present',
    )
    task_vars = dict(
        ansible_facts=dict(
            pkg_mgr='yum',
        ),
        ansible_pkg_mgr='yum',
    )
    task = action_loader.get('yum', task_args=task_args, task_vars=task_vars)

    # Create

# Generated at 2022-06-17 10:21:46.468130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 10:21:55.181116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a dictionary to pass to the run method
    task_vars = {}
    # Create a dictionary to pass to the run method
    tmp = {}
    # Create a dictionary to pass to the run method
    args = {}
    # Create a dictionary to pass to the run method
    args['use'] = 'auto'
    # Create a dictionary to pass to the run method
    args['use_backend'] = 'auto'
    # Create a dictionary to pass to the run method
    args['name'] = 'auto'
    # Create a dictionary to pass to the run method
    args['state'] = 'auto'
    # Create a dictionary to pass to the run method
    args['disable_gpg_check'] = 'auto'
    # Create a dictionary to pass to the

# Generated at 2022-06-17 10:21:58.712396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:22:05.712950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action = ActionModule(
        task=dict(
            args=dict(
                use_backend='yum',
            ),
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )

    assert action._task.args['use_backend'] == 'yum'

    # Test with invalid parameters
    action = ActionModule(
        task=dict(
            args=dict(
                use_backend='yum',
                use='yum',
            ),
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )

    assert action._task.args

# Generated at 2022-06-17 10:22:07.468993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:22:12.121728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use='auto', use_backend='auto')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 10:22:15.734383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:22:22.975200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid backend
    task_args = {'use': 'yum'}
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['ansible_facts']['pkg_mgr'] == 'yum'

    # Test with an invalid backend
    task_args = {'use': 'invalid'}
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}


# Generated at 2022-06-17 10:22:28.580452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Test with use_backend
    task.args = dict(use_backend='yum')
    result = action_plugin.run(task_vars=task_vars)

# Generated at 2022-06-17 10:22:37.993397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task_vars = dict()
    tmp = None
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    result = action_module.run(tmp, task_vars)
    assert result['failed'] is True
    assert result['msg'] == ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                             "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")

    # Test with use_backend=yum
    task_vars = dict()
    tmp = None

# Generated at 2022-06-17 10:23:34.778015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:23:43.330863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no delegate_to and no delegate_facts
    task_vars = dict(ansible_facts=dict(pkg_mgr='yum'))
    task = dict(args=dict(use='auto'))
    tmp = None
    action_module = ActionModule(task, tmp, task_vars)
    result = action_module.run(tmp, task_vars)
    assert result['ansible_facts']['pkg_mgr'] == 'yum'
    assert result['ansible_facts']['pkg_mgr'] == 'yum'

    # Test with delegate_to and delegate_facts
    task_vars = dict(ansible_facts=dict(pkg_mgr='yum'))

# Generated at 2022-06-17 10:23:46.611256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:23:51.245312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:23:56.109253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Create a mock facts
    facts = dict()

    # Create a mock module_name
    module_name = 'ansible.legacy.setup'

    # Create a mock module_args

# Generated at 2022-06-17 10:24:01.836045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use='yum', name='foo', state='present')),
        connection=dict(host='localhost', port=22),
        play_context=dict(check_mode=True, diff=True),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.args.get('use') == 'yum'
    assert action_module._task.args.get('name') == 'foo'
    assert action_module._task.args.get('state') == 'present'
    assert action_module._connection.host == 'localhost'
    assert action_module._connection.port == 22
    assert action_module._play_context.check_mode is True
    assert action_module._play_

# Generated at 2022-06-17 10:24:11.377089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.yum import ActionModule
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

# Generated at 2022-06-17 10:24:18.635903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(
        task=dict(args=dict(use='yum')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())

    assert action_module._task.args['use'] == 'yum'

# Generated at 2022-06-17 10:24:28.540663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock task vars object
    task_vars = MockTaskVars()
    # Create a mock module object
    module = MockModule()
    # Create a mock module args object
    module_args = MockModuleArgs()
    # Create a mock module name object
    module_name = MockModuleName()
    # Create a mock wrap async object
    wrap_async = MockWrapAsync()

# Generated at 2022-06-17 10:24:37.838893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'yum'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}

    # Create a mock result
    result = {'ansible_facts': {'pkg_mgr': 'yum'}}

    # Test the run method of the action plugin

# Generated at 2022-06-17 10:26:39.871227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock module
    module = 'auto'

    # Create a mock facts
    facts = dict()

    # Create a mock new_module_args
    new_module_args = dict()

    #

# Generated at 2022-06-17 10:26:42.564209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:26:52.734089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(name=['vim-enhanced', 'httpd'])

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Test run method
    result = action_plugin.run(task_vars=task_vars)

    # Assert that the result is not None
    assert result is not None

    # Assert that the result is a dict

# Generated at 2022-06-17 10:27:01.834206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with module = auto
    action_module = ActionModule()
    action_module._task = MockTask()
    action_module._task.args = {'use': 'auto'}
    action_module._task.delegate_to = None
    action_module._task.delegate_facts = None
    action_module._templar = MockTemplar()
    action_module._templar.template = Mock(return_value='auto')
    action_module._execute_module = Mock(return_value={'ansible_facts': {'pkg_mgr': 'auto'}})
    action_module._shared_loader_obj = Mock()
    action_module._shared_loader_obj.module_loader.has_plugin = Mock(return_value=True)

# Generated at 2022-06-17 10:27:13.203623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Test with use_backend
    task.args = dict(use_backend='yum')
    result = action_module.run(task_vars=task_vars)

# Generated at 2022-06-17 10:27:16.675462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-17 10:27:18.563239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:27:23.182983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:27:26.864011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:27:29.869115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)