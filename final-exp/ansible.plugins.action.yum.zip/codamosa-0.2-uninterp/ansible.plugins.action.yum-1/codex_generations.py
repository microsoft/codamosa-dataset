

# Generated at 2022-06-17 10:18:02.894552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 10:18:09.445004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3


# Generated at 2022-06-17 10:18:19.061909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import Pkg

# Generated at 2022-06-17 10:18:28.177577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MagicMock()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.delegate_facts = True
    mock_task.async_val = False

    # Create a mock connection
    mock_connection = MagicMock()
    mock_connection._shell = MagicMock()
    mock_connection._shell.tmpdir = '/tmp/ansible_yum_payload_asdf'

    # Create a mock loader object
    mock_loader_obj = MagicMock()
    mock_loader_obj.module_loader = MagicMock()
    mock_loader_obj.module_loader.has_plugin.return_value = True

    # Create a mock templar object
    mock_templar = Magic

# Generated at 2022-06-17 10:18:38.979061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    action = ActionModule()
    action._task.args = {}
    action._task.delegate_to = None
    action._task.delegate_facts = None
    action._task.async_val = False
    action._connection = None
    action._shared_loader_obj = None
    action._templar = None
    result = action.run()
    assert result['failed'] == True
    assert result['msg'] == "parameters are mutually exclusive: ('use', 'use_backend')"

    # Test with use_backend
    action = ActionModule()
    action._task.args = {'use_backend': 'yum'}
    action._task.delegate_to = None
    action._task.delegate_facts = None
    action._task.async_val = False

# Generated at 2022-06-17 10:18:49.183199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with use_backend
    task_vars = dict(ansible_pkg_mgr='yum')
    tmp = None
    task_args = dict(use_backend='yum')
    module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['changed'] == True
    assert result['msg'] == 'yum'

    # Test with use
    task_vars = dict(ansible_pkg_mgr='yum')
    tmp = None
    task_args = dict(use='yum')

# Generated at 2022-06-17 10:18:52.319605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:18:56.471354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:18:57.332925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-17 10:19:05.387406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == True
    assert am.TRANSFERS_FILES == False
    assert am._task.args == {}
    assert am._task.async_val == None
    assert am._task.delegate_facts == None
    assert am._task.delegate_to == None
    assert am._task.loop == None
    assert am._task.loop_args == None
    assert am._task.notify == None
    assert am._task.register == None
    assert am._task.until == None
    assert am._task.retries == None
    assert am._task.delay == None
    assert am._task.first_available_file == None
    assert am._task.any_errors

# Generated at 2022-06-17 10:19:12.976652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 10:19:15.435138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 10:19:18.106979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:19:20.663959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 10:19:22.997387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:19:30.019349
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 10:19:40.381499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'yum'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, display)

    # Create a mock task_vars
    task_vars = dict()

    # Test the run method
    result = action_plugin.run(task_vars=task_vars)

    # Assert the result
    assert result == {'failed': False, 'changed': False, 'msg': 'yum'}


#

# Generated at 2022-06-17 10:19:41.621827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 10:19:42.711310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 10:19:44.537819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:19:59.294665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:20:04.909344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:20:12.393966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test action module
    action_module = ActionModule()

    # Create a test task
    task = dict(
        args=dict(
            use_backend='yum',
        )
    )

    # Create a test task_vars
    task_vars = dict()

    # Call the method run of class ActionModule
    result = action_module.run(task_vars=task_vars, task=task)
    assert result['msg'] == "Could not find a yum module backend for yum."
    assert result['failed'] == True

# Generated at 2022-06-17 10:20:20.729473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import sys
    import unittest

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 10:20:34.975793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['vim-enhanced'], state='present')),
        connection=dict(host='localhost', port=22, user='vagrant', password='vagrant'),
        play_context=dict(become=False, become_method='sudo', become_user='root', check_mode=False, diff=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.args['name'] == ['vim-enhanced']
    assert action_module._task.args['state'] == 'present'
    assert action_module._connection.host == 'localhost'
    assert action_module._connection.port == 22
    assert action_module._connection.user == 'vagrant'
    assert action

# Generated at 2022-06-17 10:20:46.817652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.yum import ActionModule
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display

# Generated at 2022-06-17 10:20:48.865938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:20:59.034604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Test with use_backend
    task.args = dict(use_backend='yum')
    result = action_plugin.run(task_vars=task_vars)

# Generated at 2022-06-17 10:21:00.157356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module is not None

# Generated at 2022-06-17 10:21:02.393517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit tests for ActionModule.run()
    pass

# Generated at 2022-06-17 10:21:38.282412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParser
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserDNF
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserYUM
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserYUM4
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserZYPPER

# Generated at 2022-06-17 10:21:39.638554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 10:21:43.475138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:21:46.112072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:21:51.407110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['vim-enhanced'])),
        connection=dict(module_name='yum'),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:22:03.712098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['pkg_mgr'] = 'yum'
    task_vars['ansible_facts']['pkg_mgr_version'] = '3.4.3'
    task_vars['ansible_facts']['pkg_mgr_cmd'] = 'yum'
    task_vars['ansible_facts']['pkg_mgr_cache_valid_time'] = 0
    task_vars['ansible_facts']['pkg_mgr_cache_last_run'] = 0
    task_vars['ansible_facts']['pkg_mgr_cache_expire_after'] = 0

# Generated at 2022-06-17 10:22:11.479413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import cStringIO

# Generated at 2022-06-17 10:22:21.311291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['vim-enhanced'], state='present')),
        connection=dict(host='localhost'),
        play_context=dict(check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module._task.args['name'] == ['vim-enhanced']
    assert action_module._task.args['state'] == 'present'
    assert action_module._connection.host == 'localhost'
    assert action_module._play_context.check_mode is True
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None

# Generated at 2022-06-17 10:22:34.902582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(use_backend='yum')))
    assert ActionModule(task=dict(args=dict(use='yum')))
    assert ActionModule(task=dict(args=dict(use_backend='dnf')))
    assert ActionModule(task=dict(args=dict(use='dnf')))
    assert ActionModule(task=dict(args=dict(use_backend='auto')))
    assert ActionModule(task=dict(args=dict(use='auto')))
    assert ActionModule(task=dict(args=dict(use_backend='yum', use='yum')))
    assert ActionModule(task=dict(args=dict(use_backend='dnf', use='dnf')))

# Generated at 2022-06-17 10:22:42.218603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import jsonify
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 10:23:41.544803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Create a mock facts
    facts = dict()

    # Create a mock module_name
    module_name = 'ansible.legacy.setup'

    # Create a mock module_args

# Generated at 2022-06-17 10:23:44.150373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 10:23:45.916088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:23:56.565337
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:24:02.522970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 10:24:11.934368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None

    # Test with arguments

# Generated at 2022-06-17 10:24:13.400377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 10:24:24.427355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Test with use_backend
    task.args = dict(use_backend='yum')
    action_module.run(task_vars=task_vars)

    # Test with use
    task.args = dict(use='yum')


# Generated at 2022-06-17 10:24:25.914494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 10:24:37.111813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    # Create a dummy task
    task = dict(
        action=dict(
            module="yum",
            args=dict(
                name=["httpd"],
                state="present",
                use_backend="yum",
            ),
        ),
        async_val=0,
        delegate_to="localhost",
        delegate_facts=False,
    )

    # Create a dummy task_vars

# Generated at 2022-06-17 10:26:25.442174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:26:35.544097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    module = ActionModule()
    module._task = dict(args={})
    module._task_vars = dict()
    module._shared_loader_obj = dict()
    module._connection = dict()
    module._connection._shell = dict()
    module._connection._shell.tmpdir = dict()
    module._templar = dict()
    module._templar.template = lambda x: "yum4"
    module._execute_module = lambda x, y, z: dict(failed=False, msg="")
    result = module.run()
    assert result['failed'] is False
    assert result['msg'] == ""
    assert result['ansible_facts']['pkg_mgr'] == "yum4"

    # Test with use_backend=yum
    module = ActionModule()


# Generated at 2022-06-17 10:26:42.551915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict(name=['foo'], state='present', use='yum')),
        connection=dict(host='localhost', port=22, user='testuser', password='testpass'),
        play_context=dict(become=False, become_user='root', become_method='sudo'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action.run() == dict(
        failed=True,
        msg="Could not detect which major revision of yum is in use, which is required to determine module backend.",
        msg2="You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend}"
    )

# Generated at 2022-06-17 10:26:44.509629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:26:46.805268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:26:52.756752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    module = ActionModule()
    result = module.run()
    assert result['failed'] == True
    assert result['msg'] == ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                             "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")

    # Test with use_backend = auto
    module = ActionModule()
    module._task.args = {'use_backend': 'auto'}
    result = module.run()
    assert result['failed'] == True

# Generated at 2022-06-17 10:26:55.974171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:26:57.834572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-17 10:27:00.816229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:27:02.345413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)