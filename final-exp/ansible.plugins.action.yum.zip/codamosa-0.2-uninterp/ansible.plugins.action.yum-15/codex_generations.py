

# Generated at 2022-06-17 10:18:12.079438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='yum', module_args=dict(name='httpd'))),
        connection=dict(module_name='local', module_args=dict(transport='local')),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module._task.action['module_name'] == 'yum'
    assert action_module._task.action['module_args']['name'] == 'httpd'
    assert action_module._connection.module_name == 'local'
    assert action_module._connection.module_args['transport'] == 'local'
    assert action_module._play_context.check_mode is False

# Generated at 2022-06-17 10:18:19.827448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(use='yum')))
    assert ActionModule(task=dict(args=dict(use='yum4')))
    assert ActionModule(task=dict(args=dict(use='dnf')))
    assert ActionModule(task=dict(args=dict(use='auto')))
    assert ActionModule(task=dict(args=dict(use_backend='yum')))
    assert ActionModule(task=dict(args=dict(use_backend='yum4')))
    assert ActionModule(task=dict(args=dict(use_backend='dnf')))
    assert ActionModule(task=dict(args=dict(use_backend='auto')))

# Generated at 2022-06-17 10:18:33.334490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use='auto')),
        connection=dict(module_name='yum'),
        play_context=dict(check_mode=True, diff=False),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module._task.args == dict(use='auto')
    assert action_module._connection.module_name == 'yum'
    assert action_module._play_context.check_mode is True
    assert action_module._play_context.diff is False
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module

# Generated at 2022-06-17 10:18:37.544791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:18:48.848739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['vim-enhanced', 'nano'], state='present', use='yum')),
        connection=dict(host='localhost', port=22, user='root', password='password'),
        play_context=dict(remote_addr='localhost', remote_user='root', password='password'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.args['name'] == ['vim-enhanced', 'nano']
    assert action_module._task.args['state'] == 'present'
    assert action_module._task.args['use'] == 'yum'
    assert action_module._connection.host == 'localhost'
    assert action_module._connection.port == 22


# Generated at 2022-06-17 10:18:59.572463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'auto'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, display)

    # Create a mock task_vars
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}

    # Test run method
    result = action_plugin.run(task_vars=task_vars)
    assert result['failed'] == False
    assert result['changed'] == False


# Generated at 2022-06-17 10:19:01.463740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 10:19:02.629908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 10:19:09.158556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'yum'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Create a mock task_vars
    task_vars = {}

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the result is correct

# Generated at 2022-06-17 10:19:15.723751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('', (), {})()
    mock_task.args = {'use': 'yum'}
    mock_task.delegate_to = None
    mock_task.delegate_facts = None
    mock_task.async_val = None

    # Create a mock connection
    mock_connection = type('', (), {})()
    mock_connection._shell = type('', (), {})()
    mock_connection._shell.tmpdir = None

    # Create a mock loader
    mock_loader = type('', (), {})()
    mock_loader.module_loader = type('', (), {})()
    mock_loader.module_loader.has_plugin = lambda x: True

    # Create a mock templar
    mock_templar = type('', (), {})()


# Generated at 2022-06-17 10:19:29.975862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = {}

    # Test the run method
    result = action_plugin.run(None, task_vars)

    # Assert that the result is correct

# Generated at 2022-06-17 10:19:40.350640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-17 10:19:48.546266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'yum'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}

    # Create a mock result
    result = {'failed': False, 'msg': '', 'ansible_facts': {'pkg_mgr': 'yum'}}

    # Run

# Generated at 2022-06-17 10:19:55.779632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParser
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserFactory
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserFactoryBase

# Generated at 2022-06-17 10:19:58.122806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 10:20:04.279337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no parameters
    module = ActionModule()
    module._task = Mock()
    module._task.args = {}
    module._task.async_val = False
    module._task.delegate_to = None
    module._task.delegate_facts = True
    module._connection = Mock()
    module._connection._shell = Mock()
    module._connection._shell.tmpdir = '/tmp/test'
    module._shared_loader_obj = Mock()
    module._shared_loader_obj.module_loader = Mock()
    module._shared_loader_obj.module_loader.has_plugin = Mock(return_value=True)
    module._execute_module = Mock(return_value={'ansible_facts': {'pkg_mgr': 'yum'}})
    module._templar = Mock()
   

# Generated at 2022-06-17 10:20:06.580105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None, None, None, None)
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-17 10:20:10.339012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:20:13.140916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module.TRANSFERS_FILES is False


# Generated at 2022-06-17 10:20:15.744044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:20:37.690878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParser
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserError
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserYum

# Generated at 2022-06-17 10:20:47.368721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'yum'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock result
    result = MockResult()

    # Create a mock execute_module
    execute_module = MockExecuteModule()

    # Create a mock remove_tmp_path
    remove_tmp_path = MockRemoveTmpPath

# Generated at 2022-06-17 10:20:48.422019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 10:20:59.007114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)


# Generated at 2022-06-17 10:20:59.849901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 10:21:09.000919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParser
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserDNF
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserYUM
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserYUM4
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserZYPPER

# Generated at 2022-06-17 10:21:11.635017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 10:21:13.598594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:21:21.188664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['vim-enhanced', 'nano'], state='present')),
        connection=dict(host='localhost', port=22, user='root', password='password'),
        play_context=dict(remote_addr='localhost', password='password'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 10:21:22.616850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 10:21:52.760562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    test_action_module = ActionModule(None, None, None, None)
    assert test_action_module is not None
    assert test_action_module._supports_check_mode is True
    assert test_action_module._supports_async is True

# Generated at 2022-06-17 10:21:56.139478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:21:59.377089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:22:08.381395
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:22:10.520017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 10:22:21.523296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParser
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserDNF
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserYum
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserYum4
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactsParserZypper

# Generated at 2022-06-17 10:22:32.459754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name=['vim-enhanced'], state='present')),
        connection=dict(host='localhost', port=22, user='vagrant', password='vagrant'),
        play_context=dict(become=False, become_method='sudo', become_user='root', check_mode=False, diff=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 10:22:41.613824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module class
    mock_module = ActionModule()

    # Create a mock object for the connection class
    mock_connection = Connection()

    # Create a mock object for the task class
    mock_task = Task()

    # Create a mock object for the task_vars class
    mock_task_vars = TaskVars()

    # Create a mock object for the display class
    mock_display = Display()

    # Create a mock object for the templar class
    mock_templar = Templar()

    # Create a mock object for the shared_loader_obj class
    mock_shared_loader_obj = SharedLoaderObj()

    # Create a mock object for the module_loader class
    mock_module_loader = ModuleLoader()

    # Create a mock object for the module_utils class
    mock_module_utils

# Generated at 2022-06-17 10:22:44.841509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-17 10:22:46.064900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 10:23:50.442224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module action plugin
    mock_module = ActionModule()

    # Create a mock object for the connection plugin
    mock_connection = MockConnection()

    # Create a mock object for the task plugin
    mock_task = MockTask()

    # Create a mock object for the task variables
    mock_task_vars = MockTaskVars()

    # Set the connection plugin for the module action plugin
    mock_module._connection = mock_connection

    # Set the task plugin for the module action plugin
    mock_module._task = mock_task

    # Set the task variables for the module action plugin
    mock_module._task_vars = mock_task_vars

    # Create a dictionary of arguments for the module action plugin
    args = {
        'use': 'auto',
    }

    # Set the arguments for the task plugin

# Generated at 2022-06-17 10:23:59.169659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._task = MockTask()
    action_module._task.args = {'use': 'yum'}
    action_module._task.delegate_to = 'localhost'
    action_module._task.delegate_facts = True
    action_module._connection = MockConnection()
    action_module._shared_loader_obj = MockSharedLoaderObj()
    action_module._shared_loader_obj.module_loader.has_plugin = Mock(return_value=True)
    action_module._templar = MockTemplar()
    action_module._templar.template = Mock(return_value='yum')

# Generated at 2022-06-17 10:24:10.495703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.splitter import parse_a_line
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback

# Generated at 2022-06-17 10:24:22.397406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(name='foo', state='present')
    task.delegate_to = 'localhost'
    task.delegate_facts = True

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock module
    module = MockModule()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock facts

# Generated at 2022-06-17 10:24:29.752890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(use='auto')),
        connection=dict(module_name='yum'),
        play_context=dict(check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-17 10:24:38.165119
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 10:24:38.980721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 10:24:44.782894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'use': 'yum'}
    mock_task.async_val = False
    mock_task.delegate_to = None
    mock_task.delegate_facts = False

    # Create a mock connection
    mock_connection = MockConnection()
    mock_connection._shell = MockShell()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock action plugin

# Generated at 2022-06-17 10:24:54.857190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Test the run method
    action_plugin.run(task_vars=task_vars)

    # Test the run method with use_backend
    action_plugin.run(task_vars=task_vars)

    # Test the run method with

# Generated at 2022-06-17 10:24:59.574695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))

# Generated at 2022-06-17 10:26:56.858188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFacts
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector

# Generated at 2022-06-17 10:26:59.999047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 10:27:09.547513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('', (), {})()
    mock_task.args = {'use': 'yum4'}
    mock_task.async_val = False
    mock_task.delegate_to = None
    mock_task.delegate_facts = False

    # Create a mock connection
    mock_connection = type('', (), {})()
    mock_connection._shell = type('', (), {})()
    mock_connection._shell.tmpdir = '/tmp'

    # Create a mock shared loader object
    mock_shared_loader_obj = type('', (), {})()
    mock_shared_loader_obj.module_loader = type('', (), {})()
    mock_shared_loader_obj.module_loader.has_plugin = lambda x: True

    # Create a mock templ

# Generated at 2022-06-17 10:27:11.538173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 10:27:17.832006
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 10:27:27.450822
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 10:27:33.318016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Create a mock tmp
    tmp = None

    # Test the run method
    action_module.run(tmp, task_vars)

    # Test the run method with a use_backend parameter
    task.args = dict(use_backend='auto')

# Generated at 2022-06-17 10:27:33.789027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:27:34.425392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 10:27:40.254729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    action_module = ActionModule()

    # Create a dictionary of arguments to pass to the method run
    args = {
        'use': 'yum',
        'name': 'httpd',
        'state': 'present'
    }

    # Create a dictionary of task_vars to pass to the method run
    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum'
        }
    }

    # Create an instance of AnsibleActionFail class
    ansible_action_fail = AnsibleActionFail("parameters are mutually exclusive: ('use', 'use_backend')")

    # Create an instance of AnsibleModule class
    ansible_module = AnsibleModule()

    # Create a dictionary of facts to pass to the method execute_module
