

# Generated at 2022-06-25 08:02:28.301232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '+aV2'
    float_0 = 0.6719685
    int_0 = -50
    bytes_0 = b'04\xfa\xa9\x1b\xef\xc3\xcc\xf3'
    int_1 = -145
    dict_0 = {'R\xee\x9e\x8c\x07\xac\x95\x81\x7e\xc6\xfb\x9b\x15': -145}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    action_module_0.run()



# Generated at 2022-06-25 08:02:29.408343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True, "Test not implemented"

# Generated at 2022-06-25 08:02:35.173752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\t:5\t'
    float_0 = 589.77
    int_0 = -107
    bytes_0 = b'\xff\xdb\xb9\x9b\x8c\xaax\x96TJ\x93'
    int_1 = -103
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    assert(action_module_0._shared_loader_obj.module_loader.has_plugin('an') == False)


# Generated at 2022-06-25 08:02:39.307502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module_0 = ActionModule('AhhG', -29.0, -348, b'\x9f\xb6\xda\xc0\xfc\xdbC\xf3\xb3\x84\xbd\xee\xe0', -41, {'`?\x16\x1c\x7f\x1d9\x07\x14': -428})

    # Call the run method of class ActionModule on the instance
    action_module_0.run()

# Generated at 2022-06-25 08:02:46.930351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\tk>H=@4S?t1[716I'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 08:02:56.943278
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:03:00.795145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule)


# Generated at 2022-06-25 08:03:09.282834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\t\x11\xb7\x09\xad\x8c\x1aV\xae\x9f6\x0f'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    int_1 = -114
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    str_1 = 'O\xa0\x1e\x9f\x1a\x05\xad\xee\x0e\x84'
    int_2 = 4
   

# Generated at 2022-06-25 08:03:10.411000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:16.769442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -97
    dict_0 = {}
    str_0 = '\t\x11\xa2\x10\x91\x9d\x9eN\x95\xc8\x8e!\x1b\xce'
    bytes_0 = b'\x9b\x15\xc8\x8d\x19\xdf\xaa\x15\x0e\x9f\x9bf\xb6\xd1\x1b\x00\xec\xf3\x08\xfa\x01\x9c\x1b\x8c\x85?\xd1(\x97\x84\xd6V\xac\x9e\xcc\xfc\xc7\x86\xd2'
    float_0 = -27116.

# Generated at 2022-06-25 08:03:27.839750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement real unit tests, too many parameters and interaction with the OS
    #       Also, need to import the module to run tests on it
    assert True


# Generated at 2022-06-25 08:03:35.111373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '}x\x9b'
    float_0 = 3.65217
    int_0 = 1341
    bytes_0 = b'\xdc\xf6\xbe\xd7\x94\xa3\xc4\x0f\x98'
    dict_0 = {}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    assert str_0 == action_module_0.get_name()
    assert float_0 == action_module_0.get_action_handlers()
    assert int_0 == action_module_0.get_bypass_check()
    assert bytes_0 == action_module_0.get_async_val()
    assert float_0 == action_module_0

# Generated at 2022-06-25 08:03:40.881269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x1e\x1c\x87\x9a\x9b\xc6K\xe6\x1f'
    float_0 = 1646.0571389
    int_0 = -256
    bytes_0 = b'4\xd4\xfd\x0e\x87\xab\xef\x9a\xc3\xfa\xca\xca\xa3\x98\xf7\x99\x12'
    int_1 = -80

# Generated at 2022-06-25 08:03:48.376656
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:03:55.156677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'xE~'
    float_0 = 4608.602214552306
    int_0 = -89
    bytes_0 = b'\x1b\x8f\x10\x80\x0e\x0b\x8c\x06\x9d\x1c\x8dU\xf7\x90\x82<\x8c\x04'
    int_1 = -18
    dict_0 = {str_0: float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    var_0 = action_run(dict_0)


# Generated at 2022-06-25 08:03:58.422819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    

# Generated at 2022-06-25 08:04:01.173513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)


# Generated at 2022-06-25 08:04:07.505740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    assert action_module_0.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 08:04:14.264728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x8a\x1a\xbc\x88\x97b\x9a\x0f\x81\x82\x18\x08\xd3'
    float_0 = 1450.8188
    int_0 = -73
    bytes_0 = b'\xf7\xfb\xfaP\x82\x9e\xb9\x92\xec\xfa\xa0\xb5\xfc'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    action_module_0.run(dict_0)

if __name__ == "__main__":
    test_case_0()


# Generated at 2022-06-25 08:04:24.869971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    dict_0 = {str_0: int_0}
    int_1 = -114
    dict_1 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_1)
    str_1 = 'uB5m'
    float_1 = 1396.8025
    int_2 = -114
    bytes_1 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    str

# Generated at 2022-06-25 08:04:41.891994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)

# Generated at 2022-06-25 08:04:47.465500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule) is True


# Generated at 2022-06-25 08:04:54.466409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'c\x9dY'
    float_0 = -1116.31
    int_0 = -404
    bytes_0 = b'\x9e/\xec\xef\x98!f\xdf\x87\x8b\x91\x86\xe9\xba\xb6\xea\xbc'
    int_1 = -498
    dict_0 = {str_0: int_0, int_1: float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    var_0 = action_run(dict_0)
    assert var_0 == var_0


# Generated at 2022-06-25 08:05:02.098509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import __main__
    import unittest

    # Set up a simulation of the task_vars dictionary

    # TODO: use an actual data store instead of a dictionary
    task_vars = {}

    # Set up a simulation of the Ansible configuration variables
    module_loader_class = None
    connection_loader_class = None
    shell_class = None

# Generated at 2022-06-25 08:05:07.111195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 
    dict_0 = dict(arg='auto', yum='auto')

    action_module_1 = ActionModule(dict_0, dict_0)
    var_0 = action_module_1.run()

    # 
    dict_1 = dict(arg='auto', yum='yum3')

    action_module_1 = ActionModule(dict_1, dict_0)
    var_0 = action_module_1.run()

    # 
    dict_2 = dict(arg='auto', yum='yum4')

    action_module_1 = ActionModule(dict_2, dict_0)
    var_0 = action_module_1.run()

    # 
    dict_3 = dict(arg='yum3', yum='auto')


# Generated at 2022-06-25 08:05:20.647400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Ebk6'
    float_0 = 933.39675
    int_0 = -175
    bytes_0 = b'\xb3\x95\x82\xeb\x91\xed\x95\x8f\x9d\xb2\x9fU6\xed\xdb\xebJ'
    int_1 = -313
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    str_1 = 'jyEG'
    float_1 = 627.6683
    int_2 = -230

# Generated at 2022-06-25 08:05:30.769778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '6U8H'
    float_0 = -1166.1413
    int_0 = -78
    bytes_0 = b'\xbe\x96\xc4\xbe\x8f\x0c\xaa'
    int_1 = -37
    dict_0 = {int_0: str_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    assert action_module_0.str_0 == str_0
    assert action_module_0.float_0 == float_0
    assert action_module_0.int_0 == int_0
    assert action_module_0.bytes_0 == bytes_0
    assert action_module_0.int_1 == int

# Generated at 2022-06-25 08:05:42.840912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mocks
    class MockAnsibleActionFail(AnsibleActionFail):
        def __init__(self, str_0):
            self._str_0 = str_0
    class MockActionBase(ActionBase):
        def __init__(self, connection, task, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._play_context = play_context
            self._loader = loader
            self._connection = connection
            self._shared_loader_obj = shared_loader_obj
            self._templar = templar
        def run(self, str_0, dict_0):
            self._task = dict_0
            self._play_context = str_0
            return self._dict_0

# Generated at 2022-06-25 08:05:44.137182
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_case_0()

# Generated at 2022-06-25 08:05:50.533661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'T'
    float_0 = -191.14
    int_0 = -148
    bytes_0 = b'\xc5\x84\xa0\x9bN\xce\x90\xf30'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 08:06:17.885315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with patch.object(ActionModule, 'run') as mock:
        action_module_0 = ActionModule()
        var_7 = action_run(action_module_0)


# Generated at 2022-06-25 08:06:22.357736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n'
    float_0 = -158.9
    int_0 = -43
    bytes_0 = b'\x1d\xac\x8f\xfb'
    dict_0 = {'f\x8a\x1b\xdd\x15\x91\xc0\x1a\x1dz\x87\x89a\xad': b'\x12\x0ce\xbf'}
    var_0 = action_module_0.run(dict_0)


# Generated at 2022-06-25 08:06:31.262178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'A\xce\xdd\xac\x85\xac\x18\xb6\x17\xf0\x18\x19\x9d'
    float_0 = 279.991656
    int_0 = 1024
    bytes_0 = b'g\xbe\x16\x8f\x82\xa6\xe62\xe3\x8a\xab\xe9\x0b\x07'
    int_1 = -29
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    assert str_0 == action_module_0._task.name
    assert float_0 == action_module_0._

# Generated at 2022-06-25 08:06:38.646937
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:06:44.789770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    int_1 = -114
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    var_0 = action_run(dict_0)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 08:06:48.910914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ';c%'
    float_0 = 30.572966
    int_0 = 22
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    int_1 = -19
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)


# Generated at 2022-06-25 08:06:56.012576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assign
    str_0 = 'a'
    float_0 = 214.68
    int_0 = -230
    bytes_0 = b'\x06\x8b\xddR\x87\xaa\x9d\xe2\xce\x822'
    int_1 = 198
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    result = action_module_0.run()
    # Verify
    assert(result == None)


if __name__ == '__main__':
    # unittest.main(verbosity=2, exit=False)
    test_ActionModule_run()

# Generated at 2022-06-25 08:07:03.274232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\xf6\xee\xe9\x8b\x83\xe3\xaa+'
    float_0 = -193.806049
    int_0 = -85
    bytes_0 = b'\xc0\xf5\x8e\xae\xbc\xb1\x94\x8f'
    int_1 = -155
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    action_module_0.run()

# Mocking for method run of class ActionModule

# Generated at 2022-06-25 08:07:12.782800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -97
    float_0 = -85.5719
    bytes_0 = b'\x82\xf2N_\x97\xd9\x8d\x92\xa0\xbe\xe1\xbc[\n\xfa\x91\xbb\x8b\x92\xc0\xcf\\\xed\x8b'
    int_1 = -82

# Generated at 2022-06-25 08:07:15.938128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'M'
    float_1 = -2132.54
    int_1 = -11
    bytes_1 = b'\x0f\x9c\xd1\x14\xee\xaf\xeb?\xdf'
    int_2 = -42
    dict_1 = {str_1: int_1}
    action_module_1 = ActionModule(str_1, float_1, int_1, bytes_1, int_2, dict_1)


# Generated at 2022-06-25 08:08:10.839253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'nEDMG\xa5l`\xa7'
    float_0 = -16.838
    int_0 = -126
    bytes_0 = b'\xa1\x97\x9b\x8f\x9d\x9a[\x90\xd5\xeb\xab\xe0'
    int_1 = -127
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    assert hasattr(action_module_0, 'run')

# Generated at 2022-06-25 08:08:18.652112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'd<\xf7\x0e'
    float_0 = -1038.58
    int_0 = 1884
    bytes_0 = b'\xa3\xb3\xf1b\xdb\x1e\xbc\xdf\xcb\xc2\x1b\xd4\xcf\xef\x9c\x8b\xca'
    int_1 = -1346
    dict_0 = {'\x00\xb9\x9f\x80\xf2\xab\xd5\xe7\x1a\x84\xe4': float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)

# Generated at 2022-06-25 08:08:22.975683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 't_'
    float_0 = 441.1211
    int_0 = -13
    bytes_0 = b'\x98\xbe\xbe\xfc\x81\xfa\xa5\x08\x8e\xd5\xed\xec\x8b\x83'
    dict_0 = {}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 08:08:26.382617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'I'
    float_0 = 884.92
    int_0 = -83
    bytes_0 = b'\x9f\xa9\xfa\xdb\xcf\xce(('
    dict_0 = {float_0: dict_0, int_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)




# Generated at 2022-06-25 08:08:29.295390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 08:08:39.337412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '9H|eRsj_'
    float_0 = 934.0501
    int_0 = -89
    bytes_0 = b'\x14\x04\xfa\x10\xdd\xc7\xd0\x89A\x12\xb9,'
    int_1 = -52
    dict_0 = {str_0: int_1, 'J&': int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    str_1 = action_module_0.get_name()
    assert(str_1 == str_0)
    str_2 = action_module_0.get_connection()
    assert(str_2 == 'local')
    str_3

# Generated at 2022-06-25 08:08:46.174044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    filename = os.path.join(tmpdir, '__init__.py')

# Generated at 2022-06-25 08:08:58.000195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the action plugin
    str_0 = '0'
    float_0 = -50461.8589
    int_0 = -101
    bytes_0 = b'\xfd\xfc\xf9\xfe\xfd\xf8\xfd\xfc\xf9\xfe\xfd\xf8\xfd\xfc\xf9\xfe\xfd\xf8\xfd\xfc\xf9\xfe\xfd\xf8'
    int_1 = -50461
    dict_0 = {'R\xfc\xbc\xfb\xc6\x9e\xdb\x95\x0f\x81\xeb\x1c': -50461}


# Generated at 2022-06-25 08:09:07.071042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'J\xc6\x0c[\xed\xd3\xae2\x9d'
    float_0 = -155.19373
    int_0 = -38
    bytes_0 = b')\xf1C]\x93\x8f\x00\xfe\x88\x93\x8b>'
    int_1 = -144

    print('Testing construction of class ActionModule')
    try:
        action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1)
    except Exception as exception_0:
        print(exception_0)
    else:
        print('No exception when constructing an instance of class ActionModule')


# Generated at 2022-06-25 08:09:08.288592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 08:10:49.999506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'B|\x0b\x94\x1f1\x80\xba\x84\xe4'
    float_0 = -10.0816
    int_0 = -110
    bytes_0 = b'\xda\x0f\x12\xa4\xb4\x92\xe2\x85\xfb\xca\xa1\x1e\x8b'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    var_0 = action_module_0.run(dict_0)
    assert var_0 is None, var_0


# Generated at 2022-06-25 08:10:55.863090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    int_1 = -114
    dict_0 = {str_0: int_0}
    assert ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)._task.async_val == int_1
    str_1 = 'uB5m'
    float_1 = 1396.8025
    int_2 = -114
    bytes_1 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    int_3 = -114
    dict_

# Generated at 2022-06-25 08:11:06.707954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x91\xea\x868\xeb\xde\xd6\x17~\x92\x11\x9f'
    float_0 = 1283.24
    int_0 = -40
    bytes_0 = b'\xa0\xd2\xed\x8d\xc1\x1a\xd3\x8d\xc6N\x9c'
    dict_0 = {'x\x08\xfb\x88\x7f\x8e\x7f\x08\x063\x8c\x81\xad\x0d\xac\xf8\xf1': int_0}

# Generated at 2022-06-25 08:11:17.015053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '7g'
    float_0 = 3550.849
    int_0 = -32
    bytes_0 = b'\xad\xed\xe0Y\xb2\x9a\x9b\x98\x0b\xcc\x94*\x83\x0b'
    dict_0 = {str_0: float_0, float_0: str_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    var_0 = action_run(dict_0)
    assert var_0 == "Test"
    assert not var_0 == "Test"


# Generated at 2022-06-25 08:11:20.724072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'uB5m'
    float_0 = 1396.8025
    int_0 = -114
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    var_0 = action_module_0.run(dict_0)

if __name__ == '__main__':
    test_case_0()
    try:
        test_ActionModule_run()
    except SystemExit:
        pass
    finally:
        print('Goodbye')

# Generated at 2022-06-25 08:11:30.413304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x9b\x82\xcd\x0c*\xab'
    float_0 = -17.97
    int_0 = -210
    bytes_0 = b'\xbc\x93\xd6\x93\xbf<oPC\xe5F'
    int_1 = -108
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_1, dict_0)
    return (action_module_0, str_0, float_0, int_0, bytes_0, int_1, dict_0)


# Generated at 2022-06-25 08:11:35.058997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'nsR<'
    float_0 = 1815.5414
    int_0 = -106
    bytes_0 = b'\xf8\x88\xf6\xae\x1c\x8d\xaf\xddk4Z\xf7'
    dict_0 = {int_0: float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    var_0 = action_run(dict_0)
    assert var_0 is not None

#Unit test for method run of class ActionModule with tmp set to None

# Generated at 2022-06-25 08:11:42.078758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '_V7'
    float_1 = 1267.878
    int_1 = -164
    bytes_1 = b'\xa1\xef\xd0\x9c\xad\x80\xf5\xa1\x94\xaf\xb6'
    int_2 = 45
    dict_1 = {str_1: int_1}
    action_module_1 = ActionModule(str_1, float_1, int_1, bytes_1, int_2, dict_1)


# Generated at 2022-06-25 08:11:51.474492
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:11:59.733911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'JZ'
    float_0 = 1883.3306693079195
    int_0 = -2
    bytes_0 = b'M\x8a\x0f\xa4\x1c\x1e\x13\xda{B\x9b?\x8e'
    dict_0 = {b't:7\x8c\x99\xf6\x9a\x91\x8b\x14\x87': float_0}
    action_module_0 = ActionModule(str_0, float_0, int_0, bytes_0, int_0, dict_0)
    var_0 = action_run(dict_0)
