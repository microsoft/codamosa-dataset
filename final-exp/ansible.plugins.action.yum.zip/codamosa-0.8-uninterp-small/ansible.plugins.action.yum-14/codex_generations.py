

# Generated at 2022-06-25 08:02:26.383826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = '{H_7{c@'
    float_0 = 512.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    dict_0 = {}
    dict_1 = action_module_0.run(dict_0)


# Generated at 2022-06-25 08:02:34.274284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = '{H_7{c@'
    float_0 = 512.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    assert isinstance(action_module_0, ActionModule) is True
    assert action_module_0._ssh_common_args is None
    assert action_module_0._supports_check_mode is True
    assert action_module_0._supports_async is True
    assert action_module_0._connection is None
    assert isinstance(action_module_0._task, Task) is True
    assert action_module_0._task.args == dict_0
    assert action_module_0._task.delegate_to

# Generated at 2022-06-25 08:02:37.462832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = '{H_7{c@'
    float_0 = 512.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    result = action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 08:02:40.565682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-25 08:02:43.816821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = '{H_7{c@'
    float_0 = 512.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    str_1 = 'e*P=.s^<'
    action_module_0.run(str_1)


# Generated at 2022-06-25 08:02:50.504848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {
        'ansible_pkg_mgr': 'auto',
        'ansible_verbosity': 2
    }
    str_0 = '{H_7{c@'
    float_0 = 512.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    dict_1 = {
        'use_backend': 'auto',
        'use': 'auto'
    }
    action_module_0._task.args = dict_1
    dict_2 = {
        'use': 'auto',
        'use_backend': 'auto'
    }
    action_module_0._task.args = dict_2

# Generated at 2022-06-25 08:02:57.929203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = '{H_7{c@'
    float_0 = 512.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    assert action_module_0._display == None
    assert not isinstance(action_module_0._display, (Display,))
    assert action_module_0._task == {}
    assert not isinstance(action_module_0._task, (dict,))
    assert action_module_0._loader == None
    assert not isinstance(action_module_0._loader, (Playbook.Loader,))
    assert action_module_0._play_context == None

# Generated at 2022-06-25 08:03:09.585550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'changed': 0, 'msg': 'getargs of module returned ok', 'rc': 0, 'ansible_facts': {'ansible_pkg_mgr': 'yum'}}
    str_0 = 'action'
    float_0 = 13637.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    assert action_module_0._task is dict_0
    assert action_module_0._connection is str_0
    assert action_module_0._play_context is float_0
    assert action_module_0._loader is tuple_0
    assert action_module_0._templar is str_0
    assert action_module_0._shared_loader_obj is dict

# Generated at 2022-06-25 08:03:13.414811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = '{H_7{c@'
    float_0 = 512.0
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, float_0, tuple_0, str_0, dict_0)
    assert action_module_0._shared_loader_obj is not None


# Generated at 2022-06-25 08:03:20.930835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'ansible.modules.packaging.os.yum'
    args = {'name': 'ansible', 'state': 'present'}
    host_vars = {}
    return_value = execute_module(module, args, host_vars, check_mode=False)
    pprint(return_value)


# Test module
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:29.815704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Unit tests for all private functions and methods in class ActionModule


# Generated at 2022-06-25 08:03:32.665439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x1d'
    float_0 = -1424.0
    int_0 = 0
    var_0 = 'P=s}'
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    tmp_0 = int_0
    task_vars_0 = action_module_0.run(
        tmp_0, task_vars=var_0)

# Generated at 2022-06-25 08:03:34.874408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:36.325757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test if ActionModule constructor is well declared.
    assert_0 = TestCase()
    assert_0.assertEqual(test_case_0(), None)

# Generated at 2022-06-25 08:03:37.379485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:40.946301
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    tmp_0 = 'L$i'
    task_vars_0 = dict()
    return_value_0 = action_module_0.run(tmp_0, task_vars_0)
    assert return_value_0 == 'module args unknown'

# Generated at 2022-06-25 08:03:46.373939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    str_0 = ':7oCg'
    float_0 = 256.0
    result = action_module_0.run()
    assert result == {'changed': False, 'msg': ''}



# Generated at 2022-06-25 08:03:52.575194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'ansible.legacy.yum'
    task_vars = None
    tmp = None
    action_module_0 = ActionModule(module, task_vars, tmp, module, task_vars, tmp)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:57.140550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    str_0 = 'p'
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 08:04:05.137402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = '<%cg7PuM}P"fz'
    string_1 = 'G9'
    float_0 = 0.5271348132748604
    float_1 = 0.265623077618547
    float_2 = 0.0004640942756228277
    float_3 = 0.000387568166981902

    action_module_0 = ActionModule(float_0, string_0, float_1, string_0, string_1, float_2)
    result = action_module_0.run(float_0, float_0)

    display.display(result)
    display.display(action_module_0)
    # test_case_0()

# Generated at 2022-06-25 08:04:19.566765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 08:04:21.739857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')
    var_0 = None
    test_case_0()
    print('Done testing ActionModule')


# Generated at 2022-06-25 08:04:22.829127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule(var_0)


# Generated at 2022-06-25 08:04:27.685611
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # method run of class ActionModule with argument tmp=None, task_vars=None
    var_1 = None
    var_2 = None
    var_1 = test_case_0()
    test_obj_0 = ActionModule()
    var_1 = test_obj_0.run(var_1, var_2)
    if var_1 == 1:
        print('test_ActionModule_run success')
    else:
        print('test_ActionModule_run fail')


# Generated at 2022-06-25 08:04:34.800004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    # No.1
    var_0 = ActionModule()
    # No.5
    # var_0.display(var_1, var_2, var_3, var_4, var_5, var_6)
    # No.6
    # var_0.run(var_1)
    # No.7
    # var_0.setup(var_1)
    # No.8
    # var_0.teardown(var_1)
    # No.9
    # var_0.__getattribute__(var_1)


# Generated at 2022-06-25 08:04:36.629686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    var_1.run()
    var_2 = ActionModule()
    var_2.run()


# Generated at 2022-06-25 08:04:41.871774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    init_args = dict()
    init_args['task'] = task()
    init_args['connection'] = connection()
    init_args['play_context'] = play_context()
    init_args['loader'] = loader()
    init_args['templar'] = templar()
    init_args['shared_loader_obj'] = shared_loader_obj()

    action_module_obj = ActionModule(**init_args)
    assert action_module_obj



# Generated at 2022-06-25 08:04:53.705664
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:05:01.897571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = AnsibleActionFail()
    var_2 = list()
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = AnsibleActionFail()
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
   

# Generated at 2022-06-25 08:05:05.011055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(action=None, lookup_plugin=None, _connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, configuration=None)
    var_0.task = None
    var_1 = None
    var_2 = None
    var_0.run(tmp=var_1, task_vars=var_2)


# Generated at 2022-06-25 08:05:23.963053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'h_7{c@'
    float_0 = 256.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    action_module_0.action = str_0
    action_module_0.action_loader = str_0
    action_module_0._display = str_0
    action_module_0._load_name = str_0
    action_module_0._task = str_0
    action_module_0.ds = str_0
    action_module_0.noop_check = str_0
    action_module_0.runner = str_0
    action_module_0.set_loader = str_0
    action_module_0._play_context = str_0


# Generated at 2022-06-25 08:05:27.280908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 512.0
    str_0 = 'H_7{c@'
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)


# Generated at 2022-06-25 08:05:32.712455
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = 'H_7{c@'
  float_0 = 512.0
  action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)


# Generated at 2022-06-25 08:05:42.887890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'H_7{c@'
    float_1 = 512.0
    str_2 = 'H_7{c@'
    float_2 = 512.0
    str_3 = 'H_7{c@'
    str_4 = 'H_7{c@'
    float_3 = 512.0
    assert str_0 == str_1
    assert float_0 == float_1
    assert str_2 == str_3
    assert float_2 == float_3
    assert str_0 == str_4
    assert float_0 == float_2
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    assert str_0 == str_1
    assert float_0 == float_1
   

# Generated at 2022-06-25 08:05:45.055799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    action_run_0 = action_module_0.run(str_0)

# Generated at 2022-06-25 08:05:54.720566
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:06:03.859703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create test objects
    int_0 = 8192
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_plugin_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    # Create test case
    str_1 = 'BQ8u&#_'
    str_2 = 'vuTjrp'
    dict_0 = dict()
    tuple_0 = (str_2, dict_0)
    dict_1 = dict()
    dict_2 = dict()
    dict_1['failed'] = False
    dict_1['msg'] = "Could not detect which major revision of yum is in use, which is required to determine module backend."

# Generated at 2022-06-25 08:06:07.330643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    # Real invocation
    action_module_0.run()

# Generated at 2022-06-25 08:06:09.334904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 1
    str_0 = 'H_7{c@'
    int_1 = 1
    float_0 = 512.0
    action_module_0 = ActionModule(int_0, str_0, int_0, str_0, str_0, float_0)

# Generated at 2022-06-25 08:06:11.427621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('unit test for run')
    # TODO: More unit tests!
    print('test finished')

# Main function

# Generated at 2022-06-25 08:06:38.760969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ZTQ8]j'
    float_0 = 14.0

    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._task.args == {}
    assert action_module_0._shared_loader_obj.module_loader.has_plugin('ansible.legacy.auto') == False
    assert action_module_0._task.delegate_to == None
    assert action_module_0._task.delegate_facts == True
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0._task

# Generated at 2022-06-25 08:06:45.409509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float('NaN')
    int_0 = int(12)
    var_0 = action_run(int_0, float_0)
    var_1 = action_run(float_0, float_0)
    var_2 = action_run(int_0, float_0)


# Generated at 2022-06-25 08:06:47.423119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'R#8aU'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    var_0 = action_module_run(str_0)

# Unit test should pass
test_case_0()
test_ActionModule()

# Generated at 2022-06-25 08:06:52.593466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 08:06:58.228923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = '0'
  str_1 = '7}CR`Dd'
  float_0 = 1024.0
  action_module_0 = ActionModule(str_1, float_0, float_0, str_0, str_0, float_0)
  action_module_0.action_loader = str_1
  action_module_0._connection = str_0
  action_module_0.task = str_1
  action_module_0._templar = str_0
  action_module_0._shared_loader_obj = str_0
  action_module_0.task_vars = str_1
  var_0 = action_module_0.run(str_0)
  assert var_0 == 'False'

# Generated at 2022-06-25 08:06:59.206601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # top-down
    action_run()
    test_case_0()



# Generated at 2022-06-25 08:07:02.497010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    assert isinstance(ActionModule(float_0, str_0, float_0, str_0, str_0, float_0), ActionModule)



# Generated at 2022-06-25 08:07:08.160493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing objects
    str_0 = 'Y{}'
    float_0 = 128.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)

    # Testing execution of action_module_0._task.args.get('use',action_module_0._task.args.get('use_backend', 'auto'))
    var_0 = action_module_0._task.args.get('use', action_module_0._task.args.get('use_backend', 'auto'))

# Generated at 2022-06-25 08:07:15.489230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9Xn'
    float_0 = 12.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 08:07:18.191253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 08:08:01.093559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    action_module_0.run(str_0)


# Generated at 2022-06-25 08:08:04.376245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()



# Generated at 2022-06-25 08:08:07.435297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 08:08:11.946180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    var_0 = action_run(str_0)
    if var_0 == -1:
        print('Test failed!')


# Generated at 2022-06-25 08:08:17.631770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'W_&'
    float_0 = 393.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    var_0 = action_run('$QZF\\')
    assert var_0 == "Could not detect which major revision of yum is in use, which is required to determine module backend.", "Error in run method of action plugin ActionModule"

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 08:08:20.141149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 08:08:29.414492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set defaults
    connection_info = {'host': 'localhost', 'port': 22,
                       'username': 'ansible', 'password': 'pass',
                       'ssh_executable': 'ssh', 'scp_executable': 'scp',
                       'scp_extra_args': ''}
    connection_info_str = json.dumps(connection_info)
    yml_str = "---\n- action:\n    module_name: ansible_test.yum\n    delegate_to: 127.0.0.1\n"
    yml_dict = yaml.load(yml_str)
    task = Task(yml_dict[0].get('action'))

# Generated at 2022-06-25 08:08:37.123446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '1n74_v'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    task = {"use_backend":"yum4", "use":"auto", "args":{}}
    action_module_0._task = task
    tmp = None
    task_vars = {}
    action_module_0.run(tmp, task_vars)
    return str_0

# Unit tests for class ActionModule

# Generated at 2022-06-25 08:08:46.031101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'Lpfr)zI^'
    float_1 = 128.0634
    action_module_1 = ActionModule(float_1, str_1, float_1, str_1, str_1, float_1)
    str_2 = 'd`x`(7Vu'
    float_2 = 256.0
    action_module_2 = ActionModule(float_2, str_2, float_2, str_2, str_2, float_2)
    var_0 = action_run(str_2)


# Generated at 2022-06-25 08:08:50.511692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        print (Exception)
    else:
        print ("OK")

# Generated at 2022-06-25 08:10:14.880281
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:10:16.610061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule.__dict__['__init__'](float_0, str_0, float_0, str_0, str_0, float_0))


# Generated at 2022-06-25 08:10:20.324507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'O-oNz'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)



# Generated at 2022-06-25 08:10:24.823686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    float_0 = 0.15
    str_1 = 'H_7{c@'
    str_2 = 'yum'
    str_3 = 'H_7{c@'
    str_4 = 'H_7{c@'
    str_5 = 'H_7{c@'
    str_6 = 'H_7{c@'
    str_7 = 'yum'
    str_8 = 'H_7{c@'
    str_9 = 'H_7{c@'
    str_10 = 'H_7{c@'


# Generated at 2022-06-25 08:10:37.258687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'H_7{c@'
    float_0 = 512.0
    # test type
    assert isinstance(ActionModule(float_0, str_0, float_0, str_0, str_0, float_0), ActionModule)
    # test number of parameters
    try:
        ActionModule()
        # BEGIN Variable types
        # END   Variable types
        # BEGIN Main code
        # END   Main code
    except Exception as e:
        pass
    #test return value
    assert None == None
    #test for exception
    try:
        ActionModule()
        # BEGIN Variable types
        # END   Variable types
        # BEGIN Main code
        # END   Main code
    except Exception as e:
        pass


# Generated at 2022-06-25 08:10:39.474516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'H_7{c@'
    print(ActionModule(float_0, str_0, float_0, str_0, str_0, float_0))


# Generated at 2022-06-25 08:10:44.640698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = float_0 / float_0
    str_0 = 'Mx(g'
    action_module_0 = ActionModule(str_0, float_0, float_0, float_0, float_0, float_0)
    var_0 = action_run(float_0)



# Generated at 2022-06-25 08:10:54.531987
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test only runs if there is a yum or dnf backend available to test
    if not moduleloader.has_plugin('ansible.legacy.yum'):
        print("SKIPPING test_ActionModule_run() (yum not installed)")
        return
    if not moduleloader.has_plugin('ansible.legacy.dnf'):
        print("SKIPPING test_ActionModule_run() (dnf not installed)")
        return

    # Setup
    mock_run = MagicMock(name='run')

    # Use mock_run to replace run() function on ActionBase
    with patch('ansible.plugins.action.ActionBase.run', mock_run):

        # Attempt to get the backend for an empty task
        actionmodule_0 = ActionModule(mock.ANY, mock.ANY)
        actionmodule_

# Generated at 2022-06-25 08:11:01.228751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 512.0
    str_0 = 'H_7{c@'
    action_module_0 = ActionModule(float_0, str_0, float_0, str_0, str_0, float_0)
    str_0 = 'c{'
    action_module_0.run(str_0)

test_case_0()

# Generated at 2022-06-25 08:11:07.408884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0.0, 'test_value_0', 0.0, 'test_value_1', 'test_value_3', 0.0)
    action_run()
    assert_equals(action_module_0.run(), (0.0, 'test_value_1', 0.0, 'test_value_2', 'test_value_3', 0.0, 'test_value_3', 0.0))
    assert_equals(action_module_0.run(), (0.0, 'test_value_0', 0.0, 'test_value_1', 'test_value_2', 0.0, 'test_value_2', 0.0))

