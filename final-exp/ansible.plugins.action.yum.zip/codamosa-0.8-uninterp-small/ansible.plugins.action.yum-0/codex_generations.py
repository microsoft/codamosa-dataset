

# Generated at 2022-06-25 08:02:25.226213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'4\x9b\xa7\xa8\xae\xeeS\x04\x7f#'
    float_0 = 0.0
    int_0 = 1
    list_0 = []
    assert(isinstance(ActionModule(bytes_0, float_0, int_0, list_0, list_0, bytes_0), ActionModule))


# Generated at 2022-06-25 08:02:29.719945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'^\x8f\xd4\x1e\xdbE\x02\xf2\x89l\x0b\xf9\x8d\x1c\xbb\xb5t'
    float_0 = -574.20
    int_0 = -1158
    list_0 = []
    test_case_0()

# Unit tests for class ActionModule

# Generated at 2022-06-25 08:02:36.485564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1d\xfb\x96\x99>\xd8\x8a\x01%\x01\x9d\xc7\x1c\x0b\x82\xdc\x8f\n\xa9\x01"\xac\x8e\x07/'
    float_0 = -1059.6
    int_0 = -1144
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, int_0, list_0, list_0, bytes_0)
    tmp_0 = None
    task_vars_0 = None
    # WARNING: Expected type int, got type str instead
    action_module_0.run(tmp_0, task_vars_0)

# Unit

# Generated at 2022-06-25 08:02:42.145649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile

    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self):
            self.module_name = 'fake_module'
            self.module_args = 'fake_module'
            self.remote_user = 'fake_user'
            self.async_val = 0

            # now create temporary ansible.cfg
            self.config_file = to_bytes(tempfile.NamedTemporaryFile(delete=False).name)
            self.config_template = '[defaults]\nroles_path=%s\n'
            with open(self.config_file, 'wb') as config_fd:
                config_fd.write(self.config_template % to_bytes(os.path.dirname(__file__)))



# Generated at 2022-06-25 08:02:49.877919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x8d\xea\xf6\xdcM\xf2\x7f\x9b\x9bG\xb2\x8d\x1f\x87\x0b@'
    float_0 = -1830.3
    int_0 = -1701

# Generated at 2022-06-25 08:02:55.837557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'r\xc2\xc06\x0b\x14\xa7\xe3`\xd4\xaa\xed\xb3u\xbc{H'
    float_0 = -1911.9
    int_0 = -1160
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, int_0, list_0, list_0, bytes_0)
    assert(action_module_0 != None)
# test case for run method

# Generated at 2022-06-25 08:03:00.744315
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()

# Generated at 2022-06-25 08:03:08.765198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We need to make a tmp dir
    bytes_0 = b'tmp.bwAuEjmZY7'
    float_0 = -966.9
    int_0 = -1283
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, int_0, list_0, list_0, bytes_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    actual = result['msg']
    expected = "Could not detect which major revision of yum is in use, which is required to determine module backend."
    assert actual == expected


# Generated at 2022-06-25 08:03:13.740178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'S\xdf\xb3\xef\x8a\xde\x95\xca\x99\xf9&\x0b\xcc'
    float_0 = -1701.77
    int_0 = -1366
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, int_0, list_0, list_0, bytes_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 08:03:22.850043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xa2\xaf\x0e\x9f9\xaa\x1c\xa7!\xd1\xe8\xdf\xa4\x13\xb4\x9c\xeb'
    float_0 = -2665.92
    int_0 = -1956
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, int_0, list_0, list_0, bytes_0)
    assert(action_module_0._supports_check_mode == True)
    assert(action_module_0._supports_async == True)


# Generated at 2022-06-25 08:03:36.483397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_0.run()
    print(var_0)
    
test_ActionModule_run()

# Generated at 2022-06-25 08:03:39.022202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = 'gather_timeout'
    
    # Check for specific type
    assert isinstance(action_module_0.run(tmp_0, task_vars_0), dict)


# Generated at 2022-06-25 08:03:43.479584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = None
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    obj_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    int_1 = None
    bool_1 = None
    list_1 = None
    set_1 = {int_0, list_1}
    str_1 = 'ansible_forks'
    obj_1 = ActionModule(bool_1, int_1, list_1, set_1, str_1, int_1)
    var_0 = obj_0.run(int_0, obj_1)

# Generated at 2022-06-25 08:03:44.730216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:03:48.433466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_0.run(list_0)
    assert_result = var_0
    assert True

# Generated at 2022-06-25 08:03:49.821554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    try:
        assert((action_module_0 is not None) and (action_module_0 != ""))
    except:
        action_module_0 = None
    assert(action_module_0 is None)

# Generated at 2022-06-25 08:03:53.769160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 1
    list_0 = ['a', 'b', 1, 2]
    set_0 = {1, 2, 3}
    str_0 = 'ansible_forks'
    int_1 = 1
    AM = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_1)
    print(type(AM))


# Generated at 2022-06-25 08:03:55.333820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    test_case_0()

# Generated at 2022-06-25 08:03:58.423309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 3558
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)


# Generated at 2022-06-25 08:04:03.018299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    tmp = None
    task_vars = None
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars) == {}
    assert action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:04:18.540234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 5691
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_0.run(list_0)


# Generated at 2022-06-25 08:04:24.138950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    test_ActionModule_0()
    test_ActionModule_1()
    test_ActionModule_2()
    test_ActionModule_3()
    test_ActionModule_4()
    test_ActionModule_5()


# Generated at 2022-06-25 08:04:27.307866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 08:04:27.829083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 08:04:33.855319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._display.verbosity == 0
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 08:04:34.493896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:04:37.332385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:04:41.739294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 7797
    list_0 = None
    set_0 = {float('-1.1961017232888994'), bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    action_module_0.run(list_0, list_0)

# Test #0

# Generated at 2022-06-25 08:04:51.521515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)

# Generated at 2022-06-25 08:04:58.077562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_0.run(list_0, None)

# Generated at 2022-06-25 08:05:27.648554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {
        bool_0,
        list_0,
    }
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_0.run(list_0)
    assert var_0 == {'failed': True, 'msg': 'Missing required arguments: module_args'}


# Generated at 2022-06-25 08:05:33.332497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    bool_0 = True
    int_0 = 2128
    task_vars = {'ansible_current_user.name': int_0}
    var_0 = action_module_0.run('use_backend=dnf', task_vars)

# Generated at 2022-06-25 08:05:39.485785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except AssertionError:
        Display.error('AssertionError: False')
    except AnsibleActionFail:
        Display.error('AnsibleActionFail')
    except AttributeError:
        Display.error('AttributeError')


# Generated at 2022-06-25 08:05:49.533677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 08:05:52.871511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2177
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_0.run(action_run)



# Generated at 2022-06-25 08:05:56.420147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test 0
    test_case_0()


if __name__ == '__main__':
    # initialize the test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # add tests to the test suite
    suite.addTests(loader.loadTestsFromTestCase(TestActionModule))

    # initialize a runner, pass it your test suite and run it
    runner = unittest.TextTestRunner(verbosity=3)
    result = runner.run(suite)

# Generated at 2022-06-25 08:06:04.360607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module_1 = ActionModule()
    assert action_module_1
    # Test with one argument
    action_module_2 = ActionModule(action_module_1)
    assert action_module_2
    # Test with two arguments
    action_module_3 = ActionModule(action_module_1, action_module_1)
    assert action_module_3
    # Test with three arguments
    action_module_4 = ActionModule(action_module_1, action_module_1, action_module_1)
    assert action_module_4
    # Test with four arguments
    action_module_5 = ActionModule(action_module_1, action_module_1, action_module_1, action_module_1)
    assert action_module_5
    # Test with five arguments
    action

# Generated at 2022-06-25 08:06:06.216443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleActionFail):
        test_case_0()


# Generated at 2022-06-25 08:06:08.897906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_run(list_0)

# Generated at 2022-06-25 08:06:10.240089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:07:05.097888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    try:
        action_module_0.run(list_0, list_0)
    except:
        print("Exception: %s" % sys.exc_info())
    print("ran method")

# Generated at 2022-06-25 08:07:10.518271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = bool(0)
    int_0 = 1382
    str_0 = 'ansible_failed_result'
    str_1 = 'ansible_check_mode'
    action_module_0 = ActionModule(bool_0, int_0, int_0, int_0, str_0, str_1)
    assert action_module_0._supports_check_mode == True


# Generated at 2022-06-25 08:07:13.795064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True

# Generated at 2022-06-25 08:07:20.700934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2763
    list_0 = None
    set_0 = {int_0, list_0}
    dict_0 = dict()
    str_0 = 'ansible_shell_type'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, dict_0)
    var_0 = action_module_0.run(int_0)




# Generated at 2022-06-25 08:07:25.294962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_run(list_0)
    print(var_0)

# Generated at 2022-06-25 08:07:29.860627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check each constructor call
    action_module_0 = ActionModule('ansible_forks', 2128, None, {False, None}, 'ansible_forks', 2128)
    # Check for the class attribute initialization
    assert action_module_0 == {}


# Generated at 2022-06-25 08:07:36.539908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_run(list_0)


# Generated at 2022-06-25 08:07:38.629149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(Exception):
        actionrun()


# Generated at 2022-06-25 08:07:47.434286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AssertionError: assertion failed
    assert False

# test/unit/plugins/strategies/action.py:56: AssertionError
# test/unit/plugins/strategies/action.py:58: AssertionError
# test/unit/plugins/strategies/action.py:60: AssertionError
# test/unit/plugins/strategies/action.py:62: AssertionError
# test/unit/plugins/strategies/action.py:64: AssertionError
# test/unit/plugins/strategies/action.py:66: AssertionError
# test/unit/plugins/strategies/action.py:68: AssertionError
# test/unit/plugins/strategies/action.py:70: AssertionError
# test/unit/plugins/str

# Generated at 2022-06-25 08:07:51.209582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 1131
    list_0 = None
    set_0 = {int_0, bool_0, str_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    assert action_module_0 is not None

# Generated at 2022-06-25 08:09:37.425073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_0.run(list_0, list_0)


# Generated at 2022-06-25 08:09:38.926512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 08:09:43.839360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    test_case_0()

# Generated at 2022-06-25 08:09:44.995195
# Unit test for constructor of class ActionModule
def test_ActionModule():
   action_module_0 = ActionModule()


# Generated at 2022-06-25 08:09:50.875574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    ansible_0 = 'ansible_forks'
    ansible_1 = 'ansible_forks'
    list_0 = {ansible_0, ansible_1}
    var_0 = action_module_0.run(list_0)


# Generated at 2022-06-25 08:09:54.767224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 08:09:58.703107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:10:05.214725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = None
    int_0 = 2128
    list_0 = None
    set_0 = {bool_0, list_0}
    str_0 = 'ansible_forks'
    action_module_0 = ActionModule(bool_0, int_0, list_0, set_0, str_0, int_0)
    var_0 = action_module_run(list_0)



# Generated at 2022-06-25 08:10:09.873568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert check_result_of_run(test_case_0) == 1


# Generated at 2022-06-25 08:10:16.145672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() == None


if __name__ == '__main__':
    test_ActionModule_run()