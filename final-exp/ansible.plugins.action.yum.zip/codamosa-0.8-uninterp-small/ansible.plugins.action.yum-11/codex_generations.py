

# Generated at 2022-06-25 08:02:30.478582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 734
    set_0 = {int_0}
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_0, set_0)
    action_module_0.task_vars = {}
    str_0 = "module"
    action_module_0.task = {"args": {str_0: "auto"}}
    dict_0 = {}
    dict_1 = {}
    dict_2 = {dict_1}
    dict_3 = {dict_2}
    dict_4 = {dict_3}
    dict_5 = {dict_4}
    dict_6 = {dict_5}
    dict_7 = {dict_6}
    dict_8 = {dict_7}
    dict

# Generated at 2022-06-25 08:02:33.410737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_2 = False
    bool_3 = True
    int_3 = 105
    set_2 = {int_3}
    action_module_2 = ActionModule(bool_2, set_2, bool_2, int_3, bool_3, set_2)


# Generated at 2022-06-25 08:02:36.229867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 734
    set_0 = {int_0}
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_0, set_0)
    action_module_0.run(set_0, set_0)

# Generated at 2022-06-25 08:02:42.066467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = True
    set_1 = {'json'}
    action_module_1 = ActionModule(bool_1, set_1, bool_1, '1', bool_1, set_1)
    set_2 = {'data'}
    dict_3 = {'key': 'value'}
    action_module_2 = action_module_1.run(set_2, task_vars=dict_3)

# Generated at 2022-06-25 08:02:48.641257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {'39', '65', '36', '33', '6', '24', 'h&$'}
    action_module_0 = ActionModule(bool_0, set_0, bool_0, 54, bool_0, set_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._connection == set_0
    assert action_module_0._play_context == set_0


# Generated at 2022-06-25 08:02:53.183882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 517
    set_0 = {bool_0, int_0}
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 08:02:57.952569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 819
    set_0 = {int_0}
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_0, set_0)
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0,task_vars_0)
    print(result_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:02.713552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 536
    set_0 = {int_0}
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 08:03:07.743070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 370
    set_0 = {int_0}
    action_module_0 = ActionModule(bool_0, set_0, bool_0, int_0, bool_0, set_0)
    action_module_0.run({}, {})


# Generated at 2022-06-25 08:03:09.049792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except SystemExit:
        pass


# Generated at 2022-06-25 08:03:20.672846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    action_module_0.connection = Connection()
    action_module_0.connection.shell = ShellModule()
    action_module_0.connection.shell.tmpdir = '\''
    action_module_0.shared_loader_obj = PluginLoader()
    action_module_0.task_vars = {}
    action_module_0.tmp = '\''
    action_module_0.run(action_module_0.tmp, action_module_0.task_vars)


# Generated at 2022-06-25 08:03:28.806533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action_loader
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.action import ActionBase
    from ansible.parsing.yaml import objects
    from collections import Mapping, OrderedDict

    results = OrderedDict()
    connection = ConnectionBase(results)
    module_name = 'auto'
    module_args = {'use_backend': 'auto'}
    task_vars = {'ansible_pkg_mgr': 'yum4'}


# Generated at 2022-06-25 08:03:35.508836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'ansible.legacy.yum'
    new_module_args = ['use_backend']
    # From line 156 in ansible/plugins/action/yum.py
    if 'use_backend' in new_module_args:
        del new_module_args['use_backend']


# Generated at 2022-06-25 08:03:37.275258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Fix action_plugin_get_backends to return something.  Currently, it
    # returns nothing and I'm not sure what the intention is.
    # test_case_0()
    pass

# Generated at 2022-06-25 08:03:39.973196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new instance of ActionModule
    action_module_0 = ActionModule(False, 536, False, 536, False, 536)

    # Use the run method of the ActionModule to create a new instance of module_util

    # Verify the result of the run method
    assert module_util_0 is not None


# Generated at 2022-06-25 08:03:44.921289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == None


# Generated at 2022-06-25 08:03:45.956851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:03:51.726457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    startTime = time.time()
    test_case_0()
    endTime = time.time()
    print("Time taken for test_case_0 is: %f" %(endTime - startTime))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:52.742105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    display.debug("test_ActionModule")

    test_case_0()

# Generated at 2022-06-25 08:04:00.451921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare the arguments and variables for the tests
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    action_module_0._execute_module = lambda string_0, module_args, task_vars: ({'ansible_facts': {'ansible_pkg_mgr': 'auto'}})
    action_module_0._templar = lambda : None
    action_module_0._templar.template = lambda string_0: None
    action_module_0._task.delegate_facts = False
    action_module_0._task.args = {'use': 'auto'}

# Generated at 2022-06-25 08:04:10.017800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_1 = ActionModule()


# Generated at 2022-06-25 08:04:16.454017
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:04:20.183679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 614
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)

# Generated at 2022-06-25 08:04:23.414849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    action_run()

# Generated at 2022-06-25 08:04:24.643729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not action_run()
    print('Unit test for constructor of class ActionModule')


# Generated at 2022-06-25 08:04:27.553782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 08:04:31.018543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 08:04:37.112088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = False
    int_1 = 423
    action_module_1 = ActionModule(bool_1, int_1, bool_1, int_1, bool_1, int_1)
    var_1 = action_module_1.run()


test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 08:04:42.239315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-25 08:04:47.159742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test Case 0: missing argument
    # Expected Output: Error
    test_case_0()

# Generated at 2022-06-25 08:05:03.957049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 in __main__.Foo

# Generated at 2022-06-25 08:05:04.844352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type


# Generated at 2022-06-25 08:05:09.677658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import cached

    with pytest.raises(AnsibleActionFail):
        with mock.patch.object(ActionBase, 'run', return_value={'ansible_pkg_mgr': 'yum3'}):
            bool_0 = False
            int_0 = 536
            action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
            var_0 = action_module_0.run({'use': 'yum3'})

# Generated at 2022-06-25 08:05:10.246200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  test_case_0()


# Generated at 2022-06-25 08:05:12.093326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 510
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 08:05:21.661999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 08:05:26.824793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 458
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    action_module_0.run()



# Generated at 2022-06-25 08:05:29.068872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #action_module_0 = ActionModule(int_0, bool_0, bool_0, int_0, bool_0, int_0)
    action_module_0 = ActionModule.__init__()
    assert action_module_0.__init__() is None

# Generated at 2022-06-25 08:05:31.895230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:05:39.415805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert(True)

# Generated at 2022-06-25 08:06:13.562360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 0
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    # Action should pass
    assert True


# Generated at 2022-06-25 08:06:17.609427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AssertionError as ex:
        print("Test Case 0: " + str(ex))



# Generated at 2022-06-25 08:06:22.286701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert(isinstance(action_module_0, action_base_0))
    assert(action_module_0._supports_check_mode == bool_0)
    assert(action_module_0._supports_async == bool_0)
    assert(action_module_0._warning_messages == dict())
    assert(action_module_0._result_q == int_0)


# Generated at 2022-06-25 08:06:27.493636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert action_module_0 is not None, "Unit test for constructor of class ActionModule failed"

# Generated at 2022-06-25 08:06:34.210717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert action_module_0
    assert not bool_0
    assert int_0 == 536
    assert not bool_0
    assert int_0 == 536
    assert not bool_0
    assert int_0 == 536


# Generated at 2022-06-25 08:06:35.661258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, ActionBase)

# Generated at 2022-06-25 08:06:40.974335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    bool_1 = False
    action_module_0 = ActionModule(bool_0, int_0, bool_1, int_0, bool_0, int_0)
    test_case_0()


# Generated at 2022-06-25 08:06:43.792942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 08:06:47.855501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:06:52.180480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing the variables
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    assert bool_0 == action_module_0.run(
        tmp=bool_0, task_vars=bool_0)

# Generated at 2022-06-25 08:08:03.542076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    int_0 = 536
    action_module_0 = ActionModule(bool_0, bool_1, bool_0, bool_1, bool_1, bool_0, bool_0, bool_1, bool_0, bool_0, bool_0, bool_0, bool_1, bool_0, bool_0, bool_1, bool_0, int_0, bool_0, bool_0, bool_0, bool_1, bool_1, bool_0)
    var_0 = action_module_0.run('', {})
    var_1 = action_module_0.run('', {})

# Generated at 2022-06-25 08:08:06.696267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 53
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 08:08:07.619849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj.run()


# Generated at 2022-06-25 08:08:16.608969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of action_module_0
    action_module_0 = ActionModule(False, 536, False, 536, False, 536)
    # Call method run of ActionModule to run
    var_0 = action_module_0.run(None, None)
    # Check the results
    # 'module' should be 'yum'
    # 'module' should be 'yum'
    # 'module' should be 'dnf'
    # 'module' should be 'dnf'
    # 'module' should be 'ansible.legacy.yum'
    # 'module' should be 'ansible.legacy.dnf'
    # 'module' should be 'ansible.legacy.yum'
    # 'module' should be 'ansible.legacy.dnf'
    # 'module' should

# Generated at 2022-06-25 08:08:20.784290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 08:08:29.821955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'ansible_collections.community.general.plugins.modules.yum'
    if not os.path.exists(module):
        module = 'ansible.legacy.' + module
    module = os.path.join(os.path.dirname(module), 'plugins/action')
    if not os.path.exists(module):
        module = 'ansible.legacy.' + module

    if not os.path.exists(module):
        print("TEST FAIL: module %s not found" % module)
        return 1
    display.verbosity = 4
    a = m.load_plugin_snippet(module)
    mock_setup()
    test_case_0()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:08:32.138079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if 0 == Test.test_case_0():
        Test.test_case_0()

# Generated at 2022-06-25 08:08:35.107585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)



# Generated at 2022-06-25 08:08:37.890047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)

# Unit Test for test_case_0

# Generated at 2022-06-25 08:08:43.168555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)


# Generated at 2022-06-25 08:10:47.604575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Unit tests for class ActionModule

# Generated at 2022-06-25 08:10:53.729461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing value
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    dict_0 = dict()
    dict_0['ansible_facts'] = dict()
    dict_0['ansible_facts']['pkg_mgr'] = 'yum4'
    # Executing method run with argument dict_0 and return value 
    var_0 = action_module_0.run(dict_0)
    # Verifying the content of var_0
    assert var_0['msg'] == "Could not find a yum module backend for ansible.legacy.yum4."
    assert var_0['failed'] == True


# Generated at 2022-06-25 08:11:01.775016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 7224
    bool_1 = False
    int_1 = 3488
    bool_2 = True
    int_2 = 264
    action_module_0 = ActionModule(bool_0, int_0, bool_1, int_1, bool_2, int_2)
    assert (action_module_0._supports_check_mode == True)
    assert (action_module_0._supports_async == True)
    assert (action_module_0._supports_async == True)
    assert (action_module_0.TRANSFERS_FILES == False)
    assert (action_module_0._supports_async == True)

# Generated at 2022-06-25 08:11:03.027428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 08:11:07.986004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert (action_module_0.run() == True)


# Generated at 2022-06-25 08:11:10.310533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 08:11:12.538815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 08:11:16.932067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    bool_0 = False
    int_0 = 536
    bool_1 = False
    int_1 = 536
    bool_2 = False
    int_2 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_1, int_1, bool_2, int_2)

    # Act
    output = action_module_0.run()

    # Assert
    assert output == None

# Generated at 2022-06-25 08:11:19.617447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing class initialization
    bool_0 = False
    int_0 = 536
    action_module_0 = ActionModule(bool_0, int_0, bool_0, int_0, bool_0, int_0)
    action_module_0.run()




if __name__ == "__main__":
    test_case_0()
# End of file

# Generated at 2022-06-25 08:11:19.989114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass