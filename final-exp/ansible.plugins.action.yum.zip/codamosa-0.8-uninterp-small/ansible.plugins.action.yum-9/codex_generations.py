

# Generated at 2022-06-25 08:02:25.831032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = 200
    int_0 = 3237
    float_0 = 2211.0
    set_0 = set()
    action_module_0 = ActionModule(int_1, int_0, float_0, float_0, set_0, float_0)
    test_case_0()

if __name__ == "__main__":
    test_case_0()
    # test_ActionModule_run()

# Generated at 2022-06-25 08:02:32.603690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 4371
    float_0 = 6056.0
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)

    action_module_0.run(int_0, int_0)

if __name__ == '__main__':
    test_case_0()

    test_ActionModule_run()

# Generated at 2022-06-25 08:02:42.856682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = frozenset()
    action_module_0 = ActionModule(None, None, None, None, set_0, None)
    tmp_0 = None
    task_vars_0 = dict()
    dict_0 = dict()
    dict_1 = dict()
    dict_0['ansible_facts'] = dict_1
    dict_0['ansible_facts']['pkg_mgr'] = 'auto'
    dict_0['failed'] = True
    dict_0['msg'] = ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                     "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")
    dict_1['pkg_mgr'] = 'auto'

# Generated at 2022-06-25 08:02:50.064614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5490
    float_0 = 5389.0
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)
    dict_0 = dict()
    dict_0['name'] = 'action_module_0'
    dict_1 = dict()
    dict_0['args'] = dict_1
    dict_0['action'] = 'action_module_0'
    dict_1['action_module_0'] = 'action_module_0'
    dict_1['checksum'] = 'action_module_0'
    dict_1['action_plugin_0'] = 'action_module_0'
    dict_1['binary'] = 'action_module_0'

# Generated at 2022-06-25 08:02:53.602172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3237
    float_0 = 2211.0
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)


# Generated at 2022-06-25 08:02:54.586265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Random test case
    # test_case_0()
    pass

# Generated at 2022-06-25 08:02:57.345642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 768
    float_0 = 4346.0
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 08:03:00.889956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# vim: set noexpandtab ts=4 sw=4 :

# Generated at 2022-06-25 08:03:08.462018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 4765
    float_0 = 3015.0
    set_0 = {3570}
    action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)
    action_module_0.run('yum', 'ansible.legacy.common.selection')

test_cases = [
    test_case_0,
    test_ActionModule_run,
    test_ActionModule_run
]

if __name__ == '__main__':
    for test in test_cases:
        print(test.__doc__)
        test()

# Generated at 2022-06-25 08:03:15.263238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(AnsibleActionFail):
        action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)
        case_0 = action_module_0.run(str(tmp), str(task_vars))

    with pytest.raises(AnsibleActionFail):
        action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)
        case_1 = action_module_0.run(int(tmp), str(task_vars))

    with pytest.raises(AnsibleActionFail):
        action_module_0 = ActionModule(int_0, int_0, float_0, float_0, set_0, float_0)

# Generated at 2022-06-25 08:03:24.502378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule(var_0, var_1)
    var_2 = None
    var_3 = None
    var_4 = action_module_0.run(var_2, var_3)
    print(var_4)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:27.067558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 08:03:32.050365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    str_0 = 'ansible.facts'
    dict_0 = dict()
    dict_0['Y'] = 'vWF|qP>eT9_'
    dict_0['2V'] = '8'
    dict_0['c%vn'] = 'W<'
    dict_0['&$0+'] = 'dU.F(U'
    dict_0['+'] = 'dnf'
    dict_0['MJ(^3'] = 'xgJ{'

# Generated at 2022-06-25 08:03:35.816682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 1
    int_1 = 1
    float_0 = 1.0
    float_1 = 1.0
    set_0 = set()
    float_2 = 1.0
    action_module_0 = ActionModule(int_0, int_1, float_0, float_1, set_0, float_2)

    if 'action_result' not in action_module_0._task.result:
        print("Failed test_ActionModule")



# Generated at 2022-06-25 08:03:36.581772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:03:39.328474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1000
    int_1 = 4885
    float_0 = -332.470048
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 08:03:44.848389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    action_module_0 = ActionModule(set_0)


# Generated at 2022-06-25 08:03:46.251552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 is not None


# Generated at 2022-06-25 08:03:53.082418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    module = 100
    task_vars = { action_module_0.run(tmp='', task_vars=task_vars): module, }


# Generated at 2022-06-25 08:03:53.610207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:04:10.864030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e_0:
        print(e_0)
        raise Exception(e_0)
    else:
        pass
    finally:
        pass


test_ActionModule()

# Generated at 2022-06-25 08:04:17.509464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    action_module_0.run(set_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:04:19.654137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule_0()


# Generated at 2022-06-25 08:04:20.570417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:04:26.111048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_2 = 2928
    var_1 = 100
    int_3 = 3237
    float_1 = -787.515
    float_2 = -787.515
    set_1 = set()
    action_module_1 = ActionModule(var_1, int_2, float_1, float_2, set_1, float_2)
    var_2 = action_run()

# Generated at 2022-06-25 08:04:27.314287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 08:04:31.932324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing a case where yum backend is yum4(aka dnf)
    action_module_0 = ActionModule()
    task_vars = ansible_facts.pkg_mgr == "yum4"
    set_0 = action_module_0.run(task_vars)

    print(set_0.name)
    assert set_0.name == "dnf"

    # Testing a case where yum backend is yum3
    action_module_0 = ActionModule()
    task_vars = ansible_facts.pkg_mgr == "yum"
    set_0 = action_module_0.run(task_vars)

    print(set_0.name)
    assert set_0.name == "yum"

# Generated at 2022-06-25 08:04:37.316726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    action_module_0.run(float_0, float_0)

# Use method run of class ActionModule to run tests

# Generated at 2022-06-25 08:04:41.314977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -138
    int_1 = 24447
    float_0 = 0.336
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    float_0 = 0.957
    float_1 = 0.723


# Generated at 2022-06-25 08:04:51.721918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 75
    int_1 = 899
    float_0 = -405.919
    float_1 = -893.343
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_1, set_0, float_0)
    action_module_0.set_loader(None)
    action_module_0.set_connection(None)
    action_module_0.set__transfer_strategy(float_1)
    action_module_0.set_templar(None)
    int_2 = -717
    int_3 = -838
    float_2 = -268.997
    float_3 = -773.278
    set_1 = set()

# Generated at 2022-06-25 08:05:19.501006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(100, 3237, -787.515, -787.515, set(), -787.515)
    var_0 = action_run()

# Generated at 2022-06-25 08:05:22.666222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 08:05:25.087314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 08:05:26.853666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:05:33.772630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    float_1 = -787.515
    set_0 = set()
    float_2 = -787.515
    action_module_0 = ActionModule(int_0, int_1, float_0, float_1, set_0, float_2)

    assert action_module_0._connection.shell.tmpdir is None
    assert action_module_0.display is not None


# Generated at 2022-06-25 08:05:37.173512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = 'temp'
    task_vars = 'vars'


# Generated at 2022-06-25 08:05:39.047200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:05:49.904971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    int_0 = 4125
    int_1 = 1081
    float_0 = 301.4
    var_0 = action_module_0.run(int_0, int_1, float_0)

# Generated at 2022-06-25 08:05:54.722310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    action_module_0 = ActionModule(set_0, set_0, set_0, set_0, set_0, set_0)


# Generated at 2022-06-25 08:05:58.581403
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:06:48.016480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:06:52.893426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        int_0 = 100
        int_1 = 3237
        float_0 = -787.515
        set_0 = set()
        action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
        var_0 = action_module_0.run()
        return True
    except Exception:
        return False


# Generated at 2022-06-25 08:06:57.125284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:07:00.557880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = -1j
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)


# Generated at 2022-06-25 08:07:01.739325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 08:07:05.487030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    action_module_0 = ActionModule(set_0, set_0)
    var_0 = action_run(set_0, set_0)
    assert var_0 == None, 'Functions returns the value which is supposed to be returned'
    print('Unit Test #0 of ActionModule class: run method(p0_connected=False) -- (Passed)')

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 08:07:07.297692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type



# Generated at 2022-06-25 08:07:10.989511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test run()")
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 08:07:15.030986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'test_case_0' in globals()
    test_case_0()


# Generated at 2022-06-25 08:07:17.600057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 08:08:59.029301
# Unit test for constructor of class ActionModule
def test_ActionModule():
  int_0 = 100
  int_1 = 3237
  float_0 = -787.515
  set_0 = set()
  action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)


# Generated at 2022-06-25 08:09:02.072300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(100, 3237, -787.515, -787.515, set(), -787.515)


# Generated at 2022-06-25 08:09:08.667700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 47675
    str_0 = 'Rejpqtbeo'
    float_0 = -8571.406
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    str_1 = 'Dwrijg'
    float_1 = -967.831
    dict_0 = dict()
    dict_1 = dict()
    dict_0['Z'] = str_1
    dict_0['a'] = float_1
    dict_1['Y'] = dict_0
    var_0 = action_run(str_1, dict_1)
    var_1 = var_0
    print(var_1)


# Generated at 2022-06-25 08:09:15.932971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    action_module_0


# Generated at 2022-06-25 08:09:19.221908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 08:09:22.101487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 08:09:24.552210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # int, int, float, float, set, float -> None
    print('Unit test for constructor of class ActionModule')
    test_case_0()
    print('Unit test for constructor of class ActionModule: Success')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:09:28.596881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = None
    var_1 = None
    var_2 = None
    action_module_0.run(var_0, var_1, var_2)

# Generated at 2022-06-25 08:09:32.634729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    assert(action_module_0.action_type == 'yum')
    assert(action_module_0.task._ds == dict())
    assert(action_module_0.task._parent is None)
    assert(action_module_0.task._role is None)


# Generated at 2022-06-25 08:09:37.313129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    int_1 = 3237
    float_0 = -787.515
    set_0 = set()
    action_module_0 = ActionModule(int_0, int_1, float_0, float_0, set_0, float_0)
    assert action_module_0.run() == "module_execution_status"
    assert action_module_0.TRANSFERS_FILES
