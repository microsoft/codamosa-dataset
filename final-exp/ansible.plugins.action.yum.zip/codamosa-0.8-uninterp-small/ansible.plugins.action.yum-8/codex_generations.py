

# Generated at 2022-06-25 08:02:24.546247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    dict_1 = {}
    dict_2 = {dict_0: dict_0}
    dict_0 = {dict_1: 'mw^1', dict_2: dict_0}
    dict_1 = {dict_0: dict_0, dict_1: dict_0}


# Generated at 2022-06-25 08:02:25.388190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:02:33.559802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Test case with correct arguments
    # print("TC1")
    test_case_0()
    # print("TC2")
    test_case_0()
    # print("TC3")
    test_case_0()
    # print("TC4")
    test_case_0()

    # Test case with incorrect arguments
    # print("TC5")
    test_case_0()
    # print("TC6")
    test_case_0()
    # print("TC7")
    test_case_0()
    # print("TC8")
    test_case_0()

# Test function

# Generated at 2022-06-25 08:02:36.070873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module != None


# Generated at 2022-06-25 08:02:46.858035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = None
    tmp = None
    task_vars = None
    dict_0 = None
    dict_1 = {'failed': result, 'ansible_facts': dict_0, 'msg': result}
    var_0 = 'ansible_pkg_mgr'
    str_0 = '2T'
    dict_2 = {var_0: str_0}
    dict_3 = {'ansible_facts': dict_2}
    dict_4 = {'msg': result}
    dict_5 = {'failed': result}
    dict_6 = {'ansible_facts': dict_0, 'msg': result}
    dict_7 = {var_0: result}
    dict_8 = {'ansible_facts': dict_7}

# Generated at 2022-06-25 08:02:55.775785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = test_action_base_construct()
    module = 'ansible.modules.packaging.os'
    # Parameter 'tmp' of method run is not returned
    # Parameter 'task_vars' of method run is not returned
    int_1 = 2333
    result.update(dict_0 = None, module = 'ansible.modules.packaging.os', class_Name = 'ActionModule', int_0 = 2333, str_0 = '1- H^*_', dict_1 = {}, dict_2 = {dict_1: int_1, str_0: dict_1, int_0: str_0})
    return result

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:00.770075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = {}
    list_0 = []
    int_0 = 6192
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {'hostvars': dict_0}
    dict_6 = {'ansible_facts': dict_2}
    dict_7 = {'ansible_pkg_mgr': 'auto', 'foo': dict_6}
    dict_8 = {'filter': 'ansible_pkg_mgr', 'gather_subset': '!all'}

# Generated at 2022-06-25 08:03:09.282681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2666
    str_0 = '1- H^*_'
    dict_3 = {}
    dict_4 = {dict_3: int_0, str_0: dict_3, int_0: str_0}
    dict_5 = {}
    dict_6 = {str_0: dict_5, dict_5: dict_5, dict_0: dict_5}
    dict_7 = {}
    dict_8 = {dict_0: dict_7, int_0: dict_7}
    dict_9 = {}

    dict_10 = {dict_0: dict_9, dict_9: dict_9}
    dict_11 = {}

# Generated at 2022-06-25 08:03:10.228227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule(None, {})
    assert result is not None


# Generated at 2022-06-25 08:03:16.615312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {dict_0: dict_0, dict_1: dict_1}
    dict_0['ansible_task_vars'] = dict_1
    dict_0['ansible_tmp'] = dict_1
    dict_1['_ansible_parsed'] = dict_1
    dict_1['_ansible_verbosity'] = dict_1
    dict_1['_ansible_selinux_special_fs'] = dict_1
    dict_1['_ansible_no_log'] = dict_1
    dict_1['_ansible_delegated_vars'] = dict_1
    dict_1['_ansible_module_name'] = dict_1
    dict_1['_ansible_version'] = dict_1

# Generated at 2022-06-25 08:03:26.096384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    action_module_0 = ActionModule(tmp, task_vars)
    assert action_module_0.run(tmp, task_vars) == {'failed': False, 'invocation': {'module_args': {'use': 'auto'}}}

# Generated at 2022-06-25 08:03:34.498210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define test case inputs
    tmp = None
    task_vars = None

    # Define expected results
    expected_results_0 = {
        'failed': None,
        'msg': ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})"),
    }
    expected_results_1 = {'failed': None, 'msg': None}
    expected_results_2 = {'failed': None, 'msg': None}
    expected_results_3 = {'failed': None, 'msg': None}
    expected_results_4 = {'failed': None, 'msg': None}

# Generated at 2022-06-25 08:03:35.186779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 08:03:40.561515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_0.run(var_0, var_0)
    var_0 = None
    var_1 = None
    var_2 = None
    action_module_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_1.run(var_0, var_0)
    var_0 = None
    var_1 = None
    var_2 = None

# Generated at 2022-06-25 08:03:49.487928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule(var_0, var_1, var_0, var_0, var_1, var_0)
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_

# Generated at 2022-06-25 08:03:51.738725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)

    tmp_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 08:03:53.510837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 08:03:54.999193
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert test_case_0() == True

# unit test for `run` method of class ActionModule

# Generated at 2022-06-25 08:03:59.384039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # check for value of instance var:
        # _supports_check_mode : True
        assert isinstance(action_module_0._supports_check_mode, bool)
        assert action_module_0._supports_check_mode == True

        # check for value of instance var:
        # _supports_async : True
        assert isinstance(action_module_0._supports_async, bool)
        assert action_module_0._supports_async == True

        print("\n\n Constructor of class 'ActionModule' executed succesfully: \n\n")
    except Exception:
        print("Constructor of class 'ActionModule' failed")

# Generated at 2022-06-25 08:04:07.465455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_0 = var_0
    var_0 = var_0
    var_0 = var_0
    var_0 = var_0
    var_0 = var_0
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    var_3 = action_module_0.run(var_1, var_2)
    print("Ran ActionModule")

# Generated at 2022-06-25 08:04:16.192341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    task_vars_1 = None
    test_case_0(var_1, task_vars_1)

# Generated at 2022-06-25 08:04:24.924483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1
    var_args = {'register': 'result', 'name': 'git', 'use': 'yum3'}
    var_task_vars = {'ansible_pkg_mgr': 'yum', 'ansible_all_ipv4_addresses': '10.10.34.88'}
    action_module_0 = ActionModule(var_args, var_task_vars)
    var_return = action_module_0.run()
    assert var_return == {'ansible_facts': {}, 'ansible_module_per_host': {'10.10.34.88': 'yum'}, 'changed': False, 'msg': '', 'rc': 0}


# Generated at 2022-06-25 08:04:29.916498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        test_case_1()
    except IOError as err:
        print(err)
    except ValueError as err:
        print(err)

# Generated at 2022-06-25 08:04:39.767147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # default values used in constructor
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    action_module_1 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)
    print(action_module_1)
    # invalid values for constructor
    # var_1 = 0
    # var_2 = 0
    # var_3 = 0
    # var_4 = 0
    # var_5 = 0
    # var_6 = 0
    # action_module_2 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)
    # print(action_module_2)
    #

# Generated at 2022-06-25 08:04:41.489196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if (not (isinstance(var_0, ActionModule))):
        raise AssertionError()
    if (not (var_0._task is not None)):
        raise AssertionError()


# Generated at 2022-06-25 08:04:48.245814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = type('',(),{})()
    var_0.delegate_to = None
    var_0.delegate_facts = None
    var_0.args = {}
    var_0.async_val = None
    var_0.run = test_case_0
    var_1 = None
    module_name = 'ansible.legacy.yum'
    module = __import__(module_name)
    res = module.action_plugin(module_name)
    print(res)

# Generated at 2022-06-25 08:04:51.808131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = action_module_0.run()
    return var_1

# Generated at 2022-06-25 08:04:57.995271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    # Invoke constructor of class ActionModule
    action_module_1 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)
    # Verify member variables of class object 'action_module_1'
    assert action_module_1._connection == None
    assert action_module_1._play_context == None
    assert action_module_1._task_vars == None
    assert action_module_1._loader == None
    assert action_module_1._templar == None
    assert action_module_1._shared_loader_obj == None
    assert action_module_

# Generated at 2022-06-25 08:05:03.427087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # var_1 = None
    action_module_0 = ActionModule(None, None)
    # var_0 = {'yum_param': 'versionlock', 'confirm': False, 'name': ['kernel-2.6.32-220.23.1.el6'], 'state': 'present'}
    var_0 = {}
    action_module_0.run(None, var_0)


if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 08:05:04.508056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-25 08:05:13.496332
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FIXME: mock the _execute_module to return the needed values for the test
    action_module_0 = ActionModule()
    assert True

# Generated at 2022-06-25 08:05:16.694863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result_0 = action_module_0.run()


# Generated at 2022-06-25 08:05:20.146362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule()
    if action_module_2 == None:
        print("test_ActionModule was successful")
    else:
        raise Exception("test_ActionModule was unsuccessful")


# Generated at 2022-06-25 08:05:21.894982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None
    assert action_module.run is not None

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:05:23.781188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert action_module_1.run() == dict(skipped=True, skipped_reason="No yum/dnf facts or use/use_backend arg specified")


# Generated at 2022-06-25 08:05:32.235403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = {}

# Generated at 2022-06-25 08:05:36.383757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test 1: Constructor test case")
    action_module_1 = ActionModule()
    print("Passed")

# Unit test to test the run() method of ActionModule class

# Generated at 2022-06-25 08:05:39.856327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    try:
        action_module_0.run()
    except Exception as e:
        pass

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 08:05:49.891873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._task.args = {}
    action_module_1._task.args["use"] = "yum"
    action_module_1._execute_module = lambda _: {"ansible_facts": {'pkg_mgr': "yum4"}}
    assert action_module_1.run() == {'ansible_facts': {'pkg_mgr': 'yum4'}, 'failed': False}



# Generated at 2022-06-25 08:05:56.579554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule()

  # Test with setting delegate_to
  action_module_0._task.delegate_to = 'some-value'
  action_module_0._task.args = {'use_backend': 'some-other-value'}

  # Test with raising exception
  #assert action_module_0.run() == 'This is exception'

# Generated at 2022-06-25 08:06:14.239153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create object of class ActionModule
    action_module_0 = ActionModule()

    # define valid inputs
    result = None
    tmp = None
    task_vars = None

    # define expected outputs
    result_expected = None
    msg_expected = None
    ansible_facts_expected = None

    # act
    result_actual = action_module_0.run(tmp, task_vars)

    # assert
    assert result_actual != result_expected
    assert msg_expected not in result_actual
    assert ansible_facts_expected not in result_actual

# Generated at 2022-06-25 08:06:20.733631
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    assert (isinstance(action_module_0, ActionBase) == True)
    assert (action_module_0._supports_check_mode == True)
    assert (action_module_0._supports_async == True)
    assert (len(action_module_0._task.args) == 0)
    assert (action_module_0._task.delegate_to == None)
    assert (action_module_0._task.delegate_facts == True)
    assert (action_module_0._task.async_val == None)
    assert (action_module_0._task.async_days == None)
    assert (action_module_0._task.async_hours == None)

# Generated at 2022-06-25 08:06:29.537676
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule()
    action_module_1.set_loader(MockLoader())
    action_module_1._task = MockTask()
    action_module_1._task.args = {'use_backend': 'auto'}
    action_module_1._task.delegate_to = 'localhost'
    action_module_1._task.delegate_facts = True
    action_module_1._task.async_val = False
    action_module_1._shared_loader_obj = None
    action_module_1._templar = MockTemplar()
    action_module_1.run()

    action_module_2 = ActionModule()
    action_module_2.set_loader(MockLoader())
    action_module_2._task = MockTask()
    action_module

# Generated at 2022-06-25 08:06:37.652164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case with the following mock arguments and expected return:
    # task_args = {'use': 'yum'}
    # task_vars = {'ansible_facts': {}}
    # expected_result = {'failed': False, 'changed': False, 'rc': 0, 'ansible_facts': {}, 'invocation': {'module_name': 'ansible.legacy.yum', 'module_args': {'use': 'yum'}}}
    task_args = {'use': 'yum'}
    task_vars = {'ansible_facts': {}}

# Generated at 2022-06-25 08:06:40.338437
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    action_module_0.run()



# Generated at 2022-06-25 08:06:47.326595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '_execute_module')
    assert hasattr(ActionModule, '_remove_tmp_path')
    assert hasattr(ActionModule, '_low_level_execute_command')
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_display')
    assert hasattr(ActionModule, '_templar')
    assert hasattr(ActionModule, '_shared_loader_obj')
    assert hasattr(ActionModule, '_task')
    assert hasattr(ActionModule, '_supports_async')
    assert hasattr(ActionModule, '_supports_check_mode')
    assert hasattr(ActionModule, '_shared_loader_obj')
    assert hasattr(ActionModule, '_task')

# Generated at 2022-06-25 08:06:54.326985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    #test_module_0 = 'auto'
    test_module_0 = 'yum'
    test_tmp_0 = None
    test_task_vars_0 = dict(
        ANSIBLE_MODULE_ARGS=dict(name=dict(type=str), state=dict(type=str))
    )
    expect_result_0 = dict()
    result_0 = action_module_0.run(test_module_0, test_tmp_0, test_task_vars_0)
    #assert (result_0 == expect_result_0)
    assert (False)

# Generated at 2022-06-25 08:06:58.135321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module._shared_loader_obj is not None)
    assert(action_module.TRANSFERS_FILES == False)
    action_module.run()

# Generated at 2022-06-25 08:07:01.392769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
#
#     assert result.get('failed') is False
#     assert result.get('msg') == "Able to run the constructor of ActionModule"
#     print("Able to run the constructor of ActionModule")


# Generated at 2022-06-25 08:07:02.175557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 08:07:26.178567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not (action_module_0 == None)

# Generated at 2022-06-25 08:07:31.144753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task.args = {'use': 'auto'}
    action_module._task.delegate_to = None
    action_module._task.delegate_facts = True
    action_module._task.async_val = 0
    action_module._connection = {}
    action_module._shared_loader_obj = {}
    action_module._shared_loader_obj.module_loader = {}
    action_module._shared_loader_obj.module_loader.has_plugin = lambda x: False
    action_module._templar = {}
    action_module._templar.template = lambda x: 'auto'
    action_module._execute_module = lambda x, y, z: {'ansible_facts': {'pkg_mgr': 'yum'}}

# Generated at 2022-06-25 08:07:35.017339
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = dict()
    result = dict()
    tmp = Any()
    action_module = ActionModule()
    result = action_module.run(tmp, task_vars)
    return result

# Generated at 2022-06-25 08:07:36.840658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Simple test for valid input
    action_module_0 = ActionModule()
    output_0 = action_module_0.run()
    assert output_0 == {}

# Generated at 2022-06-25 08:07:38.836097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_action = ActionModule()
    assert module_action._supports_check_mode == True
    assert module_action._supports_async == True



# Generated at 2022-06-25 08:07:40.411846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Executing constructor of class ActionModule
    action_module_0 = ActionModule()
    action_module_1 = ActionModule(action_name='action_name_0')
    # Cleanup
    del action_module_0
    del action_module_1


# Generated at 2022-06-25 08:07:48.246329
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:07:49.673588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert action_module_1.run() == None

# Generated at 2022-06-25 08:07:51.632914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert action_module_0.__class__ == 'ActionModule'
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-25 08:08:01.314679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars = {}
    action_module_0._task.async_val = None
    action_module_0._task.delegate_to = None
    action_module_0._task.delegate_facts = None
    action_module_0._task.args = {}

    try:
        import ansible.utils.display
        ansible.utils.display.display = MagicMock()
    except:
        pass

    try:
        import ansible.plugins.action
        ansible.plugins.action.ActionBase = MagicMock()
    except:
        pass

    try:
        import ansible.errors
        ansible.errors.AnsibleActionFail = Exception
    except:
        pass


# Generated at 2022-06-25 08:08:29.629502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    print(action_module_0.run())

# Generated at 2022-06-25 08:08:32.096912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Some test to check that check_mode and async work
    assert True

# Generated at 2022-06-25 08:08:34.419404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run()
    assert not result


# Generated at 2022-06-25 08:08:35.252610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the run method under normal conditions
    pass

# Generated at 2022-06-25 08:08:42.848076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1 run
    bytes_0 = None
    float_0 = 4091.21
    tuple_0 = (bytes_0, float_0, bytes_0)
    tuple_1 = (tuple_0,)
    int_0 = 9
    float_1 = -862.0
    bool_0 = False
    float_2 = -4017.308976
    bool_1 = True
    str_0 = 'L\tsu'
    set_0 = {bool_1, str_0, bool_0}
    action_module_0 = ActionModule(tuple_1, int_0, float_1, bool_0, float_2, set_0)
    var_0 = action_module_0.run()

    # Test 2 other implementations



# Generated at 2022-06-25 08:08:43.815601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:08:48.531537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    float_0 = 4091.21
    tuple_0 = (bytes_0, float_0, bytes_0)
    tuple_1 = (tuple_0,)
    int_0 = 9
    float_1 = -862.0
    bool_0 = False
    float_2 = -4017.308976
    bool_1 = True
    str_0 = 'L\tsu'
    set_0 = {bool_1, str_0, bool_0}
    action_module_0 = ActionModule(tuple_1, int_0, float_1, bool_0, float_2, set_0)
    var_0 = action_module_0.run()
    return var_0

# Generated at 2022-06-25 08:08:58.835026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    float_0 = 4091.21
    tuple_0 = (bytes_0, float_0, bytes_0)
    tuple_1 = (tuple_0,)
    int_0 = 9
    float_1 = -862.0
    bool_0 = False
    float_2 = -4017.308976
    bool_1 = True
    str_0 = 'L\tsu'
    set_0 = {bool_1, str_0, bool_0}
    action_module_0 = ActionModule(tuple_1, int_0, float_1, bool_0, float_2, set_0)

# Generated at 2022-06-25 08:09:01.505331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(tuple_0, int_0, float_1, bool_0, float_2, set_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

# Generated at 2022-06-25 08:09:02.752646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as exc:
        print("Exception : %s" % exc)

test_ActionModule()

# Generated at 2022-06-25 08:10:01.778297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # dnf vs yum test 1
    # don't specify any backend, accuracy is based on host facts
    # expected: use yum module
    module_args = {
        'name': 'httpd',
    }
    host_facts = {
        'ansible_pkg_mgr': 'yum',
    }
    tmp = None
    task_vars = {
        'hostvars': {
            None: host_facts
        }
    }
    action_module_0 = ActionModule(module_args, None, None, False, -34.054980, ':')
    var_0 = action_module_0.run(tmp, task_vars)
    assert(var_0['module_name'] == 'ansible.legacy.yum')

# Generated at 2022-06-25 08:10:08.581605
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:10:10.293027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except:
        assert False
    print("ActionModule method run passed unit test")
    return True

# Generated at 2022-06-25 08:10:20.459917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    float_0 = 4091.21
    tuple_0 = (bytes_0, float_0, bytes_0)
    tuple_1 = (tuple_0,)
    int_0 = 9
    float_1 = -862.0
    bool_0 = False
    float_2 = -4017.308976
    bool_1 = True
    str_0 = 'L\tsu'
    set_0 = {bool_1, str_0, bool_0}
    action_module_0 = ActionModule(tuple_1, int_0, float_1, bool_0, float_2, set_0)
    var_0 = action_module_0.run()
    assert var_0 is not None


# Generated at 2022-06-25 08:10:21.407032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:10:28.271171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    float_0 = 4091.21
    tuple_0 = (bytes_0, float_0, bytes_0)
    tuple_1 = (tuple_0,)
    int_0 = 9
    float_1 = -862.0
    bool_0 = False
    float_2 = -4017.308976
    bool_1 = True
    str_0 = 'L\tsu'
    set_0 = {bool_1, str_0, bool_0}
    action_module_0 = ActionModule(tuple_1, int_0, float_1, bool_0, float_2, set_0)
    bytes_1 = '~'

# Generated at 2022-06-25 08:10:37.629222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    float_0 = 4091.21
    tuple_0 = (bytes_0, float_0, bytes_0)
    tuple_1 = (tuple_0,)
    int_0 = 9
    float_1 = -862.0
    bool_0 = False
    float_2 = -4017.308976
    bool_1 = True
    str_0 = 'L\tsu'
    set_0 = {bool_1, str_0, bool_0}
    action_module_0 = ActionModule(tuple_1, int_0, float_1, bool_0, float_2, set_0)
    assert(action_module_0.tmp == tuple_1)
    assert(action_module_0.task_vars == int_0)

# Generated at 2022-06-25 08:10:43.578352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')
    bytes_0 = None
    float_0 = 4091.21
    tuple_0 = (bytes_0, float_0, bytes_0)
    tuple_1 = (tuple_0,)
    int_0 = 9
    float_1 = -862.0
    bool_0 = False
    float_2 = -4017.308976
    bool_1 = True
    str_0 = 'L\tsu'
    set_0 = {bool_1, str_0, bool_0}
    action_module_0 = ActionModule(tuple_1, int_0, float_1, bool_0, float_2, set_0)
    assert action_module_0._supports_async
    assert action_module_0.ABSOLUTE_TIME

# Generated at 2022-06-25 08:10:47.286929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  t = ActionModule()
  t.run()

# Generated at 2022-06-25 08:10:48.110860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()