

# Generated at 2022-06-25 08:02:29.781413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for run part 1
    try:
        list_0 = None
        str_0 = 'Eeo'
        set_0 = {str_0}
        int_0 = 256
        action_module_0 = ActionModule(list_0, str_0, set_0, int_0, int_0, list_0)
        tmp_0 = 'Ce'
        dict_0 = {}
        action_module_0.run(tmp=tmp_0, task_vars=dict_0)
    except AnsibleActionFail:
        pass
    # Test for run part 2

# Generated at 2022-06-25 08:02:31.100075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 08:02:33.345403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    # TODO: Create unit test for method run of class ActionModule
    raise Error('Test Not Implemented')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:02:34.358218
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Case 0
    test_case_0()



# Generated at 2022-06-25 08:02:35.598443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    function_0 = action_module_0.run()


# Generated at 2022-06-25 08:02:37.281894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, frozenset({}), 10, None, None)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 08:02:41.819297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = None
    str_0 = 'Eeo'
    set_0 = {str_0}
    int_0 = 256
    action_module_0 = ActionModule(list_0, str_0, set_0, int_0, int_0, list_0)


# Generated at 2022-06-25 08:02:51.414448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        list_0 = None
        str_0 = 'Eeo'
        set_0 = {str_0}
        int_0 = 256
        action_module_0 = ActionModule(list_0, str_0, set_0, int_0, int_0, list_0)
        dict_0 = dict()
        dict_0['ansible_facts'] = dict()
        dict_0['ansible_facts']['pkg_mgr'] = "yum"
        action_module_0.run(list_0, dict_0)
    except AnsibleActionFail as e:
        assert isinstance(e, AnsibleActionFail)


# Generated at 2022-06-25 08:02:52.560475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:02:54.487571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print("----test for constructor of class ActionModule is finished")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:09.332449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 08:03:14.476931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  var_0 = None
  var_1 = None
  obj = ActionModule(var_0)
  res = obj.run(tmp=var_1)
  assert res  == None

#   These three tests need to be run with a pkg_mgr = package manager. i.e. rpm or dnf.
#   Below is a ansible.cfg file to run this test with dnf.
#   [inventory]
#   enable_plugins = ansible_tower, host_list, script, yaml, ini
#   [defaults]
#   inventory = /home/dmcginnis/hosts
#   transport = paramiko
#   host_key_checking = False
#   deprecation_warnings = False
#   forks = 5
#   host_vars_plugins = vars_plugins
#  

# Generated at 2022-06-25 08:03:19.396396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    output = None

    #Case 0: _task.args is None
    # expected output:
    # false, 'Could not detect which major revision of yum is in use, which is required to determine module backend.' +
    #        ' You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})'

    am = ActionModule()
    am._task.args = None
    output = am.run()

    assert (output['failed'] == True)
    assert (output['msg'] == "Could not detect which major revision of yum is in use, which is required to determine module backend." +
                             "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")

    #

# Generated at 2022-06-25 08:03:24.689268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_0 = ActionBase()
    var_1 = ActionModule(var_0)


# Generated at 2022-06-25 08:03:28.119747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule(var_0)


# Generated at 2022-06-25 08:03:28.862711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None


# Generated at 2022-06-25 08:03:33.820335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    var_1 = ActionModule()
    return var_1


# Generated at 2022-06-25 08:03:38.916243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {"auto": "a", "backend": "b"}
    var_2 = {"use": "yum", "use_backend": "dnf"}
    var_3 = {"use": "yum", "use_backend": "yum4"}

    # test case for constructor
    x = ActionModule()
    print(ActionModule)
    print(var_1['auto'])
    print(var_1['backend'])
    print(var_2['use'])
    print(var_2['use_backend'].capitalize())
    print(var_3['use'])
    print(var_3['use_backend'].capitalize())


# Generated at 2022-06-25 08:03:41.886780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0
    var_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # assert var_0.TRANSFERS_FILES == False, "Failed to assert var_0.TRANSFERS_FILES == False"

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 08:03:46.095703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    # Run method of class ActionModule
    var_0 = ActionModule.run(var_0)
    assert var_0 == None
    
    

# Generated at 2022-06-25 08:03:55.889483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # Testing type
        test = isinstance(var_0, type(None))
        assert test

        # Testing
        try:
            # Calling method 'ActionModule.run' of type 'ActionModule'
            var_1 = ActionModule.run(var_0)
            # Testing
            assert var_1 is None

        except Exception as var_2:
            # Testing
            assert False

    except Exception as var_3:
        # Testing
        assert False

# Generated at 2022-06-25 08:03:57.383800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    obj_3 = ActionModule(var_1, var_2)
    test_case_0()

# Generated at 2022-06-25 08:03:59.725975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    def test_run_0():
        var_0 = None

if __name__ == "__main__":
    import sys
    del sys.argv[1:]
    if "--test" in sys.argv:
        import doctest
        doctest.testmod()
    else:
        test_case_0()

# Generated at 2022-06-25 08:04:05.349091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None

    obj = ActionModule(var_0, var_1)
    test_case_0()



# Generated at 2022-06-25 08:04:11.225233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {'use_backend': 'auto', 'key_value': '=', 'register': 'result', 'with_items': [1, 2, 3], 'name': 'ActionModule', 'use': 'auto', 'state': 'present', 'when': '{"search_repo": "epel"}'}
    var_1 = ActionModule(var_1)
    var_1 = var_1.run()
    assert var_1 == None


# Generated at 2022-06-25 08:04:24.163946
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:04:28.067185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:04:31.606995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None

    var_1 = ActionModule()
    var_0 = var_1.run(var_0)

    test_case_0()
    return 0

test_case_0()
if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 08:04:36.113483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_0 = ActionModule()
    var_1 = var_0.run()

# Generated at 2022-06-25 08:04:39.565095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()
    var_1.run(var_0)


# Generated at 2022-06-25 08:04:58.837167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule

    var_0 = {}
    var_0 = {}
    var_1 = None
    var_2 = None
    var_2 = {u'use_backend': u'dummy'}
    var_0 = ActionModule(var_1, var_2, var_0)
    var_0.run()

# Generated at 2022-06-25 08:05:00.659476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(var_0)
    return obj


# Generated at 2022-06-25 08:05:06.584292
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:05:13.603905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    var_2 = None
    var_3 = None
    test_case_0()
    var_4 = var_1.run(var_2, var_3)
    return var_4

# Generated at 2022-06-25 08:05:17.116717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as inst:
        assert False
        print(inst)

test_ActionModule()

# Generated at 2022-06-25 08:05:23.186316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        if var_0:
            display.vvvv("We have a var")
        else:
            display.vvvv("We don't have a var")
    except: pass
    try:
        assert False
    except AssertionError as e:
        display.vvvv("AssertionError raised")
    except:
        try:
            if var_0:
                display.vvvv("We have a var")
            else:
                display.vvvv("We don't have a var")
        except: pass
        try:
            assert False
        except AssertionError as e:
            display.vvvv("AssertionError raised")
        except: pass

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 08:05:28.804595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    action_module = {'use_backend': 'yum4'}
    task_vars = {'pkg_mgr': 'yum4', 'ansible_pkg_mgr': 'yum4'}
    tmp = None
    assert module.run(tmp, task_vars) == {'failed': False}

#Unit test for method test_case_0 of class ActionModule

# Generated at 2022-06-25 08:05:32.075240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    test_case_0()


# Generated at 2022-06-25 08:05:41.433492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    if (var_1 is None):  # Passed in by the caller
        var_1 = None
    if (var_2 is None):  # Passed in by the caller
        var_2 = None
    var_0 = ActionModule(var_0, var_1)
    var_0.run(var_1, var_2)
    # All checks passed
    # All checks passed
    # All checks passed
    # All checks passed
    # All checks passed
    return

# Generated at 2022-06-25 08:05:51.694642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_object = ActionModule()
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
   

# Generated at 2022-06-25 08:06:17.912520
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    target = ActionModule()

    target.run()

# Generated at 2022-06-25 08:06:21.475312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    test_case_0()
    var_0 = "test_value_0"
    var_1 = "test_value_1"
    var_2 = "test_value_2"
    var_3 = "test_value_3"
    var_4 = "test_value_4"



# Generated at 2022-06-25 08:06:22.593076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:06:26.668818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = yum.ActionModule('ActionModule', var_0, 'AutoDetect')
    var_0.run(var_0)


# Generated at 2022-06-25 08:06:31.341594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize instance of ActionModule class
    var_0 = ActionModule()

    assert var_0


# Generated at 2022-06-25 08:06:33.562416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 08:06:34.734046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct the object
    ret_object = ActionModule()
    assert ret_object != None


# Generated at 2022-06-25 08:06:35.728631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 08:06:45.495149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 08:06:46.103213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 08:07:44.627015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    x = 0

    action_base = ActionModule(connection=var_1, new_stdin=var_2, task_queue_manager=var_3, variables=var_4)
    action_base.display = var_5

    y = []


    if x <= y[0]:
        action_base.connection = (var_1 + 2)
    else:
        var_5 = 's'

    var_1 = action_base.run(tmp=(var_1 / 2), task_vars=var_2)

    action_base.display = var_5


# Generated at 2022-06-25 08:07:46.366052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0._task.args['name'] = "zsh"
    var_0._task.args['state'] = "latest"
    with pytest.raises(AnsibleActionFail):
        var_0.run()


# Generated at 2022-06-25 08:07:46.883542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 08:07:48.224422
# Unit test for constructor of class ActionModule
def test_ActionModule():

  #Create a new instance of class ActionModule
  test_action_module = ActionModule()



# Generated at 2022-06-25 08:07:49.645928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule = ActionModule()
    assert obj_ActionModule != None


# Generated at 2022-06-25 08:07:59.684828
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testing note:
    # Due to how pytest works when we specify a test case such as
    # test_ActionModule_run, pytest will only run that specfic test case
    # ignoring others, so we will explicitly call other test cases when
    # needed
    ###########################################################################
    # Mock unit test for module run method
    ###########################################################################
    def mock_run(self, tmp=None, task_vars=None):
        # Instantiate the class being tested, and assign mock values to
        # all attributes. The test case will then have access to these
        # attributes.
        mock_obj = ActionModule()
        mock_obj._supports_check_mode = True
        mock_obj._supports_async = True
        mock_obj._shared_loader_obj = None
        mock_obj._templar

# Generated at 2022-06-25 08:08:04.673083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
# Test case class YumHandler

# Generated at 2022-06-25 08:08:05.885701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)


# Generated at 2022-06-25 08:08:06.639547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()


# Generated at 2022-06-25 08:08:08.365697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)


# Generated at 2022-06-25 08:09:07.053217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = '>g\x0b,Ai[E+c-s9#'
    int_0 = -2731
    float_0 = -3737.8
    bool_0 = False
    set_0 = {bool_0, int_0, int_0}
    tuple_2 = (float_0, tuple_0, int_0, set_0)
    tuple_3 = (tuple_1,)
    tuple_4 = (int_0,)
    tuple_5 = (int_0, tuple_1)

# Generated at 2022-06-25 08:09:11.650102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = 'j+\x0c*\xc5\xb6'
    int_0 = -2145
    str_1 = '_T\x03'
    float_0 = 4961.0
    bool_0 = False
    set_0 = {float_0, int_0, bool_0}
    action_module_0 = ActionModule(tuple_1, str_0, int_0, str_1, float_0, set_0)

# Generated at 2022-06-25 08:09:17.590049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print ("Testing run")
    tuple_0 = (15233.9671924, str_1, str_2, int_0, 5987.68, bool_1, bool_0, )
    str_0 = '`'
    str_1 = 'u.\x1dfD#\x0bL'
    str_2 = '\x0c\x18'
    int_0 = -6414
    float_0 = -1148.54
    bool_0 = False
    bool_1 = True
    set_0 = {tuple_0, int_0, bool_0, bool_0, }
    action_module_0 = ActionModule(str_0, str_1, int_0, str_0, float_0, set_0)
    var_0 = action_module_0.run

# Generated at 2022-06-25 08:09:24.994848
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_AnsibleActionFail_0 = mock.Mock(side_effect=AnsibleActionFail)
    mock_AnsibleActionFail_1 = mock.Mock(side_effect=AnsibleActionFail)
    mock_AnsibleActionFail_2 = mock.Mock(side_effect=AnsibleActionFail)
    mock_AnsibleActionFail_3 = mock.Mock(side_effect=AnsibleActionFail)
    mock_AnsibleActionFail_4 = mock.Mock(side_effect=AnsibleActionFail)
    mock_AnsibleActionFail_5 = mock.Mock(side_effect=AnsibleActionFail)
    assert test_case_0 == None

# Unit test execution
if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 08:09:34.668609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = '.'
    int_0 = -1345
    float_0 = -17.0
    bool_0 = False
    set_0 = {tuple_0, bool_0}
    set_1 = {tuple_0, bool_0}
    set_2 = {tuple_1}
    dict_0 = {str_0: tuple_0}
    dict_1 = {str_0: tuple_0}
    dict_2 = {str_0: tuple_0}
    dict_3 = {str_0: tuple_0}
    dict_4 = {str_0: tuple_0}
    dict_5 = {str_0: tuple_0}
    dict_6 = {str_0: tuple_0}
    dict

# Generated at 2022-06-25 08:09:38.639344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = '>g\x0b,Ai[E+c-s9#'
    int_0 = -2731
    float_0 = -3737.8
    bool_0 = False
    set_0 = {bool_0, int_0, int_0}
    action_module_1 = ActionModule(tuple_1, str_0, int_0, str_0, float_0, set_0)
    var_3 = action_run(tuple_0)

# Generated at 2022-06-25 08:09:47.330944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = '?[c;A3-s\x1eTd\x0c'
    int_0 = -857
    str_1 = 'k-s'
    float_0 = 4038.1
    bool_0 = False
    set_0 = {int_0, bool_0, str_1}
    action_module_0 = ActionModule(tuple_1, str_0, int_0, str_0, float_0, set_0)

    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True



# Generated at 2022-06-25 08:09:56.168347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_2 = ()
    tuple_3 = ()
    str_1 = '>g\x0b,Ai[E+c-s9#'
    int_1 = -2731
    float_1 = -3737.8
    bool_1 = False
    set_1 = {bool_1, int_1, int_1}
    action_module_1 = ActionModule(tuple_3, str_1, int_1, str_1, float_1, set_1)


# Generated at 2022-06-25 08:10:05.138868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_2 = ()
    str_5 = 'S/G\x1f\x1d'
    int_0 = 7608
    # String and int are not hashable, so we cannot create a set with them
    set_0 = {tuple_2, tuple_0}
    action_module_0 = ActionModule(tuple_2, str_5, int_0, str_5, 0.0038883244646665247, set_0)



# Generated at 2022-06-25 08:10:12.174635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = '>g\x0b,Ai[E+c-s9#'
    int_0 = -2731
    float_0 = -3737.8
    bool_0 = False
    set_0 = {bool_0, int_0, int_0}
    action_module_0 = ActionModule(tuple_1, str_0, int_0, str_0, float_0, set_0)


# Generated at 2022-06-25 08:12:04.165355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = 'b4\x1eH"\x0b\x0b'
    int_0 = -2731
    str_1 = 'm\x20\x10\x12Q\r\r'
    float_0 = -3737.8
    bool_0 = False
    set_0 = {bool_0, int_0, int_0}
    action_module_0 = ActionModule(tuple_1, str_0, int_0, str_1, float_0, set_0)
    assert isinstance(action_module_0, ActionModule)
    test_case_0()


# Generated at 2022-06-25 08:12:09.280487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'\x1f\t\x1d\x1c\x13\x06w', '\x04\x16\x03\x11\x1a\x1d\x1c\x0e\x19\x12\x06'}
    action_module_0 = ActionModule(set_0, '\x1a\x16\x11\x0b\x07\x19\x07', -3244, 'n\x18\x14\x06\x0e\x19\x1a\x05\x0fn\x0e\x07', -1215.6, set_0)
    str_0 = '\x0b\x15\x14\x06\x13\x1a\x1f\x1f'
    int

# Generated at 2022-06-25 08:12:17.996778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = ()
    str_0 = '\tDv\tT\x0c+f\x17\t'
    int_0 = -1244
    str_1 = '\x0e\x12\x1f\x14+\x18\x0f'
    float_0 = -3049.1
    bool_0 = False
    set_0 = {float_0, int_0, bool_0}
    action_module_0 = ActionModule(tuple_1, str_0, int_0, str_1, float_0, set_0)
    assert(action_module_TRANSFERS_FILES == False)
    assert(action_module_0._supports_check_mode == True)