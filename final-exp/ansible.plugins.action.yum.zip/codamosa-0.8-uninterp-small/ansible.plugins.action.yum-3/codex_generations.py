

# Generated at 2022-06-25 08:02:23.892274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule(filter='filter')
    tmp, task_vars = 'tmp', 'task_vars'
    var_0 = obj.run(tmp, task_vars)
    assert var_0 == None, var_0


# Generated at 2022-06-25 08:02:27.104558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialise test case
    list_0 = [bytes_0]
    str_0 = "Cc%1;X"
    # Perform test of method run
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:02:31.434103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf9\xde\xc8ib'
    list_0 = []
    str_0 = "gqr9{%7'~'Gb"
    dict_0 = {list_0: list_0, list_0: list_0, str_0: list_0, str_0: bytes_0}

    class Class_0:
        def _execute_module(self):
            pass


    action = ActionModule()
    action._execute_module = lambda: test_case_0()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()
    action.run()

# Generated at 2022-06-25 08:02:32.129597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # @TODO - write test
  assert true

# Generated at 2022-06-25 08:02:37.107859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf9\xde\xc8ib'
    list_0 = []
    str_0 = "gqr9{%7'~'Gb"
    dict_0 = {list_0: list_0, list_0: list_0, str_0: list_0, str_0: bytes_0}

    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:02:38.417246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 08:02:38.807320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 08:02:40.719025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule = ActionModule()
    test_case_0()
    return


# Generated at 2022-06-25 08:02:42.454121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert act_mod is not None


# Generated at 2022-06-25 08:02:49.896924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    bytes_0 = b'\xf9\xde\xc8ib'
    list_0 = []
    str_0 = "gqr9{%7'~'Gb"
    dict_0 = {list_0: list_0, list_0: list_0, str_0: list_0, str_0: bytes_0}

    # Create a new Task, with a Block, with your action plugin
    task = Task()
    block = Block()
    block.v2_block_tasks = [task]
    task.action = ActionModule()

    # Create a task that has some options enabled
    task.action.task = task
    task.args = dict_0

    # Load dependencies from a temp dir
   

# Generated at 2022-06-25 08:03:08.854447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3
    str_0 = 'q3#\x15\x12\x8d\x1c\x7f\x1e\x8c\x9f\x07v\x0f\x8c\x1dF'
    str_1 = '\x16:\x957$f\xa3\x8f\xefG\xfdl^\xc3\xe2\xf2\xf3\x9d\x19\x14\x12\x08\\3\x05|\x1d\x00\x9b\x1b\x13\x1b\x90'
    list_0 = [str_0, int_0, str_0, str_1, str_0, str_0]

# Generated at 2022-06-25 08:03:09.324457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 08:03:15.338476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 08:03:21.271029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    # Unit test for property 'supports_check_mode'
    action_module_0._supports_check_mode = not True
    # Unit test for

# Generated at 2022-06-25 08:03:28.302582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 80
    str_0 = '7V\x0bv\x15"W\x1a\x0c'
    list_0 = [str_0, str_0]
    bytes_0 = b'z\xe9\xb1\x18\t\x8d#\x03\xff\x11\x1c\x0e\x9c\xc1'
    float_0 = 0.75
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    action_module_0.action_run()


# Generated at 2022-06-25 08:03:35.447632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -14.38
    str_0 = '\x1aY\xa7\xdb\x11\x10C\xac\x0e\x9c\n\x8a\x93\x91\x1e>|\x8f\x93\xce\xb1\x8e\x13\x98\x05\xfa\x8a\x11'

# Generated at 2022-06-25 08:03:39.728391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:03:46.479816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object instance of class ActionModule
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert var_0 is None, 'Expect: None\nActual: %s' % var_0

if __name__ == "__main__":
    import sys
    test_case_0()
    test_ActionModule()
    sys.exit(0)

# Generated at 2022-06-25 08:03:54.625720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    # Assert statements for constructor of class ActionModule
    assert action_module_0._connection == arg_0
    assert action_module_0._play_context == arg_1
    assert action_module_0._loader == arg_2
    assert action_module_0._templar == arg_3
    assert action_module_0._shared_loader_obj == arg_4
    assert action_module_0._action_loader == arg_5
    # Assert statements for method run
    assert var_0 == res_0

# Generated at 2022-06-25 08:03:55.443601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert 0 == 0

# Generated at 2022-06-25 08:04:14.248550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    force_0 = 1.566
    tuple_0 = ('ba', 'tuple_1', (str('tuple_0'), str_0, str_0))
    bytes_0 = b'\xdd\xc3\x91\xb3\xd5\x96\x8f\xaf\x1c^\xb1\x8f\x9b\x85\xd1\xfc\x8f\xea'
    other_0 = ('ic', float_0, '\xfc\xad\xbc\x93\xbc\xcf', '\xbc\xf4\xc4\xbd\xf9\x86\xcb\xf8')
    var_0 = test_case_0()
    int_0 = 438610

# Generated at 2022-06-25 08:04:24.409640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 12
    str_0 = 'Ym\x0c3qg[\x0b\x0c\x7f\x7f'
    list_0 = [int_0, str_0, int_0, int_0]
    float_0 = -1895.34
    bytes_0 = b'\xd4\x99\xb0\xeb\xd4\xa8\xbe\xe2\xfe\xd2b\xfe\x89x\x9b\xae'
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    var_0 = action_run()



# Generated at 2022-06-25 08:04:34.109104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation of class ActionModule
    # On instantiation of class ActionModule, all variables should be initialized with default values

    # init method for var_0
    int_0 = 6
    # init method for var_1
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    # init method for var_12
    str_1 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    # init method for var_13
    list_0 = [str_0, int_0, str_0, str_0]
    # init method for var_14

# Generated at 2022-06-25 08:04:40.441798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 15
    str_0 = '9'
    list_0 = [str_0, int_0, int_0, str_0]
    bytes_0 = b'\x18\xdd\xb5\xf1\xcc\xad\xae\xcd\xac\x07'
    float_0 = -37.8517
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    var_0 = action_run()
    assert var_0 is None


# Generated at 2022-06-25 08:04:51.256508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3
    str_0 = 'DIXU6=\x0bR5\xc8)f\x95\x11'
    str_1 = '<k\xde\x03c\x9b\xdc\xf1K\x89sg'
    list_0 = [int_0, -850.46, -850.46, -850.46]
    bytes_0 = b'v\x8d\x15\x08\x95\x9f\x0bPd\xfd\x19\r\x0f\xee\xf0T\x1b'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_1, list_0, bytes_0, float_0)
    var

# Generated at 2022-06-25 08:04:57.492597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 6
    var_1 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    var_2 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    var_3 = [var_1, var_0, var_1, var_1]
    var_4 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    var_5 = -1605.466
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)


# Generated at 2022-06-25 08:05:02.604576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 7
    str_0 = "}'j"
    list_0 = [42, 86, 20, 84, 73, 86]
    bytes_0 = b'\x01\xbc\xfe\x8c\x9e\xf0\x00\xe2\xa2\xaa\x1e'
    float_0 = 689.724
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    action_module_0.run(int_0, list_0)


# Generated at 2022-06-25 08:05:09.159099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 9
    str_0 = '#j8\x1cohY\r@\x0c\x12\x17\x1b\x06'
    list_0 = [0, int_0, 1, int_0]
    bytes_0 = b'\xbb\xbeG\x8e\x8c\x99\xfa\xec\x8c\x1b\xaa\xda\x91I!\xd4'
    float_0 = -1357.42
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 08:05:09.826909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:05:18.755325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = '84m1'
    list_0 = [str_0, str_0, str_0, int_0]
    action_module_0 = ActionModule(0, 'J@^;w\x0b\x04\x19\x17\x0b', str_0, list_0, 'b{1m\x1a', -1.854e+307)
    var_0 = action_module_0.run()
    assert action_module_0._task.async_val is not None


# Generated at 2022-06-25 08:05:51.960356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# Testing for instance create
	action_module_0 = ActionModule()
	# Testing for method assert_type
	action_module_0.assert_type()
	# Testing for method add_path_info
	action_module_0.add_path_info()
	# Testing for method load_name_to_path_info
	action_module_0.load_name_to_path_info()
	# Testing for method get_path_info
	action_module_0.get_path_info()
	# Testing for method add_directory
	action_module_0.add_directory()
	# Testing for method find_plugin
	action_module_0.find_plugin()
	# Testing for method find_plugin_in_path
	action_module_0.find_plugin_in_path()
	# Testing for method find

# Generated at 2022-06-25 08:05:54.754922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == {'failed': True, 'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend.", 'msg': "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend"}

# Generated at 2022-06-25 08:06:03.311705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    return action_module_0


# Generated at 2022-06-25 08:06:12.235384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 6
    var_1 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    var_2 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    var_3 = [var_1, var_0, var_1, var_1]
    var_4 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    var_5 = -1605.466
    var_6 = 'auto'
    obj_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)


# Generated at 2022-06-25 08:06:17.798903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\n***Test for constructor of class ActionModule***')
    test_case_0()
    print('*'*50)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:06:26.265700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)

    # Check that all the required attributes exist
    assert hasattr(action_module_0, '_execute_module')

# Generated at 2022-06-25 08:06:34.790013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_2 = 3
    str_2 = 'N94f1PEU'
    list_2 = [str_2, int_2, str_2, str_2]
    bytes_2 = b'\xdb\x82\xcf'
    float_2 = 763.82
    action_module_2 = ActionModule(int_2, str_2, str_2, list_2, bytes_2, float_2)
    action_module_2.run(list_2, list_2)

# Generated at 2022-06-25 08:06:44.790198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)

# Generated at 2022-06-25 08:06:53.779009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 08:07:02.822145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 08:07:50.896610
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True

# Generated at 2022-06-25 08:07:51.851504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    

# Generated at 2022-06-25 08:08:01.420139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -5827
    str_0 = '~n6mxq\x05\x03\x06'
    list_0 = ['YW\x0bx#yb', -2140, '\x0b\x00\x03', '\x0b\x00\x03']
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -2737.4032
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    dict_0 = dict()

# Generated at 2022-06-25 08:08:05.455221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(1, "s", "s", [], "s", 2)
    print(t)


# Generated at 2022-06-25 08:08:06.550977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 08:08:07.464769
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule();


# Generated at 2022-06-25 08:08:16.516865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 9
    str_0 = 'pw\x12#7q5=B*\x7fXm\xc5\xc2\x1f\x7f\x0c\x16\x00'
    list_0 = [int_0, int_0]

# Generated at 2022-06-25 08:08:17.699956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:08:28.342608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -981
    str_0 = 'M\xcbc\x8eQ\xab\xcd\x02\xf4\x8a\x13\xfb\xa7\x0e\x9b\x1b\x1b\xda\xc6'
    list_0 = []
    list_3 = []
    list_3.append(-1046696325)
    list_3.append(-1046696325)
    list_0.append(list_3)
    list_3 = []
    list_3.append(-1046696325)
    list_3.append(-1046696325)
    list_0.append(list_3)
    list_3 = []
    list_3.append(-1046696325)

# Generated at 2022-06-25 08:08:31.799458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:10:09.470279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True is True


# Generated at 2022-06-25 08:10:10.240954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:10:23.091306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 5
    str_0 = '#\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True

# Test of method run of class ActionModule


# Generated at 2022-06-25 08:10:26.529818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AssertionError:
        print('Unit test failed')
    else:
        print('Unit test passed')

test_ActionModule()

# Generated at 2022-06-25 08:10:37.076809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test constructor of class ActionModule')
    int_0 = 6
    str_0 = '8uS90a#Yob\x0b4cx\x0cF2Bl'
    list_0 = [str_0, int_0, str_0, str_0]
    bytes_0 = b'\xc6\x8f\xad\xf5\xce\x8c\x8f\xe2\x90\xdf6\xfb\x99~\xd5\xea'
    float_0 = -1605.466
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)


# Generated at 2022-06-25 08:10:42.322623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = int(str_0, 16)
    str_0 = str_0[0:1] + str_0[1:2] + str_0[1:len(str_0)]
    str_0 = str_0.strip()
    list_0 = [int_0, int_0, int_0]
    float_0 = float(int_0)
    action_module_0 = ActionModule(int_0, str_0, str_0, list_0, bytes_0, float_0)
    action_module_0.run(tmp=None, task_vars=task_vars)

# vim: ft=python

# Generated at 2022-06-25 08:10:44.408326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)
    assert issubclass(ActionModule, ActionBase)
    assert issubclass(ActionModule, object)


# Generated at 2022-06-25 08:10:54.532972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    ansible_facts = dict()
    ansible_facts['pkg_mgr'] = 'yum'
    task_vars['ansible_facts'] = ansible_facts
    task_vars['ansible_facts']['pkg_mgr'] = 'yum'
    """
    The test case of the method run of class ActionModule.
    """
    try:
        # unit test for method run of class ActionModule
        method_ret_0 = ActionModule.run(ActionModule(), task_vars, task_vars)
        assert method_ret_0['ansible_facts']['pkg_mgr'] == 'yum'
    except Exception as e:
        raise Exception("Method run of class ActionModule has error: " + str(e))

# Generated at 2022-06-25 08:11:02.187047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 8
    str_0 = 'N\x1d\x9e\x0e\x9b\x0c\xed\x1d'

# Generated at 2022-06-25 08:11:11.861485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = '5;)v^8W$(w%c*kQzq#4\x1e\x10\x15\x01\x1a\x1f'
    str_1 = 'o\x0f\x00\x1a\x1f\x1f\x00\x0f\x07\x15\x13\x0f\x1c\x1a\x1f\x1e'
    list_0 = [str_1, int_0, str_0, str_1]