

# Generated at 2022-06-25 08:02:22.824338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    float_0 = -864.946
    list_0 = [float_0, str_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)


# Generated at 2022-06-25 08:02:31.648852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 08:02:35.726994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    float_0 = -864.946
    list_0 = [float_0, str_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)
    
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)
    test_case_0()

# Generated at 2022-06-25 08:02:46.583149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    float_0 = -864.946
    list_0 = [float_0, str_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)

    # Testing whether arguments are stored correctly or not
    str_0 = "yum"
    result = action_module_0._supports_check_mode
    assert result == True
    result = action_module_0._supports_async
    assert result == True
    result = action_module_0._task.args.get('use', str_0)
    assert result == str_0
    result = action_module_0._task.args.get('use_backend', str_0)
   

# Generated at 2022-06-25 08:02:50.177574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    float_0 = -864.946
    list_0 = [float_0, str_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)
    return str(action_module_0)


# Generated at 2022-06-25 08:02:51.148099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:02:57.778217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    str_0 = None
    float_0 = -864.946
    list_0 = [float_0, str_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)
    # AssertionError: {'msg': "Could not detect which major revision of yum is in use, which is required to determine module backend.", 'failed': True}
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:00.933980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # If Exception is thrown, no need to continue, so just create a new test case here
    test_case_0()

# Generated at 2022-06-25 08:03:06.550505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    float_0 = -864.946
    list_0 = [float_0, str_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)
    # Teardown


# Generated at 2022-06-25 08:03:10.348366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    float_0 = -864.946
    list_0 = [float_0, str_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, float_0, float_0, list_0, str_0, bool_0)

    assert(action_module_0 != None)



# Generated at 2022-06-25 08:03:21.456880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init
    var_0 = AnsibleActionFail("parameters are mutually exclusive: ('use', 'use_backend')")
    var_1 = None
    # Init
    var_2 = None
    var_1 = ActionModule()
    # Init
    var_3 = None
    var_4 = None
    # Init
    var_5 = None
    var_6 = None
    var_7 = None
    # Invoke method
    var_8 = var_1.run(var_2, var_3)
    assert var_8 == None, "Return value mismatch"


# Generated at 2022-06-25 08:03:23.705793
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    try:
        var_0 = None
        arg = {"tmp": var_0, "task_vars": var_0}
        test_case_0()
        obj = ActionModule()
        TestActionModule_run = obj.run(**arg)
        assert TestActionModule_run["failed"]
    except Exception:
        pass

# Generated at 2022-06-25 08:03:30.564599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None

    required_params = {"task_vars": var_1}
    display.vvv(required_params)

    # run action module
    result = ActionModule.run(var_0, var_1)
    # return test result
    return result

# Main function for testing purpose
if __name__ == "__main__":
    print(test_case_0())

# Generated at 2022-06-25 08:03:33.940481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test method run
    var_0 = None
    var_1 = None
    # Empty test

# Generated at 2022-06-25 08:03:34.856392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No error is raised
    var = ActionModule()
    var.run()

# Generated at 2022-06-25 08:03:36.228391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = TestClass.TestClass_0()
    var_0.test_method(var_0, var_0)



# Generated at 2022-06-25 08:03:37.532493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = ActionModule()
    var_3.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 08:03:38.926134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:49.012812
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:03:49.552250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()



# Generated at 2022-06-25 08:03:58.544056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule')
    test_case_0()

# Collect all test cases in this file
testcases_ActionModule = [
    test_ActionModule
]

# Collect all test classes in this file
test_classes_list = [
    ActionModule
]


# Generated at 2022-06-25 08:04:03.399573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("In test_ActionModule()")
    action_module_test_instance = ActionModule()
    assert action_module_test_instance is not None

# Generated at 2022-06-25 08:04:07.291140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 08:04:14.169496
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # callback = default('CallbackModule')
    # config = default('None')
    # connection = default('Connection')
    # layer_loader = default('LayeredLoader')
    # runner_loader = default('ActionLoader')
    # variable_manager = default('VariableManager')
    # loader = default('DataLoader')
    # templar = default('Templar')
    # task_vars = default('Dict')
    # play_context = default('PlayContext')
    # tmp = default('None')
    # shared_loader_obj = default('ModuleLoader')
    setattr(action_module, '_task_vars', '')
    setattr(action_module, '_play_context', '')
    setattr(action_module, '_shared_loader_obj', '')

    # Construct an object of class ActionModule

# Generated at 2022-06-25 08:04:14.926982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-25 08:04:19.849261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None

# Generated at 2022-06-25 08:04:27.583509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a ActionModule object
    action_module_0 = ActionModule()
    try:
        # Set up the test case scenario
        # Create a tmp directory
        import tempfile
        dirName = tempfile.mkdtemp()
        # Create a task_vars dict
        task_vars = dict()
        task_vars["pkg_mgr"] = "yum"
        # Invoke method run
        action_module_0.run(dirName, task_vars)
    finally:
        # Clean up the test case scenario
        import shutil
        shutil.rmtree(dirName, ignore_errors=True)

# Invoke unit tests
if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:04:30.809871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nTesting ActionModule class.")

    action_module = ActionModule()
    if action_module != None:
        print("SUCCESS: ActionModule valid constructor")
    else:
        print("ERROR: ActionModule invalid constructor")

# Generated at 2022-06-25 08:04:35.319511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    res = action_module.run(tmp=None, task_vars=None)
    assert res is not None

# Generated at 2022-06-25 08:04:38.054466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n\n----------------\nTesting...\n\n")
    # Retrieve the name of this class
    action_module_0 = ActionModule()
    print("Class Name: ", type(action_module_0).__name__)
    return

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 08:04:53.913781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'x~`)4D#i=tHf@tQ2gk'}
    list_0 = ['x~`)4D#i=tHf@tQ2gk', 'x~`)4D#i=tHf@tQ2gk']
    tuple_0 = ('LU6~-\\e,_?zR#Kb:H', 'x~`)4D#i=tHf@tQ2gk', 'LU6~-\\e,_?zR#Kb:H')
    str_0 = "q6Y@!e,!kR%8$znl0d"
    float_0 = -2359.267

# Generated at 2022-06-25 08:05:01.072797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {'a', 'b', 'c'}
    list_0 = ['a', set_0, 'c', 'd']
    var_0 = -3034.865
    tuple_0 = (-3034.865, 'c')
    str_0 = 'OZY#qwfng,1g\'eB1$~'
    set_1 = {tuple_0, 'c'}
    action_module_0 = ActionModule(set_0, list_0, -3034.865, tuple_0, 'c', set_1)
    action_module_0.run('', var_0)


# Generated at 2022-06-25 08:05:04.013355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = list()
    set_0 = set()
    tuple_0 = tuple()
    str_0 = str()
    float_0 = float()
    set_1 = set()
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)

# Generated at 2022-06-25 08:05:07.569112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__init__(ActionModule, {'1037', 'unicode', 'unicode'}, ['unicode', {'1037', 'unicode', 'unicode'}, 'unicode', 'unicode'], ('unicode', 'unicode'), 'unicode', -2344.417, {('unicode', 'unicode')})


# Generated at 2022-06-25 08:05:20.171314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:05:29.001986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "SIG{}"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    action_module_0.run()

# Generated at 2022-06-25 08:05:33.888363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "SWX_F;-R4at$Y1ZnTxq"
    dict_0 = {str_0, str_0, str_0}
    float_0 = -4115.603
    tuple_0 = (str_0, float_0)
    int_0 = -1428
    list_0 = [str_0, dict_0, str_0, float_0]
    set_0 = {int_0, tuple_0, dict_0, tuple_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, dict_0)


# Generated at 2022-06-25 08:05:35.095461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:05:43.070107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    val_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {val_0, val_0}
    list_0 = [val_0, val_0]
    tuple_0 = (val_0, val_0)
    val_1 = "l&F$~Bp34>^[{d8(!$O"
    float_0 = -24.2609
    set_1 = {tuple_0, val_1}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, val_1, float_0, set_1)
    return_0 = action_module_0.run()
    return return_0

# Generated at 2022-06-25 08:05:46.791861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "H#zjm~w5Z5_OSD6mPPv"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    test_case_0(action_module_0)

# Generated at 2022-06-25 08:06:07.501988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {-3588.51077, float()}
    list_0 = [float(), float()]
    tuple_0 = (float(), float())
    str_0 = "OZY#qwfng,1g'eB1$~"
    float_0 = -3034.865
    set_1 = {float_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    var_0 = action_module_0.run()

test_ActionModule_run()

# Generated at 2022-06-25 08:06:09.165159
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Run action module
    print("ActionModule_run")
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    # Output of statement is {}
    print(var_0)


# Generated at 2022-06-25 08:06:09.695916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 08:06:15.454052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "rAboFq3y"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (str_0, float_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    assert action_module_0.run(None, None) == None

# Generated at 2022-06-25 08:06:17.826135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except TypeError as exception_0:
        print(exception_0)
    else:
        raise Exception("Expected TypeError")


# Generated at 2022-06-25 08:06:26.296850
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:06:30.809638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if test_case_0():
        pass

# Generated at 2022-06-25 08:06:37.888742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    var_0 = action_run()
    action_module_0.run(set_0, None)

# Generated at 2022-06-25 08:06:41.556688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(str_0, list_0, set_0, tuple_0, float_0, set_1)
    str_1 = 'auto'
    var_0._task.args['use'] = str_1
    set_2 = {str_1}
    list_1 = [str_1, set_2, str_1, str_1]
    var_1 = var_0.run(set_2, list_1)
    str_2 = 'pkg_mgr'
    bool_0 = str_2 in var_1['ansible_facts']
    print("\n")
    print(" Ran a test")
    print("\n")


# Generated at 2022-06-25 08:06:44.044835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equals(test_case_0, 1)

# Generated at 2022-06-25 08:07:14.161089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:07:18.642684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule.py...")
    test_case_0()
    print("ActionModule class passed all tests!")
    print("Done testing ActionModule.py\n\n")

# Generated at 2022-06-25 08:07:24.950225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = list()
    tuple_0 = tuple()
    str_0 = str()
    float_0 = float()
    set_1 = set()
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    action_module_0.run()


# Generated at 2022-06-25 08:07:26.032829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Place your code here
    pass

# Generated at 2022-06-25 08:07:31.091249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {67, (1.08, "uV`wF@z(2V33*LSX", False), "7\xc8", 67, -1037.625}
    list_0 = ["E#ZnqFbXCYKD=\xac\x8d0", -1330.0, (1.45, "z\xde\x9b\x9b", ['W8QvjhdD', 1.4162135623730951, 1.4162135623730951]), 1.4142135623730951, 1.4142135623730951]
    tuple_0 = (-0.5, "rK\x7fJ%c^yC7[M2P")

# Generated at 2022-06-25 08:07:36.157807
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    ActionModule(set(), list(), tuple(), "OZY#qwfng,1g'eB1$~", -3034.865, {(tuple(), "OZY#qwfng,1g'eB1$~")})
    if False:
      raise RuntimeError()
  except RuntimeError:
    assert False
  else:
    assert True


# Generated at 2022-06-25 08:07:37.189952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:07:37.605923
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert True

# Generated at 2022-06-25 08:07:43.136373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data_0 = {'use_backend': 'dnf', 'use': 'yum', 'name': 'yum3'}
    module_name = 'yum'
    wrap_async = True
    result = {'failed': True, 'msg': 'yum'}
    action_module_0 = ActionModule(data_0, module_name, wrap_async, result)


# Generated at 2022-06-25 08:07:45.252493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a dummy object of class ActionBase
    action_base = ActionBase()
    # Create an object of class ActionModule
    action_module_0 = ActionModule()
    # Call the method run from the object of class ActionModule
    action_module_0.run()


# Generated at 2022-06-25 08:08:42.326483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 08:08:55.732290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'fFYP$e'
    str_1 = '5'
    dict_0 = dict()
    dict_0['ansible_facts'] = {str_1: str_0}
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    var_0 = action_module_0.run(dict_0, dict_0)
    # assert var_0

# Generated at 2022-06-25 08:09:06.757007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "gyzU6%~.OZY#qwfng,1g'eB1$~"
    int_0 = -20
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    action_module_0.str_1 = str_0
    action_module_0.str_2 = str_0
    action_module_0.dict_

# Generated at 2022-06-25 08:09:15.516178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "gw7$qmk>B[|T%u'9s"
    float_0 = 2220.7
    str_1 = "d.i?jK'2@[9^,I`$"
    str_2 = "M;-L.?e<Vn,nbs3|C"
    float_1 = -2220.7
    tuple_0 = (float_1, str_1, float_0, float_1)
    tuple_1 = (str_0, str_1, str_0, str_1)
    set_0 = {tuple_0, tuple_1, str_2}
    set_1 = {(tuple_1, tuple_0, float_0, tuple_0)}

# Generated at 2022-06-25 08:09:22.913850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    var_0 = action_run()


test_case_0()

# Generated at 2022-06-25 08:09:23.644918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:09:31.280628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)

# Unit tests for the member methods of the class ActionModule

# Generated at 2022-06-25 08:09:34.415635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:09:39.595597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    arg_0 = True
    arg_1 = True
    arg_2 = True
    arg_3 = True
    arg_4 = True
    arg_5 = True
    arg_6 = True

    set_0 = {'str_0', 'str_0', 'str_0'}
    list_0 = ['str_0', set_0, 'str_0', 'str_0']
    float_0 = -3034.865
    tuple_0 = (float_0, 'str_0')
    set_1 = {tuple_0, 'str_0'}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, 'str_0', float_0, set_1)

# Generated at 2022-06-25 08:09:41.945043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# End of test_ActionModule

# Generated at 2022-06-25 08:11:32.542961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "d'i<>&e'9"
    set_0 = {str_0, str_0, str_0}
    tuple_0 = (str_0, str_0)
    str_1 = "PdmJtbG"
    float_0 = -3477.12
    set_1 = {str_1, float_0, float_0, float_0}
    action_module_0 = ActionModule(set_0, str_1, tuple_0, str_0, str_1, set_1)
    var_0 = action_run()

    print(var_0)

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 08:11:42.590471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    assert True

# Generated at 2022-06-25 08:11:49.333040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "OZY#qwfng,1g'eB1$~"
    set_0 = {str_0, str_0, str_0}
    list_0 = [str_0, set_0, str_0, str_0]
    float_0 = -3034.865
    tuple_0 = (float_0, str_0)
    set_1 = {tuple_0, str_0}
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)


# Generated at 2022-06-25 08:11:53.344116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule("OpYB'e8!C>%", "OpYB'e8!C>%", "OpYB'e8!C>%", "OpYB'e8!C>%", 0.25, "OpYB'e8!C>%")
    action_module_0.run()

# Generated at 2022-06-25 08:12:01.839293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = []
    float_0 = float()
    str_0 = str()
    tuple_0 = tuple()
    set_1 = set()
    action_module_0 = ActionModule(set_0, list_0, tuple_0, str_0, float_0, set_1)
    var_0 = action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:12:04.968300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    # Call the run method on class ActionModule
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:12:06.504573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run of ActionModule")
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 08:12:16.561612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_2 = {"module_args", "delegate_to", "async_val", "task_vars", "delegate_facts"}
    list_1 = []
    tuple_1 = (list_1, set_2)
    str_1 = "OZY#qwfng,1g'eB1$~"
    float_1 = -3034.865
    set_3 = {str_1, tuple_1, float_1}
    action_module_1 = ActionModule(set_2, list_1, tuple_1, str_1, float_1, set_3)
