

# Generated at 2022-06-25 08:02:26.920393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_'
    str_1 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)
    action_module_0.run(str_1)

# Generated at 2022-06-25 08:02:29.750782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)


# Generated at 2022-06-25 08:02:30.448549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test Constructor")


# Generated at 2022-06-25 08:02:31.613448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    test_case_0()

# Generated at 2022-06-25 08:02:41.886492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)
    str_1 = None
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_1['foo'] = dict_2
    dict_0['bar'] = dict_1
    dict_3 = dict()
    dict_3['test_case_0'] = dict_0
    dict_0 = dict()
    dict_0['test_case_0'] = dict_3
    dict_1 = dict()
    dict_2 = dict()
    dict_2['test_case_0'] = 'test_value'

# Generated at 2022-06-25 08:02:53.026113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0

# Generated at 2022-06-25 08:02:57.102164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)
    str_0 = None
    complex_0 = None
    action_module_0.run(str_0, complex_0)

# Generated at 2022-06-25 08:03:09.393087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '2'
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)
    action_module_0.set_loader(complex_0)
    action_module_0.set_play_context(complex_0)
    action_module_0.set_task(complex_0)
    action_module_0.set_task_vars(complex_0)
    action_module_0.set_templar(complex_0)
    bool_0 = bool()
    tmp_0 = bool_0
    task_vars_0 = bool_0
    dict_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 08:03:11.188648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ' '
    int_0 = None
    complex_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, str_0, complex_0, complex_0)



# Generated at 2022-06-25 08:03:17.888854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'public'
    str_1 = 'ext2'
    int_0 = None
    complex_0 = None
    complex_1 = None
    action_module_0 = ActionModule(str_0, str_1, int_0, str_0, complex_0, complex_1)

    task_vars = {}
    tmp = None
    test_run = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:03:24.887705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 08:03:28.981976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    var_1 = ActionModule()
    str_1 = 'Testing ActionModule class constructor'
    var_2 = print(str_1)


# Generated at 2022-06-25 08:03:29.910999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    var_0.run() # TODO: Change

# Unit test runner

# Generated at 2022-06-25 08:03:34.622292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    var_2 = var_1.run()
    str_1 = 'Testing run of class ActionModule'
    var_3 = print(str_1)



# Generated at 2022-06-25 08:03:35.777858
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()

# Function to test calling constructor of class ActionModule
test_ActionModule()

# Generated at 2022-06-25 08:03:36.422243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:03:37.036549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 08:03:38.061257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 08:03:39.046110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:44.633674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Testing run method of class ActionModule'
    var_0 = print(str_0)


# Generated at 2022-06-25 08:03:51.601909
# Unit test for constructor of class ActionModule
def test_ActionModule():

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-25 08:03:56.500297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._supports_check_mode
    assert action_module_0._supports_async

# Generated at 2022-06-25 08:04:05.398656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Load the default test data for the constructor
    action_module_args = {}
    action_module_args['task'] = 'yum'
    action_module_args['connection'] = 'local'
    action_module_args['_ansible_verbosity'] = '4'
    action_module_args['_ansible_no_log'] = False
    action_module_args['_ansible_debug'] = True
    action_module_args['_ansible_diff'] = False

    # Execute the constructor and check the args
    action_module_instance = ActionModule(**action_module_args)
    assert action_module_instance.task == 'yum'
    assert action_module_instance.connection == 'local'
    assert action_module_instance._ansible_verbosity == '4'
    assert action_module

# Generated at 2022-06-25 08:04:12.899011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.task_vars = {
        "ansible_pkg_mgr": "dnf"}
    task = Mock(
        spec=["args", "delegate_to", "delegate_facts"],
    )
    task.args = {
        "use_backend": "auto",
    }
    task.delegate_to = None
    task.delegate_facts = False
    action_module.task = task

    action_module.tmp = None
    action_module.connection = Mock()
    action_module.connection._shell = Mock()
    action_module.connection._shell.tmpdir = '/tmp_path'
    action_module._shared_loader_obj = Mock()
    action_module._shared_loader_obj.module_loader = Mock()
    action_module

# Generated at 2022-06-25 08:04:16.146077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actmod = ActionModule()
    assert len(actmod.task_vars) == 0, "task_vars is not null"


# Generated at 2022-06-25 08:04:21.273465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # variable 'tmp' has to be a string
    # variable 'task_vars' has to be a dict
    action_module_0.run(tmp = "tmp", task_vars = {
        'ansible_pkg_mgr': "yum",
    })

# Generated at 2022-06-25 08:04:23.856536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)
    action_module_2 = ActionModule()
    assert action_module_1 == action_module_2
    action_module_1.run()

# Generated at 2022-06-25 08:04:27.323309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:04:30.633145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    facts = ActionModule().run(task_vars={'ansible_facts': {'pkg_mgr': 'yum'}})
    print(facts)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:04:31.598435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 08:04:39.611905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(test_case_0())

test_ActionModule_run()

# Generated at 2022-06-25 08:04:45.145380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    action_module_0.run()
    return 0

test_cases = [
    test_case_0,
]


# Generated at 2022-06-25 08:04:47.164897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test cases
    test_case_0()


# Generated at 2022-06-25 08:04:49.394248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Running test case: ActionModule.run...")
    test_case_0()
    print("Test case passed.")
    print("")

# Unit test

# Generated at 2022-06-25 08:04:55.349471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0, 0, False, [], bytes, set())
    str_0 = 'Xme$!d7'
    list_0 = [str_0, str_0]
    dict_0 = dict()
    dict_0[str_0] = list_0
    dict_1 = dict()
    dict_1[str_0] = str_0
    dict_2 = dict()
    dict_2[str_0] = dict_0
    dict_3 = dict()
    dict_3[str_0] = dict_1
    dict_4 = dict()
    dict_4[str_0] = dict_2
    dict_5 = dict()
    dict_5[str_0] = dict_3
    dict_6 = dict()

# Generated at 2022-06-25 08:05:00.891184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -193
    list_0 = [-127, -127, -127]
    bool_0 = False
    list_1 = [0, 0, 0, 0]
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_0, bool_0, list_1, bytes_0, set_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 08:05:05.372782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)


# Generated at 2022-06-25 08:05:10.008187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -30
    int_1 = -30
    list_0 = [int_0, int_1, int_1]
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    action_module_0 = ActionModule(int_0, list_0, False, list_0, bytes_0, set())
    var_0 = action_module_0.run(None, None)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print("Unit tests completed successfully")

# Generated at 2022-06-25 08:05:19.825064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_run(action_module_0)
    assert var_0 == "action_run"

# Generated at 2022-06-25 08:05:21.393332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    func(arg_0, arg_1, arg_2)
    assert func(arg_0, arg_1, arg_2) == exp_val


# Generated at 2022-06-25 08:05:37.161698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()
    assert var_0 == None

# Generated at 2022-06-25 08:05:40.860910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests the return type of method run of class ActionModule
    if (isinstance(ActionModule.run(), dict)):
        test_case_0()
        test_case_1()
    else:
        raise AssertionError(ActionModule.run())


# Generated at 2022-06-25 08:05:46.852472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We test the module on each valid backend, with and without delegated facts
    module_backend = [("yum", False), ("yum", True), ("dnf", False), ("dnf", True)]

    for (backend_name, delegate_facts) in module_backend:
        module = ActionModule(delegate_facts, backend_name)
        module.run(backend_name)

# Generated at 2022-06-25 08:05:50.255800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO implement constructor test
    assert True # TODO implement test


# Generated at 2022-06-25 08:05:56.608960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    print(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:05:59.749928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test for constructor of class ActionModule")
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 08:06:08.396970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert len(ActionModule._templar_type_map) == 8, "ActionModule._templar_type_map has unexpected size"
    assert len(ActionModule._global_action_cls) == 0, "ActionModule._global_action_cls has unexpected size"
    assert len(ActionModule._plugins) == 0, "ActionModule._plugins has unexpected size"
    assert len(ActionModule._action_loader) == 0, "ActionModule._action_loader has unexpected size"
    assert len(ActionModule._lookup_loader) == 0, "ActionModule._lookup_loader has unexpected size"
    assert len(ActionModule._filter_loader) == 0, "ActionModule._filter_loader has unexpected size"
    assert len(ActionModule._cache_dir) == 0, "ActionModule._cache_dir has unexpected size"

# Generated at 2022-06-25 08:06:09.805405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:06:11.304907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:06:12.394904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:06:39.763588
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test Case 0: default constructor
    test_case_0()

# Generated at 2022-06-25 08:06:47.021954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_module_0.run(tmp = None, task_vars=None)

# Generated at 2022-06-25 08:06:52.401958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(tuple(), tuple(), bool(), tuple(), b'\x8ec{b\x1c\xdf\xfd\xd2', set())
    action_module_0.run()
    assert_equals(action_module_0.run(), len(tuple()))


# Generated at 2022-06-25 08:07:02.245682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -110
    int_1 = -19
    list_0 = [int_1, int_0, int_0]
    list_1 = [int_1, int_1, list_0]
    bool_0 = True
    bytes_0 = b'\x0f\xfe\xc6\xbf\x8b\xc4iAI\x18'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 08:07:06.057681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    dict_0 = dict()
    bool_0 = False
    list_0 = [dict_0, dict_0]
    str_0 = ")b\xaf\xaf\r\n\x17\x10\xcc"
    dict_1 = dict()
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_0, bool_0, list_0, str_0, set_0)


# Generated at 2022-06-25 08:07:08.202784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Argument names match those in the original function declaration
    arg_0 = None
    arg_1 = None
    # Call the function
    test_case_0()


if __name__ == '__main__':
    # Run the unit tests
    test_ActionModule_run()

# Generated at 2022-06-25 08:07:12.665319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:07:22.037443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    return action_module_0


# Generated at 2022-06-25 08:07:29.822884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -127
    list_0 = [int_0, int_0]
    bool_0 = True
    action_module_0 = ActionModule(int_0, list_0, bool_0, list_0, bytes(), set())
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:07:37.171844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -199
    int_1 = 2703
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_1, int_1, list_0]
    bool_0 = False
    bytes_0 = b'\xed\x1c\x8a-\xde\xa5!\x9c'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:08:25.135327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_ActionModule() == "test_ActionModule"

# Generated at 2022-06-25 08:08:33.666175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_run()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:08:39.958809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 08:08:45.526424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    assert action_module_0.Transfers_FILES == False


# Generated at 2022-06-25 08:08:53.042383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_module_run()


# Generated at 2022-06-25 08:09:04.158008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None,None,False,None,b'\xeb\x15\x03o\xe0\x1b\x1d\x8b{\xdd\x86\x08',None)
    file_0 = tempfile.NamedTemporaryFile('w+b', -1, '', '', None)
    int_0 = -10
    dict_0 = dict()
    dict_1 = dict()
    var_0 = action_module_0.run(file_0.name, dict_1)
    display.debug(var_0)


# Generated at 2022-06-25 08:09:08.417144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(TestCase)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:09:12.786675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:09:17.622626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor with a valid argument type
    try:
        action_module_0 = ActionModule(None, None)
    except Exception as e:
        raise Exception(
            "Failed to create ActionModule object with valid argument list. " +
            "Exception thrown: " + str(e))
    # Test for constructor with valid argument type
    try:
        action_module_0 = ActionModule(None)
    except Exception as e:
        raise Exception(
            "Failed to create ActionModule object with valid argument type. " +
            "Exception thrown: " + str(e))
    # Test for constructor with invalid argument type

# Generated at 2022-06-25 08:09:24.996441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    int_1 = 1
    list_0 = []
    list_1 = [int_0, int_1]
    bool_0 = False
    list_2 = [int_0, int_0, list_0]
    bytes_0 = b'\xdc\x89\x1f\x9aH\xc6\x1a\x17\xbf\x05\xcf\xa2C\x9a\xcb\x1fh\xd3'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_2, bytes_0, set_0)
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 08:11:00.992749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()

# Generated at 2022-06-25 08:11:04.181444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run - ok')
    action_module_0 = ActionModule()
    var_0 = action_run()
    print('Expected:')
    print('Received:')


# Generated at 2022-06-25 08:11:11.173354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule(0, [0, 0, [0, 0, [0, 0, [0, 0]]]], True, [0, 0, [0, 0, [0, 0, [0, 0]]]], b'\x8ec{b\x1c\xdf\xfd\xd2', set())) == ActionModule

# Generated at 2022-06-25 08:11:18.330041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # use_backend is specified
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    action_module_1 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_run()
    # use_backend is not specified, failed in template

# Generated at 2022-06-25 08:11:27.257301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_0, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True


# Generated at 2022-06-25 08:11:31.272874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:11:37.120597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_module_0.run()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 08:11:44.280255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    var_0 = action_run()
    if var_0:
        print(var_0)
    else:
        print(action_module_0.run())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:11:51.946682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    assert(action_module_0 != None)


# Generated at 2022-06-25 08:11:56.893355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -127
    int_1 = 3210
    list_0 = [int_0, int_1, int_1]
    list_1 = [int_0, int_0, list_0]
    bool_0 = True
    bytes_0 = b'\x8ec{b\x1c\xdf\xfd\xd2'
    set_0 = set()
    action_module_0 = ActionModule(int_0, list_1, bool_0, list_1, bytes_0, set_0)
    action_module_0.run()
    var_0 = action_module_0.run()
