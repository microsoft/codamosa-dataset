

# Generated at 2022-06-25 08:02:28.357454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    tuple_0 = (b'\xfd',)
    list_0 = ['n', '', '\x04', '\xfb']
    float_0 = 5.63221508083817e-06
    # Test for TypeError in method call.
    try:
        test_case_0()
    except TypeError as e:
        print('TypeError raised in test_case_0: ' + str(e))
    # Test for TypeError in class initialization.
    try:
        ActionModule(b'\x00\xff\xda\x00', int_0, list_0, 'N\xab\x19', set_0)
    except TypeError as e:
        print('TypeError raised in __init__: ' + str(e))
    # Test for TypeError in

# Generated at 2022-06-25 08:02:32.341834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test if method will return True when calling with tmp == None and task_vars == None
    #assert ActionModule.run(None, None) == True, "test_ActionModule_run: method run of class ActionModule failed"
    #assert ActionModule.run() == True, "test_ActionModule_run: method run of class ActionModule failed"

    # Test arguments and expected return values of this method
    pass


# Generated at 2022-06-25 08:02:34.970088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except:
        return
    else:
        assert(False)



# Generated at 2022-06-25 08:02:37.197938
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test for method __init__()
    try:
        test_case_0()
    except Exception:
        display.warning("Caught exception testing method __init__.")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:02:38.696076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print("test_case_0 failed")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 08:02:39.307919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_0 = ActionModule()


# Generated at 2022-06-25 08:02:48.641565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    ansible_facts_0 = AnsibleFacts({'ansible_pkg_mgr': 'mock'})
    str_0 = '''parameters are mutually exclusive: ('use', 'use_backend')'''
    dict_1 = {}
    dict_1['failed'] = True
    dict_1['msg'] = str_0
    task_vars_0 = dict()
    tmp_0 = '/var/folders/j5/wv1sb__j54l60p1gbmz5t0f80000gn/T/ansible_yum_payload_aHtZ7s/tmp'
    task_vars_0['ansible_pkg_mgr'] = 'mock'

# Generated at 2022-06-25 08:02:57.191478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 457
    int_1 = 603
    bytes_0 = b'\x83\x8a\x8d\x94\x93\x8e'

# Generated at 2022-06-25 08:03:09.391423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Empty:
        _shared_loader_obj = None
        _task = Empty()
        _task.delegate_to = None
        _task.delegate_facts = None
        _task.args = {}
        _task.async_val = None

    class Empty1:
        tmpdir = b'/tmp/tmp'

    class Empty2:
        module_name = 'ansible.legacy.setup'
        module_args = {}
        wrap_async = None
        task_vars = {}

    class Empty3:
        failed = False
        msg = 'Could not find a yum module backend for ansible.legacy.setup.\n'

    class Empty4:
        module_name = 'ansible.legacy.yum'
        module_args = {}
        wrap_async = None
        task

# Generated at 2022-06-25 08:03:16.360435
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:03:27.355151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 656.852
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    float_1 = 765.553
    str_4 = 'rc@iZKlN!6 w7j4M4T'
    bool_1 = True

# Generated at 2022-06-25 08:03:27.794661
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:03:29.018533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test case 0")
    test_case_0()

# Uncomment the next line to run the test
test_ActionModule()

# Generated at 2022-06-25 08:03:33.328209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 628.22
    str_0 = 'RC1t;j4!4yek'
    bool_0 = True
    str_1 = '),?T\\'
    str_2 = 'O_^0yj$h`%c3q3O\x0bI'
    str_3 = '#=WoPjuo\x0b'
    str_4 = 'M6>H\x0bUg'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    array_0 = field_name()
    array_1 = field_name()
    action_module_0.run(array_0, array_1)

if __name__ == '__main__':
    test_

# Generated at 2022-06-25 08:03:36.647854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    assert not action_module_0
    

# Generated at 2022-06-25 08:03:37.553259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


if __name__ == '__main__':
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 08:03:42.528493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2.020

# Generated at 2022-06-25 08:03:48.460342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)
    var_0 = module.run(tmp, task_vars)
    return var_

# Generated at 2022-06-25 08:03:48.943546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)



# Generated at 2022-06-25 08:03:53.549393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 6.912
    str_0 = 'Jy\nitc^"\n`'
    bool_0 = False
    str_1 = 'dsl0\n\n*99]F'
    str_2 = '\n\n\n\n\n\n\n\n\n\n\n\n'
    str_3 = '\n\n#-\n\n$;\n\n\n\n'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    assert(action_module_0.float_0 == 6.912)
    assert(action_module_0.str_0 == 'Jy\nitc^"\n`')

# Generated at 2022-06-25 08:04:08.580372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:04:12.710954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 957.63
    str_0 = 'iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = 'pZUIs:)86"g1G\r7v'
    str_2 = '\'MhZ}#wZ3D{A|'
    str_3 = '\r15qJwe\\Im6nu'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    action_module_0.run()


# Generated at 2022-06-25 08:04:14.467846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert action_run in ActionModule.run()


# Generated at 2022-06-25 08:04:24.925997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert type(action_module_0.run()) == dict
    assert action_module_0.run() == {}
    assert type(action_module_0.run()) == dict
    assert action_module_0.run()['msg'] == 'The requested repo "notthere" does not exist.'
    assert action_module_0.run()['ansible_facts'] == {}
    assert action_module_0.run()['failed'] == False
    assert action_module_0.run()['name'] == 'git'
    assert action_module_0.run()['rc'] == 0
    assert type(action_module_0.run()) == dict
    assert action_module_0.run() == {}
    assert type(action_module_0.run()) == dict
    assert action_module_0.run() == {}

# Generated at 2022-06-25 08:04:34.161730
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:04:40.732028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_run()

# Generated at 2022-06-25 08:04:53.682918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.959
    str_0 = '=q%c$'
    bool_0 = False
    str_1 = '@xkV\x0e'
    str_2 = 'coA7Vl0s'
    str_3 = 'koz|'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    assert action_module_0.action_name == 'yum'
    # assert action_module_0.action_loader.module_loader.module_name == 'ansible.module_utils.basic.AnsibleModule'
    # assert action_module_0.action_loader.module_loader.utils.module_name == 'ansible.module_utils.basic.AnsibleModuleUt

# Generated at 2022-06-25 08:05:00.809149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_run()

# Generated at 2022-06-25 08:05:05.902339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 08:05:10.078821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 9.952
    str_0 = '/Z^R.e\n>;(|b:JL5z'
    bool_0 = True
    str_1 = 'U"(\n<l^"a(\n:\n>bl2'
    str_2 = 'L=1^Ta<HB0255`p'
    str_3 = '`*vzV7R\nH\\aV7$g'
    action_module_1 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    assert action_module_1.tmp is None
    assert action_module_1.use is 'auto'


# Generated at 2022-06-25 08:05:41.989737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    action_module_0.run()



# Generated at 2022-06-25 08:05:51.823401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_run()
    # check if the value of var_0 is the expected one
    var_0 = 'l\xdb\x9e'
    # check if the value of var_0 is the expected one

# Generated at 2022-06-25 08:05:56.920178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 264.820418
    str_0 = 'um0&(pob\'"q"$#m'
    bool_0 = True
    str_1 = 'c1IY|67J?!e5\rw0'
    str_2 = 't:H4J9o4&/\n58d)'
    str_3 = '8!r^g(nh$\r7V^v9'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    action_run()
    test_case_0()

# Generated at 2022-06-25 08:06:04.369335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    if bool(action_module_0.get_transfers_files()) is True:
        action_module_0.set_supports_async(True)
    else:
        action_module_0.set_supports

# Generated at 2022-06-25 08:06:05.164296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:06:10.274778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 779.292
    str_0 = '3q2^lHd"mZjm48!W'
    bool_0 = True
    str_1 = 'wH,8&vrmz6bkmU"QeU'
    str_2 = 'B\n$h#1dH#c%&k'
    str_3 = 'i^j0@|>vX9y*'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)

# Generated at 2022-06-25 08:06:11.562822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 08:06:17.088949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 766.788
    str_0 = '$uz*pt"^,2%3f6\x7fjK'
    bool_0 = True
    str_1 = 'CK"B<\x7f:Oi{t\r?t$'
    str_2 = '5v5\rjXn}r>@'
    str_3 = 'H'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    action_run(action_module_0)

# Generated at 2022-06-25 08:06:20.157348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 105.16504001929384
    str_0 = ']p9:1[aN'
    bool_0 = True
    str_1 = '"\t(tp'
    str_2 = '2mRh4Gq3\n'
    str_3 = 'B!S\n"F+'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)


# Generated at 2022-06-25 08:06:28.266704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    assert isinstance(action_module_0, ActionModule), 'Constructor of class ActionModule failed'


# Generated at 2022-06-25 08:07:21.652663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 985.62
    str_0 = 'J"wzpIyq3ISxA^Q2\roT'
    bool_0 = False
    str_1 = '@\rnYa~Jvx8W]/F_X'
    str_2 = 'u|SJd/kVzgsY'
    str_3 = '4+e]Xg\n{rHrN6FK'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
#    var_0 = action_run()

# Generated at 2022-06-25 08:07:28.782910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ACTION_MODULE_CLASS = ActionModule("parameter_0", "parameter_1", False, "parameter_3", "parameter_4", "parameter_5")


# Generated at 2022-06-25 08:07:34.722666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 is not None
    assert action_module_0.run() == None, 'Failed to run action module'


# Unit tests for method of class ActionModule

# Generated at 2022-06-25 08:07:44.446825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # All results of the constructor
    assert action_module_0.action_plugin == 557.618
    assert action_module_0.task == 'rc@iZKlN!6 w7j4M4T'
    assert action_module_0.connection == True
    assert action_module_0._task == '!8"jc\r15qJwe\\Im6nu'
    assert action_module_0._connection == 'p\rSqw(B/P%,jd2|'
    assert action_module_0._play_context == 'pZUIs:)86"g1G\r7v'
    # All results of the method run
    assert isinstance(var_0, dict)
    assert var_0.has_key('failed')
    assert var_0.has_key('msg')
   

# Generated at 2022-06-25 08:07:49.585668
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test data
    bool_0 = False
    str_0 = 'Z!O?K,*hv m8'
    str_1 = '}Qe&P? 4)UY|$d(0q'
    str_2 = 'D)B(,bE#q3c+NbI-Y'
    str_3 = '2c%|\rzA2J?SCF, K)'
    str_4 = 'V7Zu"J$je9,`0?`D}'

    # Execute the run() method to make sure it works as expected

# Generated at 2022-06-25 08:07:58.218992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 285.3185
    str_0 = '_FsOk`eY8f^O2.E\r*|'
    bool_0 = False
    str_1 = '\t\'\n\\"q3@q9"l,'
    str_2 = '8%cg|b7S-A\t^'
    str_3 = 'd6<4~6UQ7Vg"`'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_module_0.run()
    assert var_0 == 'test_result'


# Generated at 2022-06-25 08:07:59.848115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if True:
        # the var is defined
        test_case_0()

# Generated at 2022-06-25 08:08:10.298867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test code for ActionModule
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    # end test code

# Generated at 2022-06-25 08:08:17.044569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:08:20.550419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Simple case of instantiating the class
    var_0 = ActionModule(45.5, "abc", True, "def", "ghi", "jkl")


# Generated at 2022-06-25 08:10:04.249820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 70.7099
    str_0 = 'y=*87c'
    bool_0 = True
    str_1 = 'ClE\'*0'
    str_2 = 'Wf-U'
    str_3 = '~8&U'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)


# Generated at 2022-06-25 08:10:08.809158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_run()

# Generated at 2022-06-25 08:10:12.995961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    action_module_0.run()

# Generated at 2022-06-25 08:10:19.692970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 879.3018
    str_0 = 'H4t2P-pm[]8\t\\uYC5_'
    bool_0 = False
    str_1 = '66]C&b\r'
    str_2 = '\r'
    str_3 = 'gf/6Q(Z6YqU]G=T'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:10:24.843268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    action_module_0.test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:10:32.177486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
    var_0 = action_module_0.run()
    print(var_0)

# Generated at 2022-06-25 08:10:37.093622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 08:10:41.295766
# Unit test for constructor of class ActionModule
def test_ActionModule():
	float_0 = 958.357
	str_0 = 'H3.U3jKkZ zzS9B,'
	bool_0 = True
	str_1 = '\f;dvu,0'
	str_2 = '9ep_7F%c|'
	str_3 = '8m;xV"{t@p'
	action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)

# Generated at 2022-06-25 08:10:48.050858
# Unit test for constructor of class ActionModule
def test_ActionModule():
   float_0 = 557.618
   str_0 = 'rc@iZKlN!6 w7j4M4T'
   bool_0 = False
   str_1 = '!8"jc\r15qJwe\\Im6nu'
   str_2 = 'p\rSqw(B/P%,jd2|'
   str_3 = 'pZUIs:)86"g1G\r7v'
   action_module_0 = ActionModule(float_0, str_0, bool_0, str_1, str_2, str_3)
   assert isinstance(action_module_0, ActionModule), "Failed to instantiate an ActionModule!"


# Generated at 2022-06-25 08:10:53.407111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = 557.618
    str_0 = 'rc@iZKlN!6 w7j4M4T'
    bool_0 = True
    str_1 = '!8"jc\r15qJwe\\Im6nu'
    str_2 = 'p\rSqw(B/P%,jd2|'
    str_3 = 'pZUIs:)86"g1G\r7v'
    var_0 = action_module_0.run(float_0, str_0, bool_0, str_1, str_2, str_3)
    return var_0