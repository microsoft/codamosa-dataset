

# Generated at 2022-06-25 08:02:25.080307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'delgroup'
    set_0 = {str_0, str_0, str_0, str_0}
    float_0 = -649.15542
    action_module_0 = ActionModule(str_0, set_0, str_0, set_0, float_0, str_0)


# Generated at 2022-06-25 08:02:33.539742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9'
    set_0 = {str_0, str_0, str_0, str_0, str_0}
    float_0 = -649.15542
    action_module_0 = ActionModule(str_0, set_0, str_0, set_0, float_0, str_0)
    tmp_0 = None
    task_vars_0 = None
    dict_0 = action_module_0.run(tmp_0, task_vars_0)
    assert dict_0['failed']
    assert str_0 == dict_0['msg'].split()[2]


# Generated at 2022-06-25 08:02:38.195007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'delgroup'
    set_0 = {str_0, str_0, str_0, str_0}
    float_0 = -649.15542
    action_module_0 = ActionModule(str_0, set_0, str_0, set_0, float_0, str_0)
    str_1 = 'rpm_qf'
    set_1 = {str_1, str_1, str_1, str_1}
    action_module_0.run(str_1, set_1)


# Generated at 2022-06-25 08:02:39.925402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:02:43.731279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'deluser'
    dict_0 = dict()

    set_0 = frozenset()
    action_module_0 = ActionModule(str_2, dict_0, str_2, set_0, None, str_2)


# Generated at 2022-06-25 08:02:48.613300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'delgroup'
    set_0 = {str_0, str_0, str_0, str_0}
    float_0 = -649.15542
    action_module_0 = ActionModule(str_0, set_0, str_0, set_0, float_0, str_0)
    result = action_module_0.run()


# Generated at 2022-06-25 08:02:49.306298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:02:50.157530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:02:56.514129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'yum4'
    set_1 = {str_2, str_2, str_2, str_2}
    str_1 = 'use_backend'
    set_0 = {str_1, str_1, str_1, str_1}
    float_1 = -649.15542
    str_0 = 'v'
    action_module_0 = ActionModule(str_0, set_0, str_1, set_1, float_1, str_2)


if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 08:03:00.800093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# All tests cases
test_ActionModule()
test_case_0()

# Generated at 2022-06-25 08:03:13.970951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'install'
    str_1 = '/etc/ansible/hosts'
    str_2 = 'setup'
    str_3 = 'pkg'
    str_4 = 'ecdsa'
    str_5 = 'novars'
    dict_0 = dict()
    str_6 = 'all'

    # Demonstrates the use of a background thread to ping and
    # use the result
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    assert str_0 == action_module_0._connection
    assert str_0 == action_module_0._play_context
    assert str_0 == action_module_0._loader
    assert str_0 == action_module_0._templar

# Generated at 2022-06-25 08:03:16.506964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:18.026037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:03:24.651324
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'True'
    str_1 = 'str'
    str_2 = 'auto'
    str_3 = 'action'
    str_4 = 'module'
    str_5 = 'ansible.legacy.'
    str_6 = 'True'
    str_7 = 'msg'
    str_8 = "Could not detect which major revision of yum is in use, which is required to determine module backend."
    str_9 = "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})"
    str_10 = 'failed'
    str_11 = "Could not find a yum module backend for "
    str_12 = 'ansible.legacy.yum4'

# Generated at 2022-06-25 08:03:26.967498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the arguments
    str_0 = 'set_fact'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 08:03:29.926073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    exception_catch = None
    try:
        action_module_0.run()
    except Exception as e:
        exception_catch = e
    assert exception_catch is not None


# Generated at 2022-06-25 08:03:32.309269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '{{ ansible_pkg_mgr }}'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.run('', '')
    action_module_0.run(str_0, str_0)
    action_module_0.run([], '')


# Generated at 2022-06-25 08:03:32.861353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:03:36.510892
# Unit test for method run of class ActionModule
def test_ActionModule_run():

	str_0 = 'deluser'
	action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
	module = 'yum'
	module = action_module_0.run(module)

if __name__ == '__main__':
	test_case_0()
	test_ActionModule_run()

# Generated at 2022-06-25 08:03:39.276215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dnf'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    str_1 = 'ansible.legacy.yum'
    action_module_0.run(str_1)


# Generated at 2022-06-25 08:03:51.465717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(None, None, None, None, None, None)
    res = action_module_0.run(tmp, task_vars)
    assert res is not None

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 08:03:52.772556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ActionModule.run()
    assert type(str_0) == dict


# Generated at 2022-06-25 08:03:58.216419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    display = Display()
    str_0 = 'user'
    str_1 = ''
    str_2 = 'get_url'
    str_3 = 'get_url'
    str_4 = 'raw'
    str_5 = 'raw'
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, str_4, str_5)
    str_6 = 'user'
    str_7 = 'user'
    str_8 = 'get_url'
    str_9 = 'get_url'
    str_10 = 'raw'
    str_11 = 'raw'
    action_module_1 = ActionModule(str_6, str_7, str_8, str_9, str_10, str_11)


# Generated at 2022-06-25 08:04:06.056141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actions = ['dnf', 'yum']
    for i in actions:
        action_module_0 = ActionModule(i, i, i, i, i, i)
        # Valid input returns successfully.
        assert(action_module_0.run(str_0, str_0))

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:04:10.565387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'setup'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    assert action_module_0._task.args == {'filter': 'ansible_pkg_mgr', 'gather_subset': '!all'}


# Generated at 2022-06-25 08:04:15.088565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:04:25.114405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'deluser'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    action_module_0.module_compression = 'compressed_tar'
    action_module_0.module_name = 'module_name'

    # Input parameters for method run
    args = {
        'use': 'use'
    }
    task_vars = {
        'var_0': 'var_0',
        'var_1': 'var_1'
    }
    tmp = 'tmp'
    delegate_to = 'delegate_to'

    action_module_0.task_vars = task_vars
    action_module_0.delegate_to = delegate_to

# Generated at 2022-06-25 08:04:27.901457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 08:04:34.895943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import random
    tmp_0 = random.choice(['tmp_0', 'tmp_1', 'tmp_2', 'tmp_3', 'tmp_4'])
    task_vars_0 = random.choice(['task_vars_0', 'task_vars_1', 'task_vars_2', 'task_vars_3', 'task_vars_4'])
    str_0 = 'use_backend'
    dict_0 = copy.deepcopy(task_vars_0)
    dict_1 = copy.deepcopy(tmp_0)
    dict_2 = copy.deepcopy(task_vars_0)
    dict_3 = copy.deepcopy(tmp_0)
    dict_4 = copy.deepcopy(tmp_0)
    dict_5 = copy.deep

# Generated at 2022-06-25 08:04:41.819677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    (action_module_0, str_0) = (ActionModule(dict(), dict(), dict(), dict(), dict(), dict()), 'dict()')
    (action_module_1, str_1) = (ActionModule(False, False, False, False, False, False), 'False')
    (action_module_2, str_2) = (ActionModule('task_vars', 'task_vars', 'task_vars', 'task_vars', 'task_vars', 'task_vars'), 'task_vars')
    (action_module_3, str_3) = (ActionModule(None, None, None, None, None, None), 'None')

# Generated at 2022-06-25 08:04:59.132022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    test_case_0()

# Generated at 2022-06-25 08:05:08.382907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -10460
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    list_1 = ["F&oW@[b]|~'9P:bG;f_?-", "a"]
    dict_0 = action_run(["a"])
    assert len(dict_0) == 2
    assert '' in dict_0



# Generated at 2022-06-25 08:05:20.706129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  #
  # Init test
  #

  # Mocking AnsibleModule object
  class ansible_module_mock():
    def __init__(self, *args, **kwargs):
      self.params = args[1]

  # Mocking AnsibleAction object
  class ansible_action_mock():
    def __init__(self, *args, **kwargs):
      self.args = args[3]
      self.async_val = args[5]

  # Mocking AnsibleConnection object
  class ansible_connection_mock():
    def __init__(self, *args, **kwargs):
      self._shell = ansible_shell_mock()

  # Mocking AnsibleShell object

# Generated at 2022-06-25 08:05:27.681584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 08:05:33.507481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tuple_0 = ()
  list_0 = []
  set_0 = {tuple_0, tuple_0}
  int_0 = -2640
  action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
  action_run()

# Generated at 2022-06-25 08:05:39.976572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)

# Generated at 2022-06-25 08:05:48.226797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    tuple_1 = ()
    list_1 = []
    set_1 = {tuple_1, tuple_1}
    int_1 = -2640
    var_0 = run(tuple_1, list_1, set_1, int_1)
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 08:05:51.306172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 08:06:00.720053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0._supports_check_mode = True
    action_module_0._supports_async = True
    var_0 = 'ansible.legacy.yum'
    action_module_0.run(var_0, var_0)
    action_module_0.run(var_0, var_0)
    action_module_0.run(var_0, var_0)
    action_module_0.run(var_0, var_0)
    action_module_0.run(var_0, var_0)
    action_module_0.run(var_0, var_0)
    action_module_0.run(var_0, var_0)
    action_

# Generated at 2022-06-25 08:06:12.108343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0]
    list_0 = [list_0, list_0, list_0, list_0, list_0, list_0, list_0]
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0]
    list_0 = [tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, list_0, tuple_0]
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640

# Generated at 2022-06-25 08:06:38.251609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-25 08:06:39.606797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule != None)


# Generated at 2022-06-25 08:06:43.569396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    var_0 = action_run()
    print(var_0)

# Generated at 2022-06-25 08:06:51.052815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 08:06:56.065091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = 189
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:07:04.044396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = 0
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    tuple_1 = ()
    list_1 = []
    set_1 = {tuple_1, tuple_1}
    int_1 = 0
    action_module_1 = ActionModule(tuple_1, list_1, set_1, int_1, list_1, list_1)
    tuple_2 = ()
    list_2 = []
    set_2 = {tuple_2, tuple_2}
    int_2 = -2

# Generated at 2022-06-25 08:07:11.179696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_cases = [
        # 0: 
        {
            "expected": None,
            "input": {
                "tmp": None,
                "task_vars": None,
            }
        },
        # XXX
    ]

    for index, test_case in enumerate(test_cases):
        assert_equal(test_case['expected'], test_case['action_module_run'](), 'Failed test case #{0}'.format(index))

test_case_0()

# Generated at 2022-06-25 08:07:16.371128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    assert(action_module_0.TRANSFERS_FILES == False)


# Generated at 2022-06-25 08:07:17.330002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)


# Generated at 2022-06-25 08:07:26.198751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -1690
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    dict_0 = action_module_0.run()
    var_0 = dict_0.get('failed')
    var_1 = dict_0.get('ansible_facts')
    var_2 = dict_0.get('msg')
    var_3 = dict_0.get('rc')
    var_4 = dict_0.get('stderr')
    var_5 = dict_0.get('stderr_lines')
    var_6 = dict_0.get('stdout')
    var

# Generated at 2022-06-25 08:08:17.468649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

##################################################################################
# Unit testing for class ActionModule ends here
##################################################################################

# Generated at 2022-06-25 08:08:23.012135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor
    from ansible.errors import AnsibleActionFail
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    tmp = None
    task_vars = None
    tuple_1 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:08:27.640462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    var_0 = action_module_0.run(action_module_0, action_module_0)


# Generated at 2022-06-25 08:08:32.382708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    var_1 = action_run()
    print(var_1)

# Boilerplate

# Generated at 2022-06-25 08:08:37.326737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 08:08:40.786899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 08:08:44.781631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -4500
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    var_0 = action_module_0.run(list_0, list_0)
    print(var_0)

# Generated at 2022-06-25 08:08:45.700270
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # run one some static data
    test_case_0()

    return 0


# Generated at 2022-06-25 08:08:48.522676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_1 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 08:08:54.188933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = 2601
    str_0 = 'Y5g5f5S5'
    list_1 = [str_0, str_0, str_0, str_0, str_0]
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_1)
    var_0 = action_module_0.run(tuple_0, list_0)
    # AssertionError: "Could not detect which major revision of yum is in use, which is required to determine module backend. You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum

# Generated at 2022-06-25 08:10:37.198943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:10:42.607293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    assert action_module_0.Elist[0] == set_0
    assert action_module_0.Elist[1] == list_0
    assert action_module_0.Elist[2] == list_0
    assert action_module_0.Elist[3] == set_0
    assert action_module_0.Elist[4] == list_0


# Generated at 2022-06-25 08:10:49.735797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assignment statements
    tuple_0 = (34, )
    list_0 = []
    set_0 = {tuple_0, }
    int_0 = -3
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    function_prototype = action_module_0.run()
    
    # Testing condition for if statement
    if (var_1 != var_2):
        var_3 = var_4
    if (var_3 == var_4):
        var_5 = var_6
    else:
        var_5 = var_7
    
    var_8 = var_5
    
    return var_5

if __name__ == '__main__':
    test_case_0()
    test

# Generated at 2022-06-25 08:10:55.053157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_1 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    assert id(action_module_0) == id(action_module_1)


# Generated at 2022-06-25 08:10:58.720673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 != None

# Generated at 2022-06-25 08:11:05.023099
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:11:12.594912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    dict_0 = dict()
    dict_1 = dict()
    var_0 = action_module_0.run(dict_0, dict_1)

# Demo of unit test running
if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 08:11:18.039750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)

    action_module_0.action_loader

    action_module_0.task_executor

    action_module_0.task_loader

    action_module_0.task_queue_manager

    action_module_0._add_default_args()

    action_module_0._clear_pattern_cache()

    action_module_0._execute_module()

    action_module_0._execute_module_with_become()

    action_module_0._execute_module_with_become_and_check_

# Generated at 2022-06-25 08:11:26.542809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    action_module_1 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    assert action_module_1._task == action_module_1._task


# Generated at 2022-06-25 08:11:30.442547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    list_0 = []
    set_0 = {tuple_0, tuple_0}
    int_0 = -2640
    action_module_0 = ActionModule(tuple_0, list_0, set_0, int_0, list_0, list_0)
    action_module_0.run()
