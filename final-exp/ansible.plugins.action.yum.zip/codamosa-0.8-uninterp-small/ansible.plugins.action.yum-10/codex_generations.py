

# Generated at 2022-06-25 08:02:24.394817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:02:25.741371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:02:31.260612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test objects
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    str_0 = 'prepend colon-separated path(s) to module library (default=%s)'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, str_0, list_0, bool_0, str_0, tuple_0)

    # Call function
    result = action_module_0.run()

    assert result is None

# Generated at 2022-06-25 08:02:31.971153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:02:33.859243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Test functions to handle class functionality

# Generated at 2022-06-25 08:02:38.007674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0]
    str_0 = 'prepend colon-separated path(s) to module library (default=%s)'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, str_0, list_0, bool_0, str_0, tuple_0)
    assert(action_module_0.run().get('ansible_facts').get('pkg_mgr') == 'auto')

# Generated at 2022-06-25 08:02:40.358439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup test data
    tmp = "temp_string"
    task_vars = dict()

    # expected result
    result = dict()

    # call method to be tested
    actual_result = action_module_0.run(tmp, task_vars)

    # verify results
    assert actual_result == result

# Generated at 2022-06-25 08:02:43.487112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(    )
    assert isinstance(action_module_0._shared_loader_obj, AnsibleLoader)
    assert type(action_module_0._shared_loader_obj) == AnsibleLoader
    assert isinstance(action_module_0.action_loader, DataLoader)
    assert type(action_module_0.action_loader) == DataLoader


# Generated at 2022-06-25 08:02:55.164746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments
    task_num = 0
    task_vars = {}

    # Test error handling
    if task_num == 0:
        try:
            # Raise exception
            raise AnsibleActionFail("parameters are mutually exclusive: ('use', 'use_backend')")
        except AnsibleActionFail:
            pass

    # Test action plugin execution
    if task_num == 1:
        for module in VALID_BACKENDS:
            action_module_0 = ActionModule([], module, [], False, "auto", ())
            result = action_module_0.run(None, task_vars)

    if task_num == 2:
        action_module_0 = ActionModule([], False, [], False, "auto", ())
        result = action_module_0.run(None, task_vars)



# Generated at 2022-06-25 08:02:56.056094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:03:06.338076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule()
    module_0 = obj_0.run


# Generated at 2022-06-25 08:03:12.427476
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:03:16.169985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    test_case_0()

# Generated at 2022-06-25 08:03:18.053554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    print(test_ActionModule_run())

# Generated at 2022-06-25 08:03:20.792260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing Method run of Class ActionModule')
    x = ActionModule()
    x._task = dict()
    x._task.args = dict()
    x._task.args['arg_0'] = 'temp_string'
    x._task.args['arg_1'] = dict()
    x._task.args['arg_2'] = dict()
    result = x.run('temp_string')
    assert result == {}

# Generated at 2022-06-25 08:03:23.879248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:03:27.761647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup:
    # test:

    # teardown:
    pass


# Generated at 2022-06-25 08:03:28.607155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_class_instance_0 = ActionModule()


# Generated at 2022-06-25 08:03:29.918617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'temp_string'
    var_0 = dict()
    var_1 = dict()

    var_0 = 'yum'
    var_1 = 'auto'

# Generated at 2022-06-25 08:03:32.139826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._shared_loader_obj != None
    assert action._templar != None


# Generated at 2022-06-25 08:03:47.297002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = ":r-n'5@5HjyBhQ#5b:"
    dict_1 = {}
    str_1 = ">.6&jGq!_b!)(y}x%c"
    float_0 = 127.19566
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_1, str_1, float_0, bool_0)


# Generated at 2022-06-25 08:03:55.494977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_1 = {}
    str_1 = "KV7%c^?Ks=i*#-&W^Nzd@"
    dict_2 = {}
    str_2 = "y/<-\"*S^Fc`W]3qmHez("
    float_1 = -10.12
    bool_1 = True
    action_module_1 = ActionModule(dict_1, str_1, dict_2, str_2, float_1, bool_1)
    assert action_module_1._supports_check_mode == True
    assert action_module_1._supports_async == True
    assert action_module_1._task.args['use'] == 'auto'
    assert action_module_1._task.args['use_backend'] == 'auto'
    assert action_

# Generated at 2022-06-25 08:03:58.966959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_run()
    assert var_0 == None

# Header end

# Generated at 2022-06-25 08:04:07.380418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "N<%v=9G@W8$b/z,l;/J"
    dict_1 = {}
    str_1 = "x}Od>|R`[D6uK7?U_3G"
    float_0 = -31.73787354409597
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_1, str_1, float_0, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 08:04:14.209908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for class ActionModule
    class_instance = ActionModule()
    options = {'name': 'test', 'state': 'present'}
    task_vars = {}
    delegate_to = 'localhost'
    module_name = 'yum'
    display.deprecated("'run' is deprecated as an ActionModule constructor. Use '_execute_module' instead.",
                       version='2.13')
    loader = 'loader'
    templar = 'templar'
    shared_loader_obj = 'shared_loader_obj'
    connection_info = 'connection_info'
    action_module_0 = ActionModule(options, task_vars, delegate_to, loader)
    print(action_module_0._execute_module(module_name, options, task_vars, wrap_async=None))
    print

# Generated at 2022-06-25 08:04:21.854941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    assert action_module_0._shared_loader_obj._module_cache is None


# Generated at 2022-06-25 08:04:28.902137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        dict_0 = {}
        str_0 = "'2U:?eCd!d4V!N/y0nI["
        float_0 = -252.72154
        bool_0 = False
        action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
        action_module_run(action_module_0)
    except KeyError:
        if (type(action_module_0) is str):
            print("\nFatal Python error: Cannot delete collection key")
        else:
            print("\nFatal Python error: Invalid object for action_module_0")
    except ValueError:
        print("\nFatal Python error: Invalid object for action_module_0")
    except TypeError:
        print

# Generated at 2022-06-25 08:04:39.511250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    dict_1 = {}
    dict_2 = {}
    dict_0 = {"tmp": dict_1, "task_vars": dict_2}
    str_1 = "R;1"
    dict_3 = {"use": str_1}
    action_module_0 = ActionModule(dict_0, str_0, dict_3, str_0, float_0, bool_0)
    var_0 = action_module_0.run()
    assert(var_0.msg == "")
    assert(var_0.status == "done")



# Generated at 2022-06-25 08:04:46.012089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_4 = action_run()
    var_4 = action_run(dict_0)
    var_4 = action_run(dict_0, dict_0)
    var_4 = action_run(dict_0, dict_0, dict_0)
    var_4 = action_run(dict_0, dict_0, dict_0, dict_0)

# Generated at 2022-06-25 08:04:52.816482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -252.72154
    bool_0 = False
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    action_module_0.tmp = str_0
    action_module_0.task_vars = None
    var_0 = action_module_0.run()
    assert var_0 == None

test_case_0()

# Generated at 2022-06-25 08:05:09.037798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "fM|Q%}j>Y=aQ9q<3qj)"
    dict_1 = {}
    str_1 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    test_ActionModule_0 = ActionModule(dict_0, str_0, dict_1, str_1, float_0, bool_0)

# Generated at 2022-06-25 08:05:11.738079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_run()


# Generated at 2022-06-25 08:05:21.621110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)

    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
   

# Generated at 2022-06-25 08:05:23.963366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert isinstance(ActionModule.run, types.MethodType)
    # assert (not isinstance(ActionModule, object))
    assert isinstance(ActionModule, object)
    assert isinstance(ActionModule.run, types.MethodType)
    assert not isinstance(ActionModule.run, object)


# Generated at 2022-06-25 08:05:32.901104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    assert isinstance(action_module_0, ActionModule)
    # test_case_0()
    # test_case_1()
    # test_case_2()
    # test_case_3()


# Generated at 2022-06-25 08:05:40.968096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    boolean_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, boolean_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 08:05:49.632079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_1 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    action_module_1.run()
    var_0 = display.display()


# Generated at 2022-06-25 08:05:55.192197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = ":c'k-w`I[?jn5n5@|>S,5"
    dict_1 = {
    'AnsibleFacts': {
    'ansible_pkg_mgr': 'yum',
    },
    }
    str_1 = 'ansible.legacy.yum'
    str_2 = "ansible_pkg_mgr"
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_module_0.run(dict_0, dict_1)
    return (var_0, str_1, str_2)


# Generated at 2022-06-25 08:06:04.141511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.__class__.__name__ == 'ActionModule'
    assert action_module_0._priority == float_0
    assert action_module_0._supports_async == bool_0
    assert action_module_0._supports_check_mode == bool_0
    assert action_module_0._async_timeout == float_0
    assert action_module_0._connection._play_context.remote_addr == str_0
    assert action_module_0._connection._shell.env == dict_0
    assert action_module_0._connection._shell.executable == dict_0
    assert action_module_0._connection._shell.tmpdir == str_0
    assert action_module_0._connection._shell.variables.__class__.__name__ == 'str'
    assert action_module

# Generated at 2022-06-25 08:06:08.807360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    # AssertionError: AssertionError("'_empty_action' method is not implemented")


# Generated at 2022-06-25 08:06:44.789857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    dict_1 = {}
    str_1 = "YWU%M6Fy9XVl!5!5l5jK"
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_1, str_1, float_0, bool_0)
    return action_module_0

if __name__ == '__main__':
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    dict_1 = {}

# Generated at 2022-06-25 08:06:50.958344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {"p6P>U=I}@": "R^izG[HN;D", "qX>2_rN/Pv": 9.98989967, "hD4O?O-k0Y": -0.648729}
    str_0 = "5_t:*%cB?7"
    dict_1 = {";u]*9Mml7V": "0", ".^7V,=q3_4": 1, "-P#;N?Yd9b": -5}
    str_1 = "fh<c:?n@,d"
    float_0 = -0.4444444444444444
    bool_0 = True

# Generated at 2022-06-25 08:06:54.265184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "Async"
    float_0 = 0.5
    bool_0 = False
    action_module_0 = ActionModule(dict_0, None, None, str_0, float_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 08:06:58.382228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    if action_module_0.TRANSFERS_FILES is True:
        assert False
    if action_module_0.VALID_BACKENDS is False:
        assert False


# Generated at 2022-06-25 08:07:02.769101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 08:07:06.206939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    actions_plugin_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = actions_plugin_0.run()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 08:07:11.688389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    options = {'become': False, 'become_user': '', 'become_method': '', 'check': False, 'connection': 'network_cli', 'debug': False, 'diff': False, 'gather_facts': 'smart', 'module_name': 'yum', 'module_path': '/home/fran/devel/elasticsearch-ansible/roles/elasticsearch/library'}
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}
    module = 'ansible.legacy.yum'

    action_module_0 = ActionModule(task_vars, options, os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'yum', None, False)
    result = action_module_0

# Generated at 2022-06-25 08:07:18.009492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_run()
    print(var_0)


# Generated at 2022-06-25 08:07:27.115054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    assert len(action_module_0._task.args) == 0, "Failed to initialize action_module_0._task.args"
    assert action_module_0._task.action == "'2U:?eCd!d4V!N/y0nI[", "Failed to initialize action_module_0._task.action"

# Generated at 2022-06-25 08:07:38.521454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {
        'changed': True, 'changed_when_result': True, 'changed_when_result_item': True
    }
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    dict_1 = {
        'tasks': [{
            'bQ!': 'F', 'bQ!_result': 'F', 'bQ!_result_item': 'F'
        }]
    }
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_run(task_vars=dict_1)


# Generated at 2022-06-25 08:08:32.546274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:08:36.177691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Unit test for ActionModule.__init__
        test_case_0()
    except Exception as err:
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:08:43.559046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)

# Generated at 2022-06-25 08:08:46.256633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'yum': 'yum', 'dnf': 'dnf'}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0)

# Generated at 2022-06-25 08:08:54.973794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_run()
    assert var_0 == 'ansible.legacy.yum4'

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 08:08:58.000980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:09:03.498104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 08:09:06.130641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    assert(isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 08:09:10.742793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    action_run_0 = {'a': 'b'}
    var_0 = action_run()

# Generated at 2022-06-25 08:09:15.612519
# Unit test for constructor of class ActionModule
def test_ActionModule():

    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)


# Generated at 2022-06-25 08:11:04.813006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_1 = {}
    str_1 = "'2U:?eCd!d4V!N/y0nI["
    dict_2 = {}
    str_2 = "'2U:?eCd!d4V!N/y0nI["
    float_1 = -252.72154
    bool_1 = False
    action_module_1 = ActionModule(dict_1, str_1, dict_2, str_2, float_1, bool_1)
    var_1 = action_module_1.run(action_run(), action_run())

# Generated at 2022-06-25 08:11:11.741172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    action_module_0.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 08:11:18.373620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    state = 'present'
    name = 'git'
    action = 'install'
    use = 'auto'
    dnf_module = 'package.dnf'
    yum_module = 'package.yum'

    # test for dnf backend
    mock_task = Mock(spec=dict)
    mock_task.async_val = 20
    mock_task.args = {'use': use, 'name': name, 'state': state, 'action': action}  # use is really use_backend
    mock_templar = Mock(spec=Templar)
    mock_templar.template.return_value = 'dnf'
    mock_shared_obj = Mock(spec=SharedLoaderObj)
    mock_module_loader = Mock(spec=module_loader.ModuleLoader)
    mock_

# Generated at 2022-06-25 08:11:26.074835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    assert action_module_0.task == dict_0


# Generated at 2022-06-25 08:11:30.808243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 08:11:37.564696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = "F32y'"
    dict_1 = {}
    str_1 = "G!#@Zw.G0%I.AG&eT"
    float_0 = -93.93875
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_1, str_1, float_0, bool_0)
    assert_equals(action_module_0._task, dict_0)
    assert_equals(action_module_0._connection, str_0)
    assert_equals(action_module_0._play_context, dict_1)
    assert_equals(action_module_0._loader, str_1)

# Generated at 2022-06-25 08:11:42.146527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("TESTING constructor for class ActionModule")
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0,str_0,dict_0,str_0,float_0,bool_0)
    print("Class ActionModule constructed")


# Generated at 2022-06-25 08:11:51.549832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import ansible_collections.ansible.legacy.plugins.action
    import ansible_collections.ansible.legacy.plugins.action.yum

    module_target = ansible_collections.ansible.legacy.plugins.action.yum
    reload(module_target)
    module_name = 'ansible_collections.ansible.legacy.plugins.action.yum'
    module_target = sys.modules[module_name]
    cls = getattr(module_target, 'ActionModule')
    tmp_0 = None
    task_vars_0 = None
    # Call method run of ActionModule class
    result = cls.run(tmp_0, task_vars_0)
    assert len(result) == 3
    tmp_1 = None
    task_vars

# Generated at 2022-06-25 08:11:54.782578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "'2U:?eCd!d4V!N/y0nI["
    float_0 = -252.72154
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, float_0, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 08:11:59.341300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
