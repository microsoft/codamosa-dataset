

# Generated at 2022-06-25 08:02:28.940691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(bool_0)
    assert(action_module_0._task == bool_0)
    assert(action_module_0._connection == complex_0)
    assert(action_module_0._play_context == int_0)
    assert(action_module_0._loader == str_0)
    assert(action_module_0._templar == str_0)
    assert(action_module_0._shared_loader_obj == bool_0)
    assert(isinstance(action_module_0, ActionBase))


# Generated at 2022-06-25 08:02:29.865351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:02:36.641365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        action=dict(module_name='yum', module_args=""),
        async_val=0,
        delegate_to='',
        delegate_facts=False,
        environment=None,
        noop_task=False,
        role=None,
        role_name=None,
        task_vars={'ansible_facts': {'pkg_mgr2': 'auto', 'ansible_pkg_mgr': 'yum'}},
    )
    tmp = ''

# Generated at 2022-06-25 08:02:39.065231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 08:02:46.210200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = 1
    task_vars_0 = 'n6'
    action_module_0 = ActionModule('zzMsx', 'CX[;f', 'L-#7K', 'D:0!7', '6y[er', 'Iu#11')
    result_0 = action_module_0.run(tmp_0, task_vars_0)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 08:02:52.131540
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    assert action_module_0.run(tmp, task_vars) is None

# Generated at 2022-06-25 08:02:58.225197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    complex_0 = None
    int_0 = -1132
    str_0 = '}DWwTr'
    action_module_0 = ActionModule(bool_0, complex_0, int_0, str_0, str_0, bool_0)

    action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 08:03:00.223741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:03:01.779736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Main function
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:06.997488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(False, 0j, 0, '~Z', 'J', True)
    action_module_0.run(None, None)
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 08:03:19.964202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 08:03:23.249680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    raise Exception("Not implemented")

# Generated at 2022-06-25 08:03:24.344721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule()

# Generated at 2022-06-25 08:03:33.122589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input:
    tmp = None
    task_vars = None
    # Output:
    result = {
        'failed': False,
        'module_stderr': '',
        'module_stdout': "",
        'msg': '',
        'rc': 0,
        'stderr': '',
        'stdout': "",
        'stdout_lines': []
    }
    # Expected Output:
    expected_result = result
    # Run test
    test_case_0()
    # Compare results
    assert result == expected_result, 'Test failed'
    # Test passed
    print('Test complete.')



# Generated at 2022-06-25 08:03:35.276735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case of no argument
    test_case_0()


if __name__ == '__main__':
    """
    Test 
    """
    test_ActionModule()

# Generated at 2022-06-25 08:03:36.745341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization of the class
    action_module_0 = ActionModule()

    # Call the test case
    test_case_0()



# Generated at 2022-06-25 08:03:38.345562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = None
    var_1 = None
    var_2 = action_run(var_0, var_1)

# Generated at 2022-06-25 08:03:39.637651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_3 = action_module0()
    var_3.run(var_0, var_1)


# test


# Generated at 2022-06-25 08:03:46.005383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = None
    var_1 = None
    var_2 = ActionModule.run(var_0, var_1)

# Generated at 2022-06-25 08:03:51.143173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = None
    var_1 = None
    var_2 = action_run(var_0, var_1)


# Generated at 2022-06-25 08:03:58.801320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:04:06.536516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
#    return_value_0 = action_module_0.run(module='auto', task_vars={'ansible_pkg_mgr': 'dnf'})
    return_value_1 = action_module_0.run(module='auto', task_vars={'ansible_pkg_mgr': 'yum'})
#    assert return_value_0 == return_value_1

# Generated at 2022-06-25 08:04:09.940435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 08:04:15.151436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    test_case_0()
    print("end test_ActionModule")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:04:19.047619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert type(action_module_1._supports_check_mode) is bool and type(action_module_1._supports_async) is bool and type(action_module_1.VALID_BACKENDS) is frozenset
    assert action_module_1._supports_check_mode == True and action_module_1._supports_async == True and action_module_1.VALID_BACKENDS == frozenset(('yum', 'yum4', 'dnf'))


# Generated at 2022-06-25 08:04:21.525394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:04:23.932876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

# Generated at 2022-06-25 08:04:27.758632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 08:04:33.339910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Calling run method of ActionModule class
    result = action_module_0.run(
        tmp=None, task_vars=None
    )

    assert result is not None
    assert result['failed']
    assert result['msg'] == ("Could not detect which major revision of yum is in use, which is required to determine module backend.",
                             "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})")

    assert result['failed']

# Generated at 2022-06-25 08:04:40.960101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")

    result = {}

    class Mock_Task:
        def __init__(self):
            self.args = {'name': 'vim'}

    class Mock_ActionBase:
        def run(self, tmp=None, task_vars=None):
            return result

    mock_task = Mock_Task()
    mock_Base = Mock_ActionBase()

    # Result should contain this value
    result = {"failed": True, "msg": "parameters are mutually exclusive: ('use', 'use_backend')"}

    action_module_0 = ActionModule()
    action_module_0._task = mock_task
    action_module_0._action_base = mock_Base

    # Now, test the run method

# Generated at 2022-06-25 08:04:57.353475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Start: test_ActionModule")

    action_module_1 = ActionModule()

    # No exception thrown
    assert True

    print("End: test_ActionModule")


# Generated at 2022-06-25 08:04:58.836643
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_1 = ActionModule()

    print("Created ActionModule")


# Generated at 2022-06-25 08:05:02.183591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Test 1
    # fixture:
    # Test run of class ActionModule.
    # It was created above
    import ansible.module_utils as module_utils
    module_utils.basic._ANSIBLE_ARGS = None

    test_case_0()

    # Test 2
    # fixture:
    # Test run of class ActionModule.
    # It was created above
    test_case_0()

# Generated at 2022-06-25 08:05:03.472695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:05:04.519505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructor test case for class ActionModule")
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:05:05.748864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 08:05:11.165688
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testing for correct args
    task_vars_0 = dict()

    module_args_0 = dict()

    module_args_1 = dict()
    module_args_1['use'] = "auto"

    # Testing with optional argument tmp not specified
    result_0 = action_module_0.run(task_vars=task_vars_0)

    assert type(result_0) is dict

    # Testing with optional argument task_vars not specified
    result_1 = action_module_0.run()

    assert type(result_1) is dict

    # Testing with optional arguments tmp and task_vars not specified
    result_2 = action_module_0.run()

    assert type(result_2) is dict

    # Testing with both optional arguments tmp and task_vars specified
    result_3 = action_

# Generated at 2022-06-25 08:05:13.134429
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert_equal(action_module_0.__class__.__name__, "ActionModule")


# Generated at 2022-06-25 08:05:17.043817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module.action_name == 'yum')
    assert(action_module.transfers_files == False)

# Generated at 2022-06-25 08:05:18.879013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 08:05:42.859832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy objects for test
    expected_result = dict(
        {u'rc': 0, u'warnings': [], u'failed': False, u'ansible_facts': None, u'delta': {u'end': u'2018-06-10 11:05:07.879116', u'start': u'2018-06-10 11:05:07.831326'}, u'changed': False, u'start': u'2018-06-10 11:05:07.831326', u'invocation': dict({u'module_args': dict({u'delegate_to': None, u'use_backend': None, u'use': u'auto'})})})

    # Test routine:
    test_case_0()
    # Verify result:
    assert expected_result == None


# Generated at 2022-06-25 08:05:46.764949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 08:05:52.897977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case data
    tmp = None
    task_vars = {
      "var1": "value1",
      "var2": "value2"
    }

    # Perform the test
    test_case_0_action_module_run_obj = ActionModule()
    result = test_case_0_action_module_run_obj.run(tmp, task_vars)

    # Establish that the results are as expected

# Generated at 2022-06-25 08:05:53.392356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1 == 1


# Generated at 2022-06-25 08:05:53.883212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-25 08:06:01.492730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    task_vars_0 = {}
    task_vars_0['ansible_pkg_mgr'] = 'yum'
    task_vars_0['ansible_facts'] = {}
    task_vars_0['ansible_facts']['pkg_mgr'] = 'yum'

    task_vars_1 = {}
    task_vars_1['ansible_pkg_mgr'] = 'dnf'
    task_vars_1['ansible_facts'] = {}
    task_vars_1['ansible_facts']['pkg_mgr'] = 'dnf'

    # These tests for the run method in this class may need a connection to remote/local hosts. Instead of using
    # a connection directly, use a 'Connection' object.

   

# Generated at 2022-06-25 08:06:12.152622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_args_0 = dict()
    task_vars_0 = dict()
    action_module_0._templar = AnsibleTemplar()
    action_module_0._task = AnsibleTask()
    action_module_0._task.args = task_args_0
    action_module_0._task.delegate_to = "inventory_hostname"
    action_module_0._connection = AnsibleConnection()
    action_module_0._connection._shell = AnsibleShell()
    action_module_0._shared_loader_obj = AnsibleModuleLoader()
    action_module_0._shared_loader_obj.module_loader = AnsibleModuleLoader()
    action_module_0._task.async_val = "none"
    result = action_module_

# Generated at 2022-06-25 08:06:16.929750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule()
  assert action_module_0.run() == None


# Generated at 2022-06-25 08:06:18.450704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as e:
        print("Exception in constructor of class ActionModule", e)


# Generated at 2022-06-25 08:06:19.983368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    action_module_1 = ActionModule()

## Test cases for ActionModule
test_ActionModule()

# Generated at 2022-06-25 08:06:34.852676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test inputs and outputs
    action_module_0 = ActionModule()
    assert isinstance(action_module_0.run(), dict)

# Generated at 2022-06-25 08:06:41.401915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bool_0 = False
  bool_1 = True
  str_0 = 'M26J3'
  float_0 = 2.0
  int_0 = 2231
  float_1 = 2433.0
  action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
  var_0 = action_run()


# Generated at 2022-06-25 08:06:48.216789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = '4aTMDX:q_*i$W'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = 'auto'
    var_1 = 'yum3'
    var_2 = 'yum4'
    var_3 = 'dnf'
    var_4 = 'yum4'
    var_5 = 'yum4'
    var_6 = 'yum4'
    var_7 = 'yum4'
    var_8 = 'yum4'

# Generated at 2022-06-25 08:06:49.563801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:06:54.513195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    str_0 = 'o`?T,]~N$9'
    float_0 = 11.0
    int_0 = 18
    float_1 = 2281.0
    int_1 = 2
    action_module_0 = ActionModule(bool_1, str_0, float_0, int_0, float_1, int_1)
    assert action_module_0 is not None


# Generated at 2022-06-25 08:07:04.069400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = ':a~Zzj|'
    float_0 = 0.0
    int_0 = 0
    float_1 = 0.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = 7
    var_1 = 'DqO@o!h'
    var_2 = 'S(~8.%W'
    var_3 = 'Jp!@<^'
    var_4 = '2Zr3|JT'
    var_5 = 'sdX[^/'
    var_6 = '+j#JZ'
    var_7 = '=j+/'

# Generated at 2022-06-25 08:07:12.816846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '5`DkR(Io+O'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    assert action_module_0._shared_loader_obj._owner._action_plugins == action_module_0._shared_loader_obj._owner._action_plugins
    assert action_module_0._shared_loader_obj._owner._connection_plugins == action_module_0._shared_loader_obj._owner._connection_plugins
    assert action_module_0._shared_loader_obj._owner._filter_plugins == action_module_0._shared_loader

# Generated at 2022-06-25 08:07:15.280892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = 'g0}z-U6^eUH'
    float_0 = 1.0
    int_0 = 4154
    float_1 = 1520.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)

# Generated at 2022-06-25 08:07:21.871766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '4aTMDX:q_*i$W'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)


# Generated at 2022-06-25 08:07:27.926361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = 'nXJQW|+j$`>o=7:'
    float_0 = 5636.0
    int_0 = 9010
    float_1 = 805.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = dict()
    var_1 = dict()
    var_1['failed'] = True
    var_1['msg'] = 'hi'
    var_0['failed'] = var_1
    var_2 = dict()
    var_2['ansible_facts'] = dict()
    var_2['ansible_facts']['pkg_mgr'] = 'yum'

# Generated at 2022-06-25 08:08:04.831196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '|5~`D>y_N'
    float_0 = 7.0
    int_0 = 0
    float_1 = 2931.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()

# Generated at 2022-06-25 08:08:09.803287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = '4aTMDX:q_*i$W'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 08:08:14.527132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = 'j9hR'
    float_0 = 0.0
    int_0 = 5
    float_1 = 0.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    action_module_0.run()


# Generated at 2022-06-25 08:08:22.200955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = True
    str_0 = '#'
    float_0 = 1.0
    int_0 = 0
    float_1 = 16439.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    tmp = None
    task_vars = None
    assert action_module_0.run(tmp, task_vars)

# aatest-replay

# Generated at 2022-06-25 08:08:25.063680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule
    action_module_0.run()
    return


# Generated at 2022-06-25 08:08:34.277986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = '-.fs9*^n-pUM'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = action_run()
    assert var_0 == {'ansible_facts': {'pkg_mgr': 'auto'}, 'changed': False, 'failed': True, 'invocation': {'module_name': 'yum'}, 'task': 'Test the yum3 vs yum4 action plugin'}
    var_1 = action_run()

# Generated at 2022-06-25 08:08:38.872837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '4aTMDX:q_*i$W'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    assert action_module_0 is not None

# Generated at 2022-06-25 08:08:42.747512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '4aTMDX:q_*i$W'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)


# Generated at 2022-06-25 08:08:46.383749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initializing a class object
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:08:50.669762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print()
#    test_case_0()
    test_case_1()


# Generated at 2022-06-25 08:09:51.183735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock object
    class TestActionModule_run(ActionBase):
        _supports_check_mode = True
        _supports_async = True
        TRANSFERS_FILES = False
        def _execute_module(self, module_name, module_args=None, task_vars=None, wrap_async=None):
            return _execute_module(module_name, module_args=None, task_vars=None, wrap_async=None)
        def _remove_tmp_path(self, tmp_path):
            return _remove_tmp_path(tmp_path)
    # Run method using mock object
    action_module_1 = TestActionModule_run(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = action_module

# Generated at 2022-06-25 08:09:52.273201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:10:01.829229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = 'Ige'
    float_0 = 2.0
    int_0 = 0x1496
    float_1 = 3.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = action_module_0.action_base_0
    var_1 = action_module_0.action_base_0
    var_2 = action_module_0.task_0
    var_3 = action_module_0.task_0
    bool_2 = bool_0
    str_1 = '$ZS5}5jn&'
    str_2 = 'y4jR'
    int_1 = int_0
   

# Generated at 2022-06-25 08:10:04.927848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '4aTMDX:q_*i$W'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)


# Generated at 2022-06-25 08:10:11.635013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '4aTMDX:q_*i$W'
    float_0 = 2.0
    int_0 = 2231
    float_1 = 2433.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)

# Generated at 2022-06-25 08:10:21.301719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = 'vuzEb:W:)yL'
    float_0 = 2.0
    int_0 = 213
    float_1 = 0.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    var_0 = action_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 08:10:30.778326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = 'pkI(K%R\tl:>$J'
    float_0 = 2.0
    int_0 = 2230
    float_1 = 2432.0
    action_module_0 = ActionModule(bool_0, bool_1, str_0, float_0, int_0, float_1)
    tmp_0 = None
    task_vars_0 = None
    var_1 = action_module_0.run(tmp_0, task_vars_0)
    assert var_1 == "action_return"


# Generated at 2022-06-25 08:10:32.496372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 08:10:35.109573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = ('qvZ40gvn',)
    task_vars = ('mD@xv%c',)
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:10:36.748422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert(var_0 == None)