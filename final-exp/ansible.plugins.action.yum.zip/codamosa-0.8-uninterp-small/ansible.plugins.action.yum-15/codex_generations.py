

# Generated at 2022-06-25 08:02:28.909901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Object:
        def __init__(self, arg0):
            self.arg0 = arg0

    class Object0:
        def __init__(self):
            self.arg0 = Object(Object0)

    Object1 = Object(Object0)
    class_0 = Object0()
    class_1 = Object1
    class_1.arg0 = class_0
    actionModule = ActionModule()
    actionModule._supports_check_mode = True
    actionModule._supports_async = True

    task_vars = {
        'ansible_pkg_mgr': 'auto',
        'ansible_facts': {'pkg_mgr': 'auto'}
    }

    result = actionModule.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-25 08:02:31.000667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_ActionModule()

# Generated at 2022-06-25 08:02:34.583688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = (list_0,)
    dict_0 = {tuple_0: list_0, list_0: tuple_0, tuple_0: list_0}
    action_module_obj_0 = ActionModule()
    action_module_obj_0.run(tmp=True, task_vars=None)
    test_case_0()


# Generated at 2022-06-25 08:02:36.577703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None

    # test exception
    try:
        ActionModule.run(tmp, task_vars)
    except NotImplementedError:
        pass

# Generated at 2022-06-25 08:02:38.662179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_object = ActionModule()
    assert isinstance(actionmodule_object, ActionModule)


# Generated at 2022-06-25 08:02:42.067291
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    # Be aware these variables can be None/empty
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 08:02:43.986935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	result = True
	if result:
		pass
		# print("Test success")
	else:
		pass
		# print("Test fail")
		

if __name__ == '__main__':
	test_case_0()

# Generated at 2022-06-25 08:02:52.231381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    tuple_0 = (list_0,)
    dict_0 = {tuple_0: list_0, list_0: tuple_0, tuple_0: list_0}
    object_0 = object()
    object_0 = object()
    object_0 = object()
    object_0 = object()

    assert(callable(ActionModule.run))



# Generated at 2022-06-25 08:02:58.603733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def wrapper(tuple_0, dict_0):
        list_0 = list(tuple_0)
        tuple_0 = tuple(list_0)
    dict_0 = dict()
    dict_0 = {tuple_0: list_0, list_0: tuple_0, tuple_0: list_0}
    # Try to set the value of 'list_0' to 0
    list_0 = 0
    # Try to set the value of 'tuple_0' to 0
    tuple_0 = 0
    # Try to set the value of 'dict_0' to 1
    dict_0 = 1
    # Try to set the value of 'dict_0' to 'True'
    dict_0 = "True"
    # Try to set the value of 'dict_0' to 'True'

# Generated at 2022-06-25 08:03:00.277464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:03:09.893340
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule()

    tmp_1 = "tmp_1"
    task_vars_1 = "task_vars_1"

    result_1 = action_module_1.run(tmp=tmp_1, task_vars=task_vars_1)
    print(result_1)


# Generated at 2022-06-25 08:03:10.803286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:03:11.847758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 08:03:16.557298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0
    assert action_module_0.run() is None


# Generated at 2022-06-25 08:03:18.503278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 08:03:24.527445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result == None

# Comment on test case 0
# ======================

# Generated at 2022-06-25 08:03:25.248721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:03:33.583284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(action_module_0,'run')
    assert hasattr(action_module_0,'_shared_loader_obj')
    assert hasattr(action_module_0,'_task')
    assert hasattr(action_module_0,'_templar')
    assert hasattr(action_module_0,'_loader')
    assert hasattr(action_module_0,'_connection')
    assert hasattr(action_module_0,'_supports_check_mode')
    assert hasattr(action_module_0,'_supports_async')
    assert hasattr(action_module_0,'_display')
    assert hasattr(action_module_0,'_display')

# Generated at 2022-06-25 08:03:34.761948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule()
    assert action_module_obj is not None


# Generated at 2022-06-25 08:03:35.651211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:03:50.745209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._execute_module = lambda x, y, z: None
    action_module_1.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 08:03:56.430208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_1 = ActionModule()
    except Exception as e:
        assert(False), "exception caught: %s" % e


# Generated at 2022-06-25 08:03:58.070257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(type(action_module_0))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:03:58.860050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 08:04:08.284148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assigning parameter 'tmp'
    tmp = 'tmp_string'
    # Assigning parameter 'task_vars'
    task_vars = {'ansible_facts': {'pkg_mgr': 'yum'}}

    # Return value tests
    # Constructing the return value for method run of class ActionModule
    result = {'failed': True, 'msg': 'Could not detect which major revision of yum is in use, which is required to determine module backend. You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})'}

    # Constructing the return value for method run of class ActionModule
    result = {'ansible_facts': {'pkg_mgr': 'yum'}}
    # Constructing the return value for method run of class Action

# Generated at 2022-06-25 08:04:11.646933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    try:
        assert action_module_0
    except AssertionError:
        display.debug("Caught AssertionError...")
    else:
        display.debug("Expected an AssertionError to be caught here...")


# Generated at 2022-06-25 08:04:16.333172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Code in ActionModule is a direct copy from ActionModule.run()
# of ansible package.

# Generated at 2022-06-25 08:04:20.182862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert type(action_module_1) == ActionBase

# Generated at 2022-06-25 08:04:23.142088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule()
    except Exception as e:
        assert(False)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()
    print("Success")

# Generated at 2022-06-25 08:04:24.161900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 08:04:58.011931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input arguments
    action_module_run = ActionModule()
    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum4'
        }
    }
    # Output arguments
    output = {}
    # Expected output
    expected = {
        'ansible_facts': {
            'pkg_mgr': 'yum4'
        }
    }
    # Output from method run
    output = action_module_run.run(None, task_vars)
    assert(expected == output)


# Generated at 2022-06-25 08:04:59.210019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

test_ActionModule()

# Generated at 2022-06-25 08:05:04.237509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test for constructor of class ActionModule")
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:05:05.272850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule()
    action_module_2.run()


# Generated at 2022-06-25 08:05:10.920595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._task.args = dict(name=["mod_1", "mod_2"], state="present")
    # test with using action plugin as a module
    result_1 = action_module_1.run(tmp=None, task_vars=None)
    assert result_1['failed'] == False
    assert "msg" not in result_1
    assert result_1["module_name"] == 'ansible.legacy.yum'
    assert result_1["module_args"] == dict(name=["mod_1", "mod_2"], state="present")
    # test with using delegated action plugin as a module
    action_module_1._task.delegate_to = "host_2"
    action_module_1._task.async_val = 42


# Generated at 2022-06-25 08:05:19.825579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test environment
    # Create an instance of the action module
    action_module = ActionModule()
    # Set up the module data
    tmp = None
    #tmp = "testtmp"
    task_vars = None
    #task_vars = ["testtaskvars"]
    # Run the action module
    ret = action_module.run(tmp, task_vars)
    # Assert on the results
    assert ret != None, "ActionModule run test failed"
    assert ret['failed'] == False, "ActionModule run test failed"
    # Print message if success
    print("ActionModule run test passed")

# Generated at 2022-06-25 08:05:23.539638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ansible.modules.packaging.yum.ActionModule()
    assert type(module.run()) == dict

# Generated at 2022-06-25 08:05:28.955116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    result_1 = action_module_1.run(task_vars={'ansible_pkg_mgr': 'yum4'})
    # Test AnsibleActionFail raised by yum module.
    assert result_1['failed'] == True
    assert result_1['msg'] == "parameters are mutually exclusive: ('use', 'use_backend')"

# Generated at 2022-06-25 08:05:30.104814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Run test cases
#test_ActionModule()

# Generated at 2022-06-25 08:05:34.090005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None
    assert action_module_0._task is None

    action_module_1 = ActionModule()
    assert action_module_1 is not None
    assert action_module_1._task is None

    action_module_2 = ActionModule()
    assert action_module_2 is not None
    assert action_module_2._task is None


# Generated at 2022-06-25 08:06:28.450074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 08:06:29.521204
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert(isinstance(action_module_0, object))

# Generated at 2022-06-25 08:06:33.870522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    results = action_module_0.run(tmp=None, task_vars=None)
    assert results['failed'] == True
    assert results['msg'] == "parameters are mutually exclusive: ('use', 'use_backend')"

# Generated at 2022-06-25 08:06:35.535045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    # Check if instance
    assert isinstance(action_module, ActionModule)

    # Check for inherited methods
    assert hasattr(action_module, 'run')

# Generated at 2022-06-25 08:06:37.350372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

    action_module_0.run()

# Generated at 2022-06-25 08:06:42.942322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   
    action_module_0 = ActionModule()

    task_vars = {
        'ansible_facts': {
            'pkg_mgr': 'yum'
        },
        'ansible_facts': {
            'pkg_mgr': 'yum'
        },
    }
    tmp = None

    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 08:06:52.324681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Executing test case 0")
    action_module_0 = ActionModule()
    tmp = None
    task_vars = {'ansible_pkg_mgr': 'yum'}
    assert action_module_0.run(tmp, task_vars) == {'ansible_facts': {'pkg_mgr': 'yum'}, 'changed': False, 'msg': ''}

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:06:57.543213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_ = ActionModule()
    action_module_.run(tmp=None, task_vars=None)



# Generated at 2022-06-25 08:06:58.512065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert type(obj) == ActionModule


# Generated at 2022-06-25 08:07:05.614575
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:08:11.776688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2116
    set_0 = {int_0, int_0}
    bool_0 = False
    set_1 = {bool_0, bool_0, bool_0, bool_0}
    float_0 = -3508.83734
    float_1 = -1835.8779
    bytes_0 = b'\xff\x80\xff\x00\x00\x00\x00\x7f'
    tuple_0 = (bytes_0,)
    str_0 = ''
    str_1 = '~\n);'
    tuple_1 = (float_1, tuple_0, str_0, str_1)
    action_module_0 = ActionModule(bool_0, set_1, float_0, float_0, tuple_1, set_1)

# Generated at 2022-06-25 08:08:12.534043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 08:08:19.971720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2861
    set_0 = {int_0, int_0}
    bool_0 = True
    set_1 = {bool_0, bool_0, bool_0, bool_0}
    float_0 = -1192.34315
    float_1 = -2876.39
    bytes_0 = b']u\xefJ\xfbg\xc4\x1b\x07'
    tuple_0 = (bytes_0,)
    str_0 = ''
    str_1 = '~\n);X'
    tuple_1 = (float_1, tuple_0, str_0, str_1)
    action_module_0 = ActionModule(bool_0, set_1, float_0, float_0, tuple_1, set_1)
    assert action_module_

# Generated at 2022-06-25 08:08:20.784601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 08:08:29.823059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case description
    task_0 = {'args': {'use_backend': 'auto'}, 'delegate_to': '', 'async_val': 0, 'delegate_facts': 1, 'fail_key': ''}
    display_0 = Display()
    display_0.debug('Facts {dict}'.format(dict={}))
    task_vars_0 = {}
    action_module_0 = ActionModule(task_0, display_0)
    action_module_0.run(task_vars_0)

# Generated at 2022-06-25 08:08:35.779620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0, bool_0}
    bool_1 = False
    float_0 = 2489.6
    int_0 = -101
    tuple_0 = (bool_0, bool_0)
    action_module_0 = ActionModule(bool_0, set_0, float_0, int_0, tuple_0, set_0)



# Generated at 2022-06-25 08:08:36.717002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:08:46.777867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1477
    int_1 = 807
    set_0 = {int_0, int_1}
    bool_0 = False
    set_1 = {bool_0, bool_0}
    int_2 = 1518
    tuple_0 = (int_2,)
    int_3 = -2876.39
    set_2 = {int_1, int_3, int_3, int_0}
    action_module_0 = ActionModule(bool_0, set_1, int_3, set_2, tuple_0, set_0)
    var_0 = action_module_0.run()
    assert (var_0 == ())


# Generated at 2022-06-25 08:08:50.258185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-25 08:08:54.584393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule) is True


# Generated at 2022-06-25 08:10:48.884435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 1714
    set_0 = {int_0}
    bool_0 = True
    set_1 = {bool_0, bool_0, bool_0}
    float_0 = -2133.6754
    float_1 = -1259.6
    bytes_0 = b'\x84\x8b\xd4Z\x9a\x81\x9d\xcb\xd7\x03/}\xbe\xa8\x12\x82\xa9\x17\x1d\xf1\x0c\xa6'
    tuple_0 = (bytes_0,)
    str_0 = ''
    str_1 = '<41'
    tuple_1 = (float_1, tuple_0, str_0, str_1)

# Generated at 2022-06-25 08:10:51.971138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None, "Could not create object of class ActionModule"


# Generated at 2022-06-25 08:10:58.974165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    string_0 = 'o'
    bool_0 = True
    set_0 = {string_0, string_0, string_0, string_0, string_0}
    float_0 = 1152.48566
    float_1 = -2505.63
    tuple_0 = (-2505.63, float_1, string_0, string_0, string_0)
    action_module_0 = ActionModule(bool_0, set_0, float_0, float_0, tuple_0, set_0)
    test_case_0()

# Generated at 2022-06-25 08:11:07.117745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    set_0 = {int_0, int_0}
    bool_0 = True
    set_1 = {bool_0, bool_0, bool_0, bool_0}
    float_0 = 0.0
    float_1 = 0.0
    bytes_0 = b'\x00'
    tuple_0 = (bytes_0,)
    str_0 = ''
    str_1 = ''
    tuple_1 = (float_1, tuple_0, str_0, str_1)
    action_module_0 = ActionModule(bool_0, set_1, float_0, float_0, tuple_1, set_1)
    var_0 = action_module_0.run()
    if var_0 == var_0:
        pass
    else:
        raise

# Generated at 2022-06-25 08:11:13.940034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2955
    set_0 = {int_0, int_0}
    bool_0 = True
    set_1 = {bool_0, bool_0, bool_0, bool_0}
    float_0 = -1192.34315
    float_1 = -2876.39
    bytes_0 = b']u\xefJ\xfbg\xc4\x1b\x07'
    tuple_0 = (bytes_0,)
    str_0 = ''
    str_1 = '~\n);X'
    tuple_1 = (float_1, tuple_0, str_0, str_1)
    action_module_0 = ActionModule(bool_0, set_1, float_0, float_0, tuple_1, set_1)
    var_0 = action

# Generated at 2022-06-25 08:11:21.347317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2955
    set_0 = {int_0, int_0}
    bool_0 = True
    set_1 = {bool_0, bool_0, bool_0, bool_0}
    float_0 = -1192.34315
    float_1 = -2876.39
    bytes_0 = b']u\xefJ\xfbg\xc4\x1b\x07'
    tuple_0 = (bytes_0,)
    str_0 = ''
    str_1 = '~\n);X'
    tuple_1 = (float_1, tuple_0, str_0, str_1)
    action_module_0 = ActionModule(bool_0, set_1, float_0, float_0, tuple_1, set_1)
    var_0 = action

# Generated at 2022-06-25 08:11:22.604759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert True

# Generated at 2022-06-25 08:11:25.639694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run(set_0) == set_0

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 08:11:33.299348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2955
    set_0 = {int_0, int_0}
    bool_0 = True
    set_1 = {bool_0, bool_0, bool_0, bool_0}
    float_0 = -1192.34315
    float_1 = -2876.39
    bytes_0 = b']u\xefJ\xfbg\xc4\x1b\x07'
    tuple_0 = (bytes_0,)
    str_0 = ''
    str_1 = '~\n);X'
    tuple_1 = (float_1, tuple_0, str_0, str_1)
    action_module_0 = ActionModule(bool_0, set_1, float_0, float_0, tuple_1, set_1)


# Generated at 2022-06-25 08:11:39.300276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(True, set(), 0.0, 0.0, tuple(), set())


if __name__ == "__main__":
    test_case_0()