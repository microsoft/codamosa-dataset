

# Generated at 2022-06-25 08:02:24.358080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:02:29.842370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  float_0 = 858.65
  bytes_0 = b'\xaa\xa1\x1c\xad\xe9\x9c\xac\xed\xe8\x83l'
  bool_0 = False
  str_0 = 'b\x9b2\xfe'
  action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_0, str_0, str_0)
  action_module_0.run()


# Generated at 2022-06-25 08:02:36.608155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -367.2438
    bytes_0 = b'[\xec\xa1\x8bk\xe9\x9d\x85\x8d\x89\x81\xd0'
    bool_0 = True
    bool_1 = False

# Generated at 2022-06-25 08:02:47.391238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 17.1
    str_0 = 'Y97'
    dict_0 = dict()
    dict_0['abs'] = str_0
    dict_0['delta'] = float_0
    dict_0['gamma'] = str_0
    dict_0['beta'] = str_0
    dict_0['alpha'] = str_0
    dict_0['delta'] = str_0
    dict_0['alpha'] = float_0
    dict_0['epsilon'] = str_0
    dict_0['gamma'] = str_0
    dict_0['abs'] = str_0
    dict_0['epsilon'] = str_0
    dict_0['abs'] = str_0
    dict_0['epsilon'] = str_0

# Generated at 2022-06-25 08:02:57.567197
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:03:09.391360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.07
    bytes_0 = b'\x0f\x83\x9f\x91\x0b\xf0E\xfa\x97\x0e\x99\xcb\xd1\x9e\x94\xc8\xe6\xc0\x1f\xa5\x95\xef\x19\x1f\xd5\x81\xc2\x1b\x0b\xda'
    bool_0 = False
    str_0 = '\n\x1b\xa4\xac\xedA\xaa\x89\x15\x9e\xe5\xb8\x15\x86\xcf'

# Generated at 2022-06-25 08:03:14.339922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 967.556
    bytes_0 = b'\xfc\x0b\xbc\xa2\xce\x9b\xf6\xa9\xfa\x89\x92\x88]\x1fV\xa1\x8e\xe9\xde\xb7'
    bool_0 = False
    bool_1 = True
    str_0 = 'X7>'
    str_1 = '\xfd\xfe\xfd\xfb\xf7\xf0\xb8\xfe'
    action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_1, str_0, str_1)
    # Testing the method ActionModule.run
    action_module_0.run()

# Generated at 2022-06-25 08:03:18.279864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 825.866
    bytes_0 = b'\xd7\xa3\xe6E\xda\xe0q?\x00\xa6'
    bool_0 = False
    str_0 = 'D~%'
    action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_0, str_0, str_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:20.677963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for ActionModule
    test_ActionModule()

# Generated at 2022-06-25 08:03:28.830157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 759.646
    bytes_0 = b'\xd0\xc8\xa2\x04\xba\xba\x8b\xaf\x9f\xcb\x8f\xa4\x1f'
    bool_0 = False
    bool_1 = True
    str_0 = 'i3y'
    str_1 = ';0H-\x1b\x1f'
    action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_1, str_0, str_1)
    action_module_0.noop = True
    action_module_0.task_vars = dict()
    action_module_0._connection = dict()
    action_module_0.tmp = float_0
    action_module_

# Generated at 2022-06-25 08:03:37.292898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 08:03:37.913597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:03:39.678136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 17.1
    str_0 = 'Y97'
    var_0 = dict()

    return

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:46.590697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.yum import ActionModule
    action_module = ActionModule(None, None, None)
    assert action_module is not None

# Unit tests for class ActionModule
test_ActionModule_run()

# Generated at 2022-06-25 08:03:52.611393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    float_0 = 17.1
    str_0 = 'Y97'
    var_0 = dict()
    actionmodule = ActionModule(float_0, str_0)
    assert(actionmodule._task.async_val == False)
    assert(actionmodule._task.args == var_0)


# Generated at 2022-06-25 08:03:53.961793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj.run(tmp=test_case_0, task_vars=test_case_0)

# Generated at 2022-06-25 08:03:55.004863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 08:03:55.812759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__== '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 08:03:57.113523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_instance = ActionModule()
    assert class_instance.TRANSFERS_FILES == False


# Generated at 2022-06-25 08:04:01.963378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 17.1
    str_0 = 'Y97'
    var_0 = dict()
    float_1 = float(var_0)


# Generated at 2022-06-25 08:04:13.972495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:04:20.459207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True


# Generated at 2022-06-25 08:04:24.088293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    display.vvv("Testing ActionModule")
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-25 08:04:29.475816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module._supports_check_mode == True)
    assert(action_module._supports_async == True)

# Generated at 2022-06-25 08:04:31.404260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule().__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 08:04:36.450299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result == None

# Generated at 2022-06-25 08:04:39.459937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 08:04:43.899562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 08:04:47.005311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert action_module_0.run() == expected_results_module_0

# Generated at 2022-06-25 08:04:54.428460
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:05:12.197162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == None

# Generated at 2022-06-25 08:05:19.150983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Mockmodule(object):
        def __init__(self):
            self._supports_check_mode = False
            self._supports_async = False
    mock_module = Mockmodule()
    action_module = ActionModule(task=mock_module, connection=mock_module,
                                 play_context=mock_module, loader=mock_module,
                                 templar=mock_module, shared_loader_obj=mock_module)



# Generated at 2022-06-25 08:05:22.373830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    import inspect

    for name, obj in inspect.getmembers(ActionModule):
        if inspect.isfunction(obj):
            if name.startswith("test_"):
                print("Running %s..." % name)
                obj()
                print("%s passed!" % name)

# Generated at 2022-06-25 08:05:23.305970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 08:05:29.569440
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()
    action_module._task = {'async_val': 0, 'args': {'use': 'auto'}}
    action_module._templar = {'template': lambda x: 'yum'}
    action_module._shared_loader_obj = {'module_loader': {'has_plugin': lambda x: 0, '_find_plugin': lambda x: 0}}
    action_module._connection = {'_shell': {'tmpdir': '/tmp'}}
    action_module.run()

# Generated at 2022-06-25 08:05:35.559905
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:05:42.389599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run(tmp=None, task_vars=None) == dict(
        ansible_facts={"pkg_mgr": "auto"},
        changed=False,
        failed=True,
        msg=(
            "Could not detect which major revision of yum is in use, which is required to determine module backend.",
            "You should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend})"),
    )


# Generated at 2022-06-25 08:05:47.567928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 1
    action_module_1 = ActionModule()
    action_module_1.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 08:05:50.841736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if(action_module_0 is not None):
        print ("PASS")
    else:
        print ("FAIL")


# Generated at 2022-06-25 08:05:57.650762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert (action_module_0._supports_check_mode == True)
    assert (action_module_0._supports_async == True)
    assert (action_module_0.TRANSFERS_FILES == False)
    assert (action_module_0._task.delegate_to == None)
    assert (action_module_0._task.delegate_facts == None)
    assert (action_module_0._task.args == None)


# Generated at 2022-06-25 08:06:34.354766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os_facts = dict(pkg_mgr='yum')
    mock_object=type('',(object,),dict(task_vars=dict(ansible_facts=os_facts)))
    mock_object_instance=mock_object()
    hostvars = dict(host_to_delegate_to=dict(ansible_facts=os_facts))
    task_vars = dict(hostvars=hostvars)
    action_module_0 = ActionModule()
    retval = action_module_0.run(task_vars=task_vars)
    assert type(retval) == dict


# Generated at 2022-06-25 08:06:44.768833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = '/usr/lib/python2.7/dist-packages/ansible/modules/extras/packaging/os/yum.py'
    task_vars = {
        'ansible_facts': {'ansible_pkg_mgr': 'dnf'},
        'hostvars': {
            'test1': {'ansible_facts': {'pkg_mgr': 'dnf'}},
            'test2': {'ansible_facts': {'pkg_mgr': 'yum'}},
            'test3': {'ansible_facts': {'pkg_mgr': 'yum4'}},
            'test4': {'ansible_facts': {'pkg_mgr': 'package_manager'}}
        }
    }
    expected

# Generated at 2022-06-25 08:06:54.424976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # config
    task_vars = dict()

    # mocks
    action_module_1 = ActionModule()
    facts = dict()
    facts["ansible_pkg_mgr"] = "yum4"
    action_module_1.run.return_value = dict(ansible_facts=facts, msg="", failed=False)

    # test 1
    assert True == action_module_1.run(task_vars)

    # test 2
    action_module_1.run(task_vars)
    assert "ansible_facts" in action_module_1.run.return_value
    assert "msg" in action_module_1.run.return_value
    assert "failed" in action_module_1.run.return_value

# Generated at 2022-06-25 08:06:59.142648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pdb
    pdb.set_trace()
    action_module = ActionModule()
    action_module.run('tmp', task_vars={})


# Generated at 2022-06-25 08:07:00.709848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
#test_ActionModule()
test_case_0()

# Generated at 2022-06-25 08:07:03.435079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0()
    action_moduel_0 = ActionModule()
    action_moduel_1 = ActionModule(connection=None, _task=None, loader=None, templar=None, shared_loader_obj=None)



# Generated at 2022-06-25 08:07:12.783781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    ansible_modules_0 = action_module_0._shared_loader_obj.module_loader.path_exists("ansible.legacy.yum")
    ansible_modules_1 = action_module_0._shared_loader_obj.module_loader.path_exists("ansible.legacy.dnf")
    ansible_modules_2 = action_module_0._shared_loader_obj.module_loader.path_exists("ansible.legacy.yum")
    print("ansible.legacy.yum: %s" % bool(ansible_modules_0))
    print("ansible.legacy.dnf: %s" % bool(ansible_modules_1))

# Generated at 2022-06-25 08:07:14.862527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None

# Generated at 2022-06-25 08:07:20.674620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None, 'Failed to create ActionModule Object'


# Generated at 2022-06-25 08:07:25.384261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 08:08:30.694670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = ''
    action_module_0 = ActionModule()
    action_module_0.set_option("no_log")
    for _ in range(0, 1):
        try:
            action_module_0.run(tmp=None, task_vars=None)
        except AnsibleActionFail:
            pass
        assert(action_module_0._task.args.get('use', action_module_0._task.args.get('use_backend', 'auto')) == 'auto')
        assert(action_module_0._task.args.get('use', action_module_0._task.args.get('use_backend', 'auto')) == 'auto')

# Generated at 2022-06-25 08:08:37.852962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # run with valid args
    test_action_module_20 = ActionModule()
    test_tmp = "/tmp"
    test_task_vars = {"some":"other"}
    assert test_action_module_20.run(tmp=test_tmp, task_vars=test_task_vars) == {"failed": True, "msg": "Could not detect which major revision of yum is in use, which is required to determine module backend.\nYou should manually specify use_backend to tell the module whether to use the yum (yum3) or dnf (yum4) backend"}


# Generated at 2022-06-25 08:08:47.363294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Task argument is not of type dict
    # action_module_0 = ActionModule(task={'task_vars': {'ansible_pkg_mgr': 'yum'}}, connection={'_shell': {'tmpdir': '/home/ansible'}}, play_context={'check_mode': True})
    # action_module_0.run()

    # Task argument is of type dict
    action_module_1 = ActionModule(task={'task_vars': {'ansible_pkg_mgr': 'yum'}}, connection={'_shell': {'tmpdir': '/home/ansible'}}, play_context={'check_mode': True})
    action_module_1.run()

    # Task argument is of type dict, but with no task_vars in it
    action_module_2 = ActionModule

# Generated at 2022-06-25 08:08:50.511254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:08:56.869798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.VALID_BACKENDS == ('yum', 'yum4', 'dnf')
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 08:09:02.199150
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_1 = ActionModule()
    # FIXME: not working yet until isinstance() is fixed in vmstate

    action_module_1.run()

    action_module_2 = ActionModule()
    # FIXME: not working yet until isinstance() is fixed in vmstate

    action_module_2.run()

# Generated at 2022-06-25 08:09:08.790163
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 08:09:17.306182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.task_vars = dict()
    action_module_0.task_vars["ansible_facts"]={'pkg_mgr': "yum"}
    action_module_0._task.args = dict(use="yum", name="elasticsearch7", state="present")
    action_module_0._task.delegate_to = None
    action_module_0._task.delegate_facts = None
    action_module_0._task.async_val = None
    result = action_module_0.run()
    print(result)


# Generated at 2022-06-25 08:09:19.817754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = {}
    tmp = None
    task_vars = None
    assert ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 08:09:21.372236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule) is True


# Generated at 2022-06-25 08:11:24.646421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0).__name__ == 'ActionModule'


# Generated at 2022-06-25 08:11:29.268966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as exception:
        assert type(exception) == TypeError
    else:
        assert False, "Failed"

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 08:11:32.602192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    plugin_name = "ActionModule"
    module_name = "test.test"
    use = "yum"
    use_backend = "dnf"
    args = {'use':use, 'use_backend':use_backend}
    task_vars = {'name':'test'}
    action_module_0 = ActionModule()
    ret = action_module_0.run(**args)

# Generated at 2022-06-25 08:11:38.091869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 08:11:46.125236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    try:
        action_module_1.run()
    except Exception as e:
        print(e)
    print("-" * 80)
    print("Unit test for method run of class ActionModule")
    print("-" * 80)
    print("OK")

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 08:11:52.069391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: This test is for a side effect of the function.  The
    #        return value and the side effect needs to be separated.
    #        The test could be split into two tests, one for the side
    #        effect and one for the return value.
    action_module_1 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_1.run(tmp, task_vars)
    assert (result == {})

# Generated at 2022-06-25 08:11:53.930678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)
    assert action_module._supports_async
    assert action_module._supports_check_mode


# Generated at 2022-06-25 08:11:59.729498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Tests for method run of class ActionModule')
    action_module_obj = ActionModule()
    action_module_obj.run(None, None)

    print('Tests for method run of class ActionModule - successful')


# Generated at 2022-06-25 08:12:03.083131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    function_name = "test_ActionModule"
    try:
        display.vvvv("[%s] start test" % function_name)
        action_module_000 = ActionModule()
    except Exception as e:
        display.vvvv("[%s] Caught exception: %s" % (function_name, e))
        assert False

    assert True

# Generated at 2022-06-25 08:12:06.094132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()