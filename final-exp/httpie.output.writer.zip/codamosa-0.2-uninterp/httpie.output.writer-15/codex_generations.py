

# Generated at 2022-06-17 20:56:24.679592
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import PrettyStream

    class FakeEnv:
        def __init__(self, is_windows, stdout_isatty):
            self.is_windows = is_windows
            self.stdout_isatty = stdout_isatty

    class FakeArgs:
        def __init__(self, prettify):
            self.prettify = prettify

    class FakeOutfile:
        def __init__(self, encoding):
            self.encoding = encoding

        def write(self, text):
            self.text = text

        def flush(self):
            pass

    class FakeStream:
        def __init__(self, chunks):
            self.chunks = chunks


# Generated at 2022-06-17 20:56:35.382850
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input import ParseRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    import argparse
    import requests
    import io
    import sys
    import os
    import tempfile
    import pytest
    import errno
    import colorama
    import platform


# Generated at 2022-06-17 20:56:46.114509
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie import ExitStatus
    import argparse
    import sys

# Generated at 2022-06-17 20:56:52.333299
# Unit test for function write_message
def test_write_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:01.666398
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        RawStream, BufferedPrettyStream, PrettyStream, EncodedStream
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-17 20:57:12.041109
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 20:57:23.966128
# Unit test for function write_message
def test_write_message():
    # Test for function write_message
    # Arrange
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:34.498472
# Unit test for function write_stream
def test_write_stream():
    """
    Test for function write_stream
    """
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR

# Generated at 2022-06-17 20:57:45.317719
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input import ParseRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    import argparse
    import requests
    import io
    import sys
    import os
    import tempfile
    import pytest
    import time
    import errno
    import pytest
    import requests

# Generated at 2022-06-17 20:57:57.070360
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Test for function write_stream_with_colors_win_py3
    """
    import io
    import sys
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class TestOutfile:
        def __init__(self, encoding):
            self.encoding = encoding
            self.buffer = io.BytesIO()

        def write(self, text):
            self.buffer.write(text.encode(self.encoding))

        def flush(self):
            pass

    # Test with colorized chunks

# Generated at 2022-06-17 20:58:11.562926
# Unit test for function write_message
def test_write_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_

# Generated at 2022-06-17 20:58:22.754686
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.output.streams import write_stream_with_colors_win_py3
    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import pytest
    import sys
    import os
    import tempfile
    import io
    import shutil
    import subprocess
    import time
    import random

# Generated at 2022-06-17 20:58:29.884088
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.context import Environment
    import argparse
    import requests
    import os
    import sys
    import tempfile
    import unittest
    import io
    import json
    import httpie.cli
    import httpie.output
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output
    import http

# Generated at 2022-06-17 20:58:38.909902
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse

    env = Environment(
        stdout_isatty=True,
        stdout=None,
        stderr=None,
        stdin=None,
        stdin_isatty=True,
        is_windows=False,
    )

    args = argparse.Namespace(
        stream=False,
        prettify=None,
        style=None,
        json=False,
        format_options=None,
    )


# Generated at 2022-06-17 20:58:44.404425
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import requests
    import argparse

    args = parser.parse_args([])
    env = Environment()
    env.stdout_isatty = True
    env.is_windows = is_windows()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}

    req = requests.PreparedRequest()
    req.method = 'GET'

# Generated at 2022-06-17 20:58:53.293736
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile
    import pytest
    import shutil
    import json
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.compat
    import httpie.cli
    import httpie.context
    import httpie.output
    import httpie
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile


# Generated at 2022-06-17 20:59:00.499810
# Unit test for function write_message
def test_write_message():
    import os
    import sys
    import tempfile
    import unittest
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, RawStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argparser import parser
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.utils import get_response
    from httpie.cli.exceptions import ExitStatus
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth

# Generated at 2022-06-17 20:59:11.776382
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    import requests
    import argparse
    import sys

    args = parser.parse_args(args=[])

# Generated at 2022-06-17 20:59:18.077258
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse

    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'paraiso-dark'
    args.stream = True
    env = Environment()
    env.stdout_isatty = True
    env.stdout = 'stdout'
    env.stderr = 'stderr'
    env.is_windows = False
    env.stdin = 'stdin'
    env.stdin_isatty = True
    env.stdin_encoding = 'utf-8'
    env.stdin_errors = 'strict'

# Generated at 2022-06-17 20:59:29.274200
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:59:41.158321
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:59:50.759316
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie import ExitStatus
    import argparse


# Generated at 2022-06-17 21:00:02.085093
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    import unittest
    import unittest.mock
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES


# Generated at 2022-06-17 21:00:12.815558
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream, PrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_message
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_

# Generated at 2022-06-17 21:00:15.199765
# Unit test for function write_message
def test_write_message():
    # TODO: write unit test for function write_message
    pass

# Generated at 2022-06-17 21:00:26.084963
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests

    env = Environment()
    env.stdout_isatty = True
    env.is_windows = False
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = True

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:00:37.572656
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    args = parser.parse_args(['--json'])
    env = Environment()
    stream_class = PrettyStream
    stream_kwargs = {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=args.prettify,
            color_scheme=args.style,
            explicit_json=args.json,
            format_options=args.format_options,
        )
    }

# Generated at 2022-06-17 21:00:44.529564
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream

    env = Environment(
        stdin=io.BytesIO(),
        stdout=io.BytesIO(),
        stderr=io.BytesIO(),
        is_windows=is_windows,
        colors=256,
        stdout_isatty=True,
        stdin_isatty=True,
        stderr_isatty=True,
    )


# Generated at 2022-06-17 21:00:53.465683
# Unit test for function write_message
def test_write_message():
    import sys
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import M

# Generated at 2022-06-17 21:00:58.614216
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    import argparse
    args = argparse.Namespace()
    env = Environment()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}


# Generated at 2022-06-17 21:01:15.892560
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie import ExitStatus
    import requests
    import argparse
    import os
    import sys
    import tempfile
    import pytest
    import io
    import shutil
    import json
    import pytest
    import os
    import sys
    import tempfile
    import pytest
    import io
    import shutil
    import json
    import pytest
    import os
    import sys
    import tempfile
    import pytest
    import io
    import shut

# Generated at 2022-06-17 21:01:26.727042
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:38.279502
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.baidu.com'
    requests_message.headers = {'Accept': 'application/json'}
    requests_message.body = '{"name": "test"}'
    requests_message.is_body_upload_ch

# Generated at 2022-06-17 21:01:48.150305
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.style = None
    args.json = False
    args.format_options = {}
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 21:01:56.245479
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

# Generated at 2022-06-17 21:02:04.300728
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:02:12.215348
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context

    args = httpie.cli.parser.parse_args(args=[])
    env = httpie.context.Environment()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    message_class = {
        requests.PreparedRequest: httpie.models.HTTPRequest,
        requests.Response: httpie.models.HTTPResponse,
    }[type(requests_message)]

# Generated at 2022-06-17 21:02:21.864211
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}
    args.stream = True

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 21:02:33.778605
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_dir = None
    args.output_file = None
    args.output_options = {}
    args.output_file_options = {}
    args.output_file_

# Generated at 2022-06-17 21:02:40.768377
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py36
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py36
    from httpie.compat import is_windows_py3_or_higher

# Generated at 2022-06-17 21:02:50.114429
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.outfile = io.StringIO()

        def tearDown(self):
            self.outfile.close()

        def test_write_stream(self):
            chunks = [b'chunk1', b'chunk2']
            write_stream(stream=TestStream(chunks), outfile=self.outfile, flush=False)

# Generated at 2022-06-17 21:03:00.932391
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream, PrettyStream
    from httpie.output.streams import EncodedStream, RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    import os
    import tempfile

    class MockStream(BaseStream):
        def __init__(self, msg, with_headers, with_body, **kwargs):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
            self.kwargs = kwargs


# Generated at 2022-06-17 21:03:10.737046
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import write_stream
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import M

# Generated at 2022-06-17 21:03:18.301367
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=None, color_scheme=None, explicit_json=False, format_options=None)})

    env = Environment(stdout_isatty=False)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)

# Generated at 2022-06-17 21:03:23.220820
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    import io
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    # Create the environment

# Generated at 2022-06-17 21:03:31.354993
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
   

# Generated at 2022-06-17 21:03:42.073628
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    import requests
    import sys
    import io
    import argparse
    import os
    import tempfile
    import pytest
    import json
    import httpie.output.streams
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
   

# Generated at 2022-06-17 21:03:53.225277
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py34
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py34

# Generated at 2022-06-17 21:04:04.638891
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedBytesStream
    from httpie.output.streams import ColorizedTextStream
    from httpie.output.streams import ColorizedTextIOWrapper
    from httpie.output.streams import ColorizedBytesIOWrapper
    from httpie.output.streams import ColorizedBytesIOWrapper
    from httpie.output.streams import ColorizedTextIOWrapper
    from httpie.output.streams import ColorizedBytesIOWrapper

    # Test for ColorizedStream
    stream = ColorizedStream(
        msg=None,
        with_headers=False,
        with_body=False,
        env=None,
        conversion=None,
        formatting=None,
    )

# Generated at 2022-06-17 21:04:15.885952
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    args = parser.parse_args(['--json', '--pretty=all', '--style=paraiso-dark'])
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.is_windows = False
    env.colors = 256
   

# Generated at 2022-06-17 21:04:30.175261
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import M

# Generated at 2022-06-17 21:04:40.490082
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_style
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg

# Generated at 2022-06-17 21:04:46.172473
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:04:54.847351
# Unit test for function write_message
def test_write_message():
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import write_stream

# Generated at 2022-06-17 21:05:01.735191
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:09.669294
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    class Stream(BaseStream):
        def __init__(self, color):
            self.color = color
        def __iter__(self):
            yield self.color
    stream = Stream(b'\x1b[')
    outfile = StringIO()
    write_stream_with_colors_win_py3(stream, outfile, False)
    assert outfile.getvalue() == '\x1b['

# Generated at 2022-06-17 21:05:20.941668
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys

    args = parser.parse_args([])
    args.prettify = ['colors']
    args.stream = False

# Generated at 2022-06-17 21:05:29.864685
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input import ParseRequest
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_message
    from httpie.output.streams import build_output_stream_for_message

# Generated at 2022-06-17 21:05:39.350456
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.output.formatters.format
    import httpie.output.formatters.headers
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty
    import httpie.output.formatters.stream
    import httpie.output.formatters.terminal
    import httpie.output.formatters.utils
    import httpie.output.processing
    import httpie.output.streams
    import httpie.output.writers
    import httpie.plugins
    import httpie.status
    import httpie.utils
    import httpie.compat
    import httpie.context
    import httpie.models
    import httpie.plugins.builtin
    import http

# Generated at 2022-06-17 21:05:49.046981
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:06:03.710587
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.utils import get_response_type
    from httpie.cli.utils import get_response_type
    from httpie.cli.utils import get_response_type
    from httpie.cli.utils import get_response_type
    from httpie.cli.utils import get_response_type
    from httpie.cli.utils import get_response_type
    from httpie.cli.utils import get_response_

# Generated at 2022-06-17 21:06:14.687267
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    import unittest

    from httpie.output.streams import PrettyStream

    class TestPrettyStream(PrettyStream):
        def __init__(self, *args, **kwargs):
            super(TestPrettyStream, self).__init__(*args, **kwargs)
            self.chunks = []

        def __iter__(self):
            return iter(self.chunks)

        def write(self, chunk):
            self.chunks.append(chunk)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.stream = TestPrettyStream(
                msg=None,
                with_headers=True,
                with_body=True,
                env=None,
                conversion=None,
                formatting=None,
            )
            self.out