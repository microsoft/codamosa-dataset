

# Generated at 2022-06-17 20:56:24.337957
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    args = parser.parse_args(['--prettify', 'all', '--style', 'paraiso-dark'])
    env = Environment(stdout_isatty=True, stderr_isatty=True)
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.google.com'

# Generated at 2022-06-17 20:56:31.721627
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import Key

# Generated at 2022-06-17 20:56:38.956541
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    args = parser.parse_args(['--pretty=all', '--stream', '--style=solarized'])
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=True,
        stdin_isatty=False,
        is_windows=False,
    )
    requests_message = requests.PreparedRequest()
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_message.body = '{"name": "test"}'
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'
    requests_message.prepare()
    with_headers = True
    with_body = True


# Generated at 2022-06-17 20:56:48.436065
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream, write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream, write_stream_with_colors_win_

# Generated at 2022-06-17 20:57:00.836186
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import MESSAGE_SEPARATOR

# Generated at 2022-06-17 20:57:11.517955
# Unit test for function write_message
def test_write_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:23.618621
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream

    class MockStream(BaseStream):
        def __init__(self, *args, **kwargs):
            self.chunks = [
                b'\x1b[31mfoo\x1b[39m',
                b'bar',
                b'\x1b[32mbaz\x1b[39m',
                b'qux',
            ]

        def __iter__(self):
            return iter(self.chunks)

    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=MockStream(),
        outfile=outfile,
        flush=False,
    )

# Generated at 2022-06-17 20:57:34.460343
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import get_stream_type_and_kwargs
    import requests
    import argparse
    import json

    args = parser.parse_args(['--json', '--pretty', 'all', '--style', 'paraiso-dark'])
    env = Environment()
    env.stdout_isatty = True
    env.stdout = open('output.txt', 'w')
   

# Generated at 2022-06-17 20:57:45.280708
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    import os
    import tempfile
    import shutil
    import pytest
    import json
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_lowercase) for i in range(length))

    def random_int(length):
        return ''.join(random.choice(string.digits) for i in range(length))


# Generated at 2022-06-17 20:57:52.216726
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format

# Generated at 2022-06-17 20:58:10.134041
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    env = Environment()
    args = argparse.Namespace(prettify=['colors'], style='paraiso-dark', json=False, format_options=[], stream=True)
    requests_message = requests.PreparedRequest()
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_message.body = '{"a": "b"}'
    requests_message.url = 'http://httpbin.org/get'
    requests_message.method = 'GET'
    stream_class, stream_kw

# Generated at 2022-06-17 20:58:20.932953
# Unit test for function write_message
def test_write_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context

# Generated at 2022-06-17 20:58:29.043505
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import ColorizedChunk
    from httpie.output.streams import ColorizedChunkType
    from httpie.output.streams import RawChunk
    from httpie.output.streams import RawChunkType
    from httpie.output.streams import StreamChunk
    from httpie.output.streams import StreamChunkType


# Generated at 2022-06-17 20:58:38.704252
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream

    class TestStream(BaseStream):
        def __init__(self, msg, with_headers=True, with_body=True, **kwargs):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body

        def __iter__(self):
            yield b'\x1b[1;31m'
            yield b'\x1b[1;32m'
            yield b'\x1b[1;33m'
            yield b'\x1b[1;34m'
            yield b'\x1b[1;35m'

# Generated at 2022-06-17 20:58:43.593224
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-17 20:58:52.833557
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

# Generated at 2022-06-17 20:59:02.955218
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    import io
    import sys
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )

# Generated at 2022-06-17 20:59:14.232215
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import json
    import os
    import sys

    env = Environment()
    env.stdout = StringIO()
    env.stderr = StringIO()
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.stdin = StringIO()
    env.stdin_isatty = True
    env.is_windows = False
    env.stdin_encoding = 'utf8'
    env.stdout_encoding = 'utf8'
    env.stderr_enc

# Generated at 2022-06-17 20:59:19.580320
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    import os

    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdout_isatty=True,
        stdin_isatty=True,
        is_windows=os.name == 'nt',
        colors=256,
        encoding=sys.getdefaultencoding(),
        verify=True,
        trust_env=True,
    )

# Generated at 2022-06-17 20:59:29.930981
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class FakeOutFile:
        def __init__(self, chunks):
            self.chunks = chunks
            self.buffer = io.BytesIO()
            self.encoding = 'utf-8'

        def write(self, chunk):
            self.chunks.append(chunk)

    chunks = []
    outfile = FakeOutFile(chunks)

# Generated at 2022-06-17 20:59:49.566807
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:00:01.079963
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'paraiso-dark'
    args.json = True
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 21:00:12.660783
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:00:24.609719
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import requests
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py36
    import argparse

    env = Environment()
    args = argparse.Namespace()
    args.stream = False
    args.prettify = 'all'
    args.style

# Generated at 2022-06-17 21:00:25.944475
# Unit test for function write_message
def test_write_message():
    # TODO: Add unit test for function write_message
    pass

# Generated at 2022-06-17 21:00:37.396708
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:44.439942
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}

    # Test for RawStream
    args.prettify = []
    args.stream = False
    env.stdout_isatty = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream

# Generated at 2022-06-17 21:00:53.436755
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import pytest

    args = parser.parse_args(['--pretty=all', '--style=default', '--stream'])
    env = Environment()
    env.stdout_isatty = True
    env.stdout = sys.stdout


# Generated at 2022-06-17 21:01:04.508979
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.base import parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.base import parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.base import parser

# Generated at 2022-06-17 21:01:16.003269
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie import ExitStatus
    import requests
    import argparse
    import sys
    import os
    import tempfile
    import pytest
    import json
    import re
    import time
    import shutil
    import subprocess
    import shlex
    import platform
    import base64
    import random
    import string
    import httpie
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie

# Generated at 2022-06-17 21:01:30.851979
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    args = parser.parse_args(['--prettify', 'all', '--style', 'paraiso-dark', '--json', '--format', '{}'])
    env = Environment()
    env.stdout_isatty = True
    requests_message = HTTPRequest(HTTPResponse())

# Generated at 2022-06-17 21:01:40.048623
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:49.144933
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:57.369553
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:02:04.464120
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_bytes
    from httpie.compat import is_unicode
    from httpie.compat import is_iter

# Generated at 2022-06-17 21:02:12.321589
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    from httpie.output.streams import BaseStream
    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks
        def __iter__(self):
            return iter(self.chunks)
    class FakeOutfile(io.TextIOWrapper):
        def __init__(self):
            self.buffer = io.BytesIO()
            self.encoding = 'utf-8'
    outfile = FakeOutfile()
    write_stream_with_colors_win_py3(
        stream=FakeStream([b'\x1b[1m\x1b[31mfoo\x1b[0m', b'bar']),
        outfile=outfile,
        flush=False
    )
    assert outfile.buffer.getvalue()

# Generated at 2022-06-17 21:02:21.862839
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.config import Config
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_UA
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import AuthPlugin
    from httpie.plugins.builtin import AuthCredentials
    from httpie.plugins.builtin import AuthCredentialsInURL

# Generated at 2022-06-17 21:02:33.779343
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:02:40.769101
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse

# Generated at 2022-06-17 21:02:50.654362
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream, PrettyStream
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_LEN
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_RE
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_RE_STR
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_STR
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_WIN_PY3
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_WIN_PY3_LEN

# Generated at 2022-06-17 21:03:08.972035
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    import argparse
    import requests
    import sys
    import os
    import io
    import pytest
    import httpie.output.streams
    import httpie.output.streams

# Generated at 2022-06-17 21:03:17.169382
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MES

# Generated at 2022-06-17 21:03:28.470004
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class DummyStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    # Test with colorized output
    chunks = [
        b'\x1b[32mfoo\x1b[39m',
        b'bar',
        b'\x1b[32mbaz\x1b[39m',
    ]
    stream = DummyStream(chunks)
    outfile = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False,
    )
    assert outfile

# Generated at 2022-06-17 21:03:34.784698
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['headers']
    args.stream = True
    args.style = 'paraiso-dark'
    args.json = True
    args.format_options = {'headers': {'max_line_length': 80}}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:03:45.110457
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.formatters.colors
    import httpie.output.formatters.colors.win_py3
    import httpie.output.formatters.colors.win_py3.colorama
    import httpie.output.formatters.colors.win_py3.colorama.ansitowin32
    import httpie.output.formatters.colors.win_py3.colorama.ansitowin32.stream
    import httpie.output.formatters.colors.win_py3.colorama.ansitowin32.stream.StreamWrapper
    import httpie.output.formatters.colors.win_py3.colorama.ansitow

# Generated at 2022-06-17 21:03:54.597672
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream

    stream = PrettyStream(
        msg=HTTPResponse(requests.Response()),
        with_headers=True,
        with_body=True,
        env=Environment(),
        conversion=Conversion(),
        formatting=Formatting(
            env=Environment(),
            groups=['colors'],
            color_scheme='par',
            explicit_json=False,
            format_options={},
        )
    )
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == '\n'

# Generated at 2022-06-17 21:04:05.309938
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    import requests
    import argparse
    import sys

    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        is_windows=sys.platform == 'win32',
        colors=256,
        stdout_isatty=True,
    )
    args = parser.parse_args(args=[])
    args.prettify = ['all']
    args.stream = True


# Generated at 2022-06-17 21:04:16.152621
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 21:04:20.329251
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-17 21:04:29.943163
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import argparse

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False

    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.google.com'

# Generated at 2022-06-17 21:04:59.409019
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.cli
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models

# Generated at 2022-06-17 21:05:10.802087
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:22.034611
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message

# Generated at 2022-06-17 21:05:30.653022
# Unit test for function write_stream
def test_write_stream():
    """
    Test the write_stream function
    """
    import io
    import sys
    import unittest
    from httpie.output.streams import RawStream

    class TestWriteStream(unittest.TestCase):
        """
        Test the write_stream function
        """

        def setUp(self):
            """
            Set up the test
            """
            self.stream = RawStream(b'Hello World')
            self.outfile = io.StringIO()
            self.flush = False

        def test_write_stream(self):
            """
            Test the write_stream function
            """
            write_stream(self.stream, self.outfile, self.flush)
            self.assertEqual(self.outfile.getvalue(), 'Hello World')


# Generated at 2022-06-17 21:05:40.037263
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import os
    import sys
    import io
    import tempfile

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write(b'{"foo": "bar"}')
    temp_file.seek(0)

    # Create a request

# Generated at 2022-06-17 21:05:49.489343
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPBearerTokenAuth
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPProxyAuthSession
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPPassAuthSession

# Generated at 2022-06-17 21:06:01.973591
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES