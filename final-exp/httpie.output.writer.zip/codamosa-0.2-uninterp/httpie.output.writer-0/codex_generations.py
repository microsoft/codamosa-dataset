

# Generated at 2022-06-17 20:56:25.903912
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
   

# Generated at 2022-06-17 20:56:26.700395
# Unit test for function write_message
def test_write_message():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 20:56:36.255264
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.output.formatters
    import httpie.output.writers
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams


# Generated at 2022-06-17 20:56:47.035512
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:00.329389
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = []
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_options = ['pretty']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 20:57:11.185374
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import json

    env = Environment()
    args = argparse.Namespace(
        stream=True,
        prettify=['colors'],
        style='paraiso-dark',
        json=True,
        format_options={},
        debug=False,
        traceback=False,
    )
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'

# Generated at 2022-06-17 20:57:23.448532
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 20:57:28.339558
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    import unittest.mock

    from httpie.output.streams import BaseStream

    class MockStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stdout = self.stdout
            sys.stderr = self.stderr


# Generated at 2022-06-17 20:57:37.948334
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import sys
    import io
    import pytest
    import os
    import tempfile
    import shutil

    # test write_message
    # test write_stream
    # test write_stream_with_colors_win_py3
    # test build

# Generated at 2022-06-17 20:57:47.199764
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 20:57:59.201447
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    import requests
    import argparse
    import sys
    import os
    import io
    import tempfile
    import shutil
    import subprocess
    import pytest
    import json
    import time
    import random
    import string
    import re
    import platform
    import errno
    import signal
    import tempfile
    import shutil
    import subprocess
    import pytest
    import json
    import time
   

# Generated at 2022-06-17 20:58:05.252199
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import requests
    import argparse
    import os
    import sys
    import tempfile
    import io
    import pytest
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES

    # Create a temp file to be used as stdout
    fd, temp_file_path = tempfile.mkstemp()
    os.close(fd)
    temp_file = open(temp_file_path, 'w+b')



# Generated at 2022-06-17 20:58:13.291190
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    args = parser.parse_args(['--prettify', 'all'])

# Generated at 2022-06-17 20:58:25.104526
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:35.920420
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    import httpie.cli
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:42.684976
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Test the function write_stream_with_colors_win_py3
    """
    import sys
    import io
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.compat import is_windows

# Generated at 2022-06-17 20:58:52.408781
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:59:00.435186
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import RawStream

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.stream = RawStream(b'foo')
            self.outfile = io.StringIO()
            self.flush = False

        def test_write_stream(self):
            write_stream(self.stream, self.outfile, self.flush)
            self.assertEqual(self.outfile.getvalue(), 'foo')

    unittest.main()

# Generated at 2022-06-17 20:59:11.777546
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['all']
    args.stream = True
    args.style = 'paraiso-dark'
    args.json = True
    args.format_options = {'foo': 'bar'}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kw

# Generated at 2022-06-17 20:59:20.087192
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['all']
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_

# Generated at 2022-06-17 20:59:38.860753
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 20:59:49.686780
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    import requests
    import argparse
    import sys

    args = parser.parse_args(['-p'])
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    requests_message = requests.Response()
    requests_message.status_code = 200

# Generated at 2022-06-17 21:00:01.366123
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    import unittest
    from unittest.mock import patch

    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.outfile = io.StringIO()
            self.outfile.encoding = 'utf-8'

        def test_write_stream_with_colors_win_py3(self):
            with patch.object(sys, 'platform', 'win32'):
                with patch.object(sys, 'version_info', (3, 0)):
                    write_stream_with_col

# Generated at 2022-06-17 21:00:12.743103
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)

    args.stream = True


# Generated at 2022-06-17 21:00:24.703687
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:36.105480
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for write_message
    # Test for

# Generated at 2022-06-17 21:00:43.765494
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    import requests
    import argparse
    import sys

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'solarized'
    args.json = False
    args.format_options = {}
    args.stream = False
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args

# Generated at 2022-06-17 21:00:52.520664
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:04.243356
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    env = Environment(stdout_isatty=False)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream

# Generated at 2022-06-17 21:01:15.863390
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys

# Generated at 2022-06-17 21:01:49.351854
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams

# Generated at 2022-06-17 21:02:01.624980
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream

    env = Environment()
    args = argparse.Namespace(prettify=['colors'])
    requests_message = HTTPRequest(
        method='GET',
        url='http://example.com',
        headers={'Accept': 'application/json'},
        body=b'',
    )

# Generated at 2022-06-17 21:02:11.115489
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance

# Generated at 2022-06-17 21:02:21.115950
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    stream = ColorizedStream(
        msg=HTTPResponse(requests.Response()),
        with_headers=True,
        with_body=True,
        env=Environment(),
        conversion=Conversion(),
        formatting=Formatting(
            env=Environment(),
            groups=['colors'],
            color_scheme='par',
            explicit_json=False,
            format_options={},
        )
    )
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False
    )

# Generated at 2022-06-17 21:02:26.598416
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.formatters.colors
    import httpie.output.formatters.colors.win_py3
    import httpie.output.formatters.win_py3
    import httpie.output.formatters.utils
    import httpie.output.formatters.utils.win_py3
    import httpie.output.formatters.win
    import httpie.output.formatters.utils.win
    import httpie.output.formatters.utils.unix
    import httpie.output.formatters.unix
    import httpie.output.formatters.utils.unix_py3
    import httpie.output.formatters.unix_py3
    import httpie.output.formatters

# Generated at 2022-06-17 21:02:37.165464
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:02:47.663478
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True

# Generated at 2022-06-17 21:02:55.361079
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    env = Environment(stdout=sys.stdout, stdout_isatty=True)
    args = argparse.Namespace(prettify=['all'], style='paraiso-dark', stream=True)
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.baidu.com'

# Generated at 2022-06-17 21:03:04.944056
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest
    from httpie.cli import parser
    args = parser.parse_args(['--prettify', 'all', '--style', 'paraiso-dark'])
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=True,
        is_windows=False,
        colors=256,
        encoding='utf8',
        default_options=args,
    )
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'

# Generated at 2022-06-17 21:03:14.663103
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:04:15.887328
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context

# Generated at 2022-06-17 21:04:27.520391
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.stream = False
    args.prettify = False
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.stream = True
    args.prettify = True
    args.style = 'solarized'
    args.json = True
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:04:39.579225
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse

    env = Environment(stdout=sys.stdout, stdout_isatty=True)
    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='paraiso-dark',
        debug=False,
        traceback=False,
        json=False,
        format_options={},
    )
    with requests.Session() as session:
        session.headers.update({'Content-Type': 'application/json'})

# Generated at 2022-06-17 21:04:48.761601
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    import requests
    import sys
    import os
    import io
    import tempfile
    import shutil

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()

    # Create a temp file
    temp_file = os.path.join(temp_dir, 'temp_file')
    with open(temp_file, 'w') as f:
        f

# Generated at 2022-06-17 21:04:57.784005
# Unit test for function write_message
def test_write_message():
    import os
    import sys
    import tempfile
    import unittest
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:03.327380
# Unit test for function write_message
def test_write_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context

# Generated at 2022-06-17 21:05:14.844769
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.compat import is_windows
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    import argparse
    import requests
    import pytest
    import os
    import sys
    import tempfile


# Generated at 2022-06-17 21:05:26.277363
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment()
    args = parser.parse_args([])
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    args = parser.parse_args(['--stream'])
    assert get_stream_type_and_kwargs(env, args) == (PrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=None, color_scheme=None, explicit_json=False, format_options={})})


# Generated at 2022-06-17 21:05:36.337904
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    args = parser.parse_args(['--pretty=colors'])

# Generated at 2022-06-17 21:05:44.031704
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    import sys
    import unittest
    from unittest.mock import patch
    from httpie.output.streams import RawStream

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.outfile = StringIO()
            self.stream = RawStream(b'foo')

        def test_write_stream(self):
            write_stream(self.stream, self.outfile, False)
            self.assertEqual(self.outfile.getvalue(), 'foo')

        def test_write_stream_flush(self):
            with patch.object(self.outfile, 'flush') as mock_flush:
                write_stream(self.stream, self.outfile, True)