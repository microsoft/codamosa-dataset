

# Generated at 2022-06-17 20:56:25.865835
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:56:35.914645
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MESSAGE_SEPARATOR_

# Generated at 2022-06-17 20:56:37.569480
# Unit test for function write_message
def test_write_message():
    # TODO: Add unit test
    pass

# Generated at 2022-06-17 20:56:47.453484
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_

# Generated at 2022-06-17 20:57:00.475575
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR

# Generated at 2022-06-17 20:57:11.297525
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 20:57:23.491284
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import sys
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:30.561053
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream

# Generated at 2022-06-17 20:57:38.149703
# Unit test for function write_message
def test_write_message():
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
   

# Generated at 2022-06-17 20:57:47.270450
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import os
    import sys
    import tempfile
    import unittest
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import get_stream_type_and_kwargs

    class TestEnvironment(Environment):
        def __init__(self, **kwargs):
            super(TestEnvironment, self).__init__(**kwargs)
            self.stdout_isatty = True
            self.stdout = tempfile.TemporaryFile(mode='w+b')
            self.stderr = tempfile.TemporaryFile(mode='w+b')


# Generated at 2022-06-17 20:58:02.240725
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    import unittest

    from httpie.output.streams import PrettyStream

    class TestWriteStreamWithColorsWinPy3(unittest.TestCase):

        def setUp(self):
            self.env = Environment()
            self.env.stdout_isatty = True
            self.env.stdout_encoding = 'utf8'
            self.env.is_windows = True
            self.args = argparse.Namespace()
            self.args.prettify = ['colors']
            self.args.style = 'paraiso-dark'
            self.args.stream = False
            self.args.debug = False
            self.args.traceback = False
            self.outfile = io.StringIO()


# Generated at 2022-06-17 20:58:11.766870
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys
    import os
    import io
    import tempfile
    import pytest

    # Create a temporary file to be used as stdout
    stdout_file = tempfile.TemporaryFile()
    # Create a temporary file to be used as stderr
    stderr_file = tempfile.TemporaryFile()
    # Create a temporary file to be used as stdin
    stdin_file = tempfile.TemporaryFile()



# Generated at 2022-06-17 20:58:23.553292
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    import argparse
    import requests
    import os
    import sys
    import tempfile
    import io
    import pytest
    import requests
    import json

    # test for RawStream
    args = argparse.Namespace(
        stream=False,
        prettify=False,
        style=None,
        json=False,
        format_options={},
        download=False,
        debug=False,
        traceback=False,
    )
   

# Generated at 2022-06-17 20:58:35.062975
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    import io
    import sys
    import os

    # Test case 1:
    # stdout is not a tty and --prettify is not set
    # stream_class = RawStream
    # stream_kwargs = {'chunk_size': RawStream.CHUNK_SIZE}

# Generated at 2022-06-17 20:58:41.822290
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    import requests
    import io
    import sys
    import os
    import argparse
    import tempfile
    import pytest
    import json

    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    env.stderr = io.StringIO()
    env.stderr_isatty = True
    env.stdin = io.StringIO()
    env.stdin_isatty = True
    env.is_windows = is_windows


# Generated at 2022-06-17 20:58:51.629086
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 20:59:02.242011
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py2
    from httpie.compat import is_windows_

# Generated at 2022-06-17 20:59:13.573031
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_

# Generated at 2022-06-17 20:59:21.984449
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:59:31.836737
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import sys
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_message

# Generated at 2022-06-17 20:59:39.471131
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-17 20:59:50.037804
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)
    args.stream = True


# Generated at 2022-06-17 21:00:01.649672
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR

# Generated at 2022-06-17 21:00:12.778282
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import os
    import tempfile
    import requests
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output import write_stream, write_stream_with_colors_win_py3
    from httpie.output import build_output_stream_for_message, get_stream_type_and_kwargs

    # Test for function get_stream_type_and_kwargs
    def test_get_stream_type_and_kwargs():
        env = Environment()
        args = parser.parse_args()
        stream_class, stream_kw

# Generated at 2022-06-17 21:00:17.059819
# Unit test for function write_stream
def test_write_stream():
    stream = [b'a', b'b', b'c']
    outfile = io.BytesIO()
    write_stream(stream, outfile, False)
    assert outfile.getvalue() == b'abc'



# Generated at 2022-06-17 21:00:28.114636
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = None
    args.stream = True
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:00:39.270179
# Unit test for function write_message
def test_write_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie

# Generated at 2022-06-17 21:00:49.434481
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import json
    import requests
    import httpie
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.streams import BaseStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_message
    from httpie.output.streams import build_output_stream_for_message

# Generated at 2022-06-17 21:01:02.733641
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli.parser import parse_args

    env = Environment()
    args = parse_args([])
    stream = PrettyStream(
        msg=HTTPRequest(requests.PreparedRequest()),
        with_headers=True,
        with_body=True,
        env=env,
        conversion=Conversion(),
        formatting=Formatting(
            env=env,
            groups=['colors'],
            color_scheme='par',
            explicit_json=False,
            format_options={},
        )
    )
    outfile = String

# Generated at 2022-06-17 21:01:08.084963
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MES

# Generated at 2022-06-17 21:01:29.477981
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    import argparse
    import requests
    import sys
    import os

# Generated at 2022-06-17 21:01:39.427105
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_options = {}
    env.stdout_isatty = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 21:01:48.864991
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import sys
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import io
    import os
    import tempfile
    import unittest

    class TestGetStreamTypeAndKwargs(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.args = parser.parse_args([])
            self.args.prettify = []
            self.args.stream = False
            self.args.style = 'default'

# Generated at 2022-06-17 21:01:57.107921
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message

# Generated at 2022-06-17 21:02:04.590124
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    env = Environment()
    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='solarized',
        json=False,
        format_options={},
        debug=False,
        traceback=False,
    )
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )

# Generated at 2022-06-17 21:02:12.424796
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    import json
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-17 21:02:21.896866
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context

# Generated at 2022-06-17 21:02:33.878234
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.constants import DEFAULT_FORMAT_OPTIONS
    from httpie.cli.constants import DEFAULT_FORMAT_OPTIONS
    from httpie.cli.constants import DEFAULT_FORMAT_OPTIONS
    from httpie.cli.constants import DEFAULT_FORMAT_

# Generated at 2022-06-17 21:02:40.810625
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import M

# Generated at 2022-06-17 21:02:50.695568
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters
    import httpie.output.writers
    import httpie.output.options

    args = httpie.cli.parser.parse_args(['--stream'])

# Generated at 2022-06-17 21:03:21.102748
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_FORMAT


# Generated at 2022-06-17 21:03:30.083066
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.compat import is_windows
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream

# Generated at 2022-06-17 21:03:32.231732
# Unit test for function write_message
def test_write_message():
    # TODO: write unit test for function write_message
    pass

# Generated at 2022-06-17 21:03:42.633408
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MESSAGE_SEPARATOR_

# Generated at 2022-06-17 21:03:52.722155
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.compat import is_windows
    from httpie.cli import parser
    import argparse
    import requests
    from typing import IO, TextIO, Tuple, Type, Union
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.compat import is_windows

# Generated at 2022-06-17 21:03:58.749788
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:04:04.672896
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:04:15.888364
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:04:27.520495
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'solarized'
    args.json = True
    args.format_options = {}
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)


# Generated at 2022-06-17 21:04:39.578951
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    args = parser.parse_args(args=[])
    env = Environment(stdout=sys.stdout, stderr=sys.stderr)
    stream_class = PrettyStream
    stream_kwargs = {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=args.prettify,
            color_scheme=args.style,
            explicit_json=args.json,
            format_options=args.format_options,
        )
    }
    stream = stream

# Generated at 2022-06-17 21:05:17.764302
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import write_stream, write_stream_with_colors_win_py3
    import io
    import sys
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import unittest

    class TestWriteMessage(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self

# Generated at 2022-06-17 21:05:28.755445
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-17 21:05:38.858582
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    stream_class, stream_

# Generated at 2022-06-17 21:05:45.248539
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import sys
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:52.062533
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    env = Environment(stdout=sys.stdout, stderr=sys.stderr)
    args = argparse.Namespace(prettify=['colors'], style='paraiso-dark', stream=True)
    requests_message = requests.PreparedRequest()
    requests_message.url = 'https://httpbin.org/get'
    requests_message.method = 'GET'
    requests_message.headers = {'User-Agent': 'HTTPie/1.0.3'}

# Generated at 2022-06-17 21:06:02.619373
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items

# Generated at 2022-06-17 21:06:12.841270
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3

    # Test write_stream
    outfile = StringIO()
    write_stream(BaseStream(), outfile, False)
    write_stream(BufferedPrettyStream(), outfile, False)
    write_stream(EncodedStream(), outfile, False)
    write_stream(PrettyStream(), outfile, False)