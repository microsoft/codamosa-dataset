

# Generated at 2022-06-17 20:56:25.238549
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_windows_py3

# Generated at 2022-06-17 20:56:32.312634
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse

    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='paraiso-dark',
        json=False,
        format_options={},
    )
    env = Environment()
    env.stdout_isatty = True
    requests_message = requests.PreparedRequest()
    requests_message.body = b'{"a":1}'
    requests_message.headers = {'Content-Type': 'application/json'}

# Generated at 2022-06-17 20:56:42.637766
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import Terminal256Formatter
    from pygments.lexers import HttpLexer

    class MockArgs:
        def __init__(self):
            self.prettify = ['colors']
            self.stream = False

    class MockEnv:
        def __init__(self):
            self.stdout = StringIO()
            self.stdout_isatty = True

# Generated at 2022-06-17 20:56:50.467264
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:01.474550
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    import sys

# Generated at 2022-06-17 20:57:02.123699
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-17 20:57:12.334486
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.models import HTTPResponse
    from httpie.status import ExitStatus
    import argparse
    import requests
    import sys
    import os
    import tempfile
    import pytest
    import subprocess
    import platform
    import shutil
    import json

    class MockResponse:
        def __init__(self, status_code, headers, content):
            self.status_code = status_code
            self.headers = headers
            self.content = content


# Generated at 2022-06-17 20:57:24.176742
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:34.859254
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import get_parser
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import get_parser

# Generated at 2022-06-17 20:57:42.281603
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = True

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 20:58:00.568270
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.stream = False
    args.prettify = False
    args.json = False
    args.style = None
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prett

# Generated at 2022-06-17 20:58:10.339359
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.output.formatters.format
    import httpie.output.formatters.headers
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty
    import httpie.output.formatters.stream
    import httpie.output.formatters.terminal
    import httpie.output.formatters.utils
    import httpie.output.writers
    import httpie.plugins
    import httpie.status
    import httpie.utils
    import httpie.compat
    import httpie.models
    import httpie.output.processing
    import httpie.output.streams
    import httpie.output.writers
    import httpie.plugins
    import httpie

# Generated at 2022-06-17 20:58:21.151312
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    import requests

    args = parser.parse_args(['--prettify', 'all'])
    env = Environment()
    env.stdout_isatty = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 20:58:29.163413
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:32.349787
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli import parser
    args = parser.parse_args(args=[])
    env = Environment(vars=args)
    outfile = io.BytesIO()
    stream = RawStream(msg=HTTPRequest(None), with_headers=True, with_body=True)
    write_stream(stream=stream, outfile=outfile, flush=False)
    assert outfile.getvalue() == b''

# Generated at 2022-06-17 20:58:39.175964
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:43.974735
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    import sys


# Generated at 2022-06-17 20:58:53.041717
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile
    import pytest
    import errno
    import socket
    import http.client
    import http.cookies
    import http.server
    import threading
    import socketserver
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import json
    import time
    import datetime
    import shutil
    import collections
    import re

# Generated at 2022-06-17 20:59:00.176917
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = True
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 20:59:11.452578
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.compat import is_windows
    import sys
    import os
    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union


# Generated at 2022-06-17 20:59:30.189220
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg

# Generated at 2022-06-17 20:59:38.505509
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:59:43.315985
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}

    # RawStream
    args.prettify = []
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream

# Generated at 2022-06-17 20:59:47.798592
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:59:58.802921
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)


# Generated at 2022-06-17 21:00:06.788233
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks
        def __iter__(self):
            for chunk in self.chunks:
                yield chunk.encode()

# Generated at 2022-06-17 21:00:16.820937
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        RawStream, BufferedPrettyStream, PrettyStream, EncodedStream
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:27.777577
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream

    class FakeStream(PrettyStream):
        def __init__(self, msg, with_headers, with_body, env, conversion, formatting):
            super().__init__(msg, with_headers, with_body, env, conversion, formatting)
            self.chunks = [
                b'\x1b[31mfoo\x1b[0m',
                b'bar',
                b'\x1b[31mbaz\x1b[0m',
            ]

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class FakeEnv:
        def __init__(self):
            self.stdout_isatty = True

# Generated at 2022-06-17 21:00:39.019256
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:49.133086
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 21:01:16.601607
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream

# Generated at 2022-06-17 21:01:26.829305
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:38.313482
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.stream = False
    args.prettify = ['colors']
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}

# Generated at 2022-06-17 21:01:44.264379
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MES

# Generated at 2022-06-17 21:01:52.888761
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = []
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = []
    stream_class

# Generated at 2022-06-17 21:02:03.134929
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse

# Generated at 2022-06-17 21:02:11.421218
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile
    import pytest
    import json
    import random
    import string
    import shutil
    import time
    import subprocess
    import signal
    import threading
    import queue
    import re

    # Create a random string
    def random_string(string_length=10):
        """Generate a random string of fixed length """
        letters = string.ascii

# Generated at 2022-06-17 21:02:21.413376
# Unit test for function write_stream
def test_write_stream():
    # Test for write_stream
    import io
    import sys
    import unittest
    from unittest.mock import patch

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.stream = io.BytesIO()
            self.outfile = io.StringIO()
            self.flush = True

        def test_write_stream(self):
            write_stream(self.stream, self.outfile, self.flush)
            self.assertEqual(self.outfile.getvalue(), '')

        def test_write_stream_with_colors_win_py3(self):
            write_stream_with_colors_win_py3(self.stream, self.outfile, self.flush)

# Generated at 2022-06-17 21:02:32.896887
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MESSAGE_SEPARATOR_

# Generated at 2022-06-17 21:02:40.220553
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_message.body = '{"a": 1}'
    stream_class, stream_kwargs = get_stream_type_and_kw

# Generated at 2022-06-17 21:03:07.743224
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:03:16.353372
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:03:16.834602
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-17 21:03:28.100372
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import io
    import sys
    import os
    import tempfile
    import json
    import pytest

    env = Environment(stdin=sys.stdin,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      is_windows=os.name == 'nt',
                      colors=256,
                      stdout_isatty=sys.stdout.isatty(),
                      stdin_isatty=sys.stdin.isatty(),
                      is_posix=os.name == 'posix')

    args = arg

# Generated at 2022-06-17 21:03:34.574354
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    import sys


# Generated at 2022-06-17 21:03:45.069460
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.output.formatters.format
    import httpie.output.formatters.headers
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty
    import httpie.output.formatters.stream
    import httpie.output.formatters.utils
    import httpie.output.processing
    import httpie.output.streams
    import httpie.output.writers
    import httpie.plugins
    import httpie.status
    import httpie.utils
    import httpie.compat
    import httpie.models
    import httpie.context
    import httpie.plugins.builtin
    import httpie.plugins.manager

# Generated at 2022-06-17 21:03:54.830082
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import M

# Generated at 2022-06-17 21:04:05.396676
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37

# Generated at 2022-06-17 21:04:16.209808
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:04:23.988826
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.output.streams import RawStream

    outfile = BytesIO()
    stream = RawStream(b'foo')
    write_stream(stream, outfile, False)
    assert outfile.getvalue() == b'foo'

    outfile = BytesIO()
    stream = RawStream(b'foo')
    write_stream(stream, outfile, True)
    assert outfile.getvalue() == b'foo'

# Generated at 2022-06-17 21:05:12.647834
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.compat import is_windows
    import argparse
    import requests
    import sys

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False

    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'

# Generated at 2022-06-17 21:05:23.854568
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
   

# Generated at 2022-06-17 21:05:31.806057
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import RawStream
    outfile = StringIO()
    stream = RawStream(b'abc')
    write_stream(stream, outfile, False)
    assert outfile.getvalue() == 'abc'
    outfile = StringIO()
    stream = RawStream(b'abc')
    write_stream(stream, outfile, True)
    assert outfile.getvalue() == 'abc'
    outfile = StringIO()
    stream = RawStream(b'abc')
    write_stream(stream, outfile, False)
    assert outfile.getvalue() == 'abc'
    outfile = StringIO()
    stream = RawStream(b'abc')
    write_stream(stream, outfile, True)
    assert outfile.getvalue() == 'abc'

# Generated at 2022-06-17 21:05:41.158432
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.pre

# Generated at 2022-06-17 21:05:50.619730
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 21:06:02.355056
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )