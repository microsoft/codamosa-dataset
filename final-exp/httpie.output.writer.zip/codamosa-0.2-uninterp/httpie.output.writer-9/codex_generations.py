

# Generated at 2022-06-17 20:56:25.400818
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    env = Environment(stdout_isatty=False)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream

# Generated at 2022-06-17 20:56:35.837823
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import ColorizedStream


# Generated at 2022-06-17 20:56:46.610961
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.style = None
    args.json = False
    args.format_options = {}
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 20:57:00.231205
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream

    args = argparse.Namespace(
        stream=False,
        prettify=['colors', 'format', 'bodies'],
        style='paraiso-dark',
        debug=False,
        traceback=False,
        json=False,
        format_options={},
    )

# Generated at 2022-06-17 20:57:11.107859
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import json
    import os
    import sys
    import tempfile
    import time
    import traceback
    import warnings
    import argparse
    import collections
    import datetime
    import getpass
    import json
    import os
    import re
    import shlex
    import socket
    import ssl
    import sys
    import time
    import traceback
    import warnings
    import requests
    import requests.utils
    from requests.adapters import HTTPAdapter
    from requests.auth import AuthBase
    from requests.cookies import cookiejar

# Generated at 2022-06-17 20:57:23.452069
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream

    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True

    # Test case 1: env.stdout_isatty = True, args.prettify = False
    env.stdout_isatty = True
    args.prettify = False
    args.stream = False
    stream_class, stream_kwargs = get_

# Generated at 2022-06-17 20:57:34.423086
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:57:45.281428
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 20:57:52.220457
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    import io
    import sys

    env = Environment(stdout=io.StringIO(), stderr=sys.stderr, stdin=sys.stdin)
    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='paraiso-dark',
        json=False,
        format_options={},
    )
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kw

# Generated at 2022-06-17 20:57:59.112285
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = None
    args.style = None
    args.json = None
    args.format_options = None
    env.stdout_isatty = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == Enc

# Generated at 2022-06-17 20:58:13.980879
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile
    import pytest

    # create a temp file
    fd, temp_file_path = tempfile.mkstemp()
    os.close(fd)
    # create a temp file
    fd, temp_file_path2 = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-17 20:58:25.181053
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == EncodedStream

# Generated at 2022-06-17 20:58:35.961527
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:38.596904
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-17 20:58:44.297142
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py34
    from httpie.compat import is_py35
    from httpie.compat import is_py36
    from httpie.compat import is_py37
    from httpie.compat import is_py38

# Generated at 2022-06-17 20:58:55.129934
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    import requests
    import argparse
    import sys

# Generated at 2022-06-17 20:59:02.243310
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['all']
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}


# Generated at 2022-06-17 20:59:13.572933
# Unit test for function write_message
def test_write_message():
    import sys
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:59:21.324922
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}

    # Test 1
    env.stdout_isatty = False
    args.prettify = []
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream

# Generated at 2022-06-17 20:59:31.194846
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting

    class MockArgs:
        def __init__(self):
            self.prettify = 'colors'
            self.stream = False
            self.debug = False
            self.traceback = False

    class MockEnv:
        def __init__(self):
            self.stdout = StringIO()
            self.stdout_isatty = True
            self.is_windows = True

    class MockRequest:
        def __init__(self):
            self.url = 'http://www.example.com'

# Generated at 2022-06-17 20:59:49.526991
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import get_parser
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import requests_mock
    import responses
    import httpretty
    import urllib3
    import socket
    import ssl
    import threading
    import time
    import subprocess
    import signal
    import pytest

# Generated at 2022-06-17 20:59:55.841384
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:05.164589
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    import io
    import os
    import json
    import pytest

    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdout_isatty=True,
        stdin_isatty=True,
        is_windows=False,
    )

# Generated at 2022-06-17 21:00:14.674084
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse

    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = False
    args.style = 'parrot'
    args.json = False
    args.format_options = {}

    env = Environment()
    env.stdout_isatty = True

    requests_message = requests.PreparedRequest()
    requests_message.url = 'http://www.google.com'
    requests_message.method = 'GET'

# Generated at 2022-06-17 21:00:25.643036
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import MESSAGE_SEPARATOR

# Generated at 2022-06-17 21:00:37.066754
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    import sys
    import io
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a temporary file
    temp_file2 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file2.close

# Generated at 2022-06-17 21:00:44.279331
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import RawStream
    env = Environment()
    env.stdout = sys.stdout
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.stream = False
    args.prettify = False
    args.debug = False
    args.traceback = False
    args.download = False
    args.style = None
    args.json = False
    args.format_options = None
    args.output_file = None
    args.output_dir = None
    args.output_options = None
    args.headers = None
    args.body = None
    args.verbose = False
    args.verify = True
    args.ignore_stdin = False
    args.follow = False
    args.max

# Generated at 2022-06-17 21:00:52.003280
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks
        def __iter__(self):
            for chunk in self.chunks:
                yield chunk.encode()
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=FakeStream(['\x1b[31mfoo\x1b[0m', 'bar']),
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == '\x1b[31mfoo\x1b[0mbar'

# Generated at 2022-06-17 21:01:04.033544
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    chunks = [
        b'\x1b[1;31mfoo\x1b[0m',
        b'bar',
        b'\x1b[1;31mbaz\x1b[0m',
        b'qux',
    ]
    stream = FakeStream(chunks)
    outfile = StringIO()
    write_stream_with_colors_win_py3(stream, outfile, flush=False)

# Generated at 2022-06-17 21:01:15.764411
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:01:29.968051
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie import ExitStatus
    import requests
    import argparse
    import io
    import sys
    import os
    import tempfile
    import pytest
    import json
    import httpie.output.formatters
    import httpie.output.formatters.json
    import httpie.output.formatters.colors
    import httpie.output.formatters.colors.win_py3
    import httpie.output.formatters.colors.win_py3.win_ans

# Generated at 2022-06-17 21:01:39.678062
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_

# Generated at 2022-06-17 21:01:45.411347
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    import argparse
    import sys
    import io
    import os
    import tempfile

    # Create a temp file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()

    # Create a temp file
    temp_file2 = tempfile.NamedTemporaryFile(delete=False)
    temp_file2.close()

    # Create a temp file
    temp_file3 = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-17 21:01:52.333312
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    env = Environment()
    args = parser.parse_args()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'paraiso-dark'
    args.format_options = {}
    args.json = False
    args.debug = False
    args.traceback = False

    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.google.com'
    requests_message.headers = {'User-Agent': 'Mozilla/5.0'}

# Generated at 2022-06-17 21:02:02.932956
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_BYTES
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_LEN
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_LEN_BYTES
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_LEN_BYTES_LEN
    from httpie.output.streams import COLOR_ESCAPE_SEQUENCE_LEN_BYTES_LEN_BYTES
    from httpie.output.streams import COLOR_ESCAP

# Generated at 2022-06-17 21:02:11.288797
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.streams import BaseStream
    import argparse
    import requests
    import sys
    import os
    import io
    import tempfile
    import pytest
    import httpie.output.streams
    import httpie.output.processing
    import httpie.cli.argtypes
    import httpie.cli
    import httpie.compat

# Generated at 2022-06-17 21:02:15.768569
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    assert write_message(requests_message, env, args, with_headers, with_body) == None


# Generated at 2022-06-17 21:02:24.028004
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context

# Generated at 2022-06-17 21:02:36.224434
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BaseStream
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import MESSAGE_SEPARATOR, MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import write_stream, write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message, get_stream_type_and_kwargs

# Generated at 2022-06-17 21:02:47.333858
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:03:04.004766
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream, PrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_message
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_

# Generated at 2022-06-17 21:03:13.769243
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )


# Generated at 2022-06-17 21:03:20.257751
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    # test case 1
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 21:03:30.010646
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    import requests
    import argparse
    import io
    import sys

    # Test for RawStream
    args = parser.parse_args(['--stream'])
    env = Environment(stdout=io.StringIO(), stderr=io.StringIO())
    requests_message = requests.PreparedRequest()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == RawStream

# Generated at 2022-06-17 21:03:41.382907
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    req = requests.PreparedRequest()
    req.url = 'http://www.google.com'

# Generated at 2022-06-17 21:03:51.475878
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    req = requests.PreparedRequest()
    req.method = 'GET'
    req.url = 'http://www.google.com'
    req.headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'}
    req

# Generated at 2022-06-17 21:04:03.710746
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream

    args = argparse.Namespace()
    env = Environment()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True

    # Test for stream_class = PrettyStream
    args.prettify = ['colors']
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__.__name__ == 'Conversion'
    assert stream_kwargs['formatting'].__class

# Generated at 2022-06-17 21:04:15.508727
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams

# Generated at 2022-06-17 21:04:27.446291
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:04:39.580231
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_message
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import argparse
    import io
    import sys
    import os
    import errno



# Generated at 2022-06-17 21:04:59.552827
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py2
    from httpie.compat import is_windows_py

# Generated at 2022-06-17 21:05:06.436976
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:17.262496
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    from httpie.output.streams import PrettyStream

    args = httpie.cli.parser.parse_args(['--pretty=all'])
    env = Environment()
    env.stdout_isatty = True
    env.stdout = open('/dev/null', 'w')
    env.stderr = open('/dev/null', 'w')
    env.stdin = open('/dev/null', 'r')
    env.is_windows = False

    # test for request
    request = requests.Request('GET', 'http://httpbin.org/get')
    prepared_request = request.prepare()

# Generated at 2022-06-17 21:05:28.284393
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    env.stdout_isatty = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    stream_class, stream_kwargs = get_stream_type_and_kwargs

# Generated at 2022-06-17 21:05:38.614667
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.output.formatters.format
    import httpie.output.formatters.headers
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty
    import httpie.output.formatters.stream
    import httpie.output.formatters.terminal
    import httpie.output.formatters.utils
    import httpie.output.formatters.verbose
    import httpie.output.processing
    import httpie.output.streams
    import httpie.output.writers
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.manager
    import httpie.plugins.builtin


# Generated at 2022-06-17 21:05:43.616092
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli import parser
    args = parser.parse_args(['--pretty=all'])
    env = Environment()
    req = HTTPRequest(requests.PreparedRequest())
    stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=req,
        with_body=True,
        with_headers=True,
    )
    assert isinstance(stream, PrettyStream)

# Generated at 2022-06-17 21:05:48.350143
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class FakeOutfile(io.TextIOWrapper):
        def __init__(self, chunks):
            self.chunks = chunks
            self.buffer = io.BytesIO()
            self.encoding = 'utf-8'

        def write(self, chunk):
            self.chunks.append(chunk)

    class FakeStdout(io.TextIOWrapper):
        def __init__(self, chunks):
            self.chunks = chunks
            self.buffer = io.BytesIO()

# Generated at 2022-06-17 21:06:01.786129
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:06:12.328714
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )