

# Generated at 2022-06-17 20:56:22.545082
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    import argparse

    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = None
    args.format_options = None

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['all']
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-17 20:56:27.925248
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import RawStream
    env = Environment()
    args = argparse.Namespace()
    outfile = io.StringIO()
    stream = RawStream(msg=HTTPResponse(requests.Response()), with_headers=True, with_body=True, chunk_size=1)
    write_stream(stream, outfile, False)
    assert outfile.getvalue() == 'HTTP/1.1 200 OK\r\n\r\n'

# Generated at 2022-06-17 20:56:38.030239
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

    args = httpie.cli.parser.parse_args(['--stream', '--prettify'])
    env = Environment()
    env.stdout_isatty = True
    env.stdout = None
    env.stderr = None
    env.is_windows = False

    # Test for stream_class and stream_kwargs
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 20:56:47.778214
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream

    class args:
        def __init__(self):
            self.prettify = ['colors']
            self.stream = False
            self.style = 'default'
            self.json = False
            self.format_options = {}

    class env:
        def __init__(self):
            self.stdout_isatty = True


# Generated at 2022-06-17 20:56:53.904183
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import requests
    import argparse
    import io
    import sys
    import os
    import tempfile
    import unittest

    class TestWriteMessage(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.env.stdout = io.StringIO()
            self.env.stdout_isatty = True
            self.env.stderr = io.StringIO()
            self.env.stderr_isatty = True
            self.env.stdin = io.StringIO()
            self.env

# Generated at 2022-06-17 20:56:54.421515
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-17 20:57:02.412566
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}
    args.stream = False
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.output_dir = None
    args.output

# Generated at 2022-06-17 20:57:12.486962
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
   

# Generated at 2022-06-17 20:57:24.258221
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = True
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.google.com'
    requests_message.headers = {'Content-Type': 'text/html'}

# Generated at 2022-06-17 20:57:29.197122
# Unit test for function write_message
def test_write_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:44.934616
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union


# Generated at 2022-06-17 20:57:52.187046
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    args = parser.parse_args(['--prettify', 'all'])

# Generated at 2022-06-17 20:57:57.884267
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False

    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'

# Generated at 2022-06-17 20:58:04.711152
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class MockStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.stream = MockStream([b'foo', b'bar', b'baz'])
            self.outfile = io.BytesIO()

        def test_write_stream(self):
            write_stream(
                stream=self.stream,
                outfile=self.outfile,
                flush=False
            )
            self.assertEqual(self.outfile.getvalue(), b'foobarbaz')


# Generated at 2022-06-17 20:58:12.945621
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.output_dir = None
    args.headers = None
    args.verbose = False
    args.print_body = False
    args.style = 'default'
    args.style_sheet = None


# Generated at 2022-06-17 20:58:24.781999
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    args = parser.parse_args(['--pretty=all'])
    env = Environment(stdout=StringIO(), stdout_isatty=True)
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'https://httpbin.org/get'
    requests_message.headers = {'User-Agent': 'HTTPie/1.0.2'}
    requests_message.body = '{"key": "value"}'
    stream_class = PrettyStream
    stream_

# Generated at 2022-06-17 20:58:35.629653
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_

# Generated at 2022-06-17 20:58:42.535968
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream

# Generated at 2022-06-17 20:58:52.318597
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py3_colorama_installed
    from httpie.compat import is_windows_py3_colorama_not_installed
    from httpie.compat import is_windows_py3_colorama_installed_but_not_imported
    from httpie.compat import is_windows_py3_

# Generated at 2022-06-17 20:59:02.687540
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream

# Generated at 2022-06-17 20:59:16.008264
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    import sys
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

# Generated at 2022-06-17 20:59:22.640541
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.outfile = io.StringIO()
            self.chunks = [b'chunk1', b'chunk2']

        def test_write_stream(self):
            write_stream(
                stream=TestStream(self.chunks),
                outfile=self.outfile,
                flush=False
            )

# Generated at 2022-06-17 20:59:32.302057
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:59:39.502774
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse

    args = argparse.Namespace(
        stream=True,
        prettify=['colors'],
        style='paraiso-dark',
        json=False,
        format_options={},
    )
    env = Environment()
    env.stdout_isatty = True
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.baidu.com'
    requests_message.headers = {'User-Agent': 'Mozilla/5.0'}
    requests

# Generated at 2022-06-17 20:59:48.750101
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedBytesStream
    stream = ColorizedBytesStream(
        msg=None,
        with_headers=False,
        with_body=False,
        env=None,
        conversion=None,
        formatting=None,
    )
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False,
    )
    assert outfile.getvalue() == '\x1b[1;32m\x1b[1;32m\x1b[0m\n'

# Generated at 2022-06-17 20:59:55.355250
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__ == Conversion
    assert stream_kwargs['formatting'].__class__ == Format

# Generated at 2022-06-17 21:00:04.912675
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3

# Generated at 2022-06-17 21:00:12.703528
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    import argparse

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.style = None
    args.json = False
    args.format_options = {}
    args.stream = False

    # Test for RawStream
    env.stdout_isatty = False

# Generated at 2022-06-17 21:00:24.651979
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.downloads import Downloader
    from httpie.compat import is_windows
    from httpie.cli import parser
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    import requests
    import argparse
    import sys
    import os
    import tempfile
    import io
    import pytest


# Generated at 2022-06-17 21:00:36.070627
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 21:00:51.393016
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs

    # Test write_stream

# Generated at 2022-06-17 21:01:03.806112
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:15.697026
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins import plugin_manager
    from httpie.downloads import Downloader
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream
   

# Generated at 2022-06-17 21:01:26.536606
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:38.278640
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:48.113604
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import sys
    import unittest
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kw

# Generated at 2022-06-17 21:02:01.203086
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    import argparse
    import requests

    if not is_windows:
        return

    env = Environment()
    env.stdout = StringIO()

# Generated at 2022-06-17 21:02:10.792800
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:02:20.722215
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:02:26.165182
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io
    import pytest
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import write_stream
    from httpie.output.streams import MESSAGE_SEPARATOR

# Generated at 2022-06-17 21:02:39.374128
# Unit test for function write_stream
def test_write_stream():
    import sys
    import io
    import os
    import tempfile
    import unittest
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPR

# Generated at 2022-06-17 21:02:49.116870
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 21:03:00.649446
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream

# Generated at 2022-06-17 21:03:10.476546
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 21:03:18.140900
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.output_dir = None
    args.output_options = None
    args.output_options_file = None

# Generated at 2022-06-17 21:03:29.255277
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs

# Generated at 2022-06-17 21:03:40.963491
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import M

# Generated at 2022-06-17 21:03:50.669914
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs

    # Test

# Generated at 2022-06-17 21:03:57.675988
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys
    env = Environment()
    args = parser.parse_args(args=[])
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    message_class = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }[type(requests_message)]

# Generated at 2022-06-17 21:04:03.701850
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-17 21:04:25.987870
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.core import main
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, RawStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse

# Generated at 2022-06-17 21:04:32.212331
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.compat import is_windows
    import argparse
    import sys
    import io


# Generated at 2022-06-17 21:04:41.706263
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse

    args = argparse.Namespace(
        stream=True,
        prettify=['colors'],
        style='paraiso-dark',
        json=False,
        format_options={},
    )
    env = Environment()
    env.stdout_isatty = True

    # Test for HTTPRequest
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'

# Generated at 2022-06-17 21:04:52.131173
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import io
    import argparse
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:01.405899
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:05:12.646390
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:05:23.817372
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:31.781595
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        RawStream,
        PrettyStream,
        BufferedPrettyStream,
        EncodedStream,
    )
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False

    # Test for RawStream
    env.stdout_isatty = False

# Generated at 2022-06-17 21:05:41.090133
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment(stdout=sys.stdout, stderr=sys.stderr)
    args = argparse.Namespace()
    args.stream = True
    args.prettify = 'all'
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options

# Generated at 2022-06-17 21:05:50.571633
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py3_colorama_installed
    from httpie.compat import is_windows_py3_colorama_not_installed
