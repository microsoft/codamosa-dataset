

# Generated at 2022-06-17 20:56:25.283691
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse


# Generated at 2022-06-17 20:56:32.340479
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = None
    args.style = None
    args.json = None
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['all']
    args.stream = True
    args.style = 'solarized'
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 20:56:39.384762
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'solarized'
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    requests_message.url = 'http://www.baidu.com'
    requests_message.method = 'GET'

# Generated at 2022-06-17 20:56:47.599114
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream

    stream = ColorizedStream(
        msg=None,
        with_headers=False,
        with_body=False,
        env=None,
        conversion=None,
        formatting=None,
    )
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False,
    )
    assert outfile.getvalue() == '\x1b[1m\x1b[31mfoo\x1b[39m\x1b[22m'

# Generated at 2022-06-17 20:57:00.562786
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    import requests
    import argparse

    # Test for RawStream
    env = Environment(
        stdout_isatty=False,
        stdin_isatty=False,
        is_windows=is_windows,
        colors=256,
        stdout=None,
        stdin=None,
        stderr=None,
    )
    args = parser.parse_args(args=[])
    args.prettify = None
    args.stream = False


# Generated at 2022-06-17 20:57:11.335280
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)
    assert stream_kwargs['formatting'].env == env
    assert stream_kwargs['formatting'].groups == ['all']
    assert stream_kwargs['formatting'].color_scheme == 'solarized'

# Generated at 2022-06-17 20:57:23.535424
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    import argparse
    import requests
    import sys


# Generated at 2022-06-17 20:57:30.588144
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie import ExitStatus
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.output.formatters.colors import get_style
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import os
    import sys
    import io
    import pytest

    # Test for RawStream

# Generated at 2022-06-17 20:57:35.620611
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import isatty
    from httpie.compat import str

    class FakeStream(BaseStream):
        def __init__(self, msg, with_headers, with_body, env, conversion, formatting):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
            self.env = env
            self.conversion = conversion

# Generated at 2022-06-17 20:57:45.795573
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys
    import os


# Generated at 2022-06-17 20:57:56.622881
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_message
    from httpie.output.streams import build_output_stream_for_message

# Generated at 2022-06-17 20:58:03.878902
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    class TestStream(BaseStream):
        def __init__(self, msg, with_headers, with_body):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
        def __iter__(self):
            yield b'\x1b[1m\x1b[31m'
            yield b'\x1b[1m\x1b[32m'
            yield b'\x1b[1m\x1b[33m'
            yield b'\x1b[1m\x1b[34m'
            yield b'\x1b[1m\x1b[35m'

# Generated at 2022-06-17 20:58:08.356568
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:20.059247
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse

    args = argparse.Namespace()
    env = Environment()
    args.stream = False
    args.prettify = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    with_headers = False
    with_body = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args

# Generated at 2022-06-17 20:58:20.665171
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-17 20:58:28.892258
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:58:38.714805
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    from httpie.output.streams import write_stream, write_stream_with_colors_win_py3
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import io
    import sys
    import os
    import tempfile
    import pytest
    import platform
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import Key

# Generated at 2022-06-17 20:58:43.603329
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli import parser
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    import requests
    import argparse
    import sys
    import os
    import io
    import tempfile
    import pytest
    import httpie.output.streams
    import httpie.output

# Generated at 2022-06-17 20:58:52.832938
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    import io
    import sys
    import os
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_

# Generated at 2022-06-17 20:58:59.940118
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}

# Generated at 2022-06-17 20:59:13.160284
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream

    env = Environment()
    args = argparse.Namespace()
    args.prettify = 'colors'
    args.stream = False
    args.style = 'solarized'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    env.stdout_isatty = True



# Generated at 2022-06-17 20:59:21.066590
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import io
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context

    class MockArgs:
        def __init__(self):
            self.prettify = None
            self.stream = False
            self.style = None
            self.json = False
            self.format_options = {}
            self.debug = False
            self.traceback = False

    class MockEnv:
        def __init__(self):
            self.stdout = io.StringIO()
            self.stdout_isatty = True
            self.stderr = io.StringIO()
            self.is_windows = False


# Generated at 2022-06-17 20:59:30.859906
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    import requests
    import argparse
    import sys
    import io
    import os

    # Test for RawStream
    env = Environment(stdout=sys.stdout, stdout_isatty=False)
    args = parser.parse_args(args=[])
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE

    # Test for Raw

# Generated at 2022-06-17 20:59:38.451021
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    args.debug = False
    args.traceback = False
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-17 20:59:43.736794
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items

# Generated at 2022-06-17 20:59:48.176017
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input import ParseRequest
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parser
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA

# Generated at 2022-06-17 20:59:54.966656
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs

# Generated at 2022-06-17 21:00:04.538521
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:12.481325
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-17 21:00:24.393927
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Format

# Generated at 2022-06-17 21:00:43.284525
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    MESSAGE_SEPARATOR = '\n\n'
    MESSAGE_SEPARATOR_BYTES = MESSAGE_SEPARATOR.encode()
    requests_message = requests.PreparedRequest()
    env = Environment()


# Generated at 2022-06-17 21:00:52.262606
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream

# Generated at 2022-06-17 21:01:04.168619
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:15.836715
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import argparse
    import sys
    import io
    import os
    import tempfile
    import pytest
    import json
    import httpie.output.streams
    import httpie.output.processing
    import http

# Generated at 2022-06-17 21:01:26.686985
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import get_parser
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

    args = get_parser().parse_args(args=[])
    env = Environment(vars(args))
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class,

# Generated at 2022-06-17 21:01:38.278462
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}

    # Test for PrettyStream
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 21:01:48.151023
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Test for function write_stream_with_colors_win_py3
    """
    import io
    import sys
    from httpie.output.streams import BaseStream

    class MockStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class MockOutfile:
        def __init__(self, encoding):
            self.encoding = encoding
            self.buffer = io.BytesIO()

    class MockArgs:
        def __init__(self, prettify):
            self.prettify = prettify

    class MockEnv:
        def __init__(self, is_windows):
            self.is_windows = is_windows


# Generated at 2022-06-17 21:01:53.889152
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    env = Environment(stdout_isatty=False)
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=False, format_options=None)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream

# Generated at 2022-06-17 21:02:03.535935
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.compat import is_windows
    from httpie.cli import parser
    args = parser.parse_args([])
    env = Environment(args)

# Generated at 2022-06-17 21:02:11.734010
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class FakeEnv:
        def __init__(self, is_windows, stdout_isatty):
            self.is_windows = is_windows
            self.stdout_isatty = stdout_isatty

    class FakeArgs:
        def __init__(self, prettify, stream):
            self.prettify = prettify

# Generated at 2022-06-17 21:02:40.299049
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting

    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = []

    requests_message = requests.PreparedRequest()
    requests_message.url = 'http://localhost:8080/'
    requests_message.method = 'GET'
    requests_message.headers = {'Content-Type': 'application/json'}

# Generated at 2022-06-17 21:02:50.223952
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.cli import parser
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream

# Generated at 2022-06-17 21:03:00.949140
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='solarized',
        format_options={},
        json=False,
        debug=False,
        traceback=False,
    )

    # Test for HTTPRequest
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'

# Generated at 2022-06-17 21:03:10.778384
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.style = 'default'
    args.stream = False
    args.prettify = []
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['all']

# Generated at 2022-06-17 21:03:18.331172
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream

    class FakeEnv:
        def __init__(self):
            self.stdout = io.StringIO()
            self.stdout_isatty = True

    class FakeArgs:
        def __init__(self):
            self.prettify = []
            self.stream = False
            self.debug = False
            self.traceback = False

    class FakeStream(BaseStream):
        def __init__(self, **kwargs):
            pass

        def __iter__(self):
            yield b

# Generated at 2022-06-17 21:03:29.290769
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.compat import is_windows

# Generated at 2022-06-17 21:03:40.964183
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)
    assert stream_kwargs['formatting'].env == env
    assert stream_kwargs['formatting'].groups == ['all']
    assert stream_kwargs['formatting'].color_scheme == 'default'
    assert stream_kwargs

# Generated at 2022-06-17 21:03:51.521388
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    write_message(requests_message, env, args, with_headers, with_body)

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )

# Generated at 2022-06-17 21:03:55.173602
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.input import ParseRequest
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 21:04:05.512484
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'paraiso-dark'
    args.format_options = {}
    args.json = False
    args.debug = False
    args.traceback = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    message_class = HTTPRequest
    outfile = StringIO()

# Generated at 2022-06-17 21:04:39.509495
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows


# Generated at 2022-06-17 21:04:45.859631
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream_with_colors_win_py3

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class FakeEnv:
        def __init__(self, stdout_isatty=True):
            self.stdout_isatty = stdout_isatty


# Generated at 2022-06-17 21:04:54.653890
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3

# Generated at 2022-06-17 21:05:01.564131
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment(stdout_isatty=True, stdin_isatty=True,
                      stdout=sys.stdout, stdin=sys.stdin)
    args = argparse.Namespace(prettify=['colors'], style='paraiso-dark',
                              stream=False, json=False, format_options={})
    requests_message = requests.PreparedRequest()
    requests_

# Generated at 2022-06-17 21:05:12.725870
# Unit test for function write_message
def test_write_message():
    from httpie.input import ParseRequest
    from httpie.output import write_message
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:23.890750
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    import io
    import sys
    import os
    import tempfile


# Generated at 2022-06-17 21:05:31.805817
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests

    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}

    # Test RawStream
    args.prettify = []
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == Raw

# Generated at 2022-06-17 21:05:41.125650
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import argparse
    import requests
    import io
    import sys

    # Test case 1:
    #   env.stdout_isatty = True
    #   args.prettify = True
    #   args.stream = True
    #   env.stdout_isatty = True
    #   env.stdout = sys.stdout
    #   env.stderr = sys.stderr
    #   env.is_windows = is_windows
    #   env.stdout_encoding

# Generated at 2022-06-17 21:05:45.490555
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    sys.stdout = io.StringIO()
    write_stream(
        stream=b'hello',
        outfile=sys.stdout,
        flush=True
    )
    assert sys.stdout.getvalue() == 'hello'

# Generated at 2022-06-17 21:05:52.163311
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    env = Environment()
    args = argparse.Namespace(prettify=[], stream=False, style='', json=False, format_options={})
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__.__name__ == 'Conversion'
    assert stream_kwargs['formatting'].__class__.__name__ == 'Formatting'
    assert stream_kwargs['formatting'].env == env
    assert stream_kwargs['formatting'].groups == []
   