

# Generated at 2022-06-17 20:56:24.593456
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    import argparse
    import requests
    import io
    import sys
    env = Environment(stdout=io.StringIO(), stderr=io.StringIO(), stdin=io.StringIO())

# Generated at 2022-06-17 20:56:35.382862
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream, BufferedPrettyStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_dir = None
    args.output_file_prefix = None
    args.output_file_suffix = None
    args.output_to_devnull = False


# Generated at 2022-06-17 20:56:46.120953
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.output.formatters.format
    import httpie.output.formatters.headers
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty
    import httpie.output.formatters.stream
    import httpie.output.formatters.terminal
    import httpie.output.formatters.utils
    import httpie.output.processing
    import httpie.output.streams
    import httpie.output.writers
    import httpie.plugins
    import httpie.status
    import httpie.utils
    import httpie.compat
    import httpie.models
    import httpie.context
    import httpie.plugins.builtin
    import http

# Generated at 2022-06-17 20:56:50.612198
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:01.515024
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['headers']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_

# Generated at 2022-06-17 20:57:11.940042
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    env = Environment()
    args = argparse.Namespace()
    args.prettify = 'all'
    args.stream = False
    args.style = 'solarized'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'

# Generated at 2022-06-17 20:57:23.881063
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream, BufferedPrettyStream, EncodedStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MES

# Generated at 2022-06-17 20:57:30.869069
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:39.442964
# Unit test for function write_stream
def test_write_stream():
    import io
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest

    env = Environment()
    env.stdout = io.StringIO()
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'solarized'
    args.format_options = {}


# Generated at 2022-06-17 20:57:43.346583
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import sys
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs

# Generated at 2022-06-17 20:58:01.107503
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:10.860513
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import requests
    import argparse
    import sys
    import os
    import tempfile
    import io
    import pytest
    import shutil
    import subprocess
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp()
    os.close(fd)

    # Create the environment

# Generated at 2022-06-17 20:58:16.528564
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Test that write_stream_with_colors_win_py3 writes the correct output"""
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.core import main
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py36
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py36

# Generated at 2022-06-17 20:58:26.886365
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    args = parser.parse_args([])
    env = Environment()
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.google.com'
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_message.body = '{"key": "value"}'

# Generated at 2022-06-17 20:58:37.628336
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
   

# Generated at 2022-06-17 20:58:43.832872
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    args = parser.parse_args([])
    env = Environment(
        stdin=None,
        stdout=StringIO(),
        stderr=StringIO(),
        is_windows=False,
        colors=256,
        stdout_isatty=True,
        stdin_isatty=False,
        stderr_isatty=False,
    )

# Generated at 2022-06-17 20:58:52.992335
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    import argparse
    import sys
    env = Environment(stdout=sys.stdout, stderr=sys.stderr)
    args = argparse.Namespace(
        stream=False,
        prettify=['all'],
        style='paraiso-dark',
        json=False,
        format_options={},
        debug=False,
        traceback=False,
    )
    requests_message

# Generated at 2022-06-17 20:59:00.142795
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStreamChunkType
    from httpie.output.streams import ColorizedStreamChunk
    from httpie.output.streams import ColorizedStreamChunkType
    from httpie.output.streams import ColorizedStreamChunk
    from httpie.output.streams import ColorizedStreamChunkType
    from httpie.output.streams import ColorizedStreamChunk
    from httpie.output.streams import ColorizedStreamChunkType
    from httpie.output.streams import ColorizedStreamChunk
    from httpie.output.streams import ColorizedStreamChunkType
    from httpie.output.streams import ColorizedStreamChunk
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:59:05.678807
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:59:13.262551
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = True
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 20:59:33.780756
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:59:40.669112
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse

# Generated at 2022-06-17 20:59:50.588893
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)
    args.stream

# Generated at 2022-06-17 21:00:02.085337
# Unit test for function write_stream
def test_write_stream():
    import io
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    env = Environment()
    args = argparse.Namespace

# Generated at 2022-06-17 21:00:10.446078
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py2
    from httpie.compat import is_windows_py3_and_colorized
    from httpie.compat import is_windows_py2_and_

# Generated at 2022-06-17 21:00:21.934963
# Unit test for function write_message
def test_write_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 21:00:27.649262
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs


# Generated at 2022-06-17 21:00:38.977194
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, *args, **kwargs):
            super(TestStream, self).__init__(*args, **kwargs)
            self.chunks = []

        def __iter__(self):
            return iter(self.chunks)

        def write(self, chunk):
            self.chunks.append(chunk)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.stream = TestStream()
            self.outfile = io.StringIO()

        def test_write_stream(self):
            write_stream(self.stream, self.outfile, flush=False)

# Generated at 2022-06-17 21:00:49.094074
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
   

# Generated at 2022-06-17 21:01:02.409362
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:37.923140
# Unit test for function write_message
def test_write_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie

# Generated at 2022-06-17 21:01:47.845536
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3

# Generated at 2022-06-17 21:02:01.063501
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_

# Generated at 2022-06-17 21:02:10.635939
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    import requests
    import argparse
    import io
    import sys
    import os
    import tempfile
    import pytest
    import json
    import time
    import random
    import string
    import shutil
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.cli

# Generated at 2022-06-17 21:02:20.577934
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    import io
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the environment

# Generated at 2022-06-17 21:02:23.895821
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import RawStream

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.stream = RawStream(b'hello world')
            self.outfile = io.StringIO()
            self.flush = False

        def test_write_stream(self):
            write_stream(self.stream, self.outfile, self.flush)
            self.assertEqual(self.outfile.getvalue(), 'hello world')

    unittest.main()

# Generated at 2022-06-17 21:02:36.218307
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class TestOutfile(io.TextIOWrapper):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.buffer = io.BytesIO()

    outfile = TestOutfile(io.BytesIO(), encoding='utf8')

# Generated at 2022-06-17 21:02:41.152746
# Unit test for function write_message
def test_write_message():
    from httpie.cli import parser
    args = parser.parse_args(['--json', 'http://httpbin.org/get'])
    env = Environment(args)
    r = requests.get('http://httpbin.org/get')
    write_message(r, env, args, with_headers=True, with_body=True)

# Generated at 2022-06-17 21:02:51.034449
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        RawStream,
        PrettyStream,
        BufferedPrettyStream,
        EncodedStream,
    )
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.output.streams import (
        RawStream,
        PrettyStream,
        BufferedPrettyStream,
        EncodedStream,
    )
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie import ExitStatus

# Generated at 2022-06-17 21:02:57.355910
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse

# Generated at 2022-06-17 21:03:54.529934
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.output_dir = None
    args.output_options = None
    args.headers = None
    args.verbose = False


# Generated at 2022-06-17 21:04:05.275274
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream

# Generated at 2022-06-17 21:04:16.124087
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'paraiso-dark'
    args.format_options = {}
    args.stream = False
    args.json = False
    args.debug = False
    args.traceback = False
    args.download = False
    args.stdout = 'stdout'
    args.stderr = 'stderr'
    env.stdout = 'stdout'
    env.stderr = 'stderr'
    env.std

# Generated at 2022-06-17 21:04:27.521388
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_options = {'pretty': True}
    stream_class

# Generated at 2022-06-17 21:04:39.578435
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Test that write_stream_with_colors_win_py3 writes the correct output
    """
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.colors import get_lexer
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import pygments
    import pygments.lexers
    import pygments.formatters

    if not is_windows:
        return

    # Create a fake environment
    env = Environment()
    env.stdout = StringIO()
    env.stdout_isatty = True
    env.is_windows = True

    # Create a fake request
   

# Generated at 2022-06-17 21:04:48.727684
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, RawStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    import requests
    import argparse
    import io
    import sys
    import os
    import tempfile
    import pytest
    import json
    import httpie.output.formatters.colors
    from httpie.output.formatters.colors import get_style
    from httpie.output.formatters.colors import get_lexer

# Generated at 2022-06-17 21:04:57.513847
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    outfile = StringIO()
    write_stream(
        stream=RawStream(
            msg=HTTPResponse(
                requests.Response(
                    url='http://example.com',
                    status_code=200,
                    headers={'Content-Type': 'text/plain'},
                    content=b'Hello World!',
                )
            ),
            with_headers=True,
            with_body=True,
            chunk_size=RawStream.CHUNK_SIZE_BY_LINE
        ),
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nHello World!\n\n'

# Generated at 2022-06-17 21:05:03.151529
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import urlopen
    import requests
    import argparse
    import sys
    import os
    import json
    import pytest

    # Create a mock environment
    env = Environment()
    env.stdout_isatty = True
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdin = sys.stdin
    env.is_windows = os.name == 'nt'
    env.config_dir = os.path.expanduser('~/.httpie')

# Generated at 2022-06-17 21:05:09.002780
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:19.309893
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, PrettyStream
    from httpie.output.streams import ColorizedStream, Pretty