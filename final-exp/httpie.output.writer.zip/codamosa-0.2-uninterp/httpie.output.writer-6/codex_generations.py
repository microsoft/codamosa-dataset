

# Generated at 2022-06-17 20:56:25.512990
# Unit test for function write_message
def test_write_message():
    import sys
    import os
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:56:32.668949
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import io
    env = Environment()
    args = argparse.Namespace(
        stream=True,
        prettify=['colors'],
        style='paraiso-dark',
        debug=False,
        traceback=False,
        json=False,
        format_options={}
    )
    with_headers = True
    with_body = True
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'
    requests_message.body = ''

# Generated at 2022-06-17 20:56:39.920127
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
   

# Generated at 2022-06-17 20:56:49.111032
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:56:55.742223
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    import argparse
    import requests
    import sys
    import os

    # Test for RawStream
    args = argparse.Namespace(
        stream=False,
        prettify=False,
        style='',
        json=False,
        format_options={},
    )

# Generated at 2022-06-17 20:57:06.503572
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment

    class MockStream(BaseStream):
        def __init__(self, msg, with_headers, with_body, env, conversion, formatting):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
            self.env = env
            self.conversion = conversion
            self.formatting = formatting


# Generated at 2022-06-17 20:57:14.206171
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:57:25.588849
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-17 20:57:32.104928
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MESSAGE_SEPARATOR_

# Generated at 2022-06-17 20:57:42.887233
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import BaseStream

    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='solarized',
        format_options={},
        json=False,
        debug=False,
        traceback=False,
    )
    env = Environment()
    env.stdout_isatty = True
    env.stdout = None
    env.stderr = None
    env.is_windows = False

    requests_message = requests

# Generated at 2022-06-17 20:58:00.968131
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:58:08.840009
# Unit test for function write_message
def test_write_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = False
    with_body = False
    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-17 20:58:15.293197
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:25.995741
# Unit test for function write_stream
def test_write_stream():
    """
    Test write_stream function
    """
    import io
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message

# Generated at 2022-06-17 20:58:36.764825
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream

    class TestStream(ColorizedStream):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

# Generated at 2022-06-17 20:58:43.166165
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream

    env = Environment()
    env.stdout = StringIO()
    env.stdout_isatty = True
    env.is_windows = True
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'solarized'
    args.format_options = {}
    args.stream = False
    args.debug = False
    args.traceback = False
    args.json = False


# Generated at 2022-06-17 20:58:52.719898
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream

# Generated at 2022-06-17 20:59:02.880661
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    class Stream(BaseStream):
        def __init__(self, *args, **kwargs):
            super(Stream, self).__init__(*args, **kwargs)

        def __iter__(self):
            yield b'\x1b[0m'
            yield b'\x1b[1m'
            yield b'\x1b[1m'
            yield b'\x1b[1m'
            yield b'\x1b[1m'
            yield b'\x1b[1m'
            yield b'\x1b[1m'
            yield b'\x1b[1m'
            yield b'\x1b[1m'

# Generated at 2022-06-17 20:59:14.193520
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 20:59:21.674206
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BufferedPrettyStream

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.stream = BufferedPrettyStream(
                msg=None,
                with_headers=False,
                with_body=False,
                env=None,
                conversion=None,
                formatting=None,
            )
            self.stream.write(b'foo')
            self.stream.write(b'bar')
            self.stream.write(b'baz')

        def test_write_stream(self):
            outfile = io.StringIO()
            write_stream(self.stream, outfile, flush=False)
            self.assertEqual(outfile.getvalue(), 'foobarbaz')

# Generated at 2022-06-17 20:59:35.879824
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    import unittest
    from httpie.output.streams import (
        BaseStream, PrettyStream, BufferedPrettyStream, EncodedStream, RawStream,
    )
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.compat import is_windows

# Generated at 2022-06-17 20:59:41.534177
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests

    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=['headers'], style='default', json=False, format_options={}, stream=False)
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = False

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
   

# Generated at 2022-06-17 20:59:50.922770
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=['colors'], style='solarized', json=False, format_options={}, stream=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 21:00:02.085909
# Unit test for function write_message
def test_write_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:12.777346
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.headers = None
    args.verbose = False
    args.print_headers = False
    args.body = None


# Generated at 2022-06-17 21:00:24.739241
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:36.162708
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    args = parser.parse_args(['--stream'])
    env = Environment(stdout=StringIO(), stderr=StringIO(), vars=None)

# Generated at 2022-06-17 21:00:44.897314
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = True
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:00:53.644610
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import argparse
    import requests
    import sys


# Generated at 2022-06-17 21:00:58.741574
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:01:16.059199
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import isatty
    from httpie.compat import str
    from httpie.compat import bytes
    from httpie.compat import binary_type
    from httpie.compat import text_type
    from httpie.compat import string_types

# Generated at 2022-06-17 21:01:26.796075
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.style = 'all'
    args.json = False
    args.format_options = {}
    args.stream = False
    requests_message = requests.PreparedRequest()
    message_class = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }[type(requests_message)]
    stream_class, stream_kwargs = get_stream_

# Generated at 2022-06-17 21:01:32.005555
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:01:40.521876
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:01:47.613716
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:02:00.953732
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class Stream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class FakeStdout(io.TextIOWrapper):
        def __init__(self):
            self.buffer = io.BytesIO()
            super().__init__(self.buffer, encoding='utf-8')

        def write(self, text):
            self.buffer.write(text.encode('utf-8'))

    stdout = FakeStdout()

# Generated at 2022-06-17 21:02:10.522598
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'solarized'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.output_dir = None
    args.output_options = {}
    args.output_options_specified = False
    args.check_status = False

# Generated at 2022-06-17 21:02:20.411360
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import os
    import sys


# Generated at 2022-06-17 21:02:24.854601
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = True
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:02:36.568794
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    import sys
    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        is_windows=False,
        colors=256,
        stdout_isatty=True,
        stdin_isatty=True,
        stdin_is_readable=True,
        output_options={},
    )

# Generated at 2022-06-17 21:02:47.171708
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:03:00.455229
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import get_parser
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA
    from httpie.cli.constants import DEFAULT_UA


# Generated at 2022-06-17 21:03:10.262184
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.output.streams import BufferedPrettyStream
    from httpie.cli import parser
    args = parser.parse_args(['--prettify', 'all'])
    env = Environment()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)

    args = parser.parse_args(['--prettify', 'all', '--stream'])


# Generated at 2022-06-17 21:03:13.529532
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-17 21:03:20.133542
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union

    import requests

    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:03:30.010689
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['all']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:03:41.440084
# Unit test for function write_message
def test_write_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import argparse
    import io
    import sys

    env = httpie.context.Environment()
    args = httpie.cli.parser.parse_args([])
    args.prettify = ['all']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False

    # test for requests.PreparedRequest

# Generated at 2022-06-17 21:03:51.517013
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union

# Generated at 2022-06-17 21:04:03.748286
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    env = Environment(stdout=sys.stdout, stdout_isatty=True)
    args = argparse.Namespace(prettify=['colors'], style='solarized', stream=True, json=False, format_options={})
    requests_message = requests.PreparedRequest()
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_message.body = '{"key": "value"}'
    requests_message.method = 'GET'

# Generated at 2022-06-17 21:04:15.543255
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 21:04:39.582127
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:04:48.728337
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_py36
    from httpie.compat import is_py37
    from httpie.compat import is_py38
    from httpie.compat import is_py39
   

# Generated at 2022-06-17 21:05:00.061443
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:11.784782
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    import httpie.cli
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    args = httpie.cli.parser.parse_args(args=[])
    env = Environment(vars=args)
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://httpbin.org/get'
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_

# Generated at 2022-06-17 21:05:23.040374
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.stream = False
    args.prettify = False
    args.style = None
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify

# Generated at 2022-06-17 21:05:31.253669
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import MES

# Generated at 2022-06-17 21:05:40.516811
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse

    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    args.debug = False
    args.traceback = False
    env.stdout_isatty = True
    env.stdout = 'stdout'
    env.stderr = 'stderr'
    env.is_windows = False
    requests_message = requests.PreparedRequest()
    with_headers = True

# Generated at 2022-06-17 21:05:49.968537
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://localhost:8080/'
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_message.body = '{"name": "John"}'
    with_headers = True
   

# Generated at 2022-06-17 21:06:01.253684
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    class Stream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks
        def __iter__(self):
            for chunk in self.chunks:
                yield chunk.encode()
    stream = Stream(['\x1b[31mfoo\x1b[0m', 'bar'])
    outfile = StringIO()
    write_stream_with_colors_win_py3(stream, outfile, flush=False)
    assert outfile.getvalue() == '\x1b[31mfoo\x1b[0mbar'

# Generated at 2022-06-17 21:06:02.169036
# Unit test for function write_stream
def test_write_stream():
    # TODO: write unit test for function write_stream
    pass