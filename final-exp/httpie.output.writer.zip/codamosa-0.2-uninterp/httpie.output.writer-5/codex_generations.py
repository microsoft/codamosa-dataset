

# Generated at 2022-06-17 20:56:22.253595
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.formatters.colors
    import httpie.output.formatters.format
    import httpie.output.formatters.headers
    import httpie.output.formatters.json
    import httpie.output.formatters.pretty
    import httpie.output.formatters.stream
    import httpie.output.formatters.terminal
    import httpie.output.formatters.utils
    import httpie.output.processing
    import httpie.output.streams
    import httpie.output.writers
    import httpie.plugins
    import httpie.status
    import httpie.utils
    import httpie.compat
    import httpie.context
    import httpie.models
    import httpie.output
    import httpie.output

# Generated at 2022-06-17 20:56:30.488486
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import requests
    import argparse
    import sys

    class MockArgs:
        def __init__(self):
            self.prett

# Generated at 2022-06-17 20:56:37.951044
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:56:47.744850
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MESSAGE_SEPARATOR_

# Generated at 2022-06-17 20:56:53.835022
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.cli import parser
    args = parser.parse_args(['--prettify', 'all'])
    env = Environment()

# Generated at 2022-06-17 20:56:54.665512
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-17 20:57:02.462958
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import get_color_style_definition
    from httpie.output.streams import get_color_style_mapping
    from httpie.output.streams import get_color_style_name
    from httpie.output.streams import get_color_style_names
    from httpie.output.streams import get_color_style_value
    from httpie.output.streams import get_color_styles
    from httpie.output.streams import get_color_styles_by_name
    from httpie.output.streams import get_color_styles_by_value
    from httpie.output.streams import get_color_styles_mapping
    from httpie.output.streams import get_

# Generated at 2022-06-17 20:57:12.516414
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    import requests
    import argparse
    import sys
    import os
    import io
    import tempfile
    import pytest
    import json
    import httpie
    import pytest
    import os
    import json
    import httpie
    import pytest
    import os
    import json
    import httpie
    import pytest
    import os
    import json

# Generated at 2022-06-17 20:57:24.297329
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class FakeFile(io.TextIOBase):
        def __init__(self, chunks):
            self.chunks = chunks
            self.buffer = io.BytesIO()

        def write(self, chunk):
            self.chunks.append(chunk)

    chunks = []
    outfile = FakeFile(chunks)
    outfile.encoding = 'utf-8'

# Generated at 2022-06-17 20:57:34.976024
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:57:48.142413
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream

# Generated at 2022-06-17 20:58:00.942491
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.formatters.colors import get_style
    from httpie.output.formatters.utils import get_json_indent

    env = Environment(
        stdout=StringIO(),
        stdout_isatty=True,
        is_windows=False,
        colors=256,
        stdin=StringIO(),
        stdin_isatty=False,
        stdin_partial=False,
        output_options={},
        config={},
    )

# Generated at 2022-06-17 20:58:10.722262
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['colors']
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__ == Conversion

# Generated at 2022-06-17 20:58:21.608988
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import sys
    env = Environment(stdout=sys.stdout, stdout_isatty=True)
    args = argparse.Namespace(prettify=['colors'], style='paraiso-dark', stream=False)
    requests_message = requests.PreparedRequest()
    requests_message.url = 'http://www.google.com'
    requests_message.method = 'GET'
    requests_message.headers = {'Content-Type': 'application/json'}
    requests_message.body = '{"key": "value"}'
    requests_message

# Generated at 2022-06-17 20:58:29.395572
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import Buff

# Generated at 2022-06-17 20:58:38.738779
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_options = {'pretty': True}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 20:58:43.632454
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kw

# Generated at 2022-06-17 20:58:52.860290
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env

# Generated at 2022-06-17 20:58:59.975330
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest

    from httpie.output.streams import BufferedPrettyStream, RawStream

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.env = Environment(
                stdin=io.BytesIO(),
                stdout=io.BytesIO(),
                stderr=io.BytesIO(),
                stdout_isatty=True,
                stdin_isatty=True,
                is_windows=False,
            )
            self.args = argparse.Namespace(
                stream=False,
                prettify=False,
                style=None,
                json=False,
                format_options={},
                debug=False,
                traceback=False,
            )


# Generated at 2022-06-17 20:59:11.118814
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = 'all'
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-17 20:59:31.103762
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:59:38.662567
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import httpie.context
    import httpie.output.streams

# Generated at 2022-06-17 20:59:49.646268
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream

    args = parser.parse_args(args=[])
    env = Environment()

    # RawStream
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE}

    # RawStream with --stream
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE}



# Generated at 2022-06-17 21:00:01.243187
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie

# Generated at 2022-06-17 21:00:07.767383
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    write_message(requests_message, env, args, with_headers, with_body)

test_write_message()

# Generated at 2022-06-17 21:00:17.633712
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    import httpie.cli
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:23.206712
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import tempfile
    import os
    import sys
    import requests
    import httpie
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import httpie.output.processing
    import httpie.context
    import httpie.models
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli
    import httpie.cli

# Generated at 2022-06-17 21:00:34.487929
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = False
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)

# Generated at 2022-06-17 21:00:42.859919
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream

    args = parser.parse_args(['--pretty=all'])
    env = Environment()
    env.stdout_isatty = True
    env.stdout = sys.stdout
    env.stderr = sys.stderr

    # Test for request
    request = requests.Request('GET', 'http://httpbin.org/get')
    prepared_request = request.prepare()
    stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=prepared_request,
        with_body=True,
        with_headers=True,
    )
    assert isinstance(stream, PrettyStream)

    # Test for response

# Generated at 2022-06-17 21:00:52.201836
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli import parser
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream

# Generated at 2022-06-17 21:01:24.091178
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(
        prettify=[],
        stream=False,
        style='',
        json=False,
        format_options={},
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args = argparse.Namespace(
        prettify=['colors'],
        stream=False,
        style='',
        json=False,
        format_options={},
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert stream_

# Generated at 2022-06-17 21:01:28.182096
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    import sys
    env = Environment(stdout=sys.stdout)
    stream = PrettyStream(msg=None, with_headers=True, with_body=True, env=env, conversion=None, formatting=None)
    write_stream(stream=stream, outfile=sys.stdout, flush=False)

# Generated at 2022-06-17 21:01:38.633241
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_

# Generated at 2022-06-17 21:01:47.179370
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream

    class Stream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=Stream([b'\x1b[31mfoo\x1b[0m', b'bar']),
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == '\x1b[31mfoo\x1b[0mbar'

# Generated at 2022-06-17 21:02:00.765619
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.outfile = io.StringIO()

        def test_write_stream(self):
            chunks = ['chunk1', 'chunk2']
            write_stream(
                stream=TestStream(chunks),
                outfile=self.outfile,
                flush=False
            )
            self.assertEqual(self.outfile.getvalue(), 'chunk1chunk2')


# Generated at 2022-06-17 21:02:04.741355
# Unit test for function write_stream
def test_write_stream():
    stream = RawStream(msg=HTTPResponse(requests.Response()), with_headers=True, with_body=True)
    outfile = sys.stdout
    flush = True
    write_stream(stream, outfile, flush)

# Generated at 2022-06-17 21:02:12.496564
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream

    env = Environment()
    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='paraiso-dark',
        debug=False,
        traceback=False,
        json=False,
        format_options={},
    )
    requests_message = requests.PreparedRequest()
    requests_message.method = 'GET'
    requests_message.url = 'http://www.baidu.com'

# Generated at 2022-06-17 21:02:21.896840
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import requests
    import argparse
    import sys


# Generated at 2022-06-17 21:02:33.872547
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest
    from httpie.context import Environment
    import argparse
    import requests
    import io
    import sys
    import os

    env = Environment(stdout=io.StringIO(), stderr=io.StringIO())
    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='solarized',
        json=False,
        format_options={},
        debug=False,
        traceback=False,
    )
    requests_message = requests.PreparedRequest()
    requests_message.url = 'http://www.google.com'
    requests_message.method = 'GET'
    requests_message.headers

# Generated at 2022-06-17 21:02:40.830312
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import MESSAGE_SEPARATOR_BYTES
    from httpie.output.streams import MESSAGE_SEPARATOR

    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    env = Environment()
    env.stdout_isatty = True
    env.stdout = None
    env.stderr = None

# Generated at 2022-06-17 21:03:30.081526
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    import sys
    import io
    import argparse


# Generated at 2022-06-17 21:03:41.469401
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class FakeStdout(io.TextIOWrapper):
        def __init__(self, *args, **kwargs):
            self.buffer = io.BytesIO()
            super().__init__(self.buffer, *args, **kwargs)

    class FakeEnv:
        def __init__(self, is_windows=False):
            self.is_windows = is_windows

    class FakeArgs:
        def __init__(self, prettify=None):
            self.prettify = prettify


# Generated at 2022-06-17 21:03:51.517350
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    args.style = None
    args.stream = False
    args.prettify = []
    args.json = False
    args.format_options = {}
    env.stdout_isatty = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.pre

# Generated at 2022-06-17 21:03:58.009108
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.chunks = [b'foo', b'bar', b'baz']

        def __iter__(self):
            return iter(self.chunks)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.stream = TestStream()
            self.outfile = io.BytesIO()

        def test_write_stream(self):
            write_stream(self.stream, self.outfile, flush=False)

# Generated at 2022-06-17 21:03:58.962892
# Unit test for function write_message
def test_write_message():
    # TODO
    pass

# Generated at 2022-06-17 21:04:06.723275
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import argparse
    import httpie.cli
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3

# Generated at 2022-06-17 21:04:16.574265
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:04:27.557627
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:04:39.582457
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import sys
    import os
    import io
    import json
    import pytest
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import write_stream, write_stream_with_colors_win_py3
    from httpie.output.streams import build_

# Generated at 2022-06-17 21:04:48.727537
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream