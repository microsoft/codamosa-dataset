

# Generated at 2022-06-17 20:56:22.926488
# Unit test for function write_message
def test_write_message():
    import sys
    import os
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and

# Generated at 2022-06-17 20:56:34.181502
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import json
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:56:44.962157
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:56:49.071005
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:57:01.031125
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = 'colors'
    args.style = 'paraiso-dark'
    args.json = False
    args.format_options = {}
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)


# Generated at 2022-06-17 20:57:11.624829
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:57:23.709237
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = True
    args.style = 'parrot'
    args.json = True
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
   

# Generated at 2022-06-17 20:57:27.060285
# Unit test for function write_stream
def test_write_stream():
    stream = [b'a', b'b', b'c']
    outfile = io.BytesIO()
    write_stream(stream, outfile, True)
    assert outfile.getvalue() == b'abc'


# Generated at 2022-06-17 20:57:37.349979
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BaseStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-17 20:57:44.900739
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.outfile = io.StringIO()
            self.chunks = ['chunk1', 'chunk2']

        def test_write_stream(self):
            write_stream(
                stream=TestStream(self.chunks),
                outfile=self.outfile,
                flush=False
            )
            self.assertEqual(self.outfile.getvalue(), ''.join(self.chunks))

# Generated at 2022-06-17 20:57:58.710892
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse

# Generated at 2022-06-17 20:58:05.183295
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:58:14.211222
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 20:58:25.221826
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    import argparse
    import requests
    import sys
    import os
    import tempfile
    import unittest
    import shutil
    import subprocess
    import json

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            self.env = Environment()
            self.args = argparse.Namespace

# Generated at 2022-06-17 20:58:36.039047
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream, RawStream, BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import MESSA

# Generated at 2022-06-17 20:58:42.761841
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = 'all'
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.output_dir = None
    args.output_options = {}
    args.check_status = False
    args

# Generated at 2022-06-17 20:58:52.475155
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 20:58:59.471972
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 20:59:10.249313
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style='paraiso-dark',
        json=False,
        format_options={},
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs == {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=['colors'],
            color_scheme='paraiso-dark',
            explicit_json=False,
            format_options={},
        )
    }

# Generated at 2022-06-17 20:59:18.951622
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.output.streams import CHUNK_SIZE, CHUNK_SIZE_BY_LINE

    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(
        prettify=None,
        stream=False,
        style='default',
        json=False,
        format_options={},
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
   

# Generated at 2022-06-17 20:59:34.631032
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BaseStream
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    import argparse
    import sys
    import os
    from io import StringIO
    from io import BytesIO
    from io import TextIOWrapper
    from io import BufferedWriter
    from io import BufferedReader
    from io import BufferedRWPair
    from io import BufferedRandom


# Generated at 2022-06-17 20:59:41.256355
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = 'colors'
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream

# Generated at 2022-06-17 20:59:50.800570
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    args.prettify = ['all']
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:00:02.084934
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    import argparse
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args.prettify = ['colors']
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_

# Generated at 2022-06-17 21:00:10.444959
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = False
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=[], color_scheme='default', explicit_json=False, format_options={})})
    args.stream = True

# Generated at 2022-06-17 21:00:16.908419
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:00:27.873015
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class TestOutfile:
        def __init__(self, encoding):
            self.encoding = encoding
            self.buffer = io.BytesIO()

        def write(self, data):
            self.buffer.write(data.encode(self.encoding))

        def flush(self):
            pass

    class TestEnv:
        def __init__(self, is_windows):
            self.is_windows = is_windows

    class TestArgs:
        def __init__(self, prettify):
            self.pre

# Generated at 2022-06-17 21:00:39.102763
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import write_stream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs

    # Test for function write_message

# Generated at 2022-06-17 21:00:49.207472
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DEFAULT_FORMAT
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli.parser import parse_items
    from httpie.cli.constants import DE

# Generated at 2022-06-17 21:01:02.484040
# Unit test for function write_message
def test_write_message():
    import sys
    from httpie.context import Environment
    from httpie.output.streams import RawStream
    from httpie.output.processing import Conversion
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Formatting
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    import os
    import tempfile
    import io
    import pytest
    import json
    import httpie
    import httpie.cli
    import httpie.output
    import httpie.output.streams
    import httpie.output.processing

# Generated at 2022-06-17 21:01:18.230252
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import write_message
    from httpie.output.streams import MESSAGE_SEPARATOR
    from httpie.output.streams import MES

# Generated at 2022-06-17 21:01:27.515757
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import io
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'paraiso-dark'
    args.stream = False
    env = Environment()
    env.stdout_isatty = True
    env.stdout = io.StringIO()
    env.stderr = io.StringIO()
    env.is_windows = False
    env.stdout_encoding = 'utf-8'
    env.st

# Generated at 2022-06-17 21:01:30.861593
# Unit test for function write_stream
def test_write_stream():
    import io
    outfile = io.BytesIO()
    write_stream(b'hello', outfile, False)
    assert outfile.getvalue() == b'hello'

# Generated at 2022-06-17 21:01:40.039321
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.compat import is_windows
    from httpie.compat import is_py3
    from httpie.compat import is_windows_py3
    from httpie.compat import is_windows_py3_colorama
    from httpie.compat import is_

# Generated at 2022-06-17 21:01:49.109419
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream

    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class FakeOutfile:
        def __init__(self, chunks):
            self.chunks = chunks

        def write(self, chunk):
            self.chunks.append(chunk)

    class FakeEnv:
        def __init__(self, is_windows):
            self.is_windows = is_windows

    class FakeArgs:
        def __init__(self, prettify):
            self.prettify = prettify

    def test(chunks, expected_chunks, is_windows, prettify):
        outfile = Fake

# Generated at 2022-06-17 21:01:57.333755
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False
    args.output = None
    args.output_file = None
    args.output_dir = None
    args.output_options = []
    args.check_status = False
    args.ignore_std

# Generated at 2022-06-17 21:02:04.663047
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    import requests
    import argparse
    import sys

    args = argparse.Namespace()
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True

    # test for PrettyStream

# Generated at 2022-06-17 21:02:12.450330
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    import argparse
    from httpie.output.processing import Conversion, Formatting
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)
    args

# Generated at 2022-06-17 21:02:13.941662
# Unit test for function write_stream
def test_write_stream():
    # TODO: write unit test for function write_stream
    pass


# Generated at 2022-06-17 21:02:22.907424
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    import argparse
    import requests
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = False
    args.style = 'solarized'
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True

# Generated at 2022-06-17 21:02:47.673322
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

# Generated at 2022-06-17 21:02:55.360962
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    from httpie.output.streams import (
        BaseStream, PrettyStream,
    )
    from httpie.output.streams import (
        write_stream_with_colors_win_py3,
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        write_stream_with_colors_win_py3,
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:03:04.904024
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:03:14.626000
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-17 21:03:25.204083
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BaseStream
    import io
    import sys
    import unittest
    class TestStream(BaseStream):
        def __init__(self, msg, with_headers, with_body, **kwargs):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
            self.kwargs = kwargs
        def __iter__(self):
            yield b'hello'
            yield b'world'
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.outfile = io.StringIO()
            self.stream = TestStream(None, None, None)
        def test_write_stream(self):
            write_stream(self.stream, self.outfile, False)
            self

# Generated at 2022-06-17 21:03:32.608940
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import is_windows
    from httpie.cli import parser
    from httpie.output.streams import CHUNK_SIZE_BY_LINE, CHUNK_SIZE
    import os
    import sys
    import tempfile
    import requests
    import json
    import pytest

    args = parser.parse_args([])

# Generated at 2022-06-17 21:03:43.005577
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream

# Generated at 2022-06-17 21:03:49.747941
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream

    class DummyStream(BaseStream):
        def __iter__(self):
            yield b'\x1b[31mfoo\x1b[0m'
            yield b'bar'

    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=DummyStream(),
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == '\x1b[31mfoo\x1b[0mbar'

# Generated at 2022-06-17 21:03:57.626881
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    args = parser.parse_args([])
    env = Environment()
    requests_message = HTTPRequest(HTTPResponse())
    with_headers = True
    with_body = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream

# Generated at 2022-06-17 21:04:06.088512
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    from httpie.cli import parser
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueType
    from httpie.cli.argtypes import KeyValueType
    from httpie.cli.argtypes import KeyValueType
    from httpie.cli.argtypes import KeyValueType
    from httpie.cli.argtypes import KeyValueType
    from httpie.cli.argtypes import KeyValueType

# Generated at 2022-06-17 21:04:29.460821
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import BaseStream

    class MockStdout(object):
        def __init__(self):
            self.isatty = True
            self.encoding = 'utf-8'

        def write(self, data):
            pass

        def flush(self):
            pass

    class MockStderr(object):
        def __init__(self):
            self.isatty = True
            self.encoding = 'utf-8'

        def write(self, data):
            pass

# Generated at 2022-06-17 21:04:40.066372
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.output.streams import build_output_stream_for_message

# Generated at 2022-06-17 21:04:46.020754
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import ColorizedStream, ColorizedStreamChunk
    from httpie.output.streams import ColorizedStreamChunkType

    stream = ColorizedStream(
        msg=None,
        with_headers=True,
        with_body=True,
        env=None,
        conversion=None,
        formatting=None,
    )
    outfile = StringIO()
    flush = False
    write_stream_with_colors_win_py3(stream, outfile, flush)

    stream = ColorizedStream(
        msg=None,
        with_headers=True,
        with_body=True,
        env=None,
        conversion=None,
        formatting=None,
    )
    outfile

# Generated at 2022-06-17 21:04:54.767065
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from httpie.output.streams import BaseStream

    class TestStream(BaseStream):
        def __init__(self, *args, **kwargs):
            super(TestStream, self).__init__(*args, **kwargs)
            self.chunks = [b'foo', b'bar', b'baz']

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.outfile = io.StringIO()
            self.stream = TestStream()

        def test_write_stream(self):
            write_stream(self.stream, self.outfile, flush=False)

# Generated at 2022-06-17 21:05:01.672352
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import requests
    import io
    import sys
    import argparse
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import requests
    import io
    import sys
    import argparse
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import requests
    import io
    import sys
    import argparse
    import httpie.context
    import httpie.output.streams
    import httpie.output.processing
    import httpie.models
    import requests
    import io
    import sys
    import argparse

# Generated at 2022-06-17 21:05:12.766446
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:23.924976
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

# Generated at 2022-06-17 21:05:31.805926
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import write_stream_with_colors_win_py3
    from httpie.output.streams import write_stream
    from httpie.output.streams import build_output_stream_for_message
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import requests
    import argparse
    import sys


# Generated at 2022-06-17 21:05:41.089894
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import BaseStream
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie.context import Environment

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'utf-8'
    env.stdout_raw = False
    env.stdout = StringIO()
    env.stderr = StringIO()
    env.is_windows = True

    args = argparse.Names

# Generated at 2022-06-17 21:05:50.575325
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.formatters.colors import get_lexer
    from pygments.formatters import TerminalFormatter
    from httpie.output.formatters.utils import get_prettifier
    from httpie.cli import parser
    args = parser.parse_args([])
    env = Environment(vars={'TERM': 'xterm'})
    lexer = get_lexer(None)
    formatter = TerminalFormatter()
    prettifier = get_prettifier(lexer, formatter)