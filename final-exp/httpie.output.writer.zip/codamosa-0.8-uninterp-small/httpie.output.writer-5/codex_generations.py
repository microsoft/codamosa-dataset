

# Generated at 2022-06-25 19:00:04.903587
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:00:11.569713
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    # Default args.json
    test_msg_0 = module_0.HTTPResponse()
    # Default args.json
    test_msg_0.is_body_upload_chunk = False
    # Default args.stream
    # Default args.prettify
    test_args_0 = namespace_0
    test_with_headers = True
    test_with_body = True
    tuple_0 = build_output_stream_for_message(test_args_0, environment_0, test_msg_0, test_with_headers, test_with_body)

if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(level=logging.ERROR)
   

# Generated at 2022-06-25 19:00:14.065737
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(None, environment_0, namespace_0)


# Generated at 2022-06-25 19:00:19.514342
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:00:30.736498
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    def mock_get_stream_type_and_kwargs(env, args):
        return None
    mock_with_body = None
    mock_requests_message = mock.Mock()
    mock_with_headers = mock.Mock()
    mock_args = mock.Mock()
    mock_env = mock.Mock()
    with mock.patch('httpie.output.streams.get_stream_type_and_kwargs', new=mock_get_stream_type_and_kwargs):
        assert build_output_stream_for_message(mock_args, mock_env, mock_requests_message, mock_with_headers, mock_with_body) == None


# Generated at 2022-06-25 19:00:32.085955
# Unit test for function write_stream
def test_write_stream():
    # TODO: Implement unit test
    assert False


# Generated at 2022-06-25 19:00:38.938889
# Unit test for function write_message
def test_write_message():
    try:
        import requests as module_0
    except ImportError:
        import httpie.client as module_0
        import httpie.client as module_1
    environment_0 = module_0.Environment()
    namespace_0 = module_0.Namespace()
    request_0 = module_1.PreparedRequest()
    write_message(request_0, environment_0, namespace_0, False, False)

    environment_1 = module_0.Environment()
    namespace_1 = module_0.Namespace()
    request_1 = module_1.Response()
    write_message(request_1, environment_1, namespace_1, False, False)


if __name__ == '__main__':
    test_case_0()
    test_write_message()

# Generated at 2022-06-25 19:00:44.859552
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests as module_0
    import httpie.context as module_1
    import argparse as module_2
    namespace_0 = module_2.Namespace()
    environment_0 = module_1.Environment()
    httpresponse_0 = module_0.Response()
    iterable_0 = build_output_stream_for_message(namespace_0, environment_0, httpresponse_0, False, False)


# Generated at 2022-06-25 19:00:55.516513
# Unit test for function write_message
def test_write_message():

    import httpie.context as context
    import httpie.output.streams as streams
    import mock
    import os
    import pytest


    # Create a mock requests.PreparedRequest.
    fake_body = b'blah'
    mock_prepped_request = mock.Mock()
    mock_prepped_request.is_body_upload_chunk = False
    mock_prepped_request.headers = dict(
        a='a',
        b='b',
    )
    mock_prepped_request.body = fake_body

    # Create a mock requests.Response.
    fake_body = b'blah'
    mock_response = mock.Mock()
    mock_response.status_code = 200

# Generated at 2022-06-25 19:01:04.398008
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    # Test with a binary file
    # b'\x1b['
    binary_file = open('test_examples/binary_file.txt', 'rb')
    # b'\x1b['
    binary_file_read = binary_file.read()
    # b'\x1b['
    binary_file_read = binary_file_read.splitlines()
    base_stream = BaseStream()
    output = {'outfile': open('test_examples/binary_file.txt', 'wb')}
    write_stream_with_colors_win_py3(base_stream, **output)

    # Test with a binary file
    # b'\x1b['
    binary_file = open('test_examples/binary_file.txt', 'rb')
    # b'\x1b['


# Generated at 2022-06-25 19:01:21.483499
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Create a mock environment
    environment_0 = module_0.Environment()
    # Create a mock namespace
    namespace_0 = module_1.Namespace()

    # Assert that the function get_stream_type_and_kwargs returns the expected value.
    # The expected value is a tuple
    # The first element of the tuple is an object of type 'type'
    # The second element of the tuple is an object of type 'dict'
    assert type(get_stream_type_and_kwargs(environment_0, namespace_0)[0]) == type
    assert type(get_stream_type_and_kwargs(environment_0, namespace_0)[1]) == dict

import httpie.output.streams

# Generated at 2022-06-25 19:01:29.966443
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from requests import Request, Response
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    # unit test for class EncodedStream
    stream_0 = tuple_0[0](
        msg=HTTPResponse(Response()),
        with_headers=False,
        with_body=False,
        env=environment_0
    )
    # unit test for class RawStream

# Generated at 2022-06-25 19:01:34.480769
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(requests.PreparedRequest(requests.Request(url="https://httpbin.org/get").prepare()), environment_0, namespace_0)


# Generated at 2022-06-25 19:01:42.273963
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # fmt: off
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    class_0 = tuple_0[0]
    dictionary_0 = tuple_0[1]
    object_0 = class_0(**dictionary_0)
    # fmt: on
    write_stream_with_colors_win_py3(
        object_0,
        environment_0.stdout,
        namespace_0.stream,
    )


# Generated at 2022-06-25 19:01:51.935753
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    def function_0(arg_0):
        return arg_0.status_code
    requests.Response.status_code = property(function_0)
    class_0 = type(requests.Response())
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, class_0, None, None)
    assert not isinstance(tuple_0, str), 'We need a generator!'
    count = 0
    for element in tuple_0:
        assert isinstance(element, bytes)
        count += 1
        if count == 20:
            break


# Generated at 2022-06-25 19:01:54.848103
# Unit test for function write_message
def test_write_message():
    # Test for the following case:
    #
    #  write_message - with_headers=False, with_body=False
    pass

# Generated at 2022-06-25 19:01:58.690015
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    build_output_stream_for_message(requests_message, env, args, with_headers, with_body)


# Generated at 2022-06-25 19:02:05.409475
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == EncodedStream
    assert len(tuple_0[1]) == 1
    assert tuple_0[1]['env'] == environment_0
    environment_1 = module_0.Environment()
    namespace_1 = module_1.Namespace()
    namespace_1.stream = True
    tuple_1 = get_stream_type_and_kwargs(environment_1, namespace_1)
    assert tuple_1[0] == PrettyStream
    assert len(tuple_1[1]) == 2
    assert tuple_1[1]['env'] == environment_1
    assert tuple_1

# Generated at 2022-06-25 19:02:14.222669
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class DummyClass:
        def __init__(self, env, args):
            self.env = env
            self.args = args

    # Case 1
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0 == tuple_1
    # Case 3
    environment_1 = module_0.Environment()
    namespace_1 = module_1.Namespace()
    tuple_2 = get_stream_type_and_kwargs(environment_1, namespace_1)

# Generated at 2022-06-25 19:02:22.958264
# Unit test for function write_stream
def test_write_stream():
    # Mock 1
    # Mock 2
    # Mock 3
    # Mock 4

    # Tests for all paths
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch
    # main branch

    # try main path
    env = Environment()
    outfile = sys.stdout
    stream = EncodedStream(env=env)

    try:
        write_stream(stream, outfile, flush=False)
    except IOError:
        raise


# Generated at 2022-06-25 19:02:46.142872
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    iterator_0 = build_output_stream_for_message(namespace_0, environment_0, response_0, True, True)
    iterator_0 = iter(iterator_0)
    assert type(next(iterator_0)) == bytes, "The type of the value returned by next() isn't bytes"
    assert type(next(iterator_0)) == bytes, "The type of the value returned by next() isn't bytes"
    assert type(next(iterator_0)) == bytes, "The type of the value returned by next() isn't bytes"
    assert type(next(iterator_0)) == bytes, "The type of the value returned by next() isn't bytes"

# Generated at 2022-06-25 19:02:53.724260
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert len(tuple_0) == 2
    assert type(tuple_0[0]) == type
    assert type(tuple_0[1]) == dict
    assert tuple_0[0] is module_0.BaseStream
    assert len(tuple_0[1]) == 1
    assert 'env' in tuple_0[1]



# Generated at 2022-06-25 19:02:54.684802
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True



# Generated at 2022-06-25 19:02:59.080600
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    for _ in (1, 100):
        with io.StringIO() as io_StringIO_0, io.BytesIO() as io_BytesIO_0:
            write_stream_with_colors_win_py3(io_StringIO_0, io_BytesIO_0, False)
            write_stream_with_colors_win_py3(io_StringIO_0, io_BytesIO_0, True)

# Generated at 2022-06-25 19:03:04.823347
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    # call function
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    # test if the return value of function is equal to expected value. 
    assert False, 'fix the assert statement' 


# Generated at 2022-06-25 19:03:06.511740
# Unit test for function write_stream
def test_write_stream():
    var_0: IO = sys.stdout
    write_stream(var_0, var_0, False)


# Generated at 2022-06-25 19:03:17.338872
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()

    # Set output stream parameters
    with_body = True
    with_headers = True

    # Import prepared request class for request message
    import requests
    PreparedRequest = requests.PreparedRequest

    # Create prepared request object
    url = 'http://httpbin.org/anything'
    method = 'GET'
    headers = {'User-Agent': 'Python-urllib/2.7'}
    body = 'abc'
    request = PreparedRequest()
    request.prepare(method=method, url=url, headers=headers, body=body)


    # Generate output stream

# Generated at 2022-06-25 19:03:27.109840
# Unit test for function write_message
def test_write_message():
    import io
    import httpie.compat
    import httpie.context
    import httpie.models
    import httpie.output.streams
    import requests
    environment_0 = httpie.context.Environment()
    environment_0.stdout_isatty = True
    namespace_0 = mock.Mock()
    namespace_0.prettify = {}
    namespace_0.style = None
    namespace_0.stream = False
    namespace_0.json = False
    namespace_0.debug = False
    namespace_0.traceback = False
    namespace_0.format_options = {}
    request_0 = requests.PreparedRequest()
    request_0.method = 'GET'
    request_0.url = 'http://localhost:8080/'
    request_0.body = b''
    request_

# Generated at 2022-06-25 19:03:32.399375
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_0 = requests.PreparedRequest()
    list_0 = build_output_stream_for_message(namespace_0, environment_0, prepared_0, False, False)


# Generated at 2022-06-25 19:03:38.830618
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    assert_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert_2, assert_3 = assert_1
    assert_4 = build_output_stream_for_message(environment_0, namespace_0, 
            assert_2, assert_3, True, True)
    assert_5 = list(assert_4)
    tuple_0 = (assert_5, assert_1)


# Generated at 2022-06-25 19:04:15.614177
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Mock arguments, disable traceback
    import sys
    sys.tracebacklimit = 0

    namespace_0 = module_1.Namespace()
    namespace_0.prettify = "all"
    namespace_0.stream = True
    namespace_0.json = True
    namespace_0.debug = False
    namespace_0.traceback = False
    namespace_0.style = None
    namespace_0.format_options = ()
    environment_0 = module_0.Environment()
    environment_0.stdout_isatty = True
    requests_message_0 = module_0.HTTPRequest()


    build_output_stream_for_message(namespace_0, environment_0, requests_message_0, True, True)
    assert True


# Generated at 2022-06-25 19:04:27.014271
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = ['colors']
    namespace_0.stream = False
    namespace_0.debug = False
    namespace_0.traceback = False
    string_0 = 'y'
    boolean_0 = False
    boolean_1 = False
    requests_message = build_output_stream_for_message(namespace_0, environment_0, string_0, boolean_0, boolean_1)
    try:
        int(build_output_stream_for_message.__code__)
        assert True
    except Exception:
        assert False
    try:
        int(build_output_stream_for_message.__doc__)
        assert True
    except Exception:
        assert False

# Generated at 2022-06-25 19:04:31.031087
# Unit test for function write_stream
def test_write_stream():
    outfile_0 = io.StringIO()
    stream_0 = EncodedStream(env=Environment())
    write_stream(stream_0, outfile_0, True)


# Generated at 2022-06-25 19:04:36.767129
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = (2, 3)
    namespace_0.style = 'GALAXY'
    namespace_0.json = 'ELEPHANT'
    write_message(['PreparedRequest', 'Response'], environment_0, namespace_0)
    

# Generated at 2022-06-25 19:04:46.590196
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from urllib.request import Request
    from httpie.core import main
    from httpie.input import PYTHON3
    from httpie import __main__ as main_module
    from httpie.models import Environment, HTTPRequest
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import (
        stream_raw_chunk_size_by_line, stream_raw_chunk_size_default
    )
    import httpie.output.streams as module_0
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-25 19:04:53.174588
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Test cases
    argparse_namespace = argparse.Namespace()
    argparse_namespace.debug = False
    argparse_namespace.traceback = False
    argparse_namespace.stream = False
    argparse_namespace.prettify = 'colors'
    argparse_namespace.style = 'default'
    requests_response = requests.Response()
    requests_response.encoding = 'utf-8'
    requests_response.request.body = 'httpbin.org'
    requests_response.request.headers['Content-Type'] = 'application/json'
    requests_response.request.headers['Content-Length'] = '10'
    requests_response.request.method = 'GET'
    requests_response.request.url = 'www.google.com'

# Generated at 2022-06-25 19:04:54.020024
# Unit test for function write_message
def test_write_message():
    # TODO: Implement the unit test
    pass

# Generated at 2022-06-25 19:05:04.652502
# Unit test for function write_message
def test_write_message():
    with pytest.raises(AttributeError):
        class Exception_0(Exception):
            pass
        exception_0 = Exception_0()
        __test_write_message_body_0(exception_0, Exception_0)

    with pytest.raises(TypeError):
        namespace_0 = module_1.Namespace()
        prepared_request_0 = requests.PreparedRequest()
        environment_0 = module_0.Environment()
        __test_write_message_body_0(namespace_0, environment_0, prepared_request_0, True, True)

    with pytest.raises(TypeError):
        namespace_0 = module_1.Namespace()
        environment_0 = module_0.Environment()
        response_0 = requests.Response()

# Generated at 2022-06-25 19:05:08.736620
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    file_object_0 = open("/dev/null", "w")
    boolean_0 = True
    write_stream(BufferedPrettyStream, file_object_0, boolean_0)


# Generated at 2022-06-25 19:05:14.049120
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert(tuple_0[0] == module_0.EncodedStream)
    assert(tuple_0[1]['env'] == module_0.Environment())

import httpie.models as module_0
import requests as module_1


# Generated at 2022-06-25 19:06:11.225572
# Unit test for function write_stream
def test_write_stream():
    try:
        # Writing bytes so we use the buffer interface (Python 3).
        buf = outfile.buffer
    except AttributeError:
        buf = outfile

    for chunk in stream:
        buf.write(chunk)
        if flush:
            outfile.flush()


# Generated at 2022-06-25 19:06:15.272046
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import httpie.context as module_0
    import argparse as module_1
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] is module_0.EncodedStream


# Generated at 2022-06-25 19:06:20.220005
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.context import Environment, EnvironmentData
    from httpie.output.streams import BaseStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, environment_0, 0, 0)


# Generated at 2022-06-25 19:06:29.287780
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    object_0 = object()
    object_0 = object()
    object_1 = object()
    object_1 = object()
    object_2 = object()
    object_2 = object()
    object_2 = object()
    object_2 = object()
    object_2 = object()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, object_0, True, False)


# Generated at 2022-06-25 19:06:33.246672
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(None, environment_0, namespace_0, with_body=False, with_headers=True)
    write_message(None, environment_0, namespace_0, with_body=True, with_headers=False)


# Generated at 2022-06-25 19:06:37.742576
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = build_output_stream_for_message(namespace_0, environment_0, tuple_0, True, True)



# Generated at 2022-06-25 19:06:42.113756
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(tuple_0, str(0), 0) == None

import httpie.context as module_0
import requests as module_1


# Generated at 2022-06-25 19:06:49.892215
# Unit test for function write_stream
def test_write_stream():
    import sys
    from httpie.output.streams import BufferedPrettyStream
    namespace_0 = argparse.Namespace()
    environment_0 = module_0.Environment()
    message_class_0 = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }[type(requests_message)]
    stream_class_0, stream_kwargs_0 = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    yield from stream_class_0(
        msg=message_class(requests_message),
        with_headers=with_headers,
        with_body=with_body,
        **stream_kwargs_0,
    )

# Generated at 2022-06-25 19:07:00.032932
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    name = 'httpie'
    version = '1.0.2'
    user_agent = '{0}/{1}'.format(name, version)
    environment_0 = module_0.Environment(httpie_version=version, user_agent=user_agent)
    output_options_0 = module_1.Namespace(prettify=('all', ), style='colors', stream=False)
    tuple_0 = get_stream_type_and_kwargs(environment_0, output_options_0)
    assert tuple_0 == (BufferedPrettyStream, {'env': environment_0, 'conversion': Conversion(), 'formatting': Formatting(env=environment_0, groups=('all', ), color_scheme='colors', explicit_json=False, format_options=())})

import requests as module_4

# Generated at 2022-06-25 19:07:04.345428
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0].__name__ == "EncodedStream"
    assert tuple_0[1] == {
        'env': environment_0
    }

# Generated at 2022-06-25 19:08:06.590240
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert_equal(tuple_0[0], EncodedStream)
    assert_equal(tuple_0[1]['env'], environment_0)
    assert_equal(len(tuple_0[1]), 1)

if __name__ == '__main__':
    run_local_tests()

# Generated at 2022-06-25 19:08:16.730596
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from io import TextIOWrapper
    import sys
    import types
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from httpie.output.streams import BaseStream

    class Stream(BaseStream):
        def __init__(self, **kwargs):
            self.bytes_list = []
            self.text_list = []
            self.dump_list = []

        def __iter__(self):
            return self

        def __next__(self):
            return self.next()

        def dump(self, chunk, encoding):
            self.dump_list.append((chunk, encoding))


# Generated at 2022-06-25 19:08:19.704876
# Unit test for function write_stream
def test_write_stream():
    test_stream_0 = module_0.BufferedPrettyStream()
    test_file_0 = open("test.json", "w")
    test_boolean_0 = True
    write_stream(test_stream_0, test_file_0, test_boolean_0)

# Generated at 2022-06-25 19:08:24.351579
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = True

# Generated at 2022-06-25 19:08:30.862679
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()

    from httpie.models import HTTPRequest, HTTPResponse
    from typing import Generator

    _0 = False
    _1 = False
    message_3 = HTTPRequest(None)
    stream_4 = message_3.stream()
    assert isinstance(stream_4, Generator)
    _2, _3 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert issubclass(_2, BaseStream)


# Generated at 2022-06-25 19:08:39.469909
# Unit test for function write_message
def test_write_message():
    import tempfile
    import json
    import requests
    stdout_isatty = False
    stderr_isatty = True

    def _create_tempfile():
        return tempfile.NamedTemporaryFile(mode='w', encoding='utf8',
                                           delete=False)

    with _create_tempfile() as outfile, _create_tempfile() as errfile:
        env = Environment(
            config_dir=None,
            stdin=None,
            stdout=outfile,
            stderr=errfile,
            is_windows=False,
            stdout_isatty=stdout_isatty,
            stderr_isatty=stderr_isatty,
            stdin_isatty=False,
        )

        outfile.flush()


# Generated at 2022-06-25 19:08:42.389271
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    rawstr = b''
    color = b'\x1b['
    outfile = None
    flush = True
    try:
        write_stream_with_colors_win_py3(rawstr, outfile, flush)
    except Exception:
        pass

# Generated at 2022-06-25 19:08:50.352154
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.streams
    import httpie.output.processing
    import httpie.output.processing
    import httpie.output.processing
    import httpie.models
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io

# Generated at 2022-06-25 19:08:54.000446
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    assert (build_output_stream_for_message(namespace_0, environment_0, requests.Response(), False, False) == None)
    assert (build_output_stream_for_message(namespace_0, environment_0, requests.PreparedRequest(), True, True) == None)


# Generated at 2022-06-25 19:08:56.036649
# Unit test for function write_stream
def test_write_stream():
    # Setup args
    
    # Setup environment
    
    # Setup context
    
    # Teardown context
    
    pass
