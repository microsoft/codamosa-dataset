

# Generated at 2022-06-25 19:00:05.085730
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.client as module_0
    
    requests_PreparedRequest = module_0.PreparedRequest
    requests_Response = module_0.Response

    test_case_0(requests_PreparedRequest, requests_Response)


# Generated at 2022-06-25 19:00:15.063272
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import PrettyStream, RawStream, EncodedStream
    import requests
    import argparse

    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    requests_prepared_request_0 = requests.PreparedRequest()
    namespace_0.stream = True
    namespace_0.prettify = 'colors'
    namespace_0.style = 'ncolors'
    namespace_0.json = False
    namespace_0.format_options = tuple()

    assert write_message(requests_prepared_request_0, environment_0, namespace_0, True, True) == None



# Generated at 2022-06-25 19:00:18.320429
# Unit test for function write_stream
def test_write_stream():
    requests_message = ''
    env = ''
    args = ''
    with_headers = False
    with_body = False

    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-25 19:00:24.766497
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Setup
    text_buffer_0 = io.StringIO()
    # Assertion
    with pytest.raises(NotImplementedError):
        write_stream_with_colors_win_py3(text_buffer_0, text_buffer_0, True)
    # Teardown
    text_buffer_0.close()


# Generated at 2022-06-25 19:00:30.781306
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(module_0.Environment, module_1.Namespace) == (module_0.EncodedStream, module_0.Environment)
    assert get_stream_type_and_kwargs(module_0.Environment, module_1.Namespace) == (module_0.EncodedStream, module_0.Environment)


# Generated at 2022-06-25 19:00:39.923574
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    import io as module_0
    import pytest as module_1

    # Testing fixture 'write_stream'
    @module_1.fixture
    def fixture_0():
        class Fixture0:
            pass
        fixture_1 = Fixture0()
        class Fixture2:
            pass
        fixture_1.stream = Fixture2()
        fixture_1.outfile = module_0.StringIO()
        fixture_1.flush = True
        return fixture_1

    # Testing fixture 'write_stream_bytes'
    @module_1.fixture
    def fixture_3():
        class Fixture3:
            pass
        fixture_4 = Fixture3()
        class Fixture5:
            pass
        fixture_4.stream = Fixture5()
        fixture_4.outfile = module_0.String

# Generated at 2022-06-25 19:00:46.265438
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = "form"
    namespace_0.stream = False
    http_request_0 = HTTPRequest()
    stream_class_0, stream_kwargs_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_0(None, False, False, **stream_kwargs_0)


# Generated at 2022-06-25 19:00:47.944040
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    args_0 = module_1.Namespace()
    env_0 = module_0.Environment()


# Generated at 2022-06-25 19:00:56.604731
# Unit test for function write_message
def test_write_message():
    try:
        write_message(requests_message=None, env=None, args=args, with_headers=with_headers, with_body=with_body)
        # Verify that the message "Invalid argument" is present in the output.
        assert "Invalid argument" in str(e.value)
    except IOError as e:
        show_traceback = args.debug or args.traceback
        if not show_traceback and e.errno == errno.EPIPE:
            # Ignore broken pipes unless --traceback.
            env.stderr.write('\n')
        else:
            raise


# Generated at 2022-06-25 19:01:02.256060
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_0 = tuple_0[0]
    stream_kwargs_0 = tuple_0[1]
    stream_0 = stream_class_0(**stream_kwargs_0)
    write_stream(stream_0, environment_0.stdout, False)

# Generated at 2022-06-25 19:01:17.088906
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    tuple_0 = module_0.Tuple()
    tuple_0[0] = module_0.PreparedRequest()
    tuple_0[1] = True
    tuple_0[2] = True
    tuple_1 = tuple_0
    build_output_stream_for_message(namespace_0, environment_0, tuple_1, False, True)


# Generated at 2022-06-25 19:01:24.357169
# Unit test for function write_stream
def test_write_stream():
    from StringIO import StringIO
    from httpie.output.streams import (
        BufferedPrettyStream, Conversion, EncodedStream, Formatting,
        PrettyStream, RawStream,
    )
    from httpie.output.streams import chunk_size
    from httpie.output.streams import get_message_bytes
    from httpie.client import session
    from httpie.context import Environment
    from httpie.models import (
        ContentType,
        HTTPRequest,
        HTTPResponse
    )
    from httpie import ExitStatus
    from httpie.input import Body, Params, auth
    from httpie.plugins import AuthPlugin, TransportPlugin, plugin_manager
    from httpie.output.streams import WriteStream
    import sys
    class o:
        pass
    o.debug = False
    o.trace

# Generated at 2022-06-25 19:01:29.859771
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = tuple_0[0](msg=None,with_headers=True,with_body=True)
    try:
        write_stream_with_colors_win_py3(stream=tuple_1, outfile=None, flush=True)
    except IOError:
        pass


# Generated at 2022-06-25 19:01:37.720945
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    test_env = Environment()
    test_args = argparse.Namespace()
    test_request = HTTPRequest(method='GET', url='http://www.test.com/')

    output_stream = build_output_stream_for_message(test_args, test_env, test_request, True, True)

    assert 'GET / HTTP/1.1' in list(output_stream)[0].decode('ascii')
    assert MESSAGE_SEPARATOR in list(output_stream)[0].decode('ascii')



# Generated at 2022-06-25 19:01:41.088391
# Unit test for function write_stream
def test_write_stream():
    
    assert write_stream(EncodedStream(), sys.__stdout__, True)
    assert write_stream(BufferedPrettyStream(), sys.__stdout__, True)
    assert write_stream(PrettyStream(), sys.__stdout__, True)
    assert write_stream(RawStream(), sys.__stdout__, True)


# Generated at 2022-06-25 19:01:48.641269
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    dummy_stream = ""
    dummy_outfile = ""
    dummy_flush = 0
    try:
        write_stream_with_colors_win_py3(dummy_stream, dummy_outfile, dummy_flush)
    except IOError as e:
        assert(e.errno == 0)
    else:
        assert(False)


# Generated at 2022-06-25 19:01:51.822565
# Unit test for function write_stream
def test_write_stream():
    in_0 = IO()
    in_1 = IO()
    in_2 = False
    try:
        write_stream(in_0, in_1, in_2)
    except IOError as exception_0:
        in_0 = exception_0


# Generated at 2022-06-25 19:02:01.719940
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Test Cases

    # Arrage
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class = tuple_0[0]
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = []
    namespace_0.style = 'paraiso-dark'
    namespace_0.json = False
    namespace_0.format_options = []
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class = tuple_1[0]
    namespace_2 = module_1.Namespace()
    namespace_2.prettify = []

# Generated at 2022-06-25 19:02:04.496490
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert callable(get_stream_type_and_kwargs)

import argparse as module_0


# Generated at 2022-06-25 19:02:12.015921
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from unittest.mock import create_autospec, patch
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    # Variable setup

# Generated at 2022-06-25 19:02:23.077556
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    print("Test case for write_stream_with_colors_win_py3")
    i_o_0 = module_0.IO()
    bool_0 = False
    var_0 = write_stream_with_colors_win_py3(i_o_0, i_o_0, bool_0)


# Generated at 2022-06-25 19:02:34.786337
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    import argparse

    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.stream = True
    args.prettify = ['colors', 'format', 'headers']
    args.style = 'solarized'
    args.json = False

    assert get_stream_type_and_kwargs(env, args)[0] == PrettyStream

    env = Environment()
    env.stdout_isatty = False
    args = argparse.Namespace()
    args.stream = False
    args.prettify = None
    assert get_stream_type_and_kwargs(env, args)[0] == EncodedStream

    env = Environment()
    env.stdout_isatty = False
    args = argparse

# Generated at 2022-06-25 19:02:38.093800
# Unit test for function write_stream
def test_write_stream():
    i_o_0 = module_0.IO()
    bool_0 = False
    var_1 = write_stream(i_o_0, i_o_0, bool_0)


# Generated at 2022-06-25 19:02:39.189159
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    print(test_case_0())


# Generated at 2022-06-25 19:02:43.308729
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = 'env'
    args = 'args'
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )

    assert stream_class == get_stream_type_and_kwargs(
        env=env,
        args=args,
    )[0]
    assert stream_kwargs == get_stream_type_and_kwargs(
        env=env,
        args=args,
    )[1]


# Generated at 2022-06-25 19:02:44.486668
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert func_name == "build_output_stream_for_message"



# Generated at 2022-06-25 19:02:46.593857
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    i_o_0 = module_0.IO()
    bool_0 = False
    class_0 = BaseStream
    var_1 = class_0(i_o_0, i_o_0, bool_0)
    var_0 = write_stream_with_colors_win_py3(var_1, i_o_0, bool_0)

# Generated at 2022-06-25 19:02:50.009501
# Unit test for function write_message
def test_write_message():
    i_o_0 = module_0.IO()
    bool_0 = False
    var_1 = write_message(i_o_0, i_o_0, i_o_0, bool_0, bool_0)



# Generated at 2022-06-25 19:02:59.255134
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class argparse(object):

        def __init__(self):
            self.prettify = None
            self.style = None
            self.stream = None
            self.json = None
            self.debug = None
            self.traceback = None
            self.stream = None
            self.format_options = None
            self.prettify = None

    class requests(object):

        class PreparedRequest(object):

            def __init__(self):
                self.body = None

        def __init__(self):
            self.PreparedRequest = self.PreparedRequest()
            self.Response = self.Response()

        class Response(object):

            def __init__(self):
                self.headers = None
                self.status_code = int()
                self.reason = None
                self.url = None


# Generated at 2022-06-25 19:03:06.376359
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment()
    bool_0 = True
    bool_1 = True
    bool_2 = True
    namespace_0 = argparse.Namespace(prettify=bool_0, stream=bool_1, style=bool_2)
    tuple_0 = get_stream_type_and_kwargs(env_0, namespace_0)
    str_0 = 'BufferedPrettyStream'
    assert str(tuple_0[0]) == str_0

import typing as module_0


# Generated at 2022-06-25 19:03:31.076487
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class UnitTestEnvironment:
        def __init__(self, is_stdout_isatty):
            self.is_stdout_isatty = is_stdout_isatty
            self.stderr = module_0.TextIO()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=UnitTestEnvironment(is_stdout_isatty=False),
        args=argparse.Namespace(prettify=[''], stream=False, style=''))
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': 1}


# Generated at 2022-06-25 19:03:34.958581
# Unit test for function write_stream
def test_write_stream():
    i_o_0 = module_0.IO()
    bool_0 = False
    var_0 = write_stream(i_o_0, i_o_0, bool_0)
    assert type(var_0) == type(None)


# Generated at 2022-06-25 19:03:42.717629
# Unit test for function write_message

# Generated at 2022-06-25 19:03:53.730764
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class Class_0(object):
        def __init__(self):
            self.args = argparse.Namespace()
            self.args.style = 'default'
            self.args.json = False
            self.args.prettify = 'all'
            self.args.stream = True
            self.args.format_options = {}
            self.env = Environment(stdin=module_0.IO(encoding='utf-8'),
                                   stdin_isatty=False,
                                   stdout=module_0.IO(),
                                   stdout_isatty=True,
                                   stderr=module_0.IO())
            self.requests_message = requests.Response()
            self.with_body = True
            self.with_headers = True
    class_0 = Class_0()
    var

# Generated at 2022-06-25 19:04:02.503004
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import output
    import requests
    import argparse
    import context
    import models
    import prettifiers
    i_o_0 = output.BaseStream()
    bool_0 = False
    bool_1 = False
    dict_0 = dict()
    requests_message = requests.PreparedRequest(dict_0)
    env = context.Environment()
    args = argparse.Namespace()
    args.prettify = {"form"}
    args.style = 'paraiso-dark.py'
    args.json = prettifiers.ExplicitJSONPrettifier(args)
    args.format_options = ""
    formatting = output.formatting.Formatting(env, args.prettify, args.style, args.json, args.format_options)
    args.stream = bool_1
    args.compress = bool_

# Generated at 2022-06-25 19:04:14.239438
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-25 19:04:17.953618
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # Obtain an input object of your choice, e.g.
    request = HTTPRequest()
    args = argparse.Namespace()
    env = Environment()
    stream = build_output_stream_for_message(args, env, request, True, True)
    assert(True)

# Generated at 2022-06-25 19:04:28.564170
# Unit test for function write_message
def test_write_message():
    class MockPreparedRequest:

        def __init__(self):
            self.url = 'url'
            self.headers = {}
            self.method = 'method'
            self.body = 'body'

    class MockResponse:

        def __init__(self):
            self.url = 'url'
            self.headers = {}
            self.status_code = 200
            self.encoding = 'encoding'
            self.reason = ''

        def iter_content(self, *args, **kwargs):
            yield b'content'

    class MockNamespace:

        def __init__(self):
            self.prettify = ['prettify']
            self.style = 'style'
            self.format_options = {}
            self.stream = False
            self.json = False

# Generated at 2022-06-25 19:04:39.161695
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class mock_env:
        stdout_isatty = True
        stdout = module_0.TextIO()
        stderr_isatty = True

    class mock_args:
        stream = True
        prettify = ''
        style = ''
        json = True
        format_options = {"nested_option": True}
        debug = False
        traceback = False
        debug_traceback = False


    var_0 = get_stream_type_and_kwargs(mock_env(), mock_args())
    assert var_0 is not None
    assert isinstance(var_0, tuple)
    assert len(var_0) == 2
    assert isinstance(var_0[0], type)
    assert isinstance(var_0[1], dict)


# Generated at 2022-06-25 19:04:48.229561
# Unit test for function write_stream
def test_write_stream():
    i_o_0 = module_0.IO()
    bool_0 = False
    var_0 = write_stream(i_o_0, i_o_0, bool_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 19:05:11.223584
# Unit test for function write_message
def test_write_message():
    import argparse

    # Setup args for the test
    args = argparse.Namespace()
    args.auth_password = None
    args.auth_username = None
    args.download_rate_limit = None
    args.download_resume_from = None
    args.download_resume_from_previous = None
    args.download_start_at = None
    args.download_timeout = None
    args.form = None
    args.headers = None
    args.ignore_stdin = False
    args.output_dir = None
    args.output_file = None
    args.pretty = False
    args.style = None
    args.style_sheet = None
    args.style_sheet_path = None
    # Setup env for the test

# Generated at 2022-06-25 19:05:13.011237
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test with all non-string type
    # AssertionError: Expected 0 to be boolean
    test_case_0()


# Generated at 2022-06-25 19:05:16.223137
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class_type = module_0.Type[module_0.BaseStream]
    dict_0 = {}
    arg_0 = module_0.Environment()
    class_type, dict_0 = get_stream_type_and_kwargs(arg_0, dict_0)


# Generated at 2022-06-25 19:05:16.859210
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True

# Generated at 2022-06-25 19:05:23.372563
# Unit test for function write_message
def test_write_message():
    # Initialization of input variables
    i_o_0 = module_0.IO()
    bool_0 = False
    i_o_1 = module_0.IO()
    bool_1 = False
    var_0 = write_message(i_o_0, i_o_1, bool_0, bool_1)
    assert var_0 is None


# Generated at 2022-06-25 19:05:32.589913
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-25 19:05:35.423021
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    i_o_0 = module_0.IO()
    bool_0 = False
    var_0 = write_stream(i_o_0, i_o_0, bool_0)

# Generated at 2022-06-25 19:05:36.267133
# Unit test for function write_message
def test_write_message():
    assert True



# Generated at 2022-06-25 19:05:45.456786
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class TestClass:
        def __init__(self):
            self.encoding = None
            self.write_count = 0
            self.write_buffer_count = 0
    
    import io
    import sys
    
    i_o_0 = TestClass()
    i_o_0.encoding = 'utf_8'
    bool_0 = True
    sys.stdout = io.StringIO()
    print(write_stream_with_colors_win_py3(i_o_0, i_o_0, bool_0))
    print(i_o_0.write_count)
    print(i_o_0.write_buffer_count)
    
    print('Tests finished!')
test_write_stream_with_colors_win_py3()

# Generated at 2022-06-25 19:05:49.135614
# Unit test for function write_message
def test_write_message():
    i_o_0 = module_0.IO()
    bool_0 = False
    bool_1 = False
    t_0 = requests.Response()
    var_0 = write_message(t_0, i_o_0, i_o_0, bool_0, bool_1)


# Generated at 2022-06-25 19:06:04.662177
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:06:13.913599
# Unit test for function write_message
def test_write_message():
    i_o_0 = module_0.IO()
    i_o_1 = module_0.IO()
    bool_0 = False

# Generated at 2022-06-25 19:06:19.881961
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class argparse_Namespace:
        def __init__(self):
            self.prettify = []
            self.stream = False
            self.json = False
            self.format_options = ""
            self.style = ""

    class Environment:
        def __init__(self):
            self.stdout_isatty = False

    args = argparse_Namespace()
    env = Environment()
    (var_1, var_2) = get_stream_type_and_kwargs(env, args)
    assert var_1 == RawStream
    assert var_1 == RawStream
    assert var_2 == {'chunk_size': '5000'}
    assert var_2 == {'chunk_size': '5000'}

from unittest import TestCase

# Generated at 2022-06-25 19:06:23.615576
# Unit test for function write_stream
def test_write_stream():
    i_0 = module_0.IO()
    i_1 = module_0.IO()
    b_0 = False
    var_0 = write_stream(i_0, i_1, b_0)
    if test_write_stream.var_0 == var_0:
        pass


# Generated at 2022-06-25 19:06:33.128708
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # Test #1
    args = argparse.Namespace(auth=None, auth_type='basic', body=None, body_format='', ignore_stdin=False, json=False, output_dir='', output_file='', output_options=['session_cookies', 'history', 'form'], output_to_dir=False, output_to_file=False, pretty=None, print_body=False, print_headers=False, print_status=False, timeout=None, traceback=False, verbose=0, verify=True, verify_ssl=True)

# Generated at 2022-06-25 19:06:34.700755
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:06:38.421476
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    str_0 = "print(%s)"
    i_o_0 = module_0.IO()
    bool_0 = False
    var_0 = write_stream_with_colors_win_py3(str_0, i_o_0, bool_0)
    print(var_0)


# Generated at 2022-06-25 19:06:42.532229
# Unit test for function write_stream
def test_write_stream():
    i_o_0 = module_0.IO()
    bool_0 = False
    var_0 = write_stream(i_o_0, i_o_0, bool_0)


import unittest

# Generated at 2022-06-25 19:06:44.600670
# Unit test for function write_message
def test_write_message():
    int_0 = 0
    list_0 = []
    assert test_case_0() == None
    # Empty assert to make this test case run
    assert True

# Generated at 2022-06-25 19:06:47.749179
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    i_o_0 = module_0.IO(encoding='\N{VULGAR FRACTION ONE HALF}')
    str_0 = ''
    str_1 = write_stream_with_colors_win_py3(i_o_0, i_o_0, str_0)


# Generated at 2022-06-25 19:07:06.034783
# Unit test for function write_stream
def test_write_stream():
    i_o_0 = module_0.IO()
    bool_0 = True
    var_0 = write_stream(i_o_0, i_o_0, bool_0)


# Generated at 2022-06-25 19:07:09.733088
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Tests the following functions:
    #   - output.streams.write_stream_with_colors_win_py3
    test_write_stream_with_colors_win_py3_0()

# Tests for errors

# Generated at 2022-06-25 19:07:19.586072
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import itertools
    import textwrap
    class IO(io.BytesIO):
        def __init__(self, text):
            super().__init__()
            self.write(text.encode('utf-8'))
            self.seek(0)
    class TextIO(io.StringIO):
        def __init__(self, text):
            super().__init__()
            self.write(text)
            self.seek(0)
        def buffer(self):
            return self
    class TestCase:
        def __init__(self, color_chunks):
            self.color_chunks = color_chunks
            self.color_chunk = next(self.color_chunks)
            self.other_chunk = next(self.color_chunks)

# Generated at 2022-06-25 19:07:31.440492
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import \
        BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    from httpie.parser import ArgParser
    from httpie.config import Config, Preferences
    from httpie.context import Environment
    
    class CustomRawStream(RawStream):
    	pass
    
    class CustomEncodedStream(EncodedStream):
    	pass
    
    class CustomPrettyStream(PrettyStream):
    	pass
    
    class CustomBufferedPrettyStream(BufferedPrettyStream):
    	pass
    
    class CustomArgParser(ArgParser):
    	DATA_OPTIONS = [arg.name for arg in ArgParser.DATA_OPTIONS] + ['--stream']
    	
    	class Raw(ArgParser.Raw):
    		name = '--raw-stream'
    	


# Generated at 2022-06-25 19:07:34.533372
# Unit test for function write_stream
def test_write_stream():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        # Fixture
        env='',
        args='',
    )
    test_case_0()

# Generated at 2022-06-25 19:07:45.668418
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Check if the function raises a TypeError or not
    if ("write_stream_with_colors_win_py3" not in globals()):
        print("[FAIL] 'write_stream_with_colors_win_py3' is not defined")
        return
    
    import io
    
    # Initialize arguments

# Generated at 2022-06-25 19:07:53.529944
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie import ExitStatus
    from httpie.core import main
    from tests import http

    args = main.parser.parse_args(['--json'])
    env = main.Environment(stdin=None,
                           stdout=None,
                           stderr=None,
                           colors=256,
                           is_windows=False,
                           stdout_isatty=True)

# Generated at 2022-06-25 19:08:03.680936
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Clean up resources used by test
    import os
    try:
        os.remove('out.txt')
    except:
        pass
    try:
        os.remove('out2.txt')
    except:
        pass

    # Test the body
    from io import StringIO
    import sys
    import builtins
    from httpie.context import Environment
    from httpie.output.streams import BufferedPrettyStream, RawStream, BaseStream, PrettyStream, EncodedStream

    class MockStream(BaseStream):
        def __init__(self, msg, with_headers=False, with_body=False):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body

        def __iter__(self):
            if self.with_headers:
                yield self.msg

# Generated at 2022-06-25 19:08:14.358188
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import random
    import requests
    http_request = requests.PreparedRequest()
    http_response = requests.Response()
    message_class_dict = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }

    # Case 0
    env_0 = Environment()
    arg_namespace = argparse.Namespace()
    with_headers = False
    with_body = False
    random_0 = random.randint(0, 1)
    requests_message = http_request if (random_0==0) else http_response
    msg_class = message_class_dict[type(requests_message)]
    msg_inst = msg_class(requests_message)

# Generated at 2022-06-25 19:08:15.548004
# Unit test for function write_stream
def test_write_stream():
    write_stream(module_0.IO(), module_0.IO(), False)

# Generated at 2022-06-25 19:08:41.995082
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Setup test case(s)
    argparse.Namespace = argparse.Namespace()
    argparse.Namespace.with_body = True
    argparse.Namespace.with_headers = True
    argparse.Namespace.stream = True
    httpie.output.streams.BaseStream = BaseStream
    httpie.models.HTTPRequest = HTTPRequest
    httpie.models.HTTPResponse = HTTPResponse
    httpie.output.streams.EncodedStream = EncodedStream
    httpie.output.streams.PrettyStream = PrettyStream
    httpie.output.streams.BufferedPrettyStream = BufferedPrettyStream
    httpie.output.streams.RawStream = RawStream
    httpie.context.Environment = Environment
    httpie.context.Environment.is_windows = False

# Generated at 2022-06-25 19:08:44.194378
# Unit test for function write_message
def test_write_message():

    # Assert if function returns None
    assert write_message(i_o_0, i_o_0, i_o_0, False, False) is None, "Function is expected to return None"


# Generated at 2022-06-25 19:08:46.667530
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment()
    args_0 = argparse.Namespace()
    tuple_0 = get_stream_type_and_kwargs(env_0, args_0)

# Generated at 2022-06-25 19:08:53.778708
# Unit test for function write_message
def test_write_message():
    argv_0 = ['http', 'api.github.com/users/jakubroztocil']
    argv_1 = ['http', '--pretty=none', 'api.github.com/users/jakubroztocil']
    argv_2 = ['http', '--pretty=format', 'api.github.com/users/jakubroztocil']
    argv_3 = ['http', '--pretty=colors', 'api.github.com/users/jakubroztocil']
    argv_4 = ['http', '--pretty=all', 'api.github.com/users/jakubroztocil']

    env_0 = Environment()
    obj_0 = Environment()
    # Uncomment if needed
    # obj_0.stdout = None

# Generated at 2022-06-25 19:08:58.261729
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    i_o_0 = module_0.IO()
    bool_0 = False
    var_0 = write_stream_with_colors_win_py3(i_o_0, i_o_0, bool_0)

test_case_0()

test_write_stream_with_colors_win_py3()

# Generated at 2022-06-25 19:09:00.787062
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    i_o_0 = module_0.IO
    bool_0 = False
    var_0 = write_stream_with_colors_win_py3(i_o_0, i_o_0, bool_0)


# Generated at 2022-06-25 19:09:11.551342
# Unit test for function write_message

# Generated at 2022-06-25 19:09:23.211510
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import PrettyStream
    import argparse
    argparse_0 = argparse.Namespace()
    argparse_0.stream = False
    argparse_0.prettify = {'colors', 'format'}
    argparse_0.style = 'paraiso-dark'
    import httpie.context
    httpie_context_0 = httpie.context.Environment()
    httpie_context_0.stdout_isatty = True
    argparse_1 = argparse.Namespace()
    argparse_1.stream = False
    argparse_1.prettify = {'colors', 'format'}
    argparse_1.style = 'paraiso-dark'

# Generated at 2022-06-25 19:09:26.747176
# Unit test for function write_message
def test_write_message():

    try:

        assert(True)
    except AssertionError:
        raise AssertionError('AssertionError raised with input: i_o_0 = module_0.IO()')


# Generated at 2022-06-25 19:09:28.181310
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs() == None
