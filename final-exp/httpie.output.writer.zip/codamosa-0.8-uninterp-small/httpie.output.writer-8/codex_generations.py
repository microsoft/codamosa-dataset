

# Generated at 2022-06-25 19:00:04.832514
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    var_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

import argparse as module_0


# Generated at 2022-06-25 19:00:08.231250
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# vim:fenc=utf-8 ff=unix ft=python ts=4 sw=4 sts=4 si et

# Generated at 2022-06-25 19:00:19.558203
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test with the default values
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class = tuple_0[0]
    stream_kwargs = tuple_0[1]
    # Write the output stream.
    write_stream_with_colors_win_py3(stream_class, environment_0.stdout, namespace_0.stream)
    # Test with the default values
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class = tuple_0[0]
    stream_kwargs

# Generated at 2022-06-25 19:00:31.904722
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace = argparse.Namespace
    namespace.headers = ['q']
    namespace.body = ['q']
    namespace.download = ['q']
    namespace.json = ['q']
    namespace.pretty = ['q']
    namespace.style = ['q']
    namespace.all = ['q']
    namespace.form = ['q']
    namespace.stream = ['q']
    namespace.verbose = ['q']
    namespace.body = ['q']
    namespace.headers = ['q']
    namespace.implicit_content_type = ['q']
    namespace.implicit_headers = ['q']
    namespace.style = ['q']
    namespace.style_output_file = ['q']
    namespace.style_output_file = ['q']
    namespace.style_output_file = ['q']
    namespace.style_output_

# Generated at 2022-06-25 19:00:34.689344
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    outfile = 'outfile'
    stream = 'stream'
    flush = 'flush'
    try:
        write_stream_with_colors_win_py3(stream, outfile, flush)
    except Exception:
        pass

# Generated at 2022-06-25 19:00:37.230964
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()



# Generated at 2022-06-25 19:00:47.556861
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.models as module_0
    import httpie.output.streams as module_1
    namespace_1 = argparse.Namespace()
    environment_0 = module_0.Environment()
    tuple_0 = (None, dict())
    tuple_0[0] = module_1.RawStream
    tuple_0[1] = dict()
    tuple_0[1]["chunk_size"] = (module_1.RawStream.CHUNK_SIZE_BY_LINE if args.stream else module_1.RawStream.CHUNK_SIZE)
    if not environment_0.stdout_isatty and not namespace_1.prettify:
        stream_class = module_1.RawStream

# Generated at 2022-06-25 19:00:58.153249
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    expected_0 = (
      '\x1b[1m\nHTTP/1.1 200 OK\x1b[0m\n'
      '\x1b[1mContent-Length: 3\x1b[0m\n'
      '\x1b[1mContent-Type: application/json\x1b[0m\n\n'
      '\x1b[1m\x1b[37m{\x1b[39m\n\x1b[1m  "foo"\x1b[0m\x1b[1m:\x1b[0m'
      ' \x1b[1m"bar"\x1b[0m\n\x1b[1m\x1b[37m}\x1b[39m\n'
    )
   

# Generated at 2022-06-25 19:01:07.267985
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert not hasattr(tuple_0, "__next__")
    assert not hasattr(tuple_0, "__iter__")
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert not hasattr(tuple_1, "__next__")
    assert not hasattr(tuple_1, "__iter__")
    tuple_2 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert not hasattr(tuple_2, "__next__")

# Generated at 2022-06-25 19:01:15.993589
# Unit test for function write_stream
def test_write_stream():
    stream_0 = RawStream(HTTPResponse(), True, False)
    write_stream(stream_0, module_0.stdout, False)
    stream_1 = PrettyStream(HTTPResponse(), False, True)
    write_stream(stream_1, module_0.stdout, True)
    write_stream(stream_0, module_0.stderr, True)
    stream_2 = EncodedStream(HTTPResponse())
    write_stream(stream_2, module_0.stdout, True)


# Generated at 2022-06-25 19:01:24.415552
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    ret = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace()
    )
    str_0 = 'q'
    return ((str_0))


# Generated at 2022-06-25 19:01:31.792550
# Unit test for function write_message
def test_write_message():
    str_0 = str(1)
    str_1 = str(2)
    str_2 = str(3)
    str_3 = str(4)
    str_4 = str(5)
    str_5 = str(6)
    str_6 = str(7)
    str_7 = str(8)
    str_8 = str(9)
    str_9 = str(10)
    str_10 = str(11)
    str_11 = str(12)
    str_12 = str(13)
    str_13 = str(14)
    str_14 = str(15)
    str_15 = str(16)
    str_16 = str(17)
    str_17 = str(18)
    str_18 = str(19)
    str_19 = str(20)

# Generated at 2022-06-25 19:01:42.897440
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Python 3
    env = Environment(is_windows=False, stdout_isatty=False)
    args = argparse.Namespace(prettify=True, stream=True, style='grouped')
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)
    
    env = Environment(is_windows=False, stdout_isatty=False)
    args = argparse.Namespace(prettify=True, stream=False, style='grouped')
    stream_type, stream_kwargs = get_stream_type_and_

# Generated at 2022-06-25 19:01:50.755555
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # case 0
    output_stream_0 = {
        'msg': 'q',
        'with_body': False,
        'with_headers': False
    }
    # case 1
    output_stream_1 = {
        'msg': 'q',
        'with_body': True,
        'with_headers': False
    }
    # case 2
    output_stream_2 = {
        'msg': 'q',
        'with_body': False,
        'with_headers': True
    }
    # case 3
    output_stream_3 = {
        'msg': 'q',
        'with_body': True,
        'with_headers': True
    }
    print(output_stream_0, output_stream_1, output_stream_2, output_stream_3)

# Unit

# Generated at 2022-06-25 19:01:57.196070
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = 'for_message'
    str_1 = 'requests-message'
    str_2 = 'request-message'

    # Zero-iteration loop
    while True:
        # Zero-iteration loop
        while True:
            # Zero-iteration loop
            while True:
                str_1 = str_0
                str_2 = 'request-message'


# Generated at 2022-06-25 19:02:02.274254
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment()
    args_0 = argparse.Namespace()
    args_0.prettify = set([str_0])
    args_0.style = str_0
    args_0.json = bool_0
    args_0.format_options = list()
    args_0.stream = bool_0
    stream_class_0, stream_kwargs_0 = get_stream_type_and_kwargs(env_0, args_0)


# Generated at 2022-06-25 19:02:05.382477
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert \
    write_stream_with_colors_win_py3(stream=None, outfile=None, flush=None)


# Generated at 2022-06-25 19:02:08.743246
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    try:
        # Check if function returns a tuple
        assert(isinstance(get_stream_type_and_kwargs_0(), tuple))
    except:
        return False
    return True


# Generated at 2022-06-25 19:02:11.377582
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    fun_name = get_stream_type_and_kwargs.__name__
    print("Start unit test for function: " + fun_name)
    test_case_0()

# Unit test runner

# Generated at 2022-06-25 19:02:22.558795
# Unit test for function write_stream
def test_write_stream():
    env = Environment()
    args = argparse.Namespace()
    str_1 = 'a'
    # StringIO('foo', 'r') = <_io.StringIO object at 0x1007b71f8>
    outfile = io.StringIO(str_1, 'r')
    flush = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    message_class = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }[type(str_1)]
    yield from stream_class(
        msg='a',
        with_headers=True,
        with_body=True,
        **stream_kwargs,
    )

# Generated at 2022-06-25 19:02:32.146507
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        stdin_isatty=False,
        stdout_isatty=False,
        colors=256,
        is_windows=True,
        is_a_tty=False,
        stream=True
    )
    args = argparse.Namespace(
        prettify=None,
        style=None,
        json=None,
        format_options=None,
        stream=True
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert(stream_class is RawStream)


# Generated at 2022-06-25 19:02:43.797112
# Unit test for function write_message
def test_write_message():
    class Namespace(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    import sys
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    args = Namespace(
        headers=[],
        pretty='none',
        style='none',
        download=False,
        output=None,
        traceback=False,
        stream=False,
        print_body_only_if_redirect=False,
        stdin_isatty=False,
        stdout_isatty=True,
        quiet=0,
        params=[],
        data=[],
        files=[],
        debug=False,
    )

# Generated at 2022-06-25 19:02:53.680732
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    str_0 = 'q'
    env = Environment('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')

# Generated at 2022-06-25 19:02:55.708535
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import StringIO
    ou = StringIO.StringIO()
    write_stream_with_colors_win_py3(None, ou, None)

# Generated at 2022-06-25 19:02:59.035344
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    args.prettify = None
    args.stream = 1
    args.style = None
    args.json = None
    args.format_options = None
    args.download = 0
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 19:03:11.000535
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment()
    env_1 = Environment()
    _namespace_0 = argparse.Namespace()
    _namespace_1 = argparse.Namespace()
    _namespace_0.prettify = None
    _namespace_0.stream = None
    _namespace_1.prettify = None
    _namespace_1.stream = None
    env_1.stdout_isatty = False
    env_1.stdout_isatty = True
    _namespace_1.stream = True
    print(get_stream_type_and_kwargs(env_0, _namespace_0) == (EncodedStream, {'env': env_0}))

# Generated at 2022-06-25 19:03:19.627889
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env_0 = Environment(
        colors=256,
        stdin_isatty=False,
        stdout_isatty=False,
        is_windows=False,
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdout_bytes=sys.stdout,
        stdout_is_bytes=True,
    )

# Generated at 2022-06-25 19:03:27.433094
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env_0 = Environment()
    args_0 = argparse.Namespace()
    requests_message_0 = requests.PreparedRequest()
    with_headers_0 = False
    with_body_0 = False
    requests_message_1 = requests.Response()
    build_output_stream_for_message(env_0, args_0, requests_message_0, with_headers_0, with_body_0)
    build_output_stream_for_message(env_0, args_0, requests_message_1, with_headers_0, with_body_0)


# Generated at 2022-06-25 19:03:38.310170
# Unit test for function write_message
def test_write_message():
    str_1 = ''
    str_2 = 'q'
    str_3 = MESSAGE_SEPARATOR
    str_4 = '\n\n'
    str_5 = '\n\n'
    str_6 = MESSAGE_SEPARATOR
    str_7 = '\n\n'
    str_8 = '\n\n'
#    str_9 = '\n\n'
    write_message(
        requests_message=str_1,
        env=str_2,
        args=str_3,
        with_headers=True,
        with_body=True)

# Generated at 2022-06-25 19:03:40.321349
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = 'q'
    outfile = 'q'
    flush = True
    write_stream_with_colors_win_py3(stream, outfile, flush)

# Generated at 2022-06-25 19:03:56.082736
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    test_file = open("unit_test/unit_test_output_stream.txt", "r")
    content = test_file.read()
    str_0 = content.split("\n")[0]
    str_1 = content.split("\n")[1]
    str_2 = content.split("\n")[2]
    str_3 = content.split("\n")[3]
    str_4 = content.split("\n")[4]
    str_5 = content.split("\n")[5]
    str_6 = content.split("\n")[6]

    class Class_0():
        def __init__(self, str_0, str_1, str_2, str_3, str_4, str_5, str_6):
            self.method = str_0

# Generated at 2022-06-25 19:04:00.018335
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = BaseStream
    outfile = TextIO
    flush = bool
    try:
        # Writing bytes so we use the buffer interface (Python 3).
        buf = outfile.buffer
    except AttributeError:
        buf = outfile

    for chunk in stream:
        buf.write(chunk)
        if flush:
            outfile.flush()

# Generated at 2022-06-25 19:04:04.046502
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = 'GET /'

    class Struct_0():
        @staticmethod
        def __new__(*args, **kwargs):
            return str_0

    def func_0(arg_0):
        return arg_0

    func_0(Struct_0)
    str_0 = str()



# Generated at 2022-06-25 19:04:15.324920
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    if __package__ is None:
        import sys
        from os import path
        sys.path.append( path.dirname( path.dirname( path.abspath(__file__) ) ) )
        from output.streams import BaseStream
        from output.streams import BufferedPrettyStream
        from output.streams import EncodedStream
        from output.streams import PrettyStream
        from output.streams import RawStream
        from models import HTTPRequest
        from models import HTTPResponse
    else:
        from ..output.streams import BaseStream
        from ..output.streams import BufferedPrettyStream
        from ..output.streams import EncodedStream
        from ..output.streams import PrettyStream
        from ..output.streams import RawStream
        from ..models import HTTPRequest
        from ..models import HTTPResp

# Generated at 2022-06-25 19:04:26.863472
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    p = argparse.ArgumentParser(prog='httpie')
    p.add_argument('--stream', action='store_true')
    p.add_argument('--json', action='store_true')
    p.add_argument('--prettify', action='store_true')
    p.add_argument('--style', action='store_true')
    p.add_argument('--debug', action='store_true')
    p.add_argument('--traceback', action='store_true')
    p.add_argument('--format-options', action='store_true')
    args = p.parse_args()
    try:
        env = Environment()
    except Exception:
        env = Environment()
    requests_message = "request"

# Generated at 2022-06-25 19:04:27.943285
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True == False, test_case_0()

# Generated at 2022-06-25 19:04:33.850364
# Unit test for function write_message
def test_write_message():
    args = argparse.Namespace()
    env = Environment()
    requests_message = requests.PreparedRequest()
    try:
        write_message(requests_message, env, args, True, True)
    except IOError as e:
        print("Exception happened when invoking write_message")
        print(e)


# Generated at 2022-06-25 19:04:34.724019
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = ''


# Generated at 2022-06-25 19:04:36.338470
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:04:37.244477
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
	str_0 = 'q'

# Generated at 2022-06-25 19:04:46.930664
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

if __name__ == "__main__":
    import random
    for i in range(10):
        test_get_stream_type_and_kwargs()

# Generated at 2022-06-25 19:04:50.599768
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    argparse_namespace_0 = module_1.Namespace()
    return_value_0 = build_output_stream_for_message(argparse_namespace_0, environment_0, requests.PreparedRequest(), True, True)
    write_stream(return_value_0, sys.stdout, True)

# Generated at 2022-06-25 19:04:53.481670
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = BaseStream()
    outfile = object()
    flush = True
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=flush,
    )


# Generated at 2022-06-25 19:05:03.306586
# Unit test for function write_stream
def test_write_stream():
    stream_0 = module_0.BaseStream()
    outfile_0 = module_1.IO()
    flush_0 = module_1.bool()
    buf = outfile_0.buffer
    exc = Exception()
    try:
        for chunk in stream_0:
            buf.write(chunk)
            if flush_0:
                outfile_0.flush()
    except IOError as e:
        show_traceback = namespace_0.debug or namespace_0.traceback
        if not show_traceback and e.errno == errno.EPIPE:
            # Ignore broken pipes unless --traceback.
            environment_0.stderr.write('\n')
        else:
            raise


# Generated at 2022-06-25 19:05:12.708890
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    input_buffer_0 = b'a'
    input_buffer_1 = '\x1b[1ma\x1b[1b0'
    output_file_0 = open('/home/kemar/httpie/tests/testdata/bin/http', 'rb')
    try:
        write_stream_with_colors_win_py3(input_buffer_0, output_file_0, b'boolean_arg_0')
    finally:
        output_file_0.close()
    output_file_1 = open('/home/kemar/httpie/tests/testdata/bin/http', 'rb')

# Generated at 2022-06-25 19:05:23.815888
# Unit test for function write_message
def test_write_message():
    import httpie.context as module_0
    import httpie.models as module_1
    import argparse as module_2
    import requests as module_3
    import httpie.output.streams as module_4
    import httpie.output.processing as module_5
    import json as module_6
    import sys as module_7
    def function_0():
        try:
            pass
        except module_7.error:
            pass
    response_0 = module_3.Response()
    prepared_request_0 = module_3.PreparedRequest()
    response_1 = module_3.Response()
    namespace_0 = module_2.Namespace()
    dict_0 = {'b': ''}
    response_0.request.body = dict_0
    tuple_0 = (1, 2)
    prepared

# Generated at 2022-06-25 19:05:27.259922
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass
tuple_0 = test_write_stream_with_colors_win_py3()
# TestCase #0
testcase_0_0 = test_write_stream_with_colors_win_py3()

# Generated at 2022-06-25 19:05:34.631072
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace_0 = module_1.Namespace()

    namespace_0.stdout_isatty = True
    environment_0 = module_0.Environment()
    namespace_0.prettify = "groups"
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert isinstance(tuple_0[0], module_0.output.streams.PrettyStream)
    assert isinstance(tuple_0[1]["env"], module_0.Environment)
    assert isinstance(tuple_0[1]["conversion"], module_0.output.processing.Conversion)
    assert isinstance(tuple_0[1]["formatting"], module_0.output.processing.Formatting)

    namespace_0.stdout_isatty = True

# Generated at 2022-06-25 19:05:39.245628
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    test_case_0()
test_get_stream_type_and_kwargs()

import httpie.context as module_0
import httpie.output.processing as module_1
import httpie.output.streams as module_2
import httpie.models as module_3
import typing as module_4
import requests as module_5
import argparse as module_6


# Generated at 2022-06-25 19:05:43.487472
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == module_0.EncodedStream
    assert tuple_0[1]['env'] == environment_0


# Generated at 2022-06-25 19:06:01.350775
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(tuple_0) is tuple
    assert type(tuple_0[0]) is type
    assert type(tuple_0[1]) is dict

import httpie.output.streams as module_2
import httpie.output.streams as module_3
import httpie.output.streams as module_4
import httpie.output.streams as module_5


# Generated at 2022-06-25 19:06:12.546597
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs() == NotImplemented, 'An error has occurred'
    assert get_stream_type_and_kwargs() == NotImplemented, 'An error has occurred'
    assert get_stream_type_and_kwargs() == NotImplemented, 'An error has occurred'
    assert get_stream_type_and_kwargs() == NotImplemented, 'An error has occurred'
    assert get_stream_type_and_kwargs() == NotImplemented, 'An error has occurred'
    assert get_stream_type_and_kwargs() == NotImplemented, 'An error has occurred'
    assert get_stream_type_and_kwargs() == NotImplemented, 'An error has occurred'
    assert get_stream_type_and_kwargs() == NotImple

# Generated at 2022-06-25 19:06:15.304762
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_1 = module_1.Namespace()
    assert get_stream_type_and_kwargs(environment_0, namespace_1)[0] == module_1.BufferedPrettyStream


# Generated at 2022-06-25 19:06:19.672436
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_request = requests.PreparedRequest()
    get_stream_type_and_kwargs(environment_0, namespace_0)
    build_output_stream_for_message(namespace_0, environment_0, prepared_request, True, True)

# Generated at 2022-06-25 19:06:20.495803
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    pass


# Generated at 2022-06-25 19:06:25.539496
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Setup
    environment = Environment()
    namespace = Namespace()

    # Exercise
    stream_class, stream_kwargs = get_stream_type_and_kwargs(environment, namespace)

    # Verify
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE}



# Generated at 2022-06-25 19:06:28.283544
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)


import argparse as module_0


# Generated at 2022-06-25 19:06:30.286176
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    test_case_0()

import httpie.output.processing as module_4
import httpie.models as module_2


# Generated at 2022-06-25 19:06:31.122396
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:06:37.780821
# Unit test for function write_stream
def test_write_stream():
    # Assumes `encoding` is 'utf-8'
    outfile = io.BytesIO()
    stream = EncodedStream(
        msg=HTTPResponse(requests.Response()),
        with_headers=True,
        with_body=True,
        env=Environment(),
    )
    write_stream(stream, outfile, flush=False)
    outfile.seek(0)
    assert outfile.read().decode('utf-8') == 'HTTP/0.9 200 OK\r\n\r\n'

# Generated at 2022-06-25 19:07:08.478821
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io
    import httpie
    environment_0 = httpie.context.Environment()
    environment_0.is_windows = True
    environment_0.stdout_isatty = True
    namespace_0 = argparse.Namespace()
    namespace_0.prettify = ['colors']
    namespace_0.stream = False
    stream_class_0, stream_kwargs_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    msg_0 = httpie.models.HTTPRequest(httpie.models.Request())
    stream_0 = stream_class_0(msg_0, True, True, **stream_kwargs_0)

# Generated at 2022-06-25 19:07:18.103940
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_0[1]['env'] = namespace_0
    tuple_0[1]['formatting'] = namespace_0
    tuple_0[1]['format_options'] = namespace_0
    tuple_0[1]['color_scheme'] = namespace_0
    tuple_0[1]['groups'] = namespace_0
    tuple_0[1]['conversion'] = namespace_0
    tuple_0[1]['explicit_json'] = namespace_0
    namespace_0.style = namespace_0
    namespace_0.download = namespace_0
    namespace_0.stdout = namespace_0


# Generated at 2022-06-25 19:07:20.013315
# Unit test for function write_message
def test_write_message():
    environment = module_0.Environment()
    namespace = module_1.Namespace()
    write_message(request, environment, namespace)


# Generated at 2022-06-25 19:07:31.846153
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    requests_message_0 = None
    assert __rand_int6__(type(build_output_stream_for_message(namespace_0, environment_0, requests_message_0, False, False))) is bool
    requests_message_1 = None
    bool_0 = isinstance(requests_message_1, type(module_0.requests))
    assert __rand_int6__(bool_0) is True
    requests_message_2 = None
    assert __rand_int6__(type(build_output_stream_for_message(namespace_0, environment_0, requests_message_2, False, False))) is int
    requests_message_3 = None

# Generated at 2022-06-25 19:07:37.954060
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io as module_0
    import httpie.output.streams as module_1
    stream_0 = module_1.BaseStream
    outfile_0 = module_0.TextIOWrapper
    flush_0 = False
    write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:07:40.362521
# Unit test for function write_message
def test_write_message():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    write_message((), environment_0, namespace_0, False, False)

# Generated at 2022-06-25 19:07:44.624241
# Unit test for function write_message
def test_write_message():
    with __pytest__.raises(AttributeError):
        namespace_0 = module_1.Namespace()
        try:
            requests_response_0 = requests.Response()
        except AttributeError:
            pass
        write_message(requests_response_0, environment_0, namespace_0)


# Generated at 2022-06-25 19:07:48.181689
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    def test_case_0():
        environment_0 = module_0.Environment()
        namespace_0 = module_1.Namespace()
        tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    return None

# Generated at 2022-06-25 19:07:51.442784
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_0 = requests.Response()
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, True, True)


# Generated at 2022-06-25 19:07:56.256402
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    assert get_stream_type_and_kwargs(environment_0, namespace_0) == (BaseStream, {})

import httpie.output.streams as module_0
import httpie.context as module_1


# Generated at 2022-06-25 19:08:19.474937
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)


# Generated at 2022-06-25 19:08:28.441488
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream

    args = mock.MagicMock(spec=argparse.Namespace)
    mock_env = mock.MagicMock(spec=Environment)
    mock_message = mock.MagicMock(spec=requests.Request)

    args.prettify = False
    args.stream = False
    mock_env.is_windows = False
    mock_env.stdout_isatty = False

# Generated at 2022-06-25 19:08:32.906723
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    print("testing function write_stream_with_colors_win_py3")
    BaseStream_ = type('BaseStream', (), {})
    TextIO_ = type('TextIO', (), {})
    stream_0 = BaseStream_()
    outfile_0 = TextIO_()
    flush_0 = bool()
    write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:08:35.694872
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    assert tuple_0[0].__name__ == "EncodedStream"
    assert tuple_0[1] == {}

# Generated at 2022-06-25 19:08:40.377188
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    http_request_0 = module_0.HTTPRequest(None)
    len_0 = len(build_output_stream_for_message(namespace_0, environment_0, http_request_0, namespace_0, namespace_0))
    assert len_0 == 1


# Generated at 2022-06-25 19:08:46.683662
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message = requests.PreparedRequest()
    env = module_0.Environment()
    args = module_1.Namespace()
    with_headers = False
    with_body = False

    try:
        write_message(requests_message, env, args, with_headers,
                      with_body)
    except IOError as e:
        show_traceback = args.debug or args.traceback
        if not show_traceback and e.errno == errno.EPIPE:
            # Ignore broken pipes unless --traceback.
            env.stderr.write('\n')
        else:
            raise

# Generated at 2022-06-25 19:08:52.913499
# Unit test for function write_message
def test_write_message():
    namespace_0 = module_1.Namespace()
    namespace_0.headers = 'test_value'
    namespace_0.stream = 'test_value'
    environment_0 = module_0.Environment()
    environment_0.stdout = 'test_value'
    namespace_0.prettify = 'test_value'
    write_message(requests.PreparedRequest(), environment_0, namespace_0, 'test_value', 'test_value')
    write_message(requests.Response(), environment_0, namespace_0, 'test_value', 'test_value')

if __name__ == '__main__':
    test_case_0()
    test_write_message()

# Generated at 2022-06-25 19:09:01.267348
# Unit test for function write_stream
def test_write_stream():
    import io
    
    file_id = 0
    
    if file_id == 0:
        infile = io.BytesIO(b'abc')
    elif file_id == 1:
        infile = io.TextIOWrapper(io.BytesIO(b'def'))
    
    # Arbitrarily chosen to give no need for special treatment of
    # different cases.
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        module_0.Environment(), module_1.Namespace()
    )
    message_class = module_0.HTTPRequest

# Generated at 2022-06-25 19:09:02.305192
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    test_case_0()

# Generated at 2022-06-25 19:09:12.334498
# Unit test for function write_stream
def test_write_stream():
    # Tests for write_stream
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    environment_0.stdout_isatty = False
    environment_0.stdout = open("./test/data/output_streams/req1")
    namespace_0.prettify = ('colors', 'format')
    namespace_0.stream = False
    stream_class = PrettyStream