

# Generated at 2022-06-25 19:00:12.102958
# Unit test for function write_message
def test_write_message():
    prepared_request_0 = module_0.PreparedRequest()
    environment_0 = None
    namespace_0 = module_1.Namespace()
    var_0 = write_message(prepared_request_0, environment_0, namespace_0)
    assert True
#


# Generated at 2022-06-25 19:00:23.098261
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    type_0 = module_0.PreparedRequest
    type_1 = module_0.Response
    dict_0 = {}
    type_2 = module_0.PreparedRequest
    type_3 = module_0.Response
    dict_1 = {}
    type_4 = module_0.PreparedRequest
    type_5 = module_0.Response
    dict_2 = {}
    type_6 = module_0.PreparedRequest
    type_7 = module_0.Response
    dict_3 = {}
    type_8 = module_0.PreparedRequest
    type_9 = module_0.Response
    dict_4 = {}
    type_10 = module_0.PreparedRequest
    type_11 = module_0.Response
    dict_5 = {}


# Generated at 2022-06-25 19:00:28.035903
# Unit test for function write_message
def test_write_message():
    prepared_request_0 = module_0.PreparedRequest()
    environment_0 = None
    namespace_0 = module_1.Namespace()
    var_0 = write_message(prepared_request_0, environment_0, namespace_0)
    assert var_0 == None 


# Generated at 2022-06-25 19:00:32.699880
# Unit test for function write_stream
def test_write_stream():
    prepared_request_0 = module_0.PreparedRequest()
    environment_0 = None
    namespace_0 = module_1.Namespace()
    expected_result_0 = None
    result_0 = write_message(prepared_request_0, environment_0, namespace_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-25 19:00:34.186465
# Unit test for function write_stream
def test_write_stream():

    pass

import requests.models as module_0
import argparse as module_1


# Generated at 2022-06-25 19:00:39.435263
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_0 = module_0.PreparedRequest()
    environment_0 = None
    argparse_namespace_0 = module_1.Namespace()
    var_0 = build_output_stream_for_message(argparse_namespace_0, environment_0, requests_message_0, False, False)


# Generated at 2022-06-25 19:00:49.410123
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests.models as module_1
    import httpie.models as module_2
    import httpie.output.streams as module_3
    prepared_request_0 = module_1.PreparedRequest()
    environment_0 = None
    namespace_0 = module_1.Namespace()
    var_0 = module_0.build_output_stream_for_message(namespace_0, environment_0, prepared_request_0, True, True)
    var_1 = module_0.build_output_stream_for_message(namespace_0, environment_0, prepared_request_0, True, False)
    var_2 = module_0.build_output_stream_for_message(namespace_0, environment_0, prepared_request_0, False, True)
    var_3 = module_0.build_

# Generated at 2022-06-25 19:00:51.728693
# Unit test for function write_stream
def test_write_stream():
    stream = None
    outfile = None
    flush = None
    var_0 = write_stream(stream, outfile, flush)


# Generated at 2022-06-25 19:01:00.702598
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    GIVEN = ['', '--stream']
    for i in range(2):
        environment_0 = None
        namespace_0 = module_1.Namespace()
        namespace_0.stream = GIVEN[i]
        namespace_0.prettify = ['colors']
        namespace_0.style = 'DEFAULT'
        namespace_0.json = False
        namespace_0.format_options = {}
        namespace_0.debug = True
        namespace_0.traceback = True
        var_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
        if (__name__ == '__main__'):
            test_case_0()

# Generated at 2022-06-25 19:01:03.620318
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = Environment()
    namespace_0 = module_1.Namespace()
    var_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    var_1 = get_stream_type_and_kwargs(environment_0, namespace_0)


# Generated at 2022-06-25 19:01:22.044054
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    args.prettify = ['all']
    args.stream = True
    args.style = 'monokai'
    args.json = False
    args.format_options = []

    env = Environment(args)
    env.stdout_isatty = True

    expected_classes = PrettyStream
    expected_values = {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=args.prettify,
            color_scheme=args.style,
            explicit_json=args.json,
            format_options=args.format_options,
        )
    }

    actual_classes, actual_values = get_stream_type_and_kwargs(env, args)

    assert expected_classes

# Generated at 2022-06-25 19:01:30.349696
# Unit test for function write_message

# Generated at 2022-06-25 19:01:31.937566
# Unit test for function write_message
def test_write_message():

    from io import StringIO
    from httpie.output.streams import test_write_stream

# Generated at 2022-06-25 19:01:35.847937
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream_with_colors_win_py3(var_0, var_1, var_2)


# Generated at 2022-06-25 19:01:43.584419
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class mock_Environment():
        def __init__(self):
            self.is_windows = None
            self.stdout = None
            self.stdout_isatty = None

    class mock_PreparedRequest():
        def __init__(self):
            self.is_body_upload_chunk = None

    class mock_HTTPResponse():
        def __init__(self):
            self.is_body_upload_chunk = None

    class mock_HTTPRequest():
        def __init__(self):
            self.is_body_upload_chunk = None

    class mock_Stream():
        def __init__(self):
            self.msg = None
            self.with_headers = None
            self.with_body = None


    m_env = mock_Environment()

# Generated at 2022-06-25 19:01:50.085970
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    stream_class, stream_kwargs = get_stream_type_and_kwargs()
    message_class = {}[type()]
    assert (yield from stream_class(msg=
    message_class(), with_headers=True, with_body=True, **stream_kwargs))
    assert (yield from stream_class(msg=
    message_class(), with_headers=True, with_body=True, **stream_kwargs))


# Generated at 2022-06-25 19:01:52.758325
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = None
    output = write_stream_with_colors_win_py3(var_0, var_1, var_2)
    return output



# Generated at 2022-06-25 19:02:02.202102
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment()
    var_0.stdout = io.StringIO()
    var_0.stdout_isatty = True
    var_0.is_windows = False
    var_0.stderr_isatty = True
    var_1 = argparse.Namespace()
    var_1.prettify = list()
    var_1.style = 'paraiso-dark'
    var_1.stream = False
    var_1.json = True
    var_1.format_options = dict()
    var_1.style = 'paraiso-dark'
    var_1.format_options = dict()
    var_1.style = 'paraiso-dark'
    var_1.format_options = dict()
    var_2, var_3 = get_stream_type

# Generated at 2022-06-25 19:02:08.846675
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = HTTPResponse(None, '')
    var_1 = EncodedStream(var_0, False, False, '')
    var_2 = sys.stdout
    try:
        # write_stream_with_colors_win_py3(var_1, var_2, True)
        pass
    except IOError as e:
        assert False


# Generated at 2022-06-25 19:02:13.192401
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Check if the function returns error if input argument is not valid
    from httpie import __main__
    from httpie.cli import parser
    from httpie.context import Environment
    args = parser.parse_args([""])
    arg1 = args
    arg2 = Environment()
    var_2 = get_stream_type_and_kwargs(arg1, arg2)
    assert isinstance(var_2, tuple)

# Generated at 2022-06-25 19:02:31.825536
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    for arg in [
        HTTPRequest(requests.PreparedRequest()),
        HTTPResponse(requests.Response()),
    ]:
        assert isinstance(
            build_output_stream_for_message(
                args=None,
                env=None,
                requests_message=arg,
                with_headers=None,
                with_body=None,
            ),
            RawStream,
        )
        assert isinstance(
            build_output_stream_for_message(
                args=None,
                env=None,
                requests_message=arg,
                with_headers=None,
                with_body=None,
            ),
            BufferedPrettyStream,
        )

# Generated at 2022-06-25 19:02:36.592199
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = build_output_stream_for_message(var_0, var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 19:02:46.980221
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(
        diff=None,
        download=None,
        form=False,
        headers=[],
        method=None,
        output_file=None,
        prettify=None,
        style=None,
        traceback=None,
        verbose=False,
        json=None,
        stream=True,
        format_options=None,
        debug=None,
        style_sheet=None,
    )
    stdout_isatty = sys.stdout.isatty()
    stderr_isatty = sys.stderr.isatty()

# Generated at 2022-06-25 19:02:50.109374
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # No exception expected
    env = Environment()
    args = argparse.Namespace()

    get_stream_type_and_kwargs(
        env=env,
        args=args
    )


# Generated at 2022-06-25 19:02:55.622709
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream_for_message(var_0, var_1, var_2, var_0, var_0)
    var_4 = None
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:03:00.139793
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = None
    var_1 = None
    try:
        var_1 = get_stream_type_and_kwargs(var_0, var_0)
    except Exception as var_2:
        print('caught exception: ' + str(var_2))



# Generated at 2022-06-25 19:03:04.196975
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream_with_colors_win_py3(var_0, var_1, var_2)


# Generated at 2022-06-25 19:03:05.515610
# Unit test for function write_stream
def test_write_stream():
    assert write_stream() == write_stream(
)



# Generated at 2022-06-25 19:03:16.448155
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    temp_kwargs = {
        'chunk_size': RawStream.CHUNK_SIZE_BY_LINE
    }

    assert get_stream_type_and_kwargs(args, env) == (RawStream, temp_kwargs)

    temp_kwargs = {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(env=env, groups=args.prettify, color_scheme=args.style, explicit_json=args.json, format_options=args.format_options)
    }

    assert get_stream_type_and_kwargs(args, env) == (BufferedPrettyStream, temp_kwargs)

    temp_kwargs = {
        'env': env
    }


# Generated at 2022-06-25 19:03:18.300136
# Unit test for function write_stream
def test_write_stream():
    # 1
    var_0 = None
    var_1 = write_stream(var_0, var_0, var_0)



# Generated at 2022-06-25 19:03:48.288067
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}


# Generated at 2022-06-25 19:03:57.746264
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    if __name__ == "httpie.output.streams.build_output_stream_for_message":
        var_0 = argparse.Namespace()
        var_0.prettify = None
        var_0.stream = None
        var_0.style = None
        var_0.json = None
        var_0.debug = None
        var_0.format_options = None
        var_0.traceback = None
        var_1 = Environment()
        var_1.stdout_isatty = True
        var_1.stdout = None
        var_2 = None
        var_3 = None
        var_4 = None
        var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)
        var_6

# Generated at 2022-06-25 19:04:02.485699
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(
            stream=None,
            prettify=['all'],
            style=None,
            json=False,
            format_options=None,
            debug=None,
            traceback=False,
        )
    )
    assert stream_class == PrettyStream
    assert 'conversion' in stream_kwargs
    assert 'formatting' in stream_kwargs



# Generated at 2022-06-25 19:04:09.230249
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from unittest import mock
    from httpie.compat import is_py3

    var_1 = mock.MagicMock()
    var_2 = mock.MagicMock()
    var_3 = mock.MagicMock()
    var_4 = mock.MagicMock()
    var_5 = mock.MagicMock()
    
    with mock.patch('os.name', 'nt'), \
            mock.patch('httpie.output.streams.is_py3', is_py3):
        var_1 = '\x1b['
    
    var_3 = {
        'stream': var_4,
        'outfile': var_5,
        'flush': var_2
    }

# Generated at 2022-06-25 19:04:12.304128
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    if __name__ == '__main__':
        var_3 = None
    var_4 = None
    var_5 = write_stream_with_colors_win_py3(var_4, var_4, var_4)

# Generated at 2022-06-25 19:04:17.019220
# Unit test for function write_stream
def test_write_stream():
    assert isinstance(write_stream(var_0, var_0, var_0), (list, tuple, dict))


# Generated at 2022-06-25 19:04:27.270404
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class mockargs:
        def __init__(self):
            self.prettify = []
            self.stream = False
            self.json = False
            self.style = 0
            self.format_options = []
    class mock_env:
        def __init__(self):
            self.stdout_isatty = True
    args = mockargs()
    env = mock_env()
    assert get_stream_type_and_kwargs(env = env, args = args) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=[], color_scheme=0, explicit_json=False, format_options=[])})

# Generated at 2022-06-25 19:04:32.752462
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = True
    var_4 = True
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:04:40.873287
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class EnvironmentTest0(object):
        pass

    class EnvironmentTest1(object):
        pass

    class EnvironmentTest2(object):
        pass

    class EnvironmentTest3(object):
        pass

    class EnvironmentTest4(object):
        pass

    class EnvironmentTest5(object):
        pass

    class EnvironmentTest6(object):
        pass

    class EnvironmentTest7(object):
        pass

    argparse.Namespace.var_2 = var_2
    argparse.Namespace.var_3 = var_3

    argparse.Namespace.var_4 = var_4
    argparse.Namespace.var_5 = var_5

    argparse.Namespace.var_6 = var_6
    argparse.Namespace.var_7 = var_7

    argparse.Namespace.var_8 = var_

# Generated at 2022-06-25 19:04:44.527881
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        var_0 = None
        var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)
    except Exception:
        print('Exception: test_write_stream_with_colors_win_py3')

# Generated at 2022-06-25 19:05:45.501017
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-25 19:05:55.102718
# Unit test for function write_message
def test_write_message():
    var_0 = Environment(var_0, var_0, var_0, var_0)
    var_1 = argparse.Namespace(var_0, var_0, var_0, var_0, var_0,
        var_0, var_0, var_0, var_0, var_0, var_0, var_0)

# Generated at 2022-06-25 19:06:06.417446
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.core import main
    from httpie.compat import is_windows
    args = main.parser.parse_args(args=[], env=Environment())
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=args
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['env'].is_windows == is_windows()
    assert 'conversion' in stream_kwargs
    assert 'formatting' in stream_kwargs
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(is_windows=False),
        args=args
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['env'].is_windows == is_windows()
   

# Generated at 2022-06-25 19:06:10.390614
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace()

    requests_message = None # TODO
    with_headers = None # TODO
    with_body = None # TODO
    var_2 = write_message(requests_message, env, args, with_headers, with_body)



# Generated at 2022-06-25 19:06:17.785770
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # test args
    args = argparse.Namespace()
    args.stream = None
    args.prettify = ['colors']
    args.style = None
    args.json = False
    args.format_options = None
    args.debug = False
    args.traceback = False

    # test env
    env = Environment()
    env.debug = False
    env.stdout = None
    env.stdout_isatty = True
    env.stderr = None
    env.is_windows = True

    # test requests_message
    requests_message = requests.PreparedRequest()
    requests_message.body = 'AAA'

    # test with_headers
    with_headers = True

    # test with_body
    with_body = False

    # call function
    var_0 = None
   

# Generated at 2022-06-25 19:06:27.050463
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class MockClass:
        def __init__(self):
            self.words = "test"

    import json
    import requests
    var_0 = MockClass()
    var_0.url = "test"
    var_0.verb = "test"
    var_0.headers = {}
    var_0.body = "test"
    var_0.method = "test"
    var_1 = Environment()
    var_1.stdout_isatty = True
    args = MockClass()
    args.json = False
    args.prettify = "all"
    args.style = "test"
    args.stream = False
    args.format_options = {}
    var_3 = write_stream(var_0, var_0, var_0)

# Generated at 2022-06-25 19:06:36.386016
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test when the output is not in color
    try:
        var_0 = None
        var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)
    except Exception:
        assert False # exception raised wrongly
    else:
        assert True # expected exception not raised

    # Test when nothing is being written to the output stream
    try:
        var_0 = None
        var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)
    except Exception:
        assert False # exception raised wrongly
    else:
        assert True # expected exception not raised

    # Test when the output is in color

# Generated at 2022-06-25 19:06:39.043016
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(
        env=None,
        args=None,
    ) == (BaseStream, {
        'msg': None,
        'with_headers': None,
        'with_body': None,
    })

# Generated at 2022-06-25 19:06:43.206327
# Unit test for function write_message
def test_write_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = write_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:06:45.829791
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream_with_colors_win_py3(var_0, var_1, var_2)


# Generated at 2022-06-25 19:09:02.053909
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    import os
    import tempfile

    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.compat import is_windows
    from utils import TestEnvironment, http, HTTP_OK

    env = TestEnvironment(
        stdin_isatty=False, stdout_isatty=False, stderr_isatty=False,
        colors=0,
    )
    args = parser.parse_args(args=[], env=env)
    args.json = False
    args.prettify = False
    args.stream = True
    args.style = None
    args.headers = True
    args.verbose = False
    args.debug = False
    args.download = False
    args.traceback = False
    args.output_file = None
    args.download_output_file

# Generated at 2022-06-25 19:09:06.719603
# Unit test for function write_stream
def test_write_stream():
    try:
        assert callable(write_stream)
    except AssertionError as e:
        print(e)
        print(write_stream.__doc__)
        for name in dir(write_stream):
            if name.startswith('_'):
                continue
            print('  ' + name)
    # This function has no testable statements.


# Generated at 2022-06-25 19:09:14.655546
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment()
    var_1 = argparse.Namespace(prettify=None, style=None, stream=True)
    var_2 = True
    if var_2:
        var_3 = PrettyStream
    else:
        var_3 = BufferedPrettyStream
    var_4 = True
    if var_4:
        var_5 = PrettyStream
    else:
        var_5 = BufferedPrettyStream
    if var_2:
        var_6 = '\x1b['
        var_7 = var_0.stdout
        var_8 = var_7.encoding
        var_9 = var_0.stdout
        var_9.write(var_6.decode(var_8))
    else:
        var_10 = var_0.stdout
        var_

# Generated at 2022-06-25 19:09:26.026906
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import unittest
    import sys
    import httpie.output.streams

    class TestStream:
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return self

        def __next__(self):
            try:
                return self.chunks.pop(0)
            except IndexError:
                raise StopIteration

        next = __next__

    class TestIO:
        encoding = 'utf-8'

        def write(self, chunk):
            print(chunk, end='')

    class TestOutFile:
        def __init__(self):
            self.buffer = TestIO()

    class TestEnvironment:
        def __init__(self):
            self.is_windows = True


# Generated at 2022-06-25 19:09:26.719967
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:09:33.129470
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-25 19:09:36.135802
# Unit test for function write_message
def test_write_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    write_message(var_0, var_1, var_2, var_3, var_3)

# Generated at 2022-06-25 19:09:44.297079
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_input = [False, True]
    var_output = [BufferedPrettyStream, PrettyStream]
    var_output_list = []

    for i in range(2):
        var_input[0] = i
        var_output_list.append(get_stream_type_and_kwargs(var_input[0], var_input[1]))

    assert len(var_output_list) == 2
    assert var_output_list[0][0] == var_output[0]
    assert var_output_list[1][0] == var_output[1]
    return


# Generated at 2022-06-25 19:09:47.356200
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)


# Generated at 2022-06-25 19:09:52.085978
# Unit test for function write_stream
def test_write_stream():
    # Setup mock objects/variables/methods
    env = None
    args = None
    with_headers = False
    with_body = False
    requests_message = None
    # Call function under test
    write_message(
        requests_message,
        env,
        args,
        with_headers,
        with_body,
    )
    # Check if test case passed/failed
    # assert ...

