

# Generated at 2022-06-25 19:00:07.310639
# Unit test for function write_stream
def test_write_stream():
    stream = RawStream()
    outfile = open('test_p', 'w')
    flush = True
    write_stream(stream, outfile, flush)


# Generated at 2022-06-25 19:00:11.609132
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:00:15.063238
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    try:
        test_case_0()
    except SystemExit:
        pass
    except:
        raise AssertionError

import httpie.context as module_0
import requests as module_1
import httpie.output.streams as module_2


# Generated at 2022-06-25 19:00:24.524324
# Unit test for function write_message
def test_write_message():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment(stdout_isatty=True)
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    hR = getattr(module_0.http_client, "HTTPReplay")
    tuple_1 = (hR.response, hR.request)
    write_message(tuple_1[0], environment_0, tuple_0[1], True, True)
    write_message(tuple_1[1], environment_0, tuple_0[1], True, True)

# Generated at 2022-06-25 19:00:30.530084
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0 == (module_0.EncodedStream, {'env': environment_0})

import httpie.request as module_0


# Generated at 2022-06-25 19:00:38.201196
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.context as module_0
    import argparse as module_1
    requests = module_0
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    namespace_1 = module_1.Namespace()
    namespace_1.prettify = ''
    namespace_1.style = ''
    namespace_1.json = False
    namespace_1.download = False
    namespace_1.stream = False
    namespace_1.debug = False
    namespace_1.traceback = False
    namespace_1.format_options = []
    namespace_2 = module_1.Namespace()
    namespace_2.headers = False
    namespace_2.body = False
    namespace_2.pretty = False
    namespace_2.style = ''
    namespace_2.json = False

# Generated at 2022-06-25 19:00:48.245622
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import collections
    import requests
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.debug = bool([])
    namespace_0.traceback = bool(['traceback'])
    namespace_0.stream = bool([])
    namespace_0.prettify = tuple([])
    namespace_0.style = ''
    namespace_0.json = False
    namespace_0.format_options = collections.OrderedDict()
    namespace_0.format_options['prettify'] = True
    namespace_0.format_options['style'] = ''
    namespace_0.format_options['json'] = False
    namespace_0.format = 'test_value'
    namespace_0.format_keys = []
    namespace_0.headers = tuple([])
   

# Generated at 2022-06-25 19:00:51.944140
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()

    # Test error conditions
    try:
        tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    except ValueError:
        pass

# Generated at 2022-06-25 19:00:57.561890
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_0 = requests.request(url='https://httpie.org/', timeout=0.01)
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, True, True)


# Generated at 2022-06-25 19:01:06.302297
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test case where `outfile` is IO
    stream_0 = RawStream(msg=HTTPRequest(), with_headers=False, with_body=False)
    namespace_1 = module_1.Namespace()
    namespace_2 = module_1.Namespace()
    write_stream_with_colors_win_py3(stream_0, namespace_1, namespace_2)
    # Test case where `outfile` is TextIO
    stream_1 = RawStream(msg=HTTPRequest(), with_headers=False, with_body=False)
    namespace_3 = module_1.Namespace()
    namespace_4 = module_1.Namespace()
    write_stream_with_colors_win_py3(stream_1, namespace_3, namespace_4)


# Generated at 2022-06-25 19:01:19.361393
# Unit test for function write_stream
def test_write_stream():
    # Initializing test variables
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    outfile_0 = module_0.stdout
    # Testing function with arguments (BaseStream, Union[IO, TextIO], bool)
    test_write_stream_0(environment_0, namespace_0, outfile_0)


# Generated at 2022-06-25 19:01:24.329003
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_0 = BufferedPrettyStream
    outfile_0 = _get_output_stream(stream_0)
    flush_0 = False
    # The IOError is thrown when the output stream is closed.
    with pytest.raises(IOError):
        write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:01:30.382676
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # setup
    requests_message = requests.PreparedRequest
    requests_message.is_body_upload_chunk = False
    args = argparse.Namespace(prettify='body', style='par', json=True)
    environment = Environment()
    environment.stdout_isatty = True
    with_headers = True
    with_body = True

    # act
    result = build_output_stream_for_message(args, environment, requests_message, with_headers, with_body)

    # assert
    assert 'b\'\n\n\'' in str(result)


# Generated at 2022-06-25 19:01:33.096158
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(None, environment_0, namespace_0)


# Generated at 2022-06-25 19:01:43.510883
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    #
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0 == (module_0.output.streams.EncodedStream, {'env': module_0.Environment()})

    #
    namespace_1 = module_1.Namespace(prettify='none')
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_1)
    assert tuple_1 == (module_0.output.streams.RawStream, {'chunk_size': RawStream.CHUNK_SIZE})

    #
    environment_1 = module_0.Environment(stdout_isatty=False)
    tuple_2 = get_

# Generated at 2022-06-25 19:01:53.038117
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()

    # Test for no arg
    if ((not environment_0.stdout_isatty) and (not namespace_0.prettify)):
        assert isinstance(get_stream_type_and_kwargs(environment_0, namespace_0)[0], RawStream)
        assert (get_stream_type_and_kwargs(environment_0, namespace_0)[1]['chunk_size']) == RawStream.CHUNK_SIZE
    elif namespace_0.prettify:
        assert isinstance(get_stream_type_and_kwargs(environment_0, namespace_0)[0], PrettyStream)

# Generated at 2022-06-25 19:01:59.347778
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    try:
        environment_0 = Environment()
        args_0 = argparse.Namespace()
        tuple_0 = get_stream_type_and_kwargs(environment_0, args_0)
    except Exception as exception_0:
        print(exception_0)
try:
    from unittest import TestCase, main
    from unittest.mock import patch, MagicMock
except ImportError:
    from unittest import TestCase, main


# Generated at 2022-06-25 19:02:07.939143
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

import httpie.output.streams as module_0
import httpie.models
import httpie.output.processing
import typing as module_1
import httpie.output.streams
import typing
import httpie.output.processing as module_2


# Generated at 2022-06-25 19:02:12.206255
# Unit test for function write_stream
def test_write_stream():
    import io
    env = Environment()
    arg = argparse.Namespace(infile='file', outfile='file')
    arg.outfile = io.StringIO()
    stream = EncodedStream(env=env, chunk_size=1)
    write_stream(stream, arg.outfile, False)
    write_stream(stream, arg.outfile, True)


# Generated at 2022-06-25 19:02:16.296194
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    try:
        write_message(namespace_0, environment_0, namespace_0, namespace_0, namespace_0)
    finally:
        pass

# Generated at 2022-06-25 19:02:28.754030
# Unit test for function write_message
def test_write_message():
    # good case
    try:
        write_message(requests.PreparedRequest(), Environment(), argparse.Namespace())
        assert True
    except:
        assert False

    # bad case
    try:
        write_message("", Environment(), argparse.Namespace())
        assert False
    except:
        assert True

# Generated at 2022-06-25 19:02:29.816088
# Unit test for function write_stream
def test_write_stream():
    test_case_0()


# Generated at 2022-06-25 19:02:30.960056
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert test_case_0()

# Generated at 2022-06-25 19:02:42.713616
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test Case 0
    # Not stream, not forcing to JSON but prettify works
    print("test case 0")
    env = Environment(
        stream=False,
        force_stream=False,
        stdout_isatty=False,
        stdin_isatty=False,
        is_windows=False
    )
    args = argparse.Namespace(
        stream=False,
        force_stream=False,
        prettify=True
    )
    test_case_0()
    pretty_stream_class = PrettyStream if args.stream else BufferedPrettyStream

# Generated at 2022-06-25 19:02:52.458124
# Unit test for function write_stream
def test_write_stream():
    env_0 = Environment()
    env_0.stdout = sys.stdout
    env_0.stdout_isatty = True
    args_0 = argparse.Namespace()
    args_0.stream = True
    args_0.prettify = 'all'
    args_0.style = 'paraiso-dark'
    args_0.json = False
    args_0.format_options = {}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env_0, args=args_0)

    requests_message_0 = {}
    http_request_0 = HTTPRequest(requests_message_0)

# Generated at 2022-06-25 19:03:00.390254
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # function start
    if __name__ == '__main__':
        parser = argparse.ArgumentParser()
        parser.add_argument("-v", "--verbose", action="store_true",
                            help="increase output verbosity")
        parser.add_argument("-x", "--extend", action="store_true",
                            help="increase output verbosity")
        args = parser.parse_args()

        if args.verbose:
            print("verbosity turned on")
        elif args.extend:
            print("extend turned on")

        args.prettify = ['all']

        env = Environment()
        outfile = env.stdout


# Generated at 2022-06-25 19:03:12.065628
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    try:
        import requests
    except ImportError:
        print("Error: package \"requests\" not found")
        return
    try:
        import argparse
    except ImportError:
        print("Error: package \"argparse\" not found")
        return

    import httpie.models
    import httpie.output.streams

    from httpie.cli import parse_items
    from httpie.context import Environment
    from httpie.input import Params
    from httpie.output import initialize_output
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    from httpie.plugins import plugin_manager
    from httpie import ExitStatus
    from httpie.status import ExitStatus
    from httpie.output.processing import Conversion, Formatting

    import os
    import sys

# Generated at 2022-06-25 19:03:17.788188
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    cmd = ["http", "--pretty=all", "https://httpbin.org/get"]
    args = parser.parse_args(cmd)
    env = Environment(args)
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    # call function
    build_output_stream_for_message(args, env, requests_message,with_headers, with_body)
    # assert result
    assert True


# Generated at 2022-06-25 19:03:20.014805
# Unit test for function write_message
def test_write_message():
    print("Test of 'test_write_message'")
    try:
        assert test_case_0()
    except AssertionError:
        raise


# Generated at 2022-06-25 19:03:28.952782
# Unit test for function write_stream
def test_write_stream():
    requests_message = b'Hello World'
    env = Environment()
    env.stdout = sys.stdout.buffer
    args = argparse.Namespace()
    args.tty = True
    args.prettify = True
    args.stream = True
    args.style = True
    args.json = True
    args.format_options = True
    with_headers = True
    with_body = True
    write_message(
        requests_message,
        env,
        args,
        with_headers,
        with_body
    )

if __name__ == "__main__":
    test_case_0()
    test_write_stream()

# Generated at 2022-06-25 19:03:38.350201
# Unit test for function write_stream
def test_write_stream():
    class_0 = object()
    object_0 = object()
    object_0 = object()
    var_0 = write_stream(class_0, object_0, object_0)


# Generated at 2022-06-25 19:03:47.615389
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment("test_build_output_stream_for_message", "__main__")
    namespace_0 = module_1.Namespace("test", "test", "test", [])
    namespace_0.chunked = "test"
    namespace_0.download = "test"
    namespace_0.explain = "test"
    namespace_0.headers = "test"
    namespace_0.output_dir = "test"
    namespace_0.pretty = "test"
    namespace_0.style = "test"
    var_0 = build_output_stream_for_message(namespace_0, environment_0, "test", False, False)
    assert var_0 == None


# Generated at 2022-06-25 19:03:53.601264
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=environment_0,
        args=namespace_0
    )
    assert isinstance(stream_class, type)
    assert isinstance(stream_kwargs, dict)


# Generated at 2022-06-25 19:04:01.648252
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    message_class_0 = _internal_function_0()

    assert isinstance(message_class_0, type)

    for _ in range(9):
        stream_kwargs_0 = {}

        stream_class_0, stream_kwargs_1 = get_stream_type_and_kwargs(
            stream_kwargs_0,
            namespace_0,
        )

        var_0 = build_output_stream_for_message(
            args=namespace_0,
            stream_kwargs_0=stream_kwargs_0,
            env=environment_0,
            with_headers=namespace_0,
            with_body=namespace_0,
            requests_message=stream_kwargs_1,
        )


# Generated at 2022-06-25 19:04:04.663069
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    var_0, var_1 = get_stream_type_and_kwargs(environment_0, namespace_0)


# Generated at 2022-06-25 19:04:15.738275
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class_0 = module_0.Environment()
    class_1 = module_1.Namespace()
    class_2 = module_0.RawStream
    class_3 = module_0.PrettyStream
    class_4 = module_0.BufferedPrettyStream
    class_5 = module_0.EncodedStream
    class_6 = module_0.Conversion()
    class_7 = module_0.Formatting()
    class_8 = module_1.parse_known_args(args=['function', '--prettify'])
    class_9 = module_0.get_stream_type_and_kwargs(class_0, class_1)
    class_10 = module_0.get_stream_type_and_kwargs(class_1, class_1)
    class_11 = module_0.get_

# Generated at 2022-06-25 19:04:16.670884
# Unit test for function write_stream
def test_write_stream():
    """Test for function write_stream"""
    pass

# Generated at 2022-06-25 19:04:26.672528
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    namespace_0 = module_1.Namespace()
    currently_executing_script_directory_0 = ''
    var_0 = build_output_stream_for_message(namespace_0, currently_executing_script_directory_0, namespace_0, namespace_0, namespace_0)
    buffer_0 = StringIO()
    type_0 = type(buffer_0)
    boolean_0 = False
    var_0 = write_stream_with_colors_win_py3(var_0, buffer_0, boolean_0)
    boolean_0 = False
    var_0 = write_stream(var_0, buffer_0, boolean_0)



# Generated at 2022-06-25 19:04:38.322113
# Unit test for function write_message
def test_write_message():

    # do not record coverage for decorated function
    test_write_message._original_write_message = write_message
    @functools.wraps(write_message)
    def write_message_no_coverage(*args, **kwargs):
        return test_write_message._original_write_message(*args, **kwargs)
    import types
    write_message_no_coverage = types.ModuleType('httpie.output').write_message = write_message_no_coverage

    args = module_1.Namespace()
    args.json = None
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = None
    namespace_0.style = 'paraiso-dark'
    namespace_0.format_options = None
    namespace

# Generated at 2022-06-25 19:04:43.531106
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    file_open_0 = open()
    file_open_1 = open()
    var_0 = write_stream_with_colors_win_py3(file_open_0, file_open_1, namespace_0)

import httpie.output.streams as module_0


# Generated at 2022-06-25 19:04:53.631702
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_9 = Env()
    var_10 = Namespace()
    var_10.prettify = True
    var_10.stream = True
    var_11 = get_stream_type_and_kwargs(var_9, var_10)
    print(var_11)


# Generated at 2022-06-25 19:04:58.495198
# Unit test for function write_message
def test_write_message():
    var_0 = requests.Response()
    var_1 = Environment()
    var_2 = argparse.Namespace()
    var_3 = False
    var_4 = False
    var_5 = write_message(var_0, var_1, var_2, with_headers=var_3, with_body=var_4)


# Generated at 2022-06-25 19:05:01.572138
# Unit test for function write_message
def test_write_message():
    var_0 = build_output_stream_for_message(None, None, None, None, None)
    var_1 = write_stream(var_0, None, None)


# Generated at 2022-06-25 19:05:11.509232
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=False, stdin_isatty=False)
    args = argparse.Namespace(prettify=['all'])
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type == BufferedPrettyStream
    env = Environment(stdout_isatty=True, stdin_isatty=False)
    args = argparse.Namespace(prettify=['all'])
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type == PrettyStream
    env = Environment(stdout_isatty=False, stdin_isatty=False)
    args = argparse.Namespace(prettify=[])
    stream_type

# Generated at 2022-06-25 19:05:16.948772
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert type(get_stream_type_and_kwargs(object(), object())) == tuple, "Expected type of return value is tuple, but got %s" % type(get_stream_type_and_kwargs(object(), object()))
    assert len(get_stream_type_and_kwargs(object(), object())) == 2, "Expected length of return value is 2, but got %s" % len(get_stream_type_and_kwargs(object(), object()))


# Generated at 2022-06-25 19:05:28.736133
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment

    url = "http://www.google.com"
    # Prepare a GET request
    response = requests.get(url)
    args = argparse.Namespace()
    env = Environment()
    write_message(requests_message=response, env=env, args=args, with_body=True, with_headers=True)

    # Prepare a POST request
    args = argparse.Namespace(data={"name" : "admin", "password" : "12345"})
    response = requests.post(url, data=args.data)
    write_message(requests_message=response, env=env, args=args, with_body=True, with_headers=True)

test_build_output_stream_for_message()

# Generated at 2022-06-25 19:05:33.178058
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)
    var_6 = get_stream_type_and_kwargs(var_0, var_1)
    var_7 = var_6[0]
    var_8 = var_6[1]


# Generated at 2022-06-25 19:05:42.506872
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace(
    )

    class fake_PreparedRequest:
        def __init__(self, headers=None, body=None, content=None, is_body_upload_chunk=False):
            self.headers = headers
            self.body = body
            self.is_body_upload_chunk = is_body_upload_chunk
            if content:
                self.content = content
            else:
                raise AttributeError()

    class fake_Response:
        def __init__(self, headers=None, content=None, reason=None):
            self.headers = headers
            if content:
                self.content = content
            else:
                raise AttributeError()
            if reason:
                self.reason = reason
            else:
                raise AttributeError()



# Generated at 2022-06-25 19:05:45.500228
# Unit test for function write_message
def test_write_message():
    var_0 = var_1 = var_2 = var_3 = None
    var_4 = write_message(var_0, var_1, var_2, var_3)



# Generated at 2022-06-25 19:05:54.866017
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class dummy:
        def __init__(self, is_atty):
            self.stdout_isatty = is_atty

    env = dummy(is_atty=True)
    class dummy2:
        def __init__(self, prettify):
            self.prettify = prettify
            self.stream = False

    args = dummy2(prettify=False)
    class dummy3:
        def __init__(self, env, conversion, formatting):
            self.env = env
            self.conversion = conversion
            self.formatting = formatting
    class dummy4:
        def __init__(self, env):
            self.env = env

    res = get_stream_type_and_kwargs(env, args)
    assert(res[0]==dummy3)

# Generated at 2022-06-25 19:06:13.127822
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Python 3.8.0 (default, Oct 28 2019, 16:14:01)
    # [GCC 8.3.0] on linux
    # Type "help", "copyright", "credits" or "license" for more information.
    # input: 1, "write_stream_with_colors_win_py3"
    # output: hello
    import io
    import sys
    inp = sys.stdin
    inp.readline()
    i = 1
    str_1 = inp.readline()
    # Comment out the next line to test the program
    #sys.stdout.write(str(i) + ', ' + "write_stream_with_colors_win_py3") # print(str(i) + ', ' + "write_stream_with_colors_win_py3")

# Generated at 2022-06-25 19:06:17.172735
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class MockStream(object):
        def __iter__(self):
            return self
        def __next__(self):
            return 'next'
    class MockFile(object):
        pass
    var_0 = MockStream()
    var_1 = MockFile()
    var_2 = write_stream_with_colors_win_py3(var_0, var_1, var_0)
    assert var_2 is None

# Generated at 2022-06-25 19:06:26.820667
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    mocked_env = Environment(None, None, None, None, None, None, None, None)
    mocked_args = argparse.Namespace()
    mocked_args.prettify = None
    mocked_args.stream = None
    mocked_args.style = None
    mocked_args.json = None
    mocked_args.format_options = None
    mocked_args.debug = None
    mocked_args.traceback = None
    assert get_stream_type_and_kwargs(mocked_env, mocked_args) == (BufferedPrettyStream, {'env': mocked_env, 'conversion': Conversion(), 'formatting': Formatting(env=mocked_env, groups=None, color_scheme=None, explicit_json=None, format_options=None)})

    mocked_args = argparse.Namespace()
   

# Generated at 2022-06-25 19:06:36.176047
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    # Test that a bytes stream cannot be written to a non-binary output.
    with io.StringIO() as f:
        try:
            write_stream_with_colors_win_py3(
                stream=b'abc\n',
                outfile=f,
                flush=False
            )
        except TypeError:
            pass
        else:
            raise AssertionError

    # Test that a bytes stream can be written to a binary output.
    with io.BytesIO() as f:
        write_stream_with_colors_win_py3(
            stream=b'abc\n',
            outfile=f,
            flush=False
        )
        assert f.getvalue() == b'abc\n'

    # Test that text can be written to a text output

# Generated at 2022-06-25 19:06:38.568824
# Unit test for function write_stream
def test_write_stream():
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = write_stream(var_0, var_1, var_2)



# Generated at 2022-06-25 19:06:42.856813
# Unit test for function write_message
def test_write_message():
    # arg 0
    requests_message_0 = object()
    # arg 1
    env_0 = object()
    # arg 2
    args_0 = object()
    # arg 3
    with_headers_0 = object()
    # arg 4
    with_body_0 = object()
    # function call
    var_0 = write_message(requests_message_0, env_0, args_0, with_headers_0, with_body_0,)
    # assert
    assert var_0 is None


# Generated at 2022-06-25 19:06:45.794773
# Unit test for function write_message
def test_write_message():
    # Pass a requests.Response, a Environment, and an argparse.Namespace objects
    # Calls the function write_stream
    assert True, write_message(requests.Response(), Environment(), argparse.Namespace(), with_headers=False, with_body=False)


# Generated at 2022-06-25 19:06:46.318365
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    pass

# Generated at 2022-06-25 19:06:47.712474
# Unit test for function write_message
def test_write_message():
    var_0 = write_message(var_0, var_0, var_0)

# Generated at 2022-06-25 19:06:53.409839
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class DummyArgs:
        prettify = []
        stream = False
        style = "RESPONSE"
        json = False
    dummy_args = DummyArgs()
    class DummyEnv:
        stdout_isatty = False
    dummy_env = DummyEnv()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(dummy_env, dummy_args)
    assert(stream_class == RawStream)
    assert(stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE)

# Generated at 2022-06-25 19:07:09.586679
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = object()
    test_case_0()


# Generated at 2022-06-25 19:07:11.909738
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(colors=256, stdout_isatty=True)
    args = None
    var_0 = get_stream_type_and_kwargs(env, args)


# Generated at 2022-06-25 19:07:21.206536
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # Setup for test
    import httpie
    import requests
    from httpie.cli import parser
    from httpie import ExitStatus
    from tests import httpbin
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream

    args = parser.parse_args(args=[])
    args.pretty = True
    args.stream = False
    env = Environment(stdin=None,
                      stdout=None,
                      stderr=None,
                      verify=True,
                      trust_env=True,
                      config_dir=None)
    env.config['default_options'] = []
    env.config['__alt_env'] = {}
    env.config['style'] = 'None'
    env.config['colors'] = 256
    env.config['theme'] = 'default'


# Generated at 2022-06-25 19:07:32.414947
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Mock import 'sys' from builtins
    builtins_name_1 = 'builtins'
    builtins_obj_1 = MockBuiltins(builtins_name_1)
    sys_name_1 = 'sys'
    sys_obj_1 = MockSysModule(sys_name_1)
    builtins_obj_1.import_module(sys_name_1, sys_obj_1)

    # Mock import 'httpie.constants' from 'httpie'
    httpie_name_1 = 'httpie'
    httpie_obj_1 = MockHttpieModule(httpie_name_1)
    constants_name_1 = 'constants'
    constants_obj_1 = MockHttpieConstantsModule(constants_name_1)

# Generated at 2022-06-25 19:07:43.704646
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import json
    import requests
    import tempfile
    url = 'http://httpbin.org/'
    r = requests.get(url)
    r.url = url
    env = Environment()
    env.stdout_isatty = True
    with tempfile.TemporaryFile() as f:
        env.stdout = f
        env.stderr = f
        args = argparse.Namespace()
        args.prettify = 'all'
        args.style = 'default'
        args.stream = True
        args.format_options = json.loads('{}')
        args.json = False
        args.debug = False
        args.traceback = False
        stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
        stream = build_output_stream

# Generated at 2022-06-25 19:07:46.221576
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = object()
    var_1 = write_message(var_0, var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 19:07:56.531509
# Unit test for function write_stream
def test_write_stream():
    import httpie.context
    var_0 = object()
    var_1 = httpie.context.Environment(
        stdout_isatty=True,
        stdin_isatty=True,
        is_windows=True,
        colors=256,
        stdout=object(),
        stdin=object()
    )
    var_2 = argparse.Namespace(
        debug=False,
        download=False,
        follow=False,
        style=None,
        stream=True,
        output_file='',
        prettify=None,
        traceback=False,
        json=False,
        format_options={},
        verify=True,
        proxies={}
    )

# Generated at 2022-06-25 19:07:59.405471
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    with StringIO() as var_0:
        write_stream_with_colors_win_py3(object(), var_0, var_0)



# Generated at 2022-06-25 19:08:10.520570
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment()
    var_0 = argparse.Namespace()

    var_0.prettify = ['colors']
    var_0.stream = False
    var_0.style = 'paraiso-dark'
    var_0.json = False
    var_0.format_options = {}
    env_0.isatty_out = False
    var_1 = get_stream_type_and_kwargs(env_0, var_0)
    assert var_1 == (RawStream, {'chunk_size': 4096})

    var_0.prettify = ['colors', 'format']
    var_0.stream = True
    var_0.style = 'paraiso-dark'
    var_0.json = False

# Generated at 2022-06-25 19:08:12.684172
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = object()
    var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)


# Generated at 2022-06-25 19:08:51.201457
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass

# Generated at 2022-06-25 19:08:59.802768
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-25 19:09:11.515565
# Unit test for function write_message
def test_write_message():
    print("Test for function write_message")

    message_separator_bytes = MESSAGE_SEPARATOR.encode()
    requests_prepared_request = requests.session()
    args = argparse.Namespace()
    args.prettify = ["colors", "format", "filter"]
    args.stream = False
    args.style = "solarized"
    args.format_options = [("k", "v"), ("k2", "v2")]
    args.json = False
    args.debug = False
    args.traceback = False
    args.download = False

    env = Environment()
    env.stdout = write_stream(var_0, var_0, var_0)
    env.stdout_isatty = True
    env.is_windows = False


# Generated at 2022-06-25 19:09:16.069861
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment()
    var_1 = argparse.Namespace()
    test_case_get_stream_type_and_kwargs_0(var_0, var_1)


# Generated at 2022-06-25 19:09:26.554232
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, RawStream, EncodedStream

    kwargs = {}

    # Case 0
    env = {'stdout_isatty':True, 'is_windows': False}
    args = {'prettify':False, 'stream':True}
    result = get_stream_type_and_kwargs(env, args)
    assert result == (PrettyStream, kwargs)

    # Case 1
    env = {'stdout_isatty':True, 'is_windows': False}
    args = {'prettify':True, 'stream':True}
    result = get_stream_type_and_kwargs(env, args)
    assert result == (PrettyStream, kwargs)

    # Case 2

# Generated at 2022-06-25 19:09:28.816127
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = object()
    var_1 = object()
    var_2 = get_stream_type_and_kwargs(var_0, var_1)


# Generated at 2022-06-25 19:09:35.750029
# Unit test for function write_message
def test_write_message():
    from unittest import TestCase
    from unittest import mock
    import requests
    import pytest
    import httpie

    class MockTestCase(TestCase):
        def test_write_message(self):
            mock_requests_message = mock.MagicMock()
            mock_env = mock.MagicMock()
            mock_args = mock.MagicMock()
            mock_with_headers = mock.MagicMock()
            mock_with_body = mock.MagicMock()
            self.assertEqual(httpie.output.write.write_message(mock_requests_message,
                                                               mock_env,
                                                               mock_args,
                                                               mock_with_headers,
                                                               mock_with_body),
                             None)


# Generated at 2022-06-25 19:09:39.244689
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_9 = test_case_0
    var_10 = get_stream_type_and_kwargs(var_9, var_9)
    assert var_10[0] == EncodedStream
    assert var_10[1] is not None

# Generated at 2022-06-25 19:09:49.926730
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import copy
    import inspect
    import sys
    import unittest

    from httpie.context import Environment
    from httpie.models import FormatOptions
    from httpie.output.processing import Conversion
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, PrettyStream, RawStream

    from .base import get_stream_type_and_kwargs

    class TestGetStreamTypeAndKwargs(unittest.TestCase):

        def test_get_stream_type_and_kwargs(self):
            # Test number: 0
            env = Environment(
                colors=True,
                is_windows=True,
                stdout_isatty=True,
            )

# Generated at 2022-06-25 19:09:55.072214
# Unit test for function write_message
def test_write_message():
    var_0 = object()
    var_1 = object()
    var_2 = object()
    var_3 = object()
    var_4 = object()
    var_5 = object()
    var_6 = object()
    var_7 = object()
    try:
        write_message(var_0, var_1, var_2, var_3, var_4)
        write_message(var_5, var_6, var_7)
    except IOError:
        ret_0 = IOError()
    else:
        ret_1 = False
    finally:
        ret_0 = None

