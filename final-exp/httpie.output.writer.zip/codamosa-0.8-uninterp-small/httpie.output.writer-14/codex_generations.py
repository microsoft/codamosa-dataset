

# Generated at 2022-06-25 18:59:59.731951
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    io.StringIO()
    test_arg_0 = io.StringIO()
    test_arg_1 = True
    write_stream_with_colors_win_py3(test_arg_0, test_arg_1)

import httpie.context as module_0


# Generated at 2022-06-25 19:00:10.259018
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPResponse
    from httpie.context import Environment
    from httpie.output.formatting import Formatting
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    args_0 = {"file": StringIO(), "encoding": None, "errors": "strict", "newline": None, "line_buffering": False}
    environment_0.stdout = StringIO(**args_0)
    namespace_0.prettify = ["colors"]
    namespace_0.debug = False
    namespace_0.traceback = False
    outfile_0 = StringIO(**args_0)

# Generated at 2022-06-25 19:00:13.610818
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = module_0.RawStream(b'<!doctype html>', True, True)
    import sys as module_3
    write_stream_with_colors_win_py3(stream, module_3.stdout, False)

# Generated at 2022-06-25 19:00:19.960572
# Unit test for function write_message
def test_write_message():
    # Test arguments
    filename = "foo.txt"

    # Test function call (asserts)
    with open(filename, "w") as f:
        this_file_path = os.path.abspath(f.name)
        print(this_file_path)

# Generated at 2022-06-25 19:00:32.238332
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import ExitStatus

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    mock_args = argparse.Namespace()
    mock_args.debug = False
    mock_args.download = False
    mock_args.follow = False
    mock_args.max_redirects = 10
    mock_args.output_dir = None
    mock_args.output_file = None
    mock_args.prettify = set()
    mock_args.print_body_only = False
    mock_args.print_headers_only = False
    mock_args.print_method = False
    mock_args.raw_body = False
    mock_args.single_request = False
    mock_args.stream = False
    mock_args.style = 'default'

# Generated at 2022-06-25 19:00:39.225735
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    try:
        requests.Response()
    except:
        requests_message = None
    else:
        requests_message = requests.Response()
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = None
    namespace_0.format_options = {}
    namespace_0.json = False
    namespace_0.stream = False
    namespace_0.style = '{}'
    try:
        build_output_stream_for_message(namespace_0, environment_0, requests_message, False, False)
    except SystemExit:
        pass
    else:
        raise Exception('Returned success instead of failure')

if __name__ == '__main__':
    test_case_0()
    test_build_output_stream_

# Generated at 2022-06-25 19:00:49.288462
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.traceback = bool(0)
    namespace_0.debug = bool(0)
    namespace_0.stream = bool(0)
    namespace_0.prettify = ('colors')
    namespace_0.style = ('paraiso-dark')
    namespace_0.json = bool(0)
    namespace_0.format_options = {}
    namespace_0.auth = tuple([])
    namespace_0.auth_type = ('basic')
    namespace_0.force_basic_auth = bool(0)
    namespace_0.proxy = tuple([])
    namespace_0.traceback = bool(0)
    namespace_0.debug = bool(0)

# Generated at 2022-06-25 19:00:59.992575
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = httpie.context.Environment()
    namespace_4 = module_1.Namespace()
    assert get_stream_type_and_kwargs(environment_0, namespace_4) == (httpie.output.streams.EncodedStream, {
        'env': environment_0
    })
    namespace_4 = argparse.Namespace()
    namespace_4.prettify = []
    namespace_4.stream = False
    assert get_stream_type_and_kwargs(environment_0, namespace_4)[0] == httpie.output.streams.BufferedPrettyStream
    assert get_stream_type_and_kwargs(environment_0, namespace_4)[1]['formatting'].color_scheme == 'default'
    namespace_4 = argparse.Namespace()
    namespace_4.prett

# Generated at 2022-06-25 19:01:00.620592
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(None, None, None) is None


# Generated at 2022-06-25 19:01:06.430270
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    arg_0 = namespace_0
    arg_1 = environment_0
    arg_2 = HTTPRequest
    arg_3 = True
    arg_4 = True

# Generated at 2022-06-25 19:01:22.349542
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class class_0:
        class class_1:
            def function_0(self, chunk_size):
                ...
            function_0 = staticmethod(function_0)
        class_1 = class_1()
        class_2: bool = None

    namespace_1 = module_0.Namespace()
    namespace_1.is_windows = False
    namespace_1.isatty = True
    namespace_1.stdout_isatty = True
    namespace_1.prettify = []
    namespace_1.stream = False
    namespace_1.style = None
    namespace_1.json = None
    namespace_1.format_options = []
    namespace_0 = class_0()
    namespace_0.isatty = True
    namespace_0.stdout_isatty = True
    namespace_0

# Generated at 2022-06-25 19:01:30.605260
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    namespace_0 = module_0.Namespace()
    namespace_1 = module_0.Namespace()
    namespace_1.stream = False
    namespace_1.prettify = set()
    namespace_2 = module_0.Namespace()
    namespace_3 = module_0.Namespace()
    namespace_3.stream = True
    namespace_3.prettify = {"all"}
    namespace_3.format_options = {"colors": True}
    namespace_4 = module_0.Namespace()
    namespace_4.stream = True
    namespace_4.prettify = {"all"}
    namespace_4.format_options = {"colors": True}
    namespace_5 = module_0.Namespace()
    stream = namespace_0
    outfile = namespace_1
    flush = namespace_2
    #

# Generated at 2022-06-25 19:01:32.549077
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = get_stream_type_and_kwargs(Environment(), namespace_0)
    print(env_0)

# Generated at 2022-06-25 19:01:34.989553
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(None, None) == (None, None)


# Generated at 2022-06-25 19:01:39.295488
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = ''
    args = ''
    result = get_stream_type_and_kwargs(env, args)

    assert result[0] == ''
    assert result[1] == ''



# Generated at 2022-06-25 19:01:47.903129
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment()
    namespace_0 = argparse.Namespace()
    namespace_0.prettify = None
    namespace_0.stream = None
    namespace_0.style = None
    namespace_0.json = None
    namespace_0.format_options = None
    env_0.stdout_isatty = None
    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(env_0, namespace_0)
    assert stream_class == RawStream

    env_0.stdout_isatty = True
    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(env_0, namespace_0)
    assert (stream_class, stream_kwargs['formatting'].palettes) == (BufferedPrettyStream, None)



# Generated at 2022-06-25 19:01:49.876317
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment = context.Environment()
    namespace = argparse.Namespace()
    get_stream_type_and_kwargs(environment, namespace)

# Generated at 2022-06-25 19:01:50.774772
# Unit test for function write_stream
def test_write_stream():
    assert True == True


# Generated at 2022-06-25 19:01:56.123552
# Unit test for function write_message
def test_write_message():
    namespace_0 = module_0()
    import requests as module_1
    requests_message_0 = module_1.PreparedRequest()
    env_0 = Environment()
    write_message(requests_message_0, env_0, namespace_0, with_headers=False, with_body=False)

# Generated at 2022-06-25 19:01:58.095096
# Unit test for function write_message
def test_write_message():
    assert write_message('requests_message', 'env', 'args', 'with_headers', 'with_body') == None


# Generated at 2022-06-25 19:02:07.471706
# Unit test for function write_stream
def test_write_stream():
    with HTTMock(mock_response):
        response = requests.get("http://example.com")
        response_status = response.status_code
        assert response_status == 200

# Test mock for write_stream

# Generated at 2022-06-25 19:02:08.483386
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert 1 == 1


# Generated at 2022-06-25 19:02:10.527569
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = write_stream(var_0, var_0, var_0)


# Generated at 2022-06-25 19:02:21.636982
# Unit test for function write_message
def test_write_message():

    # Test that the function returns and the output matches the expected
    # output at the right time.

    var_1 = Environment()
    var_1.stdout = sys.stdout
    var_1.stderr = sys.stderr
    var_1.is_windows = True
    var_1.stdout_isatty = True
    var_1.stdin_isatty = True
    var_1.colors = 256
    
    var_2 = argparse.Namespace
    var_2.prettify = None
    var_2.debug = False
    var_2.traceback = False
    var_2.stream = False
    var_2.style = None

    var_3 = requests.Response()
    var_3.headers = {'Connection': 'close'}

    var_4

# Generated at 2022-06-25 19:02:26.361131
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:02:27.582112
# Unit test for function write_stream
def test_write_stream():
    func = write_stream
    test_0(func)


# Generated at 2022-06-25 19:02:33.748061
# Unit test for function write_message
def test_write_message():
    var_2 = Environment()
    var_3 = argparse.Namespace()
    var_4 = None
    var_5 = True
    var_6 = True
    try:
        expected = None
        actual = write_message(var_2, var_3, var_4, var_5, var_6)
        assert expected == actual
    except Exception as e:
        assert False


# Generated at 2022-06-25 19:02:36.415433
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = None
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    stream_class == EncodedStream



# Generated at 2022-06-25 19:02:46.867218
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment()
    var_0.stdout_isatty = False
    class argparse:
        class Namespace:
            prettify = False
            stream = False

    # Return type annotation
    var_3: dict = dict()
    # Return type annotation
    var_1: Type['BaseStream'] = BaseStream
    var_2 = get_stream_type_and_kwargs(var_0, var_1)
    assert isinstance(var_2, tuple)
    assert issubclass(var_2[0], BaseStream)
    assert var_2[1] == var_3

    var_3['env'] = var_0
    var_3['chunk_size'] = var_0

    var_0.prettify = True
    var_0.stream = True

# Generated at 2022-06-25 19:02:57.069789
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_2 = os.getenv('VIRTUAL_ENV')
    if var_2:
        exit()
    else:
        var_3 = argparse.Namespace(debug=None, download=False,
            print_headers=False, prettify=None, print_body=False,
            style='default', traceback=False, stream=True,
            format_options={}, json=False, quiet=False, verbose=False,
            headers=[])

# Generated at 2022-06-25 19:03:11.328745
# Unit test for function write_stream
def test_write_stream():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = write_stream(var_1, var_2, var_3)



# Generated at 2022-06-25 19:03:13.932111
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
	env = Environment()
	args = (None, None)
	assert (get_stream_type_and_kwargs(env, args) == 1)


# Generated at 2022-06-25 19:03:18.314528
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(prettify=None, stream=False, style=None)
    env = Environment()
    result = get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-25 19:03:22.489678
# Unit test for function write_message
def test_write_message():

    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    
    write_message(requests_message, env, args, with_headers, with_body)


# Generated at 2022-06-25 19:03:26.657689
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    env = Environment()
    requests_message = None
    with_headers = True
    with_body = True
    var_0 = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)


# Generated at 2022-06-25 19:03:37.527317
# Unit test for function write_message
def test_write_message():
    var_0 = requests.PreparedRequest()
    var_0.body = b'{"q":"foo"}'
    var_0.headers = {'Content-Type': 'application/json', 'Accept': '*/*'}
    var_0.method = 'GET'
    var_0.url = 'https://httpbin.org/anything'

    var_1 = requests.Response()
    var_1.status_code = 200
    var_1.url = 'https://httpbin.org/anything'

# Generated at 2022-06-25 19:03:38.396973
# Unit test for function write_stream
def test_write_stream():
    assert test_case_0() == None

# Generated at 2022-06-25 19:03:45.996617
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = type(var_0)
    var_2 = requests.Request
    var_3 = requests.Response
    var_4 = requests.Request
    var_5 = (var_2 == var_3)
    var_6 = (var_3 == var_4)
    var_7 = (var_5 or var_6)
    var_8 = 1
    var_9 = (var_7 and var_8)
    if (var_1 == var_9):
        write_message(var_0, var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 19:03:50.871088
# Unit test for function write_stream
def test_write_stream():
    print('Testing write_stream')

    to_test = ['python', 'python', 'python', 'python', 'python']

    # Test if args present
    assert write_stream(to_test, to_test, to_test)



# Generated at 2022-06-25 19:03:59.392271
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = MagicMock()
    env = MagicMock()
    requests_message = MagicMock()
    with_headers = MagicMock()
    with_body = MagicMock()

    # Call build_output_stream_for_message
    result = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_headers=with_headers,
        with_body=with_body
    )

    # Assert side effects
    write_stream.assert_called_once_with(
        stream=result,
        outfile=env.stdout,
        flush=env.stdout_isatty or args.stream
    )

    # Return type
    assert type(result) == type(None)



# Generated at 2022-06-25 19:04:17.110789
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import json
    import requests
    import responses

    from httpie.input import ParseError
    from httpie.cli import parser
    from tests import http, HTTP_OK

    args = parser.parse_args(args=[], env=Environment())
    args.json = None
    args.prettify = False
    args.stream = False
    args.style = None
    args.upload = False
    args.verbose = True
    args.version = True

    response = http('GET', httpbin.url + '/get')
    assert HTTP_OK in response
    assert MESSAGE_SEPARATOR_BYTES not in response

    response = http('GET', httpbin.url + '/get',
                    env=Environment(stdout_isatty=False))
    assert HTTP_OK in response
    assert MESSAGE_

# Generated at 2022-06-25 19:04:25.816272
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment(var_0, var_0, var_0)
    var_1 = argparse.Namespace(var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = get_stream_type_and_kwargs(var_0, var_1)
    assert isinstance(var_2, tuple)
    assert isinstance(var_2[0], type)
    assert isinstance(var_2[1], dict)


# Generated at 2022-06-25 19:04:29.575335
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Prepare arguments
    stream = None
    outfile = None
    flush = None

    # Execute the function
    try:
        write_stream_with_colors_win_py3(stream, outfile, flush)
    except TypeError as e:
        pass
    assert False

# Generated at 2022-06-25 19:04:40.002977
# Unit test for function write_message
def test_write_message():
    parsed_args = {
        '--body': False,
        '--download': False,
        '--form': False,
        '--headers': False,
        '--output': None,
        '--pretty': 'all',
        '--style': None,
        '--verbose': False,
        '--verify': True,
        '<url>': 'http://httpbin.org/post',
        'data': None,
        'files': {},
        'headers': {},
        'method': 'POST',
        'params': {},
        'stdin': None,
        'timeout': None
    }

    # test class Environment
    parsed_args['output_file'] = None
    parsed_args['stdin'] = "test case"

# Generated at 2022-06-25 19:04:48.887050
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test fixture -------------------------------------------------------------
    import mock
    import tempfile
    import sys

    if sys.version_info < (3, 0):
        return

    # Fixture ---------------------------------------------------------
    outfile = tempfile.TemporaryFile()

    # Test case data -----------------------------------------------------

# Generated at 2022-06-25 19:04:56.844906
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    args = argparse.Namespace()
    args.prettify = 'none'
    args.style = 'none'
    args.json = False
    args.format_options = None
    fake_env = Environment(
        stdin=None,
        stdout=None,
        stdout_isatty=False,
        stderr=None,
        color=True,
        is_windows=False,
        is_aix=False,
        format=''
    )
    var_0 = None
    var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)

# Generated at 2022-06-25 19:04:59.939091
# Unit test for function write_message
def test_write_message():
    var_0 = None
    var_1 = None
    var_2 = True
    var_3 = True
    var_4 = write_message(var_0, var_1, var_2, var_3, var_3)


# Generated at 2022-06-25 19:05:06.002008
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = argparse.Namespace(var_0, var_0, var_0, var_0, var_0, var_0)
    var_2, var_3 = get_stream_type_and_kwargs(var_0, var_1)


# Generated at 2022-06-25 19:05:09.215106
# Unit test for function write_message
def test_write_message():
    var_2 = None
    var_3 = None
    var_4 = None
    var_4 = write_message(var_2, var_2, var_2, var_2, var_2)
    return var_4


# Generated at 2022-06-25 19:05:11.950795
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        # Testing the function with example input.

        write_stream_with_colors_win_py3(None, None, None)
    except Exception as e:
        raise e


# Generated at 2022-06-25 19:05:32.657348
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(0) == 0


# Generated at 2022-06-25 19:05:33.978072
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Python 3.8 on Windows
    assert True

# Generated at 2022-06-25 19:05:36.271309
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)


# Generated at 2022-06-25 19:05:38.903526
# Unit test for function write_stream
def test_write_stream():
    try:
        assert callable(
          write_stream)
    except:
        print('AssertionError, write_stream is not callable')


# Generated at 2022-06-25 19:05:44.426197
# Unit test for function write_stream
def test_write_stream():
    outfile_0 = BytesIO()
    outfile_0.write(b'\n')
    outfile_1 = outfile_0.getvalue()
    assert outfile_0.closed is False
    assert outfile_1 == b'\n'
    stream_0 = RawStream(chunk_size=var_3)
    assert stream_0.is_chunked() is False
    stream_0.write_headers(var_4, var_5)
    outfile_0.close()



# Generated at 2022-06-25 19:05:48.174384
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)



# Generated at 2022-06-25 19:05:57.917187
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Prepare mocks
    mock_args = Mock()
    mock_env = Mock()
    mock_requests_message = Mock()
    mock_with_headers = Mock()
    mock_with_body = Mock()

    mock_args.prettify = None
    mock_args.stream = False
    mock_args.debug = False
    mock_args.traceback = False
    mock_env.stdout_isatty = False
    mock_env.is_windows = True
    mock_env.stderr.write = Mock()

    # Execute
    result = build_output_stream_for_message(mock_args, mock_env, mock_requests_message, mock_with_headers, mock_with_body)

    # Assert
    assert result == None

# Generated at 2022-06-25 19:06:09.522290
# Unit test for function write_message
def test_write_message():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None

# Generated at 2022-06-25 19:06:14.025186
# Unit test for function write_stream
def test_write_stream():

    # Prepare the input values
    requests_message = None
    env = None
    args = None
    with_headers = None
    with_body = None

    # Execute the function
    var_0 = write_stream(requests_message, env, args, with_headers, with_body)

    # Prepare the expected output values
    expected = None

    # Execute the assertions
    assert var_0 == expected



# Generated at 2022-06-25 19:06:19.864826
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:07:11.590662
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-25 19:07:15.492637
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = (var_0, var_1)
    var_3 = write_stream_with_colors_win_py3(*var_2)


# Generated at 2022-06-25 19:07:19.414415
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = None
    var_0 = None
    var_1 = get_stream_type_and_kwargs(var_0, var_0)
    var_2, var_3 = var_1
    assert var_2 == None
    assert var_3 == None


# Generated at 2022-06-25 19:07:31.235031
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import mock
    import httpie.output

    # Set up mock objects
    class mock_BaseStream(object):
        def __init__(self, msg, with_headers, with_body, **stream_kwargs):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body

        def __iter__(self):
            yield "o"

    mock_args = mock.Mock(prettify='border')
    mock_env = mock.Mock(stdout_isatty=False)
    mock_request = mock.Mock()
    mock_request.is_body_upload_chunk = False

    httpie.output.RawStream = mock_BaseStream

# Generated at 2022-06-25 19:07:42.761406
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from io import TextIOWrapper, BytesIO

    import os
    import sys
    from requests import Response

    from httpie.output.streams import PrettyStream
    from httpie.output.formatters import JSONHTTPieFormatter
    from httpie.output.formatters import Formatter
    from httpie.compat import urllib3
    from httpie.core import status_codes

    from httpie.output.formatters.default import DEFAULT_FORMATTERS
    from httpie.output.formatters.colors import COLOR_SCHEMES
    from httpie.compat import py26, py27, bytes

    # TODO: Test args with fake sys.stdout, bytesio, and pipe.
    if sys.version_info >= (3, 3):
        import unittest.mock as mock

# Generated at 2022-06-25 19:07:45.919248
# Unit test for function write_message
def test_write_message():
    var_0 = None
    var_1 = dummy_fun_call()
    var_2 = dummy_fun_call()
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 19:07:53.681891
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        argv=[],
        headers=[],
        request_data=[],
        request_method='',
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
        json_encoder=None,
        json_decoder=None,
    )

# Generated at 2022-06-25 19:08:01.070527
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = {
        'json': False,
        'prettify': None,
        'stream': False,
        'style': None,
        'traceback': False,
    }
    var_1 = Environment()
    var_1.is_windows = False
    var_1.stdout_isatty = False
    var_2 = None
    var_3 = False
    var_4 = False
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)



# Generated at 2022-06-25 19:08:12.208267
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from requests import PreparedRequest
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    
    var_0 = None
    var_1 = PreparedRequest()
    var_2 = True
    var_3 = True
    var_4 = build_output_stream_for_message(var_0, var_0, var_1, var_2, var_3)
    assert isinstance(var_4, PrettyStream)
    assert isinstance(var_4.msg, HTTPRequest)
    assert var_4.msg.method == 'GET'
    assert var_4.msg.url == 'http://localhost/'
    assert var_4.msg.headers == []
    assert var_4.msg.body == ''
    assert var_4.with_headers == True
    assert var_

# Generated at 2022-06-25 19:08:14.383183
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)
