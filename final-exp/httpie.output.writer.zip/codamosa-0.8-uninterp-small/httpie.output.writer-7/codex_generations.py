

# Generated at 2022-06-25 19:00:05.149019
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_0 = None
    outfile_0 = None
    assert (write_stream_with_colors_win_py3(stream_0, outfile_0, False) is None)


# Generated at 2022-06-25 19:00:17.117386
# Unit test for function write_message
def test_write_message():
    environment_0 = Environment()
    namespace_0 = module_0.Namespace(cookies=None, debug=None, download=None, verbose=None, style='', headers=None, traceback=None, output=True, json=None, max_redirects=None, verify=True, timeout=None, data=None, output_file=None, files=None, session=None, auth=None, method=None, prettify='all', pretty=None, streaming=None, stream=None, upload=None, proxies=None, output_options=None, file_compression=None, form=None, style_sheet=None, format_options=None)
    request_0 = None
    http_message_0 = None
    write_message(http_message_0, environment_0, namespace_0, True, False)

# Generated at 2022-06-25 19:00:18.033816
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:00:30.584506
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    try:
        assert callable(get_stream_type_and_kwargs)
    except:
        print('Function "get_stream_type_and_kwargs" is not callable.')
        raise

    import argparse as module_0
    try:
        assert isinstance(module_0, module)
    except:
        print('No module named "argparse".')
        raise
    try:
        assert isinstance(module_0.Namespace(), module_0.Namespace)
    except:
        print('No class "Namespace" defined in "argparse".')
        raise
    try:
        assert isinstance(module_0.Namespace(), argparse.Namespace)
    except:
        print('Could not import class "Namespace" from "argparse".')
        raise

    namespace_0 = module_0

# Generated at 2022-06-25 19:00:33.284105
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = Environment(None, None)
    namespace_0 = module_0.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)


# Generated at 2022-06-25 19:00:40.831156
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
	environment_0 = None
	namespace_0 = module_0.Namespace(**{"is_windows": False, "prettify": "colors", "stream": False, "stdout_isatty": True})
	requests_message_0 = requests.PreparedRequest()
	write_message(requests_message_0, environment_0, namespace_0, args=(requests_message_0, environment_0, namespace_0, False, True), with_body=args[4], with_headers=args[3])


# Generated at 2022-06-25 19:00:50.987309
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import argparse as module_0
    import httpie.output.streams as module_1
    import httpie.output.streams as module_2
    import httpie.output.streams as module_3
    class Class0:
        def __init__(self, ):
            self.stdout_isatty = False
            self.stderr_isatty = False
    class Class1:
        def __init__(self, ):
            self.stdout_isatty = True
            self.stderr_isatty = True
    class Class2:
        def __init__(self, ):
            self.stdout_isatty = False
            self.stderr_isatty = True
    class Class3:
        def __init__(self, ):
            self.stdout_isatty

# Generated at 2022-06-25 19:00:56.194152
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    ### Given
    environment_1 = None
    namespace_0 = module_0.Namespace()

# Generated at 2022-06-25 19:01:00.205813
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    try:
        write_message(requests_message, env, args, False, False)
    except Exception:
        raise AssertionError('write_message raised an exception')


# Generated at 2022-06-25 19:01:03.021884
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_0 = {}
    environment_0 = None
    namespace_0 = module_0.Namespace()
    write_message(requests_message_0, environment_0, namespace_0, True, True)


# Generated at 2022-06-25 19:01:12.522394
# Unit test for function write_message
def test_write_message():
    environment_0 = None
    namespace_0 = module_0.Namespace()
    dict_0 = dict()
    dict_0['with_body'] = False
    dict_0['with_headers'] = False
    write_message(environment_0, namespace_0, dict_0)


# Generated at 2022-06-25 19:01:13.540811
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Placeholder for test
    return


# Generated at 2022-06-25 19:01:23.073213
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    global get_stream_type_and_kwargs
    # AssertionError: (builtins.AssertionError) expected:<class 'httpie.output.streams.RawStream'> actual:<class 'httpie.output.streams.EncodedStream'>

# Generated at 2022-06-25 19:01:25.647980
# Unit test for function write_stream
def test_write_stream():
    stream_0 = None # should fail
    outfile_0 = None # should fail
    flush_0 = None # should fail
    write_stream(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:01:27.447493
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert build_output_stream_for_message() # TODO: may fail if no arguments are provided; specify function arguments in call


# Generated at 2022-06-25 19:01:32.466068
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = None
    namespace_0 = module_0.Namespace()
    stream_0 = None
    outfile_0 = None
    flush_0 = None
    write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:01:43.313374
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    namespace_0 = module_0.Namespace()
    environment_1 = None
    namespace_0.stream = None
    namespace_0.disable_colors = None
    namespace_0.stream = None
    namespace_0.download = None
    namespace_0.download = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None
    namespace_0.style = None

# Generated at 2022-06-25 19:01:52.932195
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from unittest import mock

    environment_0 = mock.Mock()
    environment_0.stdout_isatty = True
    namespace_0 = mock.Mock()
    namespace_0.prettify = None
    namespace_0.stream = False
    namespace_0.style = 'solarized-dark'
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] is EncodedStream
    assert tuple_0[1]['env'] is environment_0
    environment_0 = mock.Mock()
    environment_0.stdout_isatty = False
    namespace_0 = mock.Mock()
    namespace_0.prettify = None
    namespace_0.stream = False

# Generated at 2022-06-25 19:02:02.344936
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_0.Namespace()
    namespace_0.prettify = ['b']
    namespace_0.style = None
    namespace_0.json = False
    namespace_0.stream = False
    namespace_0.debug = False
    namespace_0.traceback = False
    namespace_0.format_options = None
    environment_0 = Environment(stdout=None, stdout_isatty=False, stdin_isatty=False, stdin=None, args=namespace_0)
    requests_0 = requests.PreparedRequest()
    requests_0.is_body_upload_chunk = True
    bool_0 = False
    bool_1 = True

# Generated at 2022-06-25 19:02:12.787344
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_0 = requests.request
    environment_0 = None
    namespace_0 = module_0.Namespace()
    call_yield_from_0 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, False, False)
    call_yield_from_1 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, True, False)
    call_yield_from_2 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, False, True)
    call_yield_from_3 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, True, True)


# Generated at 2022-06-25 19:02:18.643713
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass  # Automatic test

# Generated at 2022-06-25 19:02:19.890153
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:02:23.325106
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream_with_colors_win_py3(var_0, var_1, var_2)


# Generated at 2022-06-25 19:02:33.078622
# Unit test for function write_stream
def test_write_stream():
    var_5 = None
    var___bases____tuple__1 = ()
    var___class__ = type(
        'BaseStream',
        var___bases____tuple__1,
        {
        },
    )
    var_6 = None
    var_6 = var___class__()
    var_7 = None
    var_7 = None
    var_8 = None
    var_8 = var_6
    var_6 = var_8
    var_9 = None
    var_9 = var_6
    var_10 = None
    var_10 = write_stream(var_9, var_7, var_10)


# Generated at 2022-06-25 19:02:38.258798
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message = "Request"
    env = "Environment"
    args = "Arguments"
    with_headers = True
    with_body = False
    var_0 = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)
    assert var_0 is None


# Generated at 2022-06-25 19:02:48.162640
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(config=None)
    args = argparse.Namespace()
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type == RawStream
    assert stream_kwargs == {
        'chunk_size': 2048,
    }
    args.prettify = ['all']
    args.json = True
    env.stdout.isatty=True
    args.stream = True
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type == PrettyStream

# Generated at 2022-06-25 19:02:50.862046
# Unit test for function write_stream
def test_write_stream():
    var_0 = None
    var_1 = write_stream(var_0, var_0, var_0)


# Generated at 2022-06-25 19:02:56.047079
# Unit test for function write_stream
def test_write_stream():
    from httpie.output import streams

    case_0 = test_case_0
    case_1 = test_case_1

    stream = streams.RawStream(var_0, var_1, var_2)
    outfile = var_0
    flush = var_1
    case_0(stream, outfile, flush)
    env = var_0
    case_1(stream, outfile, flush)


# Generated at 2022-06-25 19:02:59.034673
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream_with_colors_win_py3(var_0, var_1, var_2)
    return(var_3)


# Generated at 2022-06-25 19:03:11.000934
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie
    class MockFormatter(object):
        def __init__(self, msg, with_headers, with_body, **stream_kwargs):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
            self.stream_kwargs = stream_kwargs
    class MockBufferedPrettyStream(MockFormatter):
        def __init__(self, msg, with_headers, with_body, **stream_kwargs):
            super(MockBufferedPrettyStream, self).__init__(msg, with_headers, with_body, stream_kwargs)

# Generated at 2022-06-25 19:03:19.190153
# Unit test for function write_message
def test_write_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = write_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:03:20.755937
# Unit test for function write_stream
def test_write_stream():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 19:03:26.904911
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)
    assert type(var_5) == type(build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4))


# Generated at 2022-06-25 19:03:37.778893
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment(
        config_dir=None,
        colors=256,
        config_path=None,
        config_profile='',
        default_options=[],
        dot_dir=None,
        is_windows=False,
        stdout=sys.stdout,
        stdout_isatty=False,
        stderr=sys.stderr,
        stderr_isatty=False,
    )

# Generated at 2022-06-25 19:03:42.538820
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io
    import pytest
    import builtins
    from httpie.output import streams
    from httpie.core import main as httpie
    from httpie.core import main_default as http
    import httpie.core
    import httpie.cli
    import httpie.output
    var_0 = streams.BaseStream
    var_1 = io.TextIOWrapper
    var_2 = False
    var_3 = pytest.raises(NotImplementedError, test_case_0)

# Generated at 2022-06-25 19:03:51.803004
# Unit test for function write_stream
def test_write_stream():
    var_2 = None
    var_3 = "papagayo"
    var_4 = write_stream(var_2, var_3, var_2)
    var_5 = "HTTPResponse(headers={\'a\' : \'b\'}, body=b'{\\n \\'a\\' : \\'b\\'}\\n')"
    var_6 = HTTPResponse(headers={"a": "b"}, body=b'{\n \'a\' : \'b\'}\n')
    var_7 = write_stream(var_2, var_3, var_2)


# Generated at 2022-06-25 19:03:52.401534
# Unit test for function write_stream
def test_write_stream():

    assert 0



# Generated at 2022-06-25 19:03:55.712600
# Unit test for function write_message
def test_write_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = write_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:03:56.541017
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert False


# Generated at 2022-06-25 19:04:03.313597
# Unit test for function write_message
def test_write_message():
    # Setting up environment
    env = Environment()
    env.stdout = TextIOWrapper(BytesIO())
    env.stderr = TextIOWrapper(BytesIO())
    env.stdin = BytesIO()
    env.stdin.buffer = env.stdin
    env.stdin.encoding = 'utf8'
    env.stdout.buffer = env.stdout
    env.stdout.encoding = 'utf8'
    env.stderr.buffer = env.stderr
    env.stderr.encoding = 'utf8'
    env.is_windows = False
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.download = False
    args.stream = False
    args.traceback = False
    args.debug = False

# Generated at 2022-06-25 19:04:24.701069
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = None
    var_1 = type(var_0)
    var_1 = var_0
    var_2 = None
    var_2 = var_0
    var_3 = var_0
    var_3 = var_0
    var_4 = type(var_0)
    var_4 = var_0
    var_5 = var_0
    var_5 = var_0
    var_6 = type(var_0)
    var_6 = var_0
    var_7 = var_0
    var_7 = var_0
    var_8 = type(var_0)
    var_8 = var_0
    var_9 = var_0
    var_9 = var_0
    var_10 = type(var_0)
    var_10 = var_0

# Generated at 2022-06-25 19:04:36.825047
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(
            colors=True,
            debug=False,
            download=False,
            form='None',
            headers=[],
            ignore_stdin=False,
            json='None',
            output='None',
            prettify=['None'],
            print_headers=False,
            print_body=False,
            print_status=True,
            print_cookies=False,
            print_method=False,
            print_trailers=False,
            print_upload_rate=False,
            style='None',
            stream=False,
            traceback=False,
            verify=False,
        ),
    )
    var_1 = requests.PreparedRequest()
    var_2

# Generated at 2022-06-25 19:04:46.627175
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Python 3.4 or later is needed for for...else
    import sys
    if sys.version_info < (3, 4, 0):
        return

    from io import StringIO

    var_0 = None
    var_1 = '\x1b[0;31m#\x1b[0m'
    var_2 = StringIO()
    var_2.encoding = 'utf-8'
    var_3 = '\x1b[0;31m#\x1b[0m'
    var_4 = write_stream_with_colors_win_py3(var_0, var_2, var_0)
    var_5 = var_2.getvalue()
    var_6 = var_5 == var_3
    var_7 = var_6 is True



# Generated at 2022-06-25 19:04:47.994527
# Unit test for function write_stream
def test_write_stream():
    var_0 = None
    var_1 = write_stream(var_0, var_0, var_0)


# Generated at 2022-06-25 19:04:53.874886
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment(
        stdout_isatty=True,
        colors=256,
        stdin=None,
        stdin_isatty=True,
        stdout=None,
        stderr=None,
    )
    args = argparse.Namespace(
        # [Optional, List]
        prettify=None,
        # [Optional, bool]
        stream=None,
        # [Optional, str]
        style=None
    )
    requests_message = None
    with_headers = None
    with_body = None
    var_0 = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_headers=with_headers,
        with_body=with_body,
    )
    var

# Generated at 2022-06-25 19:04:58.034217
# Unit test for function write_message
def test_write_message():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None

    var_2 = write_message(var_3, var_4, var_5, var_6, var_7)


# Generated at 2022-06-25 19:05:08.203370
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = write_message(var_0, var_0, var_0, var_0, var_0)
    var_0 = write_stream(var_0, var_0, var_0)
    var_0 = write_stream_with_colors_win_py3(var_0, var_0, var_0)
    var_0 = build_output_stream_for_message(var_0, var_0, var_0, var_0, var_0)
    var_0 = get_stream_type_and_kwargs(var_0, var_0)
    var_0 = None
    var_0 = ''
    var_0 = None
    var_0 = ''
    var_0 = None
    var_0 = ''
    var_0 = None

# Generated at 2022-06-25 19:05:16.582874
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment(var_0=None, var_1=True, var_2=None, var_3=None, var_4=None, var_5=None, var_6=None, var_7=None, var_8=None, var_9=True)
    args_0 = argparse.Namespace()
    args_0.prettify = None
    args_0.stream = False
    type_0, kwargs_0 = get_stream_type_and_kwargs(env_0, args_0)
    assert (type_0 == EncodedStream)
    assert (kwargs_0 == {'env': env_0})
    args_0.prettify = ['body']

# Generated at 2022-06-25 19:05:21.963771
# Unit test for function write_message
def test_write_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = write_message(var_0, var_1, var_2, var_3, var_4, )


# Generated at 2022-06-25 19:05:22.996952
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:05:52.838395
# Unit test for function write_stream_with_colors_win_py3

# Generated at 2022-06-25 19:06:04.239802
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    # ---
    # var_0 = None
    # var_1 = write_stream(var_0, var_0, var_0)
    # ---
    # write_stream(stream, outfile, flush)
    # This function requires var_0 of type IO, but a None is passed
    # var_0 = None
    var_0 = "string"
    var_1 = write_stream(var_0, var_0, var_0)

    # ---
    # var_0 = None
    # var_1 = write_stream(var_0, var_0, var_0)
    # ---
    # write_stream(stream, outfile, flush)
    # This function requires var_0 of type TextIO, but a None is passed
    # var_0 = None
    var_0 = "string"


# Generated at 2022-06-25 19:06:13.530396
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        Arguments,
        BaseStream,
        BufferedPrettyStream,
        Dictionary,
        Environment,
        EncodedStream,
        List,
        PrettyStream,
        RawStream,
        String,
        Tuple,
        generator,
        instance,
        int,
        property,
        type,
    )

    var_0 = Environment()
    var_1 = Arguments()
    var_1.json = False
    var_1.output = None
    var_1.stream = None
    var_1.style = None
    var_1.prettify = None
    var_1.format_options = List()
    var_1.verbose = None
    var_1.all = False
    var_1.traceback = False

# Generated at 2022-06-25 19:06:18.680331
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)

# Generated at 2022-06-25 19:06:21.399073
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert callable(write_stream_with_colors_win_py3)
    assert isinstance(write_stream_with_colors_win_py3(None, None, False), Iterable)



# Generated at 2022-06-25 19:06:29.517981
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(prettify='all', stream=False, style=None, json=False, format_options=None)
    expected_stream_class = PrettyStream
    expected_stream_kwargs = {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups='all', color_scheme=None, explicit_json=False, format_options=None)}
    output_stream_class, output_stream_kwargs = get_stream_type_and_kwargs(env, args)

    assert output_stream_class == expected_stream_class
    assert expected_stream_kwargs == output_stream_kwargs

# Generated at 2022-06-25 19:06:36.121503
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment()
    var_1 = None
    var_0.stdout_isatty = var_1
    var_1 = None
    var_0.prettify = var_1
    var_0.stream = var_1
    var_1 = test_case_0
    var_1 = get_stream_type_and_kwargs(var_0, var_1)
    var_2 = type(var_1)
    var_3 = tuple
    assert var_2 == var_3


# Generated at 2022-06-25 19:06:42.877512
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import argparse
    from httpie.context import Environment

    args = argparse.Namespace(
        format='',
        headers='',
        http2=False,
        max_redirects=30,
        output=None,
        prettify='all',
        session=None,
        style='',
        traceback=False,
        verbose=False,
        verify=True,
        version=False,
        streaming=True,
        json=False
    )
    env = Environment(
        colors=256,
        stdout_isatty=True,
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert(True)

if __name__ == "__main__":
    import sys

# Generated at 2022-06-25 19:06:50.476595
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        import cStringIO as StringIO
    except ImportError:
        import io as StringIO
    from unittest import mock

    s = mock.MagicMock()

    with mock.patch('httpie.output.streams.write_stream_with_colors_win_py3.colorama') as patch:
        # Test: 1
        patch.init.return_value = 0
        patch.init.reset_mock()
        patch.deinit.return_value = 0
        patch.deinit.reset_mock()
        patch.AnsiToWin32.return_value = 0
        patch.AnsiToWin32.reset_mock()
        mock_stream = mock.MagicMock()

# Generated at 2022-06-25 19:07:01.034134
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import pytest
    import requests
    import httpie.output.streams


# Generated at 2022-06-25 19:07:28.926498
# Unit test for function write_stream
def test_write_stream():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream(var_0, var_1, var_2)

    return


# Generated at 2022-06-25 19:07:32.529258
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    with patch.object(sys, 'exit') as mock_sys_exit:
        var_0 = None
        # Call function
        var_1 = get_stream_type_and_kwargs(var_0, var_0)
        mock_sys_exit.assert_called_with(1)
    assert var_1 is None


# Generated at 2022-06-25 19:07:43.744442
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie import ExitStatus

    args = argparse.Namespace()
    args.stream = False
    args.debug = False
    args.traceback = False
    args.prettify = None
    args.style = None
    args.json = None
    args.format_options = None

    env = Environment(
        stdin=get_test_subprocess_stdin(),
        stdout=get_test_subprocess_stdout(),
        stderr=get_test_subprocess_stderr(),
        config_dir=None,
        config_file=None,
        config_defaults=None,
        env=None
    )

    requests_message = requests.PreparedRequest()


# Generated at 2022-06-25 19:07:52.406549
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from unittest.mock import MagicMock
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    var_0 = MagicMock()
    var_0.stdout_isatty = None
    var_0.stderr.write = MagicMock()
    var_1 = MagicMock()

# Generated at 2022-06-25 19:07:56.863863
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = argparse.Namespace()
    var_1 = Environment()
    var_2 = requests.Response()
    var_3 = None
    var_4 = write_message(var_2, var_1, var_0, var_3, var_3)


# Generated at 2022-06-25 19:08:06.639220
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from contextlib import redirect_stdout
    from io import StringIO
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from httpie.context import Environment
    from httpie.cli.arguments import Parser
    from httpie.output.streams import PrettyStream, BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.output.processing import Formatting
    from httpie.output.processing import Conversion
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse
    import os

    arguments_1 = ['-A', 'httpie/0.9.9', '127.0.0.1:8080', '-v']
    parsed_args_1 = Parser().parse_

# Generated at 2022-06-25 19:08:09.309956
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:08:14.193517
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    e = Environment()
    e.stdout_encoding = 'UTF-8'
    stream = EncodedStream(env=e)
    outfile = sys.stdout
    flush = False
    try:
        write_stream_with_colors_win_py3(stream, outfile, flush)
    except IOError as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-25 19:08:15.925056
# Unit test for function write_stream
def test_write_stream():
    var_0 = None
    var_1 = write_stream(var_0, var_0, var_0)


# Generated at 2022-06-25 19:08:23.851560
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input import ParseError
    from tempfile import TemporaryFile
    import json
    import requests

    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.models import HTTPRequest
    from httpie.models import HTTPResponse

    try:
        from collections.abc import Iterable
    except ImportError:
        from collections import Iterable

    # Test with the default value of all the arguments


# Generated at 2022-06-25 19:09:33.612771
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class requests_message:
        __init__ = None
        def is_body_upload_chunk(self):
            return True
        def __iter__(self):
            return [
                b'chunk1',
                b'chunk2'
            ]


# Generated at 2022-06-25 19:09:43.570209
# Unit test for function write_message
def test_write_message():
    url = 'https://httpbin.org/get?a=1&b=2'
    r = requests.get(url)
    args = argparse.Namespace(verbose=True, debug=False, traceback=False,
                              stream=False, prettify='all', style='default',
                              json=True, download=False, format_options=[])
    env = Environment(stdin=None, stdout=r.content, stderr=r.headers,
                      __dict__=requests.get(url).json())
    with_headers = True
    with_body = True
    var_0 = write_message(r, env=env, args=args, with_headers=with_headers, with_body=with_body)

# Generated at 2022-06-25 19:09:46.392365
# Unit test for function write_stream
def test_write_stream():
    var_2 = None
    var_3 = None
    var_4 = None
    var_1 = write_stream(var_2, var_3, var_4)


# Generated at 2022-06-25 19:09:54.268859
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    argparse1 = argparse.ArgumentParser()
    argparse1.add_argument('--arg', default='default')
    args = argparse1.parse_args()
