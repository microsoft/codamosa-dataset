

# Generated at 2022-06-25 19:00:04.441268
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert write_stream_with_colors_win_py3() == write_stream_with_colors_win_py3.__defaults__[0]

# Generated at 2022-06-25 19:00:08.171411
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    
    response_0 = module_0.Response()
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    var_0 = build_output_stream_for_message(environment_0, namespace_0, response_0)
    assert var_0 == list()


# Generated at 2022-06-25 19:00:13.410704
# Unit test for function write_stream
def test_write_stream():
    stream_0 = RawStream()
    outfile_0 = open('test.out', 'wb')
    flush_0 = False
    var_0 = write_stream(stream_0, outfile_0, flush_0)
    assert var_0 == None
    outfile_0.close()


# Generated at 2022-06-25 19:00:21.739174
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Assert the expected type and value of the returned object.
    #
    # Use: assert_type(value, expected_type)
    # Use: assert_value(value, expected_value)
    # Use: assert_equal(first_value, second_value)
    # Use: assert_not_equal(first_value, second_value)
    # Use: assert_true(value)
    # Use: assert_false(value)
    # Use: assert_raises(exception, function, *args, **kwargs)
    ...


# Generated at 2022-06-25 19:00:30.059203
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BufferedPrettyStream
    import sys
    import codecs

    # Case 1
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace(colors='always')
    namespace_0.prettify.append('colors')
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        environment_0,
        namespace_0,
    )
    buffered_pretty_stream = stream_class(
        msg=module_0.Response(),
        with_headers=None,
        with_body=None,
        **stream_kwargs
    )
    string_io = StringIO()

# Generated at 2022-06-25 19:00:37.977164
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    with mock.patch('httpie.output.writers.PrettyStream') as mock_PrettyStream:
        with mock.patch('httpie.output.writers.BufferedPrettyStream') as mock_BufferedPrettyStream:
            with mock.patch('httpie.output.writers.RawStream') as mock_RawStream:
                with mock.patch('httpie.output.writers.EncodedStream') as mock_EncodedStream:
                    class Dummy():
                        def __init__(self, mock_class, stdout_isatty_bool, prettify_list):
                            self.mock_class = mock_class
                            self.stdout_isatty = stdout_isatty_bool
                            self.prettify = prettify_list


# Generated at 2022-06-25 19:00:43.284653
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_0 = RawStream(msg = "" , with_headers = True, with_body = True)
    outfile_0 = io.StringIO("\n")
    flush_0 = True
    var_0 = write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)
    assert "IOError" in str(type(var_0))

# Generated at 2022-06-25 19:00:53.614415
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = module_1.Environment()
    namespace = module_2.Namespace()
    # test with stdout is not a tty, and prettify is not set
    env.stdout_isatty = False
    namespace.prettify = False
    result_0 = get_stream_type_and_kwargs(env, namespace)
    assert result_0 == (RawStream, {'chunk_size': 8192})
    # test with stdout is not a tty, and prettify is set
    env.stdout_isatty = False
    namespace.prettify = True
    result_1 = get_stream_type_and_kwargs(env, namespace)

# Generated at 2022-06-25 19:01:02.410036
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace_0 = module_2.Namespace()
    environment_0 = module_1.Environment()
    namespace_0.stdout = Input1()
    namespace_0.prettify = ['colors']
    namespace_0.style = 'solarized'
    namespace_0.stream = True
    input_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert input_0[0] == type(Output1())
    assert input_0[1]['formatting'] == Output2()
    assert input_0[1]['conversion'] == Output3()
    assert input_0[1]['env'] == environment_0


# Generated at 2022-06-25 19:01:03.249899
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    pass


# Generated at 2022-06-25 19:01:10.276777
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:01:21.555704
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import argparse
    import httpie.context as module_0
    import httpie.models as module_1
    import sys

    environment_0 = module_0.Environment()
    namespace_0 = argparse.Namespace()
    namespace_0.is_windows = True
    namespace_0.prettify = 'colors'
    namespace_0.style = ''

    class_0 = module_1.HTTPResponse
    class_0.is_body_upload_chunk = False
    class_0.reason = 'OK'
    class_0.status_code = 200
    class_0.close = lambda : None


# Generated at 2022-06-25 19:01:25.769788
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Define arguments
    stream = None
    outfile = None
    flush = True

    # Invoke method
    try:
        write_stream_with_colors_win_py3(stream, outfile, flush)
    except Exception as e:
        assert isinstance(e, UnboundLocalError)



# Generated at 2022-06-25 19:01:32.610043
# Unit test for function write_message
def test_write_message():
    print("\n[*] test_write_message")
    import requests
    import httpie.context as module_0
    import argparse as module_1
    import httpie.output.streams as module_2
    import httpie.models as module_3
    import io as module_4
    import functools as module_5
    import operator as module_6
    import numbers as module_7
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.debug = True
    namespace_0.prettify = 'all'
    namespace_0.sort_keys = True
    namespace_0.stream = False
    namespace_0.style = 'paraiso-dark'
    namespace_0.traceback = False
    namespace_0.verbose = False

# Generated at 2022-06-25 19:01:38.698461
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_request_0 = requests.PreparedRequest()
    tuple_0 = test_case_0()
    write_message(prepared_request_0, environment_0, namespace_0, with_headers=True, with_body=False)

if __name__ == "__main__":
    test_write_message()

# Generated at 2022-06-25 19:01:41.806995
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert callable(write_stream_with_colors_win_py3)


# Generated at 2022-06-25 19:01:52.789083
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    import requests as module_2
    response_0 = module_2.Response()
    tuple_0 = test_functions.prepare_response(response_0)
    response_1 = tuple_0[0]
    write_message(response_1, environment_0, namespace_0, True, True)
    write_message(response_1, environment_0, namespace_0, True, False)
    write_message(response_1, environment_0, namespace_0, False, True)
    write_message(response_1, environment_0, namespace_0, False, False)
    import requests as module_3
    requests_message_0 = module_3.PreparedRequest()

# Generated at 2022-06-25 19:01:57.368004
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0 == (module_0.EncodedStream, {'env': module_0.Environment()})

# Generated at 2022-06-25 19:02:03.611396
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Set up object
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    formatted = tuple_0[0](env=environment_0, conversion=None, formatting=None)
    prepared_request = requests.PreparedRequest()
    # Test the function
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, prepared_request, False, False)
    assert isinstance(tuple_0, type(formatted))


# Generated at 2022-06-25 19:02:06.811298
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
	environment_0 = Environment()
	namespace_0 = argparse.Namespace()
	tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:02:14.581099
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    outfile = sys.stdout
    stream = get_stream_type_and_kwargs()[0](outfile)
    write_stream_with_colors_win_py3(stream, outfile, True)

# Generated at 2022-06-25 19:02:26.117422
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Environment is an object.
    environment = module_0.Environment()
    # Namespace is used because it has the same attributes as an argparse.Namespace
    namespace = module_1.Namespace()
    namespace.stream = False
    namespace.json = False
    namespace.style = 'emacs'
    namespace.prettify = []
    namespace.format_options = {}
    # Check function return type
    get_stream_type_and_kwargs(environment, namespace)
    # Check function return type and that the function doesn't throw an exception
    assert type(get_stream_type_and_kwargs(environment, namespace)) == tuple
    # Check value for the first element of the tuple
    assert get_stream_type_and_kwargs(environment, namespace)[0] == EncodedStream
    # Check value for the second element of the

# Generated at 2022-06-25 19:02:27.060317
# Unit test for function write_message
def test_write_message():
    assert True == True


# Generated at 2022-06-25 19:02:38.353590
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.models import Request
    from httpie.output.streams import PrettyStream, BufferedPrettyStream
    from httpie.status import ExitStatus
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    tuple_0 = write_message(namespace_0, environment_0, namespace_0)

# Generated at 2022-06-25 19:02:48.241518
# Unit test for function write_stream
def test_write_stream():
    write_stream(RawStream(), open("test_data/test_function_write_stream_11.txt","r"), True)
    write_stream(EncodedStream(), open("test_data/test_function_write_stream_6.txt","r"), False)
    write_stream(RawStream(), open("test_data/test_function_write_stream_10.txt","r"), False)
    write_stream(EncodedStream(), open("test_data/test_function_write_stream_12.txt","r"), True)
    write_stream(EncodedStream(), open("test_data/test_function_write_stream_2.txt","r"), True)
    write_stream(RawStream(), open("test_data/test_function_write_stream_1.txt","r"), True)

# Generated at 2022-06-25 19:02:52.420124
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(tuple_0) ==  tuple

# Generated at 2022-06-25 19:03:00.366441
# Unit test for function write_stream

# Generated at 2022-06-25 19:03:05.131993
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == module_0.output.streams.EncodedStream



# Generated at 2022-06-25 19:03:10.484512
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

import httpie.context as module_0
import httpie.output.streams as module_1


# Generated at 2022-06-25 19:03:13.758738
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    expected_retval_0 = b""
    retval_0 = build_output_stream_for_message(None, None, None, None, None)
    assert expected_retval_0 == retval_0


# Generated at 2022-06-25 19:03:28.754803
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    mock_message_0 = requests.PreparedRequest()
    boolean_0 = True
    boolean_1 = True
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, mock_message_0, boolean_0, boolean_1)
    return tuple_0


# Generated at 2022-06-25 19:03:39.104835
# Unit test for function write_stream
def test_write_stream():
    # Create a mock of stream
    stream_0 = BaseStream()
    # Create a mock of outfile
    outfile_0 = IO()
    # The mocked method __enter__ of outfile returns an IO object
    outfile_0.__enter__ = MagicMock(return_value=IO())
    # The mocked method __exit__ of outfile returns None
    outfile_0.__exit__ = MagicMock(return_value=None)
    # The mocked method buffer of outfile returns an IO object
    outfile_0.buffer = MagicMock(return_value=IO())
    # The mocked method flush of outfile returns None
    outfile_0.flush = MagicMock(return_value=None)
    # The mocked method write of outfile returns None

# Generated at 2022-06-25 19:03:41.341797
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class MockTextIO(TextIO):
        def __init__(self):
            self.encoding = ''

    # TODO: Add the implementation for the test case.
    raise NotImplementedError



# Generated at 2022-06-25 19:03:52.949774
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    ret_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert ret_0 == (module_0.EncodedStream, {'env': environment_0})
    environment_1 = module_0.Environment()
    namespace_1 = argparse.Namespace(prettify=[])
    ret_1 = get_stream_type_and_kwargs(environment_1, namespace_1)
    assert ret_1 == (module_0.RawStream, {'chunk_size': module_0.RawStream.CHUNK_SIZE})
    environment_2 = module_0.Environment()
    namespace_2 = argparse.Namespace(prettify=[], stream=True)
    ret_

# Generated at 2022-06-25 19:03:58.356569
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:04:03.428184
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    requests_message_0 = requests.PreparedRequest()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, bool(), bool())
    assert len(tuple_0) == 2
    assert tuple_0[0] == False


# Generated at 2022-06-25 19:04:09.928909
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = (module_0.Environment, module_1.Namespace)
    assert tuple_0 is type(build_output_stream_for_message(environment_0, namespace_0, requests.Request, True, True))


# Generated at 2022-06-25 19:04:17.070845
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()

    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = build_output_stream_for_message(namespace_0, environment_0, tuple_0, True, True)
    assert len(tuple_1) == 2


# Generated at 2022-06-25 19:04:28.130309
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class BaseStream:
        pass
    from typing import Dict
    from argparse import Namespace
    class Environment:
        stdout_isatty = True
    class RawStream(BaseStream):
        CHUNK_SIZE_BY_LINE: int
        CHUNK_SIZE: int
        def __init__(self, chunk_size: int):
            self.chunk_size = chunk_size
    class PrettyStream(BaseStream):
        def __init__(self, env: Environment, conversion: object, formatting: object):
            self.env = env
            self.conversion = conversion
            self.formatting = formatting
    class BufferedPrettyStream(BaseStream):
        def __init__(self, env: Environment, conversion: object, formatting: object):
            self.env = env
            self.conversion = conversion
            self

# Generated at 2022-06-25 19:04:38.063528
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Output of function under test
    from httpie.output.streams import BaseStream
    from httpie.models import HTTPRequest
    import requests as module_0
    import httpie.context as module_1

    environment_0 = module_1.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    instance_0 = tuple_0[0](requests_message=module_0.PreparedRequest(), env=environment_0, with_body=False, with_headers=False)
    assert isinstance(instance_0, BaseStream)



# Generated at 2022-06-25 19:04:53.605309
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_class = PrettyStream
    stream_kwargs = {
        'env': Environment(),
        'conversion': Conversion(),
        'formatting': Formatting(
            env=Environment(),
            groups='all',
            color_scheme='par',
            explicit_json=False,
            format_options={}
        )
    }
    stream = stream_class(msg=HTTPRequest(), with_headers=True, with_body=True, **stream_kwargs)
    output_stream = BufferedPrettyStream(
        msg=HTTPRequest(), with_headers=True, with_body=True, **stream_kwargs)
    output_stream_1 = EncodedStream(
        msg=HTTPRequest(), with_headers=True, with_body=True, **stream_kwargs)
    stream.__enter__()
    stream.__exit

# Generated at 2022-06-25 19:04:59.523339
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert callable(get_stream_type_and_kwargs)
    assert isinstance(get_stream_type_and_kwargs(module_0.Environment(), module_1.Namespace()), tuple)
    test_case_0() if __name__ == '__main__' else None
    # Other tests

import httpie.output.streams as module_2
import typing as module_3
from typing import List, Tuple


# Generated at 2022-06-25 19:05:00.902278
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    test_case_0()

# Generated at 2022-06-25 19:05:05.579817
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    print('Testing function get_stream_type_and_kwargs')
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert(tuple_0[0] == EncodedStream)

# Generated at 2022-06-25 19:05:10.654746
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    http_message_0 = module_0.HTTPRequest()
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, http_message_0, False, False)

import httpie.output as module_0
import argparse as module_1


# Generated at 2022-06-25 19:05:11.549341
# Unit test for function write_message
def test_write_message():
    assert (write_message == None)


# Generated at 2022-06-25 19:05:14.539032
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(tuple_0) == tuple


# Generated at 2022-06-25 19:05:17.416651
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    message_0 = module_2.HTTPResponse()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, message_0, False, True)


# Generated at 2022-06-25 19:05:19.370467
# Unit test for function write_stream
def test_write_stream():
    assert 1



# Generated at 2022-06-25 19:05:29.900403
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from unittest.mock import call
    from httpie.output.streams import RawStream

    fake_stdout = StringIO()
    fake_stdout.isatty = lambda: False

    expected_calls = [
        call('get'),
        call('post'),
        call('{}, {}, {}'.format(
            RawStream.CHUNK_SIZE, RawStream.CHUNK_SIZE_BY_LINE, RawStream.CHUNK_SIZE))
    ]
    raw_stream = RawStream(
        msg=None,
        with_headers=True,
        with_body=True,
        chunk_size=RawStream.CHUNK_SIZE,
    )
    writer = raw_stream.write(fake_stdout)
    writer('get')
    writer('post')


# Generated at 2022-06-25 19:05:48.364637
# Unit test for function write_stream
def test_write_stream():
	pass


# Generated at 2022-06-25 19:05:58.152560
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # Test cases for the function build_output_stream_for_message
    flags, args = {}, {}

    # Test case 0
    setattr(args, "stream", (flags["stream"] == "True"))
    setattr(args, "prettify", ("none"))
    setattr(args, "style", ("none"))
    setattr(args, "json", (flags["json"] == "True"))
    setattr(args, "format_options", [])
    build_output_stream_for_message(args, {"stdout": "stdout"})

    # Test case 1
    setattr(args, "stream", (flags["stream"] == "True"))
    setattr(args, "prettify", ("none"))
    setattr(args, "style", ("none"))

# Generated at 2022-06-25 19:06:09.814850
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    # This captures a stdout stream, so it can be manipulated
    # while still being printed to the console
    stdout_capture = io.StringIO()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=module_0.Environment(),
        args=module_1.Namespace(
            prettify='colors'
        )
    )
    unicode_test = 'Ä'
    encoded_test = unicode_test.encode('utf-8')
    # Test for unicode

# Generated at 2022-06-25 19:06:16.221852
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test for file system
    import sys
    encoding_2 = sys.stdout.encoding
    for _ in range(1, 4):
        stream_2 = BufferedPrettyStream(msg=HTTPResponse(MockResponse()), with_headers=True, with_body=True, env=module_0.Environment(), formatting=Formatting(env=module_0.Environment(), groups='colors', color_scheme='solarized-dark', explicit_json=False, format_options=None), conversion=Conversion())
        write_stream_with_colors_win_py3(stream_2, sys.stdout, flush=True)


# Generated at 2022-06-25 19:06:26.282261
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from mock import patch
    requests_response_0 = patch('httpie.output.stream.requests.Response')
    response_0 = requests_response_0.start()
    requests_prepared_request_0 = patch('httpie.output.stream.requests.PreparedRequest')
    prepared_request_0 = requests_prepared_request_0.start()
    namespace_0 = argparse.Namespace()
    namespace_0.prettify = False
    namespace_0.stream = False
    namespace_0.style = None
    namespace_0.json = False
    namespace_0.format_options = False
    namespace_0.prettify = True
    namespace_0.style = 'default'
    namespace_0.json = False
    namespace_0.format_options = None
    response_0.headers.__

# Generated at 2022-06-25 19:06:35.607386
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    requests_0 = requests.PreparedRequest()
    module_0.write_message(requests_0, environment_0, namespace_0)
    module_0.write_message(requests_0, environment_0, namespace_0, False, False)
    module_0.write_message(requests_0, environment_0, namespace_0, True, False)
    module_0.write_message(requests_0, environment_0, namespace_0, False, True)
    module_0.write_message(requests_0, environment_0, namespace_0, True, True)
    namespace_1 = module_1.Namespace(prettify='all', style='autumn')
    module_0.write_

# Generated at 2022-06-25 19:06:42.650020
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import io as module_0
    import io as module_1
    import io as module_2
    import io as module_3
    import io as module_4
    import io as module_5
    import requests
    import requests as module_6
    import requests as module_7
    import requests as module_8
    import requests as module_9
    import requests as module_10
    import requests as module_11
    import requests as module_12
    import httpie.models as module_13
    import httpie.output.streams as module_14
    import httpie.output.streams as module_15
    import httpie.output.streams as module_16
    import httpie.output.streams as module_17
    import httpie.output.streams as module_18
    import httpie.output

# Generated at 2022-06-25 19:06:43.211577
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    assert True == True

# Generated at 2022-06-25 19:06:45.494009
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:06:47.494992
# Unit test for function write_stream
def test_write_stream():
    fp = open("output.txt", "w")
    stream = BaseStream("")
    write_stream(stream, fp, True)
    fp.close()
    assert True

# Generated at 2022-06-25 19:07:16.518041
# Unit test for function write_message
def test_write_message():
    b'httpie - A CLI, cURL-like tool for humans'
    b'     __     '
    b'    /__\     '
    b'   / \/ \     '
    b'  /       \    '
    b' /  HTTPie  \   '
    b'/___________\  '
    b'\___________/  '
    b' \^..^ /    \^..^'
    b'  (oo)   ||   (oo)'
    b'c(")(")   ()   (")(")'
    b'------------------------------------------------------------'
    b'>>> from httpie.context import Environment'
    b'>>> from httpie.models import HTTPRequest, HTTPResponse'
    b'>>> from httpie.models import Request, Response'

# Generated at 2022-06-25 19:07:19.551232
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == EncodedStream

# Generated at 2022-06-25 19:07:31.444942
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.stream = bool()
    namespace_0.style = Any()
    namespace_0.debug = bool()
    namespace_0.json = bool()
    namespace_0.traceback = bool()
    namespace_0.prettify = Any()
    namespace_0.force_colors = bool()
    namespace_0.format_options = Any()
    req = module_2.Request('GET', 'http://example.com/')
    req.body = b''
    req.headers['Content-Type'] = 'application/json'

# Generated at 2022-06-25 19:07:42.959690
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    from io import BytesIO
    from io import TextIOWrapper
    import sys

    import requests

    import httpie.cli

    r = requests.get('https://httpbin.org/')
    p = httpie.cli.HTTPie().get_piped_from_stdin()
    a = httpie.cli.HTTPie().get_args()

    e = module_0.Environment()
    s = get_stream_type_and_kwargs(e, a)[0]

    e.stdout = sys.stdout
    e.stdout_isatty = True
    a.prettify = ['colors']

    outfile = getattr(e.stdout, 'buffer', e.stdout)

# Generated at 2022-06-25 19:07:51.783118
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # ***** Stubs *****
    # @property
    # def stdout_isatty(self): ...
    try:
        from typing import Type
    except ImportError:
        Type = type
    try:
        from typing import Union
    except ImportError:
        Union = type
    import httpie.output.streams as module_0
    import httpie.output.streams as module_1
    import httpie.output.streams as module_2
    try:
        from typing import Type
    except ImportError:
        Type = type
    try:
        from typing import Union
    except ImportError:
        Union = type
    class EncodedStream(module_0.BaseStream, ):
        """Vector of bytes chunks that gets encoded to bytes."""


# Generated at 2022-06-25 19:08:02.250335
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests as module_2
    import argparse as module_1
    import httpie.context as module_0
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    prepared_request_0 = module_2.PreparedRequest()
    type_0 = type(prepared_request_0)
    bool_2 = isinstance(type_0, module_2.PreparedRequest)
    bool_3 = isinstance(type_0, module_2.Response)
    bool_0 = bool_2 or bool_3
    assert bool_0
    bool_0 = not bool_0
    assert bool_0
    bool_0 = bool_2 and not bool_3
    assert bool_0
    bool_0 = bool_2 and bool_3
    assert not bool_0


# Generated at 2022-06-25 19:08:04.623750
# Unit test for function write_message
def test_write_message():
    with pytest.raises(IOError):
        write_message('requests_message', 'environment', 'args', True, True)



# Generated at 2022-06-25 19:08:06.308281
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert callable(write_stream_with_colors_win_py3)


# Generated at 2022-06-25 19:08:16.518642
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import random

    # Generate inputs
    random_int = random.randint(0, 10000)
    random_set = random.sample(range(0, 10000), random_int)
    stream = EncodedStream(env=Environment, msg=HTTPResponse)

    # Set up file mocks
    mock_stdout = io.StringIO()
    mock_outfile = io.StringIO()
    
    # Call function with most likely arguments
    write_stream_with_colors_win_py3(stream=stack, outfile=mock_stdout, flush=True)

    # Check function outputs

    # Check function outputs - serialized
    assert len(mock_outfile.getvalue()) > 0
    assert len(mock_stdout.getvalue()) > 0




# Generated at 2022-06-25 19:08:24.705649
# Unit test for function write_message
def test_write_message():
    namespace_0 = module_1.Namespace()
    class Class_0(object):
        def __init__(self):
            self.connection = None
        def prepare_for_serialization(self, skip_authorization):
            request = None
            return request
    request = Class_0()
    class Class_1(object):
        def __init__(self):
            self.connection = None
        def prepare_for_serialization(self, skip_authorization):
            response = None
            return response
    response = Class_1()
    environment_0 = module_0.Environment()
    requests_message = request
    arguments_0 = True
    arguments_1 = True
    with_headers = arguments_0
    with_body = arguments_1

# Generated at 2022-06-25 19:08:59.833517
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    string_0 = "abcd"
    requests_prepared_0 = module_0.PreparedRequest(string_0)
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    class_0 = tuple_0[0]
    dict_0 = tuple_0[1]
    tuple_1 = todo_0(string_0, class_0, dict_0)
    list_0 = tuple_1[0]
    int_0 = tuple_1[1]

    assert(list_0 == [b'abcd\n\n'])
    assert(int_0 == 1)
    assert(type(class_0) == type(BufferedPrettyStream))


# Generated at 2022-06-25 19:09:04.160886
# Unit test for function write_stream
def test_write_stream():
    stream_0 = "test_value"
    outfile_0 = "test_value"
    flush_0 = "test_value"
    write_stream(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:09:11.442581
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io as module_2

    file_0 = module_2.TextIOWrapper()
    module_0 = module_2.BytesIO()

    # Test with regular input
    tuple_0 = write_stream_with_colors_win_py3(module_0, file_0, False)

    # Test with bytes as input
    tuple_1 = write_stream_with_colors_win_py3(module_2.BytesIO(), file_0, False)


# Generated at 2022-06-25 19:09:21.491310
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = (RawStream, {'chunk_size': RawStream.CHUNK_SIZE})
    assert tuple_0 == tuple_1

import httpie.cli as module_0
import httpie.output as module_1
import httpie.context as module_2
import httpie.models as module_3
import httpie.output.streams as module_4
import requests as module_5
import pytest as module_6


# Generated at 2022-06-25 19:09:32.002798
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    CLI_ARGS.args = []
    CLI_ARGS.args.append('get')
    CLI_ARGS.args.append('http://httpbin.org/json')
    CLI_ARGS.args.append('-pp')
    CLI_ARGS.args.append('--pretty=all')
    CLI_ARGS.args.append('--stream')
    CLI_ARGS.args.append('--color')
    CLI_ARGS.args.append('always')
    CLI_ARGS.args.append('--nocolor')
    CLI_ARGS.args.append('--style')
    CLI_ARGS.args.append('paraglider')
    CLI_ARGS.args.append('--download')
    CLI_ARGS.args.append('--download-all')
    CLI_ARGS.args.append

# Generated at 2022-06-25 19:09:43.745686
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    #
    #
    #
    environment_0 = httpie.context.Environment()
    namespace_0 = argparse.Namespace()
    http_request_0 = requests.models.PreparedRequest()
    http_request_0.method = 'GET'
    http_request_0.url = 'http://httpbin.org/'
    http_request_0.body = None
    http_request_0.headers = {}
    http_request_0.hooks = {'response': []}
    http_request_0.files = []
    http_request_0.auth = None
    http_request_0.proxies = {}
    http_request_0.verify = False
    http_request_0.cert = None
    http_request_0.json = None
    http_request_0.preload

# Generated at 2022-06-25 19:09:50.343723
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == EncodedStream
    assert tuple_0[1] == {
        'env': environment_0
    }

import httpie.output.streams as module_0
import httpie.output.processing as module_1
import httpie.context as module_2
