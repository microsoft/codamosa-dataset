

# Generated at 2022-06-25 19:00:10.450758
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    textio_0 = open('tests/fixtures/readonly/server-error')
    bool_0 = True
    requests_response_0 = requests.Response()
    requests_response_0.status_code = 500
    requests_response_0.encoding = 'utf-8'
    requests_response_0.headers = {}
    requests_response_0.reason = ''
    requests_response_0.raw = textio_0
    requests_response_0.elapsed = datetime.timedelta(microseconds=1000000)
    requests_response_0.request = requests.Request()
    requests_response_0.connection = requests.packages.urllib3.connectionpool.HTTPConnectionPool()
    namespace_0 = module_1.Namespace()
    namespace_0.is_windows = False
    namespace_0.pre

# Generated at 2022-06-25 19:00:20.738399
# Unit test for function write_message
def test_write_message():
    import httpie.context as module_0
    import httpie.models as module_1
    import httpie.output.streams as module_2
    import requests as module_3
    requests_message_0 = module_3.PreparedRequest()
    str_0 = '7$vE.^=W8V4|\nF\x1b;RC'
    environment_0 = module_0.Environment(str_0)
    
    # Undefined variable 'args'

    bool_0 = True
    bool_1 = False
    write_message(requests_message_0, environment_0, namespace_0, bool_0, bool_1)
    bool_2 = True
    write_message(requests_message_0, environment_0, namespace_0, bool_1, bool_2)
    bool_3

# Generated at 2022-06-25 19:00:32.831089
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    str_0 = '\x16<\xc9\x0c\xeb\x16w\x82'
    namespace_0 = module_1.Namespace()
    namespace_0.stdout_isatty = True
    namespace_0.prettify = '<V`>ls]21\x0cF&!v8\\'
    namespace_0.style = str_0
    namespace_0.stream = False
    namespace_0.json = '\x16<\xc9\x0c\xeb\x16w\x82'
    namespace_0.format_options = '\x16<\xc9\x0c\xeb\x16w\x82'
    namespace_0.debug = False
    namespace_0.traceback = False

# Generated at 2022-06-25 19:00:37.675969
# Unit test for function write_message
def test_write_message():
    requests_message = None
    env = None
    args = None
    with_headers = None
    with_body = None
    try:
        write_message(requests_message, env, args, with_headers, with_body)
    except ValueError as e:
        print('Exception raised:', e)


# Generated at 2022-06-25 19:00:48.030685
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace_0 = module_1.Namespace(prettify=['headers'])
    from httpie.output.streams import BufferedPrettyStream as cls_0
    str_0 = '`N}*~[Ngbe0z>|f$L^'
    environment_0 = module_0.Environment(str_0)
    arguments_0 = cls_0(environment_0, namespace_0)
    assert (tuple_0) == (cls_0, arguments_0)
    namespace_0 = module_1.Namespace(prettify=['headers'])
    from httpie.output.streams import BufferedPrettyStream as cls_1
    str_0 = '`N}*~[Ngbe0z>|f$L^'

# Generated at 2022-06-25 19:00:52.663843
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment('')
    args = argparse.Namespace()
    output_stream_type, output_stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert output_stream_type == EncodedStream
    assert output_stream_kwargs == {'env': env}


# Generated at 2022-06-25 19:00:55.758648
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass

if __name__ == '__main__':
    test_case_0()
    test_write_stream_with_colors_win_py3()

# Generated at 2022-06-25 19:01:00.517224
# Unit test for function write_message
def test_write_message():
    str_0 = '\x7fP'
    environment_0 = module_0.Environment(str_0)
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_0[0](tuple_0[1], False, False).__next__()

# Generated at 2022-06-25 19:01:09.181749
# Unit test for function write_message
def test_write_message():
    class Foo:
        def __init__(self, x):
            self.x = x

    requests_message_0 = Foo('bar')
    namespace_0 = module_1.Namespace()
    namespace_0.debug = bool(9)
    namespace_0.traceback = bool(7)
    namespace_0.stream = bool(2)
    environment_0 = module_0.Environment('<b|>0\x0cF&!v8\\')
    args_0 = module_1.Namespace()
    args_0.debug = namespace_0.debug
    try:
        write_message(requests_message_0, environment_0, args_0, True, True)
    except IOError as e:
        assert not namespace_0.traceback
        assert e.errno == errno.EPIPE

# Generated at 2022-06-25 19:01:17.962118
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment('I_&\x0b\x15W\x10%9')
    namespace_0 = module_1.Namespace()
    str_0 = 'xb\x1dV\x06t4\x12\x00\x1b\x1b\x1b\x1b'
    class_0 = module_1.PreparedRequest(str_0)
    build_output_stream_for_message(namespace_0, environment_0, class_0, True, True)


# Generated at 2022-06-25 19:01:31.157178
# Unit test for function write_stream
def test_write_stream():

    # assign
    str_0 = 'N(a@p|C)4"M3/\x0e\x1bR'
    environment_0 = module_0.Environment(str_0)
    namespace_0 = module_1.Namespace()
    str_1 = '*8\\M~-}v`oZ*\x1a\x1c'
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, namespace_0, bool_0, bool_1)
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    bool_0 = True
    bool_1 = True
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = build_

# Generated at 2022-06-25 19:01:39.878285
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    
    str_0 = 'Yd-L.N\x1f\x026\x1d\x1c\x080'
    environment_0 = module_0.Environment(str_0)
    str_1 = 'W\'PU8'
    namespace_0 = module_1.Namespace()
    requests_response_0 = module_2.Response(str_1)
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, requests_response_0, True, False)
    assert isinstance(tuple_0, PrettyStream)


# Generated at 2022-06-25 19:01:52.620691
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        EncodedStream, BufferedPrettyStream, PrettyStream, RawStream
    )
    from httpie.context import Environment

    args = argparse.Namespace()

    # Raw non-TTY output.
    env = Environment()
    env.stdout_isatty = False
    args.prettify = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE}

    # Pretty non-TTY output.
    args.prettify = ['all']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-25 19:01:54.200516
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:02:02.829250
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    def test_equals(actual, expected):
        assert actual == expected, 'Expected {0}, but got {1}'.format(expected, actual)

    str_0 = '<V`>ls]21\x0cF&!v8\\'
    environment_0 = module_0.Environment(str_0)
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    test_equals(tuple_0[0], EncodedStream)

import argparse as module_0
import httpie.client as module_1
import httpie.cli as module_2
import httpie.context as module_3
import os as module_4
import requests as module_5
import tempfile as module_6

# Generated at 2022-06-25 19:02:12.912683
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    expected_exception = TypeError
    str_0 = 'zms?@!h:oO\t\n'
    buffered_0 = BytesIO(str_0.encode())
    environment_0 = module_0.Environment('H~\x17Uvj8w93^')
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class = tuple_0[0]
    stream_kwargs = tuple_0[1]
    base_stream_0 = stream_class((), False, False, **stream_kwargs)
    tuple_1 = ('', buffered_0, False)

# Generated at 2022-06-25 19:02:22.100386
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(module_0.Environment('<V`>ls]21\x0cF&!v8\\'), module_1.Namespace()) == (module_0.BufferedPrettyStream, {'env': module_0.Environment('<V`>ls]21\x0cF&!v8\\'), 'conversion': module_0.Conversion(), 'formatting': module_0.Formatting(env=module_0.Environment('<V`>ls]21\x0cF&!v8\\'), groups=['none'], color_scheme='none', explicit_json=False, format_options={})})


# Generated at 2022-06-25 19:02:33.366460
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    non_tty_args = argparse.Namespace(
        prettify=False,
        style='monokai',
        format_options={},
        stream=False,
        download=False,
        json=False,
        debug=False,
        traceback=True,
    )
    non_tty_env = Environment(False)
    assert (
        get_stream_type_and_kwargs(non_tty_env, non_tty_args)
        == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE})
    )


# Generated at 2022-06-25 19:02:35.829466
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    env = Environment()
    write_message(requests.PreparedRequest, env, args)


# Generated at 2022-06-25 19:02:39.856644
# Unit test for function write_message
def test_write_message():
    str_0 = './httpie-test'
    environment_0 = module_0.Environment(str_0)
    namespace_0 = module_1.Namespace()
    write_message(str_0, environment_0, namespace_0)


# Generated at 2022-06-25 19:02:51.538885
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True == True


# Generated at 2022-06-25 19:02:54.317548
# Unit test for function write_stream
def test_write_stream():
    stream_0 = None
    outfile_0 = None
    flush_0 = None
    var_0 = write_stream(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:02:58.506651
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    response_0 = module_0.Response()
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    var_0, var_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    write_message(response_0, environment_0, namespace_0, namespace_0, namespace_0)

# Generated at 2022-06-25 19:03:02.989481
# Unit test for function write_message
def test_write_message():
    response_0 = module_0.Response()
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    var_0 = write_message(response_0, environment_0, namespace_0, namespace_0)



# Generated at 2022-06-25 19:03:08.291508
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    response_0 = module_0.Response()
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    var_0 = build_output_stream_for_message(namespace_0, environment_0, response_0, namespace_0, namespace_0)
    assert var_0 == [b'']


# Generated at 2022-06-25 19:03:12.850324
# Unit test for function write_message
def test_write_message():
    response_0 = module_0.Response()
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    var_0 = write_message(response_0, environment_0, namespace_0, namespace_0)
    assert var_0 is None

# Generated at 2022-06-25 19:03:20.627434
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class Environment_0():
        stdout_isatty = True
    class Namespace_0():
        stream = True
        prettify = ['all']
    environment_0 = Environment_0()
    namespace_0 = Namespace_0()
    var_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_0 = (var_0[0], var_0[1])
    assert isinstance(var_0, tuple) == True
    assert len(var_0) == 2
    assert isinstance(tuple_0, tuple) == True
    assert len(tuple_0) == 2
    assert isinstance(tuple_0[0], type) == True
    assert issubclass(tuple_0[0], BaseStream) == True

# Generated at 2022-06-25 19:03:31.784514
# Unit test for function write_stream
def test_write_stream():
    exception_0 = IOError()
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    stream_0 = RawStream()
    stream_1 = PrettyStream()
    stream_2 = BufferedPrettyStream()
    stream_3 = EncodedStream()
    var_0 = IOError()
    var_1 = IOError()
    var_2 = IOError()
    var_3 = IOError()
    var_4 = IOError()
    var_5 = IOError()
    var_6 = IOError()
    var_7 = IOError()
    var_8 = IOError()
    var_9 = IOError()
    var_10 = IOError()
    var_11 = IOError()
    var_12 = IOError()
    var_13 = IOError()


# Generated at 2022-06-25 19:03:36.000148
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    try:
        var_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    except:
        var_1 = None
    assert var_1 is not None


# Generated at 2022-06-25 19:03:39.179760
# Unit test for function write_message
def test_write_message():
    request_0 = module_0.Request()
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    var_0 = write_message(request_0, environment_0, namespace_0, True, True)

    assert True



# Generated at 2022-06-25 19:03:58.710475
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-25 19:04:00.502910
# Unit test for function write_message
def test_write_message():
    write_message(requests.PreparedRequest(None, None), Environment(), argparse.Namespace())


# Generated at 2022-06-25 19:04:08.048464
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import BaseStream, EncodedStream, PrettyStream, RawStream
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = True
    var_9 = False
    var_10 = True
    var_11 = False
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = True
    var_16 = True
    var_17 = True
    var_18 = False
    var_19 = True
    var_20 = True
    var_21 = True
    var_22 = True
    var_23 = True
    var_24 = True
    var_25 = True
    var_26 = False
   

# Generated at 2022-06-25 19:04:16.458400
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        default_options=[],
        config_dir='.cache/httpie/users/roddy/5948f12c',
        config_path='.cache/httpie/users/roddy/5948f12c/config.json',
        config_profile=None,
        colors=256,
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        is_windows=(sys.platform == 'win32'),
        is_a_tty=sys.stdout.isatty(),
        stdout_isatty=sys.stdout.isatty(),
        stdin_isatty=sys.stdin.isatty(),
        output_options={},
    )

# Generated at 2022-06-25 19:04:22.411464
# Unit test for function write_stream
def test_write_stream():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream(var_0, var_1, var_2)
    return (var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 19:04:25.148118
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = write_stream_with_colors_win_py3(var_0, var_1, var_2)

# Generated at 2022-06-25 19:04:27.507477
# Unit test for function write_stream
def test_write_stream():
    # Setup
    var_1 = None
    var_2 = None
    var_3 = True

    # Testing
    # assert



# Generated at 2022-06-25 19:04:34.135901
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from cStringIO import StringIO
    env = Environment(
        colors=256,
        stdout_isatty=True,
        is_windows=True,
    )
    args = argparse.Namespace(headers='All', stream=True)
    outfile = StringIO()
    flush = None

# Generated at 2022-06-25 19:04:41.541442
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_2 = Environment()
    var_1 = None
    # Create mock object for HTTPRequest
    class HTTPRequest:
        def __init__(self, request):
            self.request = request
    var_3 = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }
    var_5 = HTTPRequest(var_0)
    var_4 = var_3[type(var_0)](var_5)
    var_7 = None
    # Create mock object for PrettyStream
    class PrettyStream:
        def __init__(self, msg, with_headers, with_body, env, conversion, formatting):
            self.msg = msg
            self.with_headers = with_headers
            self.with_body = with_body
            self.env = env
           

# Generated at 2022-06-25 19:04:45.493334
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:05:15.975079
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Get verbose=True so that we get print statements in test case
    args = argparse.Namespace(verbose=True)
    env = Environment(args=args)
    # Testing against a real example of a request message
    request_data = 'GET / HTTP/1.1\nHost: example.com\n\n'
    request_message = HTTPRequest(request_data)
    with_headers = True
    with_body = True
    requests_message = build_output_stream_for_message(args=args, env=env, requests_message=request_message, with_headers=with_headers, with_body=with_body)
    flag_1 = False
    for i in requests_message:
        if i == b'GET / HTTP/1.1\nHost: example.com\n\n':
            flag

# Generated at 2022-06-25 19:05:18.902172
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = write_stream_with_colors_win_py3(var_0, var_0, var_0)

# Generated at 2022-06-25 19:05:23.330362
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = Environment()
    var_0.stdout_isatty = true
    var_1 = argparse.Namespace()
    var_2, var_3 = get_stream_type_and_kwargs(var_0, var_1)


# Generated at 2022-06-25 19:05:27.176755
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = write_stream_with_colors_win_py3(var_2, var_3, var_4)


# Generated at 2022-06-25 19:05:34.579763
# Unit test for function write_message
def test_write_message():
    environment_instance = Environment(
        stdin=(
            lambda: (yield)), stdin_isatty=True,
        stdout=(
            lambda: (yield)), stdout_isatty=False,
        stderr=(
            lambda: (yield)), stderr_isatty=False)

    args_instance = argparse.Namespace()

    var_0 = None
    var_1 = False
    var_2 = False
    var_3 = write_message(var_0, environment_instance, args_instance, var_1, var_2)

    var_0 = None
    var_1 = False
    var_2 = True
    var_3 = write_message(var_0, environment_instance, args_instance, var_1, var_2)

    var_0 = None
    var

# Generated at 2022-06-25 19:05:43.488730
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = get_stream_type_and_kwargs(var_0, var_1)
    var_4 = None
    var_0 = None
    var_1 = None
    var_2 = None
    var_5 = None
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_6 = None
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_7 = None
    var_8 = None

# Generated at 2022-06-25 19:05:51.396647
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class Mock_argparse:
        def __init__(self):
            self.stream = var_0
            self.prettify = var_0
    class Mock_Environment:
        def __init__(self):
            self.stdout_isatty = var_0
            self.stdout = var_0
    var_0 = None
    var_1 = None
    var_2 = Mock_argparse()
    var_3 = Mock_Environment()
    var_4 = build_output_stream_for_message(var_1, var_2, var_3, var_4, var_4)
    assert type(var_4) == write_stream


# Generated at 2022-06-25 19:06:00.669285
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace(
        style="solarized",
        stream=False,
        json=False,
        prettify="colors",
        format_options={"indent": 2, "sort_keys": false, "separators": (",", ":")},
        debug=False,
        traceback=False
    )

# Generated at 2022-06-25 19:06:12.139912
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestCase(unittest.TestCase):
        def runTest(self):

            # Test function
            var_0 = None
            var_1 = get_stream_type_and_kwargs(var_0, var_0)
            self.assertTrue(type(var_1) is tuple)

    suite = unittest.TestSuite()
    suite.addTest(TestCase())
    result = unittest.TestResult()
    suite.run(result)
    print('\nErrors and failures:')
    for (test, err) in result.errors + result.failures:
        print(test, err)
    if not result.wasSuccessful():
        print('Test failed :(')


# Generated at 2022-06-25 19:06:18.961875
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    env = Environment(stdout=var_0, stderr=var_0, stdout_isatty=var_0, is_windows=var_0)


# Generated at 2022-06-25 19:07:09.843128
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args0 = create_args()
    env0 = create_env()
    requests_message0 = create_requests_message()
    with_headers0 = bool()
    with_body0 = bool()
    expected_var = create_expected_var()
    actual_var = build_output_stream_for_message(args0, env0, requests_message0, with_headers0, with_body0)
    if (expected_var != actual_var):
        raise Exception(f'Expected : {expected_var} Actual : {actual_var}')


# Generated at 2022-06-25 19:07:12.466407
# Unit test for function write_message
def test_write_message():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = write_message(var_3, var_2, var_4, var_5, var_5)


# Generated at 2022-06-25 19:07:16.800879
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = test_case_0()
    var_2 = None
    var_3 = write_stream_with_colors_win_py3(var_0, var_2, var_2)


# Generated at 2022-06-25 19:07:23.124948
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    url_0 = "172.31.88.154/input2.txt"
    arg = argparse.Namespace()
    arg.body = False
    arg.debug = False
    arg.download = False
    arg.follow = True
    arg.headers = False
    arg.output = "<path>"
    arg.pretty = "all"
    arg.style = "paraiso-dark"
    arg.traceback = False
    arg.verbose = False
    arg.style = "paraiso-dark"
    arg.body = False
    arg.headers = False
    arg.with_headers = True
    arg.with_body = False
    arg.include = None
    arg.body = False
    arg.json = False
    arg.pretty = "all"
    arg.style = "paraiso-dark"

# Generated at 2022-06-25 19:07:30.901754
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    HTTPRequest_class_0 = HTTPRequest
    str_0 = None
    str_1 = str_0
    None_0 = None
    var_0 = HTTPRequest_class_0(str_1, 'GET', str_1, None_0, None_0, None_0, None_0, None_0, None_0, None_0)
    var_1 = write_stream(var_0, var_0, var_0)



# Generated at 2022-06-25 19:07:34.786330
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import types
    requests_message = requests.Request()
    env = {'is_windows': False}
    args = {'prettify': 'all', 'stream': False, 'style': 'fruity'}
    with_headers = True
    with_body = True
    var_0 = build_output_stream_for_message(requests_message, env, args, with_headers, with_body)

    assert isinstance(var_0, types.GeneratorType) == True


# Generated at 2022-06-25 19:07:38.091121
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = None
    env = None
    var_0 = get_stream_type_and_kwargs(env, args)


# Generated at 2022-06-25 19:07:38.982492
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert True


# Generated at 2022-06-25 19:07:40.283461
# Unit test for function write_message
def test_write_message():
    # Runs test_case_0
    test_case_0()


# Generated at 2022-06-25 19:07:43.248989
# Unit test for function write_stream
def test_write_stream():
    try:
        # Should be an IOError
        test_case_0()
    except IOError as e:
        assert e.errno == errno.EPIPE

# Generated at 2022-06-25 19:09:38.514209
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pytest.skip(
        "TODO: write unit test for function write_stream_with_colors_win_py3"
    )

# Generated at 2022-06-25 19:09:41.902249
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test no exceptions raised when called
    try:
        write_stream_with_colors_win_py3('stream', 'outfile', True)
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 19:09:46.528584
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = argparse.Namespace()
    var_1 = Environment()
    var_2 = requests.Response()
    var_3 = False
    var_4 = True
    res_0 = build_output_stream_for_message(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 19:09:54.370086
# Unit test for function write_message
def test_write_message():
    print('start')
    requests_message = []
    requests_message.append(HTTPRequest('GET / HTTP/1.1\nHost: www.google.com\nheader: value\n'))
    requests_message.append(HTTPResponse('HTTP/1.1 302 Found\nheader: value\n\n'))
    env = Environment()