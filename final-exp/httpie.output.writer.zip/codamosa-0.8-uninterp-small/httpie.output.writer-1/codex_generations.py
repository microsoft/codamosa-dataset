

# Generated at 2022-06-25 19:00:06.485213
# Unit test for function write_stream
def test_write_stream():
    stream_class = (lambda x, y: x == y) and ((lambda x, y: x == y) and (lambda x, y: x == y))
    stream_kwargs = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
    outfile = [{}]
    flush = [{}]
    test_write_stream_0 = write_stream(stream_class, outfile[0], flush[0])


# Generated at 2022-06-25 19:00:17.239039
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    dict_0 = {'debug': False, 'verbose': False, 'json': False, 'stream': False, 'body': False, 'headers': False, 'style': 'paraiso-dark', 'prettify': (), 'format': None, 'format_options': {}, 'style_options': {}, 'traceback': False}
    namespace_0 = module_1.Namespace(**dict_0)
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    if tuple_0 != (module_0.output.streams.EncodedStream, {'env': environment_0}):
        test_case_0()

# Generated at 2022-06-25 19:00:25.561056
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    dict_0 = {'1': 1, '2': 2, '3': 3}
    request_0 = requests.PreparedRequest()
    request_0.body = b'body'
    request_0.headers = dict_0
    request_0.method = 'GET'
    request_0.url = 'http://httpbin.org/get'
    namespace_0 = module_1.Namespace(**dict_0)
    write_message(request_0, environment_0, namespace_0)

# Generated at 2022-06-25 19:00:35.653854
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class BaseStream:
        chunk = b''
    class DummyFile:
        def __init__(self, encoding):
            self.encoding = encoding
        def buffer(self):
            return self
        def write(self, chunk):
            pass
    class FileLike:
        def __init__(self, encoding, outfile):
            self.encoding = encoding
            self.outfile = outfile
        def write(self, chunk):
            self.outfile.write(chunk.decode(self.encoding))
            self.outfile.flush()

    def write(chunk):
        assert chunk == '\x1b[1;34m<!DOCTYPE html>\x1b[39;49;00m'
    file = DummyFile('utf-8')
    file.write = write
   

# Generated at 2022-06-25 19:00:46.038349
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    file_0 = open('/dev/null', 'w')
    mock_0 = MagicMock(spec=BaseStream)
    def mock_gen_1(mock_obj):
        for dummy_i in range(1, 2):
            chunk_0 = b'\x1b['
            yield chunk_0
    mock_0.__iter__.side_effect = mock_gen_1
    mock_0.__iter__.return_value = mock_0
    mock_1 = MagicMock()
    write_stream_with_colors_win_py3(mock_0, file_0, True)
    mock_0.__iter__.assert_called_once_with(mock_0)
    mock_1.buffer.write.assert_not_called()
    mock_1.write.assert_called

# Generated at 2022-06-25 19:00:47.061851
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    pass


# Generated at 2022-06-25 19:00:55.657376
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    dict_0 = {}
    namespace_0 = module_1.Namespace(**dict_0)
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert(type(tuple_0) == tuple)
    assert(type(tuple_0[0]) == type(module_0.BaseStream))
    assert(len(tuple_0[1]) == 1)
    assert(type(tuple_0[1]['env']) == type(environment_0))

import httpie.models as module_0

# Generated at 2022-06-25 19:01:04.509108
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Python3
    environment_0 = module_0.Environment()
    # Non-tty, so output should be raw
    namespace_0_0 = module_1.Namespace(**{"prettify": [], "stream": False, "style": "default"})
    # Non-tty, so output should be raw
    namespace_0_1 = module_1.Namespace(**{"prettify": ["colors"], "stream": False, "style": "default"})
    # Non-tty, so output should be raw, even though the user set prettify
    namespace_0_2 = module_1.Namespace(**{"prettify": ["colors"], "stream": True, "style": "default"})

    # TTY
    environment_1 = module_0.Environment(is_windows=False)
    environment_1._std

# Generated at 2022-06-25 19:01:05.259157
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass

# Generated at 2022-06-25 19:01:16.731359
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():


    def test_build_output_stream_for_message_0():
        environment_1 = module_0.Environment()
        dict_1 = {}
        namespace_1 = module_1.Namespace(**dict_1)

        class requests_PreparedRequest_0():
            pass

        requests_PreparedRequest_0_instance = requests_PreparedRequest_0()
        tuple_0 = build_output_stream_for_message(
            namespace_1, 
            environment_1, 
            requests_PreparedRequest_0_instance,
            True, 
            True,
        )

    def test_build_output_stream_for_message_1():
        environment_2 = module_0.Environment()
        dict_2 = {}
        namespace_2 = module_1.Namespace(**dict_2)


# Generated at 2022-06-25 19:01:28.096749
# Unit test for function write_stream
def test_write_stream():
    # Test with test_message
    test_message = "test_message"
    test_filename = "test_file"
    test_file = open(test_filename, "w")
    stream = RawStream(test_message, test_message)
    write_stream(stream, test_file, 1)
    test_file.close()
    new_test_file = open(test_filename, "r")
    new_test_message = new_test_file.readline()
    assert new_test_message == test_message

# Generated at 2022-06-25 19:01:37.204601
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    dict_0 = {}
    namespace_0 = module_1.Namespace(**dict_0)
    environment_0 = module_0.Environment()
    bool_0 = False
    list_0 = []
    requests_response_0 = requests.Response()
    yield from build_output_stream_for_message(namespace_0, environment_0, requests_response_0, bool_0, bool_0)

if __name__ == "__main__":
    import __main__
    test_case_0()
    test_build_output_stream_for_message()
    __main__.main()

# Generated at 2022-06-25 19:01:37.725407
# Unit test for function write_message
def test_write_message():
    return None


# Generated at 2022-06-25 19:01:45.499145
# Unit test for function write_message
def test_write_message():
    def test_write_message_0():
        namespace_0 = module_1.Namespace(**{})
        environment_0 = module_0.Environment()
        tuple_0 = test_case_0()
        test_write_message_0_0(tuple_0, namespace_0, environment_0)

    # Test for write_message with arguments
    #     env = Environment()
    #     args = argparse.Namespace()
    def test_write_message_0_0(tuple_0, namespace_0, environment_0):
        assert get_stream_type_and_kwargs(environment_0, namespace_0) == tuple_0

# Generated at 2022-06-25 19:01:48.729669
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    dict_0 = {}
    namespace_0 = module_1.Namespace(**dict_0)
    class_0 = module_0.Environment
    # assert write_message is False


# Generated at 2022-06-25 19:01:59.714179
# Unit test for function write_stream
def test_write_stream():
    list_0 = []

# Generated at 2022-06-25 19:02:09.244572
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace(**dict)
    try:
        write_stream_with_colors_win_py3(**dict)
    except IOError as e:
        e.errno = IOError_errno
        show_traceback = namespace_0.debug or namespace_0.traceback
        if not show_traceback and e.errno == IOError_errno:
            environment_0.stderr.write(str_0)
        else:
            raise


# Generated at 2022-06-25 19:02:10.516429
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(dict, object, bool) == NotImplemented


# Generated at 2022-06-25 19:02:21.584874
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    # python3 does not have buffer so we will use a file like object to mock it
    class MockFileLike:
        def __init__(self):
            self.data = b''

        def write(self, buffer):
            self.data += buffer

    # python3 does not have buffer so we will use a file like object to mock it
    class MockFileLike:
        def __init__(self):
            self.data = b''

        def write(self, buffer):
            self.data += buffer

    # python3 does not have buffer so we will use a file like object to mock it
    class MockFileLike:
        def __init__(self):
            self.data = b''

        def write(self, buffer):
            self.data += buffer

    # python3 does not have buffer so we will use a file like object to mock it

# Generated at 2022-06-25 19:02:26.390131
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    dictionary_0 = {"headers": {}, "body": "1234567890"}
    response_0 = requests.Response(**dictionary_0)
    write_message(response_0, environment_0, namespace_0, False, False)
    dictionary_0 = {"headers": {}, "body": "1234567890"}
    response_1 = requests.Response(**dictionary_0)
    write_message(response_1, environment_0, namespace_0, True, False)
    dictionary_0 = {"headers": {}, "body": "1234567890"}
    response_2 = requests.Response(**dictionary_0)
    write_message(response_2, environment_0, namespace_0, False, True)


# Generated at 2022-06-25 19:02:39.065837
# Unit test for function write_message
def test_write_message():
    requests_message = 0
    environment_1 = module_0.Environment()
    namespace_1 = module_1.Namespace()
    write_message(requests_message, environment_1, namespace_1, False, False)


# Generated at 2022-06-25 19:02:44.486157
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_0:requests.PreparedRequest = requests.PreparedRequest()
    environment_0 = module_0.Environment()
    namespace_0:argparse.Namespace = module_1.Namespace()
    build_output_stream_for_message(namespace_0,environment_0,requests_message_0,False,False)


# Generated at 2022-06-25 19:02:46.745743
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

import httpie.output.streams as module_0
import httpie.output.processing as module_1
import httpie.models as module_2
import httpie.context as module_3


# Generated at 2022-06-25 19:02:56.559655
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        # If a common operation takes more than one
        # second to execute, it is probably something
        # wrong with your code.
        assert(os.path.exists("test/test.py"))
        environment_0 = module_0.Environment()
        namespace_0 = module_1.Namespace()
        tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
        write_stream_with_colors_win_py3(tuple_0[0], sys.stdout, True)
        assert(os.path.exists("test/test.py"))
    except:
        if os.path.exists("test/test.py"):
            os.remove("test/test.py")
        raise

# Generated at 2022-06-25 19:03:00.865792
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    yield from tuple_0[0](msg=tuple_0[1]["env"])


# Generated at 2022-06-25 19:03:04.472812
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_1.Namespace()
    tuple_0 = build_output_stream_for_message(namespace_0, namespace_0, namespace_0, False, False)


# Generated at 2022-06-25 19:03:06.953402
# Unit test for function write_stream
def test_write_stream():
    stream = BaseStream()
    out_file = IO()
    flush = True
    print("")
    write_stream(stream,out_file, flush)

# Generated at 2022-06-25 19:03:14.514515
# Unit test for function write_message
def test_write_message():
    codebranch_0 = '---@var environment_0: httpie.context.Environment'
    codebranch_1 = '---@var namespace_0: argparse.Namespace'
    tuple_0 = (0, )
    try:
        write_message(tuple_0, codebranch_0, codebranch_1, True, False)
    except TypeError as inst_0:
        print(inst_0)
    else:
        print('No Exception')


# Generated at 2022-06-25 19:03:21.423683
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = build_output_stream_for_message(namespace_0, environment_0, tuple_0, True, True)
    assert type(tuple_1) == tuple
    tuple_2 = build_output_stream_for_message(namespace_0, environment_0, tuple_0, True, False)
    assert type(tuple_2) == tuple
    tuple_3 = build_output_stream_for_message(namespace_0, environment_0, tuple_0, False, True)
    assert type(tuple_3) == tuple
    tuple_4 = build_output_stream_for_message

# Generated at 2022-06-25 19:03:32.445994
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    class requests_PreparedRequest:
        def __init__(self, ):
            pass

    requests_message_0 = requests_PreparedRequest()
    with_headers_0 = True
    with_body_0 = True
    assert build_output_stream_for_message(namespace_0, environment_0, requests_message_0, with_headers_0, with_body_0) == (b'', b'', b'')
    requests_message_0 = requests_PreparedRequest()
    with_headers_0 = True
    with_body_0 = True

# Generated at 2022-06-25 19:03:55.005009
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_0 = module_0.BaseStream()
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = 'colors'
    namespace_0.stream = False
    namespace_0.style = 'slate'
    namespace_0.json = False
    namespace_0.format_options = {'b': 'b'}
    requests_prepared_request_0 = requests.PreparedRequest()
    text_0 = write_stream_for_message(environment_0, namespace_0, requests_prepared_request_0, True, True)
    try:
        write_stream_with_colors_win_py3(stream_0, text_0, True)
    except IOError as e:
        pass


# Generated at 2022-06-25 19:04:03.764480
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_2 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_3 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_4 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_5 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_6 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:04:09.126878
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    fd_0 = open('fd_0', 'w')
    stream_0 = BaseStream()
    write_stream_with_colors_win_py3(stream_0, fd_0, True)


# Generated at 2022-06-25 19:04:17.017396
# Unit test for function write_message
def test_write_message():
    o_0 = module_0.Environment()
    class_0 = module_1.Namespace()
    b_0 = True
    class_1 = module_1.Namespace()
    class_1.prettify = module_1.Namespace()
    class_1.prettify.__doc__ = ':arg int_0: An integer.\n\n    :arg float_0: A float.'
    b_1 = bool.from_bytes(b'\x00\x00\x00\x00', byteorder='big', signed=False)
    class_1.stream = b_1
    class_1.pretty = b_1
    class_2 = requests.PreparedRequest()
    class_2.body = b''

# Generated at 2022-06-25 19:04:28.069361
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_0 = tuple_0[0]
    tuple_1 = tuple_0[1]
    base_stream_0 = stream_class_0(None, None, None, **tuple_1)
    str_0 = "\u4fe1\u4efb"
    tuple_2 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_1 = tuple_2[0]
    tuple_3 = tuple_2[1]
    base_stream_1 = stream_class_1(None, None, None, **tuple_3)

# Generated at 2022-06-25 19:04:29.101383
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:04:32.213944
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert callable(write_stream_with_colors_win_py3)


# Generated at 2022-06-25 19:04:40.234230
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream = tuple_0[0]
    stream = tuple_0[0]
    stream = tuple_0[0]
    outfile = stream.outfile
    outfile = stream.outfile
    outfile = stream.outfile
    
    flush = tuple_0[1]['flush']
    flush = tuple_0[1]['flush']
    flush = tuple_0[1]['flush']

    write_stream_with_colors_win_py3(stream, outfile, flush)


# Generated at 2022-06-25 19:04:47.235073
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = BufferedPrettyStream(
        msg=HTTPRequest(requests.PreparedRequest()),
        with_headers=False,
        with_body=False,
        env=Environment(),
        conversion=Conversion(),
        formatting=Formatting(
            env=Environment(),
            groups=[],
            color_scheme=None,
            explicit_json=False,
            format_options={}
        )
    )
    outfile = TextIOWrapper(BytesIO())
    flush = False
    write_stream_with_colors_win_py3(stream, outfile, flush)



# Generated at 2022-06-25 19:04:52.979045
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Stream:
        def __iter__(self):
            yield b"\x1b[1mhello\x1b[0m\nworld"

    stream = Stream()
    outfile = io.StringIO()
    flush = True

    ref = io.BytesIO()
    write_stream(stream, ref, flush)
    ref.seek(0)
    write_stream_with_colors_win_py3(stream, outfile, flush)

    assert outfile.getvalue() == '\x1b[1mhello\x1b[0m\nworld'
    assert ref.read() == b'\x1b[1mhello\x1b[0m\nworld'

# Generated at 2022-06-25 19:05:07.096542
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    write_stream(tuple_0[0], tuple_0[1]['env'].stdout, False)



# Generated at 2022-06-25 19:05:10.803700
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_request_0 = requests.PreparedRequest()
    write_message(prepared_request_0, environment_0, namespace_0, True, True)


# Generated at 2022-06-25 19:05:20.663808
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Setup arguments for function call
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()

    # Call function
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

    # Check if the return value is correct
    if type(tuple_0) is not tuple:
        raise ValueError("get_stream_type_and_kwargs() returned an incorrect type")

    # Get the first return value
    actual_return_value_0 = tuple_0[0]

    # Check if the first return value is correct
    if type(actual_return_value_0) is not type:
        raise ValueError("get_stream_type_and_kwargs() returned an incorrect type for value #0 (return_value_0)")

# Generated at 2022-06-25 19:05:30.542312
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    str_0 = '\x1b['
    str_1 = str_0.encode()
    tuple_0 = ()
    tuple_1 = (tuple_0, )
    tuple_2 = (tuple_1, )
    tuple_3 = (tuple_2, )
    tuple_4 = (tuple_3, )
    tuple_5 = (tuple_4, )
    tuple_6 = (tuple_5, )
    tuple_7 = (tuple_6, )
    tuple_8 = (tuple_7, )
    tuple_9 = (tuple_8, )
    tuple_10 = (tuple_9, )
    tuple_11 = (tuple_10, )
    tuple_12 = (tuple_11, )

# Generated at 2022-06-25 19:05:32.966323
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(namespace_0, environment_0, namespace_0, True, True)


# Generated at 2022-06-25 19:05:37.047322
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    result = get_stream_type_and_kwargs(
        env=module_0.Environment(),
        args=module_1.Namespace())
    assert result == (
        module_0.RawStream,
        {'chunk_size': module_0.RawStream.CHUNK_SIZE})

# Generated at 2022-06-25 19:05:46.182382
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    raw_stream_0 = tuple_0[0]()
    namespace_0.stream = True
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    raw_stream_1 = tuple_1[0]()
    namespace_0.stream = False
    tuple_2 = get_stream_type_and_kwargs(environment_0, namespace_0)
    raw_stream_2 = tuple_2[0]()
    namespace_0.stream = True
    tuple_3 = get_stream_type_and_kwargs(environment_0, namespace_0)
    raw

# Generated at 2022-06-25 19:05:55.782751
# Unit test for function write_stream
def test_write_stream():
    stream_class_0, stream_kwargs_0 = get_stream_type_and_kwargs(module_0.Environment(), module_1.Namespace())
    stream_0 = stream_class_0(msg=module_0.HTTPRequest(mock.Mock()), with_headers=False, with_body=False, **stream_kwargs_0)
    outfile_0 = __random_bytes(__random_integer_0, __random_integer_1, __random_boolean_0)
    flush_0 = __random_boolean_1

    write_stream(stream_0, outfile_0, flush_0)

    # unit test for write_stream()

# Generated at 2022-06-25 19:05:56.659444
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True



# Generated at 2022-06-25 19:06:07.948367
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_0 = tuple_0[0]
    stream_kwargs_0 = tuple_0[1]

# Generated at 2022-06-25 19:06:19.829749
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(environment_0, namespace_0, True, True)

# Generated at 2022-06-25 19:06:20.613232
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    ...


# Generated at 2022-06-25 19:06:30.249789
# Unit test for function write_stream
def test_write_stream():
    tmpdir = py.path.local(mkdtemp())
    first_file = tmpdir.join('write_stream_first_file.txt')
    second_file = tmpdir.join('write_stream_second_file.txt')
    write_stream(["first\n", "second", "\n"], first_file, flush=True)
    write_stream(["first", "\n", "second", "\n"], second_file, flush=True)

    # - Verify that write_stream writes to a file correctly.
    assert first_file.read() == ""
    assert second_file.read() == "first\nsecond\n"
    # - Verify that write_stream writes to a buffer assigned to a file correctly.

# Generated at 2022-06-25 19:06:35.606457
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    textio_0 = sys.stderr
    write_stream_with_colors_win_py3(tuple_0[0], textio_0, True)


# Generated at 2022-06-25 19:06:42.601059
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import pytest

    environment_0 = module_0.Environment()

    namespace_0 = module_1.Namespace(
        colors=None,
        debug=False,
        download=False,
        form=False,
        headers=False,
        output=None,
        output_dir=None,
        output_file=None,
        prettify=None,
        print_body=True,
        print_headers=False,
        print_status=False,
        print_verbose_body=False,
        print_version=False,
        style=None,
    )


# Generated at 2022-06-25 19:06:43.171796
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-25 19:06:50.723944
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from io import BytesIO
    from httpie.output.streams import RawStream
    from httpie.models import HTTPRequest
    from httpie.context import Environment

    args = argparse.Namespace()
    env = Environment()
    req = HTTPRequest(requests.PreparedRequest())

    stream = build_output_stream_for_message(args, env, req, True, True)
    assert type(stream) == RawStream

    stream = build_output_stream_for_message(args, env, req, False, True)
    assert type(stream) == RawStream

    stream = build_output_stream_for_message(args, env, req, True, False)
    assert type(stream) == RawStream

    stream = build_output_stream_for_message(args, env, req, False, False)
    assert stream

# Generated at 2022-06-25 19:06:51.676648
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    pass


# Generated at 2022-06-25 19:06:55.052805
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # AssertionError: expected <httpie.output.streams.EncodedStream object at 0x7fab7594cd30> not to be equal to <httpie.output.streams.EncodedStream object at 0x7fab7594cd68>

    assert False


# Generated at 2022-06-25 19:07:01.114036
# Unit test for function write_stream
def test_write_stream():
    from unittest.mock import mock_open, patch

    # Make sure no exceptions are thrown, and that calls to write() are made
    with patch("builtins.open", mock_open()) as mock_file:
        write_stream(None, mock_file.return_value, False)
        write_stream(None, mock_file.return_value, True)

# Generated at 2022-06-25 19:07:29.448735
# Unit test for function write_stream
def test_write_stream():
    # FIXME: Create a mock client and then use it to generate a fake response

    # Create the output stream to write to the fake response
    # Write the stream, using the flags to determine what body and headers are printed and the stdout to print to
    pass


# Generated at 2022-06-25 19:07:31.012156
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert write_stream_with_colors_win_py3() == None


# Generated at 2022-06-25 19:07:31.798712
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Code
    pass


# Generated at 2022-06-25 19:07:43.249846
# Unit test for function write_stream
def test_write_stream():
    test_0 = module_1.Namespace()
    test_1 = module_0.Environment()
    test_2 = module_1.Namespace()
    test_3 = module_1.Namespace()
    test_4 = module_1.Namespace()
    test_5 = module_1.Namespace()
    test_6 = module_1.Namespace()
    test_7 = module_1.Namespace()
    test_8 = module_1.Namespace()
    test_9 = module_1.Namespace()
    write_stream(test_0, test_1, test_2)
    write_stream(test_3, test_4, test_5)
    write_stream(test_6, test_7, test_8)

# Generated at 2022-06-25 19:07:47.506253
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    True
    write_message(None, environment_0, namespace_0, True, True)
    False
    write_message(None, environment_0, namespace_0, False, False)


# Generated at 2022-06-25 19:07:52.468689
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Note: The test on win is commented out.
    # It isn't ready or not needed.
    assert callable(get_stream_type_and_kwargs)
    assert isinstance(get_stream_type_and_kwargs(object(), object()), tuple)
    assert len(get_stream_type_and_kwargs(object(), object())) == 2
    print("Passed")


if __name__ == "__main__":
    test_get_stream_type_and_kwargs()

# Generated at 2022-06-25 19:08:00.180624
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.format_options = 0
    namespace_0.style = 0
    namespace_0.stream = 0
    namespace_0.debug = 0
    namespace_0.traceback = 0
    namespace_0.prettify = 0
    namespace_0.json = 0
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_0[0](tuple_0[1])


# Generated at 2022-06-25 19:08:01.071234
# Unit test for function write_stream
def test_write_stream():
    assert write_stream()


# Generated at 2022-06-25 19:08:06.296905
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_0 = tuple_0[0](conversion=Conversion())
    write_stream_with_colors_win_py3(stream_0, environment_0.stdout, False)

# Generated at 2022-06-25 19:08:12.453643
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_request_0 = requests.PreparedRequest()
    write_message(prepared_request_0, environment_0, namespace_0)
    response_0 = requests.Response()
    write_message(response_0, environment_0, namespace_0)


# Generated at 2022-06-25 19:09:53.950184
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class MockBuffer:
        def write(self, text):
            return None

    class MockTextIO:
        def __init__(self):
            self.encoding = None
            self.buffer = MockBuffer()

    class MockBaseStream:
        def __init__(self, *args, **kwargs):
            self.stream = None

        def __iter__(self):
            return self

        def __next__(self):
            if self.stream:
                return next(self.stream)
            raise StopIteration()

        def close(self):
            return None

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            return None

        def __bool__(self):
            return True
