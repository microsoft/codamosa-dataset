

# Generated at 2022-06-25 19:00:17.031844
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    bytes_0 = b'\x1b[1md\x1b[0m'
    bytes_1 = b'\x1b[2K\x1b[A\x1b[1md\x1b[0m'
    stream_0 = get_stream_type_and_kwargs(None, None)[0](None, True, True, **{})
    write_stream_with_colors_win_py3(stream_0, None, None)
    stream_1 = get_stream_type_and_kwargs(None, None)[0](None, True, True, **{})
    write_stream_with_colors_win_py3(stream_1, None, None)

# Generated at 2022-06-25 19:00:29.252462
# Unit test for function write_message
def test_write_message():
    print("Test: write_message")
    test_arg_namespace = argparse.Namespace()
    test_arg_namespace.prettify = ["all"]
    test_arg_namespace.json = False
    test_arg_namespace.stream = True
    test_arg_namespace.traceback = True
    test_arg_namespace.debug = True
    test_arg_namespace.download = False
    test_arg_namespace.format_options = None
    test_arg_namespace.style = None
    test_environment = None
    test_message_0 = None
    test_message_type = type(test_message_0)
    test_message_type_0 = requests.PreparedRequest
    test_message_type_1 = requests.Response

# Generated at 2022-06-25 19:00:37.603704
# Unit test for function write_stream
def test_write_stream():
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    stream_0 = BaseStream()
    outfile_0 = sys.stdout
    flush_0 = 'flush_0'
    test_write_stream(stream_0, outfile_0, flush_0)

    namespace_0 = argparse.Namespace()
    stream_0 = BaseStream()
    outfile_0 = sys.stdout
    flush_0 = 'flush_0'
    test_write_stream(stream_0, outfile_0, flush_0)

    namespace_0 = argparse.Namespace()
    stream_0 = BaseStream()
    outfile_0 = sys.stdout
    flush_0 = 'flush_0'
    test_write_stream(stream_0, outfile_0, flush_0)

# Generated at 2022-06-25 19:00:44.454798
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_1 = Environment()
    namespace_1 = argparse.Namespace(download=False, json=False, prettify=None,
                                     style=None, stream=False)
    namespace_1.style = "test_style"
    namespace_1.json = True
    namespace_1.download = False
    namespace_1.stream = False
    namespace_1.prettify = ""
    assert build_output_stream_for_message(namespace_1, environment_1,
            object, object, object) == None

# Generated at 2022-06-25 19:00:54.758623
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Get the tuple of types and kwargs from function get_stream_type_and_kwargs

    # Test for valid inputs
    environment_1 = Environment(output_options=None, output_stream=None, stdout=None, stdout_isatty=True)
    namespace_1 = argparse.Namespace(prettify=None, stream=False, style=False, json=False, format_options=None, debug=False, traceback=False, download=False)
    stream_class_1, stream_kwargs_1 = get_stream_type_and_kwargs(environment_1, namespace_1)
    assert stream_class_1 == EncodedStream
    assert stream_kwargs_1 == {'env': environment_1}


# Generated at 2022-06-25 19:00:57.955026
# Unit test for function write_message
def test_write_message():
    requests_message_0 = None
    environment_0 = None
    namespace_0 = None
    write_message(requests_message_0, environment_0, namespace_0)


# Generated at 2022-06-25 19:01:06.849325
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    assert get_stream_type_and_kwargs(
        environment_0,
        namespace_0,
    ) == (EncodedStream, {'env': environment_0})
    environment_1 = Environment(debug=False, is_windows=False)
    namespace_1 = argparse.Namespace(
        force_colors=False,
        json=False,
        pretty=False,
        stream=False,
    )
    assert get_stream_type_and_kwargs(
        environment_1,
        namespace_1,
    ) == (EncodedStream, {'env': environment_1})
    environment_2 = Environment(debug=True, is_windows=False)

# Generated at 2022-06-25 19:01:09.603632
# Unit test for function write_stream
def test_write_stream():
    fd_0 = None
    buf_0 = fd_0
    chunk_0 = None
    write_stream(stream=buf_0, outfile=fd_0, flush=chunk_0)



# Generated at 2022-06-25 19:01:17.397690
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """
    Asserts if the function `build_output_stream_for_message`
    is working as expected.
    """
    requests_prepared_request_0 = None
    environment_0 = None
    namespace_0 = None
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0,
                                              requests_prepared_request_0, 0, 0)



# Generated at 2022-06-25 19:01:24.522764
# Unit test for function write_message

# Generated at 2022-06-25 19:01:42.688828
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    arguments_0 = argparse.Namespace()
    arguments_0.debug = None
    arguments_0.traceback = None
    arguments_0.stream = None
    arguments_0.stream = None
    arguments_0.download = None
    arguments_0.download_all = None
    arguments_0.download_output = None
    arguments_0.continue_download = None
    arguments_0.stream_output = None
    arguments_0.output = None
    arguments_0.verbose = None
    arguments_0.verbose = None
    arguments_0.verbose = None
    arguments_0.verbose = None
    arguments_0.style = None
    arguments_0.style = None
    arguments_0.validate_ssl = None
    arguments_0.print_bodies = None
    arguments_0.json

# Generated at 2022-06-25 19:01:52.819319
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Setup test data
    buffer = b'\x1b[91mError\x1b[0m: Invalid user identifier.\nHTTP/1.1 401 Unauthorized\nContent-Length: 0\nContent-Type: text/plain; charset=utf-8\nDate: Thu, 11 Feb 2016 21:43:44 GMT\nWww-Authenticate: Basic realm="User Visible Realm"\n\n'
    args = None
    env = None

# Generated at 2022-06-25 19:02:02.279715
# Unit test for function write_message
def test_write_message():
    import sys
    import inspect
    import copy

    # print(str(sys.modules[__name__]) + ": " + inspect.stack()[0][3] + " has started running")

    # Set up environment
    environment_0 = Environment()
    namespace_0 = Namespace()

    # Test 1
    if True:
        namespace_0 = Namespace()
        namespace_0.stdout = sys.stderr

        # Calls
        test_write_message_helper(environment_0, namespace_0)

    # Test 2
    if True:
        namespace_0 = Namespace()
        namespace_0.stream = True
        namespace_0.prettify = 'colors'
        namespace_0.prettify = 'colors'
        namespace_0.stream = True

# Generated at 2022-06-25 19:02:12.790015
# Unit test for function write_stream
def test_write_stream():
    try:
        import requests
    except ImportError:
        skip('requests not installed')
    else:
        url_1 = 'http://httpbin.org/get?a=b&c=d&e=f'
        requests_message_1 = requests.PreparedRequest()
        namespace_1 = argparse.Namespace(stream=False, prettify=False)
        environment_1 = Environment(
            colors=256,
            stdin=stdin,
            stdout=stdout,
            stderr=stderr
        )
        write_stream(
            build_output_stream_for_message(
                namespace_1, environment_1, requests_message_1, False, True
            ),
            stdout,
            False
        )
        # TODO: Add more tests here


# Generated at 2022-06-25 19:02:13.872237
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert True is True


# Generated at 2022-06-25 19:02:17.274066
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = None
    namespace_0 = None
    assert get_stream_type_and_kwargs(environment_0, namespace_0) == (EncodedStream, {'env': None})



# Generated at 2022-06-25 19:02:21.394181
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = None
    namespace_0 = None
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    print("line:", list(tuple_0)[0].__name__)


# Generated at 2022-06-25 19:02:26.166382
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = None
    args = None
    assert type(get_stream_type_and_kwargs(env, args)) == tuple
    namespace = argparse.Namespace()
    environment = Environment()
    assert type(get_stream_type_and_kwargs(environment, namespace)) == tuple


# Generated at 2022-06-25 19:02:30.663015
# Unit test for function write_stream
def test_write_stream():
    try:
        stream = 'stream'
        outfile = 'outfile'
        flush = 'flush'

        # Passing the below values would not raise an exception.
        write_stream(stream, outfile, flush)
    except Exception as e:
        print('Exception raised: ')
        raise e


# Generated at 2022-06-25 19:02:40.679858
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    bytes_0 = b'8\x1a\x1cA\xa5\xb1\xf8\xa7\x14\x19\x9e[\x15\x96\xf6\x1a\xd5c\x03\xa7\x9b\xd2\xfa\xc7\x15\xb1\xc1\xf0/\x10\r:<]}'
    stream_0 = io.BytesIO(bytes_0)
    environment_0 = None
    namespace_0 = None
    write_stream_with_colors_win_py3(stream_0, namespace_0, environment_0)

# Generated at 2022-06-25 19:02:53.281216
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    func_0 = lambda: (lambda arg_0, arg_1: arg_1)()
    var_0 = get_stream_type_and_kwargs(func_0(), (lambda arg_0: arg_0))

if __name__ == '__main__':
    test_case_0()
    test_get_stream_type_and_kwargs()

# Generated at 2022-06-25 19:02:57.069387
# Unit test for function write_message
def test_write_message():
    requests_message = HTTPRequest('GET 1.1')
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False

    var_0 = write_message(requests_message, env, args, with_headers, with_body)


# Generated at 2022-06-25 19:02:59.266453
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        test_case_0()
    except AssertionError:
        return 1
    except Exception:
        return 1

# Generated at 2022-06-25 19:03:03.795996
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment(True, True, True, True, True, 'REQUEST_BUFFER_SIZE', )
    str_0 = 'stream'
    var_0 = get_stream_type_and_kwargs(env_0, str_0)


# Generated at 2022-06-25 19:03:06.608828
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    env = Environment()
    requests_message = build_output_stream_for_message(args, env, 'request', 1, 1)


# Generated at 2022-06-25 19:03:17.465741
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # 1st test
    # Check if TypeError raised when passed arg not of type
    # JsonObject or dict
    args = argparse.Namespace()

    # TypeError
    with pytest.raises(TypeError) as excinfo:
        build_output_stream_for_message('', '', '', '', '')
    assert str(excinfo.value) == 'Input of requests_message must be of type requests.PreparedRequest or requests.Response'

    # TypeError
    with pytest.raises(TypeError) as excinfo:
        build_output_stream_for_message(args, '', '', '', '')
    assert str(excinfo.value) == 'Input of env must be of type Environment'

    # TypeError
    with pytest.raises(TypeError) as excinfo:
        build_

# Generated at 2022-06-25 19:03:19.294448
# Unit test for function write_message
def test_write_message():
    str_0 = 'stream'
    var_0 = write_message(str_0, str_0, str_0)


# Generated at 2022-06-25 19:03:21.327564
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = BufferedPrettyStream
    assert(var_0 == 1)



# Generated at 2022-06-25 19:03:32.350084
# Unit test for function write_message
def test_write_message():
    str_0 = 'pretty'
    str_1 = 'stream'
    str_2 = 'json'
    str_3 = '--pretty'
    str_4 = '--stream'
    str_5 = '--download'
    # Test HTTP Request
    var_0 = requests.PreparedRequest()

# Generated at 2022-06-25 19:03:32.975740
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-25 19:03:40.896407
# Unit test for function write_stream
def test_write_stream():
    str_0 = 'stream'
    stream = write_stream(str_0, str_0, str_0)

# Generated at 2022-06-25 19:03:44.245330
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    env = Environment()
    args = argparse.Namespace()
    req = HTTPRequest()
    write_stream_with_colors_win_py3(req, env.stdout, args.stream)


# Generated at 2022-06-25 19:03:55.094757
# Unit test for function write_message
def test_write_message():
    str_0 = 'Connection'
    str_1 = 'headers'
    flag_1 = False
    flag_0 = False
    if str_0 in str_1:
        flag_0 = True

    if not flag_0:
        str_2 = 'form'
        str_3 = 'json'
        flag_3 = False
        flag_2 = False
        if str_2 in str_3:
            flag_2 = True

        if not flag_2:
            str_4 = 'www'
            str_5 = 'form'
            flag_5 = False
            flag_4 = False
            if str_4 in str_5:
                flag_4 = True

            if not flag_4:
                str_6 = 'www'
                str_7 = 'form'
                flag_7 = False


# Generated at 2022-06-25 19:03:59.064841
# Unit test for function write_stream
def test_write_stream():
    instance = RawStream('stream')
    try:
        data1 = instance.buffer.read()
    except AttributeError:
        data1 = instance.read()
    data2 = instance.read()
    data3 = instance.read()
    data4 = instance.read()
    assert (data1==data2==data3==data4)


# Generated at 2022-06-25 19:04:01.647306
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    str_0 = 'stream'
    var_0 = write_stream_with_colors_win_py3(str_0, str_0, str_0)

# Generated at 2022-06-25 19:04:03.617448
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    str_0 = 'stream'
    var_0 = get_stream_type_and_kwargs(str_0, str_0)

# Generated at 2022-06-25 19:04:09.355997
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    str_0 = 'outfile'
    str_1 = 'stream'
    str_2 = 'flush'
    var_0 = write_stream_with_colors_win_py3(str_1, str_0, str_2)


# Generated at 2022-06-25 19:04:18.311935
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.style = None
    args.json = None
    args.format_options = None
    args.stream = False

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )

    assert stream_class.__name__ == 'BufferedPrettyStream'
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__.__name__ == 'Conversion'
    assert stream_kwargs['formatting'].__class__.__name__ == 'Formatting'


# Generated at 2022-06-25 19:04:28.648389
# Unit test for function write_stream
def test_write_stream():
    str_0: str = 'stream'
    obj_0: BaseStream = EncodedStream(str_0, str_0, str_0)
    obj_1: BufferedPrettyStream = BufferedPrettyStream(str_0, str_0, str_0)
    obj_2: PrettyStream = PrettyStream(str_0, str_0, str_0)
    obj_3: RawStream = RawStream(str_0, str_0, str_0)
    obj_4: TextIO = TextIOWrapper(BufferedRandom(RawIOBase()), 'utf-8')
    obj_5: IO = BufferedWriter(RawIOBase())

    write_stream(str_0, obj_4, str_0)
    write_stream(str_0, obj_5, str_0)

# Generated at 2022-06-25 19:04:39.474210
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = 'stream'
    str_1 = 'stream'
    var_0 = write_stream(str_0, str_0, str_0)
    var_1 = write_stream(str_0, str_0, str_0)
    var_2 = env.stdout_isatty or args.stream
    str_2 = 'stream'
    str_3 = 'stream'
    str_4 = 'stream'
    str_5 = 'stream'
    str_6 = 'stream'
    str_7 = 'stream'
    str_8 = 'stream'
    var_3 = (env.stdout_isatty and with_body and not getattr(requests_message, 'is_body_upload_chunk', False))
    var_4 = MESSAGE_SEPARATOR_BY

# Generated at 2022-06-25 19:04:58.076568
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import tempfile
    temp_stdout = tempfile.TemporaryFile('w+')
    from httpie.compat import isatty
    temp_stdout_isatty = isatty(temp_stdout.fileno())
    print(temp_stdout_isatty)

    class FakeArgs:
        def __init__(self):
            self.stream = None
            self.style = 'paraiso-dark'

    class FakeEnv:
        def __init__(self):
            self.stdout_isatty = temp_stdout_isatty

    env = FakeEnv()
    args = FakeArgs()
    get_stream_type_and_kwargs(env=env, args=args)

# Generated at 2022-06-25 19:05:08.243056
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = 'headers'
    str_1 = 'isatty'
    str_2 = 'stream'
    str_3 = 'binary'
    str_4 = 'output'
    str_5 = 'encoding'
    str_6 = 'stream'
    str_7 = 'stream'
    str_8 = 'headers'
    str_9 = 'body'
    str_10 = 'headers'
    str_11 = 'body'
    str_12 = 'headers'
    str_13 = 'body'
    str_14 = 'headers'
    str_15 = 'body'
    str_16 = 'headers'
    str_17 = 'headers'
    str_18 = 'headers'
    str_19 = 'headers'
    str_20 = 'body'

# Generated at 2022-06-25 19:05:09.275915
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert False


# Generated at 2022-06-25 19:05:14.765135
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(prettify=[], style='test',
                              format_options={}, stream=True, json=False,
                              debug=False, traceback=False)
    func_ret_val_0, func_ret_val_1 = get_stream_type_and_kwargs(env, args)
    assert (func_ret_val_0 == PrettyStream)
    #assert (func_ret_val_1.env == env)



# Generated at 2022-06-25 19:05:16.808694
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    str_0 = 'stream'
    var_0 = get_stream_type_and_kwargs(str_0, str_0)


# Generated at 2022-06-25 19:05:28.615562
# Unit test for function write_message
def test_write_message():
    env = Environment()
    env.stdout = 'http://www.example.com'
    env.stdout_isatty = True
    requests_message = requests.Response()
    requests_message.url = 'http://www.example.com/'
    requests_message.headers = {
        'Host': 'www.example.com',
        'Connection': 'close',
        'Accept': '*/*',
        'User-Agent': 'python-requests/2.19.1'
    }
    requests_message.status_code = 200

# Generated at 2022-06-25 19:05:30.637465
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream='stream'
    outfile='outfile'
    flush='flush'
    test_case_0()

# End Unit test for function write_stream_with_colors_win_py3


# Generated at 2022-06-25 19:05:32.807632
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    str_0 = 'stream'
    var_0 = get_stream_type_and_kwargs(str_0, str_0)
    return var_0


# Generated at 2022-06-25 19:05:37.813121
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=False)
    args = argparse.Namespace()
    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': 16384})
#    print (test_case_0())
#test_get_stream_type_and_kwargs()


# Generated at 2022-06-25 19:05:40.340571
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = 'stream'
    outfile = 'outfile'
    flush = 'flush'
    var_0 = write_stream_with_colors_win_py3(stream, outfile, flush)

# Generated at 2022-06-25 19:05:56.855417
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = 'stream'
    str_1 = 'stream'
    str_2 = 'stream'
    str_3 = 'stream'
    str_4 = 'stream'
    str_5 = 'stream'
    str_6 = 'stream'
    pytest.raises(Exception, write_message(str_0, str_1, str_2, str_3, str_4))
    pytest.raises(Exception, write_stream(str_0, str_1, str_2))
    pytest.raises(Exception, write_stream_with_colors_win_py3(str_0, str_1, str_2))
    pytest.raises(Exception, build_output_stream_for_message(str_0, str_1, str_2, str_3, str_4))


# Generated at 2022-06-25 19:05:59.199520
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = 'stream'
    outfile = 'outfile'
    flush = 'flush'

    assert write_stream_with_colors_win_py3(stream, outfile, flush)

# Generated at 2022-06-25 19:06:05.234240
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    env = Environment()
    requests_message = requests.Response()
    with_headers = False
    with_body = False
    var_0 = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)


# Generated at 2022-06-25 19:06:14.255939
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    #
    # assert write_stream_with_colors_win_py3() == '\n'.encode()
    # assert write_stream_with_colors_win_py3() == '\n'.encode()
    #
    # assert write_stream_with_colors_win_py3() == '\n'.encode()
    #

    # Tuple of input values
    cases = [(str_0, str_1, str_2)
        for str_0 in ['stream']
        for str_1 in ['stream']
        for str_2 in ['stream']
    ]
    # Set of expected outputs
    expected = {'\n'.encode()}
    # Iterate through the test cases
    for case in cases:
        args_0, args_1, args_2 = case

# Generated at 2022-06-25 19:06:20.297487
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace(verbose=True, traceback=False, debug=False)
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    var_0 = build_output_stream_for_message(requests_message, env, args, with_headers, with_body)


# Generated at 2022-06-25 19:06:20.881953
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass

# Generated at 2022-06-25 19:06:23.286988
# Unit test for function write_stream
def test_write_stream():
    str_0 = 'stream'
    var_1 = write_stream(str_0, str_0, str_0)
    # assert var_1 == None


# Generated at 2022-06-25 19:06:25.375029
# Unit test for function write_stream
def test_write_stream():
    # Test cases
    test_case_0()



# Generated at 2022-06-25 19:06:33.604700
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import pkg_resources
    import sysconfig

    ret_0 = build_output_stream_for_message(argparse.Namespace, Environment, requests.Response, True, True)
    assert isinstance(ret_0, list)
    # Expanding for write_stream(str_0, str_0, str_0)
    if not sysconfig.get_config_var('CUSTOMIZED_OSX_COMPILER'):
        assert ret_0 == ['HTTP/1.0 200 OK']
    else:
        assert ret_0 == ('HTTP/1.0 200 OK')
    ret_1 = build_output_stream_for_message(pkg_resources.Requirement, Environment, requests.Response, False, False)
    assert ret_1 == []



# Generated at 2022-06-25 19:06:41.659008
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-25 19:06:49.925820
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    str_0 = 'stream'
    var_0 = write_stream(str_0, str_0, str_0)


# Generated at 2022-06-25 19:06:50.688302
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import unittest



# Generated at 2022-06-25 19:07:01.288683
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-25 19:07:05.672526
# Unit test for function write_stream
def test_write_stream():
    try:
        str_0 = 'stream'
        str_1 = 'stream'
        str_2 = 'stream'
        var_0 = write_stream(str_1, str_0, str_2)
    except IOError as e:
        # Ignore broken pipes unless --traceback.
        env.stderr.write('\n')
    except:
        raise


# Generated at 2022-06-25 19:07:16.212487
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # Set so warnings are thrown
    os.environ['HTTPIE_DEBUG'] = '1'

    # 'HTTPRequest' object
    class req_object:
        def __init__(self, method, url, headers):
            self.method = method
            self.url = url
            self.headers = headers
        def __getattribute__(self, name):
            return object.__getattribute__(self, name)
    # 'Response' object
    class res_object:
        def __init__(self, status_code, headers, text):
            self.status_code = status_code
            self.headers = headers
            self.text = text
        def __getattribute__(self, name):
            return object.__getattribute__(self, name)


# Generated at 2022-06-25 19:07:19.307849
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = get_stream_type_and_kwargs(get_stream_type_and_kwargs)
    assert 'argparse' in sys.modules and 'httpie' in sys.modules, 'Missing modules'
    pass


# Generated at 2022-06-25 19:07:22.239516
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    str_0 = 'stream'
    var_0 = write_stream_with_colors_win_py3(str_0, str_0, str_0)

# Generated at 2022-06-25 19:07:26.626971
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = 'stream'
    var_0 = build_output_stream_for_message(str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 19:07:30.789006
# Unit test for function write_message
def test_write_message():
    message = 'message'
    env = ''
    args = ''
    with_headers = 'with_headers'
    with_body = 'with_body'
    var_0 = write_message(message, env, args, with_headers, with_body)


# Generated at 2022-06-25 19:07:32.850517
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    str_0 = 'headers'
    str_1 = 'stream'
    var_0 = write_stream_with_colors_win_py3(str_0, str_0, str_1)


# Generated at 2022-06-25 19:07:55.717187
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import requests
    class Environment:
        def __init__(self):
            self.is_windows = None
            self.stdout_isatty = None
            self.stderr = None
    class argparse:
        class Namespace:
            def __init__(self):
                self.prettify = None
                self.stream = None
                self.style = None
                self.json = None
                self.format_options = None

    env = Environment()
    args = argparse.Namespace()
    req = requests.PreparedRequest()
    req.body = b''
    req.is_body_upload_chunk = True
    write_message(req, env, args, with_headers=True, with_body=True)

# Generated at 2022-06-25 19:08:01.023359
# Unit test for function write_message
def test_write_message():
    requests_message = 'python3 requests module'
    env = 'environment'
    args = 'argparse module'
    with_headers = False
    with_body = False
    
    try:
        var_0 = write_message(requests_message, env, args, with_headers, with_body)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 19:08:02.780041
# Unit test for function write_message
def test_write_message():
    assert True
    msg = 'Func is Done'
    print(msg)



# Generated at 2022-06-25 19:08:05.785522
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = 'stream'
    var_1 = 'stream'

    var_2 = write_stream_with_colors_win_py3(var_0, var_1, var_0)



# Generated at 2022-06-25 19:08:16.043507
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from io import StringIO
    from unittest.mock import Mock
    from unittest.mock import patch

    mock_argparse = patch("argparse.Namespace", autospec=True)

    str_0 = 'stream'
    str_1 = 'kwargs'
    str_2 = 'stream_kwargs'
    str_3 = 'message_class'
    str_4 = 'with_headers'
    str_5 = 'with_body'
    str_6 = 'kwargs'
    str_7 = 'stream_kwargs'
    str_8 = 'requests'
    str_9 = 'with_body'
    str_10 = 'is_body_upload_chunk'
    str_11 = 'yield'

# Generated at 2022-06-25 19:08:19.774507
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class env:
        stdout_isatty = 1
        class stdout:
            buffer = 1
    class argparse:
        Namespace = 1
        class args:
            prettify = 1
            stream = 0
            style = 1
            json = 1
            format_options = 1
    var_1 = env
    var_2 = argparse
    var_3 = get_stream_type_and_kwargs(var_1, var_2.args)


# Generated at 2022-06-25 19:08:28.689996
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    from httpie.output.streams import (BaseStream, BufferedPrettyStream, RawStream)
    from httpie.output.processing import Conversion, Formatting
    env = Environment(stdout_isatty=True)
    args = "args"

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

    assert stream_class == BaseStream
    assert stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE
    assert not stream_kwargs['env'] == env
    assert not stream_kwargs['groups'] == "args"
    assert not stream_kwargs['color_scheme'] == "args"
    assert not stream_kwargs['explicit_json'] == "args"

# Generated at 2022-06-25 19:08:31.890645
# Unit test for function write_message
def test_write_message():
    args = argparse.Namespace()
    env = Environment()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    test_case_0()
    var_1 = write_message(requests_message, env, args, with_headers, with_body)
    assert var_1 == None

# Generated at 2022-06-25 19:08:33.568927
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert callable(write_stream_with_colors_win_py3)



# Generated at 2022-06-25 19:08:42.060563
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    var_0 = FakeEnvironment()
    var_0.stdout_isatty = True
    var_1 = FakeNamespace()
    var_1.prettify = 'colors'
    var_1.stream = False
    var_1.style = 'paraiso-dark'
    var_1.json = False
    var_1.format_options = ''
    var_2 = get_stream_type_and_kwargs(var_0, var_1)
    assert var_2[0] == BufferedPrettyStream
    var_2 = var_2[1]
    assert var_2['env'] == var_0
    assert var_2['conversion'] == Conversion()
    assert var_2['formatting'].env == var_0
    assert var_2['formatting'].groups == var_1

# Generated at 2022-06-25 19:09:20.872653
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    str_0 = 'stream'
    var_0 = write_stream_with_colors_win_py3(str_0, str_0, str_0)


# Generated at 2022-06-25 19:09:31.162377
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    s_0 = 'stdout_isatty'
    s_1 = 'prettify'
    s_2 = 'stream'
    s_3 = 'RawStream'
    s_4 = 'CHUNK_SIZE_BY_LINE'
    s_5 = 'prettify'
    s_6 = 'style'
    s_7 = 'json'
    s_8 = 'format_options'
    s_9 = 'PrettyStream'
    s_10 = 'BufferedPrettyStream'
    s_11 = 'EncodedStream'
    s_12 = 'chunk_size'
    s_13 = 'CHUNK_SIZE'
    env_0 = Environment()
    var_0 = get_stream_type_and_kwargs(env_0, env_0)

# Generated at 2022-06-25 19:09:36.788276
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import StringIO
    from httpie.utils import get_encoding_from_arg

    encoding = get_encoding_from_arg('latin-1')
    str_0 = 'stream'
    str_1 = 'foo'
    str_2 = 'bar'
    str_3 = ''
    bytearray_0 = bytearray()
    str_4 = 'baz'
    str_5 = 'stream'
    if True:
        str_5 = encoding
    str_6 = 'stream'
    str_7 = 'convert_bytearray_to_str'
    int_0 = 1
    int_1 = 1
    int_2 = 1
    int_3 = 1
    int_4 = 1
    var_0 = write_stream_with_colors_win_py3

# Generated at 2022-06-25 19:09:48.128939
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    str_0 = 'stream'
    str_1 = 'buffered'
    var_0 = write_stream(str_0, str_0, str_0)
    var_1 = write_stream_with_colors_win_py3(str_1, str_1, str_1)
    str_2 = 'headers'
    bool_0 = bool()
    bool_1 = bool()
    str_3 = 'args'
    str_4 = 'env'
    str_5 = 'requests_message'
    var_2 = build_output_stream_for_message(str_3, str_4, str_5, bool_0, bool_1)
    int_0 = var_2.__len__()
    str_6 = 'pretty'
    str_7 = 'style'
    str_

# Generated at 2022-06-25 19:09:53.009970
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    arg_0 = argparse.ArgumentParser()
    arg_1 = argparse.Namespace()
    arg_2 = Environment()
    arg_3 = requests.PreparedRequest()
    arg_4 = False
    arg_5 = False
    method_result_0 = build_output_stream_for_message(arg_1, arg_2, arg_3, arg_4, arg_5)
    var_0 = list(method_result_0)
    print(var_0)