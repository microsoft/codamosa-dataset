

# Generated at 2022-06-25 19:00:16.877982
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import httpie.output.streams as module_0
    import httpie.context as module_1
    import argparse as module_2
    environment_0 = module_1.Environment()
    namespace_0 = module_2.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0 == (module_0.EncodedStream, {'env': environment_0})

import subprocess as module_0
import httpie.output.streams as module_1
import httpie.context as module_2
import argparse as module_3


# Generated at 2022-06-25 19:00:18.437130
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert isinstance(build_output_stream_for_message(), types.GeneratorType)


# Generated at 2022-06-25 19:00:19.301319
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass

# Generated at 2022-06-25 19:00:31.652057
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = (module_0.Environment, module_1.Namespace)
    def test_function_0():
        environment_1 = tuple_0[0]
        namespace_1 = tuple_0[1]
        environment_1.headers = {'User-Agent': 'CLI tool httpie/2.3.1'}
        environment_1.headers = {'Accept-Encoding': 'gzip, deflate'}
        environment_1.headers = {'Accept': '*/*'}
        environment_1.headers = {'Host': 'httpbin.org:80'}
        environment_1.headers = {'Connection': 'keep-alive'}

# Generated at 2022-06-25 19:00:37.515983
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert tuple_0 == (module_0.PrettyStream, {'env': environment_0, 'conversion': module_0.Conversion(), 'formatting': module_0.Formatting(env=environment_0, groups=namespace_0.prettify, color_scheme=namespace_0.style, explicit_json=namespace_0.json, format_options=namespace_0.format_options)})

import httpie.output.processing as module_0
import httpie.output.streams as module_1
import httpie.models as module_2
import typing as module_3


# Generated at 2022-06-25 19:00:43.452893
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert isinstance(tuple_0[0], type(BufferedPrettyStream))
    assert isinstance(tuple_0[1], dict)

import httpie.context as module_0
import httpie.output.streams as module_1
import httpie.models as module_2


# Generated at 2022-06-25 19:00:49.076355
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert (tuple_0[0] == module_0.EncodedStream)
    assert (tuple_0[1] == {'env': module_0.Environment()})
    assert (len(tuple_0) == 2)


# Generated at 2022-06-25 19:00:59.767351
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert callable(write_stream_with_colors_win_py3)

# Generated at 2022-06-25 19:01:00.342391
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:01:02.614552
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, namespace_0)


# Generated at 2022-06-25 19:01:09.565636
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert build_output_stream_for_message() == None

# Generated at 2022-06-25 19:01:17.702495
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Define mock
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    setattr(environment_0, 'stdout_isatty', False)
    setattr(namespace_0, 'prettify', None)
    setattr(namespace_0, 'stream', False)
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert False


# Generated at 2022-06-25 19:01:20.852542
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.stream = True
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)


# Generated at 2022-06-25 19:01:29.357206
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    test_prepared_request_0 = requests.PreparedRequest()
    test_string_0 = test_prepared_request_0.body
    test_string_1 = test_prepared_request_0.path_url
    test_prepared_request_0.prepare_method('GET')
    test_string_2 = test_prepared_request_0.method
    test_environment_0 = module_0.Environment()
    test_namespace_0 = module_1.Namespace()
    test_iter_0 = build_output_stream_for_message(test_namespace_0, test_environment_0, test_prepared_request_0, True, True)
    test_tuple_0 = next(test_iter_0)
    test_tuple_1 = next(test_iter_0)


# Generated at 2022-06-25 19:01:32.189315
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = 'stream'
    outfile = 'outfile'
    flush = 'flush'
    write_stream_with_colors_win_py3(stream, outfile, flush)

# Generated at 2022-06-25 19:01:36.674032
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == BufferedPrettyStream


# Generated at 2022-06-25 19:01:40.087949
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(tuple_0) is tuple


# Generated at 2022-06-25 19:01:46.621554
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message((module_1.Namespace(), ), environment_0, namespace_0)

# Generated at 2022-06-25 19:01:52.848782
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    obj_0 = module_1.Namespace()
    obj_0.prettify = "colors"
    obj_0.stream = None
    obj_0.format_options = None
    obj_0.style = "default"
    obj_0.traceback = None
    obj_0.debug = False
    obj_0.json = None
    file_0 = open("str", "w")
    write_stream_with_colors_win_py3(obj_0, file_0, False)

# Generated at 2022-06-25 19:02:02.276775
# Unit test for function write_message
def test_write_message():
    namespace_0 = module_1.Namespace()
    namespace_0.stdout_isatty = bool()
    namespace_0.prettify = list()
    namespace_0.stream = bool()
    namespace_1 = module_1.Namespace()
    namespace_1.stdout_isatty = bool()
    namespace_1.prettify = list()
    namespace_1.stream = bool()
    environment_0 = module_0.Environment()
    namespace_1.stdout_isatty = bool()
    namespace_1.prettify = list()
    namespace_1.stream = bool()
    namespace_2 = module_1.Namespace()
    namespace_2.stdout_isatty = bool()
    namespace_2.prettify = list()
    namespace_2.stream = bool()


# Generated at 2022-06-25 19:02:18.621574
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.is_windows = False
    namespace_0.prettify = {"colors"}
    namespace_0.stream = False
    stream_class_0, stream_kwargs_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_0 = stream_class_0(**stream_kwargs_0)
    write_stream_with_colors_win_py3(stream_0, sys.stdout, False)

# Generated at 2022-06-25 19:02:27.580718
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    stream_0 = BaseStream()
    file_0 = open('/Users/rader/dev/httpie/tests/fixtures/file.bin', 'rb')
    write_stream(stream_0, file_0, True)
    file_0.flush()
    assert file_0.closed is False
    file_0.close()
    assert file_0.closed is True
    file_0.close()
    write_stream(stream_0, file_0, True)
    assert file_0.closed is True


# Generated at 2022-06-25 19:02:30.469538
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    requests_PreparedRequest = type(lambda: 0)
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, requests_PreparedRequest)


# Generated at 2022-06-25 19:02:42.306529
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = httpie.context.Environment()
    namespace_0 = argparse.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == httpie.output.streams.EncodedStream
    assert tuple_0[1]['env'] == environment_0
    assert tuple_0[1]['chunk_size'] == httpie.output.streams.RawStream.CHUNK_SIZE_BY_LINE
    assert tuple_0[1]['chunk_size'] == httpie.output.streams.RawStream.CHUNK_SIZE
    argparse_0 = argparse.ArgumentParser()
    argparse_0.add_argument('--prettify', action='store')

# Generated at 2022-06-25 19:02:50.561419
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message = requests.PreparedRequest()
    namespace_0 = argparse.Namespace()
    environment_0 = Environment()
    result_0 = build_output_stream_for_message(namespace_0, environment_0, requests_message, False, False)
    result_1 = build_output_stream_for_message(namespace_0, environment_0, requests_message, True, False)
    result_2 = build_output_stream_for_message(namespace_0, environment_0, requests_message, False, True)
    result_3 = build_output_stream_for_message(namespace_0, environment_0, requests_message, True, True)


# Generated at 2022-06-25 19:02:51.926950
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True == True


# Generated at 2022-06-25 19:02:52.507746
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:02:56.345318
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    write_stream_for_message(None, environment_0, namespace_0, False, False)


# Generated at 2022-06-25 19:03:02.060098
# Unit test for function write_stream
def test_write_stream():
    buffer_0 = io.BytesIO()
    buffer_1 = io.BytesIO()
    buffer_1.write(b'\x1b[7m\x1b[1mHTTP/1.1 200 OK\x1b[0m')
    buffer_1.write(b'\n\n')
    stream_0 = EncodedStream(env=module_0.Environment())
    try:
        write_stream(stream_0, buffer_1, True)
    except IOError as error:
        result = error.errno
    else:
        result = None
    assert result == errno.EPIPE
    write_stream(stream_0, buffer_0, False)

# Generated at 2022-06-25 19:03:05.559742
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, namespace_0, True, True)

# Generated at 2022-06-25 19:03:32.298521
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    write_stream_with_colors_win_py3(tuple_0[0], 1, True)


# Generated at 2022-06-25 19:03:41.105174
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from sys import platform
    from unittest import TestCase, main
    from unittest.mock import patch

    class WriteStreamWithColorsWinPy3Tests(TestCase):
        @patch('httpie.output.streams.win_py3_colorama_available', True)
        def test_write_stream_with_colors_win_py3(self):
            # The function should write the given stream to the
            # given outfile, separating colorized and non-colorized
            # chunks and processing colorized ones with `colorama`.
            outfile = StringIO()
            test_string_colorized = '\x1b[31mHello!\x1b[0m'
            test_string_plain = 'Hello, again!'


# Generated at 2022-06-25 19:03:45.563036
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    argument_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    http_response_0 = requests.Response()
    message_0 = build_output_stream_for_message(argument_0, environment_0, http_response_0, True, True)



# Generated at 2022-06-25 19:03:46.121663
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass

# Generated at 2022-06-25 19:03:52.066605
# Unit test for function write_message
def test_write_message():
    env = mock.Mock(Environment)
    args = mock.Mock(argparse.Namespace)
    requests_message = mock.Mock(requests.PreparedRequest)
    with_headers = False
    with_body = False
    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-25 19:03:57.296799
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    # AssertionError: IndexError: At least one element is expected
    # pytest.raises(AssertionError, "write_stream_with_colors_win_py3(tuple_0[0](), stdout, False)")


# Generated at 2022-06-25 19:04:00.940644
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Assuming that get_stream_type_and_kwargs returns the following values
    expected = (RawStream, {'chunk_size': RawStream.CHUNK_SIZE})
    # Executing the function under test
    actual = test_case_0()
    # Testing that the result equals the expected value (e.g., the return value)
    assert actual == expected

# Generated at 2022-06-25 19:04:12.421784
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    print("Test Case 1: ")
    
    # define environment
    environment_0 = httpie.context.Environment()
    environment_0.stdout = "output1"
    environment_0.stdout_isatty = True
    
    # define args
    namespace_0 = argparse.Namespace()
    namespace_0.stream = False
    namespace_0.prettify = ["colors", "format", "indent"]
    namespace_0.style = "default"
    namespace_0.json = False
    namespace_0.format_options = "default"
    namespace_0.debug = False
    namespace_0.traceback = False
    
    # define message
    prepared_request_0 = requests.PreparedRequest()
    prepared_request_0.body = "message body"
    prepared_request_0

# Generated at 2022-06-25 19:04:13.207973
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert True

# Generated at 2022-06-25 19:04:16.483226
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    with_headers = False
    with_body = False
    write_message(requests_message, environment_0, namespace_0, with_headers, with_body)


# Generated at 2022-06-25 19:04:43.235220
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    prepared_request_0 = requests.PreparedRequest()
    namespace_0 = module_1.Namespace()
    write_message(prepared_request_0, environment_0, namespace_0, False, False)



# Generated at 2022-06-25 19:04:48.055512
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    default_0 = write_stream_with_colors_win_py3(tuple_0[0], environment_0.stdout, namespace_0.stream)
    return default_0


# Generated at 2022-06-25 19:04:50.955348
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    message = "Hello"
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    get_stream_type_and_kwargs(environment_0, namespace_0)


# Generated at 2022-06-25 19:05:00.984627
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import datetime
    import httpie.context as module_0
    import httpie.output.streams as module_1
    import unittest.mock as module_2
    requests_message_0 = module_2.MagicMock()
    requests_message_0.headers.items.return_value = [('user-agent', 'python-requests/2.22.0'), ('accept-encoding', 'gzip, deflate'), ('accept', '*/*'), ('connection', 'keep-alive')]
    requests_message_0.url = 'http://httpbin.org/get'
    requests_message_0.content = '{}'
    requests_message_0.elapsed.total_seconds.return_value = datetime.timedelta(2, 326317)

# Generated at 2022-06-25 19:05:01.528751
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass

# Generated at 2022-06-25 19:05:07.414977
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.stream import EncodedStream
    from httpie.context import Environment
    from argparse import Namespace
    environment = Environment()
    namespace = Namespace()
    assert get_stream_type_and_kwargs(environment, namespace) == (EncodedStream, {'env': environment})

import httpie.output.streams as module_0
import httpie.context as module_1
import httpie.parser as module_2


# Generated at 2022-06-25 19:05:12.632756
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    string_stream_0 = StringIO()
    write_stream_with_colors_win_py3(((tuple_0[0])(), tuple_0[1]), string_stream_0, True)
    pass

# Generated at 2022-06-25 19:05:19.137492
# Unit test for function write_message

# Generated at 2022-06-25 19:05:28.832918
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class mock_requests_PreparedRequest():
        pass
    class mock_requests_Response():
        pass
    requests_message = mock_requests_PreparedRequest()
    env = module_0.Environment()
    argparse_Namespace_0 = module_1.Namespace()
    
    args = argparse_Namespace_0
    with_headers = True
    with_body = True
    test_1 = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)
    requests_message = mock_requests_Response()
    test_2 = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)

# Generated at 2022-06-25 19:05:36.462180
# Unit test for function write_stream_with_colors_win_py3

# Generated at 2022-06-25 19:06:30.133892
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # Case where output is should not be prettified

    # Case where output should be prettified

    # Case where output is should not be prettified

    # Case where output should be prettified

    # Case where output is should not be prettified

    # Case where output should be prettified
    pass



# Generated at 2022-06-25 19:06:39.188065
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    buf_0 = StringIO()
    stream_dict_0 = {'stream': RawStream(msg=HTTPRequest(requests.PreparedRequest('GET')), with_headers=False, with_body=False, chunk_size=RawStream.CHUNK_SIZE)}
    write_stream_with_colors_win_py3(**stream_dict_0, outfile=buf_0, flush=False)
    buf_0 = StringIO()
    stream_dict_1 = {'stream': RawStream(msg=HTTPRequest(requests.PreparedRequest('GET')), with_headers=False, with_body=False, chunk_size=RawStream.CHUNK_SIZE_BY_LINE)}
    write_stream_with_colors_win_py3(**stream_dict_1, outfile=buf_0, flush=False)

# Generated at 2022-06-25 19:06:42.200833
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(namespace_0, environment_0, False, False)

# Generated at 2022-06-25 19:06:44.378486
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(None, environment_0, namespace_0, False, False)

# Generated at 2022-06-25 19:06:47.854629
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    test_case_0()

import httpie.output.streams as module_0
import typing as module_1
import httpie.output.processing as module_2
import httpie.models as module_3
import httpie.context as module_4
import collections as module_5
import argparse as module_6
import sys as module_7

# Generated at 2022-06-25 19:06:49.855345
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert(
        (
            write_stream_with_colors_win_py3(None, None, None)
        )
    )


# Generated at 2022-06-25 19:06:59.985971
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys

    def test_case_0():
        stream_0 = RawStream(HTTPRequest(), with_body=True, with_headers=True)
        outfile_0 = io.StringIO()
        flush_0 = True
        write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)

    def test_case_1():
        stream_1 = EncodedStream(HTTPResponse(), with_body=True, with_headers=True)
        outfile_1 = io.StringIO()
        flush_1 = True
        write_stream_with_colors_win_py3(stream_1, outfile_1, flush_1)


# Generated at 2022-06-25 19:07:01.192522
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True  # What should this test?

# Generated at 2022-06-25 19:07:10.367533
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.debug = True
    namespace_0.download = False
    namespace_0.force_colors = True
    namespace_0.prettify = ''
    namespace_0.style = ''
    namespace_0.traceback = False
    namespace_0.verbose = False
    namespace_0.visualize = False
    namespace_0.implicit_content_type = 'application/json'
    namespace_0.implicit_content_type = 'application/x-www-form-urlencoded'
    namespace_0.implicit_content_type = 'multipart/form-data'
    namespace_0.implicit_content_type = 'text/plain'
    tuple_0 = build_output_stream

# Generated at 2022-06-25 19:07:12.685850
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)


# Generated at 2022-06-25 19:09:12.147871
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io.BytesIO as class_0
    import io.TextIOWrapper as class_1
    stream_0 = class_0()
    outfile_0 = class_1(stream_0, encoding='utf-8')
    flush_0 = True
    write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:09:23.453505
# Unit test for function write_message
def test_write_message():
    import httpie.output.streams as streams
    import httpie.context as context
    import httpie.models as models

    from mock import Mock, patch
    from httpie.output.streams import RawStream

    requests_message = Mock()
    env = context.Environment()
    args = Mock()
    args.prettify = None
    args.stream = False
    args.download = False
    args.debug = False
    args.traceback = False
    args.verify = True
    args.ignore_hosts = False
    args.ignore_ssl_errors = False
    args.referer = None
    args.follow = False
    args.max_redirects = 10
    write_message(requests_message, env, args, with_headers=True, with_body=True)
    
    args.stream

# Generated at 2022-06-25 19:09:31.763222
# Unit test for function write_message
def test_write_message():
    from click._compat import raw_input
    from httpie import ExitStatus
    from utils import http, HTTP_OK
    from fixtures import (
        FILE_PATH_ARG, FILE_PATH, FILE_CONTENT, JSON_FILE_PATH_ARG,
        JSON_FILE_PATH, JSON_FILE_CONTENT,
    )
    environment = Environment()
    r = http('--print=BhH', 'GET', HTTP_OK)
    assert HTTP_OK in r
    assert MESSAGE_SEPARATOR in r

    r = http('--print=H', 'GET', HTTP_OK)
    assert HTTP_OK not in r
    assert MESSAGE_SEPARATOR in r
    assert HTTP_OK in r

    r = http('--print=h', 'GET', HTTP_OK)
    assert HTTP_OK

# Generated at 2022-06-25 19:09:34.099104
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:09:38.002908
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    try:
        print(get_stream_type_and_kwargs(environment_0, namespace_0))
    except TypeError:
        pass

# Generated at 2022-06-25 19:09:48.611331
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = httpie.context.Environment()
    namespace_0 = argparse.Namespace()
    assert isinstance(environment_0.stdout, io.BufferedIOBase)
    assert isinstance(environment_0.stdout, io.RawIOBase)
    assert isinstance(environment_0.stdout, io.IOBase)
    assert isinstance(environment_0.stdout, object)
    assert isinstance(environment_0.stdout_isatty, bool)
    assert isinstance(environment_0.stdout_isatty, object)
    assert isinstance(environment_0.stderr, io.BufferedIOBase)
    assert isinstance(environment_0.stderr, io.RawIOBase)
    assert isinstance(environment_0.stderr, io.IOBase)
    assert isinstance

# Generated at 2022-06-25 19:09:55.265577
# Unit test for function write_message
def test_write_message():
    # No errors should be raised.
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(prepared_requests.PreparedRequest('GET', 'http://httpbin.org/get'), environment_0, namespace_0)
    write_message(prepared_requests.PreparedRequest('GET', 'http://httpbin.org/get'), environment_0, namespace_0, with_body=True)
    write_message(prepared_requests.PreparedRequest('GET', 'http://httpbin.org/get'), environment_0, namespace_0, with_headers=True)