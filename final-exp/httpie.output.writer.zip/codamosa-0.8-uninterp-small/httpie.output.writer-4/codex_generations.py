

# Generated at 2022-06-25 18:59:58.362026
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass # TODO: implement your test here


# Generated at 2022-06-25 19:00:03.104674
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    dict_0 = {"headers": {"Host": ["httpbin.org"], "User-Agent": ["HTTPie/1.0.3"]}, "url": "http://httpbin.org/get", "method": "GET"}
    int_0 = None
    prepared_request_0 = requests.PreparedRequest(dict_0, int_0, int_0)

# Generated at 2022-06-25 19:00:07.832670
# Unit test for function write_message
def test_write_message():

    # Setup
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = {'colors'}

    environment_0 = module_0.Environment()
    environment_0.stdout_isatty = False

    requests_message = requests.PreparedRequest()

    # Test
    write_message(requests_message, environment_0, namespace_0)


# Generated at 2022-06-25 19:00:19.384189
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.environment import Environment
    from httpie.output.streams import EncodedStream
    from httpie.models import HTTPRequest
    import argparse
    requests_message = HTTPRequest(
        method='GET',
        url='https://api.github.com/search/repositories?q=httpie',
        headers={'Accept': '*/*'},
        body=''
    )
    args = argparse.Namespace()
    env = Environment(
        colors=256,
        stdin_isatty=True,
        stdout_isatty=False,
        is_windows=False
    )
    with_body = True
    with_headers = True

# Generated at 2022-06-25 19:00:28.797409
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    dict_0 = {}
    environment_0 = module_0.Environment(**dict_0)
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(tuple_0) is tuple
    assert type(tuple_0[0]) is type
    assert tuple_0[0].__name__ == 'EncodedStream'
    assert type(tuple_0[1]) is dict
    assert tuple_0[1] == {'env': environment_0}

# Generated at 2022-06-25 19:00:37.341115
# Unit test for function write_stream
def test_write_stream():
    data_0 = "~TZTbJ6q_DdQ:z'`sR@&"
    data_1 = "^#PobE#[Aj%HM"
    data_2 = 'L'
    data_3 = "(3>P<@xA,g8$"
    data_4 = '['
    data_5 = '2'
    data_6 = 'g'
    data_7 = "Zh`G)SbS_^+j-LJ'"
    data_8 = "0<6!l3{T3T0]J+j"
    data_9 = '1'
    data_10 = '%'
    data_11 = "m[Z^u*n"
    data_12 = 'j'
    data_13 = 'D'
   

# Generated at 2022-06-25 19:00:42.435944
# Unit test for function write_stream
def test_write_stream():
    stream_class = base_stream.BaseStream
    stream_class._stream = [b'abc', b'def']
    import io
    infile = io.BytesIO()
    outfile = io.BytesIO()
    write_stream(stream_class, outfile, 0)
    assert outfile.getvalue() == b'abc\ndef'



# Generated at 2022-06-25 19:00:45.674216
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    exception_0 = IOError('IOError')
    attribute_0 = exception_0.errno
    try:
        pass
    except IOError as if_0:
        pass


# Generated at 2022-06-25 19:00:48.805070
# Unit test for function write_message
def test_write_message():
    r = requests.get('http://httpbin.org/get')
    env = Environment()
    args = parse_args('')
    write_message(r, env, args, with_headers=True, with_body=True)


# Generated at 2022-06-25 19:00:56.049771
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    dict_0 = {}
    requests_message_0 = requests.Response(**dict_0)
    dict_1 = {}
    environment_0 = module_0.Environment(**dict_1)
    args_0 = module_1.Namespace()
    with_headers_0 = None
    with_body_0 = None
    tuple_0 = build_output_stream_for_message(args_0, environment_0, requests_message_0, with_headers_0, with_body_0)


# Generated at 2022-06-25 19:01:06.598644
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = None
    dict_0 = {}
    namespace_0 = module_1.Namespace(**dict_0)
    response_0 = module_0.Response()
    var_0 = build_output_stream_for_message(namespace_0, environment_0, response_0, False, False)
    assert isinstance(var_0, tuple)
    assert isinstance(var_0[0], bytes)


# Generated at 2022-06-25 19:01:09.106361
# Unit test for function write_stream
def test_write_stream():
    class_0 = RawStream
    outfile_0 = sys.stdout
    flush_0 = True
    var_0 = write_stream(class_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:01:20.502811
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.context import Environment
    from httpie.config import DEFAULT_CONFIG_DIR


# Generated at 2022-06-25 19:01:24.666125
# Unit test for function write_message
def test_write_message():
    response_0 = module_0.Response()
    environment_0 = None
    dict_0 = {}
    namespace_0 = module_1.Namespace(**dict_0)
    var_0 = write_message(response_0, environment_0, namespace_0, with_headers=False, with_body=False)


# Generated at 2022-06-25 19:01:30.868390
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    buff = StringIO()
    write_stream_with_colors_win_py3(
        stream=RawStream(
            msg=HTTPRequest(
                requests.PreparedRequest()
            ),
            with_headers=True,
            with_body=True,
            env=Environment(),
        ),
        outfile=buff,
        flush=True
    )
    assert buff.getvalue() == (
        'GET / HTTP/1.1\r\n' +
        'Host: localhost\r\n' +
        'Connection: keep-alive\r\n\r\n'
    )


# Generated at 2022-06-25 19:01:35.722846
# Unit test for function write_stream
def test_write_stream():
    outfile_0 = None
    stream_0 = module_1.RawTextHelpFormatter()
    flush_0 = module_1.SUPPRESS
    var_0 = write_stream(stream_0, outfile_0, flush_0)
    assert var_0 == None


# Generated at 2022-06-25 19:01:40.192307
# Unit test for function write_message
def test_write_message():
    response_0 = module_0.Response()
    environment_0 = None
    dict_0 = {}
    namespace_0 = module_1.Namespace(**dict_0)
    var_0 = write_message(response_0, environment_0, namespace_0)
    assert var_0 is None


# Generated at 2022-06-25 19:01:43.828405
# Unit test for function write_message
def test_write_message():
    response_0 = module_0.Response()
    environment_0 = None
    dict_0 = {}
    namespace_0 = module_1.Namespace(**dict_0)
    var_0 = write_message(response_0, environment_0, namespace_0)


# Generated at 2022-06-25 19:01:53.161519
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    response_0 = module_0.Response()
    environment_0 = None
    namespace_0 = module_1.Namespace(**{})
    var_0 = build_output_stream_for_message(namespace_0, environment_0, response_0, True, True)
    var_1 = build_output_stream_for_message(namespace_0, environment_0, response_0, True, False)
    var_2 = build_output_stream_for_message(namespace_0, environment_0, response_0, False, True)
    var_3 = build_output_stream_for_message(namespace_0, environment_0, response_0, False, False)
    assert(var_0)
    assert(var_1)
    assert(var_2)
    assert(var_3)


# Generated at 2022-06-25 19:01:57.408813
# Unit test for function write_stream
def test_write_stream():
    buf = io.BytesIO()
    outfile = io.TextIOWrapper(buf, line_buffering=True)
    stream = b'foo'
    flush = True
    write_stream(stream, outfile, flush)
    assert buf.getvalue() == b'foo'

# Generated at 2022-06-25 19:02:10.472511
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    
    requests_message_0 = module_0.RequestsPreparedRequest()
    with_body_0 = True
    with_headers_0 = False
    result = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, with_body_0, with_headers_0)
    assert result == None

# Generated at 2022-06-25 19:02:21.586565
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    requests_prepared_request_0 = requests.PreparedRequest()
    boolean_0 = True
    boolean_1 = True
    write_message(requests_prepared_request_0, environment_0, namespace_0, boolean_0, boolean_1)
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = (tuple_0[0], tuple_0[1])
    outfile_0 = open('/dev/null', 'wb')
    boolean_2 = False
    write_stream(tuple_1, outfile_0, boolean_2)
    outfile_0.close()
    tuple_1 = get_stream_type_and_

# Generated at 2022-06-25 19:02:26.406098
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():


    assert build_output_stream_for_message(
        ) == build_output_stream_for_message(
        args
        )
    assert build_output_stream_for_message(
        ) == build_output_stream_for_message(
        args
        )
    assert build_output_stream_for_message(
        ) == build_output_stream_for_message(
        args
        )
    assert build_output_stream_for_message(
        ) == build_output_stream_for_message(
        args
        )
    assert build_output_stream_for_message(
        ) == build_output_stream_for_message(
        args
        )
    assert build_output_stream_for_message(
        ) == build_output_stream_for_message(
        args
        )


# Generated at 2022-06-25 19:02:29.677906
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = b'da6e2c'
    outfile = 'd6d066'
    flush = 'f62456'
    expected = '0eb2ab'


# Generated at 2022-06-25 19:02:32.659333
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:02:38.786248
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    request_message = requests.PreparedRequest()
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    data_0 = build_output_stream_for_message(namespace_0, environment_0, request_message, True, True)
    # Verify data_0 can be iterated over.
    for x in data_0:
        pass


# Generated at 2022-06-25 19:02:42.970255
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class TestClass:
        pass

    response = TestClass()
    response.status_code = 201
    assert len(list(build_output_stream_for_message(TestClass(), TestClass(), response, False, True))) == 0


# Generated at 2022-06-25 19:02:52.769341
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = None
    namespace_0.stream = None
    namespace_0.debug = None
    namespace_0.traceback = None
    namespace_0.json = None
    namespace_0.style = None
    namespace_0.format_options = None
    environment_0 = module_0.Environment()
    environment_0.stdout_isatty = None
    environment_0.stdout = None
    environment_0.is_windows = None
    requests_message_0 = object()
    # TARGET:
    # assert build_output_stream_for_message(
    #     args,
    #     env,
    #     requests_message,
    #     with_body=False,
    #     with_headers=False
    #

# Generated at 2022-06-25 19:02:53.770606
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert True


# Generated at 2022-06-25 19:02:57.799329
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = BufferedPrettyStream()
    outfile = EncodedStream()
    flush = False
    write_stream_with_colors_win_py3(stream, outfile, flush)
    if (stream == BufferedPrettyStream() and outfile == EncodedStream() and flush == False):
        return True
    else:
        return False


# Generated at 2022-06-25 19:03:18.510446
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # Test case with the following conditions:

    # args: <class 'argparse.Namespace'> = ...
    # env: <class 'httpie.context.Environment'> = ...
    # requests_message: <class 'requests.models.PreparedRequest'> = ...
    # with_body: False = False
    # with_headers: False = False


    args = argparse.Namespace()
    env = httpie.context.Environment()
    requests_message = requests.models.PreparedRequest()
    requests_message.body = b'E\x01\x16\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 19:03:19.672765
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert func_write_stream_with_colors_win_py3() == 0

# Generated at 2022-06-25 19:03:26.780993
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_class_0, stream_kwargs_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    for chunk in stream_class_0(msg=message_class(requests_message), with_headers=with_headers, with_body=with_body, **stream_kwargs_0):
        if b'\x1b[' in chunk:
            break
    else:
        assert False
    write_stream_with_colors_win_py3(stream, outfile, flush)


# Generated at 2022-06-25 19:03:37.652279
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_2 = module_0.Response(HTTPRequest(HTTPResponse(module_0.PreparedRequest(module_0.Request(module_0.Session()))))), module_0.Response(HTTPRequest(HTTPResponse(module_0.PreparedRequest(module_0.Request(module_0.Session())))))

    namespace_0 = module_1.Namespace()
    namespace_0.stdout_isatty = namespace_0.stdout_isatty
    namespace_0.prettify = namespace_0.prettify
    namespace_0.is_windows = namespace_0.is_windows
    namespace_0.stream = namespace_0.stream
    namespace_0.debug = namespace_0.debug
    namespace_0.traceback = namespace_0.traceback
    environment_0 = module

# Generated at 2022-06-25 19:03:42.746027
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_0 = tuple_0[0]
    stream_kwargs_0 = tuple_0[1]
    stream_0 = stream_class_0(**stream_kwargs_0)
    write_stream_with_colors_win_py3(stream_0, sys.stdout, False)


# Generated at 2022-06-25 19:03:43.395266
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass


# Generated at 2022-06-25 19:03:45.475870
# Unit test for function write_stream
def test_write_stream():
    stream = None
    outfile = None
    flush = None
    write_stream(stream, outfile, flush)


# Generated at 2022-06-25 19:03:56.238051
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    namespace_0 = module_1.Namespace()
    namespace_0.stream = None
    namespace_0.prettify = ()
    namespace_0.style = None
    namespace_0.json = None
    namespace_0.format_options = None
    environment_0 = module_0.Environment()
    environment_0.stdout_isatty = None
    environment_0.stdout = None
    requests_message_0 = None
    with_headers = True
    with_body = False
    iterator_0 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, with_headers, with_body)
    # Iterator should raise no exceptions
    for _ in iterator_0:
        pass

    namespace_0.stream = None

# Generated at 2022-06-25 19:03:59.080350
# Unit test for function write_stream
def test_write_stream():
    http_response_0 = HTTPResponse()
    output_stream_0 = EncodedStream(http_response_0, env)
    write_stream(output_stream_0, stdout, True)


# Generated at 2022-06-25 19:04:05.076505
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    if tuple_0[0] is None:
        print("Test passed.")
    else:
        print("Test failed.")
        print("Return value: " + str(tuple_0[0]))

# Test cases for function get_stream_type_and_kwargs
test_get_stream_type_and_kwargs()

# Generated at 2022-06-25 19:04:16.881618
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert (get_stream_type_and_kwargs()) != None


# Generated at 2022-06-25 19:04:27.978292
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    tuple_2 = get_stream_type_and_kwargs(environment_0, namespace_0)
    try:
        write_message(tuple_0, environment_0, namespace_0, True, True)
    except Exception as e:
        print(e)
    try:
        write_message(tuple_1, environment_0, namespace_0, True, True)
    except Exception as e:
        print(e)

# Generated at 2022-06-25 19:04:39.071427
# Unit test for function write_stream
def test_write_stream():
    stream_0 = module_0.EncodedStream
    with open('/dev/null', 'w') as fd_0:
        with open('/dev/null', 'w') as fd_1:
            write_stream(stream_0, fd_0, True)
            write_stream(stream_0, fd_1, True)
        with open('/dev/null', 'w') as fd_1:
            write_stream(stream_0, fd_1, False)
        with open('/dev/null', 'w') as fd_1:
            write_stream(stream_0, fd_1, False)
    with open('/dev/null', 'w') as fd_0:
        with open('/dev/null', 'w') as fd_1:
            write_stream

# Generated at 2022-06-25 19:04:48.156559
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Testing...
    # Requests message: requests.PreparedRequest
    # with_headers: False
    # with_body: True
    
    # Environment
    environment_0 = module_0.Environment()
    
    # Arguments
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = ['colors']
    namespace_0.style = 'paraiso-dark'
    
    # Requests
    preprequest_0 = requests.PreparedRequest()
    preprequest_0.body = 'body'
    preprequest_0.headers = {'headers': 'headers'}
    preprequest_0.method = 'method'
    preprequest_0.url = 'url'
    

# Generated at 2022-06-25 19:04:52.873734
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_request_0 = requests.PreparedRequest()
    tuple_0, dict_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    base_stream_0 = tuple_0(prepared_request_0, False, False, **dict_0)



# Generated at 2022-06-25 19:05:00.305717
# Unit test for function write_message
def test_write_message():
    try:
        raised_0 = False
        environment_1 = module_0.Environment()
        namespace_1 = module_1.Namespace()
        tuple_0 = (namespace_1, environment_1)
        tuple_1 = prepare_message(tuple_0)
        namespace_1 = tuple_1[0]
        environment_1 = tuple_1[1]
        write_message(namespace_1, environment_1, namespace_1)
        raised_0 = True
    except BaseException as e_0:
        pass
    assert raised_0


# Generated at 2022-06-25 19:05:06.732540
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace_1 = module_1.Namespace()
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_1)
    assert isinstance(tuple_1, tuple) is True
    assert isinstance(tuple_1[0], type) is True
    assert isinstance(tuple_1[1], dict) is True

# Generated at 2022-06-25 19:05:15.536999
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    file_0 = open(file='/dev/null', mode='r')
    file_buffer = file_0.buffer
    unicode_0 = re.sub(regex=unicode_0, repl=unicode_0, string=unicode_0)
    file_1 = open(file='/dev/null', mode='r')
    file_buffer = file_0.buffer
    unicode_1 = re.sub(regex=unicode_0, repl=unicode_0, string=unicode_0)
    file_2 = open(file='/dev/null', mode='r')
    file_buffer = file_0.buffer
    unicode_2 = re.sub(regex=unicode_0, repl=unicode_0, string=unicode_0)

# Generated at 2022-06-25 19:05:21.301249
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Tests that the function raises a TypeError when given less than 3 arguments.
    try:
        write_stream_with_colors_win_py3()
    except TypeError:
        pass
    else:
        raise Exception(
            "Expected exception TypeError not raised"
        )


# Generated at 2022-06-25 19:05:22.763082
# Unit test for function write_message
def test_write_message():
    # This is just a test, improve this as much as possible and remove pass
    pass

# Generated at 2022-06-25 19:05:49.660516
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pretty_stream_0 = PrettyStream(env=None, with_headers=True, with_body=True, conversion=Conversion(), formatting=Formatting(env=None, groups=None, color_scheme=None, explicit_json=False, format_options={}))
    tuple_0 = (pretty_stream_0, None, False)
    write_stream_with_colors_win_py3(*tuple_0)



# Generated at 2022-06-25 19:05:59.234392
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Split a given string into list of lines
    string = "GET / HTTP/1.1\nHost: example.com\nAccept: application/json, */*\nAccept-Encoding: gzip, deflate\nCache-Control: no-cache\nConnection: keep-alive\nUser-Agent: HTTPie/1.0.0\n\n"
    list_of_lines = string.splitlines()

    # Define a requests PreparedRequest
    session = requests.Session()
    request = requests.Request('GET', 'http://example.com')
    prepped = request.prepare()

    # Build output with all fields
    args = argparse.Namespace()
    with_headers = True
    with_body = True

# Generated at 2022-06-25 19:06:10.919416
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        raise RuntimeError
    except RuntimeError as e:
        (e.__traceback__.tb_lineno)
    # Test with a short buffer.
    stream_0 = io.BytesIO()
    stream_1 = stream_0.read()
    stream_2 = io.StringIO()
    stream_3 = stream_2.read()
    stream_4 = io.TextIOWrapper(stream_0)
    write_stream_with_colors_win_py3(stream_0, stream_2, stream_1)
    # Test with a long buffer.
    stream_5 = io.BytesIO()
    stream_6 = stream_5.read()
    stream_7 = io.StringIO()
    stream_8 = stream_7.read()
    stream_9 = io.TextIOW

# Generated at 2022-06-25 19:06:18.189813
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import os
    import sys
    import tempfile
    import unittest.mock

    # Arrange
    response = b'\x1b[33mfoo\x1b[0m\n\x1b[33mbar\x1b[0m\n'
    expected_output = '\x1b[33mfoo\x1b[0m\n\x1b[33mbar\x1b[0m\n'
    environment_mock = unittest.mock.Mock()
    environment_mock.is_windows = True
    stream_mock = unittest.mock.Mock()
    mock_iterable = iter(response)
    stream_mock.__iter__.return_value = mock_iterable
    outfile_mock = unittest.mock

# Generated at 2022-06-25 19:06:27.748274
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.debug = False
    namespace_0.traceback = False
    namespace_0.stream = False
    namespace_0.prettify = []
    requests_response_0 = requests.Response()
    namespace_0.prettify = ['colors']
    namespace_0.prettify = ['colors']
    namespace_0.prettify = ['colors']
    namespace_0.prettify = ['colors']
    namespace_0.prettify = []
    namespace_0.prettify = []
    namespace_0.prettify = []
    namespace_0.prettify = []
    namespace_0.prettify = []
    namespace_0.prettify = []
   

# Generated at 2022-06-25 19:06:37.111360
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io
    import httpie.output.streams as module_0
    environment_0 = module_0.Environment(sys.stdout.buffer, sys.stderr.buffer, sys.stdin.buffer, sys.stdout.buffer, True, True, None, None, {}, 'Auto')
    environment_1 = module_0.Environment(sys.stdout.buffer, sys.stderr.buffer, sys.stdin.buffer, sys.stdout.buffer, True, True, None, None, {}, 'Auto')
    namespace_0 = module_1.Namespace()
    buffer_0 = io.BytesIO()
    write_stream_with_colors_win_py3(module_0.EncodedStream(environment_0), buffer_0, True)
    write_stream_with_colors_win

# Generated at 2022-06-25 19:06:47.854884
# Unit test for function write_stream
def test_write_stream():
    outfile = sys.stdout
    text_0 = outfile.encoding
    message_class_1 = {
        requests.PreparedRequest: module_0.HTTPRequest,
        requests.Response: module_0.HTTPResponse,
    }[type(requests_message)]
    if (env.stdout_isatty and with_body
            and not getattr(requests_message, 'is_body_upload_chunk', False)):
        chunk = MESSAGE_SEPARATOR_BYTES
        buf = outfile.buffer
        buf.write(chunk)
        outfile.flush()
    elif args.prettify:
        stream_class = module_0.Stream if args.stream else module_0.BufferedStream

# Generated at 2022-06-25 19:06:50.689048
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    with_headers_0 = False
    with_body_0 = False
    write_message(None, environment_0, namespace_0, with_headers_0, with_body_0)

# Generated at 2022-06-25 19:07:00.553567
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    # arguments for testcase
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    # get the first item tuple[0]
    get_stream_type_and_kwargs_return_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(get_stream_type_and_kwargs_return_0[0]) is type(module_0.RawStream)
    # get the second item tuple[1]
    get_stream_type_and_kwargs_return_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(get_stream_type_and_kwargs_return_1[1]) is dict

# Generated at 2022-06-25 19:07:09.881186
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from unittest.mock import Mock, patch

    # Ensure that write_stream_with_colors_win_py3 doesn't call
    # write_stream and gets the default case for stream_class, stream_kwargs.
    with patch('httpie.output.streams.write_stream') as mock_write_stream, \
            patch('httpie.output.streams.build_output_stream_for_message') as mock_build_output_stream_for_message:
        mock_build_output_stream_for_message.return_value = []
        write_stream_with_colors_win_py3(mock_build_output_stream_for_message, Mock(), False)
    assert not mock_write_stream.called

    # Ensure that write_stream_with_colors_win_py3 doesn't call


# Generated at 2022-06-25 19:08:08.914021
# Unit test for function write_message
def test_write_message():
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    namespace_0.prettify = None
    namespace_0.style = None
    namespace_0.debug = None
    namespace_0.traceback = None
    namespace_0.json = None
    namespace_0.format_options = None
    namespace_0.stream = None
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    namespace_0 = argparse.Namespace()
    namespace_0.prettify = None
    namespace_0.style = None
    namespace_0.debug = None
    namespace_0.traceback = None
    namespace_0.json = None
    namespace_0.format_options = None
    namespace_0.stream = None
    tuple_1 = get

# Generated at 2022-06-25 19:08:11.268942
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(None, environment_0, namespace_0, True, True)

# Generated at 2022-06-25 19:08:18.718985
# Unit test for function write_stream
def test_write_stream():
    namespace_0 = argparse.Namespace()
    namespace_0.stream = True
    namespace_0.prettify = ['all']
    namespace_0.style = 'paraiso-dark'
    namespace_0.format_options = '/|grep|'
    namespace_0.debug = True
    namespace_0.traceback = True
    namespace_0.json = True
    namespace_0.prettify = ['all']
    namespace_0.style = 'paraiso-dark'
    namespace_0.format_options = '/|grep|'
    namespace_0.pretty = None
    stream_0 = EncodedStream(environment_0, namespace_0)
    text_0 = 'stdout.txt'
    file_0 = open(text_0, mode='r')

# Generated at 2022-06-25 19:08:21.725693
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_0 = None
    outfile_0 = None
    flush_0 = False
    write_stream_with_colors_win_py3(stream_0, outfile_0, flush_0)


# Generated at 2022-06-25 19:08:30.368896
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    if not environment_0.stdout_isatty and not namespace_0.prettify:
        stream_class = RawStream
        stream_kwargs = {
            'chunk_size': RawStream.CHUNK_SIZE 
        }
    elif namespace_0.prettify:
        stream_class = BufferedPrettyStream if namespace_0.stream else BufferedPrettyStream

# Generated at 2022-06-25 19:08:32.749112
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_var = module_0.Environment()
    namespace_arg = module_1.Namespace()
    tuple_val = get_stream_type_and_kwargs(environment_var, namespace_arg)

# Generated at 2022-06-25 19:08:41.323822
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    request_0 = requests.Request()
    with (Loc()) as loc_0:
        builtins_0 = loc_0.builtins
        isinstance_0 = getattr(builtins_0, "isinstance")
        isinstance_1 = isinstance_0(request_0, requests.Request)
        assert isinstance_1
        assert isinstance_1
        tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
        stream_class_0, stream_kwargs_0 = tuple_0
        message_class_0 = {requests.PreparedRequest: HTTPRequest, requests.Response: HTTPResponse}[type(request_0)]
        stream_0 = stream_class

# Generated at 2022-06-25 19:08:42.575771
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert write_stream_with_colors_win_py3((sys.stdout)) == 'This is a test\n'

# Generated at 2022-06-25 19:08:46.574180
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    assert type(get_stream_type_and_kwargs(environment_0, namespace_0)) == tuple


import httpie.output.streams as module_3
import typing as module_4
import httpie.models as module_5


# Generated at 2022-06-25 19:08:53.624536
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(tuple_0) is tuple
    assert len(tuple_0) is 2
    assert type(tuple_0[0]) is type
    assert type(tuple_0[1]) is dict

    namespace_1 = module_1.Namespace(prettify=set())
    environment_1 = module_0.Environment()
    tuple_1 = get_stream_type_and_kwargs(environment_1, namespace_1)
    assert type(tuple_1) is tuple
    assert len(tuple_1) is 2
    assert type(tuple_1[0]) is type
    assert type