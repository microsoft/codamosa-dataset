

# Generated at 2022-06-25 19:00:03.599418
# Unit test for function write_stream
def test_write_stream():
    assert True


# Generated at 2022-06-25 19:00:10.967393
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_0 = tuple_0[0]
    stream_kwargs_0 = tuple_0[1]
    byte_stream_0 = stream_class_0(**stream_kwargs_0)
    IO_0 = TextIO()
    bool_0 = bool()
    write_stream(byte_stream_0, IO_0, bool_0)
    IO_1 = TextIO()
    bool_1 = bool()
    write_stream(byte_stream_0, IO_1, bool_1)
    IO_2 = TextIO()
    bool_2 = bool()

# Generated at 2022-06-25 19:00:13.880375
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:00:24.746315
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    class MockEncodedStream():
        def __init__(self, env):
            self.env = env

    class MockRawStream():
        def __init__(self, chunk_size):
            self.chunk_size = chunk_size

    class MockPrettyStream():
        def __init__(self, env, conversion, formatting):
            self.env = env
            self.conversion = conversion
            self.formatting = formatting

    class MockBufferedPrettyStream():
        def __init__(self, env, conversion, formatting):
            self.env = env
            self.conversion = conversion
            self.formatting = formatting

    class MockEnvironment():
        def __init__(self):
            self.stdout_isatty = False

    class MockNamespace():
        def __init__(self):
            self.prettify

# Generated at 2022-06-25 19:00:28.034906
# Unit test for function write_stream
def test_write_stream():
    write_stream(BufferedPrettyStream(msg=None, with_headers=False, with_body=False, env=None, conversion=None, formatting=None), None, False)


# Generated at 2022-06-25 19:00:36.902146
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    output_stream_0 = module_0.BufferedPrettyStream()
    namespace_0 = module_1.Namespace()
    namespace_0.stdout = environment_0.stdout
    tuple_0 = module_0.get_stream_type_and_kwargs(environment_0, namespace_0)
    namespace_0.prettify = tuple_0[1]['formatting'].groups
    namespace_0.stream = tuple_0[1]['formatting'].groups
    namespace_0.style = tuple_0[1]['formatting'].color_scheme
    namespace_0.json = tuple_0[1]['formatting'].explicit_json
    namespace_0.format_options = tuple_0[1]['formatting'].format_options
   

# Generated at 2022-06-25 19:00:39.092481
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    string_0 = _get_encoding()
    _write_stream_with_colors_win_py3(string_0)


# Generated at 2022-06-25 19:00:49.160177
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import PrettyStream

    requests_message = None
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    stream = PrettyStream(
        msg=HTTPResponse(None),
        with_headers=with_headers,
        with_body=with_body,
        env=env,
        conversion=Conversion(),
        formatting=Formatting(
            env=env,
            groups=args.prettify,
            color_scheme=args.style,
            explicit_json=args.json,
            format_options=args.format_options,
        )
    )
    output = StringIO()
    write_stream_with_colors_win_py3(stream, output, flush=True)

# Generated at 2022-06-25 19:00:56.100498
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(requests.PreparedRequest(request=request_0), environment_0, namespace_0, with_headers=bool_0, with_body=bool_0)
    write_message(requests.Response(request=request_0), environment_0, namespace_0, with_headers=bool_0, with_body=bool_0)


# Generated at 2022-06-25 19:01:05.143003
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    output_stream_0 = RawStream()
    tuple_0 = (output_stream_0, {})
    tuple_1 = (output_stream_0, {})
    tuple_2 = (output_stream_0, {})
    tuple_3 = (output_stream_0, {})
    tuple_4 = (output_stream_0, {})
    tuple_5 = (output_stream_0, {})
    tuple_6 = (output_stream_0, {})
    tuple_7 = (output_stream_0, {})
    tuple_8 = (output_stream_0, {})
    tuple_9 = (output_stream_0, {})
    tuple_10 = (output_stream_0, {})
    tuple_11 = (output_stream_0, {})

# Generated at 2022-06-25 19:01:22.348815
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    message_class_0 = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
        }[type(requests_message)]
    message_class_0 = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
        }[type(requests_message)]
    boolean_0 = message_class_0(requests_message)
    message_class_0 = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
        }[type(requests_message)]
    boolean_

# Generated at 2022-06-25 19:01:30.606342
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """Assert that the output stream for a message's contents
    is built as expected.

    """
    # [1]
    from httpie.output.streams import RawStream
    from httpie import ExitStatus
    from httpie.core import main
    from requests import Session
    # [2]
    env = Environment()
    # [3]

# Generated at 2022-06-25 19:01:37.089038
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_request_0 = requests.PreparedRequest()
    boolean_0 = True
    boolean_1 = True
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, prepared_request_0, boolean_0, boolean_1)
    assert tuple_0 == (None, None)


# Generated at 2022-06-25 19:01:42.565198
# Unit test for function write_stream
def test_write_stream():

    # Test 1. Byte buffer
    # Output file is binary, should accept bytes.
    with io.BytesIO() as stream:
        write_stream(
            b"hello world",
            stream,
            True
        )
        assert stream.getvalue() == b"hello world"

    # Test 2. Text buffer
    # Output file is text, should accept bytes.
    with io.StringIO() as stream:
        write_stream(
            b"hello world",
            stream,
            True
        )
        assert stream.getvalue() == "hello world"


# Generated at 2022-06-25 19:01:50.395980
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io

    import requests

    import httpie.context as module_0
    import httpie.models as module_1

    request_0 = requests.PreparedRequest("GET", "http://httpbin.org")
    environment_0 = module_0.Environment()
    namespace_0 = module_1.HTTPResponse()
    value_0 = build_output_stream_for_message(namespace_0, request_0, environment_0, False, False)
    out_0 = io.BytesIO()


# Generated at 2022-06-25 19:01:55.226378
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    responses = requests.Response()

    args = argparse.Namespace()
    environment = Environment()
    tuple_0 = build_output_stream_for_message(args, environment, responses, True, True)
    assert len(tuple_0) == 5


# Generated at 2022-06-25 19:02:03.451572
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import _io as module_io
    import httpie.output.streams as module_output_streams
    import requests as module_requests
    import typing as module_typing
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.debug = False
    namespace_0.prettify = None
    namespace_0.traceback = False
    namespace_0.stream = False
    namespace_0.style = 'solarized'
    namespace_0.json = False
    namespace_0.format_options = None
    prepared_request_0 = module_requests.PreparedRequest()
    prepared_request_0.body = None
    prepared_request_0._cookies = None
    prepared_request_0._enc_params = {}
    prepared_request_

# Generated at 2022-06-25 19:02:09.846561
# Unit test for function write_message
def test_write_message():
    # Test arguments
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    requests_prepared_request_0 = requests.PreparedRequest()
    try:
        write_message(requests_prepared_request_0, environment_0, namespace_0)
    except IOError as e:
        print('Exception')
    else:
        print('OK')


# Generated at 2022-06-25 19:02:17.585068
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    request_0 = requests.Request()
    request_0.method = 'GET'
    request_0.url = 'http://httpbin.org/get'
    request_0.headers['User-Agent'] = 'HTTPie/0.9.2'
    request_0.auth = requests.auth.HTTPBasicAuth(
        'user',
        'pass',
    )
    request_0.body = '{'
    request_0.body += "'key': "
    request_0.body += "'value'"
    request_0.body += '}'
    request_0.body = request_0.body.encode('utf-8')
    request_0.hooks = {'response': []}
    prepared

# Generated at 2022-06-25 19:02:26.586875
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Set up mock object.
    import io
    import colorama
    stdin = io.StringIO()
    colorama.init(wrap=False, convert=False)
    from httpie.output.streams import PrettyStream
    stream_0 = PrettyStream(msg=None, with_headers=True, with_body=True, env=None, conversion=None, formatting=None)
    # Set up arguments.
    stream_0 = stream_0
    outfile = stdin
    flush = None
    assert (write_stream_with_colors_win_py3(stream_0, outfile, flush) == None)


# Generated at 2022-06-25 19:02:47.495167
# Unit test for function write_stream
def test_write_stream():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    
    # Test case with buffer.
    try:
        namespace_0.outfile.buffer
    except AttributeError:
        pass
    write_stream(
        namespace_0,
        namespace_0.outfile.buffer,
        namespace_0.flush
    )
    
    # Test case with stderr.
    try:
        namespace_0.outfile.stderr
    except AttributeError:
        pass
    write_stream(
        namespace_0,
        namespace_0.outfile.stderr,
        namespace_0.flush
    )

# Generated at 2022-06-25 19:02:57.651098
# Unit test for function write_message
def test_write_message():
    # environment_0
    environment_0 = module_0.Environment()
    # namespace_0
    namespace_0 = module_1.Namespace()
    # call_0
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    stream_class_0 = tuple_0[0]
    stream_kwargs_0 = tuple_0[1]
    message_class_0 = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }[type(requests_message)]
    yield from stream_class_0(msg=message_class_0(requests_message), with_headers=with_headers, with_body=with_body, **stream_kwargs_0)

# Generated at 2022-06-25 19:03:06.997095
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    namespace_0.prettify = 'headers'
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_0[0] == module_0.BufferedPrettyStream
    assert len(tuple_0) == 2
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert tuple_1[0] == module_0.BufferedPrettyStream
    assert len(tuple_1) == 2
    assert tuple_1 == tuple_0


# Generated at 2022-06-25 19:03:11.876292
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import httpie.context as module_0

    import argparse as module_1

    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:03:20.130093
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    namespace_0 = module_1.Namespace()
    environment_0 = module_0.Environment()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)
    assert type(tuple_0) == tuple
    assert tuple_0 == (module_0.output.streams.EncodedStream, {'env':environment_0})
    namespace_0.prettify=[1]
    tuple_1 = get_stream_type_and_kwargs(environment_0, namespace_0)

# Generated at 2022-06-25 19:03:26.190679
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from random import randint
    from . import httpbin
    from httpie import ExitStatus
    from httpie.compat import urlopen
    from httpie.downloads import (
        parse_content_range, filename_from_content_disposition, filename_from_url,
        get_unique_filename
    )
    from httpie.output.streams import RawStream, EncodedStream
    from utils import http, HTTP_OK
import requests



# Generated at 2022-06-25 19:03:31.743900
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    prepared_request_0 = requests.PreparedRequest()
    prepared_request_0.body = tuple_0
    write_message(prepared_request_0, environment_0, namespace_0, False, False)


# Generated at 2022-06-25 19:03:39.553330
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.context as module_0
    environment_0 = module_0.Environment()
    import argparse
    namespace_0 = argparse.Namespace()
    namespace_0.prettify = ['']
    namespace_0.stream = True
    namespace_0.style = 'defaul'
    namespace_0.json = True
    namespace_0.format_options = {}
    requests_message_0 = requests.PreparedRequest()
    __return_0 = build_output_stream_for_message(namespace_0, environment_0, requests_message_0, False, True)
    assert __return_0 is not None


# Generated at 2022-06-25 19:03:47.203276
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    response_0 = requests.Response()
    namespace_0 = module_1.Namespace()
    list_0 = []
    boolean_0 = response_0.is_body_upload_chunk in list_0
    tuple_0 = get_stream_type_and_kwargs(environment, namespace_0)


if __name__ == '__main__':
    import sys
    import doctest

    print(doctest.testmod(
        sys.modules[__name__],
        optionflags=doctest.ELLIPSIS,
        verbose=False,
        report=False,
    ))

# Generated at 2022-06-25 19:03:51.758233
# Unit test for function write_message
def test_write_message():
    test_message = 'test'
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    write_message(test_message, environment_0, namespace_0)


# Generated at 2022-06-25 19:04:12.663208
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    namespace_0 = module_1.Namespace()
    encodings_0 = module_0.Encodings()
    environment_0 = module_0.Environment()
    environment_0.encodings = encodings_0
    namespace_0.style = environment_0.styles.default
    namespace_0.prettify = None
    namespace_0.stream = False
    namespace_0.verbose = False
    namespace_0.debug = False
    namespace_0.traceback = False
    namespace_0.format_options = None
    write_stream_with_colors_win_py3((), environment_0, namespace_0)

# Generated at 2022-06-25 19:04:20.123776
# Unit test for function write_message
def test_write_message():
    import tempfile
    import os
    import contextlib

    @contextlib.contextmanager
    def make_stdout_stderr_from_file():
        """Helper to create temporary files to be used as stdout/stderr"""
        stdout = tempfile.TemporaryFile(mode='w+', encoding='utf-8')
        stderr = tempfile.TemporaryFile(mode='w+', encoding='utf-8')
        yield stdout, stderr

    def ensure_stdout_and_stderr_are_empty_and_close(stdout, stderr):
        assert stdout.read() == ""
        assert stderr.read() == ""
        stdout.close()
        stderr.close()

    # first use case: normal output
    # initialize things
    import sys
    orig_

# Generated at 2022-06-25 19:04:24.365808
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = Environment()
    namespace_0 = argparse.Namespace()
    tuple_0 = get_stream_type_and_kwargs(environment_0, namespace_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 19:04:31.265585
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    message_0 = {'url': 'https://httpbin.org/headers'}
    http_request_0 = HTTPRequest(message_0)
    namespace_0 = argparse.Namespace()
    environment_0 = Environment()
    tuple_0 = build_output_stream_for_message(namespace_0, environment_0, http_request_0, True, False)


# Generated at 2022-06-25 19:04:35.514316
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    assert get_stream_type_and_kwargs(environment_0, namespace_0) == (module_0.EncodedStream, {'env': module_0.Environment()})

# Generated at 2022-06-25 19:04:38.607209
# Unit test for function write_message
def test_write_message():
    environment_0 = module_0.Environment()
    namespace_0 = module_1.Namespace()
    union_0 = requests.Response()
    write_message(union_0, environment_0, namespace_0)


# Generated at 2022-06-25 19:04:47.625715
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(
            colors="16",
            format="colors"
        )
    )
    stream = stream_class(with_headers=False, **stream_kwargs)

    # Windows only:
    # make sure we don't get a UnicodeEncodeError
    # when writing the color encoded bytes to `stderr`.
    # This uses Python 3's buffer interface.
    if sys.platform == 'win32':
        try:
            write_stream(stream, env.stderr, flush=False)
        except UnicodeEncodeError:
            pytest.fail("encoded bytes were not written with the buffer interface")


# Generated at 2022-06-25 19:04:48.205375
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert 0 == 0


# Generated at 2022-06-25 19:04:53.238153
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    response_0 = module_0.Environment.Response(status_code=200, body="Yay")
    request_0 = module_0.Environment.Request(method="GET")
    namespace_0 = module_1.Namespace()
    namespace_0.stream = True
    namespace_0.prettify = True
    tuple_0 = build_output_stream_for_message(namespace_0, request_0, response_0)


# Generated at 2022-06-25 19:04:54.798812
# Unit test for function write_stream
def test_write_stream():
    # Test default args
    result = write_stream(None, None, False)
    assert result is None


# Generated at 2022-06-25 19:05:10.803920
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = None
    args = None
    var_2 = None
    var_3 = None
    var_4 = get_stream_type_and_kwargs(env, args)
    bool_1 = var_2 == var_3 and var_3 == var_4
    var_5 = None
    bool_0 = False
    bool_2 = bool_0 == bool_1
    bool_3 = bool_2 == bool_0
    var_6 = write_stream(var_5, var_5, bool_3)


# Generated at 2022-06-25 19:05:13.238438
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    var_0 = None
    var_1 = None
    bool_0 = False
    var_2 = write_stream_with_colors_win_py3(var_0, var_1, bool_0)

# Generated at 2022-06-25 19:05:16.425105
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    bool_0 = False
    var_4 = build_output_stream_for_message(var_0, var_1, var_2, bool_0, bool_0)


# Generated at 2022-06-25 19:05:22.219066
# Unit test for function write_stream
def test_write_stream():
    print("Testing function write_stream")
    var_0 = None
    var_1 = None
    bool_0 = False
    var_2 = write_stream(var_0, var_1, bool_0)
    assert var_2 is not None
    print("Passed!")


# Generated at 2022-06-25 19:05:29.739315
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    args.style = 'colorful'
    args.prettify = 'colors'
    args.stream = False
    args.json = False
    args.format_options = 'all'

    env = Environment()
    env.stdout_isatty = False

    var_0 = None
    var_1 = None
    tuple_0 = get_stream_type_and_kwargs(env, args)
    assert tuple_0[0].__name__ == 'RawStream'
    assert tuple_0[1]['chunk_size'] == 4096

# Generated at 2022-06-25 19:05:33.031835
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    var_0 = None
    var_1 = None
    var_2 = None
    bool_0 = False
    bool_1 = False
    var_3 = build_output_stream_for_message(var_0, var_1, var_2, bool_0, bool_1)


# Generated at 2022-06-25 19:05:36.074063
# Unit test for function write_stream
def test_write_stream():
    var_0 = None
    var_1 = None
    bool_0 = False
    var_2 = write_stream(var_0, var_1, bool_0)
    return var_2


# Generated at 2022-06-25 19:05:39.325510
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(Environment(None, None, None), argparse.Namespace(prettify=None)) == (EncodedStream, {'env': Environment(None, None, None)})
    assert False



# Generated at 2022-06-25 19:05:42.433258
# Unit test for function write_stream
def test_write_stream():
    if 'environ' in os.environ:
        del os.environ['environ']
    args = parser.parse_args([])
    env = Environment(args=args)
    write_stream(stream=None, outfile=None, flush=False)


# Generated at 2022-06-25 19:05:51.898865
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message_0 = None
    env_0 = Environment()
    args_0 = argparse.Namespace()
    bool_0 = False
    bool_1 = False
    with_headers_0 = bool_0
    with_body_0 = bool_1
    var_0 = build_output_stream_for_message(
        requests_message_0,
        env_0,
        args_0,
        with_headers_0,
        with_body_0
    )
    var_1 = write_message(requests_message_0, env_0, args_0, with_headers_0, with_body_0)
    bool_2 = False
    bool_3 = False
    with_headers_1 = bool_2
    with_body_1 = bool_3
    var_2 = write_

# Generated at 2022-06-25 19:06:17.029355
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class_0 = build_output_stream_for_message
    string_0 = 'return.py'
    string_1 = 'w'
    string_2 = 'n'
    string_3 = 'a'
    string_4 = 'm'
    string_5 = 'p'
    string_6 = 'l'
    string_7 = 'e'
    char_0 = '|'
    string_8 = 've'
    string_9 = 'n'
    string_10 = 'v'
    string_11 = 'n'
    string_12 = 'a'
    string_13 = 'm'
    string_14 = 'e'
    string_15 = 'n'
    string_16 = 'a'
    string_17 = 'm'
    string_18 = 'p'
    string

# Generated at 2022-06-25 19:06:26.125412
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message = "Testing build_output_stream_for_message"
    env = "Env"
    args = "Args"
    with_headers = False
    with_body = False

    try:
        var_returned = build_output_stream_for_message(
            requests_message=requests_message,
            env=env,
            args=args,
            with_headers=with_headers,
            with_body=with_body,
        )
        var_expected = "Expected"
        assert var_returned == var_expected
    except AssertionError:
        raise AssertionError(
            "Expected: {}, Actual: {}".format(var_expected, var_returned)
        )


# Generated at 2022-06-25 19:06:35.088930
# Unit test for function write_message
def test_write_message():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    env = Environment(stdin=io.BytesIO(), stdout=io.BytesIO())
    test_value_0 = ""
    test_value_1 = ""
    bool_value_0 = False
    test_value_2 = ""
    bool_value_1 = False
    var_0 = write_message(test_value_0, env, args, bool_value_0, bool_value_1)
    var_1 = write_message(test_value_1, env, args, bool_value_0, bool_value_1)
    var_2 = write_message(test_value_2, env, args, bool_value_0, bool_value_1)


# Generated at 2022-06-25 19:06:42.292255
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.context import Environment
    from httpie.models import HTTPResponse
    from httpie.output.pretty import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPBearerAuth
    from httpie.plugins.builtin import HTTPGzip
    from httpie.plugins.builtin import HTTPDeflate
    from httpie.plugins.builtin import HTTPProxyAuth
    from httpie.plugins.builtin import HTTPTrace
    from httpie.plugins.builtin import HTTPHead
    from httpie.plugins.builtin import HTTPSSO
    from httpie.plugins.builtin import HTTPXauth
    from httpie.plugins.builtin import HTTPFileUpload

# Generated at 2022-06-25 19:06:44.415268
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = None
    args = None
    var_0 = None
    var_0 = get_stream_type_and_kwargs(env, args)


# Generated at 2022-06-25 19:06:52.073589
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Example 1
    # Initialize with dummy values.
    args_0 = argparse.Namespace()
    env_0 = Environment()
    
    body_0 = b'''HTTP/1.1 200 OK
Vary: Accept
Content-Type: application/json
Content-Length: 8
Date: Fri, 15 Dec 2017 23:51:17 GMT

{"hello": "world"}'''
    requests_message_0 = requests.Response(body=body_0)
    with_headers_0 = True
    with_body_0 = True
    
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env_0,
        args=args_0,
    )

# Generated at 2022-06-25 19:06:56.300568
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    print('Test for function get_stream_type_and_kwargs')
    try:
        args = argparse.Namespace()
        env = Environment()
        get_stream_type_and_kwargs(env, args)
    except Exception:
        raise Exception('Unexpected exception encountered')
    print('Unit test completed')


# Generated at 2022-06-25 19:07:06.825869
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    path = "http://127.0.0.1:8000/api/{}/cars/"
    url_0 = path.format("karthik")
    url_1 = path.format("hello")
    url_2 = path.format("karthik")
    url_3 = path.format("karthik")
    url_4 = path.format("karthik")
    var_0 = requests.post(url_0)
    var_1 = requests.put(url_1)
    var_2 = requests.put(url_2)
    var_3 = requests.delete(url_3)
    var_4 = requests.delete(url_4)

# Generated at 2022-06-25 19:07:17.162091
# Unit test for function write_message
def test_write_message():
    from io import BytesIO
    from httpie.compat import is_windows
    from httpie.testing import test_env, argparse_mock

    env = test_env()

    env.stdout = BytesIO()
    args = argparse_mock(prettify=['all'],
                         style='solarized',
                         debug=True,
                         traceback=True)

    # Try to write a message with body and headers
    with env.stdout_redirected_to_stderr():
        pass

    # NOTE: `env.stdout` will in fact be `stderr` with `--download`

# Generated at 2022-06-25 19:07:18.065786
# Unit test for function write_message
def test_write_message():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 19:07:58.198201
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        raise Exception()
    except:
        (err_type, err_value, traceback) = sys.exc_info()
        try:
            test_case_0()
        except AssertionError as e:
            fail_test()


# Generated at 2022-06-25 19:08:01.584865
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        assert_equals(build_output_stream_for_message, "test")
    except AssertionError as e:
        print("test_write_stream_with_colors_win_py3")
        print(e)


# Generated at 2022-06-25 19:08:02.735220
# Unit test for function write_stream
def test_write_stream():
    assert func_0 == var_0



# Generated at 2022-06-25 19:08:06.798724
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    var_0 = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)


# Generated at 2022-06-25 19:08:10.126615
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    print("test_build_output_stream_for_message")
    test_case_0()


# Generated at 2022-06-25 19:08:11.022476
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    pass



# Generated at 2022-06-25 19:08:15.356697
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert callable(build_output_stream_for_message)
    # build_output_stream_for_message(requests_message: 'Union[requests.PreparedRequest, requests.Response]', env: 'Environment', args: 'argparse.Namespace', with_headers: 'bool' = False, with_body: 'bool' = False)

    test_case_0()



# Generated at 2022-06-25 19:08:18.664336
# Unit test for function write_stream
def test_write_stream():
    print('Testing write_stream...')
    bool_0 = bool
    int_0 = int
    float_0 = float
    str_0 = str
    str_1 = str
    class_0 = BaseStream
    class_1 = Output
    class_2 = Environment
    bool_1 = bool
    test_case_0()
    print('Done.')


# Generated at 2022-06-25 19:08:22.619444
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_0 = Environment()
    argument_parser_0 = argparse.ArgumentParser()
    args_0 = argument_parser_0.parse_args([])
    var_0 = get_stream_type_and_kwargs(env_0, args_0)
    assert var_0[0] == EncodedStream


# Generated at 2022-06-25 19:08:26.894382
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class mock_args:
        prettify = True
        stream = False
        style = 'windy'

    class mock_env:
        stdout_isatty = False
        prettify_formatter = True

    result = get_stream_type_and_kwargs(mock_env, mock_args)
    assert type(result[0]).__name__ == 'PrettyStream'