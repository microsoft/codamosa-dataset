

# Generated at 2022-06-12 00:09:32.399866
# Unit test for function write_message
def test_write_message():
    from ..exceptions import ExitStatus
    from ..models import Environment
    from ..output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
        ColorizedStream
    )

    def test_write_stream(stream_class, stream_kwargs):
        env = Environment(
            colors=True,
            is_windows=False,
            stdout_isatty=True,
            stdin_isatty=True,
            stdout=sys.stdout,
            stdin=sys.stdin,
            stderr=sys.stderr,
        )

        class request_obj:
            def __init__(self, *args):
                self.args = args


# Generated at 2022-06-12 00:09:43.133136
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream

    class DummyStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks
            self.idx = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.idx == len(self.chunks):
                raise StopIteration
            chunk = self.chunks[self.idx]
            self.idx += 1
            return chunk

    chunks = [
        b'a',
        b'b',
        b'c\x1b[32md\x1b[0me',
    ]

    stream = DummyStream(chunks)
    outfile = StringIO()
    outfile.encoding = 'utf8'
    flush

# Generated at 2022-06-12 00:09:51.630674
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    out_file = open("test_output.txt", "w")
    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    requests_message.url = 'https://httpbin.org/get'
    requests_message.method = 'GET'
    requests_message.headers['Accept'] = 'application/json'

    write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_headers=True,
        with_body=True
    )


if __name__ == '__main__':
    test_build_output_stream_for_message()

# Generated at 2022-06-12 00:10:02.974170
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    from httpie.context import Environment
    args = parser.parse_args(['--stream', '--pretty', 'none'])
    env = Environment()
    env.stdout = None
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    stream = stream_class(**stream_kwargs)
    assert stream.__class__ == PrettyStream
    args = parser.parse_args(['--stream'])
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    stream = stream_class(**stream_kwargs)
    assert stream.__class__ == PrettyStream
    args = parser.parse_args([])
    stream_class, stream_kwargs

# Generated at 2022-06-12 00:10:13.267636
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    env = Environment(stdout=sys.stdout)
    args = argparse.Namespace(stream=True)
    requests_message = requests.Request(method='GET', url='https://www.google.com')
    with_headers = True
    with_body = True
    write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_headers=with_headers,
        with_body=with_body
    )
    return 
    
    
    
    

# Generated at 2022-06-12 00:10:21.555162
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Write this bytes object (len = 20)
    s = b'\x1b[34moutf\x1b[39m'
    # 1. Write 4 bytes to outfile.
    # 2. Write remaining bytes to outfile.buffer.
    # 3. Write entire bytes object to outfile.buffer.

    class Outfile:
        def __init__(self, chunks):
            self.chunks = chunks
            self.buffer = self
            self.encoding = 'utf-8'

        def write(self, string):
            self.chunks.append(string)

    written_chunks = []
    outfile = Outfile(written_chunks)


# Generated at 2022-06-12 00:10:31.963920
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from httpie.cli import parser
    from httpie.client import parse_request
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.utils import get_binary_stream
    # (1) 
    # init a http request
    args = parser.parse_args([
        '--stream', 'http://www.google.com'
    ])


# Generated at 2022-06-12 00:10:33.515211
# Unit test for function write_message
def test_write_message():
    print(MESSAGE_SEPARATOR)

# Generated at 2022-06-12 00:10:42.713068
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli.argtypes
    import httpie.cli.parser
    args = httpie.cli.parser.parse_args('')
    env = httpie.cli.argtypes.KeyValueArgType.env
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = False
    stream_generator = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_headers=with_headers,
        with_body=with_body,
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )

# Generated at 2022-06-12 00:10:55.119888
# Unit test for function write_message
def test_write_message():
    from httpie.compat import is_py2
    from httpie import ExitStatus
    from httpie.core import main
    from tools import http, HTTP_OK, COLOR, CRLF
    from fixtures import (
        FILE_PATH_ARG, FILE_PATH, JSON_FILE_PATH_ARG, JSON_FILE_PATH,
        BIN_FILE_PATH_ARG, BIN_FILE_PATH,
    )
    import httpie.output

    args = httpie.cli.parser.parse_args(args=[
        '--json', 'GET', '%s' % FILE_PATH_ARG])
    env = httpie.Environment(stdin_isatty=True)

    exit_status, output_bytes = main(args, env=env)

# Generated at 2022-06-12 00:11:11.623461
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    r = requests.Response()
    r.raw = io.BytesIO()
    r.status_code = 200
    r.raw.write(b'content')
    r.raw.seek(0)
    # call
    ret = list(build_output_stream_for_message(None, None, r, True, True))
    assert type(ret[0]) == bytes
    assert len(ret) == 1
    assert ret[0] == (b'\x1b[32mHTTP/1.1 200 OK\x1b[39m\r\n\r\ncontent\r\n\r\n')


# Generated at 2022-06-12 00:11:12.590036
# Unit test for function write_stream
def test_write_stream():
    pass


# Generated at 2022-06-12 00:11:23.980565
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment(
        config=None,
        colors=False,
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=False,
        stderr=None,
        stderr_isatty=False
    )
    class Args:
        def __init__(self):
            self.stream = False
            self.prettify = {}
            self.traceback = False
            self.debug = True
            self.json = False
            self.style = None
            self.format_options = {}

    args = Args()
    requests_message = requests.Response()
    requests_message._content = b'Hello World'
    requests_message.headers['Server'] = 'TEST'

# Generated at 2022-06-12 00:11:24.585808
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-12 00:11:35.069866
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import RawStream
    from httpie.cli.argtypes import KeyValueArg
    from httpie.context import Environment
    from httpie.plugins import PluginRegistry

    plugin_registry = PluginRegistry()

    env = Environment(
        stdin=None,
        stdout=None,
        stdin_isatty=False,
        stdout_isatty=False,
        stdin_bytes_mode=False,
        stdout_bytes_mode=False,
        is_windows=False,
        config_dir=None,
        config_path=None,
        config_exists=False,
        plugins=plugin_registry,
        colors=True,
        max_allowed_stream_size=None,
    )

    args = argparse.Namespace()
    args.stream

# Generated at 2022-06-12 00:11:44.860022
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class FakeColors:
        def __init__(self):
            self.calls_write = 0
            self.calls_buffer_write = 0

        def write(self, s):
            self.calls_write += 1

        def buffer_write(self, s):
            self.calls_buffer_write += 1

    def fake_write(string):
        assert string == '\x1b[31mtest\x1b[0m'
        fake_colors.write(string)

    fake_colors = FakeColors()
    # Replace sys.stdout and sys.stderr with a fake output stream
    # and call write_stream_with_colors_win_py3()
    sys.stdout = sys.stderr = fake_colors
    write_stream_with_colors_win

# Generated at 2022-06-12 00:11:56.190278
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test for RawStream
    test_env = Environment()
    test_env.stdout_isatty = False
    test_args = argparse.Namespace()
    test_args.prettify = None
    test_args.stream = False
    test_class, test_kwargs = get_stream_type_and_kwargs(test_env, test_args)
    assert test_class == RawStream
    assert test_kwargs['chunk_size'] == RawStream.CHUNK_SIZE

    # Test for BufferedPrettyStream
    test_args.prettify = ['all']
    test_args.stream = False
    test_class, test_kwargs = get_stream_type_and_kwargs(test_env, test_args)
    assert test_class == BufferedPrettyStream
    assert 'env'

# Generated at 2022-06-12 00:12:05.202212
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        colors=256,
        stdin_isatty=True,
        stdout_isatty=True,
        is_windows=False
    )

    args = argparse.Namespace()

    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs == {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=[],
            color_scheme='par',
            explicit_json=False,
            format_options=None
        )
    }

    args.prettify = ['foo']
    args.stream = True
    args.style = 'foo'
    args.json = True


# Generated at 2022-06-12 00:12:16.644970
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class MockStream(BaseStream):
        def __init__(self, chunk_types):
            # chunk_types: list of str, can be 'color' or 'plain'
            self._chunk_types = chunk_types
            self._iter_idx = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self._iter_idx < len(self._chunk_types):
                self._iter_idx += 1
                if self._chunk_types[self._iter_idx - 1] == 'color':
                    return b'\x1b[1;33mTest\x1b[0m'
                else:
                    return b'Test'
            raise StopIteration


# Generated at 2022-06-12 00:12:22.934800
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    a = httpie.cli.parser.parse_args(args=['get', 'http://example.com/'])
    env = Environment(colors=256, stdin_isatty=False, stdout_isatty=True)
    requests_message = requests.PreparedRequest()
    requests_message.url = 'https://example.com/'
    with_headers = True
    with_body = True
    args = a
    data = []
    for item in build_output_stream_for_message(args, env, requests_message, with_headers, with_body):
        data.append(item)
    assert len(data) > 0
    assert type(data[0]) == bytes

# Generated at 2022-06-12 00:12:39.399425
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    class Env:
        def __init__(self, stdout_isatty):
            self.stdout_isatty = stdout_isatty

    class Args:
        def __init__(self, stream, prettify, json):
            self.stream = stream
            self.prettify = prettify
            self.json = json
            self.style = None

    class PrettyStream(BaseStream):
        def __init__(self, msg, with_headers, with_body, env, conversion, formatting):
            super().__init__(msg, with_headers, with_body, env)
            self.conversion = conversion
            self.formatting = formatting

        def __iter__(self):
            return [b'test']


# Generated at 2022-06-12 00:12:51.237344
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Set up fake stream
    class FakeStream(BaseStream):
        def __init__(self):
            pass

        def __iter__(self):
            yield b'\x1b[0mtest'
            yield b'test2'

    # Set up fake output file
    class FakeOutfile:
        def __init__(self, encoding):
            self.encoding = encoding

        def write(self, data):
            self.data = data

    outfile = FakeOutfile('utf-8')

    # Set up fake environment
    class FakeEnv:
        def __init__(self):
            self.is_windows = True

    env = FakeEnv()

    write_stream_with_colors_win_py3(stream=FakeStream(), outfile=outfile, flush=False)
    assert outfile.data

# Generated at 2022-06-12 00:13:01.971942
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    """
    testing function get_stream_type_and_kwargs
    """
    # function will return BaseStream, dict
    import os
    import platform
    import tempfile
    from httpie.cli import parser
    from httpie.context import Environment

    env = Environment()
    args = parser.parse_args(args=[])

    assert isinstance(
        get_stream_type_and_kwargs(env, args)[0], type)
    assert isinstance(
        get_stream_type_and_kwargs(env, args)[1], dict)

    with tempfile.NamedTemporaryFile() as temp_outfile:
        env.stdout = temp_outfile
        if os.name == 'nt':
            env.stdout_isatty = False
        elif platform.system() == 'Windows':
            env

# Generated at 2022-06-12 00:13:13.569161
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import requests
    import argparse
    args = argparse.Namespace(prettify=None, stream=False)
    env = Environment()
    env.stdout_isatty = False
    assert get_stream_type_and_kwargs(env, args) == (
        RawStream,
        {'chunk_size': RawStream.CHUNK_SIZE}
    )
    env.stdout_isatty = True
    args.prettify = []
    args.stream = False
    assert get_stream_type_and_kwargs(env, args) == (
        EncodedStream,
        {'env': env}
    )
    args.prettify = ['body']
    args.stream = True

# Generated at 2022-06-12 00:13:24.300181
# Unit test for function write_message
def test_write_message():
    from httpie.core import main
    from httpie.compat import str

    # Ensure that write_message
    # 1) doesn't produce any output when the message is empty
    # 2) handles broken pipes
    # 3) produces correct output if the message has string headers
    #    and string body
    # 4) produces correct output if the message has bytes headers
    #    and bytes body
    # 5) produces correct output if the message has bytes headers
    #    and string body

    requests_message = type('MockedPreparedRequest', (object,), {
        'is_body_upload_chunk': False,
        'headers': str(),
        'body': str(),
    })()
    with patch('httpie.cli.environment.Environment') as env:
        env.is_windows = False

# Generated at 2022-06-12 00:13:36.935015
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    data = [
        b'\x1b[31m no color',
        b' then \x1b[32m green',
        b' and a byte: \x1b[0m\x1b[35m\x1b[39mf\x1b[0m\x1b[34m\x1b[39mb\x1b[0m\x1b[32m\x1b[39mo\x1b[0m\x1b[35m\x1b[39mo',
        b''
    ]

    class FakeBytesIO:
        def __init__(self):
            self.data = b''
        def write(self, chunk):
            self.data += chunk
        def getvalue(self):
            return self.data


# Generated at 2022-06-12 00:13:46.653641
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test function get_stream_type_and_kwargs using patched environment and arguments
    # Create test environment
    env = Environment()
    env.is_windows = False
    env.stdout_isatty = True
    env.stdout_encoding = 'utf8'

    # Create test arguments
    args = argparse.Namespace()
    args.stream = False
    args.style = 'colors'
    args.prettify = []
    args.explicit_json = False
    args.json = False
    args.format_options = {}

    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    args.stream = True

# Generated at 2022-06-12 00:13:58.820370
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    try:
        from httpie.output.streams.base import BaseStream
        from httpie.output.streams.encoded import EncodedStream
        from httpie.output.streams.raw import RawStream
        from httpie.output.streams.pretty import PrettyStream
    except:
        pass
    env = Environment()
    args = argparse.Namespace()
    env.stdout_isatty = True
    args.stream = False
    args.prettify = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert issubclass(stream_class, EncodedStream)
    assert issubclass(stream_class, BaseStream)
    assert stream_kwargs == {'env': env}


# Generated at 2022-06-12 00:14:06.311497
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class PrintEnv():
        stdout_isatty = 1
        fileno = 1
        stdout = 1

    class Printargs():
        stdout_isatty = 1
        prettify = 1
        stream = 0
        style = 1
        json = 1
        format_options = 1

    class DummyRequest():
        def __init__(self):
            self.headers = {
                'Header1': 'value1',
                'Header2': 'value2',
            }
            self.request_version = 'Dummy'
            self.body = 'body_text'
            self.method = 'GET'
            self.url = 'url'
            self.content = 'content'

    env = PrintEnv()
    args = Printargs()
    req = DummyRequest()
    output_stream = build_

# Generated at 2022-06-12 00:14:07.564584
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-12 00:14:27.864305
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(env, args)
    assert isinstance(stream_class, BufferedPrettyStream)
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)
    assert stream_kwargs['env'] == env

# Generated at 2022-06-12 00:14:37.375984
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import json
    import requests

    # construct http request
    url = "http://www.httpbin.org/post"
    data = {'key1': 'value1', 'key2': 'value2'}
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url = url, data = json.dumps(data), headers = headers)

    # construct environment
    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        headers=dict(),
        colormode='on' if sys.stdout.isatty() else 'off',
    )

    # construct arguments
    parser = argparse.ArgumentParser()
    parser.add

# Generated at 2022-06-12 00:14:51.145132
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    print(type(
        get_stream_type_and_kwargs(
            env=Environment(),
            args=argparse.Namespace(
                prettify=False,
                stream=False,
            )
        )[0]
    ))
    print(type(
        get_stream_type_and_kwargs(
            env=Environment(),
            args=argparse.Namespace(
                prettify=False,
                stream=True,
            )
        )[0]
    ))
    print(type(
        get_stream_type_and_kwargs(
            env=Environment(),
            args=argparse.Namespace(
                prettify=True,
                stream=False,
            )
        )[0]
    ))

# Generated at 2022-06-12 00:14:55.172384
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace()
    req = requests.PreparedRequest()
    res = requests.Response()
    write_message(req, env, args, True, True)
    write_message(res, env, args, True, True)



# Generated at 2022-06-12 00:15:06.828365
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, RawStream

    from tests.utils import MockEnvironment

    env = MockEnvironment()

    # args.prettify == False, args.stream == True, env.stdout_isatty == False
    assert get_stream_type_and_kwargs(
        env,
        argparse.Namespace(prettify=[], stream=True, style='', json=False,
                           format_options=[]),
    ) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE})

    # args.prettify == False, args.stream == True, env.stdout_isatty == True
    env.stdout_isatty = True

# Generated at 2022-06-12 00:15:08.186683
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace()

# Generated at 2022-06-12 00:15:14.958153
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.downloads import is_file_writable
    from httpie.environment import Environment
    from httpie.output.streams import RawStream
    from httpie.core import main
    env = Environment(
        stdout=sys.stderr,
        stdin=sys.stdin,
        stdout_isatty=False,
        stdin_isatty=False,
        is_windows=sys.platform == 'win32',
        color_mode='auto'
    )
    args = main.get_parser().parse_args(['https://localhost:8000/get?a=1&b=2'])
    assert get_stream_type_and_kwargs(env, args)[0] == RawStream

# Generated at 2022-06-12 00:15:27.023101
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test case: PrettyStream with pretty enabled
    env, args = Environment(stdout_isatty=True), argparse.Namespace(prettify="all", stream=True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == PrettyStream
    assert stream_kwargs == {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups='all',
            color_scheme='',
            explicit_json=False,
            format_options=[]
        )
    }

    # Test case: PrettyStream with pretty enabled

# Generated at 2022-06-12 00:15:30.605850
# Unit test for function write_message
def test_write_message():
    try:
        import pytest
        import requests
        import argparse
        import errno
        from httpie.context import Environment
        from httpie.models import HTTPRequest, HTTPResponse
        from httpie.output.processing import Conversion, Formatting
        from httpie.output.streams import (
            BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
        )
    except:
        pass

# Generated at 2022-06-12 00:15:41.656426
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse

    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


    class Environment:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def stdout_isatty(self):
            return False

        def is_windows(self):
            return False

    class Response:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __str__(self):
            return "Test Response"

    class EncodedStream:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __iter__(self):
            return self


# Generated at 2022-06-12 00:16:18.417279
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream
    from httpie.config import Config

    config = Config(input_encoding='utf8')

    # RawStream
    env = Environment(colors=256, stdin_isatty=True, stdout_isatty=False, config=config)
    args = argparse.Namespace(stream=False, prettify=None, style='default')
    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE})

    env = Environment(colors=256, stdin_isatty=True, stdout_isatty=False, config=config)
    args = argparse.Namespace(stream=True, prettify=None, style='default')
    assert get_stream_type

# Generated at 2022-06-12 00:16:23.379606
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    outfile = StringIO()
    stream = EncodedStream(
        HTTPResponse(requests.Response()),
        env=Environment(
            stdin=None,
            stdout=outfile,
            stdin_isatty=False,
            stdout_isatty=True,
            is_windows=True,
            color_mode=1
        )
    )
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=True
    )

# Generated at 2022-06-12 00:16:33.294114
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import get_parser
    from httpie.env import Environment
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, RawStream

    args = get_parser().parse_args([])
    env = Environment()
    assert get_stream_type_and_kwargs(env, args) == (RawStream, dict(chunk_size=RawStream.CHUNK_SIZE))
    
    args = get_parser().parse_args(['--print', 'bBhH'])
    env = Environment()

# Generated at 2022-06-12 00:16:41.737684
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment

    env = Environment(
        stdout_isatty=True,
    )
    args = argparse.Namespace(
        pretty='all',
        style='paraiso-dark',
        stream=False,
        style='paraiso-dark',
        stream=True,
        format_options=None,
    )
    requests_message = requests.Response()
    requests_message.status_code = '200'
    requests_message.headers  = {'Content-Type': 'application/json'}
    requests_message.content = '''{
        "id": "d290f1ee-6c54-4b01-90e6-d701748f0851",
        "name": "HTTPie"
    }'''.encode

# Generated at 2022-06-12 00:16:51.936929
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    template = '''
    HOST: www.example.com
    Accept-Encoding: gzip, deflate
    Accept: */*
    User-Agent: python-requests/2.9.1

    {{this is body test}}
    '''
    headers = {
        'Accept': '*/*',
        'User-Agent': 'python-requests/2.9.1',
    }
    args = dict(headers=headers, data=template, method='POST', url='https://www.example.com')
    r = requests.Request(**args)
    prepped = r.prepare()
    output_stream = build_output_stream_for_message(args, Environment(), prepped, with_body=True, with_headers=True)
    message = ''

# Generated at 2022-06-12 00:17:01.756457
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    stream = PrettyStream(
        msg=HTTPRequest({}),
        with_headers=False,
        env=Environment(stdout_isatty=False),
        conversion=Conversion(),
        formatting=Formatting(
            env=Environment(stdout_isatty=False),
            groups=['headers','body','status','error'],
            color_scheme='none',
            explicit_json=None,
            format_options={}
        )
    )
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False
    )
    assert(outfile.getvalue().startswith("\x1b[38;5;24mHTTP/1."))

# Generated at 2022-06-12 00:17:12.551029
# Unit test for function write_message
def test_write_message():
    import sys
    import requests  
    from types import SimpleNamespace
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.plugins import plugin_manager

    args = SimpleNamespace()
    args.debug = False
    args.traceback = False
    args.verify = True
    args.check_status = False
    args.follow = False
    args.stream = False
    args.all = False
    args.download = False
    args.style = 'solarized'


# Generated at 2022-06-12 00:17:24.473969
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    import unittest
    import json
    import io
    import sys
    import os
    from httpie.context import Environment

    class CustomArgumentParser(argparse.ArgumentParser):
        def error(self, message):
            pass

    env = Environment()
    arguments = CustomArgumentParser()
    arguments.add_argument('--stream')
    arguments.add_argument('--prettify')
    env.stderr = io.StringIO()

    mocked_args = argparse.Namespace(**{'stream': True, 'prettify': None})

    request_message = requests.PreparedRequest()
    request_message.method = 'GET'
    request_message.url = 'http://example.com/'

    response_message = requests.Response()

# Generated at 2022-06-12 00:17:28.141629
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    print(get_stream_type_and_kwargs(Environment(), 'args'))
    print(get_stream_type_and_kwargs(Environment(stdout_isatty=False), 'args'))

# Generated at 2022-06-12 00:17:38.931341
# Unit test for function write_message
def test_write_message():
    env = Environment(stdout_isatty=False, stdin_isatty=False,
                      stdout=sys.stdout, stdin=sys.stdin,
                      verify=True, debug=False,
                      config_dir=None, config_file=None,
                      auto_json=False,
                      ignore_stdin=True,
                      default_options=None,
                      colors=256,
                      style='solarized-dark',
                      default_scheme='http',
                      default_user='',
                      default_pass='',
                      default_auth=None,
                      default_timeout=DEFAULT_TIMEOUT,
                      default_allow_redirects=DEFAULT_ALLOW_REDIRECTS,
                      default_verify=True,
                      default_stream=False,
                      default_download_dir='',
                      )

# Generated at 2022-06-12 00:18:39.418192
# Unit test for function write_message
def test_write_message():
    from httpie.cli.parser import get_parser
    args = get_parser().parse_args(['--json', 'GET', 'http://www.baidu.com'])
    env = Environment()
    response = requests.Response()
    response.status_code = 200
    response.raw = b'ok'
    response._content = response.raw
    response.url = 'http://www.baidu.com'
    response.encoding = 'utf-8'
    response.headers = {}
    write_message(response, env, args, True, True)

# Generated at 2022-06-12 00:18:51.058242
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()

    # stdout_isatty = True and not args.prettify
    env.stdout_isatty = True
    args.prettify = False
    args.stream = False
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=[], color_scheme=None, explicit_json=False, format_options={})})
    args.stream = True

# Generated at 2022-06-12 00:18:56.702261
# Unit test for function write_stream
def test_write_stream():
    outfile = open("test_write_stream_test.txt", "w")
    stream = [b'a', b'test\n']
    write_stream(stream=stream, outfile=outfile, flush=False)
    outfile.close()
    with open("test_write_stream_test.txt", "r") as f:
        assert f.read() == 'atest\n'
    os.remove("test_write_stream_test.txt")

# Generated at 2022-06-12 00:19:04.531816
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    env = Environment()

    args.prettify = 'none'
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs == {
        'chunk_size': RawStream.CHUNK_SIZE_BY_LINE,
    }

    args.prettify = 'all'
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-12 00:19:11.906355
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import argparse
    from httpie.context import Environment
    env = Environment()
    args = argparse.Namespace()
    requests_message=requests.get('http://httpbin.org/get')
    with_headers,with_body=True,True
    output_stream_for_message=build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_headers=with_headers,
        with_body=with_body,
    )
    for chunk in output_stream_for_message:
        print(chunk)