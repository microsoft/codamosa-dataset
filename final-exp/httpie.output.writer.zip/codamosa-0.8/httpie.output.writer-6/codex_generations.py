

# Generated at 2022-06-12 00:09:17.942020
# Unit test for function write_message
def test_write_message():
    status_code = 200
    args=argparse.Namespace
    env = Environment
    env.stdout = 'blah'
    requests_message = requests.Request()
    requests_message.prepare()
    requests_message.status_code = status_code
    write_message(requests_message, env, args)

# Generated at 2022-06-12 00:09:27.815345
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test with json argument
    env = Environment(colors=256)
    args = argparse.Namespace(prettify='all', style='paraiso-dark', json=True, format_options={}, stream=False)
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env, 'all', 'paraiso-dark', True, {})})
    assert get_stream_type_and_kwargs(env, args) != (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env, 'all', 'paraiso-dark', False, {})})
    
    # Test with json argument but no stream

# Generated at 2022-06-12 00:09:34.386574
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    s = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=[b'foo\x1b[1;31mbar\x1b[0m\n', b'baz'],
        outfile=s,
        flush=False
    )
    assert s.getvalue() == 'foobar\nbaz'

# Generated at 2022-06-12 00:09:38.674841
# Unit test for function write_message
def test_write_message():
    import sys
    env = Environment()
    env.stdout = sys.stdout
    env.stdout_isatty = True
    
    args = argparse.Namespace()
    args.style = 'colorful'
    args.stream = True
    args.prettify = 'colors'

    response = requests.Response()
    response.status_code = 200
    response._content = b'BODY'
    response.headers['Content-Type'] = 'text/html'
    write_message(response, env, args, True, False)

# Generated at 2022-06-12 00:09:39.280212
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    pass

# Generated at 2022-06-12 00:09:44.278971
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace()
    req = requests.Request()
    res = requests.Response()
    for msg in build_output_stream_for_message(
            env,
            args,
            req,
            False,
            False
    ):
        print(msg)


if __name__ == '__main__':
    test_build_output_stream_for_message()

# Generated at 2022-06-12 00:09:55.336488
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import os
    import sys
    import tempfile

    if sys.version_info < (3,):
        return

    if sys.platform != 'win32':
        return

    # Make stdout and stderr unbuffered.
    sys.stdout = io.TextIOWrapper(sys.stdout.detach(), errors='replace',
                                  line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.detach(), errors='replace',
                                  line_buffering=True)

    class MockEnvironment(Environment):
        def __init__(self):
            self.stdout_isatty = True
            self.is_windows = True


# Generated at 2022-06-12 00:10:05.608054
# Unit test for function write_message

# Generated at 2022-06-12 00:10:16.831278
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import requests
    import sys
    from httpie.context import Environment
    from httpie.output.streams import (
        BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
        BaseStream
    )
    from httpie.cli import parser

    url = 'http://www.google.com'
    args = parser.parse_args([url])
    headers = {'Accept-Encoding': 'gzip, deflate', 'Host': 'www.google.com'}
    data = {'spam': 'eggs'}
    r = requests.Request('GET', url, headers=headers, data=data)
    prepared = r.prepare()
    response = requests.Response()
    response.status_code = 200
    response._content_consumed = True
    response.encoding = 'utf-8'
   

# Generated at 2022-06-12 00:10:27.526637
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        stdin=None,
        stdin_isatty=True,
        stdout=None,
        stdout_isatty=True,
        stderr_isatty=True,
    )
    args = argparse.Namespace(
        json=True,
        prettify=[],
        stream=False,
        style="",
        format_options=[],
        debug=False,
        traceback=False,
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__ == Conversion

# Generated at 2022-06-12 00:10:43.348367
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output import streams
    from httpie.output.processing import Formatting
    from httpie.client import Client
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPiePlugin

    parser = argparse.ArgumentParser()
    HTTPBasicAuth().add_options(parser)
    args = parser.parse_args()
    args.auth = 'user:password'
    args.print = lambda output: None
    args.headers = []
    args.stream = False
    args.verbose = False
    args.prettify = ['all']
    args.style = None
    args.json = False
    args.format_options = {}
    args.download = False

# Generated at 2022-06-12 00:10:55.590073
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie import ExitStatus
    from httpie.constants import DEFAULT_CONFIG_DIR, UNIXCONFDIR
    from httpie.output.streams import PrettyStream, EncodedStream, RawStream
    from httpie.status import ExitStatus
    from httpie.constants import DEFAULT_CONFIG_DIR, UNIX_CONFIG_DIR
    from httpie.status import ExitStatus
    import argparse
    import os
    import tempfile
    import unittest

    class TestEnvironment(Environment):
        def __init__(self):
            self.stdout_isatty = True
            self.is_windows = False

    class TestArgs(argparse.Namespace):
        style = 'default'
        stream = False
        prettify = True
        debug = False
        traceback = False
        json = False
       

# Generated at 2022-06-12 00:11:00.884476
# Unit test for function write_stream
def test_write_stream():
    requests_message = requests.Response()
    env = Environment()
    args = argparse.Namespace(prettify='all', style='par')
    with_headers = True
    with_body = True
    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-12 00:11:12.687580
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    session = requests.Session()

# Generated at 2022-06-12 00:11:24.050353
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import __version__
    from httpie.compat import is_windows
    from httpie.output.processing import Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream,
    )
    from httpie.core import main
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parse_args
    from httpie.client import Session

    #===========================================================================
    # Prepare arguments
    #===========================================================================

# Generated at 2022-06-12 00:11:34.524274
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args1 = argparse.Namespace(prettify='all', style='none', stream=False, json=True, format_options='')
    env1 = Environment(stdout_isatty=False)
    stream_class1, stream_kwargs1 = get_stream_type_and_kwargs(env1, args1)
    assert(stream_class1 == PrettyStream)

    args2 = argparse.Namespace(prettify='all', style='none', stream=True, json=True, format_options='')
    env2 = Environment(stdout_isatty=True)
    stream_class2, stream_kwargs2 = get_stream_type_and_kwargs(env2, args2)
    assert(stream_class2 == PrettyStream)


# Generated at 2022-06-12 00:11:44.537339
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input.utils import create_response
    import io
    import json

    env = Environment()
    args = argparse.Namespace()

    # Test RawStream
    args.prettify = None

    response_text = '{"status_code": 200}'
    response = create_response(
        'GET',
        'http://127.0.0.1:8080/json',
        headers={'Content-Type': 'application/json'},
        data=response_text
    )
    stream = RawStream(
        msg=HTTPResponse(response),
        with_headers=False,
        with_body=True,
        chunk_size=RawStream.CHUNK_SIZE
    )
    output = io.BytesIO()
    write_stream(stream, output, flush=True)
   

# Generated at 2022-06-12 00:11:55.834554
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    def build_output_stream_for_message_test(args, with_headers, with_body):
        args = argparse.Namespace(**args)
        env = Environment()
        env.stdout = StringIO()
        env.stdout_isatty = True
        requests_message = requests.Response()
        requests_message._content = b'test content'
        requests_message.status_code = 200
        requests_message.reason = 'test reason'
        requests_message.headers = CaseInsensitiveDict()
        requests_message.headers['content-type'] = 'text/html'
        requests_message.url = 'http://testurl.com'
        requests_message.request = requests.Request()
        requests_message.request.method = 'GET'

# Generated at 2022-06-12 00:12:04.965362
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from .tests.base import MockEnvironment, MockRequest, MockResponse
    from .tests.utils import TESTS_ROOT
    class args:
        json = False
        pretty = False
        stream = False
        style = None
        download = False

    env = MockEnvironment(
        TESTS_ROOT,
        stdin=None,
        stdin_isatty=True,
        stdout=io.StringIO(),
        stdout_isatty=True,
        stderr=io.StringIO(),
        stderr_isatty=True,
    )

    # Request

# Generated at 2022-06-12 00:12:15.016402
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Test for function write_stream_with_colors_win_py3.

    """
    from httpie.utils import get_binary_stream

    outfile = StringIO()
    stream = get_binary_stream(bytes([27, 91, 52, 50, 109]), ['utf-8'])
    try:
        write_stream_with_colors_win_py3(
            stream=stream, outfile=outfile, flush=True
        )
    except UnicodeEncodeError:
        pytest.fail('function write_stream_with_colors_win_py3 failed')


if __name__ == '__main__':
    test_write_stream_with_colors_win_py3()

# Generated at 2022-06-12 00:12:26.815015
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream

    env = Environment()
    args = argparse.Namespace()

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    env.is_windows = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    env.is_windows = False
    env.stdout_isatty = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == Raw

# Generated at 2022-06-12 00:12:37.512730
# Unit test for function write_message
def test_write_message():
    from httpie.cli.parser import parse_cli_args
    from httpie.core import main as httpie
    from pygments.formatters import terminal256
    from pygments.lexers.data import JsonLexer
    from pygments import highlight
    import json
    result = httpie('127.0.0.1:5000/api/resource1')
    # request
    request = json.loads(result)
    json_str = json.dumps(request, indent=2)
    colorized_json = highlight(json_str, JsonLexer(), terminal256.Terminal256Formatter())
    print(colorized_json)
    # response
    result = httpie('127.0.0.1:5000/api/resource1')
    response = json.loads(result)

# Generated at 2022-06-12 00:12:41.255816
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    with open('./test.txt', 'w') as fp:
        write_stream_with_colors_win_py3(['abc\x1b[1;31;41mdef\x1b[0m'], fp, True)

# Generated at 2022-06-12 00:12:42.753018
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    msg = HTTPRequest(requests.PreparedRequest())


# Generated at 2022-06-12 00:12:53.942846
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Test 'write_stream_with_colors_win_py3' function."""
    # GIVEN
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    outfile = StringIO()
    stream = ColorizedStream(msg=None, env=None, with_headers=True, with_body=True)

    # WHEN
    write_stream_with_colors_win_py3(stream, outfile, False)
    outfile.seek(0)

# Generated at 2022-06-12 00:13:04.133360
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output import stream
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream

    for prettify in True, False:
        for env_stdout_isatty in True, False:
            for stream_flag in True, False:
                args_ = argparse.Namespace(prettify=prettify, stream=stream_flag)
                env_ = Environment(stdout_isatty=env_stdout_isatty, stdin_isatty=True)
                stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env_, args=args_)
                assert stream_class in {PrettyStream, BufferedPrettyStream, EncodedStream, RawStream}
                if stream_class == PrettyStream:
                    assert stream_kwargs

# Generated at 2022-06-12 00:13:10.014860
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """
    Just test the function in the module
    """
    from httpie.input.exceptions import UnknownContentType
    from httpie import ExitStatus
    from httpie._compat import is_windows
    test_env = Environment(colors=256, stdout_isatty=True)

# Generated at 2022-06-12 00:13:21.089645
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import tempfile
    from unittest.mock import patch
    from httpie.output.streams import COLOR_BYTES, RESET_COLOR_BYTES

    fd, filepath = tempfile.mkstemp()

    def cleanup_file():
        os.close(fd)
        os.remove(filepath)

    with patch.object(sys, 'stdout', open(filepath, 'w', encoding='utf-8')):
        write_stream_with_colors_win_py3(
            stream=COLOR_BYTES + b'foo' + RESET_COLOR_BYTES,
            outfile=sys.stdout,
            flush=False,
        )

    result = open(filepath, encoding='utf-8').read()
    cleanup_file()

# Generated at 2022-06-12 00:13:25.435637
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace(
    )

    env = Environment(
    )

    requests_message = requests.PreparedRequest(
    )

    with_headers = True

    with_body = True

    for output in build_output_stream_for_message(args, env, requests_message, with_headers, with_body):
        print(output)

# Generated at 2022-06-12 00:13:37.620684
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert(get_stream_type_and_kwargs(
        env=Environment(stdout_isatty=False),
        args=argparse.Namespace()
    ) == (RawStream,{'chunk_size': RawStream.CHUNK_SIZE_BY_LINE}))


# Generated at 2022-06-12 00:14:02.229720
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment as Env
    from collections import namedtuple
    from httpie.cli import parser as Parser
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream, BufferedPrettyStream

    Args = namedtuple('args', 'prettify stream style json format_options')
    args =  Args(
        prettify=['colors', 'format', 'headers', 'json', 'status'],
        stream=True,
        style='solarized',
        json=True,
        format_options={'colors': 'on'}
    )
    env = Env(
        stdout_isatty=True
    )


# Generated at 2022-06-12 00:14:10.648252
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """Test if response is not presented as raw output."""

    # The setup of output stream type and kwargs
    env = 'True'
    args = 'False'
    requests_message = '200(response)'
    with_headers, with_body = 'True', 'True'

    assert build_output_stream_for_message(
        env=env,
        args=args,
        requests_message=requests_message,
        with_headers=with_headers,
        with_body=with_body,
    ) != 'RawStream'

# Generated at 2022-06-12 00:14:17.739227
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # test1: RawStream
    env = Environment()
    env.stdout_isatty = False
    args = argparse.Namespace()
    args.prettify = False
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE

    # test2: PrettyStream
    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.prettify = True
    args.stream = True

# Generated at 2022-06-12 00:14:21.751062
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    mock_requests_message = requests.Response()
    mock_requests_message._content = b'hello world'

    assert build_output_stream_for_message(mock_requests_message) == b'hello world'

# Generated at 2022-06-12 00:14:22.382819
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-12 00:14:32.980847
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from tempfile import TemporaryFile
    from httpie.output.streams import write_stream_with_colors_win_py3

    f = TemporaryFile()

    write_stream_with_colors_win_py3(
        stream=iter([
            b'\x1b[33m\xff\xff\xff\xff\n',
            b'\xff\xff\xff\xff\x1b[36m'
        ]),
        outfile=f,
        flush=False
    )

    f.seek(0)

    assert f.read() == b'\x1b[33m\xff\xff\xff\xff\n\xff\xff\xff\xff\x1b[36m'

# Generated at 2022-06-12 00:14:41.108937
# Unit test for function write_stream
def test_write_stream():
    output_stream = [b'asdf', b'qwer', b'zxcv']
    output = b''
    for chunk in output_stream:
        output += chunk

    class test_outfile:
        buffer = ''

        def write(self, c):
            self.buffer += c.decode()

    outfile = test_outfile()
    write_stream(output_stream, outfile, False)
    assert output == outfile.buffer.encode()

# Generated at 2022-06-12 00:14:52.418914
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.core import main
    from httpie.context import Environment
    from httpie.cli.parser import parser

    namespace = parser.parse_args([u'--debug'])
    namespace.stdout_isatty = False
    namespace.prettify = []
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        Environment(),
        namespace
    )
    assert stream_class == RawStream and stream_kwargs == {'chunk_size': 16384}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        Environment(),
        parser.parse_args([u'--prettify', u'all', u'httpbin.org/get'])
    )
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-12 00:15:00.601454
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class mock_args:
        def __init__(self, argd):
            self.__dict__.update(argd)

    class mock_env:
        def __init__(self, argd):
            self.__dict__.update(argd)

    # prettify: No
    # stream:   No
    # env.stdout_isatty: No
    stream_class, stream_kwargs = \
        get_stream_type_and_kwargs(
            env=mock_env({'stdout': True}),
            args=mock_args({'prettify': None, 'stream': False})
        )
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE

    # prettify: No
    # stream:  

# Generated at 2022-06-12 00:15:10.996373
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from .test_output_streams import TestBufferedPrettyStream
    import httpie
    request = httpie.Request(path='https://httpbin.org/anything')
    message = HTTPRequest(request)
    args = httpie.parser.parser.parse_args(['https://httpbin.org/anything'])
    env = httpie.Environment()
    outfile = env.stdout
    with_headers = WithHeaders.LONG
    with_body = WithBody.ALWAYS

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )

    if not env.stdout_isatty and not args.prettify:
        stream_class = RawStream

# Generated at 2022-06-12 00:15:31.388163
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import io
    import requests
    import requests.structures
    from httpie.context import Environment
    from httpie.output import output_options
    env = Environment(colors=256, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    parser = output_options(env=env)
    args = parser.parse_args([
        'http',
        '--style=paraiso'
    ])
    r = requests.Response()
    r.status_code = 200

# Generated at 2022-06-12 00:15:41.861015
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    env = Environment()

    args.stream = True
    args.prettify = True
    args.format_options = {}
    args.style = 'beeline'
    args.json = False

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args)
    assert (stream_class == PrettyStream and stream_kwargs ==
            {'env': env,
             'conversion': Conversion(),
             'formatting': Formatting(
                 env=env,
                 groups=True,
                 color_scheme='beeline',
                 explicit_json=False,
                 format_options={})})

    args.stream = True
    args.prettify = False
    args.style = 'navigatrix'


# Generated at 2022-06-12 00:15:52.501839
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import input
    from httpie.context import Environment
    from httpie.core import main
    from httpie.downloads import Downloader
    from httpie.output.streams import RawStream
    from httpie.session import Session
    from httpie.input import ParseError
    from httpie.models import FileBody, KeyValue, KeyValueArg
    from httpie.plugins.builtin import HTTPBasicAuth
    # NOTE: Tests that the output stream generation is not affected by the
    # --download flag.
    # TODO: Find a better place for this test.
    # TODO: This test has been reduced to a minimal failing case by
    # removing the --download flag. If this test is ever failing again
    # with --download, find a more meaningful failing case and add this
    # flag back.
    args = argparse.Names

# Generated at 2022-06-12 00:16:01.034887
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import shutil
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream,
        RawStream,
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.constants import DEFAULT_CONTENT_TYPE

    args = argparse.Namespace(
        prettify='colors',
        style='solarized',
        debug=False,
        traceback=False,
        stream=False,
    )

# Generated at 2022-06-12 00:16:12.206620
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Test `write_stream_with_colors_win_py3`
    """
    import sys
    # Save current attributes of sys.stdout
    stdout_attrs = sys.stdout.__dict__
    # Replace stdout
    sys.stdout = TextIOWrapper(BytesIO())

    class Env(object):
        is_windows = True

    class Args(object):
        stream = False
        prettify = ['colors']
        style = 'paraiso-dark'

    env = Env()
    args = Args()

    def get_stream():
        for chunk in ['abc', b'\x1bcde']:
            yield chunk.encode()


# Generated at 2022-06-12 00:16:21.434240
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from tests.compat import patch
    from tests.data import (
        GETBIN_IP_ADDRESS, GETBIN_IP_IPV4,
        JSON_IP_ADDRESS, JSON_IP_CITY, JSON_IP_IPV4,
        JSON_IP_ORG,
    )
    from tests.utils import http, httpbin_both, httpbin, override_stdout_encoding
    from httpie import ExitStatus

    env = httpie.Environment()
    args = argparse.Namespace()
    # noinspection PyTypeChecker
    args.stream = False
    args.prettify = 'format'
    args.style = None
    args.json = False
    args.format_options = {}
    args.debug = False
    args.traceback = False
    args.download = False

# Generated at 2022-06-12 00:16:31.953881
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import os
    import pyperclip
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment

    env = Environment()
    args = argparse.Namespace(
        pretty=False,
        stream=True,
        colors='16',
        style='paraiso-dark',
        format='colors',
        format_options={},
        output_options={},
        style_options={},
        output_stream_class=None,
    )

# Generated at 2022-06-12 00:16:40.588407
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import BytesIO

    from httpie.output.streams import RawStream

    class TestStream(RawStream):
        def __iter__(self):
            yield b'foo'
            # Simulate a colorized chunk.
            yield b'\x1b[1mbar\x1b[0m'
            yield b'baz'

    outfile = BytesIO()
    write_stream_with_colors_win_py3(
        stream=TestStream(msg=None),
        outfile=outfile,
        flush=True,
    )
    assert outfile.getvalue() == b'foo\x1b[1mbar\x1b[0mbaz'

# Generated at 2022-06-12 00:16:51.081060
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    args = argparse.Namespace(
        colors=None,
        debug=False,
        download=True,
        style=None,
        prettify=None,
        traceback=False,
        verify=True,
        stream=True,
        json=False,
        headers=None,
        body=None,
        output_file=None,
        output_dir=None,
        upload=None,
        form=None,
        style_off=False,
        implict_content_type=None,
        explicit_content_type=None,
    )


# Generated at 2022-06-12 00:17:01.050016
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    
    from unittest import mock
    
    from io import BytesIO
    
    # Create BytesIO
    b = BytesIO()
    
    # Create Environment object
    env = Environment()
    env.stdout = b
    env.stdout_isatty = True
    
    # Default args with 'colors' in prettify and --stream
    args = argparse.Namespace(prettify=['colors'], stream=True)
    
    # Create RawStream object
    stream = RawStream(
        msg=HTTPResponse(requests.Response()),
        with_headers=True,
        with_body=True,
        chunk_size=RawStream.CHUNK_SIZE_BY_LINE,
    )
    
    # Flush is always True
    flush = True
    


# Generated at 2022-06-12 00:17:26.470794
# Unit test for function write_message
def test_write_message():
    requests_message = {}
    env = {"stdout_isatty":False, "stderr":sys.stderr, "stdout":sys.stderr}
    args = {"stdout_isatty":False, "stderr":sys.stderr, "stdout":sys.stderr, "style":None, "traceback":None, "debug":None, "stream":False, "prettify":None, "json":None, "format_options":{}}
    with_headers = False
    with_body = False
    write_message(
        requests_message,
        env,
        args,
        with_headers,
        with_body,
    )

# Generated at 2022-06-12 00:17:36.296852
# Unit test for function write_message
def test_write_message():
    from httpie import Environment
    from httpie.output.streams import PrettyStream
    from httpie.cli import parser
    args = parser.parse_args('')
    args.traceback = True
    env = Environment()
    env.stdout_isatty = False
    assert write_message(requests.PreparedRequest(), env, args, True, True)
    assert write_message(requests.Response(), env, args, False, False)
    with pytest.raises(IOError):
        write_message(requests.Response(), env, args, True, True)


# Generated at 2022-06-12 00:17:47.531749
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest
    from contextlib import contextmanager
    class TestWriteStream(unittest.TestCase):

        def setUp(self):
            self.stdout_ = sys.stdout
            self.stream = io.StringIO()
            self.bytes = b'\xc3\xbc'.decode('utf-8')

        def tearDown(self):
            sys.stdout = self.stdout_

        def test_write_stream_stdout(self):
            with self.captured_stdout() as stdout:
                write_stream([self.bytes], None, None)
                self.assertEqual(stdout.getvalue(), self.bytes)


# Generated at 2022-06-12 00:17:55.061025
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    This function tests write_stream_with_colors_win_py3 by writing
    chunks to a file then reading them back to check if they were
    written as expected.

    """
    import tempfile
    import os
    import sys

    # create temporary file
    tmpfile = tempfile.TemporaryFile('w+')

    # mock args
    args = argparse.Namespace(
            prettify=('colors',),
            stream=True)

    env = Environment(
            stdout=tmpfile,
            stdout_isatty=False,
            is_windows=False)

    # mock request
    requests_message = requests.Request(
            method='GET', url='http://example.com')


# Generated at 2022-06-12 00:18:07.124327
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace(  # mock argparse.Namespace object
        # NOTE: `env.stdout` will in fact be `stderr` with `--download`
        stdout=0,
        stdout_isatty=False,
        prettify=True,
        style=0,
        json=False,
        format_options={},
        debug=False,
        traceback=False,
        stream=True
    )
    r = requests.PreparedRequest()
    class HTTPRequest_func():
        def __init__(self, requests_message):
            self = requests_message
    class PrettyStream_func():
        def __init__(self, msg, with_headers, with_body, env, conversion, formatting):
            self = msg
            self = with_headers
            self = with_body


# Generated at 2022-06-12 00:18:16.341272
# Unit test for function write_stream
def test_write_stream():
    from tempfile import TemporaryFile
    from httpie.context import Environment
    from httpie.output.streams import BaseStream
    import unittest

    class SimpleStream(BaseStream):
        def __init__(self):
            super(SimpleStream, self).__init__()

        def write_chunk(self, chunk):
            pass

        def __iter__(self):
            yield b'foo\n'
            yield b'bar'

    class WriteStreamTestCase(unittest.TestCase):
        def test_write_stream(self):
            stream = SimpleStream()
            outfile = TemporaryFile()
            write_stream(
                stream=stream,
                outfile=outfile,
                flush=True,
            )
            outfile.seek(0)
            contents = outfile.read().decode()
           

# Generated at 2022-06-12 00:18:27.167739
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from . import docopt_args
    from ..core.main import main
    from ..core.parser import parse_items
    from ..core.request import Request
    from ..core.response import Response
    from ..core.sessions import Session
    from ..core.sessions import resolve_session

    args = docopt_args.parse_args(args=[])
    kwargs = {
        '__session__': None,
        '__session_created__': False,
        '__url__': 'https://httpbin.org/get',
        '__follow__': False,
        '__items__': [],
        '__auth__': (),
    }
    session = Session()
    kwargs['__session__'] = session
    arguments = parse_items(args, kwargs)

# Generated at 2022-06-12 00:18:39.465447
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from collections import namedtuple
    from httpie.cli import parser
    from httpie.output.streams import RawStream, BufferedPrettyStream, PrettyStream, EncodedStream

    args = parser.parse_args([])
    pretty_stream_args = namedtuple('pretty_stream_args', 'prettify stream')
    pretty_stream_args.prettify = ['colors']
    pretty_stream_args.stream = True

    # Test when no prettify
    env = namedtuple('env', 'stdout_isatty')
    env.stdout_isatty = True
    stream, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream is EncodedStream
    assert PrettyStream not in stream.__class__.__bases__

# Generated at 2022-06-12 00:18:46.954069
# Unit test for function write_message
def test_write_message():
    message = requests.PreparedRequest()
    body = 'hello world'
    message.body = body
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['body']
    env.stdout_isatty = True
    env.stdout = sys.stdout
    env.is_windows = False
    write_message(message, env, args)
    assert True



# Generated at 2022-06-12 00:18:56.435746
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import io

    import httpie.output.streams
    import httpie.output.writers
    import httpie.output.processing

    parser = httpie.cli.parser.get_argparser()
    args = parser.parse_args(['--prettify'])
    env = httpie.Environment()

    def build_headers_and_body_stream():
        return build_output_stream_for_message(
            args=args,
            env=env,
            requests_message=requests.Response(),
            with_headers=True,
            with_body=True,
        )

    assert type(build_headers_and_body_stream()) == \
        httpie.output.streams.BufferedPrettyStream