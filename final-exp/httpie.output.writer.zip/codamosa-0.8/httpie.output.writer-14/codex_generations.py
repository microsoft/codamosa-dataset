

# Generated at 2022-06-12 00:09:22.198786
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import BaseStream

    class FakeStream(BaseStream):
        def __init__(self, steps):
            self.steps = steps
            self.count = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.count >= len(self.steps):
                raise StopIteration

            step = self.steps[self.count]
            self.count += 1
            return step

    stream = FakeStream([b'step1', b'step2', b'step3', b'step4'])
    outfile = StringIO()
    write_stream(stream=stream, outfile=outfile, flush=False)

    assert outfile.getvalue() == 'step1step2step3step4'

# Generated at 2022-06-12 00:09:34.386652
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import io
    import httpie.compat
    import httpie.input
    import httpie.output.streams
    import httpie.output.writers
    import os
    import requests
    import sys
    import json
    import httpie.__main__
    import httpie.config
    import httpie.core

    args = httpie.__main__.parser.parse_args(args=['--traceback', 'http://httpbin.org/get'])
    args.silent = False
    args.prettify = ['all']
    args.quiet = False
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.verbose = True
    args.debug = False
    args.download = False
    args.follow = False
    # args

# Generated at 2022-06-12 00:09:41.101167
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import builtins
    from types import ModuleType
    from unittest.mock import patch, MagicMock
    from httpie.compat import bytes, is_py3
    from httpie.context import Environment

    def set_as_mod_attr(mock, mod):
        setattr(mod, mock.__name__, mock)

    # mock module
    env = Environment()
    mock_stdout = MagicMock()
    if is_py3:
        sys.stdout = mock_stdout
    else:
        sys.stdout = io.open(0, 'wb', buffering=0)

    module_mock = {}

# Generated at 2022-06-12 00:09:48.428676
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    request_object = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace(
        stream=False,
        prettify=False,
        style='friendly',
        json=False,
        format_options={},
    )

    # invalid mode
    with pytest.raises(NotImplementedError):
        write_message(
            requests_message=request_object,
            env=env,
            args=args,
            with_headers=False,
            with_body=False,
        )

    # with_headers and with_body mode is True
    args.prettify='all'
    write_message(
        requests_message=request_object,
        env=env,
        args=args,
        with_headers=True,
        with_body=True,
    )

# Generated at 2022-06-12 00:10:01.083115
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output import streams
    from httpie.output.streams import PrettyStream
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.plugins import builtin

    env = Environment(colors=256, stdout_isatty=False,
        stdout=open(os.devnull), stdin=open(os.devnull))
    args = argparse.Namespace(debug=False,
                              download=False,
                              form=False,
                              headers=True,
                              index_errors=False,
                              output=None,
                              pretty=None,
                              prettify=['all', 'text' 'body'],
                              style='Solarized',
                              verbose=False,
                              verify=True,
                              stream=True)
   
    #set stream

# Generated at 2022-06-12 00:10:04.223490
# Unit test for function write_stream
def test_write_stream():
    outfile = StringIO()
    write_stream([b'1', b'2', b'3'], outfile,False)
    outfile.seek(0)
    assert outfile.read() == '123'



# Generated at 2022-06-12 00:10:16.628184
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=None,
        args=None
    )
    test_stream = stream_class(
        msg=HTTPResponse("test"),
        with_headers=True,
        with_body=True,
        env=None,
        conversion=Conversion(),
        formatting=Formatting(
            env=None,
            groups=None,
            color_scheme=None,
            explicit_json=False,
            format_options=None,
        )
    )
    class test_file:
        def __init__(self):
            self.content = str()

        def write(self, data):
            self.content += data

        def flush(self):
            pass
    f_test = test_file()
    write

# Generated at 2022-06-12 00:10:25.834552
# Unit test for function write_stream
def test_write_stream():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(
        stream=True,
        prettify=True,
    )
    request = HTTPRequest(requests.Request("GET", "http://www.example.com"))
    stream = BufferedPrettyStream(msg=request, env=env, conversion=Conversion(),
                                  formatting=Formatting(env=env, groups="pretty",
                                                         color_scheme="velocity",
                                                         explicit_json="",
                                                         format_options={""}))
    out = io.StringIO()
    write_stream(stream, out, False)
    # print(out.read())
    assert out.getvalue() == ''

# Generated at 2022-06-12 00:10:36.651673
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import sys
    from httpie.models import Environment

    # Testing Env
    env = Environment(
        stdout=sys.stdout.buffer,  # type: ignore
        stdin=sys.stdin.buffer,  # type: ignore
        stdout_isatty=False,
    )
    # Testing args
    # Raw Stream
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    # RawStream
    assert get_stream_type_and_kwargs(env, args)[0] is RawStream

    # PrettyStream
    args.prettify = ['all']
    assert get_stream_type_and_kwargs(env, args)[0] is PrettyStream

    # EncodedStream
    args.prettify = None
    assert get_stream_type_

# Generated at 2022-06-12 00:10:43.380506
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(Environment(), argparse.Namespace(prettify='')) == (
        EncodedStream, {'env': Environment()}
    )
    assert get_stream_type_and_kwargs(Environment(), argparse.Namespace(prettify='h')) == (
        PrettyStream,
    {
        'env': Environment(),
        'conversion': Conversion(),
        'formatting': Formatting(
            env=Environment(),
            groups='h',
            color_scheme=None,
            explicit_json=False,
            format_options={},
        )
    })

# Generated at 2022-06-12 00:10:59.909089
# Unit test for function write_message
def test_write_message():
    """
    This test is to test whether write_message function can generate three different types of output
    according to the terminal type
    """
    import pytest
    from httpie.context import Environment
    from httpie import ExitStatus
    from httpie.config import Config
    from httpie.core import main
    from httpie.cli.argtypes import KeyValueArg
    import httpie.cli.argtypes
    import httpie.output.streams
    # Mocking an object that contains properties, which is close to the real env object.
    # Since we cannot apply pytest.monkeypatch to the existing Environment object.
    # Otherwise it will cause other tests imported from other files to fail.
    env = Environment()
    env.is_windows = False
    env.stream = False
    env.stdout_isatty = True
    env.stdout

# Generated at 2022-06-12 00:11:11.481115
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    Temp_env = Environment()
    Temp_args = argparse.Namespace(
        prettify='all',
        stream=False,
        style='par',
        json=False,
        format_options=[],
    )
    x, y = get_stream_type_and_kwargs(Temp_env, Temp_args)
    assert x == BufferedPrettyStream
    assert y['env'] == Temp_env
    assert y['conversion'] == Conversion()
    assert y['formatting'].env == Temp_env
    assert y['formatting'].groups == 'all'
    assert y['formatting'].color_scheme == 'par'
    assert y['formatting'].explicit_json == False
    assert y['formatting'].format_options == []



# Generated at 2022-06-12 00:11:18.991450
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Test function to build output stream for message
    response = requests.Response()
    response.status_code = 200
    response.headers['Content-Length'] = '4'
    response.headers['Content-Type'] = 'application/json'
    response._content = b'abc'

    class Dummy:
        pass

    dummy_args = Dummy()
    dummy_args.prettify = None
    dummy_args.stream = False
    dummy_args.print = None
    dummy_args.body = None
    dummy_env = Dummy()
    dummy_env.stdout = 'stdout'
    dummy_env.stdout_isatty = True


# Generated at 2022-06-12 00:11:29.520467
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from . import stream
    from .output.streams import (
        EncodedStream, PrettyStream,
    )
    from .models import HTTPRequest
    from .context import Environment
    class Stream:
        def __init__(self,status):
            self.status = status
    class MockArgs:
        pass
    mock_args = MockArgs()
    mock_args.prettify = 'all'
    mock_args.style = None
    mock_args.stream = False
    mock_args.download = False
    mock_args.traceback = False
    mock_args.debug = False
    mock_args.check_status = False
    mock_args.print_headers = False
    mock_args.headers = None
    mock_args.output_file = None
    mock_args.verbose = False
    mock_args

# Generated at 2022-06-12 00:11:31.570567
# Unit test for function write_message
def test_write_message():
    """ Unit test for function write_message """
    # You could put unit tests for this function here
    pass

# Generated at 2022-06-12 00:11:40.407088
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.output.streams import PrettyStream
    from tests.utils import httpbin
    env = Environment()
    args = argparse.Namespace(
        style = None, stream = False, print_bodies = True, pretty = True,
    )
    # requests_message = requests.PreparedRequest(method="GET", url=None, headers="")
    requests_message = requests.Response()
    requests_message._content = b'{"args": [], "headers": {"Accept": "*/*", "Connection": "close", "Host": "httpbin.org", "User-Agent": "HTTPie/2.0.0-dev0"}, "origin": "212.175.49.5", "url": "https://httpbin.org/get"}'
    requests_message

# Generated at 2022-06-12 00:11:50.734183
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import (
        BaseStream
    )
    from httpie.context import Environment

    class TestBaseStream(BaseStream):
        def __init__(self):
            super(TestBaseStream, self).__init__()

        def __iter__(self):
            yield b'foo'
            yield b'\x1b[30;42mfoo'
            yield b'bar'


    env = Environment(
        stdin_isatty=False, stdin=None,
        stdout_isatty=True, stdout=sys.stdout,
        stderr=sys.stderr,
        is_windows=True
    )


# Generated at 2022-06-12 00:12:01.817130
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Fake function to run unit test on function
    write_stream_with_colors_win_py3.
    """
    # pylint: disable=E1101

    # Test writing chunks with color
    # pylint: disable=C0103
    outfile = io.StringIO()
    stream = [b'\x1b[30mtest\x1b[m', b'\x1b[39mtest\x1b[m', b'\x1b[36mtest']
    flush = False
    write_stream_with_colors_win_py3(stream, outfile, flush)
    # pylint: enable=C0103

# Generated at 2022-06-12 00:12:04.874337
# Unit test for function write_message
def test_write_message():
    requests_message = 'test message'
    env = 'test env'
    args = 'test args'
    with_headers = False
    with_body = False
    print(write_message(requests_message, env, args, with_headers, with_body))


# Generated at 2022-06-12 00:12:07.771818
# Unit test for function write_stream
def test_write_stream():
    outfile = sys.stdout
    encoder = EncodedStream(stream='hello', env={'stdout_encoding':'utf-8'})
    write_stream(stream=encoder, outfile=outfile)

# Generated at 2022-06-12 00:12:22.378928
# Unit test for function write_message
def test_write_message():
    message = requests.PreparedRequest()
    message.headers = {'Content-Type':'text/html; charset=UTF-8'}
    message.body = '<!DOCTYPE html>\n'
    message.body += '<html lang="en">\n'
    message.body += '<head>\n<title>Request</title>\n'
    message.body += '</head>\n<body>\n<pre>\n'
    message.body += 'GET / HTTP/1.1\r\n'
    message.body += 'Content-Type: text/html; charset=UTF-8\r\n'
    message.body += '</pre>\n</body>\n'
    message.body += '</html>\n'

# Generated at 2022-06-12 00:12:27.134295
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    import os
    import sys
    import platform

    class MockRequest(requests.PreparedRequest):
        pass

    class MockResponse(requests.Response):
        pass

    class MockEnv(Environment):
        def __init__(
                self,
                stdout_isatty=False,
                is_windows=False,
                stderr=sys.stderr,
        ):
            self.stdout_isatty = stdout_isatty
            self.is_windows = is_windows
            self.stderr = stderr

    class MockStream(BaseStream):
        pass

    class MockBufferedPrettyStream(BufferedPrettyStream):
        pass

    class MockRawStream(RawStream):
        pass

    class MockPrettyStream(PrettyStream):
        pass


# Generated at 2022-06-12 00:12:37.860480
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from unittest.mock import Mock

    stream = Mock()
    outfile = Mock()
    outfile.encoding = 'utf8'

    buf = b'.' * 64

    from httpie.output.streams.base import BaseStream
    stream.__iter__ = lambda *_: iter([buf, buf[:32]])

    def buf_write(data):
        assert isinstance(data, bytes)
        assert len(data) == 64

    def outfile_write(data):
        assert isinstance(data, str)
        assert len(data) == 32

    outfile.buffer.write = buf_write
    outfile.write = outfile_write

    write_stream_with_colors_win_py3(stream, outfile, flush=False)
    assert outfile.write.call_count == 1

# Generated at 2022-06-12 00:12:49.346966
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import pytest
    import httpie.cli
    import httpie.core
    import httpie.output.formatters.json
    import httpie.output.formatters.headers
    import httpie.output.formatters.colors

    args = httpie.cli.parser.parse_args([
        '-v',
        '--format', 'json',
        '--style', 'solarized-dark',
        '--stream',
        'GET',
        'http://httpbin.org/get'
    ])

    args.no_emojis = True
    args.prettify = ['colors', 'headers', 'json']
    args.style = 'solarized-dark'

# Generated at 2022-06-12 00:12:59.895502
# Unit test for function write_stream
def test_write_stream():
    import requests
    import argparse
    import httpie.output.streams

    class FakeEnvironment():
        stdout = None
        stdout_isatty = True

    env = FakeEnvironment()
    stream_class = httpie.output.streams.PrettyStream if True else httpie.output.streams.BufferedPrettyStream
    stream_kwargs = {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=["headers"],
            color_scheme=None,
            explicit_json=False,
            format_options=None,
        )
    }

# Generated at 2022-06-12 00:13:11.048180
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import unittest
    import os
    import sys
    import io

    class WriteStreamWithColorsWinPy3TestCase(unittest.TestCase):
        def test_write_stream_with_colors_win_py3(self):
            if sys.platform == 'win32' and (sys.version_info >= (3, 0)):
                sys.stdout = io.StringIO()
                with_colors_win_py3('\x1b[0mtest\x1b[0m', sys.stdout, False)
                self.assertEqual(sys.stdout.getvalue(), '\x1b[0mtest\x1b[0m')

# Generated at 2022-06-12 00:13:22.359625
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class Args:
        def __init__(self):
            self.json = True
            self.stream = True
            self.prettify = [
                'colors', 'format', 'bundle'
            ]
            self.style = 'paraiso-dark'
            self.format_options = {
                'style': 'paraiso-dark'
            }

    class Env:
        def __init__(self):
            self.stdout_isatty = True

    import json
    import requests
    import requests.adapters

# Generated at 2022-06-12 00:13:29.038466
# Unit test for function write_message
def test_write_message():
    # Test function write_message
    # Test Case #1
    args = argparse.Namespace(prettify=b'colors', stream=False, style=None, json=False, format_options={}, download=False, debug=False, traceback=False)
    env = Environment()
    env.is_windows = False
    env.stdout = sys.stderr
    env.stderr = sys.stderr
    env.stdout_isatty = True
    r = requests.get('http://httpbin.org/get')
    with_headers=True
    with_body=True
    write_message(r, env, args, with_headers, with_body)
    
    # Test Case #2
    env.stdout_isatty = False

# Generated at 2022-06-12 00:13:40.391431
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    arguments = {
        "stream": [b'\x1b[34m\x1b[1mfoo\x1b[0m', b'bar'],
        "outfile": sys.stdout,
        "flush": False
    }
    with patch.object(sys.stdout, 'write') as mock_write:
        write_stream_with_colors_win_py3(**arguments)
        mock_write.assert_has_calls([call('\x1b[34m\x1b[1m'), call('foo'), call('\x1b[0m')])

# Generated at 2022-06-12 00:13:51.313200
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    def mock_bool(result):
        return lambda: result
    def mock_dict():
        return lambda x: x
    args = Mock(prettify='test', style='test', json=False)
    env = Mock(stdout_isatty=mock_bool(True))
    assert id(get_stream_type_and_kwargs(env, args)[0]) == id(PrettyStream)

    args.json = True
    assert id(get_stream_type_and_kwargs(env, args)[0]) == id(PrettyStream)

    env.stdout_isatty = mock_bool(False)
    assert id(get_stream_type_and_kwargs(env, args)[0]) == id(RawStream)

    args.prettify = False

# Generated at 2022-06-12 00:14:05.117927
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.context
    import httpie.models
    import mock
    import os
    import tempfile

    class MockResponse(requests.PreparedRequest):
        body = b'body'
        headers = {}
        request = requests.PreparedRequest()
        request.headers = {}
        status_code = 200

    class MockArgs(object):
        def __init__(self):
            self.stream = False
    args = MockArgs()

    class MockEnv(httpie.context.Environment):
        def __init__(self, tmpdir):
            self.is_terminal = True
            self.stdin = None
            self.stdout = None
            outfile = tempfile.NamedTemporaryFile('w+', dir=tmpdir)
            self.stdout_isatty = False
            self.stdout

# Generated at 2022-06-12 00:14:15.523071
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import pytest
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.util import (
        write_stream, write_stream_with_colors_win_py3
    )
    from httpie.core import main
    from httpie.base import message
    from httpie.output.processing import Conversion, Formatting
    from httpie.input import ParseError

    class MockEnvironment:
        is_windows = True
        stdout_isatty = True

    class MockStderr:
        def write(self, arg):
            pass

        def write_bytes(self, arg):
            pass

    class MockStdout:
        def write(self, arg):
            pass


# Generated at 2022-06-12 00:14:25.796731
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import io
    import json

    # GIVEN
    class MockArgs:

        prettify = ['colors', 'format', 'unicode']
        style = 'solarized-light'
        format_options = {}
        stream = False
        json = False

    mock_stdout = io.StringIO()
    mock_env = Environment(stdout=mock_stdout)

    request_dict = json.loads("""
    {
        "method": "POST",
        "url": "https://httpie.org",
        "headers": {"Content-Type": "text/plain"},
        "cookies": {"chocolate": "chip"},
        "body": "Hello World"
    }
    """)

# Generated at 2022-06-12 00:14:36.583326
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from tests.helpers import http, httpbin, env
    import json

    def get_output_type(
        args: argparse.Namespace,
        env: Environment,
        stdout_isatty=True,
        prettify=False,
        stream=False,
        style='solarized',
    ) -> Type['BaseStream']:
        env.stdout_isatty = stdout_isatty
        args.prettify = prettify
        args.stream = stream
        args.style = style
        stream_class, _ = get_stream_type_and_kwargs(
            env=env,
            args=args,
        )
        return stream_class


# Generated at 2022-06-12 00:14:50.527050
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import ExitStatus
    from httpie.core import main


    # Test case 1 : Ensure body's content-type is json and it is pretty printed
    #   1a. Test case 1.1 : Verify that body is pretty printed with default style
    #   1b. Test case 1.2 : Verify that body is pretty printed with rapid style
    #   1c. Test case 1.3 : Verify that body is pretty printed with solarized style
    #   1d. Test case 1.4 : Verify that body is pretty printed with monokai style
    #
    # Test case 2 : Ensure that the body's content-type is not json and it is printed
    #   2a. Test case 2.1 : Verify that body is printed with default style

    # Test case 1
    # Testcase 1a : Verify that body is pretty printed with default style
   

# Generated at 2022-06-12 00:14:58.987181
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import sys
    from httpie.context import Environment
    env = Environment(stdout=sys.stdout, stdout_isatty=False)
    args = argparse.Namespace(
        format='custom',
        style='body',
        json=True,
        stream=False,
        prettify=('colors', 'format', 'format_options'),
        format_options={}
    )
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env, ('colors', 'format', 'format_options'), 'body', True, {'indent': 4})})

# Generated at 2022-06-12 00:15:09.868219
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    # when env.stdout_isatty is True and args.stream is False
    dummy_env = Environment()
    dummy_env.colors = True
    dummy_env.stdout_isatty = True
    dummy_args = argparse.Namespace()
    dummy_args.stream = False
    dummy_args.prettify = False
    dummy_args.style = 'fiber'
    dummy_args.json = False
    dummy_args.debug = False
    dummy_args.traceback = False

    dummy_request_message = requests.PreparedRequest()
    dummy_request_message.url = 'http://example.com/'
    dummy_request_message.method = 'GET'
    dummy_request_message.headers = {'user-agent':'User Agent'}


# Generated at 2022-06-12 00:15:16.633265
# Unit test for function write_message
def test_write_message():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    env = Environment(args)
    text_request = b'GET / HTTP/1.1\r\nHost: httpie.org\r\nContent-Type: text/plain\r\n\r\ndata'
    request = requests.Request(method='GET', url='http://httpie.org/').prepare()
    request.body = 'data'
    request.headers['Content-Type'] = 'text/plain'
    write_message(request, env, args, with_headers=True, with_body=True)
    write_message(request, env, args, with_headers=True, with_body=False)
    write_message(request, env, args, with_headers=False, with_body=True)
    write

# Generated at 2022-06-12 00:15:27.793116
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.compat import urllib3

    req = requests.Request(
        method='GET',
        url='http://www.httpbin.org/',
        # We have no way to have or reliably mock a prepared request
        # in this context, so we pass a dummy value.
        # We know that the argument is not used in this specific case.
        #
        # See the code that uses this function:
        # https://gitlab.com/httpie/httpie/blob/e16a0f51/httpie/downloads.py#L207
        data=urllib3.packages.six.BytesIO(b''),
        headers={
            'Accept': 'application/json',
        }
    )
    req.prepare()
    resp = requests.Response()
    resp.status_code = 200


# Generated at 2022-06-12 00:15:37.593723
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    output_stream = build_output_stream_for_message(
        args="",
        env="",
        requests_message="",
        with_headers=True,
        with_body=True,
    )
    try:
        output_stream = bytearray(output_stream)
        AssertionError("")
    except TypeError:
        pass
    test_stream = b"{\n   "
    try:
        assert test_stream in output_stream
    except AssertionError:
        raise AssertionError("Test fail")
    finally:
        print("Test success")

# Generated at 2022-06-12 00:15:58.209369
# Unit test for function write_message
def test_write_message():
    test_write_message_with_body_and_header = write_message(requests.PreparedRequest, Environment, argparse.Namespace ,with_body=True, with_headers=True)
    assert test_write_message_with_body_and_header is None
    test_write_message_with_no_body_and_header = write_message(requests.PreparedRequest, Environment, argparse.Namespace, with_body=False, with_headers=False)
    assert test_write_message_with_no_body_and_header is None

# Generated at 2022-06-12 00:16:09.211700
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import sys
    import requests
    import httpie
    import argparse
    from httpie import ExitStatus

    r = requests.Request('GET', 'http://httpbin.org/get?name=DedSec')
    pr = r.prepare()
    args = httpie.cli.parser.parse_args([
        '--debug',
        '--json',
        '--pretty', 'all',
        '--stream',
        '--traceback',
        '--verbose'
    ])
    env = httpie.cli.environment.Environment(stdin=sys.stdin, stdout=sys.stdout)
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-12 00:16:19.287031
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        colors=False,
        stdin_isatty=False,
        stdout_isatty=False,
        is_windows=True,
        stdout_encoding='ASCII',
        stdin=None,
        stdin_raw=False,
    )


# Generated at 2022-06-12 00:16:31.047847
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import EncodedStream, RawStream, PrettyStream
    from httpie.config import Config
    from httpie.context import Environment
    import json
    import os
    import tempfile
    import unittest

    class TestGetStreamTypeAndKwargs(unittest.TestCase):
        def setUp(self):
            self.args = argparse.Namespace()
            self.args.prettify = None
            self.args.style = None
            self.args.stream = False
            self.args.json = True
            self.args.format_options = {}
            # Create temporary config file
            f, self.config_file_path = tempfile.mkstemp()
            os.close(f)


# Generated at 2022-06-12 00:16:34.911884
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    write_message(requests_message, env, args)

# Generated at 2022-06-12 00:16:42.206525
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    data = b'abc\x1b[0m\x1b[0m\x1b[31m\x1b[43mbc'
    data_bytes = data
    data_text = data.decode('utf8')
    data_bytes_len = len(data_bytes)
    data_text_len = len(data_text)

    class FakeFile():
        def __init__(self):
            self.data_written = b''

        def write(self, data):
            self.data_written += data

        def flush(self):
            pass

    fake_file = FakeFile()

    class FakeStream():
        def __init__(self, data):
            self.data = data

        def __iter__(self):
            return iter([self.data])


# Generated at 2022-06-12 00:16:52.145128
# Unit test for function write_message
def test_write_message():
    import os
    import requests
    import tempfile
    # import urllib3
    import io

    # urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    # Disable ssl warnings

    env = Environment()

# Generated at 2022-06-12 00:17:01.942285
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, BufferedPrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    env = Environment(
        stdout_isatty=True,
        stdin_isatty=True,
        is_windows=False,
        config_dir=None,
        output_options={},
        color_scheme=None,
    )
    args = argparse.Namespace(
        json=False,
        prettify=True,
        stream=False,
        style=None,
        format_options={}
    )

# Generated at 2022-06-12 00:17:12.782842
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    from httpie import core
    from httpie.models import Environment, KeyValue, KeyValueArgType

    import argparse

    args = ['-s']
    env = Environment(
        colors=64,
        stdin=object(),
        stdin_isatty=False,
        stdout=core.get_response_writer(),
        stdout_isatty=True,
        verify=True,
    )


# Generated at 2022-06-12 00:17:17.043468
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Given
    stream = b'\x1b[32mHello World\x1b[39m'
    outfile = io.StringIO()
    flush = False

    # When
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=flush
    )

    # Then
    assert outfile.getvalue() == '\x1b[32mHello World\x1b[39m'



# Generated at 2022-06-12 00:17:40.375292
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(colors=256)
    arg = argparse.Namespace(stream=False, prettify="all")
    assert get_stream_type_and_kwargs(env, arg) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(),
                                                                           'formatting': Formatting(env=env,
                                                                                                    groups='all',
                                                                                                    color_scheme='print',
                                                                                                    explicit_json=False,
                                                                                                    format_options=None)})
    arg = argparse.Namespace(stream=True, prettify="all")

# Generated at 2022-06-12 00:17:51.134170
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    fake_file = io.StringIO()
    fake_file.encoding = 'utf-8'
    fake_stream = EncodedStream(env=Environment())
    fake_stream.write_bytes(b'\x1b[34m\n\n')
    fake_stream.write_bytes(b'\x1b[1A\x1b[2K')
    fake_stream.write_bytes(b'\x1b[34m[1] \x1b[0m\n')
    fake_stream.write_bytes(b'\x1b[0m')
    write_stream_with_colors_win_py3(fake_stream, fake_file, True)
    fake_file.seek(0)
    output = fake_file.getvalue()

# Generated at 2022-06-12 00:18:02.766554
# Unit test for function write_message
def test_write_message():
    # Test with Python 2
    class TestRawStream:
        def __init__(self):
            pass

        def __iter__(self):
            for i in range(1, 11):
                yield 'Chunk Number %d' % i

    class TestEncodedStream:
        def __init__(self):
            pass

        def __iter__(self):
            for i in range(1, 11):
                yield 'Encoded Chunk Number %d' % i

    class TestPrettyStream:
        def __init__(self):
            pass

        def __iter__(self):
            for i in range(1, 11):
                yield 'Pretty Chunk Number %d' % i

    class TestBufferedPrettyStream:
        def __init__(self):
            pass


# Generated at 2022-06-12 00:18:06.697645
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        colors=256,
        stdin_isatty=True,
        stdout_isatty=True,
        stdout_bytes_written=0,
        is_windows=False,
        colors_mode='auto',
        is_ci=False,
        stdout_is_redirected=False,
    )

# Generated at 2022-06-12 00:18:15.969510
# Unit test for function write_stream
def test_write_stream():
    env = Environment()
    env.stdout = sys.stdout
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.prettify = 'all'
    args.style = 'default'
    args.format_options = [{'key': 'json.stream', 'value': 'true'}]
    args.json = False
    args.stream = False
    req = requests.PreparedRequest()
    req.headers = {'a': 'b'}
    req.body = b'{"a": "b"}'
    outfile = StringIO()


# Generated at 2022-06-12 00:18:26.903499
# Unit test for function write_message
def test_write_message():
    from httpie.compat import is_py26

    import unittest
    import argparse
    from os import path
    from httpie.compat import is_windows
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    import httpie.context
    import httpie.compat
    import io

    class TestUnit(unittest.TestCase):
        def setUp(self):
            self.args = argparse.Namespace()
            self.env = httpie.context.Environment(vars={
                'HTTPIE_CONFIG_DIR': path.join(path.dirname(__file__),
                                               '../httpie')
            })
            self.env.config.load()


# Generated at 2022-06-12 00:18:39.133429
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests

    test_args = argparse.Namespace()
    test_args.debug = False
    test_args.stream = False
    test_args.prettify = False
    test_args.style = False

    test_env = Environment()
    test_env.stdout = mock.MagicMock()
    test_env.is_windows = False
    test_env.stdout_isatty = False

    test_requests = requests.PreparedRequest()


# Generated at 2022-06-12 00:18:50.988624
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import os
    import requests
    import json
    import httpie
    import tempfile
    env = Environment(stdout=sys.stdout, stderr=sys.stderr, is_windows=True)
    args = httpie.core.parse_args([])
    with tempfile.NamedTemporaryFile() as request_file:
        request_file.write(json.dumps({'method': 'POST', 'url': 'https://google.com', 'data': '{"test": "value"}'}).encode())
        request_file.seek(0)
        request = requests.Request('POST', 'https://google.com', data='{"test": "value"}')

# Generated at 2022-06-12 00:19:00.899010
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.output import streams
    from httpie.output.colors import NoColor
    from httpie.output.formatters import JSONFormatter, FORMFormatter
    from httpie.plugins import builtin
    from httpie.plugins import plugin_manager
    from httpie.utils import env
    plugin_manager.load_builtin_plugins(builtin.__all__)
    args = parser.parse_args(['/'])
    env.stdout_isatty = False
    env.stdout = lambda: ''
    env.stdout_isatty = True
    env.stdout = lambda: ''
    args.method = "GET"
    args.url = "https://httpbin.org/get"
    args.headers = []
    args.auth = None

# Generated at 2022-06-12 00:19:04.196393
# Unit test for function write_stream
def test_write_stream():
    import io
    from contextlib import redirect_stdout
    
    f = io.StringIO()
    
    with redirect_stdout(f):
        chunks = ["test"]
        write_stream(chunks, f, False)
    
    assert f.getvalue() == "test"