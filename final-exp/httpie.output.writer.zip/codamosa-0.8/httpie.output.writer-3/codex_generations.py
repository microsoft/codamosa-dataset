

# Generated at 2022-06-12 00:09:22.515562
# Unit test for function write_message
def test_write_message():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(prettify=False, style=None, format_options=None)
    )
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': Environment()}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(prettify=["json"], style=None, format_options=None)
    )
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-12 00:09:34.431830
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace(
        prettify=['all'],
        stream=True,
    )
    env = Environment(stdout_isatty=True)
    import requests
    import io
    requests_message = requests.Response()
    requests_message.raw = io.BytesIO(b'{"test": "success"}')
    requests_message.url = "http://127.0.0.1"
    requests_message.status_code = 200
    requests_message.headers = {"content-type": "application/json"}
    requests_message.encoding = "utf-8"
    requests_message.reason = "OK"
    requests_message.request = requests.PreparedRequest()
    requests_message.request.url = "http://127.0.0.1"
    requests_message.request.method

# Generated at 2022-06-12 00:09:41.137557
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Test function write_stream_with_colors_win_py3()"""
    # pylint: disable=import-outside-toplevel
    from httpie.output.streams import build_output_stream
    # pylint: disable=protected-access
    from httpie.output.streams import _COLORS_256

    mock_stream = build_output_stream(
        env='stdout_isatty',
        args='pretty',
        msg='message',
        with_headers='with_headers',
        with_body='with_body',
    )
    mock_stream.stream = mock_stream
    mock_stream.colors = _COLORS_256.copy()
    mock_stream.chars = mock_stream.chars()
    mock_stream.iter_chunks = mock_stream.iter_ch

# Generated at 2022-06-12 00:09:48.447572
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """A unit test for function write_stream_with_colors_win_py3"""
    # color = b'\x1b['
    encoding = "utf-8"
    outfile = io.StringIO()

# Generated at 2022-06-12 00:09:53.134604
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Arrange
    # prepare argument
    env = 'env'
    outfile = 'outfile'
    flush = 'flush'

    # prepare stream
    stream = BaseStream()
    stream.__class__.CHUNK_SIZE = 1
    stream_data = ['data1', 'data2']
    stream.__iter__ = lambda self: iter(stream_data)

    # Assert
    write_stream_with_colors_win_py3(stream, outfile, flush)

if __name__ == '__main__':
    test_write_stream_with_colors_win_py3()

# Generated at 2022-06-12 00:09:53.775496
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-12 00:09:54.794829
# Unit test for function write_stream
def test_write_stream():
    pass


# Generated at 2022-06-12 00:10:05.227938
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import BaseStream
    class TestStream(BaseStream):
        def chunks(self):
            yield b'\x1b[31mtest\x1b[0m'
            yield b'\x1b[32mtest\x1b[0m'
            yield b'\x1b[33mtest\x1b[0m'
            yield b'\x1b[34mtest\x1b[0m'
            yield b'\x1b[35mtest\x1b[0m'
            yield b'\x1b[36mtest\x1b[0m'
            yield b'\x1b[37mtest\x1b[0m'
            yield b'test'
        def __iter__(self):
            return self.chunks()

# Generated at 2022-06-12 00:10:14.675734
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    test_out = StringIO()
    color_str = '\x1b[34mcolor\x1b[0m'
    bytes_written = write_stream_with_colors_win_py3(
        stream=BytesIO(b'\x1b[34mcolor\x1b[0mnocolor'),
        outfile=test_out,
        flush=False
    )
    assert bytes_written == len('color\x1b[0mnocolor')
    assert test_out.getvalue() == color_str + 'nocolor'

# Generated at 2022-06-12 00:10:24.837633
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace(all = True,
                            body = False,
                            download = False,
                            files = [],
                            form = False,
                            headers = False,
                            https_insecure = False,
                            index_errors = True,
                            method='GET',
                            output_dir = None,
                            output_file = None,
                            output_options = [],
                            prettify = None,
                            print_body = False,
                            print_headers = False,
                            session = None,
                            style = 'default',
                            traceback = False,
                            upload_file = None,
                            verbose = False,
                            verify = False)
    env = Environment()
    requests_message = requests.PreparedRequest()
    requests_message.body

# Generated at 2022-06-12 00:10:41.933829
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.config import Config
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    import requests
    import responses

    def _request(url):
        url = url.split('https://', 1)[-1]
        with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
            rsps.add(rsps.GET, url, body='hello')
            r = requests.get(url)
        return r

    env = Environment(
        stdin=io.BytesIO(),
        stdout=io.BytesIO(),
        stderr=io.BytesIO(),
        verify=True,
        config=Config()
    )
    args = parser.parse_args

# Generated at 2022-06-12 00:10:54.432197
# Unit test for function write_message
def test_write_message():
    import sys
    import io
    import requests
    import pytest

    sys.stdout = stdout = io.BytesIO()
    sys.stderr = stderr = io.BytesIO()
    temp = requests.message.Message()
    temp.headers = {'Content-Type': 'application/json; charset=UTF-8'}
    temp.body = '{"a": "b"}'
    temp.status_code = 200

    env = Environment()
    args = argparse.Namespace()
    args.stream = False
    args.prettify = 'all'
    args.style = 'colors'
    args.json = False
    args.format_options = {}

    write_message(temp, env, args)

# Generated at 2022-06-12 00:10:56.483531
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(['a', 'b'], sys.stdout, flush=False) is None

test_write_stream()

# Generated at 2022-06-12 00:11:09.480350
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Tests to ensure the correct stream is written depending on the
    isatty status of the stream.

    """
    stream = io.BytesIO()
    outfile = io.TextIOWrapper(stream)
    outfile.encoding = 'utf8'
    write_stream_with_colors_win_py3(
        stream=b'foo bar',
        outfile=outfile,
        flush=False
    )
    assert stream.getvalue() == b'foo bar'

    stream = io.BytesIO()
    outfile = io.TextIOWrapper(stream)
    outfile.encoding = 'utf8'

# Generated at 2022-06-12 00:11:14.799541
# Unit test for function write_stream
def test_write_stream():
    buffer_io = io.BytesIO()
    write_stream(
        stream=BaseStream(
            msg=HTTPResponse(requests.Response()),
            with_headers=True,
            with_body=True,
        ),
        outfile=buffer_io,
        flush=True,
    )
    print('write_stream: ok')


if __name__ == '__main__':
    test_write_stream()

# Generated at 2022-06-12 00:11:24.828479
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    message = requests.PreparedRequest()
    args = argparse.Namespace()
    args.stream = True
    args.prettify = 'all'
    env = Environment()
    env.stdout_isatty = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__.__name__ == 'Conversion'
    assert stream_kwargs['formatting'].__class__.__name__ == 'Formatting'
    assert stream_kwargs['formatting'].env == env


# Generated at 2022-06-12 00:11:35.367085
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import input
    from httpie.downloads import StreamingDownloadHandler, StreamingUploadHandler
    from httpie.output import streams
    import io

    class MockEnv:
        def __init__(self):
            self.stdout_isatty = True
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()
            self.is_windows = False

    class MockArgs:
        def __init__(self):
            self.prettify = ['colors']
            self.style = 'solarized'
            self.stream = True
            self.json = True

    class MockRequestsMessage:
        def __init__(self):
            self.body = ''

    env = MockEnv()
    args = MockArgs()
    msg = MockRequestsMessage()
   

# Generated at 2022-06-12 00:11:45.099495
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class C(object):
        def __init__(self, encoding: str):
            self.encoding = encoding

        def buffer(self, arg: bytes):
            return self

        def write(self, arg: bytes):
            self.arg = arg
    assert write_stream_with_colors_win_py3({'foo': 'bar'}, C('utf8'), False) == None
    assert C.arg == 'b\'{\'foo\': \'bar\'}\''

    assert write_stream_with_colors_win_py3({'foo': 'bar'}, C('gbk'), False) == None
    assert C.arg == 'b\'{\'foo\': \'bar\'}\''


# Generated at 2022-06-12 00:11:56.530238
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import sys

    try:
        import colorama
        colorama.init()
        reset_all = colorama.Style.RESET_ALL
    except ImportError:
        reset_all = ''

    env = Environment(
        is_windows=True,
        is_posix=False,
        stdout_isatty=True,
        stdout=sys.stdout,
        stdout_binary=sys.stdout.buffer,
        stderr=sys.stderr,
        stderr_binary=sys.stderr.buffer,
    )

# Generated at 2022-06-12 00:12:05.392247
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()

    # test: when stdout is not a tty, and is not pretty
    args = argparse.Namespace(prettify=[],raw=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE}

    # test: when stdout is a tty, and is not pretty
    env.stdout_isatty = True
    args = argparse.Namespace(prettify=[],raw=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream

# Generated at 2022-06-12 00:12:28.598286
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Test for write_stream_with_colors_win_py3 function.

    """
    import tempfile
    import io

    with tempfile.NamedTemporaryFile(mode='w+', buffering=1) as f:
        stream = io.BytesIO(b'\x1b[41mtest\x1b[0m\x1b[41mtest2\x1b[0m')
        write_stream_with_colors_win_py3(stream, outfile=f, flush=False)
        f.seek(0)
        assert f.read() == '\x1b[41mtest\x1b[0m\x1b[41mtest2\x1b[0m'

# Generated at 2022-06-12 00:12:31.795298
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(
        stream=True,
        prettify=True
    )
    env = Environment()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['conversion'] == Conversion()
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['formatting'], Formatting)

# Generated at 2022-06-12 00:12:32.770157
# Unit test for function write_stream
def test_write_stream():
    pass


# Generated at 2022-06-12 00:12:41.154786
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import exit_status

# Generated at 2022-06-12 00:12:52.444305
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-12 00:13:02.907066
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.config import Config
    from httpie.output import streams
    from httpie.context import Environment as Env
    from httpie.models import Response
    from httpie.compat import is_py36

    s = StringIO()
    env = Env(
        stdout=s,
        is_windows=True,
        colors=256,
    )

    config = Config(env=env)

# Generated at 2022-06-12 00:13:14.080186
# Unit test for function write_message
def test_write_message():
    """
    Test function write_message by creating a dummy requests.PreparedRequest and requests.Response
    and asserting that the function does not error by calling write_message and checking that the
    output is correct.
    :return: nothing
    """
    import sys
    import io

    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    import requests
    import httpie.context
    import httpie.output.streams
    import httpie.models
    import httpie.output.processing
    import httpie.output

    # create dummy request
    req = requests.PreparedRequest()
    req.url = "https://www.test.com"
    req.headers['Content-Type'] = 'application/json'
    req.headers['Accept'] = 'application/json'
    req.method

# Generated at 2022-06-12 00:13:24.787530
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    env = Environment()
    assert get_stream_type_and_kwargs(env, args={'prettify': True, 'stream': False}) == (BufferedPrettyStream,
                                  {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env,
                                                                                                    groups=True,
                                                                                                    color_scheme='',
                                                                                                    explicit_json=False,
                                                                                                    format_options=False)})


# Generated at 2022-06-12 00:13:37.151145
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import mock
    from io import StringIO
    from httpie.models import HTTPRequest, HTTPResponse
    buffer = StringIO()
    with mock.patch.object(requests.PreparedRequest, 'headers'):
        with mock.patch.object(requests.PreparedRequest, 'body'):
            with mock.patch.object(requests.Response, 'headers'):
                with mock.patch.object(requests.Response, 'content'):
                    for stream in build_output_stream_for_message(
                        args=mock.Mock(),
                        env=mock.Mock(),
                        requests_message=HTTPRequest(
                            requests.PreparedRequest()
                        ),
                        with_headers=True,
                        with_body=True
                    ):
                        buffer.write(stream.decode())

# Generated at 2022-06-12 00:13:46.764403
# Unit test for function write_stream
def test_write_stream():
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=True,
        stdin_isatty=True,
        components=None,
        config_dir=None,
    )

    args = argparse.Namespace(
        stream=False,
        prettify=None,
        format=None,
        style=None,
        json=False,
        traceback=False,
        download=None,
        output_file=None,
        form=False,
        files=None,
        implicit_content_type='',
        pretty=None,
        style_sheet=''
    )

    r = requests.PreparedRequest()
    r.prepare()
    assert 'write_message(r)' in write_stream.__doc

# Generated at 2022-06-12 00:14:06.000138
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import get_stream_type_and_kwargs
    from httpie import ExitStatus
    from httpie.core import main as httpie
    from httpie.compat import is_windows
    from tempfile import NamedTemporaryFile
    import time
    env = Environment()
    stdout_isatty = env.stdout_isatty
    args = parser.parse_args(['https://httpbin.org/'])
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class(msg=None, with_headers=None, with_body=None, **stream_kwargs)

    env = Environment()

# Generated at 2022-06-12 00:14:08.972595
# Unit test for function write_stream
def test_write_stream():

    write_stream(['test-stream'], sys.stdout, False)

# Generated at 2022-06-12 00:14:10.384879
# Unit test for function write_message
def test_write_message():
    # the function cannot be tested, but the function called inside it can though.
    assert True

# Generated at 2022-06-12 00:14:17.619155
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-12 00:14:20.618401
# Unit test for function write_message
def test_write_message():
    write_message(requests.PreparedRequest, Environment(), "", False, False)
    write_message(requests.Response, Environment(), "", False, False)

# Generated at 2022-06-12 00:14:23.661163
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    byte_stream = build_output_stream_for_message(None, None, requests.Response, True, True)
    [byte_iter] = byte_stream
    assert type(byte_iter) is bytes

# Generated at 2022-06-12 00:14:35.207242
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    class MockResponse(object):
        def __init__(self, headers, body):
            self.headers = headers
            self.body = body

    class MockIO(object):
        def __init__(self, stdout='', buffer_out=''):
            self.stdout = stdout
            self.buffer_out = buffer_out

        def write(self, out):
            self.stdout += out

        def buffer_write(self, out):
            self.buffer_out += out

    stdout = MockIO()

# Generated at 2022-06-12 00:14:49.198988
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli.output.streams import PrettyStream
    from httpie.cli.output.streams import BufferedPrettyStream
    from httpie.cli.output.streams import RawStream
    from httpie.cli.output.streams import EncodedStream
    f = io.StringIO()
    # prettify file
    args = argparse.Namespace()
    args.stream = False
    args.prettify = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(f, args)
    assert issubclass(stream_class, BufferedPrettyStream)
    # prettify stream
    args = argparse.Namespace()
    args.stream = True
    args.prettify = True

# Generated at 2022-06-12 00:14:59.053495
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.compat import (
        is_windows,
        is_py3,
    )
    import mock
    import socket
    import requests
    import os
    import sys

    class MockStdout(object):
        def __init__(self, isatty=True):
            self.isatty = isatty

        def write(self, data):
            pass

        def flush(self):
            pass

    class MockSocket(object):
        def gettimeout(self):
            return None

    def set_response_content(response, content):
        response._content = content
        response._content_consumed = False

# Generated at 2022-06-12 00:15:09.869551
# Unit test for function write_message
def test_write_message():
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream
    from httpie.compat import is_windows
    from httpie import output

    requests_message = object()
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(debug=False, stream=False, prettify=['colors'], style='paraiso')

# Generated at 2022-06-12 00:15:36.991974
# Unit test for function write_message
def test_write_message():
    assert 1 == 1

# Generated at 2022-06-12 00:15:46.986860
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class FakeEnv:
        def __init__(self, istty):
            self.stdout_isatty = istty

    class FakeArgs:
        def __init__(self, prettify, stream, style, json):
            self.prettify = prettify
            self.stream = stream
            self.style = style
            self.json = json
            self.format_options = {}

    def check_stream(env=None, args=None):
        return get_stream_type_and_kwargs(env, args)

    check_stream(FakeEnv(True), FakeArgs('none', False, None, True))
    check_stream(FakeEnv(True), FakeArgs('none', True, None, True))
    check_stream(FakeEnv(True), FakeArgs('all', False, 'parrot', True))

# Generated at 2022-06-12 00:15:47.537301
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-12 00:15:58.097848
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.downloads import Downloader

    url = 'https://www.runoob.com/python3/python3-tutorial.html'

    #\x1b[37;40m
    #\x1b[0m
    env = Environment()
    env.stdout = open('./stdout', 'w')
    env.stderr = open('./stderr', 'w')

    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'paraiso-dark'

# Generated at 2022-06-12 00:16:09.062555
# Unit test for function write_stream
def test_write_stream():
    import os
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    # TODO: use mock
    class MockOutfile(object):
        def __init__(self):
            self.written_bytes = b''
        def write(self, *args, **kwargs):
            self.written_bytes += args[0]
        def __getattr__(self, attr):
            return self.write
    class MockStdin(object):
        def isatty(self):
            return False

    outfile = MockOutfile()
    stream_class = EncodedStream
    stream_kwargs = {
        'ofile': outfile,
        'env': Environment(),
    }
    stream = stream_class(b'abcdefg', **stream_kwargs)
    write

# Generated at 2022-06-12 00:16:19.125120
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.output.streams import BinaryStream, PrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.argtypes import KeyValueArg, KeyValue
    import httpie
    import requests

    def mock_request_build_kwargs(self, args, env, stdin_isatty=True):
        return {
            'method': args.method,
            'url': args.url,
            'data': args.data,
            'files': args.files,
            'headers': args.headers,
            'params': args.params,
        }

    httpie.core.HTTPRequest.build_request_from_args = mock_request_build_kwargs


# Generated at 2022-06-12 00:16:31.047561
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # case: term_isatty = False, stream = False, no prettify
    # response = {'headers': {'content-length': '40'}, 'body': 'hello world'}
    # expect: stream_class = RawStream, stream_kwargs = {'chunk_size': 1}
    env = Environment(False)
    args = argparse.Namespace(
                        stream=False,
                        prettify=None,
                        style=None,
                        json=None,
                        format_options=None,
                        debug=False,
                        traceback=False
                    )
    result = build_output_stream_for_message(args, env, {'headers': {'content-length': '40'}, 'body': 'hello world'}, True, True)
    assert(type(next(result)) == RawStream)

# Generated at 2022-06-12 00:16:37.194361
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace(stream=True)
    requests_message = requests.PreparedRequest()
    with_headers=True
    with_body=True
    with pytest.raises(IOError):
        write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-12 00:16:42.902322
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    sys.stdin = io.StringIO('abcdefg\n')
    sys.argv = ['http', '--stream', '--headers', 'https://httpbin.org/get']
    from httpie.cli import main
    with mock.patch('httpie.output.streams.BaseStream.write_stream',
                    side_effect=write_stream_with_colors_win_py3):
        main()

# Generated at 2022-06-12 00:16:45.419047
# Unit test for function write_stream
def test_write_stream():
    with pytest.raises(ValueError):
        write_stream(stream='test', outfile=1)
        write_stream(stream=1, outfile='test')

# Generated at 2022-06-12 00:17:53.982440
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie import ExitStatus
    from requests import Request, Response

    # post request
    args = [
        '--pretty=none', 'post',
        'https://www.google.com', 'hello=world',
    ]
    exit_status, _, stderr = main(args)
    assert exit_status == ExitStatus.OK
    assert not stderr.getvalue()

    # get request
    args = [
        '--pretty=none', 'get',
        'https://www.google.com', 'hello=world',
    ]
    exit_status, _, stderr = main(args)
    assert exit_status == ExitStatus.OK
    assert not stderr.getvalue()

    # post request

# Generated at 2022-06-12 00:18:06.258760
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # env, args
    env1 = Environment(
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=False,
        stderr=None,
        stderr_isatty=True,
    )
    args1 = argparse.Namespace(
        stream=False,
        style='solarized',
        prettify=[],
        format_options=None,
        download=False,
    )
    assert (get_stream_type_and_kwargs(env1, args1) ==
            (RawStream, {'chunk_size': 1024}))


# Generated at 2022-06-12 00:18:08.017551
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    write_message(build_output_stream_for_message("", "", "", False, False))

# Generated at 2022-06-12 00:18:16.922142
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import requests
    import sys
    # Redirect stderr to stdout

    # create a dummy args object
    args = argparse.Namespace()
    args.stream = True
    args.style = None
    args.json = True
    args.format_options = {}
    args.prettify = ['colors', 'format', 'divider']

    # create a dummy env object
    env = Environment()
    env.is_windows = os.name == "nt"
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdout_isatty = True
    env.stderr_isatty = True

    # create a request
    request = requests.Request('GET', 'https://httpie.org')
    prepared = request.prepare

# Generated at 2022-06-12 00:18:27.679387
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.cli import parser
    import requests
    import json
    import sys
    import io

    try:
        # Python 3
        stdout_isatty = sys.stdout.isatty()
        stdout_buffer_attr = 'buffer'
    except AttributeError:
        # Python 2
        stdout_isatty = False
        stdout_buffer_attr = 'stdout'


# Generated at 2022-06-12 00:18:39.562690
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    import unittest

    from httpie.output.streams.base import BaseStream
    from httpie.output.streams.buffered import BufferedStream
    from httpie.output.streams.json import JSONStream

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk.encode()

    class TestBufferedStream(BufferedStream, TestStream):
        pass

    class TestJSONStream(JSONStream, TestStream):
        pass

    class TestEncodedStream(EncodedStream, TestStream):
        pass

    class TestBufferedPrettyStream(BufferedPrettyStream, TestStream):
        pass


# Generated at 2022-06-12 00:18:51.270045
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.compat import is_windows, isatty
    args = argparse.Namespace()
    args.prettify = 'all'
    args.style = 'httpie'
    args.json = True
    args.debug = False
    args.traceback = False
    args.format_options = {'backend': 'tornado'}
    env = Environment(args=args, stdin=None, stdin_isatty=False, stdout=None,
                    stdout_isatty=False)
    args.stream = False
    requests_message = requests.Response()
    requests_message.status_code = 200

# Generated at 2022-06-12 00:18:53.973067
# Unit test for function write_message
def test_write_message():
    assert write_message(requests.PreparedRequest,Environment,argparse.Namespace) == None
    assert write_message(requests.Response,Environment,argparse.Namespace) == None


# Generated at 2022-06-12 00:18:54.553554
# Unit test for function write_message
def test_write_message():
    return True

# Generated at 2022-06-12 00:18:56.901234
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    result = write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_headers=with_headers,
        with_body=with_body,
    )
    assert result == None

