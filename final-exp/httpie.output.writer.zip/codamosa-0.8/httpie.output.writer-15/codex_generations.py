

# Generated at 2022-06-12 00:09:22.008247
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input.utils import get_response_encoding
    from httpie.models import HTTPResponse
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(
        headers='',
        style='',
        prettify='',
        download=False,
        stream=True,
        json=False,
        form=False,
        body=True,
        include=False,
        traceback=False,
        print_bodies=True,
        debug=False,
        output_dir=None,
        output_file=None,
        output_options=None,
        formatter_options=None,
        pretty=False,
    )
    response = requests.Response()

# Generated at 2022-06-12 00:09:34.024218
# Unit test for function write_message
def test_write_message():
    with open('test_write_message.txt', 'r') as standard_out:
        output_stream = standard_out.read()
    message = 'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n'
    env = Environment()
    env.stdout = open('test_write_message.txt', 'w')
    args = argparse.Namespace()
    requests_message = requests.Response()
    requests_message.raw = io.StringIO(message)
    requests_message.encoding = 'utf-8'

    write_message(requests_message, env, args, with_headers=False, with_body=False)
    assert output_stream == '\n'

# Generated at 2022-06-12 00:09:41.818234
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream
    env = Environment()
    args = argparse.Namespace(prettify=['headers'], stream=True, style='foo')
    assert get_stream_type_and_kwargs(env, args) == (PrettyStream, {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=['headers'],
            color_scheme='foo',
            explicit_json=False,
            format_options={},
        ),
    })

# Generated at 2022-06-12 00:09:48.691894
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-12 00:10:01.138734
# Unit test for function write_message
def test_write_message():
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.models import KeyValue

    env = Environment()
    # env.config.default_options['--json'] = KeyValue
    # env.config.default_options['--form'] = KeyValue
    # env.config.default_options['--data'] = KeyValue
    # env.config.default_options['--body'] = KeyValue
    # env.config.default_options['--files'] = KeyValue

    request_args = argparse.Namespace()
    request_args.headers = KeyValueArgType()('X-Foo: bar')
    request_args.json = None
    request_args.form = None
    request_args.data = None
    request_args.body = None
    request_args.files = None

# Generated at 2022-06-12 00:10:08.099917
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    print(build_output_stream_for_message.__doc__)

    class args:
        class namespace:
            prettify = False
            style = None
            stream = False

    class env:
        stdout_isatty = False

    class req:
        class headers:
            pass
        def body():
            pass

    class res:
        def body():
            pass

    req.headers = {'content-length': 10}
    req.body = b'1234567890'
    req.url = 'http://www.example.com'
    req.method = 'GET'

    res.headers = {'content-length': 666}
    res.body = b'abcdefghijklmnopqrstuvwxyz'
    res.status_code = 200

# Generated at 2022-06-12 00:10:17.665040
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import httpie.output.streams

    env = Environment()
    args = argparse.Namespace(prettify=['colors'], style='default', json=False, format_options={}, stream=True)
    assert get_stream_type_and_kwargs(env=env, args=args) == (httpie.output.streams.PrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=['colors'], color_scheme='default', explicit_json=False, format_options={})})

    env = Environment(stdout_isatty=False)
    args = argparse.Namespace(prettify=['colors'], style='default', json=False, format_options={}, stream=True)
    assert get_stream_type_and_kwargs

# Generated at 2022-06-12 00:10:28.506153
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.output
    import httpie.output.streams
    import json
    import time

    mock_args = {
        'max_redirects': 3,
        'prettify': None,
        'session': None,
        'stream': False,
        'style': 'default',
        'verbose': False,
        'verify': False,
    }
    args = argparse.Namespace(**mock_args)

    mock_env = {
        'stdout_isatty': True,
        'stderr': sys.stderr,
        'stdout': sys.stdout,
        'stdin': sys.stdin,
    }
    env = httpie.Environment(**mock_env)
    with_headers = True
    with_body = True

    mock_requ

# Generated at 2022-06-12 00:10:38.889073
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from unittest.mock import MagicMock
    stdout = MagicMock()
    stdout.encoding = 'latin1'
    chunks = [
        b'\x1b[31m\x1b[1mfoo\x1b[0m',
        b'\x1b[32m\x1b[1mfoo\x1b[0m',
        b'bar'
    ]
    write_stream_with_colors_win_py3(
        stream=chunks,
        outfile=stdout,
        flush=False
    )

# Generated at 2022-06-12 00:10:49.388644
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Test write_stream_with_colors_win_py3 with simple string

    """
    import io
    import sys
    # redirect output to the string IO
    sys.stdout = stringio = io.StringIO()
    # write to string
    write_stream_with_colors_win_py3(
        stream=BaseStream(b'\x1b[33mtest\x1b[39m', True, True),
        outfile=stringio,
        flush=False,
    )
    assert stringio.getvalue() == '\x1b[33mtest\x1b[39m'

# Generated at 2022-06-12 00:11:02.158006
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(
        prettify=['colors'],
        style='none',
        stream=True,
        json=False,
        format_options=[],
        download=''
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream



# Generated at 2022-06-12 00:11:11.674216
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.cli import parser
    args = parser.parse_args(['--output-format-options', 's=¶'])
    env = Environment(vars={})
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == EncodedStream

# Generated at 2022-06-12 00:11:19.070968
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import BaseStream
    class TestColorsStream(BaseStream):
        def __init__(self, color='\x1b[0m', encoding='utf-8'):
            self.encoding = encoding
            self.color = color
            self.chunks = [
                b'foo',
                (self.color + b'bar' + self.color).encode(self.encoding),
                b'baz'
            ]

        def __iter__(self):
            return iter(self.chunks)

    import io
    import sys
    out = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=TestColorsStream(),
        outfile=out,
        flush=True,
    )

# Generated at 2022-06-12 00:11:19.737454
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-12 00:11:21.808187
# Unit test for function write_message
def test_write_message():
    write_message(requests.Response,Environment,argparse.Namespace,False,False)



# Generated at 2022-06-12 00:11:25.618955
# Unit test for function write_stream
def test_write_stream():
    buf = io.BytesIO()
    stream = [b'foo', b'bar', b'baz']
    write_stream(stream=stream, outfile=buf, flush=True)
    assert buf.getvalue() == b'foobarbaz'


# Generated at 2022-06-12 00:11:36.098627
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message = requests.Request('POST', 'http://example.com', json={'key':'value'})
    prepared_request = requests_message.prepare()
    response = requests.Response()
    response.status_code = 200
    response.url = 'http://example.com'
    response.headers = {'key': 'value'}
    response.request = prepared_request
    response.encoding = 'utf-8'
    env = Environment()
    args = argparse.Namespace(
        stream=True,
        verbose=2,
        format='default',
        style='default',
        colors=256,
        pretty='all',
        download=False
    )

    # Plain text output
    env.stdout_isatty = False

# Generated at 2022-06-12 00:11:44.026476
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(True, False) == (EncodedStream, {'env': True})
    assert get_stream_type_and_kwargs(False, True) == (RawStream, {'chunk_size': 8192})
    assert get_stream_type_and_kwargs(True, True) == (PrettyStream, {
            'env': True,
            'conversion': Conversion(),
            'formatting': Formatting(
                env=True,
                groups=True,
                color_scheme=None,
                explicit_json=False,
                format_options={}
            )
            })

# Generated at 2022-06-12 00:11:46.133815
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    get_stream_type_and_kwargs(env = env, args = args)

# Generated at 2022-06-12 00:11:57.597832
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class Object:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    args = Object()
    args.prettify = 'all'
    args.stream = True
    args.json = False
    args.raw = False
    
    class Object1(Object):
        def __init__(self, stdout_isatty, **kwargs):
            super(Object1, self).__init__(**kwargs)
            self.stdout_isatty = stdout_isatty
            
    env = Object1(True, debug=True, is_windows=False)

# Generated at 2022-06-12 00:12:13.167219
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    env = Environment()
    args.prettify = 'all'
    args.style = 'solarized-dark'
    args.format_options = {}
    args.json = False
    args.stream = True
    stream_class1, stream_kwargs1 = get_stream_type_and_kwargs(env, args)
    assert(stream_class1 == PrettyStream)
    args.stream = False
    stream_class2, stream_kwargs2 = get_stream_type_and_kwargs(env, args)
    assert(stream_class2 == BufferedPrettyStream)
    args.prettify = None
    args.stream = True
    stream_class3, stream_kwargs3 = get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-12 00:12:21.875061
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """Área de teste para a funcao build_output_stream_for_message"""

    from httpie.cli.parser import parse_args
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream

    Environment(
        stdin=open(os.devnull, 'rb'),
        stdout=sys.stdout,
        stderr=sys.stderr,
        colors=256,
    )
    args = parse_args([])
    args.traceback= True
    args.debug= True
    args.style= True
    args.format_options= True
    args.json= True
    args.prettify= True
    args.stream= True

    stream_class, stream_kwargs = get_stream_type_and_kw

# Generated at 2022-06-12 00:12:30.020912
# Unit test for function write_message
def test_write_message():
    from httprunner import exceptions, logger, utils
    from httprunner import __version__
    from httprunner.api import run_suite
    from httprunner.compat import OrderedDict
    from httprunner.loader import load_folder_files
    # test files
    testcase_folder_path = 'tests/data/demo_testsuite_httpbin'
    testsuite_file_path = 'tests/data/demo_testsuite_httpbin/testsuite_debugtalk.yml'
    testcase_file_path = 'tests/data/demo_testsuite_httpbin/testcases/testcase1_demo.yml'

# Generated at 2022-06-12 00:12:39.285232
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.compat import urlopen
    from httpie.output.streams import PrettyStream
    assert get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(
            prettify='colors',
            stream=True,
            style='solarized',
            format_options={'colors': True},
            json=False
        )
    ) == (PrettyStream, {
        'env': Environment(),
        'conversion': Conversion(),
        'formatting': Formatting(
            env=Environment(),
            groups={'colors'},
            color_scheme='solarized',
            explicit_json=False,
            format_options={'colors': True}
        )
    })

# Generated at 2022-06-12 00:12:51.237506
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class FakeStream:
        def __init__(self, value):
            self.value = value

        def __iter__(self):
            yield self.value

    class EncodingStringIO(io.StringIO):
        def __init__(self, encoding='UTF-8'):
            super(EncodingStringIO, self).__init__()
            self.encoding = encoding

    # Without color
    fake_value = b'hello'
    out = EncodingStringIO()
    write_stream_with_colors_win_py3(
        stream=FakeStream(fake_value),
        outfile=out,
        flush=True
    )
    assert out.getvalue() == 'hello'

    # With color
    out = EncodingStringIO()

# Generated at 2022-06-12 00:12:57.948006
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    test_env = Environment()
    test_env.is_windows = False
    test_env.stdout_isatty = True
    test_args = argparse.Namespace()
    test_args.prettify = None
    test_args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(test_env, test_args)
    assert stream_class == EncodedStream
    assert not stream_kwargs


# Generated at 2022-06-12 00:13:03.145148
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    >>> from io import StringIO
    >>> outfile = StringIO(newline='')
    >>> stream = b'\x1b[31mTEST'  # bytes
    >>> write_stream_with_colors_win_py3(stream, outfile, flush=False)
    >>> assert outfile.getvalue() == '\\x1b[31mTEST'  # str

    """

# Generated at 2022-06-12 00:13:14.176568
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import argparse
    import requests
    from httpie.output.pretty import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie import arguments
    output = MESSAGE_SEPARATOR_BYTES
    env = Environment(
        stdout_isatty=False,
        stdout=MockOutput(),
        stderr=MockOutput(),
        stdin=MockOutput(),
        argv=[1]
    )
    args = argparse.Namespace(
        json=None,
        pretty=None,
        style=None,
        format_options=[],
        traceback=None
    )
    req = requests.Request(
        method='GET',
        url='https://example.com/'
    )
    prepped = req.prepare()

# Generated at 2022-06-12 00:13:23.911739
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(colors=32, stdout_isatty=True)
    args = argparse.Namespace(prettify=[], stream=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}
    args = argparse.Namespace(prettify=['status'], stream=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-12 00:13:26.688176
# Unit test for function write_stream
def test_write_stream():
    write_stream_kwargs = {
        'stream': b'\x1b[32mhello world',
        'outfile': sys.stdout,
        'flush': True
    }
    write_stream(**write_stream_kwargs)


# Generated at 2022-06-12 00:13:39.272906
# Unit test for function write_message
def test_write_message():
    pass


# Generated at 2022-06-12 00:13:41.130419
# Unit test for function write_stream
def test_write_stream():
    # Test case 1: stream empty

    # Test case 2: stream not empty
    assert True



# Generated at 2022-06-12 00:13:41.925440
# Unit test for function write_message
def test_write_message():
    print(write_message)

# Generated at 2022-06-12 00:13:53.087428
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    import tempfile

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env='win',
        args=[None, None, None, None, None, None]
    )
    outfile_io = io.StringIO()

    chunks = [
        "chunk1",
        "chunk2\x1b[1;32mhi\x1b[0m",
        "chunk3",
    ]

    for chunk in chunks:
        result = stream_class(
            msg=chunk,
            with_headers=True,
            with_body=True,
            **stream_kwargs,
        )

# Generated at 2022-06-12 00:14:03.274253
# Unit test for function write_message
def test_write_message():
    import sys
    import requests
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.put('http://httpbin.org/put', data={'key': 'value'}, headers=headers)
    env = Environment(stdout_isatty=True)

# Generated at 2022-06-12 00:14:07.485271
# Unit test for function write_message
def test_write_message():
    requests_message = 'request_message'
    env = 'env'
    args = 'args'

    write_message(
        requests_message=requests_message,
        env=env,
        args=args,
    )

# Generated at 2022-06-12 00:14:16.575539
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-12 00:14:26.888526
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace(
        debug = False,
        traceback = False,
        prettify = ['colors'],
        style = None,
        json = False,
        format_options = None,
        stream = False,
        stdout = None,
        stdin = None,
        output_file = None,
        headers = None,
        ignore_stdin = False,
    )
    requests_message = requests.Response()
    requests_message.status_code = 200
    write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_headers=True,
        with_body=True,
    )


# Generated at 2022-06-12 00:14:36.889856
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout=None, stdout_isatty=True, is_windows=False)
    args = argparse.Namespace(
        stream=False,
        prettify=[],
        style=None,
        json=False,
        format_options={},
    )
    raw_stream_kwargs = {
        'chunk_size': RawStream.CHUNK_SIZE
    }
    notty_args = argparse.Namespace(
        stream=False,
        prettify=[],
        style=None,
        json=False,
        format_options={},
    )
    raw_stream_kwargs_notty = {
        'chunk_size': RawStream.CHUNK_SIZE
    }


# Generated at 2022-06-12 00:14:50.792740
# Unit test for function write_stream
def test_write_stream():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['all']
    args.style = 'parrot'
    args.format_options = None
    requests_message = requests.Response()
    requests_message.status_code = 200
    requests_message.reason = 'OK'
    stream = build_output_stream_for_message(args=args,
                                             env=env,
                                             requests_message=requests_message,
                                             with_body=True,
                                             with_headers=False)
    outfile = open(os.path.join(os.path.dirname(__file__), 'response.txt'), 'w')
    write_stream(stream=stream,
                 outfile=outfile,
                 flush=False)
    outfile.close()

# Generated at 2022-06-12 00:15:25.676300
# Unit test for function write_message
def test_write_message():
    # test 1
    url = 'https://httpbin.org/get'
    r = requests.get(url)
    class args:
        traceback = False
        download = False
        stream = False
        prettify = False

    class env:
        stdout = sys.stdout
        stdout_isatty = False
        stderr = sys.stderr
        is_windows = False

    write_message(
        requests_message = r,
        env = env,
        args = args,
        with_headers = True,
        with_body = True
    )
    # test 2
    # You could not see the print from test 2, because it is suppressed.
    # The reason of being suppressed is that the code of test 2 is used by write_stream,
    # which is used by write_message. 


# Generated at 2022-06-12 00:15:29.938727
# Unit test for function write_stream
def test_write_stream():
    test_data = [0,1,2,3,4,5,6,7,8,9]

    test_stream = BaseStream(test_data)

    test_buf = cStringIO()
    write_stream(test_stream, test_buf, flush=False)
    test_buf.seek(0)
    test_result = test_buf.read()
    assert(test_result == str(test_data))

# Generated at 2022-06-12 00:15:31.917777
# Unit test for function write_message
def test_write_message():
    requests.request(method='post', url='http://localhost:5000/login')

# Generated at 2022-06-12 00:15:32.902018
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    assert 1 == 2

# Generated at 2022-06-12 00:15:44.275439
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output import streams
    from httpie.output.streams import _get_stream_type_and_kwargs
    from httpie.compat import BytesIO

    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.Response()
    with_body = True
    with_headers = False


    args.prettify = []
    args.prettify = ['colors']
    args.prettify = ['format']
    args.json = False
    args.style = None
    args.format_options = None
    args.stream = True
    pretty_stream, pretty_stream_kwargs = _get_stream_type

# Generated at 2022-06-12 00:15:54.001394
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env=Environment()
    args=argparse.Namespace(
        prettify=True,
        stream=False,
        style='monokai',
        json=False,
        format_options=[],
    )

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env,args)

    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__ == Conversion
    assert stream_kwargs['formatting'].__class__ == Formatting
    assert stream_kwargs['formatting'].env == env
    assert stream_kwargs['formatting'].groups == ['colors']
    assert stream_kwargs['formatting'].color_scheme == 'monokai'

# Generated at 2022-06-12 00:16:01.693931
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import contextlib
    from httpie.context import Environment

    env_without_tty = Environment(
        stdin_isatty=False,
        stdout_isatty=False,
        is_windows=False
    )
    env_with_tty = Environment(
        stdin_isatty=False,
        stdout_isatty=True,
        is_windows=False
    )

# Generated at 2022-06-12 00:16:12.205917
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io

    s = io.BytesIO()
    env = Environment(
        stdout=io.TextIOWrapper(s, encoding='utf8'),
        stdout_isatty=True,
        is_windows=True
    )
    args = argparse.Namespace(prettify='colors')
    response = requests.Response()
    response.raw = io.BytesIO(b'\x1b[1;31mfoo')

    write_message(
        requests_message=response,
        env=env,
        args=args,
        with_headers=False,
        with_body=True,
    )

    assert s.getvalue() == '\x1b[1;31mfoo\n\n'

# Generated at 2022-06-12 00:16:12.905995
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-12 00:16:21.332404
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, EncodedStream, RawStream
    bstream = BytesIO()
    env = Environment()
    write_stream(PrettyStream(msg=False), bstream, False)
    assert bstream.getvalue().decode() == 'True'

    bstream = BytesIO()
    write_stream(EncodedStream(env=env), bstream, False)
    assert bstream.getvalue().decode() == 'True'

    bstream = BytesIO()
    write_stream(RawStream(msg=False), bstream, False)
    assert bstream.getvalue().decode() == 'True'



# Generated at 2022-06-12 00:16:53.340184
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = [
        b'HTTP/1.1 200 OK',
        b'\x1b[32mstatus\x1b[39m <200>',
        b'connection:',
        b'\x1b[33mkeep-alive\x1b[39m',
        b'transfer-encoding:',
        b'\x1b[33mchunked\x1b[39m',
        b'content-type:',
        b'\x1b[33mtext/plain; charset=utf-8\x1b[39m',
        b'',
        b'\x1b[38;5;24mHello 1234\x1b[39m'
    ]
    import io
    import sys

# Generated at 2022-06-12 00:17:02.807216
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        stdout_isatty=False,
        log_level=0,
        colors=256,
        stdin_isatty=False,
        stdout=sys.stdout,
        stdin=sys.stdin,
        stderr=sys.stderr,
        stdout_bytes_stdin_bytes=True,
    )
    args = argparse.Namespace(prettify=[], stream=True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == RawStream
    assert stream_class(msg=None, with_headers=True, with_body=True, **stream_kwargs)

# Generated at 2022-06-12 00:17:13.516613
# Unit test for function write_stream
def test_write_stream():
    from httpie.core import main
    from httpie.context import Environment
    from httpie import exit_status
    import os
    import tempfile
    env = Environment(
        stdin=io.BytesIO(),
        stdout=(io.BytesIO() if os.name == 'nt' else tempfile.TemporaryFile()),
        stderr=io.BytesIO()
    )
    args = argparse.Namespace(
        data='a=b',
        download=False,
        include=None,
        json=False,
        method='POST',
        pretty='all',
        preload_content=False,
        stream=True,
        styles=None,
        traceback=False,
        url='http://httpbin.org/post'
    )
    exit_status.ExitStatus.OK = 4
    main

# Generated at 2022-06-12 00:17:25.443313
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = True
    args.stream = True
    args.style = 'parity'
    args.json = True
    args.format_options = {"sort_keys": True}
    args.format_options = {"sort_keys": True}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

    assert stream_class == PrettyStream
    assert stream_kwargs[
        'chunk_size'] == PrettyStream.CHUNK_SIZE
    assert stream_kwargs[
        'conversion'] == Conversion()
    assert stream_kwargs[
        'format_options'] == {"sort_keys": True}
    assert stream_kwargs[
        'formatting'].env == env

# Generated at 2022-06-12 00:17:37.830145
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.processing import Conversion, Formatting

# Generated at 2022-06-12 00:17:49.117864
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class MyEnv:
        stdout_isatty = True
    env = MyEnv()

    class MyArgs:
        stream = True
        prettify = None
    args = MyArgs()
    (stream_class,stream_kwargs) = get_stream_type_and_kwargs(env,args)
    assert(PrettyStream == stream_class)
    assert(0 == len(stream_kwargs))

    args.stream = False
    args.prettify = 'all'
    (stream_class,stream_kwargs) = get_stream_type_and_kwargs(env,args)
    assert(BufferedPrettyStream == stream_class)
    assert(2 == len(stream_kwargs))
    assert('env' in stream_kwargs)
    assert('conversion' in stream_kwargs)
   

# Generated at 2022-06-12 00:17:58.632259
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class MockEnvironment:
        def __init__(self):
            self.stdout_isatty = False

    class MockArgs:
        def __init__(self):
            self.prettify = []
            self.stream = False

    env = MockEnvironment()
    args = MockArgs()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert isinstance(stream_class, RawStream)
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE}

    args.prettify = ['colors']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert isinstance(stream_class, BufferedPrettyStream)
    assert 'conversion' in stream_kwargs

# Generated at 2022-06-12 00:18:08.984065
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace(prettify=["group1","group2"])

# Generated at 2022-06-12 00:18:17.063673
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class FakeOutFile(object):
        def __init__(self, encoding):
            self.encoding = encoding

        def write(self, data):
            print(data)

        def flush(self):
            pass

        @property
        def buffer(self):
            return self

    outfile = FakeOutFile('ascii')
    write_stream_with_colors_win_py3(
        FakeStream([b'\x1b[31m', b'\x1b[32m', b'']),
        outfile,
        False
    )

# Generated at 2022-06-12 00:18:24.608289
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(
        stream=False,
        prettify=True,
        style='none',
        json=False,
        format_options='X',
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert type(stream_class) is type
    assert len(stream_kwargs) == 2
    assert 'env' in stream_kwargs
    assert 'conversion' in stream_kwargs