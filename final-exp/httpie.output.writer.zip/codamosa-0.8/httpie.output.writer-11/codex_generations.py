

# Generated at 2022-06-12 00:09:18.889360
# Unit test for function write_message
def test_write_message():
    result = write_message(
        requests_message.requests.PreparedRequest,
        Environment().copy(),
        argparse.Namespace(),
        with_headers=True,
        with_body=True,
    )
    expected = print(result)
    assert expected == '\n\n'

# Generated at 2022-06-12 00:09:24.247388
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    # print (get_stream_type_and_kwargs(env, args))
    for i in range(4):
        for j in range(4):
            if i == 1:
                args.prettify = ['all']
                args.stream = True
                args.style = 'paraiso-dark'
                args.json = False
                args.format_options = ['']
            elif i == 2:
                args.prettify = ['all']
                args.stream = True
                args.style = 'paraiso-dark'
                args.json = False
                args.format_options = ['']
            elif i == 3:
                args.prettify = ['all']
                args.stream = False

# Generated at 2022-06-12 00:09:35.473661
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import sys
    import contextlib
    sys.stdout = io.TextIOWrapper(io.BytesIO(), sys.stdout.encoding)
    sys.stderr = io.TextIOWrapper(io.BytesIO(), sys.stderr.encoding)

    class Sysargs:
        def __init__(self):
            self.traceback = False
            self.debug = False
            self.stream = False
            self.prettify = False
            self.style = None
            self.json = False
            self.format_options = None

    class Sysenv:
        def __init__(self):
            self.is_windows = False
            self.stdout_isatty = True

# Generated at 2022-06-12 00:09:45.654241
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import sys
    import io
    import pytest
    import tempfile
    import requests

    file_name = 'test.txt'
    file_path = os.path.join(tempfile.gettempdir(), file_name)
    url = 'https://httpbin.org/json'
    data = {
        'A': 'a',
        'B': 'b'
    }
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    os.environ.pop('HTTPIE_TEST_TOKEN', None)

    for status in (200, 201, 202, 204, 400, 401, 403, 404, 405, 500, 502, 503):
        url_path = url + '/' + str(status)
        requests_request = requests.Request

# Generated at 2022-06-12 00:09:57.427395
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    stream = PrettyStream(
        msg=HTTPResponse(
            requests.Response()
        ),
        env=Environment(),
        with_headers=True,
        with_body=True,
        chunk_size=4,
        conversion=Conversion(),
        formatting=Formatting(
            env=Environment(),
            groups=['all'],
            color_scheme='par',
            explicit_json=False,
            # This is a test case so we can use a fake format_options.
            format_options={}
        )
    )
    output = StringIO()
    write_stream_with_colors_win_py3(stream, output, flush=False)

# Generated at 2022-06-12 00:10:03.183930
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO

    outfile = StringIO()
    stream = [b'\x1b[0m\x1b[1m']
    write_stream_with_colors_win_py3(stream=stream, outfile=outfile, flush=False)

    assert outfile.getvalue() == '\x1b[0m\x1b[1m'

# Generated at 2022-06-12 00:10:16.122180
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    env = Environment()
    args = argparse.Namespace()
    env.stdout_isatty = False
    args.prettify = None
    assert get_stream_type_and_kwargs(env, args) == (RawStream,
                                        {'chunk_size': RawStream.CHUNK_SIZE})
    env.stdout_isatty = True
    args.prettify = ["all"]
    args.stream = False

# Generated at 2022-06-12 00:10:26.423809
# Unit test for function write_stream_with_colors_win_py3

# Generated at 2022-06-12 00:10:34.140732
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import PrettyStream
    class Outfile(io.TextIOWrapper):
        def __init__(self, stream):
            super().__init__(stream, encoding='utf-8')

    outfile = Outfile(io.BytesIO())
    stream = PrettyStream('test')
    write_stream_with_colors_win_py3(stream, outfile, flush=False)
    outfile.seek(0)
    assert outfile.read() == 'test'

# Generated at 2022-06-12 00:10:43.175883
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    response = requests.Response()
    response.status_code = 200
    response.encoding = 'utf-8'
    response.headers = {'Content-type': 'application/json'}
    response._content = b'testing'
    args = argparse.Namespace()
    args.stream = False
    env = Environment()
    env.stdout = StringIO()
    env.stdout_isatty = True
    with_headers = True
    with_body = True
    write_message(response, env, args, with_headers, with_body)
    assert env.stdout.getvalue() == 'HTTP/1.1 200 OK\r\nContent-type: application/json\r\n\r\ntesting\n\n'
    args.stream = True
    env.stdout = StringIO()
   

# Generated at 2022-06-12 00:10:50.437127
# Unit test for function write_message
def test_write_message():
    import requests
    resp = requests.Response()
    write_message(resp)

# Generated at 2022-06-12 00:10:59.879268
# Unit test for function write_stream
def test_write_stream():
    from httpie import ExitStatus
    from httpie.compat import is_windows
    from httpie.output.streams import PrettyStream
    stream = PrettyStream(
        msg=HTTPRequest(headers={
            'content-type': 'application/json',
            'content-disposition': 'attachment',
        }),
        with_headers=True,
        with_body=True,
        env=Environment(),
        conversion=Conversion(),
        formatting=Formatting(
            env=Environment(),
            groups=['all'],
            color_scheme='alice',
            explicit_json=False,
            format_options={},
        )
    )
    if is_windows:
        write_stream_with_colors_win_py3(stream, sys.stdout, True)

# Generated at 2022-06-12 00:11:11.434424
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(
        stream=True,
        prettify=True,
        style='test',
        json=True,
        format_options=[],
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class is PrettyStream
    assert stream_kwargs == {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=args.prettify,
            color_scheme=args.style,
            explicit_json=args.json,
            format_options=args.format_options,
        )
    }



# Generated at 2022-06-12 00:11:12.083458
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-12 00:11:19.096490
# Unit test for function write_stream
def test_write_stream():
    class dummy_file:
        def __init__(self):
            self.buffer = []
        def write(self, chunk):
            self.buffer.append(chunk)
    buf = dummy_file()
    class dummy_stream:
        def __init__(self):
            self.chunks = [b'first', b'second', b'third']
        def __iter__(self):
            return self
        def __next__(self):
            if self.chunks == []:
                raise StopIteration
            return self.chunks.pop()
    stream = dummy_stream()

    write_stream(stream=stream, outfile=buf, flush=False)
    assert buf.buffer == [b'first', b'second', b'third']


# Generated at 2022-06-12 00:11:23.759484
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class env:
        stdout_isatty = True
        stderr_isatty = True

    class args:
        prettify = None
        style = 'solarized'
        json = True
        stream = False
        format_options = {'body', 'headers'}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    stream_class == BufferedPrettyStream

# Generated at 2022-06-12 00:11:34.183079
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from tempfile import TemporaryFile
    from httpie import ExitStatus

    with TemporaryFile('w+') as tmpf:
        tmpf.write('\n')
        tmpf.seek(0)
        write_stream_with_colors_win_py3(
            [
                b'\x1b[38;2;100;0;0mtest1\x1b[0m\n',
                b'\x1b[38;2;0;100;0mtest2\x1b[0m\n',
                b'\x1b[38;2;0;0;100mtest3\x1b[0m\n',
            ],
            tmpf,
            True
        )
        tmpf.seek(0)

# Generated at 2022-06-12 00:11:40.369881
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream as expect_class
    env = Environment()
    args = argparse.Namespace(
        json=False,
        stream=False,
        prettify=['colors'],
        style='par',
        format_options=[],
    )
    (selected_class, kwargs) = get_stream_type_and_kwargs(env, args)
    assert(selected_class == expect_class)



# Generated at 2022-06-12 00:11:50.684753
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    # Outputting ANSI color codes when stdout is not a terminal
    # causes an exception.
    s = "some text"
    encoding = "ascii"
    mock_outfile = mock.MagicMock()
    type(mock_outfile).encoding = mock.PropertyMock(return_value=encoding)

    s_ansi = "\x1b[0m\x1b[1msome text\x1b[0m\x1b[1m"
    chunks = [s.encode(encoding), s_ansi.encode(encoding), b"\x1b[0m"]
    chunks_iter = iter(chunks)
    stream_mock = mock.MagicMock()
    type(stream_mock).__iter__.return_value = chunks_iter


# Generated at 2022-06-12 00:12:01.375697
# Unit test for function write_stream
def test_write_stream():
    try:
        f = open("TestFile.txt", "r")
    except IOError:
        print("\nError: File not found or path is incorrect")
    except:
        print("\nError: Could not read file")
    else:
        stream = build_output_stream_for_message(
            args="TestFile.txt",
            env="",
            requests_message="",
            with_headers="",
            with_body=""
        )
        write_stream(
            stream,
            f,
            flush="",
        )
    f.close()
    f = open("TestFile.txt", "r")
    for line in f:
        print("This is the line inside the test file: ", line)
    f.close()


# Generated at 2022-06-12 00:12:18.614826
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    env = Environment(
            stdout_isatty=True,
            colors = 256,
            stdout_encoding = 'utf-8'
    )
    args = argparse.Namespace(
        prettify=['all'],
        style='paraiso-dark',
        format_options={'pretty': True},
        json=False,
        stream=False,
    )
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type == BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__ == Conversion
    assert stream_kwargs['formatting'].__class__ == Formatting
    assert stream_kwargs['formatting'].groups

# Generated at 2022-06-12 00:12:28.655878
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=False)
    args = argparse.Namespace(prettify=False, stream=False)
    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': 2**20})

    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=False, stream=False)
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=False, stream=True)
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})



# Generated at 2022-06-12 00:12:33.060147
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = RawStream(
        HTTPRequest(
            method='GET',
            url='http://example.org',
            headers={},
            auth=None,
            data=None,
        ),
        with_headers=True,
        with_body=True,
    )
    outfile = io.StringIO()

    write_stream_with_colors_win_py3(stream, outfile, False)


# Generated at 2022-06-12 00:12:41.270164
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.processing import Conversion, Formatting
    parser = ArgumentParser()
    args = parser.parse_args(args=[])
    args.style = 'solarized'
    args.stream = False
    args.prettify = ('all', )
    args.json = False
    args.format_options = {'colors': 'true'}

# Generated at 2022-06-12 00:12:51.780910
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    with open('tmp', 'wb') as tmp_file:
        write_stream_with_colors_win_py3(
            stream=(
                b'\x1b[1m\x1b[38;5;68m\x1b[38;5;68mGET ',
                b'/test\x1b[0m\n',
            ),
            outfile=tmp_file,
            flush=True
        )

    with open('tmp', 'rb') as tmp_file:
        assert tmp_file.read() == (
            b'\x1b[1m\x1b[38;5;68m\x1b[38;5;68mGET /test\x1b[0m\n')

# Generated at 2022-06-12 00:13:02.427401
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from cStringIO import StringIO

    from httpie.compat import is_py3, is_windows
    from httpie.output.streams import PrettyStream

    if not is_py3 or not is_windows:
        return

    class DummyPrettyStream(PrettyStream):
        def __iter__(self):
            for _ in range(3):
                yield b'\x1b[34m' + 'foo'.encode('ascii') + b'\x1b[39m\n' \
                      + b'bar\n'

    out = StringIO()
    write_stream_with_colors_win_py3(
        stream=DummyPrettyStream(msg=None, with_headers=False, with_body=True),
        outfile=out,
        flush=False
    )

# Generated at 2022-06-12 00:13:13.846681
# Unit test for function write_message
def test_write_message():
    import sys
    import datetime
    import requests
    import argparse
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.config import Config
    from httpie.output.formatters.default import DefaultJSONFormatter
    import json
    import os

    url = 'http://httpbin.org/get'
    args = parser.parse_args([url])

# Generated at 2022-06-12 00:13:24.599033
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie import __version__
    from httpie.cli.argtypes import KeyValueArg
    from httpie.client import JSON_ACCEPT
    from httpie.compat import PY27, stdout_isatty, isatty

# Generated at 2022-06-12 00:13:37.059030
# Unit test for function write_stream
def test_write_stream():
    """Check the function for write in stream."""
    # Given
    class Object:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    buffer = b'A' * 80 + b'B' * 80
    stream = Object(__next__=lambda: buffer)
    outfile = Object(write=lambda data: len(data))

    # When
    write_stream(stream, outfile, flush=False)

    # Then
    assert len(buffer) == len(outfile.write.call_args_list[0].args[0])
    # When
    write_stream(stream, outfile, flush=True)
    # Then

# Generated at 2022-06-12 00:13:38.931947
# Unit test for function write_stream
def test_write_stream():
    stream = EncodedStream([b'ab'])

# Generated at 2022-06-12 00:14:01.672354
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import BufferedPrettyStream, PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import EncodedStream, RawStream
    from tests.httpbin import HTTPBIN_SERVER

# Generated at 2022-06-12 00:14:07.696418
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import cli
    from httpie.config import Config
    from httpie.output.streams import PlainStream
    from httpie.context import Environment
    from httpie.input import ParseError
    from httpie.models import Request, Response

    args = cli.parser.parse_args(args=[])
    config = Config(args)
    env = Environment(stdin=sys.stdin,
                      stdout=sys.stdout,
                      stderr=sys.stderr,
                      vars=cli.EnvironmentDefaults(),
                      config=config)
    request = Request('GET', 'http://localhost:8080/')
    response = Response.from_request(request, 'http')

    # test with_headers = False and with_headers = True
    with_headers = False
    with_body = True


# Generated at 2022-06-12 00:14:14.253937
# Unit test for function write_stream
def test_write_stream():
    stream = PrettyStream(
        msg=HTTPResponse({}),
        with_headers=True,
        with_body=True,
        env="",
        conversion=Conversion(),
        formatting=Formatting(
            env="",
            groups={},
            color_scheme="",
            explicit_json=False,
            format_options={},
        ),
    )
    for chunk in stream:
        print(chunk)



# Generated at 2022-06-12 00:14:14.842928
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-12 00:14:25.087415
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, RawStream, EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    requests_message = requests.PreparedRequest()
    env = Environment()
    env.stdout_isatty = True
    args = Namespace(
        stream=True,
        prettify=['colors'],
        style='borland',
        json=False,
        format_options={},
    )
    assert isinstance(get_stream_type_and_kwargs(env, args)[0], PrettyStream)

    args = Namespace(
        stream=False,
        prettify=['colors'],
        style='borland',
        json=False,
        format_options={},
    )

# Generated at 2022-06-12 00:14:28.006464
# Unit test for function write_stream
def test_write_stream():
    with pytest.raises(IOError):
        write_stream(
            stream=None,
            outfile=None,
            flush=None
        )

# Generated at 2022-06-12 00:14:37.375766
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from . import utils
    args = utils.Namespace(prettify=['colors'], stream=False)
    env = Environment(stdout_isatty=False)
    p = requests.models.PreparedRequest(method='GET', url='https://httpbin.org/')
    r = requests.models.Response()
    r.status_code = 200
    r.encoding = 'utf-8'
    r.url = 'https://httpbin.org/'
    for s in build_output_stream_for_message(
        args=args, env=env, requests_message=p, with_headers=True, with_body=False
    ):
        pass

# Generated at 2022-06-12 00:14:51.186830
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        stdout_isatty=False,
        stdin_isatty=False,
        is_windows=False,
        colors=256,
        stdout_encoding='UTF-8',
        stdin_encoding='UTF-8',
    )
    args = argparse.Namespace(
        style='default',
        download=False,
        prettify='all',
        redirect=True,
        traceback=False,
        stream=False,
        json=False,
        bodies='all'
    )
    assert('RawStream', {'chunk_size': 16384}) == get_stream_type_and_kwargs(env, args)
    args.stream = True

# Generated at 2022-06-12 00:15:00.050593
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    import sys
    import io
    import subprocess
    import pytest
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    # Test with pretty
    def make_request():
        import requests
        resp = requests.get('https://jsonplaceholder.typicode.com/posts/1')
        return resp

    resp = make_request()
    out = io.StringIO()
    env = Environment(
        stdin=sys.stdin,
        stdout=out,
        stderr=sys.stderr,
        is_windows=(subprocess.mswindows or sys.platform == 'cygwin')
    )


# Generated at 2022-06-12 00:15:10.501057
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie import env
    import argparse
    from httpie.output.streams import PrettyStream, EncodedStream, RawStream

    env = env.Environment()
    req = argparse.Namespace()
    req.prettify = 'all'
    req.stream = False
    req.style = 'default'
    req.json = False
    req.format_options = {}
    req.prettify = 'all'

# Generated at 2022-06-12 00:15:30.952822
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import mock
    import requests
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from argparse import Namespace
    from httpie.cli import default_options
    from functools import partial

    args = Namespace(**default_options)
    args.stdin_isatty = False
    args.follow = False
    env = Environment(args)
    env.stderr = mock.Mock()
    env.stdout = mock.Mock()
    env.stdout_isatty = True
    with mock.patch('httpie.output.streams.RawStream.CHUNK_SIZE', new=2):
        response = requests.Response()
        response.request = requests.Request()
        response._content = b'abcdefgh'
        response.status_code = 200

# Generated at 2022-06-12 00:15:41.696618
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from .context import Environment
    from .colors import COLOR_NONE, COLOR_WIN_ANSI

    env = Environment(
        stdout_isatty=True,
        stdout_bytes_written=0,
        color_mode=COLOR_WIN_ANSI,
    )

    args1 = argparse.Namespace(
        prettify=[],
        stream=True,
        style='default',
        json=False,
        format_options=[],
    )
    stream_class1, stream_kwargs1 = get_stream_type_and_kwargs(
        env=env,
        args=args1
    )
    assert stream_class1.__name__ == 'BufferedPrettyStream'

# Generated at 2022-06-12 00:15:52.323844
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test pretty stream
    env = Environment(
        stdout_isatty=True,
        stderr_isatty=False,
        stdin_isatty=False,
        stdout_encoding='UTF-8',
        stdout_raw=False,
        stdin=None,
        stdin_raw=False,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    args = argparse.Namespace(
        style='solarized',
        prettify='colors, format',
        stream=True,
        json=False,
        format_options={},
    )

# Generated at 2022-06-12 00:16:00.930156
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class _StdoutMock:
        def __init__(self, bufsize):
            self.buf = StringIO()
            self.encoding = 'utf-8'

        def isatty(self):
            return True

        def write(self, s):
            self.buf.write(s)

        def flush(self):
            pass

    class _StderrMock:
        def __init__(self, bufsize):
            self.buf = StringIO()

        def isatty(self):
            return True

        def write(self, s):
            self.buf.write(s)

        def flush(self):
            pass


# Generated at 2022-06-12 00:16:09.309617
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from . import utils
    from . import httpbin
    from httpie.client import ASYNC_OK
    args = utils.TestEnvironment().get_args()
    env = Environment(args, stream=True)
    data = b'hello world'
    kwargs = {'stream': True, 'data': data}
    r = httpbin.get(**kwargs)
    write_message(r.request, env, args, with_headers=True, with_body=True)
    assert r.request.body == data
    assert ASYNC_OK in r.prepared.body

# Generated at 2022-06-12 00:16:19.365649
# Unit test for function write_stream
def test_write_stream():
    '''
    This test is to test the following conditions:
        1. outfile is buffered and not isatty
        2. outfile is buffered and isatty
        3. outfile is not buffered
    '''

    # 1. outfile is buffered and not isatty
    # Create a response object
    response = requests.Response()
    response._content = b'Hello'
    response.status_code = 200
    response.headers = {}
    args = argparse.Namespace()
    args.prettify = []
    args.stream = False
    env = Environment()
    env.stdout_isatty = False
    env.stdout = io.BytesIO()

# Generated at 2022-06-12 00:16:23.077769
# Unit test for function write_stream
def test_write_stream():
    outbuf = io.BytesIO()
    write_stream(iter([b'hello ', b'world']), outbuf, flush=False)
    assert outbuf.getvalue() == b'hello world'



# Generated at 2022-06-12 00:16:33.087337
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Fake_stream:
        def __init__(self, items):
            self.items = items

        def __iter__(self):
            return iter(self.items)

        def __next__(self):
            return next(self.items)

    class Fake_stdout:
        def __init__(self, encoding='utf-8'):
            self.encoding = encoding

        def write(self, data):
            self.data = data

        def flush(self):
            pass


# Generated at 2022-06-12 00:16:38.177511
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(prettify=[], style=None, stream=True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert isinstance(stream_kwargs['env'], Environment)

# Generated at 2022-06-12 00:16:42.042431
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    message_class = {
            requests.PreparedRequest: HTTPRequest,
            requests.Response: HTTPResponse,
        }[type(requests.PreparedRequest)]
    msg = message_class(requests.PreparedRequest())
    assert isinstance(msg, HTTPRequest)

# Generated at 2022-06-12 00:17:18.077510
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, EncodedStream, RawStream
    from httpie.context import Environment
    from httpie.output.formatters import DEFAULT_FORMAT_OPTIONS
    from tests.utils import DummyRequest

    env = Environment(
        stdout=io.BytesIO(),
        stdin=io.BytesIO(b'text'),
        stdin_isatty=True,
        stdout_isatty=True,
        stderr_isatty=False
    )

    args = argparse.Namespace(
        pretty='all',
        style='monokai',
        stream=False,
        json=False,
        format_options=DEFAULT_FORMAT_OPTIONS,
        headers=True,
        body=False,
    )

    stream_class, stream_

# Generated at 2022-06-12 00:17:27.898549
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Unit test for function get_stream_type_and_kwargs
    from httpie.context import Environment, EnvironmentBase

    # No-TTY, no-prettify
    class Env(EnvironmentBase):
        stdout_isatty = False
        stdout_bytes_writing_enabled = True
        is_windows = True
        stdin_isatty = True

    args = argparse.Namespace(prettify=False, stream=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(Env(), args)
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE

    args = argparse.Namespace(prettify=False, stream=True)
    stream_class, stream_kwargs = get

# Generated at 2022-06-12 00:17:38.787562
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace(style='lorem', stdout_isatty=True,
                              stream=False, prettify=['colors'], debug=False,
                              traceback=False)
    from requests import PreparedRequest, Response
    prepared = PreparedRequest()
    prepared.url = 'http://lorem.com'
    prepared.headers = {'a': 'b'}
    prepared.body = 'c'
    result = build_output_stream_for_message(
        env=env,
        args=args,
        requests_message=prepared,
        with_body=True,
        with_headers=True
    )
    import pprint

# Generated at 2022-06-12 00:17:49.353975
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    class FakeColorStream(BaseStream):
        def __init__(self, string_with_color):
            self.string_with_color = string_with_color

        def __iter__(self):
            yield self.string_with_color.encode()

    out_str = StringIO()
    string_with_color = '\x1b[39m\n'
    write_stream_with_colors_win_py3(
        stream=FakeColorStream(string_with_color),
        outfile=out_str,
        flush=True,
    )
    out_str.seek(0)
    assert out_str.read() == string_with_color.encode()

# Generated at 2022-06-12 00:17:56.110345
# Unit test for function write_stream
def test_write_stream():
    # Dummy stream is a generator that will return all the values in messages when called, and then nothing else
    def dummy_stream():
        for message in messages:
            yield message

    # Test all values in messages show up when writing to a file, and that they're on a new line
    f = open("test_file.txt", "w")
    write_stream(dummy_stream(), f, False)
    f.close()
    f = open("test_file.txt", "r")
    file_contents = f.read()
    for message in messages:
        if message not in file_contents:
            raise Exception("Write_stream does not correctly write to a file")
    f.close()
    os.remove("test_file.txt")

    # Test all values in messages show up when writing to stdout, and that they're

# Generated at 2022-06-12 00:18:01.842094
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Unit test for function write_stream_with_colors_win_py3
    """
    # arrange
    stream = [b'abc', b'\x1b[0m']
    outfile = sys.stdout
    flush = True

    # act
    write_stream_with_colors_win_py3(stream, outfile, flush)

# Generated at 2022-06-12 00:18:11.442129
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    class outfile:
        def __init__(self, encoding):
            self.encoding = encoding
            self.buffer = None

    class Buffer:
        def __init__(self):
            self.data = b""

        def write(self, chunk):
            self.data += chunk

    expected = b'\x1b[42m\x1b[97mfoo\x1b[0m\n\x1b[43m\x1b[90mbar\x1b[0m\n'

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(
            prettify=["colors"]
        )
    )

# Generated at 2022-06-12 00:18:15.398221
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    """Test get_stream_type_and_kwargs"""
    from httpie import __version__
    from httpie.config import __prog__
    from httpie.core import main as httpie
    from httpie import ExitStatus
    from httpie.core import main_impl
    from httpie.context import Environment, TermLevel
    from httpie import __version__
    from httpie.config import __prog__
    from httpie.core import main as httpie
    from httpie import ExitStatus
    from httpie.core import main_impl
    from httpie.context import Environment, TermLevel
    from httpie import __version__
    from httpie.config import __prog__
    from httpie.core import main as httpie
    from httpie import ExitStatus
    from httpie.core import main_impl

# Generated at 2022-06-12 00:18:20.836542
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace(prettify={}, style=None, stream=False,
                              format_options={})
    stream_type,_ = get_stream_type_and_kwargs(env, args)
    assert stream_type is BufferedPrettyStream

    args = argparse.Namespace(prettify={}, style=None, stream=True,
                              format_options={})
    stream_type,_ = get_stream_type_and_kwargs(env, args)
    assert stream_type is PrettyStream

    env.stdout_isatty = False
    stream_type,_ = get_stream_type_and_kwargs(env, args)
    assert stream_type is RawStream

# Generated at 2022-06-12 00:18:29.766017
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Tests that functions `write_stream` and `write_stream_with_colors_win_py3`
    return the same thing.
    """
    from io import StringIO
    from .streams import PrettyStream

    outfile = StringIO()
    stream_kwargs = {
        'env': Environment(stdout_isatty=True, is_windows=True),
        'conversion': Conversion(),
        'formatting': Formatting(
            env=Environment(stdout_isatty=True, is_windows=True),
            groups=['colors'],
            color_scheme='space',
            explicit_json=False,
            format_options={'colors': 'on'}
        )
    }
