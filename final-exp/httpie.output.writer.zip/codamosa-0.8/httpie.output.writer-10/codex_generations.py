

# Generated at 2022-06-12 00:09:16.342785
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    response = HTTPResponse(requests.PreparedRequest)
    write_message(response, env=Environment(), args=argparse.Namespace(), with_headers=True, with_body=True)

# Generated at 2022-06-12 00:09:26.061282
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
        TTYRawStream, TTYPrettyStream,
    )
    args = argparse.Namespace(
        prettify=['colors'],
        stream=True,
        style='paraiso-dark',
        json=False,
        format_options=[],
    )
    env = Environment()
    env.stdout_isatty = True
    assert get_stream_type_and_kwargs(env, args)[0] == TTYPrettyStream
    env.stdout_isatty = False
    assert get_stream_type_and_kwargs(env, args)[0] == PrettyStream
    args.stream = False

# Generated at 2022-06-12 00:09:38.112953
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    msg = {"status":"OK","message": [{"id":1,"first_name":"Kyunam","last_name":"Sim","age":28,"gender":"male","email":"ksim0@naver.com"}]}
    m = HTTPResponse(msg)
    m.headers = {"content-type": "application/json"}
    m.status_code = 200

    req = HTTPRequest(m)
    req.url= 'http://localhost:5000/api/v1.0/test'
    req.headers = {"content-type": "application/json"}
    req.method = 'GET'

    # Conversion
    conversion = Conversion()
    conversion.cast(m)
    conversion.cast(req)

    # Formatting
    formatting = Formatting()
    formatting.format(m)
    formatting.format(req)

   

# Generated at 2022-06-12 00:09:46.868249
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import mock
    from httpie.output.streams import Stream
    from httpie.cli import parser

    args = parser.parse_args()
    env = Environment([])(args=args)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    stream_kwargs["formatting"].colors["body"] = "blue"

    mock_self = mock.MagicMock(name="self", spec=Stream)
    mock_self.formatting = stream_kwargs['formatting']
    mock_self.env = stream_kwargs['env']

    class MockStream(Stream):
        def __init__(self, **kwargs):
            self.env = stream_kwargs['env']

# Generated at 2022-06-12 00:09:59.032062
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream

    import requests

    args = argparse.Namespace()
    env = Environment()
    requests_message1 = requests.PreparedRequest()
    message_class = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }[type(requests_message1)]
    # Normal test case
    with patch('httpie.output.streams.PrettyStream') as mock_stream:
        mock_stream.return_value.__iter__.return_value = [1, 2, 3]
        result = build_output_stream_for_message(
            args=args,
            env=env,
            requests_message=requests_message1,
            with_body=True,
            with_headers=True)

# Generated at 2022-06-12 00:10:07.420994
# Unit test for function write_message
def test_write_message():
    import StringIO
    import requests
    args = argparse.Namespace(body="ebody", headers={"my":"header"},
                              stream=True, style="mystyle",
                              traceback=True, format_options={'pygments_formatter_class': 'None'})
    env = Environment(stdout=StringIO.StringIO(), stderr=StringIO.StringIO(),
                      is_windows=False, is_windows_named_pipe=False,
                      stdout_isatty=False, stdin_isatty=True,
                      colors=256, encoding=None,
                      is_binary_stdin=False, is_binary_stdout=True,
                      is_binary_stderr=True)
    request = requests.PreparedRequest()
    request.method = 'method'

# Generated at 2022-06-12 00:10:16.007424
# Unit test for function write_message
def test_write_message():
    url = "https://www.google.com"
    r = requests.get(url)

    env = Environment(stdout=sys.stdout, stdin=sys.stdin,
                      stdout_isatty=True, stdin_isatty=True)
    args = argparse.Namespace(prettify=False, style=None, traceback=None,
                              json=False, stream=False, debug=False,
                              style_save=False, style_save_all=False,
                              format_options={}, download=False)
    write_message(r, env, args)

# Generated at 2022-06-12 00:10:26.291160
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-12 00:10:37.100057
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class A:
        def __init__(self, x):
            self.x = x
        def json(self):
            return self.x
    import json
    import traceback
    from io import StringIO
    from httpie.cli.argtypes import KeyValue, KeyValueArgType
    from httpie.compat import is_windows
    from httpie.output.streams import BaseStream
    from httpie.output import streams
    import httpie
    def test(x):
        class Stdout:
            def __init__(self, x=None):
                if x:
                    self.x = x
                else:
                    self.x = StringIO()
                self.isatty = True
        class Stderr:
            def __init__(self, x=None):
                if x:
                    self.x

# Generated at 2022-06-12 00:10:45.121056
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import unittest
    import unittest.mock

    class Stream:
        def __iter__(self):
            yield b'\x1b[0m\x1b[0m'
            yield b'\x1b[1m\x1b[35m'
            yield b'abc'
            yield b'\x1b[0m'
            yield b'\x1b[31m'
            yield b'def'
            yield b'\x1b[0m'
            yield b'ghi'

    outfile = unittest.mock.Mock(
        **{
            'encoding': 'utf8',
            'buffer': unittest.mock.Mock(spec=io.BufferedIOBase)
        }
    )


# Generated at 2022-06-12 00:11:00.146790
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(
            stdin=io.BytesIO(),
            stdout=io.BytesIO(),
            stdout_isatty=True),
        args=argparse.Namespace(prettify=['colors'], style='solarized'),
    )
    stream_kwargs['with_body'] = True
    stream_kwargs['with_headers'] = True
    stream_kwargs['msg'] = HTTPRequest(
        requests.PreparedRequest(),
    )

    output_stream = stream_class(**stream_kwargs)
    output_stream.formatting.color_mode = '256'


# Generated at 2022-06-12 00:11:10.818536
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Only works on Windows machine with Python 3.
    """
    if sys.platform != 'win32':
        print('Only works on Windows machine with Python 3.')
        return
    if sys.version_info < (3, 0):
        print('Only works on Windows machine with Python 3.')
        return
    stream = [b'\x1b[1mHello world!\x1b[0m']
    out_file = sys.stdout.buffer
    flush = False
    write_stream_with_colors_win_py3(stream, out_file, flush)


if __name__ == '__main__':
    test_write_stream_with_colors_win_py3()

# Generated at 2022-06-12 00:11:18.062775
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    env = Environment()
    class response_class(requests.Response):
        def is_permanent_redirect(self):
            return False

    requests_message = response_class()
    requests_message.request = requests.PreparedRequest()
    requests_message.url = 'http://httpie.org/'
    requests_message.request.method = 'GET'
    requests_message.request.headers['User-Agent'] = 'Mozilla/5.0'
    requests_message.request.headers['Accept'] = '*/*'
    requests_message.request.body = "hello"
    requests_message.request.encoding = "utf-8"
    requests_message.status_code = 200
    requests_message.reason = 'OK'

# Generated at 2022-06-12 00:11:28.645432
# Unit test for function write_stream
def test_write_stream():
    from tempfile import TemporaryFile
    from io import BytesIO
    from random import random
    import os
    import os.path
    from textwrap import dedent

    from . import utils


    def test_file_like_object(outfile):
        tmpfile = TemporaryFile()
        origin_file_size = os.path.getsize(tmpfile.name)
        for _ in range(1000):
            write_stream(stream=utils.random_bytes_stream(),
                         outfile=outfile,
                         flush=False)
        final_file_size = os.path.getsize(tmpfile.name)
        assert origin_file_size < final_file_size


    def test_file_like_object_flush(outfile):
        tmpfile = TemporaryFile()

# Generated at 2022-06-12 00:11:35.960505
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli.parser import parser
    from httpie.core import main
    from httpie import ExitStatus
    session = main(parser.parse_args(['GET', 'https://httpbin.org/headers']),)
    assert session.exit_status == ExitStatus.OK
    assert session.last_response.ok

    session = main(parser.parse_args(['GET', 'https://httpbin.org/headers']),)
    assert session.exit_status == ExitStatus.OK
    assert session.last_response.ok

# Generated at 2022-06-12 00:11:45.049404
# Unit test for function write_message
def test_write_message():
    import httpie
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.input import ParseError

    args = parser.parse_args(args=[
        '--stream',
        '--print=h',
        '--ignore-stdin',
        'https://httpbin.org/get?foo=bar&one=two'
    ])
    env = httpie.Environment(args, stdin=io.StringIO())
    requests_message = requests.get("https://httpbin.org/get?foo=bar&one=two")
    with_headers = True
    with_body = False
    output = write_message(requests_message, env, args, with_headers, with_body)
    assert output is None

# Generated at 2022-06-12 00:11:56.412603
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """Unit Test to check the output stream"""
    from httpie.cli import parser
    env = Environment()
    args = parser.parse_args(['--pretty=colors', '--stream'])
    class HttpMessage():
        def __init__(self):
            self.body = b'{"ping":"pong"}'
            self.headers ={"Content-Type": "application/json"}
            self.is_body_upload_chunk = False
        def get_body(self):
            return b'{"ping":"pong"}'
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    message_class = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }

# Generated at 2022-06-12 00:12:05.339731
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.output.streams import (
        EncodedStream, BufferedPrettyStream, PrettyStream,RawStream
    )
    env = Environment(True,None)
    args = parser.parse_args(["https://httpbin.org/get"])

    assert get_stream_type_and_kwargs(env,args)[0] == EncodedStream
    env = Environment(False,None)
    args = parser.parse_args(["https://httpbin.org/get"])

    assert get_stream_type_and_kwargs(env,args)[0] == EncodedStream
    env = Environment(False,None)
    args = parser.parse_args(["https://httpbin.org/get","--pretty"])

    assert get_stream_

# Generated at 2022-06-12 00:12:15.925739
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env1 = Environment()
    env2 = Environment()
    env2.stdout_isatty = False
    args1 = argparse.Namespace()
    args2 = argparse.Namespace()
    args2.prettify = ''
    args3 = argparse.Namespace()
    args3.prettify = 'h'
    args3.style = ''
    args3.json = False
    args3.stream = False
    get_stream_type_and_kwargs(env2, args2)
    get_stream_type_and_kwargs(env1, args1)
    get_stream_type_and_kwargs(env2, args2)
    get_stream_type_and_kwargs(env1, args3)

# Generated at 2022-06-12 00:12:26.263275
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import mock
    # Test first write_stream()
    from io import BytesIO
    from io import StringIO
    from httpie.output.streams import BaseStream

    def stream(chunk_size=1):
        for i in [1, 2, 3, 4, 5]:
            if i == 5:
                yield b''
            else:
                yield str(i).encode()

    args = mock.MagicMock()
    args.prettify = []
    args.stream = False
    args.format_options = {}
    args.style = 'default'

    env = mock.MagicMock()
    env.stdout = StringIO()
    env.stdout_isatty = True
    env.stdin = BytesIO(b'abc')
    env.stdin_isatty = True
   

# Generated at 2022-06-12 00:12:49.261435
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()

    args = argparse.Namespace()
    args.prettify = None
    args.stream = False

    result = get_stream_type_and_kwargs(env, args)
    assert result == (EncodedStream, {'env': env})

    args = argparse.Namespace()
    args.prettify = 'all'
    args.stream = False

    result = get_stream_type_and_kwargs(env, args)
    assert result == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(),
      'formatting': Formatting(env=env, groups='all', color_scheme=None,
       explicit_json=False, format_options=None)})

# Generated at 2022-06-12 00:12:59.710120
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.input import KeyValue, ParseError
    from httpie.models import HTTPRequest, HTTPResponse
    import requests
    import argparse
    import typing
    import io

    req = HTTPRequest(requests.Request('GET', 'http://foo'))
    resp = HTTPResponse(requests.Response())

    # args = argparse.Namespace(
    #     format=None,
    #     headers='',
    #     pretty='all',
    #     print=None,
    #     style='vanilla',
    #     verbose=False,
    # )
    args = {}
    # NOTE: `env.stdout` will in fact be `stderr` with `--download`
   

# Generated at 2022-06-12 00:13:07.515521
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test 1:  pretty and stream set
    args = argparse.Namespace()
    env = Environment(
        stdin_isatty=False,
        stdout_isatty=False,
        is_windows=False,
    )
    args.prettify = ['all']
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    stream_class.__name__ == PrettyStream.__name__
    for k,v in stream_kwargs.items():
        assert (k,v) == ('env',env)

    # Test 2:  pretty and stream not set
    args = argparse.Namespace()

# Generated at 2022-06-12 00:13:11.985421
# Unit test for function write_stream
def test_write_stream():
    """
    >>> write_stream([b'abc', b'def'], b'abcdef')
    """
    import io
    stream = ['abc', b'def']
    outfile = io.BytesIO()
    write_stream(stream, outfile, True)
    outfile.getvalue() == b'abcdef'

# Generated at 2022-06-12 00:13:23.256032
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from unittest.mock import patch
    from httpie import env
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream

    env.stdout_isatty = True
    args = argparse.Namespace(prettify=False, stream=False, style=None)
    assert (EncodedStream, {'env': env}) == get_stream_type_and_kwargs(env, args)

    env.stdout_isatty = False
    args = argparse.Namespace(prettify=False, stream=False, style=None)
    assert (RawStream, {'chunk_size': RawStream.CHUNK_SIZE}) == get_stream_type_and_kwargs(env, args)

    env.stdout_isatty = True

# Generated at 2022-06-12 00:13:29.427509
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli.parser import parser
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.context import Environment
    from httpie.models import HTTPResponse
    from httpie.models import HTTPRequest
    
    env=Environment()
    env.stdout_isatty=False
    args=parser.parse_args(['-p'])
    with_headers=False
    with_body=False
    uri='https://www.baidu.com'
    requests_response=requests.get(uri)

# Generated at 2022-06-12 00:13:41.462499
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    outfile = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=iter([b'\x1b[1mfoo\x1b[0m', b'bar']),
        outfile=outfile,
        flush=False)
    assert outfile.getvalue() == '\x1b[1mfoo\x1b[0mbar'

    outfile = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=iter([b'foo', b'bar']),
        outfile=outfile,
        flush=False)
    assert outfile.getvalue() == 'foobar'

# Generated at 2022-06-12 00:13:52.455741
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env_isatty = False
    env_filesize = None
    env_arguments = None
    prettify = False
    style = 'solarized-dark'
    stream = True
    json = False
    format_options = {}
    env = Environment(
        stdout_isatty=env_isatty,
        stdout_filesize=env_filesize,
        output_options=env_arguments,
    )

    args = argparse.Namespace(
        prettify=prettify,
        style=style,
        stream=stream,
        json=json,
        format_options=format_options,
    )

# Generated at 2022-06-12 00:13:56.977823
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    env = Environment(stdout_isatty=True, stdin_isatty=True)
    args = argparse.Namespace(prettify=None, stream=True, style='test')

    # Check the default raw stream
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE_BY_LINE

    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == RawStream

# Generated at 2022-06-12 00:14:05.298541
# Unit test for function write_message
def test_write_message():
    import httpie.output
    import httpie.cli.application

    class FakeEnv(object):
        stdout = None
        stderr = None
        stdin = None
        is_windows = False

        def __init__(self):
            self.arguments = httpie.cli.application.Application().default_values

    class FakeResponse(object):
        status_code = 200

        def __init__(self, body):
            self.text = body
            self.status_code = 200

    class FakeRequest(object):
        url = "https://github.com/jakubroztocil/httpie"
        headers = {}

        def __init__(self):
            self.headers = {}

    class FakePipe(object):
        def __init__(self):
            self.pipe_value = ''



# Generated at 2022-06-12 00:14:33.815309
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # test case 1
    env = Environment()
    args = argparse.Namespace()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)

# Generated at 2022-06-12 00:14:47.757661
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class FakeEnv:
        def __init__(self, stdout_isatty=True):
            self.stdout_isatty = stdout_isatty

    class FakeArgs:
        format_options = {}

    env = FakeEnv()
    args = FakeArgs()

    args.prettify = ['colors']
    assert get_stream_type_and_kwargs(env, args) == (
        PrettyStream,
        {'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(env=env, groups=['colors'], color_scheme=None, explicit_json=None, format_options={})}
    )

# Generated at 2022-06-12 00:14:58.019083
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.output.streams import PrettyStream

    requests_message = requests.PreparedRequest()

    assert isinstance(
        build_output_stream_for_message(
            args=argparse.Namespace(prettify=['all'], traceback=False),
            env=Environment(config={}),
            requests_message=requests_message,
            with_headers=True,
            with_body=True,
        ),
        PrettyStream
    )

    assert isinstance(
        build_output_stream_for_message(
            args=argparse.Namespace(prettify=None),
            env=Environment(config={}),
            requests_message=requests_message,
            with_headers=True,
            with_body=True,
        ),
        EncodedStream
    )

# Generated at 2022-06-12 00:15:09.002503
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class Class:
        def __init__(self, is_stdout_isatty = False, arg_prettify = False, arg_stream = False):
            self.stdout_isatty = is_stdout_isatty
            args_prettify = arg_prettify
            args_stream = arg_stream
        def get_is_stdout_isatty(self):
            return self.is_stdout_isatty
        def get_arg_prettify(self):
            return args_prettify
        def get_arg_stream(self):
            return args_stream

    class Env:
        def __init__(self, is_stdout_isatty = False, arg_prettify = False, arg_stream = False):
            self.stdout_isatty = is_

# Generated at 2022-06-12 00:15:16.124592
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(
            colors=True,
            style='default',
            stream=False,
            pretty='all'
        )
    )
    stream = b'\x1b[32mtest\x1b[0m'
    outfile = io.TextIOWrapper(io.BytesIO(), encoding='utf8')
    write_stream_with_colors_win_py3(stream, outfile, flush=False)
    assert outfile.getvalue() == '\x1b[32mtest\x1b[0m'
    outfile = io.TextIOWrapper(io.BytesIO(), encoding='utf8')
    write_stream_with_colors_win

# Generated at 2022-06-12 00:15:27.449859
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-12 00:15:39.511663
# Unit test for function write_message
def test_write_message():
    requests_prepared_request = b"requests.PreparedRequest"
    requests_response = b"requests.Response"
    env = Environment(
        stdout=b"STDOUT",
        stderr=b"STDERR",
        stdin=b"STDIN",
        stdin_isatty=True,
        stdout_isatty=True
    )
    args = argparse.Namespace(
        stream=True,
        debug = True,
        traceback = True
    )
    with_headers = True
    with_body = True
    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs["env"] == env
    assert stream_kwargs["conversion"] == Conversion()


# Generated at 2022-06-12 00:15:47.264345
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = ["\x1b[34mfirst\x1b[0m", "\x1b[34msecond\x1b[0m", "third", "fourth\n"]
    outfile = io.TextIOWrapper(io.BytesIO(), 'utf8', newline='')
    flush = False
    write_stream_with_colors_win_py3(stream, outfile, flush)
    assert outfile.getvalue() == '\x1b[34mfirst\x1b[0m\x1b[34msecond\x1b[0mthirdfourth\n'

# Generated at 2022-06-12 00:15:52.501474
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io
    sys.stdout = io.StringIO()
    stream = RawStream(b'\x1b[33m')
    write_stream_with_colors_win_py3(stream, sys.stdout, flush=False)
    assert sys.stdout.getvalue() == '\033[33m'
    sys.stdout.close()

# Generated at 2022-06-12 00:16:01.036034
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.output
    import platform

    print("This is a test for function build_output_stream_for_message()")
    print("You need to have httpie installed to test this function")

    def check_result(requests_message, env, args):
        stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
        message_class = {
            requests.PreparedRequest: HTTPRequest,
            requests.Response: HTTPResponse,
        }[type(requests_message)]
        yield from stream_class(
            msg=message_class(requests_message),
            with_headers=False,
            with_body=False,
            **stream_kwargs,
        )


# Generated at 2022-06-12 00:16:58.900363
# Unit test for function write_stream
def test_write_stream():
    #from httpie.output.streams import RawStream
    stream = RawStream(msg=HTTPRequest("GET", "http://localhost"))
    write_stream(stream, sys.stdout, False)
    stream = RawStream(msg=HTTPRequest("GET", "http://localhost", body='hello'))
    write_stream(stream, sys.stdout, False)

    stream = BufferedPrettyStream(HTTPRequest("GET", "http://localhost"))
    write_stream(stream, sys.stdout, False)

# Generated at 2022-06-12 00:16:59.854935
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # TODO: write test unit
    pass

# Generated at 2022-06-12 00:17:01.104272
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert get_data_from_function(build_output_stream_for_message)

# Generated at 2022-06-12 00:17:11.710261
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class TestEnvironment:
        def __init__(self, stdout_isatty, stderr_isatty):
            self.stdout_isatty = stdout_isatty
            self.stderr_isatty = stderr_isatty
            self.stdout = out
            self.stderr = err

    #Environment is not a tty
    out = 'out'
    err = 'err'
    env = TestEnvironment(stdout_isatty=False, stderr_isatty=False)
    args = argparse.Namespace(style='colored')
    ret = get_stream_type_and_kwargs(env=env, args=args)
    assert (ret[0] == RawStream)

# Generated at 2022-06-12 00:17:20.715001
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import argparse, sys
    from httpie.context import Environment
    #build a fake args
    args = argparse.Namespace()
    env = Environment()
    args.prettify = False
    args.stream = False
    args.style = "default"
    args.json = False
    args.format_options = [""]
    #test with raw stream
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs["chunk_size"] == RawStream.CHUNK_SIZE
    #test with pretty stream
    args.prettify = ["all"]
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream

# Generated at 2022-06-12 00:17:29.465926
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    class TestStream(object):

        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    def test_write_stream_with_colors_win_py3(chunks, encoding):
        class TestOutfile(object):
            encoding = encoding

            def __init__(self):
                self.buf = io.BytesIO()

            def write(self, chunk):
                self.buf.write(chunk.encode(encoding))

            def buffer(self):
                return self

        stream = TestStream(chunks)
        out = TestOutfile()
        write_stream_with_colors_win_py3(stream, out, False)
        return out.buf.getvalue().decode(encoding)

    chunks

# Generated at 2022-06-12 00:17:39.592283
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class TestStream(BaseStream):
        def __init__(self, encoding):
            self.encoding = encoding

        def __iter__(self):
            yield b'\x1b[0m'
            yield b'\x1b[0m'
            yield b'\x1b[0m'
            yield b'\x1b[0m'
            yield b'\x1b[91mnot encoded'
            yield b'\x1b[0m'
            yield b'\x1b[91mnot encoded'

    class TestStdio:
        encoding = 'utf-8'

        def __init__(self):
            self.buffer = io.BytesIO()
            self.buffer.write = self.buffer.write


# Generated at 2022-06-12 00:17:51.019389
# Unit test for function write_stream
def test_write_stream():
    if sys.version_info < (3, 0):
        raise unittest.SkipTest("test_write_stream does not support Python 2")
    from io import BytesIO
    bytes_io_file = BytesIO()    # an in-memory bytes file

    # Write a string and flush
    string = 'Hello World'
    write_stream_kwargs = {
        'stream': [string.encode('utf-8')],
        'outfile': bytes_io_file,
        'flush': False
    }

    write_stream(**write_stream_kwargs)
    assert bytes_io_file.getvalue().decode('utf-8') == string

    # Write another string, don't flush and check it's still in the buffer
    string = 'Bye World'

# Generated at 2022-06-12 00:17:57.113288
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class DummyStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks
            self.written = []

        def __iter__(self):
            return iter(self.chunks)

    class DummyOutfile(TextIO):
        def __init__(self, encoding):
            self.encoding = encoding
            self.written = []

        def write(self, chunk):
            self.written.append(chunk)

    def dummy_write_stream_with_colors_win_py3(
        stream: 'DummyStream',
        outfile: DummyOutfile,
        flush: bool
    ):
        write_stream_with_colors_win_py3(stream, outfile, flush)
        return outfile.written


# Generated at 2022-06-12 00:18:07.760516
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import py3_compat
    import mock
    from httpie.output.streams import BaseStream

    class MockEnv(object):
        stdout_isatty = True
        stdout = mock.Mock(encoding='utf-8')
        is_windows = True

    class MockStream(BaseStream):

        def __init__(self, *args, **kwargs):
            pass

        def __iter__(self):
            yield 'chunk1'
            yield u'chunk2'

    class MockArgs(object):
        prettify = []



# Generated at 2022-06-12 00:19:12.784567
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()

    # Test all combinations of stdout_isatty, prettify, stream

    args.prettify = None
    args.stream = False
    env.stdout_isatty = True
    stream_class_1, stream_kwargs_1 = get_stream_type_and_kwargs(env, args)
    assert stream_class_1 is BufferedPrettyStream
    assert stream_kwargs_1['chunk_size'] == BufferedPrettyStream.CHUNK_SIZE

    env.stdout_isatty = False
    stream_class_2, stream_kwargs_2 = get_stream_type_and_kwargs(env, args)
    assert stream_class_2 is RawStream