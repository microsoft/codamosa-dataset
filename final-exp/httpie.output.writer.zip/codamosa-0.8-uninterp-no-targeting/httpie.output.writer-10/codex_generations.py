

# Generated at 2022-06-21 14:24:10.851923
# Unit test for function write_message
def test_write_message():
    r = requests.Response()
    r.status_code = requests.codes.ok
    r.encoding = 'ascii'
    r.raw = io.BytesIO(b'Hello World!')
    r.url = 'https://httpbin.org/get'
    r.headers["DNT"] = "1 (Do Not Track Enabled)"
    r.headers["Content-Length"] = "13"
    r.headers["Host"] = "httpbin.org"
    r.headers["Content-Type"] = "text/html"
    env = Environment(stdout=sys.stderr)

    

# Generated at 2022-06-21 14:24:20.700593
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream

    # Strings of various lengths
    string = 'abcdefgh'
    short_string = 'abc'
    long_string = 'abcdefghijklmnopqrstuvwxyz'
    one_line_string = 'abc\ndef\nghi\n'

    # StringIO representing stdout
    stdout = StringIO()

    # Test that empty stream returns nothing
    stream_class, stream_kwargs = get_stream_type_and_kwargs(None, None)
    stream = stream_class(None, **stream_kwargs)
    write_stream(stream, stdout, False)
    assert stdout.getvalue() == ''

    # Test with non-empty stream
    stream

# Generated at 2022-06-21 14:24:32.957908
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    from httpie.cli.argtypes import KeyValueArg
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    from httpie.compat import str
    from httpie.config import Config
    from httpie.output.formatters.colors import get_config

    def get_args(env, **kwargs):
        def create_kwargs(env, **kwargs):
            args = parser.parse_args()
            args.output_options = get_config(
                                    env,
                                    KeyValueArg(kwargs.get('output_options', '')),
                                    'colors'
                                    )
            args.stream = False
            args.json = False
            args.prettify = kwargs.get('prettify', [])
           

# Generated at 2022-06-21 14:24:43.406970
# Unit test for function write_message
def test_write_message():

    from httpie.core import main
    from httpie.core import main
    from httpie.output.streams import fileno
    from httpie.output.streams import is_redirect

    from httpie.core import main
    from httpie.core import main

    args = argparse.Namespace()
    args.headers = True
    args.body = True
    args.download = True
    args.timeout = 999

    env = Environment(argv=['http', 'http://example.com'], args=args)

    args = argparse.Namespace()
    args.headers = True
    args.body = True
    args.download = True
    args.timeout = 999

    env = Environment(argv=['http', 'http://example.com'], args=args)

# Generated at 2022-06-21 14:24:47.849565
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(stream=False, prettify=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream


# Generated at 2022-06-21 14:24:48.341674
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-21 14:25:00.507133
# Unit test for function write_message
def test_write_message():
    import requests
    import json
    import os

    requests.packages.urllib3.disable_warnings()
    url = 'https://httpie.org/'
    r = requests.get(url)
    parsed = json.loads(r.text)
    os.environ['HTTPIE_LOAD_FORMATTER_MODULES'] = '1'
    os.environ['HTTPIE_CONFIG_DIR'] = '/home/ktra/.httpie'
    os.environ['HTTPIE_SHOW_HEADERS'] = '1'

# Generated at 2022-06-21 14:25:01.826227
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 14:25:12.528128
# Unit test for function write_stream
def test_write_stream():
    from . import test_raw, test_pretty, test_encoded
    from httpie.output.streams import DEFAULT_CHUNK_SIZE

    class DummyFile:
        def __init__(self):
            self.write_calls = 0

        def write(self, text):
            self.write_calls += 1

        def flush(self):
            pass

    class DummyRawStream(RawStream):
        def __iter__(self):
            return iter(test_raw.TEST_RESPONSE_AS_BYTES)

    class DummyPrettyStream(PrettyStream):
        def __iter__(self):
            return iter(test_pretty.TEST_RESPONSE_AS_BYTES)


# Generated at 2022-06-21 14:25:19.865725
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['none']
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}


# Generated at 2022-06-21 14:25:32.288686
# Unit test for function write_stream
def test_write_stream():
    import sys
    from httpie.output.streams import EncodedStream
    requests_message = requests.Request('GET', 'http://localhost:8080/')
    env = Environment()
    stream = EncodedStream('GET /', env=env)
    write_stream(stream, sys.stdout, flush=True)
    write_stream_with_colors_win_py3(stream, sys.stdout, flush=True)

# Generated at 2022-06-21 14:25:42.302959
# Unit test for function write_message
def test_write_message():
    
    from httpie import ExitStatus
    from httpie.context import Environment, EnvironmentRequest
    from httpie.output import write_message
    from httpie.output.streams import RawStream
    from httpie.plugins.builtin import HTTPBasicAuth
    import argparse
    import sys
    import requests

    class IgnoreArgvStderr(object):
        def write(self, data):
            pass
    sys.stderr = IgnoreArgvStderr()

    parser = argparse.ArgumentParser(
        prog='http',
        usage='%(prog)s [OPTIONS] URL [ITEM [ITEM]]',
        add_help=False
    )

    class MockHTTPResponse(object):
        pass


# Generated at 2022-06-21 14:25:54.313218
# Unit test for function write_message
def test_write_message():
    req = requests.Request('GET', 'www.rappler.com')
    env = Environment(
        stdout=None,
        stdin=None,
        stderr=None,
        is_windows=False,
        stdout_isatty=False,
        stdin_isatty=False,
        should_sort=False,
        stdin_bytes_to_write=None,
    )

# Generated at 2022-06-21 14:26:06.418422
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie
    import io
    import sys
    import json
    import requests
    import requests_mock
    import pytest
    import argparse

    # Mock requests session
    s = requests.Session()
    with requests_mock.Mocker() as mock:
        mock.get('https://mock.com/get', text='mock response')
        r = s.get('https://mock.com/get')
        # Mock stdout since it's used to write response data
        sys.stdout = io.StringIO()
        parser = argparse.ArgumentParser()
        env = httpie.context.Environment(parser, stdin=sys.stdin, stdout=sys.stdout,
                                         stderr=sys.stderr)
        # Call build_output_stream_for_message
        # Calling

# Generated at 2022-06-21 14:26:12.889189
# Unit test for function write_message
def test_write_message():
    import tempfile
    import os
    import json

    encodings = ['utf-8', 'latin1', 'ascii']
    for encoding in encodings:
        with tempfile.TemporaryDirectory() as tmpdirname:
            filename = os.path.join(tmpdirname, 'test.json')
            with open(filename, 'w', encoding=encoding) as file:
                request = {'key1': 'val1', 'key2': 'val2'}
                json.dump(request, file)
                write_message(request, '', '')

                
if __name__ == "__main__":
    test_write_message()

# Generated at 2022-06-21 14:26:18.848650
# Unit test for function write_stream
def test_write_stream():
    """Function test for function write_stream.
	"""
    from httpie.plugins.builtin import HTTPHeaders, HTTPBody
    from httpie.core import main
    from httpie import ExitStatus
    from tools import http, HTTP_OK

    r = http(
        '--json',
        'GET',
        httpbin.url + '/headers',
        'Foo:bar',
        'Foo:baz',
    )
    assert HTTP_OK in r



# Generated at 2022-06-21 14:26:23.616428
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(env=None, args=None)[0] == RawStream
    assert get_stream_type_and_kwargs(env=None, args=None)[1]['chunk_size'] == RawStream.CHUNK_SIZE_BY_LINE
    assert get_stream_type_and_kwargs(env=None, args=True)[1]['chunk_size'] == RawStream.CHUNK_SIZE
    assert get_stream_type_and_kwargs(env=None, args='json')[0] == EncodedStream

# Generated at 2022-06-21 14:26:35.739832
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams import DebugRawStream
    from httpie.context import Environment
    import argparse

    env = Environment(
        stdin=None,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )

    parser = argparse.ArgumentParser()
    parser.add_argument('--stream', action='store_true', dest='stream',
                        help='the server does not close the connection. In this case, httpie'
                              'displays data as soon as it arrives'
                              'and does not wait until the end of the response')
    parser.add_argument('--pretty', action='store_true',
                        help='pretty printing of HTTPie output.')
    parser_args = parser.parse_args(args=['--stream', '--pretty'])

    requests

# Generated at 2022-06-21 14:26:44.642325
# Unit test for function write_message
def test_write_message():
    import os
    env = Environment()
    from httpie import ExitStatus
    from httpie.input import ParseArguments
    from httpie.output.streams import RawStream
    from httpie import main
    args = ParseArguments().parse_args([
        '--print', 'q', 'http://httpbin.org/post'
    ])
    env.stdout = os.fdopen(os.open('/dev/null', os.O_RDWR), 'w')
    env.stderr = os.fdopen(os.open('/dev/null', os.O_RDWR), 'w')
    exit_status, requests_session = main(env, args)
    assert exit_status == ExitStatus.OK
    assert len(requests_session.history) == 1

# Generated at 2022-06-21 14:26:55.585715
# Unit test for function write_stream
def test_write_stream():
    from httpie.core import main
    from httpie.compat import StringIO

    # Testing for stdout write
    args = ['--pretty=all', 'https://httpbin.org/get']
    env = Environment(stdin=StringIO(), stdout=StringIO())
    exit_status, output_bytes = main(args=args, env=env)
    assert exit_status == ExitStatus.OK
    assert b'HTTP/' in output_bytes

    # Testing for stderr write
    args = ['https://httpbin.org/status/500']
    env = Environment(stdin=StringIO(), stderr=StringIO())
    exit_status, _ = main(args=args, env=env)
    assert exit_status == ExitStatus.ERROR_HTTP

# Generated at 2022-06-21 14:27:10.631753
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    input_args = argparse.Namespace()
    input_args.prettify = ['none']
    input_args.stream = True
    input_args.style = 'none'
    input_args.json = False
    input_args.format_options = {}

    env = Environment()
    env.stdout_isatty = True
    env.stdout = sys.stdout

    body = "This is a test body"
    message = HTTPRequest(
        method='GET',
        url='https://httpbin.org/get',
        headers={'User-Agent': 'HTTPie/0.9.9', 'Accept': 'application/json'},
        body=body,
        body_as_bytes=body.encode()
    )

# Generated at 2022-06-21 14:27:14.169700
# Unit test for function write_message
def test_write_message():
    write_message(requests.PreparedRequest, Environment, argparse.Namespace, False, True)
    write_message(requests.Response, Environment, argparse.Namespace, True, False)

# Generated at 2022-06-21 14:27:22.674841
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    requests_message = requests.PreparedRequest()
    argparse.Namespace = argparse.Namespace
    args = argparse.Namespace(
        auth=None,
        cert=None,
        config_dir='',
        data=None,
        download=False,
        files=None,
        form=None,
        headers=None,
        http2=True,
        ignore_stdin=False,
        include=None,
        json=None,
        max_headers=None,
        method=None,
        output_file=None,
        parameters=None,
        pretty=None,
        proxies=None,
        style='parrot',
        traceback=False,
        upload=None,
        verbose=False,
        verify=None,
    )
    env = Environment()

# Generated at 2022-06-21 14:27:33.676060
# Unit test for function write_message
def test_write_message():
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment

    class FakeRequest():
        def __init__(self):
            self.body = None
            self.headers = None
            self.method = 'GET'
            self.url = '127.0.0.1'

    class FakeResponse():
        def __init__(self):
            self.body = None
            self.headers = None
            self.status_code = None

    class FakeMessage():
        def __init__(self, FakeRequest):
            self.request = FakeRequest
            self.response = FakeResponse

        def is_error(self):
            return False

    class FakeEnv():
        def __init__(self):
            self.stdout = 'stdout'

# Generated at 2022-06-21 14:27:42.336218
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace(
        stream=None,
        prettify=None,
        style=None,
        json=True,
        format_options=None,
        debug=None,
        traceback=False
    )
    with_headers = True
    with_body = True

    res_ok = requests.Response()
    res_ok._content = b'{"key1":"value1","key2":"value2"}'
    res_ok.status_code = 200

    req = requests.PreparedRequest()
    req.headers = {"key1": "value1", "key2": "value2"}
    req.body = b'{"key1":"value1","key2":"value2"}'
    req.method = 'GET'

# Generated at 2022-06-21 14:27:43.772452
# Unit test for function write_stream
def test_write_stream():
    import sys
    import io
    test_stream = io.BytesIO(b'Hello World')
    write_stream(test_stream, sys.stdout, False)
    assert(test_stream.getvalue() == b'Hello World')


# Generated at 2022-06-21 14:27:52.283034
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class OutFile:
        def __init__(self):
            self.text = ""
        def write(self, s):
            self.text += s
        def flush(self):
            pass
        @property
        def encoding(self):
            return "utf-8"
    import io
    outfile = OutFile()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(None, {'prettify': []})
    stream = stream_class(
        msg=HTTPResponse(requests.Response()),
        with_headers=False,
        with_body=False,
        **stream_kwargs,
    )
    write_stream_with_colors_win_py3(stream, outfile, False)
    assert outfile.text == ""

    stream = stream_

# Generated at 2022-06-21 14:27:58.916446
# Unit test for function write_message
def test_write_message():
    import httpie.cli.argtypes
    import httpie.output.streams
    import httpie.output.formatters.colors
    write_message(
        requests_message=None,
        env=None,
        args={
            'style': 'none',
            'prettify': ['all'],
            'headers': False,
            'body': False,
            'stream': False,
            'debug': False,
            'traceback': False,
            'download': False,
            'json': False,
            'download_progress': 'off',
            'format_options': {},
        },
        with_headers=False,
        with_body=False,
    )
test_write_message.__test__ = False  # type: ignore

# Generated at 2022-06-21 14:28:10.894210
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # test for the raw response
    env = Environment(config=None,
                      stdin=None,
                      stdin_isatty=True,
                      stdout=None,
                      stdout_isatty=False,
                      stderr=None,
                      stderr_isatty=False,
                      is_windows=False)


# Generated at 2022-06-21 14:28:21.346908
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import re
    import sys

    platform_win = (sys.platform == 'win32')
    py3 = sys.version_info > (3,)
    if not (platform_win and py3):
        # not testing this function
        return

    output = io.StringIO()

    write_stream_with_colors_win_py3(
        stream=iter([b'\x1b[31mfoo\x1b[39m', b'\x1b[32mbar\x1b[39m']),
        outfile=output,
        flush=False,
    )

    output_lines = output.getvalue()


# Generated at 2022-06-21 14:28:43.546397
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    print(get_stream_type_and_kwargs('a','b'))

# Generated at 2022-06-21 14:28:54.886774
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from io import StringIO
    import sys
    import os

    os.environ['http_proxy'] = 'http://localhost:8899'
    os.environ['https_proxy'] = 'http://localhost:8899'
    os.environ['no_proxy'] = '127.0.0.1,localhost'
    os.environ['HTTPIE_ENV'] = 'TEST_ENV'
    os.environ['HTTPIE_DEBUG'] = 'TRUE'
    os.environ['HTTPIE_TRACEBACK'] = 'TRUE'

    import requests

    import httpie.cli
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.output import streams
    from httpie.output.processing import Conversion, Formatting
    from httpie.plugins import plugin_

# Generated at 2022-06-21 14:29:02.808462
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class MyHTTPRequest(HTTPRequest):
        def __init__(self):
            self.headers = {'host': 'www.google.com', 'token': 'chrome'}
            self.method = 'GET'
            self.url = 'https://www.google.com'

    class MyHTTPResponse(HTTPResponse):
        def __init__(self):
            self.headers = {'access-control-allow-origin': '*', 'content-type': 'text/html'}
            self.raw = "Google"
            self.url = 'www.google.com'
            self.status_code = '200'
            self.content = "this is the content"

    class MyArgs:
        def __init__(self):
            self.body = 'auto'
            self.debug = False
           

# Generated at 2022-06-21 14:29:12.496067
# Unit test for function write_message
def test_write_message():
    import os
    import random
    import requests
    import sys
    import time
    import unittest

    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
        ColorScheme
    )

    from tests.test_utils import http, httpbin, minversion, method_test_parameters
    from tests.test_utils import UnicodeOutputTestCase
    from tests.test_utils import unirepr
    from tests.tempdir import TempdirTestCase
    from tests.test_utils import cls_method_test_parameters
    
    if not sys.platform.startswith('linux'):
        return

# Generated at 2022-06-21 14:29:12.994727
# Unit test for function write_message
def test_write_message():
    write_message()

# Generated at 2022-06-21 14:29:22.589934
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )


# Generated at 2022-06-21 14:29:33.430651
# Unit test for function write_stream
def test_write_stream():
    import io
    import unittest
    import mock
    import httpie.cli.argtypes
    from httpie.compat import is_py2, is_windows
    from httpie.output.streams import BufferedPrettyStream, RawStream, PrettyStream
    from httpie.output.processing import Conversion, Formatting

    class MockStream(RawStream):
        def __iter__(self):
            return iter(['HTTP/1.1 200 OK\r\n\r\n', '\r\n\r\n'])

    class MockStreamWithColors(MockStream):
        def __iter__(self):
            return iter(
                ['HTTP/1.1 200 OK\r\n\r\n', '\x1b[', '\r\n\r\n']
            )


# Generated at 2022-06-21 14:29:43.758218
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class fakeEnv:
        def __init__(self, isatty=True):
            self.stdout_isatty = isatty

    stream_class, stream_kwargs = get_stream_type_and_kwargs(fakeEnv(isatty=False), None)
    assert (stream_class == RawStream)
    assert (stream_kwargs['chunk_size'] == 8192)

    stream_class, stream_kwargs = get_stream_type_and_kwargs(fakeEnv(isatty=True), None)
    assert (stream_class == EncodedStream)
    assert (stream_kwargs['env'].stdout_isatty)

    import argparse
    args = argparse.Namespace()
    args.prettify = ['json', 'format', 'colors']

# Generated at 2022-06-21 14:29:51.508857
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie
    from httpie.core import main
    from tests import http, HTTP_OK, TestEnvironment
    from requests.structures import CaseInsensitiveDict
    env = TestEnvironment()
    args = httpie.cli.parser.parse_args(
        args=[
            '--traceback',
            '--pretty',
            'json',
            '--print',
            'hT',
            '--print',
            'b',
            'https://httpbin.org/get?a=1&b=2'
        ],
        env=env
    )
    r = main(args, env)
    request_body = r.request.body
    response_body = r.response.body
    env.stdout.write(f'request_body: {request_body}')

# Generated at 2022-06-21 14:29:58.181090
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class TestStream(BaseStream):
        def __iter__(self):
            yield b'\x1b[31mfoo\x1b[0m'
            yield 'bar'

    outfile = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=TestStream(),
        outfile=outfile,
        flush=True)
    assert outfile.getvalue() == '\x1b[31mfoo\x1b[0mbar'

# Generated at 2022-06-21 14:30:50.987331
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.compat import is_bytes
    from httpie.output.streams import BaseStream


# Generated at 2022-06-21 14:30:54.545253
# Unit test for function write_stream
def test_write_stream():
    f = open('test.log', 'a')
    write_stream(stream=['test stream\n'], outfile=f, flush=True)
    f.close()


# Generated at 2022-06-21 14:30:55.791190
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-21 14:31:06.382445
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    args = parser.parse_args(args=[
        '--prettify',
        'headers,body'
    ])
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=True,
        stderr=None,
        stderr_isatty=True,
        colors=256,
        download_dir=None,
        default_options=None,
        config_dir=None
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == PrettyStream

# Generated at 2022-06-21 14:31:11.526265
# Unit test for function write_stream
def test_write_stream():
    class IO:
        def __init__(self):
            self.msg = ''
        def write(self, msg):
            self.msg += msg
        def flush(self):
            pass
    outfile = IO()
    chunk = 'message'
    write_stream(chunk, outfile, 0)
    assert(outfile.msg == chunk)


# Generated at 2022-06-21 14:31:18.512609
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    from pytest import raises
    from httpie.cli import parser
    from httpie.output import streams

    arg_parser = parser.get_arg_parser()
    args = arg_parser.parse_args('--stream --json'.split())
    sys.stdout = open(os.devnull, 'w') # stop it from printing to console
    response = requests.Response()
    response.status_code = 200
    response._content = b'[{"hello": "world"}]'
    response.encoding = 'utf-8'
    response.headers.update({'content-type': 'application/json'})
    response.request = requests.Request(method='GET', url='http://httpbin.org/')


# Generated at 2022-06-21 14:31:22.133102
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    write_stream_for_message(requests.PreparedRequest("POST", "http://www.baidu.com"), False, False)
    write_stream_for_message(requests.Response(), False, False)


# Generated at 2022-06-21 14:31:27.889674
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace(
            style='solarized',
            pretty='all',
            verbose=None,
            print_headers=None,
            print_body=None,
        ),
    )
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs['env'].stdout_isatty == True
    assert stream_kwargs['formatting'].color_scheme == 'solarized'

# Generated at 2022-06-21 14:31:32.496854
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class FakeStdout:
        buffer = io.BytesIO()
        encoding = 'utf-8'
        def write(self, text):
            self.buffer.write(text.encode(self.encoding))

    stdout = FakeStdout()

    raw_stream_args = {'chunk_size': 10}
    raw_stream = RawStream(msg=None, with_headers=False, with_body=True, **raw_stream_args)
    write_stream_with_colors_win_py3(
        stream=raw_stream,
        outfile=stdout,
        flush=True,
    )
    assert stdout.buffer.getvalue().decode(stdout.encoding) == '0123456789'

    fake_colored_text = 'some colored te\nxt'
    color

# Generated at 2022-06-21 14:31:37.795571
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.stream = True
    args.prettify = []
    args.style = None
    args.format_options = {}

    request = requests.PreparedRequest()
    request.method = 'GET'
    request.url = 'http://httpbin.org/'

    response = requests.Response()
    response.status_code = 200
    response.encoding = 'ISO-8859-1'
    response.reason = 'OK'
    response.url = 'http://httpbin.org/'
    response.headers['Content-Type'] = 'text/plain'
    response.raw = BytesIO(b'content')
    response.raw.release_conn = None

    # test request
    stream,

# Generated at 2022-06-21 14:33:01.705301
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-21 14:33:12.567238
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # simulate stdout is being piped to a program expecting text
    from io import StringIO
    import subprocess
    import sys

# Generated at 2022-06-21 14:33:19.520970
# Unit test for function write_stream
def test_write_stream():
    from httpie.context import Environment
    import io
    import sys
    env = Environment(
        stdout=sys.stdout,
        stdout_isatty=False,
        stderr_isatty=False,
        is_windows=sys.platform == 'win32',
        stdin=io.BytesIO(b'GET /test HTTP/1.1\r\n\r\n'),
        stdin_isatty=True,
    )
    args = argparse.ArgumentParser()
    args.__dict__ = {'stream': True, 'download': True, 'traceback': True, 'debug': True}
    write_stream(env=env, args=args, outfile=io.BytesIO(), flush=True)

# Generated at 2022-06-21 14:33:29.623384
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # pylint: disable=redefined-outer-name
    from io import StringIO
    class FakeStream(BaseStream):
        def __init__(self, chunks):
            self._chunks = chunks

        def __iter__(self):
            return iter(self._chunks)

        def __next__(self):
            return next(self._chunks)


# Generated at 2022-06-21 14:33:40.415337
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # The following is the Python representation of pack("H", "1b")
    colorCode = b"\x1b"
    colorCode = colorCode.decode("utf-8")
    terminal = "CMD"

    stream = PrettyStream(HTTPRequest("GET", "https://httpie.org"),
                          with_headers=True, with_body=True, env={
                              "stdout_isatty": True,
                              "stdin_isatty": True,
                              "is_windows": True,
                              "color_mode": "never",
                              "stdin_encoding": None,
                              "stdout_encoding": None,
                              "is_bytes": True,
                              "terminal": terminal})
    outfile = sys.stdout
    flush = True

    # The following import

# Generated at 2022-06-21 14:33:46.313433
# Unit test for function write_message
def test_write_message():
    env = Environment()
    env.config['stdout_isatty'] = False
    args = argparse.Namespace(
        stream=False,
        pretty='all',
        colors=True,
        traceback=False,
        download=False)
    req = requests.Request("GET", "http://www.baidu.com/").prepare()
    resp = requests.Response()
    resp.status_code = 200
    resp.encoding = 'utf-8'
    resp.raw = io.BytesIO(b'\x1b[31m\nHTTPie hello\x1b[0m\n')
    write_message(req, env, args, True, True)
    write_message(resp, env, args, True, True)

# Generated at 2022-06-21 14:33:54.958278
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import TextIOWrapper
    from tempfile import TemporaryFile

    tfile = TemporaryFile('w+')
    tfile = TextIOWrapper(tfile)
    tfile.write = lambda s: tfile.buffer.write(s.encode('utf-8'))

    tfile.write('a')

    write_stream_with_colors_win_py3(
        stream=[b'\x1b[1ma\x1b[0m'],
        outfile=tfile,
        flush=True,
    )

    tfile.seek(0)
    tfile.read()