

# Generated at 2022-06-21 14:24:07.489358
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    stream = StringIO()
    for chunk in 'a\x1b[1mb\x1b[2mc\x1b[0m':
        write_stream_with_colors_win_py3(
            stream=BaseStream(
                msg=HTTPResponse(requests.Response()),
                with_headers=True,
                with_body=True,
            ),
            outfile=stream,
            flush=False,
        )
    assert stream.getvalue() == 'abc'



# Generated at 2022-06-21 14:24:17.043902
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Outfile:
        def __init__(self, encoding):
            self.encoding = encoding

        def write(self, text):
            self.output = text

        def flush(self):
            pass

    outfile = Outfile(encoding='utf-8')
    stream = BaseStream(b'\x1b[1;32mfoo\x1b[0m', content_type='text/plain')

    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=True
    )

    assert outfile.output == '\x1b[1;32mfoo\x1b[0m'

# Generated at 2022-06-21 14:24:24.579833
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(
        prettify=[],
        style=None,
        json=None,
        format_options={},
        stream=None,
    )
    env = Environment(
        colors=256,
        stdout_isatty=True,
        stdout_encoding='utf8',
        stdin_isatty=True,
        always_sticky=False,
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert(stream_class == EncodedStream)
    assert(stream_kwargs == {'env': env})


# Generated at 2022-06-21 14:24:35.679825
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    test_data = [
        b'\x1b[0m\x1b[0m',
        b'\x1b[38;5;1mo',
        b'\x1b[0m\x1b[38;5;1mo',
        b'\x1b[0m\x1b[38;5;1mo\x1b[0m\x1b[38;5;2mo',
        b'\x1b[38;5;1mo\x1b[0m\x1b[38;5;2mo'
    ]


# Generated at 2022-06-21 14:24:47.102240
# Unit test for function write_message
def test_write_message():
    from test.helpers import get_response_with_headers
    resp = get_response_with_headers()
    ls = []
    class Writer:
        def write(self, s):
            ls.append(s)
        def flush(self):
            pass
    env = Environment()
    env.stdout = Writer()
    env.stderr = Writer()
    args = argparse.Namespace(stream=False,
                              json=False,
                              prettify=None,
                              style=None)
    write_message(resp, env, args, with_headers=True, with_body=True)
    ls = [l.rstrip() for l in ls]

# Generated at 2022-06-21 14:24:56.821632
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    requests_message.headers = {'Accept': 'text/html'}
    requests_message.method = 'GET'
    requests_message.url = 'https://www.google.com'
    args = argparse.Namespace( body=False, debug=True,
                               headers=False, json=False,
                               method='GET', output='-',
                               pretty=True, scheme='https',
                               traceback=True, url='www.google.com',
                               verbose=False )
    assert write_message(requests_message, env, args, True, False) is None

# Generated at 2022-06-21 14:25:08.324473
# Unit test for function write_message
def test_write_message():
    message_separator = '\n\n'
    message_separator_bytes = message_separator.encode()

    try:
        write_message(
            requests_message="",
            env="",
            args="",
            with_headers=False,
            with_body=False
        )
    except IOError as e:
        show_traceback = args.debug or args.traceback
        if not show_traceback and e.errno == errno.EPIPE:
            # Ignore broken pipes unless --traceback.
            env.stderr.write('\n')
        else:
            raise

    write_stream("", "", False)

    write_stream_with_colors_win_py3("", "", "")


# Generated at 2022-06-21 14:25:16.045804
# Unit test for function write_message
def test_write_message():
    class DummyRequestsResponse:
        def __init__(self, body, status_code):
            self.body = body
            self.status_code = status_code

    class DummyArgs:
        def __init__(self, stream=False, prettify=False, style='default',
            debug=False, traceback=False, json=False, format_options=None):
            self.stream = stream
            self.prettify = prettify
            self.style = style
            self.debug = debug
            self.traceback = traceback
            self.json = json
            self.format_options = format_options

    class DummyStdoutIO:
        pass

    class DummyStdout:
        def __init__(self, isatty=False):
            self.isatty = isatty
           

# Generated at 2022-06-21 14:25:27.405898
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """Test unit build_output_stream_for_message"""
    env = Environment()
    args = argparse.Namespace(
        debug=False,
        download=False,
        output_dir=None,
        prettify=None,
        print_body=False,
        print_headers=False,
        print_status=False,
        print_trailers=False,
        stream=False,
        style=None,
        traceback=False
    )
    requests_message = requests.PreparedRequest()
    requests_message.headers = {'Host': 'httpie.org'}
    requests_message.url = 'http://httpie.org'
    requests_message.body = '123'
    with_headers = False
    with_body = False

# Generated at 2022-06-21 14:25:30.242904
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    env = Environment()
    args = ['Prettify', 'Colors', 'Request', 'Response']
    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE})

# Generated at 2022-06-21 14:25:44.397434
# Unit test for function write_message
def test_write_message():
    from httpie import output
    from httpie.input import ParseError
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.parser import parse_items
    from httpie.output.streams import PrettyStream
    import httpie
    import requests

    args = httpie.cli.parser.parse_args(['http://www.google.com'])

# Generated at 2022-06-21 14:25:56.862735
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    class env:
        stdout_isatty = 1
        stdout = 'stdout'

    class args:
        prettify = []
        stream = 0
        style = []
        json = 0

    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE})

    args.prettify = ['colors']
    args.stream = 1
    assert get_stream_type_and_kwargs(env, args) == (PrettyStream, 
        {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=['colors'], color_scheme=[], explicit_json=0, format_options={})})

    args.prettify = []
    args.stream = 0
   

# Generated at 2022-06-21 14:26:08.120215
# Unit test for function write_message
def test_write_message():
    request_message = requests.PreparedRequest()
    request_message.body = 'hello'
    env = Environment()
    args = argparse.Namespace()
    write_message(
        requests_message=request_message,
        env=env,
        args=args,
        with_headers=True,
        with_body=True
    )
    request_message.body = None
    write_message(
        requests_message=request_message,
        env=env,
        args=args,
        with_headers=True,
        with_body=True
    )
    write_message(
        requests_message=request_message,
        env=env,
        args=args,
        with_headers=True,
        with_body=False
    )

# Generated at 2022-06-21 14:26:15.034503
# Unit test for function write_message
def test_write_message():
    args.prettify = "all"
    args.style = "paraiso-dark"
    args.json = False
    args.format_options = "n"
    args.isatty = True
    assert type(write_message(
        requests_message = requests.Response,
        env = Environment(),
        args = args,
        with_headers = False,
        with_body = False,
    )) == list



# Generated at 2022-06-21 14:26:24.192394
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    from httpie.core import main
    from httpie.output.processing import Formatting
    from httpie.output.streams import PrettyStream

    args = parser.parse_args(
        ['-p', 'json', '--print=hB', 'http://httpbin.org/get']
    )
    env = Environment()

    env.stdin = io.StringIO()
    env.stdin.encoding = 'utf8'
    env.stdout = io.StringIO()
    env.stdin.encoding = 'utf8'
    env.stderr = io.StringIO()
    env.stderr.encoding = 'utf8'

    exit_status, http_response = main(args, env=env)
    assert exit_status == ExitStatus.OK

# Generated at 2022-06-21 14:26:36.337038
# Unit test for function write_message
def test_write_message():
    from httpie import cli
    from httpie.context import Environment

    arg_parser = getattr(cli, 'get_arg_parser')()
    args = arg_parser.parse_args(args=[])
    env = Environment(stdin=None,
                        stdout=None,
                        stderr=None,
                        config_dir=None,
                        env=None,
                        is_windows=None,
                        config_dir_from_env=None,
                        output_options=None)

    write_stream_output = ''''HTTP/1.0 200 OK

'''
    with requests.Session() as s:
        r = s.get('http://httpbin.org/')
        with patch('builtins.print') as mocked_print:
            write_message(r, env, args)
            assert mocked_print

# Generated at 2022-06-21 14:26:41.052348
# Unit test for function write_stream
def test_write_stream():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(),
        args=argparse.Namespace()
    )
    message_class = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }["requests.Response"]

# Generated at 2022-06-21 14:26:44.863634
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import BaseStream
    stream = (b'123', b'456', b'789')
    class FakeStream(BaseStream):
        def __iter__(self):
            return iter(stream)
    fakeoutfile = FakeTextIOWrapper()
    write_stream(FakeStream(), fakeoutfile, flush=False)
    assert fakeoutfile.data == stream

# Generated at 2022-06-21 14:26:52.153300
# Unit test for function write_stream
def test_write_stream():
    from httpie.output.streams import Stream
    # Test for write_stream function
    class TestStream(Stream):
        def __init__(self, outfile):
            self.outfile = outfile
            self.chunks = ['abcdefghijklmnopqrstuvwxyz']

        def __iter__(self):
            return iter(self.chunks)

    with open('test_stream') as TestStream:
        write_stream(TestStream, 'test_stream', False)

# Generated at 2022-06-21 14:27:00.586987
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """
    Test for build_output_stream_for_message.
    """
    from httpie.output.streams import PrettyStream
    from httpie.input import KeyValue
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    parsed_args = parser.parse_args([])
    args = parser.namespace_args(parsed_args)
    env = Environment(parser, args)
    requests_request = requests.PreparedRequest()
    requests_response = requests.Response()

# Generated at 2022-06-21 14:27:18.054451
# Unit test for function write_stream
def test_write_stream():
    obj = object()

    class MockStream(object):
        def __iter__(self):
            yield obj

    class MockOutfile(object):
        def __init__(self):
            self.data = []

        def buffer(self):
            return self

        def write(self, chunk):
            self.data.append(chunk)

        def flush(self):
            self.data.append('flush')

    outfile = MockOutfile()
    write_stream(MockStream(), outfile, flush=True)
    assert outfile.data == [obj, 'flush']

# Generated at 2022-06-21 14:27:25.148283
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.utils import StdinBytesIO
    import sys

    class TestingPrettyStream(PrettyStream):
        def __init__(self, colors, **kwargs):
            self.colors = colors
            super().__init__(**kwargs)

        def __iter__(self):
            yield from self.colors

    env = Environment()
    args = argparse.Namespace(prettify=['colors'])

    stdin = sys.__stdin__
    sys.stdin = StdinBytesIO()
    sys.stdin.encoding = 'gbk'

# Generated at 2022-06-21 14:27:35.472122
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import sys
    class Env():
        stdout_isatty = False
    class Args():
        prettify = None
        stream = False
        style = None
        json = False
        format_options = None
    # 1 
    env = Env()
    args = Args()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env = env,
        args = args
    )
    assert str(stream_class) == "<class 'httpie.output.streams.RawStream'>"
    assert stream_kwargs == {
        'chunk_size': 32768
    }
    # 2
    env = Env()
    args = Args()
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_

# Generated at 2022-06-21 14:27:44.425430
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Tests the write_stream_with_colors_win_py3 function
    :return:
    """
    import io
    import os
    import platform
    import sys
    from httpie._compat import get_best_encoding
    from httpie.output.streams import BaseStream

    class MockStream(BaseStream):
        def __init__(self, chunks):
            self._chunks = chunks

        def __iter__(self):
            for chunk in self._chunks:
                yield chunk

    # Set up platform and test string
    if platform.system() != 'Windows':
        return
    if sys.version_info < (3, 0):
        return
    test_string = 'a\r\nb\r\n'
    expected_string = 'a\nb\n'

    # Set up out

# Generated at 2022-06-21 14:27:53.175725
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.core import main
    import pytest
    import json

    # Test Raw Stream
    args = main.parser.parse_args(
        args=[
            '--stream',
            '--body',
            'https://example.org',
        ],
        env=Environment()
    )
    args.stdout = pytest.helpers.io()

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=args.env,
        args=args,
    )
    assert stream_class.__name__ == RawStream.__name__
    assert stream_kwargs == {
        'chunk_size': RawStream.CHUNK_SIZE_BY_LINE
    }

    # Test PrettyStream
    args.prettify = ['b']
    args.stream = True

# Generated at 2022-06-21 14:27:53.680702
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert False

# Generated at 2022-06-21 14:27:59.232870
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO

    def _get_write_stream_with_colors_win_py3(outfile):
        env = Environment()
        env.stdout_isatty = False
        args = argparse.Namespace(prettify=None)
        stream = BaseStream([b'foo\x1b[32mbar\x1b[0m'])
        write_stream_with_colors_win_py3(stream, outfile, False)

    def _get_write_stream_with_colors_win_py3_no_color(outfile):
        env = Environment()
        env.stdout_isatty = False
        args = argparse.Namespace(prettify=None)

# Generated at 2022-06-21 14:28:08.373429
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.compat import StringIO
    from httpie.output.streams import EncodedStream

    def build_stream():
        yield b'\x1b[31mHello world\x1b[0m'
        yield b'!\n'

    file = StringIO()
    write_stream_with_colors_win_py3(
        stream=build_stream(),
        outfile=file,
        flush=True
    )
    assert file.getvalue() == '\x1b[31mHello world\x1b[0m!\n'

# Generated at 2022-06-21 14:28:19.064066
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io
    stripped_blob = b'\x1b['
    color_blob = b'\x1b[1;33m'
    regular_blob = b'regular'
    color_blob_end = b'\x1b[0m'
    chunks = [
        stripped_blob,
        b'abc',
        color_blob,
        b'abc',
        color_blob_end,
        stripped_blob,
        b'abc',
        regular_blob,
        stripped_blob,
        b'abc',
        color_blob,
        b'abc',
    ]

    def get_stream(chunks):
        for chunk in chunks:
            yield chunk


# Generated at 2022-06-21 14:28:26.841282
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.Response()
    requests_message.encoding = 'utf-8'
    requests_message.raw = io.BytesIO(b'Hello, world!\n')
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)
    env.stdout = open(tmpfile, 'w+b')
    write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_headers=False,
        with_body=True,
    )
    env.stdout.close()
    assert open(tmpfile).read() == 'Hello, world!\n\n'
    os.remove(tmpfile)

# Generated at 2022-06-21 14:28:54.184641
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = True
    with_body = True
    write_message(requests_message, env, args, with_headers, with_body)
    # no return value of write_message
    # assert isinstance(result, object)

# Generated at 2022-06-21 14:29:02.086791
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    # NOTE: writing the following line in one line without `\` results timeout
    # in pytest.
    stream = io.BytesIO(b'\x1b[1m\x1b[1mGET / HTTP/1.1\x1b[0m \x1b[36m200\x1b[0m'),
    outfile = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False
    )

# Generated at 2022-06-21 14:29:11.981978
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment.empty()
    args = argparse.Namespace()
    args.prettify = 'colors'
    args.stream = True
    args.style = 'solarized'
    args.json = True
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class.__name__ == "PrettyStream"
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__.__name__ == "Conversion"
    assert stream_kwargs['formatting'].__class__.__name__ == "Formatting"
    assert stream_kwargs['formatting'].env == env
    assert stream_kwargs['formatting'].groups == 'colors'
   

# Generated at 2022-06-21 14:29:21.777524
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(
        prettify='all',
        stream=False,
        debug=False,
        verbose=False,
        traceback=False,
        style='solarized',
        json='False',
        format_options={},
        files=[]
    )

    response_headers = {
        'content-type': 'text/html; charset=utf-8',
        'content-length': '2'
    }
    response_body = '12'
    response = requests.Response()
    response.status_code = 200
    response.headers = response_headers
    response._content = response_body
    response._content_consumed = True


# Generated at 2022-06-21 14:29:32.606433
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # PrettyStream with style json
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'json'
    args.stream = True
    args.format_options = ['pretty']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs == {'env': env, 'conversion': Conversion(),
                             'formatting': Formatting(env=env, groups=['colors'],
                             color_scheme='json', explicit_json=False,
                             format_options=['pretty'])
                            }
    # EncodedStream with style emacs
    env = Environment()
    args = argparse.Namespace()

# Generated at 2022-06-21 14:29:39.493922
# Unit test for function write_stream
def test_write_stream():
    import io
    stream = BaseStream(
        msg=HTTPRequest(
            requests.Request('GET', 'https://google.com').prepare()
        ),
        with_headers=True,
        with_body=True,
    )
    outfile = io.StringIO()
    write_stream(
        stream=stream,
        outfile=outfile,
        flush=True
    )
    assert outfile.getvalue() == 'GET / HTTP/1.1\r\nHost: google.com\r\n\r\n\n\n'


# Generated at 2022-06-21 14:29:43.985999
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os

    import requests
    from httpie.cli import get_argparser
    from httpie.output.streams import RawStream

    parser = get_argparser()
    env = Environment()

    args = parser.parse_args(['--stream', '--raw-stream-chunk-size-by-line', 'https://httpie.org/'])
    env.stdout_isatty = False
    env.stdout = open(os.devnull, 'wb')

    requests_message = requests.get('https://httpie.org/')
    requests_message.raw = requests.adapters.HTTPAdapter.build_response(build_response=requests_message)
    with_headers = True
    with_body = True


# Generated at 2022-06-21 14:29:45.759858
# Unit test for function write_stream
def test_write_stream():
    import sys
    write_stream(b'hello world', sys.stdout, True)

# Generated at 2022-06-21 14:29:52.301925
# Unit test for function write_message
def test_write_message():
    # env
    env = Environment(
        stdin=None,
        stdin_isatty=False,
        stdout=None,
        stdout_isatty=False,
        stderr=None,
        ignore_stdin=(True,),
        is_windows=False,
        colors=None
    )
    # args

# Generated at 2022-06-21 14:30:03.396447
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.input.parse_items
    import httpie.output.streams
    import httpie.cli.argparser
    import tempfile
    import os
    #import sys
    #sys.stdout = open('log', 'w+')
    from httpie.core import main
    from httpie.output.pretty import format_output_for_debug
    from httpie.models import HTTPRequest, HTTPResponse
    #import shutil
    #shutil.rmtree('./httpie', ignore_errors=True)
    class MyTestEnvironment(Environment):
        stdin = None
        cookies = None
        stdout_isatty = True
        is_windows = False
        colors = 256

# Generated at 2022-06-21 14:30:40.600031
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    env.stdout_isatty = False
    args = argparse.Namespace()
    args.prettify = False
    args.style = "default"
    args.stream = False
    args.format_options = ""
    args.json = False
    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(
    env=env,
    args=args
    )
    assert stream_class == RawStream
    assert stream_kwargs["chunk_size"] == RawStream.CHUNK_SIZE
    env.stdout_isatty = False
    args.prettify = True
    args.stream = True
    args.json = True

# Generated at 2022-06-21 14:30:41.253161
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-21 14:30:47.265072
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    from httpie.output import streams
    import httpie.output.streams
    args = httpie.cli.parser.parse_args()
    env = httpie.cli.get_environment(args)

    requests_message = requests.PreparedRequest()
    requests_message.method = "GET"
    HTTPRequest = HTTPRequest(requests_message)
    assert HTTPRequest.method == "GET", "HTTPRequest method should be GET"

# Generated at 2022-06-21 14:30:57.993944
# Unit test for function write_message

# Generated at 2022-06-21 14:31:09.287253
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Unit test for function write_stream_with_colors_win_py3"""
    from io import StringIO
    args = argparse.Namespace()
    env = Environment()
    env.is_windows = True
    env.stdout_isatty = True
    args.prettify = ['colors']
    response = requests.Response()
    output = StringIO()

# Generated at 2022-06-21 14:31:17.263719
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Case 1: without headers but with body
    env = Environment(
        stdin=requests.Session(),
        stdout=requests.Session(),
        stderr=requests.Session(),
        stdin_isatty=requests.Session(),
        stdout_isatty=requests.Session(),
        stdin_raw=requests.Session(),
        stdout_raw=requests.Session(),
        simple_output=requests.Session(),
        unicode_errors=requests.Session(),
        request_timeout=requests.Session(),
        verify=requests.Session(),
        proxies=requests.Session(),
        max_redirects=requests.Session(),
    )

# Generated at 2022-06-21 14:31:26.641215
# Unit test for function write_stream
def test_write_stream():
    import sys
    import io
    import requests
    
    sys.path.append("/home/utente/PycharmProjects/http-request-tester/src/httpie/output")
    from stream import EncodedStream
    from processing import Conversion, Formatting
    from context import Environment
    from models import HTTPRequest, HTTPResponse
    
    class test_stream(EncodedStream):
        def __init__(self,msg,with_headers=False,with_body=False,env=None):
            super().__init__(env=env)
            self.msg=msg
            self.with_headers=with_headers
            self.with_body=with_body
        def __iter__(self):
            test_stream_iterator=iter("TEST_ENCODED_STREAM")
            yield test_stream

# Generated at 2022-06-21 14:31:28.711026
# Unit test for function write_message
def test_write_message():
    environment = Environment(stdin=None, stdout=None, stderr=None)
    write_message(requests.Response, environment, argparse, True, True)

# Generated at 2022-06-21 14:31:32.515167
# Unit test for function write_message
def test_write_message():
    print("test write_message")
    import httpie.output
    print("test write_message")
    from httpie.output.streams import  BufferedPrettyStream
    print("test write_message")
    a=IsolatedPrettyStream("aaaa")
    print("test write_message")
    print("test write_message")
    print("test write_message")

# Generated at 2022-06-21 14:31:42.984960
# Unit test for function write_message
def test_write_message():
    requests_response = requests.Response()
    assert requests_response.status_code == 200
    assert (requests_response.raw is None) == True

    requests_response.status_code = 201
    assert requests_response.status_code == 201
    assert (requests_response.raw is None) == True

    requests_response.status_code = 202
    assert requests_response.status_code == 202
    assert (requests_response.raw is None) == True

    requests_response.status_code = 203
    assert requests_response.status_code == 203
    assert (requests_response.raw is None) == True

    requests_response.status_code = 204
    assert requests_response.status_code == 204
    assert (requests_response.raw is None) == True

    requests_response.status_code = 205

# Generated at 2022-06-21 14:33:00.059055
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import pytest
    class argparse:
        class Namespace:
            prettify = ['colors']
            format_options = []
            stream = False
    class environment:
        stdout_isatty = True
    class requests_responses:
        class Response:
            def __init__(self, url, body, headers, status_code):
                self.url = url
                self.text = body
                self.headers = headers
                self.status_code = status_code
    class requests_prepared_request:
        class PreparedRequest:
            def __init__(self, headers, body, method, url):
                self.headers = headers
                self.body = body
                self.method = method
                self.url = url
    
    
    # test response with all the arguments that you can pass

# Generated at 2022-06-21 14:33:11.081318
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.core
    import httpie.models
    import httpie.cli
    import httpie.output

    # Build a request
    requests.request(method='POST', url='https://localhost:8080/test',
                     data="foo=bar")

    # Extract request and response objects
    request = httpie.core.HTTPClient().history[0].request
    response = httpie.core.HTTPClient().history[0].response

    # Create the request and the response messages
    request_msg = httpie.models.HTTPRequest(request)
    response_msg = httpie.models.HTTPResponse(response)

    # Define flags
    with_headers = True
    with_body = True

    # Create a fake argparse namespace

# Generated at 2022-06-21 14:33:12.093081
# Unit test for function write_stream
def test_write_stream():
    pass  # TODO


# Generated at 2022-06-21 14:33:17.205431
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    import sys
    from httpie.output.streams import RawStream

    env = Environment(stdout=StringIO())
    stream = RawStream(msg=HTTPRequest("GET http://test.test HTTP/1.1"))
    write_stream(stream, env.stdout, True)
    stream = RawStream(msg=HTTPResponse("hello world"))
    write_stream(stream, env.stdout, True)
    print(env.stdout.getvalue())

# Generated at 2022-06-21 14:33:22.930631
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie import ExitStatus
    from httpie.context import Environment
    from tests.compat import unittest

    args = main.parse_args(args=[])
    env = Environment(vars(args))
    requests_response = requests.Response()
    request_type = {
        'headers': [],
        'body': {}
    }
    requests_response._content = json.dumps(request_type).encode()
    requests_message = requests.PreparedRequest()

# Generated at 2022-06-21 14:33:33.661382
# Unit test for function write_message
def test_write_message():
    import argparse
    from httpie.exitstatus import ExitStatus
    from httpie.output import streams
    from httpie.core import main

    requests.Response._content = b'{"args": {"test": "ok"}, "data": "", "files": {}, "form": {}, "headers": {"Accept": "*/*", "Accept-Encoding": "gzip, deflate", "Connection": "close", "Content-Length": "", "Content-Type": "application/x-www-form-urlencoded", "Host": "httpbin.org", "User-Agent": "HTTPie/1.0.3"}, "json": null, "origin": "80.12.246.181", "url": "http://httpbin.org/post"}'
    requests.Response.status_code = 200


# Generated at 2022-06-21 14:33:42.550641
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    c = b'\x1b['
    r = b'\r'
    e = '.\r\n'
    x = b''.join([c, r, e])
    r = '.\r\n'
    bs = b''.join([b'a', r, b'b', r, b'c', r])
    s = 'a.\r\n'.encode('utf8')
    b = 'b.\r\n'.encode('utf8')
    c = 'c.\r\n'.encode('utf8')
    fs = b''.join([s, b, c])
    n = '\n'
    n_s = n.encode('utf8')
    f = b''.join([s, n_s, b, n_s, c, n_s])


# Generated at 2022-06-21 14:33:45.508014
# Unit test for function write_message
def test_write_message():
    requests.Response.is_body_upload_chunk = True
    assert write_message(
        requests.PreparedRequest,
        Environment,
        argparse.Namespace,
        False,
        False
    ) == None



# Generated at 2022-06-21 14:33:51.256038
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    stdout = io.StringIO()
    stream = BaseStream(b"\x1b[31m")
    write_stream_with_colors_win_py3(stream=stream,
                                     outfile=stdout,
                                     flush=True)
    assert stdout.getvalue() == "\x1b[31m"