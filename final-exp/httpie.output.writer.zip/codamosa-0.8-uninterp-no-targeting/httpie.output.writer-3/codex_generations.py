

# Generated at 2022-06-21 14:24:13.972117
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input.base import ParseError
    from httpie.plugins import plugin_manager
    from httpie.plugins.__main__ import main
    from httpie import ExitStatus
    from httpie.core import main as core_main
    from httpie.compat import is_windows
    from httpie.output import (
        parse_content_type,
        get_response_as_json
    )

    # Setup
    env = Environment()
    args = parse_args([])
    args.verbose = False

    # Start response
    response = requests.Response()
    response.status_code = 200
    response.raw = requests.packages.urllib3.response.HTTPResponse(body=b'')
    response.headers = requests.structures.CaseInsensitiveDict()


# Generated at 2022-06-21 14:24:20.294359
# Unit test for function write_stream
def test_write_stream():
    # write_stream의 리턴값은 None이므로, 함수 내부 내용을 테스트 해야함.
    content = io.StringIO()
    mock_stream = [b'hello', b'world']
    write_stream(mock_stream, content, True)
    assert content.getvalue() == 'helloworld'

# Generated at 2022-06-21 14:24:24.569967
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.output.streams
    class Environment(object):
        def __init__(self):
            self.stdout = sys.stdout
            self.stdout_isatty = True
            self.is_windows = sys.platform == "win32"
    class ArgparseNamespace(object):
        def __init__(self):
            self.stream = False
            self.prettify = []
    env = Environment()
    args = ArgparseNamespace()
    # Test for HTTPRequest
    class PreparedRequest(requests.PreparedRequest):
        def __init__(self):
            self.method = 'GET'
            self.url = 'http://localhost'
            self.headers = {
                'User-Agent': 'Test',
                'Accept': '*/*'
            }

# Generated at 2022-06-21 14:24:25.384816
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-21 14:24:36.129097
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Unit test for function write_stream_with_colors_win_py3
    """
    from httpie.output.streams import FakeFile

    outfile = FakeFile()
    stream = [
        'It\x1b[0m \x1b[1;32mwas\x1b[0m \x1b[1;31mthe\x1b[0m \x1b[1;31mbest\x1b[0m \x1b[1;33mof\x1b[0m \x1b[0m\x1b[1;33mtimes\x1b[0m\n',
        b'\x1b'
    ]
    write_stream_with_colors_win_py3(stream, outfile, False)


# Generated at 2022-06-21 14:24:37.460640
# Unit test for function write_message
def test_write_message():
    assert write_message((True, False)) == ('\n\n')

# Generated at 2022-06-21 14:24:48.717965
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    args.stream = False
    args.prettify = False
    env = Environment()

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert buffered_pretty_stream_class is stream_class
    assert stream_kwargs['env'] is env

    args = argparse.Namespace()
    args.stream = True
    args.prettify = False
    env = Environment()

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert raw_stream_class is stream_class
    assert stream_kwargs['chunk_size'] == raw_stream_class.CHUNK_SIZE_BY_LINE

    args = argparse.Namespace()

# Generated at 2022-06-21 14:25:00.877821
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import pytest
    from io import StringIO
    from httpie.output.streams import (
        BaseStream, PrettyStream
    )

    class MockStream(BaseStream):
        def __init__(self, iterator_content):
            super(BaseStream, self).__init__()
            self.iterator_content = iterator_content

        def __iter__(self):
            for item in self.iterator_content:
                yield item

    class MockEnvironment:
        is_windows = True
        stdout_isatty = True
        stdout = StringIO()

    class MockArgs:
        prettify = ['colors']
        style = ''
        stream = False

    class MockResponse:
        pass

    class MockMessage:
        def __init__(self, req_resp):
            self.request = req_resp


# Generated at 2022-06-21 14:25:11.674303
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(colors=256)
    env.stdout = sys.stdout
    env.stdout_isatty = True
    env.stdin_isatty = True

    args = create_argparse().parse_args(['-p', 'hbc', '--style', 'paraiso-light'])
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class.__name__ == 'PrettyStream'
    assert stream_kwargs['formatting'].color_scheme.name == 'paraiso-light'
    assert stream_kwargs['conversion'].__class__.__name__ == 'Conversion'
    assert stream_kwargs['env'].colors == 256


# Generated at 2022-06-21 14:25:15.120041
# Unit test for function write_stream
def test_write_stream():
    requests_message = None
    args = argparse.Namespace()
    env = Environment()
    with_headers = False
    with_body = True
    write_message(requests_message, env, args, with_headers, with_body)

# Generated at 2022-06-21 14:25:29.138818
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-21 14:25:39.463426
# Unit test for function write_message
def test_write_message():
    from io import StringIO
    from tempfile import TemporaryDirectory
    from tests.data.messages import REQUEST as requests_request
    from tests.data.messages import RESPONSE as requests_response
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.input import ParseError
    from httpie.context import Environment
    from httpie.output import streams

    raw_args = ['GET', 'https://httpbin.org/get']
    args = parser.parse_args(raw_args)
    env = Environment(stdin=StringIO(), stdout=StringIO(), stderr=StringIO())

# Generated at 2022-06-21 14:25:40.473868
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Do nothing here
    pass

# Generated at 2022-06-21 14:25:47.455964
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.input
    class Args:
        stream = None
        prettify = []
        style = None
        debug = None
        traceback = None
    args = Args()
    req=requests.Request()
    req.method='get'
    req.url='http://www.baidu.com'
    header={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36'}
    req.headers=header
    req.body = ""

# Generated at 2022-06-21 14:25:59.283449
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import argparse
    from httpie.context import Environment
    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        colors=256,
        is_windows=False,
        stdout_isatty=True,
        stdin_isatty=False,
        scheme='https',
        default_options=[
        ],
    )
    args = argparse.Namespace()
    args.headers = False
    args.body = False
    args.stream = False
    args.prettify = True
    args.style = 'default'
    args.json = False
    requests_message = requests.PreparedRequest
    with_headers = False
    with_body = False

# Generated at 2022-06-21 14:26:10.034989
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env: Environment = Environment(
        colors=256,
        stdout_isatty=True,
        stdin_isatty=True,
        stdout=None,
        stderr=None
    )

# Generated at 2022-06-21 14:26:14.532569
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env=Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    for message in build_output_stream_for_message(args, env, requests_message, with_headers, with_body):
        print(message)

# Generated at 2022-06-21 14:26:23.852213
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class fake_env():
        stdout = None
        stdout_isatty = None
        is_windows = None
    class fake_req():
        body = 'b'
        headers = {'a': 1}
    class fake_args():
        stream = None
        prettify = None
        style = None

    from httpie.streams import BaseStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.formatters import UnixTimestampHTTPrettyFormatter
    from httpie.compat import is_windows
    args = fake_args()
    args.stream = True
    args.prettify = None
    args.style = 'test'
    env = fake_env()
    env.stdout_isatty = True
    env.is_windows = is_windows()
    type

# Generated at 2022-06-21 14:26:36.006975
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    from io import StringIO
    from httpie.core import main
    from httpie import ExitStatus

    args = ['-p', 'pretty']
    env = Environment()
    env.stdout = StringIO()
    env.stderr = StringIO()
    env.argv = args
    args = main.parse_args(args=args, env=env)
    main.configure_logging(args, env)
    exit_status, _, requests_session = main.requests_main(args, env)
    assert exit_status == ExitStatus.OK
    text = '\033[31m' + 'hello kitty' + '\033[0m'
    print(text)

# Generated at 2022-06-21 14:26:44.817191
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test bytes input encoding
    text = b'\x1b[1m\x1b[42m\x1b[31mRED OVER GREEN\x1b[0m'
    stream = list(text)
    fd_stderr = StringIO()
    write_stream_with_colors_win_py3(stream, fd_stderr, flush=False)
    assert fd_stderr.getvalue() == '\x1b[1m\x1b[42m\x1b[31mRED OVER GREEN\x1b[0m'

    # Test bytes input decoding

# Generated at 2022-06-21 14:26:56.670658
# Unit test for function write_stream
def test_write_stream():
    # TODO: Test for function
    pass

# Generated at 2022-06-21 14:27:07.147169
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli import parser

    class RequestsResponse: pass
    args = parser.parse_args(args=["--pretty", "none", "https://example.com"])
    env = Environment(stdin=None,
                      stdout=None,
                      stderr=None,
                      color=False,
                      download_dir=None,
                      config_dir=None,
                      config_path=None,
                      is_windows=False,
                      stdin_isatty=False,
                      stdout_isatty=True,
                      stdout_redirected=False
                      )

    r = RequestsResponse()

# Generated at 2022-06-21 14:27:14.864586
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class args:
        prettify = None
        stream = False
    class env:
        stdout_isatty = True
    class requests_response:
        status_code = 200
        headers = {'a': 'b'}
        url = '/'
        request = None

    y = list(build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_response,
        with_headers=True,
        with_body=True,
    ))

    assert len(y) == 1
    assert y[0] == b'HTTP/1.0 200 OK\r\n\r\n\n\n'

# Generated at 2022-06-21 14:27:23.235721
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import copy
    import httpie
    import httpie.cli
    from httpie import ExitStatus
    from httpie.compat import urlopen
    from httpie.core import main
    from utils import http, HTTP_OK, UnknownJSON
    from fixtures import FILE_PATH, FILE_CONTENT, FILE_PATH_ARG
    from httpie.input import URL
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream

    env = Environment(
        stdin=open(os.devnull),
        stdout=open(os.devnull, 'wb'),
        stderr=open(os.devnull, 'wb')
    )
    args = httpie.cli.parser.parse_args()

    resp = requests.Response()
    resp.status_

# Generated at 2022-06-21 14:27:26.545768
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    # Assume stdout is writeable
    assert io.open(sys.stdout.fileno(), 'wb', closefd=False)

# Generated at 2022-06-21 14:27:36.575946
# Unit test for function write_stream
def test_write_stream():
    data = [b'hello_world\n', b'test_write_stream\n']

    class Stream(object):
        def __init__(self):
            self.data = data
            self.current_pos = 0

        def __iter__(self):
            return self

        def __next__(self):
            try:
                ret = self.data[self.current_pos]
                self.current_pos += 1
                return ret
            except IndexError:
                raise StopIteration

    class StreamFile(object):
        def __init__(self):
            self.data = b''

        def write(self, content):
            self.data += content

        def flush(self):
            pass

    class IOFile(object):
        def __init__(self):
            self.data = b''


# Generated at 2022-06-21 14:27:44.239891
# Unit test for function write_message
def test_write_message():
    import sys
    import requests
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    from httpie.cli.parser import get_parser
    args = get_parser().parse_args(['http://httpbin.org/get'])
    env = Environment()
    args.output_options = {'stream': True}
    r_req = requests.PreparedRequest()
    r_req.headers = {'test_h': 'test_h'}
    r_req.url = 'http://httpbin.org/get'
    r_req.body = 'test_b'

# Generated at 2022-06-21 14:27:52.949004
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    env = Environment()
    requests_message = requests.PreparedRequest()
    # NOTE: `env.stdout` will in fact be `stderr` with `--download`
    outfile = env.stdout
    outfile.write("some_text")
    outfile.flush()
    args = argparse.Namespace()
    args.prettify = 'colors'
    args.style = 'default'
    args.json = False
    args.format_options = []

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-21 14:27:59.755948
# Unit test for function write_message
def test_write_message():
    requests_message = requests.Response()
    
    args = argparse.Namespace()
    args.prettify = ['none']
    args.stream = False
    args.json = False
    args.format_options = dict()
    
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdout_isatty = True
    env.is_windows = False
    
    with_headers = False
    with_body = True
    
    for chunk in write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_headers=with_headers,
        with_body=with_body,
    ) :
        sys.stdout.buffer.write(chunk)



# Generated at 2022-06-21 14:28:07.361362
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify=None,
                              stream=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    expected_stream_class = EncodedStream
    expected_stream_kwargs = {}
    assert stream_class == expected_stream_class
    assert stream_kwargs == expected_stream_kwargs

# Generated at 2022-06-21 14:28:38.551852
# Unit test for function write_message
def test_write_message():
    class Dummy:

        def __init__(self, message):
            self.body = message

    class Dummy2:

        def __init__(self, message):
            self.request = Dummy(message)
            self.response = Dummy(message)

    def test_write_stream(stream, file, flush):
        pass

    request_message = Dummy2('hello')
    args = argparse.Namespace(stream='False')
    env = Environment()
    write_message(
        requests_message=request_message,
        env=env,
        args=args,
        with_headers=False,
        with_body=False,
    )

# Generated at 2022-06-21 14:28:46.636003
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment(
        stdin=io.BytesIO(),
        stdout=io.BytesIO(),
        stderr=io.BytesIO(),
        is_windows=False,
        stdout_isatty=False,
    )
    args = argparse.Namespace(
        download=False,
        stream=True,
        output_stream=None,
        verbose=False,
        debug=False,
    )
    url = 'http://example.org/0'
    method = 'get'
    r = requests.Request(method=method, url=url)
    prepared = r.prepare()

# Generated at 2022-06-21 14:28:57.155278
# Unit test for function write_message
def test_write_message():
    class TestClass(HTTPRequest):
        def __init__(self, status_code):
            self.status_code = status_code
            self.text = 'Response'
            self.body = self.text.encode('utf-8')
            self.headers = {'Content-Type': 'text/html; charset=utf-8'}
            self.raw = b''
            self.request = b''
            self.reason = 'Reason'
    class TestClass2(HTTPRequest):
        def __init__(self, status_code):
            self.status_code = status_code
            self.text = 'Response'
            self.body = self.text.encode('utf-8')
            self.headers = {'Content-Type': 'text/html; charset=utf-8'}

# Generated at 2022-06-21 14:29:04.197017
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.stream = False
    args.prettify = False

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == EncodedStream
    assert not stream_kwargs

    args.prettify = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert isinstance(stream_kwargs['conversion'], Conversion)
    assert isinstance(stream_kwargs['formatting'], Formatting)



# Generated at 2022-06-21 14:29:07.047045
# Unit test for function write_message
def test_write_message():
    assert write_message(requests_message="toto", env="toto", args="toto", with_headers="toto", with_body="toto")


# Generated at 2022-06-21 14:29:09.928327
# Unit test for function write_message
def test_write_message():
    data="Hello world!"
    args = argparse.Namespace()
    env = Environment()
    with open('test_msg.txt', 'w') as f:
        write_message(data,env,args,with_body=True)


# Generated at 2022-06-21 14:29:10.549857
# Unit test for function write_message
def test_write_message():
    pass


# Generated at 2022-06-21 14:29:19.866413
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import tempfile
    from httpie.output.streams import SimpleRedirectStream
    from httpie.output.streams.base import color
    # This only applies for windows and python 3 with colorized terminal output
    if sys.platform != 'win32' or sys.version_info < (3,):
        return
    # Create a stream with some colorized and non-colorized output
    class ColorEnabledStream(SimpleRedirectStream):
        @property
        def color_enabled(self):
            return True
    stream = ColorEnabledStream()
    stream.write(color('foo', fg='red'))
    stream.write(b'bar')
    stream.write(color('baz', fg='green'))
    # Write the stream output to a file
    fd, path = tempfile.mkstemp()


# Generated at 2022-06-21 14:29:24.194065
# Unit test for function write_stream
def test_write_stream():
    # Temporary file to write stream
    testTemp = namedtemporaryfile()

    # Test with RawStream
    stream = RawStream(msg=HTTPResponse("test"))
    write_stream(stream=stream, outfile=testTemp, flush=False)
    testTemp.seek(0)
    assert testTemp.read() == b"test"
    testTemp.seek(0)
    testTemp.truncate()

    # Test with EncodedStream
    stream = EncodedStream(msg=HTTPResponse("test"), env="utf8")
    write_stream(stream=stream, outfile=testTemp, flush=False)
    testTemp.seek(0)
    assert testTemp.read() == b"test"
    testTemp.seek(0)
    testTemp.truncate()

    # Test with PrettyStream

# Generated at 2022-06-21 14:29:31.491066
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    buffer = BytesIO()
    outfile = TextIOWrapper(buffer, encoding='utf-8')
    outfile.write('X')
    stream = [b'\x1b[1m', b'foo', b'\x1b[0m']

    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False
    )

    assert buffer.getvalue() == b'X\x1b[1mfoo\x1b[0m'

# Generated at 2022-06-21 14:30:21.231783
# Unit test for function write_stream
def test_write_stream():
    import sys
    stdout = sys.stdout
    sys.stdout = open(os.devnull,'w')
    stdout_isatty = True
    stdout = sys.stdout
    outfile = stdout
    buffer = outfile
    flush = True
    buf = buffer
    for chunk in stream:
        buf.write(chunk)
        if flush:
            outfile.flush()
    sys.stdout = stdout

# Generated at 2022-06-21 14:30:31.505984
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream, RawStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPResponse
    import requests
    from httpie.compat import is_windows
    from httpie.cli import parser

    args = parser.parse_args(args=[])
    args.stream = False
    args.prettify = []
    env = Environment(
        stdout=None,
        stdin=None,
        stdout_isatty=False,
        stdin_isatty=False
    )
    assert(get_stream_type_and_kwargs(env, args) == (RawStream,
                                                     {'chunk_size': RawStream.CHUNK_SIZE}))



# Generated at 2022-06-21 14:30:32.240177
# Unit test for function write_message
def test_write_message():
    write_message()

# Generated at 2022-06-21 14:30:43.645064
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment

    # should be the same regardless of stream
    initialization_list = []
    for i in range(2):
        stream_type, kwargs = get_stream_type_and_kwargs(Environment(),
                                                         argparse.Namespace(prettify=['colors',
                                                                                      'headers'],
                                                                            stream=True))
        initialization_list.append(stream_type)
        initialization_list.append(kwargs)

# Generated at 2022-06-21 14:30:44.745526
# Unit test for function write_stream
def test_write_stream():
    write_stream(None, None, False)

# Generated at 2022-06-21 14:30:47.706114
# Unit test for function write_stream
def test_write_stream():
    outfile = StringIO()
    stream = BaseStream(b'a\nb\nc')
    write_stream(stream, outfile, False)
    assert outfile.getvalue() == 'a\nb\nc'

# Generated at 2022-06-21 14:30:58.138143
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import BaseStream

    class Stream(BaseStream):
        def __init__(self, text):
            self.text = text.encode()

        def __iter__(self):
            yield self.text

    class FallbackStream(BaseStream):
        def __iter__(self):
            yield b'c%s' % b'\x1b['
            yield b'%sc' % b'\x1b['

    color = b'\x1b['
    class StreamWithColor(Stream):
        def __iter__(self):
            yield color
            yield b'c'
            yield color
            yield b'%sc' % color


# Generated at 2022-06-21 14:31:09.470888
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    parser = argparse.ArgumentParser()
    group = parser.add_argument_group('Output options')
    group.add_argument(
        '--style', action='store', dest='style', metavar='STYLE',
        help='Syntax highlighting style (solarized, monokai, ...). '
             'See http://pygments.org/docs/styles/'
    )
    group.add_argument(
        '-p', '--prettify', action='append', dest='prettify',
        help='Prettify the request, response and debug output. '
             'Choices: all, colors, format, headers, body, '
             'status, cookies. Default: all.',
        default=[],
        type=lambda choices: [c.strip() for c in choices.split(',')]
    )

# Generated at 2022-06-21 14:31:17.351982
# Unit test for function write_message
def test_write_message():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    env = Environment()
    env.stdout = sys.stdout
    class MockPreparedRequest:
        def __init__(self):
            self.body = 'test data'
        def _encode_method(self):
            return 'test data'
        def _encode_url(self):
            return 'test data'
        def _encode_body(self):
            return 'test data'
    class MockResponse:
        def __init__(self):
            self.body = 'test data 2'
        def _encode_body(self):
            return 'test data 2'
    prepared_request = MockPreparedRequest()
    response = MockResponse()

# Generated at 2022-06-21 14:31:26.677602
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import httpie.cli.argtypes as argtypes
    import httpie.cli.parser as parser
    import httpie.output.util as output_util
    from httpie import ExitStatus
    from httpie.input import DEFAULT_HASH
    from httpie.cli.parser import default_options
    from httpie.constants import DEFAULT_UA

    parser.DEFAULT_OPTIONS = default_options
    parser.DEFAULT_UA = DEFAULT_UA
    output_util.__name__ = "output_util"

    # Dummy request

# Generated at 2022-06-21 14:32:28.968620
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.compat import is_windows
    from httpie.output import stream
    if not is_windows():
        return

    buf = StringIO()

    # buffer is for binary data
    buf.buffer = StringIO()

    # text mode
    buf.encoding = 'utf8'

    buf.flush = lambda: None

    write_stream_with_colors_win_py3(
        stream.BaseStream(b'some string'),
        buf,
        False
    )

    assert buf.buffer.getvalue() == ''

    write_stream_with_colors_win_py3(
        stream.BaseStream(b'\x1b[32msome string\x1b[0m'),
        buf,
        False
    )

    assert buf.buffer.getvalue()

# Generated at 2022-06-21 14:32:37.081714
# Unit test for function write_message
def test_write_message():
    args = argparse.Namespace(type='json')
    env = Environment(
        stdout=sys.stdout,
        stdout_isatty=True,
        stdin_isatty=True,
        colors=256,
        is_windows=False,
        stdin=sys.stdin,
        stderr=sys.stderr,
        stdin_allowed=True,
        output_options=Args(args)
    )
    requests_message = requests.PreparedRequest(
        method='GET',
        url='http://httpbin.org/get'
    )
    write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_body=True,
        with_headers=True
    )

# Generated at 2022-06-21 14:32:41.180445
# Unit test for function write_message
def test_write_message():
    class RequestsMessage:
        pass
    requests.Response.is_body_upload_chunk = False
    requests.Response.raw.readable = True
    requests.Response.content = [b'hello world']
    r = requests.Response()
    r.status_code = 200
    r.headers["Content-Type"] = "text/html"
    environment = Environment(
    )
    args = argparse.Namespace()
    write_message(
        args=args,
        env=environment,
        requests_message=r,
        with_body=True,
        with_headers=True,
    )

# Generated at 2022-06-21 14:32:50.324229
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.formatter import JSONFormatter
    from httpie.cli import parser
    from httpie.context import Environment, Environment
    from httpie.config import Config
    from httpie import ExitStatus
    from httpie.output.streams import (
        RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    )
    from httpie.compat import is_py35
    from httpie.constants import DEFAULT_CONFIG_DIR
    from httpie.downloads import (
        parse_content_range, filename_from_content_disposition, filename_from_url
    )
    from httpie.models import (
        ContentType, HTTPAuth, HTTPRequest, HTTPResponse, Params,
        URL, HTTPExchange
    )

# Generated at 2022-06-21 14:32:59.871857
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        stdin=sys.stdin,
        stdin_isatty=False,
        stdout=sys.stdout,
        stdout_isatty=True,
        stderr=sys.stderr,
        stderr_isatty=True,
        color=True,
    )
    args = argparse.Namespace(debug=False, download=False,
                              form=False, headers=False,
                              prettify=None, style='default',
                              json=False, traceback=False,
                              output_file=None, verbose=False,
                              verify=True, stream=False,
                              output_options=None)

# Generated at 2022-06-21 14:33:10.864126
# Unit test for function write_message

# Generated at 2022-06-21 14:33:18.893079
# Unit test for function write_message
def test_write_message():
    import sys
    import json
    import requests
    _env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdin_isatty=sys.stdin.isatty(),
        stdout_isatty=sys.stdout.isatty(),
        is_windows=sys.platform.startswith('win'),
    )

# Generated at 2022-06-21 14:33:25.830618
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import RawStream
    stream_klass = RawStream
    stream = stream_klass(
        msg=HTTPRequest('GET http://httpbin.org HTTP/1.1\r\n\r\n'),
        with_headers=True,
        with_body=True,
    )
    stream_out = StringIO()
    write_stream_with_colors_win_py3(stream, stream_out, flush=True)
    assert stream_out.getvalue() == ''

# Generated at 2022-06-21 14:33:28.749235
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace()
    write_message(requests.PreparedRequest(), env, args)
    write_message(requests.Response(), env, args)

# Generated at 2022-06-21 14:33:38.225432
# Unit test for function write_message
def test_write_message():
    import json
    import requests
    env = Environment()
    args = argparse.Namespace(prettify='all', style='parzen')
    with requests.Session() as s:
        r = s.get('http://test.com/test')
        write_message(r, env, args)
        assert 'test' in env.stdout.read().decode('utf-8')
        r = s.get('http://test.com/test', '{}')
        env.stdout.seek(0)
        write_message(r, env, args)
        assert 'test' in env.stdout.read().decode('utf-8')