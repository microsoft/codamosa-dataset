

# Generated at 2022-06-21 14:24:06.903529
# Unit test for function write_message
def test_write_message():
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdout_isatty = False
    args = argparse.Namespace()
    args.stream = True
    args.prettify = ['all']
    write_message(None, env, args, with_body=True, with_headers=True)

# Generated at 2022-06-21 14:24:14.982278
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import sys
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream, BufferedPrettyStream, RawStream, PrettyStream
    from httpie.cli import parser
    args = parser.parse_args()
    env = Environment()
    assert (EncodedStream, {'env': env}) == get_stream_type_and_kwargs(env, args)
    args.prettify = ['colors']
    assert (BufferedPrettyStream, {'conversion': Conversion(), 'env': env, 'formatting': Formatting(args, env), 'pretty_stream': sys.stdout.buffer}) == get_stream_type_and_kwargs(env, args)
    args.stream = True

# Generated at 2022-06-21 14:24:19.241179
# Unit test for function write_stream
def test_write_stream():
    import io

    import sys

    stream = io.BytesIO()
    stream.write(b'foobar')
    stream.seek(0)
    outfile = io.StringIO()

    write_stream(stream, outfile, False)

    assert outfile.getvalue() == 'foobar'


# Generated at 2022-06-21 14:24:20.090878
# Unit test for function write_message
def test_write_message():
    requests.PreparedRequest
    requests.Response
    HTTPRequest

# Generated at 2022-06-21 14:24:26.139681
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import mock
    import httpie
    args = httpie.cli.parser.parse_args(['--form', '--verbose'])
    args = mock.Mock(**{'__dict__': args.__dict__})
    env = Environment()
    env = mock.Mock(**{'__dict__': env.__dict__})
    del env.__dict__['headers']
    env.__dict__['stdout'] = sys.stdout
    env.__dict__['stdout_isatty'] = True
    env.__dict__['stdin_isatty'] = True
    env.__dict__['stdin'] = sys.stdin
    env.__dict__['stderr'] = sys.stderr

# Generated at 2022-06-21 14:24:35.070042
# Unit test for function write_message
def test_write_message():
    print('Case-1: --json or --stream')
    env = Environment()
    args = argparse.Namespace()
    args.prettify = []
    args.json = []
    args.stream = []
    write_message(None, env, args)
    args.json = [1]
    write_message(None, env, args)
    args.stream = [1]
    write_message(None, env, args)

    print('Case-2: other')
    args.prettify = ['colors']
    args.json = []
    args.stream = []
    write_message(None, env, args, True, True)

# Generated at 2022-06-21 14:24:46.455967
# Unit test for function write_message
def test_write_message():
    args =  argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.format_options = {}
    env =  Environment()
    env.stdout_isatty = True
    env.stdout = sys.stdout

    # Test with_headers and with_body
    with_headers = True
    with_body = True
    res = requests.Response()
    res.url = 'https://httpbin.org/headers'
    res.request = requests.PreparedRequest()
    res.request.body = 'hello'
    res.content = b'{"hello": "world"}'
    res.headers = {"hello": "world"}

# Generated at 2022-06-21 14:24:57.539288
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    from httpie.output import streams
    from httpie.output.streams.stream import CHUNK_SIZE

    from tests.utils import MockEnvironment

    args = parser.parse_args([])
    # Environment
    env = MockEnvironment(stdout_isatty=False, colors=256)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == streams.RawStream
    assert stream_kwargs == {'chunk_size': CHUNK_SIZE}

    # False, False
    env = MockEnvironment(stdout_isatty=False, colors=256)
    args = parser.parse_args([])

# Generated at 2022-06-21 14:25:09.011549
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import argparse

# Generated at 2022-06-21 14:25:16.405432
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        colors=256,
        stdin_isatty=True,
        stdout_isatty=True
    )
    args = argparse.Namespace(
        prettify='all',
        style='hello',
        format_options={},
        stream=True,
        json=True
    )
    (stream_type, stream_kwargs) = get_stream_type_and_kwargs(env, args)
    assert stream_type is PrettyStream
    assert stream_kwargs.keys() == {'env', 'conversion', 'formatting'}
    assert stream_kwargs['env'] is env
    assert stream_kwargs['conversion'] is not None
    assert stream_kwargs['formatting'] is not None
    formatting = stream_kwargs['formatting']

# Generated at 2022-06-21 14:25:29.963460
# Unit test for function write_message
def test_write_message():
	requests_message = requests.Response()

# Generated at 2022-06-21 14:25:40.343105
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(
        env=Environment(),
        args={
            'prettify': None,
            'stream': False
        }
    ) == (EncodedStream, {'env': Environment()})


# Generated at 2022-06-21 14:25:50.075120
# Unit test for function write_message
def test_write_message():
    from httpie.output.streams.pretty import NO_PRETTY

    requests_message = requests.PreparedRequest()
    requests_message.body = 'test'
    requests_message.headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
    requests_message.method = 'GET'
    requests_message.url = 'https://test.com/test'

    args = argparse.Namespace(
        download=False,
        pretty=NO_PRETTY,
        stream=False,
        style='test',
        format_options={},
        traceback=False,
        debug=False,
    )

# Generated at 2022-06-21 14:25:59.121170
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace()
    env = Environment()
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    env.stdout_isatty = False
    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': 8192})

    env.stdout_isatty = False
    args.prettify = True
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {'env': env})

# Generated at 2022-06-21 14:26:09.921842
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    env = Environment()
    with open('./httpie/tests/test_file') as f:
        requests_message = requests.Response()
        requests_message.encoding = 'utf-8'
        requests_message.status_code = 200
        requests_message.raw = f
        stream_list = list(build_output_stream_for_message(
            args=args,
            env=env,
            requests_message=requests_message,
            with_headers=True,
            with_body=True
        ))
        # print(''.join(stream_list))
        assert len(stream_list) == 3
        assert stream_list[0].startswith(b'HTTP/1.1 200 OK')


# Generated at 2022-06-21 14:26:20.281620
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    from httpie.output.streams import ColorScheme
    from httpie.constants import DEFAULT_FORMAT
    from httpie.context import Environment

    argv = ['--prettify', 'all']
    args = parser.parse_args(argv)
    env = Environment(vars=args.__dict__)

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class is PrettyStream
    assert stream_kwargs['env'] is env
    assert stream_kwargs['conversion'].__class__.__name__ == 'Conversion'

# Generated at 2022-06-21 14:26:22.515394
# Unit test for function write_stream
def test_write_stream():
    """
    Test write_stream
    """
    outfile = open('mock.txt', 'w')
    # Using the BufferedPrettyStream as the writing stream
    write_stream(
        BufferedPrettyStream(
            msg=None,
            with_headers=True,
            with_body=True,
            env=None,
            conversion=None,
            formatting=None),
        outfile,
        flush=False
    )
    outfile.close()

# Generated at 2022-06-21 14:26:33.543319
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Temporary fix for unit tests on TravisCI
    # https://github.com/jakubroztocil/httpie/issues/1314
    if os.name == 'posix' and sys.version_info[:2] == (3, 5) and os.environ.get('TRAVIS_PYTHON_VERSION') == '3.5':
        return

    # if stdout is a tty and --pretty is used,
    # then PrettyStream is returned
    env = Environment(
        colors=256,
        stdin=io.StringIO(),
        stdout=io.StringIO(),
        stdin_isatty=True,
        stdout_isatty=True,
    )
    args = argparse.Namespace(prettify=['all'])
    assert get_stream_type_and_

# Generated at 2022-06-21 14:26:43.827530
# Unit test for function write_message
def test_write_message():
    import requests
    from httpie.cli import parser
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    env = Environment(stdin=None, stdout=None, stderr=None)
    env.stdout_isatty = False
    env.stdout = None

    args = parser.parse_args(["--json"])
    with_headers=True
    with_body=True

    rsp = requests.Response()
    rsp.status_code=200
    rsp.headers['Content-Type'] = 'application/json'
    rsp.raw = b'{"msg":"hello"}'

# Generated at 2022-06-21 14:26:49.642663
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest
    env = None
    args = argparse.Namespace
    with_headers = True
    with_body = False

    write_message(
        requests_message=requests_message,
        env=env,
        args=args,
        with_headers=with_headers,
        with_body=with_body
    )


# Generated at 2022-06-21 14:27:06.234178
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import json
    import httpie.cli

    parser = httpie.cli.get_parser()
    args = parser.parse_args(['http://www.google.com'])
    env = httpie.cli.Environment()
    r = requests.get("http://www.google.com")
    write_message(
        requests_message=r,
        env=env,
        args=args,
        with_headers=True,
        with_body=True,
    )
    print(r.encoding)
    print(r.text)
    print(r.content)
    print(r.status_code)
    print(r.headers)
    print(r.raw)
    print(r.cookies)
    print(json.dumps(r.history, default=lambda x: x.__dict__))

# Generated at 2022-06-21 14:27:17.380277
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Get stream type and kwargs for a raw stream
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.style = 'solarized'
    args.stream = False
    args.json = False
    args.format_options = {}
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    # Get stream type and kwargs for a raw stream with non-tty env
    env = Environment()
    env.stdout_isatty = False
    args = argparse.Namespace()
    args.prettify = None
    args.style = 'solarized'

# Generated at 2022-06-21 14:27:24.684737
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import tempfile
    env = Environment(
        # env.stdout_isatty = Whether stdout appears to be a tty.
        # env.is_windows = Whether the platform is Windows.
        stdout_isatty=False,
        stdout=tempfile.TemporaryFile(),
        stderr=tempfile.TemporaryFile(),
        is_windows=True,
    )
    # args.prettify = What should be prettified
    # args.prettify, args.style, args.format_options
    # args.stream=Wheter --stream is specified
    args = argparse.Namespace(
        prettify=["all"],
        style="default",
        format_options={},
        stream=False
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs

# Generated at 2022-06-21 14:27:35.034669
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ""
    args.style = ""
    args.json = ""
    args.format_options = ""
    args.stream = True
    env.stdout_isatty = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE}
    args.stream = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE}

# Generated at 2022-06-21 14:27:43.229518
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO

    from httpie import output

    stream = [
        b'\x1b[31mabc',
        b'\x1b[0mdef',
        b'ghi\x1b[0m',
        b'\x1b[32mjkl\x1b[0m',
        b'mno\x1b[31m',
        b'pqr\x1b[0mstu',
    ]
    outfile = StringIO()
    output.write_stream_with_colors_win_py3(stream, outfile, flush=True)

# Generated at 2022-06-21 14:27:49.120161
# Unit test for function write_stream
def test_write_stream():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(Environment(), argparse.Namespace())
    stream_message = stream_class(msg=HTTPRequest("GET / HTTP/1.1\r\n\r\n"),
                                 with_headers=True,
                                 with_body=True,
                                 **stream_kwargs)

    import io
    outfile = io.BytesIO()
    write_stream(stream_message, outfile, True)
    outfile.seek(0)
    value = outfile.read()
    assert value == b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n"

# Generated at 2022-06-21 14:27:56.534648
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    with requests.Session() as s:
        r1 = s.get('http://httpbin.org/get')
        r2 = s.get('http://httpbin.org/redirect/1')
        r3 = s.get('http://httpbin.org/get')
        r4 = s.get('http://httpbin.org/redirect/1')


    res = list(build_output_stream_for_message(args=None,env=None,requests_message=r1, with_headers=True, with_body=True))
    assert not(res[0].endswith(b'\n\n'))

    res = list(build_output_stream_for_message(args=None,env=None,requests_message=r2, with_headers=True, with_body=True))
   

# Generated at 2022-06-21 14:28:07.612902
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.compat import is_windows

    if is_windows():
        class FakeOutfile:
            def __init__(self):
                self.buffer = b''

        class Stream(BaseStream):
            """A stream with colored chunks.
            Usage: for chunk in stream: ...
            """

# Generated at 2022-06-21 14:28:08.287437
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-21 14:28:09.208879
# Unit test for function write_message
def test_write_message():
    assert write_message is not None

# Generated at 2022-06-21 14:28:24.366628
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """check that write_stream_with_colors_win_py3
    works as expected.
    """

    fake_env = Environment(
        stdin=sys.stdin,
        stdin_isatty=False,
        stdout_isatty=True,
        stdout=sys.stdout,
        stderr=sys.stderr
    )

    fake_args = argparse.Namespace(
        stream=False,
        prettify=['colors'],
        style="test",
        json=False,
        format_options={},
        download=None)

    outfile = StringIO()

    # write_stream_with_colors_win_py3 will flush to stderr as this
    # is what is passed in during tests.
    fake_env.stdout = outfile

   

# Generated at 2022-06-21 14:28:33.598552
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    args = parser.parse_args(['--print=hB'])
    env = Environment(stdout_isatty=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class.__name__ == 'PrettyStream'
    assert stream_kwargs['conversion'].__class__.__name__ == 'Conversion'
    assert stream_kwargs['formatting'].__class__.__name__ == 'Formatting'

# Generated at 2022-06-21 14:28:43.589336
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Ensure ANSI colors are output correctly in Windows with Python 3 by
    writing fake colorized bytes to a StringIO object and checking the result.

    """
    import colorama
    colorama.init()
    encoded_stream = EncodedStream(env=Environment())

# Generated at 2022-06-21 14:28:50.600209
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    write_stream_with_colors_win_py3(
        stream=('b\x1b[34mblue\x1b[39m\n' +
                '\x1b[31mred\x1b[39m\n' +
                '\x1b[32mgreen\x1b[39m\n').encode(),
        outfile=None,
        flush=None,
    ) is None


# Generated at 2022-06-21 14:28:59.826135
# Unit test for function write_stream
def test_write_stream():
    # TODO: Shouldn't test this here.
    # TODO: Use request.Request
    class Request:
        method = 'GET'
        path_url = '/foo/bar'
        headers = {'Accept': 'application/json'}

    r = Request()
    headers = {'Content-Type': 'application/json'}
    body = b'{"foo": "bar"}'
    response = requests.Response()
    response.status_code = 200
    response.headers = headers
    response.raw = MockStream()
    response.raw.read = lambda *args, **kwargs: body

    # TODO: Shouldn't test this here.
    class Response:
        status_code = 200
        headers = headers
        body = body


# Generated at 2022-06-21 14:29:09.611408
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    def get_stream_type(env, args):
        return get_stream_type_and_kwargs(env, args)[0]
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    env.stdout_isatty = True
    args.stream = False
    assert get_stream_type(env, args) == EncodedStream
    env.stdout_isatty = False
    assert get_stream_type(env, args) == RawStream
    args.prettify = 'all'
    assert get_stream_type(env, args) == BufferedPrettyStream
    args.prettify = None
    assert get_stream_type(env, args) == RawStream
    args.stream = True
    assert get_stream_type(env, args) == PrettyStream



# Generated at 2022-06-21 14:29:11.439551
# Unit test for function write_stream
def test_write_stream():
    stream = BaseStream()
    outfile = 'outfile'
    flush = True
    write_stream(stream, outfile, flush)


# Generated at 2022-06-21 14:29:12.679412
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-21 14:29:22.270533
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()

    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': 8192})

    env.stdout_isatty = True
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    args.prettify = ['all']
    args.stream = False
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=['all'], color_scheme='ansi', explicit_json=False, format_options={})})

    args.stream = True
    assert get_stream_type_and

# Generated at 2022-06-21 14:29:33.036573
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io

    class StringIO(io.BytesIO):
        """BytesIO that exposes an additional `text` property
        with a string representation.

        """

        def get_text(self):
            text = self.getvalue().decode('utf8')
            self.seek(0)
            self.truncate(0)
            return text

    def test(env, args):
        try:
            import colorama
        except ImportError:
            raise unittest.SkipTest('colorama not installed')
        colorama.init()
        sio = StringIO()
        stream = EncodedStream(
            msg=HTTPRequest('http://httpbin.org/get'),
            with_headers=True,
            with_body=False,
            env=env,
        )
        write_stream_with_colors_win_

# Generated at 2022-06-21 14:29:52.976702
# Unit test for function write_message
def test_write_message():
    message = 'Test'
    env = Environment(stdout=sys.stdout, stderr=sys.stderr)

# Generated at 2022-06-21 14:29:57.937108
# Unit test for function write_message
def test_write_message():
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    args.prettify = "colors"
    args.stream = False
    env = Environment()
    r = requests.get("http://127.0.0.1:5000/")
    write_message(r, env, args, with_body=True, with_headers=True)

# Generated at 2022-06-21 14:30:09.096086
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    from httpie import ExitStatus

    args = httpie.cli.parser.parse_args(['--debug'])
    env = Environment(args, '', stdout_isatty=True)
    response = requests.Response()
    response.status_code = 200
    response.headers['Date'] = '2011-01-01'
    response.headers['Cache-Control'] = 'max-age=60, private'
    response.headers['Content-Type'] = 'application/json; charset=UTF-8'
    response.headers['Set-Cookie'] = 'foo=bar'
    response._content = b'{"a": "A", "c": "C", "b": "B"}'


# Generated at 2022-06-21 14:30:17.452383
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class env_stub:
        def __init__(self):
            self.stdout = sys.stdout

    class requests_response:
        pass

    class requests_prepared_request:
        pass

    env = env_stub()
    args = argparse.Namespace(style='parrot', json=False, stream=False,
                              prettify='colors', debug=False, traceback=False,
                              format_options=None)
    with pytest.raises(KeyError):
        build_output_stream_for_message(env, args, requests_response(), False, False)

    req_msg = build_output_stream_for_message(env, args, requests_prepared_request(), True, True)
    assert(type(req_msg) == types.GeneratorType)

# Generated at 2022-06-21 14:30:19.662570
# Unit test for function write_message
def test_write_message():
    write_message(
        requests_message=requests.PreparedRequest(),
        env='',
        args='',
        with_headers=False,
        with_body=False,
    )

# Generated at 2022-06-21 14:30:22.355709
# Unit test for function write_stream
def test_write_stream():
    outfile = sys.stdout # type: IO
    outfile.encoding = sys.stdout.encoding
    stream = EncodedStream(msg = HTTPResponse(requests.Response()), env = Environment())
    write_stream(stream = stream, outfile = outfile, flush = False)

# Generated at 2022-06-21 14:30:33.026994
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Test encodings that do not encode '\x1b[' to b'\x1b['.
    # These encodings are not used when encoding TEXT streams.
    encodings = ['ascii', 'iso-8859-1', 'iso8859_15', 'cp437', 'mac_roman']
    for encoding in encodings:
        outfile = io.TextIOWrapper(io.BytesIO(), encoding=encoding)
        buf = outfile.buffer
        assert buf.write(b'\x1b[42m') == 4
        assert buf.getvalue() == b'\x1b[42m'
        assert outfile.write('\x1b[42m') == 0
        assert buf.getvalue() == b'\x1b[42m'

    # Test encodings that encode

# Generated at 2022-06-21 14:30:36.452427
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs({}, {}) == (
        EncodedStream, {
            'env': {}
        }
    )



# Generated at 2022-06-21 14:30:46.821534
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import EncodedStream, PrettyStream, RawStream
    from httpie.core import main as core_main
    from httpie.input import HTTP_METHODS

    for method in HTTP_METHODS:
        args = [
            "http",
            "--stream",
            "--prettify",
            "compact",
            "--no-stream",
            "--no-prettify",
            method,
        ]
        args.append("localhost:8000")
        if method != "GET":
            args.append(
                '{{"a": "b", "c": "d", "e": "f", "g": "h", "i": "j"}}',
            )
        env = (
            core_main(args)  # type: ignore
        )

        sut = build

# Generated at 2022-06-21 14:30:47.391604
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    pass

# Generated at 2022-06-21 14:31:13.296420
# Unit test for function write_message
def test_write_message():
    from httpie.core import main

    url = 'http://www.baidu.com'
    argv = [
        'http',
        '--method', 'GET',
        url
    ]
    main(args=argv)

# Generated at 2022-06-21 14:31:20.321797
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from .functions import build_output_stream_for_message
    import requests

    req = requests.Request('GET', 'http://localhost/')
    prep = req.prepare()
    s = build_output_stream_for_message(
        env="",
        args="",
        requests_message=prep,
        with_headers=False,
        with_body=False,
    )
    for chunk in s:
        print(chunk)

# Generated at 2022-06-21 14:31:27.098999
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    env = Environment(stdout=io.StringIO())
    args = argparse.Namespace(stream=False,
                              prettify=False,
                              style='default',
                              json=False,
                              format_options={},)
    message = requests.Response()
    message._content = b'hello world'
    for chunk in build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=message,
        with_body=True,
        with_headers=False,
    ):
        assert chunk == b'hello world'

# Generated at 2022-06-21 14:31:34.489267
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.compat import is_windows_py_3
    from httpie.output.streams import SpinnerFormattedStream
    if not is_windows_py_3:
        return
    args = argparse.Namespace()
    args.prettify = ["colors"]
    args.style = "solarized"
    env = Environment(stdout_isatty=True)
    req = HTTPRequest(requests.PreparedRequest())

# Generated at 2022-06-21 14:31:45.446665
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    request = HTTPRequest(
        [b'httpie-test-url'],
        headers={'test-key': 'test-value'},
        method='test-method',
        body=b'test-body',
    )
    response = HTTPResponse(
        [b'httpie-test-url'],
        headers={'test-key': 'test-value'},
        status_code=200,
        body=b'test-body',
    )
    class Args:
        def __init__ (self):
            self.stream = False
            self.prettify = True
            self.style = 'monokai'
            self.json = True
            self.format_options = {}
            self.debug = True
            self.traceback = False
    args = Args()

# Generated at 2022-06-21 14:31:53.617545
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Simulate console environment
    isatty = True
    # Simulate console encoding
    encoding = 'utf-8'
    env = Environment(isatty, isatty, encoding)
    args = argparse.Namespace()

    # Check for RawStream
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = None
    args.format_options = None
    stream_class, expected = get_stream_type_and_kwargs(env, args)
    assert isinstance(stream_class('dummy'), BufferedPrettyStream)
    assert expected == {}

    # Check for BufferedPrettyStream
    args.prettify = None
    args.stream = True
    args.style = None
    args.json = None
    args.format_options = None
    stream

# Generated at 2022-06-21 14:32:03.926914
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class MockEnv:
        def __init__(self, stdout_isatty=False):
            self.stdout_isatty = stdout_isatty

    class MockArgs:
        def __init__(self, prettify=False, stream=False):
            self.prettify = prettify
            self.stream = stream

    env = MockEnv()
    args = MockArgs()

    # Raw stream
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == RawStream
    assert stream_kwargs == {
        'chunk_size': RawStream.CHUNK_SIZE_BY_LINE
    }

    # Raw stream with --stream
    args.stream = True
    stream_class, stream_kwargs = get_stream_

# Generated at 2022-06-21 14:32:13.752773
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.cli import parser

    args = parser.parse_args(['http://localhost/'])

# Generated at 2022-06-21 14:32:17.817514
# Unit test for function write_stream
def test_write_stream():
    with pytest.raises(IOError):
        write_stream(
            stream=PrettyStream(
                msg=HTTPRequest.from_http(
                    "GET http://example.org/ HTTP/1.1\r\n"
                    "Accept: */*\r\n"
                    "Accept-Encoding: gzip, deflate\r\n"
                    "Host: example.org\r\n",
                    protocol='HTTP/1.1'
                ),
                conversion=Conversion()
            ),
            outfile=BytesIO(),
            flush=False
        )


# Generated at 2022-06-21 14:32:21.823118
# Unit test for function write_stream
def test_write_stream():
    stream = ['test1', 'test2']
    outfile = open("test.txt", "wb")
    write_stream(stream, outfile, False)

# Generated at 2022-06-21 14:32:52.683197
# Unit test for function write_stream
def test_write_stream():
    assert 1==1

# Generated at 2022-06-21 14:33:00.856745
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True,
                      stdin_isatty=True,
                      is_windows=False)
    args = argparse.Namespace(prettify=["colors"],
                              style="paraiso-dark",
                              stream=True,
                              verbose=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs["env"] == env
    assert isinstance(stream_kwargs["conversion"], Conversion)
    assert isinstance(stream_kwargs["formatting"], Formatting)
    assert stream_kwargs["formatting"].env == env
    assert stream_kwargs["formatting"].groups == ["colors"]

# Generated at 2022-06-21 14:33:06.228783
# Unit test for function write_message
def test_write_message():
    file_out = open("test_stream_output.txt", "w+")
    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = False
    write_message(requests_message, env, args, with_headers, with_body)


# Generated at 2022-06-21 14:33:07.160351
# Unit test for function write_stream
def test_write_stream():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 14:33:16.561060
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.core import main
    import pytest
    from httpie.compat import is_windows
    if not is_windows:
        pytest.skip('Windows only')
    import colorama
    colorama.init()
    env = Environment()
    outfile = env.stdout
    env.stdout = None
    env.stdout_isatty = False
    args = main.parser.parse_args(args=['https://httpbin.org/get'])
    requests_message = requests.Response()
    requests_message._content = b'\x1b[33mhello'
    requests_message.status_code = 200

# Generated at 2022-06-21 14:33:19.581006
# Unit test for function write_message
def test_write_message():
    print('----- Start test_write_message -----')

    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    write_message(requests_message, env, args)

    print('----- Done test_write_message -----')


# Generated at 2022-06-21 14:33:29.697722
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import requests
    import json
    import httpie
    import sys

    url = 'http://httpbin.org/get'
    args = httpie.cli.parser.parse_args(args=['GET', url])
    # Build a suitable requests.Response object
    # First, the header
    header = {'Content-Type': 'application/json'}
    # Second, the payload: A get request

# Generated at 2022-06-21 14:33:40.502568
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class FakeEnv(object):
        stdout_isatty = True


    class FakeArgs(object):
        pretty = None
        stream = False
        prettify = []
        style = 'foo'
        json = False
        format_options = {}

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=FakeEnv(),
        args=FakeArgs(),
    )

    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': FakeEnv()}

    class FakeArgs(object):
        pretty = None
        stream = True
        prettify = []
        style = 'foo'
        json = False
        format_options = {}


# Generated at 2022-06-21 14:33:42.270130
# Unit test for function write_stream
def test_write_stream():
    class fake_outfile:
        data = b""

        def write(self, chunk):
            self.data += chunk

    outfile = fake_outfile()
    write_stream(b"hello world", outfile, flush=False)
    assert outfile.data == b"hello world"

# Generated at 2022-06-21 14:33:53.184443
# Unit test for function write_message
def test_write_message():
    """
    This function is used to test write_message function
    """
    import argparse
    import httpie.config
    from httpie.client import BaseSession
    from httpie.context import Environment
    import os
    import requests    
    import sys
    import tempfile
    class CustomSession(BaseSession):
        """HTTPie session."""
        pass
    class FakeStdout(TextIO):
        """A file-like object for outputting to stdout."""
        encoding = 'ascii'
        def __init__(self):
            self.content = ''
            self.read_from_stdin = False
        def write(self, s):
            self.content += s
        def isatty(self):
            return True