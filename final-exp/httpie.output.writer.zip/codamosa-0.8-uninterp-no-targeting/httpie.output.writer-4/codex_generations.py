

# Generated at 2022-06-21 14:24:12.380776
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    from unittest.mock import Mock

    def mock_stdout(data):
        sys.stdout.raw.write(data)

    m = Mock(encoding='utf8', write=mock_stdout, buffer=Mock())
    write_stream_with_colors_win_py3(
        stream=PrettyStream(msg=Mock(), env=Mock(), with_headers=True,
                            with_body=True, conversion=Conversion(),
                            formatting=Formatting(env=Mock(), groups=['colors'])),
        outfile=m,
        flush=False
    )

# Generated at 2022-06-21 14:24:16.956968
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(prettify=['colors'], style='paraiso-dark', json=False, stream=False, format_options=None)
    env = Environment()
    stream_type = get_stream_type_and_kwargs(env=env,args=args)[0]
    assert stream_type == PrettyStream

# Generated at 2022-06-21 14:24:20.171681
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from .helpers import http, httpbin

    stream = write_stream_with_colors_win_py3(
        stream='stream',
        outfile='outfile',
        flush=False,
    )
    assert stream == 'stream'

# Generated at 2022-06-21 14:24:26.177321
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    from tests.test_utils import TESTS_ROOT, load_json
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import PrettyStream
    # The env in which the message will be written
    env = Environment()
    # A request that can be produced by httpie.
    url = "https://httpie.org"
    args = argparse.Namespace()
    # The request that must be sent to the server
    request = HTTPRequest(url, headers={"User-agent": "HTTPie/2.2.0-dev0"},
                          method="GET", body="{}")
    # The response that must be received by the client

# Generated at 2022-06-21 14:24:36.560108
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    args = argparse.Namespace(
            output_options=[],
            output_format='text',
            stream=True,
            style='none',
            pretty='all',
            traceback=False,
            json=False,
            format_options=[],
            output_file=None,
            )
    r = requests.get('http://www.google.com')
    env = Environment(
            # stubs
            args=args,
            stdout_isatty=True,
            is_windows=(os.name == 'nt'),
            stdout=sys.stdout,
            stderr=sys.stderr,
            )
    with_headers = True
    with_body = True

# Generated at 2022-06-21 14:24:48.049362
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    print()
    # Write a stdout stream to a text file
    env = Environment(
        colors=256,
        stdin_isatty=True,
        stdout_isatty=True,
        stderr_isatty=True
    )
    args = argparse.Namespace(
        json=False,
        pretty='all',
        style='paraiso-dark',
        prettify=None,
        print_body='',
        stream=False,
        output_file=None,
        print_headers='',
        ignore_stdin=False,
        debug=False,
        traceback=False,
        verbose=False,
        output_options=[]
    )
    with open('test_output.txt', 'w') as outfile:
        test_request = requests.PreparedRequest()

# Generated at 2022-06-21 14:25:00.135223
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import sys
    import argparse
    from io import StringIO

    from httpie import output

    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli.parser import parser

    from httpie.output.streams import PrettyStream, EncodedStream
    from httpie.output.processing import (
        Conversion,
        Formatting,
    )

    def parse_args(args):
        return parser.parse_args(args, env=Environment())

    args = parse_args([])
    env = args.__dict__.pop('env')

    # Testing the case where --must-prettify is False

    args = parse_args(['--stream', '-f', 'json'])
    env.is_windows = False
    env.stdout

# Generated at 2022-06-21 14:25:10.995778
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        stdout=StringIO(),
        stdout_isatty=False)
    parser = argparse.ArgumentParser()
    parser.add_argument('prettify', nargs='?')
    args = parser.parse_args([])
    assert get_stream_type_and_kwargs(env, args) == (RawStream, {
        'chunk_size': RawStream.CHUNK_SIZE
    })

    parser = argparse.ArgumentParser()
    parser.add_argument('prettify', nargs='?')
    parser.add_argument('--stream', action='store_true')
    args = parser.parse_args(['--stream'])

# Generated at 2022-06-21 14:25:16.573923
# Unit test for function write_stream
def test_write_stream():
    import io
    import os

    with io.BytesIO() as f:
        # f.write(b'hello')
        write_stream(
            stream=b'hello',
            outfile=f,
            flush=True
        )
        data = f.getvalue()
        print(data)
        for chunk in data:
            chunk = chunk.decode()
            print(chunk)
        assert data == b'hello'

# Generated at 2022-06-21 14:25:27.699209
# Unit test for function write_stream
def test_write_stream():
    """
    单元测试函数write_stream
    """
    import sys
    import unittest

    import httpie.output.streams
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, \
        PrettyStream, RawStream

    test_string = 'ertyuiytyui' * 20

    class _TestRequest:

        @property
        def headers(self):
            return {}

        def iter_content(self, size):
            yield test_string.encode()

    class _TestResponse:

        @property
        def headers(self):
            return {}

        def iter_content(self, size):
            yield test_string.encode()

        @property
        def is_redirect(self):
            return False


# Generated at 2022-06-21 14:25:45.106466
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli.parser
    env = Environment()
    args = httpie.cli.parser.parse_args(['http://127.0.0.1', '-v'])
    resp = requests.Response()
    resp._content = b'helloworld'
    resp.status_code = 200
    resp.headers = {'content-length': 10}
    resp.request = requests.Request(method='GET', url='http://127.0.0.1')
    stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=resp,
        with_headers=True,
        with_body=True
    )
    for _ in stream:
        assert _.startswith(b'HTTP/1.1 200 OK\r\n')

# Generated at 2022-06-21 14:25:54.825725
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace(prettify = 'True')
    requests_message = requests.Response()
    for chunk in build_output_stream_for_message(requests_message, env, args,
                                                 with_headers=False,
                                                 with_body=False):
        print("Chunk is %s" % chunk)
    print("=====")
    for chunk in build_output_stream_for_message(requests_message, env, args,
                                                 with_headers=True,
                                                 with_body=True):
        print("Chunk is %s" % chunk)


# Generated at 2022-06-21 14:26:06.953100
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.output.streams import JSONStream, PrettyStream
    from httpie.output.processing import Conversion

    request = HTTPRequest("POST", "http://localhost/path", "abc")
    response = HTTPResponse("200", "OK", "\n", [], [])

    # Write pretty
    args = argparse.Namespace(verbose=False, prettify="all", style="monokai",
                              stream=True, output_options=None, json=False,
                              debug=False, traceback=False, format_options=[],
                              output_file=None)

# Generated at 2022-06-21 14:26:13.431060
# Unit test for function write_stream
def test_write_stream():
    """
    Unit test for function write_stream
    :return:
    """
    # File setup
    file = open("/tmp/test_file.txt", "w+")
    file.write("test string")
    file.close()
    file = open("/tmp/test_file.txt", "r+")

    # Test setup

# Generated at 2022-06-21 14:26:14.437808
# Unit test for function write_message
def test_write_message():
    env = Environment()




# Generated at 2022-06-21 14:26:23.778059
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import os
    import shutil
    import tempfile
    import filecmp

    tempdir = tempfile.mkdtemp()
    # Create files used to compare results
    temp_file_1 = os.path.join(tempdir, "temp_file_1")
    expected_temp_file_1 = os.path.join(tempdir, "expected_temp_file_1")
    with open(temp_file_1, 'wb') as f:
        f.write(b'abc\x1b[31mdef\x1b[0m')
    with open(expected_temp_file_1, 'w') as f:
        f.write("abc\x1b[31mdef\x1b[0m")

    temp_file_2 = os.path.join(tempdir, "temp_file_2")

# Generated at 2022-06-21 14:26:28.116727
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True)
    args = argparse.Namespace(prettify='b', stream=False, style='none')
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert isinstance(stream_class, type)

# Generated at 2022-06-21 14:26:31.368677
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    out_stream = build_output_stream_for_message(args, env, requests_message, with_headers=True, with_body=True)
    assert isinstance(out_stream,BaseStream)



# Generated at 2022-06-21 14:26:40.317102
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace(prettify=['body'], style='fancy')
    requests_message = requests.PreparedRequest()
    requests_message.body = 'Hello world'
    requests_message.headers['Content-Type'] = 'text/plain'
    requests_message.url = 'http://httpbin.org'
    requests_message.method = 'GET'
    out = write_message(requests_message, env, args, with_body=True, with_headers=True)
    assert out is not None

# Generated at 2022-06-21 14:26:43.826951
# Unit test for function write_stream
def test_write_stream():
    import io
    outfile = io.BytesIO()
    messages = [
        b'{"hello": "world"}',
        b'{"second": "message", "try": true}',
    ]

    write_stream(messages, outfile, True)
    assert outfile.getvalue() == b''.join(messages)

# Generated at 2022-06-21 14:26:58.116247
# Unit test for function write_stream
def test_write_stream():
    class TestStream(BaseStream):
        def __init__(self, data):
            self.data = data

        def __iter__(self):
            for i in self.data:
                yield i

    f = open('test_write_stream.txt', 'w')
    data = [b"1", b'2', b'3']
    write_stream(TestStream(data), f, False)
    f.close()

test_write_stream()

# Generated at 2022-06-21 14:27:08.596815
# Unit test for function write_stream
def test_write_stream():
    from httpie import exit_status
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import build_output_stream_for_message, write_stream
    from httpie.cli import parser
    from httpie.compat import str
    args = parser.parse_args(
        args=[
            '--pretty=all',
            '--style=paraiso-dark',
            'https://httpbin.org/get',
        ]
    )
    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        is_windows=(sys.platform == 'win32'),
        colors=256,
        prefer_ipv6=False,
    )
    response

# Generated at 2022-06-21 14:27:19.810957
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    from httpie.context import Environment
    import argparse

    env = Environment()
    args=argparse.Namespace()
    env.stdout_isatty = False
    args.prettify = True
    args.stream = True
    args.style = ['solarized']
    args.json = True
    args.format_options = [0, 1]
    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(env=env, args=args)
    assert isinstance(stream_class, PrettyStream)
    assert isinstance(stream_kwargs['formatting'].env, Environment)
    assert isinstance(stream_kwargs['formatting'].groups, list)

# Generated at 2022-06-21 14:27:26.235608
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import io
    import unittest

    class TestEnvironment(object):
        stdout_isatty = True

    class TestArgParse(object):
        prettify = False
        stream = False
        style = "default"
        json = False
        format_options = {}

    class TestArgParse1(object):
        prettify = "body,headers,history"
        stream = False
        style = "default"
        json = False
        format_options = {}

    class TestArgParse2(object):
        prettify = "body,headers,history"
        stream = True
        style = "default"
        json = False
        format_options = {}

    class TestArgParse3(object):
        prettify = "headers,history"
        stream = False
        style = "default"
        json = False

# Generated at 2022-06-21 14:27:36.365838
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace()
    request1 = HTTPRequest(requests.PreparedRequest())
    request2 = HTTPRequest(requests.PreparedRequest())
    response1 = HTTPResponse(requests.Response())
    response2 = HTTPResponse(requests.Response())

    for message in [request1, request2, response1, response2]:
        for with_headers in [False, True]:
            for with_body in [False, True]:
                msg = message.message
                if with_headers:
                    msg.headers = {'injected-header': 'injected-header'}
                if with_body:
                    msg.raw = b'abc'


# Generated at 2022-06-21 14:27:45.306891
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import json
    import pwd
    from mock import patch
    import platform
    import subprocess

    class FakeArgparseNamespace(object):
        def __init__(self):
            self.stream = False
            self.prettify = ["colors"]
            self.style = "solarized"
            self.json = False
            self.format_options = {}
            self.debug = False
            self.traceback = False

    class FakeEnv(object):
        def __init__(self):
            self.stdout_isatty = False
            self.is_windows = False

    def build_stream_test(with_headers, with_body):
        args = FakeArgparseNamespace()
        env = FakeEnv()
        response_dict = {}

# Generated at 2022-06-21 14:27:54.028923
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    from httpie.output.streams import BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    args = argparse.Namespace(prettify=[], stream=False, style='foo', json=False)
    env = Environment()

    env.stdout_isatty, args.prettify, args.stream = False, False, False
    assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE})
    env.stdout_isatty, args.prettify, args.stream = False, False, True

# Generated at 2022-06-21 14:28:00.607262
# Unit test for function write_message
def test_write_message():
    from io import StringIO
    from httpie.core import main
    from subprocess import Popen, PIPE

    env = Environment()

# Generated at 2022-06-21 14:28:01.942954
# Unit test for function write_message
def test_write_message():
    (write_message())

# Generated at 2022-06-21 14:28:13.430480
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream
    env = Environment()
    args = argparse.Namespace(
        style='native',
        colors='16',
        prettify='all',
        format_options=[],
        json=True,
        download=False,
        stream=False
    )
    cls, kwargs = get_stream_type_and_kwargs(env, args)
    assert cls, PrettyStream
    assert kwargs['env'], env

# Generated at 2022-06-21 14:28:28.278743
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace(prettify={}, style={}, json={}, format_options={})

    stream_class_1, stream_kwargs_1 = get_stream_type_and_kwargs(env, args)
    assert stream_class_1.__name__ == "EncodedStream"
    assert stream_kwargs_1 == {'env': env}

    args.prettify = "colors"
    args.style = "frozen"
    args.format_options = {}
    stream_class_2, stream_kwargs_2 = get_stream_type_and_kwargs(env, args)
    assert stream_class_2.__name__ == "PrettyStream"
    assert stream_kwargs_2["env"] == env

# Generated at 2022-06-21 14:28:40.071364
# Unit test for function write_message
def test_write_message():
    import pytest

    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.compat import is_py26

    args = parser.parse_args([
        '--verbose',
        '--prettify', 'all',
        '--style', 'solarized',
        '--stream',
        '--format-options', 'colors.request.headers=on'
    ])
    env = Environment(stdin=None, stdout=None, stderr=None, vars=None)

    with pytest.raises((KeyboardInterrupt, BrokenPipeError)):
        write_message(None, env, args, with_headers=False, with_body=False)

# Generated at 2022-06-21 14:28:49.037343
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    # import httpie.output
    from httpie.config import Config
    from httpie.context import Environment
    from httpie import output
    from httpie import streams
    from httpie.input import ParseError, KeyValue
    from httpie.models import Environment as _Environment
    from httpie.cli import parser
    from httpie.output.streams import EncodedStream

    output.streams = streams
    env = Environment(_Environment())
    args = httpie.cli._get_args(parser, [])
    args.headers = None
    args.prettify = None
    args.style = None
    args.json = None
    args.form = None
    args.stream = False


# Generated at 2022-06-21 14:28:59.160615
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.core import main
    from httpie.output.streams import RawStream, EncodedStream, PrettyStream
    env = Environment()
    args = main.parser.parse_args(['--stream', '--prettify'], env=env)
    assert (PrettyStream, {'env': env, 'conversion': Conversion(),
           'formatting': Formatting(env, ['all'], 'default', False, {}, None)}) == get_stream_type_and_kwargs(env, args)

    args = main.parser.parse_args(['--style', 'google'], env=env)
    assert (EncodedStream, {'env': env}) == get_stream_type_and_kwargs(env, args)


# Generated at 2022-06-21 14:29:09.068526
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    try:
        # In case of pypy, this always fails
        import colorama
    except ImportError:
        colorama = None
    else:
        colorama.init(wrap=False)


    def get_args():
        parser = argparse.ArgumentParser()
        parser.add_argument('--pretty', action='store',
                            choices=['all', 'colors', 'format'],
                            default='format',
                            help='Prettify the output.')
        parser.add_argument('--stream', action='store_true',
                            default=False,
                            help='Stream the response body.')
        return parser.parse_args()



# Generated at 2022-06-21 14:29:15.642252
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    import sys

    outfile = StringIO()

    # with colors

# Generated at 2022-06-21 14:29:24.148752
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Ensure that color codes are properly handled on Windows."""
    # Colorized terminal output lines must be written as text to be
    # processed by colorama, but non-colorized lines must be written
    # as bytes to maintain binary compatibility.
    # https://github.com/jakubroztocil/httpie/issues/1116

# Generated at 2022-06-21 14:29:24.750412
# Unit test for function write_stream
def test_write_stream():
    print('write stream')

# Generated at 2022-06-21 14:29:35.401090
# Unit test for function write_stream_with_colors_win_py3

# Generated at 2022-06-21 14:29:46.136781
# Unit test for function write_message
def test_write_message():
    #  Test cases
    #  1. Test cases with headers and with body
    #  2. Test cases with headers and without body
    #  3. Test cases without headers and with body
    #  4. Test cases without headers and without body
    #  5. Test cases with format set as "json"

    #  Test case 1
    req_obj_with_headers_and_body = requests.PreparedRequest()

# Generated at 2022-06-21 14:30:13.179785
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import httpie.output.writers
    from collections import namedtuple

    class FakeBaseStream:
        def __init__(self):
            self.item = ""

        def __iter__(self):
            return self

        def __next__(self):
            """Fake iterator."""
            if self.item:
                return_value = self.item
                self.item = ""
                return return_value
            else:
                raise StopIteration

    FakeArgument = namedtuple('FakeArgument', ['colors'])

    FakeResponse = namedtuple('FakeResponse', ['status_code'])

    FakeRequest = namedtuple('FakeRequest', ['method', 'url', 'headers', 'body'])


# Generated at 2022-06-21 14:30:20.391470
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import cli
    env = Environment(cli.parser.parse_args([]))
    args = cli.parser.parse_args([])

# Generated at 2022-06-21 14:30:30.454749
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class Args:
        def __init__(self, stream, prettify, debug, traceback, json, style, format_options):
            self.stream = stream
            self.format_options = format_options
            self.prettify = prettify
            self.json = json
            self.style = style
            self.debug = debug
            self.traceback = traceback

    class Request:
        def __init__(self, headers, json, form):
            self.headers = headers
            self.json = json
            self.form = form

        @property
        def headers(self):
            return {
                "Accept": "*/*",
                "Accept-Encoding": "gzip, deflate",
                "Connection": "keep-alive",
                "Host": "httpbin.org",
            }


# Generated at 2022-06-21 14:30:37.924923
# Unit test for function write_stream
def test_write_stream():
    stream = [b'a', b'b', b'c']
    outfile = io.BytesIO()
    write_stream(stream,outfile,True)
    assert outfile.getvalue() == b'abc'
    outfile.close()

    stream = [b'a', b'b', b'c']
    outfile = io.StringIO()
    write_stream(stream,outfile,False)
    assert outfile.getvalue() == ''
    outfile.close()

# Generated at 2022-06-21 14:30:47.929541
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = Namespace(verbose=False,
        pretty="all",
        style="default",
        download=False,
        output=None,
        session=False,
        stream=True,
        debug=False,
        traceback=False,
        verify=None,
        cert=None,
        json=True,
        form=False,
        headers=False,
        body=False,
        style_default_colors=[],
        prettify="all",
        format_options={})
    env = Environment(stdout=None, stdout_isatty=False,
        stderr=None, stderr_isatty=False,
        stdin=None, stdin_isatty=False,
        is_windows=True,
        is_a_tty=False,
        colors=None)


# Generated at 2022-06-21 14:30:58.175031
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    import io
    import httpie.input
    import httpie.cli
    import httpie.plugins

    outputfile = io.BytesIO()
    args = httpie.cli.parser.parse_args('--output-file=tempfile'.split())
    env = httpie.Environment(args)

    httpie.plugins.load_builtin_plugins()

    session = requests.Session()
    request_adapter = requests.adapters.HTTPAdapter(max_retries=3)
    session.mount('http://', request_adapter)
    httpie.input.FILE_SCHEME_PREFIX = '../'

# Generated at 2022-06-21 14:30:58.763678
# Unit test for function write_stream
def test_write_stream():
    assert write_stream

# Generated at 2022-06-21 14:31:10.247047
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.output.formatters.utils import get_format
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    import argparse
    class myTParse():
        def __init__(self):
            self.json = None
            self.style = None
            self.format_options = None
            self.prettify = None
            self.stream = False
            self.debug = None
            self.traceback = None
    class myTEnv():
        def __init__(self):
            self.stdout = None
            self.stderr = None
            self.stdout_isatty = True


# Generated at 2022-06-21 14:31:17.772112
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-21 14:31:26.323703
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    import sys
    import colorama
    sys.stdout = StringIO()

    class AsciiPrettyStream(PrettyStream):
        def gen_line_iter(self):
            yield colorama.ansi.Fore.GREEN + 'Hello!' + colorama.ansi.Fore.RESET
            yield '\n'

    self = AsciiPrettyStream()

    write_stream_with_colors_win_py3(
        stream=self,
        outfile=sys.stdout,
        flush=True
    )

    sys.stdout.seek(0)
    assert sys.stdout.read() == colorama.ansi.Fore.GREEN + 'Hello!' + colorama.ansi.Fore.RESET

# Generated at 2022-06-21 14:32:13.489671
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class TestEnvironment:
        def __init__(self):
            self.stdout_isatty = True

    class TestArgs:
        def __init__(self):
            self.prettify = []
            self.stream = False
            self.json = False
            self.format_options = []
            self.style = None

    for prettify in [['colors'], ['format'], ['format', 'colors']]:
        test_environment = TestEnvironment()
        test_args = TestArgs()
        test_args.prettify = prettify
        test_args.stream = True
        stream_type, stream_kwargs = get_stream_type_and_kwargs(
            env=test_environment,
            args=test_args,
        )
        assert stream_type == PrettyStream
        assert stream_kw

# Generated at 2022-06-21 14:32:18.789499
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import os
    import platform
    import sys

    class FloatIO(io.IOBase):
        def write(self, s):
            pass

    def get_stream(s):
        if platform.python_implementation() == 'PyPy':
            return s.encode('utf-8')
        return s

    class FakeEnv:
        def __init__(self):
            self.is_windows = True
            self.stdout = FakeStdout()

    class FakeStdout:
        def __init__(self):
            self.encoding = 'utf-8'
            self.buffer = FloatIO()

    class FakeStream:
        def __init__(self, s):
            self._s = s
            self._i = 0

        def __iter__(self):
            return self

       

# Generated at 2022-06-21 14:32:27.459952
# Unit test for function write_stream
def test_write_stream():
    args = object()
    env = object()
    for cls in [RawStream, PrettyStream, BufferedPrettyStream, EncodedStream]:
        stream = cls(
            msg=object(),
            with_headers=object(),
            with_body=object(),
            **get_stream_type_and_kwargs(
                env=env,
                args=args
            )[1]
        )
        write_stream(
            stream=stream,
            outfile=object(),
            flush=object()
        )

# Generated at 2022-06-21 14:32:36.082833
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO, BytesIO
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream

    # Setup
    env = Environment()
    env.stdout = StringIO()
    env.stdout_isatty = True
    args = argparse.Namespace(stream=True)
    requests_message = requests.PreparedRequest()
    requests_message.body = b'test'
    requests_message.headers['content-type'] = 'text/html; charset=utf-8'
    write_stream_kwargs = {
        'stream': RawStream(HTTPRequest(requests_message)),
        'outfile': env.stdout,
        'flush': env.stdout_isatty or args.stream
    }
    # No stream

# Generated at 2022-06-21 14:32:47.280488
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import input
    from httpie.core import main
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.models import Request
    from httpie.output.streams import PrettyStream

    args = input.DEFAULT_PARSERS.parse_args(args=[])
    env = Environment(args=args,
                      stdin=io.StringIO(),
                      stdout=io.StringIO(),
                      stderr=io.StringIO(),
                      is_windows=False,
                      config_dir=input.get_default_config_dir())

    # Something like this to emulate requests.PreparedRequest
    request = Request('GET', 'https://httpbin.org/get', {}, None)

    # args and env from httpie.core.main
    stream_type, stream_kw

# Generated at 2022-06-21 14:32:57.602227
# Unit test for function write_message
def test_write_message():
    import httpie.formatter
    import httpie.output.formatters.json
    httpie.formatter.JSONFormatter = httpie.output.formatters.json.JSONFormatter
    from httpie.output.streams import PrettyStream
    from httpie.cli import parser
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie import ExitStatus
    import httpie.exit
    httpie.exit.ExitStatus = ExitStatus
    import io
    outstr=io.StringIO()
    env = Environment(
            stdin=None,
            stdout=outstr,
            stderr=None,
        )
    requests_message = requests.PreparedRequest()

# Generated at 2022-06-21 14:32:59.144627
# Unit test for function write_message
def test_write_message():
    try:
        requests.patch('http://example.org')
        requests.get('http://example.org')
    except Exception as e:
        print(e)

# Generated at 2022-06-21 14:33:04.000119
# Unit test for function write_message
def test_write_message():
    args = argparse.Namespace()
    args.stream = False
    args.prettify = None
    args.style = None
    env = Environment()
    response = requests.Response()
    response.body = '{"name":"test1","role":"tester"}'
    write_message(response, env, args, False, True)

# Generated at 2022-06-21 14:33:14.679348
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    class TestArgs:
        def __init__(self):
            self.stream = False
            self.prettify = ''
            self.style = None
            self.json = ''
            self.format_options = ''
    class TestEnv:
        def __init__(self):
            self.stdout_isatty = False
    env = TestEnv()
    args = TestArgs()
    assert get_stream_type_and_kwargs(env, args)[0] is RawStream
    assert get_stream_type_and_kwargs(env, args)[1]['chunk_size'] == \
        RawStream.CHUNK_SIZE
    args.prettify = 'all'
    env.stdout_isatty = True

# Generated at 2022-06-21 14:33:21.303701
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    outfile = StringIO()
    args = []

    class BaseStream(object):
        def __init__(self, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __iter__(self):
            yield b'\x1b[0m\x1b[0m\n'
            yield b'\x1b[0m\x1b[32m\n'
            yield b'\x1b[0m\x1b[0m\n'
            yield b'\x1b[0m\x1b[31m\n'
            yield b'\x1b[0m\x1b[0m\n'

    class PrettyStream(BaseStream):
        pass
