

# Generated at 2022-06-21 14:24:13.922998
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.context import Environment
    from io import StringIO
    import tempfile
    import os
    import sys
    import shutil

    class MockArgs():
        def __init__(self, prettify, stream):
            self.prettify = prettify
            self.stream = stream

    def run_mock_main(args, **kwargs):
        sys.stdout = StringIO()
        main(args, **kwargs)
        return sys.stdout.getvalue()

    with_headers = True
    with_body = True
    stream = False


# Generated at 2022-06-21 14:24:22.824800
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    env.stdout_isatty = False
    args = argparse.Namespace(prettify=None, stream=False, style='solarized')

    exp_stream_class = RawStream
    exp_stream_kwargs = {'chunk_size': None}
    actual_stream_class, actual_stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert exp_stream_class == actual_stream_class
    assert exp_stream_kwargs == actual_stream_kwargs

    args.stream = True
    exp_stream_kwargs = {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE}
    actual_stream_class, actual_stream_kwargs = get_stream_type_and_kwargs(env, args)
   

# Generated at 2022-06-21 14:24:34.195274
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import argparse
    import httptools
    import io
    import requests
    import httpie
    import httpie.input
    import httpie.cli
    import httpie.plugins
    import httpie.output
    import httpie.downloaders
    from httpie import ExitStatus

    httpie.plugins.load_internal_plugins()
    httpie.plugins.load_external_plugins()
    parser = httpie.cli.get_parser()
    args = parser.parse_args()

# Generated at 2022-06-21 14:24:45.811907
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    '''
    Given a prepared_request, this test verifies that correct
    output stream is passed.
    '''
    from httpie.cli import parser
    from httpie.context import Environment
    import tempfile
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    args = parser.parse_args(['--pretty=all'])
    env = Environment(stdin=None, stdout=None, stderr=None)

    # Mock a prepared request
    class PreparedRequestStub(object):
        _content = '{}'
        method = 'GET'
        scheme = 'https'
        host = 'httpbin.org'
        path = '/get'
        headers = {}
    request_obj = PreparedRequestStub

# Generated at 2022-06-21 14:24:52.403095
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import contextlib
    import tempfile

    import pytest
    from httpie.core import main as httpie_core
    from httpie.core import main as httpie
    from httpie.cli import main as cli
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie import ExitStatus

    @contextlib.contextmanager
    def open_temp_file():
        _, path = tempfile.mkstemp()
        try:
            with open(path, 'wb') as f:
                yield f
        finally:
            if os.path.exists(path):
                os.remove(path)

    class NullIO:
        """
        A IO-alike object that does nothing.
        """
        def isatty(self):
            return False

# Generated at 2022-06-21 14:25:04.056625
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, EncodedStream
    from httpie.context import Environment
    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace()
    args.prettify = ['all']

    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'] == Conversion()
    assert stream_kwargs['formatting'].env == env
    assert stream_kwargs['formatting'].groups == ['all']
    assert stream_kwargs['formatting'].color_scheme is None

# Generated at 2022-06-21 14:25:05.228991
# Unit test for function write_message
def test_write_message():
    """Unit test for function write_message"""
    assert 1

# Generated at 2022-06-21 14:25:14.524270
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = type('', (), {'prettify': [], 'stream': False, 'style': ''})()
    env = type('', (), {'stdout': '', 'stdout_isatty': False})()
    requests_message_response = type('', (), {'ok': True, 'headers': {'test': 'test'},
                                              'request': type('', (), {'headers': {'test': 'test'},
                                                                        'body': b'test_body',
                                                                        'path_url': '/test_url'})()})()

    output_stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message_response,
        with_headers=False,
        with_body=False
    )


# Generated at 2022-06-21 14:25:22.776869
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    result = build_output_stream_for_message(
        requests_message=requests.PreparedRequest(),
        with_headers=True,
        with_body=True,
        args=argparse.Namespace(stdout_isatty=True, stream=False, style='bw'),
        env='local',
    )
    assert next(result) == b'GET / HTTP/1.1\r\n\r\n\n\n'

# Generated at 2022-06-21 14:25:34.544449
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest
    import argparse
    from httpie import __version__
    from httpie.context import Environment

    environment = Environment(
        stdin=None, stdout=None, stderr=None,
        stdin_isatty=True, stdout_isatty=False, stderr_isatty=False,
        stdout_bytes_written=0,
        is_windows=True,
        server_version=__version__,
    )

    request = "GET / HTTP/1.1\r\nHost: localhost:8080\r\nUser-Agent: httpie.py/1.0\r\nContent-Length: 4\r\n\r\nbody"

# Generated at 2022-06-21 14:25:53.330451
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    header1_name = "testheader1"
    header1_value = "testvalue1"
    header2_name = "testheader2"
    header2_value = "testvalue2"
    header_a = header1_name + ": " + header1_value
    header_b = header2_name + ": " + header2_value
    testheaders = [header_a, header_b]
    testsession = requests.Session()
    testrequest = HTTPRequest(args=[], env={}, session=testsession)
    testurl = "http://www.google.com/"
    testresponse = HTTPResponse(args=[], env={})
    headers = testheaders
    data = b'hello'
    stream_class = RawStream

# Generated at 2022-06-21 14:26:05.455397
# Unit test for function write_stream
def test_write_stream():
    from httpie.core import main
    from httpie.compat import is_windows

    if is_windows:
        pytest.skip('No testing on windows')

    assert not is_windows


# Generated at 2022-06-21 14:26:13.238011
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Test for write_stream_with_colors_win_py3

    Test if method write colored parts to stdout as text, but non-colored
    parts as bytes. This is to ensure that colorama works correctly on Windows.
    """
    from io import StringIO
    import httpie.output.streams
    import httpie.output.streams
    class TestStream(httpie.output.streams.BaseStream):
        def __init__(self):
            pass
        def __iter__(self):
            yield b'\x01b[0m\x1b[1;32mhello world'
            yield b'\x01b[0m\x1b[1;32mhello world'
            yield b'\x01b[0m\x1b[1;32mhello world'
            yield b

# Generated at 2022-06-21 14:26:22.757263
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Stream():
        def __iter__(self):
            yield b'foo\x1b[2mbar\x1b[0m\n'
            yield b'baz\n'

    class FakeStdout():
        def __init__(self, buf):
            self.buf = buf

        def write(self, value):
            self.buf.append(value)

    class FakeArgs():
        pass

    class FakeEnv():
        def __init__(self, is_windows, stdout_isatty):
            self.is_windows = is_windows
            self.stdout_isatty = stdout_isatty

    content = []
    args = FakeArgs()
    env = FakeEnv(True, True)

# Generated at 2022-06-21 14:26:33.242288
# Unit test for function write_stream
def test_write_stream():
    class file_mock (object):
        def write(self, data):
            pass
    args = argparse.Namespace(stream=True)
    env = Environment()
    env.stdout_isatty = False
    env.stdout = file_mock()
    response = requests.Response()
    response.raw = io.BytesIO()
    response.raw.write(b'This is a test response.')
    response.raw.seek(0)
    response.headers = {}
    response.reason = 'OK'
    response.status_code = 200
    write_stream(
        stream=EncodedStream(msg=HTTPResponse(response), env=env),
        outfile=env.stdout,
        flush=args.stream
    )

# Generated at 2022-06-21 14:26:38.165114
# Unit test for function write_stream
def test_write_stream():
	with open('test.txt','w',encoding='UTF-8') as f:
		f.write('test ok')
	with open('test.txt','r',encoding='UTF-8') as f:
		write_stream(f,f,False)




# Generated at 2022-06-21 14:26:44.025274
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    from httpie.output.streams import BaseStream

    class FakeStream(BaseStream):
        def __iter__(self):
            yield b'\x1b[31mfoo\x1b[0m'
            yield b'bar'

    stream = FakeStream()
    f = io.StringIO()
    write_stream_with_colors_win_py3(stream, f, False)
    assert f.getvalue() == '\x1b[31mfoo\x1b[0mbar'

# Generated at 2022-06-21 14:26:55.032563
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # For Python 2
    try:
        io.StringIO().buffer
    except AttributeError:
        return

    # For systems other than Windows
    import os
    if os.name == 'nt':
        return

    from httpie.plugins.builtin import HTTPHeaders
    from httpie.output.streams import PrettyStream, COLOR_OFF_CODE
    from httpie.output.streams import COLOR_END_CODE_LEN

    from requests.structures import CaseInsensitiveDict
    from httpie.compat import is_windows
    from httpie import ExitStatus

    args = argparse.Namespace()
    args.stream = False
    args.prettify = ('colors', 'all')
    args.style = HTTPHeaders.DEFAULT_PYGMENT_STYLE
    args.json

# Generated at 2022-06-21 14:27:05.389558
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.cli.constants import DEFAULT_FORMAT, DEFAULT_PRETTY
    from httpie.input.utils import stream_to_generator

    class MockResponse:
        headers = {'User-Agent': 'mock'}
        status_code = 200
        is_body_upload_chunk = False
        content = b'test_build'

    resp = MockResponse()
    args = parser.parse_args([])
    args.prettify = DEFAULT_PRETTY
    args.format = DEFAULT_FORMAT
    args.stream = False

# Generated at 2022-06-21 14:27:14.864700
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams.base import RawStream, EncodedStream, PrettyStream, BufferedPrettyStream, BaseStream

    args = argparse.Namespace(
        download=True,
        prettify=(),
        style='',
        format_options=(),
        stream=False,
        json=False,
    )
    env = Environment(
        stdout_isatty=False,
        stderr_isatty=False,
        stdin_isatty=False,
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == RawStream
    assert stream_kwargs == {
        'chunk_size': RawStream.CHUNK_SIZE
    }


# Generated at 2022-06-21 14:27:36.400874
# Unit test for function write_message
def test_write_message():
    import argparse, sys, pytest
    from contextlib import redirect_stdout
    from tempfile import TemporaryFile
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parse_args, get_output_opener, get_requests_kwargs, get_response
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.input import SEP_CREDENTIALS
    from httpie import ExitStatus, __version__
    auth = HTTPBasicAuth()

    class Testing:
        def __init__(self):
            pass

        def _get_parser(self):
            parser = parse

# Generated at 2022-06-21 14:27:45.308025
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    r = requests.Response()
    r.status_code = 200
    r.encoding = 'utf-8'
    r.raw = io.BytesIO(b'\xcf\x80\xce\xb1\xce\xb9')
    r.reason = 'OK'
    r.url = 'http://www.baidu.com'
    r.request = requests.Request(
        method='GET',
        url='http://www.baidu.com',
    ).prepare()

    args = argparse.Namespace()

    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )


# Generated at 2022-06-21 14:27:54.064406
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env1 = Environment()
    env2 = Environment()
    env2.stdout_isatty = False
    args1 = argparse.Namespace()
    args2 = argparse.Namespace()
    args2.prettify = True
    args3 = argparse.Namespace()
    args3.prettify = True
    args3.stream = True
    env3 = Environment()
    args4 = argparse.Namespace()
    args4.stream = True
    env4 = Environment()
    env4.stdout_isatty = False
    args5 = argparse.Namespace()
    args5.prettify = True
    args5.stream = True
    env5 = Environment()
    env5.stdout_isatty = False
    args6 = argparse.Namespace()
    args6.pre

# Generated at 2022-06-21 14:28:00.656204
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty = False)
    args = argparse.Namespace(prettify=None, stream=None, style=None)

    func = get_stream_type_and_kwargs
    assert func(env, args) == (RawStream, {'chunk_size': 2**14})

    args = argparse.Namespace(prettify=None, stream=True, style=None)
    assert func(env, args) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE})

    args = argparse.Namespace(prettify=[], stream=None, style=None)

# Generated at 2022-06-21 14:28:12.894822
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    This is a unit test for the function write_stream_with_colors_win_py3
    We will first create a buffer and write it to the output file
    We will later check the content of the buffer by getting it as a string
    If the output file content is the same as the buffer content, it means that the function works
    """
    from io import StringIO
    args = argparse.Namespace()
    env = Environment()
    class MockStream:
        def __init__(self, content):
            self.content = content
            self.index = 0
        def __iter__(self):
            return self
        def __next__(self):
            if self.index == len(self.content):
                raise StopIteration
            else:
                self.index += 1

# Generated at 2022-06-21 14:28:23.262707
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli.argtypes import KeyValueArg
    from httpie.output.streams import EncodedStream, PrettyStream, RawStream, BufferedPrettyStream
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment

    args = argparse.Namespace()
    args.stream = False
    args.prettify = False
    env = Environment(colors=256,
                      is_windows=False,
                      stdin_isatty=False,
                      stdout_isatty=False,
                      stderr_isatty=True)

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == RawStream

# Generated at 2022-06-21 14:28:34.698145
# Unit test for function write_message
def test_write_message():
    import json
    import os
    import httpie.cli
    from httpie.input import ParseError
    from httpie.context import Environment
    from httpie.models import Request, Response

    def set_args(args):
        arguments = [
            '--ignore-stdin',
            '--follow',
            '--traceback',
            '--debug',
        ]
        arguments.extend(args)
        args = httpie.cli.parser.parse_args(args=arguments)
        dir(args)
        return args
    def set_env(args):
        env = Environment()
        env.config = httpie.config.Config(
            dir=os.path.expanduser('~/.httpie'),
            env=env,
        )
        env.config.load_config()

# Generated at 2022-06-21 14:28:38.051273
# Unit test for function write_stream
def test_write_stream():
    import io
    o = io.StringIO()
    write_stream([b'hello'], o, False)
    o.close()
    assert o.getvalue() == 'hello'


# Generated at 2022-06-21 14:28:45.663876
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    env = Environment()
    requests_message = requests.PreparedRequest()
    with_headers = True
    with_body = True
    args = argparse.Namespace()
    
    stream, stream_kwargs = get_stream_type_and_kwargs(env, args)
    stream_instance = stream(msg=HTTPRequest(requests_message), with_headers=with_headers, **stream_kwargs)
    test_stream = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)
    assert (type(test_stream) == type(stream_instance))
    assert (test_stream._msg == stream_instance._msg)

# Generated at 2022-06-21 14:28:49.406933
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # The test is that it doesn't raise an exception.
    stream = [b'\x1b[1;37m']
    outfile = io.StringIO()
    flush = False
    write_stream_with_colors_win_py3(stream, outfile, flush)

# Generated at 2022-06-21 14:29:22.620097
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class args:
        def __init__(self):
            self.prettify = False
            self.stream = False
            self.format_options = None
            self.json = False

    class env:
        def __init__(self):
            self.is_windows = False
            self.stdout = None
            self.stderr = None
            self.stdout_isatty = True

    class message:
        def __init__(self):
            self.body = 'Hello, world!'

    args = args()
    env = env()
    message = message()
    print(list(build_output_stream_for_message(args=args, env=env, requests_message=message, with_headers=True, with_body=True)))
    print(MESSAGE_SEPARATOR_BYTES)

# Generated at 2022-06-21 14:29:31.537555
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(
        prettify="all",
        stream=True,
        style="solarized",
        json=False,
        format_options="pretty,colors",
    )
    env = Environment()
    expected = (PrettyStream, {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups='all',
            color_scheme='solarized',
            explicit_json=False,
            format_options='pretty,colors',
        )
    }
    )
    actual = get_stream_type_and_kwargs(env, args)
    assert expected == actual

# Generated at 2022-06-21 14:29:33.256728
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    stream_class, stream_kwargs = get_stream_type_and_kwargs()

# Generated at 2022-06-21 14:29:43.510993
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """For py2, output raw bytes. For py3, output unicode with colorama."""
    import sys
    from io import StringIO
    from httpie.compat import is_windows, is_py3
    from httpie.output.streams import RawStream, PrettyStream
    from httpie.output.writers import write_stream_with_colors_win_py3

    class Devnull(object):
        def write(self, x): pass


# Generated at 2022-06-21 14:29:49.108489
# Unit test for function write_stream
def test_write_stream():
    write_stream(
        stream=build_output_stream_for_message(
            args=args,
            env=env,
            requests_message=requests_message,
            with_body=True,
            with_headers=True
        ),
        # NOTE: `env.stdout` will in fact be `stderr` with `--download`
        outfile=env.stdout,
        flush=env.stdout_isatty or args.stream
    )
    assert True

# Generated at 2022-06-21 14:29:53.014127
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert isinstance(get_stream_type_and_kwargs(False, True)[0], PrettyStream)
    assert isinstance(get_stream_type_and_kwargs(True, False)[0], RawStream)
    assert isinstance(get_stream_type_and_kwargs(True, True)[0], EncodedStream)

# Generated at 2022-06-21 14:30:04.185595
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    from httpie.cli import parser_options
    from httpie.output.streams import PrettyStream

    args = parser_options.parse_args([])
    env = Environment()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == -1

    args = parser_options.parse_args(['-s'])
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == RawStream
    assert stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE_BY_LINE


# Generated at 2022-06-21 14:30:13.819768
# Unit test for function write_message
def test_write_message():
    requests_message = requests.Request("GET","https://httpbin.org/get")
    env = Environment(
            stdout_isatty=True,
            colors=256,
            stdout=sys.stdout.buffer,
            stderr=sys.stderr.buffer,
            is_windows=False,
            log_level=0
        )


# Generated at 2022-06-21 14:30:19.688283
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
    )
    args = httpie.cli.parser.parse_args([])

    res = requests.Response()
    res.url = "https://www.bing.com/search?q=hello"

    stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=res,
        with_headers=True,
        with_body=True,
    )

    for chunk in stream:
        print(chunk.decode())

# Generated at 2022-06-21 14:30:28.955905
# Unit test for function write_message
def test_write_message():
    args = argparse.Namespace(verbose=True, debug=False, traceback=False,
                              stream=False, prettify=[], style='',
                              download=False, json=False, format_options={})
    env = Environment(stdout_isatty=False, is_windows=False)
    requests_message = requests.PreparedRequest()
    with_headers=True
    with_body=True
    write_message(requests_message,env,args,True,True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env,args)
    assert(stream_class == EncodedStream)
    assert(stream_kwargs == {'env': env})

    env = Environment(stdout_isatty=False, is_windows=False)
    args = argparse

# Generated at 2022-06-21 14:31:25.075680
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import json

    env = Environment()
    args = argparse.Namespace(prettify=False, stream=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args)
    assert stream_class == RawStream
    assert stream_kwargs["chunk_size"] == 10240000

    args = argparse.Namespace(prettify=False, stream=True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args)
    assert stream_class == RawStream
    assert stream_kwargs["chunk_size"] == RawStream.CHUNK_SIZE_BY_LINE

    env.stdout_isatty = True

# Generated at 2022-06-21 14:31:32.935416
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import os
    import sys
    import tempfile
    import unittest

    class EnvStub(object):
        stdout_isatty = False
        def __init__(self):
            _, self.stderr = tempfile.mkstemp()

    class ArgsStub(object):
        prettify = None
        stream = False
        style = None
        json = False
        format_options = {}
        debug = False
        traceback = False

    # Terminal output without --prettify
    class TestRawStream(unittest.TestCase):
        def test_stream_class(self):
            env = EnvStub()
            args = ArgsStub()
            stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
            self.assertEqual

# Generated at 2022-06-21 14:31:43.311829
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import os
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    class env:
        class stdout:
            class buffer:
                def write(a):
                    return a
            def flush():
                return
            encoding = 'utf-8'
            isatty = True
        def __init__(self):
            self.stdout = self
            self.stdout.buffer = self.stdout
            
    class dict:
        def get(self, a):
            return a
        def items(self, a):
            return a

# Generated at 2022-06-21 14:31:48.028154
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    data = '{"a": \x1b[1m1\x1b[22m}'
    data_bytes = data.encode('utf-8')
    with io.BytesIO() as outfile:
        write_stream_with_colors_win_py3(
            stream=iter([data_bytes]),
            outfile=outfile,
            flush=False
        )
        assert outfile.getvalue() == data

# Generated at 2022-06-21 14:31:55.561090
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import (
        ColorizedStream, PrettyStream,
    )
    class MockStream(ColorizedStream):
        def __init__(self, *args, **kwargs):
            super(MockStream, self).__init__(*args, **kwargs)
            self.iteration = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.iteration == 0:
                self.iteration += 1
                return '\x1b[1m\x1b[31m\x1b[1mcolors\x1b[0m\x1b[0m'
            raise StopIteration()


# Generated at 2022-06-21 14:32:06.302843
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    messages = [HTTPRequest(requests.PreparedRequest()),
                HTTPResponse(requests.Response())]
    args = argparse.Namespace()
    env = Environment(False, True)
    with_headers = False
    with_body = False

    for msg in messages:
        for stream in build_output_stream_for_message(requests_message=msg, env=env, args=args, with_headers=with_headers, with_body=with_body):
            assert isinstance(stream, RawStream) or isinstance(stream, EncodedStream)

    args.prettify = True
    args.stream = True
    with_headers = True
    with_body = True


# Generated at 2022-06-21 14:32:14.718007
# Unit test for function write_stream
def test_write_stream():
    class DummyFile(object):
        def __init__(self):
            self.chunks = []
        def write(self, chunk):
            self.chunks.append(chunk)

    outfile = DummyFile()
    write_stream(stream=iter(['abc', 'def', '123456']), outfile=outfile, flush=False)
    assert ''.join(outfile.chunks) == 'abcdef123456'

    outfile = DummyFile()
    write_stream(stream=iter(['abc', 'def', '123456']), outfile=outfile, flush=True)
    assert ''.join(outfile.chunks) == 'abcdef123456'

    write_stream(stream=iter(['abc', 'def', '123456']), outfile=io.BytesIO(), flush=False)

# Generated at 2022-06-21 14:32:16.468259
# Unit test for function write_message
def test_write_message():
    """
        This file can only be tested by the main file, since it is the main file
        that constructs the message.
    """
    assert True
    # It's impossible to write a unit test for this function.

# Generated at 2022-06-21 14:32:19.951457
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    message = HTTPRequest(
        requests.Request(
            method='GET',
            url='http://httpbin.org/headers',
        )
    )
    args = argparse.Namespace()

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env=env, args=args)
    output_stream = stream_class(
        msg=message,
        with_headers=True,
        with_body=True,
        **stream_kwargs
    )
    assert output_stream is not None

# Generated at 2022-06-21 14:32:24.045999
# Unit test for function write_message
def test_write_message():
    message = "Test"
    write_message(message, 'test_output.txt')
    assert open('test_output.txt').read() == message
    os.remove('test_output.txt')