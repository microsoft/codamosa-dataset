

# Generated at 2022-06-21 14:24:11.998876
# Unit test for function write_message
def test_write_message():
    class SamplePreparedRequest:
        def __init__(self, headers):
            self.headers = headers
    class SampleResponse:
        def __init__(self, headers, content):
            self.headers = headers
            self.content = content
    headers = {
        'Content-Type': 'text/plain',
    }
    content = 'the content of message'

# Generated at 2022-06-21 14:24:21.561252
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import unittest

    class TestWriteStream(unittest.TestCase):
        def setUp(self):
            # python3 io.BytesIO() does not accept str
            # http://bugs.python.org/issue10198
            self.outfile_b = io.BytesIO()

        def test_write_stream_empty(self):
            write_stream([], self.outfile_b, False)

            # TODO: this assumes windows
            self.assertEqual(self.outfile_b.getvalue(), b'')

        def test_write_stream(self):
            write_stream([b'foo', b'bar'], self.outfile_b, True)

            # TODO: this assumes windows

# Generated at 2022-06-21 14:24:22.113455
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-21 14:24:33.775456
# Unit test for function write_message
def test_write_message():
    class mock_requests_message():
        is_body_upload_chunk = False

    requests_message = mock_requests_message()

    class mock_stdout():
        isatty = True

    class mock_stderr():
        isatty = False

    class mock_args():
        stream = False
        prettify = 'colors'

    class mock_stdout_buffer():
        def write(self):
            pass

    class mock_stderr_buffer():
        def write(self):
            pass

    class mock_env():
        stdout = mock_stdout()
        stderr = mock_stderr()
        is_windows = False
        stdout_isatty = True

    env = mock_env()


# Generated at 2022-06-21 14:24:43.556026
# Unit test for function write_stream
def test_write_stream():
    class MockOutfile():
        def __init__(self, encoding=None):
            self.encoding = encoding
            self.buffer = MockFileBuffer() if encoding else self

    class MockFileBuffer:
        def write(self, value):
            print('write: ' + str(value))

    mock_outfile = MockOutfile()

    write_stream(
        stream=(b'a', b'b', b'c'),
        outfile=mock_outfile,
        flush=False,
    )
    # Output:
    # write: b'a'
    # write: b'b'
    # write: b'c'



# Generated at 2022-06-21 14:24:51.582053
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from tempfile import TemporaryFile
    import sys
    import os

    class DummyStream:
        def __iter__(self):
            yield 'this '
            yield 'is '
            yield '\x1b[41ma '
            yield '\x1b[42mb '
            yield '\x1b[43mc '
            yield '\x1b[44md '
            yield '\x1b[45me '
            yield '\x1b[46mf '
            yield '\x1b[47mg '
            yield '\x1b[0mh '
            yield '\x1b[100mi '
            yield '\x1b[101mj '
            yield '\x1b[102mk '
            yield '\x1b[103ml '

# Generated at 2022-06-21 14:25:02.635217
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO

    # given
    enc = 'UTF-8'
    outfile = StringIO()
    outfile.encoding = enc
    colors = (
        '31',  # red
        '32',  # green
        '33',  # yellow
        '34',  # blue
        '35',  # magenta
        '36',  # cyan
        '37'  # white
    )

    class TestStream(EncodedStream):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self._chunks = []

        def __iter__(self):
            prefix = '\x1b['
            suffix = 'm'


# Generated at 2022-06-21 14:25:13.199704
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import json
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io

# Generated at 2022-06-21 14:25:24.738633
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream
    from httpie.context import Environment
    env = Environment()
    from argparse import Namespace
    args = Namespace()
    args.stream=False
    args.prettify=True
    args.style='default'
    args.json=True
    args.format_options={}
    args.stream=False
    args.chunk_size=None
    assert get_stream_type_and_kwargs(env=env,args=args) == (PrettyStream, {'env':env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=True, color_scheme='default', explicit_json=True, format_options={})})

# Generated at 2022-06-21 14:25:36.256243
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    message_class = {
        requests.PreparedRequest: HTTPRequest,
        requests.Response: HTTPResponse,
    }[type(requests.PreparedRequest)]
    class Test:
        def __init__(self):
            self.prepared_request = requests.PreparedRequest()
            self.args = argparse.Namespace()
            self.env = Environment()
    test = Test()
    test.stream_class, test.stream_kwargs = get_stream_type_and_kwargs(test.env, test.args)
    test_stream = test.stream_class(test.prepared_request, True, True, test.env, Conversion(), Formatting(test.env, None, None, None, None))

# Generated at 2022-06-21 14:25:49.926770
# Unit test for function write_message
def test_write_message():
    import httpie.cli
    # Test case: Test function write_message
    # Test is simple and only check that write_message function succeed

    # Test setup
    # httpie.cli.main(args=['--download', '--verbose', '--print=b', 'https://httpbin.org/get'])
    # return
    httpie.cli.main(args=['--download', '--verbose', '--print=B', 'https://httpbin.org/get'])
    return

# Generated at 2022-06-21 14:26:02.038350
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, RawStream, EncodedStream, BufferedPrettyStream
    import os
    import argparse
    from httpie.context import Environment
    if(hasattr(os, '_wrap_close')):
        print("stdout is not a tty")
        args = argparse.Namespace(prettify=False, stream=False)

# Generated at 2022-06-21 14:26:11.718015
# Unit test for function write_stream
def test_write_stream():
    import sys
    from .output.streams import BaseStream
    from .output.streams import RawStream
    from .output.streams import EncodedStream
    from .output.streams import PrettyStream
    from .output.streams import BufferedPrettyStream
    from .context import Environment
    from .models import HTTPRequest
    from .models import HTTPResponse
    from .models import Request
    from .models import Response
    from .config import DEFAULT_CONFIG_DIR
    from .sessions import DEFAULT_SESSION_NAME
    from .sessions import Session
    from httpie.output.processing import Conversion
    from httpie.output.processing import Formatting
    from httpie.utils import MESSAGE_SEPARATOR
    from httpie.utils import MESSAGE_SEPARATOR_BYTES

# Generated at 2022-06-21 14:26:21.521947
# Unit test for function write_message
def test_write_message():
    import pytest
    from httpie import ExitStatus
    from utils import TestEnvironment, http
    # Test for Invalid host
    with pytest.raises(SystemExit) as e:
        env = TestEnvironment(stdout_isatty=True, colors=256)

# Generated at 2022-06-21 14:26:22.378068
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    assert build_output_stream_for_message()

# Generated at 2022-06-21 14:26:33.433574
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import tempfile
    import requests
    import responses
    import pytest
    import httpie
    from contextlib import suppress
    with suppress(ModuleNotFoundError):
        import httpie_unittest
    with suppress(ModuleNotFoundError):
        import httpie_unittest.config
        import httpie_unittest.utils

    @pytest.fixture
    def response_mock_fixture(request):
        responses.start()
        yield
        responses.stop()

    # Mocks
    def response_callback(request):
        print(request.url)
        print(request.headers)
        print(request.body)
        print(request.text)

# Generated at 2022-06-21 14:26:43.680148
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.downloads import is_file_url
    from httpie.output.streams import ColoredPrettyStream, EncodedStream, PrettyStream, RawStream, \
        StreamWithDecodedContent, StreamWithHeaders, StreamWithCallbacks, StreamWithContentLength
    from httpie.output.processing import ColorizedBinaryStream, BinaryStream, Colorize, FormatStream, \
        FormatOptions

    from mock import Mock
    from pytest import fixture

    from httpie.output.streams import get_stream_type_and_kwargs

    env = Mock()

    args = Mock()
    args.style = None
    args.stream = False
    args.prettify = None
    args.json = False
    args.format_options = []

    requests_message = Mock(spec_set=requests.Response)

    stream, k

# Generated at 2022-06-21 14:26:54.640331
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    import argparse
    import requests

    env = Environment(
        stdout=1,
        stderr=2,
    )
    parsed_args = argparse.Namespace(
        style='',
        pretty='all',
        print_body=True,
        headers='',
        stream=False,
        stdin=None,
        verify=True,
        cert=None,
        json=[],
    )

    msg = '''\
GET /get HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Host: httpbin.org
User-Agent: HTTPie/0.9.9

'''

    res = requests.PreparedRequest()
    res.method = 'GET'

# Generated at 2022-06-21 14:27:01.858955
# Unit test for function write_message
def test_write_message():
        import requests
        import argparse
        from httpie.context import Environment
        from httpie.output.streams import RawStream, BufferChunkedRead
        class Response(requests.Response):
            """
            A custom response class which takes the
            response message as a string.
            """
            def __init__(self, msg):
                super(Response, self).__init__()
                self.msg = msg
            def raw_response(self):
                return self.msg

        env = Environment()
        args = argparse.Namespace()
        args.prettify = []
        args.stream = False
        args.style = 'parrot'
        args.json = False
        args.format_options = {}
        env.stdout_isatty = False

# Generated at 2022-06-21 14:27:10.682708
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    env.config.update({'prettify': ['colors']})
    args = argparse.Namespace()
    response = requests.Response()
    response.status_code = 200
    response.headers = {'content-length': '1234'}
    response.encoding = 'utf-8'
    response._content = b'foo'
    output_stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=response,
        with_headers=True,
        with_body=True
    )
    # Check type
    assert isinstance(output_stream, PrettyStream)

# Generated at 2022-06-21 14:27:27.699825
# Unit test for function write_message
def test_write_message():

    import pytest
    from httpie.output.streams import BaseStream, PrettyStream, RawStream, EncodedStream

    with pytest.raises(TypeError):
        write_message(requests_message=None, env=None, args=None, with_headers=1, with_body=1)



# Generated at 2022-06-21 14:27:37.340698
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import io
    class MockEnv:
        def __init__(self):
            self.isatty = False
    class MockParser:
        def __init__(self, args):
            self.stream = args
            self.prettify = ['all']
            self.style = 'none'
            self.json = False
    def mock_request():
        class MockMsg:
            def __init__(self, body):
                self.body = body
        return MockMsg

# Generated at 2022-06-21 14:27:39.922348
# Unit test for function write_stream
def test_write_stream():
    with open('write_message_test.txt', 'w') as outfile:
        #write_stream(None, outfile)
        write_stream(None, None, None)


test_write_stream()

# Generated at 2022-06-21 14:27:42.502334
# Unit test for function write_stream
def test_write_stream():
    write_stream_kwargs = {
        'stream': None,
        'outfile': None,
        'flush': None
        }
    write_stream(**write_stream_kwargs)

# Generated at 2022-06-21 14:27:43.485040
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # TODO: http://docs.pytest.org/en/latest/goodpractices.html#test-discovery
    pass

# Generated at 2022-06-21 14:27:50.213821
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    message = requests.Response()
    message.request = requests.Request()
    message.request.method = "GET"
    message.request.url = "http://www.baidu.com"
    message.request.headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/49.0.2623.110 Safari/537.36",
        "Accept-Encoding": "gzip, deflate, sdch",
        "Accept": "*/*",
        "Connection": "keep-alive"
    }
    message.status_code = 200
    message.url = "http://www.baidu.com"

# Generated at 2022-06-21 14:27:57.213190
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    This function tests if the correct output is being generated when the
    function write_stream_with_colors_win_py3 is used.
    """
    import sys
    import io

    # Using memory streams as terminal streams
    # 1: Redirects stdout to a bytes stream
    # 2: Redirects stderr to a bytes stream
    sys.stdout = io.BytesIO()
    sys.stderr = io.BytesIO()

    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    )

    # testing the colors when the stream class is RawStream:
    stream_class = RawStream
    stream_kwargs = {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE}
    stream = stream_class

# Generated at 2022-06-21 14:28:05.972538
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class MockStream(BaseStream):
        def __iter__(self):
            yield '\x1b[0;32m⚡ '
            yield 'hello\x1b[0m'

    class MockOutfile:
        def __init__(self, encoding=None):
            self.encoding = encoding
            self.buffer = self

        def write(self, data):
            pass

    write_stream_with_colors_win_py3(
        stream=MockStream(),
        outfile=MockOutfile(encoding='utf-8'),
        flush=False
    )

# Generated at 2022-06-21 14:28:06.711374
# Unit test for function write_stream
def test_write_stream():
    return

# Generated at 2022-06-21 14:28:17.430216
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import os
    import pytest
    from httpie.context import Environment
    from httpie.plugins import plugin_manager

    class namespace:

        def __init__(self, prettify, stream, style, json, format_options):
            self.prettify = prettify
            self.stream = stream
            self.style = style
            self.json = json
            self.format_options = format_options

        def __contains__(self, item):
            return item in self.__dict__

    env = Environment()
    plugin_manager.load_internal_plugins()

    # Stream with prettify `all`
    args = namespace(prettify=('all',),
                     stream=True,
                     style=None,
                     json=False,
                     format_options={})
    stream_class, stream_kwargs = get_

# Generated at 2022-06-21 14:28:37.708746
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    from httpie.core import main
    args = main(args=['--json', 'http://httpbin.org/get'])
    env = Environment()
    r = requests.get('http://httpbin.org/get')
    with_body = True
    with_headers = True
    stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=r,
        with_body=with_body,
        with_headers=with_headers,
    )
    print(stream)

# Generated at 2022-06-21 14:28:46.176644
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import unittest
    import types
    import json
    import io

    def read_json_file(json_file):
        with open(json_file) as f:
            return json.load(f)

    def write_to_file(content, file_name):
        with open(file_name, 'w') as f:
            f.write(content)

    class TestWriteStream(unittest.TestCase):
        def test_write_stream_with_colors_win_py3(self):
            stream = BaseStream()
            outfile = io.StringIO()
            flush = True
            self.assertRaises(AssertionError, write_stream_with_colors_win_py3, stream, outfile, flush)

        def test_write_stream(self):
            stream = BaseStream()


# Generated at 2022-06-21 14:28:51.532957
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    test for write_stream_with_colors_win_py3 function
    """
    # create dummy stream and outfile
    stream = []
    outfile = sys.stdout
    flush = False
    # write to stream and outfile
    write_stream_with_colors_win_py3(stream, outfile, flush)

# Generated at 2022-06-21 14:28:57.032441
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    args = httpie.cli.parser.parse_args(['GET', '--pretty', 'all', 'https://httpbin.org/get'])
    import httpie.context
    env = httpie.context.Environment(vars={})
    import requests
    response = requests.get('https://httpbin.org/get')
    write_message(response, env, args, False, False)
    response.close()

# Generated at 2022-06-21 14:29:04.127368
# Unit test for function write_stream

# Generated at 2022-06-21 14:29:12.956655
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert (RawStream, {
        'chunk_size': RawStream.CHUNK_SIZE
    }) == get_stream_type_and_kwargs(
        env=Environment(stdout_isatty=False,
                        stdout_encoding='utf8'),
        args=argparse.Namespace(prettify=None, stream=False)
    )
    assert (RawStream, {
        'chunk_size': RawStream.CHUNK_SIZE_BY_LINE
    }) == get_stream_type_and_kwargs(
        env=Environment(stdout_isatty=False,
                        stdout_encoding='utf8'),
        args=argparse.Namespace(prettify=None, stream=True)
    )

# Generated at 2022-06-21 14:29:22.558010
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie import __main__
    from httpie.input import ParseArguments

    fake_args = ParseArguments(__main__.parser.parse_args(["--style", "paraiso-dark"]))
    fake_env = Environment(stdout_isatty=True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(fake_env, fake_args)
    assert stream_class == PrettyStream
    assert stream_kwargs.get("env") == fake_env

# Generated at 2022-06-21 14:29:33.345004
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.compat import is_windows
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import DEFAULT_CHUNK_SIZE
    from httpie.output.streams import CHUNK_SIZE_BY_LINE
    class FakeEnv:
        stdout_isatty = True
        is_windows = is_windows

    class FakeArgs:
        pretty = True
        stream = False
        json = False
        debug = False
        traceback = False
        style = None
        prettify = ['ok']
        headers = True
        body = True

    env = FakeEnv()
    args = Fake

# Generated at 2022-06-21 14:29:38.446679
# Unit test for function write_stream
def test_write_stream():
    class DummyData(object):
        def __init__(self, data):
            self.data = data

        def write(self, chunk):
            self.data.append(chunk)

    stream = [b'foo', b'bar']
    file = []
    write_stream(stream=stream, outfile=DummyData(file), flush=False)
    assert file



# Generated at 2022-06-21 14:29:48.702835
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import json
    import httpie.cli
    env = Environment()
    args = httpie.cli.parser.parse_args('')

    # test print body

# Generated at 2022-06-21 14:30:22.219607
# Unit test for function write_message
def test_write_message():
    class request:
        def full_url():
            return "http://www.google.com"
        def method():
            return "GET"
        def headers():
            return {"headers": "Hi"}
        def body():
            return "body"
    class env:
        def stdout():
            return "stdout"
        def is_windows():
            return False

    class args:
        def __init__(self):
            self.traceback = False
            self.debug = False
            self.stream = False
            self.prettify = "all"
    write_message(request,env,args,True,True)

# Generated at 2022-06-21 14:30:32.729377
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    URL = 'http://httpbin.org/get'
    testargs = [
        '--prettify',
        '--style', 'paraiso-light',
        '--stream',
        '--download'
    ]
    args = argparse.Namespace(**vars(args.parse_args(testargs)))
    env = Environment(
        stdin=six.StringIO(),
        stdout=six.StringIO(),
        stderr=six.StringIO(),
        is_windows=False,
        stdout_isatty=False,
    )
    session = requests.Session()
    prepared_request = session.prepare_request(requests.Request('GET', URL))
    response = requests.Response()
    response.status_code = 200
    text_body = 'Some text body'

# Generated at 2022-06-21 14:30:44.153708
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message(): 
    import os
    import sys
    import io
    import mock
    import pytest
    import requests
    import httpie.core
    import httpie.compat
    from httpie.constants import DEFAULT_UA
    from httpie.styles import default_style_map as style_map
    from httpie.context import Environment
    from httpie.compat import bytes
    from httpie.cli import parser
    from httpie.output.streams import RawStream

    # mock requests 
    # requests.PreparedRequest
    mock_request_prepare = \
        mock.create_autospec(
            httpie.core.prepare_request,
            return_value=(
                mock.Mock(spec=requests.PreparedRequest),
                mock.Mock(spec=requests.Session),
            )
        )

# Generated at 2022-06-21 14:30:51.516909
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser

    environment = Environment()
    arg1 = parser.parse_args(['--json'])
    arg2 = parser.parse_args(['--stream'])
    arg3 = parser.parse_args(['--prettify'])
    arg4 = parser.parse_args(['--prettify=colors'])
    arg5 = parser.parse_args(['--prettify=colors,bodies'])

    expected_res1 = (EncodedStream, {})

# Generated at 2022-06-21 14:31:00.442272
# Unit test for function write_message
def test_write_message():
    import io
    import json
    import requests
    import argparse
    from httpie.input import ParseArguments
    from httpie.client import Client
    from httpie.output import write_message
    from httpie.context import Environment
    from httpie.compat import is_windows
    from httpie.downloads import (Downloader, parse_content_range)
    from httpie.output.streams import RawStream
    from httpie.plugins import plugin_manager
    from httpie import ExitStatus
    from httpie.config import Config
    from httpie.status import ExitStatus
    from httpie.models import (
        Request,
        Response,
        FileLikeWithFilename,
        DownloadProgressAdapter,
        DownloadProgressFileWrapper,
        REDIRECT_STATI
    )
    from httpie import cli
    client

# Generated at 2022-06-21 14:31:09.122233
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    args = argparse.Namespace()
    env = Environment()
    requests_message = requests.PreparedRequest()
    stream = build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_body=True,
        with_headers=True,
    )
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == '\n\n'

# Generated at 2022-06-21 14:31:17.329917
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.cli import parse_args
    from httpie.context import Environment

    data = b'test_write_stream'
    stream = BytesIO(data)

    env = Environment(
        stdin=BytesIO(),
        stdout=BytesIO(),
        stderr=BytesIO()
    )
    args = parse_args([])

    write_stream(
        stream=stream,
        outfile=env.stdout,
        flush=env.stdout_isatty or args.stream
    )
    assert env.stdout.getvalue() == data

# Generated at 2022-06-21 14:31:18.015102
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-21 14:31:21.830815
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()

    expected_stream_class = EncodedStream
    expected_stream_kwargs = {
        'env': env
    }
    actual_stream_class, actual_stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=argparse.Namespace()
    )
    assert expected_stream_class == actual_stream_class
    assert expected_stream_kwargs == actual_stream_kwargs

    expected_stream_class = RawStream
    expected_stream_kwargs = {
        'chunk_size': RawStream.CHUNK_SIZE
    }

# Generated at 2022-06-21 14:31:22.804960
# Unit test for function write_message
def test_write_message():
    assert write_message('', '', '') == None

# Generated at 2022-06-21 14:31:54.609490
# Unit test for function write_stream
def test_write_stream():
    outfile = sys.stdout
    args = argparse.Namespace()
    env = Environment()
    with mock.patch('httpie.output.streams.write_stream') as mocked:
        my_stream = BaseStream()
        for _ in my_stream:
            pass
        write_stream(my_stream, outfile, args, env)
        mocked.assert_called_once()

# Generated at 2022-06-21 14:31:58.803364
# Unit test for function write_message
def test_write_message():
    env = Environment()
    args = argparse.Namespace()
    setattr(args, 'debug', True)
    setattr(args, 'traceback', True)
    assert (write_message(requests.PreparedRequest(), env, args, False, False) == None)


# Generated at 2022-06-21 14:32:09.735321
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from .utils import MockStdStreams

    mock_stdout = MockStdStreams.BYTES_IO()
    mock_stdout.isatty = lambda: True


# Generated at 2022-06-21 14:32:13.722112
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-21 14:32:18.927130
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import pytest
    import io
    import httpie.output.streams as streams


# Generated at 2022-06-21 14:32:30.228667
# Unit test for function write_message
def test_write_message():
    # test with headers
    test_args = argparse.Namespace()
    test_args.stream = False
    test_args.prettify = ['all']
    test_args.style = False
    test_env = Environment()

    requests_message = requests.Response()
    requests_message.headers = {'content-type': 'application/json'}
    outfile = io.StringIO()
    remember_stdout = sys.stdout

# Generated at 2022-06-21 14:32:33.755282
# Unit test for function write_message
def test_write_message():
    request = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    write_message(request, env, args, with_headers, with_body)

# Generated at 2022-06-21 14:32:40.168407
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.testing import mock
    from httpie.output.streams import PrettyStream
    from httpie.output.processing import Conversion
    from httpie.output.formatters.custom import Formatter

    class MockArgumentParser(object):
        def __init__(self):
            self.prettify = ['colors', 'format']
            self.style = 'colors'
            self.format = None
            self.stream = False
            self.debug = False
            self.traceback = False
            self.json = False
            self.format_options = None

    class MockEnv(object):
        def __init__(self):
            self.stdout = mock.Mock()
            self.stdout_isatty = True
            self.is_windows = False


# Generated at 2022-06-21 14:32:50.198554
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Mock(object):
        def __init__(self, name):
            self.name = name
        def write(self, x):
            self.buffer += x
        def __repr__(self):
            return self.name
        def flush(self):
            pass

    # Mock of Windows stdout

# Generated at 2022-06-21 14:32:54.954514
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    outfile = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=iter(['\x1b[2K']),
        outfile=outfile,
        flush=True,
    )
    assert outfile.getvalue() == '\x1b[2K'