

# Generated at 2022-06-21 14:24:06.303228
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    text = "foo"
    stream = (text.encode(),)
    outfile = StringIO("")
    flush = False
    write_stream_with_colors_win_py3(stream, outfile,flush)

# Generated at 2022-06-21 14:24:14.697418
# Unit test for function write_message
def test_write_message():
    import argparse
    from io import StringIO
    from httpie.context import Environment
    import sys
    import requests
    import requests_mock
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.output.streams import BufferedPrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    
    parser = argparse.ArgumentParser()
    HTTPBasicAuth().add_options(parser)
    args = parser.parse_args([
        "--auth=admin:123456",
    ])
    env = Environment()
    with requests_mock.Mocker() as m:
        url = "http://httpbin.org/cookies/set/sessioncookie/123456789"
        m.post(url)

# Generated at 2022-06-21 14:24:15.087019
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-21 14:24:23.584072
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Test basic cases
    env = Environment()
    args = argparse.Namespace(prettify=[], stream=False)
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    args = argparse.Namespace(prettify=[], stream=True)
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    # Test with stream=True and prettify=all
    args = argparse.Namespace(prettify=['all'], stream=False)

# Generated at 2022-06-21 14:24:34.836691
# Unit test for function write_stream
def test_write_stream():
    kwargs = {
        'stream': build_output_stream_for_message(
            args={
                'stream': True,
                'prettify': 'b'
            },
            env={
                'stdout': 'stdout',
                'stdout_isatty': False,
            },
            requests_message=requests.PreparedRequest,
            with_body=True,
            with_headers=False,
        ),
        # NOTE: `env.stdout` will in fact be `stderr` with `--download`
        'outfile': 'stdout',
        'flush': False

    }

# Generated at 2022-06-21 14:24:46.364747
# Unit test for function write_message
def test_write_message():
    # test write_message with file
    test_file = open('test_file.txt', mode='w', encoding='utf-8')
    test_file.write('test_file_write')
    test_file.close()
    test_file = open('test_file.txt', mode='r', encoding='utf-8')
    test_write_message_buffer = test_file.buffer
    test_write_message_w_str = b'test_file_write'
    test_write_message_with_file(
        test_write_message_buffer, test_write_message_w_str)
    # test write_message with stdout
    test_write_message_w_str = b'write_message_with_stdout'

# Generated at 2022-06-21 14:24:57.392258
# Unit test for function write_message

# Generated at 2022-06-21 14:25:06.663449
# Unit test for function write_stream
def test_write_stream():
    from httpie.core import main
    from httpie.output import write_stream
    import io
    from io import BytesIO
    from httpie.output.streams import RawStream
    from httpie.context import Environment
    from httpie.cli import parser

    args = parser.parse_args(['--stream'])
    env = Environment(args, stdin=BytesIO(b"data"), stdout=io.StringIO(),
                      stderr=io.StringIO(), vars={})

    bs = RawStream([b'test'])
    write_stream(bs, env.stdout, flush=False)



# Generated at 2022-06-21 14:25:15.258406
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    args.stream = False
    env = Environment()
    env.stdout_isatty = False
    args.prettify = False
    with open('./README.md', 'rb') as f:
        response = requests.Response()
        response._content = f.read()
        response.raw = f
        response.headers['content-type'] = 'application/json'
        response.encoding = 'utf-8'
        response.status_code = 200
        response.reason = 'OK'

        print(response.text)
        print('\n')
        print(test_build_output_stream_for_message.__doc__)

# Generated at 2022-06-21 14:25:26.921888
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    
    def mock_args(**kwargs):
        class Mock(object):
            pass
        mock = Mock()
        mock.__dict__.update(**kwargs)
        return mock


    def mock_env(stdout_isatty, stdout, stderr):
        class Mock(object):
            pass
        mock = Mock()
        mock.stdout_isatty = stdout_isatty
        mock.stdout = stdout
        mock.stderr = stderr
        return mock

    def mock_request(is_body_upload_chunk):
        class Mock(object):
            pass
        mock = Mock()
        mock.is_body_upload_chunk = is_body_upload_chunk
        return mock

    request = mock_request(False)

    args = mock_args

# Generated at 2022-06-21 14:25:43.649638
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from . import output
    import sys
    import mock

    env = Environment(
        colors=256,
        stdin_isatty=True,
        stdout_isatty=True,
        stderr_isatty=True,

    )
    args = mock.Mock(headers=True, body=True,
                     prettify={"body", "headers"},
                     style='default',
                     format_options={},
                     json=False,
                     debug=False,
                     traceback=False,
                     stream=False)

    stream_class, stream_kwargs = output.get_stream_type_and_kwargs(env, args)
    assert stream_class is output.BufferedPrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'] == output.Conversion()


# Generated at 2022-06-21 14:25:55.483445
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import BaseStream
    from httpie.output.writers import write_stream_with_colors_win_py3
    class MockStream(BaseStream):
        def __iter__(self):
            yield b'\x1b[0m<div>'
            yield b'This is a test\n'
            yield b'</div>'

    outfile = mock.MagicMock()
    write_stream_with_colors_win_py3(MockStream(), outfile, False)
    outfile.write.assert_any_call('\x1b[0m<div>')
    outfile.write.assert_any_call('This is a test\n')
    outfile.write.assert_any_call('</div>')
    outfile.buffer.write.assert_any

# Generated at 2022-06-21 14:26:07.462423
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import requests
    from httpie import ExitStatus
    from httpie.input import ParseError
    from httpie.cli import parser
    from httpie.context import Environment, EnvironmentError
    from httpie.compat import is_windows
    from httpie.models import KeyValue, KeyValueArgType, HTTPRequest
    from httpie.output import streams as output_streams
    from httpie.output.streams import (
        BaseStream, PrettyStream, BufferedPrettyStream, RawStream, EncodedStream,
    )
    from httpie.output.write_stream import (
        write_message,
        build_output_stream_for_message,
        get_stream_type_and_kwargs
    )
    from httpie import ExitStatus
    from httpie.utils import VERSION

# Generated at 2022-06-21 14:26:11.169837
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    def check(args, expected_stream_class):
        args = argparse.Namespace(**args)
        stream_class, stream_kwargs = get_stream_type_and_kwargs(
            env=Environment(stdout_isatty=False), args=args
        )
        assert stream_class == expected_stream_class

# Generated at 2022-06-21 14:26:21.196304
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    from httpie.context import Environment
    from httpie.output.streams import RawStream, PrettyStream, EncodedStream

    env = Environment(
        stdout_isatty=True,
        prefer_json=False)

    # prettify=False, stream=False
    args = argparse.Namespace(
        prettify=False, stream=False)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env}

    # prettify=False, stream=True
    args = argparse.Namespace(
        prettify=False, stream=True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class

# Generated at 2022-06-21 14:26:25.672567
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    exception_raised = False
    try:
        build_output_stream_for_message(
            args = lambda: None,
            env = Environment(),
            requests_message = requests.PreparedRequest(),
            with_headers = False,
            with_body = False,
        )
    except BaseException as e:
        exception_raised = True
        assert str(e) == 'Unexpected request object: <PreparedRequest [GET]>'
    assert exception_raised == True

# Generated at 2022-06-21 14:26:38.360395
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.plugins import builtin
    from httpie.cli import parser
    args = parser.parse_args(
        ['-p', 'hb']
    )
    env = Environment(
        colors=256,
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        is_windows=False,
        # plugins=[builtin.BuiltinPlugin()],
    )
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert isinstance(stream_class, BufferedPrettyStream)
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__ == Conversion
    assert stream_kwargs['formatting'].__class__ == Formatting
   

# Generated at 2022-06-21 14:26:45.986681
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import (
        RawStream,
        EncodedStream,
        PrettyStream,
        BufferedPrettyStream,
    )
    from httpie.context import Environment
    from httpie.config import DEFAULTS
    from httpie.plugins import plugin_manager
    from httpie.output.formatters.colors import (
        get_style,
    )

    def create_parser():
        class Parser:
            def __init__(self, args):
                for k, v in args.items():
                    setattr(self, k, v)

        return Parser

    args = {
        'prettify': 'all',
        'stream': False,
        'style': 'paraiso-light',
        'json': False,
        'format_options': {},
    }

    #

# Generated at 2022-06-21 14:26:53.611013
# Unit test for function write_stream
def test_write_stream():
    from httpie.core import main;
    from httpie import ExitStatus
    args = main.parser.parse_args(['httpie', 'https://httpie.org'])
    env = main.get_environments()
    env.stdout = sys.stdout
    r = requests.get('http://httpbin.org/get')
    write_message(
        requests_message=r,
        env=env,
        args=args,
        with_headers=True,
        with_body=True,
    )

# Generated at 2022-06-21 14:27:01.235127
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    import os
    import pytest
    from httpie.output.streams import BaseStream

    class MyStream(BaseStream):
        def __init__(self):
            pass

        def __iter__(self):
            yield b'Hello world'

    if sys.platform.startswith('win32'):
        # Skip this test because the purpose of the function is to
        # write to the buffer on windows, and we cannot write
        # to a buffer on a stdin file.
        pytest.skip("line buffering not supported on Windows")

    old_stdout = sys.stdout
    stdout_fd = stdout = None

# Generated at 2022-06-21 14:27:17.533491
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # pylint: disable=redefined-outer-name
    from unittest.mock import patch, Mock
    from io import StringIO

    from httpie.models import HTTPResponse
    from httpie.output.streams import PrettyStream

    # pylint: disable=protected-access
    with patch.object(PrettyStream, '__init__', return_value=None), \
            patch.object(PrettyStream, '__iter__', return_value=[]):
        env = Mock()
        args = Mock(prettify=['colors'])
        env.stdout.encoding = 'utf-8'

# Generated at 2022-06-21 14:27:20.893288
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream_class = PrettyStream
    stream_kwargs = {
        'msg': 'test'
    }
    write_stream_with_colors_win_py3(
        stream=stream_class,
        outfile=stream_kwargs,
        flush=False
    )


# Generated at 2022-06-21 14:27:31.957170
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import unittest

    class build_output_stream_for_messageTestCase(unittest.TestCase):

        def test_build_output_stream_for_message(self):
            from httpie.compat import is_windows
            from httpie import ExitStatus
            from httpie.cli import parser
            from httpie.output.streams import BufferedPrettyStream
            from httpie.output.streams import EncodedStream
            from httpie.output.streams import PrettyStream
            from httpie.output.streams import RawStream
            from httpie.output.streams import get_content_stream
            from httpie.core import main
            from httpie.core import main_debug

            # Test missing environment variable

# Generated at 2022-06-21 14:27:33.416793
# Unit test for function write_message
def test_write_message():
    requests_message='test'
    env='test'
    args='test'
    write_message(requests_message,env,args)

# Generated at 2022-06-21 14:27:42.127461
# Unit test for function write_message
def test_write_message():
    if not (with_body or with_headers):
        return
    write_stream_kwargs = {
        'stream': build_output_stream_for_message(
            args=args,
            env=env,
            requests_message=requests_message,
            with_body=with_body,
            with_headers=with_headers,
        ),
        # NOTE: `env.stdout` will in fact be `stderr` with `--download`
        'outfile': env.stdout,
        'flush': env.stdout_isatty or args.stream
    }

# Generated at 2022-06-21 14:27:44.910365
# Unit test for function write_message
def test_write_message():
  import os
  os.environ['http_proxy'] = ''
  os.environ['https_proxy'] = ''
  print("Testing function write_message")
  import httpie.cli
  httpie.cli.main()

# Generated at 2022-06-21 14:27:53.429267
# Unit test for function write_stream
def test_write_stream():
    counter = 0
    chunks = ['foo', 'bar']
    def fake_stdout_write(chunk):
        nonlocal counter
        counter += 1
        assert chunk == chunks[counter - 1]
        if counter == len(chunks):
            raise IOError(errno.EPIPE, 'fake broken pipe')

    write_stream_kwargs = {
        'stream': [bytes(chunk, 'utf-8') for chunk in chunks],
        'outfile': 'fake outfile',
        'flush': True
    }

    with mock.patch('httpie.output.util.write.flush',
                    side_effect=fake_stdout_write, create=True):
        with pytest.raises(IOError):
            write_stream(**write_stream_kwargs)

# Generated at 2022-06-21 14:27:59.509220
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    verify that bytes in the stream are written correctly to the output file
    :return:
    """
    buf = StringIO()
    ostream = BufferedPrettyStream(with_body=True, with_headers=True, prettified_body='\x1b[32mfoo\x1b[0m',
                                   prettified_headers='\x1b[32mheaders\x1b[0m')
    write_stream_with_colors_win_py3(stream=ostream, outfile=buf, flush=False)
    assert buf.getvalue().encode() == b'headers\n\n\x1b[32mfoo\x1b[0m\n\n'

# Generated at 2022-06-21 14:28:04.818468
# Unit test for function write_message
def test_write_message():
    # input arguments:
    env = Environment()
    env.stdout = sys.stdout
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    write_message({"key": "value"}, env, args)


# Generated at 2022-06-21 14:28:13.342695
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Test if function write_stream_with_colors_win_py3 writes correctly.

    """
    from io import TextIOWrapper
    from tempfile import TemporaryFile

    f = TemporaryFile("w+")
    f.write("test")
    f.seek(0)

    assert write_stream_with_colors_win_py3(
        stream=EncodedStream(env=Environment(stdout_isatty=False)),
        outfile=TextIOWrapper(f),
        flush=False
    ) is None
    f.seek(0)
    assert f.read() == "test"

# Generated at 2022-06-21 14:28:38.252274
# Unit test for function write_stream
def test_write_stream():
    class FakeFile:
        def __init__(self, content):
            self.content = content
        def write(self, content):
            self.content += content
        def flush(self):
            pass
    outfile = FakeFile("")
    class FakeStream:
        def __iter__(self):
            yield b"Hello"
            yield b" world!"
        def __next__(self):
            raise StopIteration()
    write_stream(FakeStream(), outfile, False)
    assert outfile.content == "Hello world!"


# Generated at 2022-06-21 14:28:40.069250
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs() == (EncodedStream, {'env': Environment()})

# Generated at 2022-06-21 14:28:45.186980
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, RawStream, EncodedStream
    env = Environment(stdout_isatty=True, colors=256)
    args = argparse.Namespace(prettify=['all'], style='paraiso-dark', stream=False, json=False, format_options='')
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream


# Generated at 2022-06-21 14:28:56.275278
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.config import Config
    from httpie.plugins import plugin_manager

    env = Environment()
    parser = argparse.ArgumentParser()
    plugin_manager.load_internal_plugins()
    plugin_manager.load_external_plugins(parser)
    args = parser.parse_args([])
    config = Config(env, args)

    MESSAGE_SEP_LEN = len(MESSAGE_SEPARATOR)

    # HTTP Request
    req_headers = [
        (b'a', b'b'),
        (b'c', b'd'),
    ]
    req_body = b'e'
    req = requests.PreparedRequest()
    req.body = req_body
    req.headers = req_headers

    # HTTP Response

# Generated at 2022-06-21 14:28:58.841495
# Unit test for function write_stream
def test_write_stream():
    print("test_write_stream")
    stream = 'a'
    outfile = 'b'
    flush = 'c'
    write_stream(stream, outfile, flush)


# Generated at 2022-06-21 14:29:02.241848
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(
        stream = BaseStream(),
        outfile = build_output_stream_for_message(
        args=argparse.Namespace(),
        env=Environment(),
        requests_message=Type(),
        with_headers=False,
        with_body=False,
        ),
        flush = True,
    ) == "write_stream"

# Generated at 2022-06-21 14:29:02.984607
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-21 14:29:12.600655
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(prettify=None, stream=False, style=None, json=None,
                              format_options=None)

    # EncodedStream when stdout is a tty
    env = Environment(stdout_isatty=True)
    stream_class, _ = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == EncodedStream

    # EncodedStream when stdout is not a tty (Windows PowerShell)
    # (regression test for issue #30)
    env = Environment(stdout_isatty=False)
    stream_class, _ = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == EncodedStream

    # RawStream when stdout is not a tty
    env

# Generated at 2022-06-21 14:29:22.196011
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import httpie.output.streams

    class FakeStream(httpie.output.streams.BaseStream):
        def __init__(self):
            self.iterable = [
                b'foo\x1b[0m\x1b[1mbar',
                b'baz\x1b[0mbaz',
                b'\x1b[0m'
            ]
            self.index = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.index >= len(self.iterable):
                raise StopIteration()
            else:
                self.index += 1
                return self.iterable[self.index - 1]

    stream = FakeStream()

# Generated at 2022-06-21 14:29:32.938643
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import tempfile
    import httpie.cli

    # Dummy HTTP Request
    request = requests.Request('GET', 'http://httpbin.org/get')
    prepped = request.prepare()

    # Dummy HTTP Response
    response = requests.Response()
    response.status_code = 200

    # Dummy args
    parser = httpie.cli.get_parser()
    args = parser.parse_args(args=[])
    args.prettify = ['all']

    # Dummy environment

# Generated at 2022-06-21 14:30:04.270700
# Unit test for function write_message
def test_write_message():
    import argparse
    import httpie
    import tempfile
    import os

    env = httpie.Environment()
    args = parse_args(["--json"])
    with tempfile.TemporaryDirectory() as dir:
        with open(os.path.join(dir, 'tmp'), 'w+') as out:
            prev_out = env.stdout
            env.stdout = out
            write_message(requests.Response(), env, args, True, True)
            env.stdout = prev_out

        with open(os.path.join(dir, 'tmp'), 'r') as f:
            assert f.read() == "HTTP/1.1 200 OK\r\n\r\n{\n}\n\n"

# Generated at 2022-06-21 14:30:07.014260
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    write_message(requests_message = requests_message, env = env, args = args)

# Generated at 2022-06-21 14:30:16.115907
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    f = StringIO()
    stream = BufferedPrettyStream(
        msg=HTTPResponse("HTTP/1.1 200 OK\r\nHost:example.com\r\nFoo:bar"),
        with_headers=True,
        conversion=Conversion(),
    )
    write_stream_with_colors_win_py3(stream, f, True)
    expected = (
        '\x1b[37mHTTP/1.1 \x1b[92m200 \x1b[39mOK\r\n\x1b[37mHost: \x1b[94m'
        'example.com\r\n\x1b[37mFoo: \x1b[93mbar\x1b[39m\r\n'
    )
   

# Generated at 2022-06-21 14:30:21.080369
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.stream = False
    args.prettify = ['all']

    (stream_class, stream_kwargs) = get_stream_type_and_kwargs(env, args)
    assert stream_class is BufferedPrettyStream
    assert stream_kwargs['env'] is env
    assert stream_kwargs['conversion'] is not None
    assert stream_kwargs['formatting'] is not None

# Generated at 2022-06-21 14:30:31.302866
# Unit test for function write_message
def test_write_message():
    from .utils import MockEnvironment
    from .utils import mock
    from . import ExitStatus
    from .compat import is_windows
    from .cli.base import http
    from requests.models import Response, Request
    from httpie import __version__
    from httpie.output.streams import BufferedPrettyStream, RawStream, PrettyStream
    import tempfile
    import os

    def do_args(msg, *args):
        args = ['--verbose', '--debug', '--traceback'] + list(args) + [
            '--print=HB',
            'httpbin.org/get'
        ]
        return args

    env = MockEnvironment()

# Generated at 2022-06-21 14:30:36.920091
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    import io

    outfile = io.TextIOWrapper(io.BytesIO(), encoding='utf8')
    stream = EncodedStream(msg='test', env=Environment())
    write_stream_with_colors_win_py3(stream, outfile, flush=False)

    assert outfile.getvalue() == 'test'

# Generated at 2022-06-21 14:30:47.225442
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.stream import build_output_stream_for_message
    from io import StringIO
    import os
    import sys
    import pytest
    from httpie import ExitStatus

    make_request_func = "httpie.core.main.make_request"
    make_request_func_test = "tests.functional.test_output_stream.make_request"
    env_class = "httpie.core.environment.Environment"
    env_class_test = "tests.functional.test_output_stream.TestEnvironment"
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=TestEnvironment(),
        args=main.parser.parse_args(['-b','BODY','GET','http://localhost:8000'])
    )
    message

# Generated at 2022-06-21 14:30:56.709952
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    def t(
        args,
        env,
        requests_message,
        with_headers=False,
        with_body=False,
        expected_output=''
    ):
        args = argparse.Namespace()
        env = Environment()
        out = build_output_stream_for_message(
            args,
            env,
            requests_message,
            with_headers,
            with_body,
        )

        actual_output = b''.join(out)
        assert actual_output == expected_output

    t(
        None,
        None,
        requests.PreparedRequest(),
        False,
        False,
        b''
    )




# Generated at 2022-06-21 14:31:03.176891
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = EncodedStream()

    def _write(data):
        stream_iter = iter(stream)
        data_bytes = data.encode()
        assert data_bytes == next(stream_iter)

    stream.process_str = _write
    stream.process_bytes = _write

    stream.write_headers(HTTPRequest())
    stream.write_body("whatever")
    stream.write_body("\n")
    stream.write_headers(HTTPRequest())
    stream.write_body("\n")

# Generated at 2022-06-21 14:31:13.880146
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    from os import linesep

    from httpie.cli import parser
    from httpie.environment import Environment

    test_arguments_data = [
        (dict(vars(parser.parse_args([]))),
         {'stream': False, 'prettify': False}),
        (dict(vars(parser.parse_args(['--stream']))),
         {'stream': True, 'prettify': False}),
        (dict(vars(parser.parse_args(['--pretty', 'all']))),
         {'stream': False, 'prettify': ['all']}),
        (dict(vars(parser.parse_args(['--stream', '--pretty', 'all']))),
         {'stream': True, 'prettify': ['all']}),
    ]


# Generated at 2022-06-21 14:31:57.477349
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class TestArgs:
        def __init__(self):
            self.prettify = []
            self.stream = False
            self.style = None
            self.json = False
            self.format_options = []

    class TestEnv:
        def __init__(self):
            self.stdout = None
            self.stdout_isatty = False

    class TestParsedRequest:
        def __init__(self):
            self.body = {}
            self.headers = {}
            self.url = ''
            self.method = 'GET'

    class TestParsedResponse:
        def __init__(self):
            self.body = b''
            self.headers = b''
            self.reason = b''
            self.status_code = 200
            self.url = ''

# Generated at 2022-06-21 14:32:08.162014
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    def new_args(**kwargs):
        return argparse.Namespace(**kwargs)

    def new_env(**kwargs):
        return Environment(stdout_isatty=True, **kwargs)

    args = new_args(
        prettify='colors',
        stream=True,
    )
    env = new_env()
    stream_type, stream_kwargs = get_stream_type_and_kwargs(args, env)
    assert stream_type is PrettyStream
    assert stream_kwargs['env'] == env
    assert not isinstance(stream_kwargs['formatting'], Formatting)
    assert not isinstance(stream_kwargs['conversion'], Conversion)

    args = new_args()
    env = new_env()
    stream_type, stream_kwargs = get_stream

# Generated at 2022-06-21 14:32:09.738701
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(requests, Environment(), True) == 'requests'

# Generated at 2022-06-21 14:32:16.909446
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # import pytest
    # pytest.main()

    import os
    import httpie
    import requests
    import json

    args = httpie.cli.parser.parse_args(['--json', 'http://httpbin.org/post'])
    env = Environment(stdin=None, stdout=None, stderr=None, vars={})

    url = 'http://httpbin.org/post'
    json_data = {'json_data': 'json_data'}
    prepared_request = requests.Request('POST', url, json=json_data).prepare()

    # When
    (buffered_pretty_stream, buffered_pretty_stream_kwargs), _ = (
        get_stream_type_and_kwargs(env=env, args=args))
    output = buffered_pretty_stream

# Generated at 2022-06-21 14:32:27.098684
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    测试函数write_stream_with_colors_win_py3
    """
    from io import StringIO
    from tests.compat import b
    
    outfile = StringIO()
    # 产生测试数据
    stream = EncodedStream(b'\x1b[1mblue\x1b[0m', env=Environment())
    
    write_stream_with_colors_win_py3(
        stream,
        outfile,
        flush=False,
    )
    assert outfile.getvalue() == 'blue'

# Generated at 2022-06-21 14:32:35.737801
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Tests that output streams are set up properly

    class MockArgs:
        def __init__(self, prettify, stream, style, json, format_options):
            self.prettify = prettify
            self.stream = stream
            self.style = style
            self.json = json
            self.format_options = format_options

    class MockEnv:
        def __init__(self, stdout_isatty):
            self.stdout_isatty = stdout_isatty

    args = MockArgs(
        prettify=['colors'],
        stream=True,
        style='paraiso-dark',
        json=True,
        format_options={'pretty_all': True}
    )
    env = MockEnv(stdout_isatty=True)

    assert get_stream_

# Generated at 2022-06-21 14:32:46.789562
# Unit test for function write_message
def test_write_message():
    import requests

    class Environment(object):
        def __init__(self, stdout_isatty=True):
            self.stdout_isatty = stdout_isatty

    class Namespace(object):
        def __init__(self, json=False, stream=False,
                     debug=False, traceback=False,
                     prettify='all', style='solarized',
                     format_options={}):
            self.json = json
            self.stream = stream
            self.debug = debug
            self.traceback = traceback
            self.prettify = prettify
            self.style = style
            self.format_options = format_options


# Generated at 2022-06-21 14:32:57.561967
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():

    from tempfile import TemporaryFile
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, RawStream

    args_template = argparse.Namespace(
        stream=False,
        prettify=False,
        style=None,
        json=None,
        format_options={},
    )

    # Class EncodedStream without stdout_isatty
    tmp_stream = TemporaryFile('w+t')
    env = Environment(stdout=tmp_stream, stderr=tmp_stream, is_windows=None)
    stream_type, stream_kwags = get_stream_type_and_kwargs(
        env=env,
        args=args_template
    )
    assert stream_type is EncodedStream
    assert 'env' in stream_kwags

    # ------------------------------------------

    # Class RawStream

# Generated at 2022-06-21 14:33:06.709160
# Unit test for function write_message
def test_write_message():
    from httpie.output.formatters.colors import NO_COLOR_PALETTE
    from httpie.output.formatters.default import DEFAULT_PALETTE
    from httpie.output.formatters.json import JSON_PALETTE
    from httpie.output.formatters.tutorial import TUTORIAL_PALETTE
    from httpie.output.formatters.utils import print_via_pager
    from httpie.session import Session
    import httpie.cli

    s = Session()

    args = argparse.Namespace()
    args.stream = False
    args.debug = False
    args.traceback = True
    args.json = False
    args.pretty = True
    args.all = True
    args.download = False
    args.style = 'unknown'


# Generated at 2022-06-21 14:33:08.256954
# Unit test for function write_stream
def test_write_stream():
    assert write_stream(BaseStream(None, False, False), sys.stdout, True)