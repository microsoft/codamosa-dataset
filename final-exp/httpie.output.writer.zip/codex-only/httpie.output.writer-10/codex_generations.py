

# Generated at 2022-06-23 19:40:30.765827
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # using a fake stream instead of stdout to test write_stream_with_colors_win_py3
    class FakeStream(object):
        def __init__(self):
            self.output = ""
        def write(self, input):
            self.output += input
            
    class FakeBaseStream(BaseStream):
        def __iter__(self):
            yield b'\x1b[1m' + b'foo' + b'\x1b[0m'
            yield b'bar'

    fake_stream = FakeStream()
    args = argparse.Namespace()
    setattr(args, 'prettify', ['colors'])
    env = Environment()
    setattr(env, 'stdout_isatty', True)
    setattr(env, 'stdout', fake_stream)
    write

# Generated at 2022-06-23 19:40:39.384185
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys

    import pytest
    from httpie.context import Environment

    args = argparse.Namespace(
        stream=False,
        debug=False,
        traceback=False,
        prettify=('colors',),
        style='paraiso-dark',
        format_options={},
        json=True,
    )
    env = Environment()
    env.stdout = io.BytesIO()
    env.stdout_isatty = True
    env.stdin_isatty = True

    # Windows with Python 3 and ANSI color support
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-23 19:40:40.063991
# Unit test for function write_stream
def test_write_stream():
    pass


# Generated at 2022-06-23 19:40:45.277513
# Unit test for function write_stream
def test_write_stream():
    # pylint: disable=protected-access
    import io
    import pytest

    class FakeArgs(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class FakeStream(BaseStream):
        def __init__(self, chunk_1=b'CHUNK_1'):
            self.chunk_1 = chunk_1
            self.chunk_2 = b'CHUNK_2'
            self.i = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.i < 2:
                self.i += 1
                if self.i == 1:
                    return self.chunk_1
                return self.chunk_2
           

# Generated at 2022-06-23 19:40:54.296401
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io

    class FakeFile(io.TextIOWrapper):
        def __init__(self):
            stream = io.BytesIO()
            super().__init__(stream, encoding='utf8')
            self.encoding = 'utf8'
            self._writes = []

        def write(self, s):
            # Record strings written to .write() for validation.
            self._writes.append(s)

    fake_file = FakeFile()

    chunks = [
        b'foo',
        b'\x1b[0m',
        b'\x1b[1m',
        b'\x1b[0m',
        b'bar\x1b[31;1mbaz',
    ]


# Generated at 2022-06-23 19:41:02.589346
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        colors=256,
        stdout_isatty=True,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdin=sys.stdin,
    )
    args = argparse.Namespace(
        stream=True,
        prettify='all',
        style="default",
        format_options='',
        json=False,
    )

    res = get_stream_type_and_kwargs(env, args)
    assert type(res[1]) is dict

# Generated at 2022-06-23 19:41:13.389133
# Unit test for function write_message
def test_write_message():
    # Test 1
    with requests.PreparedRequest() as req:
        # Test 1.1
        with requests.Response() as resp:
            class Test1():
                def __init__(self, req, resp):
                    self.req = req
                    self.resp = resp

            test1 = Test1(req, resp)
            for i in test1.req, test1.resp:
                write_message(i, env=None, args=None, with_headers=False, with_body=False)
        # Test 1.2
        with requests.Response() as resp:
            class Test2():
                def __init__(self, req, resp):
                    self.req = req
                    self.resp = resp

            test2 = Test2(req, resp)

# Generated at 2022-06-23 19:41:21.403833
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.input import parse_items

    args = parse_items([
        '--form', 'a=b',
        '--pretty',
        '—style=autumn',
        '--stream',
        '--json',
        '--format-options=utf8=False',
        'GET',
        'https://httpbin.org/get'
    ])
    stream_type, kwargs = get_stream_type_and_kwargs(None, args)
    assert stream_type is PrettyStream
    assert kwargs['conversion'].is_enabled() is True
    assert kwargs['formatting'].explicit_json is True
    assert kwargs['formatting'].format_options['utf8'] is False


# Generated at 2022-06-23 19:41:30.616121
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import os
    import httpie
    from httpie import ExitStatus
    from httpie.cli import parser
    from httpie.compat import is_windows
    from httpie.core import main
    from httpie.context import Environment
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    import requests
    import argparse
    import errno
    from typing import IO, TextIO, Tuple, Type, Union
    url = 'http://httpbin.org/'
    args = parser.parse_args([url])
    args.prettify = ['all']

# Generated at 2022-06-23 19:41:39.575298
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import __main__
    from httpie.output.streams import EncodedStream
    from httpie.context import Environment
    import tempfile
    import io
    import os

    args = __main__.parse_args([])
    env = Environment(args)

    temp_stdout = tempfile.TemporaryFile()
    env.stdout = io.TextIOWrapper(temp_stdout)

    result = list(build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=HTTPResponse({"Content-Type": "text/plain; charset=utf-8"}, b"Chunk1\nChunk2\n"),
        with_headers=True,
        with_body=True
    ))


# Generated at 2022-06-23 19:41:50.802668
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.core import main
    from httpie.output.initialize import init_output_options
    from httpie.config import EnvironmentDefaults
    from httpie.compat import is_windows
    from httpie.output.streams import EncodedStream, BaseStream, PrettyStream

    args = main.parser.parse_args(args=[])

    #case1: stream_class=RawStream, stream_kwargs={'chunk_size': RawStream.CHUNK_SIZE}
    env = Environment(
        stdin=io.StringIO(),
        stdout=io.BytesIO(),
        stderr=io.StringIO(),
        is_windows=is_windows,
        colors=256,
        stdout_isatty=False,
        config_dir=EnvironmentDefaults.CONFIG_DIR
    )
    stream

# Generated at 2022-06-23 19:41:58.205867
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.downloads import write
    from httpie.input import ParseRequest
    from httpie.output.streams import BaseStream
    from httpie.output.utils import write_message
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import Loader as BuiltinLoader
    from httpie.plugins.manager import PluginManager
    from httpie.plugins.builtin import FormatterPlugin
    from httpie.plugins import builtin
    from httpie.config import Config
    from httpie.output.streams import write
    from httpie.plugins import builtin
    from httpie.plugins.builtin import HTTPiePlugin
    from httpie.plugins.builtin import Loader as BuiltinLoader
    from httpie.plugins.manager import PluginManager
   

# Generated at 2022-06-23 19:42:08.451043
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace(
        stream=False,
        prettify=False
    )
    requests_message = requests.PreparedRequest()
    requests_message.url = 'http://www.google.com'
    with_headers = True
    with_body = True
    a = list(build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_headers=with_headers,
        with_body=with_body
    ))
    outfile = env.stdout
    write_stream(a, outfile, False)

# Generated at 2022-06-23 19:42:11.070615
# Unit test for function write_stream
def test_write_stream():
    outfile = "abc"
    env = "def"
    args = "ghi"
    stream = "jkl"

    write_stream(stream, outfile, env, args)


# Generated at 2022-06-23 19:42:17.571873
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.core import main
    # Create HTTP Basic Auth plugin
    HTTPBasicAuth().sessions.__init__()
    # Temporary file for the output
    temp_outfile = StringIO()
    # Temporary env
    temp_env = Environment(stdout=temp_outfile, stdin=StringIO(), stderr=StringIO())
    # Check that the failure is returned

# Generated at 2022-06-23 19:42:29.488892
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """
    $ http POST http://localhost:5000/some_api/some_url/some_id/some_more_id?some_parameter=some_value
    """
    r = requests.post('http://localhost:5000/some_api/some_url/some_id/some_more_id?some_parameter=some_value')
    env = Environment(stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr)
    args = argparse.Namespace(prettify=[], style='default', stream=False, 
        json=False, debug=False, traceback=False)
    stream_type_and_kwargs = get_stream_type_and_kwargs(env, args)
    stream_type = stream_type_and_kwargs[0]
   

# Generated at 2022-06-23 19:42:30.118087
# Unit test for function write_stream
def test_write_stream():
    pass

# Generated at 2022-06-23 19:42:38.660614
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli.parser import parser
    from httpie.cli.util import set_by_cli
    from httpie.context import Environment
    import requests
    import io
    import sys

    io_obj = io.StringIO()
    sys.stdout = io_obj
    sys.stderr = io_obj

    parser.is_valid = False
    args = parser.parse_args(['--style', 'auto', '--prettify', 'all', '--json', '--stream'])
    env = Environment(colors=256, stdin=sys.stdin, stdout=sys.stdout, stderr=sys.stderr, is_windows=False)
    env, args = set_by_cli(env, args)

    fake_req = requests.PreparedRequest()

# Generated at 2022-06-23 19:42:43.037211
# Unit test for function write_message
def test_write_message():
    # get the current working environment
    env = Environment()
    # create a mock request with a random url
    request = requests.Request('https://www.example.com')
    # make a response with that request
    response = requests.Response()
    # use the write_message function to write the response
    write_message(response, env, request)

# Generated at 2022-06-23 19:42:53.099774
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import ColorizedStream, StreamStub

    stream_stub = StreamStub(text=True)
    text_chunk = b'\x1b[1m'
    bytes_chunk = b'\x1b[0m'

    stream = ColorizedStream(
        chunks=[text_chunk, bytes_chunk],
        stream=stream_stub,
    )
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=stream_stub._outfile,
        flush=False,
    )
    assert bytes_chunk in stream_stub._outfile.buffer.getvalue()
    assert text_chunk in stream_stub._outfile.getvalue()

# Generated at 2022-06-23 19:43:03.170897
# Unit test for function write_message
def test_write_message():
    # test case 1
    with open('test-file-1.txt', 'w+') as f:
        filename = f.name
    class args(object):
        def __init__(self, body_as_form, body_as_form_hex, debug, download, form, headers, http, json, method, output, prettify, style, traceback, verbose):
            self.body_as_form = body_as_form
            self.body_as_form_hex = body_as_form_hex
            self.debug = debug
            self.download = download
            self.form = form
            self.headers = headers
            self.http = http
            self.json = json
            self.method = method
            self.output = output
            self.prettify = prettify
            self.style = style
            self

# Generated at 2022-06-23 19:43:07.641009
# Unit test for function write_message
def test_write_message():
    argv = ['get', 'http://httpbin.org/post']
    args = parser.parse_args(argv)
    env = Environment(args)
    requests_message = requests.PreparedRequest()
    write_message(requests_message, env, args, True, True)

# Generated at 2022-06-23 19:43:15.559416
# Unit test for function write_stream
def test_write_stream():
    File = namedtuple('File', ['write'])
    m = mock.MagicMock()
    m.write = mock.MagicMock(side_effect=lambda x: x)
    m.buffer = m
    write_stream(
        stream=['a', 'b', 'c'],
        outfile=m,
        flush=False
    )
    assert m.write.call_count == 3
    assert m.buffer.write.call_count == 3



# Generated at 2022-06-23 19:43:20.522873
# Unit test for function write_message
def test_write_message():
    import requests
    import httpie

    env = httpie.context.Environment()
    args = argparse.Namespace()
    r = requests.get('http://example.com/')
    with_headers = True
    with_body = True
    write_message(r, env, args, with_headers, with_body)

# Generated at 2022-06-23 19:43:30.946096
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.context import Environment
    from httpie.cli import parser
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.utils import info
    import requests
    import os
    import tempfile
    import subprocess
    # Generate the test case
    raw_url = "http://127.0.0.1:8877/get"
    s = requests.Session()
    r = s.get(raw_url)
    response_message = r.request
    request_message = r

    # Test case 1
    args = parser.parse_args(args=[])
    env = Environment()


# Generated at 2022-06-23 19:43:36.032312
# Unit test for function write_stream
def test_write_stream():
    """TODO: Docstring for test_write_stream.
    :returns: TODO

    """
    print("Test: write_stream")
    a = io.StringIO()
    b = "Test"
    c = io.BytesIO(b.encode())
    write_stream(c, a, True)
    print(a.getvalue())



# Generated at 2022-06-23 19:43:41.933300
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # RawStream
    assert get_stream_type_and_kwargs(
        env=Environment(
            stdout_isatty=False,
            stdout_encoding='ascii',
        ),
        args=argparse.Namespace(
            prettify=None,
            stream=False,
        ),
    ) == (RawStream, {
        'chunk_size': RawStream.CHUNK_SIZE
    })

    # RawStream line-by-line

# Generated at 2022-06-23 19:43:52.821886
# Unit test for function write_message
def test_write_message():
    import mock
    import requests
    from httpie.cli import parser
    from httpie.output.streams import PrettyStream
    
    args = parser.parse_args()
    
    req = requests.Request('GET','www.google.com')
    prep = req.prepare()
    env = mock.MagicMock(stdout_isatty=True, is_windows=False)
    args.debug=True
    args.traceback=True
    args.prettify=False
    args.stream=False
    
    with mock.patch('httpie.output.streams.PrettyStream') as _PrettyStream:
        from httpie.output import streams
        streams.PrettyStream = _PrettyStream
        write_message(prep,env,args,True,True)

# Generated at 2022-06-23 19:43:55.227963
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(env=None, args=None) == (None, None)
    assert get_stream_type_and_kwargs(env='', args='') == ('', '')

# Generated at 2022-06-23 19:43:56.542849
# Unit test for function write_stream
def test_write_stream():
    print("Function: write_stream()")
    # TODO



# Generated at 2022-06-23 19:44:03.325632
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    """Check if the right streams are returned based on command line args"""
    args1 = argparse.Namespace()
    args1.prettify = None
    args1.stream = False
    args1.style = None
    args1.json = None
    args1.format_options = None
    env1 = Environment()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env1,
        args=args1
    )
    assert stream_class == EncodedStream
    assert stream_kwargs == {'env': env1}

    args2 = argparse.Namespace()
    args2.prettify = ['colors', 'format']
    args2.stream = True
    args2.style = None
    args2.json = None
    args2.format_options

# Generated at 2022-06-23 19:44:13.199500
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Tests the function write_stream_with_colors_win_py3."""
    stream = [
        b'\x1b[1m\x1b[38;5;214m',
        b'HTTP/1.1 200 OK'
    ]
    outfile = io.StringIO()
    for chunk in stream:
        if b'\x1b[' in chunk:
            outfile.write(chunk.decode())
        else:
            outfile.buffer.write(chunk)

# Generated at 2022-06-23 19:44:22.083407
# Unit test for function write_message
def test_write_message():
    from httpie.output.options import OutputOptions

    # Prepare environment and arguments
    env = Environment(
        colors = 256,
        stdin = sys.stdin,
        stdout = sys.stdout,
        stderr = sys.stderr,
        is_windows = sys.platform == 'win32'
    )
    args = OutputOptions()

    class req:
        def __init__(self, method, url):
            self.method = method
            self.url = url
            self.headers = {'User-Agent': 'httpie'}
            self.body = ('{"hello": "world"}')
            self.encoding = 'utf-8'
            self.ok = True
            self.status_code = 200


# Generated at 2022-06-23 19:44:26.136202
# Unit test for function write_stream
def test_write_stream():
    import sys
    outfile = sys.stdout
    data = {'key': 'value'}
    write_stream_with_colors_win_py3(**write_stream_kwargs)

# Generated at 2022-06-23 19:44:37.414060
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.downloads import Downloader
    from httpie.input import ParseRequest
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    from httpie.core import main

    request = """GET http://httpbin.org/headers HTTP/1.1
User-Agent: HTTPie/0.9.2
Accept-Encoding: gzip, deflate, compress
Accept: */*
Host: httpbin.org
Content-Length: 2

ok
"""
    args = ParseRequest().parse_args(args=[], env=Environment())
    args.stream = False
    args.prettify = ['all']
    args.style = 'default'
    args.json = False
    args.format_options = []
    env = Environment()
    env.stdout.isatty

# Generated at 2022-06-23 19:44:42.965698
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    stream = io.BytesIO(b'\x1b[31mtest\x1b[m')
    outfile = io.StringIO()
    write_stream_with_colors_win_py3(stream=stream, outfile=outfile, flush=False)
    assert outfile.getvalue() == '\x1b[31mtest\x1b[m'

# Generated at 2022-06-23 19:44:53.844455
# Unit test for function write_message
def test_write_message():
    '''
    测试函数 write_message
    :return:
    '''

# Generated at 2022-06-23 19:45:00.703428
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import BufferedPrettyStream, RawStream
    env = Environment()
    env.stdout_isatty = True
    args = argparse.Namespace()
    req = requests.PreparedRequest()
    req.headers = {'h1': 'v1'}
    req.body = 'body'
    req.url = 'url'
    req.method = 'GET'
    req.http_version = '1.0'
    res = requests.Response()
    res.headers = {'h2': 'v2'}
    res.url = 'url2'
    res.raw = type('HTTPResponse', (object,), {'read': lambda x: 'body', 'isclosed': True})()
    res.request = req
    env.stdout_isatty = False

# Generated at 2022-06-23 19:45:11.997332
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.__main__ import main
    from httpie.core import main as core_main
    from httpie.input import ParseError
    from tests.constants import (
        TEST_FILE_PATH_ARG,
        TEST_FILE_PATH_ARG_QUOTED
    )
    from tests.utils import TestEnvironment, http, httpbin

# Generated at 2022-06-23 19:45:20.898617
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace()
    env = Environment()
    env.stdout_isatty = True
    args.prettify = ['har']
    args.har_pretty_print = True

    requests_message = requests.PreparedRequest()
    requests_message.headers = {b"Accept": b"application/json"}
    requests_message.body = b"TESTING"
    requests_message.method = b"GET"
    requests_message.path_url = b"/foo"

    output = b""
    for chunk in build_output_stream_for_message(requests_message, env, args):
        output += chunk
    json_output = json.loads(output)

# Generated at 2022-06-23 19:45:28.273489
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Output(BytesIO):
        pass

    stream = ['ab', '\x1b[33mte\x1b[0m', 'st']
    outfile = Output()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=True
    )

    assert outfile.getvalue() == 'ab\x1b[33mte\x1b[0mst'

# Generated at 2022-06-23 19:45:40.334623
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.compat import to_native_string
    from httpie import ExitStatus
    from httpie.core import main
    from httpie.input import ParseError
    import os
    import pytest
    # url = "http://httpie.org"
    url = "http://httpbin.org/anything"
    args = ['-v', url]
    env = Environment()
    try:
        exit_status, http_response = main(args, env)
    except SystemExit as e:
        exit_status = e.code
    except KeyboardInterrupt:
        exit_status = ExitStatus.ERROR_CTRL_C
    except ParseError as e:
        exit_status = ExitStatus.ERROR_PARSING
        http_response = HTTPError('\n'.join(e.args))

# Generated at 2022-06-23 19:45:44.481857
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from httpie.output.streams import PrettyStream
    env = Environment()
    args = argparse.Namespace(stream=True)
    outfile = BytesIO(b"")
    requests_message = requests.Response()
    requests_message.headers["Content-Type"]='application/json'
    requests_message.headers["Status"]='200'
    requests_message.text="json text"
    requests_message.status_code=200

# Generated at 2022-06-23 19:45:54.040203
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import json
    import sys
    import tempfile
    import time
    import unittest

    import httpie

    class BaseTestCase:
        data = None
        with_headers = False
        with_body = True
        chunk_size = None

        def setUp(self):
            self.old_stdout = sys.stdout
            self.old_stderr = sys.stderr
            self.temp_outfile = tempfile.TemporaryFile()
            self.temp_errfile = tempfile.TemporaryFile()
            sys.stdout = self.temp_outfile
            sys.stderr = self.temp_errfile
            self.env = httpie.Environment(stdin=None)
            self.args = httpie.parser.parse_args([])


# Generated at 2022-06-23 19:46:00.849868
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.input.reader import FileReader
    from httpie.input.utils import get_encoding_from_headers
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import base_stream_factory_for_binary_output
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    response = requests.Response()

# Generated at 2022-06-23 19:46:10.315904
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env=Environment()
    args=argparse.Namespace
    env.stdout_isatty=True
    args.prettify='all'
    args.binary_implicit=True
    args.stream=True
    #args.stream is true implies raw
    args.stream=False
    args.prettify='body '
    args.stream=False
    args.prettify='headers '
    args.stream=False
    args.prettify='none'
    args.stream=False
    args.prettify='bodies '
    args.stream=False
    args.prettify='headers'
    args.stream=False
    args.prettify='headers '
    args.stream=True
    args.prettify='all'
    args.stream=True

# Generated at 2022-06-23 19:46:17.446536
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    orig_stderr = sys.stderr
    sys.stderr = StringIO()

# Generated at 2022-06-23 19:46:25.649203
# Unit test for function write_message
def test_write_message():
    class args:
        pass
    args.prettify = []
    args.stream = True
    args.style = 'default'
    args.json = False
    args.format_options = []
    args.debug = False
    args.traceback = False
    class req:
        pass
    req.text = '{"a": "b"}'
    req.headers = {'x': 'y'}
    env = Environment(
        stdin=None,
        stdout=None,
        is_windows=False,
        colors=256,
        ignore_stdin=False,
    )
    env.pagesize = 0
    write_message(req, env, args, True, True)

# Generated at 2022-06-23 19:46:27.495769
# Unit test for function write_message
def test_write_message():
    return None

if __name__ == '__main__':
    test_write_message()

# Generated at 2022-06-23 19:46:38.099580
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace(
        stream=False,
        # prettify=['all'],
        json=False,
        style='paraiso-dark',
        style_sheet=None,
        format=None,
        download=False,
        traceback=False,
        debug=False,
        verbose=False,
        quiet=False,
    )
    env = Environment()

    from requests import Response
    response = Response()
    response.url = "https://httpbin.org/get"
    response.status_code = 200
    response.encoding = "utf-8"
    response.raw = b"[]"

# Generated at 2022-06-23 19:46:47.087246
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.core import main
    from httpie.output.streams import PrettyStream
    from httpie.input import ParseError
    from testserver.server import Server
    from httpie.downloads import (
        parse_content_range, filename_from_content_disposition, filename_from_url,
    )
    import requests
    import pytest
    import sys
    import time
    import tempfile
    import shutil
    import os
    import os.path

    def http(*args, **kwargs):
        env = Environment()

# Generated at 2022-06-23 19:46:56.369851
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.compat import is_py3
    from httpie.output.streams import PrettyStream, PrettyBytesStream

    test_str = 'Hello World'
    test_bytes = b'Hello World with color\x1b[m'
    msg = HTTPRequest(test_str)
    stream_class = PrettyStream if is_py3 else PrettyBytesStream
    stream = stream_class(msg=msg, with_body=True, with_headers=True)

    s = StringIO(test_str)
    write_stream_with_colors_win_py3(stream, s, True)
    assert s.getvalue() == test_str

    s = StringIO(test_str)
    s.buffer = StringIO()

# Generated at 2022-06-23 19:47:06.758750
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class IOString(StringIO):
        def __init__(self, *args, **kwargs):
            self._out = StringIO()
            self._in = StringIO(*args, **kwargs)

        def buffer(self):
            return self._out

        def __next__(self):
            value = self._in.readline().encode()
            if value:
                return value


# Generated at 2022-06-23 19:47:17.618448
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    import pytest
    from httpie import ExitStatus

    class MockR():
        """
        This builds a mock requests.PreparedRequest or requests.Response
        """
        def __init__(self, status_code, body):
            self.status_code = status_code
            self.body = body

    # We need to mock the parser for our exit functions
    class MockParser:
        def exit(self, *args, **kwargs):
            pass

    class MockEnv:
        """
        This mocks the env object.
        We do this so we can mock the standard I/O and the isatty flags.
        """
        def __init__(self, stdout, stderr, stdout_isatty, stderr_isatty):
            self.stdout = stdout

# Generated at 2022-06-23 19:47:19.905721
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    pass

# Generated at 2022-06-23 19:47:27.267877
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from .streams import PrettyStream
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    
    env = Environment()
    env.stdout = sys.stdout
    env.stdout_isatty = sys.stdout.isatty()

    args = argparse.Namespace()
    args.stdout = sys.stdout
    args.prettify = []
    args.stream = False
    
    with open("sample.log", "rb") as f:
        requests_response = requests.Response()
        requests_response._content = f.read()
        
    # see https://realpython.com/python-mock-library/

# Generated at 2022-06-23 19:47:31.365665
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Arrange
    stream = [b'\x1b[0m\x1b[37mfoo\x1b[0m', b'bar']
    outfile = io.StringIO()

    # Act
    write_stream_with_colors_win_py3(stream=stream, outfile=outfile, flush=False)

    # Assert
    assert outfile.getvalue() == '\x1b[0m\x1b[37mfoo\x1b[0mbar'

# Generated at 2022-06-23 19:47:41.070460
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import httpie.cli
    import httpie.output.streams
    args = httpie.cli.parser.parse_args(args=['--json'])
    env = Environment(
        stdout=io.StringIO(),
        stderr=io.StringIO(),
        stdin=io.StringIO(),
    )
    response = requests.Response()
    response.url = 'https://www.baidu.com'
    response.status_code = 200
    response.raw = io.BytesIO(b'Hello World!')
    response._content_consumed = True
    response.headers = {
        'Content-Type': 'application/json; charset=UTF-8'
    }
    response.encoding = 'utf-8'
    stream_class, stream_kwargs = get_stream_

# Generated at 2022-06-23 19:47:41.426521
# Unit test for function write_message
def test_write_message():
    assert 2 == 2

# Generated at 2022-06-23 19:47:50.278476
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # Arrange
    import io
    import colorama
    env = Environment(
        colors=256,
        stdout_isatty=True,
        stdin_isatty=False,
        stdout=io.StringIO(),
        is_windows=True,
    )
    args = argparse.Namespace(
        colors='256',
        style='auto',
        prettify='all',
        stream=True,
    )
    requests_message = object()
    outfile = io.StringIO()
    # Write a color code to the stream
    color_code = colorama.Style.RESET_ALL + colorama.Fore.RED + 'x'
    color_code_bytes = color_code.encode("utf-8")

# Generated at 2022-06-23 19:47:54.548211
# Unit test for function write_stream
def test_write_stream():
    import io
    f = io.StringIO()
    write_stream(["hello", "world"], f, flush=True)
    f.seek(0)
    print(f.read())


if __name__ == '__main__':
    test_write_stream()

# Generated at 2022-06-23 19:48:03.068754
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    #
    # prettify off, stream off
    #
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(stdout_isatty=False),
        args=argparse.Namespace(
            prettify=False,
            stream=False,
        )
    )
    assert stream_class is RawStream
    assert stream_kwargs == {'chunk_size': RawStream.CHUNK_SIZE}
    #
    # prettify off, stream on
    #
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=Environment(stdout_isatty=False),
        args=argparse.Namespace(
            prettify=False,
            stream=True,
        )
    )
    assert stream_

# Generated at 2022-06-23 19:48:12.659280
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = ''
    args.stream = False
    args.style = 'default'
    args.json = False
    args.format_options = {}
    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    args.stream = True
    assert get_stream_type_and_kwargs(env, args) == (PrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups='', color_scheme='default', explicit_json=False, format_options={})})

    args.prettify = 'all'

# Generated at 2022-06-23 19:48:23.044173
# Unit test for function write_message
def test_write_message():
    import subprocess
    import os.path
    import sys
    import os
    import shutil
    import json
    import re
    import requests

    CURDIR = os.path.dirname(os.path.abspath(__file__))

    TEST_DIR = os.path.join(CURDIR, 'httpie_test_dir')
    RESOURCES_DIR = os.path.join(TEST_DIR, 'resources')
    BIN_DIR = os.path.join(TEST_DIR, 'bin')
    DOCS_DIR = os.path.join(TEST_DIR, 'docs')
    TESTS_DIR = os.path.join(TEST_DIR, 'tests')
    PYTHON_EXE = os.path.join(sys.exec_prefix, 'python.exe')



# Generated at 2022-06-23 19:48:33.874355
# Unit test for function write_message
def test_write_message():
    env = Environment(
        stdin=io.StringIO(),
        stdout=io.StringIO(),
        stdout_isatty=False,
        stderr=io.StringIO(),
        stderr_isatty=False,
    )
    args = argparse.Namespace()
    request = requests.PreparedRequest()
    request.headers = [('h1', 'v1'), ('h2', 'v2')]
    request.body = 'body'
    write_message(
        requests_message=request,
        env=env,
        args=args,
        with_headers=True,
        with_body=True,
    )

    response = requests.Response()
    response.headers = [('h1', 'v1'), ('h2', 'v2')]

# Generated at 2022-06-23 19:48:36.495228
# Unit test for function write_stream
def test_write_stream():
    write_stream(stream=["jakob", "is", "cool", "af"], outfile="stdout", flush=True)



# Generated at 2022-06-23 19:48:44.968763
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie import Environment
    import sys
    from httpie.output.streams import RawStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream
    env = Environment(
        colors=1,
        stdin_isatty=sys.stdin.isatty(),
        stdout_isatty=sys.stdout.isatty(),
        stdout_encoding=sys.stdout.encoding,
        stdout_raw=sys.stdout.isatty(),
    )

    args_raw_stream = [
        argparse.Namespace(prettify=None),
        argparse.Namespace(prettify=None, stream=False),
        argparse.Namespace(prettify=None, stream=True),
    ]

   

# Generated at 2022-06-23 19:48:52.633515
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    from httpie.output.streams import Conversion, Formatting

    from httpie.compat import urlopen
    #  env = Environment()
    req_session = requests.Session()
    req = requests.Request('GET', 'https://en.wikipedia.org/wiki/HTTPie').prepare()
    req_session.send(req)
    req = req_session.get('https://en.wikipedia.org/wiki/HTTPie')

    resp = urlopen('https://en.wikipedia.org/wiki/HTTPie')
    args = argparse.Namespace()
   

# Generated at 2022-06-23 19:49:03.597432
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(stdout_isatty=True, is_windows=False)
    args = argparse.Namespace(
        verbose=True,
        traceback=True,
        debug=True,
        json=True,
        prettify=True,
        style=True,
        format_options=True,
        stream=True,
    )
    expected = (PrettyStream, {
        'env': env,
        'conversion': Conversion(),
        'formatting': Formatting(
            env=env,
            groups=True,
            color_scheme=True,
            explicit_json=True,
            format_options=True,
        )
    })

    actual = get_stream_type_and_kwargs(env=env, args=args)
    assert expected == actual

# Generated at 2022-06-23 19:49:15.616716
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    Run unit tests for function write_stream_with_colors_win_py3
    """
    import io
    import colorama
    colorama.init()
    stream_class = 'BaseStream'
    stream_type, stream_kwargs = get_stream_type_and_kwargs('env', 'args')
    assert stream_class == stream_type
    outfile = io.StringIO()
    flush = True
    message_class = {
        'PreparedRequest': HTTPRequest,
        'Response': HTTPResponse,
    }['type']
    yield from stream_class('msg', message_class)

# Generated at 2022-06-23 19:49:18.960221
# Unit test for function write_stream
def test_write_stream():
    outfile = open('my_file.txt', 'w')
    write_stream(["hello", "world"], outfile, False)

if __name__ == '__main__':
    test_write_stream()

# Generated at 2022-06-23 19:49:19.742144
# Unit test for function write_message
def test_write_message():
    assert write_message() == ''

# Generated at 2022-06-23 19:49:29.971167
# Unit test for function write_message
def test_write_message():
    Environment.colors = 256
    args = argparse.Namespace(stream=False, prettify='all', style='parrot')
    from httpie.output.processors import Colors
    env = Environment(colors=256, stdout=sys.stdout, stderr=sys.stderr,
                      colors_mode=Colors.ANSI,
                      stdin_isatty=sys.stdin.isatty(),
                      stdout_isatty=sys.stdout.isatty(),
                      is_windows=sys.platform.startswith('win'),
                      is_posix=os.name == 'posix',
                      is_mac=sys.platform == 'darwin',
                      is_linux=sys.platform.startswith('linux'),
                      is_32bit=sys.maxsize < 2 ** 32)

   

# Generated at 2022-06-23 19:49:39.185256
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """Unit test for function build_output_stream_for_message."""
    import pytest
    from httpie import ExitStatus
    from httpie.core import main
    from httpie.config import Config
    from . import httpbin

    class MockConfig:
        """Config used only for tests.

        If we were to call `Config.load_config()` it would try to
        access the system config file and cache, so this instead
        allows us to mock out the config class and pick it up as
        `args.config`.

        """
        def __init__(self, JSON_FLAG=False, pretty=None, style=None,
                     format=None, headers=None, body=None,
                     download=False, print_headers=False, stdout=False,
                     stdout_isatty=False, stream=False):
            self

# Generated at 2022-06-23 19:49:48.225458
# Unit test for function write_message
def test_write_message():
    env = Environment()
    env.stdout = sys.stdout
    env.stderr = sys.stderr
    env.stdout_isatty = True
    env.stderr_isatty = True
    env.colors = 256
    env.is_windows = False

    parser = argparse.ArgumentParser()
    parser.add_argument('--traceback')
    args = parser.parse_args()

    requests_message = requests.Response()
    requests_message.status_code = 200
    requests_message.url = 'http://www.gov.sg'

    HTTPResponse().to_stream(requests_message, '')

# Generated at 2022-06-23 19:49:57.839128
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys


# Generated at 2022-06-23 19:50:09.150437
# Unit test for function write_message
def test_write_message():
    # test with headers
    print("test with headers")
    env = Environment()
    env.stdout_isatty = False
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = []
    args.debug = False
    args.traceback = False
    args.download = False
    req = requests.PreparedRequest()
    req.url = 'https://httpbin.org/'
    req.method = 'GET'
    req.body = b''
    req.headers = {'Content-Type': 'application/json',
                   'Accept-Encoding': 'utf-8'}
    write_message(req, env, args, with_headers=True, with_body=False)

# Generated at 2022-06-23 19:50:14.523103
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # import subprocess
    # import click
    # import logging
    # from httpie.core import main
    # from httpie.cli import parser
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    args = parser.parse_args(['-v'])
    env = Environment()

    #
    requests_message = requests.Response()
    requests_message.status_code = 200
    requests_message.content = 'test'
    requests_message._content_consumed = True

    #

# Generated at 2022-06-23 19:50:17.436941
# Unit test for function write_stream
def test_write_stream():
    s = "Hello world"
    bytes = s.encode()
    stream = write_stream(bytes, sys.stdout, True)
    print("Hello world")

# Generated at 2022-06-23 19:50:25.148859
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys

    # Bytes are written to the BytesIO,
    # Text is written to the StringIO.
    buf = io.BytesIO()
    outfile = io.TextIOWrapper(buf, encoding='utf8')
    outfile.buffer.write = lambda s: s
    outfile.write = lambda s: s
    outfile.flush = lambda: None

    chunks = [(b'\x1b[32m', '\x1b[32m'), (b'1\x1b[0m', '1\x1b[0m')]

    if sys.version_info[0] == 3:
        write_stream_kwargs = {
            'stream': chunks,
            'outfile': outfile,
            'flush': False
        }
    else:
        write_stream