

# Generated at 2022-06-23 19:40:25.469037
# Unit test for function write_stream
def test_write_stream():
    print("\n"+"running test for: write_stream")
    env = Environment()
    args = environment.parse_args()
    req = requests.Request(
        'GET',
        'http://httpbin.org/stream/20',
        params={'arg': 'value'}
    ).prepare()
    # resp = requests.Response()
    write_message(req, env, args, with_headers=False, with_body=True)

# Generated at 2022-06-23 19:40:34.874489
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    request_prepared = requests.Request("get", "http://www.baidu.com", data="abc").prepare()
    request_response = requests.Response()
    request_response.status_code = 200
    request_response.encoding = "UTF-8"
    request_response.headers = {'K1':"V1", 'K2':"V2"}
    request_response._content = b'{"name":"value"}'
    request_response.request = request_prepared
    request_response.raw = BytesIO(b'{"name":"value"}')
    argparse_namespace = argparse.Namespace
    argparse_namespace.format = "json"
    argparse_namespace.headers = ["K1:V1", "K2:V2"]

    result = ""

# Generated at 2022-06-23 19:40:41.818240
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from unittest import TestCase

    from httpie.downloads import write_stream

    class WriteStreamTestCase(TestCase):

        def setUp(self):
            self.stream = StringIO()

        def test_write_stream(self):
            stream_instance = StringIO('foo\r\nbar\r\nbaz\r\n')
            write_stream(
                stream=stream_instance,
                outfile=self.stream,
                flush=False)
            self.assertEqual(self.stream.getvalue(), 'foo\nbar\nbaz\n')

        def tearDown(self):
            self.stream.close()

    unittest.main()

# Generated at 2022-06-23 19:40:52.268399
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.cli import parser
    args = parser.parse_args('')

    from httpie.context import Environment
    env = Environment()

    from requests import Request, Session
    session = Session()
    request_message = Request(
        method='GET',
        url='http://www.google.com',
        headers=dict(a=1)
    )
    prepped_request = session.prepare_request(request_message)
    response_message = session.send(prepped_request)

    output_stream = build_output_stream_for_message(
        requests_message=response_message,
        env=env, args=args,
        with_headers=True, with_body=True
    )

    for chunk in output_stream:
        print(chunk)

# Generated at 2022-06-23 19:40:56.638157
# Unit test for function write_message
def test_write_message():
    args_bk = argparse.Namespace
    env_bk = Environment
    #Exception tests
    args = argparse.Namespace(
        body = "asd",
        download = True,
        files = None,
        form = False,
        headers = True,
        json = False,
        method = "GET",
        page_options = True,
        output=None,
        pretty = None,
        querystring = "asd",
        scheme = "asd",
        stream = False,
        traceback = False,
        url = "asd",
        verify = False,
    )

# Generated at 2022-06-23 19:41:05.853065
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    env.stdout_isatty = True
    raw_args = argparse.Namespace(prettify=[], stream=False, style=None, json=False, format_options=[])
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, raw_args)

    # This function is just a wrapper that returns values, so test the values instead
    assert stream_class == PrettyStream
    assert stream_kwargs == {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=[], color_scheme=None, explicit_json=False, format_options=[])}

# Generated at 2022-06-23 19:41:11.556138
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream
    from httpie import ExitStatus

    env = Environment(colors=256)
    args = argparse.Namespace()
    args.prettify = ['all']
    args.verbose = 3

    assert PrettyStream == get_stream_type_and_kwargs(env, args)[0]

test_get_stream_type_and_kwargs()

# Generated at 2022-06-23 19:41:12.395441
# Unit test for function write_stream
def test_write_stream():
    assert write_stream('hi', 'hi', False)

# Generated at 2022-06-23 19:41:20.932505
# Unit test for function write_message
def test_write_message():
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.output import OutputOptions
    from httpie.output.streams import BinaryPrefixOut

    class MyFakeBinaryPrefixOut(BinaryPrefixOut):
        """My fake BinaryPrefixOut for unit testing

        Simulate that stream is opened to write the content
        """
        def __init__(self, stream):
            self.stream = stream
            self.stream_opened = False
            self.closed = False
            self.content = b''

        def open(self, mode='w'):
            self.stream_opened = True

        def write(self, chunk):
            self.content += chunk

    # case 1: with_headers=False, with_body=False

# Generated at 2022-06-23 19:41:23.997307
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    f = StringIO()
    write_stream(stream=['a'], outfile=f, flush=False)
    assert f.getvalue() == 'a'

# Generated at 2022-06-23 19:41:32.541655
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(
            stream=True,
            download=False,
            continue_download = False,
            output = "",
            output_dir = "",
            output_file = "",
            )
    env = Environment()

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs != None
    assert stream_kwargs['env'] != None
    assert stream_kwargs['conversion'] != None
    assert stream_kwargs['formatting'] != None

    args = argparse.Namespace(
            stream=False,
            download=False,
            continue_download = False,
            output = "",
            output_dir = "",
            output_file = "",
            )
   

# Generated at 2022-06-23 19:41:34.036989
# Unit test for function write_stream
def test_write_stream():
    write_stream


# Generated at 2022-06-23 19:41:38.565153
# Unit test for function write_message
def test_write_message():
    """
        test for write_message
    """
    user_args = argparse.Namespace
    env = Environment()
    requests_message = requests.PreparedRequest
    with_headers = False
    with_body = False
    write_message(requests_message,
                  env,
                  user_args,
                  with_body,
                  with_headers)



# Generated at 2022-06-23 19:41:44.740122
# Unit test for function write_message
def test_write_message():
    from io import BytesIO
    from httpie.input import ParseRequest

    env = Environment(stdin=BytesIO(), stdout=BytesIO(), stderr=BytesIO())
    env.config.default_options.sv = True
    args = ParseRequest().parse_args(args=['https://api.example.com/'])
    write_message(
        requests.PreparedRequest(method='GET', url='https://api.example.com/'),
        env=env,
        args=args,
        with_headers=True,
        with_body=True
    )

# Generated at 2022-06-23 19:41:50.546208
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    bytes = b'\x1b[7mfoo\x1b[0m'
    # This is required as an argument by write_stream_with_colors_win_py3
    args = argparse.Namespace()
    outfile = io.StringIO('')

    try:
        # For now just don't throw an exception
        write_stream_with_colors_win_py3(bytes, outfile, args)
    except Exception as e:
        raise(e)

# Generated at 2022-06-23 19:41:58.192753
# Unit test for function write_message
def test_write_message():

    class Args(object):
        def __init__(self, config):
            self.traceback = config['traceback']
            self.debug = config['debug']
            self.stream = config['stream']
            self.prettify = config['prettify']
            self.style = config['style']
            self.json = config['json']
            self.format_options = config['format_options']

    class RequestsMessage(object):
        def __init__(self, config):
            self.headers = config['headers']
            self.content = config['content']

    class Environment(object):
        def __init__(self, config):
            self.stdout = sys.stdout
            self.stderr = sys.stderr

# Generated at 2022-06-23 19:42:06.345501
# Unit test for function write_stream
def test_write_stream():
    import sys
    import pytest
    from StringIO import StringIO

    if not sys.version_info >= (3, 0):
        out = StringIO()

# Generated at 2022-06-23 19:42:12.610743
# Unit test for function write_message
def test_write_message():
    import sys
    import requests
    
    # what if I call requests with localhost, or HTTPIE
    # must define a parameter for the port we are using.
    host = 'http://localhost' # parameter
    port = '8000' # parameter
    
    # request_messages = requests.get(host+':'+port)
    request_messages = requests.get('http://localhost:8000')
    
    # write_message(request_messages, sys.env, sys.args)

if __name__ == '__main__':
    test_write_message()

# Generated at 2022-06-23 19:42:18.985553
# Unit test for function write_message
def test_write_message():
    stdout = sys.stdout
    stdout = io.TextIOWrapper(stdout.buffer, encoding='utf-8')
    env = Environment(stdin=sys.stdin, stdout=stdout, stderr=sys.stderr)

# Generated at 2022-06-23 19:42:31.101739
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.context import Environment
    from httpie.output.streams.raw import RawStream
    from httpie.output.streams.buffered_pretty import BufferedPrettyStream
    from httpie.output.streams.encoded import EncodedStream
    from httpie.output.streams.pretty import PrettyStream
    from httpie.output.processing.formatting import Formatting
    from httpie.output.processing.conversion import Converter
    class args: pass
    env = Environment()
    env.stdout_encoding = 'UTF-8'
    env.stdout_isatty = True

    # not istty, not prettify
    args.prettify = None
    args.stream = False

# Generated at 2022-06-23 19:42:40.709877
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from click.testing import CliRunner
    import httpie.cli

    runner = CliRunner()
    result = runner.invoke(
        httpie.cli.main,
        ['--prettify', 'all', '--style', 'paraiso-dark', 'https://httpbin.org/get']
    )
    assert result.exit_code == 0

# Generated at 2022-06-23 19:42:51.090921
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Test for method write_stream_with_colors_win_py3
    """

    class MockOutfile(object):
        """Class to mock outfile
        """

        def __init__(self):
            self.content = b''

        def write(self, content):
            self.content += content.encode('utf-8')

        def flush(self):
            pass

    class MockStream(object):
        """Class to mock BaseStream
        """

        def __init__(self, env, args):
            self.env = env
            self.args = args

# Generated at 2022-06-23 19:42:58.085981
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.config import Config, DEFAULT_CONFIG_DIR
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.plugins import plugin_manager
    from httpie.output.streams import RawStream, BufferedPrettyStream, EncodedStream
    from httpie import ExitStatus

    config_dir = os.path.join(os.getcwd(), 'httpie_parameter_test_dir')
    configs = Config(Config.load(config_dir, config_dir.rstrip('/') + '.cfg'))
    config = configs.get_config_for_dir(os.getcwd())

# Generated at 2022-06-23 19:43:03.659722
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output import stream

    stream.write_stream_with_colors_win_py3(
        stream=b'\x1b[32mtest\x1b[0m',
        outfile=StringIO(),
        flush=True
    )
    stream.write_stream_with_colors_win_py3(
        stream=b'test',
        outfile=StringIO(),
        flush=True
    )

# Generated at 2022-06-23 19:43:13.084373
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from os import isatty
    from tempfile import TemporaryFile
    tty = TemporaryFile(mode='w+t')

    # Simulate the tty is a text file
    env = Environment(stdout=tty, stdout_isatty=True)
    # Simulate the variables in argparse
    args = argparse.Namespace()
    args.prettify = ['colors']
    args.style = 'default'
    args.json = False
    args.format_options = {}
    args.stream = True

    # Test 1: stream_type expect to be PrettyStream
    stream_class, _ = get_stream_type_and_kwargs(env=env, args=args)
    assert stream_class == PrettyStream

    # Test 2: stream_type expect to be RawStream
    args.prettify = []


# Generated at 2022-06-23 19:43:25.048947
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream

    url = 'http://localhost:8080/'
    env = Environment()
    mock_args = get_args(url, 'GET', '--output-format=json', '--stream')
    message = requests.Request('GET', url).prepare()
    stream, _ = get_stream_type_and_kwargs(env, mock_args)
    assert stream==BufferedPrettyStream

    mock_args = get_args(url, 'GET', '--output-format=json', '--stream')
    message = requests.Request('GET', url).prepare()
    stream, _ = get_stream_type_and_kwargs(env, mock_args)
    assert stream==BufferedPretty

# Generated at 2022-06-23 19:43:32.955113
# Unit test for function write_message
def test_write_message():
    import httpie
    env = httpie.Environment()
    req = requests.Request(method='GET', url='http://127.0.0.1')
    resp = requests.Response()
    args = argparse.Namespace()
    with_body = True
    with_headers = False
    write_message(req, env, args, with_headers, with_body)
    write_message(resp, env, args, with_headers, with_body)

# Generated at 2022-06-23 19:43:42.038832
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import PrettyStream
    env = Environment()
    env.stdout.encoding = 'utf-8'
    stream = PrettyStream(
        msg=HTTPResponse({
            'headers': {'Content-Type': 'application/json'},
            'status_code': 200,
        }, b'{}'),
        env=env,
        conversion=Conversion(),
        formatting=Formatting(
            env=env,
            groups=['pretty', 'colors'],
            color_scheme='Emacs',
            explicit_json=False,
            format_options={},
        ),
    )
    outfile = StringIO()

# Generated at 2022-06-23 19:43:47.891255
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    class StringIO(six.BytesIO):
        def write(self, s):
            super(StringIO, self).write(s.encode())

    class Stream(object):
        def __iter__(self):
            yield b'color\x1b[me-color'

    sio = StringIO()
    write_stream_with_colors_win_py3(
        stream=Stream(),
        outfile=sio,
        flush=False
    )
    assert (b'color\x1b[me-color' == sio.getvalue())

    sio = StringIO()
    write_stream_with_colors_win_py3(
        stream=Stream(),
        outfile=sio,
        flush=False
    )

# Generated at 2022-06-23 19:43:48.786220
# Unit test for function write_message
def test_write_message():
    # TODO: test for write_message
    return

# Generated at 2022-06-23 19:43:49.371723
# Unit test for function write_message
def test_write_message():
    print('Working')

# Generated at 2022-06-23 19:43:58.927919
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from tests.compat import mock

    args = argparse.Namespace(
        download=False,
        print_body=True,
        print_headers=False,
        print_headers_only=False,
        print_status=False,
        pretty=None,
        style=None,
        stream=True,
    )
    env = mock.Mock(
        stdout_isatty=True,
    )
    requests_message = requests.Response()
    requests_message.status_code = 200
    requests_message.headers['Content-Type'] = 'text/html; charset=utf8'
    requests_message.encoding = requests_message.apparent_encoding = 'utf-8'
    requests_message._content_consumed = False

# Generated at 2022-06-23 19:44:03.868729
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    out = StringIO()
    stream = b'\x1b[0m\x1b[0m\x1b[0m\x1b[0m'
    write_stream_with_colors_win_py3(stream = stream, outfile = out, flush = False)
    assert out.read() == '\x1b[0m\x1b[0m\x1b[0m\x1b[0m'

# Generated at 2022-06-23 19:44:06.356325
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    cls, kwargs = get_stream_type_and_kwargs({}, {})

# Generated at 2022-06-23 19:44:10.845940
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import build_output_stream
    from httpie.context import Environment
    from httpie.compat import FileNotFoundError
    import sys
    import io
    import os
    if not sys.platform.startswith('win'):
        raise FileNotFoundError(__file__)

    env = Environment(stdout=io.StringIO(), stderr=io.StringIO())

    class TestStream(BaseStream):
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk.encode('utf8')


# Generated at 2022-06-23 19:44:17.421244
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColoredStream
    sio = StringIO()
    stream = ColoredStream([b'\x1b[31mfoo\x1b[39;49m', b'bar'], None)
    write_stream_with_colors_win_py3(stream, sio, False)
    assert sio.getvalue() == '\x1b[31mfoo\x1b[39;49mbar'

# Generated at 2022-06-23 19:44:27.342600
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    from io import StringIO

    f = BytesIO()
    write_stream(b'123', f, False)
    f.seek(0)
    assert f.read() == b'123'

    f = BytesIO()
    write_stream(b'123\n456\n', f, False)
    f.seek(0)
    assert f.read() == b'123\n456\n'

    f = StringIO()
    write_stream(b'123\n456\n', f, False)
    f.seek(0)
    assert f.read() == '123\n456\n'

# Generated at 2022-06-23 19:44:38.298381
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Function write_stream_with_colors_win_py3 writes color structured
    bytes stream to a file.

    """
    import io
    import sys
    import random

    mock_args = argparse.Namespace()
    mock_args.prettify = ["colors"]

    with io.StringIO() as outfile:
        write_stream_with_colors_win_py3(
            stream=_MockStream(
                (b'\x1b[1;32mfoo\x1b[0m', b'bar')
            ),
            outfile=outfile,
            flush=False
        )

        assert outfile.getvalue() == '\x1b[1;32mfoo\x1b[0mbar'

    sys.stdout = sys.__stdout__



# Generated at 2022-06-23 19:44:39.229163
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Add unit test here
    pass

# Generated at 2022-06-23 19:44:47.097674
# Unit test for function write_message
def test_write_message():
    print()
    print('test_write_message')
    print()
    class Response:
        pass

    class Namespace:
        pass

    tmp_args = Namespace()
    tmp_args.prettify = ['all']
    tmp_args.style = 'foo'
    tmp_args.json = False
    tmp_args.format_options = {}
    tmp_args.stream = False
    tmp_args.debug = False
    tmp_args.traceback = False

    class Environment:
        def __init__(self, is_windows=False, stdout=sys.stdout, stderr=sys.stderr):
            self.is_windows = is_windows
            self.stdout = stdout
            self.stderr = stderr
            self.stdout_isatty = False

    tmp

# Generated at 2022-06-23 19:44:49.849114
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie import ExitStatus
    output_stream = build_output_stream_for_message('', '', '', '', '', '')
    return output_stream

# Generated at 2022-06-23 19:45:01.281249
# Unit test for function write_message
def test_write_message():
    import pytest
    from tempfile import NamedTemporaryFile
    from textwrap import dedent
    from httpie.cli.args import parser
    from httpie.context import Environment
    from httpie.output.streams import EncodedStream, format_request, format_response_headers
    from httpie.output.formatters.colors import get_lexer, get_style_by_name
    from httpie.output.processing import Conversion, Formatting
    from httpie.models import HTTPRequest, HTTPResponse

    url = 'https://httpbin.org/get'

# Generated at 2022-06-23 19:45:12.368353
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    env.stdout_isatty = True
    args.prettify = ['colors']
    args.stream = True

    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert stream_kwargs['env'] == env
    assert stream_kwargs['conversion'].__class__ == Conversion
    assert stream_kwargs['formatting'].__class__ == Formatting
    assert stream_kwargs['formatting'].color_scheme == 'default'

    # output is not a terminal
    env.stdout_isatty = False
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_

# Generated at 2022-06-23 19:45:16.332409
# Unit test for function write_stream
def test_write_stream():
    write_stream(['a', 'b', 'c'], sys.stdout, False)
    assert sys.stdout.getvalue()=='abc'
    sys.stdout.truncate(0)
    sys.stdout.seek(0)
    write_stream(['a', 'b', 'c'], sys.stdout, True)
    assert sys.stdout.getvalue()=='abc'
    sys.stdout.truncate(0)
    sys.stdout.seek(0)


# Generated at 2022-06-23 19:45:23.755206
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.output.streams import ColorizedStream
    b = b'hoge\x1b[31mfuga\x1b[0mfoo'
    stdout = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=ColorizedStream({}),
        outfile=stdout,
        flush=False
    )
    stdout.write(b)
    assert stdout.getvalue() == u'hoge\x1b[31mfuga\x1b[0mfoo'

# Generated at 2022-06-23 19:45:27.374825
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()
    output = write_message(requests_message, env, args)

# Generated at 2022-06-23 19:45:40.188243
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import requests
    import httpie.output.streams

    args = argparse.Namespace()
    args.stream = False
    args.prettify = False
    env = Environment(stdout=sys.stdout, stream=False, is_windows=False, stdout_isatty=True)
    request = requests.Request('POST', 'https://httpbin.org/post', data='{ "username": "jojo", "password": "jojo123"}')
    request_prepared = request.prepare()
    response = requests.Response()
    response.status_code = 200
    response.headers = {'Content-Type': 'application/json'}
    response.encoding = 'utf-8'
    response._content = b'{ "username": "test", "password": "test123"}'
   

# Generated at 2022-06-23 19:45:49.064476
# Unit test for function write_stream
def test_write_stream():
    import io
    import sys
    def write_stream(
        stream: BaseStream,
        outfile: Union[io.TextIOWrapper],
        flush: bool
    ):
        """Write the output stream."""
        try:
            # Writing bytes so we use the buffer interface (Python 3).
            buf = outfile.buffer
        except AttributeError:
            buf = outfile

        for chunk in stream:
            write_stream(chunk)
            if flush:
                outfile.flush()

    output = write_stream(
        stream=BaseStream(),
        outfile=sys.stdout,
        flush=False
    )



# Generated at 2022-06-23 19:45:59.335437
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace(prettify=set(), stream=True, style="monokai", json=False, format_options="[json]")
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream, EncodedStream
    for args.prettify in [None, set()]:
        for env.stdout_isatty in [True, False]:
            assert get_stream_type_and_kwargs(env, args) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE})
    args.prettify = set(["all"])

# Generated at 2022-06-23 19:46:09.501266
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO

    import requests
    from httpie.cli.argtypes import KeyValue

    from httpie.context import Environment
    from httpie.models import HTTPRequest
    from httpie.output.streams import PrettyStream
    from httpie.constants import DEFAULT_FORMAT_OPTIONS

    outfile = StringIO()

# Generated at 2022-06-23 19:46:13.881892
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    outfile = StringIO()
    stream = [b'ab\x1b[0m', b'\x1b[36mcd']
    write_stream_with_colors_win_py3(stream, outfile, True)
    outfile.seek(0)
    assert outfile.read() == 'ab\x1b[0m\x1b[36mcd'

# Generated at 2022-06-23 19:46:22.412700
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import httpie.cli
    from httpie.input import RawRequest
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.processing import Formatting

    args = httpie.cli.Parser().parse_args(['--verbose'])
    env = Environment(vars=args)

# Generated at 2022-06-23 19:46:34.393421
# Unit test for function write_message
def test_write_message():
    import json
    import requests
    from httpie.context import Environment
    from httpie.output.processors.headers import HeadersProcessor

    env = Environment(
        stdout_isatty=False,
        stdin_isatty=False,
        output_options=object(),
    )
    args = argparse.Namespace(
        stream=True,
        pretty="none",
        debug=False,
        traceback=False,
        style='paraiso-dark',
    )
    with_headers=False
    with_body=False


# Generated at 2022-06-23 19:46:44.669190
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    - write_stream_with_colors_win_py3() is expected to write chunk
        with ansi color sequence directly to stream,
        otherwise write it through buffer
    - Only stream is expected to be modified when writing with colors
        and rest of streams are expected to be untouched
    """
    from io import StringIO

    stream = [b'\x1b[35mI am a colored chunk', b'I am a normal chunk']
    outfile = StringIO()

    write_stream_with_colors_win_py3(stream, outfile, flush=False)
    # check if outfile has been colorized by stripping any color
    # escape sequences
    assert outfile.getvalue().strip('\x1b[0m') == 'I am a colored chunkI am a normal chunk'

# Generated at 2022-06-23 19:46:55.276193
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import BaseStream
    def chunks(text):
        if isinstance(text, str):
            text = text.encode('utf8')
        return [
            text[i:i+2] for i in range(0, len(text), 2)
        ]
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=BaseStream(chunks('\x1b[31mRED\x1b[0m'), False, False),
        outfile=outfile,
        flush=False,
    )
    assert outfile.getvalue() == 'RED'
    outfile.close()


if __name__ == '__main__':
    test_write_stream_with_colors_win_py3()

# Generated at 2022-06-23 19:47:00.833331
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    req = build_output_stream_for_message(
        with_body=True,
        with_headers=True,
        request=requests.get('https://httpbin.org/get'),
        env=Environment(argv=['http', 'get', 'https://httpbin.org/get']),
        args=argparse.Namespace(
            json=False,
            prettify=True,
            style='default',
            format_options={}
        )
    )
    print(type(req))
    print(next(req))

# Generated at 2022-06-23 19:47:04.605534
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # Test with_headers is True, and with_body is True.
    # Test with_headers is True, and with_body is False.
    # Test with_headers is False, and with_body is True.
    # Test with_headers is False, and with_body is False.
    return True



# Generated at 2022-06-23 19:47:11.428416
# Unit test for function write_stream
def test_write_stream():
    class MockPrettyStream(PrettyStream):
        def __iter__(self):
            return iter([b'foo', b'bar', b'\nbaz\n'])

    class MockBufferedPrettyStream(BufferedPrettyStream):
        def get_http_message(self) -> bytes:
            return b'foo'

    class MockEncodedStream(EncodedStream):
        def __iter__(self):
            return iter([b'foo', b'bar', b'\nbaz\n'])

    mocks = [
        MockPrettyStream(),
        MockBufferedPrettyStream(),
        MockEncodedStream()
    ]
    for mock_stream in mocks:
        for mock_file in [StringIO(), BytesIO()]:
            write_stream(mock_stream, mock_file, False)

# Generated at 2022-06-23 19:47:17.300703
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import io
    from httpie.cli import parser
    from httpie.compat import is_bytes
    from httpie.output.raw import RawStream
    from httpie.output.pretty import PrettyStream
    from httpie.output.streams import BufferedPrettyStream

    class DummyEnvironment:
        def __init__(self, isatty):
            self.stdout_isatty = isatty

    args = parser.parse_args(['-p'])
    env = DummyEnvironment(True)
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert 'env' in stream_kwargs

    args = parser.parse_args(['-p', '--stream'])
    env = DummyEnvironment(True)
   

# Generated at 2022-06-23 19:47:26.094913
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """
    >>> import httpie.output
    >>> import requests
    >>> import httpie.cli

    >>> env = httpie.context.Environment()
    >>> args = httpie.cli.parser.parse_args(['--pretty=all', '--download'])
    >>> requests_message = requests.PreparedRequest()
    >>> requests_message.headers = {'A': '1', 'B': '2'}
    >>> requests_message.url = 'https://example.com'
    >>> requests_message.body = 'test'
    >>> for chunk in httpie.output.build_output_stream_for_message(args, env, requests_message, with_headers=True, with_body=True):
    ...     assert chunk is not None
    """
    pass

# Generated at 2022-06-23 19:47:31.258333
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import json, requests
    url = 'http://httpbin.org/ip'
    env, args, message = Environment(), argparse.Namespace(), requests.Response()
    message.url = url
    message.request = requests.PreparedRequest()
    message.request.url = url

    assert build_output_stream_for_message(args, env, message, with_headers=False, with_body=True)[0].decode('utf-8') == json.dumps({'origin': '71.189.153.4'})

# Generated at 2022-06-23 19:47:33.601356
# Unit test for function write_message
def test_write_message():
    write_message('a', 'b', 'c', True, True)

# Generated at 2022-06-23 19:47:43.153768
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.context import Environment
    from tests.data import Response

    env = Environment()
    env.stdout_isatty = True
    env.stdout_encoding = 'GBK'
    outfile = io.TextIOWrapper(io.BytesIO())

    with open('tests/data/colorized.txt') as f:
        stream = BuildOutputStream(Response(f))

    write_stream_with_colors_win_py3(stream, outfile, False)
    print(repr(outfile.getvalue()), file=sys.stderr)



# Generated at 2022-06-23 19:47:47.047937
# Unit test for function write_stream
def test_write_stream():
    import io
    from httpie.output.streams import BaseStream
    bs = BaseStream()
    bs.chunks = [b'1', b'2']
    outfile = io.StringIO()
    write_stream(bs, outfile, True)
    assert outfile.getvalue() == '12'

# Generated at 2022-06-23 19:47:58.799760
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class Config(object):
        def __init__(self):
            self.stdout_isatty = False
            self.stdin_isatty = False
            self.is_windows = False
            self.prettify = None
            self.output_options = None


    args = argparse.Namespace()
    args.stream = True
    args.debug = False
    args.traceback = False

    env = Environment(None, None, None, None, Config())

    class request_object(object):
        def __init__(self):
            self.body = None
            self.encoding = None
            self.headers = None
            self.method = None
            self.url = None
            self.cookies = None


# Generated at 2022-06-23 19:48:04.986630
# Unit test for function write_message
def test_write_message():
    import requests
    import pytest
    from httpie.context import Environment
    from httpie.input import ParseArguments
    from httpie.output.streams import RawStream
    from httpie.models import HTTPRequest
    from httpie import ExitStatus
    from httpie.config import DEFAULT_CONFIG_DIR, DEFAULT_CONFIG_PATH
    from httpie import __version__
    from httpie.status import ExitStatus
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie import ExitStatus
    from httpie.output import Progress
    from httpie.cli import Environment
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-23 19:48:14.014901
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import EncodeStream
    from httpie.output import EncodedStream

    env = Environment()
    args = argparse.Namespace()

    class MockArgs():
        def __init__(self,
                     stream=False,
                     prettify=None,
                     style=None,
                     json=None,
                     format_options=None,
                     ):
            self.stream = stream
            self.prettify = prettify
            self.style = style
            self.json = json
            self.format_options = format_options

        def __repr__(self):
            return '<MockArgs>'

    class MockEnv():
        def __init__(self, stdout_isatty=True):
            self.stdout_isatty = stdout_isatty


# Generated at 2022-06-23 19:48:22.963474
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie import input

    args = input.ParseResult(
        args=[],
        env=Environment(
            colors=0,
            stdout_isatty=False,
            stderr_isatty=False,
        ),
        stdout=StringIO(),
    )
    stream_class, _ = get_stream_type_and_kwargs(
        args=args,
        env=args.env,
    )
    assert stream_class is RawStream

    args.env.colors = 1
    stream_class, _ = get_stream_type_and_kwargs(
        args=args,
        env=args.env,
    )
    assert stream_class is EncodedStream

# Generated at 2022-06-23 19:48:26.396938
# Unit test for function write_stream
def test_write_stream():
    str1 = "test"
    ioobj = io.BytesIO(bytes(str1, encoding='utf-8'))
    write_stream(ioobj, ioobj, False)


# Generated at 2022-06-23 19:48:37.311926
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-23 19:48:46.733989
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    lines = ['a', 'b', 'c']
    color_lines = ['\x1b[1;31m' + line + '\x1b[0m' for line in lines]
    separator = b'\n'
    chunks = [
        separator.join([line.encode() for line in lines]),
        separator.join([color_line.encode() for color_line in color_lines]),
        separator.join([line.encode() for line in lines]),
    ]
    s = BytesIO()
    write_stream_with_colors_win_py3(
        stream=chunks,
        outfile=s,
        flush=False,
    )

# Generated at 2022-06-23 19:48:57.106779
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output import streams

    env = Environment()

# Generated at 2022-06-23 19:49:06.991810
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(
        env=Environment(stdout_isatty=True),
        args=argparse.Namespace(prettify=['colors'], stream=False),
    ) == (BufferedPrettyStream, {
        'conversion': Conversion(),
        'env': Environment(stdout_isatty=True),
        'formatting': Formatting(
            env=Environment(stdout_isatty=True),
            groups=['colors'],
            color_scheme=None,
            explicit_json=False,
            format_options=None,
        )
    })

# Generated at 2022-06-23 19:49:17.735673
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from httpie.core import main
    from httpie.output.streams import Colorized

    env = Environment(stdout=BytesIO(), stderr=BytesIO(), is_windows=True)
    args = Namespace(prettify=['colors'])
    # Colorized chunks are written as text
    with patch.object(Colorized, '__iter__', return_value=('\x1b[31m', '\x1b[0m')):
        write_stream_with_colors_win_py3(
            stream=Colorized(env),
            outfile=env.stdout,
            flush=True
        )
        assert env.stdout.getvalue() == '\x1b[31m\x1b[0m'
    # Non colorized chunks are written with buffer

# Generated at 2022-06-23 19:49:25.161368
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output import streams

    req = requests.PreparedRequest()
    req.method = "GET"
    req.path_url = '/'
    res = requests.Response()
    res.request = req
    res.status_code = 200
    res.headers['Content-Length'] = "501"
    res.encoding = 'utf-8'
    res.raw = BytesIO(b'test content')

    reqStreamClass = PrettyStream if 1 else BufferedPrettyStream
    resStreamClass = PrettyStream if 1 else BufferedPrettyStream

    # with_header=False and with_body=False
    result = build_output_stream_for_message(args=1, env=1, requests_message=req, with_headers=False, with_body=False)

# Generated at 2022-06-23 19:49:35.507987
# Unit test for function write_stream
def test_write_stream():
    from httpie import core
    from httpie.input import ParseError
    from httpie.cli import get_config
    from requests.models import PreparedRequest
    args = get_config(core.load_config(), (), ['--format', '--pretty=all'])
    req = PreparedRequest()
    req.url = "https://httpbin.org"
    req.method = "GET"
    req.headers["Content-Type"] = "application/json"
    req.body = "s"
    out = sys.stdout

# Generated at 2022-06-23 19:49:39.530045
# Unit test for function write_stream
def test_write_stream():
    from io import BytesIO
    stream = []
    outfile = BytesIO()
    header = 'header'
    stream.append(header.encode())
    body = 'body'
    stream.append(body.encode())
    for chunk in stream:
        outfile.write(chunk)
    outfile.seek(0)
    assert outfile.read() == b'headerbody'


# Generated at 2022-06-23 19:49:49.749555
# Unit test for function write_message
def test_write_message():
    import os
    os.chdir("../../..")

# Generated at 2022-06-23 19:49:56.704834
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import BaseStream, PrettyStream, RawStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()

    # Try with prettify, and with_headers, with_body
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert type(stream_type({}, 1, 1, **stream_kwargs)) == PrettyStream
    assert type(stream_kwargs['env']) == Environment
    assert type(stream_kwargs['conversion']) == Conversion
    assert type(stream_kwargs['formatting']) == Formatting

    args.prettify = []

    # Try without prettify, and with_headers,

# Generated at 2022-06-23 19:50:02.272646
# Unit test for function write_message
def test_write_message():
    assert write_message(requests.PreparedRequest, Environment(**{'stream': True}), {'prettify': False, 'format': None, 'colors': 256, 'style': 'solarized', 'download': False, 'verify': True, 'session': None, 'all': False, 'pretty': 'all', 'download': False, 'headers': 'True', 'json': False, 'traceback': False, 'debug': False, 'stream': True}, with_headers=True, with_body=True) == None

# Generated at 2022-06-23 19:50:03.211469
# Unit test for function write_message
def test_write_message():
    pass


# Generated at 2022-06-23 19:50:10.348487
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import io
    import contextlib
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import ColorSchemes

    ps = PrettyStream(
        env=Environment(),
        msg=HTTPResponse(requests.Response()),
        conversion=Conversion(),
        formatting=Formatting(
            env=Environment(),
            groups=['colors'] if sys.platform.startswith('win') else [],
            color_scheme=ColorSchemes.RESPONSE,
        ),
    )

    captured_output = io.StringIO()
    with contextlib.redirect_stdout(captured_output):
        write_stream_with_colors_win_py3(ps, sys.stdout, flush=True)

# Generated at 2022-06-23 19:50:10.990842
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    pass

# Generated at 2022-06-23 19:50:18.033890
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """test_write_stream_with_colors_win_py3"""

    with open('out.log', 'w') as outfile:
        stream = BaseStream(msg=None, with_body=False, with_headers=False)
        stream = NonSeekablePseudoRawStream(stream=stream, color=b'\x1b')
        write_stream_with_colors_win_py3(
            stream=stream,
            outfile=outfile,
            flush=True
        )

