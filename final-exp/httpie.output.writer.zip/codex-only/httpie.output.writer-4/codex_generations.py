

# Generated at 2022-06-23 19:40:28.737686
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    stderr = sys.stderr
    sys.stderr = io.StringIO()
    write_message("hello world", "env", "arg", True, True)
    sys.stderr.close()
    sys.stderr = io.StringIO()
    write_message("hello world", "env", "arg", False, False)
    sys.stderr.close()
    sys.stderr = io.StringIO()
    write_message("hello world", "env", "arg", False, True)
    sys.stderr.close()
    sys.stderr = io.StringIO()
    write_message("hello world", "env", "arg", True, False)
    sys.stderr.close()
    sys.stderr = stderr



# Generated at 2022-06-23 19:40:34.697745
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.output.streams

    class OriginalRequestsMessage(object):
        def __init__(self, status_code, headers, body, request_headers=None):
            self.status_code = status_code
            self.headers = headers
            self.body = body
            self.request_headers = request_headers

    class OBJ(object):
        def __init__(self, **kwargs):
            for name, v in kwargs.items():
                setattr(self, name, v)

    import collections
    class OBJ(collections.namedtuple('_OBJ', 'status_code headers body')):
        pass

    class Environment(object):
        stdout_isatty = True

    class Arguments(object):
        json = False
        stream = True
        pretty = 'all'
       

# Generated at 2022-06-23 19:40:42.367144
# Unit test for function write_message

# Generated at 2022-06-23 19:40:48.266636
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    args = argparse.Namespace(
        stream=False, prettify=['headers'], style='paraiso-light', json=True,
        format_options={'colors': True},
    )
    env = Environment()
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-23 19:40:58.157853
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io

    # Python 3
    if sys.version_info[0] >= 3:
        from unittest import mock
        mock_buffer = io.BytesIO()
        mock_outfile = mock.Mock()
        mock_outfile.encoding = 'utf-8'
        mock_outfile.buffer = mock_buffer

        chunks = (
            b'foo',
            b'\x1b[5m',
            b'bar',
            b'\x1b[0m',
            b'\x1b[31m',
            b'baz',
            b'\x1b[0m',
            b'qux',
            b'\x1b[0;32m',
            b'quux',
            b'\x1b[0m',
        )

# Generated at 2022-06-23 19:41:03.647769
# Unit test for function write_message
def test_write_message():
    import requests
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=True,
        stdin_isatty=True,
        is_windows=False
    )
    args = argparse.Namespace()
    



if __name__ == "__main__":
    test_write_message()

# Generated at 2022-06-23 19:41:13.786043
# Unit test for function write_message
def test_write_message():
    """
    Check result of test_write_message
    """

    class mock_request:

        def __init__(self, json_obj, headers):
            self.json_obj = json_obj
            self.headers = headers

        def json(self):
            return self.json_obj

    json_obj = {'a': 1, 'b': 2}
    headers = {'Content-Type': 'application/json; charset=utf-8'}
    requests_message = mock_request(json_obj, headers)
    class mock_args:
        def __init__(self, headers, body):
            self.headers = headers
            self.body = body

    args = mock_args(headers=True, body=True)

# Generated at 2022-06-23 19:41:17.857234
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args=argparse.Namespace()
    requests_message=requests.PreparedRequest()
    env=Environment()
    with_headers=True
    with_body=True
    stream = build_output_stream_for_message(args, env, requests_message, with_headers, with_body)
    for chunk in stream:
        print(chunk)

# Generated at 2022-06-23 19:41:26.706527
# Unit test for function write_stream
def test_write_stream():
    class BufferedOutput(object):
        def __init__(self, content=b''):
            self.content = content
            self.text = self.content.decode()

        def buffer(self):
            return self

        def write(self, content):
            self.content += content
            self.text += content.decode()

        def flush(self):
            pass

    out = BufferedOutput()

# Generated at 2022-06-23 19:41:36.991386
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    # See if function can be imported even when using Python 2
    from io import BytesIO, StringIO
    from requests import PreparedRequest
    from httpie.output.streams import BaseStream
    from httpie.context import Environment

    class BufferedPrettyStreamPy2(BaseStream):
        def __init__(self, data):
            self.data = data

        def __iter__(self):
            return iter(self.data)

    args = argparse.Namespace(
        debug = False,
        traceback =False,
        prettify ='colors',
        style ='default',
        stream = False,
        json =False,
        format_options ={},
    )
    req = PreparedRequest()
    fake_stdout = StringIO()
    fake_stdout.encoding = 'utf-8'


# Generated at 2022-06-23 19:41:45.631485
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import sys
    import pytest
    from httpie.output import streams
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    # set up objects for test
    os.environ['HTTPIE_TESTING'] = 'True'
    args = type('args', (object,), {'prettify': ['all'], 'stream': False})
    args = pytest.approx(args)
    env = type('env', (object,), {'stdout_isatty': False})
    env = pytest.approx(env)
    class HTTPBody():
        def __init__(self, text):
            self.text = text
            self.content = text.encode('utf-8')


# Generated at 2022-06-23 19:41:54.416638
# Unit test for function write_message
def test_write_message():
    import requests
    import httpie.output
    from httpie.input import HTTPieInput
    from httpie.cli import parser
    from httpie.context import Environment
    from httpie.downloads import Downloader
    from httpie.client import Client
    from httpie.output import write_message
    a = HTTPieInput(['https://www.taufanlubis.web.id'], 'GET')
    args = parser.parse_args(a.args, env=None)
    session = requests.sessions.Session()
    env = Environment(vars(args), stdin=None, stdout=None, stderr=None,
                      isatty=True, stdout_isatty=True,
                      stdin_isatty=False)  # disabled for testing
    client = Client(args, env, session)


# Generated at 2022-06-23 19:42:00.519986
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, RawStream, EncodedStream
    from httpie.context import Environment
    env = Environment()
    args = argparse.Namespace()
    args.stream = True
    args.json = False
    args.prettify = ['colors']
    args.style = 'parrot'
    args.format_options = 'option'
    assert get_stream_type_and_kwargs(env, args) == (PrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=['colors'], color_scheme='parrot', explicit_json=False, format_options='option')})

args = argparse.Namespace()
args.stream = False
args.json = False
args.prettify = []
env = Environment

# Generated at 2022-06-23 19:42:11.363816
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import sys
    import unittest
    from httpie.argtypes import KeyValueArgType

    class TestBuildOutputStreamForMessage(unittest.TestCase):
        def test_build_output_stream_for_message(self):
            parser = argparse.ArgumentParser()
            parser.add_argument('--download', action='store_true')

            args, unknown_args = parser.parse_known_args(args=[''])
            env = Environment(colors=256, stdin=sys.stdin, stdout=sys.stdout,
                              stdout_isatty=False, stdin_isatty=False,
                              is_windows=False, argv=args, config_dir=None,
                              config_path=None)


# Generated at 2022-06-23 19:42:19.935885
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.compat import is_windows
    from httpie.output.streams import get_stream_type_and_kwargs

    assert get_stream_type_and_kwargs(env=Environment(stdout_isatty=True),
                                      args=argparse.Namespace(prettify=['all'], format_options={}, style='par', download=False)) == (PrettyStream, {'env': Environment(stdout_isatty=True), 'conversion': Conversion(), 'formatting': Formatting(env=Environment(stdout_isatty=True),
                                                                                                                                         groups=['all'], color_scheme='par', explicit_json=False, format_options={})})

# Generated at 2022-06-23 19:42:31.869712
# Unit test for function write_message
def test_write_message():
    print("test_write_message")
    import requests
    import argparse
    from httpie.compat import Response
    http_request = requests.packages.urllib3.request.RequestMethods()
    env = Environment()
    # http_request.set_method(b'GET')
    http_request.prepare = lambda: http_request.prepare()
    http_request.prepare_method = lambda method, url=None: http_request.prepare_method(method, url)
    http_request.prepare_url = lambda url, params=None: http_request.prepare_url(url, params)
    http_request.prepare_headers = lambda headers, cookies=None: http_request.prepare_headers(headers, cookies)

# Generated at 2022-06-23 19:42:38.096423
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Arrange
    args = argparse.Namespace()
    args.prettify = 'colors'
    args.stream = False
    args.style = 'paraiso-dark'
    args.json = True
    args.format_options = {
        'class' : { 'show' : '$__name__' }
    }
    env = Environment()
    env.stdout_isatty = True

    # Act
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)

    # Assert
    assert stream_class == BufferedPrettyStream

# Generated at 2022-06-23 19:42:41.137614
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    requests_message = requests.PreparedRequest()
    write_message(
        requests_message,
        Environment(),
        argparse.Namespace(),
        with_headers=False,
        with_body=False
    )

# Generated at 2022-06-23 19:42:51.507925
# Unit test for function write_stream
def test_write_stream():
    line = 'hello, world\n'
    line_bytes = line.encode()

# Generated at 2022-06-23 19:42:58.407479
# Unit test for function write_stream
def test_write_stream():
    stdout = io.StringIO()
    stderr = io.StringIO()
    raw = RawStream([b'abcdefghij\nabcdefghij\nabcdefghij\n'], chunk_size=7)
    for i in range(3):
        write_stream(raw, stdout, True)
        stdout.write('\n')
    assert stdout.getvalue() == 'abcdefg\nabcdefg\nabcdefg\n\n\n\n'

    raw = RawStream([b'abcdefghij\nabcdefghij\nabcdefghij\n'], chunk_size=1)
    for i in range(3):
        write_stream(raw, stdout)
        stdout.write('\n')

# Generated at 2022-06-23 19:43:07.945815
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.input import KeyValue
    from httpie.output import StreamUnicodeWrapper
    from httpie.output.streams import write_stream

    class Args:
        def __init__(self):
            self.stream = None
            self.prettify = None

    class Env:
        def __init__(self):
            self.stdout = StreamUnicodeWrapper(sys.stdout)
            self.stdout_isatty = True

    args = Args()
    env = Env()
    env.is_windows = sys.platform.startswith('win')

    _http_version_10 = "HTTP/1.0"

    def _get_request(url: str) -> requests.PreparedRequest:
        r = requests.Request(method="GET", url=url)
       

# Generated at 2022-06-23 19:43:14.312182
# Unit test for function write_message
def test_write_message():
    # environment
    env = Environment(
        stdin=io.BytesIO(),
        stdout=io.BytesIO(),
        stderr=io.BytesIO(),
        stdout_isatty=True,
        stderr_isatty=True,
    )

    # parser
    parser = argparse.ArgumentParser(description="desc", parents=[])
    parser.add_argument("--download", action="store_true", default=False)
    parser.add_argument("--stream", action="store_true", default=False)
    parser.add_argument("--traceback", action="store_true", default=False)
    parser.add_argument("--debug", action="store_true", default=False)

    # request
    args = parser.parse_args()
    requests_message = requests.PreparedRequest()

# Generated at 2022-06-23 19:43:19.150100
# Unit test for function write_message
def test_write_message():
    requests_message = "hi"
    env = Environment()
    args = argparse.Namespace(prettify = ['all'])
    with_headers = True
    with_body = True
    str = write_message(requests_message, env, args, with_headers, with_body)
    assert str

# Generated at 2022-06-23 19:43:19.852301
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    pass

# Generated at 2022-06-23 19:43:30.419987
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import colorama
    colorama.init()
    import sys
    class MockTextIO:
        def __init__(self, encoding):
            self.encoding = encoding

        def buffer(self):
            return self

        def write(self, txt):
            sys.stdout.buffer.write(txt.encode(self.encoding))

    mock_stream = [
        b'\x1b[31mcolored\n',
        b'\x1b[32mcolored\n',
        b'plain\n',
        b'\x1b[33mcolored\n',
        b'plain\n'
    ]

    args = argparse.Namespace(
        prettify='colors',
        stream=True,
    )

# Generated at 2022-06-23 19:43:39.844537
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    args = argparse.Namespace(
        stream=True,
        prettify='all',
        style='parrot',
        format_options={}
    )
    env = Environment('.', '.', '.')
    message = requests.Response()
    message.status_code = 200
    message.headers['content-type'] = 'application/json'
    message._content = b'{"hello": "world"}'
    for i in build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=message,
        with_body=True,
        with_headers=True,
    ):
        print("i", i)

if __name__ == "__main__":
    test_build_output_stream_for_message()

# Generated at 2022-06-23 19:43:51.544298
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import argparse
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.cli import parser
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )
    import requests
    import io
    import os

    out = io.StringIO()
    out_b = io.BytesIO()
    Environment(stdin=io.StringIO(),
                stdout=out,
                stdout_isatty=False,
                stderr=out,
                stderr_isatty=False)
    args = parser.parse_args([
        'get',
        'https://httpbin.org/get'
    ])

# Generated at 2022-06-23 19:44:00.326722
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    environment=Environment()
    arguments=argparse.Namespace()
    arguments.stream=False
    arguments.prettify=[]
    arguments.json=False
    arguments.style=None
    arguments.format_options=[]
    stream_class,stream_kwargs=get_stream_type_and_kwargs(environment,arguments)
    assert stream_class is BufferedPrettyStream
    assert len(stream_kwargs) is 3
    assert stream_kwargs['env'] is not None
    assert isinstance(stream_kwargs['conversion'],Conversion)
    assert isinstance(stream_kwargs['formatting'],Formatting)
    arguments.prettify=['all']
    arguments.json=True
    arguments.style='default'
    arguments.format_options=[('json.sort_keys','true')]
   

# Generated at 2022-06-23 19:44:02.715799
# Unit test for function write_message
def test_write_message():
    parser = argparse.ArgumentParser()
    args, unknown = parser.parse_known_args()
    env = Environment()
    assert write_message(requests.PreparedRequest, env, args) == None
    assert write_message(requests.Response, env, args) == None

# Generated at 2022-06-23 19:44:13.704109
# Unit test for function write_message
def test_write_message():
    from httpie.compat import StringIO
    from httpie import ExitStatus
    from httpie.cli import parser
    args = parser.parse_args(['GET', 'http://httpbin.org/get'])
    env = Environment(
        stdin=sys.stdin,
        stdout=StringIO(),

        stdout_isatty=False,
    )
    r = requests.get(url='http://httpbin.org/get',verify=False)
    write_message(requests_message=r, env=env, args=args, with_headers=False, with_body=True)

# Generated at 2022-06-23 19:44:21.207639
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import EncodedStream
    stderr = StringIO()

    stream_class = EncodedStream
    stream_kwargs = {
        'env': Environment(),
    }

    stream = stream_class(
        msg=HTTPResponse(requests.Response()),
        with_headers=True,
        with_body=True,
        **stream_kwargs,
    )

    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=stderr,
        flush=True,
    )
    assert stderr.getvalue() == ''

# Generated at 2022-06-23 19:44:30.121087
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import PrettyStream

    assert isinstance(
        build_output_stream_for_message(
            args=argparse.Namespace(
                stream=False,
                prettify=('colors',),
                style='default',
                json=False,
                format_options={},
                debug=False,
                traceback=False,
            ),
            env=argparse.Namespace(
                stdout_isatty=True,
                stderr=sys.stderr,
                is_windows=False,
            ),
            requests_message=requests.Response(),
            with_headers=True,
            with_body=True,
        ), PrettyStream,
    )

# Generated at 2022-06-23 19:44:40.390901
# Unit test for function write_message
def test_write_message():
    import sys
    from httpie.context import Environment
    from pygments import highlight
    from pygments.lexers import HttpLexer
    from pygments.formatters import TerminalFormatter
    env = Environment()
    args = env.argparser.parse_args([])

# Generated at 2022-06-23 19:44:48.016812
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class MockArgumentParserClass:
        def __init__(self, args=(), kwargs={}):
            self.args = args
            self.kwargs = kwargs
            self.defaults = {}

        def is_default(self, arg):
            return self.kwargs[arg] == self.defaults[arg]

    mock_answer = "HTTP/1.1 404 Not Found\r\nServer: nginx/1.10.3 (Ubuntu)\r\nDate: Sun, 12 May 2019 00:06:49 GMT\r\nContent-Type: text/html\r\nContent-Length: 1539\r\nConnection: keep-alive\r\n"

# Generated at 2022-06-23 19:44:57.446580
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    """Unit test for function test_get_stream_type_and_kwargs"""
    env = Environment(
        stdin=None,
        stdout=None,
        stderr=None,
        stdout_isatty=False,
        is_windows=False
    )
    args = argparse.Namespace(
        prettify=False,
        stream=False,
        style="none",
        json=False,
        format_options={},
    )

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == RawStream
    assert stream_kwargs == {"chunk_size": RawStream.CHUNK_SIZE}


# Generated at 2022-06-23 19:45:07.900999
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from httpie.output.streams import ColorizedStream
    from httpie.status import ExitStatus
    from httpie.cli import parser
    args = parser.parse_args(['--pretty', 'all'])
    env = Environment(vars={'HTTPIE_COLORS': '1'}, stdout=StringIO(), stderr=StringIO())

    # test write stream with colors

# Generated at 2022-06-23 19:45:17.988494
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    try:
        from colorama import AnsiToWin32, init
        init()
        outfile = AnsiToWin32(sys.stdout)
    except ImportError:
        return
    except AttributeError:  # sys.stdout.buffer might not be an io.TextIOBase
        return

    stream = [b'\x1b[31mfoo\x1b[0m']
    write_stream_with_colors_win_py3(stream, outfile, flush=False)
    assert stream == []  # == stream is exhausted

    stream = [b'bar']
    write_stream_with_colors_win_py3(stream, outfile, flush=False)
    assert stream == [b'bar']  # == stream is not exhausted

# Generated at 2022-06-23 19:45:29.679518
# Unit test for function write_message
def test_write_message():
    from io import BytesIO
    from httpie.input.base import AuthCredentials

    # Dummy `Environment`
    env = Environment(stdout=BytesIO(), stdin=BytesIO(),
                      stderr=BytesIO(), is_windows=False, stdout_isatty=True,
                      stdin_isatty=True, stdout_bytes_written=0)
    env.stdout.write = BytesIO.write
    env.stderr.write = BytesIO.write

    # Dummy `argparse.Namespace`
    args = argparse.Namespace()
    args.pretty = True
    args.stream = True
    args.debug = False
    args.download = False
    args.traceback = False

    # Dummy HTTP Request

# Generated at 2022-06-23 19:45:39.768720
# Unit test for function write_message
def test_write_message():
    try:
        import requests
    except ImportError:
        return
    from httpie.context import Environment
    from httpie.context import Environment
    from httpie.output.processing import Conversion, Formatting
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream,
    )

    env = Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest
    with_headers = False
    with_body = False
    build_output_stream_for_message(args=args, env=env, requests_message=requests_message, with_headers=with_headers,
                                    with_body=with_body)



# Generated at 2022-06-23 19:45:44.677659
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys

    env = Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stdout_isatty=False
    )
    return write_stream_with_colors_win_py3(
        stream=BaseStream(msg=HTTPResponse(requests.Response()), with_headers=True, with_body=True),
        outfile=io.TextIOWrapper(io.BytesIO()),
        flush=False
    )

# Generated at 2022-06-23 19:45:54.217142
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """Unit test for function build_output_stream_for_message
    """
    try:
        outfile = sys.stdout.buffer
    except AttributeError:
        outfile = sys.stdout

    env = Environment()
    env.is_windows = False

    requests_message = HTTPResponse()
    requests_message.request = HTTPRequest()
    requests_message.request.url = "https://example.com"
    requests_message.request.method = "GET"
    requests_message.request.http_version = b"HTTP/1.1"
    requests_message.request.headers["X-Header"] = "Request Header"
    requests_message.http_version = b"HTTP/1.1"
    requests_message.status_code = 200
    requests_message.reason_phrase = "OK"


# Generated at 2022-06-23 19:45:55.284047
# Unit test for function write_message
def test_write_message():
    pass



# Generated at 2022-06-23 19:45:58.263790
# Unit test for function write_stream
def test_write_stream():
    """Test to check if the write stream is successfull"""
    stream = write_stream(sys.stdout, b"TESTING", False)
    assert stream is not None
    assert stream == "TESTING"



# Generated at 2022-06-23 19:46:05.055994
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    import urllib3
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.output.streams import RawStream

    args = argparse.Namespace(
        stream=False, debug=False, traceback=False, 
        prettify=False, style='none', json=False, 
        format_options=[], color=True
    )
    env = Environment(
        stdin_isatty=False,
        stdout_isatty=False,
        stderr_isatty=False,
        color=True,
        keyring_backend=None,
    )
    get_resp = requests.Response()
    get_resp.status_code = 200
    get_resp.raw.version = 11
    get_resp

# Generated at 2022-06-23 19:46:15.638193
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-23 19:46:24.917636
# Unit test for function write_stream
def test_write_stream():
    from httpie.core import main
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie.plugins import Plugin
    """
    Used to check that write_stream works with real data (not just an empty
    string or an empty list)

    For test below to pass, the only required adjustment is to change the url
    to a valid url
    """
    url = 'http://httpbin.org/get'

    args = main._get_parsed_args(
        args=[url],
        env=main._build_env(stdin=None, stdout=None, stderr=None, vars=None)
    )
    env = Environment(args=args)

# Generated at 2022-06-23 19:46:28.321214
# Unit test for function write_stream
def test_write_stream():
    write_stream(stream = RawStream(msg=HTTPResponse('{"msg":"hello"}'), with_body=True, with_headers=True),
                 outfile = sys.stdout,
                 flush = False)

# Generated at 2022-06-23 19:46:38.630845
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.core import main
    from httpie.output.streams import EncodedStream
    from httpie.output.streams import RawOutputStream
    from httpie.output.streams import SimpleOutputStream
    from tests.output.streams import BufferedPrettyStream
    from tests.output.streams import PrettyOutputStream
    from tests.output.streams import PrettyOutputStream1
    from tests.output.streams import PrettyOutputStream2
    from tests.output.streams import PrettyOutputStream3
    from tests.output.streams import PrettyOutputStream4
    from tests.output.streams import PrettyOutputStream5
    from tests.output.streams import PrettyOutputStream6
    from tests.output.streams import PrettyOutputStream7
    from tests.output.streams import PrettyOutputStream8

# Generated at 2022-06-23 19:46:41.832360
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    streampair = get_stream_type_and_kwargs(Environment(), argparse.Namespace(prettify=None, stream=False, style='default', json=False))
    assert streampair[0] == EncodedStream


# Generated at 2022-06-23 19:46:45.329819
# Unit test for function write_stream
def test_write_stream():
    import io
    stream = BaseStream(msg=f'res')
    outfile = io.BytesIO()
    write_stream(stream=stream, outfile=outfile, flush=False)
    out = outfile.getvalue()
    # print(out)

# Generated at 2022-06-23 19:46:55.716809
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Buffer:
        def __init__(self):
            self.chunks = []

        def write(self, chunk):
            self.chunks.append(chunk)

    class Stream:
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            return iter(self.chunks)

    class Outfile:
        def __init__(self, encoding, buffer):
            self.encoding = encoding
            self.buffer = buffer

    # Only colorized output is written to the outfile,
    # but the outfile is still written to as text
    # to ensure it gets processed by colorama.
    buffer = Buffer()
    outfile = Outfile('latin-1', buffer)

# Generated at 2022-06-23 19:47:01.184268
# Unit test for function write_message
def test_write_message():
    """
    test for write_message(
    requests_message: Union[requests.PreparedRequest, requests.Response],
    env: Environment,
    args: argparse.Namespace,
    with_headers=False,
    with_body=False,
    )
    """
    import requests
    import httpie
    env = httpie.Environment()
    args = argparse.Namespace()
    requests_message = requests.PreparedRequest()
    write_message(requests_message, env, args)



# Generated at 2022-06-23 19:47:05.777144
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs([False, True], [True, True]) == (RawStream, {'chunk_size': RawStream.CHUNK_SIZE_BY_LINE})
    assert get_stream_type_and_kwargs([True, True], [True, True]) == (EncodedStream, {'env': [True, True]})

# Generated at 2022-06-23 19:47:13.751667
# Unit test for function write_stream
def test_write_stream():
    from httpie.context import Environment
    from httpie.output.streams import PrettyStream
    hs = PrettyStream(
        env=Environment(),
        msg=HTTPResponse(requests.Response()),
        with_headers=True,
        with_body=True,
        conversion=Conversion(),
        formatting=Formatting(env=Environment(), groups=('group',), color_scheme=None, explicit_json=False, format_options=None),
    )
    return write_stream(
                hs,
                sys.stdout,
                False
    )

# Generated at 2022-06-23 19:47:19.463589
# Unit test for function write_stream
def test_write_stream():
    class stream:
        def __init__(self,a,b):
            self.a=a
            self.b=b
        def __iter__(self):
            return self
        def __next__(self):
            return self.a
    class outfile:
        def __init__(self,buffer):
            self.buffer=buffer
        def write(self,chunk):
            return self.buffer.write(chunk)

    class buffer:
        def __init__(self,):
            self.data=[]
        def write(self,chunk):
            self.data.append(chunk)
        def get_data(self,):
            return self.data
    class flush:
        def __init__(self,a):
            self.a=a

# Generated at 2022-06-23 19:47:26.929565
# Unit test for function build_output_stream_for_message

# Generated at 2022-06-23 19:47:33.913757
# Unit test for function write_stream
def test_write_stream():
    import sys

    #1.Write to stdout
    try:
        # Writing bytes so we use the buffer interface (Python 3).
        buf = sys.stdout.buffer
    except AttributeError:
        buf = sys.stdout
    
    stream = EncodedStream(env = Environment())._iter_bytes() 
    for chunk in stream:
        buf.write(chunk)

    #2.Write to stdout with color
    stream = PrettyStream(env=Environment(),conversion=Conversion(),formatting=Formatting(env=Environment(),groups=['colors'],color_scheme='par',explicit_json=False,format_options=None))._iter_bytes()
    for chunk in stream:
        buf.write(chunk)
if __name__ == "__main__":
    test_write_stream()

# Generated at 2022-06-23 19:47:39.586203
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(Environment, '--prettify')
    assert stream_class == BufferedPrettyStream
    assert stream_kwargs == {
        'env': Environment,
        'conversion': Conversion(),
        'formatting': 'no need to test formatting'}

# Generated at 2022-06-23 19:47:41.897642
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    st = get_stream_type_and_kwargs(Environment(), argparse.ArgumentParser())
    assert isinstance(st[0], RawStream)

# Generated at 2022-06-23 19:47:42.426543
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-23 19:47:49.599582
# Unit test for function write_message
def test_write_message():
    import unittest
    from unittest import mock
    from httpie.output.formats.wrappers import ResponseWrapper
    from httpie.input import SEP_CRLF

    class DictLikeResponse(object):
        """
        Dict like response for unit test
        """
        def __init__(self, status_code, headers, body):
            self.status_code = status_code
            self.headers = headers
            self.body = body

        def get(self, key, default=None):
            if key == 'status':
                return self.status_code
            if key == 'headers':
                return self.headers
            if key == 'body':
                return self.body

    # need to mock the output stream and write function in order to test

# Generated at 2022-06-23 19:47:57.106195
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from .utils import StreamTestClass
    from httpie.output.streams import BaseStream, PrettyStream, BufferedPrettyStream

    stream_classes = [PrettyStream, BufferedPrettyStream]
    for stream_class in stream_classes:
        stream = StreamTestClass(stream_class.__name__)
        outfile = StringIO()
        write_stream_with_colors_win_py3(
            stream=stream, outfile=outfile, flush=False
        )
        assert outfile.getvalue() == stream.name

# Generated at 2022-06-23 19:48:08.224107
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():

    import sys
    import io
    import os

    def is_windows():
        return sys.platform == 'win32'

    def is_python3():
        return sys.version_info >= (3, 0)

    if not is_windows() or not is_python3():
        return

    import functools
    import locale
    locale.setlocale(locale.LC_ALL, '')

    if not hasattr(sys, 'base_prefix'):
        # Python 2.7 needs some extra imports
        from io import BytesIO
        from ctypes import (
            windll,
            create_unicode_buffer,
            create_string_buffer,
            cast,
            POINTER,
            WinError,
        )
        from ctypes.wintypes import HANDLE, DWORD, BOOL, LPWSTR

# Generated at 2022-06-23 19:48:17.666397
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import pytest
    from httpie.output.streams import RawStream
    from httpie.output.streams import PrettyStream
    from httpie.output.streams import BufferedPrettyStream
    from httpie.output.streams import EncodedStream

    class Arguments(object):
        def __init__(self, style='', prettify='', stream='', json='', format_options=''):
            self.style = style
            self.prettify = prettify
            self.stream = stream
            self.json = json
            self.format_options = format_options

    class Environment(object):
        def __init__(self, is_windows=''):
            self.is_windows = is_windows


# Generated at 2022-06-23 19:48:25.798778
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    from shutil import rmtree
    from tempfile import mkdtemp
    from httpie.output.streams import UnicodeStream
    from httpie.plugins.builtin import FormattedKeyValue, JSONStream

    class Stream(BaseStream):
        def __init__(self):
            raise Exception()

    stream = Stream()
    a = StringIO()
    b = StringIO()
    write_stream(stream, a, flush=False)
    write_stream(stream, b, flush=True)

    a = StringIO()
    b = StringIO()
    stream = JSONStream(FormattedKeyValue(u'k', u'v'))
    write_stream(stream, a, flush=False)
    write_stream(stream, b, flush=True)

    a = StringIO()

# Generated at 2022-06-23 19:48:36.721193
# Unit test for function write_message
def test_write_message():
    import io
    import sys
    import unittest
    from unittest.mock import patch
    from httpie.core import main

    class TestWriteMessage(unittest.TestCase):
        def test_write_message(self):
            stdout = io.StringIO()
            env = Environment()
            env.stdout = stdout
            env.stdout_isatty = False
            env.is_windows = False
            args = main.parse_args(args=[
                'https://github.com', '-i', '--json', '--body'
            ])
            response = requests.Response()
            response.status_code = 200
            response.url = 'https://github.com'
            response.encoding = 'utf-8'
            response._content_consumed = True
            response.raw = io

# Generated at 2022-06-23 19:48:45.093862
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli.args import args

    # from a running session
    from httpie import context
    env = context.Environment(headers={}, auth={})
    args.headers = {}
    args.auth = {}

    # Choose stream class and kwargs
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )

    # test cases
    assert stream_class == RawStream
    assert stream_kwargs == {'chunk_size': 65536}

    args.prettify = ['body']
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args
    )
    assert stream_class == PrettyStream

# Generated at 2022-06-23 19:48:52.692985
# Unit test for function write_message
def test_write_message():
    args = argparse.Namespace(
        format='{h.Host}',
        headers='',
        http__form='',
        http__ignore_stdin='',
        http__pretty='all',
        http__style=None,
        json='',
        method='GET',
        pretty='all',
        session='',
        url='',
        verbose='',
        version='1.0.2',
        # Added for unit test
        stream='',
        download='',
        debug='',
        traceback='',
        prettify='all',
        style='solarized-dark',
        format_options='',
    )
    env = Environment()
    requests_message = requests.PreparedRequest()
    with_headers = False
    with_body = False

# Generated at 2022-06-23 19:49:03.639038
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """
    This function is used to simulate the behavior of `write_stream_with_colors` function
    when it is run in Windows with Python 3 and colorized terminal output.
    """
    import sys
    class OutputCollector:
        def __init__(self):
            self.value = ''
            self.encoding = 'utf-8'
        def write(self, value):
            self.value += value
        def flush(self):
            pass
    outfile = OutputCollector()
    color = b'\x1b['
    class BaseStream:
        def __iter__(self):
            yield b'Inconnu. '
            yield color + b'0;31m' + b'Possible'
            yield color + b'0m' + b'ment '
            yield b'une '

# Generated at 2022-06-23 19:49:15.661467
# Unit test for function write_message
def test_write_message():
    import sys
    import time
    import httpie.input
    import httpie.cli
    parser = httpie.cli.parser
    args = parser.parse_args(args=['test_write_message'])
    env = httpie.cli.Environment(
        stdin=sys.stdin,
        stdout=sys.stdout,
        stderr=sys.stderr,
        stdin_isatty=True,
        stdout_isatty=True,
        colors=256
    )
    req = requests.PreparedRequest()
    runtime_conf = httpie.input.Env(*httpie.cli.parse_env())
    req.headers.update(httpie.input.DEFAULT_HEADERS)
    req.headers.update(runtime_conf.headers)
    #req.auth = runtime_

# Generated at 2022-06-23 19:49:24.184000
# Unit test for function write_stream
def test_write_stream():
    from unittest.mock import MagicMock
    from io import StringIO
    from httpie.tests.utils import MockEnvironment
    import sys
    import httpie

    env = MockEnvironment(
        stdout=StringIO(),
        stdout_isatty=False
    )

    args = httpie.cli.parser.parse_args(
        ['-p', 'n', '--stream', '--debug', 'https://httpbin.org/get']
    )

    res = requests.get('https://httpbin.org/get')

    buffer = sys.stdout

    write_stream(
        build_output_stream_for_message(
            args,
            env,
            res,
            with_headers=True,
            with_body=True
        ),
        buffer,
        False,
    )




# Generated at 2022-06-23 19:49:34.027420
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import os
    import tempfile
    in_file, out_file = tempfile.mkstemp(text=True)
    env = Environment(stdout_isatty=True, stdin_isatty=True, is_windows=False, stdout=open(out_file, 'wb'))
    class args:
        def __init__(self):
            self.style = 'monokai'
            self.prettify = []
            self.stream = False
            self.json = False
            self.format_options = {}
    request_obj = requests.PreparedRequest()
    request_obj.method = 'GET'
    request_obj.url = 'http://httpbin.org/cookies'
    request_obj.headers = {
    'Cookie': 'httpie-test=test-cookie'
    }

# Generated at 2022-06-23 19:49:34.912332
# Unit test for function write_stream
def test_write_stream():
    pass


# Generated at 2022-06-23 19:49:42.137334
# Unit test for function write_stream
def test_write_stream():
    from io import StringIO
    import requests

    s = StringIO()
    r = requests.Response()
    r.url = 'www.baidu.com'
    r.encoding = 'utf-8'
    r.raw = open('/Users/hongxiang/PycharmProjects/httpie/httpie/output/testing/test.html')
    r.raw.encoding = 'utf-8'
    r.elapsed = requests.structures.CaseInsensitiveDict()
    write_stream(stream=build_output_stream_for_message(
        args=argparse.Namespace,
        env=Environment(),
        requests_message=r,
        with_headers=False,
        with_body=False,
    ), outfile=s, flush=True)



# Generated at 2022-06-23 19:49:50.471639
# Unit test for function write_stream
def test_write_stream():
    from unittest.mock import MagicMock
    from io import StringIO
    env = MagicMock()
    env.is_windows = False
    env.stdout_isatty = True
    outfile = StringIO()
    args = MagicMock()
    args.stream = False
    stream = MagicMock()
    stream = ['test']
    write_stream(stream=stream, outfile=outfile, flush=False)
    assert outfile.getvalue() == 'test'
    args.stream = True
    outfile = StringIO()
    write_stream(stream=stream, outfile=outfile, flush=False)
    assert outfile.getvalue() == 'test'

# Generated at 2022-06-23 19:49:57.445017
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import pytest
    from httpie.output.streams import __all__ as streams
    from httpie.output.processing import Conversion, Formatting
    from httpie.context import Environment
    from httpie.utils import group_dict_items
    data_headers = {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': 0,
    'Host': 'httpbin.org',
    'X-Powered-By': 'Flask',
    'X-Processed-Time': '0.000',
    'Date': 'Sat, 12 Jan 2019 16:36:23 GMT'
    }
    data_url = 'http://httpbin.org/get'
    data_method = 'GET'

# Generated at 2022-06-23 19:50:08.393434
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    from httpie.output.streams import BaseStream
    # create stream class that has color in the text
    class TestStream(BaseStream):
        def __init__(self):
            self.n = 0
        def __iter__(self):
            return self
        def __next__(self):
            self.n += 1
            if self.n > 1:
                raise StopIteration
            return b'\x1b['
    stream = TestStream()
    expected = '\x1b['
    outfile = io.StringIO()
    write_stream_with_colors_win_py3(stream, outfile, True)
    assert outfile.getvalue() == expected
    outfile.close()

# Generated at 2022-06-23 19:50:14.089448
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    import os
    from httpie.context import Environment
    os.environ['HTTPIE_ENV'] = 'development'
    args = ['http', 'www.google.com']
    env = Environment()
    assert get_stream_type_and_kwargs(env=env,args=args)[0].__name__ == "PrettyStream"
    os.environ['HTTPIE_ENV'] = 'production'
    env = Environment()
    assert get_stream_type_and_kwargs(env=env, args=args)[0].__name__ == "EncodedStream"

# Generated at 2022-06-23 19:50:22.851787
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import io
    import sys
    import json
    import requests
    from httpie.output.streams import RawStream, BufferedPrettyStream, PrettyStream, EncodedStream
    from httpie.output.processing import Conversion, Formatting

    url = 'http://httpie.org'
    headers = {'User-Agent': 'HTTPie'}
    data = {'name': 'John', 'email': 'john@example.com'}
    auth = ('user', 'pass')

    # Mock the `requests.Response` instance returned by the requests library.
    # `requests` library doesn't have a `.raw` attribute.
    response = requests.Response()
    response.status_code = 201
    response.headers = requests.structures.CaseInsensitiveDict({'content-type': 'application/json'})
    response.enc