

# Generated at 2022-06-23 19:40:27.142344
# Unit test for function write_message
def test_write_message():
    import sys
    import tempfile
    from httpie.downloads import BASE_MESSAGE_CLS

    from . import TestEnvironment


    class TestCase:

        def __init__(self, request, response):
            self.request = request
            self.response = response

        def __repr__(self):
            return '%s -> %s' % (self.request, self.response)

        def __eq__(self, other):
            return (
                self.request == other.request
                and self.response == other.response
            )

    


# Generated at 2022-06-23 19:40:29.823743
# Unit test for function write_stream
def test_write_stream():
    stream = 'test stream'
    outfile = ['a', 'b']
    def flush():
        pass
    write_stream(stream, outfile, flush)



# Generated at 2022-06-23 19:40:35.665315
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
        stdin=io.StringIO(''),
        stdout=io.BytesIO(),
        stderr=io.StringIO(''),
        is_windows=False,
        colors=256,
        stdout_isatty=True
    )
    args = argparse.Namespace()
    args.prettify = []
    args.style = ''
    args.json = False
    args.format_options = {}
    args.stream = False

    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type is BufferedPrettyStream

# Generated at 2022-06-23 19:40:42.637048
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream
    env = Environment(colors=256)
    args = argparse.ArgumentParser()
    args.prettify = ["colors"]

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == PrettyStream
    assert stream_kwargs['conversion'].__class__ == Conversion
    assert stream_kwargs['formatting'].__class__ == Formatting
    assert stream_kwargs['env'] == env

# Generated at 2022-06-23 19:40:52.925244
# Unit test for function write_message
def test_write_message():
    import requests
    import argparse
    from httpie.context import Environment
    import os
    import subprocess
    import re
    import time
    import signal
    import pytest

    pid = 0
    false_requests_message = ''
    false_env = ''
    false_args = ''
    false_with_headers = ''
    false_with_body = ''

    def write_message_test(requests_message,with_body=False,with_headers=False):
        false_requests_message = requests_message
        false_with_body = with_body
        false_with_headers = with_headers
        write_message(requests_message,false_env,false_args,false_with_headers,false_with_body)

    # Prepare an incorrect test environment
    false_args = argparse.Names

# Generated at 2022-06-23 19:41:00.764534
# Unit test for function write_stream_with_colors_win_py3

# Generated at 2022-06-23 19:41:09.335365
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import tempfile
    env = Environment(
        stdin=tempfile.TemporaryFile(),
        stdin_isatty=False,
        stdout=tempfile.TemporaryFile(),
        stdout_isatty=True,
        stderr=tempfile.TemporaryFile(),
        stderr_isatty=True,
        is_windows=True
    )
    args = argparse.Namespace(prettify=['colors'])
    stream = EncodedStream(
        msg='Testing'
    )
    write_stream_kwargs = {
        'stream': stream,
        'outfile': env.stdout,
        'flush': env.stdout_isatty
    }
    write_stream_with_colors_win_py3(**write_stream_kwargs)

# Generated at 2022-06-23 19:41:18.013724
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    # ts = time.time()
    env = Environment()
    args = env.argparser.parse_args(['--json'])

    r = requests.Request(
        method='get',
        url='https://test.test.test',
        headers=dict(
            hi=2,
            mo=5
        ),
        data=json.dumps(dict(
            test=True
        ))
    )

    write_message(r.prepare(), env, args, with_headers=True, with_body=True)

    print()

    r = requests.Response()
    r.url = 'https://test.test.test'
    r.ok = True
    r.status_code = 200
    r.headers = dict(
        hi=2,
        mo=5
    )
    r.json = dict

# Generated at 2022-06-23 19:41:19.310546
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(
        env='',
        args='',
    )

# Generated at 2022-06-23 19:41:29.977939
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from click.testing import CliRunner
    from httpie.cli import main

    # Test for Raw stream
    runner = CliRunner()
    result = runner.invoke(
        main, ['--stream', '--body', 'https://httpbin.org/get']
    )
    assert result.exit_code == 0
    assert 'HTTP/1.1 200 OK' in result.output
    assert 'HTTPStreamRawChunked' in result.output

    # Test for Encoded stream
    runner = CliRunner()
    result = runner.invoke(
        main, ['--body', 'https://httpbin.org/get']
    )
    assert result.exit_code == 0
    assert 'HTTP/1.1 200 OK' in result.output
    assert 'HTTPEncodedChunked' in result.output

    # Test for Pretty

# Generated at 2022-06-23 19:41:36.049038
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class Message():
        def __init__(self, text):
            self.text = text
            self.encoding = 'utf-8'

    class Stream():
        def __iter__(self):
            color_chunk = b'\x1b[33m'
            text_chunk = 'message'.encode('utf-8')
            yield color_chunk
            yield text_chunk

    env = Environment()
    env.is_windows = True
    env.stdout_encoding = 'utf-8'
    buf = io.StringIO()
    write_stream_with_colors_win_py3(
        stream=Stream(),
        outfile=buf,
        flush=True
    )
    assert buf.getvalue() == "\x1b[33mmessage\x1b[0m"




# Generated at 2022-06-23 19:41:44.816901
# Unit test for function write_message
def test_write_message():
    """Unit test for function write_message"""
    import json
    from httpie.plugins import builtin
    from httpie.core import main
    from httpie.output.streams import EncodedStream
    from httpie.config import Config
    from httpie.context import Environment


# Generated at 2022-06-23 19:41:52.407985
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    from httpie.output.streams import BaseStream
    from httpie.output.streams import ColorizeWinPy3Mixin

    class DummyStream(BaseStream[b''], ColorizeWinPy3Mixin):
        pass

    stream = DummyStream(msg=None, with_body=True, with_headers=False, env=None)
    out = io.BytesIO()
    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=out,
        flush=True
    )
    out.seek(0)
    assert out.read() == b'\n'

# Generated at 2022-06-23 19:41:59.480660
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """
    # 1. with_headers and with_body is False，build_output_stream_for_message()
    will return a empty tuple

    # 2. with_headers is True, with_body is False，build_output_stream_for_message()
    will return a PRETTY_STREAM_CLASS 

    # 3. with_headers is False, with_body is True，build_output_stream_for_message()
    will return a PRETTY_STREAM_CLASS 

    # 4. with_headers is True, with_body is True，build_output_stream_for_message()
    will return a PRETTY_STREAM_CLASS 
    """

# Generated at 2022-06-23 19:42:10.570207
# Unit test for function write_message
def test_write_message():
    class FakeRequest:
        pass
    class FakeResponse:
        pass
    # Test 1
    # Check if it does not execute the body of the if statement
    # when with_body or with_headers are False
    write_message(FakeRequest(), None, None, False, False)
    write_message(FakeResponse(), None, None, False, False)
    # Test 2
    class FakeArgs:
        stream = True
    class FakeEnvironment:
        stdout = 'stdout'
        stdout_isatty = True

    # Check if the function will execute write_stream method
    # in case of a valid request
    try:
        write_message(FakeRequest(), FakeEnvironment(), FakeArgs(), True, True)
    except IOError as e:
        if not (e.errno == errno.EPIPE):
            raise


# Generated at 2022-06-23 19:42:19.361931
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    request_mock = MagicMock()
    request_mock.headers = {'foo': 'bar'}
    request_mock.url = 'foo'
    response_mock = MagicMock()
    response_mock.headers = {'foo': 'bar'}
    response_mock.elapsed = MagicMock()
    response_mock.elapsed.total_seconds = 1
    response_mock.status_code = 200
    response_mock.url = 'foo'

    stream = build_output_stream_for_message(Environment(), argparse.Namespace(
        prettify=['all'], style='default', stream=True,
        colors=True), request_mock, True, True)
    outfile = TextIOWrapper(BytesIO(), encoding='utf-8')
    write_stream

# Generated at 2022-06-23 19:42:31.229757
# Unit test for function write_stream
def test_write_stream():
    with open("test.py", 'w') as f:
        env = Environment(
            stdout=f,
            stdout_isatty=False,
        )
        
        parser = argparse.ArgumentParser()
        parser.add_argument('-v', '--verbose', action='store_true')
        parser.add_argument('--json', action='store_true')
        parser.add_argument('--stream', action='store_true')
        parser.add_argument('--debug', action='store_true')
        parser.add_argument('--traceback', action='store_true')
        parser.add_argument('--download', action='store_true')
        parser.add_argument('--prettify', nargs='+')
        parser.add_argument('--style', nargs='+')
        parser

# Generated at 2022-06-23 19:42:40.795560
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    import sys
    sys.stdout = io.StringIO()
    write_stream_with_colors_win_py3(BaseStream([b'\x1b[1m', b'foo', b'\x1b[0m', b'bar']), sys.stdout, True)
    assert sys.stdout.getvalue() == '\x1b[1mfoo\x1b[0mbar'
    sys.stdout = io.StringIO()
    write_stream_with_colors_win_py3(BaseStream([b'\x1b[1m', b'foo', b'\x1b[0m', b'bar\n']), sys.stdout, True)

# Generated at 2022-06-23 19:42:50.516947
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    class FakeStream:
        def __init__(self, chunks):
            self.chunks = chunks

        def __iter__(self):
            for chunk in self.chunks:
                yield chunk

    from io import StringIO
    colors = b'\x1b['
    chunks = [
        b'foo',
        colors + b'bar',
        colors + b'baz' + colors,
    ]
    outfile = StringIO()
    write_stream_with_colors_win_py3(
        stream=FakeStream(chunks),
        outfile=outfile,
        flush=False,
    )
    result = outfile.getvalue()
    assert chunks[0].decode() in result
    assert colors.decode() in result

# Generated at 2022-06-23 19:43:00.726467
# Unit test for function write_message
def test_write_message():
    from httpie import ExitStatus
    from httpie.compat import urlopen
    from httpie.output.streams import PrettyStream
    import httpie
    from httpie.context import Environment
    from httpie.output.processing import Conversion
    from httpie.output.streams import PrettyStream
    from httpie.models import HTTPRequest, HTTPResponse
    env = Environment(stdin=None, stdout=None, stderr=None)
    etag = '"686897696a7c876b7e"'
    class Response:
        def __init__(self, status_code, headers, raw):
            self.status_code = status_code
            self.raw = raw
            self.headers = headers
            self.reason = 'OK'

# Generated at 2022-06-23 19:43:11.309446
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    msg = requests.Response()
    msg.status_code = 401
    msg.headers['Content-Type'] = 'html/text'
    msg.request.headers['Content-Type'] = 'html/text'
    msg.text = 'lalalal'
    msg.request.headers['Content-Type'] = 'html/text'
    msg.request.method = 'GET'
    msg.request.url = 'www.baidu.com'
    msg.request.body = 'abc\r\ndef'
    args = argparse.Namespace()
    args.headers = False
    args.body = True
    env = Environment()
    env.is_windows = False
    env.stdout_isatty = True

# Generated at 2022-06-23 19:43:18.577470
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env = Environment(is_windows = False, stdout_isatty = False),
        args = argparse.Namespace(
            prettify = True,
            style = 'parrot',
            stream = True,
            format_options = {},
            json = True,
        )
    )
    assert stream_class == PrettyStream

# Generated at 2022-06-23 19:43:29.611211
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    """
    :return:
    """
    from io import StringIO
    import unittest
    from httpie.output.streams import (
        BaseStream, BufferedPrettyStream, EncodedStream, PrettyStream, RawStream
    )
    from httpie.models import HTTPRequest, HTTPResponse

    class Args:
        def __init__(self):
            self.stream = False
            self.prettify = []
            self.style = 'github'
            self.json = False
            self.format_options = []

        def __repr__(self):
            return '<Args>'

    class Env:
        def __init__(self):
            self.stdout_isatty = True
            self.stdout = StringIO()


# Generated at 2022-06-23 19:43:39.487881
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():

    class FakeEnv():

        def __init__(self):
            self.stdout_isatty = False
            self.is_windows = False
            self.debug = False
            self.traceback = False

    class FakeArgParseNamespace():

        def __init__(self):
            self.stream = False
            self.prettify = []
            self.style = None
            self.json = False
            self.format_options = {}

    from httpie.output.streams import RawStream

    class FakeRequest():
        pass

    class FakeResponse():
        pass

    with_headers = True
    with_body = True

    env = FakeEnv()
    args = FakeArgParseNamespace()

    requests_message = FakeRequest()
    requests_message.headers = {}

    data = build_output_

# Generated at 2022-06-23 19:43:51.431216
# Unit test for function write_stream
def test_write_stream():
    outfile = io.BytesIO()

    # Test with RawStream and chunk_size = 1
    write_stream(
        stream=RawStream(b'ABCDEFG'),
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == b'ABCDEFG'

    # Test with RawStream and chunk_size = 10
    outfile = io.BytesIO()
    write_stream(
        stream=RawStream(b'ABCDEFG', chunk_size=10),
        outfile=outfile,
        flush=False
    )
    assert outfile.getvalue() == b'ABCDEFG'

    # Test with RawStream, chunk_size = 1, and line
    outfile = io.BytesIO()

# Generated at 2022-06-23 19:44:00.147482
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import io
    from httpie.output.streams import PrettyStream

    stream = PrettyStream(
        msg=HTTPResponse({'status_code': 200}),
        with_headers=True,
        with_body=True,
        env={'is_windows': True},
        conversion=Conversion(),
        formatting=Formatting(
            env={'stdout_isatty': True, 'is_windows': True},
            groups=['colors'],
            color_scheme='solarized',
            explicit_json=False,
            format_options=[],
        )
    )
    outfile = io.StringIO()

    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False
    )

    assert outfile.get

# Generated at 2022-06-23 19:44:06.893603
# Unit test for function write_stream_with_colors_win_py3

# Generated at 2022-06-23 19:44:08.692807
# Unit test for function write_message
def test_write_message():
    pass

# Generated at 2022-06-23 19:44:19.245791
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream
    from httpie.models import EnvironmentImpl
    import argparse
    class Namespace:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    env = EnvironmentImpl(stdin_isatty=True, stdout_isatty=True)
    args = Namespace(prettify=(), format_options=None, style=None,
                     stream=False, json=False)

# Generated at 2022-06-23 19:44:29.577410
# Unit test for function write_message
def test_write_message():
    from httpie.context import Environment
    from httpie.models import HTTPRequest, HTTPResponse
    from httpie import ExitStatus
    from httpie.output.streams import RawStream, PrettyStream, BufferedPrettyStream
    from httpie import doc
    env = Environment(stdin=None,
                      stdout=None,
                      stderr=None,
                      verify=True,
                      debug=False,
                      config_dir=os.path.expanduser("~/.httpie/"),
                      default_options=[],
                      auto_auth_password=None,
                      session=None)

    args = doc.parser.parse_args(args=['--prettify',
                                       '-v'])

# Generated at 2022-06-23 19:44:39.282441
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    args = httpie.cli.parser.parse_args(['--print', 'H', 'https://example.org'])
    env = Environment(args)
    response = requests.Response()
    response.status_code = 200
    response.request = requests.Requests()
    response.request.method = 'GET'
    response.request.headers = {b'header': b'value'}
    response.headers = {b'header': b'value'}
    response.raw = b'body'
    write_message(
        requests_message=response,
        env=env,
        args=args,
        with_headers=True,
        with_body=True,
    )


# Generated at 2022-06-23 19:44:47.157217
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import httpie.cli
    args = httpie.cli.parser.parse_args(
        args=[
            '--prettify',
            '--stream',
            '--body-preview',
            '1024',
        ]
    )
    env = Environment()
    response_obj = requests.Response()
    response_obj.status_code = 200
    response_obj.headers = {
        'Connection': 'Keep-Alive',
        'Cache-Control': 'private, max-age=100',
        'Content-Length': '14',
        'Content-Type': 'text/html; charset=ISO-8859-4',
    }
    response_obj.encoding = 'utf-8'

# Generated at 2022-06-23 19:44:56.818420
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.cli import parser
    from httpie.context import Environment
    from os import environ
    from pprint import pformat
    from requests.models import PreparedRequest
    import sys

    env = Environment(
        stdin=sys.stdin,
        stdin_isatty=False,
        stdout=sys.stdout,
        stdout_isatty=False,
        stderr=sys.stderr,
        stderr_isatty=False,
        colors=256,
        style='paraiso-dark',
        default_options={},
        vars={'HTTPIE_CONFIG_DIR': '.httpie'},
    )


# Generated at 2022-06-23 19:45:07.670995
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    env = Environment()
    args = argparse.Namespace(stream=True, prettify=['b'])
    requests_message = requests.Response()
    requests_message.body = 'Hello'
    requests_message.headers['content-type'] = 'application/json'
    requests_message.headers['content-length'] = '5'
    requests_message.headers['server'] = 'AWS'
    assert list(build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_body=True,
        with_headers=False
    )) == [b'Hello', MESSAGE_SEPARATOR_BYTES]

# Generated at 2022-06-23 19:45:09.294908
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    if __name__ == '__main__':
        test_build_output_stream_for_message()

# Generated at 2022-06-23 19:45:19.119916
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from click.testing import CliRunner
    from httpie.cli.request_items import parse_items
    from httpie.cli.parser import parser
    from httpie import __version__
    from httpie.output.streams import PrettyStream, BufferedPrettyStream, EncodedStream, RawStream

    env = Environment(
        stdout_isatty=True,
        is_windows=False,
    )
    args, _ = parser.parse_known_args(['-v'])
    args, items = parse_items(args=args)
    args.stream = False
    args.verbose = True
    args.prettify = ['colors']
    args.style = ''
    args.format_options = {}
    r = requests.Response()

# Generated at 2022-06-23 19:45:29.245251
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    content = b'{"a": "\x1b[31mred"}\x1b[0m'
    expected = '{"a": "\x1b[31mred"}'

    class MockFile:
        def __init__(self, name):
            self.name = name
        def write(self, data):
            self.data = data
        def flush(self):
            pass

    mock_file = MockFile('mock file')

    write_stream_with_colors_win_py3(
        stream=content,
        outfile=mock_file,
        flush=False
    )

    assert mock_file.data == expected

# Generated at 2022-06-23 19:45:38.947403
# Unit test for function write_message
def test_write_message():
    import io
    r = requests.Response
    r.headers = {'Content-Type': 'application/json'}
    r.encoding = 'UTF-8'
    r.content = b'{"name": "John"}'
    response = r()
    request = requests.PreparedRequest()
    request.headers = {'Content-Type': 'application/json'}
    request.encoding = 'UTF-8'
    request.body = b'{"name": "John"}'
    s = io.StringIO()
    write_message(request, s, with_body=True)
    s = io.StringIO()
    write_message(response, s, with_body=True)

# Generated at 2022-06-23 19:45:46.235335
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import BytesIO
    from io import StringIO
    import platform

    from httpie.output.streams import BaseStream, PrettyStream

    class TestStream(BaseStream):

        def __init__(self, test_stream, with_headers=True, with_body=True):
            super(TestStream, self).__init__(with_headers=with_headers,
                                             with_body=with_body)
            self._test_stream = test_stream
            self._is_headers_done = False
            self._is_body_done = False

        def __iter__(self):
            return self

        def __next__(self):

            if not self._is_headers_done and self.with_headers:
                self._is_headers_done = True

# Generated at 2022-06-23 19:45:49.837185
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    from httpie.output.streams import BufferedPrettyStream
    from httpie.core import main
    from httpie.context import Environment
    import io
    import sys
    output_stream = build_output_stream_for_message(
        args=main.parse_args(['localhost']),
        env=Environment(),
        requests_message=requests.Response(),
        with_headers=True,
        with_body=True,
    )
    assert isinstance(output_stream, BufferedPrettyStream)


# Generated at 2022-06-23 19:45:59.539229
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    args = argparse.Namespace()
    args.prettify = None
    args.stream = False
    args.style = None
    args.json = False
    args.format_options = None

    assert get_stream_type_and_kwargs(env, args) == (EncodedStream, {'env': env})

    args.prettify = 'h'
    assert get_stream_type_and_kwargs(env, args) == (BufferedPrettyStream, {
            'env': env,
            'conversion': Conversion(),
            'formatting': Formatting(
                env=env,
                groups='h',
                color_scheme=None,
                explicit_json=False,
                format_options=None,
            )
        })

# Generated at 2022-06-23 19:46:01.011712
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    env = Environment()
    args = argparse.Namespace()

# Generated at 2022-06-23 19:46:10.460917
# Unit test for function get_stream_type_and_kwargs

# Generated at 2022-06-23 19:46:20.812610
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    import requests
    env = Environment()
    args = argparse.Namespace()

    # test case1: with_headers=False, with_body=False
    requests_message = requests.Response()
    with_headers = False
    with_body = False
    lines = [line for line in build_output_stream_for_message(
        args=args,
        env=env,
        requests_message=requests_message,
        with_headers=with_headers,
        with_body=with_body,
    )]
    assert 0 == len(lines)

    # test case2: with_headers=True, with_body=False
    requests_message = requests.Response()
    with_headers = True
    with_body = False

# Generated at 2022-06-23 19:46:25.471007
# Unit test for function write_stream
def test_write_stream():
    from . import output
    from .output.tests.test_util import test_output_factory
    from .test.utils import (
        DummyIO, DummyWindowsIO, DummyPy3WindowsIO, DummyPy3NonWindowsIO
    )
    from .test.utils import mock, MockRequest, MockResponse
    from .test.utils import pytest_generate_tests
    from .test.utils import Py3WindowsIO, Py3NonWindowsIO

    # Unit test for function get_stream_type_and_kwargs
    def test_get_stream_type_and_kwargs(args, env, stream_class, stream_kwargs):
        assert get_stream_type_and_kwargs(
            env=env,
            args=args,
        ) == (stream_class, stream_kwargs)


# Generated at 2022-06-23 19:46:36.318560
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    """Unit test for function write_stream_with_colors_win_py3"""
    import io
    from httpie.cli.output.streams import (BaseStream, ColorizedBytesStream)
    from httpie.cli.output import Colors

    class MockStream(BaseStream):
        """MockStream"""

# Generated at 2022-06-23 19:46:45.853397
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    output = io.StringIO()
    output.isatty = lambda: True
    output.encoding = 'utf-8'
    output.write = lambda s: s
    args = argparse.Namespace()
    args.prettify = 'colors'
    env = Environment(
            stdout=output,
            stdout_isatty=True,
            is_windows=True,
            colors=256,
            stdin=sys.__stdin__,
            stdin_isatty=True,
            is_terminal=True
        )

# Generated at 2022-06-23 19:46:55.793062
# Unit test for function write_message
def test_write_message():
    # Arrange
    args = argparse.Namespace(
        stream=False,
        prettify=None
    )

    class EnvironmentMock(Environment):
        def __init__(self):
            self.is_windows = False
            self.stdout = 'stdout'
            self.stdout_isatty = True
            self.stderr = ''
            self.stdin = 'stdin'


    env = EnvironmentMock()

    import http.client
    conn = http.client.HTTPConnection("google.com")
    conn.request("GET", "/")
    res = conn.getresponse()
    requests_response = res.msg
    requests_message = requests_response

    # Act

# Generated at 2022-06-23 19:47:04.739619
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment(
            colors=256,
            stdin_isatty=False,
            stdout_isatty=True,
            stdout_raw=False,
            output_encoding='ascii',
            is_windows=False,
            is_mac=(platform.system() == 'Darwin'),
            is_linux=(platform.system() == 'Linux'),
            stdout_is_redirected=False,
        )

# Generated at 2022-06-23 19:47:10.024763
# Unit test for function write_stream
def test_write_stream():
    import io
    outfile = "test_outfile.txt"
    stream_raw = [b'test1', b'test2']
    exp_res = b"test1test2"
    def f_test_write_stream(stream, outfile, flush):
        with io.open(outfile, "wb") as out:
            write_stream(stream, out, flush)
    f_test_write_stream(stream_raw, outfile, False)
    with open(outfile, "rb") as out:
        res = out.read()
    assert(res == exp_res)

# Generated at 2022-06-23 19:47:16.457978
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = Environment()
    env.stdout = 'stdout'
    env.stdout_isatty = 'isatty'
    args = argparse.Namespace()
    args.stream = 'stream'
    args.prettify = 'prettify'
    args.format_options = 'format_options'

    stream_class, stream_kwargs = get_stream_type_and_kwargs(
        env=env,
        args=args,
    )
    assert stream_class == PrettyStream

# Generated at 2022-06-23 19:47:23.347144
# Unit test for function write_message
def test_write_message():
    url = 'http://www.baidu.com'
    r = requests.get(url)
    args = argparse.Namespace(format='json', style='solarized')
    env = Environment()
    with open('message.json', 'w') as f:
        env.stdout = f
        write_message(r, env, args)

if __name__ == '__main__':
    test_write_message()

# Generated at 2022-06-23 19:47:25.219928
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    assert get_stream_type_and_kwargs(
        'env', 'args'
    ) == (
        EncodedStream, {
            'env': 'env'
        }
    )

test_get_stream_type_and_kwargs()

# Generated at 2022-06-23 19:47:30.269755
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import sys
    import colorama
    env: Environment = Environment()
    # Set colorama.init() and colorama.deinit() so that it doesn't crash
    # (colorama doesn't set anything, so it is up to us to init and deinit)
    colorama.init()
    stream = [b'\x1b[31mred', b'\x1b[0mno-color']
    class FakeStream:
        def __init__(self):
            self.items = []
        def write(self, s):
            self.items.append(s)
        def flush(self):
            pass
    fake_sysstdout = FakeStream()
    old_sysstdout = sys.stdout
    sys.stdout = fake_sysstdout

# Generated at 2022-06-23 19:47:40.500854
# Unit test for function write_message
def test_write_message():
    class MockEnvironment:
        stdout = 'teststdout'
        stdout_isatty = False

    class MockArgParser:
        def __init__(self):
            self.prettify = [
                'all',
            ]
            self.style = 'all'
            self.debug = False
            self.traceback = False
            self.json = False
            self.format_options = {}
            self.stream = False

    test_args = MockArgParser()
    test_env = MockEnvironment()

    class MockRequest:
        pass

    test_request = MockRequest()

    # Unit test case 1: with body
    test_request.headers = MockRequest()
    test_request.url = 'http://localhost'
    test_request.method = 'GET'

# Generated at 2022-06-23 19:47:49.621017
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from unittest.mock import MagicMock
    from io import StringIO
    import sys
    env = MagicMock()
    env.is_windows = True
    outfile = StringIO()
    args = MagicMock()
    args.prettify = ['colors']

    outfile.write = MagicMock()
    outfile.buffer = MagicMock()

    outfile.encoding = sys.getdefaultencoding()

    color = b'\x1b['
    stream = MagicMock()
    stream.__iter__ = MagicMock(return_value=['text', color + b'1m' + 'color', 'text2'])
    write_stream_with_colors_win_py3(stream, outfile, True)

    assert outfile.buffer.write.call_count == 1
   

# Generated at 2022-06-23 19:47:59.678940
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    class Args:
        def __init__(self, prettify, stream, debug, traceback):
            self.prettify = prettify
            self.stream = stream
            self.debug = debug
            self.traceback = traceback

    class Env:
        def __init__(self, stdout, stdout_isatty):
            self.stdout = stdout
            self.stdout_isatty = stdout_isatty
            self.is_windows = False

    class RequestsMessage:
        def __init__(self, is_body_upload_chunk):
            self.is_body_upload_chunk = is_body_upload_chunk

    class RequestsPreparedRequest(RequestsMessage):
        pass

    class RequestsResponse(RequestsMessage):
        pass


# Generated at 2022-06-23 19:48:09.847932
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from tests.data import StreamMock, FileMock
    stream = StreamMock(chunks=[
        b'\x1b[30mchunk 1',
        b'\x1b[40mchunk 2',
        b'\x1b[40mchunk 3',
        b'chunk 4\x1b[00m',
        b'chunk 5',
        b'chunk 6'
    ])
    file = FileMock()
    env = Environment(stdout=file, stderr=file)
    args = argparse.Namespace(prettify=['colors'])
    write_stream_with_colors_win_py3(
        stream=stream, outfile=file, flush=False
    )

# Generated at 2022-06-23 19:48:16.844378
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    # Normal case with prettify
    args = argparse.Namespace()
    args.prettify = ["all"]
    args.json = False
    env = Environment()
    env.stdout_isatty = True
    args.stream = True
    args.style = None
    stream_class, stream_kwargs =get_stream_type_and_kwargs(env, args)
    assert stream_class == PrettyStream
    assert "env" in stream_kwargs
    assert stream_kwargs["env"] == env

    # Normal case with prettify and json
    args = argparse.Namespace()
    args.prettify = ["all"]
    args.json = True
    env = Environment()
    env.stdout_isatty = True
    args.stream = True
    args.style = None
    stream_

# Generated at 2022-06-23 19:48:25.345056
# Unit test for function write_message
def test_write_message():
    class args:
        def __init__(self):
            self.debug = False
            self.traceback = False
            self.stream = False
            self.prettify = ('all',)
            self.style = None
            self.json = False
            self.format_options = {}

    class env:
        def __init__(self):
            self.stdout = None
            self.stdout_isatty = False
            self.is_windows = False
            self.debug = False

    args = args()
    env = env()
    env.stdout = io.StringIO()

    class req:
        def __init__(self):
            self.headers = {}
            self.body = None

    class res:
        def __init__(self):
            self.headers = {}
            self.status_

# Generated at 2022-06-23 19:48:31.512440
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.core import main
    from .tools import no_style

    args = main.parser.parse_args(args=['--json'])
    env = Environment(stdout_isatty=True, colors=256,
                      style=no_style(), stdout=None, colors_mode='256')
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_type == PrettyStream

# Generated at 2022-06-23 19:48:41.660372
# Unit test for function write_message
def test_write_message():
    import httpie
    import requests

    client_obj = httpie.cli.api.Client()
    args = client_obj.get_default_args()
    env = httpie.get_default_env()
    with_headers = True
    with_body = True

    test_message_1 = requests.PreparedRequest()
    test_message_1.method = 'GET'
    test_message_1.url = 'http://127.0.0.1:5000/'
    test_message_1.headers = {'user-agent': 'curl/7.63.0', 'accept-encoding': 'gzip, deflate', 'accept': '*/*', 'connection': 'keep-alive'}

    write_message(test_message_1, env, args, with_headers, with_body)

# Generated at 2022-06-23 19:48:47.810998
# Unit test for function write_message
def test_write_message():
    env = Environment('/')
    args = argparse.Namespace()
    with_headers = False
    with_body = False
    request_message = requests.Request('GET', 'http://httpbin.org/json')
    response_prep = requests.Session().prepare_request(request_message)
    response_message = requests.get(request_message.url, stream=with_body)
    write_message(response_prep, env, args, with_headers, with_body)
    write_message(response_message, env, args, with_headers, with_body)
    with_headers = True
    with_body = True
    write_message(response_prep, env, args, with_headers, with_body)
    write_message(response_message, env, args, with_headers, with_body)


#

# Generated at 2022-06-23 19:48:57.413410
# Unit test for function write_message
def test_write_message():
    requests_message = requests.PreparedRequest()
    requests_message.url = 'test_url'
    env = Environment(True)
    args = argparse.Namespace()
    args.headers = None
    args.json = False
    args.style = None
    args.stream = False
    args.prettify = ['all']
    args.traceback = False
    args.debug = False
    args.download = False
    args.output = None
    args.form = None
    args.files = None
    message = requests_message.prepare()
    message.headers['Host'] = 'test_url'

    get_stream_type_and_kwargs(env, args)

# Generated at 2022-06-23 19:49:07.214047
# Unit test for function write_message
def test_write_message():
    if '__file__' in globals():
        # Needed to make the test discoverable by py.test
        import os
        __file__ = os.path.relpath(__file__)
    import pytest
    try:
        from httprunner import HttpRunner
    except ImportError:
        pytest.skip('fail to install httprunner')

    runner = HttpRunner()

# Generated at 2022-06-23 19:49:12.853873
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    """Test get_stream_type_and_kwargs function"""
    import argparse
    env = Environment()
    args = argparse.Namespace()
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert(stream_type == RawStream)
    assert(stream_kwargs['chunk_size'] == RawStream.CHUNK_SIZE_BY_LINE)

    args.prettify = True
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert(stream_type == BufferedPrettyStream)

    args.stream = True
    stream_type, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert(stream_type == PrettyStream)


# Generated at 2022-06-23 19:49:20.724534
# Unit test for function write_stream
def test_write_stream():
    # Here we are using mock and patch to test the write_stream function

    # mock.patch is used to mock the objects imported in the function
    # patch is used to replace the object being imported with a mock object
    # side_effect can be used to raise exceptions and perform operations on the
    # mock object
    # we patch an object to return a mock object that is for the buffer we patch
    # the buffer to return a string

    with mock.patch('httpie.output.streams.outfile',
                    new_callable=mock.PropertyMock) as mock_outfile, \
            mock.patch('httpie.output.streams.buf',
                       new_callable=mock.PropertyMock) as mock_buf:
        mock_outfile.return_value = '1'
        mock_buf.return_value = '2'

# Generated at 2022-06-23 19:49:27.937113
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    from io import StringIO
    from unittest.mock import Mock

    stream = Mock()
    color = '\x1b['
    text = 'some text'
    text_colored = color + 'some text'
    stream.__iter__.return_value = (text_colored, text)
    outfile = StringIO()

    write_stream_with_colors_win_py3(
        stream=stream,
        outfile=outfile,
        flush=False,
    )
    assert outfile.getvalue() == text_colored + text

# Generated at 2022-06-23 19:49:37.545353
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    print("hello")
    env = Environment.from_env()
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--prettify', action='store_true')
    args = argparse.Namespace(prettify=True)
    #args = parser.parse_args(["--prettify"])
    pr = requests.PreparedRequest()
    pr.body = "hello"
    pr.headers = {'abc': 'abc', 'def':'def'}
    pr.method = 'GET'
    pr.url = 'http://www.google.com'

# Generated at 2022-06-23 19:49:48.558484
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    from httpie.downloads import is_debug
    from io import BytesIO
    args = argparse.Namespace()
    env = Environment()
    env.stdout_isatty = True
    args.prettify = ['headers']
    args.stream = True
    stream_class, stream_kwargs = get_stream_type_and_kwargs(env, args)
    assert stream_class is PrettyStream
    output = BytesIO()
    response = requests.Response()
    response.request = requests.PreparedRequest()
    response.status_code = 200
    response._content = b'{"key":"value"}'
    request = HTTPResponse(response)

# Generated at 2022-06-23 19:49:49.278190
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    pass

# Generated at 2022-06-23 19:49:56.143096
# Unit test for function write_stream_with_colors_win_py3
def test_write_stream_with_colors_win_py3():
    import pytest
    from io import StringIO
    from contextlib import redirect_stdout
    from httpie import ExitStatus
    from httpie.context import Environment
    from httpie.output.streams import BaseStream, PrettyStream

    class ColorfulPrettyStream(PrettyStream):

        def __init__(self):
            super().__init__(
                env=Environment(),
            )
            self.headers_color = '\033[33m'
            self.status_color = '\033[32m'
            self.body_color = '\033[36m'

        def _write_headers(self, headers, outfile):
            outfile.write(self.headers_color)

# Generated at 2022-06-23 19:50:01.780377
# Unit test for function write_stream
def test_write_stream():
    env = Environment()
    args = argparse.Namespace()

    class outfile(object):
        def __init__(self):
            self.output = io.StringIO()
        def write(self, chunk):
            self.output.write(chunk)
        def getvalue(self):
            return self.output.getvalue()

    write_stream(
        stream = 'hello world',
        outfile = outfile(),
        flush = False,
    )

    assert outfile.getvalue() == "hello world"

# Generated at 2022-06-23 19:50:11.355278
# Unit test for function get_stream_type_and_kwargs
def test_get_stream_type_and_kwargs():
    env = None
    args1 = argparse.Namespace(prettify=None, stream=False, style=None, json=None, format_options=None)
    expected1 = (EncodedStream, {'env': env})
    args2 = argparse.Namespace(prettify=[], stream=False, style=None, json=None, format_options=None)
    expected2 = (BufferedPrettyStream, {'env': env, 'conversion': Conversion(), 'formatting': Formatting(env=env, groups=[], color_scheme=None, explicit_json=None, format_options=None)})
    args3 = argparse.Namespace(prettify=['url', 'headers'], stream=False, style=None, json=None, format_options=None)

# Generated at 2022-06-23 19:50:21.343397
# Unit test for function build_output_stream_for_message
def test_build_output_stream_for_message():
    result = []
    requests_message = 'test'
    env = Environment(
        stdout_isatty=False,
        stdin_isatty=False,
        stdin=None,
        stdin_raw=False,
        stdout=None,
        stderr=None,
        color=None,
        colors=None,
        styles=None,
        default_options=None,
        default_options_overrides=None)