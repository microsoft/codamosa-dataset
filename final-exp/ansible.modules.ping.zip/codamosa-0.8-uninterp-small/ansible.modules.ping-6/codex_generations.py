

# Generated at 2022-06-25 02:56:08.932009
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    var_1 = 'crash'
    if var_0.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=var_0.params['data'],
    )
    var_0.exit_json(**result)
    return var_0

    


# Generated at 2022-06-25 02:56:12.664268
# Unit test for function main
def test_main():
    ans_test = AnsibleModule(argument_spec={})
    ans_test.enter_json_mode()
    ans_test.exit_json(changed=True, foo='bar')
    main()


# Generated at 2022-06-25 02:56:17.738382
# Unit test for function main
def test_main():
    mock_module = mock.MagicMock()
    mock_module.params = {'data': 'pong'}
    mock_module.exit_json.return_value = True
    test_case_0()



# Generated at 2022-06-25 02:56:20.375205
# Unit test for function main
def test_main():
    assert main() == (None)


# Generated at 2022-06-25 02:56:21.636838
# Unit test for function main
def test_main():
  val = main()
  assert val == None, "Main doesn't return anything."

# Generated at 2022-06-25 02:56:25.089695
# Unit test for function main
def test_main():
    class_var = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    class_var.params['data'] == 'crash'
    class_var.params['data'] = 'pong'


# Generated at 2022-06-25 02:56:25.614817
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-25 02:56:26.009947
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:56:27.729747
# Unit test for function main
def test_main():
	# Setup
	var_0 = dict(data='pong')
	module = AnsibleModule(var_0, supports_check_mode=True)

	# Run
	main()


# Generated at 2022-06-25 02:56:28.279239
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:56:43.120213
# Unit test for function main
def test_main():
    # Testing if data is pong
    test_data.params["data"] = "pong"
    var_1 = test_data.params
    var_2 = var_1["data"]
    assert var_2 == "pong"
    #Testing if data is not crash
    test_data.params["data"] = "crash"
    var_3 = test_data.params
    var_4 = var_3["data"]
    assert var_4 != "pong"
    # Testing supports_check_mode
    test_data.supports_check_mode = True
    var_5 = test_data.supports_check_mode
    assert var_5 == True
    # Testing if test_data.args are equal to test_data.params
    test_data.params["data"] = "crash"
    var_

# Generated at 2022-06-25 02:56:47.787681
# Unit test for function main
def test_main():
    var_2 = get_param({ 'get_attr' : 'var_1' } , { 'boot' : 'less' }, var_1 = 'var_2')
    if 'var_3' in locals():
        var_3 = 1
    var_4 = main(var_2)
    return var_4


# --- test_case_0 ---


# Generated at 2022-06-25 02:56:57.704528
# Unit test for function main
def test_main():
    import sys
    import StringIO

    ############################################################
    #
    # queue from ansible
    #
    ############################################################
    queue = [
    #{
    #  "changed": false,
    #  "ping": "pong"
    #}
    ]

    ############################################################
    #
    # mock command line from ansible
    #
    ############################################################
    sys.argv = ['ansible', 'localhost', '-c', 'local', '-m', 'ansible.builtin.ping']

    ############################################################
    #
    # override stdout and capture
    #
    ############################################################
    output = StringIO.StringIO()
    sys.stdout = output

    ############################################################
    #
    # call main
    #


# Generated at 2022-06-25 02:57:05.529009
# Unit test for function main
def test_main():
    json_val = DataObject()
    json_val.set_value('pong')
    ansible_mod = AnsibleModule(json_val)
    assert ansible_mod.argument_spec.get('type') is None
    assert ansible_mod.params.get('type') is None
    #assert ansible_mod.params.get('type') == 'pong'
    assert main() == 'pong'


# Generated at 2022-06-25 02:57:10.775835
# Unit test for function main
def test_main():
    var_0 = {'data': 'pong'}
    var_1 = type(main) == 'types.FunctionType'
    assert var_1
    var_2 = main(var_0) == 0
    assert var_2

# Generated at 2022-06-25 02:57:12.338918
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == {'ping': 'pong'}


# Generated at 2022-06-25 02:57:19.967105
# Unit test for function main
def test_main():

    # Create the 'return_value' mock object
    # Create the 'AnsibleModule' mock object
    ansible_module_instance = mock.create_autospec(AnsibleModule)
    # Return the mock object
    return_value = ansible_module_instance

    # Set the return value of the mock object to the AnsibleModule instance
    setattr(AnsibleModule, 'return_value', return_value)
    # Return a mock object
    return ansible_module_instance



# Generated at 2022-06-25 02:57:21.724862
# Unit test for function main
def test_main():
    # var_0 = 'pong'
    # main()
    main()

# Generated at 2022-06-25 02:57:23.365670
# Unit test for function main
def test_main():
    assert callable(main)



# Generated at 2022-06-25 02:57:27.282630
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None


# Generated at 2022-06-25 02:57:35.719895
# Unit test for function main
def test_main():
    assert isinstance(main(), dict)



# Generated at 2022-06-25 02:57:39.807691
# Unit test for function main
def test_main():
    main()

test_main()

# Generated at 2022-06-25 02:57:41.936375
# Unit test for function main
def test_main():

    test_case_0()

test_main()

# Generated at 2022-06-25 02:57:44.222886
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == True


# Generated at 2022-06-25 02:57:47.233534
# Unit test for function main
def test_main():
    try:
        print(main())
    except Exception as e:
        print(e)

if __name__ == '__name__':
    test_main()

# Generated at 2022-06-25 02:57:53.722749
# Unit test for function main

# Generated at 2022-06-25 02:57:56.237647
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:57:56.686799
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:57:59.297431
# Unit test for function main
def test_main():
    if sys.version_info < (3,):
        stdout, stderr = capture_stdout_stderr()
        assert stdout == ''
        assert stderr == ''
    else:
        assert stdout == b''
        assert stderr == b''
    assert var_0 == None



# Generated at 2022-06-25 02:57:59.807109
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:58:20.252227
# Unit test for function main
def test_main():
    from test_cases.test_case_0 import var_0

    # var_0 is a generator, thus having a "next" call
    # If it fails, an Exception is raised
    message = next(var_0)
    assert message == ("test")

# Generated at 2022-06-25 02:58:29.813464
# Unit test for function main
def test_main():
    assert 1 == 1, 'Failed assert 1 == 1'
    assert 6 == 6, 'Failed assert 6 == 6'
    assert 6 == 6, 'Failed assert 6 == 6'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'
    assert 0 == 0, 'Failed assert 0 == 0'

# Generated at 2022-06-25 02:58:31.655611
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except SystemExit as e:
        assert(e.code == 0)


# Generated at 2022-06-25 02:58:32.814699
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None


# Generated at 2022-06-25 02:58:33.922249
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-25 02:58:37.562525
# Unit test for function main
def test_main():
    var_0 = main()
    assert type(var_0) == tuple
    assert var_0[0] == {}
    assert type(var_0[1]) == str
    assert len(var_0[1]) > 0
    assert type(var_0[2]) == str
    assert len(var_0[2]) > 0


# Generated at 2022-06-25 02:58:38.736055
# Unit test for function main
def test_main():
    input_0 = "crash"
    assert main("pong") == None;

# Generated at 2022-06-25 02:58:39.552486
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-25 02:58:41.937659
# Unit test for function main
def test_main():
    var_0 = "pong"
    var_1 = "crash"
    assert var_0 == "pong"
    assert var_1 != "crash"

# Generated at 2022-06-25 02:58:42.797416
# Unit test for function main
def test_main():
    assert(test_case_0())

# Generated at 2022-06-25 02:59:21.488259
# Unit test for function main
def test_main():
    var_1 = "pong"
    var_2 = main()
    var_3 = var_2.get(var_1)

    assert var_3 == "pong"

# Generated at 2022-06-25 02:59:23.993723
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == var_0, 'Value returned did not match expected'

# Generated at 2022-06-25 02:59:24.771342
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:59:29.525535
# Unit test for function main
def test_main():
    # Create the mock object
    ## mock_get_module_args = MagicMock(return_value={'data': 'crash'})
    ## mock_AnsibleModule = MagicMock(return_value=AnsibleModule)

    ## main(mock_AnsibleModule, mock_get_module_args)
    assert var_0 is not None

# Generated at 2022-06-25 02:59:32.974554
# Unit test for function main
def test_main():
    import unittest

    class mainTestCase(unittest.TestCase):
        def test_default(self):
            result = main()
            self.assertEqual(result, {'ping': 'pong'})

    unittest.main()

# Generated at 2022-06-25 02:59:34.373780
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:59:37.762100
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    #print module.params['data']
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )
    #print result, type(result)
    module.exit_json(**result)


# Generated at 2022-06-25 02:59:44.512141
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if var_1.params['data'] == 'crash':
        raise Exception("boom")

    var_2 = dict(
        ping=var_1.params['data'],
    )

    var_1.exit_json(**var_2)


# Generated at 2022-06-25 02:59:45.362042
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:59:46.182885
# Unit test for function main
def test_main():
    assert main() == None



# Generated at 2022-06-25 03:01:14.362009
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-25 03:01:19.173493
# Unit test for function main
def test_main():
    var_0 = AnsibleModule( argument_spec={ "data": { "type": "str", "default": "pong" } }, supports_check_mode=True )
    if var_0.params['data'] == 'crash':
        raise Exception("boom")
    var_1 = dict( ping=var_0.params['data'] )
    var_0.exit_json( **var_1 )


if __name__ == '__main__':
    print(main())

# Generated at 2022-06-25 03:01:20.624330
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == (dict(ping='pong'), )

# Generated at 2022-06-25 03:01:23.517985
# Unit test for function main
def test_main():
    var_1 = AnsibleModule.argument_spec
    var_2 = AnsibleModule.ansible_version
    var_3 = AnsibleModule.check_mode
    var_4 = AnsibleModule.no_log


# Generated at 2022-06-25 03:01:26.009571
# Unit test for function main
def test_main():
    result = main()
    print("Result: " + str(result))
    assert result == "pong"

test_main()

# Generated at 2022-06-25 03:01:27.152388
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None


# Generated at 2022-06-25 03:01:28.278662
# Unit test for function main
def test_main():
    print("Testing function main")
    test_case_0()

# Generated at 2022-06-25 03:01:29.070652
# Unit test for function main
def test_main():
    # No params
    assert main()


# Generated at 2022-06-25 03:01:30.363930
# Unit test for function main
def test_main():
  var_0 = main()
  assert type(var_0) == None
  return var_0

# Generated at 2022-06-25 03:01:32.887976
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 03:04:31.167454
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            pass
        else:
            raise
    except Exception as inst:
        print(inst)

test_main()

# Generated at 2022-06-25 03:04:32.450898
# Unit test for function main
def test_main():
    assert type(var_0) == dict
    assert var_0 == dict(ping='pong')

# Generated at 2022-06-25 03:04:33.699729
# Unit test for function main
def test_main():

    # Stub
    var_0 = None

    # Assertion
    assert var_0 is None

# Generated at 2022-06-25 03:04:34.430475
# Unit test for function main
def test_main():
    assert var_0 == None

# Generated at 2022-06-25 03:04:37.157730
# Unit test for function main
def test_main():
    data = 'data'
    var_0 = 'crash'
    try:
        data == var_0
        assert False
    except Exception as exc:
        print(exc)
        assert True

__all__ = [
    "test_case_0",
    "test_main"
]

# Generated at 2022-06-25 03:04:45.650585
# Unit test for function main
def test_main():

    # Mock call to main
    #mock_main = mocker.patch.object(mocker.modules.builtin.ping, 'main')
    mock_main = mocker.patch.object(mocker.modules['ansible.builtin.ping'], 'main')

    # Example of setting expected side effects
    mock_main.side_effect = Exception("boom")

    # Example of setting a return value
    mock_main.return_value = "bar"

    assert mock_main() == "bar"

# Generated at 2022-06-25 03:04:46.560073
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:04:48.516755
# Unit test for function main
def test_main():
    pass
    #  try:
    #      _main()
    #  except:
    #      pass
# EOF

# Generated at 2022-06-25 03:04:50.000787
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as err:
        #print err
        assert False, "undexpected error"
    else:
        assert True, "ping"

# Generated at 2022-06-25 03:04:54.733128
# Unit test for function main
def test_main():
    assert main() == "echo '__main__'"
    assert main() == "echo '__main__'"
    assert main() is None
    assert main() == "echo '__main__'"
    assert main() == "echo '__main__'"
    assert main() == "echo '__main__'"
    assert main() == "echo '__main__'"
    assert main() is None