

# Generated at 2022-06-25 02:56:05.964739
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert(False)



# Generated at 2022-06-25 02:56:08.346523
# Unit test for function main
def test_main():
    var_0 = PingModule()
    var_1 = main()
    var_0.exit_json(var_1)
    var_0.fail_json(var_1)
    var_0.exit_json(msg="STH")
    var_0.fail_json(msg="STH")


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:56:13.416790
# Unit test for function main
def test_main():
    var_0 = {'ansible_check_mode': False, 'changed': False, 'invocation': {'module_args': {'data': 'pong'}, 'module_name': 'ansible.builtin.ping'}, 'ping': 'pong'}

    assert var_0 == main()

# Generated at 2022-06-25 02:56:16.741870
# Unit test for function main
def test_main():
    # Source: ../../ansible/lib/ansible/builtin/ping.py:29
    assert True

# Generated at 2022-06-25 02:56:21.012979
# Unit test for function main
def test_main():
    # main()
    assert True

test_main()


# End of tests
# Output:
# hello
# pong
# hello
# pong

# Generated at 2022-06-25 02:56:22.952228
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == "hello"

# Generated at 2022-06-25 02:56:24.491185
# Unit test for function main
def test_main():
    # Call function
    var_0 = main()

    # Check return value
    assert var_0 == None



# Generated at 2022-06-25 02:56:33.723994
# Unit test for function main
def test_main():
    assert ('AnsibleModule(argument_spec=dict(data=dict(default=pong, type=str)), supports_check_mode=True)' == main.__defaults__[0]['argument_spec']['data']['type'])
    assert ('pong' == main.__defaults__[0]['argument_spec']['data']['default'])
    assert (('AnsibleModule(argument_spec=dict(data=dict(default=pong, type=str)), supports_check_mode=True)' == main.__defaults__[0]['argument_spec']['data']['type']) and ('pong' == main.__defaults__[0]['argument_spec']['data']['default']))

# Generated at 2022-06-25 02:56:34.532818
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:56:36.511961
# Unit test for function main
def test_main():
    assert main() == [{'ping': 'pong'}]

# Generated at 2022-06-25 02:56:42.244702
# Unit test for function main
def test_main():
    # Assuming that the module ping.py has a function main
    if main != None:
        # Calling main
        var_0 = main()


# Generated at 2022-06-25 02:56:43.003088
# Unit test for function main
def test_main():
    assert True == True, "Test Case Failed"

# Generated at 2022-06-25 02:56:46.063666
# Unit test for function main
def test_main():
    # Unit test for function main
    var_1 = ansible_module_ping(data=None)
    with pytest.raises(Exception) as e_1:
        assert var_1 == 'pong'

# Generated at 2022-06-25 02:56:47.248392
# Unit test for function main
def test_main():
    raise Exception("No test for function main")

# Generated at 2022-06-25 02:56:48.363012
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass


# Generated at 2022-06-25 02:56:49.945425
# Unit test for function main
def test_main():
    assert_0 = main()


# Generated at 2022-06-25 02:56:54.449361
# Unit test for function main
def test_main():
    # Test with an exception of type Exception
    # Induce an exception to see what happens
    # ansible.builtin.ping:
    #  data: crash
    assert main() == None


# Generated at 2022-06-25 02:56:59.100896
# Unit test for function main
def test_main():
    # Output is a Python dictionary
    var_0 = main()
    assert var_0 is None or isinstance(var_0, dict)

if __name__ == "__main__" :
    test_main()

# Generated at 2022-06-25 02:57:01.302848
# Unit test for function main
def test_main():
    assert var_0 == 0

# Generated at 2022-06-25 02:57:06.546207
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-25 02:57:24.925798
# Unit test for function main
def test_main():
    var_0 = {'data': 'pong'}
    var_1 = {'changed': False}
    var_2 = {}
    var_2['ping'] = 'pong'
    var_1['ansible_facts'] = var_2
    var_3 = {'ansible_facts': {'ping': 'pong'}, 'changed': False}
    var_4 = {'data': 'pong'}
    var_5 = main(var_4)
    assert var_5 == var_3
    var_6 = {'data': 'crash'}
    var_7 = main(var_6)
    var_8 = var_7
    var_9 = {'ansible_facts': {'ping': 'pong'}, 'changed': False}
    assert var_8 == var_9

# Generated at 2022-06-25 02:57:31.902966
# Unit test for function main
def test_main():
    var_0 = {'ansible_module': 'ansible.builtin.ping', 'data': 'crash', 'data.base_path': None, 'data.name': 'ping', 'data.namespace': 'ansible.builtin', 'data.original_basename': 'ansible.builtin.ping', 'data.path': None, 'data.plugin_type': 'module', 'data.version': None, 'invocation': {'module_args': {'data': 'crash'}}, 'module_name': 'ansible.builtin.ping', 'playbook_dir': '', 'playbook_file': ''}
    var_1 = False
    var_2 = False

# Generated at 2022-06-25 02:57:34.410163
# Unit test for function main
def test_main():
    var_0 = var_0_test_case_0 = main()

# Generated at 2022-06-25 02:57:35.607276
# Unit test for function main
def test_main():

    """
    Description:
    
    Pre-requisites for the function test:

    Sample test case 1:

    Input:
    
    Expected outcome:
    Result should be success, with proper message

    """

    var_0 = main()

# Generated at 2022-06-25 02:57:36.005079
# Unit test for function main
def test_main():
    var_0 = main()



# Generated at 2022-06-25 02:57:43.636701
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    var_1 = var_0.params['data']
    assert var_1 is None, "Expected var_1 to be None"
    assert var_1 == 'pong', "Expected var_1 to be 'pong'"

    try:
        raise Exception("boom")
    except Exception as var_2:
        assert (var_2.args[0] == "boom"), "Expected var_2.args[0] to be 'boom'"

# Generated at 2022-06-25 02:57:44.462026
# Unit test for function main
def test_main():
    mocker = main()
    main(var_0)

# Generated at 2022-06-25 02:57:47.277778
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 02:57:49.077429
# Unit test for function main
def test_main():
    try:
        # function main return value
        assert var_0 == "None"
    except AssertionError:
        # Assertion Error
        print("Assertion Error")

# Generated at 2022-06-25 02:57:51.778402
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:58:14.547714
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:58:15.974868
# Unit test for function main
def test_main():
    assert var_0 == module.exit_json, 'var_0 != module.exit_json'



# Generated at 2022-06-25 02:58:16.817601
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 02:58:23.207717
# Unit test for function main
def test_main():

    # Define a class for the mock
    class MockModule(object):
        def __init__(self, **methods):
            self.methods = methods

        def __call__(self, *args, **kwargs):
            method = self.methods[args[0]]
            return method(*args[1:], **kwargs)

    # Class name is not defined as an attribute on the object
    with pytest.raises(AttributeError):
        main()
        if hasattr(var_0, 'methods'):
            var_1 = var_0.methods
        else:
            var_1 = None
        assert var_1 == '__call__'
    var_0 = MockModule()


# Generated at 2022-06-25 02:58:24.000677
# Unit test for function main
def test_main():
    # Test case_0
    ret_val = main()

# Generated at 2022-06-25 02:58:24.477947
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:58:26.689033
# Unit test for function main
def test_main():
    assert var_0 == 'pong'

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:58:28.765085
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False


# Generated at 2022-06-25 02:58:29.812837
# Unit test for function main
def test_main():
    assert var_0 == 0

# Generated at 2022-06-25 02:58:31.015174
# Unit test for function main
def test_main():
    var_0 = main()

# Test case for main

# Generated at 2022-06-25 02:59:06.819773
# Unit test for function main
def test_main():
    var_0 = main()
    assert not var_0


# Generated at 2022-06-25 02:59:13.582217
# Unit test for function main
def test_main():
    try:
        _ansible_module_runner = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
    except Exception as exc:
        assert False, "Exception creating an AnsibleModule object"

    try:
        if _ansible_module_runner.params['data'] == 'crash':
            raise Exception("boom")
    except Exception as exc:
        assert False, "Exception testing for exception"

    try:
        _ansible_module_runner.exit_json(
            ping=_ansible_module_runner.params['data'],
        )
    except Exception as exc:
        assert False, "Exception exiting json"

# Generated at 2022-06-25 02:59:17.978670
# Unit test for function main
def test_main():
    fake_module = type("FakeModule", (object,), {})
    fake_module().AnsibleModule = type("FakeAnsibleModule", (object,), {})
    fake_module().AnsibleModule = fake_module().AnsibleModule()
    fake_module().AnsibleModule.argument_spec = dict(
        data=dict(type='str', default='pong')
    )
    fake_module().AnsibleModule.params = {'data': 'crash'}
    with raises(Exception):
        main()

# Generated at 2022-06-25 02:59:18.755583
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:59:20.101531
# Unit test for function main
def test_main():
  try:
    var_1 = main()
  except Exception as err:
    assert False, err

# Generated at 2022-06-25 02:59:21.062405
# Unit test for function main
def test_main():
    # assert var_0 == expected
    test_case_0()

# Generated at 2022-06-25 02:59:24.390343
# Unit test for function main
def test_main():
    try:
        main()
    except NameError as err:
        assert True
        print('Test success')
    except Exception as err:
        assert True
        print('Test failed')

test_main()

# Generated at 2022-06-25 02:59:27.773990
# Unit test for function main
def test_main():

    # Test case #0
    try:
        test_case_0()
        test_case_0()
    except:
        print("Exception encountered while running test case 0")

test_main()

# Generated at 2022-06-25 02:59:28.983586
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-25 02:59:34.951767
# Unit test for function main
def test_main():
    doc = DOCUMENTATION
    examples = EXAMPLES
    return_val = RETURN
    
    module = AnsibleModule(
		argument_spec=dict(
			data=dict(type='str', default='pong'),
		),
		supports_check_mode=True
	)

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-25 03:01:04.877531
# Unit test for function main
def test_main():
    with patch('main') as patch_function_0:
        patch_function_0.return_value = var_0
        patch_function_1 = mock.patch('ansible.module_utils.basic.AnsibleModule')
        with patch_function_1 as patch_function_0:
            with patch_function_0 as patch_function_0:
                patch_function_0.return_value = var_0
                expected_result_0 = var_0
                result_0 = main()
                assert expected_result_0 == result_0

# Generated at 2022-06-25 03:01:06.330260
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == '{"changed": false, "ping": "pong"}'


# Generated at 2022-06-25 03:01:07.041811
# Unit test for function main
def test_main():
    assert (test_case_0).__eq__()

# Generated at 2022-06-25 03:01:07.789070
# Unit test for function main
def test_main():
    raise Exception("add test")

# Generated at 2022-06-25 03:01:08.469227
# Unit test for function main
def test_main():
    assert 'object' == type(main()).__name__

# Generated at 2022-06-25 03:01:11.250148
# Unit test for function main
def test_main():
    dict_0 = dict(
        data=dict(type='str', default='pong'),
    )

    dict_1 = dict(
        support_check_mode=True,
    )

    dict_2 = dict(
        ping=dict(type='str', default='pong'),
    )




# Generated at 2022-06-25 03:01:17.204500
# Unit test for function main
def test_main():
    with patch('ansible_collections.ansible.builtin.plugins.modules.ping.AnsibleModule') as p0:
        with patch('ansible_collections.ansible.builtin.plugins.modules.ping.AnsibleModule.exit_json') as p1:
            p0.params = {}
            p1.return_value = None
            var_2 = p0
            var_3 = p0.exit_json
            try:
                res = main()
            except Exception:
                var_3.side_effect = RuntimeError('super boom')
                raise
            finally:
                pass
            var_3.assert_called_once()


# Generated at 2022-06-25 03:01:18.986601
# Unit test for function main
def test_main():
    # These tests in this function aren't complete yet, but they're a good start
    var_0 = main()


# Unit tests for the module

# Generated at 2022-06-25 03:01:19.766098
# Unit test for function main
def test_main():
    var_0 = main()

test_main()

# Generated at 2022-06-25 03:01:20.926929
# Unit test for function main
def test_main():
    assert(main() == {'ping': 'pong'})

# Generated at 2022-06-25 03:04:22.663439
# Unit test for function main
def test_main():
    #  Expected value of result at the end
    var_0 = "pong"
    arg_5 = {"ping": var_0}

    #  Function Under Test
    var_6 = main()
    #  Check against expected
    if var_6 == arg_5:
        return 0
    return 1


# Generated at 2022-06-25 03:04:23.949118
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as err:
        assert False, err


# Generated at 2022-06-25 03:04:24.580824
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 03:04:25.242878
# Unit test for function main
def test_main():
    assert not main(), "Incorrect return value"

# Generated at 2022-06-25 03:04:27.896316
# Unit test for function main
def test_main():
    # set up test parameters
    argv = []

    # run test
    retval = main(argv)
    assert retval


# Generated at 2022-06-25 03:04:29.273263
# Unit test for function main
def test_main():
    # we could get better coverage with a second test that does not just call main
    var_0 = main()


# Generated at 2022-06-25 03:04:34.295752
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Unit test main
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:04:34.991769
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:04:37.218246
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )


# Test function main if raises an exception

# Generated at 2022-06-25 03:04:44.757206
# Unit test for function main
def test_main():
    if (not (True)):
        var_2 = True
        if (not (var_2)):
            var_3 = []
            var_3.append(var_2)
            var_1 = var_3[0]
        else:
            var_1 = var_2
    else:
        var_1 = True

    return var_1
