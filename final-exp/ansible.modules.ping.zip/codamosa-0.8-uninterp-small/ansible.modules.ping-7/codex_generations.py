

# Generated at 2022-06-25 02:56:16.459818
# Unit test for function main

# Generated at 2022-06-25 02:56:20.007342
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 02:56:23.105324
# Unit test for function main
def test_main():
    args = dict(data='crash')
    # Check if exception is raised
    try:
        main()
        assert False
    except:
        assert True

    check = main(args, {'changed': False})
    assert check == args['data']

# Generated at 2022-06-25 02:56:25.089694
# Unit test for function main
def test_main():
    var_0 = None
    # Test for our call
    args = dict(
        data='crash',
    )

    var_0 = main(var_0, **args)

    assert True