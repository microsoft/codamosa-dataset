

# Generated at 2022-06-25 02:56:10.995952
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None


# Generated at 2022-06-25 02:56:20.168020
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec={'data': {'default': 'pong', 'type': 'str'}},
        supports_check_mode=True
    )
    def mock_exit_json(*args, **kwargs):
        raise Exception("boom")
    var_1.exit_json = mock_exit_json
    var_1.params = {'data': {}}
    # var_1 -> mock
    with pytest.raises(Exception):
        main()
    var_1.params = {'data': None}
    # var_1 -> mock
    with pytest.raises(Exception):
        main()
    var_1.params = {'data': []}
    # var_1 -> mock
    with pytest.raises(Exception):
        main()
    var_

# Generated at 2022-06-25 02:56:23.736878
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except:
        assert False
    try:
        assert 'AnsibleModule' in str(main.__code__)
    except:
        assert False
    try:
        assert True if main() else False
    except:
        assert False
test_main()

# Generated at 2022-06-25 02:56:24.549892
# Unit test for function main
def test_main():
    assert main()


# Generated at 2022-06-25 02:56:29.143219
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:56:29.760065
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:56:37.510488
# Unit test for function main
def test_main():
    # access vars from outside
    global url
    global headers
    global timeout
    global method
    global validate_certs
    global data

    # set up
    url = "url"
    headers = {
                   "header": "a value"
               }
    timeout = 10
    method = "GET"
    validate_certs = True
    data = "data"

    # run test
    test_case_0()

    # verify
    assert 200 == requests.get(url, headers=headers, timeout=timeout, verify=validate_certs, data=data)

# Generated at 2022-06-25 02:56:40.654123
# Unit test for function main
def test_main():
    var_0 = main()



# Generated at 2022-06-25 02:56:41.768856
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False


# Generated at 2022-06-25 02:56:42.824610
# Unit test for function main
def test_main():

    assert(var_0 == {"ping": "pong"})

# Generated at 2022-06-25 02:56:55.573148
# Unit test for function main
def test_main():

    # Setup variable for test
    tmp_test = "value"

    # Setup variable for test
    ansible_module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)

    # Setup variable for test
    ansible_module.params['data'] == 'crash'

    # Set up variable for test
    result = dict(ping=ansible_module.params['data'])

    # Check if result is as expected
    assert result['ping'] == 'crash'

    # Setup variable for test
    var_0 = main()

# Generated at 2022-06-25 02:56:57.318741
# Unit test for function main
def test_main():
    assert var_0 == 1

# Generated at 2022-06-25 02:57:01.216808
# Unit test for function main
def test_main():
    expected_result = {}
    actual_result = main()
    assert expected_result == actual_result

# Generated at 2022-06-25 02:57:10.136860
# Unit test for function main
def test_main():
    assert main()


# This file's unit tests can be run via python -m ansible.module_utils.basic.ping [testcase]
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print("Running unit tests for '{0}'".format(sys.argv[0]))
        loc = locals()
        for funcname, func in list(loc.items()):
            if funcname.startswith('test_') and callable(func):
                print("  Calling '{0}'".format(funcname))
                func()
        print("Done")
        sys.exit(0)
    else:
        print("Use 'python -m ansible.module_utils.basic.ping [testcase]'")
        sys.exit(1)

# Generated at 2022-06-25 02:57:11.328464
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 02:57:23.579768
# Unit test for function main
def test_main():
    # Define arguments and prepare the necessary data for feeding to the AnsibleModule object
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    )

    # Instantiate the module object
    module = AnsibleModule(argument_spec=argument_spec, supports_check_mode=True)

    # Check mode is supported
    assert module.supports_check_mode is True

    # Check if module.params['data'] is equal to 'crash'
    if module.params['data'] == 'crash':
        # If yes, fail the module
        raise Exception("boom")

    # Set the result as passed data
    result = dict(
        ping=module.params['data'],
    )

    # Exit the module and return the required JSON.
    module.exit_json(**result)



# Generated at 2022-06-25 02:57:27.026287
# Unit test for function main
def test_main():
    assert main()

test_case_0()

# Generated at 2022-06-25 02:57:29.473928
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == {'ping': 'pong'}

# Generated at 2022-06-25 02:57:38.182618
# Unit test for function main
def test_main():
    # Test case: missing argument
    # Sample argument:
    #   -m 'ansible.modules.network.nxos.nxos_static_route'
    #   -a '''dest="10.10.10.0" group="bravo" mask="255.255.255.0" name="foobar" state="absent"'''
    #   -M 'test/units/modules/network/nxos'
    #   -P '(?i)UNREACHABLE! => {.*}'
    module_args = dict(
        data="pong",
    )
    with pytest.raises(AnsibleExitJson):
        main()


# Generated at 2022-06-25 02:57:39.756982
# Unit test for function main
def test_main():
    try:
        test_case_0()
        print('Test case 0')
    except:
        print('Test case 0 function failed')

#------------------------

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:57:51.924107
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None



# Generated at 2022-06-25 02:57:57.123331
# Unit test for function main
def test_main():
    var_1 = { "ping": "pong" }
    assert main('pong') == var_1
    var_2 = Exception("boom")
    assert main('crash') == var_2

# Generated at 2022-06-25 02:58:00.224474
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert 'data' in module.params
    # assert that the ping return value is 'pong'
    assert module.params['data'] == 'pong'

# Generated at 2022-06-25 02:58:02.449744
# Unit test for function main
def test_main():
	try:
		test_case_0()
	except:
		pass
		
test_main()

# Generated at 2022-06-25 02:58:03.390263
# Unit test for function main
def test_main():
    var_0 = ansible_module_ping_main()
    assert var_0 == 0

# Generated at 2022-06-25 02:58:04.337665
# Unit test for function main
def test_main():
    assert func_ret_val_0 == "pong"


# Generated at 2022-06-25 02:58:08.077676
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        import sys
        print("In test_main()")
        print("Got unexpected exception", sys.exc_info()[0])
        raise

# Generated at 2022-06-25 02:58:09.283407
# Unit test for function main
def test_main():
    # Test case 0, check that main doesn't fail execution
    assert test_case_0() == None

# Generated at 2022-06-25 02:58:12.401569
# Unit test for function main
def test_main():
    dict0_var_0 = dict()
    dict0_var_0['data'] = 'pong'

    var_0 = main(dict0_var_0)

    assert(var_0.get('ping') == 'pong')

# Generated at 2022-06-25 02:58:14.532484
# Unit test for function main
def test_main():
    var_0 = var_0()
    print(var_0())

# Generated at 2022-06-25 02:58:32.110468
# Unit test for function main
def test_main():
    # Setup
    var_0 = AnsibleModule()


# Generated at 2022-06-25 02:58:33.722345
# Unit test for function main
def test_main():
	expected_0 = {
        'ping': 'pong',
    }
	actual_0 = main()
	assert(expected_0 == actual_0)

# Generated at 2022-06-25 02:58:34.240127
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-25 02:58:35.396172
# Unit test for function main
def test_main():
    assert 'AnsibleModule' in str(type(main()))


# Generated at 2022-06-25 02:58:37.111489
# Unit test for function main
def test_main():
    try:
      main()
      assert True
    except:
      assert False, "Unit Test Failed"


# Unit Test for function main

# Generated at 2022-06-25 02:58:38.619925
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'pong', "Error"


# Generated at 2022-06-25 02:58:46.477894
# Unit test for function main
def test_main():
    # mock_0 = mocker.patch('main.AnsibleModule')
    # mock_1 = mocker.patch('main.main')
    # assert mock_0.return_value == var_0
    # assert mock_1 == var_0
    # mock_2 = mocker.patch('main.AnsibleModule')
    # mock_3 = mocker.patch('main.main')
    # assert mock_2.return_value == var_0
    # assert mock_3 == var_0
    # raise Exception("Test case not implemented for function main")
    pass


# main()

# Generated at 2022-06-25 02:58:47.399007
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:58:54.386779
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test default value for parameter data
    assert var_1.params['data'] == 'pong'
    var_2 = var_1.params['data']
    if var_2 == 'crash':
        raise Exception("boom")
    # Test default value for parameter ansible.builtin.ping.ping
    assert var_1.result['ping'] == 'pong'

# Test case for class AnsibleModule

# Generated at 2022-06-25 02:58:55.453683
# Unit test for function main
def test_main():
    result = main()
    assert result == 'Ping output'

# Generated at 2022-06-25 02:59:35.771518
# Unit test for function main
def test_main():
    assert True

# Testing main() function

# Generated at 2022-06-25 02:59:39.413451
# Unit test for function main
def test_main():
    var_1 = None
    try:
        main()
        assert True
    except:
        import traceback

        var_1 = traceback.format_exc()
        assert False, 'Error running testcase: %s' % var_1


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:59:42.224578
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except ValueError as e:
        assert "boom" in e.message

# Generated at 2022-06-25 02:59:43.381840
# Unit test for function main
def test_main():
    # Todo: Add test
    assert test_case_0() == True

# Generated at 2022-06-25 02:59:44.202839
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:59:45.643280
# Unit test for function main
def test_main():
    # Set up test environment
    test_case_0()

# Global setup to prepare for test run

# Generated at 2022-06-25 02:59:53.694964
# Unit test for function main
def test_main():
    # Setup mocks
    import ansible.module_utils.basic
    m_ansible_module_utils_basic = ansible.module_utils.basic
    m_ansible_module_utils_basic.AnsibleModule = mock.MagicMock()
    m_ansible_module_utils_basic.AnsibleModule.return_value = mock.MagicMock()
    m_ansible_module_utils_basic.AnsibleModule.return_value.params = dict(data='pong')
    m_ansible_module_utils_basic.AnsibleModule.return_value.supports_check_mode = True
    # Setup data for test
    # Setup exception for test
    # Setup return values for test
    import ansible.module_utils.basic
    m_ansible_module_utils_basic.Ansible

# Generated at 2022-06-25 02:59:54.076381
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-25 02:59:56.352422
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == "pong"


# Generated at 2022-06-25 03:00:02.912942
# Unit test for function main
def test_main():
    var_0 = 'crash'
    var_1 = dict()
    var_1['data'] = var_0
    var_2 = dict()
    var_2['argument_spec'] = var_1
    var_3 = dict()
    var_3['check_mode'] = True
    var_2['supports_check_mode'] = var_3
    var_4 = AnsibleModule(**var_2)
    var_5 = var_4.params
    var_6 = dict()
    var_6 = var_5['data']
    var_8 = var_6 == 'crash'
    if var_8:
        var_7 = Exception('boom')
        raise var_7
    var_9 = dict()
    var_10 = dict()

# Generated at 2022-06-25 03:01:35.517777
# Unit test for function main
def test_main():
    assert 0 == 0

# Generated at 2022-06-25 03:01:40.554633
# Unit test for function main
def test_main():
    var_1 = getattr(var_0, 'exit_json', None)
    var_2 = getattr(var_1, '__call__', None)
    var_3 = getattr(var_2, '__code__', None)
    var_4 = getattr(var_3, 'co_varnames', None)
    var_5 = getattr(var_1, '__globals__', None)
    var_6 = getattr(__builtins__, 'globals', None)
    var_7 = getattr(var_6, '__call__', None)
    var_8 = getattr(var_7, '__code__', None)
    var_9 = getattr(var_8, 'co_varnames', None)

# Generated at 2022-06-25 03:01:41.721503
# Unit test for function main
def test_main():
    var_1 = test_case_0()
    assert var_1 == 'pong'

# Generated at 2022-06-25 03:01:43.067127
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None


test_main()

test_case_0()

# Generated at 2022-06-25 03:01:46.882915
# Unit test for function main
def test_main():
    aa = AnsibleModule()
    bb = AnsibleModule()



# Generated at 2022-06-25 03:01:47.755496
# Unit test for function main
def test_main():
    # code here
    pass

# Generated at 2022-06-25 03:01:50.019144
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        assert(e.__class__.__name__ == 'Exception')

# Testing the module class.

# Generated at 2022-06-25 03:01:51.465044
# Unit test for function main
def test_main():
    v_var_0 = test_case_0()
    print(v_var_0)

# Generated at 2022-06-25 03:01:53.959539
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        if e is None:
            pass
        elif "boom" in str(e):
            pass
        else:
            raise Exception(e)

# Generated at 2022-06-25 03:02:02.083820
# Unit test for function main
def test_main():
    var_1 = {'params': {'data': 'pong'}}
    var_2 = {'ping': 'pong'}
    var_3 = {'ping': 'pong'}

    def test_case_1():
        var_1 = {'params': {'data': 'pong'}}
        var_2 = {'ping': 'pong'}
        var_3 = {'ping': 'pong'}
        var_4 = 'pong'
        var_5 = main(var_1)

    def test_case_2():
        var_1 = {'params': {'data': 'crash'}}
        var_2 = {'ping': 'pong'}
        var_3 = {'ping': 'pong'}
        var_4 = 'crash'
        var

# Generated at 2022-06-25 03:05:12.576368
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-25 03:05:15.781091
# Unit test for function main
def test_main():
    assert var_0 == '0', 'Expected 0, got "{}"'.format(var_0)

# Generated at 2022-06-25 03:05:17.779869
# Unit test for function main
def test_main():
    raise Exception("Not implemented")


# Generated at 2022-06-25 03:05:22.009650
# Unit test for function main
def test_main():
        ansible_0 = {
                'ansible_check_mode': False,
                'ansible_diff_mode': False,
                'ansible_facts': {'kiosk_mode': False, 'ansible_connection': 'network_cli', 'ansible_network_os': 'ios'},
                'ansible_module_name': 'ansible.builtin.ping',
                'ansible_module_args': {'data': 'pong'},
                'ansible_version': {'full': '2.9.11', 'major': 2, 'minor': 9, 'revision': 11}}

# Generated at 2022-06-25 03:05:22.793078
# Unit test for function main
def test_main():
    assert main() is not None


# Generated at 2022-06-25 03:05:24.409993
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception: " + err.__class__.__name__)

# Generated at 2022-06-25 03:05:25.439180
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 1


# Generated at 2022-06-25 03:05:31.173348
# Unit test for function main
def test_main():
    var_0 = dict(data='crash')
    var_1 = dict(ANSIBLE_MODULE_ARGS=var_0)

    # Module is not supported on Windows
    if not PY2:
        module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)
        module.exit_json(failed=True, msg="Windows is not supported")
    else:
        module = AnsibleModule(var_1, var_0)
        var_2 = Exception('boom')
        var_3 = module.mock_function()
        var_3.side_effect = var_2

        with pytest.raises(Exception) as var_4:
            module.main()


# Generated at 2022-06-25 03:05:33.030519
# Unit test for function main
def test_main():
    var_0 = main()
    var_0 = main()

# Generated at 2022-06-25 03:05:33.835903
# Unit test for function main
def test_main():
    assert main() == 'pong'