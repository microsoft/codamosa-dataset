

# Generated at 2022-06-25 02:56:10.597462
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:56:11.424783
# Unit test for function main
def test_main():
    pass

test_case_1 = True

# Generated at 2022-06-25 02:56:12.873122
# Unit test for function main
def test_main():
    assert var_0 == {'ping': 'pong'}, 'Failed to assert'

# Generated at 2022-06-25 02:56:16.382260
# Unit test for function main
def test_main():
    assert callable(main)
    pass


### END OF TEST CASES ###

# Generated at 2022-06-25 02:56:18.347147
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0.NAME == 'pong'
    assert var_0.VALUE == 'pong'
    assert var_0.TYPE == 'pong'


# Generated at 2022-06-25 02:56:20.660275
# Unit test for function main
def test_main():
    for i in range(0):
        assert test_case_0() == var_0

# Generated at 2022-06-25 02:56:21.100482
# Unit test for function main
def test_main():
  pass

# Generated at 2022-06-25 02:56:24.634275
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as ex:
        assert False, "test_case_0 failed: " + str(ex)

# Generated test cases for the following inputs
#   data="pong"

# Unit tests for function main

# Generated at 2022-06-25 02:56:29.175898
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:56:30.799731
# Unit test for function main
def test_main():
    var_1 = {}
    var_2 = dict({u'data': 'crash'})
    test_case_0(var_1, var_2)

# Generated at 2022-06-25 02:56:37.559968
# Unit test for function main
def test_main():
    # test case 0
    print("***** test case 0 *****")

    test_case_0()


# run unit test
test_main()

# Generated at 2022-06-25 02:56:43.038226
# Unit test for function main
def test_main():
    if (sys.version_info > (3, 0)):
        # Python 3 case
        var_1 = unittest.main()
    elif (sys.version_info < (3, 0)):
        # Python 2 case
        var_1 = unittest.main()


# Generated at 2022-06-25 02:56:51.346269
# Unit test for function main
def test_main():
    # mock_type_vars
    mock_type_vars = {'SUPPORT_CHECK_MODE': True}

    # mock_module
    mock_module = type('mock_module', (), {'params': {'data': 'pong'}, 'supports_check_mode': True})

    # mock_main
    mock_main = type('mock_main', (), {'main': main()})

    # mock_exit_json
    mock_exit_json = type('mock_exit_json', (), {'exit_json': exit_json()})

    def test_case_0():
        var_0 = main()

    def test_case_1():
        var_0 = main()




# Generated at 2022-06-25 02:56:54.449104
# Unit test for function main
def test_main():
    var_1 = AnsibleModule('main')
    test_case_0(var_1)
# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 02:57:04.834691
# Unit test for function main
def test_main():
    # Test to see if we can successfully import the function
    mod_import_test(name='ansible.module_utils.basic',
                    module='ansible.module_utils.basic',
                    function='AnsibleModule')

    # Test to see if we can successfully import the function
    mod_import_test(name='ansible.module_utils.basic',
                    module='ansible.module_utils.basic',
                    function='main')
    # Test to see if we can successfully import the function
    mod_import_test(name='ansible.module_utils.basic',
                    module='ansible.module_utils.basic',
                    function='test_case_0')
    # Test to see if we can successfully import the function

# Generated at 2022-06-25 02:57:10.017846
# Unit test for function main
def test_main():
    # Could not import

    # No arguments specified

    # Argument specified
    main(data='pong')
    main(data='crash')

# Generated at 2022-06-25 02:57:20.887121
# Unit test for function main
def test_main():
    REQUIRED_ATTRIBUTES = [
        'AN_IMPORT_EXAMPLE',
        'ARGUMENT_SPEC',
        'SUPPORTS_CHECK_MODE'
    ]
    module = AnsibleModule({
        'AN_IMPORT_EXAMPLE': 42
    }, supports_check_mode=True) # var_0 = 42
    var_1 = module.params['AN_IMPORT_EXAMPLE'] # var_1 = 42
    if module.params['data'] == 'crash':
        var_2 = Exception("boom")
        raise var_2
    var_3 = {
        'ping': module.params['data'],
    }
    return module.exit_json(**var_3) # return {'changed': False, 'ping': 'pong'}
    assert var_

# Generated at 2022-06-25 02:57:23.664135
# Unit test for function main
def test_main():
    try:
        assert True
    except AssertionError:
        var_0 = AssertionError()
        raise var_0

# Generated at 2022-06-25 02:57:27.905941
# Unit test for function main
def test_main():
    # Setup and Run
    # Teardown

    # Asserts
    assert var_0 == None
    assert var_0 == None


# Generated at 2022-06-25 02:57:29.016027
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:57:40.181427
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:57:45.987932
# Unit test for function main
def test_main():
    # mock_args
    mock_args = ['ansible-test-module.py', '--data', 'pong']
    # Call function under test
    main(mock_args)


# Generated at 2022-06-25 02:57:49.979285
# Unit test for function main
def test_main():
    obj = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert type(obj).__name__ == 'AnsibleModule'
    assert obj.params['data'] == 'pong'
    assert len(obj.params) == 1
    assert obj.supports_check_mode == True


# Generated at 2022-06-25 02:57:51.838753
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:57:52.490954
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:57:57.577701
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print('main exit non-zero')
            raise

test_main()

# Generated at 2022-06-25 02:57:58.138983
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:58:02.016319
# Unit test for function main
def test_main():
    var_1 = module.params['data']
    if var_1 == 'crash':
        raise Exception("boom")
    var_2 = module.params['data']
    var_3 = dict(ping=var_2)
    module_exit_json(**var_3)


# Generated at 2022-06-25 02:58:07.647774
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    # Replace this with some actual testing code.
    assert True

# Generated at 2022-06-25 02:58:08.368549
# Unit test for function main
def test_main():
    this_var = 11


# Generated at 2022-06-25 02:58:30.230584
# Unit test for function main
def test_main():
    assert isinstance(var_0, dict), "Return is not a dict"
    assert "ping" in var_0, "ping missing in return value"
    assert var_0["ping"] == "pong"


# Generated at 2022-06-25 02:58:33.535313
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    var_1 = main()


# Generated at 2022-06-25 02:58:36.303572
# Unit test for function main
def test_main():
    raise Exception("FIX ME!!!")
    # Assign parameter data
    var_1 = ITR(0, "0")

    var_2 = test_0(var_1)

    return var_2


# Generated at 2022-06-25 02:58:37.890188
# Unit test for function main
def test_main():
    var_1 = AnsibleModule('')
    var_2 = AnsibleModule('')

# Generated at 2022-06-25 02:58:44.156357
# Unit test for function main
def test_main():
    # <Value '<module_wrapper.<locals>...' at 0x7fb590c6eaf8>
    var_1 = AnsibleModule()
    var_2 = dict()
    var_3 = dict()
    var_3["type"] = 'str'
    var_3["default"] = 'pong'
    var_2["data"] = var_3
    var_1.argument_spec = var_2
    var_1.supports_check_mode = True
    var_4 = var_1.params
    var_5 = var_4["data"]
    var_6 = var_5 == 'crash'
    if var_6:
        raise Exception("boom")
    else:
        var_7 = dict()
        var_7["ping"] = var_5

# Generated at 2022-06-25 02:58:48.188943
# Unit test for function main
def test_main():
    try:
        assert 'var_0' in globals()
    except AssertionError:
        raise AssertionError("fatal error: module hasn't been loaded")
    assert (var_0 == None)

# Generated at 2022-06-25 02:58:50.799531
# Unit test for function main
def test_main():
    with mock.patch('ansible.module_utils.basic.AnsibleModule'):
        assert main() == 'foo'

# Unit test if request.add_header() is called with the correct parameters

# Generated at 2022-06-25 02:58:51.993829
# Unit test for function main
def test_main():
    # Test case 0
    # Run test with no parameters
    test_case_0()

# Generated at 2022-06-25 02:59:00.259068
# Unit test for function main

# Generated at 2022-06-25 02:59:00.869939
# Unit test for function main
def test_main():
    var_0 = main()



# Generated at 2022-06-25 02:59:42.223913
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-25 02:59:43.068153
# Unit test for function main
def test_main():
    print('test case#0')

# Generated at 2022-06-25 02:59:43.904991
# Unit test for function main
def test_main():
    assert func_0(var_0) == var_0

# Generated at 2022-06-25 02:59:45.324232
# Unit test for function main
def test_main():
    # get the function and call it
    func = getattr(sys.modules[__name__], "main")
    func()

# Generated at 2022-06-25 02:59:45.830087
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:59:50.863161
# Unit test for function main
def test_main():
    # This unit test checks that AnsibleModule, AnsibleModule.exit_json, and AnsibleModule.fail_json are imported correctly
    ansible_module = AnsibleModule()
    assert(ansible_module.exit_json == AnsibleModule.exit_json)
    assert(ansible_module.fail_json == AnsibleModule.fail_json)
    # This unit test checks that the function is returning the correct value
    assert(main() == None)


# Generated at 2022-06-25 02:59:51.381416
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-25 02:59:53.656799
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    var_0 = {}
    var_0 = main(var_0)

    assert var_0 == {"ping": "pong"}


# Generated at 2022-06-25 02:59:57.876287
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if var_0.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=var_0.params['data'],
    )

    var_0.exit_json(**result)

# Generated at 2022-06-25 03:00:02.997362
# Unit test for function main
def test_main():
    # ===> Try to open file "test_case_0.py"
    # ===> File opened successfully, checking the case number
    assert var_0['ping'] == 'pong', 'Expected return value should be "pong", but the actual value returned is ' + str(var_0['ping'])
    assert var_0['ping'] == 'pong', 'Expected return value should be "pong", but the actual value returned is ' + str(var_0['ping'])
    # ===> File closed successfully
    test_main()

# Generated at 2022-06-25 03:01:36.017501
# Unit test for function main
def test_main():
    assert main() == 'ping'


# Generated at 2022-06-25 03:01:36.741838
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 03:01:37.865566
# Unit test for function main
def test_main():
    var_0 = main()

    assert(var_0 != 0)


# Generated at 2022-06-25 03:01:38.704402
# Unit test for function main
def test_main():
    assert main() == "pong"

# Generated at 2022-06-25 03:01:43.819758
# Unit test for function main
def test_main():
    # Make the arguments
    arguments = []
    arguments.append([])
    arguments[0].append(dict(
        ansible_module_args={
            "data":"pong",
        },
        changed=False,
        ping="pong",
    ))
    # Run the function
    results = main(*arguments)

    # Test the results
    assert(results[0]["changed"] == False)
    assert(results[0]["ping"] == "pong")

# Generated at 2022-06-25 03:01:46.562855
# Unit test for function main
def test_main():
    assert(main())

# Generated at 2022-06-25 03:01:49.448516
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print >>sys.stderr, "unit test failed with exit code %d" % inst.args[0]
            raise

# Generated at 2022-06-25 03:01:51.425071
# Unit test for function main
def test_main():
  data_0 = "<script>alert('Hello');</script>"
  var_0 = main()
  assert var_0 == data_0

# Generated at 2022-06-25 03:01:52.856580
# Unit test for function main
def test_main():
    try:
        main()
    except:
        main()
        assert False


# Generated at 2022-06-25 03:01:55.347416
# Unit test for function main
def test_main():
    var_0 = main(a = 'pong', b = None, c = None, d = None, e = None)
    assert var_0 == {'ping': 'pong'}, "Return value did not match expected."

# Generated at 2022-06-25 03:05:07.435819
# Unit test for function main
def test_main():
    class DummyModule():
        def __init__(self):
            self.params = { 'data': 'pong' }
            self.supports_check_mode = True

    var_0 = DummyModule()
    main(var_0)

# Generated at 2022-06-25 03:05:07.933111
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:05:10.474106
# Unit test for function main
def test_main():
    data = {
        'ping': 'pong'
    }

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert data == var_0

# Generated at 2022-06-25 03:05:16.934769
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None or type(var_0) is int


# Generated at 2022-06-25 03:05:21.110676
# Unit test for function main
def test_main():
    var_0 = AnsibleModule((), {u'supports_check_mode': True, u'argument_spec': {u'data': {u'required': False, u'type': u'str', u'default': u'pong'}}})
    var_1 = (var_0.params[u'data'] == u'crash')
    var_2 = Exception("boom") if var_1 else None
    if (var_1):
        raise var_2
    else:
        var_5 = dict(ping=var_0.params[u'data'])
        var_0.exit_json(**var_5)

# Generated at 2022-06-25 03:05:22.539158
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 03:05:23.301295
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0

# Generated at 2022-06-25 03:05:24.608575
# Unit test for function main
def test_main():
    assert test_case_0() == \
    ({'ping': 'pong'}, None)

# Generated at 2022-06-25 03:05:30.743210
# Unit test for function main
def test_main():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except:
        print("SKIP: needs AnsibleModule")
        return
    try:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils._text import to_text
    except:
        print("SKIP: needs to_text")
        return

    module_args = dict(
        data=dict(type='str', default='pong'),
    )

    module_args = dict()
    module_args.update(ARGS)

    # Test passing args as dict
    mock_args = dict(
        params=module_args
    )

# Generated at 2022-06-25 03:05:33.836740
# Unit test for function main
def test_main():
    import ansible.modules.system.ping
    main = ansible.modules.system.ping.main
    ansible.modules.system.ping.EXAMPLES = None
