

# Generated at 2022-06-25 02:56:06.916576
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")
    
    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)
    
    assert var_0 == result


# Generated at 2022-06-25 02:56:09.218289
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-25 02:56:11.427478
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except:
        assert False


# Generated at 2022-06-25 02:56:15.431021
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-25 02:56:18.027497
# Unit test for function main
def test_main():
    try:
        result = main()
        pass
    # Expecting ValueError exception
    except SystemExit:
        if result.get('changed', False):
            print('* Changed result: %s' % result['changed'])
        pass

# Generated at 2022-06-25 02:56:20.630286
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None


# Generated at 2022-06-25 02:56:27.568777
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes, to_native
    import traceback

    # Save the built in Exception class in case we need to reference it
    ExceptionClass = Exception

    # Test case to use
    test_case = 0

    # Get the test case
    try:
        test_case = int(os.environ['TEST_CASE'])
    except KeyError:
        pass

    module_args = dict(
        data=dict(type='str', default='pong'),
    )


# Generated at 2022-06-25 02:56:28.981983
# Unit test for function main
def test_main():
    var_0 = "pong"
    var_1 = "crash"

    # Check for expected return value.
    print(var_0)
    print(var_1)
    assert var_0 == var_1

# Generated at 2022-06-25 02:56:33.383262
# Unit test for function main

# Generated at 2022-06-25 02:56:41.601091
# Unit test for function main
def test_main():
    try:
        assert True
    except AssertionError:
        var_0 = AssertionError()
    else:
        var_0 = None
    finally:
        var_0 = None
    try:
        assert True
    except AssertionError:
        var_1 = AssertionError()
    else:
        var_1 = None
    finally:
        var_1 = None
    try:
        assert True
    except AssertionError:
        var_2 = AssertionError()
    else:
        var_2 = None
    finally:
        var_2 = None
    try:
        assert True
    except AssertionError:
        var_3 = AssertionError()
    else:
        var_3 = None
    finally:
        var_3 = None

# Generated at 2022-06-25 02:56:48.903994
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 02:56:57.735317
# Unit test for function main
def test_main():
    import ansible.modules.system.ping as ping
    import ansible.module_utils.basic as basic
    import ansible.module_utils.basic as basic
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.six as six
    import ansible.module_utils.six as six
    import ansible.module_utils.six as six
    import ansible.module_utils.six as six
    import ansible.module_utils.six as six
    import ansible.module_utils.six as six
    import ansible.module_utils.six.moves as moves
    import ansible.module_utils.six.moves as moves
    import ansible.module_utils.six.moves as moves
    import ansible.module_utils.six.moves as moves
    import ans

# Generated at 2022-06-25 02:57:08.181246
# Unit test for function main
def test_main():
    # Unit test for function main
    # Test we can logon to 'webservers' and execute python with json lib.
    # ansible webservers -m ping
    #
    # Example from an Ansible Playbook
    var_0 = {"ping": "pong"}
    arg_0 = var_0
    # Induce an exception to see what happens
    var_0 = {"ping": "pong"}
    arg_1 = var_0
    unit_test_case0 = var_0
    unit_test_case1 = var_0
    arg_2 = var_0
    unit_test_case2 = var_0
    unit_test_case3 = var_0



# Generated at 2022-06-25 02:57:12.506719
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    var_1 = var_0.params['data']
    if var_1 == 'crash':
        raise Exception("boom")
    else:
        var_2 = dict(
            ping=var_1,
        )

        var_0.exit_json(**var_2)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:57:24.326652
# Unit test for function main

# Generated at 2022-06-25 02:57:31.870786
# Unit test for function main
def test_main():
    var_2 = {'data': 'foo', '_ansible_check_mode': False, '_ansible_diff': False, '_ansible_module_name': 'ansible.builtin.ping', '_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_module_name': 'ansible.builtin.ping', '_ansible_module_name': 'ansible.builtin.ping', '_ansible_module_name': 'ansible.builtin.ping'}

# Generated at 2022-06-25 02:57:36.468250
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            pass
        else:
            print('Incorrect function main was called. Returned value was: ' + str(inst.args[0]))
            raise


# Generated at 2022-06-25 02:57:37.948469
# Unit test for function main
def test_main():
    try:
        main()
    except:
        var_0 = 0
        var_1 = 0
        if var_0 != var_1:
            raise Exception("Test case 0 failed")

# Generated at 2022-06-25 02:57:40.771682
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        assert False
        var_2 = e
    else:
        pass
    assert True

# Generated at 2022-06-25 02:57:47.235809
# Unit test for function main
def test_main():
   var_1 = {'data': 'crash'}
   var_2 = False
   try:
      var_1['data'] = 'crash'
   except:
      var_2 = True
   if var_2 != True:
      raise Exception("boom")
   return var_2

# Generated at 2022-06-25 02:57:58.902189
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:58:01.111346
# Unit test for function main
def test_main():
    var_1 = dict(ping=2, data=5)
    print(var_1)


# Generated at 2022-06-25 02:58:02.628504
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except Exception as e:
        raise Exception("Failed to call function 'main'")

# Generated at 2022-06-25 02:58:08.400675
# Unit test for function main
def test_main():
    var_1 = True
    var_2 = False
    flag = False
    if var_1 is var_2:
        flag = True
    if flag is not True:
        raise ValueError("flag is not true")
    path = '/home/kshitiz/Desktop/Ansible/Python/ansible/modules/testing/unit/module_utils/basic.py'
    assert flag == True


if __name__ == '__main__':
    
    test_main()

# Generated at 2022-06-25 02:58:09.105313
# Unit test for function main
def test_main():
    assert main() == 'foo'

# Generated at 2022-06-25 02:58:09.798613
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 02:58:11.915825
# Unit test for function main
def test_main():
    var_0 = main()
    assert(var_0 == None)
    # assert(False)

# Generated at 2022-06-25 02:58:12.680890
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:58:14.842338
# Unit test for function main
def test_main():
    res = main()
    #print (res)
    assert(res == "pong")

# Generated at 2022-06-25 02:58:17.149021
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
    {
    },
    supports_check_mode=True
)
    assert var_1 != None
    assert var_1 != False


# Generated at 2022-06-25 02:58:33.883781
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-25 02:58:34.401734
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-25 02:58:35.228010
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:58:36.068642
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-25 02:58:36.838740
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:58:37.693282
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:58:38.851417
# Unit test for function main
def test_main():
    assert callable(main), "main is not callable"


# Generated at 2022-06-25 02:58:40.343129
# Unit test for function main
def test_main():
    doc_0 = ping.__doc__
    assert doc_0 is not None


# Generated at 2022-06-25 02:58:41.025049
# Unit test for function main
def test_main():

    test_case_0()

# Generated at 2022-06-25 02:58:41.686204
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:59:23.884518
# Unit test for function main
def test_main():
    var_0 = main()
    assert isinstance(var_0, dict)

# Unit tests for function main

# Generated at 2022-06-25 02:59:25.239993
# Unit test for function main
def test_main():
    # Result of function call
    result = main()
    assert result is None
    assert result is not None


# Generated at 2022-06-25 02:59:28.390021
# Unit test for function main
def test_main():
    try:
        var_0 = main()
        assert var_0 != None
    except Exception as inst:
         print('Exception in main: ', inst)

# Test Call

# Generated at 2022-06-25 02:59:32.101491
# Unit test for function main
def test_main():
    var_1 = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    var_2 = dict(
        ping=var_1.params["data"],
    )
    var_1.exit_json(**var_2)

# Generated at 2022-06-25 02:59:33.514785
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:59:35.773256
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:59:38.832450
# Unit test for function main
def test_main():
    try:
        assert (callable(main))
    except AssertionError as e:
        print("Caught AssertionError %s" % e.args)
        raise e
if __name__ == '__main__':

    main()

# Generated at 2022-06-25 02:59:39.337849
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:59:41.064780
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-25 02:59:42.538966
# Unit test for function main
def test_main():
    var_0 = 'Ubuntu'
    var_1 = main()
    var_2 = 'pong'
    var_3 = var_1['ping']
    var_4 = assert_equal(var_2, var_3)

# Generated at 2022-06-25 03:01:12.926094
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-25 03:01:14.167249
# Unit test for function main
def test_main():
    var_0 = main()
    assert type(var_0) == dict
    assert var_0['failed'] == False

# Generated at 2022-06-25 03:01:18.964146
# Unit test for function main
def test_main():

    # Exercise class ansible.module_utils.basic.AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Exercise function ansible.module_utils.basic.AnsibleModule.exit_json()
    module.exit_json(**dict(
        ping=module.params['data'],
    ))

# Generated at 2022-06-25 03:01:19.777193
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 03:01:20.634027
# Unit test for function main
def test_main():
    assert main == 'pong'

# Generated at 2022-06-25 03:01:29.536333
# Unit test for function main
def test_main():
    # Start of module ping
    assert main() == 'boom'
    # Assignment to result
    # Masking ansible.builtin.ping module
    # Branch 1
    # Assignment to result
    # Branch 2
    # Assignment to result
    # Masking ansible.builtin.ping module
    # Branch 1
    # Return
    # End of module ping
    # Return
    assert main(module=dict(params=dict(data='crash'))) == 'boom'
    # Assignment to result
    # Masking ansible.builtin.ping module
    # Branch 1
    # Assignment to result
    # Return
    # End of module ping
    # Return
    assert main(module=dict(params=dict(data='pong', does_not_exist='foo'))) == 'pong'
    # Assignment to result
   

# Generated at 2022-06-25 03:01:34.860274
# Unit test for function main
def test_main():

    run = True
    if not run:
        return

    test_case_0()


# Compiles Python code

# Generated at 2022-06-25 03:01:36.228495
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 03:01:39.139756
# Unit test for function main
def test_main():
    assert True == main()

# Generated at 2022-06-25 03:01:39.930016
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 03:04:43.041891
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False



# Generated at 2022-06-25 03:04:46.999425
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:04:51.433205
# Unit test for function main
def test_main():

    # Try a default ping
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == main()

    # try a crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        main()
    except:
        pass
    else:
        assert False, 'Should have thrown an exception'
    # TODO - test check mode?

# Generated at 2022-06-25 03:04:52.451960
# Unit test for function main
def test_main():
    try:
        assert main()
    except:
        assert False

# Generated at 2022-06-25 03:04:52.846264
# Unit test for function main
def test_main():
    assert main() == 1

# Generated at 2022-06-25 03:04:54.873189
# Unit test for function main
def test_main():
    # Check if option 'data' is 'pong'
    assert True == ('pong' == ping.data)

# Generated at 2022-06-25 03:04:56.015354
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == {'ping': 'pong'}


# Generated at 2022-06-25 03:04:59.657534
# Unit test for function main
def test_main():
    var_0 = test_case_0()


# Generated at 2022-06-25 03:05:00.847404
# Unit test for function main
def test_main():
    assert main() == 'pong', "Did not return 'pong'"

# Generated at 2022-06-25 03:05:02.802643
# Unit test for function main
def test_main():
    try:
        # Unit-test for function main
        assert callable(main)
    except AssertionError as e:
        print('An error occured in unit-test for function main:')
        print(str(e))
    else:
        print('Function main passed unit-test')