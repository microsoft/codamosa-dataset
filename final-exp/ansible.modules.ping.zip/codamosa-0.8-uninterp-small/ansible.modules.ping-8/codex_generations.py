

# Generated at 2022-06-25 02:56:06.839621
# Unit test for function main
def test_main():
    assert var_0 == None

# Generated at 2022-06-25 02:56:15.128009
# Unit test for function main
def test_main():
    # mock module
    module = MagicMock()
    module.params = {'data': 'pong'}
    module.supports_check_mode = True

    # get a handle on the mocked module object
    mod = module().params

    # assert that the mocked module object was given the correct parameters
    assert(mod == {'data': 'pong'})

    # get a handle on the mocked module exit_json function
    mocked_exit_json = module().exit_json

    # assert that the mocked module exit_json function was called with the correct parameters
    mocked_exit_json.assert_called_with(ping='pong')

# Generated at 2022-06-25 02:56:19.927764
# Unit test for function main
def test_main():
    print('var_0 = main()')
    from ansible.module_utils.basic import AnsibleModule    
    var_0 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    if var_0.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=var_0.params['data'],
    )
    var_0.exit_json(**result)


# Generated at 2022-06-25 02:56:26.990820
# Unit test for function main
def test_main():
    try:
        assert var_0 == u'pong'
    except AssertionError as e:
        var_0 = False
    try:
        assert var_0 == u'pong'
    except AssertionError as e:
        var_0 = False
    try:
        assert var_0 == u'pong'
    except AssertionError as e:
        var_0 = False
    try:
        assert var_0 == u'pong'
    except AssertionError as e:
        var_0 = False
    try:
        assert var_0 == u'pong'
    except AssertionError as e:
        var_0 = False
    try:
        assert var_0 == u'pong'
    except AssertionError as e:
        var_0 = False
   

# Generated at 2022-06-25 02:56:28.256536
# Unit test for function main
def test_main():
    var_0 = main()
    assert not var_0
    var_1 = var_0
    # assert var_1 == "pong"


# Generated at 2022-06-25 02:56:28.927744
# Unit test for function main
def test_main():
    assert var_0 == "pong"


# Generated at 2022-06-25 02:56:32.578320
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule.__init__', new=MagicMock(return_value=None)):
        with patch('ansible.module_utils.basic.AnsibleModule.exit_json', new=MagicMock(return_value=None)):
            with patch('ansible.module_utils.basic.AnsibleModule.params', new=MagicMock(return_value={'data': 'pong'})):
                with patch('ansible.module_utils.basic.AnsibleModule.supports_check_mode', new=MagicMock(return_value=True)):
                    main()

# Generated at 2022-06-25 02:56:43.120273
# Unit test for function main
def test_main():
    import random, sys, os, tempfile
    from io import StringIO
    if sys.version_info[0] < 3:
        from nose.tools import assert_equal, assert_raises
        from nose import SkipTest
    else:
        from nose.tools import assert_equal, assert_raises, raises
        from nose import SkipTest
        
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.urls import open_url
    import ansible.module_utils.urls as urls
    import ansible.module_utils.six as six


    fd, test

# Generated at 2022-06-25 02:56:43.848991
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-25 02:56:45.125828
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:56:51.079720
# Unit test for function main
def test_main():
    try:
        _main()
    except SystemExit:
        pass


# Generated at 2022-06-25 02:57:00.855724
# Unit test for function main
def test_main():
    var_1 = AnsibleModule()
    var_2 = dict(data=dict(type='str', default='pong'))
    var_3 = dict(argument_spec=var_2, supports_check_mode=True)
    var_1.params = dict(data='crash')
    var_1.check_mode = False

# Generated at 2022-06-25 02:57:02.187919
# Unit test for function main
def test_main():
    assert main() == {u'ping': 'pong'}

# Generated at 2022-06-25 02:57:03.219691
# Unit test for function main
def test_main():
    assert var_0 == "ok"


# Generated at 2022-06-25 02:57:08.181071
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    raise Exception("boom")
    var_2 = dict(
        ping=var_1.params['data'],
    )
    var_1.exit_json(**var_2)



# Generated at 2022-06-25 02:57:10.479226
# Unit test for function main
def test_main():

#	var_0 = RESULT_0
	if var_0 == 'pong':
		assert True
	else:
		assert False


# Generated at 2022-06-25 02:57:11.422716
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-25 02:57:17.491542
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            pass
        else:
            raise
    except Exception as e:
        print('Caught exception: ' + repr(e))
        raise
    else:
        raise Exception('Exception expected')


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 02:57:18.583606
# Unit test for function main
def test_main():
    var_0 = main()



# Generated at 2022-06-25 02:57:24.926292
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)
    
    

# Generated at 2022-06-25 02:57:38.123305
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)
    var_1 = var_0.params
    var_2 = var_1['data']
    var_3 = var_2 == 'crash'
    if var_3:
        raise Exception("boom")

    var_4 = dict(ping=var_1['data'])
    var_0.exit_json(**var_4)

# Generated at 2022-06-25 02:57:41.242149
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong'}}, supports_check_mode=True)
    main()


# Generated at 2022-06-25 02:57:47.573343
# Unit test for function main
def test_main():
    var_1 = None
    var_2 = main()
    var_3 = None
    var_1 = var_2
    var_3 = (var_1 is None)
    var_3 = var_3 == 0
    if var_3:
        var_1 = var_2
    else:
        var_1 = var_2
    return var_1



# Generated at 2022-06-25 02:57:48.305965
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:57:53.677456
# Unit test for function main
def test_main():
    import ansible.modules.extras.networking.ping
    from ansible.modules.extras.networking.ping import main

    args = dict(data='crash')
    with pytest.raises(Exception) as _excinfo:
        main()

    args = dict(data='pong')
    out = main()
    assert out == 'pong'

# Generated at 2022-06-25 02:57:57.819470
# Unit test for function main
def test_main():
    assert callable(main)
    assert True == main()
    assert False == main()
    assert bool(True) == main()
    assert bool(False) == main()
    assert bool(True) == main()


# Generated at 2022-06-25 02:57:59.537900
# Unit test for function main
def test_main():
    try:
        assert False
    except:
        assert True
    

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 02:58:01.363972
# Unit test for function main
def test_main():
    var_0 = main()
    # assert var_0 == None

# Generated at 2022-06-25 02:58:02.328051
# Unit test for function main
def test_main():
    response = main()
    assert response == None


# Generated at 2022-06-25 02:58:08.077332
# Unit test for function main
def test_main():

    config = dict(
        data = "pong"
    )

    module_name = "ansible.builtin.ping"

    module = AnsibleModule(
        argument_spec=config,
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-25 02:58:30.021482
# Unit test for function main
def test_main():
    var_1 = UNKNOWN_VALUE
    ping = UNKNOWN_VALUE
    data = UNKNOWN_VALUE

    # Test function call
    assert (var_1 == ping)
    assert (var_1 == data)



# Generated at 2022-06-25 02:58:33.503187
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        ),
        supports_check_mode=True
    )
    assert var_1 is not None


# Generated at 2022-06-25 02:58:34.670887
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'pong'

# Generated at 2022-06-25 02:58:43.030167
# Unit test for function main
def test_main():
    import os
    import tempfile
    import json
    import subprocess

    data_0_0 = json.loads(var_0)
    assert data_0_0['ping'] == 'pong'
    assert data_0_0['changed'] == False
    assert data_0_0['ansible_facts'] is None
    assert data_0_0['invocation'] is not None
    assert data_0_0['invocation']['module_name'] == 'ping'

    data_0_1 = json.loads(var_1)
    assert data_0_1['msg'] == 'boom'
    assert data_0_1['rc'] == 1
    assert data_0_1['stderr_lines'] is not None

# Generated at 2022-06-25 02:58:44.805514
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == var_0

# Generated at 2022-06-25 02:58:47.437618
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None, \
        "not assert"
# end test_main

# Generated at 2022-06-25 02:58:49.728544
# Unit test for function main
def test_main():
    assert main == None, "Function <main()> has incorrect return type"
    assert callable(main), "Function <main()> does not exist"

# Generated at 2022-06-25 02:58:52.835713
# Unit test for function main
def test_main():
    var_0 = get_test_data('test_case_0.json')
    test_0 = var_0['test_0']
    result = main(test_0['test_0'])
    assert result == var_0['test_0']['test_0']

# Generated at 2022-06-25 02:58:54.500074
# Unit test for function main
def test_main():
    param_0 = {"data": "pong"}
    var_0 = main(param_0)

# Generated at 2022-06-25 02:58:55.454486
# Unit test for function main
def test_main():
    assert(
        test_case_0
    )

# Generated at 2022-06-25 02:59:35.811281
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-25 02:59:36.315032
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:59:37.367629
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'ping'

# Generated at 2022-06-25 02:59:46.268939
# Unit test for function main
def test_main():
    var_1 = "pong"
    var_2 = dict(ping=var_1)
    var_3 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    var_4 = "crash"
    var_3.params = dict(data=var_4)
    var_5 = Exception("boom")
    exception = False
    try:
        var_3.exit_json(**var_2)
    except SystemExit as e:
        exception = e
    if exception:
        assert exception.code == 0, "Didn't exit normally"
    else:
        raise

# Generated at 2022-06-25 02:59:48.061034
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'pong'


# Generated at 2022-06-25 02:59:48.550435
# Unit test for function main
def test_main():
    print(" ! Test ping.")

# Generated at 2022-06-25 02:59:49.333122
# Unit test for function main
def test_main():
    assert var_0 == 1

# Generated at 2022-06-25 02:59:49.789361
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-25 02:59:51.158446
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is not None, "Expected value is not None"


# Generated at 2022-06-25 02:59:58.599071
# Unit test for function main
def test_main():
    try:
        main()
        assert True
    except (AssertionError, ValueError) as e:
        assert False, str(e)



# module.params['data']
# 'pong'
# module.params['data']
# 'pong'
# module.params['data']
# 'pong'
# module.params['data']
# 'crash'
# module.params['data']
# 'crash'
# module.params['data']
# 'crash'
# module.params['data']
# 'pong'
# module.params['data']
# 'pong'
# module.params['data']
# 'pong'
# module.params['data']
# 'pong'
# module.params['data']
# 'pong'
# module.params['data']

# Generated at 2022-06-25 03:01:33.213918
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 03:01:40.066569
# Unit test for function main
def test_main():

    var_1 = AnsibleModule( argument_spec = dict( data = dict( type = str, default = pong ) ), supports_check_mode = True )

    var_2 = var_1.params[data]

    if var_2 == crash:
        raise Exception(boom)

    var_3 = dict( ping = var_1.params[data] )

    var_1.exit_json(**var_3)


# Generated at 2022-06-25 03:01:45.877382
# Unit test for function main
def test_main():
    var_0 = dict(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)
    var_1 = AnsibleModule(var_0)
    var_2 = var_1.params['data']
    var_3 = var_2 == 'crash'
    if var_3:
        raise Exception("boom")
    var_4 = dict()
    var_5 = var_1.params['data']
    var_4['ping'] = var_5
    var_6 = var_4
    var_1.exit_json(**var_6)


# Generated at 2022-06-25 03:01:49.808221
# Unit test for function main
def test_main():
    import json
    import xmltodict
    def test_1(var_0):
        assert var_0 == 'pong'
        print(var_0)
    def test_2(var_0):
        assert var_0 == 'crash'
        print(var_0)
    var_0 = main()
    test_1(var_0)
    var_0 = main()
    test_2(var_0)
    # print(json.dumps(xmltodict.parse(var_0)))
# Test function main

# Generated at 2022-06-25 03:01:50.573303
# Unit test for function main
def test_main():
    var_1 = main()

# Generated at 2022-06-25 03:01:54.980202
# Unit test for function main
def test_main():
    assert main(["PingModule.py"]) == 0
    assert main(["PingModule.py", "", ""]) == 0
    assert main(["PingModule.py", "data"]) == 0
    # If test fails, type "pytest"
    assert main(["PingModule.py", "'pong'"]) == 0
    assert main(["PingModule.py", "'crash'"]) == 0

# Generated at 2022-06-25 03:01:59.323721
# Unit test for function main
def test_main():
    var_1 = main()
    # ValueError should be thrown when "data" is "crash"
    try:
        var_2 = main()
    except ValueError :
        var_2 = 0
    finally:
        pass
    # ValueError should be thrown when "data" is undefined
    try:
        var_3 = main()
    except ValueError :
        var_3 = 0
    finally:
        pass

# Generated at 2022-06-25 03:02:00.465676
# Unit test for function main
def test_main():
    print("Unit testing function main")

    test_case_0()

main()

# Generated at 2022-06-25 03:02:06.499862
# Unit test for function main
def test_main():
    print('Testing function main')
    dummy_data_0 = {}
    dummy_data_0["args"] = {"data": dummy_data_0}
    dummy_data_0["changed"] = True
    dummy_data_0["ping"] = 'pong'
    dummy_data_0["_ansible_check_mode"] = False
    dummy_data_0["_ansible_diff"] = False
    dummy_data_0["_ansible_verbosity"] = 0
    dummy_data_0["_ansible_no_log"] = False
    
    test_case_0()
    test_main()

# Generated at 2022-06-25 03:02:08.081450
# Unit test for function main
def test_main():
    # Initialize test environment
    var_0 = main()

    # Teardown test environment
    print("Test Environment teardown...")

# Generated at 2022-06-25 03:05:19.302697
# Unit test for function main
def test_main():
    assert var_0 =="""{'changed': False, 'ping': 'pong'}""", "Module %s called with %s did not actually return %s"


# Generated at 2022-06-25 03:05:20.492105
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == None


# Generated at 2022-06-25 03:05:22.686174
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == test_case_0()



# Generated at 2022-06-25 03:05:24.339075
# Unit test for function main
def test_main():
    test_case_0()


# Run unit test against main function
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:05:25.637470
# Unit test for function main
def test_main():
    var_1 = 1
    main()
    assert var_1 == 1


# Generated at 2022-06-25 03:05:25.988475
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 03:05:27.321659
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-25 03:05:27.931125
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 03:05:28.580998
# Unit test for function main
def test_main():
    test_case_0()


# main()

# Generated at 2022-06-25 03:05:35.815054
# Unit test for function main
def test_main():
    file_name = os.path.basename(__file__)
    case_0 = {'data': 'crash', 'assert_status': 50}

    # Arrange
    case_arr = [case_0]
    for case in case_arr:
        try:
            # Act
            main.__name__ = 'main'
            main(case)
            assert 0 != case['assert_status'], "Execution status should be failure"
        except Exception as e:
            if case['assert_status'] != 50:
                raise e
            pass
        finally:
            pass
