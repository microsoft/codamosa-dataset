

# Generated at 2022-06-23 03:58:22.303074
# Unit test for function main
def test_main():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        f.write(b'''{
  "changed": false,
  "invocation": {
    "module_args": {
      "data": "pong"
    }
  },
  "ping": "pong"
}''')
        f.flush()
        main()

# Generated at 2022-06-23 03:58:33.736748
# Unit test for function main
def test_main():
    import functools
    import json

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import PropertyMock
    from ansible.module_utils._text import to_bytes

    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import to_list

    # We need to mock the AnsibleModule class before importing the main module
    with patch('ansible.module_utils.common.AnsibleModule', autospec=True):
        import ansible_collections.ansible.netcommon.plugins.module_utils.network.common.ping as ping



# Generated at 2022-06-23 03:58:37.773017
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

test_main()

# Generated at 2022-06-23 03:58:42.076075
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

    # Unit test for function main

# Generated at 2022-06-23 03:58:53.749916
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )

    # Mock pytest parametrize call
    def parametrize(param):
        return (
            # Called on the first pass through the loop
            (dict(ping_type=args['ping_type'])),
        )

    # Mock the module
    module_mock = Mock()
    module_mock.params = args
 
    # Mock AnsibleModule.exit_json
    def exit_json(ping):
        assert ping == 'pong'

    result = dict(
        ping='pong'
    )
    module_mock.exit_json = exit_json
 
    # Mock the function
    function_mock = Mock()
    function_mock.return_value = result

    # Mock the module

# Generated at 2022-06-23 03:58:59.159556
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # ping of pong should result in success
    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 03:59:06.199395
# Unit test for function main
def test_main():
    # Test case with no parameters
    args = {}
    rval = main(args)
    assert rval['ping'] == 'pong'

    # Test case with data = crash
    args = dict(data='crash')
    module = AnsibleModule(argument_spec=args)
    with pytest.raises(Exception) as excinfo:
        main(args, '1.1.1.1', module)
    assert 'boom' in str(excinfo.value)

    # Test case with data = foo
    args = dict(data='foo')
    rval = main(args)
    assert rval['ping'] == 'foo'

# Generated at 2022-06-23 03:59:14.135292
# Unit test for function main
def test_main():
    import json
    import errno
    import os
    import subprocess
    import sys
    import pytest

    if not os.path.exists('/tmp/ansible_ping_payload.json'):
        pytest.skip("ping module did not create the file")

    with open('/tmp/ansible_ping_payload.json') as payload_fd:
        payload = json.load(payload_fd)

    assert payload['data'] == 'pong'

# Generated at 2022-06-23 03:59:17.108135
# Unit test for function main
def test_main():
    # Mock Module
    module = Mock()
    setattr(module, "params", {"data": "test"})

    # Execute main() function
    main()

# Generated at 2022-06-23 03:59:29.937264
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

import json
print(json.dumps({
  "changed": False,
  "ping": "pong"
}))
"""

# For modified module that lacks documentation
RUN_OUTPUT_MODULE_LACKS_DOCUMENTATION_FAILED = b"""
#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2012, Michael DeHa

# Generated at 2022-06-23 03:59:32.071814
# Unit test for function main
def test_main():
    main()
    main(data='ping')
    main(data='crash')

# Generated at 2022-06-23 03:59:37.906831
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-23 03:59:40.458127
# Unit test for function main
def test_main():
    module = Mock(params={'data': 'pong'})
    module.exit_json = Mock()
    main()
    module.exit_json.assert_called_with(ping='pong')

# Generated at 2022-06-23 03:59:40.841547
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:59:44.454698
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.basic import AnsibleModule

    data = {
        "ANSIBLE_MODULE_ARGS": {
            "data":"testdata"
        }
    }
    module = AnsibleModule(data)
    module.exit_json = lambda **kwargs: True
    main()

# Generated at 2022-06-23 03:59:53.035857
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.exit_json.call_count == 0

    assert module.params == dict(
        data='pong',
    )

    assert module.params['data'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json.assert_called_once_with(**result)

# Generated at 2022-06-23 03:59:56.862799
# Unit test for function main
def test_main():
    m = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert m == main()


# Generated at 2022-06-23 04:00:03.906735
# Unit test for function main
def test_main():
    # Test with correct arguments
    module = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong'}})
    assert(main() is None)

    # Test with incorrect arguments
    module = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'crash'}})
    assert(main() is None)

# Generated at 2022-06-23 04:00:16.769170
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import json
    import sys

    # Insert the common functions used by the Ansible modules at the beginning of the python path.
    # This is done to allow testing of the functions using `pytest test_utils/`
    sys.path.insert(0, '../../../utils/')
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic

    # Change stdout so that it is possible to check the output of the function.
    saved_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    # Create a function to emulate `AnsibleModule`

# Generated at 2022-06-23 04:00:31.488231
# Unit test for function main
def test_main():
    import sys
    import warnings
    import ansible.module_utils.basic
    import ansible.module_utils.network.netcommon.net_ping
    import ansible.module_utils.connection
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.platform

    args = dict(
        data='pong'
    )
    if 'id' in args:
        del args['id']
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ansible.module_utils.network.netcommon.net_ping.os = None
        ansible.module_utils.basic._ANSIBLE_ARGS = ansible.module_utils.basic._ANSIBLE_ARGS

# Generated at 2022-06-23 04:00:40.306347
# Unit test for function main
def test_main():
    args = dict(
        data='test'
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test pre-conditions
    assert module.params['data'] == 'pong'
    assert module.params['check_mode'] == False
    # Execute function under test
    main()
    # Test post-conditions
    # The function exits with the arguments passed to exit_json()
    assert module._result['ping'] == args['data']
    assert module._result['changed'] == False
    assert module._result['ansible_facts'] == {}
    assert module._result['ansible_modules'] == {}
    assert module._result['invocation'] == {}
    assert module

# Generated at 2022-06-23 04:00:43.976691
# Unit test for function main
def test_main():
    args = {
        'data': 'pong',
    }
    module = AnsibleModule(**args)
    with pytest.raises(Exception):
        main(module)

    args = {
        'data': 'pong',
    }
    module = AnsibleModule(**args)
    result = main(module)
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:00:47.374262
# Unit test for function main
def test_main():
    # Arrange
    params = dict(
            data=dict(type='str', default='pong'),
        )
    module = AnsibleModule(
        argument_spec=params,
        supports_check_mode=True
    )
    print("main")
    # Act
    main()
    # Assert
    # assert 1 == 1, "True is not equal to True"

# Generated at 2022-06-23 04:00:53.585662
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:01:04.560136
# Unit test for function main
def test_main():

    # Test ping module with default value
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(ping=module.params['data'])

    assert result == {'ping': 'pong'}

    # Test ping module when the data parameter is set to crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'crash'

test_main()

# Generated at 2022-06-23 04:01:10.724025
# Unit test for function main
def test_main():
    print('Test started')
    args = dict(data = 'ping', check_mode = True)
    main()
    print('Test passed')

# Generated at 2022-06-23 04:01:13.665553
# Unit test for function main
def test_main():
    argument_spec = {'data': {'type': 'str', 'default': 'pong'}}
    module = AnsibleModule(supports_check_mode=True, argument_spec=argument_spec)
    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 04:01:23.695024
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        with patch.object(AnsibleModule, 'run_command') as mock_run_command:
            main()

            expected_result = dict(
                ping='pong',
            )

            mock_exit_json.assert_called_once_with(**expected_result)

# Generated at 2022-06-23 04:01:34.222942
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    import tempfile
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.basic import AnsibleFallbackNotFound

    # Test with a crash
    try:
        module.params['data'] = 'crash'
        main()
    except:
        err = get_exception()
        assert 'boom' in str(err)

    # Test with a non-crash
    try:
        module.params['data'] = 'test'
        result = main()
        assert result['ping'] == 'test'
    except:
        err = get_exception()

# Generated at 2022-06-23 04:01:35.628706
# Unit test for function main
def test_main():
    data= {'data': 'test'}
    result = main()
    assert result == data

# Generated at 2022-06-23 04:01:41.243354
# Unit test for function main
def test_main():
    # Test that if data parameter is set to "crash" an Exception is raised
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        main()
    except Exception as exception_raised:
        assert "boom" in str(exception_raised)

# Generated at 2022-06-23 04:01:48.653382
# Unit test for function main
def test_main():
    # without parameters
    result = ping({"data": "pong"})
    assert type(result) is dict
    assert len(result) == 1
    assert "ping" in result.keys()
    assert result["ping"] == "pong"
    # with parameters
    result = ping({"data": "ping"})
    assert type(result) is dict
    assert len(result) == 1
    assert "ping" in result.keys()
    assert result["ping"] == "ping"
    # with crash
    try:
        result = ping({"data": "crash"})
        assert True == False
    except:
        assert True == True

# Generated at 2022-06-23 04:01:49.938492
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:01:57.051247
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'
    assert module.check_mode == True


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 04:02:08.430321
# Unit test for function main
def test_main():
    # make a fake module for ansible
    fake_module = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # define mock output for ansible
    class MockExitJson(object):
        def __init__(self, myoutput):
            self.output = myoutput
        def exit_json(self, **kwargs):
            print(self.output)

    # use mock outputs
    oldexitjson = AnsibleModule.exit_json
    AnsibleModule.exit_json = MockExitJson

    # execute the module
    main()

    # replace with the orignial exit_json
    AnsibleModule.exit_json = oldexitjson

# Generated at 2022-06-23 04:02:11.675692
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0


# Generated at 2022-06-23 04:02:14.200796
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # Test passing of params

    # Test check_mode

    # Test diff_mode

    # Test platform

# Generated at 2022-06-23 04:02:22.363175
# Unit test for function main
def test_main():
    params = {'data': 'pong'}
    result = {'ping': 'pong'}

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = params

    try:
        main()
    except Exception as e:
        if "boom" in str(e):
            module.fail_json(msg="Induced exception")
        else:
            raise e

    assert module.exit_json.called
    assert module.exit_json.call_args == call(**result)

# Generated at 2022-06-23 04:02:25.870331
# Unit test for function main
def test_main():
    my_mock = MagicMock()
    my_mock.params = dict()
    my_mock.params['data'] = 'pong'
    my_mock.return_value = dict(
        ping = "pong",
    )
    result = main(my_mock)
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:02:27.592048
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:02:31.663722
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type = 'str', default = 'pong')
        )
    )
    assert "pong" == module.params['data']
    assert "boom" != module.params['data']

# Generated at 2022-06-23 04:02:33.934914
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print("Exception: %s" % e)

# Generated at 2022-06-23 04:02:40.365726
# Unit test for function main
def test_main():
    bad_params = dict(
        data=dict(type='str', default='pong')
    )
    ok_params = dict(
        data=dict(type='str', default='crash')
    )

    # Check that a crash by data is reported as a crash
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-23 04:02:46.026904
# Unit test for function main
def test_main():
    """Test main() function"""
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = main(module)
    assert result == dict(ping='pong')



# Generated at 2022-06-23 04:02:55.455217
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible.module_utils import basic

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an
        exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise

# Generated at 2022-06-23 04:03:02.626203
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:03:06.931639
# Unit test for function main
def test_main():
    data = dict(ping='pong', data='pong')
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
        ))
    module.exit_json(**data)

# Generated at 2022-06-23 04:03:11.616892
# Unit test for function main
def test_main():
    fake_params = {'data': 'crash'} 
    m = AnsibleModule(fake_params)
    assert m
    assert m.params == fake_params
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-23 04:03:13.791189
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:03:19.119607
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        main()
    except Exception as e:
        assert "boom" in str(e)


# Generated at 2022-06-23 04:03:26.284591
# Unit test for function main
def test_main():
    import pytest
    import os
    import json
    import re

    testfile = os.path.join(os.getcwd(), "test_ping.json")
    with open(testfile, 'rb') as f:
        data = json.load(f)
        # test_data_1 returns pong
        result = main(data[0]["input"])
        assert result['ping'] == "pong"
        # test_data_2 returns data: crash
        with pytest.raises(Exception):
            result = main(data[1]["input"])

# Generated at 2022-06-23 04:03:28.113204
# Unit test for function main
def test_main():
    # assertion of the structure which is returned from the main function
    assert main() is None

# Generated at 2022-06-23 04:03:41.377889
# Unit test for function main
def test_main():
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Make a copy of our testdata JSON that we can mess with to
    # test different scenarios
    with open(path, "w+") as f:
        f.write(json.dumps(module_args))

    f, temp_path = tempfile.mkstemp()
    oc = Command('/usr/bin/ansible-playbook',
           'ansible-test.yaml',
           '-i', 'localhost,' + path,
           '--connection', 'local',
           '-e', 'host_key_checking=False',
           '-vvvv'
          )
    result = oc.run()
    if result.rc != 0:
        print('Got an error rc %d' % result.rc)
   

# Generated at 2022-06-23 04:03:47.633527
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    def make_args(data='pong'):
        return dict(
            ansible_facts=dict(),
            ansible_check_mode=False,
            ansible_diff_mode=True,
            params=dict(data=data),
            check_mode=False,
            _ansible_debug=False,
            _ansible_color=False,
            _ansible_remote_tmp='/private/tmp/ansible-tmp-1505863208.75-137204936081892/',
        )

    with pytest.raises(Exception) as exc:
        main()
    assert 'missing required arguments' in str(exc)
    with pytest.raises(Exception) as exc:
        main(**make_args())