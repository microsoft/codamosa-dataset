

# Generated at 2022-06-23 03:58:22.315462
# Unit test for function main

# Generated at 2022-06-23 03:58:25.443625
# Unit test for function main
def test_main():
    # TODO: Improve the unit test to cover more scenarios
    pass

# Generated at 2022-06-23 03:58:35.331569
# Unit test for function main
def test_main():
    # set up required arguments
    module_args = dict()
    module_args.update({'data': {'type': 'str', 'default': 'pong'}, })
    # set up args
    args = dict()
    # The AnsibleModule class takes a single argument which must be a dict.
    # This dict is later used to load a module by Ansible
    # The dict is initialized with the necessary parameters, in this case
    # there are only two parameters required, the argument_spec and the
    # bypass_checks
    # The argument_spec is used by Ansible to create the arguments for the
    # module
    # Bypass Checks is a bool that is used as a flag to let the module know
    # that it should skip calling _check_libs and _check_mode
    # (bypass_checks=True)

# Generated at 2022-06-23 03:58:36.752858
# Unit test for function main
def test_main():
    ping = main()
    assert ping == pong

# Generated at 2022-06-23 03:58:40.021990
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-23 03:58:42.058924
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.ping import main

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == dict(ping=module.params['data'])

# Generated at 2022-06-23 03:58:47.260902
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 03:58:53.236089
# Unit test for function main
def test_main():
    #
    # required args only
    #
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = module.params['data']
    assert result == 'pong', 'expected default value for parameter `data`'


# Generated at 2022-06-23 03:59:00.074144
# Unit test for function main
def test_main():

    # Test that pong is the result with no input param
    params = {
        'data': 'pong',
    }
    result = main(params)
    assert result['ping'] == 'pong', 'Did not return expected pong value'

    params = {
        'data': 'boom',
    }
    with pytest.raises(Exception) as excinfo:
        result = main(params)
    assert 'boom' in str(excinfo.value)

# Generated at 2022-06-23 03:59:05.306689
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert(result == dict(ping='pong'))

# Generated at 2022-06-23 03:59:17.583497
# Unit test for function main
def test_main():
    import ansible.module_utils
    mod = ansible.module_utils.basic.AnsibleModule(
        argument_spec='dict(data=dict(type=str, default=pong))'
    )
    mod.exit_json = lambda a: None

    # Test non-crash return
    mod.params['data'] = 'pong'
    main()
    assert mod.fail_json.called == False

    # Test crash return
    mod.params['data'] = 'crash'
    main()
    #raise Exception(mod.fail_json.called)
    assert mod.fail_json.called == True
    #assert mod.fail_json.call_args ==

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 03:59:26.904457
# Unit test for function main
def test_main():
    import sys
    import json
    from subprocess import Popen, PIPE
    # Capture the result to examine later
    p = Popen([sys.executable, 'ping.py', '-T', AppTest.default_python_interpreter, '-a', 'data=hello world'], stdout=PIPE)
    out, err = p.communicate()
    results = json.loads(out)
    assert(results['ansible_facts']['ping'] == 'hello world')


# Unit test to check module return status

# Generated at 2022-06-23 03:59:32.356775
# Unit test for function main
def test_main():
  # replace sys.argv for unit test purpose
  sys.argv = [ 'ping',
               '{"ansible_module_args": {"data": "crash"}}' ]
  try:
    with pytest.raises(Exception) as excinfo:
      main()
    assert str(excinfo.value) == 'boom'
  finally:
    # restore sys.argv
    sys.argv = sys_argv_ori

# Generated at 2022-06-23 03:59:32.993663
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:59:44.998094
# Unit test for function main
def test_main():
    # HACK: Ensure path for ansible included for imports
    import os
    os.sys.path.append(
        os.path.join(os.path.dirname(os.path.realpath(__file__)), ".."))
    from ansible.module_utils.basic import AnsibleModule

    import mock
    import sys

    def mock_get_bin_path(*args, **kwargs):
        return ''

    def mock_load_file_common_arguments(*args, **kwargs):
        return dict(
            data=dict(type='str', default='pong'),
        )

    def mock_exit_json(*args, **kwargs):
        sys.exit(0)

    def mock_fail_json(*args, **kwargs):
        sys.exit(1)


# Generated at 2022-06-23 03:59:50.552983
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

# Generated at 2022-06-23 03:59:56.144839
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)
    return result

# Generated at 2022-06-23 03:59:59.047276
# Unit test for function main
def test_main():
    args = dict(
        data = 'pong'
    )
    # this test is too simple to bother with assert style
    main()
    print("Test completed")

# Generated at 2022-06-23 04:00:04.377563
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 04:00:06.015860
# Unit test for function main
def test_main():
    result = main()
    assert type(result) == dict
    assert "ping" in result.keys()

# Generated at 2022-06-23 04:00:06.574438
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:00:12.524917
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        ),
        supports_check_mode=True
    )
    
    output = main(module)
    assert output['ping'] == 'pong'


# Generated at 2022-06-23 04:00:13.104297
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:00:21.479346
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test case1
    print("Test case1")
    assert module.params['data'] == 'pong'

    # Test case2
    print("Test case2")
    module.params['data'] = 'crash'
    print("Expect Exception error message : boom")
    try:
        assert main()
    except Exception as e:
        print("Exception : boom")
        assert str(e) == "boom"

# Generated at 2022-06-23 04:00:22.469431
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:00:22.945114
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 04:00:24.620491
# Unit test for function main
def test_main():
    ping = AnsibleModule({'data': 'pong'},
        supports_check_mode=True)
    assert(ping.params['data'] == 'pong')

# Generated at 2022-06-23 04:00:26.543747
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 04:00:35.482161
# Unit test for function main
def test_main():
    def fake_module(**kwargs):
        class FakeModule(object):
            def __init__(self, *args, **kwargs):
                self.params = kwargs
                self.check_mode = False
                self.exit_json = FakeModule.json_exit

            @staticmethod
            def json_exit(**kwargs):
                FakeModule.exited = True
                FakeModule.kwargs = kwargs

        module = FakeModule(**kwargs)
        return module

    def fake_exit_json(**kwargs):
        FakeModule.exited = True
        FakeModule.kwargs = kwargs

    FakeModule.params = {}
    FakeModule.exited = False


# Generated at 2022-06-23 04:00:38.159755
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)
        assert 0 == 1
    else:
        assert 1 == 1

# Generated at 2022-06-23 04:00:38.726264
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:00:41.799107
# Unit test for function main
def test_main():
    module = AnsibleModule({}, {})
    assert main(module) == {'ping': 'pong'}

# Generated at 2022-06-23 04:00:48.804401
# Unit test for function main
def test_main():

    argument_spec=dict(
            data=dict(type='str', default='pong')
        )

    module = AnsibleModule(argument_spec=argument_spec)
    result = dict(
        ping=module.params['data'],
    )

    # Check if is crashing the module
    module.params['data'] = "crash"
    module.exit_json(changed=False, meta=result)

# Generated at 2022-06-23 04:00:52.944632
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:01:04.272086
# Unit test for function main
def test_main():
  import ansible.modules.names as names
  reload(names)
  import ansible.modules.tracer_names as tracer_names
  reload(tracer_names)
  import ansible.modules.codes as codes
  reload(codes)
  import ansible.modules.tracer_codes as tracer_codes
  reload(tracer_codes)
  import ansible.modules.utils as utils
  reload(utils)

  # pprint(names.get_names())
  # pprint(names.get_names(cached=False))
  names_dict = names.get_names(cached=False)
  # pprint(tracer_names.get_tracer_names())
  # pprint(tracer_names.get_tracer_names(cached=False))

# Generated at 2022-06-23 04:01:11.805955
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json(changed=False, ping="pong")

# Generated at 2022-06-23 04:01:13.190115
# Unit test for function main
def test_main():
    assert main() == None, "If test is running, main should return None"


# Generated at 2022-06-23 04:01:16.825545
# Unit test for function main
def test_main():

    # test for simple ping
    args = dict()
    args['data'] = 'pong'
    args_ping = args['data']
    main()
    assert args_ping == 'pong'
    # test for crash
    args = dict()
    args['data'] = 'crash'
    args_ping = args['data']
    main()
    assert args_ping == "boom"

# Generated at 2022-06-23 04:01:21.015632
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    ret = main(module)
    assert ret == {'ping': 'pong'}


# Generated at 2022-06-23 04:01:21.903632
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:01:34.075087
# Unit test for function main
def test_main():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.called_exit_json = False

        def exit_json(self, **kwargs):
            self.called_exit_json = True
            self.exit_json_kwargs = kwargs

    # Test normal behavior
    m_module = MockModule(data='pong')
    main()
    assert m_module.called_exit_json
    assert m_module.exit_json_kwargs['ping'] == 'pong'

    # Test induced exception
    m_module = MockModule(data='crash')
    try:
        main()
        assert not m_module.called_exit_json
    except Exception as e:
        assert e.message == 'boom'
        assert not m

# Generated at 2022-06-23 04:01:36.086832
# Unit test for function main
def test_main():
    test_args = {}
    test_args['data'] = 'pong'
    result = main(test_args)
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:01:45.786985
# Unit test for function main
def test_main():
    module_mock = Mock(params={'data': 'crash'})
    module_mock.exit_json.return_value = None
    module_mock.check_mode = False

    try:
        main()
        assert False, 'Should have thrown an error'
    except Exception as e:
        assert str(e) == 'boom'

    module_mock = Mock(params={'data': 'pong'})
    module_mock.exit_json.return_value = None
    module_mock.check_mode = False
    main()

    assert module_mock.exit_json.called_once()
    assert module_mock.exit_json.call_args == call({'ping': 'pong'})

# Generated at 2022-06-23 04:01:48.962802
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0
    finally:
        pass

# vim:ft=python ts=8 sw=4 sts=4 et

# Generated at 2022-06-23 04:01:49.989531
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:01:56.600552
# Unit test for function main
def test_main():
    test_header = 'Zsxdcftvgbnhjmk,l'
    input_data = {
        'data': '{}'.format(test_header)
    }
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    main()
    assert test_module.params['data'] == test_header

# Generated at 2022-06-23 04:02:04.129716
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        with patch.object(AnsibleModule, 'fail_json') as mock_fail_json:
            with patch.object(AnsibleModule, 'params') as mock_params:
                mock_params.return_value = dict(
                )
                main()
                assert mock_exit_json.called
                assert not mock_fail_json.called
                assert mock_params.called

# Generated at 2022-06-23 04:02:07.323715
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main()

# Generated at 2022-06-23 04:02:10.376724
# Unit test for function main
def test_main():
    args = dict(
        data="pong"
    )

    result = main(args)
    assert result['changed'] is False
    assert result['ping'] == "pong"

# Generated at 2022-06-23 04:02:11.968831
# Unit test for function main
def test_main():
  data = 'pong'
  ret = main()
  assert data == ret['ping']

# Generated at 2022-06-23 04:02:19.316769
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        with patch.object(AnsibleModule, 'fail_json') as fail_json:
            with patch.object(AnsibleModule, 'params', {'data': 'pong'}):
                main()
                assert exit_json.call_count == 1
                assert fail_json.call_count == 0
                assert exit_json.call_args[0] == (dict(ping='pong'),)


# Generated at 2022-06-23 04:02:26.506731
# Unit test for function main
def test_main():
    test_manager = core.module_loader.ModuleLoader()
    test_shared_loader = shared.module_loader.ModuleLoader(
        path_list=[os.path.join(os.path.dirname(__file__), "../")]
    )

    test_module = test_manager.load_module('ansible.builtin.ping', None,
            module_loader=test_shared_loader)

    invocation = '''
---
data: pong
'''

    bytes_data = to_bytes(invocation, errors='surrogate_or_strict')
    set_module_args(json.loads(bytes_data))
    result = main()

    assert result['changed'] is False
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:02:33.222674
# Unit test for function main
def test_main():
    test_ansible_args = dict(
        ANSIBLE_MODULE_ARGS=dict(
            data="bar",
        )
    )
    test_ansible_result = dict(
        ping="bar",
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json(**test_ansible_result)

# Generated at 2022-06-23 04:02:35.554718
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        assert main() == None

# Generated at 2022-06-23 04:02:40.267330
# Unit test for function main
def test_main():

    # Skip the unit test if this is not a linux system
    import platform
    if platform.system() != 'Linux':
        return None

    os.system("pwd")
    print("Calling unit test main() function")
    main()


# Function unit test
test_main()

# Generated at 2022-06-23 04:02:44.290181
# Unit test for function main
def test_main():
    module_args = dict(
            data="testdata"
    )

    retval = main(module_args)  

    assert retval['ping'] == 'testdata'

# Generated at 2022-06-23 04:02:54.742081
# Unit test for function main
def test_main():
    # Save the 'ansible.module_utils.basic.AnsibleModule' class
    # so we can restore it after cleaning up the module-under-test
    ansible_module_utils_basic_AnsibleModule = ansible.module_utils.basic.AnsibleModule

    # Test with a completely empty response from the server
    req = HttpRequest(None, None, None, None, None)
    bad_response = req.getresponse()
    ansible.module_utils.basic.AnsibleModule = Mock(return_value=Mock(params=dict(data=None), exit_json=Mock(side_effect=SystemExit)))
    with pytest.raises(SystemExit):
        main()

    # Test with a bad response from the server

# Generated at 2022-06-23 04:02:58.246465
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule({'data': 'pong'}, check_invalid_arguments=False)
    assert main() == None

# Generated at 2022-06-23 04:02:59.073457
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:03:11.796991
# Unit test for function main
def test_main():
    # Convert the test cases into a list.
    test_cases = [
        # Format:
        #   [expected_return, arg1, arg2, arg3, ...]
        #   For example, from ping: main(data='crash')
        [{"failed": True, "msg": "boom"}, {'data': 'crash'}],
        # This one does not work so well with the new module_utils.basic
        # syntax.  Will fix for Ansible 2.4 probably.
        # [{"ping": "pong"}, {}],
    ]

    # Set up the module.
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None

# Generated at 2022-06-23 04:03:17.381158
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() is None

# Generated at 2022-06-23 04:03:27.092316
# Unit test for function main
def test_main():
    import platform
    import sys
    import tempfile

    import pytest

    from ansible.module_utils.six import b, u

    class MockActionModule(object):
        def __init__(self, args):
            self.argument_spec = dict(
                data=dict(type='str', default=u('pong')),
            )

            self.connection = 'local'
            self.check_mode = False
            self.diff_mode = False
            self.platform = platform.system()
            self.args = args

        def get_bin_path(self, executable, opts=None, required=False):
            if required:
                pytest.fail('Tried to get bin path of executable')
            return executable

        def exit_json(self, **kwargs):
            self.exception = None

# Generated at 2022-06-23 04:03:27.874229
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:03:39.228033
# Unit test for function main
def test_main():
    args = {
        'data' : [
            'pong',
            'crash'
        ]
    }
    for arg in args['data']:
        try:
            with patch.dict(ansible.builtin.ping.__opts__, {'test': False}):
                rc = ansible.builtin.ping.main()
        except SystemExit as exception:
            if arg == 'pong':
                result = {
                    "ping": "pong"
                }
                if result == exception.code:
                    return True
            else:
                if arg == 'crash':
                    raise Exception("boom")
    return False

# Generated at 2022-06-23 04:03:44.752522
# Unit test for function main
def test_main():
    mock_module = Mock(return_value=None)
    try:
        with patch.dict(ansible.builtin.ping.__dict__, {'AnsibleModule': mock_module}):
            ansible.builtin.ping.main()
    except Exception as err:
        print(str(err))
        assert False

ansible.builtin.ping.main()

# Generated at 2022-06-23 04:03:45.321821
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 04:03:52.678137
# Unit test for function main
def test_main():
    with patch(MODPATH + 'AnsibleModule') as mock_module:
        with patch(MODPATH + 'os') as mock_os:
            with patch(MODPATH + 'sys') as mock_sys:
                main()
                mock_module().assert_called_once()
                mock_module().exit_json.assert_called_once()
                mock_sys.exit.assert_not_called()

# Generated at 2022-06-23 04:04:04.152806
# Unit test for function main
def test_main():
    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    function = "ansible.module_utils.basic.AnsibleModule"
    with mock.patch(function) as mock_AnsibleModule:
        mock_AnsibleModule.return_value = mock_module
        mock_AnsibleModule.params = {'data':'pong'}
        main()

# Generated at 2022-06-23 04:04:10.265146
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:04:11.076418
# Unit test for function main
def test_main():
    assert main != None

# Generated at 2022-06-23 04:04:11.666375
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:04:14.497036
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict())
    #assert(main(module) == True)
    #assert(main(module) == False)
    pass

# Generated at 2022-06-23 04:04:15.158786
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:04:17.124225
# Unit test for function main
def test_main():
    args = dict(
        data="pong"
    )
    returned = main()
    assert returned == args

# Generated at 2022-06-23 04:04:17.739306
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:04:26.080826
# Unit test for function main
def test_main():
    import sys
    import json

    # Save the original args so we can restore them after processing them in main
    orig_args = list(sys.argv)
    try:
        # Simulate executing this module as a standalone script
        # First argument is always the module filename
        sys.argv = [__file__]

        # set return value for AnsibleModule
        sys.argv.append('{"data": "pong"}')

        # return value for exit_json
        expected_result = {"ping": "pong"}

        # invoke main with the above arguments
        main()
    except SystemExit as inst:
        if inst.args[0] == 0:
            # main exits with status 0 on success
            print("Success")
        else:
            # non-zero return code means failure
            print("Failure")

    # Restore the original

# Generated at 2022-06-23 04:04:29.957485
# Unit test for function main
def test_main():
    ping_test_1 = { "data": "pong" }
    ping_test_2 = { "data": "crash" }

    assert main() == ping_test_1
    assert main() == ping_test_2

# Generated at 2022-06-23 04:04:34.620542
# Unit test for function main
def test_main():
    ping = 'pong'
    data = dict(ping=ping)

    # No attributes set, should return a dict
    m = AnsibleModule(argument_spec=dict())
    m.params['data'] = 'crash'
    assert m.params == dict(data='crash'), 'initial value is wrong'
    m.exit_json(**data) == dict(changed=False, ping='pong'), 'returned value is wrong'

# Generated at 2022-06-23 04:04:38.940684
# Unit test for function main
def test_main():
    err = None
    response = None
    try:
        response = main()
    except Exception as e:
        err = e

    assert err is None
    assert response is not None

# Generated at 2022-06-23 04:04:45.054757
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-23 04:04:48.225232
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == dict(ping=module.params['data'])

# Generated at 2022-06-23 04:04:51.122717
# Unit test for function main
def test_main():
  module = AnsibleModule(dict(data=dict(type='str', default='pong')))
  main()


# Generated at 2022-06-23 04:05:00.487780
# Unit test for function main
def test_main():
    '''
    Test function main
    '''
    from ansible.module_utils.basic import AnsibleModule

    def test_params():
        return dict(
            data=dict(type='str', default='pong'),
        )

    def test_run_command_patch(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return 0, ''

    mp = AnsibleModule(argument_spec=test_params(),
                       supports_check_mode=True)
    mp.run_command = test_run_command_patch

    result = main()

    assert result == mp.exit_json.return_value

# Generated at 2022-06-23 04:05:06.855079
# Unit test for function main
def test_main():
    module_args = {}

    module_args = {}
    module_args.update({'data': 'crash'})
    module  = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    set_module_args(module_args)
    result = main()
    assert result == dict(
        ping='pong',
    )
    module_args = {}
    module_args.update({'data': 'crash'})
    module  = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    set_module_args(module_args)
    result = main()

# Generated at 2022-06-23 04:05:09.202671
# Unit test for function main
def test_main():
    # Make the test fail without updating the results.
    # TODO: Find a way to test set the environment for the module.
    pass

# Generated at 2022-06-23 04:05:12.158235
# Unit test for function main
def test_main():
    test_main.return_value = None
    assert main() is test_main.return_value

# Generated at 2022-06-23 04:05:18.259320
# Unit test for function main
def test_main():
    test = {
        'data': "this is a test value"
    }

    def fake_exit_json(changed=False, **kwargs):
        if 'ping' in kwargs:
            assert kwargs['ping'] == test['data']
        else:
            assert False

    def fake_AnsibleModule(argument_spec, **kwargs):
        assert argument_spec == {
            'data': {'default': 'pong', 'type': 'str'},
        }

        class FakeModule(object):
            def __init__(self, argument_spec, **kwargs):
                pass

            # Fake the module API used
            def exit_json(self, changed=False, **kwargs):
                fake_exit_json(changed=changed, **kwargs)

            # Fake the module API used

# Generated at 2022-06-23 04:05:21.902266
# Unit test for function main
def test_main():
    print("Test main()")
    result = main()
    assert result == 'pong'
    print("Test success")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:05:23.073075
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:05:32.521711
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_iterable

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert isinstance(module.params['data'], str)
    assert isinstance(module.check_mode, bool)

    result = dict(
        ping=module.params['data'],
    )
    assert isinstance(result, Mapping)
    assert isinstance(result['ping'], str)
    assert isinstance(result['_ansible_no_log'], bool)


# Generated at 2022-06-23 04:05:36.876890
# Unit test for function main
def test_main():
    args = dict(
        data = 'notcrash'
    )
    # Fail if AnsibleModule raises an exception
    with pytest.raises(Exception) as excinfo:
        main()
    assert 'boom' not in str(excinfo.value)

# Generated at 2022-06-23 04:05:43.928388
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleMock(AnsibleModule):
        def __new__(mock, *args, **kwargs):
            module = AnsibleModule(*args, **kwargs)
            module.exit_json(a=1, b=2)

    module = AnsibleModuleMock(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
    )
    main()
    module_results = module.results
    assert module_results['ping'] == 'pong'

# Generated at 2022-06-23 04:05:51.160264
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    m.params['data'] = 'crash'
    with pytest.raises(Exception):
        main()

    m.params['data'] = 'pong'
    main()
    assert m.exit_json.called

# Generated at 2022-06-23 04:05:53.482870
# Unit test for function main
def test_main():
  args = {}
  result = main()
  assert result == {'ping': 'pong'}, "Result: %s" % result

# Generated at 2022-06-23 04:05:59.851061
# Unit test for function main
def test_main():
    module_args = {}
    module_args.update({ 'data': 'pong' })
    module = AnsibleModule(argument_spec=module_args)
    result = {}
    result.update({ 'changed': False })
    result.update({ 'ping': 'pong' })
    module.exit_json(**result)

# Generated at 2022-06-23 04:06:09.207483
# Unit test for function main
def test_main():
    # test arguments
    args = dict(
        data=dict(type='str', default='pong'),
    )

    # test results
    results = dict(
        CHANGED=True,
        ping="pong",
    )
    # test exception
    test_exception = dict(
        CHANGED=True,
        ping="crash",
    )

    # test import module
    import os
    import sys
    import types
    import ansible.module_utils.basic
    # test load
    module = types.ModuleType('ansible.builtin.ping')
    module.AnsibleModule = ansible.module_utils.basic.AnsibleModule
    sys.modules["ansible.builtin.ping"] = module
    module.main()
    assert True

# Generated at 2022-06-23 04:06:10.053383
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:06:19.225704
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:06:26.263107
# Unit test for function main
def test_main():
    test_data = {
        '_ansible_check_mode': False,
        '_ansible_diff': False,
        '_ansible_no_log': False,
        'ansible_module_name': 'ping',
        'data': 'pong',
    }
    ansible_mod = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    ansible_mod.params = test_data
    result = main()
    expected_result = dict(changed=False, ping='pong')
    assert result == expected_result

# Generated at 2022-06-23 04:06:31.888497
# Unit test for function main
def test_main():
    # Setup test conditions
    with patch.dict(builtin_ping.__dict__, {'AnsibleModule': mock}):
        with patch.dict(mock.__dict__, {'exit_json': mock}):
            # Test function
            main()
            # Test conditions
            mock.assert_called_with(
                argument_spec={'data': {'type': 'str', 'default': 'pong'}},
                supports_check_mode=True
            )

            if module.params['data'] == 'crash':
                raise Exception("boom")

            result = dict(
                ping = module.params['data'],
            )

            mock.assert_called_with(**result)

# Generated at 2022-06-23 04:06:41.556604
# Unit test for function main
def test_main():
    test_module_path = '/home/johnpb/ansible/test_ping_module/test/unit/test_ping.py'
    test_module_name = 'test_ping'
    # Start
    test_host = 'localhost'
    test_port = 22
    test_username = 'johnpb'
    test_password = 'boba'
    test_connection = 'local'
    test_data = 'pong'
    test_check_mode = False
    test_diff_mode = False
    test_platforms = ['posix']
    # Test 1
    print('TEST 1')
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=test_check_mode
    )


   

# Generated at 2022-06-23 04:06:44.380947
# Unit test for function main
def test_main():
    import pytest
    import sys
    sys.exit(pytest.main(["-s", __file__]))

# Generated at 2022-06-23 04:06:45.029553
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:06:52.541132
# Unit test for function main
def test_main():
    # AnsibleModule
    # https://github.com/ansible/ansible/blob/8c7a9f86b855f7e1e01a8f7c699a637132745aef/lib/ansible/module_common.py#L433
    module_args = dict(data='ping')
    m = AnsibleModule(**module_args)
    assert dict(ping='ping') == main()

# Generated at 2022-06-23 04:06:55.506693
# Unit test for function main
def test_main():
    # Find me
    # Find me
    # Find me
    print('Hello')
    # Find me
    return True


# Generated at 2022-06-23 04:06:59.344356
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = module.exit_json(**dict(
        ping=module.params['data'],
    ))
    assert result == 0, "Did not pass exception test"

# Generated at 2022-06-23 04:07:10.816165
# Unit test for function main
def test_main():
    import json
    import pytest

    class NullConnection(object):
        def put_file(self, *args, **kwargs):
            pass

        def fetch_file(self, *args, **kwargs):
            pass

        def close(self):
            pass

        def connect(self, *args, **kwargs):
            pass
    conn = NullConnection()
    conn._shell = None
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils._text import to_bytes, to_text

# Generated at 2022-06-23 04:07:22.304646
# Unit test for function main
def test_main():
    # Ensure ansible.module_utils.basic.module_common.AnsibleModule instantiated with correct args
    assert main.__defaults__ == (None,
                                 None,
                                 None,
                                 {'data': {'type': 'str', 'required': False, 'default': 'pong', 'description': "Data to return for the C(ping) return value.\nIf this parameter is set to C(crash), the module will cause an exception."},
                                  'supports_check_mode': True},
                                 None,
                                 None,
                                 None,
                                 None,
                                 None,
                                 None,
                                 None,
                                 None,
                                 None)

# Generated at 2022-06-23 04:07:24.902116
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson) as exec_info:
        main()
    assert usage in str(exec_info.value)


# Generated at 2022-06-23 04:07:25.709991
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:07:36.097643
# Unit test for function main
def test_main():
    from ansible.module_utils.pycompat24 import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=False
    )

    try:
        if module.params['data'] == 'crash':
            raise Exception("boom")
    except Exception as e:
        module.fail_json(msg=repr(e))

    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)



# Generated at 2022-06-23 04:07:46.939442
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from time import time
    ping_start_time = time()
    my_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert my_module.params['data'] == 'pong'
    assert 'ping' in my_module.exit_json, my_module.exit_json.keys()
    assert my_module.exit_json['ping'] == 'pong'
    ping_end_time = time()
    ping_time = ping_end_time - ping_start_time
    assert ping_time < 1, ping_time
    print("\tPing time: %.2f" % ping_time)

# Generated at 2022-06-23 04:07:58.977219
# Unit test for function main
def test_main():
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Unit test for successful run
    data = dict(
        ANSIBLE_MODULE_ARGS=dict(
            data='pong'
        ),
        ansible_facts=dict(
            platform='posix'
        ),
    )
    module = AnsibleModule(**data)
    result = main()
    assert result == 'pong'

    # Unit test for failed run
    data = dict(
        ANSIBLE_MODULE_ARGS=dict(
            data='crash'
        ),
        ansible_facts=dict(
            platform='posix'
        ),
    )
    module = AnsibleModule(**data)
    result = main()
    assert result == 'Crashed'

# Generated at 2022-06-23 04:08:01.113682
# Unit test for function main
def test_main():
    '''
    Unit test for main function
    '''
    main()

# Generated at 2022-06-23 04:08:01.640842
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:08:09.286574
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule = AnsibleModule
    ansible_args = dict(
        data=dict(type='str', default='pong'),
    )

    # Test with data = 'pong'
    set_module_args(dict(ansible_args, data='pong'))
    with pytest.raises(SystemExit) as ci:
        main()
    assert ci.value.code == 0

    out = sys.stdout.getvalue()
    assert 'ping' in out
    assert 'pong' in out

    # Test with data = 'crash'
    set_module_args(dict(ansible_args, data='crash'))
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-23 04:08:14.089041
# Unit test for function main
def test_main():
    def invocation_module_props(module_name, **kwargs):
        module_args = dict(
            data=kwargs.get('data', 'pong'),
        )
        return {
            'argument_spec': dict(
                data=dict(type='str', default='pong'),
            ),
            'module_name': module_name,
            'module_args': module_args,
            'name': module_name,
            'path': 'test_path'
        }

    def test_module_init(mocker, module_name, module_args, result):
        invocation_module = mocker.MagicMock()
        invocation_module.params = module_args
        invocation_module.fail_json = mocker.MagicMock(side_effect=Exception(module_name))

        return invocation_module

   

# Generated at 2022-06-23 04:08:14.675607
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-23 04:08:15.282898
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 04:08:20.709463
# Unit test for function main
def test_main():
    # There's not a lot to test here since the module runs a ping with no
    # parameters.  It's just making sure that the code runs without error.
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        main()
        assert mock_exit_json.call_count == 1
        arguments, _ = mock_exit_json.call_args
    assert arguments[0]['ping'] == 'pong'