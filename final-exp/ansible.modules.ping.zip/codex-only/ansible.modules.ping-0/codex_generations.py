

# Generated at 2022-06-23 03:58:15.912105
# Unit test for function main
def test_main():
    test_main.__name__ = 'test_main'
    # TODO: Implement tests
    assert True


# Generated at 2022-06-23 03:58:21.787079
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    result = dict(
        ping=module.params['data'],
    )
    assert result == {'ping': 'pong'}

# Generated at 2022-06-23 03:58:27.274264
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 03:58:31.400477
# Unit test for function main
def test_main():
  module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

  results = module.exit_json(**result)

  assert(results["ping"] == 'pong')

# Generated at 2022-06-23 03:58:31.977856
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-23 03:58:34.994335
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert test_module.params['data'] == 'pong'

# Generated at 2022-06-23 03:58:36.706344
# Unit test for function main
def test_main():
    # Test that the module doesn't crash.
    main()

# Generated at 2022-06-23 03:58:37.305585
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:58:45.518400
# Unit test for function main
def test_main():
    # Test with no argument
    args = []
    assert True == main(args)

    # Test with a valid argument
    args = ['valid_arg']
    assert True == main(args)

    # Test with a valid argument
    args = ['invalid_arg']
    assert True == main(args)

    # Test with no additional argument
    args = ['invalid_arg']
    assert True == main(args)

    # Test with no additional argument
    args = ['invalid_arg', 'additional_arg']
    assert True == main(args)

# Generated at 2022-06-23 03:58:46.124663
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:58:51.035995
# Unit test for function main
def test_main():
    doc = dict(argument_spec=dict(
               data=dict(type='str', default='pong')),
               supports_check_mode=True)
    module = AnsibleModule(doc, "test")

    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 03:59:02.074970
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3

    def encode_for_python3(x):
        if PY3:
            return to_bytes(x, errors='surrogate_or_strict')
        return x

    # Load the module
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ), supports_check_mode=True)

    # Test with a normal ping response
    # Invoke the function
    result = module.from_json(main())

# Generated at 2022-06-23 03:59:02.830165
# Unit test for function main
def test_main():
    assert main() == 'pong'

# Generated at 2022-06-23 03:59:08.071728
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import json
    import sys
    import tempfile
    import pytest
    import os
    args = '''
{
    "changed": false,
    "ping": "pong"
}
    '''
    args = json.loads(args)
    sys.argv = ['ping.py', '-vvvv', '-b', '-c localhost ansible_connection=local']
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.joint(tmpdir, 'ansible-log.json'), 'w') as ansible_log_file:
            ansible_log_file.write('')
            ansible_log_file.flush()

# Generated at 2022-06-23 03:59:19.426533
# Unit test for function main
def test_main():
    '''
    Test the main function.
    '''
    im_kwargs = {
        'argument_spec': {
            'data': {
                'type': 'str',
                'default': 'pong',
            },
        },
        'supports_check_mode': True,
    }
    m = AnsibleModule(**im_kwargs)
    main(m)
    assert m.exit_json.call_count == 0
    assert m.fail_json.call_count == 1
    assert m.fail_json.call_args[0][0].startswith('boom')
    # TODO: this should probably be standarized better.
    m.exit_json.reset_mock()
    m.fail_json.reset_mock()

# Generated at 2022-06-23 03:59:20.812358
# Unit test for function main
def test_main():
    # No test case when check_mode is true
    assert main() == None

# Generated at 2022-06-23 03:59:28.780758
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import json
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() is None
    out = json.loads(to_bytes(module._result['stdout']))
    assert out['ping'] == 'pong'

# Generated at 2022-06-23 03:59:39.562393
# Unit test for function main
def test_main():

    # Mock input types in order to unit test
    class ansible_module_ping:
        argument_spec = {
            'data': { 'type': 'str', 'default': 'pong'},
        }
        supports_check_mode=True
        def exit_json(self, **kwargs):
            raise Exception('exit_json called: %s' % kwargs)
        def fail_json(self, **kwargs):
            raise Exception('fail_json called: %s' % kwargs)

    # Must mock
    class ansible_module_ping:
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.params['check_mode'] = False
            self.exit_json = lambda **kwargs : None

# Generated at 2022-06-23 03:59:49.920433
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # Example of a working module with some parameters
    module_args = dict(
        ping="pong",
    )

    # Mock module class
    mod = AnsibleModule(module_args)
    # Mock arguments
    mod.params = module_args
    # Mock exit json
    mod.exit_json = lambda x:x

    # call main
    main()

    # example of how to test a module without an exit json function
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        ping="pong",
    )

    # Mock module class
    mod = AnsibleModule(module_args)
    # Mock arguments
    mod.params = module_args

   

# Generated at 2022-06-23 03:59:50.960762
# Unit test for function main
def test_main():
    result = main()

    assert result is not None

# Generated at 2022-06-23 03:59:52.014767
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-23 03:59:52.416258
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:00:00.362248
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    test_module.exit_json = MagicMock(return_value={})

    test_main()

    # Check that it exited with the expected results
    exit_json_args, exit_json_kwargs = test_module.exit_json.call_args
    assert exit_json_kwargs == { 'ping' : 'pong' }

# Generated at 2022-06-23 04:00:05.753103
# Unit test for function main
def test_main():
    import json
    args = dict(data="pong")
    rc, out, err = module.run_command('{0} {1}'.format(module.params['_ansible_python_interpreter'], module.__file__))
    result = json.loads(out)
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:00:07.947066
# Unit test for function main
def test_main():
    # Test that module does not error when data param is 'crash'
    # Test module does not error on any other param
    # Test that value returned from module is the same as the param
    pass

# Generated at 2022-06-23 04:00:12.472442
# Unit test for function main
def test_main():
    try:
        main()
        print("test_main has passed!")
    except Exception as e:
        print(e)
        print("test_main has failed!")

# Generated at 2022-06-23 04:00:19.569785
# Unit test for function main
def test_main():
    # Init AnsibleModule
    module = AnsibleModule({
        'data': dict(type='str', default='pong'),
    }, supports_check_mode=True)
    # Run Module Code
    main()
    # Check if results are correct
    assert module.exit_json == {'changed': False,
    'ping': 'pong',
    'invocation': {'module_name': 'AnsibleModule',
    'module_args': "{'data': {'type': 'str', 'default': 'pong'}}",
    'module_complex_args': None,
    'module_class': AnsibleModule}}

# Generated at 2022-06-23 04:00:30.996445
# Unit test for function main
def test_main():
    # Define the test case inputs and expected results.
    module_args = dict(
        data="pong",
    )

    result = dict(
        ping="pong",
    )

    # Run test
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-23 04:00:33.031268
# Unit test for function main
def test_main():
    test_params = dict(
        data='test',
    )
    assert main(test_params)['ping'] == 'test'

# Generated at 2022-06-23 04:00:33.461100
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:00:35.407465
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong'),
    )
    ## Act
    result = main()
    ## Verify
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:00:41.250382
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:00:46.028903
# Unit test for function main
def test_main():
    args = dict(data="pong")
    result = dict(changed=False, ping='pong')
    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        main()
        exit_json.assert_called_with(**result)

# Generated at 2022-06-23 04:00:51.566575
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    ansible_module = ansible.module_utils.ansible_fake_module()
    main()
    assert (result == ansible_module.exit_json['ansible_facts'])



# Generated at 2022-06-23 04:00:54.132913
# Unit test for function main
def test_main():
    print(__name__)
    print('Calling function main.')

    main()

# Unit tests for module

# Generated at 2022-06-23 04:00:59.339232
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == None

test_main()

# Generated at 2022-06-23 04:01:03.942257
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")

# Generated at 2022-06-23 04:01:04.481117
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:01:11.841126
# Unit test for function main
def test_main():
    args = {'data': 'foo'}
    result = main(args)
    assert result['ping'] == 'foo'
    assert result['changed'] == False
    assert result['ansible_facts'] == None
    assert result['ansible_modules'] == None

# Generated at 2022-06-23 04:01:13.800576
# Unit test for function main
def test_main():
    ping = main()
    assert ping.exit_json() == 'pong'

# Generated at 2022-06-23 04:01:17.949999
# Unit test for function main
def test_main():
    action = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main(action) == dict(ping=action.params['data'])

main()

# Generated at 2022-06-23 04:01:28.703847
# Unit test for function main
def test_main():
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass

    def exit_json(*args, **kwargs):
        """function to patch over exit_json; package return data into an
        exception"""
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)


# Generated at 2022-06-23 04:01:37.880005
# Unit test for function main
def test_main():
    # Try with a basic positive result
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == main(), "Positive result test failed"

    # Try with a forced fail result
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default=crash),
        ),
        supports_check_mode=True
    )
    assert result == main(), "Negative result test failed"

# Generated at 2022-06-23 04:01:41.252108
# Unit test for function main
def test_main():
    module_args = {}
    # TODO: make mock object for AnsibleModule
    with pytest.raises(Exception) as excinfo:
        main()
    pytest.main()

# Generated at 2022-06-23 04:01:52.808279
# Unit test for function main
def test_main():
    # function to convert a unittest.TestCase __str__ to a python
    # logging style message
    def convert_testcase(func):
        import re
        return re.sub(r'^[A-Za-z0-9_ ]+\(?[A-Za-z0-9_.]+\.[A-Za-z0-9_]+\) *\(?', '', str(func))

    import json
    import unittest
    import os


    class PingModule(unittest.TestCase):
        def setUp(self):
            self.mock_ansible_module = AnsibleModule({
                'data': 'pong',
            })


# Generated at 2022-06-23 04:01:53.507442
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:02:01.271498
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:02:02.695551
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule()

    assert True


# Generated at 2022-06-23 04:02:05.369544
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-23 04:02:16.315090
# Unit test for function main
def test_main():
    x = {'ansible_check_mode': False, 'ansible_diff_mode': False}
    rc = 0
    out = '{"ping": "pong"}'
    ansible_rval = {'out':out, 'rc':rc}
    # First, get the function to return the args to use
    m = AnsibleModule(argument_spec={'data': dict(type='str', default='pong')},
                                 check_invalid_arguments=False,
                                 bypass_checks=False)
    # Then we can stub out the functions with arbitrary return values

    # AnsibleModule.fail_json()
    def myfail_json(msg, **kwargs):
        return {'failed': True, 'msg': msg, 'changed': False}
    m.fail_json = myfail_json

    # Ansible

# Generated at 2022-06-23 04:02:17.541766
# Unit test for function main
def test_main():
    func = main()

# Generated at 2022-06-23 04:02:21.808232
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
      data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True,
  )
  main()
  assert module.params['data'] == 'crash'
  assert module.exit_json.__name__ == 'ping'

# Generated at 2022-06-23 04:02:28.314268
# Unit test for function main
def test_main():
    # Mock AnsibleModule
    class AnsibleModuleMock():
        def __init__(self, argument_spec, supports_check_mode=True):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode

            self.params = dict(
                data='pong',
            )

    # Test that without inducing an exception, the function returns expected result
    am = AnsibleModuleMock(dict(
        data=dict(type='str', default='pong'),
    ), supports_check_mode=True)

    result = dict(
        changed=False,
        ping='pong',
    )
    assert main() == result

    # Test that with inducing an exception, the function returns expected result

# Generated at 2022-06-23 04:02:29.040121
# Unit test for function main
def test_main():
    assert main() == True

# Generated at 2022-06-23 04:02:37.746909
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule

  class FakeModule(object):
    def __init__(self, params={}):
      self.params = params

  def fake_exit_json(changed, **kwargs):
    from ansible.module_utils.basic import AnsibleModule
    assert changed == False
    assert kwargs["ping"] == "pong"
    assert "invocation" in kwargs
    assert "module_args" in kwargs["invocation"]
    assert "data" in kwargs["invocation"]["module_args"]
    assert kwargs["invocation"]["module_args"]["data"] == "pong"


# Generated at 2022-06-23 04:02:40.676858
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    assert main() == {'ping': 'pong'}

# Generated at 2022-06-23 04:02:48.568400
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-23 04:02:50.505396
# Unit test for function main
def test_main():
  # TODO: Add this unit test back in once we have a test module
  # framework in place.
  assert True

# Generated at 2022-06-23 04:02:53.101045
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:03:00.733295
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
                ),
            supports_check_mode=True
            )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
            ping=module.params['data'],
            )

    module.exit_json(**result)

# Generated at 2022-06-23 04:03:07.530997
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

main()

# Generated at 2022-06-23 04:03:13.476632
# Unit test for function main
def test_main():
    """
    Normal case for main()
    """
    test_args = dict(
        data = 'pong'
    )
    test_ansible_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    test_ansible_module.params = test_args
    main()

# Generated at 2022-06-23 04:03:23.087541
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    class Args:
        def __init__(self, data):
            self.data = data

    class Module(object):
        def __init__(self, params):
            self.params = params

    def exit_json(*args, **kwargs):
        pass

    def fail_json(*args, **kwargs):
        pass

    my_module = Module({'data': 'pong'})
    main()
    with pytest.raises(Exception):
        my_module = Module({'data': 'crash'})
        main()

# Generated at 2022-06-23 04:03:33.709957
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule
    import pytest
    from ansible.module_utils.six import PY2
    from ansible_collections.ansible.community.tests.unit.compat import mock

    if PY2:
        builtin_str = '__builtin__.str'
    else:
        builtin_str = 'builtins.str'

    docs = module.__doc__.split('\n')
    if PY2:
        exec("def ansible_module_apply_defaults(m): pass")
    else:
        def ansible_module_apply_defaults(m): pass


# Generated at 2022-06-23 04:03:45.840234
# Unit test for function main
def test_main():
  import sys
  module = AnsibleModule(
    argument_spec=dict(
      data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True
  )
  global EXAMPLES
  EXAMPLES = ''

  # This will cause main() to raise an exception
  module.params['data'] = 'crash'
  try:
    main()
  except Exception as e:
    assert e.message == 'boom'

  module.params['data'] = 'pong'
  # For testing purposes, we're changing out sys.stdout.  This is necessary because nose does
  #   not allow unit testing of functions that use print.
  # This is a little unusual because usually sys.stdout is a file handler and not a StringIO().

# Generated at 2022-06-23 04:03:53.897846
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-23 04:03:58.449237
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == None


# Generated at 2022-06-23 04:03:59.971471
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-23 04:04:08.597930
# Unit test for function main
def test_main():
    pong = {
        u'msg': u'',
        u'changed': False,
        u'invocation': {
            u'module_args': {
                u'data': u'pong'
            }
        },
        u'ping': u'pong'
    }
    boom = {
        u'msg': u'boom',
        u'changed': False,
        u'invocation': {
            u'module_args': {
                u'data': u'crash'
            }
        },
        u'exception': u'Exception',
        u'failed': True
    }
    assert main(dict(data='pong')) == pong
    assert main(dict(data='crash')) == boom

# Generated at 2022-06-23 04:04:11.478558
# Unit test for function main
def test_main():
    # Call function main with provided arguments
    # and capture the output.
    out, err = capsys.readouterr()
    assert '"ping": "pong"' in out

# Generated at 2022-06-23 04:04:15.402868
# Unit test for function main
def test_main():
    testargs = ['ping']
    test_result = {}
    test_result['ping'] = 'pong'

    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        mock_exit_json.return_value = None
        main()

    mock_exit_json.assert_called_with(**test_result)

# Generated at 2022-06-23 04:04:18.137562
# Unit test for function main
def test_main():
    fixture = [({"data": "pong"}, {"data": "pong"}),]
    for inp, outp in fixture:
        assert main(inp) == outp
        

# Generated at 2022-06-23 04:04:18.708063
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:04:20.756596
# Unit test for function main
def test_main():
    data = dict(
        data=dict(type='str', default='pong'),
    )
    assert main() == data, "main()"

# Generated at 2022-06-23 04:04:24.503864
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = main()
    assert result['changed'] == False
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:04:25.214054
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:04:30.280850
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    ans = m.execute_module()
    if ans['ping'] == 'pong':
        assert True
    else:
        assert False


# Generated at 2022-06-23 04:04:31.230514
# Unit test for function main
def test_main():
    value = main()
    assert value == None

# Generated at 2022-06-23 04:04:34.023220
# Unit test for function main
def test_main():
    args = dict(
        data='pong'
    )
    result = dict(
        ping='pong'
    )
    ping = AnsibleModule(argument_spec=args)
    ping.exit_json(**result)

# Generated at 2022-06-23 04:04:42.249892
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO

    my_args = dict(data='toto')
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(ping=module.params['data'])
    assert result == dict(ping='toto')

# Generated at 2022-06-23 04:04:48.127886
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )

    module_results = dict(
        ping=module.params['data'],
    )

    assert(module_results) == mai()

# Generated at 2022-06-23 04:04:52.734746
# Unit test for function main
def test_main():
    data = dict()
    module = AnsibleModule(data, check_mode=False)
    module.params['data'] = ''
    result = main()
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:05:00.387221
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Return values that tests can use
    output = {}
    # Return code for test to check
    rc = 0
    # Unit test for function main
    if test_module.params['data'] == 'crash':
        raise Exception("boom")

    output['ping'] = test_module.params['data']

    test_module.exit_json(**output)
    return (rc, output)

# Generated at 2022-06-23 04:05:04.570653
# Unit test for function main
def test_main():
    data = dict(
        data=dict(type='str', default='pong')
    )
    result = dict(
        ping=data['data']
    )

    assert data == result


# Generated at 2022-06-23 04:05:16.141675
# Unit test for function main
def test_main():
    import sys
    from io import StringIO, BytesIO

    # call function main with a mock module
    try:
        from ansible.modules.builtin import ping
        from ansible.modules.builtin.ping import main
        m = ping
        m.module = p = ping
    except:
        from ansible.modules.extras.cloud.amazon import ping
        from ansible.modules.extras.cloud.amazon.ping import main
        m = ping
        m.module = p = ping

    m.params = dict(
        data=dict(type='str', default='pong'),
    )
    sys.stdout = StringIO()  # capture printed output
    sys.stderr = StringIO()  # capture printed output
    main()

# Generated at 2022-06-23 04:05:23.669938
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:05:28.264837
# Unit test for function main
def test_main():
    import sys
    import test.test_module_utils
    print(sys.path)
    print(sys.modules)
    print(test.test_module_utils.__file__)

    print('Created and initialised main()')
    main()


# Generated at 2022-06-23 04:05:31.984541
# Unit test for function main
def test_main():
    mock_ansible_module = AnsibleModule({
        'data': {'type':'str', 'default':'pong'},
    }, supports_check_mode=True)
    assert AnsibleModule == type(mock_ansible_module)



# Generated at 2022-06-23 04:05:34.232847
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.builtin.ping

# Generated at 2022-06-23 04:05:39.792511
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:05:44.969325
# Unit test for function main
def test_main():
    import ansible.module_ping
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-23 04:05:47.681807
# Unit test for function main
def test_main():
  content = {'data': {'key': 'value'}}
  content = json.loads(content)
  print(content)

# Generated at 2022-06-23 04:05:56.575054
# Unit test for function main
def test_main():
    # These imports are only needed for unit testing, not the execution of this module
    import ansible.module_utils.basic
    import sys

    # Mock function of the AnsibleModule class, this will be called to create the module object
    # We need to add the return value of the AnsibleModule class to the sys.modules dict, so it
    # can be found by the modules name later when we try to instantiate it.
    def mock_AnsibleModule_init(self, argument_spec, bypass_checks=None, supports_check_mode=False):
        module = dict(
            argument_spec=argument_spec,
            supports_check_mode=supports_check_mode
        )
        sys.modules[self.__module__] = module
        return module

    # Mock function of the AnsibleModule class, this will be called to create the

# Generated at 2022-06-23 04:06:02.703404
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        assert main(data="crash") is None
    assert main(data="pong") == dict(ping="pong", _ansible_verifiable=False)

# Needed for testing
if __name__ == '__main__':
    # pytest is needed for testing
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 04:06:06.935936
# Unit test for function main
def test_main():
    is_error, has_changed, result = main()
    assert is_error == False
    assert has_changed == False
    assert result == {'ansible_facts': {'ping': 'pong'}, 'changed': False, 'failed': False}


# Generated at 2022-06-23 04:06:15.625097
# Unit test for function main
def test_main():
    import ansible.modules.system.ping as ping

    m = ping.AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    assert m.params['data'] == 'pong'

    r = ping.main()
    assert r['ping'] == 'pong'

# Generated at 2022-06-23 04:06:19.104019
# Unit test for function main
def test_main():
    # package returns ansible.module_utils.basic.AnsibleModule object
    module = main()
    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 04:06:24.461895
# Unit test for function main
def test_main():
    # ansible.module_utils.basic.AnsibleModule object
    ansible_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    ansible_module.exit_json(test_var="test_value")

# Generated at 2022-06-23 04:06:35.940802
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = main()
    assert result['ansible_facts']['ping'] == 'pong'

    # Crash to test the exception handling
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    result = main()
    assert result['failed']

# Generated at 2022-06-23 04:06:44.242385
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    class AnsibleModule1(object):
        def __init__(self, argument_spec, *args, **kwargs):
            self.params = {}

            if 'argument_spec' in kwargs:
                argument_spec = kwargs['argument_spec']

            self.argument_spec = argument_spec

        def did_fail(self):
            return True

        def exit_json(self, *args, **kwargs):
            pass

    class AnsibleModule2(AnsibleModule1):
        def exit_json(self, *args, **kwargs):
            raise Exception("boom")

    class AnsibleModule3(AnsibleModule1):
        def exit_json(self, *args, **kwargs):
            pass

    orig_module_utils_basic = basic

# Generated at 2022-06-23 04:06:46.320726
# Unit test for function main
def test_main():
    print("TEST")
    pass
    assert True == True


# Generated at 2022-06-23 04:06:50.424302
# Unit test for function main
def test_main():
    module = MagicMock()
    module.params = {'data': 'pong'}
    result = dict(ping='pong')
    module.exit_json.assert_called_with(result)

# Generated at 2022-06-23 04:06:52.265370
# Unit test for function main
def test_main():
  modules = {"name": "ping","args": "data=pong"}
  main()
test_main()

# Generated at 2022-06-23 04:07:01.726107
# Unit test for function main
def test_main():
    test1_args = {
        'data': 'crash'
    }
    test1_out = {
        'failed':True,
        'msg':'boom'

    }

    test2_args = {
        'data': 'pong'
    }
    test2_out = {
        'changed':False,
        'ping':'pong'
    }

    test3_args = {
        'data': 'testing'
    }
    test3_out = {
        'changed':False,
        'ping':'testing'
    }

    tests = [
        (test1_args, test1_out),
        (test2_args, test2_out),
        (test3_args, test3_out)
    ]
    results = []

# Generated at 2022-06-23 04:07:11.787008
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    from unittest.mock import patch

    class TestAnsibleModule(AnsibleModule):
        def fail_json(self, **kwargs):
            assert False

    with patch('ansible.module_utils.basic.AnsibleModule', TestAnsibleModule):
        with pytest.raises(Exception) as err:
            main()
        assert 'boom' in str(err.value)

    with patch('ansible.module_utils.basic.AnsibleModule', TestAnsibleModule):
        with patch('ansible.module_utils.basic.jsonify', lambda x: x):
            main()

# Generated at 2022-06-23 04:07:20.792225
# Unit test for function main
def test_main():
    # run module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raised = False
        try:
          raise Exception("boom")
        except:
          raised = True
        assert raised

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:07:27.746992
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    data = module.params['data']
    result = dict(
        ping=module.params['data'],
    )
    if data == 'crash':
        raise Exception("boom")



# pylama:ignore=W0401,W0611

# Generated at 2022-06-23 04:07:40.292419
# Unit test for function main
def test_main():
    with mock.patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        mock_exit_json.return_value = True
        with mock.patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
            mock_exit_json.return_value = True
            with mock.patch.object(AnsibleModule, 'argument_spec') as mock_argument_spec:
                mock_argument_spec.return_value = True
                with mock.patch.object(AnsibleModule, '__init__') as mock_init:
                    mock_init.return_value = True
                    with mock.patch.object(AnsibleModule, 'params') as mock_params:
                        mock_params.return_value = True

# Generated at 2022-06-23 04:07:41.017779
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 04:07:48.212994
# Unit test for function main
def test_main():

    ping_data = 'data'
    ping = 'ping'

    # Test with valid data
    test_data = dict(data=ping_data)
    module = AnsibleModule(test_data, fake_params=test_data)
    result = dict(ping=test_data['data'])
    module.exit_json.assert_called_with(**result)

    # Test with crashing data
    test_data = dict(data='crash')
    module = AnsibleModule(test_data, fake_params=test_data)
    module.fail_json.assert_called_with(msg='boom')

# Generated at 2022-06-23 04:07:48.900550
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:07:54.429987
# Unit test for function main
def test_main():
    # Mock AnsibleModule
    class args:
        data = 'pong'
    ansible_module_ping = AnsibleModule(argument_spec=args.__dict__)
    main()
    # Assert JSON structure
    assert ansible_module_ping.exit_json == dict(changed=False, ping='pong')

# Generated at 2022-06-23 04:07:59.621237
# Unit test for function main
def test_main():
    # Set up test data
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = dict(data='pong')
    try:
        main()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-23 04:08:06.448345
# Unit test for function main
def test_main():
    # Test 1.
    # test_args = [
    #   {'data': 'Crash'}
    # ]
    # ansible_args = {
    #   'ANSIBLE_MODULE_ARGS': test_args[0]
    # }
    # test_args[0]
    with pytest.raises(Exception):
        main()

# Unit test 2
# test_args[1]
y = main()
print(y)

# Generated at 2022-06-23 04:08:10.591031
# Unit test for function main
def test_main():
    # Define function to call
    function_to_test = main
    # Get modules and arguments with which to call function
    args = {}
    kwargs =  {}
    # Call function and check for results
    function_to_test(**kwargs)

# Generated at 2022-06-23 04:08:20.858499
# Unit test for function main
def test_main():
    from ansible.module_utils import core as module_core
    from ansible.module_utils import basic as module_basic
    import json
    import unittest

    def mock_module(**kwargs):
        return module_core.AnsibleModule(**kwargs)

    class TestAnsibleModulePing(unittest.TestCase):

        # Test normal path
        def test_main_success(self):
            with mock.patch('ansible.module_utils.basic.AnsibleModule', side_effect=mock_module) as mock_am:
                module = module_basic.AnsibleModule(argument_spec=dict(data=dict(type="str", default='pong')))
                result = main()
                test_result = dict(
                    changed=False,
                    ping='pong',
                )
