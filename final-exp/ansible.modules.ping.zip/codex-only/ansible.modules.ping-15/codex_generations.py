

# Generated at 2022-06-23 03:58:25.112952
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import Facts
    module_args = dict(
        data='pong',
    )
    module = AnsibleModule(supports_check_mode=True, **module_args)
    facts = Facts()
    facts.populate()
    result = dict(
        ping='pong',
    )

    assert(module.exit_json == result)
# Ensure no stdout
    assert (module.stdout == '')
# Ensure no stderr
    assert (module.stderr == '')

# Generated at 2022-06-23 03:58:28.181144
# Unit test for function main
def test_main():
    """
    Test main function
    """
    try:
        r = main()
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-23 03:58:31.072997
# Unit test for function main
def test_main():
	print("Unit test for function main")
	result = main()
	if result:
		print("Unit test for function main succeeded")
	else:
		print("Unit test for function main failed")

# Generated at 2022-06-23 03:58:35.694951
# Unit test for function main
def test_main():
    # Unit test for the ping module.
    # For details please refer to https://github.com/ansible/ansible/blob/devel/test/units/modules/ping_test.py
    # Create ansible module object
    module_obj = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    main()

# Generated at 2022-06-23 03:58:37.920176
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json(ping='pong')

# Generated at 2022-06-23 03:58:44.586943
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == 'crash'

# Generated at 2022-06-23 03:58:46.075267
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 03:58:50.250747
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main(module) == "pong"

# Generated at 2022-06-23 03:58:51.142723
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:58:56.079756
# Unit test for function main
def test_main():
    field = dict(
        data="pong",
    )
    raw = dict(
        data="pong",
    )
    result = dict(
        ping="pong"
    )

    testobj = AnsibleModule(argument_spec=dict())
    testobj.params = field
    assert testobj.params == raw
    assert main() == result

# Generated at 2022-06-23 03:58:57.592491
# Unit test for function main
def test_main():
    print('Test function main')
    print('TODO: Function not written yet')
    assert True

# Generated at 2022-06-23 03:59:05.100665
# Unit test for function main
def test_main():
    # Test without parameters
    args = {}
    exit_args = {'changed': False, 'ping': 'pong'}
    ansible_module = spy_AnsibleModule(**args)
    main()
    assert ansible_module.exit_json.call_args[0][0] == exit_args
    # Test with parameters
    args = {'data': 'foo'}
    exit_args = {'changed': False, 'ping': 'foo'}
    ansible_module = spy_AnsibleModule(**args)
    main()
    assert ansible_module.exit_json.call_args[0][0] == exit_args

# Generated at 2022-06-23 03:59:13.005600
# Unit test for function main
def test_main():
    testdata_1 = {
        "data": "pong"
    }
    testdata_2 = {
        "data": "crash"
    }
    for test_data in [testdata_1, testdata_2]:
        common_args = {}
        common_args.update(test_data)
        result = main()
        assert result['ping'] == test_data['data']

# Generated at 2022-06-23 03:59:17.760152
# Unit test for function main
def test_main():
    ping_data = dict(
        data=dict(type='str', default='pong'),
    )

    result = dict(
        ping=ping_data['data'],
    )

    m = AnsibleModule(argument_spec=ping_data)
    res = main(m)
    assert res == result

# Generated at 2022-06-23 03:59:30.034924
# Unit test for function main
def test_main():
    test_values = [
        dict(
            data='pong',
            ping='pong'
        ),
        dict(
            data='crash',
            exception=True
        )
    ]

    for test_value in test_values:
        module = AnsibleModule(argument_spec=dict(
            data=dict(type='str', default='pong')
        ))
        module.params['data'] = test_value.get('data', 'pong')

        # Use this to test the exception behavior
        if 'exception' in test_value:
            try:
                main()
                assert False, 'Should have thrown an exception'
            except Exception as e:
                assert str(e) == 'boom', 'Got the wrong exception: %s' % str(e)
            continue

        # Use this to test the

# Generated at 2022-06-23 03:59:40.535200
# Unit test for function main
def test_main():
    # set up parameter arguments
    argument_spec=dict(data=dict(type='str'))

    # set up return results
    retvals = dict(ping="pong")
    # set up module object
    mock_module = type('obj', (object,), dict(
        params=argument_spec,
        exit_json=lambda x, **kwargs: True,
        supports_check_mode=True,
        check_mode=False))

    # set up module test function
    def test_function(module):
        module.exit_json(**retvals)

    # create patch for module function

# Generated at 2022-06-23 03:59:41.120874
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:59:46.336480
# Unit test for function main
def test_main():
    from unittest import TestCase
    from test_ansible_module import TestAnsibleModule

    # Test simple positive case
    result = TestAnsibleModule(module=main,
                               exit_json={'ping': 'pong'}).run()
    assert result.success

    # Test simple negative case
    result = TestAnsibleModule(module=main,
                               exit_json={'ping': 'pong'},
                               params={'data': 'crash'},
                               failed=True).run()
    assert result.failed

# Generated at 2022-06-23 03:59:50.236330
# Unit test for function main
def test_main():
    fields = {
         'data': dict(type='str', default='pong'),
    }
    module = AnsibleModule(argument_spec=fields)
    assert main() is None

# Generated at 2022-06-23 03:59:50.863471
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:59:51.911016
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-23 04:00:02.042528
# Unit test for function main
def test_main():
    sys.modules['ansible'] = Mock()
    sys.modules['ansible'].module_utils = Mock()
    sys.modules['ansible'].module_utils.basic = Mock()
    sys.modules['ansible'].module_utils.basic.AnsibleModule = Mock()
    sys.modules['ansible'].module_utils.basic.AnsibleModule.exit_json = Mock()
    sys.modules['ansible'].module_utils.basic.AnsibleModule.fail_json = Mock()

    from ansible.module_utils import basic

    basic.AnsibleModule.exit_json.assert_called_with(**result)

# Generated at 2022-06-23 04:00:07.718580
# Unit test for function main
def test_main():
    args = dict(
        data='pong'
    )
    results = dict(
        ping='pong'
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    results = dict(
        ping=module.params['data'],
    )

    module.exit_json(**results)

# Generated at 2022-06-23 04:00:08.628255
# Unit test for function main
def test_main():
    assert ping is not None

# Generated at 2022-06-23 04:00:11.076293
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() is not None

# Test handling a specific exception

# Generated at 2022-06-23 04:00:15.036655
# Unit test for function main
def test_main():
    test_obj = { "data": "crash", "module_name": "ansible.builtin.ping" }
    result = main(vars(create_ansible_mock(test_obj)))
    assert result == False

# Generated at 2022-06-23 04:00:18.394325
# Unit test for function main
def test_main():
    print('Test module main')
    assert main()


# Generated at 2022-06-23 04:00:19.105147
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:00:20.524180
# Unit test for function main
def test_main():
    assert False, "Unit tests not yet implemented"

# Generated at 2022-06-23 04:00:29.210175
# Unit test for function main
def test_main():
    args = dict(
        ansible_ssh_user="root",
        ansible_ssh_pass="curled",
        ansible_module_args=dict(data="pong")
    )

    result = dict(
        ping="pong"
    )

    result = main(args)

    assert result == result, "test_main failed"

# Generated at 2022-06-23 04:00:33.468266
# Unit test for function main
def test_main():
    # ansible.module_utils.basic.AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong', }, 'supports_check_mode': True})

    # unit test will not call module.exit_json() but I assume that's a by product of testing.
    pass

# Generated at 2022-06-23 04:00:44.655859
# Unit test for function main
def test_main():
    # Inject builtins module
    module_builtins = importlib.import_module('builtins')
    # Override the default print function
    module_builtins.print = lambda *args, **kwargs: None
    # Mock the BaseException class to simulate the exception raised
    module_builtins.BaseException = Exception
    # Mock the AnsibleModule class
    module_ansible = mock.MagicMock()
    # Return a mock object for the return value of main()
    module_ansible.return_value.__exit__.return_value = None
    # Inject base module attributes
    sys.modules['ansible'] = mock.MagicMock()
    sys.modules['ansible.module_utils'] = mock.MagicMock()
    sys.modules['ansible.module_utils.basic'] = mock.MagicMock()
   

# Generated at 2022-06-23 04:00:51.710671
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          data=dict(type='str', default='pong'),
      ),
      supports_check_mode=True
  )

  if module.params['data'] == 'crash':
    raise Exception("boom")

  result = dict(
      ping=module.params['data'],
  )

  module.exit_json(**result)

# Generated at 2022-06-23 04:00:52.307269
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:01:00.179273
# Unit test for function main
def test_main():
  fd = 5
  module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
            fd=dict(type='int', default=fd),
        ),
        supports_check_mode=True
    )
  data = 'crash'
  fd = module.params['fd']
  module.params['data'] = data
  module.params['fd'] = fd
  print(data)
  print(fd)

# Generated at 2022-06-23 04:01:04.187248
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert type(main()) == dict


# Generated at 2022-06-23 04:01:12.833355
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    module.check_mode = False
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:01:13.340214
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:01:19.266120
# Unit test for function main
def test_main():
    data = dict(
        data='pong'
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    module.params = data

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:01:24.857233
# Unit test for function main
def test_main():
    # Create the module object
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Was module.params correct?
    assert module.params['data'] == 'pong'
    # Generate ping value
    result = dict(
        ping=module.params['data'],
    )
    # Was the result expected?
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:01:29.506866
# Unit test for function main
def test_main():
    # Dummy data to use for the test
    data = dict(
        ANSIBLE_MODULE_ARGS = dict(data="ping")
    )

    results = dict(
        ANSIBLE_MODULE_RESULTS = dict(
            changed=False,
            ping="pong"
        )
    )

    main()

# Generated at 2022-06-23 04:01:36.002951
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile

    test_file = tempfile.NamedTemporaryFile(mode='w', delete=False)

    try:
        test_file.write('{"data": "pong"}')
        test_file.close()

        sys.argv = [
            '',
            'test_file'
        ]
        main()
    finally:
        os.remove(test_file.name)

# Generated at 2022-06-23 04:01:36.454441
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 04:01:37.092494
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-23 04:01:40.876714
# Unit test for function main
def test_main():
    test1 = dict(
        data = 'pong',
    )

    result = main(test1)

    assert result['changed'] is True
    assert result['ansible_facts']['ping'] == 'pong'


# Generated at 2022-06-23 04:01:52.268456
# Unit test for function main
def test_main():
    import json
    import sys
    import pytest

    # default valid parameters
    args = { 'data': 'pong' }
    result = {}

    def exit_json(*args, **kwargs):
        print(json.dumps(kwargs))

    def fail_json(*args, **kwargs):
        print(json.dumps(kwargs))
        sys.exit(1)

    def fail_exit(*args, **kwargs):
        fail_json(*args, **kwargs)
        sys.exit(1)

    setattr(main(), 'exit_json', exit_json)
    setattr(main(), 'fail_json', fail_json)
    setattr(main(), 'fail_exit', fail_exit)


# Generated at 2022-06-23 04:01:57.453454
# Unit test for function main
def test_main():
    args = dict(data="pong")
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=args)

    result = dict(
        ping="pong"
    )

    assert result == main(args, module)

# Generated at 2022-06-23 04:01:59.591594
# Unit test for function main
def test_main():
  assert func_main() == func_main()

 

# Generated at 2022-06-23 04:02:10.118686
# Unit test for function main
def test_main():
    import ansible.module_utils.basic

    # Mock event callback
    ansible.module_utils.basic.ANSIBLE_MODULE_ARGS = {}
    ansible.module_utils.basic.ANSIBLE_EVENTS = []
    ansible.module_utils.basic.ANSIBLE_EVENTS.append({"event": "on_start", "timestamp": 0})
    ansible.module_utils.basic.ANSIBLE_EVENTS.append({"event": "on_init", "timestamp": 0})
    ansible.module_utils.basic.ANSIBLE_EVENTS.append({"event": "on_any", "timestamp": 0, "data": "on_any"})

# Generated at 2022-06-23 04:02:14.739089
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:02:17.440331
# Unit test for function main
def test_main():
    args = dict(data='foo')
    result = main()
    assert result == dict(
        ping=args['data'],
        )

# Generated at 2022-06-23 04:02:22.363039
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:02:33.700481
# Unit test for function main
def test_main():
    import __builtin__
    setattr(__builtin__, '__package__', '')
    import ansible.module_utils.basic
    setattr(ansible.module_utils.basic, 'AnsibleModule', MockAnsibleModule)

    # We have to do this because the builtin AnsibleModule imports
    # `import json` rather than `from ansible.module_utils import json`
    import json
    import sys
    setattr(sys.modules[__name__], 'json', json)
    from ansible.modules.remote_management.network import ping

    module = ping.main()
    assert module.params['data'] == 'pong'
    assert module.fail_json.called
    assert module.fail_json.call_args == {'msg': 'boom'}
    module = ping.main()

# Generated at 2022-06-23 04:02:39.467353
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        )
    )
    assert module.params['data'] == 'pong'



# Generated at 2022-06-23 04:02:51.703167
# Unit test for function main
def test_main():
    import sys

    # The return of this module is wrapped in a AnsibleModule
    # class so we need to import it and construct a fake
    # class to return from the module.
    sys.path.append('../core')
    from ansible_module import AnsibleModule

    # Generate an empty AnsibleModule for testing.
    module = AnsibleModule(argument_spec={})

    # Unit test for function ping
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    global ping
    ping = 'pong'
    result = dict(ping=ping)
    assert dict(ping='pong') == result

# Generated at 2022-06-23 04:02:56.132084
# Unit test for function main
def test_main():
    # No data, normal return
    module = AnsibleModule(dict())
    result = main()
    assert result['ping'] == 'pong'

    # With data
    module = AnsibleModule(dict(data='foobar'))
    result = main()
    assert result['ping'] == 'foobar'

    # With crash data
    module = AnsibleModule(dict(data='crash'))
    with pytest.raises(Exception, match='boom'):
        result = main()

# Generated at 2022-06-23 04:03:09.854112
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import sys

    sys.stdin = open(os.path.dirname(__file__) + '/test_main_stdin', 'r')
    sys.stdout = open(os.path.dirname(__file__) + '/test_main_stdout', 'w')

    module_args = {'data': 'pong'}
    module = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong'}}, supports_check_mode=True)
    main()


# Generated at 2022-06-23 04:03:11.292239
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson):
        main()

# Generated at 2022-06-23 04:03:13.636434
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:03:21.416415
# Unit test for function main
def test_main():
    test1 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert test1.params['data'] == 'pong'
    test2 = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    assert test2.params['data'] == 'crash'

# Generated at 2022-06-23 04:03:22.059533
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:03:25.675962
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    args = {}
    ansible.module_args = {'data': 'test'}
    assert main() == ansible.exit_json(changed=False, ping='test')

# Temporary function to test function ping

# Generated at 2022-06-23 04:03:26.940960
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:03:29.495262
# Unit test for function main
def test_main():
    # Making sure that it doesn't return any error
    assert main() == None, "It should not return an error"

# Generated at 2022-06-23 04:03:30.124281
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:03:37.767239
# Unit test for function main
def test_main():
    import argparse
    import os
    import sys
    os.environ['ARGV'] = 'test'

    output = []

    def print_func(s):
        output.append(s)

    print = print_func
    print = print
    sys.argv = ['ansible-ping']
    main()
    assert output == ['{"changed": false, "ping": "pong"}\n']

# Generated at 2022-06-23 04:03:38.821431
# Unit test for function main
def test_main():
    #pass
    pass


# Generated at 2022-06-23 04:03:39.405749
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:03:41.798227
# Unit test for function main
def test_main():
    args = { 'check_mode': False, 'data': None }
    rval = main()
    assert rval['ping'] == 'pong'

# Generated at 2022-06-23 04:03:50.323433
# Unit test for function main
def test_main():
    import os
    os.system('rm -rf /tmp/result.json')
    args = [
        "ansible-playbook",
        "test_ping.yml"
    ]
    os.system('ansible-playbook test_ping.yml')
    with open('/tmp/result.json') as f:
        result = json.load(f)
    assert result['changed']
    assert len(result['ping']) == 4
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:03:58.935180
# Unit test for function main
def test_main():
    import mock
    from ansible.module_utils import basic
    from ansible.module_utils import actions

    m = mock.Mock(spec=basic.AnsibleModule)
    m.params = dict(data="pong")
    main(m)
    assert not m.fail_json.called
    assert m.exit_json.called

    m = mock.Mock(spec=basic.AnsibleModule)
    m.params = dict(data="crash")
    main(m)
    assert not m.fail_json.called
    assert m.exit_json.called

# Generated at 2022-06-23 04:04:03.646133
# Unit test for function main
def test_main():
    my_vars = {
        'data': 'pong'
    }

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        no_log=True
    )

    module.params = my_vars

    result = main()
    assert(result['changed'] == False)

# Generated at 2022-06-23 04:04:05.217709
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:04:14.258329
# Unit test for function main
def test_main():
    import ansible.modules, ansible.modules.ping, ansible.modules.ping.ping
    import ansible.module_utils.basic, ansible.module_utils.basic.AnsibleModule
    import ansible_collections.ansible.community.tests.unit.compat.mock, ansible_collections.ansible.community.tests.unit.compat.mock.MagicMock
    import ansible_collections.ansible.community.tests.unit.modules.utils, ansible_collections.ansible.community.tests.unit.modules.utils.ansible_module_patch  # noqa

# Generated at 2022-06-23 04:04:15.922556
# Unit test for function main
def test_main():
    assert main() == dict(ping='pong')
    pass

# Generated at 2022-06-23 04:04:16.523913
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:04:21.225123
# Unit test for function main
def test_main():
    fake_module_args = dict(
        data=dict(type='str', default='pong')
    )
    fake_module = AnsibleModule(
        argument_spec=fake_module_args
    )
    assert main(fake_module) == dict(
        ping=fake_module_args.get('data', dict(type='str', default='pong')).default
    )

# Generated at 2022-06-23 04:04:21.788727
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 04:04:23.163247
# Unit test for function main
def test_main():
    assert main() == main()

# Generated at 2022-06-23 04:04:31.960412
# Unit test for function main
def test_main():
    m = AnsibleModule({}, {})
    m.fail_json = fail_json = lambda *args, **kwargs: fail_json_mock(*args, **kwargs)
    m.exit_json = exit_json = lambda *args, **kwargs: exit_json_mock(*args, **kwargs)
    m._ansible_no_log = lambda *args, **kwargs: None
    m.params = {'data': 'pong'}

    main()

    assert(json_out == dict(changed=False, ping='pong'))
    assert(json_err == dict())

# Generated at 2022-06-23 04:04:37.221579
# Unit test for function main
def test_main():
    from ansible.modules.system.ping import main

    args = {
        'ANSIBLE_MODULE_ARGS': {
            'data': 'pong'
        }
    }

    # Ensure we can call the function without error
    assert main() is None

# Generated at 2022-06-23 04:04:48.447393
# Unit test for function main
def test_main():
    # We can't use the default assert since the contents of the dict will
    # change per invocation.
    #
    # So instead we'll just verify that the dict returned is non-empty and that
    # the top-level keys are as we expect them to be.
    from ansible.module_utils.basic import AnsibleModule

    def exit_json(*args, **kwargs):
        return kwargs

    def fail_json(*args, **kwargs):
        return kwargs

    msg = "AnsibleModule has been moved to ansible.module_utils.basic.  Please update your imports."
    with raises(ImportError) as excinfo:
        AnsibleModule = __import__('ansible.module_utils.basic').AnsibleModule

    assert msg in str(excinfo.value)


# Generated at 2022-06-23 04:04:51.349270
# Unit test for function main
def test_main():
  description = "Test module: basics.ping"
  with pytest.raises(SystemExit, match=r"0.*"):
    main()

# Generated at 2022-06-23 04:04:54.918042
# Unit test for function main
def test_main():
    argument_spec = dict(
            data=dict(type='str', default='pong'),
        ),
    assert True


# Generated at 2022-06-23 04:05:00.387283
# Unit test for function main
def test_main():
    import tempfile
    import yaml
    import os

    (fd, test_params_file) = tempfile.mkstemp()
    data = {'ping': 'pong'}
    yaml.dump(data, os.fdopen(fd, 'w'))

    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))

    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 04:05:05.672109
# Unit test for function main
def test_main():
  data = 'Hello world'
  module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
  assert module.params['data'] == data

# Generated at 2022-06-23 04:05:06.770926
# Unit test for function main
def test_main():
    ping = main()
    assert ping == "pong"

# Generated at 2022-06-23 04:05:14.634430
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.common.removed import removed_module

    # Test removal
    with pytest.raises(removed_module) as excinfo:
        from ansible.modules.system.ping import main
    assert excinfo.value.args[0] == "The 'ansible.modules.system.ping' module has been renamed to 'ansible.builtin.ping'"

    # Test function
    with pytest.raises(Exception, match="boom"):
        main()

# Generated at 2022-06-23 04:05:16.262971
# Unit test for function main
def test_main():
    # Test module import
    from ansible.modules.system import ping

    # Test function import
    from ansible.modules.system.ping import main


# Unit tests for function main

# Generated at 2022-06-23 04:05:18.183224
# Unit test for function main
def test_main():
    assert(main() == True)

# Generated at 2022-06-23 04:05:18.771080
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:05:25.925168
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    print("Mocking module")
    print("Mocking module")
    print("Mocking module")
    print("Mocking module")
    print("Mocking module")
    print("Mocking module")



# Generated at 2022-06-23 04:05:30.738115
# Unit test for function main
def test_main():
    args = dict(data='pong')
    rc, out, err = module_execute(module.params, args)
    assert rc == 0
    assert out['ping'] == 'pong'

    args = dict(data='crash')
    rc, out, err = module_execute(module.params, args)
    assert rc == 1
    assert err == 'Exception: boom'

# Generated at 2022-06-23 04:05:40.305561
# Unit test for function main
def test_main():
    data = dict(
        data='pong'
    )

    target = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    data_output = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    data_output.params = data
    result = dict(
        ping=target.params['data']
    )

    assert data_output.exit_json(**result) == None

# Generated at 2022-06-23 04:05:40.900965
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:05:42.144355
# Unit test for function main
def test_main():
    data = {'data': 'pong'}
    assert main() == data

# Generated at 2022-06-23 04:05:47.736257
# Unit test for function main
def test_main():
    my_mock = {
        'data': 'pong',
        'check_mode': False,
    }
    module = AnsibleModule(my_mock, supports_check_mode=True)
    try:
        main()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-23 04:05:56.595540
# Unit test for function main
def test_main():
    # Mock out arguments and ansible module object
    args = {
        'data':'test',
    }
    mod_obj = AnsibleModule(
        argument_spec={
            'data':dict(type='str', default='pong'),
        },
        supports_check_mode=True
    )

    # Replace the exit json function for our own test exit function
    def test_exit_json(*args, **kwargs):
        module.exit_json(*args, **kwargs)
    mod_obj.exit_json = test_exit_json

    # Call main and set the module object to our mocked object
    main()
    assert module.exit_json.call_args[0][0]['ping'] == 'test'
    assert module.exit_json.call_count == 1

    # Mock the function to cause an exception
   

# Generated at 2022-06-23 04:06:07.992440
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Successful execution
    res = module.exit_json(**dict(ping=module.params['data']))
    assert res['msg'] == module.params['data']
    assert "CRITICAL" not in res['msg']
    assert "ERROR" not in res['msg']
    assert res['changed'] == False

    # Failed execution
    module.params['data'] = 'crash'
    with pytest.raises(Exception):
        module.exit_json(**dict(ping=module.params['data']))

# Generated at 2022-06-23 04:06:14.139180
# Unit test for function main
def test_main():
    args = dict(
        data='pong'
    )
    # We don't have any return values in ping, but at least we can verify that it doesn't fail
    assert main(args)

# Generated at 2022-06-23 04:06:25.907484
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import pytest
    import json

    # mock the module args
    class Args:
        def __init__(self):
            self.data = "pong"
    # mock the module
    class AnsibleModule:
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.params = Args()
            self.check_mode = True
        def exit_json(self, **kwargs):
            self.result = kwargs
            assert False
        def fail_json(self, **kwargs):
            self.result = kwargs
            assert False
    # mock the sys.stdin

# Generated at 2022-06-23 04:06:28.671314
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    ret = main(module)
    assert ret == {'changed': False, 'ping': 'pong'}

# Generated at 2022-06-23 04:06:39.782229
# Unit test for function main
def test_main():
    import os
    import pytest

    @pytest.fixture
    def fake_module(request):
        class FakeModule(object):
            def __init__(self):
                self.check_mode = False
                self.exit_json = self.fake_exit_json
                self.fail_json = self.fake_fail_json
                self.params = {'data':'pong'}
            def fake_exit_json(self, **kwargs):
                self.exit_args = kwargs
            def fake_fail_json(self, **kwargs):
                self.fail_args = kwargs
        return FakeModule()


# Generated at 2022-06-23 04:06:40.974763
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 04:06:44.960426
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import ansible.builtin.ping

    ansible.builtin.ping.main = lambda: None
    m = basic.AnsibleModule(
        argument_spec={'data': {'type': 'str', 'default': 'pong'}},
        supports_check_mode=True
    )
    ansible.builtin.ping.main = main

# Generated at 2022-06-23 04:06:51.753871
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    try:
        result = module.params['data']
        if result == 'crash':
            raise Exception("boom")
    except:
        raise
    module.exit_json(**result)

# Generated at 2022-06-23 04:06:52.722031
# Unit test for function main
def test_main():
    # Test defined vars
    main()

# Generated at 2022-06-23 04:06:53.621986
# Unit test for function main
def test_main():
    # Makes sure module_utils.basic.AnsibleModule is imported
    main()

# Generated at 2022-06-23 04:06:57.165827
# Unit test for function main
def test_main():
    args = dict(
        data="pong"
    )
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = args
    main()

# Generated at 2022-06-23 04:07:04.352283
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
           data=dict(type='str', default='pong')
        )
    )
    module.exit_json = Mock()

    result = dict(
        ping=module.params['data'],
    )
    main()

    assert module.exit_json.call_args == call(**result)

# Generated at 2022-06-23 04:07:09.244373
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = module.main()

    assert(result['ping'] == 'pong')

    assert(result['ansible_facts']['ansible_check_mode'] == False)

# Generated at 2022-06-23 04:07:09.803548
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:07:10.756478
# Unit test for function main
def test_main():
    # TODO: implement test

    main()

# Generated at 2022-06-23 04:07:18.639037
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    # If this test fails it will mean the exit_json is not called with proper arguments
    module.exit_json(**dict(ping=module.params['data']))

# Generated at 2022-06-23 04:07:25.785310
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

if __name__ == '__main2__':
    test_main()

# Generated at 2022-06-23 04:07:30.227714
# Unit test for function main
def test_main():
  data = dict(data="ping")
  res = dict(ping="ping")

  result = main(data)
  assert result == res, "function main should return '%s', returns '%s'" % (res, result)


# Generated at 2022-06-23 04:07:43.018281
# Unit test for function main
def test_main():
    # Mock module
    module_mock = MagicMock()
    module_mock.params.__getitem__ = MagicMock(return_value = 'pong')

    # Mock exit_json
    exit_json_mock = MagicMock()
    module_mock.exit_json = exit_json_mock

    # Mock exception
    exception = MagicMock()
    exception.__name__ = 'Exception'
    exception.__new__ = MagicMock(return_value = exception)
    exception.__str__ = MagicMock(return_value = 'boom')

    # Call to main
    main(module_mock)

    # Assert exit_json was called
    exit_json_mock.assert_called_once_with(ping = 'pong')


# Generated at 2022-06-23 04:07:44.394202
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False

# Generated at 2022-06-23 04:07:45.013354
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:07:46.552817
# Unit test for function main
def test_main():
    result = main()
    assert result['ansible_facts']['ping'] == 'pong'

# Generated at 2022-06-23 04:07:52.646454
# Unit test for function main

# Generated at 2022-06-23 04:07:54.585148
# Unit test for function main
def test_main():
    result = main()
    assert result[0]['ping'] == 'pong'

# Generated at 2022-06-23 04:07:59.783304
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(ping=module.params['data'])
    assert result == dict(ping=module.params['data'])

# Generated at 2022-06-23 04:08:08.979971
# Unit test for function main
def test_main():
    # Create a mock argument spec
    args_spec = dict(
        data=dict(type='str', default='pong'),
    )
    # Create a mock exit json
    result = dict(
        ping='pong',
    )
    # Create a mock module
    module = AnsibleModule(
        argument_spec=args_spec,
        supports_check_mode=False,
    )
    # Save the original exit json method
    module_exit_json = module.exit_json
    # Save the original fail json method
    module_fail_json = module.fail_json
    # Define the exit json method to call
    def exit_json(**kwargs):
        # Check if the exit json is correct
        assert kwargs == result
        # Set the exit json result to True

# Generated at 2022-06-23 04:08:15.093448
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )    
    
    module.exit_json(**result)

import unittest


# Generated at 2022-06-23 04:08:23.558587
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.modules import ping

    # Check mode is not provided in arguments
    m = basic.AnsibleModule(argument_spec={'data':{'type':'str', 'default':'pong'}})
    with pytest.raises(basic.AnsibleModule.fail_json):
        ping.main()

    # Check mode is provided in arguments
    m = basic.AnsibleModule(argument_spec={'data':{'type':'str', 'default':'pong'}}, supports_check_mode=True)
    m.exit_json = lambda **kwargs: kwargs
    result = ping.main()