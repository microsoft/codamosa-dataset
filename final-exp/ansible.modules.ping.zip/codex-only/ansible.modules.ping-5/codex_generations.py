

# Generated at 2022-06-23 03:58:19.425843
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 03:58:23.822966
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    from ansible.module_utils.basic import AnsibleExitJson, AnsibleFailJson, AnsibleExitModule
    try:
        main()
    except Exception as e:
        print(e)
        assert True

# Generated at 2022-06-23 03:58:24.557736
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:58:25.075693
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 03:58:27.226515
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 03:58:35.479217
# Unit test for function main
def test_main():
    import json
    import sys
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    mock_args = {
        "data": "crash"
    }
    mod.params = mock_args
    sys.argv = [sys.argv[0], json.dumps(mod.params)]
    try:
        main()
        assert False
    except:
        assert True
    mock_args = {
        "data": "pong"
    }
    mod.params = mock_args
    sys.argv = [sys.argv[0], json.dumps(mod.params)]
    try:
        main()
        assert True
    except:
        assert False

# Generated at 2022-06-23 03:58:36.039008
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:58:36.614207
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:58:40.168177
# Unit test for function main
def test_main():
    dict_to_test = dict(
        data="pong"
    )
    module_to_test = AnsibleModule(argument_spec=dict_to_test)
    assert main() is True

# Generated at 2022-06-23 03:58:47.037162
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert 'pong' == module.params['data']
    try:
        module.params['data'] = 'crash'
        main()
        assert False, "Did not raise exception as expected"
    except Exception as e:
        assert e.message == "boom"


# Generated at 2022-06-23 03:58:53.376231
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 03:58:54.235495
# Unit test for function main
def test_main():
    result = main()
    assert result == True

# Generated at 2022-06-23 03:58:54.904714
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:59:04.800211
# Unit test for function main
def test_main():
    # Usage:
    #  python -m pytest [-s] tests/test_ping.py  # test the module
    #  python -m pytest [-s] tests/test_ping.py::test_main # test function main
    #  python -m pytest [-s] tests/test_ping.py::test_main::test_errcode  # test method test_errcode
    if '-v':
        print('> TEST: test_main()')
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
        mock_module = mock.Mock()
        mock_AnsibleModule.return_value = mock_module
        # ------------------------------- call function -------------------------------
        main()
        # ------------------------------- assertions -------------------------------

# Generated at 2022-06-23 03:59:07.581747
# Unit test for function main
def test_main():
  with pytest.raises(Exception):
    main()

# Generated at 2022-06-23 03:59:16.278090
# Unit test for function main
def test_main():
    ping_id = 'ping'
    ping_data = 'pong'
    ping_result = dict(ping='pong')

    with patch("ansible.module_utils.basic.AnsibleModule", autospec=True) as mocked_module:
        module = mocked_module.return_value
        module.params = dict(data=ping_id)

        # call the function under test
        main()

        # verify that AnsibleModule.exit_json is called with the correct arguments
        mocked_module.exit_json.assert_called_once_with(**ping_result)


# Generated at 2022-06-23 03:59:20.638354
# Unit test for function main
def test_main():
    module = AnsibleModule({'data':'pong'})
    exit_json = {'ping':'pong'}
    main()



# Generated at 2022-06-23 03:59:32.275472
# Unit test for function main
def test_main():
    import os
    import sys
    import shlex
    import subprocess
    import json
    path = os.path.dirname(os.path.realpath(__file__))
    arg = shlex.split('/usr/bin/python ' + path + '/' + 'ping.py')
    os.environ['ANSIBLE_PING_DATA'] = 'foo'
    print('Test: ping:')
    p = subprocess.Popen(arg,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True
    )
    (stdout, stderr) = p.communicate(input='{}')
    r = json.loads(stdout)

# Generated at 2022-06-23 03:59:33.685431
# Unit test for function main
def test_main():
  #Checks if function main returns the right value
  assert main() == "pong"

# Generated at 2022-06-23 03:59:39.562167
# Unit test for function main
def test_main():
    test1 = """---
- hosts: localhost
  connection: local
  gather_facts: false
  tasks:
    - name: ping test
      ping:
        data: bar
"""
    with open("test1.yml", "w") as f:
        f.write(test1)
    data = AnsibleModule({"data": "bar"}, "test1.yml")
    assert main(data) == {"ping": "bar"}


# Generated at 2022-06-23 03:59:45.786145
# Unit test for function main
def test_main():
    # Create the module object
    my_args = dict()
    my_args['data'] = 'pong'
    my_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert my_module.params['data'] == 'pong'

    # Test crash
    my_args['data'] = 'crash'
    try:
        main()
    except Exception as e:
        assert e.message == 'boom'

# Generated at 2022-06-23 03:59:51.391952
# Unit test for function main
def test_main():
    args = dict(data='pong')

    with patch.object(AnsibleModule, 'exit_json') as mock_exit:
        main()
        assert mock_exit.call_count == 1

        result = dict(
            ping=args['data'],
        )

        assert mock_exit.call_args[0][0] == result

# Generated at 2022-06-23 03:59:56.886121
# Unit test for function main
def test_main():
    def AnsibleModule(argument_spec, supports_check_mode=False):
        assert(argument_spec == dict(
            data=dict(type='str', default='pong'),
        ))
        return MagicMock(params={"data": "pong"})

    m = MagicMock()
    from ansible.module_utils.basic import *
    with patch.dict(globals(), {"AnsibleModule": AnsibleModule , "m": m}):
        main()
    assert(m.exit_json.call_count == 1)
    assert(m.exit_json.call_args[0][0] == dict(ping="pong"))

# Generated at 2022-06-23 04:00:02.653683
# Unit test for function main
def test_main():
    source_dir = os.path.dirname(os.path.realpath(__file__))
    test_args = {
        'data': 'pong',
        '_ansible_check_mode': True
    }
    test_result = {
        'ping': 'pong'
    }

    def mocked_exit_json(*args, **kwargs):
        module_results.update(kwargs)

    module_results = dict()

# Generated at 2022-06-23 04:00:03.365796
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:00:04.467411
# Unit test for function main
def test_main():
    self.assertEqual(main(), 0)

# Generated at 2022-06-23 04:00:07.309549
# Unit test for function main
def test_main():
    data='pong'
    m = AnsibleModule(argument_spec=dict(data=dict(default=data)))
    m.exit_json(ping=m.params['data'])

# Generated at 2022-06-23 04:00:17.702903
# Unit test for function main
def test_main():
    # Stub out module class
    class MockModule():
        def __init__(self, **kwargs):
            self.params = kwargs
            self.exit_json = lambda **kwargs: True

    # Stub out AnsibleModule
    class MockAnsibleModule():
        def __new__(cls, **kwargs):
            return MockModule(**kwargs)

    # Save AnsibleModule class
    ansible_module = AnsibleModule

    # Replace AnsibleModule with MockAnsibleModule
    AnsibleModule = MockAnsibleModule

    # Execute the function
    main()

    # Restore AnsibleModule class
    AnsibleModule = ansible_module

# Generated at 2022-06-23 04:00:31.870993
# Unit test for function main
def test_main():
  with patch.object(basic, 'AnsibleModule') as mock_AnsibleModule:
     # Mock arguments
    mock_AnsibleModule.params = { 'data': 'pong' }
    # Run the function under test
    main()
     # Check the exit_json method
    mock_AnsibleModule.exit_json.assert_called_with( ping = "pong")
     # Check that `basic.AnsibleModule` was instantiated correctly
     # (with the appropriate arguments)
    mock_AnsibleModule.assert_called_with( argument_spec = { 'data': { 'type': 'str', 'default': 'pong' } }, supports_check_mode = True)

# Generated at 2022-06-23 04:00:36.340085
# Unit test for function main
def test_main():
    # Use the AnsibleModule odulstools to mock a module and its arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Make sure we get a ping result
    assert main()['ping'] == 'pong'

# Generated at 2022-06-23 04:00:44.241842
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.systemd.tests.unit.compat import unittest
    import ansible_collections.community.systemd.tests.unit.compat.mock as mock

    def my_exit_json(self, **kwargs):
        self.exit_args = kwargs
        self.exit_called = True

    def my_fail_json(self, **kwargs):
        self.fail_args = kwargs
        self.fail_called = True

    def my_exit_fail(self):
        self.exit_called = True

    class AnsibleExitJson(AnsibleModule):
        exit_args = dict()
        exit_called = False


# Generated at 2022-06-23 04:00:55.380416
# Unit test for function main
def test_main():
    # Mock the module class to not actually try and exit
    mock_module = MagicMock(name='AnsibleModule')
    mock_module.exit_json = MagicMock(name='exit_json')
    mock_module.fail_json = MagicMock(name='fail_json')
    mock_module.params = {'data': 'pong'}
    mock_module.check_mode = MagicMock(side_effect=[False, True])
    mock_module.supports_check_mode = True

    main()
    # main() is only supporting check mode and will not have an action in check mode
    mock_module.exit_json.assert_not_called()
    # main() is only supporting check mode and will not have an action in check mode
    mock_module.fail_json.assert_not_called()

    #

# Generated at 2022-06-23 04:01:03.487157
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test we can logon to 'webservers' and execute python with json lib.
    # ansible webservers -m ping
    test_module.exit_json(ping=test_module.params['data'])

    # Test we can logon to 'webservers' and execute python with json lib.
    # ansible webservers -m ping -a "data=crash"
    test_module.fail_json(msg="boom")

# Generated at 2022-06-23 04:01:09.202372
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:01:14.788464
# Unit test for function main
def test_main():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ))

    assert module.params['data'] == 'pong'

    # Test exception function
    try:
        raise Exception("boom")
    except Exception as exc:
        assert str(exc) == "boom"

    # Test exit_json function
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-23 04:01:18.718541
# Unit test for function main
def test_main():
    def test_module(*args):
        argv = ['ping', '-T', 'json']
        argv.extend(args)
        argv.append("-")
        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
        module.run()
        return module.params

    params = test_module("-vvvv")
    assert params['data'] == 'pong'

# Generated at 2022-06-23 04:01:22.983624
# Unit test for function main
def test_main():
    # We do not mock ansible_check_mode since this is a basic one-line module.
    # The module doesn't actually do much so we don't have a lot of complex behavior to test either.
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test that we get the correct result when we return success
    assert module.exit_json.call_count == 0
    main()
    result = module.exit_json.call_args[0][0]
    assert result == dict(ping='pong')

    # Test that we get the correct result when we return an exception

# Generated at 2022-06-23 04:01:26.159044
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str'),
        ),
        supports_check_mode=True
    )

    assert main == 'foo'

# Generated at 2022-06-23 04:01:38.008173
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import sys
    import os

    # Create a backup of the module path so we can restore it after testing.
    sys.path_importer_cache.clear()
    module_path_backup = list(sys.path)
    tempdir = tempfile.mkdtemp()
    sys.path.append(tempdir)

    # Create a fake module so we can test the code path where the module
    # isn't found.
    fake_module_path = os.path.join(tempdir, 'fakemodule')
    os.mkdir(fake_module_path)
    fake_module_path_file = os.path.join(fake_module_path, '__init__.py')

# Generated at 2022-06-23 04:01:38.894461
# Unit test for function main
def test_main():
    assert False, 'Test not implemented'

# Generated at 2022-06-23 04:01:41.946792
# Unit test for function main
def test_main():
    example = dict(data='crash')
    module = AnsibleModule(example)
    module.exit_json = Mock()
    main()
    assert(module.exit_json.called)

# Generated at 2022-06-23 04:01:50.659881
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule(argument_spec={'data': {'required': False, 'default': 'pong', 'type': 'str'}},supports_check_mode=True)
    assert module.params == {'data': 'pong'}
    assert module.check_mode == True
    try:
        module.exit_json(**dict(ping='pong'))
    except SystemExit as e:
        assert e.code == 0
    try:
        module.exit_json(**dict(ping='crash'))
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-23 04:01:51.723604
# Unit test for function main
def test_main():
    assert test_main('some text') == 'some text'

# Generated at 2022-06-23 04:01:53.005889
# Unit test for function main
def test_main():
    # Test an exception is thrown when the data is set to crash
    pass


# Generated at 2022-06-23 04:02:01.705165
# Unit test for function main
def test_main():
    '''
    This is the unit test for function main
    '''
    # these variables are initialized for the tests
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    data = 'pong'
    # below is the code stub for the test
    result = dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-23 04:02:12.098837
# Unit test for function main
def test_main():
    def ansibleModuleMockup(spec):
        # mockup some parameters
        params = {'data': 'pong'}
        # add some return values
        spec.exit_json = lambda **kwargs: True
        return params

    orig_init = AnsibleModule.__init__
    AnsibleModule.__init__ = lambda self, argument_spec: ansibleModuleMockup(self)
    # this may raise and exception, but we don't care
    main()
    # turn the AnsibleModule constructor back to its original state
    AnsibleModule.__init__ = orig_init

# Generated at 2022-06-23 04:02:17.087470
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible_builtin.ping
    import ansible_builtin.ping.main

    args = dict(
        data='pong',
    )

    ansible_builtin.ping.main.main()



# Generated at 2022-06-23 04:02:23.628504
# Unit test for function main
def test_main():
    o_mock = mock.mock_open(read_data='pong')
    with mock.patch('builtins.open', o_mock):
        with mock.patch('ansible.modules.windows.'
                        'ping.AnsibleModule') \
                as ansible_module_mock:
            ansible_module_mock.return_value = mock.MagicMock()
            ansible_module_mock.return_value.params = {'data': 'pong'}
            pong = main()
            assert pong == {'ping': 'pong'}

# Generated at 2022-06-23 04:02:30.472203
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-23 04:02:35.885660
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert mod.params['data'] == 'pong'

# Generated at 2022-06-23 04:02:41.660002
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)
    return result

# Generated at 2022-06-23 04:02:50.613317
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        with patch('ansible_collections.community.general.plugins.modules.ping.AnsibleModule') as module_mock:
            ping_mock = MagicMock(return_value={'ping': 'pong'})
            module_mock.return_value = ping_mock
            main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0


# Generated at 2022-06-23 04:03:05.238745
# Unit test for function main
def test_main():

    # Test with data = pong
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(
        ping='pong',
    ), "The function main is not working as expected"

    # Test with data = crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-23 04:03:13.516146
# Unit test for function main
def test_main():
    import ansible.module_utils.basic

    # Test module parameters
    module_parameters = {
        "data": "pong",
    }

    result = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            "data": {"default" : "pong", "type" : "str"}
        },
        supports_check_mode=True,
    ).execute_module()

    assert result["changed"] == False
    assert result["ping"] == "pong"

# Generated at 2022-06-23 04:03:23.527145
# Unit test for function main
def test_main():
    # Test empty data
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == {'ping': 'pong'}

    # Test crash data
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        assert result == {'ping': module.params['data']}
    except:
        assert True

# Generated at 2022-06-23 04:03:32.913713
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    cli_parser = module.cli.get_cli_parser(module)
    cli_args = cli_parser.parse_args(args=[
        "--extra-vars",
        "data=pong1"])

    module.parse(cli_args)

    assert module.params['data'] == "pong1"

# Generated at 2022-06-23 04:03:42.451784
# Unit test for function main
def test_main():
    class TestAnsibleModule(object):

        @staticmethod
        def exit_json(**kwargs):
            module_result = kwargs
            raise StopIteration()

        @staticmethod
        def fail_json(**kwargs):
            module_result = kwargs
            raise StopIteration()

    module = TestAnsibleModule()
    module.params = {"data" : "pong"}

    try:
        main()
    except StopIteration as ex:
        module_result = ex.args[0]

    assert module_result == {'ping': 'pong'}

# Generated at 2022-06-23 04:03:44.176081
# Unit test for function main
def test_main():
    print()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:03:51.160280
# Unit test for function main
def test_main():
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    ),
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    ),
    pong = dict(
        ping=module.params['data'],
    ),
    module.exit_json(**pong)

# Generated at 2022-06-23 04:03:52.676392
# Unit test for function main
def test_main():
    result = main()
    assert result == dict(
        ping='pong',
    )

# Generated at 2022-06-23 04:04:03.325332
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[0] == 3:
        buffer_class = io.BytesIO
    else:
        buffer_class = io.StringIO

    try:
        from __main__ import json
    except ImportError:
        import json

    module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=False
        )

    assert main() == None



# Generated at 2022-06-23 04:04:05.114095
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:04:07.742778
# Unit test for function main
def test_main():
    for key, val in test_main.__dict__.items():
        if key.startswith('test_'):
            run_function(key)

# Generated at 2022-06-23 04:04:17.634670
# Unit test for function main
def test_main():
    import json

    # Test nothing happens when data is not set to crash
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        params = {'data': 'pong'}

    module = FakeModule()

    assert main() == module.exit_json(data='pong')

    # Test nothing happens when data is not set to crash
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        params = {'data': 'crash'}

    module = FakeModule()

    with pytest.raises(Exception) as excinfo:
        main()
    assert "boom" in str(excinfo.value)

# Generated at 2022-06-23 04:04:23.588118
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:04:25.661339
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 04:04:27.572079
# Unit test for function main
def test_main():
    global __file__
    __file__ = 'mock_ansible_module.py'
    main()

# Generated at 2022-06-23 04:04:34.312528
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            asd=dict(type='str', default='pong'),
            data=dict(type='str', default='pong'),
        )
    )
    try:
        main()
    except Exception as e:
        assert (e.args[0] == "unrecognized arguments: asd")
    data = dict(ping='pong')
    module.exit_json(**data)
    assert module.params['data'] == 'pong'
    assert module.params['asd'] == 'pong'

# Generated at 2022-06-23 04:04:45.916810
# Unit test for function main
def test_main():
    f = open('ping.py', 'w')

# Generated at 2022-06-23 04:04:49.624043
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-23 04:04:59.651575
# Unit test for function main
def test_main():
    # Test for no argument
    # ping_result = main()
    # assert ping_result == {'ping': 'pong'}
    # Get a function reference
    function_main = globals()['main']
    # Create an instance of the AnsibleModule class
    module = function_main.__globals__['AnsibleModule']
    test_module = module(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Assert that main returns a "_ansible_module" object
    assert function_main() == test_module.exit_json(**{'ping': 'pong'})

# Generated at 2022-06-23 04:05:12.953460
# Unit test for function main
def test_main():
    # Called from main(), so figure out where we are.
    import os
    import sys

    os.chdir(os.path.dirname(os.path.realpath(sys.argv[0])))
    sys.path.insert(0, os.path.dirname(os.path.realpath(sys.argv[0])))

    import json
    import pkg_resources

    from ansible_test.unit_test import TestModule, AnsibleExitJson, AnsibleFailJson

    # Unit test exec path
    module_path = 'ansible_test/lib/ansible/modules/commands/system/ping.py'


# Generated at 2022-06-23 04:05:14.417569
# Unit test for function main
def test_main():
    from ansible.module_utils.common.removed import removed_module
    removed_module('ansible.builtin.ping')

# Generated at 2022-06-23 04:05:27.068735
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule, AnsibleExitJson
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import builtins
    if six.PY3:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    def fake_exit_json(**kwargs):
        """make exit_json throw an exception"""
        raise AnsibleExitJson(arguments=kwargs)


# Generated at 2022-06-23 04:05:29.721923
# Unit test for function main
def test_main():
    import sys
    # Restore cli arguments for function main
    sys.argv = sys.argv[:1]
    # call function main
    assert main() == 0

# Generated at 2022-06-23 04:05:30.920553
# Unit test for function main
def test_main():
    ''' If no exception is raised from main, the tests passed '''
    assert True

# Generated at 2022-06-23 04:05:31.786511
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:05:38.195466
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:05:45.829646
# Unit test for function main
def test_main():
    import ansible.module_pong
    import ansible.module_utils.basic
    import json
    import ansible.constants
    import os

    def fake_ansible_module(**kwargs):
        class FakeModule:
            def __init__(self, **kwargs):
                self.argument_spec = kwargs['argument_spec']
                self.params = kwargs['params']
                self.supports_check_mode = kwargs['check_mode']

            def fail_json(self, *args, **kwargs):
                raise Exception('failing')

            def exit_json(self, *args, **kwargs):
                if self.supports_check_mode:
                    assert 'check_mode' in kwargs.keys()
                    assert kwargs['check_mode'] is True

# Generated at 2022-06-23 04:05:46.994877
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-23 04:05:48.040467
# Unit test for function main
def test_main():
    # Place holder
    pass

# Generated at 2022-06-23 04:05:54.902073
# Unit test for function main
def test_main():
    fail_json_dummy = lambda self, *args, **kwargs: None
    setattr(AnsibleModule, 'fail_json', fail_json_dummy)
    setattr(AnsibleModule, 'exit_json', fail_json_dummy)

    ping_dummy = lambda self, *args, **kwargs: None
    setattr(AnsibleModule, 'ping', ping_dummy)

    # run module without argument
    with pytest.raises(Exception):
        main()


# Generated at 2022-06-23 04:06:01.045984
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)
main()

# Generated at 2022-06-23 04:06:08.647497
# Unit test for function main
def test_main():
    import pytest
    test_module = {'ping': 'pong'}
    def ansible_module_run_exit_json(data, **kwargs):
        test_module = data
        raise SystemExit

    class FakeAnsibleModule:
        exit_json = ansible_module_run_exit_json
        exit_json.__annotations__ = {'data': dict, '**kwargs': dict}

    mocker.patch('ansible.module_utils.basic.AnsibleModule', FakeAnsibleModule)
    main()
    assert test_module == {'ping': 'pong'}

# Generated at 2022-06-23 04:06:24.115593
# Unit test for function main

# Generated at 2022-06-23 04:06:34.161621
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params['data'] = 'crash'
    with pytest.raises(Exception):
        main()
    module.params['data'] = 'pong'
    main()
    module.params['data'] = ''
    main()

# Generated at 2022-06-23 04:06:39.779928
# Unit test for function main
def test_main():

    # test with argument_spec
    module_args = dict(
        data=dict(type='str', default='pong'),
    )
    module_return = dict(
        ping='pong',
    )
    tmp_module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    assert main() == module_return, "Function [main] does not exist!"


# Generated at 2022-06-23 04:06:46.208258
# Unit test for function main
def test_main():
    testdata = dict(
        ping=module.params['data'],
    )

    result = dict(
        ping=module.params['data'],
    )

    # Test with default data
    assert result == main()

    # Test with specified data
    assert result == main(data='crash')

    assert result != main(data='no-crash')

# Generated at 2022-06-23 04:06:47.123216
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:06:57.124937
# Unit test for function main
def test_main():

    test_params = dict(
    data=dict(type='str', default='pong'),
    )
    test_supports_check_mode = True

    module = AnsibleModule(
        argument_spec=dict(
        test_params
        ),
        supports_check_mode=test_supports_check_mode
    )

    return_obj = dict(
    ping=module.params['data'],
    )

    assert module.params['data'] == 'pong'
    assert module.params['data'] == 'boom'
    assert module.exit_json(**result) == return_obj
    assert main() == test_main()
    assert test_main() == main()

# Generated at 2022-06-23 04:07:09.376527
# Unit test for function main
def test_main():
    data = json.loads('{"cloud_flavor": {"os_distro": "rhel", "os_version": "7.2"}, "ansible_facts": {"distribution": "CentOS", "distribution_major_version": "7", "distribution_release": "Core", "distribution_version": "7.2.1511", "kernel": "Linux", "os_family": "RedHat", "virtualization_role": "guest"}}')
    data['ansible_facts']['distribution'] = 'CentOS'
    data['ansible_facts']['distribution_major_version'] = '7'
    data['ansible_facts']['distribution_release'] = 'Core'
    data['ansible_facts']['distribution_version'] = '7.2.1511'

# Generated at 2022-06-23 04:07:19.195410
# Unit test for function main
def test_main():
    module_args = dict(
     data='test'
    )
    result = dict(
     changed=False,
     ping='test',
     invocations={
      'module_args': module_args,
     },
     ansible_facts={},
    )

    # TODO: Create a mock AnsibleModule object

    # TODO: Create a mock connection to return a result

    # TODO: Add try/except around AnsibleModule calls
    # TODO: Set the AnsibleModule.fail_json

    # TODO: Get the result value and test it

# Generated at 2022-06-23 04:07:27.700029
# Unit test for function main
def test_main():
    # Get the module parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Induce an exception to see what happens (test the exception handling)
    if module.params['data'] == 'crash':
        raise Exception("boom")

    # Create the expected result
    result = dict(
        ping=module.params['data'],
    )

    # Print the result
    module.exit_json(**result)

# Generated at 2022-06-23 04:07:32.543732
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    my_result = main()
    assert (my_result.get('ping') == 'pong')

# Generated at 2022-06-23 04:07:39.228200
# Unit test for function main
def test_main():

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    module = TestModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert main() == result

# Generated at 2022-06-23 04:07:39.941499
# Unit test for function main
def test_main():
    assert(main())

# Generated at 2022-06-23 04:07:44.150632
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )

    result = dict(
        ping=module.params['data'],
    )

    assert (main() == result)

# Generated at 2022-06-23 04:07:51.300691
# Unit test for function main
def test_main():
  try:
    main()
  except Exception:
    print("crash test")
  
test_main()


# Generated at 2022-06-23 04:07:52.867399
# Unit test for function main
def test_main():
    res = main()
    assert res == 0

# Generated at 2022-06-23 04:07:56.833899
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    main(test_module)

# Generated at 2022-06-23 04:08:05.672240
# Unit test for function main
def test_main():
    import ansible.module_utils.basic

    ansible.module_utils.basic.ANSIBLE_VERSION = '2.8.0'
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Check we can call the function
    result = main(module)
    # Check that we can handle unknown exception
    module.params['data'] = 'crash'
    with pytest.raises(Exception):
        main(module)

# Generated at 2022-06-23 04:08:06.483942
# Unit test for function main
def test_main():
    result = main()
    assert result == 'pong'

# Generated at 2022-06-23 04:08:17.963899
# Unit test for function main
def test_main():
    import json
    import pytest

    def _run_module(data):
        module_args = dict(
            data=data,
        )

        return do_the_job(module_args)

    # Test option 'data' set to default value ('pong')
    def test_data_default():
        result = _run_module('pong')
        assert result.get('ping') == 'pong'

    # Test option 'data' set to it's maximum value ('crash')
    def test_data_max():
        with pytest.raises(Exception) as ex:
            _run_module('crash')
        assert str(ex.value) == 'boom'

    # Test if all exceptions are caught.

# Generated at 2022-06-23 04:08:20.027491
# Unit test for function main
def test_main():
    print("Transforming urls...")
    ping_data = main()
    print("ping_data")

test_main()