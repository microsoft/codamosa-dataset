

# Generated at 2022-06-23 03:58:18.662943
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:58:28.659238
# Unit test for function main
def test_main():
    # Imports inside the function are to allow unit parameters to be mokced
    import sys
    module = sys.modules['ansible.module_utils.basic']
    mocked_module = module.AnsibleModule
    mocked_exit_json = module.exit_json
    mocked_fail_json = module.fail_json

    def set_params(data):
        module.AnsibleModule.return_value.params = {'data': data}

    def set_exit_json(changed, ping):
        module.exit_json.return_value = {'changed': changed, 'ping': ping}

    def set_fail_json(failed, msg):
        module.fail_json.return_value = {'failed': failed, 'msg': msg}

    def check_exit_json():
        assert mocked_exit_json.call_count

# Generated at 2022-06-23 03:58:33.307565
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 03:58:33.812747
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:58:41.010066
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-23 03:58:52.894996
# Unit test for function main
def test_main():
    import pytest
    from ansible.errors import AnsibleAction, AnsibleConnectionFailure
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.display import Display

    display = Display()
    options = load_options_vars(loader=None, options=dict())
    loader = DataLoader()

# Generated at 2022-06-23 03:58:56.499816
# Unit test for function main
def test_main():
    res = main()
    assert res == {"changed": False, "ping": "pong"}, "Unexpected output for main"

# Generated at 2022-06-23 03:59:00.194647
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 03:59:02.510652
# Unit test for function main
def test_main():
    # generate test data
    # test module execution
    # check results
    pass

# Generated at 2022-06-23 03:59:08.099864
# Unit test for function main
def test_main():
    import StringIO
    string_io = StringIO.StringIO()
    try:
        main(
            {'ansible_module_args': {'data': 'crash'}}, string_io
        )
    except:
        pass
    else:
        assert False, 'Exception expected'
    assert string_io.getvalue() == '{"failed": true, "msg": "boom"}\n', 'Unexpected module output'

    string_io = StringIO.StringIO()
    main(
        {'ansible_module_args': {'data': 'pong'}}, string_io
    )
    assert string_io.getvalue() == '{"changed": false, "ping": "pong"}\n', 'Unexpected module output'

# Generated at 2022-06-23 03:59:09.432032
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    assert module.ping == 'pong'

# Generated at 2022-06-23 03:59:10.052347
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:59:20.633317
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  import unittest
  import sys
  import os.path

  my_path = os.path.dirname(os.path.realpath(__file__))
  sys.path.insert(0, os.path.join(my_path, ".."))
  from units.helper import ExitJson, FailJson
  from units.helper import AnsibleExitJson
  from units.helper import AnsibleFailJson
  from units.mock import mock_open
  from units.mock import patch

  class TestModule(unittest.TestCase):
    def test_main_success(self):
      m = AnsibleModule({
        'data': 'pong'
      })

# Generated at 2022-06-23 03:59:27.011946
# Unit test for function main
def test_main():
    fields = [
    'ping'
    ]

    args = dict(
        data="pong",
        test="unit test"
        )
    result = main(args, fields)
    assert (result['changed'] == False)
    assert (result['ping'] == "pong")
    assert (result['test'] == "unit test")

# Generated at 2022-06-23 03:59:30.918006
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == dict(ping="pong")

# Generated at 2022-06-23 03:59:34.900760
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json(changed=False, ping="pong")


# Generated at 2022-06-23 03:59:43.436861
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = ImmutableDict(
        ping='pong',
    )

    assert module.params == {'data': 'pong'}
    assert module.check_mode is True

    module.exit_json(**result)

# Generated at 2022-06-23 03:59:49.028594
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    pong = main()
    assert pong == dict(
        ping=m.params['data'],
    )

# Generated at 2022-06-23 03:59:55.625473
# Unit test for function main
def test_main():
    # create the module, as if it was going through ansible
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # make sure we get what we expect from the function
    result = dict(
        ping=module.params['data'],
    )

    assert result == module.exit_json(**result)



# Generated at 2022-06-23 03:59:57.962600
# Unit test for function main
def test_main():
    # The argument_spec argument is required in order to induce the loading
    # of the module
    assert main(argument_spec=dict())

# Generated at 2022-06-23 04:00:03.905972
# Unit test for function main
def test_main():
    my_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    # dumb test since this is just a module shell...
    assert my_module.params['data'] == 'pong'

# Generated at 2022-06-23 04:00:08.157789
# Unit test for function main
def test_main():
    # Test module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test normal return
    result = dict(
        ping=module.params['data'],
    )

    assert result == main()


# Generated at 2022-06-23 04:00:19.610129
# Unit test for function main
def test_main():
    # Check that module doesn't crash on invalid args
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        bypass_checks=True
    )
    # Check that it doesn't crash on crash
    module.params = dict(data='crash')
    with pytest.raises(Exception):
        main()
    # Check that it returns the pong value it was passed
    for data in ['foo', 'bar', 'baz']:
        module.params = dict(data=data)
        module.exit_json = lambda **kwargs: None  # Mock exit_json
        result = dict(changed=False)
        main()

# Generated at 2022-06-23 04:00:30.176479
# Unit test for function main
def test_main():
    def ansible_module_mock(spec):
        return MockModule(spec)

    module = sys.modules[__name__]
    old_ansible_module = module.AnsibleModule

    sys.modules[__name__].AnsibleModule = ansible_module_mock
    try:
        main()
    finally:
        sys.modules[__name__].AnsibleModule = old_ansible_module

# Unit test case for the AnsibleModule class

# Generated at 2022-06-23 04:00:30.555538
# Unit test for function main
def test_main():
     assert main() == 0

# Generated at 2022-06-23 04:00:34.599242
# Unit test for function main
def test_main():
    '''
    Unit tests for module ping
    '''

    # Result unit tests
    result = dict(
        ping='pong'
    )
    assert main() == result

    # Result unit tests - data is crash
    result = dict(
        ping='pong'
    )
    assert main() == result

# Generated at 2022-06-23 04:00:37.698784
# Unit test for function main
def test_main():
    data = dict(
        data='pong',
    )
    with pytest.raises(SystemExit) as rc:
        main(data)
    assert rc == 0

# Generated at 2022-06-23 04:00:41.798356
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-23 04:00:47.976865
# Unit test for function main
def test_main():
    # Mock the module input parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:00:52.596786
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert(module.params['data'] == 'pong')
    assert(module.params['data'] != 'crash')

# Generated at 2022-06-23 04:00:53.953679
# Unit test for function main
def test_main():
    main()
    assert True

# Generated at 2022-06-23 04:00:54.271019
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 04:00:56.794078
# Unit test for function main
def test_main():
  # Unit tests must not be required to provide any set of arguments.
  assert main() == None

# Generated at 2022-06-23 04:01:08.871270
# Unit test for function main
def test_main():

    def fail_debug(s=""):
        sys.stderr.write(str(s))
        sys.exit(1)

    import sys
    import re
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModuleError
    from ansible.module_utils.basic import get_exception

    from ansible.module_utils.basic import json
    from ansible.module_utils.basic import json

    from ansible.module_utils.basic import missing_required_lib
    from ansible.module_utils.basic import no_log_values
    try:
        from ansible.module_utils.basic import OpenSSL
    except ImportError:
        pass
    from ansible.module_utils.basic import ConfigParser

# Generated at 2022-06-23 04:01:16.578559
# Unit test for function main
def test_main():
    from ansible.executor.task_result import TaskResult
    TaskResult._result = None
    TaskResult._task_items = None
    TaskResult._use_cache = False
    TaskResult._is_failed = False
    TaskResult._result_good = {}
    TaskResult._result_bad = {}
    TaskResult._fail_reason = None
    TaskResult._task_fields = None
    TaskResult.traceback = None
    TaskResult.exception = None
    TaskResult.module_stdout = None
    TaskResult._host = None
    TaskResult._task = None
    TaskResult._is_changed = False
    TaskResult.task_uuid = None
    TaskResult._event_data = None
    TaskResult._custom_uuid = None
    TaskResult._result_raw = None
    TaskResult._tmpdir = None



# Generated at 2022-06-23 04:01:16.966828
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 04:01:21.501458
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong'),
    )
    orig_args = dict(data='pong')

    # Test with a module that doesn't exist
    ping_module = AnsibleModule(argument_spec=args, supports_check_mode=True)
    assert ping_module is not None

# Generated at 2022-06-23 04:01:34.031496
# Unit test for function main
def test_main():

    import ansible.module_utils.connection as connection

    # Test function with exception
    def make_connection_exception(module):
        raise Exception("boom")

    # Patch the function "make_connection" from the module "connection"
    # to make it raise an exception
    connection.Connection._make_connection = make_connection_exception

    # Exception for test_function
    def patch_exit_json(self, *args, **kwargs):
        if self.params['data'] == 'crash':
            raise Exception("boom")
        else:
            self.exit_json(*args, **kwargs)

    from ansible.module_utils.basic import AnsibleModule
    # Patch the function "exit_json" from the class "AnsibleModule"
    # to make it raise an exception named "exception"
    Ans

# Generated at 2022-06-23 04:01:35.157582
# Unit test for function main
def test_main():
    assert True == main()
    assert False == main()


# Generated at 2022-06-23 04:01:35.632933
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 04:01:40.626083
# Unit test for function main
def test_main():
    data = {'data': 'test_data'}
    module_args = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
    )
    module = AnsibleModule(**module_args)
    module.params = data
    main()

# Generated at 2022-06-23 04:01:42.421409
# Unit test for function main
def test_main():
    import ansible.module_ping as ping
    assert ping.main() == True


# Generated at 2022-06-23 04:01:44.727008
# Unit test for function main
def test_main():
    import sys
    import doctest
    sys.exit(doctest.testmod(sys.modules[__name__])[0])

# Generated at 2022-06-23 04:01:47.938186
# Unit test for function main
def test_main():
    args = dict(data='')
    res_args = dict(ping='pong')
    test_ansible_module(module_name='ansible.builtin.ping', module_args=args, checkmode=False, result=res_args)


# Generated at 2022-06-23 04:01:51.378185
# Unit test for function main
def test_main():
    args = {}
    args['data'] = ''
    module = AnsibleModule(argument_spec=args)
    #print("%s" % module.params)
    #print("%s" % module.check_mode)
    result = main()
    assert 'ping' in result
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 04:01:52.894466
# Unit test for function main
def test_main():
    ping_result = {}
    ping_result['ping'] = 'pong'
    assert main() == ping_result

# Generated at 2022-06-23 04:02:05.342235
# Unit test for function main
def test_main():
    test_dict = {'data': 'pong'}
    test_module_args = dict(
        data ='pong',
    )
    with pytest.raises(Exception) as excinfo:
        main()
    assert excinfo.value.message == 'boom'

# Generated at 2022-06-23 04:02:10.206013
# Unit test for function main
def test_main():
    fields = {
        "data": {"default": "pong", "type": "str"},
    }

    output = {
        "ping": "pong"
    }

    module = AnsibleModule(argument_spec=fields, supports_check_mode=True)
    result = main()

    assert result['ansible_facts'] == output

# Generated at 2022-06-23 04:02:21.090095
# Unit test for function main
def test_main():
    def write_module(func):
        def _module(*args):
            class _module_args:
                pass
            m = _module_args()
            m.params = {}
            m.check_mode = False
            m.exit_json = func
            m.params['data'] = None
            m.params['data'] = 'pong'
            func(*args, m)
        return _module

    class Args:
        def __init__(self):
            self.data = None
    args = Args()
    args.data = None

    def _module(*args):
        class _module_args:
            pass
        m = _module_args()
        m.params = {}
        m.check_mode = False
        m.exit_json = None
        return m


# Generated at 2022-06-23 04:02:25.112803
# Unit test for function main
def test_main():
    # Mock data and module parameters
    mock_data = 'pong'
    mock_parameters = dict( data = mock_data )

    # Create a module mock
    m = AnsibleModule( argument_spec = dict(data=dict(type='str',default='pong')), supports_check_mode=True )

    # End of test_main

# Generated at 2022-06-23 04:02:25.691020
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:02:30.608104
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == {'ping': 'pong'}

# Generated at 2022-06-23 04:02:42.692983
# Unit test for function main

# Generated at 2022-06-23 04:02:45.703992
# Unit test for function main
def test_main():
    import json
    
    # Test no params
    result_no_params = main()
    assert result_no_params['ping'] == 'pong'

    # Test crash
    result_crash = main(params={'data': 'crash'})
    assert result_crash['ping'] == 'crash'

# Generated at 2022-06-23 04:02:50.239702
# Unit test for function main
def test_main():
    my_module = AnsibleModule(
        argument_spec = dict(
            data = dict(default='pong'),
        ),
        supports_check_mode=True,
    )
    result = main()
    my_module.exit_json(**result)


# Generated at 2022-06-23 04:03:01.872156
# Unit test for function main
def test_main():

    # Unit test for command line
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # We dont test the cras case, this should be fix
    if module.params['data'] == 'crash':
        raise Exception("boom")


    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    assert result['ping']=='pong'

# Generated at 2022-06-23 04:03:02.486464
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 04:03:03.962791
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-23 04:03:15.296013
# Unit test for function main
def test_main():
    # The b_* prefix means byte representation of the string.
    # The unicode() prefix means unicode representation of the string.
    # The u_* prefix means unicode representation of the string.
    # The r_* prefix means raw representation of the string.
    # The string is always the unicode representation of the string.
    # The bytes are always the byte representation of the string.
    # The raw is always the raw representation of the string.
    b_ping = b'ping'
    b_pong = b'pong'
    u_pong = u'pong'
    string_pong = 'pong'
    b_crash = b'crash'

# Generated at 2022-06-23 04:03:21.178862
# Unit test for function main
def test_main():
    test_string = "fake output"
    def fake_exit_json(**args):
        pass
    class FakeAnsibleModule(object):
        def __init__(self):
            self.exit_json = fake_exit_json
    module = FakeAnsibleModule()
    module.params = {"data":test_string}
    main()
    
    assert module.params["data"] == test_string

# Generated at 2022-06-23 04:03:24.313293
# Unit test for function main
def test_main():
    try:
        # Test expected exception
        main()
        raise Exception('No exception thrown')
    except TypeError as e1:
        print(e1)
        assert isinstance(e1, TypeError)

# Generated at 2022-06-23 04:03:30.953990
# Unit test for function main
def test_main():
    class Module(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.result = None
            self.params = {}
        def fail_json(self, result):
            self.result = result
        def exit_json(self, **result):
            self.result = result

    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.result = None
            self.params = {}

    m = Module(argument_spec={}, supports_check_mode=True)
    main(m)
   

# Generated at 2022-06-23 04:03:38.153447
# Unit test for function main
def test_main():
    ping_data = 'pong'
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == {'ping': ping_data}

# Generated at 2022-06-23 04:03:43.192448
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    test_result = dict(
        ping=test_module.params['data'],
    )

    assert test_main() == test_result


# Generated at 2022-06-23 04:03:53.047623
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    data = module.params['data']
    #test case 1 - data is pong
    if data == 'pong':
        result = dict(
            ping=module.params['data'],
        )
        module.exit_json(**result)
    #test case 2 - data is crash
    elif data == 'crash':
        raise Exception("boom")

test_main()

# Generated at 2022-06-23 04:03:59.958093
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if test_module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=test_module.params['data'],
    )

    test_module.exit_json(**result)

    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:04:02.453418
# Unit test for function main
def test_main():
    module_args = dict(data='crash')

    result = dict(
        ping='crash',
    )

    with pytest.raises(Exception):
        main()



# Generated at 2022-06-23 04:04:13.629267
# Unit test for function main
def test_main():
    import pytest
    import ansible.module_utils as module_utils
    import datetime as dt

    # Test when module.params = { }
    with pytest.raises(Exception) as excinfo:
        main()
    assert "boom" in str(excinfo.value)

    # Test when module.params = {
    #     'data': 'crash',
    # }
    with pytest.raises(Exception) as excinfo:
        main()
    assert "boom" in str(excinfo.value)

    # Test when module.params = {
    #     'data': 'pong',
    # }
    assert main() == '''ping:
    description: Value provided with the data parameter.
    returned: success
    type: str
    sample: pong
'''

# Generated at 2022-06-23 04:04:17.685098
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert(module.params['data'] == 'pong')



# Generated at 2022-06-23 04:04:22.628556
# Unit test for function main
def test_main():
    moduleMock = AnsibleModuleMock()
    pingModule = Ping()
    pingModule.main(moduleMock)

    # Check moduleMock.exit_json() was called
    assert moduleMock.exit_json.called
    
    # Check the exit_json() call arguments
    callArgs = moduleMock.exit_json.call_args
    assert callArgs[0][0]['ping'] == 'pong'

# Generated at 2022-06-23 04:04:33.488690
# Unit test for function main
def test_main():
    import __builtin__
    # Test the default behavior of "data"
    setattr(__builtin__, 'module', Mock())
    module.params = {'data': None}
    main()
    assert module.params == {'data': 'pong'}
    # Test with data provided
    setattr(__builtin__, 'module', Mock())
    module.params = {'data': 'foo'}
    main()
    assert module.params == {'data': 'foo'}
    # Test with data set to "crash"
    with pytest.raises(Exception) as excinfo:
        setattr(__builtin__, 'module', Mock())
        module.params = {'data': 'crash'}
        main()
    assert str(excinfo.value) == "boom"

# Generated at 2022-06-23 04:04:41.787815
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

    fake_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=fake_module.params['data'],
    )
    assert json.dumps(result) == json.dumps(dict(ping='pong'))

# Generated at 2022-06-23 04:04:49.612530
# Unit test for function main
def test_main():
    # Import module
    import ansible.modules.system.ping

    # Create module object
    data = 'pong'
    module = ansible.modules.system.ping.AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)

    # Set options
    module.params['data'] = data

    # Run main function
    ansible.modules.system.ping.main()

# Generated at 2022-06-23 04:04:56.625680
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:05:05.897149
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test normal use (crash is not invoked)
    data = module.params['data']
    assert data == 'pong'

    # Test crash is not invoked
    with pytest.raises(Exception) as excinfo:
        data = module.params['data']
        assert data == 'crash'

    assert 'boom' in str(excinfo.value)

# Generated at 2022-06-23 04:05:18.093097
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.tests.unit.modules.testing.ping import AnsibleExitJson
    from ansible_collections.ansible.builtin.tests.unit.modules.testing.ping import AnsibleFailJson
    import ansible_collections.ansible.builtin.plugins.modules.ping as ping
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import MagicMock

    mock_module = MagicMock()
    mock_module.params = dict(
        data='pong',
    )

    with pytest.raises(AnsibleExitJson) as result:
        ping.main()
    assert result.value.args[0]['ping'] == 'pong'


# Generated at 2022-06-23 04:05:19.828645
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
    )
    assert main(test_module) == 0

# Generated at 2022-06-23 04:05:29.270092
# Unit test for function main
def test_main():
    # Test normal run
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == dict(ping='pong')

    # Test exception run
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        main()
        assert False, "Expected failure"
    except Exception:
        pass

# Generated at 2022-06-23 04:05:29.867952
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:05:35.081249
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        main(module)
    except Exception as e:
        assert "boom" in e

# Generated at 2022-06-23 04:05:39.006613
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'



# Generated at 2022-06-23 04:05:43.992827
# Unit test for function main
def test_main():
  args = dict(
    data='crash',
    check_mode=True,
  )
  res = {}
  with pytest.raises(AnsibleModuleExit):
    main()
  assert res == {}
  args = dict(
    data='pong',
    check_mode=True,
  )
  res = dict(
    ping='pong'
  )
  main()
  assert res == dict(
    ping='pong'
  )

# Generated at 2022-06-23 04:05:51.159962
# Unit test for function main
def test_main():
    module_args_dict = {'data': 'crash'}
    module = get_module(module_args_dict)
    result = {'changed': False, 'ping': 'crash'}
    with pytest.raises(Exception):
        main()
        assert exception.value == 'boom'
    assert result['ping'] == 'crash'
    assert result['changed'] == False

# Generated at 2022-06-23 04:05:53.941548
# Unit test for function main
def test_main():
    input1 = {}
    input1['data'] = 'pong'
    output1 = main(input1)
    if output1['ping'] != 'pong':
        return "error"
    return "pass"

# Generated at 2022-06-23 04:05:55.508676
# Unit test for function main
def test_main():
    prgm = ping.__main__()
    assertEqual(prgm,0)

# Generated at 2022-06-23 04:06:03.820532
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:06:07.062281
# Unit test for function main
def test_main():
    try:
        # It should fail, because the data param is invalid
        exit_status = main()
        assert False
    except Exception as e:
        # It should raise an exception, because the data param is invalid
        assert True


# Generated at 2022-06-23 04:06:12.745366
# Unit test for function main
def test_main():
    import os
    import sys
    import inspect

    # Workaround for missing sys.argv in unittests
    main.__globals__['__file__'] = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '../../'))

    # Mock the AnsibleModule class and call main()
    class ModuleMock:
        pass

    sys.modules['ansible.module_utils.basic'] = ModuleMock
    sys.modules['ansible.module_utils.basic'].AnsibleModule = ModuleMock
    function_arguments = inspect.getargspec(main)[0]
    if len(function_arguments) == 1:
        # Versions of ansible before 2.8
        ansible_kwargs = {}

# Generated at 2022-06-23 04:06:13.380280
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()

# Generated at 2022-06-23 04:06:22.529104
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.remote_management.ansible_ping import main

    # Ping module is invoked with no arguments
    args = dict(ANSIBLE_MODULE_ARGS={})
    with mock.patch.object(AnsibleModule, 'run_command') \
            as mock_run_command:
        mock_run_command.return_value = (0, '')
        with pytest.raises(SystemExit):
            main()

# Generated at 2022-06-23 04:06:23.097624
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-23 04:06:28.961003
# Unit test for function main
def test_main():
    args = {
        'data' : 'ping',
        'ANSIBLE_MODULE_ARGS' : {
            'data' : 'ping',
        },
    }
    main(args)

# Generated at 2022-06-23 04:06:31.198968
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    # TBD: Create a mock of the module and call main function with different types of arguments
    # TBD: Create a mock of the module and call main function with different types of arguments
    return

# Generated at 2022-06-23 04:06:33.284513
# Unit test for function main
def test_main():
    ping = {
        'data': 'pong',
    }
    assert(main(ping) == ping)

# Generated at 2022-06-23 04:06:38.644301
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:06:43.485855
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    import ansible_collections.ansible.builtin.plugins.module_utils.basic
    ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule = module
    return main()

# Generated at 2022-06-23 04:06:55.413457
# Unit test for function main
def test_main():
    def run_module():
        module_args = {
            'data': 'pong'
        }
        return AnsibleModule(
            argument_spec=json.dumps(module_args).encode('utf-8'),
            check_invalid_arguments=False,
            bypass_checks=True
        )

    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        module = run_module()
        module.exit_json.assert_called_with(data='pong')

    with patch.object(AnsibleModule, 'fail_json') as exit_json:
        module = run_module()
        module.fail_json.assert_called_with(msg='boom')

# Generated at 2022-06-23 04:06:58.984864
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-23 04:07:10.584989
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from contextlib import contextmanager

    @contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    @contextmanager
    def stderrIO(stderr=None):
        old = sys.stderr
        if stderr is None:
            stderr = StringIO()
        sys.stderr = stderr
        yield stderr
        sys

# Generated at 2022-06-23 04:07:18.429822
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        main()
    except Exception as e:
        if str(e) != "boom":
            raise e



# Generated at 2022-06-23 04:07:21.887881
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 04:07:34.667978
# Unit test for function main
def test_main():
    # Check the 'pong' case
    print('Test: pong')
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = module.params['data']
    assert result == 'pong'

    # Check the 'crash' case
    print('Test: crash')
    try:
        main()
    except Exception:
        pass

    # Check the code coverage for return statement
    print('Test: code coverage')
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = {}
    result['ping'] = 'pong'


# Generated at 2022-06-23 04:07:45.661609
# Unit test for function main
def test_main():
    module_args = {}
    module_args.update(
        data=dict(type=str, default='pong'),
    )
    def test_module(module):
        module.exit_json = lambda **kwargs: None
        return module

    import sys
    import os
    import ansible.module_utils.basic
    module_path = os.path.join(os.path.dirname(__file__), '.<ansible_module_name>')
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic
    sys.modules['<ansible_module_name>'] = test_module

# Generated at 2022-06-23 04:07:49.872570
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

test_main()

# Generated at 2022-06-23 04:07:53.835203
# Unit test for function main
def test_main():
    f, p, d = main()
    assert f == 0, 'f is a fail'
    assert p == 0, 'p is a fail'
    assert d == 0, 'd is a fail'

# Generated at 2022-06-23 04:08:05.592829
# Unit test for function main
def test_main():
    data = 'pong'

    # Create a fake AnsibleModule object
    import ansible.utils
    from ansible.utils import module_docs, module_args, module_params, module_name, CommandLine
    import ansible.module_utils.basic
    pm = module_params(ansible.module_utils.basic.AnsibleModule.argument_spec)

    args = {'data': data}
    pm.update(args)


# Generated at 2022-06-23 04:08:10.763298
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )
    return module.exit_json(**result)


# Generated at 2022-06-23 04:08:14.965570
# Unit test for function main
def test_main():
    import sys
    import os
    import inspect
    import pytest
    import itertools
    import textwrap
    from pint import UnitRegistry

    # required for testing
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.json import json

    from ansible.module_utils.six import b
    from ansible.module_utils._text import to_bytes

    # the required test data will be stored in a dictionary
    # this module actually has no required arguments, but
    # this serves as an example on how everything works
    required_args = {
        'data': {'type': 'str', 'default': 'pong'},
    }

    # the test itself will be a function
    # all arguments are passed in as function arguments
    # the function name can be anything

# Generated at 2022-06-23 04:08:23.466701
# Unit test for function main
def test_main():
    import os
    import sys
    import shlex
    import pytest
    # When run as a script, the module checks for a specific environment
    # variable, but this doesn't happen when run from a unit test.
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = ':'.join(sys.path)

    def run_module(data=None):
        module = AnsibleModule(argument_spec=dict(data=dict(type='str', default=data)), supports_check_mode=True)
        return module.exit_json(ping=module.params['data'])
    with pytest.raises(Exception):
        run_module(data='crash')
    assert run_module(data='pong') == dict(changed=False, ping='pong')