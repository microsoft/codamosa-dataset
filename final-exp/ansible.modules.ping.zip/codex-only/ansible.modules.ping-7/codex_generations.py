

# Generated at 2022-06-23 03:58:19.168516
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    basic.AnsibleModule = AnsibleModule
    main()

# Generated at 2022-06-23 03:58:24.994446
# Unit test for function main
def test_main():
  run_set = {
    "changed": False,
    "params": {
      "data": "pong"
    },
    "invocation": {
      "module_args": {
        "data": "pong"
      },
      "module_name": "ansible.builtin.ping"
    }
  }
  run_copy = dict(run_set)
  return run_copy, run_set


# Generated at 2022-06-23 03:58:28.053241
# Unit test for function main
def test_main():
    # Failed to import
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        pass

# Generated at 2022-06-23 03:58:29.951502
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod(module=None, raise_on_error=False)

# Generated at 2022-06-23 03:58:37.647089
# Unit test for function main
def test_main():
    # Mock out module class for this test
    ping_mod = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Unit test to make sure ping_mod.params['data'] == pong.
    assert ping_mod.params['data'] == 'pong'

    # Unit test to make sure for a other data value, check mode is not enabled
    ping_mod.params['data'] = 'baz'
    ping_mod.check_mode = False
    assert ping_mod.params['data'] == 'baz' and ping_mod.check_mode == False
    ping_mod.params['data'] = 'baz'
    ping_mod.check_mode = True

# Generated at 2022-06-23 03:58:44.908647
# Unit test for function main
def test_main():
    try:
        testmod = importlib.import_module("Ping")
    except ImportError:
        from ansible.modules.network.eos.test import ping as testmod

    # Load parameters used for testing
    fqn = "ansible.extra.ansible_builtin.ping.json"
    if fqn in testmod.__dict__:
        for k in testmod.__dict__[fqn]:
            testmod.params[k] = testmod.__dict__[fqn][k]

    # Run test
    result = testmod.main()

    # Fail the module if exceptions or unexpected results occur
    assert result.get('failed', False) is False, \
        "Testcase is not implemented entirely or failed. " \
        "Please fix this and try again."

# Generated at 2022-06-23 03:58:46.417032
# Unit test for function main
def test_main():
    # Set up
    # Run
    main()
    # Assert
    pass

# Generated at 2022-06-23 03:58:49.013119
# Unit test for function main
def test_main():
    args = { 'data':'pong'}
    result = main({},args)
    assert result['ping'] == 'pong'

# Generated at 2022-06-23 03:58:54.746301
# Unit test for function main
def test_main():
    test_data = [
        {'input': {'data': 'pong'}, 'output': {'changed': False, 'invocation': {'module_args': {'data': 'pong'}}, 'ping': 'pong'}},
    ]
    for test in test_data:
        module = AnsibleModule(test['input'])
        assert(main() == test['output'])

# Generated at 2022-06-23 03:59:01.871396
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    args = dict(
        data=dict(type='str', default='pong'),
    )
    result = dict(
        ping='pong',
    )
    mock = ansible.module_utils.basic.AnsibleModule(argument_spec=args)
    main(mock)
    assert mock.exit_json.called
    assert mock.exit_json.call_args == ansible.module_utils.common.safe_eval(result)

# Generated at 2022-06-23 03:59:03.778475
# Unit test for function main
def test_main():
    pass
    # assert result['ping'] == 'pong'
    # assert result['invocation']['module_args'] == {}

# Generated at 2022-06-23 03:59:14.596391
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    test_module.check_mode = False
    test_module.exit_json(changed=True, ping='pong')

    
    if test_module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=test_module.params['data'],
    )

    test_module.exit_json(**result)



# Generated at 2022-06-23 03:59:16.667044
# Unit test for function main
def test_main():
    data = main()
    # Please insert assert statements below.
    # Example: assert data == 'value'

# Generated at 2022-06-23 03:59:26.330342
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    test_data = {
        'ansible_check_mode': ''
    }

    test_results = dict(
        ping='pong' 
    )

    module.exit_json(**test_results)


# Generated at 2022-06-23 03:59:29.664205
# Unit test for function main
def test_main():
	module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-23 03:59:33.288820
# Unit test for function main
def test_main():
    ping_test = dict(
        data = dict(type='str', default='pong'),
    )

    try:
        main()
    except Exception as ex:
        return ex.message
    else:
        return None

# Generated at 2022-06-23 03:59:34.208558
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-23 03:59:42.601068
# Unit test for function main
def test_main():
    import tempfile
    import json
    import os
    from ansible.module_utils import basic

    tmpdir = tempfile.mkdtemp()
    parms = {
        'ANSIBLE_MODULE_ARGS': {
            'data': 'pong'
        }
    }
    parms_crash = {
        'ANSIBLE_MODULE_ARGS': {
            'data': 'crash'
        }
    }
    filename = os.path.join(tmpdir, 'ping')
    with open(filename, 'w') as ping:
        ping.write('#!/usr/bin/python -tt\n')
        ping.write('\n')
        ping.write(basic.__file__.strip('c') + '\n')
        ping.write('\n')

# Generated at 2022-06-23 03:59:54.651585
# Unit test for function main
def test_main():
    # without this import the test fails because of an error in module_utils
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson, AnsibleFailJson

    monkeypatch = MonkeyPatch()
    # we will test our function with these arguments
    arguments = dict(
        data='pong'
    )
    # this is the json that function main returns
    ret_val = dict(
        ping='pong'
    )

    # we will make Ansible fail this way
    def fail_json(*args, **kwargs):
        args[0]['failed'] = True
        if 'msg' in kwargs:
            args[0]['msg'] = kwargs['msg']
        raise AnsibleFailJson(args[0])

    # we will make

# Generated at 2022-06-23 04:00:05.695438
# Unit test for function main
def test_main():
    def test_module_arguments():
        module_args = dict(
            data=dict(type='str', default='pong'),
        )
        if not module_args:
            raise SkipTest
    def test_failure_param():
        assert module.params['data'] == 'crash'
        with pytest.raises(Exception) as exc:
            main()
        assert exc.value.args[0] == "boom"
    def test_success_param():
        assert module.params['data'] == 'pong'
        main()
        assert result['ping'] == module.params['data']
    def test_run_command():
        run_command()


# Generated at 2022-06-23 04:00:09.946348
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong'),
    )

    # AnsibleModule class is not used here
    # because it is not available in ansible-test
    module = AnsibleModule(argument_spec=args,
                           supports_check_mode=True)
    print(args)

    module.exit_json(**dict(
        ping=module.params['data'],
        ))

# Generated at 2022-06-23 04:00:12.323155
# Unit test for function main
def test_main():
    assert main() == {"ping": "pong"}
    assert main(data="test") == {"ping": "test"}

# Generated at 2022-06-23 04:00:14.075238
# Unit test for function main
def test_main():
    # setup
    args = dict(
        data='pong',
        )

    # Exercise
    main()

# Generated at 2022-06-23 04:00:17.815123
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Add assert statements here
    module.exit_json(**result)


# Generated at 2022-06-23 04:00:29.075439
# Unit test for function main
def test_main():
    arguments = {'data': 'pong'}
    result = dict(ping='pong', ansible_facts={})

    module = Mock(params=arguments, exit_json=Mock())
    # func_name = module.exit_json
    test_main()
    module.exit_json.assert_called()
    module.exit_json.assert_called_with(**result)
    # func_name(**result)
    # module.exit_json.assert_called_with(changed=False, meta={})

# Generated at 2022-06-23 04:00:33.684669
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong')
    )
    with pytest.raises(Exception):
        ansible_module.main()
    args['data'] = 'crash'
    with pytest.raises(Exception):
        ansible_module.main(**args)