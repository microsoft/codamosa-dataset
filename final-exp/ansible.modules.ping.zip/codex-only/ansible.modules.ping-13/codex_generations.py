

# Generated at 2022-06-23 03:58:20.276662
# Unit test for function main
def test_main():
    module_name = 'ansible.builtin.ping'
    main()

# Generated at 2022-06-23 03:58:20.821281
# Unit test for function main
def test_main():
    print(main())

# Generated at 2022-06-23 03:58:25.309341
# Unit test for function main
def test_main():

    # The test case argument list
    args = []

    # The test case options dictionary
    kwargs = { "data": "pong"}

    # Instance of our module class to test
    module = AnsibleModule(argument_spec={'data': {'type': 'str'}}, supports_check_mode=True)

    # Run tests
    result = main(module)

    assert result['ping'] == "pong"

# Generated at 2022-06-23 03:58:31.767765
# Unit test for function main
def test_main():
    ping_result = dict(changed=False, ping="pong")
    module = get_mocked_module_object()
    module.params['data'] = 'crash'
    try:
        main()
    except Exception as e:
        assert e.message == 'boom'
    assert 'ping' in result, repr(result)
    assert result['ping'] == ping_result['ping'], repr(result)


# Test module without fail

# Generated at 2022-06-23 03:58:36.469430
# Unit test for function main
def test_main():
    h = {u'data': u'pong'}
    module = AnsibleModule(h)
    ret = main()
    assert ret
    assert ret == {u'changed': False, u'ping': u'pong'}

# Generated at 2022-06-23 03:58:37.016642
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:58:38.919271
# Unit test for function main
def test_main():
    '''
    docstring of test_main
    '''
    assert True


# Generated at 2022-06-23 03:58:42.171870
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    assert main() == None

# Generated at 2022-06-23 03:58:53.833761
# Unit test for function main
def test_main():
    import sys
    import json
    sys.modules['__builtin__'].__dict__['__salt__'] = {'kubernetes.ping': mock_ping}
    sys.modules['__builtin__'].__dict__['__opts__'] = {'test': False}
    sys.modules['__builtin__'].__dict__['__env__'] = 'base'

    with open(__file__ + '.input', encoding='utf-8') as f:
        module_args = json.load(f)

    with open(__file__ + '.output', encoding='utf-8') as f:
        output = json.load(f)

    m = AnsibleModule(argument_spec=module_args)
    m.exit_json = MagicMock()

    main()

# Generated at 2022-06-23 03:58:55.940287
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-23 03:58:57.473293
# Unit test for function main
def test_main():
    ping = 'pong'

    result = dict(
        ping = 'pong',
    )


# Generated at 2022-06-23 03:59:00.505727
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    func_result = main(module)
    assert func_result['ping'] == 'pong'

# Generated at 2022-06-23 03:59:09.672549
# Unit test for function main
def test_main():
    test_args = dict(
        data = dict(type = 'str', default = 'pong'),
    )
    test_exit_json = dict(
        ping = 'pong',
    )
    def mock_ansible_module(argument_spec, supports_check_mode):
        class AnsibleModuleDummy:
            def __init__(self, arg_spec, s_check_mode):
                self.params = dict()

                for key, value in arg_spec.items():
                    self.params[key] = value['default']

            def exit_json(self, **kwargs):
                print(kwargs)

        return AnsibleModuleDummy(argument_spec, supports_check_mode)


# Generated at 2022-06-23 03:59:10.487048
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:59:14.079636
# Unit test for function main
def test_main():
    md = AnsibleModule({})
    main(md)
    try:
        main(md)
    except Exception as e:
        assert str(e) == "boom"


# Generated at 2022-06-23 03:59:18.679557
# Unit test for function main
def test_main():
    argument_spec = dict(
            data=dict(type='str', default='pong'),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'


# Generated at 2022-06-23 03:59:20.508290
# Unit test for function main
def test_main():
    ARGUMENTS = { 'data': 'pong' }
    result = main()
    assert result == True

# Generated at 2022-06-23 03:59:25.609873
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert 'ping' in main()


# Generated at 2022-06-23 03:59:36.621888
# Unit test for function main
def test_main():
    parameter_values = [
        ['ping', 'pong', None, None],
        ['data', 'pong', None, None],
        ['data', 'crash', Exception, None],
    ]
    module_args = dict(
        data=dict(type='str', default='pong'),
        _ansible_check_mode=True,
    )
    module_name = 'ansible.builtin.ping'

    results = [
        dict(ping='pong'),
        dict(ping='pong'),
        dict(failed=True, msg='boom'),
    ]
    
    from ansible_collections.ansible.builtin.plugins.modules import ping


# Generated at 2022-06-23 03:59:37.298614
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-23 03:59:44.741819
# Unit test for function main
def test_main():
    # Dummy function for function `main`
    def main():
        pass

    ansible_module_ping = dict(
        argument_spec=dict(
            data=dict(
                type='str',
                default='pong'
            ),
        ),
        supports_check_mode=True,
    )

    module = AnsibleModule(
        ansible_module_ping,
    )

    # Test with no arguments
    assert module.params['data'] == 'pong'
    assert module.check_mode is True

    # Test with valid arguments

# Generated at 2022-06-23 03:59:54.651809
# Unit test for function main
def test_main():
    test_string = '''
# Test we can logon to 'webservers' and execute python with json lib.
# ansible webservers -m ping

- name: Example from an Ansible Playbook
  ansible.builtin.ping:

- name: Induce an exception to see what happens
  ansible.builtin.ping:
    data: crash
'''
    test_obj=ansible.builtin.ping.main()
    test_obj.exit_json(changed=False, meta=test_string)
    return test_obj.fail_json(msg="Expected: key1=value1, got key1=value2")

# Generated at 2022-06-23 04:00:01.774661
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:00:07.868000
# Unit test for function main
def test_main():
    # Test that when data is not set, default is pong
    module = AnsibleModule(
        dict(),
        False
    )
    assert main() == dict(ping='pong')

    # Test that when data is set to crash, exception is raised
    module = AnsibleModule(
        dict(data='crash'),
        False
    )
    try:
        assert main() == dict(ping='crash')
    except Exception as e:
      assert e.message == 'boom'

# Generated at 2022-06-23 04:00:11.507390
# Unit test for function main
def test_main():
    set_module_args(dict(
        data="crash",
    ))
    result = main()
    exit()

# Generated at 2022-06-23 04:00:18.644736
# Unit test for function main
def test_main():
    data = dict(
        AnsibleModule=AnsibleModule
    )
    import ansible.builtin
    ansible.builtin._module_class = 'ping'
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    assert main() == dict(
        ping='pong',
        _ansible_module_class='ping',
        changed=False,
        _ansible_version='2.9.14'
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 04:00:28.412604
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:00:32.941937
# Unit test for function main
def test_main():
    m = AnsibleModule(dict(data='test'), check_mode=True)
    r = main()
    assert r['ping'] == 'test'

    m = AnsibleModule(dict(data='crash'), check_mode=True)
    try:
        r = main()
        assert False
    except:
        pass

# Generated at 2022-06-23 04:00:37.308236
# Unit test for function main
def test_main():
    """
    Validate main function with good data
    """
    # Mock module.params with valid data
    test_module_params = {
        'data': 'ping'
    }
    # Execute main function with mocked args
    output = main(test_module_params)
    # Assert the result
    assert output.get('ping', None) == 'ping'



# Generated at 2022-06-23 04:00:43.124815
# Unit test for function main
def test_main():
    class MyAnsibleModule:
        def __init__(self):
            self.params = dict(
                data='pong',
            )
            self.exit_json = lambda ret: exit_json.append(ret)
            self.fail_json = lambda msg: fail_json.append(msg)
        def exit_json(self, **kwargs): pass
        def fail_json(self, msg): pass

    exit_json = []
    fail_json = []

    main(MyAnsibleModule)
    assert exit_json == [{'ping': 'pong'}]

# Generated at 2022-06-23 04:00:50.197823
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:00:52.317859
# Unit test for function main
def test_main():
    args = dict(
        data='Hi'
        )
    result = main(args)
    assert result[0]['ping'] == 'pong'

# Generated at 2022-06-23 04:01:04.030679
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    # import ansible.module_utils.ansible_module_ping

    m_paths = sys.path[:]
    sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))

    try:
        import __init__
        #import ansible.module_utils.ansible_module_ping
    finally:
        sys.path = m_paths


# Generated at 2022-06-23 04:01:04.557800
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:01:09.328313
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:01:10.322550
# Unit test for function main
def test_main():
    # assert main() == dict()
    assert True

# Generated at 2022-06-23 04:01:17.519096
# Unit test for function main

# Generated at 2022-06-23 04:01:22.677332
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong'),
    )
    result = dict(
        ping='pong'
    )

    command_results = dict(
        changed=False,
        results='',
        rc=0,
        stderr='',
        stdout=''
    )
    m = AnsibleModule(args)
    assert m.main() == result

# Generated at 2022-06-23 04:01:25.715489
# Unit test for function main
def test_main():
  module_args = {}
  res = main(module_args)
  assert res == {'ping': 'pong'}


# Generated at 2022-06-23 04:01:26.214779
# Unit test for function main
def test_main():
	main()

# Generated at 2022-06-23 04:01:27.824767
# Unit test for function main
def test_main():
    ansible.network.ping.main()

# Generated at 2022-06-23 04:01:28.851253
# Unit test for function main
def test_main():
    print("Testing function main")
    assert main() is None

# Generated at 2022-06-23 04:01:38.682394
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    outline = ansible.module_utils.basic.AnsibleModule.exit_json
    def do_test(args, result):
        class AnsibleModuleTmp:
            def __init__(self, args):
                self.params = args
                self.check_mode = False
            def exit_json(self, **kwargs):
                assert(kwargs == result)
        args['supports_check_mode'] = True
        main(AnsibleModuleTmp(args))
    do_test({'data':'pong'}, {'ping': 'pong'})
    do_test({'data':'crash'}, {'ping': 'crash'})

# Generated at 2022-06-23 04:01:41.342823
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exit_result:
        main()
        assert exit_result.exception.code == 0

# Generated at 2022-06-23 04:01:50.230404
# Unit test for function main
def test_main():
    import tempfile

    from ansible.module_utils.basic import *
    from ansible.module_utils.six import PY2

    # Create temporary ansible.cfg and ansible.log
    f_ansible_cfg = tempfile.NamedTemporaryFile(delete=False)
    f_ansible_log = tempfile.NamedTemporaryFile(delete=False)
    f_ansible_cfg.close()
    f_ansible_log.close()

    # Env and args hack
    temp_env = os.environ.copy()
    temp_env['ANSIBLE_CONFIG'] = f_ansible_cfg.name
    temp_env['ANSIBLE_LOG_PATH'] = f_ansible_log.name


# Generated at 2022-06-23 04:01:56.909304
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert module.params['data'] == result['ping']
    assert module.params['data'] == 'pong'

# Generated at 2022-06-23 04:02:02.223161
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert test_module.params['data'] == 'pong'

# Generated at 2022-06-23 04:02:10.382932
# Unit test for function main
def test_main():
    data = 'crash'
    try:
        main()
        return 1
    except:
        return None
        
# Report errors if this is loaded as a module
if __name__ == '__main__' and test_main() is not None:
    from ansible.module_utils.common.removed import removed_module
    removed_module(" module " + __file__ + " has been removed in Ansible 2.13. ")

# Generated at 2022-06-23 04:02:11.578663
# Unit test for function main
def test_main():
    assert main() == 0


# Generated at 2022-06-23 04:02:15.251188
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:02:20.952965
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result


# Generated at 2022-06-23 04:02:25.011997
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-23 04:02:35.329171
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

    # Test with no specified data
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result_args = dict(
        ping='pong'
    )

    # Set the exit_json in the module to be a mock
    def test_exit_json(*args, **kwargs):
        assert args[0]['ping'] == 'pong'
        assert args[0]['changed'] == False
    module.exit_json = test_exit_json

    # Now, run the function module.params have been set by AnsibleModule
    main()

    # Test with data supplied

# Generated at 2022-06-23 04:02:38.944521
# Unit test for function main
def test_main():
    test_module = AnsibleModule(argument_spec=dict(data=dict(type='str')))
    assert main(test_module) == dict(ping='pong')

# Generated at 2022-06-23 04:02:51.104852
# Unit test for function main
def test_main():
    import copy
    import module_utils.basic 
    import ansible.module_utils.basic 
    import module_utils.common.network 
    import module_utils.common.remoting 
    import ansible.module_utils.common.remoting 
    import module_utils.common.text 
    import ansible.module_utils.common.text 
    import pluggy 
    import collection_loader 
    import ansible.plugins.loader 
    import ansible.plugins.action 
    import ansible.plugins.connection 
    import ansible.plugins.lookup 
    import ansible.plugins.inventory 
    import ansible.plugins.vars 
    import ansible.plugins.filter 
    import ansible.plugins.callback 
    import ansible.plugins.httpapi 

# Generated at 2022-06-23 04:03:03.637898
# Unit test for function main
def test_main():
    # AnsibleModule is a MagicMock, class type with a return_value
    # property that is a MagicMock, instance type.  The instance
    # type of the return_value has a side_effect property that is a
    # list.  Append a function to the list and when called it will
    # modify the module.params dictionary
    def exit_json(key=None, **kwargs):
        module.params.update(key=key, **kwargs)
        return

    m = MagicMock(return_value=MagicMock(side_effect=exit_json))
    module = MagicMock(AnsibleModule=m)
    assert module == main()

# Generated at 2022-06-23 04:03:11.197432
# Unit test for function main
def test_main():
    args = dict(
        data='foo',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert 'failed' not in main()
    assert main(module, args) == {"ansible_facts": {}, "changed": False, "ping": "foo"}

# Generated at 2022-06-23 04:03:17.586912
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
        data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True
    )

    assert isinstance(main(), AnsibleModule)

# Generated at 2022-06-23 04:03:27.227620
# Unit test for function main
def test_main():

    import tempfile

    # Dummy module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    with tempfile.TemporaryFile() as f:
        try:
            # Set stdout to temporary file
            sys.stdout = f

            # Call function with crash parameter
            main(module)

            # Restore stdout
            sys.stdout = sys.__stdout__

            # Raise an exception if it was not raised
            assert False, 'Exception has not been raised'
        except Exception as e:
            assert 'boom' in str(e), 'Exception message does not contain the expected text'


# Generated at 2022-06-23 04:03:40.341409
# Unit test for function main
def test_main():
    import unittest
    import os
    import tempfile
    import textwrap
    from ansible.module_utils import basic

    class ExitJsonException(Exception):
        pass
    class FailJsonException(Exception):
        pass
    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise ExitJsonException(kwargs)
    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise FailJsonException(kwargs)

    def load_fixture(name):
        pass


# Generated at 2022-06-23 04:03:53.043168
# Unit test for function main
def test_main():
    args = {
        'data': 'pong'
    }

    import json
    import sys
    from mock import patch

    from ansible.module_utils.basic import AnsibleModule

    # Exit statements are calling sys.exit()
    # so we override sys.exit with something that raises an exception
    # we can catch
    def exit(arg=0):
        raise Exception("sys.exit() called")

    with patch.object(AnsibleModule, 'exit_json') as ex_json:
        with patch.object(AnsibleModule, 'fail_json') as fail_json:
            with patch.object(AnsibleModule, 'params') as params:
                params.__getitem__.side_effect = lambda n: args[n]

# Generated at 2022-06-23 04:03:54.190149
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:04:00.106963
# Unit test for function main
def test_main():
    # See if function can be called and exits as expected
    assert callable(main)
    # Test for module failure
    try:
        main()
        assert False
    except Exception:
        assert True
    # Test for module success
    try:
        main()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-23 04:04:04.121340
# Unit test for function main
def test_main():
    '''This function will be called as a test case:
      python ansible-script.py -v --no-logger --log-path=ansible-script.log -t <test-case-file-path> <ansible-script-file-path>
    '''

    try:
        if __file__ == '__main__':
            main()
    except Exception as e:
        print("[ERROR] Exception reached: {}".format(e))
        print("[FAIL] Testcase failed")

# Generated at 2022-06-23 04:04:08.619360
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.dict_transformations import to_list
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.modules.ping import main

    import os
    import pytest

    test_cases = [
        (dict(
            ping='pong',
        ), {}),

        (dict(
            ping='pong',
        ), dict(
            data='foo',
        )),
    ]
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-23 04:04:14.842421
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic

    # Create the module object
    module_args = dict()
    module_args['data'] = 'hello'
    module_obj = basic.AnsibleModule(argument_spec=module_args)

    # call the function we are testing
    main(module_obj)

    # assert that the ping parameter is set to our value
    assert module_obj.exit_json_data['ping'] == 'hello'

# Generated at 2022-06-23 04:04:16.023192
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-23 04:04:22.898249
# Unit test for function main
def test_main():
    # Mock module
    class MockModule:
        def __init__(self, params):
            self.params = params

        def exit_json(self, **kwargs):
            return kwargs

        def fail_json(self, **kwargs):
            self.exception = kwargs['msg']

    module = MockModule({
        'data': 'pong'
    })

    # Result of main function
    result = main()

    # Asserts
    assert result == {
        'ping': 'pong'
    }, "Result is different from expected"



# Generated at 2022-06-23 04:04:33.701676
# Unit test for function main
def test_main():
    import sys
    import os
    import shlex
    module_path = os.path.abspath(os.path.dirname(__file__))
    sys.path.append(module_path)
    # Need to set ANSIBLE_MODULE_UTILS pointing to the directory where the test is run
    # so that the ansible.module_utils.* modules are found.
    os.environ['ANSIBLE_MODULE_UTILS'] = os.path.join(module_path, '..', '..', 'module_utils')
    from ansible.module_utils import basic
    if sys.version_info[0] >= 3:
        stdin = open(sys.stdin.fileno())
        stdout = open(sys.stdout.fileno(), 'wb')
    else:
        stdin = sys.stdin

# Generated at 2022-06-23 04:04:40.987032
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:04:44.376868
# Unit test for function main
def test_main():
    test = dict(data = 'pong')
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = test
    main()
    assert result == dict(ping='pong')

# Generated at 2022-06-23 04:04:52.721534
# Unit test for function main
def test_main():
# For this unit test to work, the followig is required:
# 1. PYTHONPATH need to be set to the directory that contains 'ansible'
# 2. ansible.unitT.utils.UnitTestDB has to be included in the PYTHONPATH
    from ansible.unitT.utils import UnitTestDB
    from ansible.module_utils import basic
    db = UnitTestDB()
    module = basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params['data'] = 'crash'

# Generated at 2022-06-23 04:04:53.338273
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 04:04:55.872643
# Unit test for function main
def test_main():
    m = AnsibleModule([], {})
    main()
    assert m.exit_json == 'test'

# Generated at 2022-06-23 04:04:56.970333
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:05:03.681768
# Unit test for function main
def test_main():
    import pytest
    import sys

    test_args = ['-v', '-s']
    with pytest.raises(SystemExit):
        with pytest.raises(Exception) as exc:
            with pytest.raises(SystemExit):
                sys.argv = [__file__] + test_args
                main()
        # assert exc.data.get('ping') == 'pong'

# Generated at 2022-06-23 04:05:10.288610
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert(result['ping'] == 'pong')

# Generated at 2022-06-23 04:05:15.251240
# Unit test for function main
def test_main():

    data = 'pong'

    # Create a mock instance of the AnsibleModule
    module = MockAnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Create a mock instance of the AnsibleModuleResult
    result = module.result = MockAnsibleModuleResult()

    # Execute main
    main()

    # Assert the result
    assert result.exit_json.called
    assert 'changed' not in result.exit_json.call_args[1]
    assert result.exit_json.call_args[1]['ping'] == data

# Generated at 2022-06-23 04:05:15.817188
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 04:05:19.223007
# Unit test for function main
def test_main():
    result = main()
    assert type(result) == dict
    assert 'ping' in result
    assert result['ping'] == 'pong'


# Generated at 2022-06-23 04:05:30.030751
# Unit test for function main
def test_main():
    # Test as if run from ansible core as:
    #   ansible localhost -m ping -a 'data=pong'
    # Test that we get the right args back
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    # Test that we return ping:pong
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')
    # Test that we return the right status code
    module.exit_json(**result)

# Generated at 2022-06-23 04:05:41.252369
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to_bytes
    import pytest
    import json
    def fake_params(data):
        return dict(
            _ansible_module_called_from_command_line=dict(data=data)
        )
    def fake_exit_json(data):
        sys.stdout.write(json.dumps(data, ensure_ascii=False))

# Generated at 2022-06-23 04:05:47.315402
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.builtin.ping as ping

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    module.exit_json = mock.Mock()

    ping.main()
    module.exit_json.assert_called_once_with(
        ping='pong',
        ansible_facts={},
        ansible_version=ansible.__version__,
        changed=False)

    module.exit_json.reset_mock()
    module.params['data'] = 'crash'

    with raises(Exception) as excinfo:
        ping.main()

# Generated at 2022-06-23 04:05:56.451966
# Unit test for function main
def test_main():
    pong = dict(ping='pong')

    test_cases = dict(
        normal=dict(
            data='pong',
            params=dict(
                data='pong',
            ),
            result=pong,
        ),
        crash=dict(
            data='pong',
            params=dict(
                data='crash',
            ),
            exception=True,
        ),
        custom=dict(
            data='foo',
            params=dict(
                data='foo',
            ),
            result=dict(
                ping='foo',
            ),
        ),
    )

    for test_name, test_case in test_cases.items():
        module_args = dict(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
        )


# Generated at 2022-06-23 04:06:03.617417
# Unit test for function main
def test_main():
    # Test with no parameters results in default data of "pong"
    module = AnsibleModule(argument_spec=dict())
    result = main()['ping']
    assert result == 'pong'

    # Test with data parameter of "crash" causes Exception
    module = AnsibleModule(argument_spec=dict(data='crash'))
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-23 04:06:09.270261
# Unit test for function main
def test_main():
    # Test with data='pong'
    my_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        ),
        supports_check_mode=True
    )
    if my_module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=my_module.params['data'],
    )
    assert result['ping'] == 'pong'


# Generated at 2022-06-23 04:06:22.434905
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.common.netcommon

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'
    module.params['data'] = 'test'
    assert module.params['data'] == 'test'

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-23 04:06:24.398852
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    result = dict(
        sample='Hello, world!'
    )
    assert main() == result

# Generated at 2022-06-23 04:06:35.538759
# Unit test for function main
def test_main():
    data = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Set up basic mocks
    module.exit_json = mock_exit_json(result)
    module.params = data

    main()
    assert result == {'ping': 'pong'}


# Generated at 2022-06-23 04:06:37.790382
# Unit test for function main
def test_main():
    result = {}
    with pytest.raises(Exception) as e:
        main()
    assert "boom" in str(e)

# Generated at 2022-06-23 04:06:45.118879
# Unit test for function main
def test_main():
    # Make a connection to the base class so that it can discover what transport
    # is used and invoke the correct functions.  http is required here because
    # that is the transport used to send the ansible.parsing.dataloader.DataLoader
    # .get() calls to their respective paths.
    from ansible.plugins.loader import connection_loader
    connection = connection_loader.get('http', {})

    # For Ansible 2.4, the module_utils.basic.AnsibleModule has been moved to
    # Ansible 2.6, the module_utils.basic.AnsibleModule has been removed and replaced with
    # AnsibleModule.  Make sure the new object is set up to take the same
    # arguments as the old object for backwards compatibility
    from ansible.module_utils.basic import AnsibleModule
    module_args

# Generated at 2022-06-23 04:06:49.475426
# Unit test for function main
def test_main():
    args = {
        'data': 'pong'
    }
    result = main(args)
    assert result['changed'] == False
    assert result['ping'] != ''
    assert result['ping'] == args['data']

# Generated at 2022-06-23 04:06:50.307924
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 04:06:57.122909
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.exit_json(ping='pong') == {"changed":False,"ping":"pong"}
    assert module.fail_json(msg='boom') == {"failed":True,"msg":"boom"}


# Generated at 2022-06-23 04:07:08.297968
# Unit test for function main
def test_main():
    import json
    from ansible_module_ping import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    try:
        if module.params['data'] == 'crash':
            raise Exception("boom")
    except Exception as e:
        result = dict(
            failed=True,
            msg='Exception: {0}'.format(e),
            ping=module.params['data'],
        )
    else:
        result = dict(
            ping=module.params['data'],
        )
    print(json.dumps(result))

# Generated at 2022-06-23 04:07:21.261563
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    argv = ['-m', 'ping', '-a', 'data=pong']
    req_plugins = frozenset(['ping'])

    # create the mock
    class AnsibleModuleMock(object):
        def __init__(self, argv, req_plugins):
            self._argv = argv
            self.req_plugins = req_plugins

        @staticmethod
        def exit_json(**kwargs):
            pass

        @staticmethod
        def fail_json(**kwargs):
            pass

        @property
        def params(self):
            data = {}
            for arg in self._argv:
                if '=' in arg:
                    k,v = arg.split('=')

# Generated at 2022-06-23 04:07:22.577272
# Unit test for function main
def test_main():
    a = 5
    b = 6
    assert a + b == 11, 'test failed'

# Generated at 2022-06-23 04:07:31.791365
# Unit test for function main
def test_main():
    # In order to test check mode, we need to fake some objects.
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # This breaks the contract of ping with how it exists in the main code, but it's not
    # possible to run this test without changing the interface for main to accept a module
    # so we just accept the break with the test.
    result = main(module)
    assert {'ping': 'pong'} == result

# Generated at 2022-06-23 04:07:36.254651
# Unit test for function main
def test_main():
    ansible_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    main(ansible_module)

# Generated at 2022-06-23 04:07:40.156369
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert(dict(ping = 'pong') == main())
    module.params['data'] = 'crash'
    try:
        main()
    except:
        assert(True)

# Generated at 2022-06-23 04:07:41.228422
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-23 04:07:49.902228
# Unit test for function main
def test_main():
  import ansible.module_utils.basic
  test_params = {'data': 'pong'}
  test_result = {'ping': 'pong'}
  def test_exit_json(*args, **kwargs):
    assert args[0]['changed'] == False
    assert args[0]['ansible_facts']['ping'] == 'pong'
  def test_fail_json(*args, **kwargs):
    assert False
  with ansible.module_utils.basic.AnsibleModule(argument_spec=dict(
      data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True
  ) as test_module:
    test_module.exit_json = test_exit_json
    test_module.fail_json = test_fail_json

# Generated at 2022-06-23 04:07:51.873542
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    assert main()

# Generated at 2022-06-23 04:08:04.234418
# Unit test for function main
def test_main():
    args = dict(data='pong')
    result = dict(
        ping='pong',
        changed=False,
        ansible_facts={},
        ansible_inventories={},
        ansible_play_hosts={})
    module = AnsibleModule(**args)
    m_execute_module = MagicMock()
    m_execute_module.return_value = result
    with patch.object(AnsibleModule, 'execute_module', m_execute_module):
        with patch.object(AnsibleModule, '_ansible_module', module):
            main()
            assert m_execute_module.called
            assert module.exit_json.called
            assert result == module.exit_json.call_args[0][0]
    # TODO test that the parameters are loaded correctly when the arguments are passed via

# Generated at 2022-06-23 04:08:05.862905
# Unit test for function main
def test_main():
    assert(main())


# unit test for main

# Generated at 2022-06-23 04:08:11.487389
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # params = {
    #     'data': 'pong'
    # }

    # AnsibleModule(params=params)
    # print(test_main())

    # noinspection PyUnresolvedReferences
    # assert test_main() == 'pong'
    # assert test_main()

    assert test_main()

# Generated at 2022-06-23 04:08:15.045652
# Unit test for function main
def test_main():
    import ping

    def fake_exit_json(data):
        assert data["changed"]

    ping.module = type('module', (), {
        "exit_json": fake_exit_json
    })
    ping.main()

# Generated at 2022-06-23 04:08:16.428031
# Unit test for function main
def test_main():
    # Remove if the AnsibleModule argument_spec changes
    global main
    main()

# Generated at 2022-06-23 04:08:24.344677
# Unit test for function main
def test_main():
    import sys
    import os

    path = os.path.dirname(os.path.abspath(__file__))  # We need to prepend this to sys.path.
    sys.path.insert(0, path)

    import main
    import json

    # make sure we get clean results on each run
    if os.path.exists('.ansible-module-params.json'):
        os.remove('.ansible-module-params.json')

    # Test success case.
    # .ansible-module-params.json will be dumped on disk, and later used to return data in the tests.
    args = dict(data='pong')
    main.main()
