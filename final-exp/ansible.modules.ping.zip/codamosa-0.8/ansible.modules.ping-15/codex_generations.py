

# Generated at 2022-06-11 07:36:01.871398
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-11 07:36:02.875677
# Unit test for function main
def test_main():
    # check 0
    assert main() == None


# Generated at 2022-06-11 07:36:03.350505
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:36:06.052589
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:36:12.339553
# Unit test for function main
def test_main():
    import sys
    if sys.version_info.major == 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    func_for_mock = MagicMock()

    mod_dict = dict(
        main=func_for_mock,
        AnsibleModule=MagicMock()
    )

    with patch.dict(sys.modules, mod_dict):
        import ansible.builtin.ping as ping
        ping.main()

    assert func_for_mock.call_count == 1

# Generated at 2022-06-11 07:36:13.857636
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        raise e


# Generated at 2022-06-11 07:36:14.428578
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:36:23.713255
# Unit test for function main
def test_main():

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    assert not is_sequence(result)
    assert isinstance(result, dict)

# Generated at 2022-06-11 07:36:25.658475
# Unit test for function main
def test_main():
    print("test main")
    main()


# Generated at 2022-06-11 07:36:27.490210
# Unit test for function main
def test_main():
    print('Testing ping')
    # No data
    result = main()
    assert result == 'pong'

    # Crash
    result = main()
    assert result == Exception('boom')

# Generated at 2022-06-11 07:36:40.459381
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert(module.params['data'] == 'pong')

# Generated at 2022-06-11 07:36:44.161368
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    result = main(module)
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:36:51.508548
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as exit_json_mock:
        with patch.object(AnsibleModule, 'params') as params_mock:
            params_mock.__getitem__.return_value = 'pong'
            with pytest.raises(AnsibleExitJson):
                # call function under test
                main()
            # assert results
            assert exit_json_mock.call_count == 1
            exit_json_mock.assert_called_with(ansible_facts=dict(ping='pong'))



# Generated at 2022-06-11 07:36:57.392600
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(
        ping='pong',
    )

# Generated at 2022-06-11 07:37:03.602214
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # test exception
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-11 07:37:07.022239
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == "pong"

# Generated at 2022-06-11 07:37:07.576840
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:37:14.285300
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert main() == dict(
        ansible_facts=dict(ping=module.params['data']),
        ansible_included_var_files=ImmutableDict(),
        ansible_modules=ImmutableDict(),
        changed=False
    )

# Generated at 2022-06-11 07:37:21.562231
# Unit test for function main
def test_main():
    func_name = 'main'
    # Set up mocks
    functions = {
        'AnsibleModule': MagicMock(),
        'module.exit_json': MagicMock(),
    }
    module = MagicMock(**functions)
    module.params = {
        'data': 'crash'
    }
    # Trigger the exception
    with pytest.raises(Exception) as excinfo:
        main()
    error_msg = str(excinfo.value)
    assert error_msg == "boom"

# Generated at 2022-06-11 07:37:29.602773
# Unit test for function main
def test_main():
    import pytest
    import sys
    import os

    # Declare return_values
    return_values = [
        dict(msg=""),
        dict(changed=False, ping="pong"),
        dict(changed=True, ping="pong"),
        dict(failed=True)
    ]

    def _mock_AnsibleModule(spec, **kwargs):
        mock_AnsibleModule = MagicMock()
        mock_AnsibleModule_instance = mock_AnsibleModule.return_value

        mock_AnsibleModule_instance.params = spec
        mock_AnsibleModule_instance.fail_json.side_effect = return_values.pop()
        mock_AnsibleModule_instance.exit_json.side_effect = return_values.pop()

        return mock_AnsibleModule_instance



# Generated at 2022-06-11 07:37:51.630277
# Unit test for function main
def test_main():
    args = {
        'data': 'crash',
    }

    from ansible.modules.network.ping import main
    m = AnsibleModule(**args)
    import pytest
    with pytest.raises(Exception) as excinfo:
        main()
    assert 'boom' in str(excinfo.value)

# Generated at 2022-06-11 07:37:56.457813
# Unit test for function main
def test_main():
    def my_exit_json(**kwargs):
        return kwargs

    def my_Fail_json(**kwargs):
        return kwargs

    ansible_module_instance = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    ansible_module_instance.exit_json = my_exit_json
    ansible_module_instance.fail_json = my_Fail_json
    main()

# Generated at 2022-06-11 07:38:00.938216
# Unit test for function main
def test_main():
    # Test basic function
    assert(main() == {'ping': 'pong'})
    # Test with parameter data set to 'boom' and 'boom'
    assert(main(data='crash') == 'crash')

# Generated at 2022-06-11 07:38:07.116404
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:38:11.917545
# Unit test for function main
def test_main():
    # Mode to use for creating the module instance
    module_args = {
        'data': 'pong'
    }

    # AnsibleModule instance to be used for creating the test case
    module = AnsibleModule(**module_args)

    # Main module call
    main()

    # Result of the module execution
    # **module.result** is a dictionary that contains the success or failed status and the the result data
    assert module.result['ping'] == 'pong'

# Generated at 2022-06-11 07:38:17.572805
# Unit test for function main
def test_main():
    input = dict(
        data='pong'
        )

    result = dict(
        ping='pong'
        )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
        )
    newResult = AnsibleModule.exit_json(module, **result)
    assert newResult == result

# Generated at 2022-06-11 07:38:21.781446
# Unit test for function main
def test_main():
    # Without any params, we can't do anything
    with pytest.raises(os.error):
        main()

    # Assert that we return data when data param is set
    with pytest.raises(os.error):
        main({'data': 'pong'})

# Generated at 2022-06-11 07:38:33.085421
# Unit test for function main
def test_main():
    from ansible.module_utils.common.dataloader import DataLoader
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    mock_loader = DataLoader()

    # Data is expected to be JSON encoded
    mock_loader.load_from_file = lambda _: dict(data=AnsibleJSONEncoder().encode("pong"))

    # The module only prints a string and then exits
    # This can't be detected by ansible_module_runner
    ansible_module_runner = lambda _: "pong"

    # Create our module with the normal runtime arguments
    # Our module is hard coded with an argument specification, so we just
    # construct a parameter dict with what we need to pass the module and
    # then pass it to the module to be processed

# Generated at 2022-06-11 07:38:41.447843
# Unit test for function main
def test_main():
    with patch.object(builtins, '__import__') as mock_import:
        mock_module = MagicMock()

        mock_import.return_value = mock_module
        ping.main()

        mock_import.assert_called_once_with('ansible.module_utils.basic', fromlist=('AnsibleModule',))
        assert mock_module.AnsibleModule.call_args == call(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )

        assert mock_module.exit_json.call_args == call(ping='pong')

# Generated at 2022-06-11 07:38:49.185557
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    try:
        main()
    except Exception as e:
        assert('boom' in str(e))
    test_module.params['data'] = 'pong'
    test_result = dict(
        ping=test_module.params['data'],
    )
    test_module.exit_json(**test_result)

# Generated at 2022-06-11 07:39:25.009183
# Unit test for function main
def test_main():
    #ansible_module = AnsibleModule(function_name, function_args)
    #ansible_module.exit_json(**result)
    pass


# Generated at 2022-06-11 07:39:34.890643
# Unit test for function main
def test_main():
    # Mock out the built-in open function, so we can assert that it is called
    # with the appropriate parameters, as well as return a magic mock instead
    # of a real file handle
    with patch('__builtin__.open', mock_open()) as m:
        # Call the function under test
        main()
        # Assert that the call to 'open' was made with the expected parameters
        m.assert_called_once_with('/etc/passwd', 'w')

        # Get a "handle" to the mocked open function
        handle = m()

        # Assert that the mocked file handle was written to with the
        # appropriate "data"
        handle.write.assert_called_once_with('hello\n')

# Generated at 2022-06-11 07:39:39.058195
# Unit test for function main
def test_main():
    test_args = dict(data='pong')
    res_args = dict(changed=False, ping='pong')
    with pytest.raises(Exception):
        main(test_args.copy(), dict(data='crash'))


# vim: set noexpandtab ts=4 sw=4 ft=python :

# Generated at 2022-06-11 07:39:43.296609
# Unit test for function main
def test_main():
    args = dict(
        data = 'pong',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert ping.main() == None


# Generated at 2022-06-11 07:39:47.925049
# Unit test for function main
def test_main():
    import tempfile, os.path
    cmd = ['ansible-doc', 'ping']
    output = tempfile.mkstemp()
    outf = output[0]
    try:
        with open(outf, "w") as f:
            main(cmd, f)
        assert os.path.exists(output[1])
    finally:
        os.unlink(output[1])

# Generated at 2022-06-11 07:39:49.076375
# Unit test for function main
def test_main():
    assert ping.main() == {'ping': 'pong'}

# Generated at 2022-06-11 07:39:52.666201
# Unit test for function main
def test_main():
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    results = dict()

    data = "Test"
    results['ping'] = data
    fname = tempfile.mktemp()
    fd = open(fname, 'w')
    fd.write(to_bytes(module))
    fd.close()
    testmodule = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    testmodule.exit_json(**results)

    # Finally remove testfile
    os.unlink(fname)



# Generated at 2022-06-11 07:40:00.995325
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    from ansible.module_utils.facts import ansible_module_exit_args

    mod_args = dict(
        data=dict(type='str', default='pong'),
    )

    # input data for ansible_module
    ansible_module_args = dict(
        argument_spec=mod_args,
        supports_check_mode=True,
        check_invalid_arguments=False,
        bypass_checks=True,
    )

    # output data from ansible_module
    ansible_result = dict(
        ping='pong',
    )

    # exit arguments from ansible_module (exit code, exit msg)

# Generated at 2022-06-11 07:40:03.160581
# Unit test for function main
def test_main():
    print(
        test_module(
            dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
    )

# Generated at 2022-06-11 07:40:10.790500
# Unit test for function main
def test_main():
    result = dict(
        ping='pong',
    )
    # We only support check_mode on posix based hosts
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        platform='linux',
    )

    try:
        main_result = main(module)
    except Exception:
        main_result = dict(
            failed=True,
            ping='FAILURE',
            exception=traceback.format_exc(),
        )

    if importlib.util.find_spec('pytest_mock'):
        # Our pytest-ansible plugin has patched module_utils.basic._ANSIBLE_ARGS to
        # match what we want in this test
        assert main_result == result



# Generated at 2022-06-11 07:40:57.637716
# Unit test for function main
def test_main():
    # Check that module exits without error
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data']
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:41:07.779599
# Unit test for function main
def test_main():

    from ansible.modules.system.ping import main
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.six import PY3

    # test command line parameters

# Generated at 2022-06-11 07:41:18.159162
# Unit test for function main
def test_main():
    test_args = {
        'data': "test",
    }
    ansible_args = {}
    import ansible.constants as C
    # We need a dummy class that we can stuff the return values into
    class ModuleResult(object):
        def __init__(self, exit_args, exit_json, fail_json):
            self.exit_args = exit_args
            self.exit_json = exit_json
            self.fail_json = fail_json
            self.params = {}
            self.check_mode = False
            self.diff = False
            self.connection = 'local'

    mr = ModuleResult(dict(rc=0), dict(), dict())

# Generated at 2022-06-11 07:41:23.826979
# Unit test for function main
def test_main():
    module_name, namespace, kwargs = main()
    assert module_name == 'ansible.builtin.ping'
    assert namespace == 'ansible_module_ping'
    assert type(kwargs) == dict
    assert 'AnsibleModule' in kwargs
    assert 'argument_spec' in kwargs
    assert 'supports_check_mode' in kwargs
    assert 'data' in kwargs['argument_spec']

# Generated at 2022-06-11 07:41:25.410101
# Unit test for function main
def test_main():

    # Data for test
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-11 07:41:29.639016
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type = 'str', default = 'pong'),
        ),
        supports_check_mode = True
    )
    module.exit_json(**{'ping': 'pong'})


# Generated at 2022-06-11 07:41:33.618933
# Unit test for function main
def test_main():
    module = MockAnsibleModule()
    module.params = {'data': 'pong'}

    result = dict(
        ping=module.params['data'],
    )

    main()
    assert True


# Generated at 2022-06-11 07:41:34.713222
# Unit test for function main
def test_main():
    try:
        main()
    except:
        pass

# Generated at 2022-06-11 07:41:39.764054
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:41:40.250468
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:43:22.432829
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:43:23.489899
# Unit test for function main
def test_main():
    assert 1 == 1, 'Failed unit test'

# Generated at 2022-06-11 07:43:31.296298
# Unit test for function main
def test_main():
    ansible_args = dict(
        data=dict(type='str', default='pong'),
    )
    with patch('ansible.module_utils.basic.AnsibleModule'):
        with patch('ansible.module_utils.basic.AnsibleModule.exit_json') as mock_exit_json:
            with patch('ansible.module_utils.basic.AnsibleModule.fail_json') as mock_fail_json:
                assert main(ansible_args) == 'pong'
                assert mock_exit_json.call_count == 1
                assert mock_fail_json.call_count == 0

# Generated at 2022-06-11 07:43:32.129412
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-11 07:43:35.413142
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    result = dict(
        ping=module.params['data'],
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:43:39.200728
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.six
    import ansible.module_utils.netcommon
    import ansible.module_utils.snmp
    import ansible.module_utils.windows
    main()

# Generated at 2022-06-11 07:43:41.999025
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main(module) is None

# Generated at 2022-06-11 07:43:42.779974
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-11 07:43:48.040674
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result["ping"] == 'pong'

# Generated at 2022-06-11 07:43:51.941294
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')