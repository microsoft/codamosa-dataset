

# Generated at 2022-06-11 07:36:11.222668
# Unit test for function main
def test_main():
    import copy
    import __builtin__ as builtins

    def exit_json(*args, **kwargs):
        if 'changed' in kwargs:
            assert kwargs['changed'] is True
            del kwargs['changed']
        assert args[0] == dict(ping='pong')
        return args, kwargs

    def exit_failure(*args, **kwargs):
        pass

    setattr(builtins, 'exit_json', exit_json)
    setattr(builtins, 'exit_failure', exit_failure)

    m = copy.deepcopy(module)
    params = copy.deepcopy(m.params)
    with pytest.raises(Exception) as execinfo:
        m.params = dict(data='crash')


# Generated at 2022-06-11 07:36:15.967435
# Unit test for function main
def test_main():
    in_data = dict(data='pong')
    in_check_mode = False
    out_result = dict(ping='pong')

    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=in_check_mode)
    module.params = in_data.copy()
    module.exit_json(**out_result)

# Generated at 2022-06-11 07:36:18.819238
# Unit test for function main
def test_main():
  args = dict(
    data = 'pong',
  )
  result = dict(
    ping = 'pong'
  )
  module = AnsibleModule(argument_spec=args)
  module.exit_json(**result)


# Generated at 2022-06-11 07:36:21.759524
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    main()


# Generated at 2022-06-11 07:36:22.768105
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:36:27.902595
# Unit test for function main
def test_main():
    # Module ping with options data=test
    module = AnsibleModule(
        {
            'data': 'test'
        },
        check_mode=False
    )
    result = main()

    # Assert that main returns expected values
    assert module.exit_json.called_once
    assert module.exit_json.call_args[0][0]['ping'] == 'test'

# Generated at 2022-06-11 07:36:31.625183
# Unit test for function main
def test_main():
    test = dict(
        data = 'pong'
    )
    result = dict(
        ping='pong',
    )

    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))

    module.params = test
    main()
    assert module.exit_json == result

# Generated at 2022-06-11 07:36:34.807127
# Unit test for function main
def test_main():
    # Dummy result
    d_result = {"msg": "ok"}
    # Undefined arguments
    d_args = {}
    # Create a function call
    res = main(d_args)
    # Check result is equal with dummy result
    assert res == d_result

# Generated at 2022-06-11 07:36:43.588905
# Unit test for function main
def test_main():
    print("Test main function")
    # mock_module is an object that can be used as if it were a module
    with mock.patch.object(ansible.module_utils.basic.AnsibleModule, 'from_json') as mock_from_json:
        with mock.patch.object(ansible.module_utils.basic.AnsibleModule, 'exit_json') as mock_exit_json:
            main()
            # verify that exit_json was called with the expected arguments
            mock_exit_json.assert_called_once_with(msg="Not implemented yet")

# Generated at 2022-06-11 07:36:45.044502
# Unit test for function main
def test_main():
    result = main(['pong'])
    assert result == 0

# Generated at 2022-06-11 07:36:56.340365
# Unit test for function main
def test_main():
    # make sure we get 'pong' back
    args = ['-m', 'ping', '-a', 'data=pong', 'localhost']
    rc, out, err = module_execute(module_args=args)
    assert rc == 0
    assert out == '{"ping": "pong"}\n'
    assert err == ''

    # make sure we bomb on 'crash'
    args = ['-m', 'ping', '-a', 'data=crash', 'localhost']
    rc, out, err = module_execute(module_args=args)
    assert rc == 1
    assert out.startswith('{"msg":')
    assert out.endswith('Traceback (most recent call last):\\n  File "/tmp')
    assert err.startswith('The full traceback is:\\n')
   

# Generated at 2022-06-11 07:36:59.091508
# Unit test for function main
def test_main():
    module_mock = mock.Mock()
    module_mock.params = {'data': 'crash'}
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-11 07:37:05.909585
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.language

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    print(result)

# Generated at 2022-06-11 07:37:11.584958
# Unit test for function main
def test_main():
    # See
    # https://docs.pytest.org/en/latest/writing_plugins.html#assertion-rewriting
    # for how to write a unit test for this module.
    raise DeprecationWarning("Not writing unit tests for this deprecated module")

    #from ansible.modules.network.ping import main

    #data = '{"ping": "pong"}'
    #from ansible.module_utils.basic import AnsibleModule
    #AnsibleModule.from_json(data)

# Generated at 2022-06-11 07:37:16.571225
# Unit test for function main
def test_main():
    # check that we can ping when valid data is supplied
    result = AnsibleModule({'data': 'pong'}, check_mode=False).exit_json
    assert(result['changed'] == False)
    assert(result['ping'] == 'pong')
    # check that we exit with an error when invalid data is supplied
    with pytest.raises(Exception):
        result = AnsibleModule({'data': 'crash'}, check_mode=False).exit_json

# Generated at 2022-06-11 07:37:22.322735
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    test_module.params = {'data': 'pong'}

    result = dict(
        ping=test_module.params['data'],
    )

    test_module.exit_json(**result)

# Generated at 2022-06-11 07:37:24.333300
# Unit test for function main
def test_main():
    is_error, has_changed, result = main()
    assert result == dict(
        ping='pong',
    )

# Generated at 2022-06-11 07:37:25.958373
# Unit test for function main
def test_main():
    res = main()
    assert res == None

# Generated at 2022-06-11 07:37:27.389018
# Unit test for function main
def test_main():
    import ansible.modules.ping as ping
    ping.main()

# Generated at 2022-06-11 07:37:37.112822
# Unit test for function main
def test_main():
    # Need to mock the AnsibleModule class
    class AnsibleExitJson(Exception):
        def __init__(self, *args):
            self.args = args


    class AnsibleFailJson(Exception):
        def __init__(self, *args):
            self.args = args


    class AnsibleModule(object):
        def __init__(self, *args):
            self.args = args
            self.exit_json = lambda *args, **kwargs: None
            raise AnsibleExitJson

        def fail_json(self, *args):
            self.exit_json = lambda *args, **kwargs: None
            raise AnsibleFailJson

    import sys

    def exit_json(*args):
        raise AnsibleExitJson(*args)

    def fail_json(*args):
        raise Ans

# Generated at 2022-06-11 07:37:46.519197
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-11 07:37:52.897614
# Unit test for function main
def test_main():
    module_args = dict(
        data='foo',
    )
    ping_result = dict(
        ansible_facts=dict(
            ping='foo',
        ),
        changed=False,
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )

    module.check_mode = False
    result = main()
    assert result == ping_result



# Generated at 2022-06-11 07:38:02.345004
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert test_module.main() == {'changed': False, 'ping': 'pong'}

    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )

    try:
        test_module.main()
    except Exception as e:
        assert str(e) == 'boom'
    else:
        assert False, 'Should have thrown exception'

# Generated at 2022-06-11 07:38:03.500679
# Unit test for function main
def test_main():

    assert main() == "pong"


# Generated at 2022-06-11 07:38:04.961175
# Unit test for function main
def test_main():
    if not main() == True:
        raise AssertionError

# Generated at 2022-06-11 07:38:11.511180
# Unit test for function main
def test_main():

    # Test with a one int argument, the default value
    ping_int = module.params['data']
    assert ping_int == 'pong'

    # Test with a one string argument, the default value
    ping_str = module.params['data']
    assert ping_str == 'pong'

    # Test with a one float argument, the default value
    ping_float = module.params['data']
    assert ping_float == 'pong'

    # Test with a one list argument, the default value
    ping_list = module.params['data']
    assert ping_list == 'pong'

# Generated at 2022-06-11 07:38:22.457786
# Unit test for function main
def test_main():
    # test with no parameters
    module = AnsibleModule(argument_spec=dict())
    result = dict(
        ping='pong',
    )
    module.exit_json(**result)

    # test with no parameters
    module = AnsibleModule(argument_spec=dict())
    result = dict(
        ping='pong',
    )
    module.exit_json(**result)

    # test with data as a parameter
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    module.exit_json(**result)

    # test with data=crash as a parameter

# Generated at 2022-06-11 07:38:24.783365
# Unit test for function main
def test_main():
    # Unit test for function
    # assert module.exit_json.called
    # assert ping == 'pong'
    return True

# Generated at 2022-06-11 07:38:36.136064
# Unit test for function main
def test_main():
  try:
    import ansible.utils.jsonfun as jsonfun
  except ImportError:
    import json as jsonfun
  from ansible.module_utils.basic import AnsibleModule

  test_data = dict(
      data='value',
  )
  module = AnsibleModule(
      argument_spec=dict(
          data=dict(type='str', default='pong'),
      ),
      supports_check_mode=True
  )
  module.exit_json = lambda d: d
  ping = main()
  ping = jsonfun.loads(ping)
  assert ping.get('ping') == 'value'

  test_data = dict(
      data='crash',
  )

# Generated at 2022-06-11 07:38:36.924685
# Unit test for function main
def test_main():
    raise Exception("unit testing not implemented")

# Generated at 2022-06-11 07:38:55.822054
# Unit test for function main
def test_main():
    module_args = dict(data=dict(type='str', default='pong'))
    result = dict(
        ping=module_args['data'],
    )
    assert main(module_args) == dict(changed=False, meta=result)

# Generated at 2022-06-11 07:39:01.536068
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:39:06.550549
# Unit test for function main
def test_main():
    with patch("ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule") as mock_module:
        mock_module.return_value.params.return_value = {'data':'pong'}
        result = main()
        assert result == {'changed': False, 'ping': 'pong'}


# Generated at 2022-06-11 07:39:08.973377
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-11 07:39:18.717811
# Unit test for function main
def test_main():
    test_args = {'data': 'pong'}
    with mock.patch.object(AnsibleModule, 'from_json') as am_from_json:
        am = AnsibleModule(argument_spec={'data': dict(type='str', default='pong')})
        am_from_json.return_value = am
        with mock.patch.object(AnsibleModule, 'exit_json') as am_exit_json:
            main()
            assert am_from_json.call_count == 1
            args, kwargs = am_from_json.call_args
            assert args == ()
            assert kwargs == dict(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)
            assert am_exit_json.call_count == 1


# Generated at 2022-06-11 07:39:19.272545
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:39:20.302946
# Unit test for function main
def test_main():
    test = main
    assert main == test

# Generated at 2022-06-11 07:39:30.828913
# Unit test for function main
def test_main():
    args = {}
    expected = {
        'ping': 'pong'
    }
    result = {'ping': None}

    new_module = MagicMock()
    new_module.params = args
    new_module.exit_json = lambda result: result.update(result)

    def mock_exit(*args):
        raise SystemExit

    new_module.exit_json.side_effect = mock_exit

    main(new_module)

    assert result ==  expected

# Generated at 2022-06-11 07:39:35.628097
# Unit test for function main

# Generated at 2022-06-11 07:39:41.767659
# Unit test for function main
def test_main():
    args = {
        'data': 'pong'
    }
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module_result = {
        'changed': False,
        'failed': False,
        'ping': 'pong'
    }
    result = main(args, module)
    assert result == module_result

# Generated at 2022-06-11 07:40:29.294941
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )


    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:40:30.337669
# Unit test for function main
def test_main():
    attrs = main()
    # test return value
    assert type(attrs) == dict

# Generated at 2022-06-11 07:40:32.414125
# Unit test for function main
def test_main():
    test_dict = dict(
        data = 'test'
    )
    result = main()

# Generated at 2022-06-11 07:40:37.811153
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() is None
    assert module.params['data'] == 'pong'
    assert module.exit_json()['invocation']['module_name'] == 'ansible.builtin.ping'
    assert module.exit_json()['ping'] == 'pong'

# Generated at 2022-06-11 07:40:46.606595
# Unit test for function main
def test_main():
    import pytest

    # no args -- just testing to see that main() runs and returns an object
    # that appears to be a valid AnsibleModuleResult object
    assert main()

    # test to see that module returns a value
    with pytest.raises(AnsibleException):
        assert main(dict(data='crash'))

    # test with data=abc
    assert main(dict(data='abc')) == dict(
        ansible_facts=dict(
            ping='abc',
        ),
    )

    # test with invalid data
    with pytest.raises(AnsibleException):
        assert main(dict(data=None)) != dict(
            ansible_facts=dict(
                ping=None,
            ),
        )

# Generated at 2022-06-11 07:40:51.185741
# Unit test for function main
def test_main():

    # Setup and supply function parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
       ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:40:53.508226
# Unit test for function main
def test_main():
    # hack to make sure we have the correct function name
    main.__name__ = 'main'
    main()
    main.__name__ = 'test_main'

# Generated at 2022-06-11 07:40:56.828360
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:41:02.200639
# Unit test for function main
def test_main():
    mod = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=mod.params['data'],
    )

    mod.exit_json(**result)
    
    


# Generated at 2022-06-11 07:41:10.756594
# Unit test for function main
def test_main():
    import module_utils.network as network_utils
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    class TestPing(unittest.TestCase):

        def setUp(self):
            self.mock_module = patch.multiple(basic.AnsibleModule, exit_json=exit_json, fail_json=fail_json)
            self.mock_module.start()
            self.addCleanup(self.mock_module.stop)
            self.mock_exit_json = exit_json
            self.mock_fail_json = fail_json

# Generated at 2022-06-11 07:42:29.768616
# Unit test for function main
def test_main():
    data = dict(
        data='pong',
    )
    res = main(data=data)
    assert res['sample'] == 'pong'

# Generated at 2022-06-11 07:42:32.757737
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:42:33.383880
# Unit test for function main
def test_main():
  pass

# Generated at 2022-06-11 07:42:41.977714
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.utils.vars import merge_hash
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import ModuleData
    
    class ModuleReturnValueMock(Mapping):
        def __init__(self):
            self.value = None
            self.__getitem__ = self.getitem

        def getitem(self, key):
            return self.value

        def __repr__(self):
            return '{0}'.format(self.value)

    class ModuleExitJsonMock(object):
        def __init__(self, module_ret_val):
            self.module_ret_val = module_ret_val


# Generated at 2022-06-11 07:42:47.463274
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-11 07:42:54.564648
# Unit test for function main
def test_main():
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.basic import AnsibleModule

  module = AnsibleModule(
      argument_spec=dict(
          data=dict(type='str', default='pong'),
      ),
      supports_check_mode=True
  )

  try:
    with pytest.raises(SystemExit):
      main()
  except Exception as e:
    pytest.fail("Unexpected Exception: " + str(e))

  assert module.exit_json.called
  assert module.exit_json.call_args[0][0] == {}
  assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:42:57.687395
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # run module
    try:
        main()
    # catch exceptions
    except Exception as e:
        module.fail_json(msg=e)

# Generated at 2022-06-11 07:43:01.999990
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:43:06.733872
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:43:07.877661
# Unit test for function main
def test_main():
    # this test is required to make sure the function main exists.
    pass