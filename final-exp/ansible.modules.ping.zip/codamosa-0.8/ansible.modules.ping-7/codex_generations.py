

# Generated at 2022-06-11 07:36:02.383530
# Unit test for function main
def test_main():
    """Test module."""

    #FIXME: replace this with a proper unit test
    pass

# Generated at 2022-06-11 07:36:05.853006
# Unit test for function main
def test_main():
    os.environ['ANSIBLE_MODULE_ARGS'] = json.dumps({
        "data": { "default": "pong", "type": "str" }
    })
    assert main() == { "ping": "pong" }

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 07:36:14.913240
# Unit test for function main
def test_main():
    import copy
    import sys
    import ansible.constants as C
    from ansible.module_utils import basic

    m_basic = basic

    reload(sys)
    sys.setdefaultencoding('utf8')


# Generated at 2022-06-11 07:36:15.477754
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:36:17.766910
# Unit test for function main
def test_main():
    """This test is untested because it's a trivial function. Currently there's a bug in the test runner so that we can't
       test trivial functions.
    """
    pass

# Generated at 2022-06-11 07:36:22.891227
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    args = {'data': 'prong'}
    with patch.object(AnsibleModule, 'exit_json', return_value=None) as exit_json_mock:
        main()
        assert exit_json_mock.call_count == 1
        assert exit_json_mock.call_args == call({'ping': 'prong'})

# Generated at 2022-06-11 07:36:24.762130
# Unit test for function main
def test_main():
    result = main()
    assert result == {'ping': 'pong'}

# Generated at 2022-06-11 07:36:27.940542
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main(test_module) == {"ping": "pong"}

# Generated at 2022-06-11 07:36:31.664152
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )


# Generated at 2022-06-11 07:36:35.537159
# Unit test for function main
def test_main():
    # Given
    module_args = dict(
        data='pong',
    )

    testmodule = AnsibleModule(argument_spec=module_args)
    testmodule.exit_json = lambda **kwargs: True

    # When
    main()

    # Then
    assert testmodule.params["data"] == 'pong'


# Generated at 2022-06-11 07:36:44.928251
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-11 07:36:45.531115
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:36:46.559389
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-11 07:36:49.427901
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == None

# Generated at 2022-06-11 07:36:54.820088
# Unit test for function main
def test_main():
    # Module must have params under the _params variable
    # The data parameter must be set by the user
    # Using a MagicMock object to mimic the AnsibleModule class
    mock_module = MagicMock()
    mock_module._params = {'data': 'pong'}

    # Define variables to be used in the unit test
    expected_result = {'ping': 'pong'}

    # Run the main function from the ping module and check that it returns the expected result
    assert main(mock_module) == expected_result


# Generated at 2022-06-11 07:36:59.921598
# Unit test for function main
def test_main():
    test_module = {'data': 'ping'}
    test_obj = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    test_res = main(test_obj)
    assert test_res == {'changed': False, 'ping': 'ping'}

# Generated at 2022-06-11 07:37:09.974961
# Unit test for function main
def test_main():
    def _failing_executor():
        raise Exception("boom")

    class MockModule(object):
        class AnsibleModule(object):
            def __init__(self, argument_spec, **kwargs):
                self.params = kwargs['params']
        def __init__(self, **kwargs):
            self.module = self.AnsibleModule(kwargs['argument_spec'], params=kwargs['params'])
            self.exit_json = kwargs['exit_json']
            self.fail_json = kwargs['fail_json']
            raise Exception("shouldn't have called this")


# Generated at 2022-06-11 07:37:13.936058
# Unit test for function main
def test_main():
    with open('test/fixtures/ping.yml') as pingfile:
        docfile = yaml.dump(yaml.load(pingfile), default_flow_style=False)
        assert len(docfile) > 0
        assert docfile.startswith("---")


# Generated at 2022-06-11 07:37:19.507929
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:37:25.961330
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:37:42.443378
# Unit test for function main
def test_main():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # TODO: Mock the module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    os.environ['ANSIBLE_MODULE_ARGS'] = to_bytes(json.dumps({'data': 'pong'}))

    aping_m.main()

    assert result['changed'] == False
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:37:53.015805
# Unit test for function main
def test_main():
    m = AnsibleModule(argument_spec=dict(data=dict()), check_invalid_arguments=False, check_required_arguments=False)
    assert hasattr(m, 'argument_spec')
    assert hasattr(m, 'supports_check_mode')
    assert m.argument_spec == dict(data=dict(default='pong', type='str'))
    assert m.supports_check_mode == True
    assert m.params == dict(data='pong')
    assert m.check_mode == False

    def fail_json_test(self, **kwargs):
        self.fail_json_called = True

    def exit_json_test(self, **kwargs):
        self.exit_json_called = True

    setattr(m, 'fail_json', fail_json_test)


# Generated at 2022-06-11 07:37:53.510499
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:38:05.018039
# Unit test for function main
def test_main():
    import sys

    test_data = [
        {
            'data': 'pong',
            'expected':
            {
                'changed': False,
                'ping': 'pong',
            }
        },
        {
            'data': 'crash',
            'expected':
            {
                'changed': True,
                'failed': True,
            }
        }
    ]

    for test in test_data:
        with AnsibleModule(argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        ) as am:
            am.params = test['data']
            try:
                main()
            except SystemExit as e:
                if test['expected'].get('failed', False):
                    assert e.code == 1


# Generated at 2022-06-11 07:38:13.014313
# Unit test for function main
def test_main():
    from ansible.module_utils.common.module_utils import basic
    from ansible.module_utils.common.io import StringIO
    import json
    import pytest

    # Build mock for basic.AnsibleModule and args
    class TestModule:
        def __init__(self, a, b):
            self.params = a
            self.debug = b
    mock_module = TestModule({}, {})
    mock_args = {
        'ansible_module_args': {
            'data': 'pong',
        },
    }

    # Build mock for class basic.AnsibleModule and its return values
    def mock_return(a):
        return a
    mock_ansible_module = basic.AnsibleModule(mock_args)
    mock_ansible_module._load_params = mock_

# Generated at 2022-06-11 07:38:18.239667
# Unit test for function main
def test_main():
    # external import in function
    global AnsibleModule
    AnsibleModule = collections.namedtuple('AnsibleModule', 'check_mode,params')
    module = AnsibleModule(check_mode=False, params={'data':'pong'})
    assert(module.exit_json(ping=module.params['data']) == {'ping':'pong'})

# Generated at 2022-06-11 07:38:18.891152
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:38:19.511843
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:38:24.070551
# Unit test for function main
def test_main():
    test_data = {'data': u'pong'}
    test = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    test.exit_json(**test_data)

# Generated at 2022-06-11 07:38:35.401547
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.tests.unit.compat.mock import MagicMock, patch

    def get_module_mock(params):
        module_mock = MagicMock(params=params)
        return module_mock

    def get_check_mode_mock(check_mode):
        check_mode_mock = MagicMock(check_mode=check_mode)
        return check_mode_mock

    def get_result_mock(ping):
        result_mock = {
            'ping': ping
        }
        return result_mock

    def get_ansible_module_mock(return_value):
        ansible_module_mock = MagicMock(exit_json=return_value)

# Generated at 2022-06-11 07:38:56.507941
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")



# Generated at 2022-06-11 07:39:06.796703
# Unit test for function main
def test_main():
    from mock import patch
    from io import StringIO

    module = patch.multiple(AnsibleModule, exit_json=lambda *args, **kwargs: None).start()

    # Example response from: ansible localhost -m ping -a "data=pong"
    output = u'{"changed": false, "ping": "pong"}'
    output_lines = output.split("\n")

    unicode_stdin = StringIO(u'{"ANSIBLE_MODULE_ARGS": {"data": "pong"}}')
    unicode_stdout = StringIO()
    unicode_stderr = StringIO()

# Generated at 2022-06-11 07:39:08.932409
# Unit test for function main
def test_main():
    # Main test
    assert main == 2

# Generated at 2022-06-11 07:39:14.486469
# Unit test for function main
def test_main():
    mock_module = Mock(return_value=None)
    with patch.dict(ansible_builtin_ping.__dict__,
                    {'AnsibleModule': mock_module}):
        ansible_builtin_ping.main()
    assert mock_module.call_args[0][0]['argument_spec'] == dict(data=dict(type='str', default='pong'))

# Generated at 2022-06-11 07:39:22.202322
# Unit test for function main
def test_main():
    # Fixture
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.ansible_release import __version__

    args = dict(
        data='pong',
    )

    # Mocking module
    try:
        from unittest.mock import patch
        from unittest.mock import MagicMock
    except ImportError:
        from mock import patch
        from mock import MagicMock

    mocked_module = MagicMock(spec=AnsibleModule)
    mocked_module.check_mode = False


# Generated at 2022-06-11 07:39:33.166431
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    class AnsibleExitJson():
        def __init__(self, data):
            self.data = data

        def exit_json(self, **kwargs):
            self.kwargs = kwargs

    class AnsibleFailJson():
        def __init__(self, data):
            self.data = data

        def fail_json(self, **kwargs):
            self.kwargs = kwargs

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.exit_json = AnsibleExitJson(*args)
            self.fail_json = AnsibleFailJson(*args)
            self.params = kwargs
            self.check_mode = False



# Generated at 2022-06-11 07:39:38.476394
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:39:39.104131
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:39:43.711479
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.network.ping import main as ping_main

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    ping_main()

# Generated at 2022-06-11 07:39:44.310351
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:40:30.552366
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    print(result)

# ...and run tests if we need to
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:40:36.720096
# Unit test for function main
def test_main():
    # Test fail if check-mode is on
    result = AnsibleModule({"data": "pong"}, supports_check_mode=True).main()
    assert result["failed"] is True
    assert result["msg"].startswith("CHECK_MODE")
    # Test with correct output
    result = AnsibleModule({"data": "pong"}, supports_check_mode=False).main()
    assert result["failed"] is False
    assert result["changed"] is False
    assert result["ping"] == "pong"

# Generated at 2022-06-11 07:40:40.568155
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'
# End unit test

# Generated at 2022-06-11 07:40:44.683339
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    expected_result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**expected_result)


# Generated at 2022-06-11 07:40:52.540100
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def run_module():
        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True,
            bypass_checks=True
        )

        if module.params['data'] == 'crash':
            raise Exception("boom")

        result = dict(
            ping=module.params['data'],
        )

        module.exit_json(**result)

    def test_no_crash():
        with mock.patch('ansible.module_utils.basic.AnsibleModule') as am:
            run_module()
            assert am.exit_json.called


# Generated at 2022-06-11 07:41:03.016692
# Unit test for function main
def test_main():
    # Test no arguments
    args = dict()
    result = dict(
        ping="pong",
        changed=False,
        skipped=False
    )
    module = AnsibleModule(**args)
    result = main()
    assert result == result
    # Test with arguments
    args = dict(
        data="break",
    )
    result = dict(
        ping="break",
        changed=False,
        skipped=False
    )
    module = AnsibleModule(**args)
    result = main()
    assert result == result
    # Test with exceptions
    args = dict(
        data="crash",
    )
    result = dict(
        failed=True,
        changed=False,
        skipped=False
    )
    module = AnsibleModule(**args)
    result = main()

# Generated at 2022-06-11 07:41:11.100117
# Unit test for function main
def test_main():
    # Unit test for function main
    argv_orig = sys.argv
    sys.argv = ['']
    with tempfile.NamedTemporaryFile(delete=True) as f:
        f.write(json.dumps({'ANSIBLE_NET_USERNAME': 'admin', 'ANSIBLE_NET_PASSWORD': 'admin'}).encode('utf-8'))
        f.flush()
        sys.argv.append('-i={0}'.format(f.name))
        sys.argv.append('--check')
        sys.argv.append('localhost')
        sys.argv.append('ansible.builtin.ping')
        sys.argv.append('data=data')
        with pytest.raises(SystemExit):
            main()
    sys.argv = argv_

# Generated at 2022-06-11 07:41:12.471935
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as execinfo:
        main()

# Generated at 2022-06-11 07:41:17.879302
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    #Make sure that the data parameter is properly returned
    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == module.params['data']

# Generated at 2022-06-11 07:41:20.739415
# Unit test for function main
def test_main():
    
    with pytest.raises(Exception) as boom_execption:
        main()
    assert str(boom_execption.value) == 'boom'

# /Unit test for function main

# Generated at 2022-06-11 07:42:52.809680
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:42:57.752075
# Unit test for function main
def test_main():
    collection = ansible.utils.collection
    load_module = collection.load_module
    module_utils_basic = ansible.module_utils.basic
    ansible_module_ping = load_module("ansible_module_ping")
    argument_spec = dict(data=dict(type='str', default='pong'))
    supports_check_mode = True
    module = ansible_module_ping.AnsibleModule(argument_spec=argument_spec, supports_check_mode=supports_check_mode)
    main(module=module)

# Generated at 2022-06-11 07:42:59.046941
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-11 07:43:06.814854
# Unit test for function main
def test_main():
    test_dict = dict(
        data=dict(type='str', default='pong'),
    )
    with patch.dict(ANSIBLE_MODULE_ARGS, test_dict):
        class TestException(Exception):
            pass

        # Test exception if data == 'crash'
        test_dict = dict(
            data='crash'
        )
        with patch.dict(ANSIBLE_MODULE_ARGS, test_dict):
            with patch.object(AnsibleModule, 'exit_json'):
                with patch.object(AnsibleModule, 'fail_json'):
                    with pytest.raises(TestException) as excinfo:
                        main()
                    excinfo.match("boom")

        # Test normal return
        test_dict = dict(
            data='pong'
        )

# Generated at 2022-06-11 07:43:09.738459
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() is None


# Generated at 2022-06-11 07:43:14.389677
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:43:17.590735
# Unit test for function main
def test_main():
    global module
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)

    try:
        main()
    except Exception as e:
        assert e.message == "boom"



# Generated at 2022-06-11 07:43:18.503288
# Unit test for function main
def test_main():
    assert 0, "Function not implemented"

# Generated at 2022-06-11 07:43:24.938335
# Unit test for function main
def test_main():
    # Mock out the results for test purposes
    # We want the checks to pass but not actually change anything
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule
    m.exit_json = lambda x, **kwargs: True
    m.fail_json = lambda x, **kwargs: True

    # Execute the main function
    main()

# Generated at 2022-06-11 07:43:32.585834
# Unit test for function main
def test_main():
    test_args = dict(
        data='pong'
    )
    test_args_fail = dict(
        data='crash'
    )
    # Note that this needs to be run from the directory it lives in (test/units/module_utils/$module)
    # to get the template files.
    result = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    ).execute_module(**test_args)
    assert result['ping'] == 'pong', result
