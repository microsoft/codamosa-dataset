

# Generated at 2022-06-11 07:36:04.723880
# Unit test for function main
def test_main():
    argument_spec=dict(
        data=dict(type='str', default='pong'),
    )
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)


# Generated at 2022-06-11 07:36:06.377865
# Unit test for function main
def test_main():
    mydict = {}
    mydict['data'] = 'pong'
    assert main() == mydict

# Generated at 2022-06-11 07:36:15.434403
# Unit test for function main
def test_main():
    class namelist:
        def __init__(self, name):
            self.name = name

    class args:
        def __init__(self, args):
            self.args = args

    class params:
        def __init__(self, data):
            self.params = {'data': data}

    class check_mode:
        def __init__(self, supported):
            self.supported = supported

    class exit_json:
        def __init__(self, data):
            self.data = data

    def noop(self, data):
        return data

    class AnsibleModule:

        def __init__(self, a, b, c):
            return

        def exit_json(self, a):
            return

    args = args(['main.py'])
    params = params('pong')

# Generated at 2022-06-11 07:36:19.388391
# Unit test for function main
def test_main():
    ping_result = ''
    ping_data = 'pong'
    ping_msg = ''
    ping_changed = False
    ping_rc = 0

    result = dict(
        ping = ping_data,
        msg = ping_msg,
        changed = ping_changed,
        rc = ping_rc,
    )

    assert result == main()

# Generated at 2022-06-11 07:36:28.983488
# Unit test for function main
def test_main():
    print("Testing ..")

    test_arguments = dict(
        data=dict(type='str'),
    )

    module = AnsibleModule(
        argument_spec=test_arguments,
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# test_arguments = dict(
# 	data=dict(type='str'),
# )

# test_parameters = dict(
# 	data=dict(type='str', default='pong'),
# )


# print("Testing ...")

# Test we can logon to 'webservers' and execute python with json lib
# ans

# Generated at 2022-06-11 07:36:31.543342
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    my_obj = Ping()
    ansible.module_utils.basic.AnsibleModule = DummyAnsibleModule
    my_obj.main()

# Generated at 2022-06-11 07:36:34.356883
# Unit test for function main
def test_main():
    args = {'data': 'crash'}
    module = AnsibleModule(argument_spec={'data': dict(type='str', default='pong')}, supports_check_mode=True)
    module.params = args
    main()

# Generated at 2022-06-11 07:36:43.486816
# Unit test for function main
def test_main():
  # set up test input/result
  result = dict(
        ping='pong',
  )
  # set up module input
  params = dict(
        data='pong',
  )
  # do not use main() as it exits and works with ansible module
  ping = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
  assert ping.params == params
  # do the ping, actual func main would have called
  ping.exit_json(**result)


# Generated at 2022-06-11 07:36:46.120943
# Unit test for function main
def test_main():
    """
    Unit test for function main()
    """

    module = {"params": {"data": "test_data"}}
    main(module)



# Generated at 2022-06-11 07:36:50.130618
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    if module.params['data'] == 'crash':
        message = "boom"
        assert Exception(message)

# Generated at 2022-06-11 07:37:01.272100
# Unit test for function main
def test_main():
    test_params = {'data': 'pong'}
    expected_return = {'changed': False, 'ping': 'pong'}

    actual_return = main(test_params)
    assert actual_return == expected_return

# Generated at 2022-06-11 07:37:10.680827
# Unit test for function main
def test_main():
    test_data = dict(
        module_args=dict(
            data='pong'),
        ansible_facts=dict(
            ansible_check_mode=True,
            ansible_diff_mode=True,
            ansible_platform=dict(
                platforms=['posix'])))
    module_return_value = dict(
        ping='pong')
    module = AnsibleModule(test_data)
    module.exit_json = mock.Mock()
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as m:
        m.return_value = module
        main()
    assert module.exit_json.call_args_list == [
        mock.call(**module_return_value)]


# Generated at 2022-06-11 07:37:14.332010
# Unit test for function main
def test_main():
    # Test simple case
    result = {}

    # Test crash case
    with pytest.raises(Exception) as excinfo:
        result = main({'data': 'crash'}, None, None, None)
        assert 'boom' in str(excinfo.value)

# Generated at 2022-06-11 07:37:19.405209
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    args = dict(
        data = 'pong'
    )

    main(test_module.params)
    assert test_module.exit_json(**args)

# Generated at 2022-06-11 07:37:25.423930
# Unit test for function main
def test_main():
    test_data = [
        [
            "pong",
            0
        ],
        [
            "crash",
            1
        ]
    ]
    for test in test_data:
        try:
            main(test[0])
            assert 0
        except:
            if test[1] == 1:
                assert 1
            else:
                assert 0

# Generated at 2022-06-11 07:37:26.524770
# Unit test for function main
def test_main():
    assert True

# vim: set et st=4 :

# Generated at 2022-06-11 07:37:27.655729
# Unit test for function main
def test_main():
    assert 1 == main()

# Generated at 2022-06-11 07:37:32.904947
# Unit test for function main
def test_main():
    """ ping module """
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        main()
        test_exception = False
    except Exception:
        test_exception = True
    assert test_exception == False

# Generated at 2022-06-11 07:37:36.826799
# Unit test for function main
def test_main():
    import json
    with open('./test/unit/module_utils/ansible_module_ping.json') as fd:
        input_data = json.load(fd)
    fd.close()
    current_result = {'failed': False, 'ping': 'pong', 'changed': False}
    assert main() == current_result

# Generated at 2022-06-11 07:37:43.621160
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-11 07:37:55.172956
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result == main()

# Generated at 2022-06-11 07:38:07.160020
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_bytes
    from copy import deepcopy
    import sys
    import pytest
    import os

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

    # Get the version of the Ansible module

# Generated at 2022-06-11 07:38:13.571320
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    builtins.open = open

    # Mock out the open method used in the ping module
    def fake_file(filename, mode):
        assert 'ping' in filename
        return StringIO('{"ping":"pong"}')

    def fake_dump(result, filename):
        assert 'ensure_dir' in filename
        assert 'ping' in str(result)

    builtins.open = fake_file
    builtins._dump_results = fake_dump

    import ansible.modules.builtin.ping as ping
    # ansible modules don't take arguments at the moment
    ping.main()

# Generated at 2022-06-11 07:38:20.119725
# Unit test for function main
def test_main():
    func_fixture = lambda: None
    func_fixture.params = { 'data': 'pong' }
    func_fixture.exit_json = lambda **kwargs: None
    func_fixture.fail_json = lambda **kwargs: None
    mock_AnsibleModule = lambda **kwargs: func_fixture
    with patch('ansible.modules.system.ping.AnsibleModule', new=mock_AnsibleModule):
        main()

# Generated at 2022-06-11 07:38:27.050916
# Unit test for function main
def test_main():

    # Demonstrate a call to the module to set up test data in the state file.
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)
    # test the apply logic of the main function.
    assert True

# Generated at 2022-06-11 07:38:32.966273
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:38:38.836618
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic
    test_args = ['-m', 'ping', '-a', 'data=pong']
    with basic.patch_ansible_module_args(test_args):
        res = main()
        assert res['ping'] == 'pong'
        assert res['changed'] == False
        assert 'invocation' in res
        assert 'module_args' in res['invocation']

# Generated at 2022-06-11 07:38:43.281422
# Unit test for function main
def test_main():
    argument_spec = dict(
        data=dict(type='str', default='pong')
    )
    module = AnsibleModule(argument_spec=argument_spec)
    module.exit_json = MagicMock()
    result = dict(ping='pong')
    main()
    assert module.exit_json.call_count == 1
    assert module.exit_json.call_args[0][0] == result

# Generated at 2022-06-11 07:38:50.876030
# Unit test for function main
def test_main():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    args = dict(ANSIBLE_MODULE_ARGS = dict(data = 'foo'))
    args['ANSIBLE_MODULE_CONSTANTS'] = dict(MODULE_COMPLEX_ARGS=dict())
    (rc, out, err) = module_test_main("ansible.builtin.ping", tmpdir, args)
    assert rc == 0
    assert out == dict(changed=False, ping=u'foo')
    assert not err

# Generated at 2022-06-11 07:38:58.414159
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if test_module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=test_module.params['data'],
    )

    test_module.exit_json(**result)

# Generated at 2022-06-11 07:39:18.061063
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:39:22.168805
# Unit test for function main
def test_main():
    import pytest
    def test_result():
        with pytest.raises(SystemExit):
            try:
                main()
            except Exception as e:
                print(e)
                if "boom" in e:
                    test_result.error = e
                    pytest.exit("crash")
    test_result()

# Generated at 2022-06-11 07:39:33.104179
# Unit test for function main
def test_main():
    import pytest

    # This hack forces the test to load the module module
    # Normally this would be done via import but we don't want the actual module loaded
    # we just want to load the module path and run the main method in the unit test
    # It may be possible to make this more readable with pytest hooks.
    if not hasattr(pytest, '_ansible_module_loaded'):
        pytest._ansible_module_loaded = True

        import sys
        import os

        mod_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/modules/builtin/ping.py')
        mod_name,file_ext = os.path.splitext(os.path.split(mod_path)[-1])

# Generated at 2022-06-11 07:39:36.879452
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main()
    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:39:37.466734
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:39:47.015506
# Unit test for function main
def test_main():
    def test_func(ansible_module):
        # Test idempotency
        result = ansible_module.command(
            'ansible testnode -i inventory -m ping | tee result.txt')
        assert result == 0
        assert ansible_module.jsonify(
            'result.txt') == {'changed': False, 'ping': u'pong'}

        # Test noop
        result = ansible_module.command(
            'ansible testnode -i inventory -m ping -D | tee result.txt')
        assert result == 0
        assert ansible_module.jsonify(
            'result.txt') == {'changed': False, 'ping': u'pong'}

        # Test exception

# Generated at 2022-06-11 07:39:48.556563
# Unit test for function main
def test_main():
    args = dict(data='')
    result = dict(ping='pong')
    assert main(args) == result

# Generated at 2022-06-11 07:39:49.729061
# Unit test for function main
def test_main():
    # print("importing test_main function from ping module")
    pass

# Generated at 2022-06-11 07:39:50.987872
# Unit test for function main
def test_main():
    ping_ret = main()
    assert ping_ret == u'pong'

# Generated at 2022-06-11 07:39:55.654542
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:40:43.837287
# Unit test for function main
def test_main():
    class SomeClass:
        def __init__(self, params):
            self.params = params

        def exit_json(self, **kwargs):
            print('Exit Json')
            print(kwargs)

        def fail_json(self, **kwargs):
             print('Fail Json')
             print(kwargs)

    class FakeModule(SomeClass):
        def __init__(self, params):
            SomeClass.__init__(self, params)
            self.check_mode = params['check_mode']

    def mocked_ansible_module(params):
        return FakeModule(params)

    import ansible.builtin.ping
    ansible.builtin.ping.AnsibleModule = mocked_ansible_module

    original_main = ansible.builtin.ping.main


# Generated at 2022-06-11 07:40:48.721456
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # test normal function
    result = dict(
        ping=module.params['data'],
    )
    main()
    # test exception
    try:
        module.params['data'] = 'crash'
        main()
    except:
        pass

# Generated at 2022-06-11 07:40:56.301002
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    print("try:")
    try:
        if module.params['data'] == 'crash':
            raise Exception("boom")

        result = dict(
            ping=module.params['data'],
        )

        module.exit_json(**result)
    except Exception as e:
        print("catch:")
        print(str(e))
        module.fail_json(msg=str(e))

test_main()

# Generated at 2022-06-11 07:41:01.609305
# Unit test for function main
def test_main():
    yaml = """
        ping: pong
    """
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert main() == result

# Generated at 2022-06-11 07:41:02.259779
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:41:10.784005
# Unit test for function main
def test_main():
    # Try to access module.params
    assert main.__globals__['module'].params

    assert main.__globals__['module'].params['data'] == 'pong'
    assert main.__globals__['module']._name == 'ansible.builtin.ping'
    assert main.__globals__['module'].params['data'] == 'pong'
    assert main.__globals__['module'].params['data'] == 'pong'

    # Try to access module.exit_json
    assert main.__globals__['module'].exit_json

    main.__globals__['module'].params['data'] = 'pong'
    main.__globals__['module'].exit_json(ping='pong')

    main.__globals__

# Generated at 2022-06-11 07:41:16.557155
# Unit test for function main
def test_main():
    # Unit tests for function main
    args = dict(
        data = 'pong'
    )

    ansible = dict(
        check_mode = False,
        diff = False
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        ),
        supports_check_mode=True
    )

    assert main() is not None

# Generated at 2022-06-11 07:41:21.104388
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    module.exit_json(**result)

# Generated at 2022-06-11 07:41:25.821353
# Unit test for function main
def test_main():
  # Create a dummy module
  module = AnsibleModule(
    argument_spec = dict(
      data = dict(type='str', default='pong'),
    ),
    supports_check_mode = True
  )
  
  # Invoke function main() and test the results
  main()
  assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:41:31.630285
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=module.params['data'],
    )


# Generated at 2022-06-11 07:43:00.490745
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:43:02.935576
# Unit test for function main
def test_main():
    module_args = dict(
        data='pong'
    )
    print('main')
    result = main(module_args)
    print(result)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:43:06.852900
# Unit test for function main
def test_main():
    default_args = dict(
        data='pong'
    )
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong')
    ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert result == main()

# Generated at 2022-06-11 07:43:07.351950
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:43:10.311743
# Unit test for function main
def test_main():
    # Setup ansible moduleunit test parameters.
    args_dict = dict(data="hello")
    result_dict = dict(ping="hello")
    # Invoke main function
    main()
    # Verify result
    assert result == result_dict

# Generated at 2022-06-11 07:43:12.259270
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-11 07:43:12.906543
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:43:21.939245
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    MOCK_MODULE_ARGS = {
        'data': 'pong'
    }
    MOCK_ANSIBLE_MODULE = basic.AnsibleModule(**MOCK_MODULE_ARGS)
    MOCK_SYS_EXIT = basic.AnsibleModule.exit_json
    MOCK_EXIT_JSON = basic.AnsibleModule.exit_json
    MOCK_EXIT_JSON.return_value = {
        'changed': True,
        'invocation': {'module_args': MOCK_MODULE_ARGS},
        'ping': 'pong'
    }
    # MOCK_ANSIBLE_MODULE.check_mode = False


# Generated at 2022-06-11 07:43:23.659161
# Unit test for function main
def test_main():
  mock_action_name = {"data":"pong"}
  assert(main(mock_action_name) == None)

# Generated at 2022-06-11 07:43:32.348030
# Unit test for function main
def test_main():
    import mock
    import json
    import ansible
    from ansible.module_utils.six import StringIO
    import __builtin__

    def test_ansible_module(mock_module):
        # Create a class of the same type as the AnsibleModule class
        # within the imported ansible.module_utils.basic package.  This
        # will allow us to instantiate an object of this class.
        class TestAnsibleModule(type(mock_module)):
            # Define a function with the same name as the exit_json
            # function within the AnsibleModule class.
            def exit_json(self, *args, **kwargs):
                # mark that exit_json was called
                self.exit_json_called = True
                # Call the original exit_json function