

# Generated at 2022-06-11 07:36:05.335551
# Unit test for function main
def test_main():
    try:
        import sys
        from io import StringIO
        from ansible.module_utils.basic import *
        mod = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
        main()
    except:
        raise

# Generated at 2022-06-11 07:36:11.336288
# Unit test for function main
def test_main():
    """ Unit test for function main """
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = main()

    assert result == {
        "ping": "pong",
        "_ansible_check_mode": False,
        "changed": False,
        "_ansible_module_name": "ansible.builtin.ping",
    }

# Generated at 2022-06-11 07:36:16.098551
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-11 07:36:19.869608
# Unit test for function main
def test_main():
    set_module_args(dict(
        data='abc'
    ))

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'abc'


# Generated at 2022-06-11 07:36:25.440857
# Unit test for function main
def test_main():
    # Get the module object
    from ansible.modules.cloud.amazon.ping import main as ping
    module = AnsibleModule(argument_spec={'data': {"required": False, "type": "str", "default": "pong"}}, supports_check_mode=True)
    # source, destination = ping.main(module)
    assert 1 == 1


# Generated at 2022-06-11 07:36:32.055081
# Unit test for function main
def test_main():
    def ansible_module_mock(**kwargs):
        return('''{"module_name": "ansible.builtin.ping", "module_args": {"data": "pong"}}''')

    # Mock part of AnsibleModule
    import sys
    class AnsibleModule_mock(object):
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            self.params = {}

        def exit_json(self, ping):
            self.result = dict(ping=ping)

    class sys_mock(object):
        modules = { "ansible.builtin.ping": ansible_module_mock }

    sys_mock.modules = { "ansible.builtin.ping": ansible_module_mock }

# Generated at 2022-06-11 07:36:35.287187
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")


# Generated at 2022-06-11 07:36:47.024063
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    from ansible.module_utils._text import to_bytes

    class MockModule(AnsibleModule):
        def __init__(self, *a, **kw):
            super(MockModule, self).__init__(*a, **kw)
            self.params = {'_ansible_check_mode': False}

        def exit_json(self, **kw):
            self.exit_args = kw
            self.exit_args['changed'] = kw.pop('changed', False)
            raise SystemExit()

    with pytest.raises(SystemExit):
        main()
        assert MockModule().exit_args['changed'] == True
        assert MockModule().exit_args['ping'] == 'pong'


# Generated at 2022-06-11 07:36:55.212597
# Unit test for function main

# Generated at 2022-06-11 07:37:02.429158
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    with pytest.raises(Exception) as excinfo:
        module = main()
        assert 'boom' in str(excinfo.value)

    result = {
        'ping': module.params['data']
    }

    assert result == {'pong'}

# Generated at 2022-06-11 07:37:20.503122
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

    def test_exception(msg):
        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
        try:
            main()
        except Exception as exception:
            assert str(exception) == msg
            return True
        return False


    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert main() == None

# Generated at 2022-06-11 07:37:32.092743
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    from ansible.module_utils._text import to_bytes
    content = basic._ANSIBLE_ARGS
    if content is None:
        sys.stderr.write("Failed to load ansible arguments")
        exit(1)
    else:
        arg_lines = content.split(b('\n'))
    lines = [x.strip() for x in arg_lines if x.strip() != b('')]
    parser = argparse.ArgumentParser(description="test program")
    parser.add_argument('-d', '--data', required=False)
    options = parser.parse_args(lines)

# Generated at 2022-06-11 07:37:33.346334
# Unit test for function main
def test_main():

    # Assert if main() returns the expected result.
    assert main() == dict(ping='pong')

# Generated at 2022-06-11 07:37:39.924523
# Unit test for function main
def test_main():
    data = dict(
        data='pong',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.check_mode = False
    assert module.exit_json(**data) == {
        'changed': False,
        'ping': 'pong'
    }
    assert data == {
        'data': 'pong',
    }

# Generated at 2022-06-11 07:37:46.009177
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:37:52.492931
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')
    
    module.exit_json(**result)

# Generated at 2022-06-11 07:37:55.650391
# Unit test for function main
def test_main():
    ping_value = 'pong'
    ping_data = {'ping': ping_value}
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    main()

# Generated at 2022-06-11 07:37:58.502555
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(data=dict(type="str", default="pong")))
    result = dict(ping=module.params["data"])
    assert result["ping"] == "pong"

# Generated at 2022-06-11 07:38:10.138887
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import actions
    from ansible.module_utils.common._collections_compat import Mapping

    # create a dummy connection for testing
    class Connection(object):
        ''' dummy connection for testing'''
        def __init__(self, *args, **kwargs):
            pass

    # create a dummy module for testing
    class Module(object):
        ''' dummy ansible module for testing'''
        def __init__(self, *args, **kwargs):
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')


# Generated at 2022-06-11 07:38:15.643366
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] != 'pong':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:38:24.220170
# Unit test for function main
def test_main():
   assert False


# Generated at 2022-06-11 07:38:34.267490
# Unit test for function main
def test_main():
    # Unit test for valid inputs
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == {"ping": "pong"}

    # Unit test for invalid inputs
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == {"ping": "crash"}

# Generated at 2022-06-11 07:38:37.263985
# Unit test for function main
def test_main():
    # example from above
    data = {
        'data': 'pong'
    }
    module = AnsibleModule(data, supports_check_mode=True)

    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:38:39.014067
# Unit test for function main
def test_main():
    result = main()
    assert result == {"ping":"pong"}, "expected pong from main function"

# Generated at 2022-06-11 07:38:43.676261
# Unit test for function main
def test_main():
  spec = dict(
      data=dict(type='str', default='pong'),
  )
  module = AnsibleModule(argument_spec=spec)
  result = dict(
      ping=module.params['data'],
  )
  if module.params['data'] == 'crash':
    try:
      raise Exception("boom")
    except Exception as e:
      raise

  assert(result == dict(ping='pong'))

# Generated at 2022-06-11 07:38:46.125435
# Unit test for function main
def test_main():
    test_data = dict(
        data='pong',
        changed=False
    )
    result = main()
    assert result == test_data

# Generated at 2022-06-11 07:38:57.516537
# Unit test for function main
def test_main():
    import sys

    argv = [sys.argv[0]]

    # you can use the stdout/stderr capturer from sh library here
    # (https://amoffat.github.io/sh )
    # for example:
    #   import sh
    #   result = sh.python(argv[0], _in='\n'.join(argv[1:]), _out=StringIO(), _err=StringIO())
    #   stdout, stderr = result.stdout, result.stderr

    from io import StringIO
    from ansible.utils.unicode import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    stdout = StringIO()
    stderr = StringIO()
    sys.stdout = stdout
    sys.stderr = stderr


# Generated at 2022-06-11 07:38:58.565039
# Unit test for function main
def test_main():
  main()


# Generated at 2022-06-11 07:39:03.104388
# Unit test for function main
def test_main():
    module_args = {
        "data": 'pong'
    }

    if __name__ == '__main__':
        main()

    # Testing the module
    result = ping.main(module_args)
    assert result['ansible_facts']['ping'] == 'pong'

# Generated at 2022-06-11 07:39:11.265041
# Unit test for function main
def test_main():
    # mock module input parameters
    module_args = dict(
        data=dict(type='str', default='pong'),
    )
    # Inject mocks
    with patch.object(AnsibleModule, '__init__') as am_mock:
        am_mock.return_value = None
        am_mock.params = module_args
        am_mock.check_mode = False
        # Run module code
        main()
        # Assert we called AnsibleModule.exit_json with proper arguments
        am_mock.assert_has_calls([call(ping='pong')])
    # A second test, this time with check_mode set to True
    with patch.object(AnsibleModule, '__init__') as am_mock:
        am_mock.return_value = None


# Generated at 2022-06-11 07:39:30.497544
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == True

# Generated at 2022-06-11 07:39:31.222412
# Unit test for function main
def test_main():
  main(None)

# Generated at 2022-06-11 07:39:36.391634
# Unit test for function main
def test_main():
    test_module = AnsibleModule(argument_spec={
        'data': {'type': 'str', 'default': 'pong'},
    }, supports_check_mode=True)
    test_module.params = {'data': 'pong'}
    test_main_res = main()
    assert test_main_res['ping'] == 'pong'

# Generated at 2022-06-11 07:39:42.249350
# Unit test for function main
def test_main():
    args = dict(
      data='pong',
      check_mode=True
    )

    result = dict(
        ping='pong'
    )

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:39:46.563364
# Unit test for function main
def test_main():
    # Make sure we can load the module
    module = __import__('ping')

    # Make sure we stand up a test module
    module.main()

    # Make sure we crash with the crash data
    try:
        module.main()
    except Exception:
        pass
    else:
        raise AssertionError('Test failure: unable to crash by passing in test data.')

# Generated at 2022-06-11 07:39:52.754817
# Unit test for function main
def test_main():
    import json
    data = dict(
        ANSIBLE_MODULE_ARGS = dict(
            data = 'pong'
        )
    )
    print(data)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    m = AnsiModule(argument_spec=dict(), supports_check_mode=True)
    basic._ANSIBLE_ARGS = data
    result = main()
    assert result['ping'] == 'pong'
    print(json.dumps({'ping': 'pong'}, indent=4))

# Generated at 2022-06-11 07:40:00.196032
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    import json

    with open('ping/ping.json') as ping_json_data:
        ping_json_data = json.load(ping_json_data)

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        )
    )

    assert module.params['data'] == 'test_data'
    assert ping_json_data["changed"] == False
    assert ping_json_data["ansible_facts"] == {}
    assert ping_json_data["ping"] == 'test_data'

# Generated at 2022-06-11 07:40:02.422991
# Unit test for function main
def test_main():
    # FIXME:  Need to test the exception case
    result = dict(
        ping='pong',
    )

    assert main() == result

# Generated at 2022-06-11 07:40:10.140962
# Unit test for function main
def test_main():
    # Try to read the user's ~/.ansible/ansible.cfg file.
    # If we can, set the user's ansible variables from the .cfg file.
    # This assumes that the virtualenv the test is being run in is the same
    # virtualenv that ansible is installed in.  If it isn't, the tests will
    # raise an error.  The theory is that if the user is running the test,
    # they are doing it in a virtualenv created by us.
    pre_inventory = None

# Generated at 2022-06-11 07:40:10.557832
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:40:52.199771
# Unit test for function main
def test_main():
    # Unit test code
    pass

# Generated at 2022-06-11 07:40:52.758530
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:41:03.280993
# Unit test for function main
def test_main():
    import sys
    import imp
    import json
    import tempfile
    import subprocess
    from unittest import TestCase
    from ansible.module_utils import basic as module_utils_basic
    from ansible.module_utils._text import to_bytes

    fixtures = [
        {
            'data': 'pong'
        },
        {
            'data': 'crash'
        }
    ]
    for fixture in fixtures:
        print(json.dumps(fixture), file=sys.stdout)

        # create a temporary file, which we can pass to our module
        # as a fake argument
        tmp = tempfile.NamedTemporaryFile()
        with open(tmp.name, 'w') as f:
            f.write(json.dumps(fixture))


# Generated at 2022-06-11 07:41:07.438682
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] is not None
    assert module.params['data'] == 'pong'
    assert module.params['data'] is not 'crash'

# Generated at 2022-06-11 07:41:17.748173
# Unit test for function main

# Generated at 2022-06-11 07:41:19.410383
# Unit test for function main
def test_main():
	with pytest.raises(Exception) as excinfo:
		main()
	assert excinfo

# Generated at 2022-06-11 07:41:20.409807
# Unit test for function main
def test_main():
  # Unit tests don't work at this time
  pass

# Generated at 2022-06-11 07:41:28.550789
# Unit test for function main
def test_main():
    with patch(
        'ansible.module_utils.basic.AnsibleModule',
        return_value=AnsibleModule(argument_spec=dict(data=dict(type="str", default="pong")))
    ) as mock_AnsibleModule, \
         patch('sys.exit') as mock_exit, \
         patch('sys.stdout') as mock_stdout:
        main()
        mock_exit.assert_called_once_with(0)
        mock_stdout.write.assert_called_once_with('{"changed": false, "ping": "pong"}\n')

# Generated at 2022-06-11 07:41:32.800803
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0


# Generated at 2022-06-11 07:41:42.093624
# Unit test for function main
def test_main():
    unit_tests = [
        { 'params': {'data': 'pong'}, 'rc': 0, 'stdout': '{"ansible_facts": {"ping": "pong"}, "changed": false, "ping": "pong"}' },
        { 'params': {'data': 'crash'}, 'rc': 1, 'stdout': '{"ansible_facts": {"ping": "pong"}, "changed": false, "msg": "boom"}' },
    ]

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    for unit_test in unit_tests:
        module.params['data'] = unit_test['params']['data']


# Generated at 2022-06-11 07:43:15.716604
# Unit test for function main
def test_main():
    # TODO: !!!
    # Check return code of function.
    assert True

# Generated at 2022-06-11 07:43:20.391527
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params['data'] = 'pong'

    result = dict(
        ping=module.params['data'],
    )

    assert module.params['data'] == result['ping']

# Generated at 2022-06-11 07:43:21.006680
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:43:30.828335
# Unit test for function main
def test_main():
  # Mock object to replace AnsibleModule
  class AnsibleModuleMock:
    def __init__(self, argument_spec, supports_check_mode, required_one_of, required_together, mutually_exclusive):
      self.argument_spec = argument_spec
      self.supports_check_mode = supports_check_mode
      self.required_one_of = required_one_of
      self.required_together = required_together
      self.mutually_exclusive = mutually_exclusive

    def fail_json(self, **kwargs):
      raise Exception("Test failed")

    def exit_json(self, **kwargs):
      pass
  class ExceptionMock(Exception):
    pass
  class FakeModule:
    def __init__(self, argument_spec, supports_check_mode):
      self.argument_spec = argument

# Generated at 2022-06-11 07:43:33.782061
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-11 07:43:42.670450
# Unit test for function main
def test_main():
    import json

    # Case: Normal return
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
        changed=False
    )
    module.exit_json = lambda x: x
    assert json.loads(main()) == result

    # Case: Only returned value is changed
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='ping'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
        changed=False
    )
    module.exit_json = lambda x: x

# Generated at 2022-06-11 07:43:48.262270
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    mod_args = dict(data='crash')
    failed, result = basic._test_module(module_name='ansible.builtin.ping',
                                        module_args=mod_args,
                                        check_mode=False)
    assert failed == True
    assert to_bytes(result['msg']) == to_bytes('Exception: boom')

# Generated at 2022-06-11 07:43:48.785514
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:43:50.133815
# Unit test for function main
def test_main():
  ''' This function checks the main function'''
  assert main == main

# Generated at 2022-06-11 07:43:58.696588
# Unit test for function main
def test_main():
    test_params = {
        'data': 'pong'
    }

    result = {
        'ping': 'pong',
        '_ansible_check_mode': False,
        '_ansible_version': '2.9.11',
        '_ansible_module_name': 'ping',
        '_ansible_no_log': False,
        '_ansible_verbose_always': False,
        '_ansible_diff': False
    }

    module = mock.MagicMock(
        exit_json=lambda x: result.update(x),
        params=test_params,
        supports_check_mode=True
    )
    main()

    assert result['ping'] == 'pong'


# If module has been called as a script, run the unit tests