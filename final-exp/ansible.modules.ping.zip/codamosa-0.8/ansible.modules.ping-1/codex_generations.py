

# Generated at 2022-06-11 07:36:04.749283
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:36:13.819141
# Unit test for function main
def test_main():

    # If test_main() is called, it means that the module is already fully
    # parsed and the test can run, but we must supply params as if we were
    # called from Ansible - which we mimic via a class
    class AnsibleModule_mock:
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.params = {}
        def exit_json(self, **kwargs):
            self.exit_json_args = kwargs
            self.exit_json_called = True
        def fail_json(self, **kwargs):
            self.fail_json_args = kwargs
            self.fail_json_called = True
    my_ansible_module = AnsibleModule_mock(dict())

    # Test normal cases

# Generated at 2022-06-11 07:36:15.474360
# Unit test for function main
def test_main():
    args = dict(data=1)
    result = main(args)
    assert result['ping'] == 1

# Generated at 2022-06-11 07:36:21.760472
# Unit test for function main
def test_main():
    # Test a successful run
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
    )
    m.exit_json = lambda **kwargs: kwargs

    retval = main()
    assert retval == {'ping': 'pong'}
    retval = main(data='crash')
    assert retval['failed']
    assert 'Exception: boom' in retval['msg']
    assert retval['exception'] == "Exception('boom',)"

# Generated at 2022-06-11 07:36:24.720359
# Unit test for function main

# Generated at 2022-06-11 07:36:29.794322
# Unit test for function main
def test_main():
    tdict = dict(data=dict(type='str', default='pong'))
    tmodule = AnsibleModule(
        argument_spec=tdict,
        supports_check_mode=True
    )
    assert tmodule.params['data'] == 'pong'
    result = dict(
        ping=tmodule.params['data'],
    )
    assert result == {
        "ping": "pong"
    }
    tmodule.exit_json(**result)


# Generated at 2022-06-11 07:36:35.327524
# Unit test for function main
def test_main():
    meta = {'no_log': True,
            'removed_items': [
                'invocation',
                'messages',
                'module_name'
            ]
           }
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-11 07:36:40.697735
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:36:43.168246
# Unit test for function main
def test_main():
    main_return = main()
    assert main_return['changed'] is False
    assert main_return['message'] == 'pong'

# Generated at 2022-06-11 07:36:46.017005
# Unit test for function main
def test_main():
  main_dict = { "ansible_module_name": "ping",
      "ansible_module_args":"data=pong",
      "ansible_playbook_python":"/usr/bin/python",
  }
  main_result = {
      "ping": "pong"
  }
  main(main_dict)
  if main_result == main_dict:
    return 0
  else:
    return -1

# Generated at 2022-06-11 07:36:57.646718
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # set the args
    args = module.parse_args(['data=bang'])
    # update the arguments from the task into the module
    module.params.update(args)
    # call function `main` with params-kwargs
    main(module)
    # get the result
    result = module.exit_json._result
    # test result
    assert result['ping'] == 'bang'
    # test exit_json
    assert module.exit_json.called

# Generated at 2022-06-11 07:37:08.116624
# Unit test for function main
def test_main():
    from ansible.modules.extras.cloud.openstack.os_volume_snapshot import main
    os_volume_snapshot = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True),
        description=dict(type='str'),
        volume_id=dict(type='str'),
        force=dict(type='bool', default=False),
        state=dict(choices=['present', 'absent'], default='present'),
    ))
    os_volume_snapshot.params['name'] = 'snapshot1'
    os_volume_snapshot.params['volume_id'] = 'volume1'
    os_volume_snapshot.params['description'] = 'description1'
    os_volume_snapshot.params['state'] = 'present'

# Generated at 2022-06-11 07:37:09.111585
# Unit test for function main
def test_main():
    # Verify if function main exists
    assert main

# Generated at 2022-06-11 07:37:19.095378
# Unit test for function main
def test_main():
    # Importing within the function because this module is defined as entry_point
    # and doesn't exist under normal circumstances.
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(*sub_dirs, **kwargs):
        test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
        return os.path.join(test_data_dir, *sub_dirs)

    # Insert action plugin path to import modules from there.
    sys.path.insert(0, get_bin_path('..', '..', '..', '..', '..', 'lib', 'ansible', 'plugins', 'action'))

    # Patch AnsibleModule to prevent it from exiting on a

# Generated at 2022-06-11 07:37:24.124883
# Unit test for function main
def test_main():
    import json

    data = '{"changed": false, "ping": "pong"}'
    args = "{'data': 'pong'}"
    sys.argv = ['ansible-test', 'ping', '-m', 'ping', '--args', args]
    out = json.loads(json.dumps(main()))
    assert data == out

# Generated at 2022-06-11 07:37:25.090948
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:37:32.152467
# Unit test for function main
def test_main():
    # We cannot test that data == crash actually makes the module exit non-zero because that is a normal exception.
    # So we test that the parameter data being crash affects the outcome of the module
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ), supports_check_mode=True)
    with pytest.raises(Exception):
        module.params['data'] = 'crash'
        main()
    result = module.params['data']
    assert result == 'pong'

# Generated at 2022-06-11 07:37:32.598331
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:37:40.688895
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    from ansible.module_utils.basic import AnsibleModule

    class args():
        '''Class to mimic ansible.module_utils.basic.AnsibleModule'''
        def __init__(self, dictionary):
            '''Create an object of class AnsibleModule'''
            self.params = dictionary
            self.fail_json = False
            self.exit_json = True

    def fail_json(**kwargs):
        '''Mimic function fail_json'''
        pass
    class ret():
        '''Class to mimic return ansible.module_utils.basic.AnsibleModule'''
        def __init__(self, dictionary):
            '''Create an object of class ret'''
            self.fail_json = fail_json

    # Create objects of classes Ans

# Generated at 2022-06-11 07:37:42.203076
# Unit test for function main
def test_main():
    # test `A trivial test module`
    assert True

# Generated at 2022-06-11 07:37:49.720854
# Unit test for function main
def test_main():
    my_mock = MagicMock()
    my_mock.params = dict(data='pong')
    main()
    assert my_mock.result == dict(ping='pong')

# Generated at 2022-06-11 07:37:53.172261
# Unit test for function main
def test_main():
    # Test module parameters and exits, without needing to fully initialize Ansible
    ansible_args = {}
    args = AnsibleModule(argument_spec={}, supports_check_mode=True).parse_args(ansible_args)
    assert args["check_mode"]
    assert not args["diff"]

# Generated at 2022-06-11 07:37:55.455079
# Unit test for function main
def test_main():
    ansible_args = dict(
        data='pong'
    )
    module = AnsibleModule(argument_spec=ansible_args, supports_check_mode=True)
    assert 'ping' in main()

# Generated at 2022-06-11 07:37:58.645054
# Unit test for function main
def test_main():
    args = dict(
        data='crash'
    )
    try:
        module = AnsibleModule(argument_spec=dict())
        main()
    except Exception as e:
        assert(str(e) == 'boom')



# Generated at 2022-06-11 07:38:07.290019
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong'}}, supports_check_mode=True)

    def test_ansible_module(**kwargs):
        module.exit_json(**kwargs)

    module.exit_json=test_ansible_module

    try:
        main()
    except Exception as e:
        if "boom" in e.message:
            assert True


# vim: expandtab shiftwidth=4 tabstop=4

# Generated at 2022-06-11 07:38:08.237489
# Unit test for function main
def test_main():
    pass

# ===========================================

# Generated at 2022-06-11 07:38:16.715679
# Unit test for function main
def test_main():
    data_param = {'data': 'pong'}
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = data_param
    result = dict(
        ping=module.params['data'],
    )
    assert main() == module.exit_json(**result)
    test_exception = {'data': 'crash'}
    module.params = test_exception
    try:
        main()
        assert False
    except Exception as e:
        assert str(e) == 'boom'

# Generated at 2022-06-11 07:38:22.147440
# Unit test for function main
def test_main():
    test_data = {
        'data': 'pong',
        'action': 'ping',
        '_ansible_no_log': False,
        'changed': True,
        'ping': 'pong' 
    }
    args = {
        "data": "pong"
    }

    result = main(args)

    assert result == test_data


# Generated at 2022-06-11 07:38:33.476852
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.builtin.ping as ping
    import sys

    if sys.version_info[0] >= 3:
        from unittest.mock import Mock, patch
    else:
        from mock import Mock, patch

    reload(ping)

    module = Mock(spec=AnsibleModule)
    module.params = {'data': 'pong'}

    # If a function returns a value, then it must be returned
    # by exit_json()
    ping.main()
    module.exit_json.assert_called_with(ping='pong')

    # If a function throws an exception, it must be returned by fail_json()
    module.params['data'] = "crash"
    ping.main()
    module.fail_json.assert_

# Generated at 2022-06-11 07:38:36.996546
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main(dict(data='crash'))

    assert main(dict()) == dict(ping='pong')

    assert main(dict(data='foo')) == dict(ping='foo')

# Generated at 2022-06-11 07:38:55.814905
# Unit test for function main
def test_main():
    # Test with no arguments
    m = AnsibleModule(dict())
    p, s, h = m.run_command()
    d = m.from_json(p)
    assert d['ping'] == 'pong'

    # Test with arguments
    m = AnsibleModule(dict(data='splat'))
    p, s, h = m.run_command()
    d = m.from_json(p)
    assert d['ping'] == 'splat'

    # Test with check_mode
    m = AnsibleModule(dict(data='splat'), check_mode = True)
    p, s, h = m.run_command()
    assert p is None
    assert s is None
    assert h is None

    # Test with diff_mode

# Generated at 2022-06-11 07:39:01.172793
# Unit test for function main
def test_main():
    def ansibleModule(argument_spec):
        assert(argument_spec == dict(
            data=dict(type='str', default='pong'),
        ))
        return DictionaryMockModule()

    setattr(__builtins__, 'AnsibleModule', ansibleModule)
    from ansible.module_utils.basic import AnsibleModule
    from ping import main
    main()



# Generated at 2022-06-11 07:39:10.121962
# Unit test for function main
def test_main():
    import json
    import sys

    testmodule = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True)

    # mock the module settings, will get cleaned up at end of test
    testmodule._ansible_no_log = False
    testmodule._ansible_verbosity = 0
    testmodule._ansible_debug = False

    # Save real stdout.
    old_stdout = sys.stdout
    sys.stdout = sys.__stdout__

    # Check if AnsibleModule throws an error when there is 'crash'
    # as the value of data argument

    testmodule.params['data'] = 'crash'

    assert testmodule.fail_json.called is False


# Generated at 2022-06-11 07:39:11.656395
# Unit test for function main
def test_main():
    assert main(data="crash") is None

# Generated at 2022-06-11 07:39:17.270864
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import common_koji

    with patch.object(basic.AnsibleModule, 'exit_json') as exit_json_mock:
        with patch.object(common_koji, 'koji') as koji_mock:
            with patch.object(koji_mock, 'ensure_logged_in'):
                main()
                exit_json_mock.assert_called_once()

# Generated at 2022-06-11 07:39:21.286139
# Unit test for function main
def test_main():
    # Test module arguments
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    )

    # AnsibleModule arguments
    module_args = dict(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    module = AnsibleModule(**module_args)
    module.exit_json(**dict(ping=module.params['data']))

# Generated at 2022-06-11 07:39:25.995619
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule', _AnsibleModule):
        _main()
        module_result = _AnsibleModule.run.call_args[0][0]
        assert module_result['failed'] == False
        assert module_result['changed'] == False
        assert module_result['ping'] == 'pong'

# Generated at 2022-06-11 07:39:28.018405
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        ping.main()

# Generated at 2022-06-11 07:39:36.436584
# Unit test for function main
def test_main():
    # Dummy class for AnsibleModule
    class AnsibleModuleClass(object):
        def __init__(self):
            self._module_class = ''
            self._module_name = ''
            self._module_args = {'data': 'pong'}
            self._result = {}

        def exit_json(self, **kwargs):
            self._result = kwargs


    am = AnsibleModuleClass()
    main()
    assert am._result['ping'] == 'pong'

    am._module_args['data'] = 'crash'
    try:
        main()
        assert False
    except:
        assert True

# Generated at 2022-06-11 07:39:37.020352
# Unit test for function main

# Generated at 2022-06-11 07:39:59.676476
# Unit test for function main
def test_main():
    test_params = {
        'data': {
            'type': 'str',
            'default': 'pong',
        },
    }
    result = {
        'ping': 'pong'
    }
    main(args=None, params=test_params, result=result)

# Generated at 2022-06-11 07:40:02.053739
# Unit test for function main
def test_main():
    import pytest

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-11 07:40:04.992778
# Unit test for function main
def test_main():
    # module = AnsibleModule(
    #     argument_spec=dict(
    #         data=dict(type='str', default='pong'),
    #     ),
    #     supports_check_mode=True
    # )
    assert None == None

# Generated at 2022-06-11 07:40:08.958267
# Unit test for function main
def test_main():
    import json
    import pytest

    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_merge

    with pytest.raises(SystemExit):
        main()


    with pytest.raises(Exception):
        main()

    result = dict(
        ping="pong"
    )
    assert main() == result


# Generated at 2022-06-11 07:40:12.345561
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:40:12.774583
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:40:13.356323
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-11 07:40:16.332855
# Unit test for function main
def test_main():
    m = {'params': {'data': 'pong'}}
    result = main()
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:40:20.620549
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:40:21.380437
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 07:40:59.001096
# Unit test for function main
def test_main():
    # FIXME: unit test is needed
    pass

# Generated at 2022-06-11 07:40:59.648910
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:41:09.282933
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils._text import DIFF_OMITTED
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if PY3:
        builtins = 'builtins'
    else:
        builtins = '__builtin__'

    module_args = dict(
        data=dict(default='pong', type='str'),
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
        add_file_common_args=True,
    )

    # This is the return value for `module.exit_json()`
    result = dict

# Generated at 2022-06-11 07:41:19.086699
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import json
    from ansible.module_utils.basic import AnsibleModule

    with tempfile.NamedTemporaryFile(delete=False) as stdout:
        original_stdout = sys.stdout
        sys.stdout = stdout

# Generated at 2022-06-11 07:41:29.890934
# Unit test for function main
def test_main():
    fp = open("ping-input.json")
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    results = module.from_json(fp)
    if results['data'] == 'crash':
        raise Exception("boom")
    
    result = dict(
        ping=results['data'],
    )
    assert result['ping'] == results['params']['data']
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-11 07:41:31.012868
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:41:32.578837
# Unit test for function main
def test_main():
    args = {
        'data': 'pong'
    }
    main(args)

# Generated at 2022-06-11 07:41:37.522250
# Unit test for function main
def test_main():
    # Input as in above main function
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    #EXIT_JSON = {'changed': True, 'rc': 0, 'results': 'pong'}
    assert main() == None


# Generated at 2022-06-11 07:41:38.170478
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:41:42.520482
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:43:15.754243
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module

# Generated at 2022-06-11 07:43:22.916114
# Unit test for function main
def test_main():
    # Fail the module under test if a parameter's value is set to crash
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Pass the module under test if a parameter's value is set to something other than crash
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-11 07:43:23.493951
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:43:26.704435
# Unit test for function main
def test_main():
    test_ping_data = ['pong', 'crash']
    test_ping_result = ['pong', Exception]
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    for i in range(len(test_ping_result)):
        with pytest.raises(test_ping_result[i]):
            module.params.update(data=test_ping_data[i])
            main()

# Generated at 2022-06-11 07:43:28.770770
# Unit test for function main
def test_main():
    args = {}
    args['data'] = 'crash'
    with pytest.raises(Exception):
        main()



# Generated at 2022-06-11 07:43:36.873732
# Unit test for function main
def test_main():

    class _module(object):
        def __init__(self, argument_spec=None, supports_check_mode=False):
            self.params = {}
            self.exit_json = lambda x: print(x)
            self.fail_json = lambda x: print(x)

    class _ansible_module(object):
        def __init__(self, argument_spec=None, supports_check_mode=False):
            self.params = {}
            self.exit_json = lambda x: print(x)
            self.fail_json = lambda x: print(x)

    class _exit_json:
        def __init__(self, name):
            self.name = name

    module = _module(supports_check_mode=True)
    module.params['data'] = 'pong'

    ansible_module

# Generated at 2022-06-11 07:43:38.154515
# Unit test for function main
def test_main():
        assert 1 == 1, "Unit test failed"


# Generated at 2022-06-11 07:43:42.036196
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=test.params['data'],
    )
    test.exit_json(**result)

# Generated at 2022-06-11 07:43:45.603446
# Unit test for function main
def test_main():
    args = dict(data="pong")
    result = dict(ping="pong")
    module = AnsibleModule(argument_spec=args, supports_check_mode=True)
    module.exit_json.return_value = result
    assert main() == result

# Generated at 2022-06-11 07:43:47.686245
# Unit test for function main
def test_main():
    data = dict(
        data='crash'
    )

    with pytest.raises(Exception) as excinfo:
        main(data)