

# Generated at 2022-06-11 07:36:00.983627
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-11 07:36:01.542504
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:36:02.348655
# Unit test for function main
def test_main():
    ping = main()
    assert ping == 'pong'

# Generated at 2022-06-11 07:36:04.762598
# Unit test for function main
def test_main():
    args = dict(
        data = 'pong',
        ansible_check_mode = False
    )
    assert (main(args) == {})
    # assert(main() == 'boom')

# Generated at 2022-06-11 07:36:09.404938
# Unit test for function main
def test_main():
    import json
    testmod = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    with pytest.raises(Exception):
        main(testmod)

    testmod.params['data'] = 'crash'
    testmod.exit_json

# Generated at 2022-06-11 07:36:10.007582
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:36:18.740578
# Unit test for function main
def test_main():
    test_ping_data = {
        'ping' : 'pong'
    }
    AnsibleModule = mock.MagicMock()
    AnsibleModule.params = {'data':'pong'}
    main()
    AnsibleModule.exit_json.assert_called_once_with(**test_ping_data)

# Generated at 2022-06-11 07:36:25.614905
# Unit test for function main
def test_main():
    # input_data = 'ping'
    data_map = {
        'ping': 'pong',
        'crash': Exception('boom'),
    }
    for input_data, expected_result in data_map.iteritems():
        result = main(input_data)
        if result != expected_result:
            raise Exception('Failed test_main: input=%s, expected=%s, result=%s' % (input_data, expected_result, result))

test_main()

# Generated at 2022-06-11 07:36:29.151290
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test module with args
    result = main()
    assert result == dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-11 07:36:29.716919
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:36:36.586407
# Unit test for function main
def test_main():
    from ansible.modules.system import ping
    args = {'data': 'pong'}
    result = ping.main(args)
    assert result['ansible_facts']['ping'] == 'pong'


# Generated at 2022-06-11 07:36:48.273073
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    import json
    import sys

    test_result = {}
    test_result["data"] = "pong"
    test_result["rc"] = 0
    test_result["stdout_lines"] = ["1"]
    test_result["stdout"] = "1"
    test_result["stderr_lines"] = []
    test_result["stderr"] = ""
    test_result["changed"] = False
    test_result["invocation"] = {
        "module_name": "ansible.builtin.ping",
        "module_args": "data=pong",
        "task_args": ""
    }

    result = {}
    result["ping"] = "pong"



# Generated at 2022-06-11 07:36:55.952926
# Unit test for function main
def test_main():
    modmock = mock.MagicMock()
    with mock.patch.dict(ansible.module_utils.basic.AnsibleModule.__dict__, {
        'exit_json.__name__': 'exit_json',
        '__package__': None}):
        # __package__ is needed to find AnsibleModule.exit_json
        with mock.patch('ansible.module_utils.basic.AnsibleModule', modmock):
            ping.main()
            modmock.assert_called_once()
            args, _ = modmock.call_args
            assert args[0] == dict(
                argument_spec=dict(
                    data=dict(type='str', default='pong'),
                ),
                supports_check_mode=True
            )

            # test argument parsing
            args[1]()

# Generated at 2022-06-11 07:37:06.734474
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    # define return results for test function main
    # if module.exit_json(**result) is called in the function 'main'
    # the below results are returned to the calling function
    # 'mock_ansible_module.exit_json.assert_called_with' returns
    # None for the first argument and results for the second argument
    # these are the results that are returned to the calling function
    #
    # if exception occurs in function 'main', the below results and the exception
    # are returned to the calling function
    # 'mock_ansible_module.fail_json.assert_called_with' returns
    # None for the first argument and results for the second argument
    # these are the results that are returned to the calling function

# Generated at 2022-06-11 07:37:12.961510
# Unit test for function main
def test_main():
    # Test we can logon to 'webservers' and execute python with json lib.
    # ansible webservers -m ping
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:37:17.155249
# Unit test for function main
def test_main():
    test_result = dict(
        ping='pong'
    )
    module = type('ping', (object,), {'params': {'data': 'pong'}, 'exit_json': print})
    try:
        main()
    except TypeError:
        main(module)
    assert test_result == result

# Generated at 2022-06-11 07:37:18.175901
# Unit test for function main
def test_main():
    # Simple test of main()
    pass

# Generated at 2022-06-11 07:37:19.609099
# Unit test for function main
def test_main():
    # TODO: move the test_main logic to the test_main.py
    pass

# Generated at 2022-06-11 07:37:25.970614
# Unit test for function main
def test_main():
    # mock module to return a value for the `data` parameter
    module = mock.MagicMock(params={'data': 'mock_data', 'foo': 'bar'})
    # mock exit_json to capture the return value
    module.exit_json = mock.MagicMock()

    # run our function
    main()

    # verify function exited correctly
    module.exit_json.assert_called_once_with(ping='mock_data')

# Generated at 2022-06-11 07:37:28.911695
# Unit test for function main
def test_main():
    m = AnsibleModule({"data": "pong"}, check_mode=False)
    result = main()
    assert result['ping'] == "pong"

# Generated at 2022-06-11 07:37:37.841961
# Unit test for function main
def test_main():
    # Test that function main returns a value
    assert True == True

# Generated at 2022-06-11 07:37:42.347727
# Unit test for function main
def test_main():
    mock_module = MagicMock(return_value=None)
    mock_module.params = dict(
        data='pong',
    )
    import ansible.modules.system.ping as ping
    ping.AnsibleModule = mock_module
    ping.main()

# Generated at 2022-06-11 07:37:47.357193
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as excinfo:
        module_params = dict(data='crash')
        main()
    assert 'boom' in str(excinfo.value)
    module_params = dict(data='pong')
    result=main()
    assert result.get('ping')=='pong'

# Generated at 2022-06-11 07:37:56.017626
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    assert module.params['data'] == 'pong'
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str'),
        ),
    )
    assert module.params['data'] is None
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', choices=['crash', 'pong']),
        ),
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:38:07.732762
# Unit test for function main
def test_main():

    # Data is not empty
    data = dict(
        data = 'pong'
    )

    # Mock the module class
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type = 'str', default = 'pong')
        )
    )

    # Set the module return value to data
    module.exit_json = Mock(return_value = data)

    # Test function
    main()

    # Test return value
    assert module.exit_json.called
    assert_equal(module.exit_json.call_args[0][0], data)

    # Test function
    main()

    # Test return value
    assert module.exit_json.called
    assert_equal(module.exit_json.call_args[0][0], data)

# Generated at 2022-06-11 07:38:08.419673
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:38:15.336191
# Unit test for function main
def test_main():
    import sys
    import pytest

    def test_data_crash():
        sys.argv = [sys.argv[0], "{'data': 'crash'}"]
        with pytest.raises(Exception) as exc:
            main()
        assert exc.value.args[0] == 'boom'

    def test_data_pong():
        sys.argv = [sys.argv[0], "{'data': 'pong'}"]
        main()

    test_data_pong()
    test_data_crash()

# Generated at 2022-06-11 07:38:18.078743
# Unit test for function main
def test_main():
    input_args = dict(data='pong')
    result = dict(ping='pong')
    assert main(input_args) == result


# Generated at 2022-06-11 07:38:19.150266
# Unit test for function main
def test_main():
    print("Testing ping")
    main()

# Generated at 2022-06-11 07:38:20.223999
# Unit test for function main
def test_main():
    # Not Implemented
    pass

# Generated at 2022-06-11 07:38:41.129592
# Unit test for function main
def test_main():
    def test_module(*args, **kwargs):
        module_args = dict(
            data=dict(type='str', default='pong'),
        )
        module_args.update(**kwargs)
        module_return = dict(
            ping=module_args['data'],
        )
        return module_return
    test_cases = [
        {
            'module_args': {},
            'expected_results': {'ping': 'pong'},
        },
        {
            'module_args': {'data': 'foo'},
            'expected_results': {'ping': 'foo'},
        }
    ]
    for test_case in test_cases:
        assert test_module(**test_case['module_args']) == test_case['expected_results']


# Generated at 2022-06-11 07:38:45.413620
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:38:46.024933
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:38:51.317302
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong'), ), supports_check_mode=True)
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(ping=module.params['data'], )
    module.exit_json(**result)

# Generated at 2022-06-11 07:39:02.430271
# Unit test for function main
def test_main():
    from ansible.config import cfg

    # Setup arguments and parameters
    args = dict(
        _ansible_debug=False,
        _ansible_check_mode=False,
        ansible_ssh_user='foobar',
        ansible_python_interpreter='/usr/bin/python',
        ansible_shell_type='csh',
        ansible_shell_executable='/bin/csh',
        ansible_facts={
            'python_version': [2, 7, 14],
            'python_executable': '/usr/bin/python',
            'python_version_info': [2, 7, 14, 'final', 0],
            'has_systemd': True
        },
        ansible_playbook_python='/usr/bin/python'
    )

# Generated at 2022-06-11 07:39:04.637276
# Unit test for function main
def test_main():
    module_args = dict(
        'data', 'crash',
    )

    with pytest.raises(Exception):
        main(module_args)

# Generated at 2022-06-11 07:39:08.144283
# Unit test for function main
def test_main():
    # Test that an exception will be raised if a crash is requested
    # And the output is correct if no crash is specified
    with pytest.raises(Exception):
        main(dict(data='crash'))
    assert main(dict(data='pong')) == dict(ping='pong')

# Generated at 2022-06-11 07:39:18.271233
# Unit test for function main

# Generated at 2022-06-11 07:39:18.856633
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:39:21.889061
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:39:57.479293
# Unit test for function main
def test_main():
    import ansible.builtin.ping as ping
    import pytest

    class test_AnsibleModule(object):

        class test_params(object):
            data = 'pong'

        params = test_params()

    with pytest.raises(SystemExit):
        ping.main()
        assert main == 0

# Generated at 2022-06-11 07:40:03.508623
# Unit test for function main
def test_main():

    from ansible.module_utils import basic
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic
    import ansible.module_utils

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={'data': {'type': 'str', 'default': 'pong'}},
        supports_check_mode=True
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = {'ping': module.params['data']}

    module.exit_json(**result)

# Generated at 2022-06-11 07:40:05.069706
# Unit test for function main
def test_main():
    ping = main(dict())
    assert ping == dict(ping='pong')

# Generated at 2022-06-11 07:40:06.812483
# Unit test for function main
def test_main():
    mod, res = main()
    assert mod.params['data'] == 'pong'
    assert res['ping'] == 'pong'

# Generated at 2022-06-11 07:40:08.104030
# Unit test for function main
def test_main():
    p = main()
    assert p['ping'] == 'pong', "sqrt of 4 should be 2"

# Generated at 2022-06-11 07:40:09.216974
# Unit test for function main
def test_main():
	with pytest.raises(AnsibleModule):
		main()

# Generated at 2022-06-11 07:40:17.669360
# Unit test for function main
def test_main():
    """Test of module for Ansible"""
    import sys
    import os
    import copy
    
    try:
        # Used to simulate AnsibleModule where necessary
        import ansible.module_utils.basic
    except:
        raise Exception('Could not import ansible.module_utils.basic')
    
    # AnsibleModule will set these attributes
    module_params = dict()
    result = dict()
    fail_json = dict()
    
    # AnsibleModule() calls exit_json() and exit_json() calls sys.exit()
    # This makes unit testing harder so we catch the call to sys.exit on sys.exit and
    # set a flag to let us know the call was made.  We will reraise the exception after
    # testing if it is not the expected sys.exit() exception.
    sys_exit = False
    original

# Generated at 2022-06-11 07:40:18.188908
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:40:23.746976
# Unit test for function main
def test_main():
    from ansible.module_utils import modules
    from ansible.module_utils._text import to_bytes, to_text

    data = {
        "ANSIBLE_MODULE_ARGS": {
            "data": "",
            "_ansible_check_mode": False,
            "_ansible_diff": False,
            "_ansible_verbosity": 3,
        },
        "ANSIBLE_MODULE_CONSTANTS": {},
    }

    set_module_args(data["ANSIBLE_MODULE_ARGS"])
    result = main()
    assert result == False

# Generated at 2022-06-11 07:40:25.133935
# Unit test for function main
def test_main():
    # Simple test to verify main() runs
    from ansible.module_utils.basic import AnsibleModule
    main()

# Generated at 2022-06-11 07:41:33.824424
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:41:37.188222
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:41:41.161059
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        ansible_module = MagicMock()
        ansible_module.params = {'data':'pong'}
        test_object = (ansible_module, {})
        main(test_object)
        assert exit_json.called

# Generated at 2022-06-11 07:41:49.613569
# Unit test for function main
def test_main():
    def my_exit_json(*args, **kwargs):
        assert args[0]['ping'] == 'pong'

    def my_fail_json(*args, **kwargs):
        assert False

    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    m.exit_json = my_exit_json
    main()
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    m.fail_json = my_fail_json
    m.params = dict(
        data='crash'
    )
    main()

# Generated at 2022-06-11 07:41:53.414122
# Unit test for function main
def test_main():

    # Module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Mock return
    result = dict(
        ping=module.params['data']
    )

    assert result == main()

# Generated at 2022-06-11 07:41:56.121681
# Unit test for function main
def test_main():
    mod_mock = MagicMock()
    main(mod_mock)
    assert mod_mock.exit_json.called
    assert mod_mock.exit_json.called_once_with(ping='pong')


# Generated at 2022-06-11 07:41:57.622027
# Unit test for function main
def test_main():
    global __name__
    __name__ = 'ping'
    print(main.__doc__)

# Generated at 2022-06-11 07:42:00.732107
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == main()

# Generated at 2022-06-11 07:42:04.309415
# Unit test for function main
def test_main():
    args = dict(data='pong')
    m = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong')
    ))
    m.params = args
    main()
    assert m.exit_json.called
    assert not m.fail_json.called

# Generated at 2022-06-11 07:42:07.092378
# Unit test for function main
def test_main():
    # TODO: Ideally we should load a json file for these arguments
    #       This way we test the module in an almost real-world scenario
    module_args = {
        'data': 'pong',
    }
    module = AnsibleModule(
        argument_spec=module_args,
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-11 07:44:59.747486
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    import json



# Generated at 2022-06-11 07:45:03.743415
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(),
        ),
        supports_check_mode=True
    )
    try:
        main()
    except Exception as e:
        if "crash" in e.message:
            module.exit_json(changed=True)
        raise e
    module.exit_json(changed=False)

# Generated at 2022-06-11 07:45:04.923860
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    assert main(module) == 0

# Generated at 2022-06-11 07:45:05.535003
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:45:10.826419
# Unit test for function main
def test_main():
    test_args = { 'data': 'pong' }
    with patch.object(AnsibleModule, 'exit_json'):
        with patch.object(AnsibleModule, 'argument_spec'):
            AnsibleModule.argument_spec = dict(data=dict(type='str', default='pong'))
            with patch.object(AnsibleModule, 'params'):
                AnsibleModule.params = test_args
                main()
                AnsibleModule.exit_json.assert_called_with(**test_args)

# Generated at 2022-06-11 07:45:15.051060
# Unit test for function main
def test_main():
    module_args = dict(
        data=dict(type='str', default='pong'),
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json(**result)

# Generated at 2022-06-11 07:45:24.267423
# Unit test for function main
def test_main():
    dummy_module = DummyAnsibleModule(argument_spec={
        'data': dict(type='str', default='pong')
    })
    dummy_module.params = {
        'data': 'pong'
    }

    # Test the happy path
    assert main(dummy_module) == {'changed': False, 'ping': 'pong'}
    assert dummy_module.exit_json.call_count == 1

    dummy_module.exit_json.reset_mock()

    # Test failure path
    dummy_module.params = {
        'data': 'crash'
    }
    assert main(dummy_module) == {'failed': True, 'msg': 'boom'}
    assert dummy_module.fail_json.call_count == 1


# Generated at 2022-06-11 07:45:24.816710
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:45:30.206018
# Unit test for function main
def test_main():
    # Test with default values for args
    module_args = {}
    result = main()
    assert(result == {"ping":"pong"} )

    # Test with pong datum
    module_args = {'data': 'pong'}
    result = main()
    assert(result == {"ping":"pong"} )

    # Test with data=crash
    module_args = {'data': 'crash'}
    # Call to main raises an exception, so we cannot check the result
    assert(main() is None)

# Generated at 2022-06-11 07:45:30.953324
# Unit test for function main
def test_main():
    pass