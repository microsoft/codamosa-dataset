

# Generated at 2022-06-11 07:36:05.013605
# Unit test for function main
def test_main():
    # Mock out the module spec to force the check mode status to be True
    def get_module_spec(self):
        return {'check_mode': True}

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    orig_get_spec = builtins.__dict__.get('_get_module_spec', None)
    builtins._get_module_spec = get_module_spec
    # Run the module
    main()
    # Restore the get_module_spec call
    if orig_get_spec:
        builtins._get_module_spec = orig_get_spec
    else:
        del builtins._get_module_spec

# Generated at 2022-06-11 07:36:05.933874
# Unit test for function main
def test_main():
    ping = main()
    assert ping == 'pong'

# Generated at 2022-06-11 07:36:10.908358
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:36:14.865526
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        assert main == module.exit_json

    except AssertionError as e:
        raise(e)


# Generated at 2022-06-11 07:36:23.795601
# Unit test for function main
def test_main():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file for test
    tfile = tempfile.NamedTemporaryFile(delete=False)
    # Create the test module spec for function main (generated from args above)
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Run the module code
    main()

    # Parse out the JSON returned by module code
    data = json.loads(tfile.read())

    # Remove the temporary file
    os.unlink(tfile.name)

    # Test the return value
    assert data['ping'] == 'pong'

# Generated at 2022-06-11 07:36:30.251196
# Unit test for function main
def test_main():
    stdout = StringIO()
    sys.stdout = stdout

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    sys.stdout = sys.__stdout__

    assert stdout.getvalue() == "hello\n"


# Generated at 2022-06-11 07:36:40.560977
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(*args, **kwargs):
        args = list(args)
        if 'check_mode' in kwargs and kwargs['check_mode'] is True:
            args[0]['check_mode'] = True
        elif 'check_mode' in kwargs:
            args[0].pop('check_mode', None)
        for arg in args:
            if 'params' in arg and 'data' in arg['params'] and arg['params']['data'] == 'crash':
                raise Exception("boom")
        return dict(changed=True, ping=args[0]['params']['data'])

    original_module = AnsibleModule

    # substitute the decarated function into the module during testing
    AnsibleModule = test

# Generated at 2022-06-11 07:36:48.323228
# Unit test for function main
def test_main():
  # Unit test for function main

  # Load the module
  module = AnsibleModule(
      argument_spec=dict(
          data=dict(type='str', default='pong'),
      ),
      supports_check_mode=True
  )
  # Test the function
  result = dict(
      ping=module.params['data'],
  )
  # Check output
  assert result == {'ping': 'pong'}
  # Test the function
  with pytest.raises(Exception) as e:
    result = main(dict(data='crash'))

# Generated at 2022-06-11 07:36:48.930020
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:36:50.898915
# Unit test for function main
def test_main():
    args = {'data': 'pong'}
    result = {}
    main()
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:37:08.854228
# Unit test for function main
def test_main():
    def check_results(result, values):
        for key in values.keys():
            assert result.get(key) == values.get(key)
    args = dict(data='pong')
    result = dict(changed=False, ping='pong')
    mod = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True)
    mod.params = args
    main()
    check_results(mod.exit_json.call_args[0][0], result)
    args = dict(data='crash')
    result = dict(failed=True, msg='Exception: boom')

# Generated at 2022-06-11 07:37:09.489537
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:37:15.019627
# Unit test for function main
def test_main(): 
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result['ping'] == 'pong'


# Generated at 2022-06-11 07:37:20.125633
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # TODO
    # unit test for data crash

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:37:26.209849
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # pylint: disable=missing-kwoa
    assert main() is None
    module.params['data'] = 'crash'
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-11 07:37:33.087298
# Unit test for function main
def test_main():
    # Test module execution
    data = dict(
        data='pong',
    )
    rc = AnsibleModule(argument_spec=data).execute()
    assert rc['changed'] is False
    assert rc['ansible_facts'] == dict(
        ping=data['data'],
    )

    # Test module execution when data is set to crash
    data = dict(
        data='crash',
    )
    rc = AnsibleModule(argument_spec=data).execute()
    assert rc['failed'] is True

# Generated at 2022-06-11 07:37:38.048640
# Unit test for function main
def test_main():
    argv = [
        "ping.py",
    ]
    with patch('ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule') as mock_amodule:
        module_instance = mock_amodule.return_value
        assert module_instance.send_caching_for_session.return_value == 'pong'
        main()

# Generated at 2022-06-11 07:37:49.567774
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.module_utils import basic as basic_module_util
    import json

    basic._ANSIBLE_ARGS = None

# Generated at 2022-06-11 07:37:51.724853
# Unit test for function main
def test_main():
    ansible.module_utils.basic.AnsibleModule = ansible.module_utils.basic.AnsibleModuleMock
    main()

# Generated at 2022-06-11 07:37:54.223480
# Unit test for function main
def test_main():
    arg = [
        'ansible.builtin.ping',
        '-a', 'data=pong'
    ]
    with mock.patch.object(sys, 'argv', arg):
        main()


# Generated at 2022-06-11 07:38:05.947763
# Unit test for function main
def test_main():
  # test normal return
  from ansible.module_utils.basic import AnsibleModule
  from ansible.modules.ping import main

  my_module = AnsibleModule()
  my_module.params = {}
  my_module.params['data'] = 'pong'

  main()

# Generated at 2022-06-11 07:38:09.987428
# Unit test for function main
def test_main():
    # Test with a data value of crash
    testargs = {'data': 'crash'}
    with pytest.raises(Exception):
        main(testargs)

    # Test with a data value of pong (the default)
    output = main({"data": "pong"})
    assert output["ping"] == "pong"

# Generated at 2022-06-11 07:38:19.708884
# Unit test for function main
def test_main():
    args = {
        'data': 'foo',
    }
    rc = main({'ANSIBLE_MODULE_ARGS':args})
    assert(rc == {'ping': 'foo'})

    args = {
        'data': 'crash',
    }
    try:
        rc = main({'ANSIBLE_MODULE_ARGS':args})
        print("rc=%s" % rc)
        assert(False)
    except Exception as e:
        assert('boom' in str(e))

    args = {
        'data': 'pong',
    }
    rc = main({'ANSIBLE_MODULE_ARGS':args})
    assert(rc == {'ping': 'pong'})


# Generated at 2022-06-11 07:38:26.143586
# Unit test for function main
def test_main():
    # This example is from the source code
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:38:30.305027
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main(module.params) == dict(
        ping=module.params['data'])

# Generated at 2022-06-11 07:38:40.675304
# Unit test for function main
def test_main():
    # Do not generate a diff for this test.
    # This test is the one C(no_log) test that is required for
    # a baseline coverage test.  In fact, there's no way to
    # cover this test perfectly and still be able to test that a diff
    # is generated.  There's also no way to cover the test properly
    # without having the diff be tested.  So we're stuck with no
    # coverage for the one line that we can't test coverage for.
    # This is a flake8 failure.  See
    # https://github.com/ansible/ansible/pull/41413#issuecomment-412073202
    # for a more in-depth discussion on the limitations of this test.
    # flake8: noqa
    args = dict(data='pong')

# Generated at 2022-06-11 07:38:41.208710
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:38:42.233605
# Unit test for function main
def test_main():
    args = {}
    main(args)

# Generated at 2022-06-11 07:38:47.485679
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Unit tests for try statement
    try:
        result = dict(
            ping=module.params['data'],
        )
    except Exception:
        raise Exception("boom")

# Generated at 2022-06-11 07:38:51.127666
# Unit test for function main
def test_main():
    # The following example shows how to capture the results
    # of a call to the module.
    def capture(stdout, stderr, **kwargs):
        print(str(stdout))
        print(str(stderr))

        assert "\"ping\": \"pong\"" in str(stdout)

        module.exit_json.return_value = kwargs

        return module.exit_json(**kwargs)

    def fail(stdout, stderr, **kwargs):
        assert "An exception occurred during task execution." in str(stderr)

        module.exit_json.return_value = kwargs

        return module.fail_json(**kwargs)


# Generated at 2022-06-11 07:39:16.736295
# Unit test for function main
def test_main():
    import json
    fake_result = [json.dumps({'ping': 'pong'})]
    def fake_exit_json(result):
        fake_result[0] = json.dumps(result)

    class FakeModule:
        def __init__(self, result):
            self.params = result
            self.exit_json = fake_exit_json

    def fake_argument_spec():
        return {}


# Generated at 2022-06-11 07:39:21.171210
# Unit test for function main
def test_main():
    """ test_main() function unit test """
    args = {'data': 'crash'}
    # param_args = {'params':args }
    # p = AnsibleModule(param_args)
    p = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    try:
        p.exit_json(main())
    except Exception:
        p.fail_json(failed=True)

# Generated at 2022-06-11 07:39:23.937142
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True)
    assert(main() != None)

# Generated at 2022-06-11 07:39:30.125866
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        assert(False)

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-11 07:39:38.017929
# Unit test for function main
def test_main():
    # Import and Hide Parameters
    module_args = dict(data=dict(type='str', default='pong'))

    # Define Results
    result = dict(
        ping='pong'
    )

    # Replace Module
    AnsibleModule = mock.MagicMock()
    module = mock.MagicMock(params=module_args)
    AnsibleModule.return_value = module

    # Replace Exceptions
    Exception = mock.MagicMock()

    # Run Function
    main()
    
    # Validate Results
    module.exit_json.assert_called_with(**result)


# Generated at 2022-06-11 07:39:42.032514
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.check_mode=True
    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:39:42.620512
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:39:44.590340
# Unit test for function main
def test_main():
    args = dict(
            data = 'pong',
            )
    result = main(args)
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:39:45.511744
# Unit test for function main
def test_main():
    # Just check it doesn't crash
    main()

# Generated at 2022-06-11 07:39:54.034204
# Unit test for function main
def test_main():
    import time
    import uuid
    import os
    # the following is not safe to run in parallel, since the environment
    # variables are overwritten

# Generated at 2022-06-11 07:40:41.041504
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Create mocked module arguments
    module_args = dict(
        data=dict(type='str', default='pong'),
    )

    # Create expected results
    expected_results = dict(
        ping='pong',
    )

    # Run the module
    actual_results = main()

    # Check the results
    assert actual_results == expected_results

# Generated at 2022-06-11 07:40:44.154132
# Unit test for function main
def test_main():
    # Test with no parameters
    module = Mock(params=dict())
    # Test with data=pong
    module.params['data'] = 'pong'
    # Test with data=crash
    module.params['data'] = 'crash'

# Generated at 2022-06-11 07:40:48.721795
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-11 07:40:53.820382
# Unit test for function main
def test_main():
    test_params = dict(
        data='pong'
    )
    result = dict(
        ping='pong'
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = test_params

    try:
        main()
    except SystemExit as e:
        assert e == 0
    except Exception as e:
        raise
    else:
        assert result == module.exit_json.call_args[0][0]

# Generated at 2022-06-11 07:40:59.345105
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:41:05.504815
# Unit test for function main
def test_main():
    def func(args):
        class FT:
            def __init__(self):
                self.data = args['data']
        return FT()

    module_args = {
        'data': 'pong'
    }
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True,
                           )
    module.exit_json = func
    main()

# Generated at 2022-06-11 07:41:14.504336
# Unit test for function main
def test_main():
    # param: data
    module = load_fixture('ping.py', dict(data='pong'))
    ping = module.ansible_module.params['data']
    assert ping == 'pong'
    # return: ping
    assert module.exit_json()['ping'] == 'pong'
    assert module.exit_json()['ping'] == module.ansible_module.params['data']
    assert module.exit_json()['ping'] == 'pong'
    # exception: boom
    module = load_fixture('ping.py', dict(data='crash'))
    assert module.run() == False
    assert module.ansible_module.fail_json()['msg'] == 'An exception occurred during task execution. To see the full traceback, use -vvv. The error was: Exception: boom'

# Generated at 2022-06-11 07:41:22.528951
# Unit test for function main
def test_main():
    def fake_module(**kwargs):
        m_args = dict(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
        m_args.update(kwargs)
        return AnsibleModule(**m_args)
    #
    # test with crash
    #
    m = fake_module(params=dict(data="crash"))
    with pytest.raises(Exception):
        main()
    #
    # test with good data
    #
    m = fake_module(params=dict(data="pong"))
    main()
    assert m.exit_json.call_count == 1
    assert m.exit_json.call_args == call(**dict(ping='pong'))
    #


# Generated at 2022-06-11 07:41:27.609928
# Unit test for function main
def test_main():
    module_args = dict(
        data=dict(type='str', default='pong'),
    )
    result = {"ping": "pong"}
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert result == main()

# Generated at 2022-06-11 07:41:36.157235
# Unit test for function main
def test_main():
    #assert ping.__version__ == '0.3.3'
    pass
    

 
# Test ping.py
#python -m pytest test_ping.py
#python3 -m pytest test_ping.py


# https://www.youtube.com/watch?v=sugvnHA7ElY
# https://github.com/pytest-dev/pytest 
# https://docs.pytest.org/en/latest/
# pip install pytest

# python -m pytest test_sample.py
# python3 -m pytest test_sample.py

# Generated at 2022-06-11 07:43:09.368133
# Unit test for function main
def test_main():
    data_in = {'data': 'pong'}
    data_out = {'changed': False, 'ping': 'pong'}
    path = 'ansible.builtin.ping'
    res = {'ping': 'pong'}
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    module.params['data'] = data_in['data']
    result = main()
    assert(result['ping'] is data_out['ping'])



# Generated at 2022-06-11 07:43:18.117400
# Unit test for function main
def test_main():
    import pytest
    import ansible_collections.ansible.builtin
    M = ansible_collections.ansible.builtin.plugins.modules.ping.main
    def test_fail_MissingRequiredArg(mocker):
        with pytest.raises(TypeError) as error:
            M(dict())
        assert "missing a required argument: 'AnsibleModule'" in str(error.value)
    mocker.patch('ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule.exit_json')
    def test_AnsibleModuleExitJson(mocker, monkeypatch):
        monkeypatch.setattr(ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule, 'params', {'data': 'pong'})


# Generated at 2022-06-11 07:43:22.020144
# Unit test for function main
def test_main():
  module = MockAnsibleModule(
    argument_spec=dict(
        data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True
  )
  with pytest.raises(AnsibleModuleExit):
    main()


# Generated at 2022-06-11 07:43:23.404038
# Unit test for function main
def test_main():
  content = main()
  assert content['args']['data'] == 'pong'

# Generated at 2022-06-11 07:43:28.240648
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == None

# Generated at 2022-06-11 07:43:30.954864
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-11 07:43:34.494396
# Unit test for function main
def test_main():
    argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    test_module=AnsibleModule(argument_spec=argument_spec)
    result=dict(
        ping=test_module.params['data'],
    )
    test_module.exit_json(**result)

# Generated at 2022-06-11 07:43:37.526895
# Unit test for function main
def test_main():
    print("\n STARTING TEST FOR main")
    test_function = main()
    assert test_function is not None
    assert type(test_function) == dict
    print("\n FINISHED TEST FOR main")

test_main()

# Generated at 2022-06-11 07:43:38.076751
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:43:40.993699
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
