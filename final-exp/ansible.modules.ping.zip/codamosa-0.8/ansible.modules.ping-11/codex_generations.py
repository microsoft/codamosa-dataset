

# Generated at 2022-06-11 07:36:11.986493
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    mo = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    io = StringIO()
    sys.stdout = io
    main()
    sys.stdout = sys.__stdout__
    assert io.getvalue().startswith("{\"changed\": false, \"ping\": \"pong\"}")
    
    mo.params['data'] = 'crash'
    mo.check_mode = False
    try:
        main()
        assert False, "Exception should have been raised"
    except:
        pass

# Generated at 2022-06-11 07:36:16.368222
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == module.exit_json(**result)
    assert main() == module.exit_json(**result)
    assert main() == module.exit_json(**result)

# Generated at 2022-06-11 07:36:21.562467
# Unit test for function main
def test_main():
    # copy from above and make adjustments for testing
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Test with different parameters

# Generated at 2022-06-11 07:36:29.083151
# Unit test for function main
def test_main():
    ping_data = 'pong'  # should be default for data parameter
    m_params = {'data': ping_data}
    m_args = {'argument_spec': {'data': {'type': 'str', 'default': 'pong'}},
              'supports_check_mode': True}
    m = AnsibleModule(**m_args)
    m.params = m_params
    main()
    assert m.exit_json.called
    result = m.exit_json.call_args[0][0]
    assert 'ping' in result
    assert result['ping'] == ping_data

# Generated at 2022-06-11 07:36:30.327566
# Unit test for function main
def test_main():
    data = 'crash'
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-11 07:36:35.901052
# Unit test for function main
def test_main():
    import pytest
    import json
    import mock

    _mock_module = mock.Mock()
    _mock_module.params = dict(
        data='pong'
    )
    _mock_module.exit_json.side_effect = SystemExit

    try:
        with pytest.raises(SystemExit):
            main()
    except SystemExit:
        _mock_module.exit_json.assert_called_with(
            ping='pong'
        )

# Generated at 2022-06-11 07:36:45.532748
# Unit test for function main
def test_main():
    test_dict = dict()
    test_dict['data'] = 'pong'
    test_ping = main(test_dict)
    assert test_ping == test_dict['data']
    test_dict['data'] = 'crash'
    test_ping = main(test_dict)
    try:
        test_ping = main(test_dict)
    except Exception: # bang!
        assert True

# Unit tests for full module
from ansible.tests.unit.module_utils.ansible_base_mock import MockAnsibleModule 
MockAnsibleModule.mock_module_common()


# Generated at 2022-06-11 07:36:51.306699
# Unit test for function main
def test_main():

    # Construct the call
    test_mock = MagicMock()
    test_mock.params = { "data": "pong" }
    test_mock.exit_json = MagicMock()
    main()

    # Test it ran the exit_json function
    assert test_mock.exit_json.called
    # Test it ran the exit_json function with the correct data
    test_mock.exit_json.assert_called_with(ping="pong")

# Generated at 2022-06-11 07:36:54.189389
# Unit test for function main
def test_main():
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert m.params['data'] == 'pong'
    assert m.check_mode is True

# Generated at 2022-06-11 07:37:05.505093
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    test_cases = [
        (
            dict(
                data='pong'
            ),
            dict(
                ping='pong'
            )
        ),
        (
            dict(
                data='crash'
            ),
            dict(
                exception='boom'
            )
        ),
    ]

    for arg_spec, expected_result in test_cases:
        m = AnsibleModule(argument_spec=dict())
        m.params = arg_spec
        try:
            main()
            assert False
        except Exception as e:
            if expected_result.get('exception') != str(e):
                raise
        else:
            result = m.exit_json.call_args[0][0]
            assert result == expected_result

# Generated at 2022-06-11 07:37:16.277392
# Unit test for function main
def test_main():
    x = dict(
      data = 'pong'
    )
    y = dict(
      ping = 'pong'
    )
    result = main()
    assert result == y

# Generated at 2022-06-11 07:37:21.561754
# Unit test for function main
def test_main():
    #from ansible.module_utils.basic import AnsibleModule
    module_args = {
        'data': 'pong'
        # 'argument_spec': {},
        # 'supports_check_mode': True
    }
    with pytest.raises(SystemExit):
        result = main(module_args)
        print (result)
        assert True

# Generated at 2022-06-11 07:37:23.144275
# Unit test for function main
def test_main():
    args = {'data':None}
    result = main()
    assert result['ping'] == 'pong'

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:37:32.041295
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert not module.check_mode
    assert "ping" not in module.exit_json.__dict__
    assert "metadata" not in module.exit_json.__dict__
    assert "changed" not in module.exit_json.__dict__

    module.params['data'] = 'crash'
    try:
        main()
    except Exception as e:
        assert e.message == 'boom'

# Generated at 2022-06-11 07:37:36.769658
# Unit test for function main
def test_main():
    # Mock module arguments
    with patch.multiple(
        'ansible.modules.network.eos.eos_route_interface',
        exit_json=exit_json,
        fail_json=fail_json,
        set_module_args=set_module_args,
        get_module_args=get_module_args
    ) as module_local_mocks:
        # Test function
        main()

# Generated at 2022-06-11 07:37:41.736664
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        "data": "pong"
    })
    test_main(test_module)

    test_module = AnsibleModule({
        "data": "crash"
    })
    with pytest.raises(Exception):
        test_main(test_module)

# Generated at 2022-06-11 07:37:52.453108
# Unit test for function main
def test_main():
    def fake_module(**kwargs):
        return kwargs

    def fake_exit_json(**kwargs):
        return kwargs

    def fake_fail_json(msg=None, **kwargs):
        raise Exception(msg)

    class AnsibleExitJson(object):
        def __init__(self, kwargs):
            self.kwargs = kwargs

    # Example of a function call:
    #   fn(module(argument_spec=dict(foo=dict(type='str', required=True)),
    #             supports_check_mode=True,
    #             check_invalid_arguments=False),
    #      exit_json=fake_exit_json,
    #      fail_json=fake_fail_json)

    # Retrieve the arguments to the function.

# Generated at 2022-06-11 07:37:57.063236
# Unit test for function main
def test_main():

    data = "CUSTOM"
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default=data),
        ),
        supports_check_mode=True
    )

    expected = dict(
        ping=module.params['data']
    )

    result = dict(
        ping=module.params['data'],
    )

    assert expected != result
    assert expected == result

# Generated at 2022-06-11 07:38:04.881781
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-11 07:38:12.925526
# Unit test for function main
def test_main():
    # Test case #1: Test the response when ping returns a pong
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    test_module.exit_json = MagicMock()

    test_main()

    # Verify: If a pong is passed in, then the return data should be pong
    test_module.exit_json.assert_called_once_with(changed=False, ping='pong')

    # Test case #2: Test the response when ping returns crash
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    # Mock

# Generated at 2022-06-11 07:38:21.463764
# Unit test for function main
def test_main():
    import sys

# Generated at 2022-06-11 07:38:25.554610
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves.mock import MagicMock, patch
    module_mock = MagicMock(name='module')
    module_mock.params = {'data': 'pong'}
    main()
    main()

# Generated at 2022-06-11 07:38:28.052770
# Unit test for function main
def test_main():
    args = {'ping': 'pong'}
    result = main({'data': 'pong'})
    assert result['ping'] == args['ping']

# Generated at 2022-06-11 07:38:34.900025
# Unit test for function main
def test_main():
    # Mock function AnsibleModule with mocker fixture
    mocker.patch('ansible.module_utils.basic.AnsibleModule')
    main()
    # Assert that AnsibleModule was called with the arguments:
    # AnsibleModule.assert_called_with(
    #     argument_spec=dict(
    #         data=dict(type='str', default='pong'),
    #     ),
    #     supports_check_mode=True
    # )

# Generated at 2022-06-11 07:38:35.644943
# Unit test for function main
def test_main():
    '''
    Just import it
    '''
    assert True

# Generated at 2022-06-11 07:38:39.116963
# Unit test for function main
def test_main():
    # Mock out the module so we can test this function.
    class FakeModule(object):
        def __init__(self):
            self.params = {'data': 'pong'}
            self.exit_json = lambda **kwargs: None

    fake_module = FakeModule()

    main()

    assert fake_module.params['data'] == 'pong'


# Generated at 2022-06-11 07:38:44.445586
# Unit test for function main
def test_main():
    model = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    #data_test_1
    model.params['data'] = 'crash'
    try:
        main()
        assert False,"Exception should be raised"
    except Exception:
        assert True,"Exception raised"
    #data_test_2
    model.params['data'] = 'pong'
    main()


# Generated at 2022-06-11 07:38:51.081257
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={"data": {"type": "str", "default": "pong"}}, supports_check_mode=True)

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:38:51.840383
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 07:38:59.321708
# Unit test for function main
def test_main():
  module = AnsibleModule(
      argument_spec=dict(
          data=dict(type='str', default='pong')
      ),
      supports_check_mode=False
  )

  #json_input = module.json_from_basictest(input_data)
  #result = main(**json_input)
  result = main()
  #result = main()
  #assert result['invocation']['module_args']['data'] == 'pong'
  #assert result['ping'] == 'pong'
  print(result)

# Generated at 2022-06-11 07:39:20.692924
# Unit test for function main
def test_main():
    # import basic module
    from ansible.module_utils.basic import AnsibleModule

    # import common utils
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:39:24.154994
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = module.exit_json(**main())
    assert result == 'pong'

# Generated at 2022-06-11 07:39:31.931207
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0
    print('---- argument_spec ----')
    assert module.argument_spec == {'data': {'type': 'str', 'default': 'pong'}}
    print('---- supports_check_mode ----')
    assert module.supports_check_mode
    print('')


# Generated at 2022-06-11 07:39:35.872520
# Unit test for function main
def test_main():
    testmodule = AnsibleModule({
        "data": "testdata"
    })
    testmodule.exit_json = lambda *args, **kwargs: None
    testmodule.fail_json = lambda *args, **kwargs: None
    main()

# Generated at 2022-06-11 07:39:45.592260
# Unit test for function main
def test_main():
    from ansible import context
    from ansible.utils.vars import combine_vars

    context.CLIARGS = {}
    context.CLIARGS['_ansible_debug'] = False
    context.CLIARGS['_ansible_check_mode'] = False
    context.CLIARGS['_ansible_selinux_special_fs'] = [
        "fuse", "nfs", "vboxsf", "ramfs", "9p", "vfat"
    ]
    context.CLIARGS['_ansible_diff'] = False

    module_args = dict(data='pong')
    module_args = combine_vars(module_args, {})
    result = dict(ping='pong')

    assert main() == (result, False)

# Generated at 2022-06-11 07:39:53.783067
# Unit test for function main
def test_main():
    test_params = {'data': 'test'}
    test_args = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        params=test_params
    )
    test_module = AnsibleModule(**test_args)

    try:
        main()
    except SystemExit as e:
        assert e.code == 0

    assert test_module.exit_json.called
    # exit() is being called from within the main() function and so the result is not being returned to the test
    # but rather to sys.exit()
    # assert test_module.exit_json.call_args[0][0]['ping'] == 'test'



# Generated at 2022-06-11 07:40:01.028538
# Unit test for function main
def test_main():
    module_ = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module_.params['data'] = 'dummy'
    assert main() == module_.exit_json(**dict(ping='dummy'))
    # Test for exception handling
    # BUG: This doesn't work because main() is void function
    #module_.params['data'] = 'crash'
    #exception_raised_flag = False
    #try:
    #    main()
    #except Exception:
    #    exception_raised_flag = True
    #assert exception_raised_flag == True

# Generated at 2022-06-11 07:40:04.495631
# Unit test for function main
def test_main():
    data = dict(data='crash')
    result = dict(ping='crash')

    try:
        main()
        assert False
    except Exception as e:
        assert 'boom' in str(e)

    assert result == dict(ping=data['data'])

# Generated at 2022-06-11 07:40:10.110386
# Unit test for function main
def test_main():
    test_module = {
      "argument_spec": {
        "data": {
           "type": "str",
           "default": "pong"
        }
     },
     "supports_check_mode": "True"
    }
    test_module = AnsibleModule(**test_module)
    test_module.params = {"data" : "pong"}
    pong = test_module.params['data']
    result = dict(
        ping=test_module.params['data'],
    )
    assert result == test_module.exit_json(**result)


    

# Generated at 2022-06-11 07:40:11.804719
# Unit test for function main
def test_main():
    # Given
    module_args = dict(
        data=dict(type='str', default='pong'),
    )

    # When
    main()

    # Then
    assert False

# Generated at 2022-06-11 07:41:01.663839
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    for data in ('pong', 'crash'):
        with mock.patch.object(AnsibleModule, 'exit_json') as exit_json:
            with mock.patch.object(AnsibleModule, 'fail_json') as fail_json:
                if data == 'crash':
                    with pytest.raises(Exception) as exc_info:
                        with mock.patch.object(AnsibleModule, 'params') as params:
                            params.__getitem__.return_value = 'crash'
                            main()
                else:
                    with mock.patch.object(AnsibleModule, 'params') as params:
                        params.__getitem__.return_value = 'pong'
                        main()


# Ansible action snippets for unit testing

# Generated at 2022-06-11 07:41:10.461881
# Unit test for function main
def test_main():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    monkeypatch.setattr(AnsibleModule, '__init__', lambda self, *args, **kwargs: TestModule.__init__(self, **kwargs))

    monkeypatch.setattr(AnsibleModule, 'fail_json', lambda self, *args, **kwargs: TestModule.fail_json(self, *args, **kwargs))
   

# Generated at 2022-06-11 07:41:19.006529
# Unit test for function main
def test_main():
    import os
    import tempfile

    module_args = dict(
        data='pong',
        type='str',
        default='pong',
    )

    # Create a temporary file to write module args to
    handle, tmp_path = tempfile.mkstemp()

    # Generate argument string
    arg_string = "data_arg='{data}' type_arg='{type}' default_arg='{default}'".format(**module_args)

    # Write the arguments to the file
    with os.fdopen(handle, 'w') as handle:
        handle.write(arg_string)

    # Run main with the module arguments
    main(tmp_path)

# Generated at 2022-06-11 07:41:21.721996
# Unit test for function main
def test_main():
    # Test
    test = {'data': 'ping'}
    data = main(test)
    assert data == {'ping': 'ping'}


# Generated at 2022-06-11 07:41:22.295271
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:41:33.568868
# Unit test for function main
def test_main():
  with patch('ansible_module.AnsibleModule') as mock_ansible_module:
    mock_options_dict = {'data': 'pong'}
    mock_ansible_module.return_value.params = mock_options_dict

    # Initiate main function
    main()

# Generated at 2022-06-11 07:41:42.619060
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    try:
        main()
    except Exception as e:
        print(e)
    else:
        assert False, "should have raised exception"

# vim: set expandtab:ts=4:sw=4
"""

print(dedent(ansible_ping_py))
 
print('=== Cut Here ===')
 
 
ansible_win_ping_py = """
#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2012, Michael DeHaan <michael.dehaan@gmail.com>
# (c) 2016, Toshio Kuratomi <tkurat

# Generated at 2022-06-11 07:41:47.557988
# Unit test for function main
def test_main():
    test_args = {'data': 'crash'}
    _m = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    _m.params = test_args
    with pytest.raises(Exception) as excinfo:
        main()
    assert "boom" in str(excinfo.value)

# Generated at 2022-06-11 07:41:55.778497
# Unit test for function main
def test_main():
    class Args(object):
        def __init__(self,data):
            self.data = data
        @property
        def __dict__(self):
            return {'data': self.data}
    setattr(Args,'__contains__',lambda self, name:True)
    import StringIO

    output = StringIO.StringIO()
    class AnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode):
            pass
        def exit_json(self, data):
            output.write(str(data))
    am = AnsibleModule
    main(am(dict(), False), Args('pong'))
    assert(output.getvalue() == "{'ping': 'pong'}")

    output.truncate(0)

# Generated at 2022-06-11 07:41:59.959552
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:43:37.864023
# Unit test for function main
def test_main():

    # Unit test with default value of ping
    # Default value of ping should be "pong", so that is what we expect to get back
    data = dict(data="pong")
    result = main(data=data)
    assert result['ping'] == "pong"


# Generated at 2022-06-11 07:43:41.461361
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == None

# Generated at 2022-06-11 07:43:42.856233
# Unit test for function main
def test_main():
    module = {"params": {"data": "pong"}}
    main()
    assert(True)


# Generated at 2022-06-11 07:43:44.430600
# Unit test for function main
def test_main():
    result = main()
    print(result)

test_main()

# Generated at 2022-06-11 07:43:53.548508
# Unit test for function main
def test_main():
    '''
    Run tests for functions in module main
    '''
    test_main_args = {
        'data': {'type': 'str', 'default': 'pong'},
    }
    test_main_supports_check_mode = True
    log_result = []

    def fake_exit_json(*args, **kwargs):
        '''
        Fake exit_json with log_result
        '''
        log_result.append(kwargs)

    def fake_fail_json(*args, **kwargs):
        '''
        Fake fail_json with log_result
        '''
        log_result.append(kwargs)

    # Set up mock AnsibleModule object
    class fake_module(object):
        '''
        Mock AnsibleModule object
        '''

# Generated at 2022-06-11 07:43:56.017721
# Unit test for function main
def test_main():
    args = {
        'data': 'orchids'
    }
    result = {
        'ping': 'orchids'
    }
    assert main({'params': args}) == result

# Generated at 2022-06-11 07:44:02.387343
# Unit test for function main
def test_main():
    # Test module import
    mod_path = "ansible.builtin.ping"
    mod = load_module_from_file(mod_path, "./library")
    client = AnsibleAction(mod_path, DictClass())
    client.executor(mod, DictClass())
    print('---')
    # Test module args
    args = {'data': 'pong'}
    client = AnsibleAction(mod_path, DictClass())
    client.executor(mod, DictClass(args))
    print('---')
    # Test module args with a crash
    args = {'data': 'crash'}
    client = AnsibleAction(mod_path, DictClass())
    client.executor(mod, DictClass(args))
    print('---')
    # Test check mode
    args

# Generated at 2022-06-11 07:44:09.446239
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    results = Results()
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type = 'str', default = 'pong'),
        ),
        supports_check_mode = True
    )

    module.params = {
        'data': 'pong',
    }

    def exit_json(*args, **kwargs):
        results.success = args[0]['success']
        results.changed = True

    module.exit_json = exit_json

    main()
    assert results.success == True
    assert results.changed == True

# Class to store results during test

# Generated at 2022-06-11 07:44:14.665967
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:44:21.676149
# Unit test for function main
def test_main():
    # Setting up
    #   1) Create a valid AnsibleModule object
    #   2) Create an empty result dict
    #   3) Create an empty fake_result dict

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = { }
    fake_result = { }

    # Test with an invalid data parameter
    # Expected result: Error message from Ansible
    setattr(module.params, 'data', 'invalid_data_parameter')
    try:
        main()
        raise Exception("Module function main did not raise")
    except Exception as e:
        if "invalid_data_parameter" not in str(e):
            raise
        # In AnsibleModule
