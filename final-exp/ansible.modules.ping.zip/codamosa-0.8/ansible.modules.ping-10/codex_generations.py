

# Generated at 2022-06-11 07:36:08.860445
# Unit test for function main
def test_main():

    # Test with no arguments
    m = AnsibleModule(
        argument_spec=dict(data=dict(type='str', default='pong')),
        supports_check_mode=True
    )

    assert m.params['data'] == 'pong'

    # Test with argument data set to 'crash'
    m = AnsibleModule(
        argument_spec=dict(data=dict(type='str', default='crash')),
        supports_check_mode=True
    )

    assert m.params['data'] == 'crash'

# Generated at 2022-06-11 07:36:09.455789
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:36:12.731267
# Unit test for function main
def test_main():
    test_data = {"data":"test_data"}
    module = AnsibleModule(argument_spec={"data": {"type": "str", "default":"pong"}}, supports_check_mode=True)
    assert module.params == test_data
    assert module.check_mode == True

# Generated at 2022-06-11 07:36:21.477873
# Unit test for function main
def test_main():
    import mock
    import os
    import tempfile

    # Create a fake ansible module and copy module parameters
    # to the fake ansible module object
    module = mock.Mock()
    module.params = dict()
    module.params['data'] = None
    module.params['data'] = None
    try:
        os.unlink(tempfile.gettempdir() + os.sep + 'ansible_ping_payload')
    except OSError:
        pass
    try:
        os.unlink(tempfile.gettempdir() + os.sep + 'ansible_ping_payload.txt')
    except OSError:
        pass

    # Create a fake AnsibleModule and copy module input parameters
    # to the fake AnsibleModule object
    # This will populate the module.params dictionary
   

# Generated at 2022-06-11 07:36:26.317835
# Unit test for function main
def test_main():
    # Test
    module = AnsibleModule(
        argument_spec = dict(
            data = dict( type = 'str', default = 'pong' )
        )
    )
    result = dict(
        ping = module.params[ 'data' ]
    )

    module.exit_json( **result )

# Generated at 2022-06-11 07:36:35.158913
# Unit test for function main
def test_main():
    # deserialize arguments from JSON
    args = json.loads(input)
    # call function main
    result = main(args)
    # serialize resut to JSON
    output = json.dumps(result)
    # output result
    print(output)
'''

PYTHON_SCRIPT_TEMPLATE = '''
#!/usr/bin/python

# (c) 2012, Michael DeHaan <michael.dehaan@gmail.com>
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it

# Generated at 2022-06-11 07:36:46.867685
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    import sys

    test_module = AnsibleModule({
        'data': {'type': 'str', 'default': 'pong'},
    }, supports_check_mode=True)
    test_module.exit_json = exit_json
    test_module.fail_json = fail_json

    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    # Execute actual function (and catch exception)
    backup = sys.stdout
    backup2 = sys.stderr
    sys.stdout = mystdout = StringIO()
    sys.stderr = mystderr

# Generated at 2022-06-11 07:36:47.852927
# Unit test for function main
def test_main():
  assert main() is not None

# Generated at 2022-06-11 07:36:50.265705
# Unit test for function main
def test_main():
    from ansible.modules.network.ntp import main

    test_dict = dict(
        data='pong',
    )

    x = main()
    assert x == test_dict

# Generated at 2022-06-11 07:36:57.080631
# Unit test for function main
def test_main():
    # Get a random port for a listening tcp4 socket
    # for testing with the ping module 
    import socket, random, threading
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("",0))
    port = s.getsockname()[1]
    s.close()
    del s

    # Listener thread
    def listener():
        import SocketServer
        class MyTCPHandler(SocketServer.BaseRequestHandler):
            def handle(self):
                self.request.sendall('pong')
        server = SocketServer.TCPServer(("", port), MyTCPHandler)
        server.serve_forever()

    # Start the listener thread and set the shutdown flag
    # to kill the listener thread.

# Generated at 2022-06-11 07:37:10.756799
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.jsoncompat import json

    def get_main_obj(params):
        return main()

    def do_main(params, check_mode=False):

        # Set up argument spec
        argument_spec = dict(
            data=dict(type='str', default='pong'),
        )

        # Create the module
        module = AnsibleModule(argument_spec=argument_spec,
                               supports_check_mode=check_mode)

        # Actually execute the module
        result = dict(
            ping=module.params['data'],
        )

        module.exit_json(**result)

    # Example params

# Generated at 2022-06-11 07:37:19.302237
# Unit test for function main
def test_main():
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    )
    first_result = dict(
        ping="pong",
    )
    second_result = dict(
        ping="crash",
    )
    # Test case with default parameters and default data
    test_module = AnsibleModule(argument_spec=argument_spec)
    test_module.exit_json(**first_result)
    # Test case with different data
    test_module = AnsibleModule(argument_spec=argument_spec)
    test_module.params["data"] = "crash"
    test_module.exit_json(**second_result)

# Generated at 2022-06-11 07:37:25.080910
# Unit test for function main
def test_main():
    p = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert test_main() == module.exit_json(**result)

# Generated at 2022-06-11 07:37:26.311695
# Unit test for function main
def test_main():
    assert main() is not None

# Generated at 2022-06-11 07:37:34.935692
# Unit test for function main
def test_main():
    test_data = dict(
        data = dict(type='str', default='pong'),
    )
    assert test_data['data'] == 'pong'
    assert test_data['data'] == dict(type='str', default='pong')['data']
    assert test_data['data'] == dict(data=dict(type='str', default='pong'))['data']
    assert test_data['data'] == dict(data=dict(type='str', default='pong'))['data']['data']
    assert test_data['data'] == dict(data=dict(type='str', default='pong'))['data']['data']['data']

# Generated at 2022-06-11 07:37:38.202327
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
        )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-11 07:37:44.104292
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    testmodule = basic.AnsibleModule(
        argument_spec=dict(
            data=dict(required=False, default='pong'),
        ),
        supports_check_mode=True
    )

    testmodule.exit_json(**test_main.__wrapped__(testmodule))

test_main.__wrapped__ = main

# Generated at 2022-06-11 07:37:54.056772
# Unit test for function main
def test_main():
    # Create a module mock
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Assert the module fail_json method is called
    module.fail_json = MagicMock(return_value=None)

    # Assert the module exit_json method is called
    module.exit_json = MagicMock(return_value=None)

    # Check if the module's exit_json was called
    def mock_exit_json(status, result):
        if status == 'success':
            if result == {'ping': 'pong'}:
                return True
            else:
                return False
        else:
            return False

    module.exit_json = mock_exit_json

    # Check

# Generated at 2022-06-11 07:37:58.379691
# Unit test for function main
def test_main():
    test_spec = dict(
        data=dict(type='str', default='pong')
    )

    module = AnsibleModule(argument_spec=test_spec, supports_check_mode=True)
    try:
        module.params['data'] = 'crash'
        assert main() != 0
    except Exception as e:
        assert e.message == 'boom'

# Generated at 2022-06-11 07:38:01.019497
# Unit test for function main
def test_main():
    # Example test case with multiple asserts
    assert main() == "Success"

# Generated at 2022-06-11 07:38:14.642129
# Unit test for function main
def test_main():
   module = AnsibleModule(
       argument_spec=dict(
           data=dict(type='str', default='pong'),
       ),
       supports_check_mode=True
   )

   if module.params['data'] == 'crash':
       raise Exception("boom")

   result = dict(
       ping=module.params['data'],
   )

   module.exit_json(**result)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:38:22.146091
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:38:25.985283
# Unit test for function main
def test_main():
    from mock import patch

    with patch.object(AnsibleModule, 'exit_json') as mock:
        main()
        assert mock.called
        assert mock.call_args[0][0]['ping'] == 'pong'

# Generated at 2022-06-11 07:38:30.151027
# Unit test for function main
def test_main():
    # Do not use a test of ansible.module_utils.basic.AnsibleModule().
    # This is so that the module can be imported without being run.
    import ansible.modules.system.ping

    assert ansible.modules.system.ping.main() == None

# Generated at 2022-06-11 07:38:33.096332
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)
    assert(main() == 'ping')

# Generated at 2022-06-11 07:38:37.042159
# Unit test for function main
def test_main():
    test_var = {'data': 'pong'}
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()
    # Test with valid arguments
    with pytest.raises(SystemExit):
        main(test_var)

# Generated at 2022-06-11 07:38:38.332826
# Unit test for function main
def test_main():
    data = main("ping: data")
    assert data == "ping: data"

# Generated at 2022-06-11 07:38:43.244754
# Unit test for function main
def test_main():
    class TestArgs(object):
        module_args = dict(
            data=dict(type='str', default='pong'),
        )
        supports_check_mode = True
        check_mode = False
        diff = False
    args = TestArgs()
    assert args.module_args['data'] == 'pong'
    assert args.supports_check_mode
    assert not args.check_mode
    assert not args.diff

# Generated at 2022-06-11 07:38:51.587419
# Unit test for function main
def test_main():
    import pytest

    dummy_module = pytest.Mock()
    dummy_module.params = {}

    dummy_module.fail_json.mock_returns(None)
    dummy_module.exit_json.mock_returns(None)

    main()
    dummy_module.exit_json.assert_called_once_with(ping='pong')

    dummy_module.params['data'] = 'crash'
    with pytest.raises(Exception) as excinfo:
        main()
    assert "boom" in str(excinfo.value)

# Generated at 2022-06-11 07:38:52.292416
# Unit test for function main
def test_main():
    test_main()

# Generated at 2022-06-11 07:39:17.105447
# Unit test for function main
def test_main():
    # Mock function call
    class AnsibleModuleMock(object):
        def __init__(self, **kw):
            self.params = kw['argument_spec']
            
        def exit_json(self, **kw):
            # Asserting on mocked function call
            assert kw['ping'] == 'pong'
            
    def test():
        # Create object of class AnsibleModule
        obj = AnsibleModuleMock(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
        )
        
        # Call main function
        main(obj)
        
    test()
    

# Generated at 2022-06-11 07:39:19.297900
# Unit test for function main
def test_main():
    test_args = {
        u"data": "crash",
    }
    import pytest
    assert pytest.fail("Unit tests for function main not implemented")

# Generated at 2022-06-11 07:39:29.790970
# Unit test for function main
def test_main():
    import os
    import sys
    import shlex
    import argparse
    import StringIO

    os.environ['ANSIBLE_MODULE_ARGS'] = "{'data': 'crash'}"
    my_args = dict(ANSIBLE_MODULE_ARGS=os.environ['ANSIBLE_MODULE_ARGS'])
    test_args = dict([(k, v) for (k, v) in my_args.iteritems() if v is not None])
    args = argparse.Namespace(**test_args)

    stderr = StringIO.StringIO()
    sys.stderr = stderr

    try:
        main()
    except SystemExit as e:
        assert e.code == 1

# Generated at 2022-06-11 07:39:32.538190
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as excinfo:
        main([])
    assert str(excinfo.value) == 'boom'


# Generated at 2022-06-11 07:39:37.827723
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:39:47.286362
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import json
    import sys
    import pytest

    args = {'data': 'pong', 'ANSIBLE_MODULE_ARGS': {'data': 'pong'}}
    sys.stdout = StringIO()
    main()
    result = to_bytes(sys.stdout.getvalue())
    sys.stdout = sys.__stdout__
    assert json.loads(result) == ImmutableDict({"ping": "pong", "changed": False})

    args = {'data': 'crash', 'ANSIBLE_MODULE_ARGS': {'data': 'crash'}}

# Generated at 2022-06-11 07:39:51.547554
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:40:00.023395
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible_collections.ansible.builtin.tests.unit.compat.mock as mock
    import sys

    class Args(object):
        pass

    args = Args()
    args.params = ImmutableDict(data='pong')
    args.setdefault = mock.Mock()
    args.setdefault.side_effect = args.__setitem__
    args.__getitem__ = lambda self, key: {'data': 'pong'}[key]
    args.get = lambda self, key, default=None: {'data': 'pong'}.get(key, default)

    orig_sys_argv = sys.argv

# Generated at 2022-06-11 07:40:00.529770
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:40:08.744209
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json
    import pytest
    import sys

    exc_info = None

    m_ansible = pytest.Mock()
    m_ansible.Module.return_value = m_ansible.module
    m_ansible.module.params = {'data': 'test_data'}
    m_ansible.module.exit_json.side_effect = lambda **kargs: sys.exit(0)

    m_open = pytest.Mock(return_value=1)

    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 0


# Generated at 2022-06-11 07:40:50.399726
# Unit test for function main
def test_main():
    assert 1


# Generated at 2022-06-11 07:41:00.315498
# Unit test for function main
def test_main():
    # Setup the test environment
    ansible_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Setup the result object and the module return value
    result = dict(
        ping=ansible_module.params['data'],
    )
    ansible_module.exit_json(**result)

    # Test exception handling
    ansible_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-11 07:41:09.773407
# Unit test for function main
def test_main():
    import mock
    import collections

    module = mock.MagicMock()
    module.params = collections.defaultdict(lambda: 'default')

    module.exit_json.side_effect = Exception('exit_json was called')
    # Test module.params['data'] == 'crash' raises an exception
    module.params['data'] = 'crash'
    try:
        main()
    except Exception as e:
        assert e.args[0] == 'exit_json was called'

    # Test module.params['data'] == 'foo' goes down the try/except
    module.params['data'] = 'foo'
    try:
        main()
    except Exception as e:
        assert e.args[0] == 'exit_json was called'

    # Test module.params['data'] == 'default' goes down the try/

# Generated at 2022-06-11 07:41:19.541751
# Unit test for function main
def test_main():
    ''' Unit test for function main '''
    # You can always test your code by eliminating C(common.py) from your solution. All the common functions
    # will be imported from ansible.module_utils.basic directly.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExitModule
    # You import the module here and mock the AnsibleModule. The AnsibleModule class is defined in
    # ansible.module_utils.basic, it is a class to help mock modules. It's instance has the following attributes:
    #
    # 1. params -- The dictionary contains arguments passed by user. For example, `ansible.builtin.ping`,

# Generated at 2022-06-11 07:41:22.629452
# Unit test for function main
def test_main():
    test_module = AnsibleModule({'data': 'pong'}, None)
    try:
        test_module.exit_json(ping='pong')
    except Exception as e:
        assert False


# Generated at 2022-06-11 07:41:25.770052
# Unit test for function main
def test_main():
    from ansible_collections.ansible.builtin.tests.unit.modules.network import test_ping

    with pytest.raises(Exception):
        test_ping.main()


# Generated at 2022-06-11 07:41:32.929259
# Unit test for function main
def test_main():
    print("Testing function main")

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

test_main()

# Generated at 2022-06-11 07:41:37.811474
# Unit test for function main
def test_main():
    mock_module = MagicMock(name='AnsibleModule')
    mock_module.params = {'data': 'pong'}
    mock_module.check_mode = True
    mock_module.exit_json = MagicMock(return_value=None, name='exit_json')
    assert main() == mock_module.exit_json.return_value


# Generated at 2022-06-11 07:41:44.302324
# Unit test for function main
def test_main():
    # Mock module for testing
    class Module:
        def __init__(self):
            class ModuleResult:
                def __init__(self):
                    self.exit_json = None
                    self.fail_json = None
            self.params = {}
            self.check_mode = True
            self.result = ModuleResult()
    module_obj = Module()
    module_obj.params['data'] = 'ping'
    main()
    # Check result
    assert module_obj.result.exit_json['ping'] == 'ping'

    # Mock module for testing
    class Module2:
        def __init__(self):
            class ModuleResult:
                def __init__(self):
                    self.exit_json = None
                    self.fail_json = None
            self.params = {}
            self.check_mode = True

# Generated at 2022-06-11 07:41:44.788306
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:43:17.311466
# Unit test for function main
def test_main():
    assert True is True


# Generated at 2022-06-11 07:43:28.534854
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule,'exit_json') as mock_exit_json:
        ansible_module = mock.Mock()
        ansible_module.params = {'data': 'crash'}
        main()
        mock_exit_json.assert_called_once()

# Generated at 2022-06-11 07:43:35.883405
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import json

    myargs = dict(
        data='pong',
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    output = '{"ping": "pong"}'

    assert(output == to_bytes(module.exit_json(**result)))



# Generated at 2022-06-11 07:43:39.286845
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.plugins.modules.ping import main

    assert main() is None
    main()
    main()

# Generated at 2022-06-11 07:43:48.707438
# Unit test for function main
def test_main():
    import sys
    import os
    import subprocess

    if not os.path.exists("tests/ansible_module_ping.py"):
        raise Exception("ansible_module_ping.py not found")
    if not os.path.exists("tests/ping.yaml"):
        raise Exception("ping.yaml not found")
    if not os.path.exists("tests/ping_crash.yaml"):
        raise Exception("ping_crash.yaml not found")

    p = subprocess.Popen([sys.executable, "tests/ansible_module_ping.py", "tests/ping.yaml"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (out, err) = p.communicate()

# Generated at 2022-06-11 07:43:57.536849
# Unit test for function main
def test_main():
    from StringIO import StringIO
    from ansible.module_utils import basic
    import sys

    output = StringIO()
    sys.stdout = output
    a = basic.AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
            )
    class A:
        def __init__(self):
            self.params=dict()
            self.params['data']='pong'
        def exit_json(self, changed=False, **kwargs):
            print("in exit_json")
            print(kwargs)

    a.params = A()
    main()
    sys.stdout = sys.__stdout__
    print("output is:")
    print(output.getvalue())

# Generated at 2022-06-11 07:44:01.319930
# Unit test for function main
def test_main():
    test_main.args = {'data': 'pong'}
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=test_main.args, supports_check_mode=True)
    module.params['data'] = 'pong'
    result = dict(ping='pong')
    assert (result == main())

# Generated at 2022-06-11 07:44:09.520664
# Unit test for function main
def test_main():
    # Partially mock the module so we can control some of the params
    with patch.object(AnsibleModule, '__init__', lambda self, argument_spec, supports_check_mode=False: None):
        module = AnsibleModule
        module._verbosity = False
        module.exit_json = lambda **kwargs: kwargs
        module.params = dict(data='pong')

        assert module.exit_json(**main())['ping'] == 'pong'
        module.params = dict(data='crash')
        with pytest.raises(Exception) as exec_info:
            main()
        assert 'boom' in str(exec_info.value)



# Generated at 2022-06-11 07:44:15.327371
# Unit test for function main
def test_main():
    # import ansible.modules.system.ping.main as ping_main
    # import json
    # module_args = {'data': 'crash'}
    # module = AnsibleModule(
    #     argument_spec=dict(
    #         data=dict(type='str', default='pong'),
    #     ),
    # )
    # result = ping_main.main()
    # assert result == 'pong'
    assert True, "Unit test not implemented"

# Generated at 2022-06-11 07:44:18.358515
# Unit test for function main
def test_main():
    data = {"data": "crash"}
    try:
        main()
    except Exception as e:
        assert (e.args[0] == "boom")
        assert True
    data = {"data": "pong"}
    try:
        main()
    except Exception as e:
        assert False
        assert True