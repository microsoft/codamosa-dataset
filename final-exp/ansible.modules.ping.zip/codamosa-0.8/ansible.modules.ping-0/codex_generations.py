

# Generated at 2022-06-11 07:36:01.840886
# Unit test for function main
def test_main():
    test_dict = {"data":"crash"}
    with pytest.raises(Exception, message="boom"):
        main()


# Generated at 2022-06-11 07:36:04.989208
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:36:11.644097
# Unit test for function main
def test_main():
    yaml_dump = {'ping': 'pong'}
    yaml_args = {'data':'pong'}
    yaml_results = {'json': yaml_dump}
    yaml_inargs = []
    yaml_expargs = []
    cmd = AnsibleModule(argument_spec={})
    m_run_command = cmd.run_command
    cmd.run_command = lambda *args, **kwargs: (0, '', '')
    m_run_command.assert_called_with(*yaml_inargs, **yaml_expargs)

# Generated at 2022-06-11 07:36:13.157717
# Unit test for function main
def test_main():
    with pytest.raises(Exception, match="boom"):
        main()
# end unit test

# Generated at 2022-06-11 07:36:14.379712
# Unit test for function main
def test_main():
    result = main()
    # Assert with expected results
    assert result == 'pong'

# Generated at 2022-06-11 07:36:17.766979
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = args
    assert main() == module.exit_json(**dict(
        ping='pong',
    ))

# Generated at 2022-06-11 07:36:18.623558
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-11 07:36:28.312488
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import _load_params
    import json

    import sys
    sys.argv.append('-vvvv')
    # test_module.params['data'] == 'crash'
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        check_invalid_arguments=False,
        bypass_checks=True
    )
    test_module.params['data'] = 'crash'
    main()
    # test_module.params['data'] == 0

# Generated at 2022-06-11 07:36:29.750318
# Unit test for function main
def test_main():
    assert main() == dict(
        ping=module.params['data'],
    )


# Generated at 2022-06-11 07:36:30.331716
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:36:35.747218
# Unit test for function main
def test_main():
    ping_data = 'pong'
    assert main() == "ping"

# Generated at 2022-06-11 07:36:46.663346
# Unit test for function main
def test_main():
    import sys
    # Load up our module

    # Pre-set values for unit tests
    # Define our parameters
    params = {
        'data': 'foo'
    }

    # Set up the module
    module = AnsibleModule(
        argument_spec = params
    )

    # Set up our module
    module.fail_json = {}
    module.fail_json['msg'] = ""
    module.exit_json = {}
    module.exit_json['ping'] = 'foo'

    # Run the unit test
    main()
    print("Exit JSON: ", module.exit_json)
    print("Fail JSON: ", module.fail_json)
    assert module.exit_json['ping'] == 'foo'

# Generated at 2022-06-11 07:36:51.545575
# Unit test for function main
def test_main():
    data = dict(
        data='pong'
    )
    result = dict(
        ping=data['data']
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = data
    result = main()
    assert result == result

# Generated at 2022-06-11 07:36:57.441456
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type='str', default='pong'),
        ),
        supports_check_mode = True
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping = module.params['data'],
    )

    assert result == dict(ping='pong')

# Generated at 2022-06-11 07:37:02.776283
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    argument_spec = dict(
            data=dict(type='str', default='pong'),
        )
    module = AnsibleModule(
        argument_spec=argument_spec
    )
    response = [
        {'ping': 'pong'}
    ]
    module.exit_json(**response[0])

# Generated at 2022-06-11 07:37:03.400629
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-11 07:37:07.414541
# Unit test for function main
def test_main():
    from random import choice
    from string import ascii_letters

    # Generate some random data
    for _ in range(50):
        args = {'data': ''.join(choice(ascii_letters) for _ in range(50))}
    module = AnsibleModule(**args)
    assert args['data'] == main().get('ping')

# Generated at 2022-06-11 07:37:07.978116
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 07:37:09.319637
# Unit test for function main
def test_main():
    module = FakeModule()
    main()
    assert module.exit_json.called

# Generated at 2022-06-11 07:37:09.881876
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 07:37:23.105061
# Unit test for function main
def test_main():
    """ Tests the main() function. """
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type='str', default='pong'),
        ),
        supports_check_mode = True
    )
    result = dict(
        ping = module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-11 07:37:26.889070
# Unit test for function main
def test_main():
    test_args = []
    args = AnsibleModule.parse_args(test_args)
    rc,result = main(args)
    assert rc == 0
    assert result.get('changed') is False

# Generated at 2022-06-11 07:37:27.494125
# Unit test for function main
def test_main():
  assert True

# Generated at 2022-06-11 07:37:31.584789
# Unit test for function main
def test_main():
    args = {
        'data': 'test',
    }

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )

    result = main()
    assert result['ping'] == 'test'

# Generated at 2022-06-11 07:37:34.718566
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    main()
    assert True

# Generated at 2022-06-11 07:37:35.640601
# Unit test for function main
def test_main():
    # test return value with different input values
    pass

# Generated at 2022-06-11 07:37:40.344967
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    assert True

# Generated at 2022-06-11 07:37:41.632998
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-11 07:37:49.720829
# Unit test for function main
def test_main():
    import pytest
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    with pytest.raises(Exception) as execinfo:
        module.params['data'] = 'crash'
        main()
    assert "boom" in str(execinfo.value)
    module.params['data'] = 'pong'
    result = dict(
        ping=module.params['data'],
    )
    main()
    return True

# Generated at 2022-06-11 07:37:53.172614
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert test_module.params['data'] == 'pong'

# Generated at 2022-06-11 07:38:12.123347
# Unit test for function main
def test_main():
    args = dict(
        data="pong"
    )
    result = dict(
        ping="pong",
    )
    ping = main
    assert ping(args) == result

# Generated at 2022-06-11 07:38:13.177817
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-11 07:38:24.076840
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule, is_logged

    def _count_logging_calls(logger):
        if hasattr(logger, '_records'):
            return len(logger._records)
        return 0

    # Test verbose operation
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
            _ansible_debug=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        check_invalid_arguments=False,
    )

    debug_logger = module._logger
    assert debug_logger is not None

    # Test no log and log depending on verbose state
    debug_logger.debug('test1')


# Generated at 2022-06-11 07:38:26.198564
# Unit test for function main
def test_main():
    result = dict(
        ping='pong',
    )
    assert main() == result


# Generated at 2022-06-11 07:38:36.433661
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    # Test module arguments
    arguments = dict(
        data=dict(
            type='str',
            required=False,
            choices=None,
            default='pong'
        ),
    )
    # Test state
    state = dict(
        ping='pong',
    )
    # Run module
    module_args = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module = AnsibleModule(**module_args)
    # Test module run
    result = dict(
     ping='pong',
    )
    assert result == module.run()

# Generated at 2022-06-11 07:38:38.019545
# Unit test for function main
def test_main():
    params = {'data':'crash'}
    rc, out, err = module_execute(params)
    assert rc == 1

# Generated at 2022-06-11 07:38:39.013518
# Unit test for function main
def test_main():
    print("Entering test_main")

# Generated at 2022-06-11 07:38:45.860604
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleModule

    import os
    import sys
    import json

    # python2 and python3 compatible
    if sys.hexversion >= 0x3040000:
        from io import StringIO
    else:
        from cStringIO import StringIO

    if not os.path.exists('.result'):
        os.mkdir('.result')

    # case 1
    result = StringIO()
    sys.stdout = result

# Generated at 2022-06-11 07:38:53.311066
# Unit test for function main
def test_main():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = dict(data="test")
    test_module.exit_json = lambda x: sys.exit(0)
    test_module.fail_json = lambda x: sys.exit(0)
    print("ANSIBLE_MODULE_ARGS=%s" % (test_module.params))
    main()
    return

if __name__ == '__main__':
    # Unit testing of this module
    test_main()

# Generated at 2022-06-11 07:39:03.902319
# Unit test for function main
def test_main():
    from ansible.modules.network.ping import main

    # Test with no params
    module = AnsibleModule({
        'data': {'type': 'str', 'default': 'pong'}
    }, supports_check_mode=True)
    result = {
        'changed': False,
        'ping': module.params['data'],
    }
    main(module)
    assert module.exit_json.call_args.kwargs == result

    # Test with data=crash
    module = AnsibleModule({
        'data': {'type': 'str', 'default': 'crash'}
    }, supports_check_mode=True)
    main(module)
    assert module.fail_json.call_args.kwargs == {"msg": "boom"}

# Generated at 2022-06-11 07:39:43.174130
# Unit test for function main
def test_main():
    module_args = dict(
        data=dict("pong"),
    )
    module_args_new = dict(
        data=dict("boom"),
    )
    result = dict(
        ping=module_args["data"],
    )
    result_new = dict(
        ping=module_args_new["data"],
    )
    assert(module_args == result)
    assert_not(module_args_new == result)

# Generated at 2022-06-11 07:39:51.148774
# Unit test for function main
def test_main():
    # Unit test for function main with no parameters
    def test_main_no_params():
        assert main() == 0

    # Unit test for function main with no parameters that simulates a crash
    def test_main_no_params_crash():
        import builtins
        builtins.module.params = dict(data='crash')
        assert builtins.main() == 0

    # Unit test for function main with parameters
    def test_main_with_params():
        assert main() == 0

    # Unit test for function main with parameters that simulates a crash
    def test_main_with_params_crash():
        import builtins
        builtins.module.params = dict(data='crash')
        assert builtins.main() == 0

# Generated at 2022-06-11 07:39:56.829307
# Unit test for function main
def test_main():
    f = open('/tmp/ansible_ping_payload', 'w')
    f.write('''{
    "changed": false,
    "ping": "pong"
}''')
    f.close()

    main()

    f = open('/tmp/ansible_ping_payload', 'r')
    assert(f.read() == '{"changed": false, "invocation": {"module_args": {"data": "pong"}}, "ping": "pong"}')


# Generated at 2022-06-11 07:40:00.675397
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule({"data":"crash"}, {"data":"crash"}, check_invalid_arguments=False)
    try:
        main()
    except Exception as e:
        assert e.message == "boom"
        mod.exit_json(changed=False, ping="pong")

# Generated at 2022-06-11 07:40:01.782772
# Unit test for function main
def test_main():
    print('Test for function main')



# Generated at 2022-06-11 07:40:05.627747
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-11 07:40:12.486198
# Unit test for function main
def test_main():

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = False

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True

        def check_mode(self):
            return self.params['_ansible_check_mode']

    results = dict(ping='pong')

    module = TestModule(params=dict(
        data='pong',
        _ansible_check_mode=False,
    ))

    try:
        main()
    except Exception:
        raise AssertionError('An exception was raised when it should not have been')

   

# Generated at 2022-06-11 07:40:21.598912
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import basic
    import platform

    def create_fake_module(data):
        """
        Create a fake AnsibleModule object
        :param data: Data to pass to the module (i.e. the 'checkmode' parameter)
        :return: Fake AnsibleModule object
        """

        sys_platform = platform.system()

        checkmode_param = dict(
            dict(name='check_mode', default=False),
        )

        argument_spec = dict(
            dict(argument_spec='', check_invalid_arguments=True, mutually_exclusive=[], required_together=[]),
            data=dict(type='str', default='pong')
        )

        module_args = 'data=' + data


# Generated at 2022-06-11 07:40:29.872584
# Unit test for function main
def test_main():
    # Testing the following call:
    # main()

    # Module parameters and responses
    module_params = dict(
        data=dict(type='str', default='pong'),
    )

    module_result = dict(
        ping=mock.MagicMock(return_value=dict(
            type='str',
            default='pong',
        )),
    )

    # Call the function
    # ansible.module_utils.basic.AnsibleModule.exit_json()
    ansible.module_utils.basic.AnsibleModule.exit_json(
        data=mock.MagicMock(return_value=dict(
            ping=dict(
                type='str',
                default='pong',
            ),
        )),
        changed=True,
    )

    # Call the function
    # ans

# Generated at 2022-06-11 07:40:34.080709
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-11 07:41:51.586220
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as m1, patch('ansible.module_utils.basic.AnsibleModule') as m2:
        m = m2.return_value
        m.params = {'data': 'pong'}
        main()
        m1.assert_called_with(changed=False, ping='pong')

    with patch.object(AnsibleModule, 'exit_json') as m1, patch('ansible.module_utils.basic.AnsibleModule') as m2:
        m = m2.return_value
        m.params = {'data': 'crash'}
        with pytest.raises(Exception, match='boom'):
            main()
        m1.assert_not_called()

# Generated at 2022-06-11 07:41:56.685525
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data']
    )

    module.exit_json(**result)

# vim: set et sts=4 ts=4 sw=4 ft=python:

# Generated at 2022-06-11 07:42:00.477042
# Unit test for function main
def test_main():
    class module_mock(dict):
        def __init__(self, module_name, **kwargs):
            self.params = kwargs
            self.params['module_name'] = module_name
        def exit_json(self, **kwargs):
            return kwargs

    module = module_mock('ansible.builtin.ping', data='pong')
    result = main(module)
    assert result['ping'] == 'pong'

# Generated at 2022-06-11 07:42:04.600913
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data']
    )
    module.exit_json(changed=False, ping='pong')

test_main()

# Generated at 2022-06-11 07:42:07.353396
# Unit test for function main
def test_main():
    print(main())

import collections
import json
import os
import pprint
import sys
import yaml

from ansible.compat.tests import unittest
from ansible.compat.tests.mock import patch
from ansible.module_utils import basic
from ansible.module_utils._text import to_bytes

BASIC_CONTENT = '{"basic": "content"}'


# Class to handle basic AnsibleModule tests.

# Generated at 2022-06-11 07:42:10.124733
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'


# Generated at 2022-06-11 07:42:10.545981
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:42:18.761798
# Unit test for function main
def test_main():
    def test_ansible_module(module_name, module_args, expected, check_invalid_arguments=None,
                            debug_str=None, fail_on_diff=True, no_log=False,
                            verbose=False, connection=None, timeout=60,
                            force_handlers=False, module_vars=None):
        # test_ansible_module is a stub function to test ping module
        print('test_ansible_module mock function called')
        print(' - module_name: ' + module_name)
        print(' - module_args: ' + module_args)
        print(' - expected: ' + expected)
        print(' - check_invalid_arguments: ' + check_invalid_arguments)
        print(' - debug_str: ' + debug_str)

# Generated at 2022-06-11 07:42:19.100915
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-11 07:42:19.901539
# Unit test for function main
def test_main():
    print("test_main")



# Generated at 2022-06-11 07:45:31.604869
# Unit test for function main
def test_main():
    fixture = dict(
        data = 'crash'
    )

    # validate the parameters
    assert fixture['data'] == 'crash'

    # test our main function
    main()

# Generated at 2022-06-11 07:45:36.091813
# Unit test for function main
def test_main():
    # create the module object
    module = AnsibleModule(
        dict(
            data=dict(type='str', default='pong'),
        )
    )

    result = dict(
        changed=False,
        ping="pong",
    )
    assert module.exit_json.call_args_list == [call(**result)]



# Generated at 2022-06-11 07:45:40.623547
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    args = {}
    args['data'] = 'pong'

    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    m.params = args
    main()
    assert m.params['data'] == 'pong'

# Generated at 2022-06-11 07:45:45.601960
# Unit test for function main
def test_main():
    with patch('ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule') as mock_module:
        with patch('ansible_collections.ansible.builtin.plugins.modules.ping.main') as mock_main:
            module = mock_module.return_value
            module.params['data'] = 'pong'
            main()
            mock_main.assert_called_once()

# Generated at 2022-06-11 07:45:54.571964
# Unit test for function main
def test_main():
    # Setup test environment
    import os
    test_var_dir = 'TEST_ANSIBLE_VAR_PLACEHOLDER'