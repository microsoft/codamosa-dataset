

# Generated at 2022-06-20 22:14:23.491590
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with arguments
    args = dict(
        data='mytestdata'
    )
    result = main(args)
    assert result['ping'] == 'mytestdata'

    # Test with crash
    args = dict(
        data='crash'
    )
    with py.test.raises(Exception) as excinfo:
        main(args)

    assert str(excinfo.value) == 'boom'

# Generated at 2022-06-20 22:14:23.952726
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:14:25.591761
# Unit test for function main
def test_main():
    print('Testing main function')
    try:
        main()
    except SystemExit:
        print('Failure')
    else:
        print('Success')

# Generated at 2022-06-20 22:14:33.386385
# Unit test for function main
def test_main():
    from mock import patch

    # Helpers
    def do_patch(from_what, to_what, **kwargs):
        def patch_it(from_what, to_what):
            patcher = patch(from_what, to_what)
            return patcher.start(), patcher.stop

        started = []
        stopped = []
        try:
            for target in from_what:
                start, stop = patch_it(target, to_what)
                started.append(start)
                stopped.append(stop)
            yield started, stopped
        finally:
            for s in stopped:
                s()

    # Content

# Generated at 2022-06-20 22:14:41.312301
# Unit test for function main
def test_main():
    module = MockAnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        ),
        supports_check_mode=True
    )
    module.exit_json = Mock()

    with pytest.raises(Exception):
        main()

    result = dict(
        ping=module.params['data']
    )

    assert module.exit_json.call_count == 1
    args, kwargs = module.exit_json.call_args
    assert args == ()
    assert kwargs == result

# Generated at 2022-06-20 22:14:50.136501
# Unit test for function main
def test_main():
    # An example unit test
    module_args = dict(
        data='pong',
    )
    result = dict(
        changed=False,
        ping='pong',
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    assert main() == module.exit_json(**result)
    # An example unit test that causes an exception
    module_args = dict(
        data='crash',
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    try:
        assert main()
    except Exception:
        pass

# Generated at 2022-06-20 22:14:54.928798
# Unit test for function main
def test_main():
    from ansible.modules.core import ping

    with mock.patch.object(ping.AnsibleModule, 'exit_json', return_value=None) as exit_json:
        with mock.patch.object(ping.AnsibleModule, 'params', return_value=dict(data='pong')):
            ping.main()
            assert exit_json.called


# Generated at 2022-06-20 22:15:01.822204
# Unit test for function main
def test_main():
    argv = ["ping.py", "-a", "data=crash"]
    assert main()[0] == 255
    assert main()[2] == "boom"

    argv = ["ping.py", "data=pong"]
    assert main()[0] == 0
    assert main()[1]["ping"] == "pong"

# Generated at 2022-06-20 22:15:02.454534
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-20 22:15:03.403498
# Unit test for function main
def test_main():
    assert(main() == None)

# Generated at 2022-06-20 22:15:11.724949
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str'),
        ),
    )
    module.params['data'] = 'pong'
    result = dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-20 22:15:14.065953
# Unit test for function main
def test_main():
    args = {
        'data': 'pong',
    }
    result = main()

    assert result.get('ping') == args.get('data')

# Generated at 2022-06-20 22:15:21.190820
# Unit test for function main
def test_main():
    # Use the builtin function open to mock a file since this is just a unit test
    # and should not actually modify anything on the file system.
    with open('/etc/group') as m:
        module = MagicMock(spec=AnsibleModule)
        module.params = {'data': 'pong'}
        assert main() == module.exit_json(**{'ping': 'pong'})
        with open('/etc/group') as m:
            module.params = {'data': 'crash'}
            module.exit_json.side_effect = Exception("boom")
            assert main() == module.exit_json(**{'ping': module.params['data']})

# Generated at 2022-06-20 22:15:33.180809
# Unit test for function main
def test_main():
    args = dict(data='pong')
    res = {}
    def exit_json(**kwargs):
        res.update(kwargs)
    def fail_json(**kwargs):
        raise Exception()
    class ExitJsonException(Exception):
        pass
    class FailJsonException(Exception):
        pass
    m = type('AnsibleModule', (object,), {'params': args, 'exit_json': exit_json, 'fail_json': fail_json, 'check_mode': False})
    main(m)
    assert res.get('changed', False) == False
    assert res['ping'] == args['data']

    res.clear()

# Generated at 2022-06-20 22:15:39.338137
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:15:44.026869
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:44.568414
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:15:47.858804
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    assert main() == None

# Generated at 2022-06-20 22:15:57.191250
# Unit test for function main
def test_main():
    
    # Test with data_parm = pong
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    assert result['ping'] == 'pong'
    # Test with data_parm = crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception

# Generated at 2022-06-20 22:16:00.454343
# Unit test for function main
def test_main():
    class MockModule:
        def __init__(self):
            self.params = dict(
                data = 'pong',
            )

    my_module = MockModule()

    main()

    assert my_module.exit_json.called
    assert my_module.exit_json.call_args == dict(
        ping='pong',
    )

# Generated at 2022-06-20 22:16:18.510284
# Unit test for function main
def test_main():
    import logging
    import os
    import shutil

    # Make fake log file
    logfile = '/tmp/ansible-test-log.txt'
    logger = logging.getLogger()
    fh = logging.FileHandler(logfile)
    fh.setFormatter(logging.Formatter(''))
    logger.addHandler(fh)

    # Create fake module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Check basic return value
    main()
    assert module.exit_json.call_args[1]['ping'] == 'pong'

    # Check crash
    assert 'crash' not in module._name

# Generated at 2022-06-20 22:16:20.347307
# Unit test for function main
def test_main():
    result = {}
    result['ping'] = 'pong'
    assert main() == result

# Generated at 2022-06-20 22:16:29.192562
# Unit test for function main
def test_main():
    from ansible.module_utils.common.text.formatters.human_readable import human_readable

    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    result = main()
    assert result == {
        'changed': False,
        'ping': 'pong',
    }

    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    try:
        main()
    except Exception as e:
        assert e.args == ("boom",)


# Generated at 2022-06-20 22:16:39.537090
# Unit test for function main
def test_main():

    # Mock AnsibleModule
    module = MagicMock()

    # Mock AnsibleModule.params
    params = {
        'data': 'pong',
    }
    module.params = params

    # Mock AnsibleModule.exit_json
    def exit_json(ansible_module, **kwargs):
        ansible_module.exit_json.called = True
        ansible_module.exit_json.called_with = kwargs

    def fail_json(ansible_module, **kwargs):
        ansible_module.fail_json.called = True
        ansible_module.fail_json.called_with = kwargs

    module.exit_json = Mock(side_effect=exit_json)
    module.fail_json = Mock(side_effect=fail_json)

    # Test code
    main()

# Generated at 2022-06-20 22:16:50.147026
# Unit test for function main
def test_main():
    # Dummy class for AnsibleModule
    class AnsiModule:
        def __init__(self):
            self.params = dict()
            self.params['data'] = 'pong'

        def exit_json(self, **kwargs):
            print("exit_json was called")
            self.exit_json_kwargs = kwargs

        def fail_json(self, **kwargs):
            print("fail_json was called")
            self.fail_json_kwargs = kwargs

    # create an instance of the AnsibleModule class
    ansible_module = AnsiModule()

    # call main()
    main()

    # print and verify that exit_json was called with the expected argument

# Generated at 2022-06-20 22:16:52.764733
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as excinfo:
        main()
    assert 'boom' in str(excinfo.value)

# Generated at 2022-06-20 22:17:05.078567
# Unit test for function main
def test_main():
    from ansible.utils.display import Display
    from unit.mock.loader import DictDataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.plugins.callback.default import CallbackModule

    display = Display()


# Generated at 2022-06-20 22:17:12.513620
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# import the unit test module
import unittest

# Define main() for unit test

# Generated at 2022-06-20 22:17:14.099638
# Unit test for function main
def test_main():
    result = dict(ping='pong', _ansible_check_mode=False)
    assert(main() == result)

# Generated at 2022-06-20 22:17:15.061790
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:17:39.673198
# Unit test for function main
def test_main():
    def fake_module():
        return ansible.module_utils.basic.AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )

    # We need to fake some functions in the module to be able to unit test
    @mock.patch.object(ansible.module_utils.basic.AnsibleModule, '__init__')
    def fake_module_init(self, arg_spec, supports_check_mode):
        self.params = arg_spec
        self.check_mode = supports_check_mode

    ansible.module_utils.basic.AnsibleModule.__init__ = fake_module_init


# Generated at 2022-06-20 22:17:40.554205
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 22:17:42.732077
# Unit test for function main
def test_main():
  returns = { 'ping': 'pong' }
  assert main() == returns

# Generated at 2022-06-20 22:17:44.966864
# Unit test for function main
def test_main():
    # This test will pass when we remove the AnsibleModule import above
    with pytest.raises(AttributeError):
        main()

# Generated at 2022-06-20 22:17:51.108539
# Unit test for function main
def test_main():
    m = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    # test exception path
    m.params['data'] = 'crash'
    try:
        main(m)
    except Exception as e:
        assert 'boom' in str(e)
    # test good path
    m.params['data'] = 'pong'
    main(m)
    assert m.exit_json.called
    # test return value
    assert m.exit_json.call_args[1]['ping'] == 'pong'

# Generated at 2022-06-20 22:17:57.014997
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Exception case
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(changed=True, meta=result)

# Generated at 2022-06-20 22:18:01.689617
# Unit test for function main
def test_main():
    module_args = dict(
        data='pong'
    )
    result = dict(
        ping='pong'
    )
    mocked_module = mock.Mock(params=module_args)
    main()
    mocked_module.exit_json.assert_called_once_with(**result)

# Generated at 2022-06-20 22:18:10.280728
# Unit test for function main
def test_main():
    class AnsibleModule():
        def __init__(self, argument_spec, supports_check_mode):
            self.params = dict(
                data=dict(type='str', default='pong'),
            )

    try:
        main()
        raise "[ERROR] ping module should raise exception!"
    except:
        print("[SUCCESS] ping module raises exception!")

test_main()

# Ansible-playbook
# ansible-playbook ping.yml


# ping.yml
# ---
# - hosts: all
#   tasks:
#     - name: ping
#       ping:
#         data: crash

# Generated at 2022-06-20 22:18:11.186995
# Unit test for function main
def test_main():
    assert main()['ping'] == 'pong'

# Generated at 2022-06-20 22:18:12.154964
# Unit test for function main
def test_main():
    assert False, "No test implemented"



# Generated at 2022-06-20 22:19:03.835688
# Unit test for function main
def test_main():
    # Basic unit test for ping module
    def fake_module_main(module_args):
        import sys

        if 'data' in module_args and module_args['data'] == 'crash':
            raise Exception("boom")
        return (None, None, None)

    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule.main = fake_module_main

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')),
        supports_check_mode=True)
    result = module.main()

    assert result == (None, None, None)

# Generated at 2022-06-20 22:19:08.352154
# Unit test for function main
def test_main():
    import os
    import json
    
    _mocked_module_params = {
            'data': 'pong'
    }
    _mocked_ansible_module = AnsibleModule(_mocked_module_params)
    
    if _mocked_ansible_module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=_mocked_ansible_module.params['data'],
    )
    print(json.dumps(result,sort_keys=True,indent=4,separators=(',', ': ')))
    
# Unit test case    
test_main()

# Generated at 2022-06-20 22:19:14.020331
# Unit test for function main
def test_main():

    # This is how you would typically write a unit test for a function
    # via a function called test_<function name> that is defined in the
    # same file as the function.
    # assert pong.main() == "pong"

    assert True

# Generated at 2022-06-20 22:19:23.383906
# Unit test for function main
def test_main():
    import tempfile
    test_args = ['--data=crash', '--ignore-check-mode']

    # Basically a copy of ansible.module_utils.basic.AnsibleModule.exit_json()
    # with support removed for check_mode and diff_mode
    class AnsibleModuleMock(object):
        def __init__(self, params, args, check_mode=False, diff_mode=True, supports_check_mode=True,
                     supports_diff_mode=False):
            self.params = params
            self.args = args
            self.check_mode = check_mode
            self.diff_mode = diff_mode
            self.supports_check_mode = supports_check_mode
            self.supports_diff_mode = supports_diff_mode


# Generated at 2022-06-20 22:19:27.859778
# Unit test for function main
def test_main():
    argspec = dict(
        data=dict(type='str', default='pong')
    )
    module = AnsibleModule(
        argument_spec=argspec,
        supports_check_mode=True
    )

    for value in ['pong', 'crash']:
        module.params['data'] = value
        try:
            main()
        except Exception:
            if module.params['data'] == 'crash':
                pass
            else:
                raise

# Generated at 2022-06-20 22:19:29.039812
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:19:35.274108
# Unit test for function main
def test_main():
    import pytest
    import mock
    import sys

    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestModule(unittest.TestCase):
        def test_ping(self):
            with mock.patch.object(AnsibleModule, 'exit_json') as exit_json:
                module = mock.Mock(params={'data': 'pong'})
                exit_json.return_value = None
                main()
                exit_json.assert_called_with(ping='pong')


# Generated at 2022-06-20 22:19:38.370300
# Unit test for function main
def test_main():
    args = {"data": "ping"}
    module = AnsibleModule(argument_spec=args)
    result = module.exit_json(**main())
    assert result['ping'] == "pong"

# Generated at 2022-06-20 22:19:48.581815
# Unit test for function main
def test_main():
    #from ansible.modules.network.nxos import ping
    import ansible.modules.network.nxos.ping as my_module
    import sys
    import os
    import ansible.modules.network.nxos.ping as ping
    print ('in test_main')
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    print ('in test_main2')

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:19:57.864130
# Unit test for function main
def test_main():
    # Mock AnsibleModule
    AnsibleModule_mock = MagicMock(name='AnsibleModule')
    module = AnsibleModule_mock.return_value
    module.params = {'data': 'pong'}

    # Mock AnsibleModule.exit_json
    exit_json_mock = MagicMock()
    module.exit_json = exit_json_mock

    # Mock AnsibleModule.fail_json
    fail_json_mock = MagicMock()
    module.fail_json = fail_json_mock

    # Call function main
    try:
        main()
    except:
        assert False, "Exception raised"

    # Check if AnsibleModule function calls and results are correct
    assert AnsibleModule_mock.call_count == 1
    assert AnsibleModule_mock.call_

# Generated at 2022-06-20 22:21:36.323296
# Unit test for function main
def test_main():
    # Ensure that AnsibleModule argument_spec contains the parameters expected by the module
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    )

    # Create a new instance of AnsibleModule object
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    # Assert that result is equal to expected data
    assert main(module) == dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-20 22:21:41.299090
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:21:44.945143
# Unit test for function main
def test_main():
    argument_spec = dict(
            data=dict(type='str', default='pong'),
        )
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )


# Generated at 2022-06-20 22:21:52.572478
# Unit test for function main
def test_main():
    import inspect
    import json

    # Get the function's argspec, and check if it is correct
    spec = inspect.getargspec(main)

    assert spec.args == ['module', '*args', '**kwargs']
    assert spec.varargs == 'args'
    assert spec.keywords == 'kwargs'
    assert spec.defaults is None

    # Create an instance of the module also.  In case the module has a different
    # constructor function than called from the argument_spec, we will test that too.
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-20 22:21:53.706672
# Unit test for function main
def test_main():
    assert main() is not None

# Generated at 2022-06-20 22:22:04.879144
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils.common.dicttransformers import to_bytes
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six
    import ansible.module_utils._text
    import ansible.module_utils.network
    import ansible.module_utils.netconf
    import ansible.module_utils.nxos
    import ansible.module_utils.nxos_command
    import ansible.module_utils.nxos_static_interface
    import ansible.module_utils.nx

# Generated at 2022-06-20 22:22:12.191013
# Unit test for function main
def test_main():

    # Mock the AnsibleModule class.
    class MockAnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = dict(data='pong')

        def exit_json(self, **kwargs):
            self.exit_json_args = kwargs

        def fail_json(self, **kwargs):
            self.fail_json_args = kwargs

    # Create a mock module object.
    mock_module = MockAnsibleModule(dict(
        data=dict(type='str', default='pong'),
    ), True)

    # Run the function.
    main()

    # Check the results.

# Generated at 2022-06-20 22:22:13.695951
# Unit test for function main
def test_main():
    data = dict(data='pong')
    main(data)

# Generated at 2022-06-20 22:22:20.419748
# Unit test for function main
def test_main():
    global __ansible_module__
    __ansible_module__ = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    
    if __ansible_module__.params['data'] == 'crash':
        raise Exception("boom")
    else:
        result = dict(
            ping=__ansible_module__.params['data'],
        )
        __ansible_module__.exit_json(**result)

# Generated at 2022-06-20 22:22:27.238242
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)