

# Generated at 2022-06-20 22:14:27.082195
# Unit test for function main
def test_main():
    module_args = {"data":"pong"}
    original_module_params = {"data":"pong"}
    original_module_args = {"data":"pong"}
    original_check_mode = False
    result = {"ping":"pong"}
    converted_args = [{"data":"pong"}]
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # Mock the AnsibleModule
    module.params = module_args
    module.original_module_params = original_module_params
    module._original_module_args = original_module_args
    module.check_mode = original_check_mode

    main()
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0] == result

# Generated at 2022-06-20 22:14:31.242240
# Unit test for function main
def test_main():

	# Instantiating an AnsibleModule object is the first step of Ansible execution
	module = AnsibleModule(
        argument_spec = dict(
            data = dict(type = str, default = 'pong')
        )
    )

	# Checking if all the required params are present
	if module.params['data'] == "crash":
		raise Exception("boom")

	# Creating a results dictionary for the AnsibleModule
	results = dict(
        ping = module.params['data'],
    )

	# Passing the results back to AnsibleModule
	module.exit_json(**results)

# Generated at 2022-06-20 22:14:35.154808
# Unit test for function main
def test_main():
    # Create a module mock
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Set the module args
    module.params = dict(
        data='pong'
    )

    # Execute the main function
    main()

    # Test for results
    assert module.exit_json.call_count == 1
    exit_json = module.exit_json.call_args_list[0][0][0]
    assert type(exit_json) == dict
    assert exit_json['changed'] == False
    assert exit_json['ping'] == 'pong'


# Generated at 2022-06-20 22:14:39.370349
# Unit test for function main
def test_main():
    module_args = dict(
        data='pong',
    )

    m = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    result = main()
    assert result['ping'] == 'pong'


# Generated at 2022-06-20 22:14:43.396947
# Unit test for function main
def test_main():
    test_data = {'data': 'ping'}
    result = main(test_data)
    print(result)
    assert result == {'ping': 'ping'}

# Generated at 2022-06-20 22:14:52.174433
# Unit test for function main
def test_main():
    from ansible.utils.contextmanager import make_contextmanager
    from ansible.utils.sentinel import Sentinel
    from ansible.module_utils.basic import AnsibleModule

    # Test we can logon to 'webservers' and execute python with json lib.
    # ansible webservers -m ping

    # - name: Example from an Ansible Playbook
    #   ansible.builtin.ping:

    # - name: Induce an exception to see what happens
    #   ansible.builtin.ping:
    #     data: crash

    def get_fake_args():
        return {
            'argument_spec': dict(
                data=dict(type='str', default='pong'),
            ),
            'check_mode': Sentinel
        }


# Generated at 2022-06-20 22:14:53.362787
# Unit test for function main
def test_main():
    ping = main()
    assert ping['ping'] == 'pong'

# Generated at 2022-06-20 22:15:00.862004
# Unit test for function main
def test_main():
    rval = ping(['test', '-m', 'ping'])
    assert rval['ping'] == 'pong'
    rval = ping(['test', '-m', 'ping', 'data=pang'])
    assert rval['ping'] == 'pang'
    rval = ping(['test', '-m', 'ping', 'data=crash'])
    assert rval['failed']

# Generated at 2022-06-20 22:15:01.625801
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:15:03.564806
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as myexception:
        assert 'boom' in str(myexception)

# Generated at 2022-06-20 22:15:08.820562
# Unit test for function main
def test_main():
    assert main()



# Generated at 2022-06-20 22:15:14.464765
# Unit test for function main
def test_main():
  module_args = dict(
      data=dict(type='str', default='pong'),
    )
  module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

  assert module.params['data'] == 'pong'
  assert 'ping' in module.exit_json(ping='pong')
  assert 'ping' not in module.exit_json(pong='ping')

# Generated at 2022-06-20 22:15:22.037734
# Unit test for function main
def test_main():
    """Test ping module."""
    module_path = 'ansible.builtin.ping'
    data = 'pong'

    def fake_exit_json(**kwargs):
        """Fake exit_json function."""
        assert 'ping' in kwargs
        assert data == kwargs['ping']

    def fake_fail_json(**kwargs):
        """Fake exit_json function."""
        assert 'msg' in kwargs
        assert 'exception' in kwargs
        assert 'boom' in kwargs['msg']
        assert 'crash' in kwargs['msg']

    def fake_ansible_module(**kwargs):
        """Fake ansible module function."""
        assert 'argument_spec' in kwargs
        assert 'data' in kwargs['argument_spec']
       

# Generated at 2022-06-20 22:15:29.868153
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:34.284137
# Unit test for function main
def test_main():
    result = {}
    result = main()
    assert len(result) == 1
    assert result['ping'] == 'pong'

    test_data = ['foo', 'bar', '', 'crash']

    result = {}
    result = main(test_data)
    assert len(result) == 1
    assert result['ping'] == 'crash'

# Generated at 2022-06-20 22:15:36.226199
# Unit test for function main
def test_main():
    result = main()
    assert result == {'changed': False, 'ping': 'pong'}

# Generated at 2022-06-20 22:15:37.641274
# Unit test for function main
def test_main():
    pong = main()
    assert pong == "pong"

# Generated at 2022-06-20 22:15:50.006910
# Unit test for function main
def test_main():
    import copy
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test module run with --check
    # These examples are not currently tested, however, they are needed to move the module code to use self.exit_json and self.fail_json.

    # Test module run with --check --diff
    # These examples are not currently tested, however, they are needed to move the module code to use self.exit_json and self.fail_json.

    # Test module run with --check --diff and data=crash
    with pytest.raises(Exception) as e:
        module.params['data'] = 'crash'
        main()
    assert 'boom' in str(e)

    #

# Generated at 2022-06-20 22:15:57.343364
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as module:
        exception = Exception('boom')
        module.params = {
            'data': 'crash'
        }
        module.exit_json.side_effect = exception
        main()
        assert module.exit_json.called_with(**result)
    with patch('ansible.module_utils.basic.AnsibleModule') as module:
        result = dict(
            ping=''
        )
        module.params = {
            'data': ''
        }
        module.exit_json.side_effect = None
        main()
        assert module.exit_json.called_with(**result)

# Generated at 2022-06-20 22:16:00.248999
# Unit test for function main
def test_main():
    try:
        import ansible.modules.system.ping as ping
    except ImportError:
        import ansible.modules.network.ping as ping
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert ping.main() == None

# Generated at 2022-06-20 22:16:13.062046
# Unit test for function main
def test_main():
    testmodule = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(ping=testmodule.params['data'])
    assert main() == result

# Generated at 2022-06-20 22:16:13.498818
# Unit test for function main
def test_main():
    print("Test main")

# Generated at 2022-06-20 22:16:14.085542
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:16:19.121956
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    test_main_result = main(test_module)

    assert test_main_result is not None



# Generated at 2022-06-20 22:16:28.250684
# Unit test for function main
def test_main():

    # Mock Module class
    module = Mock(check_mode=True, params={'data': 'pong'})

    # Mock spec of a base AnsibleModule
    module_spec = type('ansible.module_utils.basic.AnsibleModule', (object,),
        {'argument_spec': dict(data=dict(type='str', default='pong'))})

    # Initialize Mock object
    module.__class__ = module_spec

    assert main() == {'ping': 'pong'}

    # Mock Module class
    module = Mock(check_mode=True, params={'data': 'crash'})

    # Mock spec of a base AnsibleModule with Method mocks

# Generated at 2022-06-20 22:16:36.850214
# Unit test for function main
def test_main():
    import sys

    # Monkeypatch sys.modules and sys.argv so that the module is run from the command line
    orig_sys_modules = sys.modules.copy()
    sys.modules['ansible.module_utils.basic'] = __import__('ansible.module_utils.basic')
    sys.argv = [sys.argv[0], '-m', 'ping', '-a', 'data=pong']
    main()
    sys.argv = [sys.argv[0]]
    sys.modules = orig_sys_modules

# Generated at 2022-06-20 22:16:40.650098
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        print(e)
        assert False
    except Exception as e:
        print(e)
        assert False

test_main()

# Generated at 2022-06-20 22:16:51.374169
# Unit test for function main
def test_main():
    import sys

    orig_sys_argv = sys.argv
    sys.argv = ['ansible-test', 'ping']
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Check that we get the crash exception
    sys.argv = ['ansible-test', 'ping', 'data=crash']

# Generated at 2022-06-20 22:16:52.870387
# Unit test for function main
def test_main():
    module.params['data'] = 'pong'
    main()


# Generated at 2022-06-20 22:16:55.576708
# Unit test for function main
def test_main():
    mock_module = MagicMock()
    mock_module.params = {'data':'mock'}
    assert ping.main(mock_module) is not None


# Generated at 2022-06-20 22:17:15.885385
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    with pytest.raises(Exception) as execinfo:
        result=dict(ping='pong')
        module = AnsibleModule(argument_spec={}, supports_check_mode=True)
        module.exit_json(**result)
    assert 'boom' in str(execinfo.value)

# Generated at 2022-06-20 22:17:16.987732
# Unit test for function main
def test_main():
    # unit tests are not written
    pass

# Generated at 2022-06-20 22:17:20.882266
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == 'pong'

# Generated at 2022-06-20 22:17:33.293939
# Unit test for function main
def test_main():
    # Get a function reference
    main_ref = globals()['main']

    # Get a module reference for this module
    module_to_test = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Set the module args
    module_to_test.params = dict(
        data=dict(type='str', default='pong'),
    )

    # Return value/result
    # Each call to the module should be checked.
    # The previous one should not have any impact on the next
    result = dict(
        changed=False,
        ping='pong'
    )

    # Test the return value
    result_to_check = main_ref(module_to_test)

    # Check

# Generated at 2022-06-20 22:17:33.922236
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:17:41.203545
# Unit test for function main
def test_main():
    # Create the module mock object
    class ModuleMock(object):
        def __init__(self, dict):
            self.params = dict
            self.exit_json = exit_json
            self.fail_json = fail_json

    # create the exit_json mock object
    class ExitJsonMock(object):
        def __init__(self):
            self.return_value = None

        def __call__(self, dict):
            self.return_value = dict

    # create the fail_json mock object
    class FailJsonMock(object):
        def __init__(self):
            self.return_value = None

        def __call__(self, dict):
            self.return_value = dict

    # Create the module module_mock object

# Generated at 2022-06-20 22:17:48.562973
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = {'ping': 'pong'}
    byte_result = to_bytes(result, errors='surrogate_or_strict')
    assert module.exit_json(**result) == byte_result

# Generated at 2022-06-20 22:17:51.297764
# Unit test for function main
def test_main():
    args = dict(
      data = 'pong'
    )
    check_args(dict(changed=False, ping='pong'), main, args)

# Generated at 2022-06-20 22:17:59.640786
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:18:02.545552
# Unit test for function main
def test_main():

    dummy_module = DummyModule()

    res_args = {
        'failed': False,
        'changed': False,
        'ping': 'pong'
    }

    assert main(dummy_module) == res_args


# Generated at 2022-06-20 22:18:51.952823
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.common._text.converters import to_bool
    from ansible.module_utils import basic

    with pytest.raises(Exception):
        result = basic.AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
        result.params['data'] = 'crash'
        my_obj = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=to_bool('True'))
        my_obj.params['data'] = 'crash'
        my_obj.exit_json(**result)

    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:19:03.734758
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.collections import is_iterable

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=module.params['data'],
    )
    assert result == {'ping': 'pong'}



# Generated at 2022-06-20 22:19:07.745678
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    sys.path.append('./')

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result == {"ping": "pong" }

# Generated at 2022-06-20 22:19:08.540403
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:19:10.585294
# Unit test for function main
def test_main():
    result = main()
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:19:13.431542
# Unit test for function main
def test_main():
    result = main()
    assert result['ping'] == 'pong'


# Generated at 2022-06-20 22:19:19.336525
# Unit test for function main
def test_main():
    test_data = dict(
        data=dict(type='str', default='pong'),
    )
    module = AnsibleModule(
        argument_spec=test_data,
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

test_main()

# Generated at 2022-06-20 22:19:22.823935
# Unit test for function main
def test_main():

    results = []
    with patch('ansible.modules.remote_management.network.nxos.nxos_command.load_config'):
        for arg_defs, arg_names, ret_val in [
            # args,                                  kwargs,                        ret
            (dict(),                                dict(),                        True),
            (dict(data='pong'),                     dict(),                        True),
            (dict(),                                dict(data='pong'),             True),
            (dict(data='crash'),                    dict(),                        False),
            (dict(),                                dict(data='crash'),            False),
        ]:
            # Execute
            args = dict(arg_names, **arg_defs)

# Generated at 2022-06-20 22:19:23.986768
# Unit test for function main
def test_main():
    if main() != None:
        raise Exception('Test failed')

# Generated at 2022-06-20 22:19:27.109356
# Unit test for function main
def test_main():
    # DONE: Uncomment code as you go along so that each
    #       stage is tested as you add code.  This allows
    #       you to quickly find where you are having problems
    #       when you are running the play in Ansible
    result = main()
    assert result == 'pong'

# Generated at 2022-06-20 22:20:53.207515
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Sample test_main
result = test_main()
if result is None:
    # Test case failed
    print("test case failed")
else:
    print("test case passed")
test_main()

# Generated at 2022-06-20 22:20:54.726105
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule({'data': 'pong'})
    m.exit_json = lambda x: x
    assert main() == {'ping': 'pong'}

# Generated at 2022-06-20 22:21:00.064500
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    d = m.params['data']
    assert(d == 'pong')

# Generated at 2022-06-20 22:21:02.622153
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    result = dict(ping=module.params['data'])
    assert result == dict(ping='pong')

# Generated at 2022-06-20 22:21:03.877804
# Unit test for function main
def test_main():
    x = main()
    y = 'pong'
    assert x == y

# Generated at 2022-06-20 22:21:11.202899
# Unit test for function main
def test_main():
  import sys
  import json
  from mock import patch, Mock
  from StringIO import StringIO

  class TestModule(object):
    def __init__(self, params=None):
      self.params = params
      self.exit_json = Mock(return_value=True)

    def fail_json(self, **kwargs):
      raise Exception("PING module failed")

  def run_module(*args):
    print("Test args are: {}".format(args))
    m = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    m.exit_json = Mock(return_value=True)
    m.params={"data":"crash"}
    ping(m)
    return True


# Generated at 2022-06-20 22:21:21.343041
# Unit test for function main
def test_main():
    # Mock the module arguments and results of AnsibleModule.
    mock_module_args = dict(
        data='foo',
    )
    mock_module_exit_json = dict(
        ping='foo',
        changed=False,
    )
    mock_ansible_module = MagicMock(**{
        'params': mock_module_args,
        'exit_json': mock_module_exit_json,
    })
    with patch.object(sys, 'argv', ['/path/to/ping']):
        main()
    assert mock_ansible_module.exit_json.called
    # Verify AnsibleModule.exit_json() was called with the expected args.
    assert mock_ansible_module.exit_json.call_args == call(
        **mock_module_exit_json
    )



# Generated at 2022-06-20 22:21:22.790297
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    main()

# Generated at 2022-06-20 22:21:27.839933
# Unit test for function main
def test_main():
    args = dict(data="newdata")
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        with patch.dict(ansible.module_utils.basic.AnsibleModule.__dict__, {
            'exit_json': MagicMock(),
            'exit_json.assert_called_with': MagicMock(),
            '__exit__.assert_called_with': MagicMock(),
            '_ansible_module_create': MagicMock(return_value=AnsibleModuleStub(**args)),
            }):
            main()
        assert pytest_wrapped_e.type == SystemExit

# Generated at 2022-06-20 22:21:32.785552
# Unit test for function main
def test_main():
    print("=== TEST ===")
    test_input = dict(
        data="pong",
    )
    test_result = dict(
        ping="pong",
    )
    main()
    #main(test_input, test_result)