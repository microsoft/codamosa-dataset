

# Generated at 2022-06-20 22:14:20.065581
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong'),
    )
    result = dict(
        ping=module.params['data'],
    )
    assert main() == result

# Generated at 2022-06-20 22:14:25.020433
# Unit test for function main
def test_main():
    test_data = dict(
        data="foo",
    )

    test_ansible_module_for_linux_ping = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert test_ansible_module_for_linux_ping.params['data'] == "foo", "Should be equal"
    test_ansible_module_for_linux_ping.exit_json(**test_data)

# Generated at 2022-06-20 22:14:28.356328
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == None

# Generated at 2022-06-20 22:14:33.464142
# Unit test for function main
def test_main():
    from ansible.modules.network.ping import main

    # Note: This is a hack to test inside of a dev environment
    # I'm sure there's a better way, but I don't know what it is.
    try:
        import __main__
        __main__.__file__ = __file__
    except (ImportError, AttributeError):
        pass

    # Build a dummy module
    module = AnsibleModule(argument_spec=dict())

    # For testing, we're going to change the argument passed to module.exit_json
    # so that the unit test can tell if the parameters have been passed in properly
    def fake_exit_json(*args):
        fake_exit_json.exit_args = args

    # Now we'll execute the ping module with the fake exit json
    module.exit_json = fake_exit_json
   

# Generated at 2022-06-20 22:14:38.320166
# Unit test for function main
def test_main():
    args = dict()
    res = {"ping": 'pong'}
    m = AnsibleModule(argument_spec=args)
    m.exit_json = lambda res: res
    assert main() == res, "main() returned unexpected result"

# Generated at 2022-06-20 22:14:41.380403
# Unit test for function main
def test_main():
    test_results = main()
    assert test_results == (True, {})

# Generated at 2022-06-20 22:14:43.131932
# Unit test for function main
def test_main():
    #output = main()
    assert True == True

# Generated at 2022-06-20 22:14:44.427455
# Unit test for function main
def test_main():
    result = dict(ping='pong')
    assert main() == result

# Generated at 2022-06-20 22:14:53.205134
# Unit test for function main
def test_main():
    # Num hits: 3
    # Converted: 3
    # Lines: 3
    # Missing: 0
    # Parse errors: 0
    # Num coverage: 1
    # Num uncovered: 0
    # Num partial: 0
    # Num full: 1
    # Num uncovered ifs: 0
    # Num uncovered loops: 0
    mock_module = [
        {
            'params': {
                'data': 'pong',
            },
            'supports_check_mode': True,
        },
    ]
    for entry in mock_module:
        module = entry
        if (module['params']['data'] == 'crash'):
            raise Exception('boom')
        result = dict(
            ping=module['params']['data'],
        )

test_main()

# Generated at 2022-06-20 22:15:01.531577
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # create an instance of the AnsibleModule object
    mod_obj = PingModule()
    # set the module_name and module_args for AnsibleModule
    mod_obj.params = {}
    # execute the main() method of the AnsibleModule class
    mod_obj.main()

# Generated at 2022-06-20 22:15:13.887145
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def exit_json(*args, **kwargs):
        return args[0]
    def fail_json(*args, **kwargs):
        return args[0]

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.exit_json = exit_json
            self.fail_json = fail_json

    with pytest.raises(Exception) as e:
        main(AnsibleModuleMock(data='crash'))

    assert 'boom' in str(e.value)

    assert main(AnsibleModuleMock(data='pong')) == dict(ping='pong')

# Generated at 2022-06-20 22:15:21.718176
# Unit test for function main
def test_main():
    mod = AnsibleModule({})
    assert mod.params['data'] == 'pong'


'''
Module unit test for ansible
(c) 2016, Toshio Kuratomi <tkuratomi@ansible.com>
'''

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import os
import sys
import json
import shutil
import tempfile
import subprocess

from ansible_collections.community.general.tests.unit.compat import unittest
from ansible_collections.community.general.tests.unit.compat.mock import MagicMock, patch
from ansible.module_utils import basic
from ansible.module_utils._text import to_bytes
from ansible.module_utils.pycompat24 import get_exception

# Generated at 2022-06-20 22:15:27.600888
# Unit test for function main
def test_main():
    # Default return value, no data
    assert main({'data': 'pong'}) == { 'ping': 'pong' }
    # With data
    assert main({'data': 'foo'}) == { 'ping': 'foo' }
    # With crash data
    assert main({'data': 'crash'}) == { 'ping': 'crash' }

# Generated at 2022-06-20 22:15:35.258122
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )
    result = dict(
        changed=False,
        ping='pong',
    )
    # The call to main() is mocked so the only the module.exit_json call
    # is called.  This is not normally something that is good practice but
    # is done in this situation to verify the calls and arguments to the
    # exit_json() function.
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        main()
        mock_exit_json.assert_called_once_with(**result)

# Generated at 2022-06-20 22:15:46.414541
# Unit test for function main
def test_main():
    # Make it so we can use the unittest mock module
    import sys
    sys.modules['ansible'] = type('MockAnsibleModule', (object,), {'AnsibleModule': type('MockAnsibleModuleClass', (object,), {'exit_json': type('MockExitJson', (object,), {'side_effect': Exception("end of test")})})})
    sys.modules['ansible.module_utils'] = type('MockAnsibleModuleUtil', (object,), {'basic': type('MockAnsibleModuleUtilBasic', (object,), {'AnsibleModule': type('MockAnsibleModuleClass', (object,), {'exit_json': type('MockExitJson', (object,), {'side_effect': Exception("end of test")})})})})

# Generated at 2022-06-20 22:15:50.729633
# Unit test for function main
def test_main():
    args = {'data': 'pong'}
    result = {}
    res = main(args, result)
    assert res['ping'] == 'pong'
    assert result == {'ping': 'pong'}

# Generated at 2022-06-20 22:15:58.391487
# Unit test for function main
def test_main():
    """ Test module main """
    module_list = [
        {
            'data': 'pong'
        }
    ]
    for module in module_list:
        result = main(module)
        assert result['ping'] == module['data']
    # Test exception
    with pytest.raises(Exception):
        result = main(
            {
                'data':'crash'
            }
        )

# Generated at 2022-06-20 22:16:06.064705
# Unit test for function main
def test_main():
    # Mock the AnsibleModule and the ansible arguments
    am = AnsibleModule(argument_spec={
        "data": dict(type='str', default='pong')
    })
    def am_json(d):
        print("JSON %s" % str(d))
        assert True
    am.exit_json = am_json

    # Call the module
    try:
        main()
    except:
        # Fail if the test failed
        assert False
    # If the test didn't fail, then the test passed
    assert True

# Generated at 2022-06-20 22:16:09.247003
# Unit test for function main
def test_main():
    m = AnsibleModule(dict(data=dict(default='pong', type='str')))
    m._check_mode = True
    m.fail_json = lambda *args: None
    m.exit_json = lambda **kwargs: None
    setattr(m, 'ansible_facts', dict())
    main()

# Generated at 2022-06-20 22:16:15.862118
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Unit test to check result

# Generated at 2022-06-20 22:16:31.304861
# Unit test for function main
def test_main():
    args = {
        "data": "pong",
    }
    # Parsed results of the json sent back by the module
    parsed_results = {
        "ping": "pong",
    }

    # The json sent as input to the module's utility function
    input_json = {
        "params": args,
    }

    # The function name of the module's utility function
    function_name = 'main'

    # Initialize a mock connection to the module
    connection = MockConnection(input_json, function_name)

    # Call the utility function to actually run the module
    try:
        connection.run()
    except Exception as e:
        # If an exception occurred during the module execution, ensure
        # the exception is saved so it can be reraised by the test
        connection.excep = e

    # Ensure the

# Generated at 2022-06-20 22:16:39.999780
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

    module.params['data'] = 'crash'

    try:
        assert module.params['data'] == 'crash'
        main()
    except Exception as reason:
        raise Exception(reason)

    module.params['data'] = 'pong'

    try:
        assert module.params['data'] == 'pong'
        main()
    except Exception as reason:
        raise Exception(reason)

    print("Testing completed successfully!")

# Generated at 2022-06-20 22:16:43.608391
# Unit test for function main
def test_main():
    module_args = {}
    module_args.update(dict(data='pong'))
    result = dict(ping='pong')
    module = AnsibleModule(module_args)
    assert module.get_bin_pathreturn_value == result

# Generated at 2022-06-20 22:16:46.804610
# Unit test for function main
def test_main():
    ping = mock.Mock()
    ping.params = dict(data='pong')
    result = dict(
        ping=ping.params['data'],
    )
    assert main() == result
    assert main()['ping'] == 'pong'

# Generated at 2022-06-20 22:16:51.961727
# Unit test for function main
def test_main():
    import ansible.constants as C
    import types
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args):
            raise Exception()

        def exit_json(self, **kwargs):
            self.result = kwargs

    try:
        # check module without required arguments = fail
        setattr(C, 'DEFAULT_LOCAL_TMP', '/tmp')
        myansiblemodule = TestAnsibleModule()
        main()
    except Exception:
        pass

# Generated at 2022-06-20 22:17:04.270164
# Unit test for function main
def test_main():
    data = dict(
        data={
          "ansible_check_mode": False,
          "ansible_module_name": "ping",
          "ansible_version": {"full": "2.6.2", "major": 2, "minor": 6, "revision": 2},
          "data": "pong",
          "invocation": {"module_args": {"data": "pong"}},
          "module_args": {"data": "pong"},
          "system_distribution": None,
          "system_distribution_release": None,
          "system_distribution_version": None,
          "system_python_version": "2.7.12",
          "system_user": "root",
        }
    )
    result = main()
    assert result['ping'] == "pong"
    #assert

# Generated at 2022-06-20 22:17:11.411547
# Unit test for function main
def test_main():
    import json
    import pytest

    data_to_respond_with = '12345'

    test_json = dict({
        'params': dict({
            'data': data_to_respond_with,
        }),
    })
    argv = [
        'ping.py',
        json.dumps(test_json),
    ]

    # api_response will be the response from the module
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-20 22:17:23.366975
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = basic._ANSIBLE_ARGS[:1] + [args]

    # Emit fake args for testing
    # Side effect is to set basic._ANSIBLE_ARGS

    sys.argv = ['ping.py']
    with pytest.raises(SystemExit):
        main()

    sys.argv = ['ping.py', '_json_args']
    with pytest.raises(SystemExit):
        main()

    # Test default is to return pong

# Generated at 2022-06-20 22:17:28.842202
# Unit test for function main
def test_main():
  
  # AnsibleModule class define in python-2.7/ansible/module_utils/basic.py
  module = AnsibleModule(dict(data=dict(type='str', default='pong')))
  assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:17:33.662572
# Unit test for function main
def test_main():
    # Test with no args
    testargs = ['ansible-test-module.py']
    args = AnsibleModule.parse(argv=testargs)
    assert main(args) == True
    # Test with args
    testargs = ['ansible-test-module.py', '-a', 'foo=bar']
    args = AnsibleModule.parse(argv=testargs)
    assert main(args) == True

# Generated at 2022-06-20 22:17:51.678242
# Unit test for function main
def test_main():
    result = main()
    assert result['params'] == {'data': 'pong'}
    assert result['check_mode'] == True
    assert result['diff_mode'] == False

# Generated at 2022-06-20 22:17:56.384012
# Unit test for function main
def test_main():
    response = AnsibleModule( argspec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert response.params['data'] == 'pong'

# Generated at 2022-06-20 22:17:58.108347
# Unit test for function main
def test_main():
    output = os.popen('ansibule ping.yml')
    print(output)
    
test_main()

# Generated at 2022-06-20 22:18:07.312049
# Unit test for function main
def test_main():
    module_args = dict(
        data=dict(type='str', default='pong'),
    )
    result = dict(
        ping='pong',
    )

    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )

        main()
        exit_json.assert_called_with(**result)

    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )

        module.params['data'] = 'crash'
        with patch.object(module, 'fail_json') as fail_json:
            main

# Generated at 2022-06-20 22:18:12.371399
# Unit test for function main
def test_main():
    ping_result = 'pong'
    ping_data = dict(
        changed=False,
        ping=ping_result,
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default=ping_result),
        ),
    )

    result = dict(
        ping=module.params['data'],
    )
    assert result == ping_data

# Generated at 2022-06-20 22:18:13.828812
# Unit test for function main
def test_main():    
    # Unit tests for function main
    #Function main() is tested in test_ansible_module
    assert True

# Generated at 2022-06-20 22:18:15.830226
# Unit test for function main
def test_main():
    print("Running test_main")
    result=main()
    assert result['ping'] == "pong", "Should return 'pong'"
    print("PASS")

test_main()

# Generated at 2022-06-20 22:18:20.192757
# Unit test for function main
def test_main():
    # Construct data
    module_args = {
        'data': 'pong'
    }
    module = AnsibleModule(argument_spec=module_args)
    module.main()
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['ping'] == module_args['data']


# Generated at 2022-06-20 22:18:24.609037
# Unit test for function main
def test_main():

    args = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.check_mode = False
    returned_result = main()

    assert returned_result == result

# Generated at 2022-06-20 22:18:29.544667
# Unit test for function main
def test_main():
    my_dict = { u'data': u'pong', u'CHECKMODE': False }
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert test_main() == (test_module.exit_json(**my_dict), None)

# Generated at 2022-06-20 22:19:08.477082
# Unit test for function main
def test_main():
    m = {'ANSIBLE_MODULE_ARGS': {'data': 'ping'}}
    module = AnsibleModule(m)
    result = dict(
        ping=module.params['data'],
    )
    assert module.exit_json(**result) == dict(
        ping='ping',
        changed=False,
        failed=False,
    )

# Generated at 2022-06-20 22:19:16.526198
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:19:20.288641
# Unit test for function main
def test_main():
    res = dict(
      data='crash',
      ping='pong',
    )
    for k, v in res.items():
        mod = AnsibleModule(argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
            supports_check_mode=True
        )

# Generated at 2022-06-20 22:19:28.240534
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    global __file__
    __file__ = 'ansible.builtin.ping'

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    stdout = StringIO()
    module.exit_json(stdout=stdout, **result)

# Generated at 2022-06-20 22:19:34.951209
# Unit test for function main
def test_main():
    arguments = dict(
        data=dict(type='str', default='pong'),
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = module.params['data']
    assert result == "pong"

# Generated at 2022-06-20 22:19:39.247278
# Unit test for function main
def test_main():
    from ansible.module_utils import ansible_module_args
    from ansible.module_utils import ansible_module_supports_check_mode
    from ansible.module_utils import ansible_module_common_arguments
    from ansible.module_utils import ansible_module_exit_json
    from ansible.module_utils import ansible_module_exit_fail
    from ansible.module_utils import ansible_module_fail_json
    from ansible.module_utils import ansible_module_get_closest_match
    from ansible.module_utils import ansible_module_load_params

    # SETUP FIXTURES
    import copy
    import json
    import sys
    import __builtin__

    # AnsibleModule can only be instantiated once
    # so we'll do it an a class

# Generated at 2022-06-20 22:19:50.399602
# Unit test for function main
def test_main():
    # first pass
    m_module = Mock(return_value={
        'params': {
            'data': 'pong'
        },
        'supports_check_mode': True
    })
    m_exit_json = Mock()
    with patch.multiple(
        'ansible.modules.system.ping',
        AnsibleModule=m_module,
        exit_json=m_exit_json,
    ):
        main()
    assert m_module.call_count == 1
    assert m_exit_json.call_count == 1
    assert m_exit_json.call_args == call({
        'changed': False,
        'ping': 'pong'
    })

    # second pass

# Generated at 2022-06-20 22:19:54.424450
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import EnvironmentConfig
    from ansible_collections.ansible.builtin.plugins.modules import ping

    config = EnvironmentConfig()

    (changed, result) = ping.main()

    assert result['changed'] == changed
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:20:01.481529
# Unit test for function main
def test_main():
    from ansible.modules.extras.network.ping import main
    m = AnsibleModule({
        'data': "pong",
    }, check_invalid_arguments=False)
    m.exit_json = lambda x: None
    m.fail_json = lambda x: None

    def get_mock_result(result):
        def mock_exit_json(obj):
            assert obj == result

        def mock_fail_json(obj):
            assert False, 'should not have failed'

        return mock_exit_json, mock_fail_json

    # Success case
    exit_json, fail_json = get_mock_result({
        "ping": "pong",
    })
    m.exit_json = exit_json
    m.fail_json = fail_json
    main()

    # Crash case

# Generated at 2022-06-20 22:20:05.626557
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:21:32.695952
# Unit test for function main
def test_main():
    test_data = {
        'data': 'crash'
    }
    # Should raise exception
    assert main(module_params=test_data)

# Generated at 2022-06-20 22:21:41.804068
# Unit test for function main
def test_main():

    def test_function(function_name, test_params, expected_results):
        """ Test a function, given the function name and parameters,
            and the expected results.
        """
        with patch.dict(ansible_module_utils.basic.AnsibleModule.__dict__,
                        {'run_command.return_value': (0, 'success output', 'success error')}):
            ansible_module_utils.basic.AnsibleModule = MagicMock()
            ansible_module_utils.basic.AnsibleModule.params = test_params
            ansible_module_utils.basic = MagicMock()
            ansible_module_utils.basic.AnsibleModule.exit_json.return_value = None

            # Call the function
            function_pointer = globals()[function_name]
            function_pointer()

# Generated at 2022-06-20 22:21:48.940059
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    response = module.exit_json(**result)
    assert response == {
        'changed': False, 
        'ping': 'pong', 
        'invocation': 
        {
            'module_args': {
                'data': 'pong'
            }
        }, 
        'ansible_facts': {}
    }

# Generated at 2022-06-20 22:21:53.022509
# Unit test for function main
def test_main():
    # TODO: AnsibleModule and AnsibleExitJson are stubs, fix for actual unit test
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:22:03.788615
# Unit test for function main
def test_main():
    import mock
    mock_module = mock.MagicMock()
    mock_module.params = {'data': 'crash'}
    mock_module.exit_json.side_effect = SystemExit
    mock_module.fail_json.side_effect = Exception
    try:
        main()
    except SystemExit:
        pass
    assert 'An exception occurred during task execution. To see the' \
           ' full traceback, use -vvv. The error was:' in mock_module.fail_json.call_args_list[0][0][0]['msg']
    assert 'boom' in mock_module.fail_json.call_args_list[0][0][0]['msg']
    # TODO: Add a test case with 'data: pong'

# Generated at 2022-06-20 22:22:11.570073
# Unit test for function main
def test_main():
    import io
    import os

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, 'test_ping.json')

    test_args = {
        'data': 'pong'
    }

    test_result = {
        'ping': 'pong'
    }

    with open(test_file) as f:
        test_module = f.read()

    tmp_file = open('/tmp/test_ping.py', 'w')
    tmp_file.write(test_module)
    tmp_file.close()


# Generated at 2022-06-20 22:22:15.689248
# Unit test for function main
def test_main():
    # missing argument
    # action should fail
    args = dict()
    args['data'] = "test"
    result = dict(
        ping=args['data'],
        changed=False,
    )
    with pytest.raises(SystemExit):
        main()
        assert result == result

# Generated at 2022-06-20 22:22:20.938664
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    module_args = {"data":"ping"}

    ping_module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # Verify contents from the ping module
    assert ping_module.params['data'] == 'ping'

    # Verify exception for crash
    ping_module.params['data'] = 'crash'
    pytest.raises(Exception)

# Generated at 2022-06-20 22:22:31.796559
# Unit test for function main
def test_main():
    this_module = AnsibleModule(dict(
        data=dict(default='pong')))

    def run_module():
        return this_module.run()

    # Below is the return object information
    # {u'_ansible_parsed': True, u'invocation': {u'module_args': {u'data': u'pong'}, u'module_name': u'ansible.builtin.ping'}, u'msg': u'', u'rc': 0}
    this_module.run_command = run_module

    result = this_module.main()

    assert result == dict(
        ansible_facts={},
        ping='pong',
        changed=False
    )


# Generated at 2022-06-20 22:22:35.702825
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)