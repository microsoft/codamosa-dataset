

# Generated at 2022-06-20 22:14:21.635901
# Unit test for function main
def test_main():
    response = {'ping': 'pong'}
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    module.pre_run_check(data=response['ping'])
    module.exit_json(**response)

test_main()

# Generated at 2022-06-20 22:14:27.402905
# Unit test for function main
def test_main():
    import json
    from ansible.modules.network.net_ping import main
    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    def mock_exit_json(ping):
        assert ping == 'pong'

    def mock_fail_json(msg):
        assert msg == "boom"

    ansible_module.exit_json = mock_exit_json
    ansible_module.fail_json = mock_fail_json
    main(ansible_module)

# Generated at 2022-06-20 22:14:30.273976
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:14:35.670497
# Unit test for function main
def test_main():
    argv = ['']
    argv[0] = 'ansible-test'
    argv.append('--tags=unit')
    argv.append('--start=test_main')
    argv.append('--tb=no')
    test_main.main(argv=argv)

# Generated at 2022-06-20 22:14:40.983731
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as mock_object:
        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
        module.exit_json = mock_object
        mock_object.assert_called_with(**{'ping': 'pong'})

# Generated at 2022-06-20 22:14:43.794311
# Unit test for function main
def test_main():
    import ping
    import pytest
    with pytest.raises(Exception) as e:
        main()
    assert "boom" in str(e)

# Generated at 2022-06-20 22:14:48.385128
# Unit test for function main
def test_main():
    ping_dict = {'data': 'pong'}
    from ansible.modules.network.ping import main
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    main()

# Generated at 2022-06-20 22:14:50.681972
# Unit test for function main
def test_main():
    args = {'data': 'crash'}
    main(args)

# Generated at 2022-06-20 22:14:58.670788
# Unit test for function main
def test_main():
    import os, sys, pytest, mock, tempfile
    from ansible.module_utils import basic as basic_lib
    import ansible.modules.system.ping as ping
    from ansible.module_utils.six.moves import builtins

    os_path_exists_mock = mock.Mock(return_value=True)
    os_path_isfile_mock = mock.Mock(return_value=True)
    open_mock = mock.mock_open(read_data="")
    check_output_mock = mock.Mock(return_value="")
    builtins_open = builtins.open


# Generated at 2022-06-20 22:15:00.543636
# Unit test for function main
def test_main():
    my_dict = {"ping": "pong"}
    assert main(my_dict) == my_dict

# Generated at 2022-06-20 22:15:12.958870
# Unit test for function main
def test_main():
    args = dict(
        data='something',
    )
    module = AnsibleModule(**args)
    result = dict(
        ping=module.params['data'],
    )
    assert module.params['data'] == 'something'
    assert result['ping'] == 'something'


# Generated at 2022-06-20 22:15:19.275501
# Unit test for function main
def test_main():
    # Create the module object
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Check the result of ping when data = crash
    with pytest.raises(Exception) as excinfo:
        result = module.params['data'] == 'crash'
        assert 'boom' in str(excinfo.value)

    # Check the result of ping when data is not crash
    result = module.params['data'] != 'crash'
    assert result

# Generated at 2022-06-20 22:15:23.680927
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )

    result = main(data=module.params['data'])
    print(result)



# Generated at 2022-06-20 22:15:28.575463
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == 'pong'

# Generated at 2022-06-20 22:15:34.562888
# Unit test for function main
def test_main():
    # import ansible.module_utils.basic
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params={'data': 'crash'}
    result = main()
    if result != 'boom':
        print ("Unit test has failed.")
    else:
        print ("Unit test has passed.")

test_main()

# Generated at 2022-06-20 22:15:39.292188
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:15:39.917900
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 22:15:40.553392
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:15:42.514232
# Unit test for function main
def test_main():
    result = dict(
        ping="pong",
    )

    assert main() == result


# Generated at 2022-06-20 22:15:47.407839
# Unit test for function main
def test_main():
    
    class MockAnsibleModule(object):

        def __init__(self):
            self.params = {'data': 'pong'}

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, msg):
            pass

    class MockException(Exception):
        pass

    mock_module = MockAnsibleModule()
    mock_module.params['data'] = 'crash'

    try:
        main()
        assert False
    except MockException:
        assert True

# Generated at 2022-06-20 22:15:56.142958
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 22:15:56.881944
# Unit test for function main
def test_main():
    s = main()
    assert s == None

# Generated at 2022-06-20 22:15:57.560722
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-20 22:16:03.219392
# Unit test for function main
def test_main():
    import json

    # Transitional module class deprecation warning
    with pytest.warns(DeprecationWarning, match='ansible.module_utils.basic.AnsibleModule is deprecated since Ansible 2.12.0'):
        module = basic_t.AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )

    with pytest.raises(Exception) as excinfo:
        module.params['data'] = 'crash'
        main()
        assert 'boom' in str(excinfo.value)

    module.params['data'] = 'pong'
    main()
    assert json.loads(module.exit_json) == dict(ping='pong')


# Generated at 2022-06-20 22:16:07.563346
# Unit test for function main
def test_main():
    try:
        # With data="pong", no exception is raised and it just returns to (module.exit_json)
        assert main()
    except Exception as e:
        # When data="crash", it raises an Exception and it returns to (module.fail_json)
        assert "boom" in str(e)

# Generated at 2022-06-20 22:16:17.734181
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost,')

# Generated at 2022-06-20 22:16:27.651103
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six import PY3

    if PY3:
        exc_class = SyntaxError
    else:
        exc_class = NameError

    m = basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    with pytest.raises(exc_class):
        m.fail_json(msg='foo')

    with pytest.raises(exc_class):
        m.exit_json(msg='foo')


# Generated at 2022-06-20 22:16:36.334765
# Unit test for function main
def test_main():
    os.environ.update({
        "ANSIBLE_MODULE_ARGS": "data=pong"
    })
    result = ansible_runner.run('./ping.py', module_name='ansible.builtin.ping')
    assert result.status == 'successful'
    assert result.rc == 0
    for item in result.contacted.values():
        assert item['ping'] == 'pong'

if __name__ == '__main__':
    pytest.main([__file__])

pytest.main([__file__])

# Generated at 2022-06-20 22:16:38.145230
# Unit test for function main
def test_main():
    # pass
    assert 1 == 1

# Generated at 2022-06-20 22:16:48.630255
# Unit test for function main
def test_main():
    from ansible.module_utils.six import b
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    import json
    import sys

    # These are needed since we are invoking main
    import ansible.module_utils.basic
    import ansible.module_utils.action

    # Set stdout to a StringIO so we can read the output
    orig_stdout = sys.stdout
    sys.stdout = StringIO()

    # Make the actual call
    main()

    # Set sys.stdout back to the original
    sys.stdout = orig_stdout
    # Read the output
    stdout = sys.stdout.getvalue()

    # Convert to unicode string (for Python2.x and 3.x compatibility)
    stdout = to_

# Generated at 2022-06-20 22:17:09.377246
# Unit test for function main
def test_main():
    testobj = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    assert testobj.params['data'] == 'pong'
    testobj = AnsibleModule(argument_spec=dict(data=dict(type='str', default='crash')))
    assert testobj.params['data'] == 'crash'

# Generated at 2022-06-20 22:17:10.836879
# Unit test for function main
def test_main():
    result = dict(
        ping='pong',
    )
    assert main() == result

# Generated at 2022-06-20 22:17:18.945435
# Unit test for function main
def test_main():
    def test_ping_result(error=None, error_msg=None, ping_data=None):
        params = {'data': ping_data}
        module = AnsibleModule(params)
        res_args = {'changed': False, 'ping': ping_data}
        if error:
            res_args['failed'] = True
            res_args['msg'] = error_msg
        else:
            res_args['failed'] = False
        return module.exit_json(**res_args)

    # Case 1: The module can return pong data as expected.
    test_ping_result(ping_data='pong')

    # Case 2: The module can return user provided data.
    test_ping_result(ping_data='data')

    # Case 3: The module can detect an error.
    test_ping_result

# Generated at 2022-06-20 22:17:31.452168
# Unit test for function main
def test_main():
    # Pause for 180 seconds if this module needs to be disabled
    # Do not disable permanently or on a schedule, but if needed
    # this allows a user to demonstrate the expected behavior.
    #time.sleep(180)

    # Setup arguments to be passed to module
    args = dict(
        data=dict(type='str', default='pong'),
    )

    # Setup test inputs based on args
    test_input = dict(
        ping='pong',
    )

    # mock the AnsibleModule
    M = MagicMock()
    M.params = args
    M.run_command = MagicMock()
    M.fail_json = MagicMock()
    M.exit_json = MagicMock()

    # Ensure the module is registered
    #check.registrate(module)

    # Run the action/function with mocked

# Generated at 2022-06-20 22:17:36.756268
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:17:37.373347
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-20 22:17:45.047962
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:17:49.289861
# Unit test for function main
def test_main():
    import ansible.modules.network.ping as ping
    from ansible.module_utils.network.ping import ping as ping_module
    from ansible.module_utils import basic

    m = ping_module.AnsibleModule(argument_spec={'data': {'default': 'pong', 'type': 'str'}})
    ping.main()

# Generated at 2022-06-20 22:17:50.475965
# Unit test for function main
def test_main():
    res = main()
    assert len(res) == 1

# Generated at 2022-06-20 22:17:51.046948
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:18:38.065319
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import get_distribution
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils import six
    import ansible.builtin.ping

    try:
        from cStringIO import StringIO as NativeStringIO
    except ImportError:
        from io import StringIO as NativeStringIO

    mock_module = type('AnsibleModule', (object,), dict(
        AnsibleModule=type('AnsibleModule', (object,), dict(
            _load_params=lambda self: True,
            params=type('params', (object,), dict(
                data='pong',
            ))
        ))
    ))

    mock_module.AnsibleModule._ansible_module

# Generated at 2022-06-20 22:18:41.346529
# Unit test for function main
def test_main():
    request_payload = {
        "params": {
          "data": "pong"
        }
    }

    response = {
        "ping": "pong"
    }

    assert main(Request(request_payload)) == response

# Generated at 2022-06-20 22:18:49.969519
# Unit test for function main
def test_main():
    from ansible_builtin_ping import *
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    import ansible.module_utils.common.text.converters
    reload(ansible.module_utils.common.text.converters)
    cliargs = {'ANSIBLE_MODULE_ARGS': {'data': 'pong'}, 'ANSIBLE_MODULE_NAME': 'ansible.builtin.ping'}
    module = AnsibleModule(**cliargs)
    assert main() == exit_json({'ping': 'pong'})


# Generated at 2022-06-20 22:18:54.703800
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert True

# Generated at 2022-06-20 22:18:55.337788
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:18:57.570898
# Unit test for function main
def test_main():
    try:
        main()
    except:
        return False
    return True

# Generated at 2022-06-20 22:19:08.192725
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.actions
    import ansible.module_utils.connection
    import ansible.module_utils.facts
    import ansible.module_utils.six


    ansible.module_utils.basic.ANSIBLE_VERSION = '2.7'
    ansible.module_utils.basic.HAS_PYWINRM = False
    ansible.module_utils.basic.HAS_KERBEROS = False


    ansible.module_utils.actions.WARNINGS = []
    ansible.module_utils.actions.MODULE_NO_JSON = []
    ansible.module_utils.actions.os = None
    ansible.module_utils.actions.shutil = None
    ansible.module_utils.actions.PKG_MANAGER_CAC

# Generated at 2022-06-20 22:19:20.208797
# Unit test for function main
def test_main():
    testdata = dict(
        data=dict(type='str', default='pong')
    )

    def checkresult_true(ansible_module):
        return True

    def checkresult_false(ansible_module):
        return False

    def exitjson_true():
        return True

    def exitjson_false():
        return False

    def failjson_true():
        return True

    class TestException(Exception):
        pass

    def raise_exception(exception_class):
        raise TestException

    test_parameters = dict(
        data=dict(default='pong')
    )

    test_ansible_module = dict(
        argument_spec=testdata,
        supports_check_mode=True,
        check_mode=checkresult_true
    )


# Generated at 2022-06-20 22:19:25.041759
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:19:32.652936
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:20:52.213793
# Unit test for function main
def test_main():
    assert ping.run_command('ping',['ping']) is None

# Generated at 2022-06-20 22:20:58.751049
# Unit test for function main
def test_main():
    # Tests for positive result cases
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    # Tests for negative result cases
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")


# Generated at 2022-06-20 22:21:00.281767
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:21:01.521475
# Unit test for function main
def test_main():
    # Calls main()
    if __name__ == '__main__':
        main()

# Generated at 2022-06-20 22:21:05.745451
# Unit test for function main
def test_main():
    import mock
    import subprocess

    p = Mock(spec=subprocess.Popen)
    p.returncode = 1
    p.communicate.return_value = ['pong']
    p.delay = 1
    m = mock.Mock()
    with mock.patch('subprocess.Popen', m):
        m.return_value = p
        main()


# Generated at 2022-06-20 22:21:13.914901
# Unit test for function main
def test_main():
    import os
    import sys
    import subprocess
    # NOTE: we can't use the ansible modules here to avoid
    # a circular dependency with subprocess
    py_cmd = [sys.executable, "-c",
              "import json;"
              "print json.dumps(json.load(sys.stdin), indent=4, separators=(',', ': '))"]
    cmd = [ 'ansible', '-i', os.path.join('test','units','inventory'),
            '-m', 'ping', 'localhost']
    env = dict(os.environ)
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    output, errors = p.communicate()
    p.stdin.close()

# Generated at 2022-06-20 22:21:18.988465
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:21:21.453470
# Unit test for function main
def test_main():
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.basic import AnsibleModule

    with pytest.raises(removed_module):
        assert AnsibleModule()

# Generated at 2022-06-20 22:21:21.887787
# Unit test for function main
def test_main():
  assert True

# Generated at 2022-06-20 22:21:24.444002
# Unit test for function main
def test_main():
    import ansible_collections.ansible.builtin.plugins.module_utils.ansible_module_ping as under_test

    # test_main()
    # Test execution of 'main()'
    # check module invocation
    with pytest.raises(SystemExit):
        under_test.main()  # nosec

test_main()