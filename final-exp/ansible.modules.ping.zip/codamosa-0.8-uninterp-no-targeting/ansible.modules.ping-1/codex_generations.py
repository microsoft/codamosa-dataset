

# Generated at 2022-06-20 22:14:22.460517
# Unit test for function main
def test_main():
    result = dict(
        ping='pong',
    )
    assert main() == result

# Generated at 2022-06-20 22:14:27.602480
# Unit test for function main
def test_main():

    # simple execution test
    my_dict = dict(
        data="pong",
    )

    my_module = AnsibleModule(argument_spec=my_dict)
    assert(my_module.params == dict(data='pong'))

    # test with a parameter
    my_dict = dict(
        data="crash",
    )

    my_module = AnsibleModule(argument_spec=my_dict)
    assert(my_module.params == dict(data='crash'))
    try:
        main()
    except Exception as e:
        assert(str(e) == "boom")

# Generated at 2022-06-20 22:14:28.255720
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-20 22:14:28.660560
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:14:35.710324
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic
    from ansible.module_utils.basic import AnsibleModule


    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    #Test that main can be reached
    assert main() == None

# Generated at 2022-06-20 22:14:38.596682
# Unit test for function main
def test_main():
    class Args():
        data = 'pong'
    a = Args()
    assert getattr(a, 'data') == 'pong'

# Generated at 2022-06-20 22:14:41.425709
# Unit test for function main
def test_main():
    module = Mock(params={'data': 'pong'})
    exit_json = Mock()
    setattr(module, 'exit_json', exit_json)

    main()
    assert exit_json.call_args[0][0] == dict(ping='pong')



# Generated at 2022-06-20 22:14:46.903210
# Unit test for function main
def test_main():
    def test_data(data):
        module = mock.MagicMock()
        module.params = dict(data=data)
        with pytest.raises(Exception) as ex:
            main()
        assert str(ex.value) == "boom"

    test_data('crash')
    test_data('fault')
    test_data('boom')

# Generated at 2022-06-20 22:14:47.489398
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:14:57.341450
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # Test no arguments
    args = []
    if __name__ == '__main__':
        main()
    module = AnsibleModule(args=args)
    assert module.params['data'] == 'pong'

    # Test with arguments data=crash
    args = ['-a', 'data=crash']
    if __name__ == '__main__':
        main()
    module = AnsibleModule(args=args)
    assert module.params['data'] == 'crash'

    # Test with arguments data=pong
    args = ['-a', 'data=pong']
    if __name__ == '__main__':
        main()
    module = AnsibleModule(args=args)
    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:15:10.007524
# Unit test for function main
def test_main():
    module = MagicMock()
    module.params = {'data' : 'pong'}
    module.exit_json = MagicMock()
    module.exit_json.return_value = True
    result = main()
    expected_result = {'ping' : 'pong'}
    assert result == expected_result

# Generated at 2022-06-20 22:15:13.621204
# Unit test for function main
def test_main():
    a = {'data': 'crash'}
    try:
        main(a)
    except Exception as e:
        print(e)
        assert e.args[0] == 'boom'
    assert 1 == 1

# Generated at 2022-06-20 22:15:16.310175
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() is None

# Generated at 2022-06-20 22:15:20.521878
# Unit test for function main
def test_main():
    # Test creating a new ping module
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test the returned result was as expected
    assert m.params['data'] == 'pong'
    assert repr(main()) == "dict(ping='pong')"

# Generated at 2022-06-20 22:15:24.669943
# Unit test for function main
def test_main():
    import ansible.module_utils.basic

    with ansible.module_utils.basic.AnsibleModule.entry_point(provider_spec=dict(provider=dict()),
                                                              argument_spec=dict(data=dict(type='str', default='pong'))) as module:
        assert module.params == {}

        module.params = {}
        module.params['data'] = 'pong'
        assert {} == module.params

        module.fail_json('message', 'exception')
        module.exit_json('message', **{})
        module.run_command('/usr/bin/whoami')
        module.run_command('/usr/bin/whoami', check_rc=True)
        module.run_command('/usr/bin/whoami', use_unsafe_shell=True)



# Generated at 2022-06-20 22:15:31.695008
# Unit test for function main
def test_main():
    module = AnsibleModule(
      argument_spec=dict(
        data=dict(type='str', default='pong'),
      ),
      supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
      ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:33.683200
# Unit test for function main
def test_main():
    # Return value and message
    (data, message) = main()
    assert "pong" in data, message
    assert "crash" in message, message

# Generated at 2022-06-20 22:15:34.416754
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:15:40.285439
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params['data'] = 'crash'
    with pytest.raises(Exception) as e:
        main()
    module.params['data'] = 'pong'
    main()

# Generated at 2022-06-20 22:15:42.755723
# Unit test for function main
def test_main():
    args = dict(data=['foo'])
    result = main(args)
    assert result['ping'] == 'foo'
# EOF

# Generated at 2022-06-20 22:15:51.089495
# Unit test for function main
def test_main():
  main()

# Generated at 2022-06-20 22:15:53.354443
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-20 22:15:53.920423
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:15:58.438662
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )
    retval = dict(
        ping='pong',
        changed=True,
    )
    module = AnsibleModule(argument_spec=args)
    assert main(module) == retval

# Generated at 2022-06-20 22:16:01.846721
# Unit test for function main
def test_main():
    args = {
        'data': 'pong',
        'check_mode': True
    }
    module = AnsibleModule(argument_spec=dict(data=dict(type='str')))
    result = main()
    assert result['changed'] == False
    args['data'] = 'crash'
    result = main()
    assert result['changed'] == True
    module.fail_json(msg='foo', **result)
# -- Unit test for function main

# Generated at 2022-06-20 22:16:05.876473
# Unit test for function main
def test_main():
    # Create the module mock
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test the function main
    main(module)

# Generated at 2022-06-20 22:16:16.408985
# Unit test for function main
def test_main():
    import pytest
    import mock

    @mock.patch.object(AnsibleModule, 'exit_json')
    def test_success(mock_exit_json):
        module = mock.MagicMock()
        mock_module = mock.MagicMock()
        module.params = dict(
            data='pong',
        )
        mock_module.params = dict(
            data='pong',
        )

        main()

        module.exit_json.assert_called_once_with(ping='pong')
        mock_exit_json.assert_called_once_with(mock_module)

    @mock.patch.object(AnsibleModule, 'exit_json')
    def test_failure(mock_exit_json):
        module = mock.MagicMock()

# Generated at 2022-06-20 22:16:24.883569
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    # Test with no data parameter
    args = dict(
        _ansible_check_mode=False,
        _ansible_diff=False,
    )
    module = AnsibleModule(argument_spec={})
    assert main(module) == dict(ping='pong')

    # Test with data parameter
    args = dict(
        data='test data',
        _ansible_check_mode=False,
        _ansible_diff=False,
    )
    module = AnsibleModule(argument_spec=args)
    assert main(module) == dict(ping='test data')

# Generated at 2022-06-20 22:16:28.656458
# Unit test for function main
def test_main():

    # Test with default values
    input1 = { 'data': 'pong' }
    result = main(input1)

    assert result['ping'] == 'pong'

    # Test with custom values
    input2 = { 'data': 'crash' }
    # result = main(input2)
    # assert result['ping'] == 'crash'

# Generated at 2022-06-20 22:16:29.266599
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:16:47.719065
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert test_module.params['data'] == 'pong'

# Generated at 2022-06-20 22:16:57.434482
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule

  args = {
      'data': 'pong'
  }

  fake_module = AnsibleModule(
    argument_spec=dict(
        data=dict(type='str', default='pong'),
    ),
    check_invalid_arguments=False,
    bypass_checks=True,
  )

  fake_exited = False

  class FakeExitJson:
    def __init__(self, module):
      pass

    def __call__(self, **kwargs):
      fake_exited = True

  class FakeFailJson:
    def __call__(self, **kwargs):
      pass

  fake_module.exit_json = FakeExitJson(module=fake_module)
  fake_module.fail_json = FakeFailJ

# Generated at 2022-06-20 22:17:10.322708
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.builtin.tests._private import load_fixture
    from ansible.compat.tests.mock import patch

    def get_tmp_path(filename):
        return os.path.join(tempfile.gettempdir(), filename)

    m_tmp_path = get_tmp_path('mock_ansible_module')
    fname = get_tmp_path('test.yml')
    with open(fname, 'wb') as f:
        f.write(to_bytes(load_fixture('test_ping.yml'), errors='surrogate_or_strict'))


# Generated at 2022-06-20 22:17:10.921508
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:17:18.977186
# Unit test for function main
def test_main():
    def test_main_data(mocker, monkeypatch, data):
        import ansible.module_utils.basic
        assert ansible.module_utils.basic.AnsibleModule


        class TestAnsibleModule:
            def __init__(self):
                self._results = dict()
                self.params = dict()
            def exit_json(self, **kwargs):
                self._results = kwargs

            def fail_json(self, msg, **kwargs):
                self._results = dict(failed=True, msg=msg)


        test_obj = TestAnsibleModule()
        monkeypatch.setattr(ansible.module_utils.basic, "AnsibleModule", lambda **kwargs: test_obj)


# Generated at 2022-06-20 22:17:23.210028
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert(main() == module.exit_json(**{ "ping": "pong" }))

# Generated at 2022-06-20 22:17:24.450117
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-20 22:17:35.910817
# Unit test for function main
def test_main():
    # Imports inside the unit test function in order to ensure that
    # the base module is not installed and cached when the unit test
    # is run individually.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson

    import ansible.module_utils.ping as ping

    # Setup a mock for the AnsibleModule object
    mMockAnsibleModule = mock.MagicMock()

    # Setup the default arguments that would get passed to AnsibleModule
    module_args = dict()

    # create instance of AnsibleModule object
    instance = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # Create a mock for the decorated function using

# Generated at 2022-06-20 22:17:45.140787
# Unit test for function main
def test_main():
    with mock.patch.object(AnsibleModule, 'exit_json') as exit_json:
        with mock.patch.object(AnsibleModule, 'run_command') as run_command:
            main()
            exit_json.assert_called_once_with(
                ansible_facts=dict(
                    ansible_ping = 'pong'
                ),
                changed=False,
                invocation=dict(
                    module_args=dict(
                        data='pong'
                    )
                ),
                ping='pong'
            )

# Generated at 2022-06-20 22:17:49.022237
# Unit test for function main
def test_main():
    # needs to be called with a argument
    # module.params['data'] = 'crash'

    # needs to be called with a argument
    # module.params['data'] = 'pong'

    # needs to be called with a argument
    # module.params['data'] = 'boom'

    pass

# Generated at 2022-06-20 22:18:31.437070
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    ping_data = module.params['data']
    assert ping_data == module.params['data'], "Expected: %s, Actual: %s" % (ping_data, module.params['data'])

# Generated at 2022-06-20 22:18:42.033860
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.ping.ping import main as ping_main
    from ansible.module_utils.network.ping.ping import get_transport_connection

    connection = Connection('ssh')
    attrs = dict(
        module=basic.AnsibleModule(argument_spec=dict(
            data=dict(type='str', default='pong'),
        )),
        provider=load_provider(connection)
    )

# Generated at 2022-06-20 22:18:47.833362
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        module = AnsibleModule(argument_spec={"data": {"type": "str", "default":"pong"}})
        module.params["data"] = "crash"
        result = dict(ping=module.params["data"])
        assert result["ping"] == "pong"
        module.exit_json(**result)

# Generated at 2022-06-20 22:18:58.145274
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        ),
        supports_check_mode=True
    )
    data = module.params['data']
    result = dict(
        ping=module.params['data'],
    )
    # Check if the data is equal to 'pong'
    assert data == "pong"
    # Check if the result is a dictionary
    assert isinstance(result, dict)
    # Check if the result is equal to the expected result
    assert result == {'ping': 'pong'}

# Generated at 2022-06-20 22:19:06.477341
# Unit test for function main
def test_main():
    mock_module = Mock(return_value={})
    mock_module.params = {'data': 'pong'}
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        main()
        mock_exit_json.assert_called_once_with(ping=mock_module.params['data'])
    mock_module.params = {'data': 'crash'}
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        with raises(Exception) as err:
            main()
        assert str(err.value) == "boom"

# Generated at 2022-06-20 22:19:14.613186
# Unit test for function main
def test_main():

    my_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=my_module.params['data'],
    )

    assert my_module.params['data'] == 'pong'
    assert my_module.exit_json(**result)

# Generated at 2022-06-20 22:19:19.969525
# Unit test for function main
def test_main():
    test_fail = dict(ANSIBLE_MODULE_ARGS = dict(data='crash'))
    test_ping = dict(ANSIBLE_MODULE_ARGS = dict(data='pong'))
    with pytest.raises(Exception):
        main()
    with pytest.raises(SystemExit):
        main(test_ping)
    with pytest.raises(SystemExit):
        main(test_fail)

# Generated at 2022-06-20 22:19:22.864866
# Unit test for function main
def test_main():
    params = {
        'data': 'crash',
    }
    with pytest.raises(Exception) as excinfo:
        main()
    assert 'boom' in str(excinfo.value)

# Generated at 2022-06-20 22:19:25.273712
# Unit test for function main
def test_main():
  args = {'data': 'pong'}
  result = main(argv=args)
  if 'pong' in result.keys():
    print('Test passed')
  else:
    print('Test failed')

# Generated at 2022-06-20 22:19:33.438165
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:20:57.798588
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Unit testing
from ansible.module_utils import basic
from ansible.module_utils.common.dict_transformations import camel_dict_to_snake_dict


# Generated at 2022-06-20 22:21:03.268644
# Unit test for function main
def test_main():
    # Create dict with required args
    module_args = dict(
        data="pong",
    )
    result = dict(
        ping="pong",
    )
    with pytest.raises(Exception) as excinfo:
        main()
    # The exception message should be 'boom'
    assert "boom" in str(excinfo.value)

# Generated at 2022-06-20 22:21:08.618209
# Unit test for function main
def test_main():
  m = AnsibleModule(
      argument_spec=dict(
          data=dict(type='str', default='pong'),
      ),
      supports_check_mode=True
  )
  m.params = { 'data': 'crash' }
  m.exit_json = None
  with pytest.raises(Exception):
    main()
  m.params = { 'data': 'pong' }
  m.exit_json = lambda **kwargs: None
  main()


# Generated at 2022-06-20 22:21:09.337412
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:21:12.673534
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        main()
    except Exception as e:
        module.fail_json(msg='Test fatal: %s' % e)

# Generated at 2022-06-20 22:21:22.829389
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    from ansible.module_utils._text import to_bytes, to_text
    import platform

    def get_exception():
        return Exception('This is a test exception')

    def get_platform_system(string):
        return "This is a test"

    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleModule, self).__init__(*args, **kwargs)
            self.params = {'data': 'pong'}

    m = TestAnsibleModule()
    m.exit_json = lambda x: x

# Generated at 2022-06-20 22:21:26.004296
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:21:36.691240
# Unit test for function main
def test_main():
    # Unit tests need to fix up sys.path to include the current directory as a
    # package location so that we can import our test modules.
    import sys
    import os.path
    sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

    import ansible.module_utils.basic
    import ansible_collections
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    from ansible.module_utils.basic import AnsibleModule
    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:21:46.092061
# Unit test for function main
def test_main():

    # for this test, we are going to modify the module itself, but first
    # we need to grab the original.  This hacky way is the only way I could
    # figure out to do it.
    import ansible.builtin.ping
    realmain = ansible.builtin.ping.main

    # now swap out the main function with our own, remember, this is a closure
    # so we can access our main function above
    ansible.builtin.ping.main = main

    # set up the basic args and kwargs needed to call our main function
    args = ()
    kwargs = {'argument_spec': dict(data=dict(type='str', default='pong'))}


# Generated at 2022-06-20 22:21:47.266278
# Unit test for function main
def test_main():
    args = {
        "data": "pong"
    }
    main(args)