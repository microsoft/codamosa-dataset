

# Generated at 2022-06-20 22:14:23.165817
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    module.exit_json(changed=True, meta=module.params)

# Generated at 2022-06-20 22:14:29.448436
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Mock module.exit_json()
    def exit_json(**kwargs):
        results.update(kwargs)
    module.exit_json = exit_json

    # Mock module.fail_json()
    def fail_json(msg):
        results['failed'] = True
        results['msg'] = msg
        exit_json(**results)
        assert False
    module.fail_json = fail_json

    # Mock module.params.get()
    def mock_get(name):
        return results['params'][name]
    module.params.get = mock_get
    # Mock module.params.__getitem__()


# Generated at 2022-06-20 22:14:35.221072
# Unit test for function main
def test_main():
    # Test we can logon to 'webservers' and execute python with json lib.
    # ansible webservers -m ping
    p = {'ANSIBLE_MODULE_ARGS': {}}
    res = execute_main(p)
    assert(res['ping'] == 'pong')



# Generated at 2022-06-20 22:14:36.274785
# Unit test for function main
def test_main():
    assert main()['ping'] == 'pong'

# Generated at 2022-06-20 22:14:38.041113
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-20 22:14:39.883280
# Unit test for function main
def test_main():
    import ansible.module_utils.common.removed as removed
    assert removed.main() == False  # we want to return False not None

# Generated at 2022-06-20 22:14:50.138507
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    ansible_options = os.environ.get('ANSIBLE_MODULE_ARGS', '')
    args = {}
    if ansible_options:
        args.update(eval(ansible_options))
    args.update({'ANSIBLE_MODULE_ARGS': ansible_options})
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")

# Generated at 2022-06-20 22:14:51.948915
# Unit test for function main
def test_main():
    # no arguments.  just return
    assert (main() == None)

# Generated at 2022-06-20 22:14:54.385551
# Unit test for function main
def test_main():
    argv = ["/bin/ansible-ping","-a", "ping"]
    with pytest.raises(SystemExit):
        main(argv)

'''
$ python ansible_ping
'''

# Generated at 2022-06-20 22:15:03.009829
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Simulate main()
    try:
        main()
    except Exception as e:
        # main() raises an exception if data == crash
        if module.params['data'] == 'crash':
            assert str(e) == 'boom'
        else:
            raise e


# Generated at 2022-06-20 22:15:11.597643
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:15:20.459698
# Unit test for function main
def test_main():

    # Set ansible_module_args
    ansible_module_args = {}

    # Set module and results
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    results = dict()

    # Set result for module.exit_json (in main)
    results['ping'] = module.params['data']

    # Test main() with -vvv
    import sys
    import os
    if len(sys.argv) == 1:
        sys.argv.append('-vvv')
    if sys.version_info[:2] <= (2, 7):
        import __builtin__
        builtins = __builtin__
    else:
        import builtins
    builtins.H

# Generated at 2022-06-20 22:15:22.240522
# Unit test for function main
def test_main():
    assert test_ping.main() == None


# Generated at 2022-06-20 22:15:26.793971
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import json
    import pytest
    from ansible.module_utils import basic

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False)

    # Create a passing argument
    passing_arg = list()
    passing_arg.append("-m")
    passing_arg.append("ansible.builtin.ping")
    passing_arg.append("-a")
    passing_arg.append("data=pong")

    # Create a failing argument
    failing_arg = list()
    failing_arg.append("-m")
    failing_arg.append("ansible.builtin.ping")
    failing_arg.append("-a")
    failing_arg.append("data=crash")

    # Call the main function with arguments
    assert main

# Generated at 2022-06-20 22:15:27.440804
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:15:37.207830
# Unit test for function main
def test_main():
  ansible_mock = AnsibleModule(argument_spec={
      'data': {'type': 'str', 'default': 'pong'}
  }, supports_check_mode=True)

  def run_main():
    try:
      main()
    except Exception:
      return False
    return True

  # Test with `data` parameter set to 'crash'
  ansible_mock.params['data'] = 'crash'
  assert run_main() == False

  # Test with `data` parameter set to 'pong' (default value)
  ansible_mock.params['data'] = 'pong'
  assert run_main() == True

# Generated at 2022-06-20 22:15:44.120692
# Unit test for function main
def test_main():
    '''
    This function is used for testing the main function in the module 'ping'.
    '''
    host = "webservers"
    data = ""
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    print(result)
test_main()

# Generated at 2022-06-20 22:15:51.678075
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    assert result == dict(
        ping="pong",
    )

# Generated at 2022-06-20 22:16:03.891196
# Unit test for function main
def test_main():
    ping_data = dict(data='pong')
    ping_answer = dict(ping = 'pong')
    ping_m = AnsibleModule(ping_data)
    assert ping_answer == main(ping_m)

    # Try crashing once
    ping_data = dict(data='crash')
    ping_m = AnsibleModule(ping_data)
    try:
        main(ping_m)
    except:
        pass
    else:
        assert False

    # Try crashing twice
    ping_data = dict(data='crash')
    ping_m = AnsibleModule(ping_data)
    try:
        main(ping_m)
    except:
        pass
    else:
        assert False

    # Try crashing thrice
    ping_data = dict(data='crash')

# Generated at 2022-06-20 22:16:11.500272
# Unit test for function main
def test_main():
    test_args = []

    with mock.patch('ansible.module_utils.basic.AnsibleModule') as mock_module:
        with mock.patch('ansible.module_utils.basic.exit_json') as mock_exit:
            test_module = mock_module.return_value
            test_module.params = {}

            main()

            mock_exit.assert_called_once_with(ping='pong')
            test_module.fail_json.assert_not_called()


# Generated at 2022-06-20 22:16:28.436848
# Unit test for function main
def test_main():
    data_path = os.path.join(os.path.split(os.path.dirname(__file__))[0],
                              'unit/data')

    # load test data
    data_file = os.path.join(data_path, 'main.json')
    with open(data_file, 'r') as f:
        test = json.load(f)

    # save args and kwargs for test cases
    input_args = test['input']['args']
    input_kwargs = test['input']['kwargs']
    output_args = test['output']['args']
    output_kwargs = test['output']['kwargs']

    # set up module

# Generated at 2022-06-20 22:16:33.807570
# Unit test for function main
def test_main():
    print("")
    # Assume ping module in current dir, invoked as "/home/travis/virt/ansible/hacking/test-module -m ping"
    module_args = dict(
        data='pong',
    )
    # run the function
    main()

# Generated at 2022-06-20 22:16:44.377365
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    import json
    with open('payload.json') as payload:
        p = json.load(payload)
        module_args = dict(
            data='pong'
        )
        result = dict(
            ping='pong'
        )

        # Configure the parameters that would be returned by querying the
        # remote device
        ansible_module_mock = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=False
        )
        ansible_module_mock.params = module_args
        # Override methods to force specific logic in the module to happen
        basic.AnsibleModule.exit

# Generated at 2022-06-20 22:16:49.251234
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result == {'ping': 'pong'}

# Generated at 2022-06-20 22:17:01.444344
# Unit test for function main
def test_main():
    request_data = {'params': {'data': 'pong'}, 'argument_spec': dict(data=dict(type='str', default='pong'))}
    with patch.object(AnsibleModule, '__init__', return_value=None) as mock_module:
        with patch.object(AnsibleModule, 'exit_json', return_value=None) as mock_exit_json:
            mock_module.return_value.params = request_data['params']
            mock_module.return_value.argument_spec = request_data['argument_spec']
            main()
            assert mock_module.return_value.params == request_data['params']
            assert mock_module.return_value.argument_spec == request_data['argument_spec']
            assert mock_exit_json.call_count == 1


# Generated at 2022-06-20 22:17:05.830277
# Unit test for function main
def test_main():
    argv = ['main.py']
    argv.append('--data=pong')
    main(argv)
    argv.append('--data=crash')
    main(argv)
    argv.append('--check')
    main(argv)

# Generated at 2022-06-20 22:17:15.957450
# Unit test for function main
def test_main():

    import os
    import tempfile
    loader, inventory, variable_manager = ansible_test.get_test_loader_inventory_variable_manager(None, {})
    with tempfile.NamedTemporaryFile('w+') as f:
        f.write('''
{
  "ping": "pong"
}
        ''')
        f.flush()
        f.seek(0)
        stdout = f.name
        module = ansible.module_utils.basic.AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )

# Generated at 2022-06-20 22:17:27.157312
# Unit test for function main
def test_main():
    data = {
        'ansible_check_mode': False,
        'ansible_diff': False,
        'ansible_facts': {
            'discovered_interpreter_python': '/usr/bin/python3',
            'gather_subset': [
                'all'
            ]
        },
        'ansible_module_name': 'ping',
        'ansible_version': {
            'full': '2.9.13',
            'major': 2,
            'minor': 9,
            'revision': 13,
            'string': '2.9.13'
        },
        'changed': False,
        'failed': False
    }

    assert data == main()

# Generated at 2022-06-20 22:17:34.348693
# Unit test for function main
def test_main():
    from ansible.modules.network.ping import main
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = main(module)

    fields = ['ping']

    for field in fields:
        assert result.has_key(field)
        #assert result[field] == 'pong'

# Generated at 2022-06-20 22:17:37.121251
# Unit test for function main
def test_main():
  try:
    test_module = AnsibleModule(argument_spec = dict(
        data = dict(type = 'str', default = 'pong')
    ))
    main()
  except Exception:
    assert False

# Generated at 2022-06-20 22:18:03.750997
# Unit test for function main
def test_main():
    import copy
    import sys
    import os
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    mock_stdin_patch = patch('sys.stdin', new=MagicMock(spec=sys.stdin))
    mock_stdin_patch.start()
    mock_sys_module_patch = patch('sys.modules', MagicMock())
    mock_sys_module_patch.start()
    mock_os_module_patch = patch('os.path', MagicMock())
    mock_os_module_patch.start()
    mock_open_patch = patch('__builtin__.open', new=MagicMock(spec=open))
    mock_open_patch.start()
    main()
    mock_stdin_patch

# Generated at 2022-06-20 22:18:10.885674
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test that we get the correct result when a non-exception
    # is returned by ping
    assert dict(
        ping='pong',
        changed=False
    ) == main()

    try:
        main(data='crash')
    except Exception:
        pass
    else:
        assert False, "Exception not raised for data=crash"

# Generated at 2022-06-20 22:18:15.856982
# Unit test for function main
def test_main():
    print(__name__)
    print("Unit test: function main")
    # Call function
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    main()


# Generated at 2022-06-20 22:18:24.148638
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import argparse
    import unittest

    class MockArgs(object):
        def __init__(self, args):
            self.args = args

        def __getattr__(self, name):
            try:
                return self.args[name]
            except KeyError:
                raise AttributeError

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def exit_json(self, result, **kwargs):
            self.exit_json_called = True
            self.exit_json_result = result

        def exit_failure(self, **kwargs):
            self.exit_failure_called = True


# Generated at 2022-06-20 22:18:26.690351
# Unit test for function main
def test_main():
    # If you unit test this function, please add the argument data to your unit test.
    # This is required for compatibility for Ansible 2.11
    assert main(data='pong') == dict(ping='pong')

# Generated at 2022-06-20 22:18:27.495390
# Unit test for function main
def test_main():
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:18:32.448806
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert test_module.params['data'] == 'pong'
    assert test_module.supports_check_mode == True

# Generated at 2022-06-20 22:18:33.041495
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:18:39.654181
# Unit test for function main
def test_main():
    # default_data
    from ansible.module_utils.basic import AnsibleModule
    import ansible.modules.system.ping as ping

    print("---default_data---")
    new_module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    ping.main()


# Generated at 2022-06-20 22:18:49.787609
# Unit test for function main
def test_main():
   with patch('ansible_collections.ansible.builtin.plugins.modules.ping.AnsibleModule') as mock_AnsibleModule:
      with patch('ansible_collections.ansible.builtin.plugins.modules.ping.main') as mock_main:
        mock_AnsibleModule.return_value = mock_module
        mock_main.return_value = mock_exit_json
        mock_module.params = VALID_PARAMS_FOR_PRESENT
        ping.main()
        assert [call.exit_json(ansible_facts=dict(ping='pong'))] == mock_exit_json.mock_calls
# ansible-playbook ping.yml --check

# Generated at 2022-06-20 22:19:24.571482
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping='pong',
    )
    test_module.exit_json(**result)

# Generated at 2022-06-20 22:19:30.586957
# Unit test for function main
def test_main():
    import sys
    import json
    import os
    import re
    import contextlib
    from ansible.module_utils.basic import AnsibleModule

    with contextlib.redirect_stdout(open(os.devnull, 'w')):
        with contextlib.redirect_stderr(open(os.devnull, 'w')):
            orig_load_ansible_module = AnsibleModule.load_ansible_module

            # We are going to patch AnsibleModule.load_ansible_module to return
            # our result for this function

# Generated at 2022-06-20 22:19:41.569626
# Unit test for function main
def test_main():
    import os
    import tempfile
    # test empty parameter
    module_args = {'data': ''}
    # make JSON out of it
    module_args_json = module_args.copy()
    for key, value in module_args.items():
        module_args_json[key] = json.dumps(value)

    # make a temporary file to store the result
    handle, path = tempfile.mkstemp()
    os.close(handle)

    # generate a raw ansible-playbook command
    cmd = 'ansible-playbook -i localhost, --limit localhost /etc/ansible/library/ping.py'
    # append the parameters
    cmd += ' '.join(['"' + key + '=' + module_args_json[key] + '"'])
    # execute the command and get the output


# Generated at 2022-06-20 22:19:46.882894
# Unit test for function main
def test_main():
    test_module_path = 'ansible/modules/system/ping.py'
    ping_module = imp.load_source('ansible_ping', test_module_path)

    # Test ping action
    data = 'crash'
    try:
        ping_module.main()
        assert False
    except:
        assert True

# Generated at 2022-06-20 22:19:51.530526
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Should exit normally with pong
    main()
    # Should exit with error when data is crash
    main(module.params['data'] == 'crash')

# Generated at 2022-06-20 22:19:57.055414
# Unit test for function main
def test_main():
    import pytest
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    with pytest.raises(Exception) as excinfo:
        main()
    assert excinfo.type == Exception
    assert 'boom' in excinfo.value.args

# Generated at 2022-06-20 22:20:06.209110
# Unit test for function main
def test_main():
    function_args = dict()
    function_args['data'] = 'pong'

    module_args = dict(function_args)
    module_args['check_mode'] = True

    result = dict(
        changed=False,
        ping='pong',
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json(**result)

    assert result == {'changed': False, 'ping': 'pong'}


# Generated at 2022-06-20 22:20:10.458129
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert result == dict(ping='pong')

# Generated at 2022-06-20 22:20:14.953726
# Unit test for function main
def test_main():
    data = dict(
        data=dict(type='str', default='pong'),
    )

    if data['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=data['data'],
    )

    module.exit_json(**result)

if __name__ == '__main2__':
    test_main()

# Generated at 2022-06-20 22:20:21.260479
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

test_main()

# Generated at 2022-06-20 22:21:55.440988
# Unit test for function main
def test_main():
    # Unit test for function main (replace module_utils/basic.py with a mock)
    from ansible.module_utils import basic
    import sys

    # Mock
    class MockAnsibleModule(dict):
        def __init__(self, argument_spec, **kwargs):
            self.argument_spec = argument_spec
            self.exit_json = dict.pop("exit_json", lambda self, **kwargs: sys.exit(0))
            self.fail_json = dict.pop("fail_json", lambda self, **kwargs: sys.exit(1))
            self.__dict__.update(kwargs)

        def exit_json(self, **kwargs):
            self.__class__.exit_json(self, **kwargs)

        def fail_json(self, **kwargs):
            self.__class

# Generated at 2022-06-20 22:21:55.996191
# Unit test for function main
def test_main():
	pass

# Generated at 2022-06-20 22:22:05.460379
# Unit test for function main
def test_main():
    import json

    _mock_module = type('AnsibleModule', (), dict(exit_json=lambda self, **kwargs: print(json.dumps(kwargs)),
                                                  fail_json=lambda self, **kwargs: print(json.dumps(kwargs))))

    _mock_module.params = dict(data='pong')

    def _mock_exit_json(self, **kwargs):
        print(json.dumps(kwargs))

    _mock_module.exit_json = _mock_exit_json
    _mock_module.fail_json = lambda **kwargs: print(json.dumps(kwargs))

    main()
    main()
    main()

# Generated at 2022-06-20 22:22:10.674761
# Unit test for function main
def test_main():
  data = {}
  data['ANSIBLE_MODULE_ARGS'] = {}
  
  module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)

  data['ANSIBLE_MODULE_ARGS']['delete'] = ''
  result = None
  with pytest.raises(Exception) as excinfo:
      result = main()
  assert 'boom' in str(excinfo.value)

# Generated at 2022-06-20 22:22:19.164635
# Unit test for function main
def test_main():
    # test with good input
    data = dict(
        data='pong',
        check_mode=False
    )
    m = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    m.params = data
    assert main() == m.exit_json(**dict(ping=data['data']))

    # test with bad input
    data = dict(
        data='bad',
        check_mode=False
    )
    m = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    m.params = data
    assert main() == m.fail_json(msg='boom')

# Generated at 2022-06-20 22:22:19.943146
# Unit test for function main
def test_main():
  main()

# Generated at 2022-06-20 22:22:25.465843
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert test_module.params['data'] == 'pong'

test_main()

# Generated at 2022-06-20 22:22:30.947568
# Unit test for function main
def test_main():
    post_data = {
        'data': 'pong',
    }
    post_json = json.dumps(post_data)
    m = AnsibleModule(json.loads(post_json))
    m._ansible_diff = False
    m.check_mode = True
    m._connection.check_mode = True
    main()

    module.exit_json(**result)


# Generated at 2022-06-20 22:22:36.048757
# Unit test for function main
def test_main():
    mock = Mock()
    mock.params = {'data': 'pong', 'changed': False}
    main(mock)
    mock.exit_json.assert_called_with({'ping': 'pong'})
    mock.params = {'data': 'crash', 'changed': False}
    main(mock)
    mock.fail_json.assert_called_with(msg='Exception: boom', exception=exception('boom'))

import unittest
from mock import Mock, patch, sentinel


# Generated at 2022-06-20 22:22:37.917438
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    result = dict(ping='pong')
    module.exit_json(**result)
