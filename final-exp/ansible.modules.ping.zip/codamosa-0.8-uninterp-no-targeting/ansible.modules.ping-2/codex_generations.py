

# Generated at 2022-06-20 22:14:20.442583
# Unit test for function main
def test_main():
    test_module(dict(data='pong'), 'unittest.json', assert_type='dict')

# Generated at 2022-06-20 22:14:30.001475
# Unit test for function main
def test_main():
    connection = AnsibleConnection(None, None, None)
    connection.host = 'test_host'
    connection.port = 999

    module = AnsibleModuleMock('ansible.builtin.ping',
        connection, {'data': 'pong'},
        check_mode=True)
    assert module.params['data'] == 'pong'

    module = AnsibleModuleMock('ansible.builtin.ping',
        connection, {'data': 'crash'},
        check_mode=True)
    assert module.params['data'] == 'crash'

# Generated at 2022-06-20 22:14:41.225933
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.tests.unit.compat import unittest


    def mocked_run_command(module, args, check_rc=True, close_fds=True, executable=None, data=None):
        if 'ping' in args:
            return "", 0, None
        else:
            rc = 255
            if 'pong' in args:
                rc = 0
            return "", rc, None

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class ModuleMock():
        def __init__(self, *args, **kwargs):
            self.params = kwargs


# Generated at 2022-06-20 22:14:47.409061
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:14:56.871372
# Unit test for function main
def test_main():
    print("test_main")
    class MockModule(object):
        def __init__(self, name):
            self.name = name
        def exit_json(self, **kw):
            print("exit_json called with kw=%s", kw)
        def fail_json(self, **kw):
            print("fail_json called with kw=%s", kw)
            assert False
        def params(self, key):
            if key == "data":
                return "pong"
            assert False
    class MockAnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode):
            print("MockAnsibleModule init with spec %s", argument_spec)
            self.argument_spec = argument_spec

# Generated at 2022-06-20 22:15:03.009304
# Unit test for function main
def test_main():
    test_module = ansible_module_ping

    from ansible.module_utils.basic import AnsibleModule

    test_module.AnsibleModule = AnsibleModule

    module_args = {}
    if module_args is False:
        module_args = {}

    set_module_args(module_args)

    main()

# Generated at 2022-06-20 22:15:04.914298
# Unit test for function main
def test_main():
    args = dict(data="pong")
    result = main(args)
    assert result == {'ping': 'pong'}

# Generated at 2022-06-20 22:15:06.692077
# Unit test for function main
def test_main():
    result = main('', '', '', '', '')
    assert {'ping': 'pong'} == result


# Generated at 2022-06-20 22:15:07.195991
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:15:17.661354
# Unit test for function main
def test_main():
    import io
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    try:
        out = io.StringIO()
        sys.stdout = out
        sys.stderr = out
        with pytest.raises(SystemExit) as pytest_wrapped_e:
            main()
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == 0
        result = out.getvalue().rstrip('\n')
        assert result == '{"changed": false, "ping": "pong"}'
    finally:
        sys.stdout.close()
        sys.stdout = orig_stdout

# Generated at 2022-06-20 22:15:31.644164
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    success = dict(
        changed=False,
        ping='pong'
    )
    fail = dict(
        msg='boom'
    )

    # Success
    result = main()
    assert result.exit_json == success

    # Failure
    module.params['data'] == 'crash'
    result = main()
    assert result.fail_json == fail

# Generated at 2022-06-20 22:15:33.999617
# Unit test for function main
def test_main():
    test_dict = dict()
    test_dict['data'] =  'pong'
    result = main(test_dict)
    assert result['ping'] == 'ping'

# Generated at 2022-06-20 22:15:45.110181
# Unit test for function main
def test_main():
    import sys
    import json
    import pytest

    # Hack to load unittest2 on Python2.6
    if sys.version_info < (2, 7):
        try:
            import unittest2 as unittest
        except ImportError:
            pytest.skip("unittest2 is required to run the tests with python2.6")
    else:
        import unittest

    class TestModule(unittest.TestCase):
        def setUp(self):
            self.raw_module_args = dict(data='pong')
            self.module = AnsibleModule(argument_spec=dict(
                data=dict(type='str', default='pong'),
            ), supports_check_mode=True)
            self.module._ansible_diff = False

        def test_ping(self):
            self

# Generated at 2022-06-20 22:15:50.730097
# Unit test for function main
def test_main():
    args = dict(
        data='crash',
    )

    # Fail module if exception not raised
    with pytest.raises(Exception) as excinfo:
        main()
    assert 'boom' in str(excinfo.value)

    # We should not get this far
    assert False

# Generated at 2022-06-20 22:15:56.815479
# Unit test for function main
def test_main():
    # Test data for function main
    tests = [
        {
            'params': {
                'data': 'pong',
            },
            'response': {
                'ping': 'pong',
            },
        },
    ]

    for test in tests:
        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
        module.params = test['params']
        main()
        assert module.params == test['response']

# Generated at 2022-06-20 22:16:05.734340
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = module.params(data='crash')
    #print(result)
    
    if module.params['data'] == 'crash':
        try:
            raise Exception("boom")
        except Exception as ex:
            # print(ex)
            assert(ex=="boom")
    
    result = dict(
        ping=module.params['data'],
    )
    assert(result['ping']=='crash')


# Generated at 2022-06-20 22:16:12.979694
# Unit test for function main
def test_main():
    import json
    data = dict(
        ANSIBLE_MODULE_ARGS=dict(
            data='pong'
        )
    )
    setattr(__builtins__, '__ansible_module_mock', True)
    d = dict(
        ping='pong',
        rc=0,
        stdout='',
        stderr='',
        changed=False
    )
    json.loads = lambda x: d
    with pytest.raises(Exception) as e:
        main()
    assert e.value.args[0] == 'boom'
    data = dict(
        ANSIBLE_MODULE_ARGS=dict(
            data='crash'
        )
    )
    setattr(__builtins__, '__ansible_module_mock', True)
   

# Generated at 2022-06-20 22:16:17.185900
# Unit test for function main
def test_main():
    mod_args = dict(
        data='pong'
    )
    module = AnsibleModule(
        argument_spec=mod_args,
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    result = dict(
        ping='pong'
    )
    module.exit_json(**result)

# Generated at 2022-06-20 22:16:18.152980
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 22:16:24.680991
# Unit test for function main
def test_main():
    output = dict(ping='pong')
    res_args = dict(
                changed=False,
                ping='pong',
        )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    module.exit_json(**output)
    #assert result == res_args

# Generated at 2022-06-20 22:16:33.481762
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:16:39.677675
# Unit test for function main
def test_main():
    hostname = 'localhost'
    data = 'pong'

    # Test with no argument - it should fail
    result = main()
    assert result['failed']

    # Test with a wrong data
    data = 'wrong data'
    with pytest.raises(Exception):
        assert result['changed'] == True
        assert result['ping'] == data

    # Test with a good data
    data = 'pong'
    assert result['ping'] == data

# Generated at 2022-06-20 22:16:50.236864
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == test_module.exit_json(**result)

# Generated at 2022-06-20 22:17:02.844254
# Unit test for function main
def test_main():
    import os
    import pytest
    import tempfile
    import json

    # AnsibleModule arguments
    argument_spec = {'data': {'default': 'pong', 'type': 'str'}}
    # AnsibleModule return values
    return_values = {'ping': 'pong'}
    # AnsibleModule side effect values
    side_effects = {}

    # AnsibleModule arguments
    argument_spec = {'data': {'default': 'pong', 'type': 'str'}}
    # AnsibleModule return values
    return_values = {'ping': 'pong'}
    # AnsibleModule side effect values
    side_effects = {}

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp file

# Generated at 2022-06-20 22:17:12.779462
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    created_module = AnsibleModule({
        'argument_spec': {
            'data': {'type': 'str', 'default': 'pong'},
        },
        'supports_check_mode': True
    })

    try:
        # Run the main function
        main()

        assert False, 'No exception raised'
    except SystemExit as e:
        # The main function ends up calling a submodule that exits the program.  Catch the exit so that we can check the results
        pass

    assert created_module.params['data'] == 'pong'

# Generated at 2022-06-20 22:17:17.226376
# Unit test for function main
def test_main():

    # test crash
    my_args = dict(data='crash')
    with pytest.raises(Exception):
        main()

    # test default
    my_args = dict()
    result = main()
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:17:29.855634
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    def ANSIBLE_MODULE_UTILS_basic():
        module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)
        module.exit_json(changed=False, ansible_facts=facts)
    def ansible_module_exit_json():
        global module
        module.exit_json(changed=False, meta=result)
    def ansible_module_fail_json():
        global module
        module.fail_json(msg='You requested this to fail', **result)

# Generated at 2022-06-20 22:17:35.776868
# Unit test for function main
def test_main():

    ping_test = {"data": "test"}

    mock_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    mock_module.params = ping_test
    result = dict(
        ping=mock_module.params['data'],
    )

    assert result == dict(ping=ping_test["data"])

# Generated at 2022-06-20 22:17:48.031132
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.ping as module_utils_ping
    # Test with a normal return for ping
    data = {
        'ansible_facts': {
            'foo': 'bar'
        },
        'changed': False,
        'ping': 'pong'
    }
    module_args = '{"ANSIBLE_MODULE_ARGS": {"data": "pong"}}'

# Generated at 2022-06-20 22:17:49.340244
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:18:06.793012
# Unit test for function main
def test_main():
    print("Nothing to test")

# Generated at 2022-06-20 22:18:07.875119
# Unit test for function main
def test_main():
    assert main() == 'pong'

# Generated at 2022-06-20 22:18:17.806453
# Unit test for function main
def test_main():
    import pytest
    import ansible
    from ansible.cli.playbook import PlaybookCLI
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.basic import AnsibleModule

    playbook_cli = PlaybookCLI(['ansible-playbook', 'ansible/test_ping.yml', '-vvvv'])
    playbook_cli.parse()
    loader, inventory, variable_manager = playbook_cli._play_prereqs()
    all_vars = variable_manager._extra_vars = {'ansible_python_interpreter': '/usr/bin/python'}
    # Get the object which will be used to load the module
    from ansible.compat.six import PY3
    import os
    import sys
    import imp
    basedir

# Generated at 2022-06-20 22:18:25.567126
# Unit test for function main
def test_main():
    def fake_AnsibleModule(spec, grp):
        return {
            'mock_spec': spec,
            'mock_grp': grp,
            'params': {
                'data': 'xxx',
            },
            'exit_json': lambda **kwargs: None,
        }

    # Function to be tested
    from ansible.modules.system import ping as ping

    # Patcher for function AnsibleModule
    from unittest.mock import patch
    from functools import partial
    AnsibleModule_patch = patch('ansible.modules.system.ping.AnsibleModule', partial(fake_AnsibleModule))
    AnsibleModule_patch.start()
    # main() testing

# Generated at 2022-06-20 22:18:26.433998
# Unit test for function main
def test_main():
    # Call function main
    main()

# Generated at 2022-06-20 22:18:32.228811
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # test data=crash
    with pytest.raises(Exception):
        main()

    # test data=pong
    main()

# Generated at 2022-06-20 22:18:42.748804
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.common.dict_transformations
    
    class FakeModule:
        def __init__(self):
            self.exit_json = ansible.module_utils.basic.AnsibleModule.exit_json
            self.fail_json = ansible.module_utils.basic.AnsibleModule.fail_json
    
            class FakeAnsibleModule:
                PARSED_ARGUMENTS = {
                    'data': 'pong'
                }
            
                def __init__(self):
                    self.params = ansible.module_utils.common.dict_transformations.map_keys(
                            FakeAnsibleModule.PARSED_ARGUMENTS
                        )
        
            self.ansible_module = FakeAnsibleModule

# Generated at 2022-06-20 22:18:51.733418
# Unit test for function main
def test_main():
    """
    Code to be run for unit tests
    """

    # Set the module to run directly
    setattr(sys.modules[__name__], '__name__', '__main__')

    from io import StringIO
    from ansible.module_utils import basic

    # Set the USER environment variable for AnsibleModule
    os.environ['USER'] = 'nobody'

    # Set the ARGV environment variable for AnsibleModule
    sys.argv = ['ansible-test', 'ping', '-vvv',
             '--data', 'crash']

    # Create a string buffer to hold the stdout
    stdout = StringIO()

    # Catch any exception and return the code
    rc = 1

# Generated at 2022-06-20 22:19:04.086536
# Unit test for function main
def test_main():

    # function parametrization
    call_params = {'data': 'crash'}

    # mocking module return values
    mock_AnsibleModule = MagicMock()
    instance = mock_AnsibleModule.return_value
    instance.params = {'data': 'crash'}
    instance.check_mode = False

    # function import
    from ansible.modules.system.ping import main

    # call function
    try:
        main()
    except:
        pass

    # check if the expected exception type was raised
    assert mock_AnsibleModule.assert_called_once_with()
    assert instance.exit_json.called == False
    assert instance.fail_json.called == True
    call_args, call_kwargs = instance.fail_json.call_args

# Generated at 2022-06-20 22:19:09.320352
# Unit test for function main
def test_main():
    def mock_exists(path):
        return True

    def mock_open(path):
        return open(path, 'r')

    def mock_load_file(path):
        return open(path, 'r').read()

    class MockModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    def mock_get_bin_path(exe, required=True, opt_dirs=None):
        if exe == 'py':
            return '/usr/bin/python'
        elif exe == 'python':
            return '/usr/bin/python'

    mock_module = MockModule(
        data='test-data',
    )

    saved_import = __import__


# Generated at 2022-06-20 22:19:42.422755
# Unit test for function main
def test_main():
    # TODO: need unit test
    assert True

# Generated at 2022-06-20 22:19:53.396414
# Unit test for function main
def test_main():
    import __main__ as main
    test_module = main.__file__

    # Test the direct execution path of the module
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import json
    import sys

    args_string = "{\"ANSIBLE_MODULE_ARGS\": {\"data\": \"pong\"}}"
    new_stdin = basic._ANSIBLE_ARGS

    sys.argv = [test_module, to_bytes(args_string)]
    main()

    # Test the result of the direct execution path of the module
    result = json.loads(basic._ANSIBLE_ARGS)
    assert result['pong'] == "pong"

    # Test the functionality of the module
    from ansible.modules.ping import main
    basic._ANSIBLE_AR

# Generated at 2022-06-20 22:19:54.966076
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        assert False, e

# Generated at 2022-06-20 22:19:59.022303
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == module.exit_json(changed=False)

# Generated at 2022-06-20 22:20:02.514191
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong'),
    )
    supports_check_mode=True

    if args['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=args['data'],
    )

    module.exit_json(**result)
    assert result['ping'] == "pong"
    assert result['ping'] == "crash"

# Generated at 2022-06-20 22:20:05.238746
# Unit test for function main
def test_main():
    _m = Mock()
    _m.params = {'data':'pong'}
    main(_m)

# Generated at 2022-06-20 22:20:06.126672
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-20 22:20:06.658113
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:20:08.877644
# Unit test for function main
def test_main():
    test_data = dict(
        data='foo',
    )
    with pytest.raises(Exception, match='boom'):
        main(test_data)

# Generated at 2022-06-20 22:20:16.236872
# Unit test for function main
def test_main():
    test_args = {'data': 'pong',
                 'check_mode': True}
    test_kwargs = {}

    result = main(test_args, test_kwargs)

    assert result[0] == True
    assert result[1] == {
        'ping': 'pong'
    }

    test_args = {'data': 'crash',
                 'check_mode': True}
    test_kwargs = {}

    with pytest.raises(Exception) as e_info:
        result = main(test_args, test_kwargs)
    assert 'boom' in str(e_info)

# Generated at 2022-06-20 22:21:52.528870
# Unit test for function main
def test_main():
    # Pass in a test_params dictionary with the data field set to "test"
    test_params = {"data": "test"}

    # Set a test_result dictionary containing the expected result
    test_result = {"ping": "test"}

    # Construct a fake AnsibleModule
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Set the params to the test_params we constructed above
    test_module.params = test_params

    # Run the function passing the AnsibleModule and the dictionary we constructed above
    main()

    # Check to see if the result we got back matches our expected result
    assert test_module.exit_json.called
    assert test_module.exit_json.call_args == call(**test_result)



# Generated at 2022-06-20 22:21:55.020077
# Unit test for function main
def test_main():
  assert True

# Generated at 2022-06-20 22:21:55.907299
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:21:58.450915
# Unit test for function main
def test_main():
    # Check all vars are defined
    assert 'module' not in locals()

    # Check function behavior
    result = main()
    assert result is None

# Generated at 2022-06-20 22:22:03.177339
# Unit test for function main
def test_main():
    args = dict(data='pong')
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    response = main()
    assert response['ping'] == args['data']

# Generated at 2022-06-20 22:22:09.636472
# Unit test for function main
def test_main():
    import json
    data_in = dict(
        data='pong'
    )
    check_mode_in = True

    json_str = json.dumps(data_in)
    module = MockAnsibleModule(json_str)
    module.check_mode = check_mode_in

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-20 22:22:19.492055
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
        check_mode=True,
        diff=False
    )
    args = dict(args, **{
        'ANSIBLE_MODULE_ARGS': {
            'data': args['data']
        }
    })
    with patch('ansible_collections.ansible.builtin.plugins.modules.ping.AnsibleModule') as mock_am:
        mock_am_instance = mock_am.return_value
        mock_am_instance.params.return_value = args
        ansible_module_ping.main()
        print(mock_am_instance.fail_json.call_args_list)
        assert mock_am_instance.exit_json.call_args == call(
            ping='pong',
            changed=False
        )

# Generated at 2022-06-20 22:22:20.463947
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:22:21.974853
# Unit test for function main
def test_main():
    # TODO: Implement test_main()
    pass # nothing to test

# Generated at 2022-06-20 22:22:25.227995
# Unit test for function main
def test_main():
    args = dict(data='pong')
    obj = AnsibleModule(**args)
    assert main() == None