

# Generated at 2022-06-20 22:14:27.555313
# Unit test for function main
def test_main():
    from ansible.modules.builtin.ping import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    import pytest

    def do_test(data):

        m = AnsibleModule(argument_spec={})
        m.params = {'data': data}
        main()

        if data == 'crash':
            assert not m.exit_json.called
            assert m.fail_json.called
            assert 'unable to convert parameter to integer' in to_text(m.fail_json.call_args[0][1]).lower()
        else:
            assert m.exit_json.called
            assert dict(ping=data) == m.exit_json.call_args[0][0]

    # Happy path test

# Generated at 2022-06-20 22:14:27.955527
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 22:14:33.154303
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import json
    import sys
    
    # construct a fake pseudofile for stdin
    class PseudoFile(object):
        def __init__(self):
            self.data = json.dumps({
                "ANSIBLE_MODULE_ARGS": {
                    "data": "pong"
                }
            })
    
        def read(self):
            return self.data
    
    sys.stdin = PseudoFile()
    
    # construct a fake pseudofile for stdout
    class PseudoFile(object):
        def __init__(self):
            self.data = []
    
        def write(self, data):
            self.data.append(data)
    
        def read(self):
            return "".join(self.data)
    

# Generated at 2022-06-20 22:14:38.784801
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-20 22:14:39.372750
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:14:44.114467
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    argument_spec=dict(
        data=dict(type='str', default='pong'),
    )
    module = AnsibleModule(argument_spec=argument_spec)

# Generated at 2022-06-20 22:14:48.681211
# Unit test for function main
def test_main():
    # Test with crash
    result = dict(
        ping = 'pong'
    )

    # Test with crash
    result = dict(
        ping = 'crash'
    )

    # Test small string
    result = dict(
        ping = 'smol'
    )

    # Test small string
    result = dict(
        ping = ''
    )

# Generated at 2022-06-20 22:14:50.718397
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        assert main() == Exception("boom")

# Generated at 2022-06-20 22:14:55.689221
# Unit test for function main
def test_main():
    # See if function module.exit_json fails when called
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )
    assert result == main()

# Generated at 2022-06-20 22:15:08.072081
# Unit test for function main
def test_main():
    # Set up required arguments, as would be provided by AnsibleModule
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    )
    # This is a minimally-required result.  We could add more for each
    # checked output, but this suffices for simple tests.  (There are no
    # extra arguments in this module, so we don't need to check them.)
    result = dict(
        ping='pong',
    )

    # Test no changes
    module = AnsibleModule(argument_spec=argument_spec, supports_check_mode=True)
    assert module.exit_json(**result) == (
      {'changed': False, 'ping': 'pong'},
      []
    )

    # Test crash

# Generated at 2022-06-20 22:15:20.773641
# Unit test for function main
def test_main():
   # unit tests :
   import unittest
   class TestMain(unittest.TestCase):
       def setUp(self):
           self.mock_module = MagicMock()
           self.mock_module.params = { 'data': 'pong' }
           self.mock_module.exit_json = MagicMock()
           self.mock_module.fail_json = MagicMock()

       def test_pong(self):
           # Test the default case
           main()
           # Check if exit_json was called.
           self.assertTrue(self.mock_module.exit_json.called)
           self.assertFalse(self.mock_module.fail_json.called)
           # Check if exit_json was called with correct arguments.

# Generated at 2022-06-20 22:15:26.061602
# Unit test for function main
def test_main():
    data = dict(data = 'pong')
    result = dict(ping = 'pong')
    with pytest.raises(Exception) as e:
        main(data)
    assert "boom" in str(e.value)
    assert main(result) == dict(ping = 'pong')

# Generated at 2022-06-20 22:15:26.931249
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:15:28.220994
# Unit test for function main
def test_main():
    data = dict(
       data=dict(type='str', default='pong')
    )
    # Test real Ping
    ret = main()
    assert ret
    # Test Crash
    data[data] = "crash"
    # Test Exception
    assert main()

# Generated at 2022-06-20 22:15:38.843892
# Unit test for function main
def test_main():
    #unit test for module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)
    #unit test for class
    class fake_module(object):
        argument_spec = dict(
            data=dict(type='str', default='pong'),
        )
        supports_check_mode = True
    module = fake_module()
    if module.params['data'] == 'crash':
        raise Exception("boom")


# Generated at 2022-06-20 22:15:40.812120
# Unit test for function main
def test_main():
    result = main()
    assert result == dict(
        ping='pong',
    ), result

# Generated at 2022-06-20 22:15:41.483718
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:15:42.558779
# Unit test for function main
def test_main():
    assert 0


# Generated at 2022-06-20 22:15:45.192563
# Unit test for function main
def test_main():
    class Args(object):
        def __init__(self, data):
            self.data = data
            self.check_mode = True
    args = Args("pong")
    main(args)

# Generated at 2022-06-20 22:15:47.614367
# Unit test for function main
def test_main():
    result = {
        u"ping": "pong"
    }
    assert main() == result

# Generated at 2022-06-20 22:16:06.340495
# Unit test for function main
def test_main():
    # Test without data
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
    )
    result = dict(
        ping=module.params['data'],
    )
    assert dict(ansible_facts={'ping': 'pong'}) == main()

    # Test with data = 'crash'
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        main()
    except Exception as exception:
        assert 'boom' in str(exception)

# Generated at 2022-06-20 22:16:08.607220
# Unit test for function main
def test_main():
    host = { 'data' : 'pong' }
    data = dict(
        ping=host['data'],
    )
    assert main.__annotations__['return'] == data

# Generated at 2022-06-20 22:16:11.057841
# Unit test for function main
def test_main():

    import ansible.modules.system.ping as ping

    assert ping.main()

# Generated at 2022-06-20 22:16:19.266230
# Unit test for function main
def test_main():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    mod.exit_json = mock.Mock(return_value=None)
    mod.fail_json = mock.Mock(return_value=None)

    result = dict(
        ping=mod.params['data'],
    )

    main()
    mod.exit_json.assert_called_with(**result)

    # Exception raised
    mod.params['data'] = 'crash'
    mod.exit_json.side_effect = None
    mod.fail_json.side_effect = None

    main()

# Generated at 2022-06-20 22:16:22.497395
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:16:25.999092
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )
    module = AnsibleModule(argument_spec = dict(), supports_check_mode = True)
    result = dict(
        ping=args['data']
    )
    module.exit_json(**result)



# Generated at 2022-06-20 22:16:37.938219
# Unit test for function main
def test_main():
    # First, run this against a real AnsibleModule
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    m.exit_json = lambda **kwargs: kwargs
    result = main()
    assert 'ping' in result
    assert result['ping'] == 'pong'

    # Now, run the same thing but this time cause the module to raise an exception
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        )
    )
    m.exit_

# Generated at 2022-06-20 22:16:42.109432
# Unit test for function main
def test_main():
    module_args = dict(
        data=dict(type='str', default='pong'),
    )
    mod = AnsibleModule(module_args)

    main_result = main()

    assert main_result == mod.exit_json(**main_result)

# Generated at 2022-06-20 22:16:50.994448
# Unit test for function main
def test_main():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('test_main(): fail_json')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    m = TestModule(data='desired value')
    try:
        main()
    except Exception as err:
        error = str(err)
    else:
        error = False

    assert not error
    assert m.exit_args[0]['ping'] == 'desired value'



# Generated at 2022-06-20 22:16:59.058761
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    AnsibleModule = ansible.module_utils.basic.AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
            _ansible_check_mode=dict(default='False'),
        )
    )
    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:17:19.546050
# Unit test for function main
def test_main():
    from ansible.module_utils.common.arguments import AnsibleModuleArgumentSpec
    from ansible.module_utils.common.params import AnsibleModuleParameters
    from ansible.module_utils.basic import AnsibleModule
    moduleArgs = {'data': 'pong'}
    defTestModule = AnsibleModule(
        argument_spec=moduleArgs,
        supports_check_mode=True
    )
    defMainResult = main()
    assert defMainResult['ping'] == 'pong'
    assert defTestModule.exit_json.called


# Generated at 2022-06-20 22:17:26.161980
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    test_module.exit_json = MagicMock(return_value=dict())
    main()
    test_module.exit_json.assert_called_once_with(ping='pong')

# Generated at 2022-06-20 22:17:35.025470
# Unit test for function main
def test_main():
    # test that a check mode doesn't change the result
    try:
        # make sure check mode is initialized to False
        check_mode = None
        main()
    except Exception as e:
        check_mode = isinstance(e, SystemExit)
    try:
        # now set it to True and make sure we get the same result
        check_mode = True
        main()
    except Exception as e:
        assert (check_mode == isinstance(e, SystemExit))
    # Make sure that 'crash' as the data parameter causes an exception
    with pytest.raises(Exception):
        main(dict(data='crash'))

# Generated at 2022-06-20 22:17:38.521914
# Unit test for function main
def test_main():
    my_dict = {
        'data': 'test_dict'
    }
    module = AnsibleModule(argument_spec=dict(data=dict(type='str')))
    module.params.update(data='test')
    result = main()

    assert result['ansible_facts']['ping'] == 'test'

# Generated at 2022-06-20 22:17:42.477184
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

    # unit tests go here
    assert 1 == 1

# Generated at 2022-06-20 22:17:43.097950
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:17:43.794091
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 22:17:44.394921
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:17:48.733017
# Unit test for function main
def test_main():
    test_module = AnsibleModule({'data': 'Ping?'}, check_invalid_arguments=False)
    main()
    assert test_module.exit_args['failed'] is False
    assert test_module.exit_args['changed'] is False
    assert test_module.exit_args['meta']['ping'] == 'Ping?'

# Generated at 2022-06-20 22:17:55.821319
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:18:35.638264
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:18:39.557795
# Unit test for function main
def test_main():
    test_module = AnsibleModule({}, supports_check_mode=True)
    my_solution = {}
    my_solution['ping'] = 'pong'

    assert main() == (  # noqa: WPS441
        my_solution,
        '',
        0,
    )

# Generated at 2022-06-20 22:18:47.757078
# Unit test for function main
def test_main():
    argv = [
        "ping.py",
        "--data", "hello",
    ]

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    setattr(module, "_ansible_sys_argv", argv)
    setattr(module, "_ansible_dev_debug", True)

    result = dict(
        ping="hello",
    )

    assert main() == module.exit_json(**result)

# Generated at 2022-06-20 22:18:48.770807
# Unit test for function main
def test_main():
    assert(main() == None)

# Generated at 2022-06-20 22:19:01.521620
# Unit test for function main
def test_main():
    data = dict()
    data['ansible_system_capabilities'] = dict()
    data['ansible_system_capabilities']['platform'] = 'Linux'
    data['ansible_system_capabilities']['distribution'] = 'Debian'
    data['ansible_system_capabilities']['distribution_version'] = '10'
    data['ansible_system_capabilities']['distribution_release'] = 'buster'
    data['ansible_system_capabilities']['is_linux'] = True
    data['ansible_all_ipv4_addresses'] = [ '192.168.1.1' ]
    data['ansible_python_version'] = '3.7.4'
    data['ping'] = 'pong'
    assert main() == data

# Generated at 2022-06-20 22:19:02.392953
# Unit test for function main
def test_main():
  pass

# Generated at 2022-06-20 22:19:05.853654
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:19:08.996026
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as excinfo:
        main()
    assert "boom" in str(excinfo.value)

# Generated at 2022-06-20 22:19:12.459323
# Unit test for function main
def test_main():
    print("Unit test for function main")
    assert main() == None


# Generated at 2022-06-20 22:19:21.901956
# Unit test for function main
def test_main():
    module_name = "ansible.builtin.ping"
    from ansible.modules.network.ping import main as ping_main
    module = importlib.import_module(module_name)
    module.main = ping_main
    orig_sys_argv = sys.argv
    sys.argv = [sys.argv[0]]
    b_input = io.BytesIO()
    b_output = io.BytesIO()
    writer = codecs.getwriter('utf-8')
    reader = codecs.getreader('utf-8')
    input_stream = reader(b_input)
    output_stream = writer(b_output)
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(module, '__builtins__', Mock(dict))

# Generated at 2022-06-20 22:20:42.631605
# Unit test for function main
def test_main():
    """ This is testing the module.
    """

    from ansible.module_utils.basic import AnsibleModule

    # Define argument specifications
    argument_spec = dict(data=dict(type='str', default='pong'))

    # Instantiate module
    module = AnsibleModule(argument_spec=argument_spec,
                           supports_check_mode=True)

    # Check that module is working as expected
    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:20:47.934550
# Unit test for function main
def test_main():
    from ansible.modules.network.ping import main
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == dict(ping='pong')

# Generated at 2022-06-20 22:20:56.639294
# Unit test for function main
def test_main():
    # function main() with good parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

    # function main() with bad parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")


# Generated at 2022-06-20 22:20:57.837523
# Unit test for function main
def test_main():
    '''
    unit test for function main
    '''
    assert 'truc' == 'truc'

# Generated at 2022-06-20 22:20:58.280978
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-20 22:21:09.280899
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as e:
        module_args = dict(
            data=dict(type='str', default='crash'),
        )
        result = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=False
        )
        assert result['ping'] == 'pong'
        assert str(e.value) == 'boom'

    with pytest.raises(Exception) as e:
        module_args = dict(
            data=dict(type='str', default='boom'),
        )
        result = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=False
        )
        assert result['ping'] == 'pong'
        assert str(e.value) == 'boom'

# Generated at 2022-06-20 22:21:11.076994
# Unit test for function main
def test_main():
    test_params = {'data': 'test-pong'}
    x = main(test_params)
    assert x['ping'] == 'test-pong'

# Generated at 2022-06-20 22:21:14.376624
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    set_module_args(dict(
        data='crash'
    ))
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-20 22:21:15.219134
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:21:19.239949
# Unit test for function main
def test_main():
    import json
    with open('test/ping.json') as ping_json:
        ping_data = json.load(ping_json)
    module = AnsibleModule(argument_spec=ping_data['arguments'])
    ping_result = main()
    assert ping_result['ansible_facts']['ping'] == 'pong'

# Generated at 2022-06-20 22:24:24.659307
# Unit test for function main
def test_main():
    import sys
    import json
    import pytest

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    ################################################################################
    ##             Example invocation from ansible-test integration test          ###
    ################################################################################
    # `ansible-test integration -v --python 2.6 --test ping` invokes the module with the following args:
    args = {
        'ANSIBLE_MODULE_ARGS': {
            'data': 'pong',
        },
    }

    # and it expects the following return data:
    expected_result = dict(
        ping='pong',
    )

    # When running `ansible-test integration -v --python 2.6