

# Generated at 2022-06-20 22:14:21.963279
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 22:14:25.491255
# Unit test for function main
def test_main():
    data = dict(
        data=dict(type='str', default='pong'),
        changed=False
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == module.exit_json(**data)

# Generated at 2022-06-20 22:14:33.354883
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    # as of python3, mock is not part of unittest and must be imported separately
    # import mock
    # # mock is used to replace AnsibleModule in the ping module with a mocked version.
    # # because it is a separate library, the python2 and python3 versions need to be
    # # referenced with different names.  this is why "mock" is imported above to alias
    # # the correct one.
    # from unittest.mock import MagicMock
    # AnsibleModule = MagicMock()
    # AnsibleModule.run_command = MagicMock()
    # AnsibleModule.run_command.return_value = (0, 'pong', '')
    # AnsibleModule.exit_json = Magic

# Generated at 2022-06-20 22:14:43.004856
# Unit test for function main
def test_main():
    # Data to be used for testing
    sample_data = {'data': 'ping'}

    # Some tests will validate the exit_json method, and we want to capture the output
    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio    # free up some memory
            sys.stdout = self._stdout

    # Module is a mock of the ansible module that is calling this test
    class MockModule():
        def __init__(self, params):
            self.params = params

    # Load the module script with some sample values

# Generated at 2022-06-20 22:14:44.997065
# Unit test for function main
def test_main():
    run_main(module_args={})
    run_main(module_args={'data': 'something different'})



# Generated at 2022-06-20 22:14:53.683214
# Unit test for function main
def test_main():
    import sys
    import json
    import argparse
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    # Hack to run AnsibleModule's parse_args function even though
    # we have defined a custom main function.
    AnsibleModule._original_parse_args = AnsibleModule.parse_args
    AnsibleModule.parse_args = lambda self: None
    json_obj = json.loads('{"params":{"data":"pong"}}')

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    sys.argv = ['main.py']

# Generated at 2022-06-20 22:14:54.395289
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:15:01.010998
# Unit test for function main
def test_main():
    print("Testing ping module")
    test_module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    result = dict(ping=test_module.params['data'])
    test_module.exit_json(**result)

# Test no echo, no crash, no ping
test_main()

# Generated at 2022-06-20 22:15:06.142574
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:15:12.665090
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

test_main()

# Generated at 2022-06-20 22:15:23.438774
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:28.315528
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils.pycompat import mock
  m = mock.Mock()
  assert main() == m.exit_json(**dict(ping=m.params['data']))

# Generated at 2022-06-20 22:15:33.330378
# Unit test for function main
def test_main():
    ansible_mock = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == {'ping': ansible_mock}

# Generated at 2022-06-20 22:15:44.360061
# Unit test for function main
def test_main():
    '''
    Test the main function
    '''
    import ansible.module_utils.basic as basic
    data = 'return'
    # Without args
    m = basic.AnsibleModule(
        argument_spec=dict(
        )
    )
    result = main()
    assert result == None
    # With args
    m = basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
            )
    )
    result = main()
    assert result == None
    # With exception
    m = basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash')
            )
    )
    with pytest.raises(Exception) as excinfo:
        result = main()


# Generated at 2022-06-20 22:15:55.264169
# Unit test for function main
def test_main():
    host_args = dict(
        data="pong",
    )
    fail_json_mock = dict()
    exit_json_mock = dict(
        ping="pong",
    )
    module_mock = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        params=host_args,
        exit_json=lambda x: exit_json_mock.update(x),
        fail_json=lambda x: fail_json_mock.update(x),
    )
    module_mock['check_mode'] = False
    module_mock['no_log'] = False
    with pytest.raises(SystemExit):
        main()
    assert fail_json_mock == {}
    assert exit_json_mock == dict

# Generated at 2022-06-20 22:16:07.051967
# Unit test for function main
def test_main():

    import ansible.module_utils.basic
    import sys
    import inspect

    print(inspect.getsource(ansible.module_utils.basic))

    # Define a fake module
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    class AnsibleModule(object):
        def __init__(self, argument_spec, **kwargs):
            self.params = Options(**kwargs)
            self.exit_json = lambda **kwargs: print(kwargs)
    original_module = sys.modules['ansible.module_utils.basic']
    sys.modules['ansible.module_utils.basic'] = AnsibleModule

    # Test function
    main()
    print("=======================")

# Generated at 2022-06-20 22:16:13.061038
# Unit test for function main
def test_main():
    """Simulate module running"""

    # AnsibleModule is the common object that supports all modules
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Called from the base class's exit_json method
    module.exit_json(changed=False)

# Generated at 2022-06-20 22:16:15.378228
# Unit test for function main
def test_main():
    args = dict(data='crash')
    with pytest.raises(Exception):
        main()
    args = dict(data='pong')
    main()

# Generated at 2022-06-20 22:16:25.613436
# Unit test for function main
def test_main():
    from ansible.modules.system.ping import main
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    def make_mock_module():

        params = dict(
            data=dict(type='str', default='pong'),
        )

        return AnsibleModule(
            argument_spec=params,
            supports_check_mode=True
        )

    # Test successful case

    # Test normal data
    module = make_mock_module()
    module.params = dict(data=dict(type='str', default='pong'))
    expected_response = dict(ping="pong")
    assert_equal(main(), expected_response)

    # Test changed data
    module = make_mock_module()
    module.params

# Generated at 2022-06-20 22:16:32.476963
# Unit test for function main
def test_main():
    # Unit test for function main
    function_name = 'main'
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test with data='foo'
    data = 'foo'
    result = dict(ping='foo')
    setattr(module, "_ansible_check_mode", False)
    setattr(module, "params", dict(data=data))

    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 0
    assert module.exit_json.call_count == 1
    assert module.exit_json.call_args == call(**result)

    # Test with data='crash', should raise an exception
    data

# Generated at 2022-06-20 22:16:46.214319
# Unit test for function main
def test_main():
    def genres(count):
        import random
        all_genres = ['classical','jazz','hiphop','country','pop','metal','punk','alternative','rock','blues','reggae','dance','electronic','edm','trance','house','dubstep','drumandbass','techno','ambient','newage','folk','function','gospel','sexy','funk','indie','soul','bluegrass','grunge','garage','post-rock','disco','ska','progressive']
        return ','.join([random.choice(all_genres) for i in range(count)])

    # import modules needed by this function
    import json
    import os
    import sys

    # set input data
    module_args = dict(
        data='crash'
    )


    # load the module

# Generated at 2022-06-20 22:16:50.279215
# Unit test for function main
def test_main():
    # get the builtin ping module
    import ansible.modules.ping
    m = ansible.modules.ping.AnsibleModule(argument_spec = {'data': {'type': 'str', 'default': 'pong'}})
    main()
    main()

# Generated at 2022-06-20 22:16:53.752930
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    assert module.params['data'] == 'pong'
    assert module.check_mode == False

# Generated at 2022-06-20 22:16:59.929313
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:17:03.474026
# Unit test for function main
def test_main():
    test_data = {
        'ansible_check_mode': False,
        'ansible_diff_mode': False,
        'ansible_module_name': 'ping',
        'ansible_version': {'full': '2.4.2.0', 'major': 2, 'minor': 4, 'revision': 2, 'string': '2.4.2.0'},
        'module_args': {'data': 'pong'},
        'module_name': 'ping',
        '_ansible_version': '2.4.2.0',
        'changed': False
    }
    result = main()
    assert test_data == result



# Generated at 2022-06-20 22:17:11.462786
# Unit test for function main
def test_main():
    # Arrange
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleValidationException
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Act
    main()
    # Assert
    assert True

# Generated at 2022-06-20 22:17:18.568625
# Unit test for function main
def test_main():
    # Construct a mock module and exit_json return values
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()

    # Call the function under test
    main()

    # Make sure it called exit_json with the correct values
    module.exit_json.assert_called_once_with(
        ping='pong',
        changed=False
    )

    # Make sure it didn't call fail_json
    assert not module.fail_json.called


# Generated at 2022-06-20 22:17:24.223040
# Unit test for function main
def test_main():

    module = AnsibleModule(
            argument_spec = dict(
                data=dict(type='str', default='pong')
            ),
            supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert module.exit_json(**result)



# Generated at 2022-06-20 22:17:29.165029
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:17:34.020223
# Unit test for function main
def test_main():
    # Check is data argument is set
    module.params = dict(data='foo')
    result = dict(ping='foo')
    assert result == main()
    # Check is module raises exception if data == crash
    module.params = dict(data='crash')
    result = dict(ping='crash')
    assert result == main()

# Generated at 2022-06-20 22:17:54.370256
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.modules.system.ping as ping
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong')), supports_check_mode=True)
    output = ping.main()


# Generated at 2022-06-20 22:18:05.231488
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import sys

    content = {
        "ANSIBLE_MODULE_ARGS": "{'data': 'crash'}",
        "ANSIBLE_MODULE_NAME": "ansible.builtin.ping",
        "ANSIBLE_MODULE_KWARGS": "{}",
        "ANSIBLE_MODULE_REQUIRE_ARGS": "0",
        "ANSIBLE_MODULE_SUPPORTS_CHECK_MODE": "1"
    }
    sys.argv = ['ansible-test','ping','','']
    module = AnsibleModule(content=content)


# Generated at 2022-06-20 22:18:11.839850
# Unit test for function main
def test_main():
    args = dict(
        data = 'pong'
    )
    result = dict(
        ping='pong'
    )
    module = AnsibleModule(argument_spec=args)
    try:
        main()
    except SystemExit as e:
        assert e._exit_code == 0
    else:
        assert False, "Should have thrown an exception"
    assert module.exit_json.called
    for key, value in iteritems(args):
        assert module.exit_json.called_with[key] == value

# Generated at 2022-06-20 22:18:17.357114
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:18:20.425124
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert list(pytest_wrapped_e.value.args) == [0]

# Generated at 2022-06-20 22:18:21.612538
# Unit test for function main
def test_main():
    args = dict(
        data='crash',
    )
    main(args)

# Generated at 2022-06-20 22:18:28.811630
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.compat import PY2
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleModule, _load_params
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types, iteritems, binary_type, text_type

    # Use a try/except block to get the correct error message when running python3.6 with python3.5

# Generated at 2022-06-20 22:18:36.909491
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule as MockingModule

    module = MockingModule()
    # set params
    module.params = dict(
        data=dict(type='str', default='pong'),
    )
    module.params['data'] = 'crash'
    # set exit_json
    module.exit_json = magicMock()

    try:
        main()
    except:
        pass
    else:
        raise AssertionError('Module has not thrown Exception')
    # Module has thrown exception as specified in test

# Generated at 2022-06-20 22:18:37.500000
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:18:42.510723
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:19:22.570215
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:19:25.913747
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    my_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert True == True

# Generated at 2022-06-20 22:19:34.900637
# Unit test for function main
def test_main():
    # Define arguments and parameters
    argv = []
    argv.append('')

    # Make the test
    test_args = argv[1:]
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {
        'data': '',
    }
    test_result = main()

    # Assertions
    assert type(test_result) == dict
    assert test_result == test_module.exit_json(**test_result)


# Generated at 2022-06-20 22:19:35.441962
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-20 22:19:44.728753
# Unit test for function main
def test_main():
    args = dict(
        data = 'pong'
    )
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type = 'str', default = 'pong')
        ),
        supports_check_mode=True
    )
    module.exit_json = exit_json
    main()
    assert module.exit_json_called_with == dict(changed = False, meta = dict(invocation=dict(module_args=dict(data='pong'))))
    args['data'] = 'crash'
    try:
        main()
    except Exception as e:
        assert e == Exception("boom")
    else:
        assert False

# Generated at 2022-06-20 22:19:45.130352
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:19:47.448596
# Unit test for function main
def test_main():
    params = {'data': 'blah'}
    module = AnsibleModule(params=params)
    assert module.params['data'] == 'blah'

# Generated at 2022-06-20 22:19:51.662553
# Unit test for function main
def test_main():
    data = dict()
    data['data'] = 'cake'
    with patch('ansible.modules.remote_management.network.ansible_ping.AnsibleModule'):
        ansible_ping.main()
    assert ansible_ping.AnsibleModule.call_args[1] == data


# Generated at 2022-06-20 22:19:58.497389
# Unit test for function main
def test_main():
    import pytest
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
        
    # Test with normal input
    sys.stdout = StringIO()
    sys.argv = 'ping -a data=pong'.split()
    try:
        main()
        assert False
    except SystemExit:
        assert True
    
    # Test with normal input
    sys.stdout = StringIO()
    sys.argv = 'ping -a data=crash'.split()
    try:
        main()
        assert False
    except SystemExit:
        assert True

# Generated at 2022-06-20 22:20:00.056318
# Unit test for function main
def test_main():
    assert main() is None

# Unit tests for functions that can be called from any module.
# Called like:  python -m ansible.modules.builtin.ping test_my_func

# Generated at 2022-06-20 22:21:37.993387
# Unit test for function main
def test_main():
    infile = 'ping'
    outfile = 'ping.out'
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    with open(infile, 'wb') as f:
        f.write(b'pong')
    with open(outfile, 'wb') as f:
        f.write(b'')
    try:
        os.remove(outfile)
    except OSError:
        pass
    module.exit_json(changed=False, msg='test_main is successful')

# Unit test to raise exception in main

# Generated at 2022-06-20 22:21:42.005160
# Unit test for function main
def test_main():
    with AnsibleRunner(
        os.path.join(os.path.dirname(__file__), 'ping_unittest.yml'),
        os.path.join(os.path.dirname(__file__), 'ping_unittest.json'),
    ) as runner:
        runner.run_module(main, dict(data='pong'))

# Generated at 2022-06-20 22:21:46.958832
# Unit test for function main
def test_main():
    # Test no exception
    main()

    # Test exception
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    arguments = dict(
        data='crash',
    )
    # Set module args
    module.params = arguments

    # Execute main()
    main()

# Generated at 2022-06-20 22:21:53.111284
# Unit test for function main
def test_main():
    return_dict = {}
    answer = {'changed': False}

    # Call module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    try:
        if module.params['data'] == 'crash':
            raise Exception("boom")
    except Exception as err:
        module.fail_json(msg=err)

    result = dict(
        ping=module.params['data'],
    )
    return_dict['ping'] = result['ping']

    module.exit_json(**return_dict)


# Generated at 2022-06-20 22:22:00.426966
# Unit test for function main
def test_main():
    pingData = 'pong'
    test_dict = dict(
        data=pingData
    )
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        )
    )
    test_module.params = test_dict
    assert main() == None
    assert test_dict['data'] == 'pong'
    assert test_module.params['data'] == 'pong'

from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 22:22:05.649782
# Unit test for function main
def test_main():
    test_module = importlib.import_module(__name__)
    test_main = test_module.main
    # Insert code here to set up test_main

    # Set the module arguments
    args = {}

    # Run the command using `ansible-test local`
    result = runner.run(test_main, args)
    # Insert code here to validate the result
    # Validate the result

    # Insert code here to tear down test_main

# Generated at 2022-06-20 22:22:06.519394
# Unit test for function main
def test_main():
    assert main() is None



# Generated at 2022-06-20 22:22:18.604776
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import actions
    from ansible.module_utils import loader
    from ansible.module_utils import connection
    from ansible.module_utils import arguments
    import ansible.module_utils.action
    from ansible.module_utils.six import StringIO
    import yaml
    import sys

    def MOCK_main():
        sys.modules['ansible'] = type('ansible', (object,), dict(__file__='/dev/null'))
        sys.modules['ansible.module_utils'] = type('ansible.module_utils', (object,), dict())
        sys.modules['ansible.module_utils.basic'] = basic
        sys.modules['ansible.module_utils.actions'] = actions

# Generated at 2022-06-20 22:22:27.534473
# Unit test for function main
def test_main():

    # Mock out the connection object
    module = MagicMock(name='module')()

    module.exit_json = MagicMock(name='exit_json')

    # Mock out the argument spec
    module.params = {
        'data': 'pong',
        }

    # Mock out the check mode
    module.supports_check_mode = True

    # Run module
    main()

    # Assert exit_json was called to return the result
    module.exit_json.assert_called_once_with(
        ping='pong'
        )


# Generated at 2022-06-20 22:22:33.744565
# Unit test for function main
def test_main():
    args = dict(
        data="pong",
    )
    result = dict(
        ping="pong",
        changed=False,
    )

    module = AnsibleModule(argument_spec=args)
    # Allow the module to exit as if all went well
    module.exit_json = lambda **kwargs: None
    module.params = args

    main()
    module.fail_json.assert_not_called()
    module.exit_json.assert_called_once_with(**result)