

# Generated at 2022-06-20 22:14:24.015920
# Unit test for function main
def test_main():
    def mock_exit_json(**kwargs):
        # pylint: disable=unused-argument
        assert(kwargs == dict(ping='pong'))

    with pytest.raises(Exception, match='boom'):
        with mock.patch.object(AnsibleModule, 'exit_json', mock_exit_json):
            main()

# Generated at 2022-06-20 22:14:24.536190
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:14:27.519397
# Unit test for function main
def test_main():
    if not os.path.exists(sys.path[0]+'/ansible/modules/ping.py'):
        pytest.skip(msg="ping.py not found")
    content = open(sys.path[0]+'/ansible/modules/ping.py').read()
    assert content.find('raise Exception("boom")') != -1

# Generated at 2022-06-20 22:14:29.625967
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=False
    )
    result = main()
    assert result['stdout'] == 'pong'


# Generated at 2022-06-20 22:14:31.515697
# Unit test for function main
def test_main():
    data = {"data": "crash"}
    main(data)

# Generated at 2022-06-20 22:14:38.161639
# Unit test for function main
def test_main():
    import mock
    import ansible.module_utils.basic
    import ansible.module_utils
    with mock.patch.object(ansible.module_utils.basic.AnsibleModule, 'exit_json') as exit_json_mock:
        exit_json_mock.return_value = {}
        main()
        assert exit_json_mock.called

# Generated at 2022-06-20 22:14:45.091482
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def exit_json(*args, **kwargs):
        pass

    def exit_args(*args, **kwargs):
        pass

    def fail_json(*args, **kwargs):
        pass

    class AnsibleExitJson(BaseException):
        pass

    class AnsibleFailJson(BaseException):
        pass

    setattr(AnsibleModule, 'exit_json', exit_json)
    setattr(AnsibleModule, 'exit_args', exit_args)
    setattr(AnsibleModule, 'fail_json', fail_json)
    setattr(AnsibleModule, 'AnsibleExitJson', AnsibleExitJson)
    setattr(AnsibleModule, 'AnsibleFailJson', AnsibleFailJson)

   

# Generated at 2022-06-20 22:14:54.929462
# Unit test for function main
def test_main():
    check_output = '''{
    "changed": false,
    "ping": "pong"
}'''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import AnsibleModuleTest
    from ansible.module_utils.six import exec_command

    if not hasattr(AnsibleModuleTest, 'fail_json'):
        from ansible.module_utils.mysql import fail_json
    else:
        from ansible.module_utils.mysql import fail_json

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-20 22:14:55.570215
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:15:01.616733
# Unit test for function main
def test_main():
    myfunc = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    myfunc.exit_json({'ping':'pong'})


# Generated at 2022-06-20 22:15:10.793449
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == (
        dict(
            ping=module.params['data'],
        ),
        False
    )


# Generated at 2022-06-20 22:15:19.856945
# Unit test for function main
def test_main():
    import os
    import pytest
    import sys
    import textwrap
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    # Test with default args
    with pytest.raises(basic.AnsibleExitJson) as execute_exception:
        def exit_json(*args, **kwargs):
            if args and isinstance(args[0], Mapping):
                raise basic.AnsibleExitJson(args[0])

        monkeypatch = pytest.MonkeyPatch()
        monkeypatch.setattr(basic, 'exit_json', exit_json)

        # Test with default args and bad data
        main()

    # Test with default args

# Generated at 2022-06-20 22:15:23.540828
# Unit test for function main
def test_main():
    rc, out, err = test_module.run_command("ping")
    assert err == ''
    assert out == '{"ping": "pong"}'
    assert rc == 0


# Generated at 2022-06-20 22:15:28.833307
# Unit test for function main
def test_main():
    try:
        testargs = "ansible_module_ping data=crash"
        args, argv = ansible_module.parse_kv(testargs)
        main(args)
        fail()
    except:
        pass


# unit test for function main

# Generated at 2022-06-20 22:15:39.292774
# Unit test for function main
def test_main():
    # Replace function "ping" with the mock function created above
    # module.exit_json = exit_json
    # module.fail_json = fail_json

    # Test case 1
    # Make sure that module.params contains all of the expected values
    # These values should be coming from the "argument_spec" dictionary
    # defined in the main function
    params = {
        'data': 'pong',
    }

    # Set the module arguments using the mock_module.params dictionary
    # Since exit_json and fail_json are mock functions, the module will
    # exit with the desired state.
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    # Test case 2
    # Make sure that module.params contains all of the expected values
    # These values should be coming from the "argument

# Generated at 2022-06-20 22:15:40.341335
# Unit test for function main
def test_main():
  assert main == "test"

# Generated at 2022-06-20 22:15:50.018741
# Unit test for function main
def test_main():
    # Now we can use the code as input to the test
    #   the output is defined in the RETURN dictionary
    #   at the end of the ping module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    # Test the error being raised
    module.exit_json(**result)

# Generated at 2022-06-20 22:15:51.935499
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(default='test'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)


# Generated at 2022-06-20 22:15:59.015224
# Unit test for function main
def test_main():
    import tempfile

    dummy_args = dict(
        data=dict(type='str', default='pong')
    )

    module = AnsibleModule(argument_spec=dummy_args, supports_check_mode=True)

    assert module.params['data'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )

    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:16:05.145264
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-20 22:16:17.135826
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    with pytest.raises(Exception):
        assert module.params['data'] == 'crash'

# Generated at 2022-06-20 22:16:20.778917
# Unit test for function main
def test_main():
    func_input = {'data': 'test_data'}
    func_output = dict(ping=func_input['data'])
    assert main(func_input) == func_output

# Generated at 2022-06-20 22:16:29.532102
# Unit test for function main
def test_main():
    """
    Unit test.  Test that main works as expected.

    """
    ping = { 'data': 'pong' }
    check_mode = True
    ping_false = { 'data': 'bong' }
    check_mode_false = False
    module = AnsibleModule(argument_spec=dict(
            data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
            )
    assert module.params == ping
    assert module.check_mode == check_mode
    module = AnsibleModule(argument_spec=dict(
            data=dict(type='str', default='bong'),
            ),
            supports_check_mode=False
            )
    assert module.params == ping_false
    assert module.check_mode == check_mode_false

# Generated at 2022-06-20 22:16:36.536922
# Unit test for function main
def test_main():
    import sys

    # create a dummy module instance to test
    module = AnsibleModule(argument_spec={'data':{'type':'str', 'default':'pong'}}, supports_check_mode=True)

    # unit test by creating a exception
    try:
        module.params['data'] = 'crash'
        main()
    except Exception:
        pass
    else:
        sys.exit(1)

# Generated at 2022-06-20 22:16:38.145038
# Unit test for function main
def test_main():
    assert main() == 'pong'

# Generated at 2022-06-20 22:16:48.630835
# Unit test for function main
def test_main():
    test_parameters = { "data": ["crash","pong"] }
    test_result = { "ping": ["pong","pong"] }
    temp_stdout = StringIO()
    temp_stderr = StringIO()

# Generated at 2022-06-20 22:17:00.566492
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.dict_transformations import _dict_merge
    doc = dict(DOCUMENTATION=DOCUMENTATION)
    res = dict(ANSIBLE_MODULE_ARGS=dict(), CHANGED=False, PING='pong')
    m = basic.AnsibleModule(argument_spec=dict(),
       supports_check_mode=True,
       documentation=doc)
    res['ansible_facts'] = dict(doc_facts=dict(), module_setup=True,
       module_default_args=dict(), module_args=dict(), test_items=dict())
    m._ansible_module_facts = dict()
    m._handle_aliases(m.params)
    m._set_defaults(m.params)
    m._

# Generated at 2022-06-20 22:17:12.424435
# Unit test for function main

# Generated at 2022-06-20 22:17:13.834565
# Unit test for function main
def test_main():
    import ansible.module_utils.ping as ping_module
    ping_module.main()

# Generated at 2022-06-20 22:17:14.787469
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 22:17:31.675345
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:17:39.237346
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        with patch.object(AnsibleModule, 'fail_json') as fail_json:
            with patch.object(AnsibleModule, 'run_command') as run_command:
                with patch.object(AnsibleModule, 'check_mode') as check_mode:
                    module_returned = ping.main()
                    assert module_returned == None
                    assert exit_json.call_count == 1
                    assert fail_json.call_count == 0
                    assert run_command.call_count == 0
                    assert check_mode.call_count == 1

# Generated at 2022-06-20 22:17:43.838741
# Unit test for function main
def test_main():
    testmodule = dict(data=dict(type='str', default='pong'))

    with pytest.raises(Exception):
        main(testmodule)

    testmodule['data'] = 'crash'
    main(testmodule)
#

# Generated at 2022-06-20 22:17:52.087361
# Unit test for function main
def test_main():
    test_module = AnsibleModule({}, {})
    test_module.exit_json = lambda **kwargs: None

    def raiseError(msg):
        raise Exception(msg)

    test_module.fail_json = raiseError

    assert test_module.fail_json.__name__ == 'raiseError'

    results = dict(ping='pong')

    def exit(results):
        assert results == results

    test_module.exit_json = exit

    test_module.params = dict(data=None)
    main()

    assert test_module.exit_json.__name__ == 'exit'
    assert test_module.exit_json.__closure__ is not None and len(test_module.exit_json.__closure__) == 1
    assert test_module.exit_json.__closure__[0].cell_cont

# Generated at 2022-06-20 22:17:56.868998
# Unit test for function main
def test_main():
    result = dict(
        ping='pong',
    )
    run_result, changed = main.run_command(None, dict(data='crash'), ["boom"])
    assert changed is True
    assert result == run_result

# Generated at 2022-06-20 22:18:04.801493
# Unit test for function main
def test_main():
    def mock_exit_json(changed=False, ping="pong"): #, ansible_facts=None
        module.exit_json(changed=changed, ping=ping)

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    module.exit_json = mock_exit_json

    main()
    assert module.exit_json.called
    assert module.exit_json.call_args[0] == (dict(changed=False, ping="pong"),)


# Generated at 2022-06-20 22:18:07.763762
# Unit test for function main
def test_main():
    data = dict(
        data='pong'
    )
    result = dict(
        changed=False,
        ping='pong'
    )
    assert main(data=data) == result

# Generated at 2022-06-20 22:18:09.603037
# Unit test for function main
def test_main():
  import json

  result = json.loads(main())
  assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:18:10.498495
# Unit test for function main
def test_main():
    # FIXME - add unit tests
    pass

# Generated at 2022-06-20 22:18:15.132919
# Unit test for function main
def test_main():
    testobj = None
    if os.path.exists('/tmp/test_ansible_ping.py'):
        testobj = imp.load_source('*', '/tmp/test_ansible_ping.py')
    if hasattr(testobj, 'unit_test'):
        testobj.unit_test()

# Generated at 2022-06-20 22:19:02.880802
# Unit test for function main
def test_main():
    module_args = {}
    module_args['data'] = 'pong'
    module = AnsibleModule(**module_args)
    result = dict(
        ping = 'pong',
    )
    assert module.exit_json == result
    # Test exception
    module_args['data'] = 'crash'
    module = AnsibleModule(**module_args)
    assert Exception('boom') == result

# Generated at 2022-06-20 22:19:05.894818
# Unit test for function main
def test_main():
   # set up actual params and call function
   actual = None
   try:
      actual = main()
   except:
      pass
   assert actual == {'ping': 'pong'}


# Generated at 2022-06-20 22:19:09.772542
# Unit test for function main
def test_main():
    test_params = {
        'data': 'pong'
    }
    val = main(test_params)
    assert val['ping'] == 'pong'

# Generated at 2022-06-20 22:19:17.083254
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:19:20.760326
# Unit test for function main
def test_main():
    mock_options = {'data': 'pong'}
    module = AnsibleModule(mock_options)
    exit_args, changed_bool = main(module)
    assert 'ping' in exit_args
    assert exit_args['ping'] == 'pong'
    assert changed_bool is None

# Generated at 2022-06-20 22:19:25.000760
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    result = dict(
        ping=module.params['data'],
        )
    assert result == {'ping': 'pong'}

# Generated at 2022-06-20 22:19:37.912813
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import *
    original_exit_json = exit_json
    def fake_exit_json( return_value):
        """
        This is used to fake out exit_json so that unit tests can be written
        without the module making the request.
        """
        original_exit_json(return_value)
        raise SystemExit(0)
    exit_json = fake_exit_json

    try:
        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
    except SystemExit as e:
        if type(e) == int and e == 0:
            pass
        else:
            raise

# Generated at 2022-06-20 22:19:48.943822
# Unit test for function main
def test_main():
    import copy
    import sys
    import subprocess
    import platform
    import os

    # Windows requires python to be in PATH
    # Ensure PATH is set so that it is possible to run this test on a system
    # that doesn't have python in the path (e.g. Windows)
    python3_path = subprocess.check_output(['which', 'python3']).strip().decode('utf-8')
    os.environ['PATH'] = '{}{}{}'.format(python3_path, os.pathsep, os.environ['PATH'])

    python_version = platform.python_version()

    # Python 2 and Python 3 differ in how they set the return code of a module
    # so we need to make sure that the test checks the correct return code

# Generated at 2022-06-20 22:19:54.349762
# Unit test for function main
def test_main():
  module = AnsibleModule(
    argument_spec=dict(
      data=dict(type='str', default='pong'),
    ),
    supports_check_mode=True
  )

  if module.params['data'] == 'crash':
    raise Exception("boom")

  result = dict(
    ping=module.params['data'],
  )
  module.exit_json(**result)

# Generated at 2022-06-20 22:19:55.274583
# Unit test for function main
def test_main():
    # FIXME
    pass

# Generated at 2022-06-20 22:21:37.961239
# Unit test for function main
def test_main():
    import sys
    import json

    # Hack the path so that our ansible_module is preferred.
    sys.path.insert(0, '.')

    # Test with data=crash.  This should fail with Exception: boom
    print("Testing with crash")
    try:
        main()
    except Exception as e:
        assert e.message == 'boom'
    # Hack the path so that our ansible_module is preferred.
    sys.path.insert(0, '.')

    # Test with data='pong'.  This should succeed
    print("Testing with pong")
    with open('test_ping.json', 'w') as testf:
        oldstdout = sys.stdout
        sys.stdout = testf
        main()
        sys.stdout = oldstdout


# Generated at 2022-06-20 22:21:39.261024
# Unit test for function main
def test_main():
    test_module = AnsibleModule(argument_spec={})
    main()

# Generated at 2022-06-20 22:21:46.958549
# Unit test for function main
def test_main():
  # tests case: return valid data
  args = {"data": "pong"}
  result = {}
  def fake_exit_json(**args):
    result.update(**args)

  module = MagicMock()
  module.params = args
  module.exit_json = fake_exit_json

  main(module)
  expected_result = {"changed": False, "ping": "pong"}
  assert result == expected_result
  
  # tests case: raise and catch exception
  args = {"data": "crash"}
  result = {}
  result["ping"] = None
  module = MagicMock()
  module.params = args
  main(module)
  expected_result = {"changed": False, "ping": None}
  assert result == expected_result

# Generated at 2022-06-20 22:21:53.138496
# Unit test for function main
def test_main():
    # Test with successful ping
    argv = ['/usr/bin/ansible-playbook', 'foo', '-i', 'localhost,', '-m', 'ping']
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['ping'] == 'pong'

    # Test with unsuccessful ping
    argv = ['/usr/bin/ansible-playbook', 'foo', '-i', 'localhost,', '-m', 'ping', '-a', 'data=crash']
    module = AnsibleModule(argument_spec={})
    try:
        result = main()
    except Exception as exception:
        assert exception == 'boom'

# Generated at 2022-06-20 22:22:04.263846
# Unit test for function main
def test_main():
    # set our arguments
    module_args = dict(
        data="pong"
    )
    module_class = AnsibleModule

    # create module object
    ping_mod = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # set module attributes
    ping_mod.params = module_args

    result = dict(
        ping="pong"
    )

    def module_exit_json(data):
        # calling module_exit_json(data) will return the data back to the caller
        # if all that is needed is to return the data back to the user, then this assert is not needed
        assert(data == result)


# Generated at 2022-06-20 22:22:09.712102
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == module.exit_json(**{"ping": "pong"})


# Generated at 2022-06-20 22:22:14.577005
# Unit test for function main
def test_main():
    content = load_fixture('ansible_module_ping.json')
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert main() == content
    assert main() == {'ping': 'pong'}

# Generated at 2022-06-20 22:22:18.072148
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
       argument_spec=dict(
           data=dict(type='str', default='pong'),
       ),
        supports_check_mode=True
    )
    assert(test_module.params['data'] == 'pong')

# Generated at 2022-06-20 22:22:25.512508
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:22:27.241754
# Unit test for function main
def test_main():
    ping = AnsibleModule({'data': 'crash'})
    assert ping
    assert main()