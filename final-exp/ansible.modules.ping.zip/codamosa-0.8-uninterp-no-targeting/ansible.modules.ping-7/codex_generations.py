

# Generated at 2022-06-20 22:14:20.185232
# Unit test for function main
def test_main():
    pass
# vim: expandtab:ts=4:sw=4

# Generated at 2022-06-20 22:14:25.142176
# Unit test for function main
def test_main():
	data = 'pong'
	module = AnsibleModule(
		argument_spec=dict(
			data=dict(type = 'str', default = data),
		)
	)
	result = dict(ping = data)
	assert module.exit_json(**result) == print (data)
	assert  main() == print (data)

# Generated at 2022-06-20 22:14:29.446434
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong')
        )
    )
    result = dict(
        ping ='pong'
    )
    module.exit_json(**result)

# Generated at 2022-06-20 22:14:37.919554
# Unit test for function main
def test_main():
    from ansible.modules.system.ping import main
    import pytest
    from ansible.module_utils import basic

    with pytest.raises(SystemExit):
        main()

    test_object = basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = main()
    assert result == dict(ping='pong')

# Generated at 2022-06-20 22:14:38.454760
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-20 22:14:42.542008
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:14:51.605280
# Unit test for function main
def test_main():

    # Unit test for main - no arguments provided
    def test_main_no_arguments():
        """
        No arguments provided
        """

        # Create a mock argument
        mock = {
            'params': {}
        }

        # Call main function
        main(mock)

        # Assert an exception was not raised
        assert True


    # Unit test for main - arguments provided
    def test_main_arguments():
        """
        Arguments provided
        """

        # Create a mock argument
        mock = {
            'params': { 'data': 'test' }
        }

        # Call main function
        main(mock)

        # Assert an exception was not raised
        assert True

    # Call test function
    test_main_no_arguments()
    test_main_arguments()

# Generated at 2022-06-20 22:14:52.489608
# Unit test for function main
def test_main():
    import mock

    m = mock.mock_mo

# Generated at 2022-06-20 22:15:04.794193
# Unit test for function main
def test_main():
    # This is a module test
    # We are just going to run a handful of cases to make sure the module does not fail horribly.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.ping import main as test_main
    import io

    # case 1: Ping
    run_args = dict(data="pong")
    result = dict(changed=False, ping="pong")

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    module.params.update(run_args)
    test_main()

    assert module.exit_json.called
    assert module.exit_json.call_args[0][0] == result

    # case 2

# Generated at 2022-06-20 22:15:06.892550
# Unit test for function main
def test_main():
    dict = dict(
        data=dict(type='str', default='pong'),
    )
    module = AnsibleModule(dict)
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:15:15.260423
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Assert Call
    result = main()
    assert result == dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-20 22:15:19.436809
# Unit test for function main
def test_main():
    args = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    obj = AnsibleModule(argument_spec={'data':{'type':'str', 'default': 'pong'}})
    obj.params = args
    assert main() == obj.exit_json(changed=False, **result)


# Generated at 2022-06-20 22:15:22.143889
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule = AnsibleModule
    main()

# Generated at 2022-06-20 22:15:24.574212
# Unit test for function main
def test_main():
    ping = "pong"
    assert main() == ping 
    assert main() != "not pong"
    assert main() == "pong"

# Generated at 2022-06-20 22:15:31.931448
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong'),
    )

    module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:38.452847
# Unit test for function main
def test_main():
    # check if an exception is raised
    # we only test the inner exception, because the the outer exception
    #  is intended to be printed to the screen.
    try:
        main()
    except Exception as e:
        # raise the exception again, but with another message, to see if
        #  it is the exception we're expecting
        raise Exception('Expected exception not raised')
    else:
        # main did not cause an exception to be raised
        raise Exception('Expected exception not raised')

# Generated at 2022-06-20 22:15:42.606866
# Unit test for function main
def test_main():
  try:
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    main()
  except SystemExit:
    pass

# Generated at 2022-06-20 22:15:43.799773
# Unit test for function main
def test_main():
    # run function main
    main()

# Generated at 2022-06-20 22:15:49.441195
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='dict', default={'ping': 'pong'}),
        ),
    )

    result = dict(
        ping=module.params['data']['ping'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:50.058239
# Unit test for function main
def test_main():
    assert 1 == 1

# Generated at 2022-06-20 22:16:02.835997
# Unit test for function main
def test_main():
    args = dict(
        data = 'pong',
    )
    with pytest.raises(Exception) as e:
        main(args)
    args = dict(
        data = 'pong',
    )
    with pytest.raises(Exception) as e:
        main(args)

# Generated at 2022-06-20 22:16:14.173058
# Unit test for function main
def test_main():
    # Test '--check' mode
    args = dict()
    args['data'] = 'pong'

    module = AnsibleModule(argument_spec=args)
    result = dict(changed=False, ping='pong')
    module.exit_json(**result)

    # Test '--check' mode
    args = dict()
    args['data'] = 'crash'

    module = AnsibleModule(argument_spec=args)
    result = dict(changed=True, ping='crash')
    module.exit_json(**result)


# Unit tests
# @unittest.skip("skip until refactor")
# class TestPing(unittest.TestCase):
#     def test_ping_data_pong(self):
#         args = dict()
#         args['data'] = 'pong'
#

# Generated at 2022-06-20 22:16:20.168841
# Unit test for function main
def test_main():
    ansible_args = dict(
        data='pong'
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = ansible_args
    module.exit_json = print
    main()

# Generated at 2022-06-20 22:16:23.363947
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == None


# Generated at 2022-06-20 22:16:25.956356
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    result = main()
    assert result == dict(ping='pong')

# Generated at 2022-06-20 22:16:30.241863
# Unit test for function main
def test_main():
    args = dict(
        data='pong'
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    ping_result = dict(
        ping='pong',
    )

    assert module.params['data'] == args['data']
    assert dict(ansible_facts=ping_result) == main()

# Generated at 2022-06-20 22:16:38.683663
# Unit test for function main
def test_main():
    args = dict(
        data='pong'
    )
    result = dict(
        ping='pong'
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str')
        ),
        supports_check_mode=False
    )
    module.params = args

    main()

    assert module.exit_json.called
    assert module.exit_json.call_count == 1

    call_args, call_kwargs = module.exit_json.call_args
    assert call_args == ()
    assert call_kwargs == dict(result=result)

# Generated at 2022-06-20 22:16:39.343289
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:16:50.011084
# Unit test for function main
def test_main():

    # Inside the unit test, the __main__ module has already
    # been imported and is available as an attribute.
    #
    # So, in order to test main(), we need to save off
    # the current value of __main__.main and then restore
    # it when the test is complete.
    #
    # We also need to temporarily replace __main__ with
    # a fake module.
    import __main__

    saved_main = __main__.main

    class FakeModule:
        def __init__(self, *args, **kwargs):
            self.exit_json = kwargs['exit_json']


# Generated at 2022-06-20 22:16:59.612035
# Unit test for function main
def test_main():
    # Mock out the main function to test main
    # Not using the pytest monkeypatch fixture as it seems to cause issues with the AnsibleModule object
    # created in main
    original_main = ping.main
    def mock_main():
        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True
        )
        return module
    ping.main = mock_main
    try:
        module = ping.main()
        # Test that the default arguments are properly set
        assert module.params['data'] == 'pong'
    finally:
        ping.main = original_main

# Generated at 2022-06-20 22:17:16.247546
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:17:28.453805
# Unit test for function main
def test_main():
    import pytest
    
    # prepare the test environment
    test_vars = load_fixture('test_main.json')
    test_args = load_fixture('test_main_args.json')
    mocked_module = mock.MagicMock()
    mocked_module.params = test_args
    
    # execute the code to be tested
    with pytest.raises(Exception) as excinfo:
        main()
    
    # assert that the code produced the expected results
    assert 'boom' in str(excinfo.value)
    assert mocked_module.exit_json.call_args[0][0]['ping'] == 'pong'
    assert mocked_module.exit_json.call_count == 1
    assert mocked_module.fail_json.call_count == 0

# Generated at 2022-06-20 22:17:36.798221
# Unit test for function main
def test_main():
    import ansible.module_utils.basic as basic
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import StringIO
    import json
    answer = {
     'ping': 'pong'
    }
    module = AnsibleModule(argument_spec={
        'data': {'type': 'str', 'default': 'pong'}
    })
    try:
        main()
    except SystemExit:
        pass
    result = sys.stdout.getvalue()
    assert result == json.dumps(answer, sort_keys=True, indent=4)

# Unit test function raise an exception

# Generated at 2022-06-20 22:17:44.538000
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        main()
    except Exception:
        assert test_module.params['data'] == 'crash'
    else:
        assert test_module.params['data'] != 'crash'

# Generated at 2022-06-20 22:17:45.529040
# Unit test for function main
def test_main():
    print("Test main function")
    main()

# Generated at 2022-06-20 22:17:50.218089
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:17:55.675799
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert 'ping' in m.exit_json(ping='pong')

# Generated at 2022-06-20 22:18:00.645813
# Unit test for function main
def test_main():
    list_of_attributes = {
        'argument_spec': {
            'data': {
                'default': 'pong',
                'type': 'str'
            }
        },
        'supports_check_mode': True
    }
    assert main() == AnsibleModule(list_of_attributes)

# Generated at 2022-06-20 22:18:07.874657
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module

    result = dict(
        ping=module.params['data'],
    )
    assert result['ping'] == 'pong'
    assert result
    assert module

# Generated at 2022-06-20 22:18:11.101393
# Unit test for function main
def test_main():
    data = dict(
        params = dict(
            # ping value
            data = 'pong',
        ),
        check_mode = True,
    )
    obj = AnsibleModule(data)
    assert main() == obj.exit_json

# Generated at 2022-06-20 22:18:56.282242
# Unit test for function main
def test_main():
    # parm_data = 'pong'
    # result = main(module)
    # assert result['ping'] == parm_data
    assert True

# Generated at 2022-06-20 22:19:04.031391
# Unit test for function main
def test_main():
    module = ansible_module_ping()
    # Add some return values
    setattr(module, '_ansible_check_mode', True)
    setattr(module, '_ansible_diff_mode', True)
    setattr(module, '_ansible_debug', True)

    # We can not test this module easy.
    # The module can not be called in a stable way.
    assert False
    # assert module() == (True, dict(ping='pong'))


# Generated at 2022-06-20 22:19:04.510501
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:19:09.258390
# Unit test for function main
def test_main():
    # Make sure we can create a module.
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test for no changes if we don't cause an exception.
    assert module.params['data'] == 'pong'
    assert module.check_mode == True

    # Test for changes if we cause an exception.
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'crash'
    assert module.check_mode == True

# Generated at 2022-06-20 22:19:17.037321
# Unit test for function main
def test_main():
    data = {
        "ansible_facts": {
            "discovered_interpreter_python": "/usr/bin/python"
        },
        "changed": False,
        "ping": "pong"
    }

    args = dict(
        data="pong"
    )

    is_error, has_changed, result = main()

    assert not is_error
    assert not has_changed
    assert data == result


# Generated at 2022-06-20 22:19:26.557837
# Unit test for function main
def test_main():
    f_name = '__main__.main'

    # Create the 'ansible_module' mock
    module = AnsibleModuleMock()

    # Set the return values for tuple of the 'ansible_module.params' attribute
    # Mock the 'ansible_module.params' attribute to access it like a dict
    module.params = {
        'data': 'pong'
    }

    # Set the return value of the 'ansible_module.exit_json' method
    setattr(module, 'exit_json', get_exit_json_mock(module))

    # Set the return value of the 'ansible_module.fail_json' method
    setattr(module, 'fail_json', get_fail_json_mock(module))

    # Test the main() function
    main()

    # Ensure the ansible_

# Generated at 2022-06-20 22:19:33.877189
# Unit test for function main
def test_main():
    args = dict(
        data='foo',
    )

    result = dict(
        ping='foo',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    main_result = main()
    assert main_result['result'] == result

# Generated at 2022-06-20 22:19:39.157551
# Unit test for function main
def test_main():
    test_dict = dict(
        data=dict(type="str", defaul="pong")
    )
    module = AnsibleModule(
        argument_spec=test_dict
    )
    assert module.params['data'] == 'pong'

    module.params['data'] = 'crash'
    try:
        main()
    except:
        assert True

# Generated at 2022-06-20 22:19:40.617210
# Unit test for function main
def test_main():
    print('This is a unit test')

# Unit test end

# Generated at 2022-06-20 22:19:43.964588
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    with pytest.raises(Exception) as e:
        main()
    assert 'boom' in str(e)

# Generated at 2022-06-20 22:21:16.137707
# Unit test for function main

# Generated at 2022-06-20 22:21:19.450578
# Unit test for function main
def test_main():

    test_module.params = {'data': 'pong'}
    # test_module.params = {'data': 'crash'}
    result = main()
    assert result['ping'] == 'pong'

import pytest


# Generated at 2022-06-20 22:21:24.797984
# Unit test for function main
def test_main():
    import json
    import pytest

    from . import ping

    def run_module(module, data):
        return json.loads(module.exit_json(**data))

    args = dict(
        data='pong'
    )
    result = dict(
        ping='pong',
    )
    assert run_module(ping, args) == result

    args = dict(
        data='crash'
    )
    with pytest.raises(Exception):
        assert(run_module(ping, args))

# Generated at 2022-06-20 22:21:27.198468
# Unit test for function main
def test_main():

    print("Unit test for function main")

    # module.exit_json(**result)
    # assert module.params['data'] == 'crash'
    # assert result == (module.exit_json(**result))

# Generated at 2022-06-20 22:21:37.216102
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExitJson
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:21:41.768719
# Unit test for function main
def test_main():
    # Create a mock module
    module = AnsibleModule(
        supports_check_mode=True
    )

    # Mock the exit json function
    module.exit_json = MagicMock()

    # Call main
    main()

    # Make sure that the exit json function was called with a ping result
    module.exit_json.assert_called_with(ping='pong')

# Generated at 2022-06-20 22:21:45.113155
# Unit test for function main
def test_main():
    # Test if ansible exits with a valid respose.
    assert exit_json.called
    assert json_response == {'ping':'pong'}
    # Test if ansible fails without proper input
    assert fail_json.called
    assert fail_json.kwargs['msg'] == 'Error: boom'

# Generated at 2022-06-20 22:21:49.414406
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:21:53.137176
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:21:59.040379
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    results = dict(
        changed=True,
        ping='pong',
    )
    assert module.main() == results
