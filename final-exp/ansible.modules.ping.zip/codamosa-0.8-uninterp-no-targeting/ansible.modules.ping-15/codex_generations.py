

# Generated at 2022-06-20 22:14:25.102635
# Unit test for function main
def test_main():
    data = dict(data='crash')
    result = dict(ping='crash')
    mock_module = MagicMock()
    mock_module.params = data
    mock_module.exit_json.return_value = result
    try:
        main()
    except:
        pass
    assert mock_module.exit_json.called
    assert mock_module.exit_json.call_count == 1
    assert mock_module.exit_json.call_args == call(result)

# Generated at 2022-06-20 22:14:30.156805
# Unit test for function main
def test_main():
    ## fail module
    old_data = {'ANSIBLE_MODULE_ARGS': {'data': 'crash'}}
    with pytest.raises(Exception):
        main()
    ## success module
    old_data = {'ANSIBLE_MODULE_ARGS': {'data': 'pong'}}
    main()

# Generated at 2022-06-20 22:14:32.535556
# Unit test for function main
def test_main():
    params = { 'data': 'crash'}
    with pytest.raises(Exception, match=r'boom'):
        main(params)

# Generated at 2022-06-20 22:14:35.551799
# Unit test for function main
def test_main():
    from ansible.module_utils.common.removed import removed_module

    assert removed_module

# Generated at 2022-06-20 22:14:43.835994
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import six
    import sys
    import json
    import pytest
    if six.PY3:
        return_dict = {'ping': 'pong'}
        if sys.version_info.major == 3 and sys.version_info.minor >= 6:
            print_string = "'" + json.dumps(return_dict, indent=4) + "'"
        else:
            print_string = "'" + json.dumps(return_dict, indent=4, sort_keys=True) + "'"
        assert main() == None
    else:
        return_dict = {'ping': 'pong'}

# Generated at 2022-06-20 22:14:47.396472
# Unit test for function main
def test_main():
    data = 'crash'
    result = {'changed': False, 'ping': 'pong'}
    result_fail = {'msg': 'boom'}
    with pytest.raises(Exception):
        main()
    assert result == result_fail

# Generated at 2022-06-20 22:14:55.071387
# Unit test for function main
def test_main():
    # Test module with args
    module_args = dict(
        data=dict(type='str', default='pong'),
    )
    # Test AnsibleModule with mocked args and params
    module_mock = AnsibleModule(argument_spec=module_args)
    # Test the return value of the test module.
    result = module_mock.main()
    assert result['ping'] == 'pong'
    # Test the exception case
    module_mock.params['data'] = 'crash'
    result = module_mock.main()
    assert result['failed'] == True

    module_mock.params['data'] = 'pong'
    module_mock.check_mode = True

# Generated at 2022-06-20 22:15:06.927595
# Unit test for function main
def test_main():
    import json
    import sys
    import pytest
    from ansible.module_utils._text import to_bytes

    test_cases = [
        {
            u'parameters': {
                u'data': u'bing'
            },
            u'expected': {u'ping': u'bing'}
        },
        {
            u'parameters': {
                u'data': u'crash'
            },
            u'expected': {
                u'exception':
                u'boom',
                u'failed':
                True,
                u'changed':
                False,
                u'_ansible_parsed':
                True
            }
        },
    ]


# Generated at 2022-06-20 22:15:12.317991
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:15:20.802672
# Unit test for function main
def test_main():

    # You can create your own test cases by creating a "my_test_file.py" and using the pytest.main(['my_test_file.py'])
    # command line.

    # The test below is using the pytest.main() method via the script name.
    pytest.main(['test_ansible_builtin_ping.py'])

    # Alternatively, you can create a test_module class (see other tests for examples)
    # and run it like this:
    #   class Test_ansible_builtin_ping(unittest.TestCase):
    #       def setUp(self):
    #           pass
    #       def tearDown(self):
    #           pass
    #       def tests(self):
    #           pass
    #
    #   if __name__ == '__main__':


# Generated at 2022-06-20 22:15:31.695238
# Unit test for function main
def test_main():
    test_args = dict(data='prong')
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')), supports_check_mode=True)
    module.params = test_args.copy()
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='prong')


# Generated at 2022-06-20 22:15:33.683189
# Unit test for function main
def test_main():
    # be a good captain and prepare yourself for failure
    assert True == False
    # if you got this far you set yourself up for success
    assert True == True

# Generated at 2022-06-20 22:15:41.808278
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:44.247046
# Unit test for function main
def test_main():
    result = dict(
        ping='pong'
    )
    assert result == main(data='pong')

# Generated at 2022-06-20 22:15:44.931727
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:15:53.683069
# Unit test for function main
def test_main():
    my_dict = {}
    my_dict['data'] = 'pong'
    my_dict['CHECKMODE'] = False
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    def test_module():
        from ansible.module_utils.basic import AnsibleModule
        return AnsibleModule
    module = test_module()
    setattr(module, 'params', my_dict)
    assert main() == {'changed': False, 'ping': 'pong'}

# Generated at 2022-06-20 22:16:00.745068
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )

    assert(dict(invocation=dict(module_args=dict(data='pong'))) == module.params)
    assert(dict(ping='pong') == result)

# Generated at 2022-06-20 22:16:12.101853
# Unit test for function main
def test_main():
    source_code = """
        /usr/bin/ansible all -i /etc/ansible/hosts -c local -m ping -a "data=pong"

        /usr/bin/ansible all -i /etc/ansible/hosts -c local -m ping -a "data=crash"
    """

    def execute_module(data):
        import sys
        import subprocess
        cmd = [sys.executable, '-c', source_code.split('\n')[data].lstrip()]
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        output, err = p.communicate()
        print(output.decode("utf-8"))

    # Test of function main
    execute_module(0)
    # Test if an exception is thrown
    execute_

# Generated at 2022-06-20 22:16:16.142549
# Unit test for function main
def test_main():
    args = dict(data="pong")
    with patch.object(AnsibleModule, 'exit_json') as mock_exit, \
        patch.object(AnsibleModule, 'params', new=args):
        main()
        result = mock_exit.call_args[0][0]

    assert(result['ping'] == 'pong')

# Generated at 2022-06-20 22:16:26.330147
# Unit test for function main
def test_main():

    # set up the test
    module_args = dict(
        data="pong",
    )
    module_args_global = dict(
    )

    set_module_args(module_args, module_args_global)
    check_for_special_parameters(module_args)

    test_module = AnsibleModule(
        argument_spec=check_parameter_bypass(module_args, 'ping'),
        supports_check_mode=True,
    )

    # actual testing
    try:
        result = main()
    except Exception as e:
        test_module.fail_json(msg=str(e))

    # testing the module result
    test_module.exit_json(**result)


# unit test for function main
import pytest
import ansible_collections.ansible.builtin.plugins

# Generated at 2022-06-20 22:16:35.347760
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:16:37.285542
# Unit test for function main
def test_main():
    # TODO
    assert True

# Generated at 2022-06-20 22:16:38.400316
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:16:43.809511
# Unit test for function main
def test_main():
    """ AnsiblePingUnitTest """
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    def test_id(id):
        return None

    def test_argument_spec():
        return {
            "data": {"default": "pong", "type": "str"}
        }

# Generated at 2022-06-20 22:16:48.932927
# Unit test for function main
def test_main():

    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    pass

# Generated at 2022-06-20 22:16:54.961089
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:17:07.782436
# Unit test for function main
def test_main():
    argv = [
        'ping.py',
        'arg1=foo',
    ]
    with patch.object(__builtins__, '__import__', lambda *args: None):
        module_mock = MagicMock()
        module_mock.exit_json = lambda *args: sys.exit()
        with patch.object(sys, 'argv', argv):
            with patch.object(ansible.module_utils.basic, 'AnsibleModule', return_value=module_mock) as module_mock:
                
                ping.main()
                module_mock.assert_called_with(
                    argument_spec=dict(
                        data=dict(type='str', default='pong'),
                    ),
                    supports_check_mode=True
                )

# Generated at 2022-06-20 22:17:14.301425
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # Test function call with no argument
    assert(main() == {"ping": "pong"})
    # Test function call with argument
    assert(main(module) == {"ping": "pong"})
    # Test function call with exception
    assert(main(module, "crash") == Exception("boom"))

# Generated at 2022-06-20 22:17:19.744177
# Unit test for function main
def test_main():
    args = dict(
        data='crash'
    )
    kwargs = dict(
        exit_json=None,
        supports_check_mode=True
    )

    import ansible.module_utils.basic as basic
    m = basic.AnsibleModule
    # Skip the actual test
    m.exit_json = lambda *args, **kwargs: True
    m.fail_json = lambda *args, **kwargs: True

    assert m.main == main

    with pytest.raises(Exception) as e:
        m.main(args, kwargs)


# Generated at 2022-06-20 22:17:32.197791
# Unit test for function main
def test_main():
    import tempfile
    import json
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    class AnsibleModule:
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

        def exit_json(self, **kwargs):
            self.exit = kwargs
            self.exit.update(changed=False)
            raise SystemExit()

    # Test that we get pong by default
    m = AnsibleModule({})
    try:
        main()
    except SystemExit:
        pass
    assert m.exit['ping'] == 'pong'

    # Test that if we specify data it contains that data

# Generated at 2022-06-20 22:17:49.386720
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-20 22:17:55.773131
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:18:00.346307
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'


# Generated at 2022-06-20 22:18:11.931686
# Unit test for function main
def test_main():
    test_module = '''
#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2012, Michael DeHaan <michael.dehaan@gmail.com>
# (c) 2016, Toshio Kuratomi <tkuratomi@ansible.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function
__metaclass__ = type


DOCUMENTATION = '''

# Generated at 2022-06-20 22:18:12.497670
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:18:16.021395
# Unit test for function main
def test_main():
    m = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong'}})
    assert main() == m.exit_json(ping=m.params['data'])

# Generated at 2022-06-20 22:18:20.378717
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    # this is the return value when data='pong'
    exp = {"AnsibleModule":  {"argument_spec": {}, "check_mode": False, "diff": False, "params": {}}}
    assert exp == mod.__dict__

# Generated at 2022-06-20 22:18:23.837048
# Unit test for function main
def test_main():
    module_args = dict(data='pong'
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.exit_json(**main())

# Generated at 2022-06-20 22:18:26.965714
# Unit test for function main
def test_main():
    keys = ['ping']
    params = {}
    result = { }
    # Test module without parameters
    ping_result = main(params=params)
    assert ping_result is not None
    assert ping_result['ping'] == 'pong'
    assert ping_result.keys() == keys


# Generated at 2022-06-20 22:18:32.184098
# Unit test for function main
def test_main():
    import sys, mock
    m = mock.Mock()
    m.params = {}
    m.params['data'] = 'gamez'
    m.check_mode = False
    m.exit_json = lambda x: sys.exit(1)
    try:
        main()
        assert False
    except SystemExit as e:
        assert True

# Generated at 2022-06-20 22:19:15.686371
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    data = dict(
        data='pong',
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert data == dict(ping='pong')

# Generated at 2022-06-20 22:19:26.390568
# Unit test for function main
def test_main():
    capture_args = []
    capture_kwargs = []

    class AnsibleModuleMock:
        def __init__(self, *args, **kwargs):
            capture_args.append(args)
            capture_kwargs.append(kwargs)
        def exit_json(self, **kwargs):
            return kwargs

    def fake_module(**kwargs):
        return AnsibleModuleMock(**kwargs)

    def fake_exception(message):
        raise Exception(message)

    saved_module = __builtins__.__import__
    __builtins__.__import__ = fake_module

    saved_exception = __builtins__.__import__
    __builtins__.__import__ = fake_exception

    main()

    __builtins__.__import__ = saved_module

   

# Generated at 2022-06-20 22:19:32.333491
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-20 22:19:43.171555
# Unit test for function main
def test_main():
    from ansible.module_utils.common.dict_transformations import _to_bytes
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    with pytest.raises(Exception):
        if module.params['data'] == 'crash':
            raise Exception("boom")
        else:
            assert module.params['data'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:19:47.448925
# Unit test for function main
def test_main():
    with AnsibleRunner(playbook_params=dict(
        data='pong'
    )) as am:
        results = am.run_module('ping')

    assert results.status == 'SUCCESS'
    assert results.data['ping'] == 'pong'


# Generated at 2022-06-20 22:19:54.714762
# Unit test for function main
def test_main():
    module_instance = {
        "check_mode": False,
        "params": {
            "data": "pong"
        }
    }
    main()
    assert module_instance["state"] == "pong"

"""
module_instance = {
    "check_mode": False,
    "params": {
        "data": "pong"
    }
}
print module_instance

main()
print module_instance
"""

# Generated at 2022-06-20 22:19:55.319422
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:19:56.447970
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:19:57.242082
# Unit test for function main
def test_main():
    print("Test main")
    main()

# Generated at 2022-06-20 22:20:08.114958
# Unit test for function main
def test_main():
    module_data = {'data': 'foo'}

    module_mock = MagicMock()
    module_mock.params = module_data

    main(module_mock)
    module_mock.exit_json.assert_called_once()
    assert module_mock.exit_json.call_args_list[0][0][0] == {'ping': 'foo'}

    module_data = {'data': 'crash'}

    module_mock = MagicMock()
    module_mock.params = module_data

    main(module_mock)
    module_mock.fail_json.assert_called_once()
    assert module_mock.fail_json.call_args_list[0][0][0] == "boom"

# Generated at 2022-06-20 22:21:40.108524
# Unit test for function main
def test_main():
    assert main() == True

# Generated at 2022-06-20 22:21:48.106355
# Unit test for function main
def test_main():
    """test_main
    test that data='pong' returns as expected
    """

    import json
    import subprocess

    ansible_ping_params = dict(
        data='pong',
    )

# Generated at 2022-06-20 22:21:50.384243
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default="pong"),
        ),
        supports_check_mode=True
    )
    assert main() is not None

# Generated at 2022-06-20 22:21:53.662057
# Unit test for function main
def test_main():
    module_args = {
        'data': 'pong',
    }
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    result = dict(
        ping='pong',
    )

    assert module.exit_json(**result) == None, "This is expected to be None"

# Generated at 2022-06-20 22:21:59.630125
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-20 22:22:05.428371
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:22:10.107465
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import ansible.module_utils.basic
    ansible.module_utils.basic = basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    out = main()
    assert out['ping'] == 'pong'

# Generated at 2022-06-20 22:22:16.666152
# Unit test for function main
def test_main():
    """Test if module works with function main()"""

    ping_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert ping_module.params['data'] == 'pong'
    ping_module.params['data'] = 'crash'
    with pytest.raises(Exception) as excinfo:
        main()
    assert 'boom' in str(excinfo.value)

# Generated at 2022-06-20 22:22:28.296055
# Unit test for function main
def test_main():
    """ Test module ping.main() with mocked module input_data """

    # Modules input_data
    module_input_data = {
        'argument_spec': {
            'data': {
                'type': 'str',
                'default': 'pong'
            }
        },
        'check_mode': True,
        'params': {
            'data': 'crash'
        }
    }

    # Mock class for module
    class AnsibleModuleMock:
        def __init__(self, *_):
            pass

        def exit_json(*_):
            pass

    # When AnsibleModule() is called it will use the input_data above to
    # create the class
    module = AnsibleModuleMock()

    with pytest.raises(Exception, match=r'boom'):
        main

# Generated at 2022-06-20 22:22:29.935167
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    import ping
    ping.main()