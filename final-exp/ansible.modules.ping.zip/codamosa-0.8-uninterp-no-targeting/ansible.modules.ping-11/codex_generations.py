

# Generated at 2022-06-20 22:14:23.820186
# Unit test for function main
def test_main():
    # Arrange
    module_args = dict(
        data="pong"
    )

    def exit_json(*args, **kwargs):
        pass

    def fail_json(*args, **kwargs):
        pass

    module = Mock()
    module.params = module_args
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Act
    main()

    # Assert
    assert module.params == module_args

# Generated at 2022-06-20 22:14:29.549411
# Unit test for function main
def test_main():
    # Pre-conditions:
    #   Imitation of a module_utils.basic.AnsibleModule object
    #   Imitation of a module object
    class AnsibleModuleTest:
        def __init__(self, argument_spec, supports_check_mode=False):
            self.params = {'data': 'pong'}
            self.check_mode = True
            self.exit_json = lambda **kwargs: True
    module = AnsibleModuleTest({'data': {'type': 'str', 'default': 'pong'}}, supports_check_mode=True)

    # Action
    main()

    # Post-conditions
    assert module.check_mode is True
    assert module.params['data'] == 'pong'

# Generated at 2022-06-20 22:14:40.197715
# Unit test for function main
def test_main():
    """
    Unit test for function main
    See https://testinfra.readthedocs.io/en/latest/modules.html
    """
    import pytest

    # Test with params with valid inputs
    with pytest.raises(Exception) as exc:
        module = dict(
            params=dict(
                data='crash'
            )
        )
        main(module)
        assert exc.value.message == 'boom'

    # Test with params with valid inputs
    module = dict(
        params=dict(
            data='pong'
        )
    )
    main(module)
    result = dict(
        ping=module['params']['data']
    )
    assert result

# Generated at 2022-06-20 22:14:47.531332
# Unit test for function main
def test_main():
    test_ansible_module = dict(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    test_main_data = dict(
        ping='pong'
    )

    with patch.object(AnsibleModule, 'exit_json') as mock_exit:
        main()
        assert AnsibleModule.__init__.called

    mock_exit.assert_called_once_with(**test_main_data)

# Generated at 2022-06-20 22:14:48.428482
# Unit test for function main
def test_main():
    #TODO: fix unit test
    assert True

# Generated at 2022-06-20 22:14:55.256725
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    c = AnsibleExitJson(module.params['data'])
    if module.params['data'] == 'crash':
        c = AnsibleFailJson(msg="boom")
    assert c.exit_json == dict(ping=module.params['data'])

# Generated at 2022-06-20 22:15:02.779071
# Unit test for function main
def test_main():

    arguments = dict(
        data='pong'
    )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping='pong',
    )

    assert (result == main(module, arguments))

# Generated at 2022-06-20 22:15:11.458285
# Unit test for function main
def test_main():
    # This test simulates a basic test
    #
    # ansible -m ansible.builtin.ping localhost
    #
    # Normal return path:
    # Expected return value: {"msg": "pong"}

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert result['ping'] == 'pong'

    # This test simulates a negative test where the user asks for the module to
    # crash
    #
    # ansible -m ansible.builtin.ping localhost -a data=crash
    #
    # Expected return value: Exception("boom")
    module = Ans

# Generated at 2022-06-20 22:15:12.115709
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:15:17.493217
# Unit test for function main
def test_main():
    class TestAnsibleModule(object):
        def __init__(self, argument_spec=dict(), supports_check_mode=False):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = dict()
            self.fail_json = lambda *args, **kwargs: False

        def exit_json(self, **kwargs):
            self.result = kwa

# Generated at 2022-06-20 22:15:29.041024
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    try:
        main()
        assert False
    except SystemExit:
        assert False
    except:
        assert True
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)


# Generated at 2022-06-20 22:15:39.126254
# Unit test for function main
def test_main():
    #import ansible.module_utils.ansible_release
    #print(ansible.module_utils.ansible_release.__file__)
    print('File: {}'.format(__file__))
    ping_data_string = '{}'.format(__file__)
    print(ping_data_string)
    ping_data_string_safe = ping_data_string.replace('/', '\/')
    print(ping_data_string_safe)
    ping_data_list = [ping_data_string]
    print(ping_data_list)

    ping_data_dict = dict(
        ping=ping_data_list
    )
    print(ping_data_dict)

    assert ping_data_dict == {'ping': [ping_data_string]}

# Generated at 2022-06-20 22:15:43.720598
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-20 22:15:52.023319
# Unit test for function main
def test_main():
    import sys
    import json

    # Manually set args and initialize AnsibleModule
    sys.argv = ['ping', '-a', 'data=pong']
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))

    # Run the module code
    main()

    # Assert values in the resulting JSON
    result = json.loads(sys.stdout.getvalue())
    assert result['changed'] == False
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:16:01.967972
# Unit test for function main
def test_main():
    import ansible.modules.network.ping

    module_args = dict(
        data=dict(type='str', default='pong'),
    )

    obj = ansible.modules.network.ping.AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if obj.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=obj.params['data'],
    )

    obj.exit_json(**result)

# Generated at 2022-06-20 22:16:09.246721
# Unit test for function main
def test_main():
    # Note: An assert is used in main and if the assert fails,
    # the entire function returns False which is interpreted
    # as a failure by a pytest test (AKA it generates a red
    # X instead of a green check mark).
    # Because of this, this function is broken up such that
    # each assert is in a separate function.
    # In the future, this unit test will go away as assert
    # statements are removed from the python code.
    assert test_main_and_exit_json()
    assert test_main_crash()


# Generated at 2022-06-20 22:16:16.180463
# Unit test for function main
def test_main():

    # Unit test for function main with parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:16:17.143324
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-20 22:16:24.681647
# Unit test for function main
def test_main():
    args = dict(
        data='crash'
    )
    with pytest.raises(Exception) as ex:
        main(args)
        pytest.fail('An exception should have been raised')
    assert 'boom' in str(ex.value)
    assert ex.type == Exception
    assert type(ex.value) == Exception
    assert ex.value.args == ('boom',)
    assert ex.type.__name__ == 'Exception'
    assert ex.traceback is not None

# Generated at 2022-06-20 22:16:29.329069
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:16:48.352915
# Unit test for function main
def test_main():
    data = []
    # Test function call with normal arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test function call with normal arguments
    result = dict(
        ping='pong',
    )
    data.append(result)

    # Test function call with normal arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Test function call with normal arguments
    result = dict(
        ping='pong',
    )
    data.append(result)

    # Test function call with normal arguments

# Generated at 2022-06-20 22:16:59.996361
# Unit test for function main
def test_main():
    import json

    module_args = {}
    module_args['data'] = 'pong'
    module_args['_ansible_check_mode'] = False
    module_args['_ansible_debug'] = False
    module_args['_ansible_diff'] = False

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # Create a mock for ansible.module_utils.basic.AnsibleModule
    ansible_module_instance = MockAnsibleModule()

    # Create a mock for function exit_json
    exit_json = MagicMock(name='exit_json')
    ansible_module_instance.exit_json = exit_json

    main()

    result = json.loads(exit_json.call_args[0][0].result)

    assert result

# Generated at 2022-06-20 22:17:12.331987
# Unit test for function main
def test_main():
    # mock argument spec
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    )

    # mock module
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    # set module args
    setattr(module, 'params', dict(
        data='pong',
    ))

    # run module
    main()

    # test result
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['ping'] == 'pong'

    # set module args
    setattr(module, 'params', dict(
        data='crash',
    ))

    # run module
    main()

    # test exception
    assert module.fail_json.called

# Generated at 2022-06-20 22:17:18.012812
# Unit test for function main
def test_main():
    my_dict = { 'data': 'pong' }

    M = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ), supports_check_mode=True)
    M.params = my_dict
    pingrd = { 'ping': 'pong' }
    M.exit_json(**pingrd)

# Generated at 2022-06-20 22:17:28.842171
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as e:
        main()
    assert str(e.value) == "boom"

# Generated at 2022-06-20 22:17:35.116328
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    with pytest.raises(Exception) as exc:
        module.params['data'] = 'crash'
        main()
    assert 'boom' in str(exc.value)

    try:
        module.params['data'] = 'crash'
    except Exception as e:
        pytest.fail("Unexpected exception: " + str(e))

    result = dict(
        ping=module.params['data'],
    )

# Generated at 2022-06-20 22:17:41.798083
# Unit test for function main
def test_main():
    def test_args():
        return dict(
            data=dict(type='str', default='pong'),
        )

    def test_failure(module):
        raise Exception("boom")

    def test_success(module):
        result = dict(
            ping=module.params['data'],
        )

        module.exit_json(**result)

    # run unit test
    import unittest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_cases = [
        (dict(data='pong'), test_success),
        (dict(data='crash'), test_failure),
    ]

    for test_args, expected_results in test_cases:
        module = AnsibleModule(argument_spec=test_args())

        # for

# Generated at 2022-06-20 22:17:45.388909
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    assert module.params['data'] == 'pong'

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:17:48.606703
# Unit test for function main
def test_main():
    # this is not a good test, really
    test_dict = dict(data='pong')
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params.update(test_dict)
    main()

# Generated at 2022-06-20 22:17:53.530318
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    # No test exists, just use the function.


# Generated at 2022-06-20 22:18:17.126235
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:18:17.697332
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:18:25.475625
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # Check behaviour when valid data is passed
    test_module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Build dummy result
    test_result = dict(
        ping=test_module.params['data'],
    )

    # Check _ansible_module_runner() returns test_result to main()
    test_module.exit_json(**test_result)
    assert test_result['ping'] == 'pong'

    import pytest
    # Check behaviour when invalid data is passed

# Generated at 2022-06-20 22:18:32.994758
# Unit test for function main
def test_main():
    import sys
    import __builtin__
    # Inject fake display class to influence outcome of
    # AnsibleModule.consider_explicit_target example code
    class FakeDisplay:
        def verbosity_(self):
            return 0
    __builtin__.__dict__['ansible_display'] = FakeDisplay()
    # Inject our own parser to stop execution
    class Parser:
        def exit(self, n=0, msg=None):
            pass
    sys.argv = [ sys.argv[0] ]
    # FIXME: Write tests
    #main()

# Generated at 2022-06-20 22:18:42.151371
# Unit test for function main
def test_main():
    import json
    import os
    from ansible_collections.ansible.builtin.plugins.module_utils.common.removed import removed_module
    import pytest

    # Capture command line arguments for AnsibleModule
    args = [
        '- ',
    ]

    # Generate valid argument spec for AnsibleModule
    argument_spec = dict(
        data=dict(type='str', default='pong'),
    )

    # Create an AnsibleModule from the arguments provided
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    # Run the main() function
    main()



# Generated at 2022-06-20 22:18:51.296175
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import sys

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
        )

    try:
        if module.params['data'] == 'crash':
            raise Exception("boom")

        result = dict(
            ping=module.params['data'],
            )

        module.exit_json(**result)
    except Exception:
        exc_type, exc_value, exc_tb = sys.exc_info()
        dummy, import_error, dummy = get_exception()
        module

# Generated at 2022-06-20 22:18:54.769584
# Unit test for function main
def test_main():

    # Import
    import os
    import tempfile
    import json


# Generated at 2022-06-20 22:19:06.101978
# Unit test for function main
def test_main():
    from mock import Mock, create_autospec
    from ansible.module_utils import base
    from ansible.module_utils.basic import AnsibleModule
    module = create_autospec(base.AnsibleModule)
    module.params = {'data': 'pong'}
    module.exit_json = Mock()
    ansible.module_utils.basic.AnsibleModule = Mock(return_value=module)
    ansible.module_utils.basic.AnsibleModule.fail_json = Mock(return_value=module)
    ansible.module_utils.basic.AnsibleModule.run_command = Mock(return_value=module)
    ansible.module_utils.basic.AnsibleModule.run_command = Mock(return_value=module)
    ansible.module_utils.basic.An

# Generated at 2022-06-20 22:19:19.040514
# Unit test for function main
def test_main():

    def exit_json(*args, **kwargs):
        assert args[0]["ping"] == "pong"
        raise SystemExit(0)

    def fail_json(*args, **kwargs):
        raise SystemExit(1)

    with patch.object(AnsibleModule, "exit_json", exit_json):
        with patch.object(AnsibleModule, 'fail_json', fail_json):
            with patch('ansible.module_utils.basic.AnsibleModule'):
                main()

    with patch.object(AnsibleModule, "exit_json", exit_json):
        with patch.object(AnsibleModule, 'fail_json', fail_json):
            with patch('ansible.module_utils.basic.AnsibleModule'):
                main()


# Generated at 2022-06-20 22:19:20.687366
# Unit test for function main
def test_main():
    if result['changed']:
        return True
    else:
        return False
test_main()

# Generated at 2022-06-20 22:20:02.380963
# Unit test for function main
def test_main():
    args = {
                "new_attributes": {
                    "value": 1,
                    "description": "Changed by Ansible"
                },
                "current_attributes": {
                    "value": 0,
                    "description": "Old description"
                }
            }
    args = module_args_parser(args)
    result = main(args)
    assert result == {
        'failed': False,
        'meta': {
            'current_attributes': {
                'description': 'Old description',
                'value': 0
            },
            'new_attributes': {
                'description': 'Changed by Ansible',
                'value': 1
            }
        }
    }


# Generated at 2022-06-20 22:20:03.647886
# Unit test for function main
def test_main():
  assert main() == {"changed": False, "ping": "pong"}

# Generated at 2022-06-20 22:20:10.143039
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if not module.params['data']:
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:20:17.589724
# Unit test for function main
def test_main():
    test_module = AnsibleModule({'data': 'foo'}, check_mode=True)
    result_data = {"ping": "foo"}
    result_exit_json = {'changed': False, 'ping': 'foo'}
    result_fail_json = {'failed': True}

    def mock_exit_json(data):
        assert data == result_exit_json
    def mock_fail_json(data):
        assert data == result_fail_json

    # Test normal case
    with mock.patch.object(test_module, 'exit_json', mock_exit_json):
        main()

    # Test crash exception case

# Generated at 2022-06-20 22:20:22.113109
# Unit test for function main
def test_main():
    my_data = 'pong'
    my_module = AnsibleModule({'data': my_data}, check_mode=False)
    main()
    assert 'ping' in my_module.exit_json.keys()
    assert my_module.exit_json['ping'] == my_data

# Generated at 2022-06-20 22:20:27.481330
# Unit test for function main
def test_main():
  temp_module = None
  try:
    temp_module = AnsibleModule(
      argument_spec=dict(
        data=dict(type='str', default='pong'),
      ),
      supports_check_mode=True
    )
    main()
  finally:
    if temp_module is not None:
      temp_module.exit_json(**result)

# Generated at 2022-06-20 22:20:31.775103
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(ping=module.params['data'])
    module.exit_json(**result)

# Generated at 2022-06-20 22:20:36.494572
# Unit test for function main
def test_main():
  test_args = dict(
    data=dict(type='str', default='pong'),
  )
  args = dict(
    data='pong',
  )
  result = dict(
    ping='pong',
  )
  assert main() == AnsibleModule(test_args, supports_check_mode=True)
  assert module.exit_json(**result)

# Generated at 2022-06-20 22:20:41.853277
# Unit test for function main
def test_main():

    # TODO: Mock module.exit_json(**result) so we can check result

    test_param_values = [
        { "data": "pong" },
        { "data": "crash" },
    ]

    for test_params in test_param_values:
        try:
            main()
        except Exception as e:
            if test_params["data"] == "crash":
                exception_expected = True
            else:
                exception_expected = False
            assert exception_expected, "Unexpected exception from main(): %s" % e

# Generated at 2022-06-20 22:20:44.381784
# Unit test for function main
def test_main():
    # TODO: Unit test for function main
    assert True

# Generated at 2022-06-20 22:22:09.636546
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:22:10.600174
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:22:11.218287
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 22:22:18.593812
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    try:
        main()
    except Exception as e:
        print(e)

    module.params['data'] = 'crash'

    try:
        main()
    except Exception as e:
        print(e)

    module.params['data'] = 'pong'

    try:
        main()
    except Exception as e:
        print(e)


# pylama:ignore=E501,D

# Generated at 2022-06-20 22:22:26.378933
# Unit test for function main
def test_main():
    result = main()
    assert isinstance(result, dict)
    assert 'ping' in result

    result = main(dict(data='foo'))
    assert isinstance(result, dict)
    assert 'ping' in result
    assert result['ping'] == 'foo'

    try:
        main(dict(data='crash'))
    except Exception as e:
        assert 'boom' in e.message
    else:
        raise Exception("Exception expected")

# Generated at 2022-06-20 22:22:31.669471
# Unit test for function main
def test_main():
    # Assign function to module object
    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    m.exit_json = MagicMock(return_value=None)
    m.exit_json.assert_called_with(
        changed=False,
        ping='pong',
    )

# Generated at 2022-06-20 22:22:39.256398
# Unit test for function main
def test_main():
    import json
    import sys
    import os
    import pytest
    os.chdir(os.path.dirname(__file__))

    out, err, rc = run_module_kwargs(
        dict(data='foo', _ansible_check_mode=True),
        dict(ANSIBLE_MODULE_ARGS=dict(check_mode=True)))

    assert rc == 0
    assert json.loads(out) == dict(ping='foo', ansible_check_mode=True)

    with pytest.raises(Exception) as e:
        out, err, rc = run_module_kwargs(
            dict(data='crash', _ansible_check_mode=True),
            dict(ANSIBLE_MODULE_ARGS=dict(check_mode=True)))

# Generated at 2022-06-20 22:22:42.737563
# Unit test for function main
def test_main():
    data = 'pong'
    result = dict(ping=data, changed=False)
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        main()
        assert mock_exit_json.call_args == ((result,),)


# Generated at 2022-06-20 22:22:50.859199
# Unit test for function main
def test_main():
    # Test simple run with ping module
    with patch.object(AnsibleModule, 'exit_json') as exit_mock:
        # Test with default data value
        with patch.object(AnsibleModule, 'params', return_value={'data': 'pong'}):
            main()
        exit_mock.assert_called_once_with(ping='pong')

        # Test with changed data value
        with patch.object(AnsibleModule, 'params', return_value={'data': 'nope'}):
            main()
        exit_mock.assert_called_once_with(ping='nope')

    # Test exception handling with ping module

# Generated at 2022-06-20 22:22:51.541438
# Unit test for function main
def test_main():
    pass