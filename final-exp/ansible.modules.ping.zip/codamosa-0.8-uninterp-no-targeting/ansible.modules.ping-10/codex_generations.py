

# Generated at 2022-06-20 22:14:24.984807
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Unit tests

    # data=pong
    result = dict(
        ping=module.params['data'],
    )

    # data=crash
    if module.params['data'] == 'crash':
        raise Exception("boom")

    module.exit_json(**result)



# Generated at 2022-06-20 22:14:26.266884
# Unit test for function main
def test_main():
    # Exit is not used in main
    # pylint: disable=unused-variable
    pass

# Generated at 2022-06-20 22:14:29.873028
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-20 22:14:32.353691
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as excinfo:
        main()
    assert "boom" in str(excinfo.value)

# Generated at 2022-06-20 22:14:38.001176
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as am:
        am.return_value.params = {'data': 'crash'}
        with pytest.raises(Exception):
            main()

# vim: set et ts=4 sw=4

# Generated at 2022-06-20 22:14:43.186921
# Unit test for function main
def test_main():
    test_ping = {'ping': 'pong'}
    test_boom = {'boom': 'boom'}
    test = {}

    test_data = 'pong'
    test_data_crash = 'crash'

    try:
        test = main(test_data)
    except:
        test = {}

    assert test == test_ping

    try:
        test = main(test_data_crash)
        assert test == test_boom
    except:
        test = {}

    print(test)


# Generated at 2022-06-20 22:14:44.057039
# Unit test for function main
def test_main():
    result = main()
    assert result["ping"] == "pong"

# Generated at 2022-06-20 22:14:48.596713
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    return result

# Generated at 2022-06-20 22:14:50.679196
# Unit test for function main
def test_main():
    args = dict(data='pong')
    assert main(args) == args

# Generated at 2022-06-20 22:14:58.671364
# Unit test for function main
def test_main():
    primitive_args = {
        'data': 'pong'
    }
    primitive_args.update(action_common_attributes_args)
    primitive_args.update(action_common_cleanup_args)
    primitive_args.update(action_common_config_args)
    primitive_args.update(action_common_distribution_args)
    primitive_args.update(action_common_environment_args)
    primitive_args.update(action_common_no_log_args)
    primitive_args.update(action_common_remote_tmp_args)
    primitive_args.update(action_common_selinux_args)
    primitive_args.update(action_common_shell_args)
    primitive_args.update(action_common_site_packages_args)

# Generated at 2022-06-20 22:15:06.422073
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)



# Generated at 2022-06-20 22:15:08.738226
# Unit test for function main
def test_main():
    '''
    Tests for function: main
    '''
    assert True


# Generated at 2022-06-20 22:15:14.378191
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:15:18.663504
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    print("Test - data='pong'")
    result = dict(
        ping='pong',
    )
    main()
    assert result['ping'] != 'crash'

# Generated at 2022-06-20 22:15:19.552826
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main()

# Generated at 2022-06-20 22:15:32.436950
# Unit test for function main
def test_main():
    a = [
        {
            "data": "pong",
            "check_mode": True,
            "diff": False,
            "platform": "posix",
            "id": "",
            "metadata": {}
        },
        {
            "data": "crash",
            "check_mode": True,
            "diff": False,
            "platform": "posix",
            "id": "",
            "metadata": {}
        }
    ]
    for i in a:
        m = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default='pong'),
            ),
            supports_check_mode=True,
            check_invalid_arguments=False
        )
        m._an_instance = i
        main()

# Generated at 2022-06-20 22:15:41.013814
# Unit test for function main
def test_main():
    tmpdir = pytest.ensuretemp('ansible_module_ping')
    file = tmpdir.join('arguments')
    file.write('{')
    file.write(' "argument_spec": {')
    file.write('  "data": {')
    file.write('   "default": "pong"')
    file.write('  }')
    file.write(' }')
    file.write('}')
    file.write('{')
    file.write(' "module_name": "ansible.builtin.ping"')
    file.write('}')
    file.write('{')
    file.write(' "supports_check_mode": True')
    file.write('}')


# Generated at 2022-06-20 22:15:42.929324
# Unit test for function main
def test_main():
  try:
    main()
  except Exception as e:
    return True


# Generated at 2022-06-20 22:15:47.078418
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

test_main()

# Generated at 2022-06-20 22:15:47.710612
# Unit test for function main
def test_main():
    # FIXME: This needs tests!
    pass

# Generated at 2022-06-20 22:16:05.973829
# Unit test for function main
def test_main():
    ans = dict(rc=0, changed=False, pong=None)
    m = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    m.run_command = lambda module_name, shell=False, executable=None, chdir=None, remove_tmp=None, remote_tmp=None, args=None, stdin=None, stdin_add_newline=True,  sudo=False,  use_persistent_connections=False, su=None, su_user=None, su_pass=None, ask_pass=False,  rlimits=None, data=None: ans
    main()
    assert m.params['data'] == ans['pong']

# Generated at 2022-06-20 22:16:12.060510
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    
    module.params['data'] = "pong"
    result = dict(
        ping=module.params['data'],
    )
    assert result == {"ping": "pong"}



# Generated at 2022-06-20 22:16:17.170147
# Unit test for function main
def test_main():
    """Test basic functionality with unittest"""
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:16:27.354903
# Unit test for function main
def test_main():

    # Tests for function 'main' using data from yaml file
    test_data = '''
    - name: Example from an Ansible Playbook
      ansible.builtin.ping:
      register: pong
      delegate_to: localhost

    - name: Induce an exception to see what happens
      ansible.builtin.ping:
        data: crash
      register: pong
      delegate_to: localhost
    '''

    # Create an AnsibleModule object
    am = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Run AnsibleModule.run()
    result = None

# Generated at 2022-06-20 22:16:31.571356
# Unit test for function main
def test_main():
    import json
    import sys

    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=m.params['data'],
    )

    m.exit_json(**result)

    output = sys.stdout.getvalue().strip()

    assert '"ping": "pong"' in output
    assert '"changed": false' in output

# Generated at 2022-06-20 22:16:40.251230
# Unit test for function main
def test_main():
    # FIXME: clean up
    # Inject code to test and capture output
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    #from test.ansible_mock import patch
    #from ansible.module_utils.basic import AnsibleModule
    #import ansible.builtin.ping as ping
    #import imp
    #from collections import namedtuple
    #args = namedtuple('args', 'data')('pong')
    #with patch.object(ping, 'AnsibleModule', return_value=module) as patched_amodule:
    #    with patch.object(imp, 'new_module',

# Generated at 2022-06-20 22:16:44.406645
# Unit test for function main
def test_main():
    # test for non sudo user
    args = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    # result = main()
    assert result == module.exit_json(**result)


# Generated at 2022-06-20 22:16:45.875930
# Unit test for function main
def test_main():
    # TODO: Implement unit tests here
    print('No unit tests to run')
    # assert True

# Generated at 2022-06-20 22:16:49.309194
# Unit test for function main
def test_main():
    pass
    # ansible_module = AnsibleModule(
    #     argument_spec=dict(
    #         data=dict(type='str', default='pong'),
    #     ),
    #     supports_check_mode=True
    # )
    # ansible_module.exit_json(**result)



# Generated at 2022-06-20 22:16:50.875485
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-20 22:17:06.435796
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:17:10.564670
# Unit test for function main
def test_main():
    test_module = AnsibleModule({
        'data': {'type': 'str', 'default': 'pong'}
    })
    result = dict(ping='pong')
    assert(main(test_module) == result)

# Generated at 2022-06-20 22:17:18.762040
# Unit test for function main
def test_main():
    fields = {
        "data": {
            "default": "pong",
            "type": "str"
        }
    }
    args = dict(data='')
    output = dict(
        ping='',
        changed=False,
        ansible_facts={}
    )
    ansible_facts = dict()
    def exit_json(**dout):
        output.update(dout)
    class AnsibleModule:
        supports_check_mode = True
        def __init__(self, argument_spec, *args, **kwargs):
            self.argument_spec = argument_spec
            self.params = args[0]
        def fail_json(self, **kwargs):
            dout = dict()
            dout.update(kwargs)
            output.update(dout)

# Generated at 2022-06-20 22:17:31.289436
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils.common._collections_compat import (
        Mapping,
        MutableMapping,
    )

    def check_result(result):
        if not isinstance(result, MutableMapping):
            assert False, "Return value not a dict"
        assert result == dict(
            ping="pong"
        )

    def run_the_method(params=dict(data="pong")):
        if not isinstance(params, Mapping):
            assert False, "Params not a dict"

        module = AnsibleModule(
            argument_spec=dict(
                data=dict(type='str', default="pong"),
            ),
            supports_check_mode=True
        )

        module.params = params

        from ansible.modules.ping import main


# Generated at 2022-06-20 22:17:39.710399
# Unit test for function main
def test_main():
    # Get and parse the action parameters:
    import sys
    sys.path.append('./test/lib/')
    import data
    data = data.data()
    action_params = data.module_params()
    # Return information to ansible:
    sys.path.append('./plugins/modules/')
    import return_info
    return_info = return_info.return_info(action_params)
    # Assertions:
    assert return_info['msg'] == '', "msg test"
    assert return_info['changed'] == False, "changed test"
    assert return_info['invocation']['module_args']['data'] == 'pong', "data test"
    assert return_info['ping'] == 'pong', "ping test"

# Generated at 2022-06-20 22:17:45.629840
# Unit test for function main
def test_main():
    run_setups('ping')
    values = dict(ANSIBLE_MODULE_ARGS={
        'data': 'pong'
    })
    my_args = dict(values, **global_args)
    ping_result = dict(changed=False, ping='pong')
    with pytest.raises(SystemExit):
        with set_module_args(my_args):
            with pytest.raises(StopExecution):
                main()
        assert module_result == ping_result
    with pytest.raises(SystemExit):
        with set_module_args(dict(data='crash', **global_args)):
            with pytest.raises(Exception):
                with pytest.raises(StopExecution):
                    main()

# Generated at 2022-06-20 22:17:48.475073
# Unit test for function main
def test_main():
    test_module = AnsibleModule({}, {})
    test_module.params['data'] = 'pong'
    main_result = main()
    assert main_result == dict(ping='pong')

# Generated at 2022-06-20 22:17:49.593194
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:18:01.618326
# Unit test for function main
def test_main():
    import os
    import socket
    import json
    import pytest

    from ansible.module_utils.basic import AnsibleModule

    path = os.path.dirname(__file__)
    # We will use the current directory with a relative path
    path = os.path.join(path, "test_files")

    # Call the main function with a test path and make sure it works
    try:
        main(path)
    except SystemExit:
        pass
    # Make sure we have the address and port
    assert ip is not None
    assert port is not None
    # Check that we can connect to the socket
    assert socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect_ex((ip, port)) == 0
    # Check that we got the correct data

# Generated at 2022-06-20 22:18:03.218723
# Unit test for function main
def test_main():
    check = main()
    assert check == {'ping': 'pong'}

# Generated at 2022-06-20 22:18:48.201076
# Unit test for function main
def test_main():
    args = dict(
        data=dict(type='str', default='pong')
    )
    result = dict(
        ping='pong'
    )
    test_module = AnsibleModule(**args)
    test_main()
    assert test_module.exit_json == result

# Generated at 2022-06-20 22:18:54.445404
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert result == dict(ping=module.params['data'])

# Generated at 2022-06-20 22:18:59.572175
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'exit_json') as exit_json:
        with patch.object(AnsibleModule, 'params') as params:
            params.data = 'crash'
            params.return_value = 'crash'
            with pytest.raises(Exception):
                main()

# Generated at 2022-06-20 22:19:09.394023
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import platform
    if platform.python_version_tuple() < ('2','7','12'):
        # Skip this test under old versions of python.
        return
    import ansible
    # Change cwd so we can find our test files
    saved_dir = os.getcwd()
    test_dir = os.path.join(os.path.dirname(__file__), '../../test/integration/targets/ping')
    test_vars_file = os.path.join(test_dir, 'vars/main.yml')
    os.chdir(test_dir)
    # Skip test if we don't have the test vars file

# Generated at 2022-06-20 22:19:20.911740
# Unit test for function main
def test_main():

    # deep testing of module internals
    from ansible.utils.path import unfrackpath
    from ansible.module_utils import basic

    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json

    data = dict(
        ANSIBLE_MODULE_ARGS=dict(
            data='pong',
        )
    )

    basic._ANSIBLE_ARGS = None

    with open('ping.args.json', 'w') as argsfile:
        argsfile.write(json.dumps(data, cls=AnsibleJSONEncoder))

    main()

    with open('ping.result.json') as resultfile:
        result = json.load(resultfile)

    assert result['ping'] == 'pong'

    data['ANSIBLE_MODULE_ARGS']['data']

# Generated at 2022-06-20 22:19:28.511946
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_resources.ping import main

    # Test with default values
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )
    main()
    assert module.exit_json.called
    assert module.exit_json_args == {'ping': 'pong'}
    assert module.fail_json.called == False
    module.exit_json.reset_mock()

    # Test with a provided ping
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        params={'data': 'boom'}
    )
    main()
    assert module.exit_json

# Generated at 2022-06-20 22:19:35.407312
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-20 22:19:44.660627
# Unit test for function main
def test_main():

    # Construct the parameters in the desired format.
    module_args = {
        "data": "pong"
    }

    # Dictionnary containing the parameters to return
    result = {
        "ping": "pong"
    }

    # Simulate the module execcution.
    module = AnsibleModule(module_args)
    module.exit_json(**result)

# Unit tests to check that the parameters are correctly set.
import pytest


# Generated at 2022-06-20 22:19:45.052296
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:19:50.548078
# Unit test for function main
def test_main():
    data = dict(
        data=dict(type='str', default='pong'),
    )
    result = dict(
        ping=data['data'],
    )
    def _exit_json(**kwargs):
        assert kwargs == result 
    class AnsibleModuleFakeClass(object):
        def __init__(self):
            self.check_mode = True
        def exit_json(self, **kwargs):
            _exit_json(**kwargs)
    sys.modules['ansible.module_utils.basic'] =  AnsibleModuleFakeClass()
    main()

# Generated at 2022-06-20 22:21:23.326649
# Unit test for function main
def test_main():

    connection = Connection('localhost')
    host = setup_module_object(connection)

    # Make the test reproducible
    connection.socket_path = None

    # Test returning data value
    module = PingModule({"data": "test"})
    result = module.run()
    assert result["ping"] == "test"

    # Test raising exception
    module = PingModule({"data": "crash"})
    with pytest.raises(Exception):
        module.run(task_vars={"ansible_check_mode": True})
    with pytest.raises(Exception):
        module.run()
    with pytest.raises(Exception):
        module.run(task_vars={"ansible_check_mode": False})

# Generated at 2022-06-20 22:21:23.795255
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:21:26.694067
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-20 22:21:32.876764
# Unit test for function main
def test_main():
    (return_code, stdout, stderr) = module.run_command(
        'PYTHONPATH=%s %s %s' % (extra_path, python, module.params['module_path']),
    )
    result = module.from_json(stdout)
    assert result['ping'] == 'pong'

# Generated at 2022-06-20 22:21:33.465132
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:21:39.628648
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    m = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    ret = main()

    def check_result():
        assert ret['ping'] == 'pong'
    check_result()

# Generated at 2022-06-20 22:21:47.654164
# Unit test for function main
def test_main():

    class AnsibleExitJson:
        def __init__(self, value):
            self.value = value

        def exit_json(self, **kwargs):
            self.value = kwargs

    class AnsibleFailJson:
        def __init__(self, value):
            self.value = value

        def fail_json(self, **kwargs):
            self.value = kwargs

    class ModuleMock:
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def check_mode(self):
            return False

    module = ModuleMock(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )

    result = AnsibleExitJson({})
    main()

# Generated at 2022-06-20 22:21:48.145346
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-20 22:21:51.309929
# Unit test for function main
def test_main():
    my_args = dict(data="pong")
    my_module = AnsibleModule(argument_spec=my_args)
    my_module.params['data'] = "pong"

    with pytest.raises(Exception) as exec:
        main()
    assert "boom" in str(exec.value)

# Generated at 2022-06-20 22:21:57.869849
# Unit test for function main
def test_main():

    test_data = dict(
        data='pong',
        )

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    module.params = test_data

    # Execute main()
    main()