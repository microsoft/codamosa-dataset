

# Generated at 2022-06-17 04:57:17.635873
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:21.263071
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:25.174175
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:27.929925
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 04:57:32.776499
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception:
        assert True

# Generated at 2022-06-17 04:57:38.976306
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 04:57:46.176435
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        data='crash'
    )
    assert module.params['data'] == 'crash'

# Generated at 2022-06-17 04:57:52.672508
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:00.499192
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:05.274616
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:17.957871
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:18.456110
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-17 04:58:23.875374
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:34.619205
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 04:58:39.405786
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:44.787859
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:53.194204
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

# Generated at 2022-06-17 04:59:02.053515
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import builtins

    # Save the builtin open function
    builtin_open = builtins.open

    # Make sure we can find the module source
    module_path = os.path.join(os.path.dirname(__file__), 'ping.py')

# Generated at 2022-06-17 04:59:07.016541
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:14.937106
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:28.770344
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'
    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 04:59:40.026828
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception as e:
        assert str(e) == 'boom'

# Generated at 2022-06-17 04:59:51.703991
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
    except Exception as e:
        assert str(e) == 'boom'

# Generated at 2022-06-17 04:59:58.018350
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:01.448403
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:09.405620
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:00:17.766248
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:24.441031
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.check_mode == True

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.check_mode == True

# Generated at 2022-06-17 05:00:33.595269
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['ping'] == 'pong'
    assert result['changed'] == False

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='crash')))
    try:
        result = main()
    except Exception as e:
        assert e.message == 'boom'
    else:
        assert False, "Should have thrown an exception"

# Generated at 2022-06-17 05:00:41.046520
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 05:01:02.675218
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:10.321961
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    assert main(args) == result

    # Test with data
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    assert main(args) == result

    # Test with crash
    args = dict(
        data='crash',
    )
    result = dict(
        ping='crash',
    )
    assert main(args) == result

# Generated at 2022-06-17 05:01:15.232469
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:21.820262
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:26.960040
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['ping'] == 'pong'

    # Test with data=crash
    module = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong'}})
    result = main()
    assert result['ping'] == 'pong'

# Generated at 2022-06-17 05:01:33.636780
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:38.822382
# Unit test for function main
def test_main():
    # Test with no argument
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    # Test with argument
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 05:01:42.168989
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 05:01:49.381515
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:57.962402
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 05:02:30.446892
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.params['data'] != 'crash'

# Generated at 2022-06-17 05:02:36.403968
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:39.673648
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    with pytest.raises(Exception):
        result = main(args)

# Generated at 2022-06-17 05:02:48.699496
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 05:02:54.947510
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:59.537611
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:06.659523
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:14.181672
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:19.199713
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.check_mode == True

# Generated at 2022-06-17 05:03:19.659107
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-17 05:04:33.033024
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:37.505304
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:45.444331
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:53.369860
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:05:00.630461
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 05:05:07.042423
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:05:14.683673
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:05:19.423417
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert main() == module.exit_json(**dict(ping=module.params['data']))

# Generated at 2022-06-17 05:05:23.782537
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 05:05:29.609156
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)