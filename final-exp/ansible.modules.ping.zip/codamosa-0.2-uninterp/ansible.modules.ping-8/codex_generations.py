

# Generated at 2022-06-17 04:57:16.944470
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

# Generated at 2022-06-17 04:57:19.952075
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 04:57:27.080120
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:30.871325
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:40.774996
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.six.moves.configparser
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.error


# Generated at 2022-06-17 04:57:48.115955
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        data='crash'
    )
    assert module.params['data'] == 'crash'

# Generated at 2022-06-17 04:57:54.459776
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:59.304408
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:05.158968
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:09.057434
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:20.232830
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:31.010779
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = MagicMock()
    main()
    module.exit_json.assert_called_with(**result)

    # Test with data=crash
    args = dict(
        data='crash',
    )
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    module.exit_json = MagicMock()
    main()
    module.fail_json.assert_called_with(msg='boom')

    # Test with data=foo
    args = dict(
        data='foo',
    )

# Generated at 2022-06-17 04:58:40.375361
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleExit

# Generated at 2022-06-17 04:58:47.480726
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:52.196197
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'
    # Test with data=crash
    args = dict(data='crash')
    with pytest.raises(Exception) as excinfo:
        main(args)
    assert 'boom' in str(excinfo.value)
    # Test with data=foo
    args = dict(data='foo')
    result = main(args)
    assert result['ping'] == 'foo'

# Generated at 2022-06-17 04:59:01.576947
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.common.json
    import ansible.module_utils.common.text
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.removed_in_version_2_9
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.collections_compat
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.network
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.sys_info
    import ansible.module_utils.common.file
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common

# Generated at 2022-06-17 04:59:06.955728
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 04:59:18.573562
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

# Generated at 2022-06-17 04:59:29.123780
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 04:59:39.480127
# Unit test for function main
def test_main():
    # Test with no argument
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')
    # Test with argument
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

# Generated at 2022-06-17 04:59:54.064998
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:59.929713
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 05:00:09.624720
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data argument
    module = AnsibleModule(argument_spec=dict(data='pong'))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data argument
    module = AnsibleModule(argument_spec=dict(data='crash'))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:00:18.174036
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:28.213383
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with crash argument
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    with pytest.raises(Exception):
        result = dict(
            ping=module.params['data'],
        )

# Generated at 2022-06-17 05:00:35.357778
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:40.830164
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 05:00:48.460635
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception:
        assert True

# Generated at 2022-06-17 05:00:54.641286
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:59.132257
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:23.941608
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:27.959883
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    assert main(args) == result

    # Test with data=crash
    args = dict(
        data='crash',
    )
    with pytest.raises(Exception):
        main(args)

    # Test with data=foo
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    assert main(args) == result

# Generated at 2022-06-17 05:01:33.852926
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:37.301060
# Unit test for function main
def test_main():
    # Test with no arguments
    args = {}
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = {'data': 'crash'}
    with pytest.raises(Exception):
        result = main(args)

# Generated at 2022-06-17 05:01:43.219322
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:53.592096
# Unit test for function main
def test_main():
    # Test module with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(argument_spec=args)
    module.exit_json = MagicMock()
    main()
    module.exit_json.assert_called_with(**result)

    # Test module with data argument
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    module = AnsibleModule(argument_spec=args)
    module.exit_json = MagicMock()
    main()
    module.exit_json.assert_called_with(**result)

    # Test module with data argument set to crash
    args = dict(
        data='crash',
    )

# Generated at 2022-06-17 05:01:57.768179
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:02.928595
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:08.098075
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:21.902792
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.netcommon
    import ansible.module_utils.network
    import ansible.module_utils.shell
    import ansible.module_utils.windows
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.wait_for
    import ansible.module_utils.database
    import ansible.module_utils.system
    import ansible.module_utils.firewall
    import ansible.module_utils.stat
    import ansible.module_utils.storage
    import ansible.module_utils.packaging
    import ansible.module_utils.cloud
    import ansible.module_utils.notification

# Generated at 2022-06-17 05:02:58.604122
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:05.971067
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:09.392019
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:17.837491
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 05:03:22.323493
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:30.227981
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:38.719499
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:45.822244
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:56.662519
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.collections_compat
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.text
    import ansible.module_utils.common.json_utils
    import ansible.module_utils.common.logging_utils
    import ansible.module_utils.common.sys_info
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.file
    import ansible.module_utils.common.process
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common.network
   

# Generated at 2022-06-17 05:04:06.649051
# Unit test for function main
def test_main():
    import json
    import sys
    import os
    import tempfile
    import shutil
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a temp directory to store the test files
    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, 'test_file')

    # Create a test file
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a test module
    test_module = os.path.join(tmpdir, 'test_module.py')

# Generated at 2022-06-17 05:05:30.381756
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    args['data'] = 'pong'
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with arguments
    args = dict()
    args['data'] = 'crash'
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 05:05:44.899998
# Unit test for function main
def test_main():
    # Test module with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test module with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

# Generated at 2022-06-17 05:05:51.624417
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:06.126643
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert module.exit_json(**result) == dict(
        changed=False,
        ping='pong',
    )

    # Test with data
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert module.exit_json(**result) == dict(
        changed=False,
        ping='pong',
    )

    # Test with data
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))

# Generated at 2022-06-17 05:06:11.252038
# Unit test for function main
def test_main():
    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Mock module.exit_json
    module.exit_json = lambda **kwargs: kwargs

    # Mock module.params
    module.params = {'data': 'pong'}

    # Call main
    result = main()

    # Assert result
    assert result == {'changed': False, 'ping': 'pong'}

# Generated at 2022-06-17 05:06:14.411082
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:19.719125
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    result = dict(
        ping='crash',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:06:27.134398
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:33.680935
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:39.795951
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)