

# Generated at 2022-06-17 04:57:22.778304
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:28.397400
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:36.318153
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:41.228346
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 04:57:46.857741
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:53.578384
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:58.621216
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:03.406486
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 04:58:09.488217
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.check_mode is True

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        data='foo'
    )
    assert module.params['data'] == 'foo'
    assert module.check_mode is True

# Generated at 2022-06-17 04:58:16.276547
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 04:58:30.725058
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:35.879450
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:39.817583
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:44.818915
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:50.872568
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.check_mode is True

    # Test with parameters
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'crash'
    assert module.check_mode is True

# Generated at 2022-06-17 04:58:57.527362
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:03.961875
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:10.891728
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:11.235076
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-17 04:59:13.954784
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 04:59:33.540686
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:41.730495
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    # Create a mock module
    test_module = type('AnsibleModule')
    test_module.exit_json = lambda self, **kwargs: sys.exit(0)
    test_module.exit_failure = lambda self, **kwargs: sys.exit(1)
    test_module.fail_json = lambda self, **kwargs: sys.exit(1)
    test_module.params = {}
    test_module.supports_check_mode = True
    test_module.check_mode = False
    test_module.no_log = False

# Generated at 2022-06-17 04:59:48.962809
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 04:59:56.876400
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:06.745560
# Unit test for function main
def test_main():
    # Test module with no argument
    args = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = MagicMock()
    main()
    module.exit_json.assert_called_with(**result)

    # Test module with argument
    args = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='pong')))
    module.exit_json = MagicMock()
    main()
    module.exit_json.assert_called_with(**result)

    # Test module with argument

# Generated at 2022-06-17 05:00:13.056868
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:17.372923
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:17.869146
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-17 05:00:21.991489
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:26.559903
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:01.768865
# Unit test for function main
def test_main():
    # Test with no arguments
    result = main()
    assert result['ping'] == 'pong'

    # Test with data=crash
    result = main(dict(data='crash'))
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 05:01:11.182789
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:01:17.522524
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    with pytest.raises(Exception):
        result = main(args)

# Generated at 2022-06-17 05:01:22.071830
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:28.082361
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:34.331571
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 05:01:43.394281
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 05:01:49.473743
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:54.401412
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:57.173728
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 05:03:07.793030
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:16.508645
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:21.417950
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:27.359599
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 05:03:40.320088
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.check_mode == True
    assert module.exit_json.__name__ == 'exit_json'
    assert module.fail_json.__name__ == 'fail_json'

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        )
    )

# Generated at 2022-06-17 05:03:48.692139
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:56.460273
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:01.117713
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(data='crash'))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(data='pong'))
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:04:07.709960
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:21.063490
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.common.json
    import ansible.module_utils.common.text
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.removed_in_version_2_9
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.file
    import ansible.module_utils.common.process
    import ansible.module_utils.common.system
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common.logging
   

# Generated at 2022-06-17 05:05:49.819869
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.connection
    import ansible.module_utils.network
    import ansible.module_utils.shell
    import ansible.module_utils.windows
    import ansible.module_utils.six
    import ansible.module_utils.json
    import ansible.module_utils.urls
    import ansible.module_utils.helpers
    import ansible.module_utils.crypto
    import ansible.module_utils.facts
    import ansible.module_utils.hashing
    import ansible.module_utils.parsing
    import ansible.module_utils.compat
    import ansible.module_utils.cloud
    import ansible.module_utils.ec2
    import ansible.module_utils.vmware
    import ans

# Generated at 2022-06-17 05:06:00.432757
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True,
        data='foo'
    )
    assert module.params['data'] == 'foo'

# Generated at 2022-06-17 05:06:08.148494
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert module.exit_json(**result) == None

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', default='crash')))
    result = dict(
        ping='crash',
    )
    assert module.exit_json(**result) == None

# Generated at 2022-06-17 05:06:20.893397
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(
        ping='pong',
    )

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception as e:
        assert str(e) == "boom"

# Generated at 2022-06-17 05:06:27.240337
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:35.206250
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    assert main(args) == result

    # Test with data=crash
    args = dict(
        data='crash',
    )
    with pytest.raises(Exception) as excinfo:
        main(args)
    assert 'boom' in str(excinfo.value)

    # Test with data=foo
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    assert main(args) == result

# Generated at 2022-06-17 05:06:39.874552
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:40.352532
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-17 05:06:47.889826
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:54.727868
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'