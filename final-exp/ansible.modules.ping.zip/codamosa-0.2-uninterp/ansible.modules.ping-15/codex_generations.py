

# Generated at 2022-06-17 04:57:20.725288
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.connection
    import ansible.module_utils.network
    import ansible.module_utils.shell
    import ansible.module_utils.windows
    import ansible.module_utils.six
    import ansible.module_utils.json
    import ansible.module_utils.text
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.text
    import ansible.module_utils.common.collections_compat
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings

# Generated at 2022-06-17 04:57:25.331960
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    try:
        result = main(args)
    except Exception as e:
        assert e.message == 'boom'

    # Test with data=foo
    args = dict(data='foo')
    result = main(args)
    assert result['ping'] == 'foo'

# Generated at 2022-06-17 04:57:29.271301
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:36.362786
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:40.932644
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:46.635510
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:53.249819
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:00.529572
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:05.916354
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:09.731890
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:19.604655
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    with pytest.raises(Exception):
        result = main(args)

# Generated at 2022-06-17 04:58:28.238195
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 04:58:36.670246
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data parameter
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data parameter set to crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.fail_json(msg='boom')

# Generated at 2022-06-17 04:58:46.732790
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception as e:
        assert str(e) == "boom"

# Generated at 2022-06-17 04:58:50.930160
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:57.607198
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:07.927223
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data set to 'crash'
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data set to 'pong'
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 04:59:15.772630
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:20.480587
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:27.787510
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with a data argument
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with a data argument
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 04:59:42.103161
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:48.951941
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:56.871991
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:01.386145
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:07.162166
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:16.258129
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:20.120928
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 05:00:28.262640
# Unit test for function main
def test_main():
    # Mock the module class
    class MockModule(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {'data': 'pong'}
        def exit_json(self, **kwargs):
            self.exit_json_kwargs = kwargs
            return True
        def fail_json(self, **kwargs):
            self.fail_json_kwargs = kwargs
            return True

    # Mock the module
    module = MockModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    # Call the function
    main()



# Generated at 2022-06-17 05:00:35.395616
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:44.662538
# Unit test for function main
def test_main():
    import json
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary playbook
    playbook = os.path.join(tmpdir, "ping.yml")
    with open(playbook, 'w') as f:
        f.write("""
---
- hosts: localhost
  connection: local
  tasks:
    - ping:
        data: pong
""")

    # Create a temporary ansible.cfg
    ansible_cfg = os.path.join(tmpdir, "ansible.cfg")

# Generated at 2022-06-17 05:01:13.789772
# Unit test for function main
def test_main():
    import json
    import sys
    import os
    import pytest

    # Set up a fake module
    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self.exit_json = sys.exit
            self.fail_json = sys.exit

    # Set up a fake AnsibleModule
    class FakeAnsibleModule(object):
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = {}

        def fail_json(self, **kwargs):
            raise Exception(kwargs)


# Generated at 2022-06-17 05:01:22.559572
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception as e:
        assert str(e) == 'boom'

# Generated at 2022-06-17 05:01:29.336224
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)


# Generated at 2022-06-17 05:01:39.902106
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.connection
    import ansible.module_utils.network
    import ansible.module_utils.shell
    import ansible.module_utils.windows
    import ansible.module_utils.six
    import ansible.module_utils.json
    import ansible.module_utils.text
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.urls
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.alpine
    import ansible.module_utils.facts.system.distribution.arch

# Generated at 2022-06-17 05:01:52.702821
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    def _mock_module(**kwargs):
        params = kwargs.pop('params', {})
        mock_module = AnsibleModule(argument_spec=kwargs, supports_check_mode=True)
        mock_module.params = params
        return mock_module


# Generated at 2022-06-17 05:01:56.970706
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:05.837364
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception as e:
        assert str(e) == "boom"

# Generated at 2022-06-17 05:02:11.171162
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:18.710302
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with arguments
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with arguments
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:02:26.588429
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:03.657499
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:07.237939
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:19.931242
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with data=crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        main()
        assert False
    except Exception as e:
        assert str(e) == 'boom'

# Generated at 2022-06-17 05:03:29.032174
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['ping'] == 'pong'

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(data='crash'))
    with pytest.raises(Exception):
        result = main()

    # Test with data=foo
    module = AnsibleModule(argument_spec=dict(data='foo'))
    result = main()
    assert result['ping'] == 'foo'

# Generated at 2022-06-17 05:03:34.603083
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    module.exit_json(**result)

# Generated at 2022-06-17 05:03:41.831354
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.json
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.removed_in_version_2_9
    import ansible.module_utils.common.text
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.process
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.file
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common.os

# Generated at 2022-06-17 05:03:49.639734
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:56.022750
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:00.186228
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:04:11.846805
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:05:41.659184
# Unit test for function main
def test_main():
    # Test module arguments
    module_args = dict(
        data=dict(type='str', default='pong'),
    )

    # Test module execution
    result = dict(
        ping='pong',
    )

    # Test module exit
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    module.exit_json(**result)

# Generated at 2022-06-17 05:05:48.562674
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:02.746125
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:06:03.178766
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-17 05:06:08.242865
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:14.974237
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'


# Generated at 2022-06-17 05:06:20.545510
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:26.355236
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 05:06:33.289381
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:06:41.774507
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception as e:
        assert str(e) == 'boom'