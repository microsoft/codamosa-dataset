

# Generated at 2022-06-17 04:57:20.080596
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    assert main(args) == result

    # Test with data=crash
    args = dict(
        data='crash',
    )
    with pytest.raises(Exception) as excinfo:
        main(args)
    assert 'boom' in str(excinfo.value)

    # Test with data=foo
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    assert main(args) == result

# Generated at 2022-06-17 04:57:30.668581
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
    except Exception as e:
        assert e.args[0] == 'boom'
    else:
        assert False, 'Expected exception'

# Generated at 2022-06-17 04:57:36.638479
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:41.188570
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:46.857916
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:57:52.810825
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    result = main(args)
    assert result['ping'] == 'pong'

# Generated at 2022-06-17 04:57:59.803262
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.params['data'] != 'crash'

# Generated at 2022-06-17 04:58:05.196871
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:09.092974
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:16.579698
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:30.807388
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:35.965026
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:45.934336
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

    # Test with crash
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='crash'),
        ),
        supports_check_mode=True
    )
    try:
        result = dict(
            ping=module.params['data'],
        )
        assert False
    except Exception as e:
        assert str(e) == 'boom'

# Generated at 2022-06-17 04:58:50.297634
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:58:56.938140
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:03.925369
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:13.646463
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert result == dict(ping='pong')

    # Test with arguments
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    result = dict(
        ping=module.params['data'],
    )

    assert result == dict(ping='pong')

# Generated at 2022-06-17 04:59:18.200033
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:29.510058
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict(
        data='pong',
    )
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = args
    main()
    assert module.exit_json.called
    assert module.exit_json.call_args == call(**result)
    # Test with crash
    args = dict(
        data='crash',
    )
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    module.params = args


# Generated at 2022-06-17 04:59:36.699547
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 04:59:57.994930
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:03.777282
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:08.225777
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'
    # Test with data=crash
    args = dict(data='crash')
    with pytest.raises(Exception):
        result = main(args)
    # Test with data=foo
    args = dict(data='foo')
    result = main(args)
    assert result['ping'] == 'foo'

# Generated at 2022-06-17 05:00:14.998440
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    result = dict(
        ping=module.params['data'],
    )
    assert result == dict(ping='pong')

# Generated at 2022-06-17 05:00:20.711843
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:26.705710
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:32.167817
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 05:00:39.401864
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'
    assert module.check_mode == True

# Generated at 2022-06-17 05:00:46.765319
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:00:51.607686
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = main(args)
    assert result['ping'] == 'pong'

    # Test with data=crash
    args = dict(data='crash')
    with pytest.raises(Exception):
        result = main(args)

# Generated at 2022-06-17 05:01:36.175422
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:44.812076
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='crash'),
    ))
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str', default='pong'),
    ))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:01:47.772220
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:01:52.657983
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )
    assert module.params['data'] == 'pong'

# Generated at 2022-06-17 05:01:57.958647
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    assert main(args) == result

    # Test with data=crash
    args = dict(
        data='crash',
    )
    result = dict(
        ping='crash',
    )
    assert main(args) == result

    # Test with data=foo
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    assert main(args) == result

# Generated at 2022-06-17 05:02:03.005469
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:06.794973
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['ping'] == 'pong'

    # Test with data=crash
    module = AnsibleModule(argument_spec={'data': {'type': 'str', 'default': 'pong'}})
    module.params['data'] = 'crash'
    result = main()
    assert result['ping'] == 'crash'

# Generated at 2022-06-17 05:02:11.006730
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:18.926161
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:02:26.587922
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:46.638192
# Unit test for function main
def test_main():
    # Test with no argument
    args = dict()
    result = dict(
        ping='pong',
    )
    assert main(args) == result

    # Test with data=crash
    args = dict(
        data='crash',
    )
    with pytest.raises(Exception):
        main(args)

    # Test with data=foo
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    assert main(args) == result

# Generated at 2022-06-17 05:03:53.319578
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:03:57.349489
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:06.211815
# Unit test for function main
def test_main():
    # Test module with no arguments
    args = dict()
    result = dict(
        ping='pong',
    )
    module = AnsibleModule(argument_spec=args)
    assert main() == result

    # Test module with data argument
    args = dict(
        data='foo',
    )
    result = dict(
        ping='foo',
    )
    module = AnsibleModule(argument_spec=args)
    assert main() == result

    # Test module with data argument
    args = dict(
        data='crash',
    )
    result = dict(
        ping='crash',
    )
    module = AnsibleModule(argument_spec=args)
    assert main() == result

# Generated at 2022-06-17 05:04:12.912977
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:17.878492
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:31.986013
# Unit test for function main
def test_main():
    # Test module with no arguments
    args = dict()
    result = dict(
        ping='pong',
        changed=False
    )
    module = AnsibleModule(argument_spec=args)
    assert main() == result

    # Test module with data argument
    args = dict(
        data='foo'
    )
    result = dict(
        ping='foo',
        changed=False
    )
    module = AnsibleModule(argument_spec=args)
    assert main() == result

    # Test module with data argument set to crash
    args = dict(
        data='crash'
    )
    result = dict(
        ping='crash',
        changed=False
    )
    module = AnsibleModule(argument_spec=args)
    assert main() == result

# Generated at 2022-06-17 05:04:38.645015
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)

# Generated at 2022-06-17 05:04:43.998573
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=crash
    module = AnsibleModule(argument_spec=dict(data='crash'))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

    # Test with data=pong
    module = AnsibleModule(argument_spec=dict(data='pong'))
    result = dict(
        ping='pong',
    )
    assert main() == module.exit_json(**result)

# Generated at 2022-06-17 05:04:50.909880
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='str', default='pong'),
        ),
        supports_check_mode=True
    )

    if module.params['data'] == 'crash':
        raise Exception("boom")

    result = dict(
        ping=module.params['data'],
    )

    module.exit_json(**result)