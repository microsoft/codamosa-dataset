

# Generated at 2022-06-18 10:00:05.764925
# Unit test for function main
def test_main():
    import sys
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPError
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.process import fork_processes
    from tornado.util import b
    from tornado.test.util import unittest

    class HelloHandler(RequestHandler):
        def get(self):
            self.write(b("Hello world"))

    class HelloRedirectHandler(RequestHandler):
        def get(self):
            self.redirect("/hello")


# Generated at 2022-06-18 10:00:18.425925
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:00:30.846925
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test

    class MyAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(self, request, callback):
            callback(HTTPResponse(request, 200, buffer=BytesIO(b"OK")))

    class MyAsyncHTTPTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return None

        @gen_test
        def test_fetch_impl(self):
            client = MyAsyncHTTPClient()
            response = yield client.fetch("http://example.com/")
            self.assertEqual(200, response.code)
            self.assertEqual(b"OK", response.body)

    unittest.main()


# Generated at 2022-06-18 10:00:39.660944
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:00:50.766620
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.httpclient
    import tornado.httputil

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    def handle_request(response):
        if response.error:
            print("Error:", response.error)
        else:
            print(response.body)
        tornado.ioloop.IOLoop.current().stop()

    def go():
        application = tornado.web.Application([(r"/", MainHandler)])
        http_server = tornado.httpserver.HTTPServer(application)
        port = http_server.listen(8888)
        print("Listening on port:", port)
        url = "http://localhost:8888/"


# Generated at 2022-06-18 10:00:55.501926
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPError
    from tornado.options import define, options
    import tornado.ioloop
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import os
    import sys
    import tempfile
    import unittest
    import urllib.parse
    import warnings
    import functools
    import socket
    import ssl
    import time
    import logging
    import re
    import subprocess
    import threading
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures

# Generated at 2022-06-18 10:00:56.587999
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:00:57.282910
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-18 10:00:57.935928
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-18 10:01:02.205816
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import io
    import subprocess
    import unittest
    import tornado.testing
    import tornado.options
    import tornado.httpclient
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.ioloop
    import tornado.iostream
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.escape
    import tornado.httputil
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.tcpserver
   

# Generated at 2022-06-18 10:01:29.709304
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:01:32.165158
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # test_AsyncHTTPClient_fetch_impl is not tested.
    pass


# Generated at 2022-06-18 10:01:37.881842
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when an instance is created.
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.kwargs = kwargs

    client = TestAsyncHTTPClient(foo=1, bar=2)
    assert client.kwargs == dict(foo=1, bar=2)



# Generated at 2022-06-18 10:01:50.071066
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import os
    import sys
    import time
    import logging
    import tornado.ioloop
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test

# Generated at 2022-06-18 10:02:00.991215
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPClient, HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import aiohttp
    import aiohttp.client
    import aiohttp.web
    import aiohttp.multipart
    import aiohttp.streams
    import aiohttp.client_exceptions
    import aiohttp.server

# Generated at 2022-06-18 10:02:03.839884
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    assert client._closed == True


# Generated at 2022-06-18 10:02:16.390336
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # __new__ is a static method, so we need to use a class method call
    # to get an instance.
    instance = AsyncHTTPClient.__new__(AsyncHTTPClient)
    assert isinstance(instance, AsyncHTTPClient)
    assert instance.io_loop is None
    assert instance._instance_cache is None
    assert instance._closed is False
    instance.close()
    assert instance._closed is True
    # __new__ is a static method, so we need to use a class method call
    # to get an instance.
    instance = AsyncHTTPClient.__new__(AsyncHTTPClient, force_instance=True)
    assert isinstance(instance, AsyncHTTPClient)
    assert instance.io_loop is None
    assert instance._instance_cache is None
    assert instance._closed is False
    instance.close()
   

# Generated at 2022-06-18 10:02:17.044144
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:29.537908
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.httputil
    import tornado.httpserver
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.stack_context
    import tornado.util
    import tornado.process
    import tornado.locks
    import tornado.ioloop
    import tornado.queues
    import tornado.gen
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.http1

# Generated at 2022-06-18 10:02:39.780785
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.web import RequestHandler, Application
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    import unittest
    import tornado.platform.asyncio
    import asyncio
    import sys
    import os
    import time
    import json
    import logging
    import tornado.log
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.platform.asyncio
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.testing
    import tornado.test.httpclient_test

# Generated at 2022-06-18 10:03:07.201079
# Unit test for function main
def test_main():
    import sys
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import unittest
    import os
    import time
    import socket
    import threading
    import logging
    import urllib.parse
    import functools
    import json
    import subprocess
    import shutil
    import tempfile
    import ssl
    import warnings
    import io
    import gzip
    import zlib
    import base64
    import hmac
    import hashlib
    import binascii
    import contextlib
    import concurrent.futures


# Generated at 2022-06-18 10:03:15.197757
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method should be implemented by subclasses.
    # It is called with an HTTPRequest object and should call
    # callback with an HTTPResponse object (or raise an Exception).
    #
    # The callback should not modify the HTTPResponse object,
    # as it may be cached and shared with other callbacks.
    #
    # The callback may be called synchronously or asynchronously.
    # If it is called asynchronously, it must not be called after
    # the AsyncHTTPClient object has been closed.
    pass



# Generated at 2022-06-18 10:03:27.140067
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close()
    client.close

# Generated at 2022-06-18 10:03:36.111020
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import sys
    import os
    import io
    import unittest
    import subprocess
    import time
    import signal
    import socket
    import threading
    import logging
    import tempfile
    import shutil
    import contextlib
    import functools
    import warnings
    import ssl
    import base64
    import json
    import re
    import urllib.parse
    import urllib.request
    import urllib.error
    import email.utils
    import email.message

# Generated at 2022-06-18 10:03:38.296328
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # AsyncHTTPClient.fetch_impl(request, callback) NotImplementedError
    pass


# Generated at 2022-06-18 10:03:38.889628
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:03:42.618675
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method must be implemented by subclasses.
    # It should call callback with an HTTPResponse object.
    return


# Generated at 2022-06-18 10:03:53.813189
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTP

# Generated at 2022-06-18 10:04:02.182121
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.escape import native_str
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import urllib.parse
    import urllib.request
    import urllib.error
    import http.client
    import socket
    import ssl
    import time
    import warnings
    import functools
    import logging
    import threading
    import concurrent.futures
    import subprocess
    import tempfile
    import shutil
    import io
    import gzip
    import zlib
    import base64
    import hmac
    import hashlib
    import email.utils
    import email.message
    import email.policy


# Generated at 2022-06-18 10:04:02.776948
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:06:43.766483
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:06:53.955322
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:07:04.956866
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPClient, HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.util import b
    from tornado.testing import bind_unused_port
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")


# Generated at 2022-06-18 10:07:08.553763
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when an instance is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.initialized = True
    client = MyAsyncHTTPClient()
    assert client.initialized


# Generated at 2022-06-18 10:07:18.777487
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPMessageDelegate
    from tornado.httpclient import HTTPResponseParser
    from tornado.httpclient import HTTPHeaders
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPStreamClosedError
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import _HTTPConnectionParameters
    from tornado.httpclient import _HTTPConnection
    from tornado.httpclient import _HTTPRequest
    from tornado.httpclient import _HTTPConnectionContext
    from tornado.httpclient import _HTTPConnectionDelegate

# Generated at 2022-06-18 10:07:20.280209
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:07:30.344902
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:07:40.471976
# Unit test for method __new__ of class AsyncHTTPClient

# Generated at 2022-06-18 10:07:48.170169
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    proxy = _RequestProxy(request, defaults)
    assert proxy.method == "GET"
    assert proxy.url == "http://www.baidu.com"
    assert proxy.proxy_host == None
    assert proxy.proxy_port == None
    assert proxy.proxy_username == None
    assert proxy.proxy_password == None
    assert proxy.proxy_auth_mode == None
    assert proxy.url == "http://www.baidu.com"
    assert proxy.method == "GET"
    assert proxy.body == None
    assert proxy.body_producer == None
    assert proxy.auth_username == None
    assert proxy.auth_password == None
    assert proxy.auth_mode == None
    assert proxy

# Generated at 2022-06-18 10:07:59.662709
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.web import Application, RequestHandler
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import threading
    import time
    import unittest
    import urllib.parse
    import warnings
    import weakref
    import functools
    import logging
    import socket
    import ssl
    import subprocess
    import tempfile
    import shutil
    import contextlib
    import concurrent.futures
    import concurrent.futures
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
    import typing
