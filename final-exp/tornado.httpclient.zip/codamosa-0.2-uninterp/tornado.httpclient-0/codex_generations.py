

# Generated at 2022-06-18 09:59:55.885498
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.headers == {}
    assert request_proxy.body == b""
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == "basic"
    assert request_proxy.connect_timeout == 20.0
    assert request_proxy.request_timeout == 20.0
    assert request_proxy.if_modified_since == None
    assert request_proxy.follow_redirects == True
    assert request_proxy.max_redirects

# Generated at 2022-06-18 10:00:09.202110
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import subprocess
    import tornado.testing
    import tornado.options
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.netutil
    import tornado.process

    class HelloHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello")

    class HelloRedirectHandler(tornado.web.RequestHandler):
        def get(self):
            self.redirect("/hello")

    class HelloRedirectChainHandler(tornado.web.RequestHandler):
        def get(self):
            self.redirect("/redirect")


# Generated at 2022-06-18 10:00:21.674742
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:00:24.575738
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="http://www.google.com")
    response = HTTPResponse(request=request, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()


# Generated at 2022-06-18 10:00:33.876418
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # Test HTTPClient.fetch
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:00:43.653923
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Test that AsyncHTTPClient.fetch() returns a Future
    # and that the Future has a result when the request is complete.
    # This test doesn't actually make a request, so it doesn't need
    # to be run in an IOLoop.
    client = AsyncHTTPClient()
    response = client.fetch("http://www.google.com/")
    assert isinstance(response, Future)
    assert not response.done()
    response.set_result(HTTPResponse(request=HTTPRequest("http://www.google.com/"), code=200))
    assert response.done()
    assert isinstance(response.result(), HTTPResponse)


# Generated at 2022-06-18 10:00:56.631204
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import tornado.simple_httpclient
    import tornado.curl_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
   

# Generated at 2022-06-18 10:01:05.285713
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url='http://www.baidu.com')
    code = 200
    headers = None
    buffer = None
    effective_url = None
    error = None
    request_time = None
    time_info = None
    reason = None
    start_time = None
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    response.rethrow()
    print('test_HTTPResponse_rethrow passed')


# Generated at 2022-06-18 10:01:17.375938
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest('http://www.google.com')
    response = HTTPResponse(request, 200, None, None, None, None, None, None, None, None)
    assert response.request == request
    assert response.code == 200
    assert response.reason == 'OK'
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer == None
    assert response._body == None
    assert response.effective_url == 'http://www.google.com'
    assert response.error == None
    assert response.request_time == None
    assert response.time_info == {}
    assert response.start_time == None
    assert response.body == b''

# Generated at 2022-06-18 10:01:21.489836
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url="http://www.baidu.com")
    defaults = {"method": "GET"}
    req = _RequestProxy(request, defaults)
    assert req.method == "GET"
    assert req.url == "http://www.baidu.com"


# Generated at 2022-06-18 10:01:53.319776
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test for method initialize of class AsyncHTTPClient
    # Test that the defaults are applied to the request
    # (and that the request is copied)
    defaults = dict(
        connect_timeout=300,
        request_timeout=600,
        follow_redirects=False,
        max_redirects=10,
        decompress_response=True,
        proxy_host="localhost",
        proxy_port=8888,
        proxy_username="user",
        proxy_password="pass",
        allow_nonstandard_methods=False,
        validate_cert=True,
        ca_certs=None,
        allow_ipv6=True,
        client_key=None,
        client_cert=None,
        body_producer=None,
        expect_100_continue=False,
    )
    client

# Generated at 2022-06-18 10:02:01.096358
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:02:14.771394
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import logging
    import os
    import socket
    import sys
    import threading
    import time
    import unittest
    import urllib.parse
    import warnings
    import zlib
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.log import gen_log
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.test.util import unittest, skipOnTravis, skipIfNon

# Generated at 2022-06-18 10:02:18.839435
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.headers == {}
    assert request_proxy.body == b""
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect

# Generated at 2022-06-18 10:02:20.573300
# Unit test for function main
def test_main():
    # TODO: add tests
    pass

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:02:30.568932
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:02:42.706682
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.concurrent import Future
    from tornado.test.util import unittest

    class MainTest(AsyncTestCase):
        def setUp(self):
            super(MainTest, self).setUp()
            self.io_loop = self.new_ioloop()
            AsyncIOMainLoop().install()
            self.http_client = AsyncHTTPClient(self.io_loop)

# Generated at 2022-06-18 10:02:55.016900
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.pos

# Generated at 2022-06-18 10:03:05.601247
# Unit test for method initialize of class AsyncHTTPClient

# Generated at 2022-06-18 10:03:14.992583
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = AsyncHTTPClient()

# Generated at 2022-06-18 10:03:43.951367
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url='http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.proxy_host == None

# Generated at 2022-06-18 10:03:54.986063
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import unittest
    import sys
    import os
    import io
    import random
    import string

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            class MainHandler(RequestHandler):
                def get(self):
                    self.write("Hello, world")

            return Application([("/", MainHandler)])

        def test_main(self):
            define("print_headers", type=bool, default=False)

# Generated at 2022-06-18 10:04:02.972125
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado

# Generated at 2022-06-18 10:04:14.018894
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import options, define
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.ioloop
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import tornado.escape
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.util
    import tornado.queues
    import tornado.ioloop
    import tornado.iostream
    import tornado

# Generated at 2022-06-18 10:04:25.949556
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient


# Generated at 2022-06-18 10:04:26.301709
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:04:35.571963
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import logging
    import os
    import socket
    import ssl
    import sys
    import unittest
    import warnings
    import weakref
    import zlib
    from tornado.concurrent import Future
    from tornado.escape import utf8, native_str

# Generated at 2022-06-18 10:04:38.593180
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method should be implemented by subclasses.
    # It should call callback with an HTTPResponse object.
    pass


# Generated at 2022-06-18 10:04:49.640328
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com", method="GET")
    defaults = {"method": "POST"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.defaults == {"method": "POST"}
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.defaults == {"method": "POST"}
    assert request_proxy.headers == {}
    assert request_proxy.defaults == {"method": "POST"}
    assert request_proxy.body == b""
    assert request_proxy.defaults == {"method": "POST"}
    assert request_proxy.proxy_host == None
    assert request_proxy.defaults == {"method": "POST"}
    assert request_proxy.proxy_port

# Generated at 2022-06-18 10:04:53.346606
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method should be implemented by subclasses.
    # It is called with an HTTPRequest object and should call
    # callback with an HTTPResponse object (or raise an Exception).
    return


# Generated at 2022-06-18 10:06:27.878904
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTP

# Generated at 2022-06-18 10:06:38.920436
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPHeaders
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import _HTTPConnection
    from tornado.httpclient import _HTTPRequest
    from tornado.httpclient import _HTTPConnectionDelegate
    from tornado.httpclient import _HTTPConnectionParameters
    from tornado.httpclient import _HTTPConnectionFuture
    from tornado.httpclient import _HTTPConnectionFutureAdapter
    from tornado.httpclient import _HTTPConnectionFutureAdapterWithTimeout
    from tornado.httpclient import _HTTPConnectionFutureAdapterWithTimeoutAndRetry

# Generated at 2022-06-18 10:06:50.564897
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    import unittest.mock
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:06:53.064075
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method should be implemented by subclasses.
    # It should call callback with an HTTPResponse object.
    pass



# Generated at 2022-06-18 10:07:04.247804
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import unittest
    import tornado.testing
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.curl_httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.platform.auto
    import tornado.testing
    import tornado.util
    import tornado.options
    import tornado.gen
    import tornado.locks
    import tornado.iostream
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.platform.auto
    import tornado.testing
    import tornado.util
    import tornado.web


# Generated at 2022-06-18 10:07:08.127500
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    print(request_proxy.method)
    print(request_proxy.url)
    print(request_proxy.proxy_host)


# Generated at 2022-06-18 10:07:17.457298
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import bind_unused_port
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.ioloop import IOLoop
    from tornado.log import enable_pretty_logging
    from tornado.testing import AsyncHTTPTestCase

# Generated at 2022-06-18 10:07:28.434435
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.web
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.iostream
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.gen
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream

# Generated at 2022-06-18 10:07:29.255687
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:07:34.816163
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that AsyncHTTPClient.initialize() is called
    # when an AsyncHTTPClient is constructed.
    # This is a regression test for a bug that caused
    # the initialize() method to be called twice.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.initialized = True
    client = MyAsyncHTTPClient()
    assert client.initialized
    client.close()
