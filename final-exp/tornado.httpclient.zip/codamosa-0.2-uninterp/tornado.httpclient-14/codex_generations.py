

# Generated at 2022-06-18 09:59:58.961791
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import logging
    import time
    import json
    import os
    import sys
    import threading
    import concurrent.futures
    import functools
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.escape
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.iostream
    import tornado.stack_context
    import tornado.template
    import tornado.con

# Generated at 2022-06-18 10:00:13.228955
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    import tornado.testing
    import tornado.options
    import tornado.httpclient
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.kqueue
    import tornado.platform.epoll
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.kqueue
    import tornado.platform.epoll
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows

# Generated at 2022-06-18 10:00:25.315313
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import unittest
    import urllib.parse
    import time
    import datetime
    import pycurl
    import io
    import os
    import sys
    import socket
    import logging
    import threading
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent

# Generated at 2022-06-18 10:00:33.485251
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that initialize() is called with the right arguments
    # when an AsyncHTTPClient is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, defaults=None):
            self.defaults = defaults
            self.io_loop = IOLoop.current()

    client = MyAsyncHTTPClient(defaults=dict(foo="bar"))
    assert client.defaults == dict(foo="bar")
    assert client.io_loop is IOLoop.current()



# Generated at 2022-06-18 10:00:44.826839
# Unit test for method initialize of class AsyncHTTPClient

# Generated at 2022-06-18 10:00:50.550688
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url="http://www.baidu.com")
    defaults = {"method": "GET"}
    proxy = _RequestProxy(request, defaults)
    assert proxy.method == "GET"
    assert proxy.url == "http://www.baidu.com"
    assert proxy.proxy_host == None


# Generated at 2022-06-18 10:00:51.934956
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:00:52.848639
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:00:58.629546
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    import os
    import sys
    import subprocess
    import time
    import threading
    import urllib.parse
    import unittest
    import socket
    import ssl
    import functools
    import tempfile
    import shutil
    import contextlib
    import concurrent.futures
    import warnings
    import logging
    import re
    import http.client
    import base64
    import email.utils
    import email.message
    import email.policy
    import email.parser
    import email.generator
    import email.headerregistry
    import email

# Generated at 2022-06-18 10:01:11.809106
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import logging
    import os
    import socket
    import sys
    import unittest
    import urllib.parse
    import weakref
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.iostream
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.gen
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.test

# Generated at 2022-06-18 10:01:23.907210
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://www.baidu.com"
    method = "GET"
    headers = {"Content-Type": "application/json"}
    body = "hello world"
    auth_username = "admin"
    auth_password = "admin"
    auth_mode = "basic"
    connect_timeout = 20.0
    request_timeout = 20.0
    if_modified_since = datetime.datetime.now()
    follow_redirects = True
    max_redirects = 5
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
    use_gzip = True

# Generated at 2022-06-18 10:01:36.078290
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import time
    import os
    import sys
    import json
    import logging
    import requests
    import random
    import string
    import threading
    import concurrent.futures
    import multiprocessing
    import socket
    import urllib.parse
    import urllib.request
    import urllib.response
    import urllib.error
    import urllib.parse
    import urllib.robotparser
    import http.client
    import http.cookies
    import http.cookiejar
    import http.server
    import http.client

# Generated at 2022-06-18 10:01:47.610674
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
   

# Generated at 2022-06-18 10:01:48.473092
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:01:59.770896
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:02:13.420974
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import urllib.parse
    import time
    import json
    import os
    import sys
    import logging
    import logging.handlers
    import socket
    import random
    import string
    import datetime
    import time
    import uuid
    import requests
    import concurrent.futures
    import threading
    import functools
    import concurrent.futures
    import threading
    import functools
    import concurrent.futures
    import threading
    import functools
    import concurrent.futures
    import threading
    import funct

# Generated at 2022-06-18 10:02:21.578428
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import subprocess
    import shutil
    import time
    import signal
    import socket
    import threading
    import random
    import unittest
    import logging
    import functools
    import ssl
    import urllib.parse
    import http.server
    import socketserver
    import tornado.testing
    import tornado.escape
    import tornado.netutil
    import tornado.platform.auto
    import tornado.simple_httpclient
    import tornado.curl_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_

# Generated at 2022-06-18 10:02:23.860658
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # AsyncHTTPClient.__new__()
    pass


# Generated at 2022-06-18 10:02:24.666887
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:02:26.265707
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:02:37.313640
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.proxy_host == None


# Generated at 2022-06-18 10:02:38.780129
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass


# Generated at 2022-06-18 10:02:51.840574
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.httpclient
    import tornado.ioloop
    import tornado.web
    import tornado.websocket
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import json
    import time
    import os
    import sys
    import logging
    import threading
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.qt
    import tornado.platform.select
    import tornado.platform.tornado
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.tornado
    import tornado.platform.qt
    import tornado.platform.asyncio
   

# Generated at 2022-06-18 10:02:52.643340
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:58.987071
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.platform.asyncio
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.netutil
    import tornado.stack_context
    import tornado.locks
    import tornado.escape
    import tornado.httputil
    import tornado.http1connection
    import tornado.iostream
    import tornado.escape
    import tornado.gen
    import tornado.httputil

# Generated at 2022-06-18 10:03:08.914778
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:03:13.178252
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method': 'GET'}
    proxy = _RequestProxy(request, defaults)
    assert proxy.method == 'GET'
    assert proxy.url == 'http://www.baidu.com'
    assert proxy.headers == {}
    assert proxy.body == b''
    assert proxy.auth_username == None
    assert proxy.auth_password == None
    assert proxy.auth_mode == None
    assert proxy.connect_timeout == 20
    assert proxy.request_timeout == 20
    assert proxy.if_modified_since == None
    assert proxy.follow_redirects == True
    assert proxy.max_redirects == 5
    assert proxy.user_agent == 'tornado/%s' % tornado.version
    assert proxy.use_g

# Generated at 2022-06-18 10:03:23.594375
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest("http://www.baidu.com")
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "http://www.baidu.com"
    error = None
    request_time = None
    time_info = None
    reason = None
    start_time = None
    http_response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    try:
        http_response.rethrow()
    except HTTPError as e:
        print(e)


# Generated at 2022-06-18 10:03:33.501153
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import json
    import os
    import sys
    import unittest
    import urllib.parse
    import warnings
    import zlib
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.log import gen_log
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.test.util import unittest, skipOnTravis, skipIfNoIPv6
    from tornado.testing import AsyncHTTPTestCase, ExpectLog, bind_unused_

# Generated at 2022-06-18 10:03:42.570727
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # __new__ is a class method
    # __new__ of AsyncHTTPClient is a AsyncHTTPClient
    assert_equal(AsyncHTTPClient.__new__, AsyncHTTPClient)
    # __new__ of AsyncHTTPClient is callable
    assert_true(callable(AsyncHTTPClient.__new__))
    # __new__ of AsyncHTTPClient takes 1 argument
    assert_equal(AsyncHTTPClient.__new__.__code__.co_argcount, 1)
    # __new__ of AsyncHTTPClient takes 1 argument
    assert_equal(AsyncHTTPClient.__new__.__code__.co_varnames, ('cls',))
    # __new__ of AsyncHTTPClient takes 1 argument
    assert_equal(AsyncHTTPClient.__new__.__code__.co_argcount, 1)
   

# Generated at 2022-06-18 10:03:49.257733
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 10:03:52.648006
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['', 'http://www.google.com']
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:04:01.350412
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient
    import os
    import sys
    import unittest
    import urllib.parse
    import subprocess
    import time
    import json
    import random
    import string
    import shutil
    import logging
    import signal
    import multiprocessing
    import functools
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix


# Generated at 2022-06-18 10:04:11.906505
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Test the AsyncHTTPClient.__new__ method
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    # Test the singleton behavior
    client1 = AsyncHTTPClient()
    client2 = AsyncHTTPClient()
    assert client1 is client2
    client1.close()
    client2.close()

    # Test the force_instance=True argument
    client1 = AsyncHTTPClient(force_instance=True)
    client2 = AsyncHTTPClient(force_instance=True)
    assert client1 is not client2
    client1.close()
    client2.close()

    # Test the singleton behavior with a custom class
    AsyncHTTPClient.configure(SimpleAsyncHTTPClient)
    client1 = AsyncHTTPClient()
    client2 = AsyncHTTPClient()
    assert client1 is client2


# Generated at 2022-06-18 10:04:12.580394
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:04:13.291012
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:04:25.311036
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:04:25.916880
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:04:35.310526
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted

# Generated at 2022-06-18 10:04:37.928441
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client = AsyncHTTPClient()
    http_client.close()
    assert http_client._closed == True


# Generated at 2022-06-18 10:05:04.520025
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
   

# Generated at 2022-06-18 10:05:08.191147
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() is called when the client is
    # garbage-collected.
    client = AsyncHTTPClient()
    client.close = mock.Mock()
    del client
    gc.collect()
    AsyncHTTPClient.close.assert_called_with()

# Generated at 2022-06-18 10:05:09.987146
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    assert client._closed == True


# Generated at 2022-06-18 10:05:10.904874
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-18 10:05:22.100566
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import signal
    import socket
    import threading
    import unittest
    import urllib.parse
    import warnings
    import functools
    import logging
    import contextlib
    import io
    import ssl
    import tempfile
    import shutil
    import json
    import base64
    import gzip
    import zlib
    import email.utils
    import email.message
    import email.policy
    import hmac
    import hashlib
    import binascii
    import asyncio
    import concurrent

# Generated at 2022-06-18 10:05:31.931359
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.httpclient
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

# Generated at 2022-06-18 10:05:43.640034
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.netutil
   

# Generated at 2022-06-18 10:05:52.172099
# Unit test for method __new__ of class AsyncHTTPClient

# Generated at 2022-06-18 10:06:03.238631
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url="http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect_timeout == None
    assert request_proxy.request_timeout == None

# Generated at 2022-06-18 10:06:03.696123
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:06:34.958995
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.util import unittest

    class TestAsyncHTTPClient(AsyncHTTPClient):
        pass

    class TestSimpleAsyncHTTPClient(SimpleAsyncHTTPClient):
        pass

    class TestAsyncHTTPClient2(AsyncHTTPClient):
        pass

    class TestSimpleAsyncHTTPClient2(SimpleAsyncHTTPClient):
        pass

    class TestAsyncHTTPClient3(AsyncHTTPClient):
        pass

    class TestSimpleAsyncHTTPClient3(SimpleAsyncHTTPClient):
        pass

    class TestAsyncHTTPClient4(AsyncHTTPClient):
        pass

    class TestSimpleAsyncHTTPClient4(SimpleAsyncHTTPClient):
        pass

    class TestAsyncHTTPClient5(AsyncHTTPClient):
        pass

    class TestSimpleAsyncHTTPClient5(SimpleAsyncHTTPClient):
        pass


# Generated at 2022-06-18 10:06:47.114035
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:06:48.091421
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-18 10:06:56.354698
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnection
   

# Generated at 2022-06-18 10:07:07.046239
# Unit test for function main
def test_main():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform

# Generated at 2022-06-18 10:07:09.210630
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test the method initialize of class AsyncHTTPClient
    # This is a static method
    # No need to test
    pass


# Generated at 2022-06-18 10:07:19.655193
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest, HTTPResponse
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.options
    import tornado.ioloop
    import tornado.gen
    import tornado.httpserver
    import tornado.httputil
    import tornado.iostream
    import tornado.escape
    import tornado.concurrent
    import tornado.locks
    import tornado.simple_httpclient
    import tornado.netutil
    import tornado.process
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.util
    import tornado.queues
   

# Generated at 2022-06-18 10:07:29.817281
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import urllib.parse
    import http.cookies
    import time
    import socket
    import ssl
    import sys
    import os
    import logging
    import functools
    import concurrent.futures
    import threading
    import subprocess
    import contextlib
    import tempfile
    import shutil
    import warnings
    import re
    import io
    import gzip
    import zlib
    import base64
    import hmac
    import hashlib
    import binascii
    import email.utils
    import email.message

# Generated at 2022-06-18 10:07:39.895998
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.process import Subprocess
    from tornado.util import b
    from tornado.test.util import unittest
    from tornado.test.util import skipIfNonUnix
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoNetwork
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipIfNoSSL
    from tornado.test.util import skipIfNoCompression

# Generated at 2022-06-18 10:07:47.012166
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() closes the underlying HTTPClient
    # and that it can be called multiple times without error.
    http_client = AsyncHTTPClient()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()

# Generated at 2022-06-18 10:08:39.831806
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:08:40.531142
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:08:51.228630
# Unit test for function main
def test_main():
    import sys
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
   

# Generated at 2022-06-18 10:08:59.206872
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.escape
    import tornado.platform.asyncio
    import asyncio
    import time
    import json
    import os
    import sys
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.request
    import urllib.error
    import urllib

# Generated at 2022-06-18 10:09:10.661000
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import signal

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")


# Generated at 2022-06-18 10:09:17.780381
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://www.example.com")
    response = HTTPResponse(request, 200, reason="OK")
    assert response.request == request
    assert response.code == 200
    assert response.reason == "OK"
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer is None
    assert response.body == b""
    assert response.effective_url == "http://www.example.com"
    assert response.error is None
    assert response.request_time is None
    assert response.time_info == {}
    assert response.start_time is None


# Generated at 2022-06-18 10:09:21.741896
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() works.
    # This is a bit tricky because the client is a singleton, so we
    # have to use force_instance=True to get a new one.
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    assert client._closed
    assert client.io_loop.closed()
    # Make sure we can call close() again without error.
    client.close()


# Generated at 2022-06-18 10:09:26.814802
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
   