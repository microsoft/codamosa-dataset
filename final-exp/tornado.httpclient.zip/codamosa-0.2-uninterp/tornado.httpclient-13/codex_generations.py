

# Generated at 2022-06-18 09:59:52.421630
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:00:04.337911
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import _HTTPConnection
    from tornado.httpclient import _HTTPConnectionDelegate
    from tornado.httpclient import _HTTPConnectionParameters
    from tornado.httpclient import _HTTPConnectionFuture
    from tornado.httpclient import _HTTPConnectionContext
    from tornado.httpclient import _HTTPConnectionContextDelegate
    from tornado.httpclient import _HTTPRequestProxy
    from tornado.httpclient import _HTTPRequestContext
    from tornado.httpclient import _HTTP

# Generated at 2022-06-18 10:00:10.359625
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([('/', RequestHandler)])
        @gen_test
        def test_main(self):
            main()

# Generated at 2022-06-18 10:00:19.041312
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:00:32.276406
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.gen
    import tornado.http1connection
    import tornado.httputil
    import tornado.iostream
    import tornado.locks
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.test.web_test
    import tornado.util
    import tornado.web
    import tornado

# Generated at 2022-06-18 10:00:43.877172
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.util import Configurable
    from tornado.concurrent import Future
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.simple_httpclient
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.locks
    import tornado.queues
    import tornado.iostream
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.process
    import tornado.netutil
    import tornado.stack_context
    import tornado.escape
    import tornado.httputil
    import tornado.http1connection
   

# Generated at 2022-06-18 10:00:50.189923
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'


# Generated at 2022-06-18 10:01:02.450412
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that AsyncHTTPClient.initialize() is called
    # when an AsyncHTTPClient is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    client = MyAsyncHTTPClient()
    assert client.args == ()
    assert client.kwargs == {}

    client = MyAsyncHTTPClient(foo=1)
    assert client.args == ()
    assert client.kwargs == {"foo": 1}

    client = MyAsyncHTTPClient(foo=1, force_instance=True)
    assert client.args == ()
    assert client.kwargs == {"foo": 1}

    client = MyAsyncHTTPClient(force_instance=True)
    assert client.args == ()
    assert client.kwargs

# Generated at 2022-06-18 10:01:06.661762
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:01:12.129526
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest("http://www.google.com")
    response = HTTPResponse(request, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()


# Generated at 2022-06-18 10:01:52.202446
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    import pytest
    with pytest.raises(NotImplementedError):
        AsyncHTTPClient().fetch_impl(None, None)


# Generated at 2022-06-18 10:01:54.450091
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    assert client._closed == True


# Generated at 2022-06-18 10:02:06.598665
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import subprocess
    import time
    import signal
    import logging
    import multiprocessing
    import threading
    import socket
    import tempfile
    import shutil
    import functools
    import contextlib
    import warnings
    import concurrent.futures
    import concurrent.futures._base
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.windows

# Generated at 2022-06-18 10:02:18.440835
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import time
    import unittest
    import sys
    import os
    import os.path
    import logging
    import json
    import io
    import functools
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient

# Generated at 2022-06-18 10:02:20.396931
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test for method fetch_impl( ... ) of class AsyncHTTPClient
    # This method is abstract and should be overridden.
    pass


# Generated at 2022-06-18 10:02:21.525482
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:33.637414
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import HTTPError
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import bind_unused_port
    from tornado.web import RequestHandler, Application
    from tornado.websocket import WebSocketHandler
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_sockets
    from tornado.testing import AsyncHTTPTestCase, ExpectLog
    from tornado.testing import LogTrapTestCase
    from tornado.testing import bind_unused_port


# Generated at 2022-06-18 10:02:41.641730
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # __new__ is a static method
    # __new__ of class AsyncHTTPClient with arguments (force_instance=False, **kwargs)
    # __new__ of class AsyncHTTPClient with arguments (force_instance=True, **kwargs)
    # __new__ of class AsyncHTTPClient with arguments (force_instance=False, **kwargs)
    # __new__ of class AsyncHTTPClient with arguments (force_instance=True, **kwargs)
    pass


# Generated at 2022-06-18 10:02:54.081084
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:02:59.451039
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that close() frees the AsyncHTTPClient instance.
    # This is a regression test for a memory leak that occurred
    # when an AsyncHTTPClient was created and closed without ever
    # using it.
    io_loop = IOLoop()
    io_loop.make_current()
    try:
        AsyncHTTPClient()
        AsyncHTTPClient.configure("tornado.test.mock_httpclient.MockAsyncHTTPClient")
        AsyncHTTPClient()
        io_loop.close()
        gc.collect()
        assert not AsyncHTTPClient._async_clients()
    finally:
        io_loop.close()
        io_loop.clear_current()


# Generated at 2022-06-18 10:05:31.149150
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"a":1}
    proxy = _RequestProxy(request,defaults)
    assert proxy.a == 1
    assert proxy.url == "http://www.baidu.com"


# Generated at 2022-06-18 10:05:42.173616
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:05:51.571939
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
   

# Generated at 2022-06-18 10:06:02.710741
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import unittest
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib

# Generated at 2022-06-18 10:06:06.099982
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when the class is instantiated.
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.initialized = True

    client = TestAsyncHTTPClient()
    assert client.initialized



# Generated at 2022-06-18 10:06:11.789210
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, main
    from tornado.web import RequestHandler, Application
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.iostream
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.process
    import tornado.netutil
    import tornado.httputil
    import tornado.escape
    import tornado.locale
    import tornado.log
    import tornado.stack_context
    import tornado.concurrent
    import tornado.ioloop
    import tornado.simple_httpclient
    import tornado.curl

# Generated at 2022-06-18 10:06:22.171485
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:06:32.916111
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.headers == {}
    assert request_proxy.body == b''
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect_timeout == None
    assert request_proxy.request_timeout == None
    assert request_proxy.if_modified_since == None
    assert request_proxy.follow_redirects == True
    assert request_proxy.max_redirects == 5
   

# Generated at 2022-06-18 10:06:38.364015
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    import os
    import sys
    import unittest
    import urllib.parse
    import tempfile
    import shutil
    import subprocess
    import time
    import signal
    import socket
    import functools
    import ssl
    import threading
    import logging
    import concurrent.futures
    import asyncio
    import contextlib
    import warnings
    import json
    import io
    import re
    import base64
    import gzip
    import zlib
    import platform
    import email.utils
    import email.message


# Generated at 2022-06-18 10:06:50.145618
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://www.baidu.com"
    method = "GET"
    headers = {"Content-Type": "application/json"}
    body = "hello world"
    auth_username = "username"
    auth_password = "password"
    auth_mode = "basic"
    connect_timeout = 20.0
    request_timeout = 20.0
    if_modified_since = datetime.datetime.now()
    follow_redirects = True
    max_redirects = 5
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36"
    use_gzip = True