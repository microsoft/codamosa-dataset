

# Generated at 2022-06-18 09:59:59.964717
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    import asyncio
    import unittest
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.httpserver
   

# Generated at 2022-06-18 10:00:14.223444
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() is called when the client is
    # garbage collected.
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    import gc
    import asyncio
    import unittest

    class TestAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, io_loop: IOLoop, close_called: "Future[None]") -> None:
            super(TestAsyncHTTPClient, self).__init__()
            self.io_loop = io_loop
            self.close_called = close_called

        def close(self) -> None:
            super(TestAsyncHTTPClient, self).close()

# Generated at 2022-06-18 10:00:26.899482
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import urllib.parse
    import subprocess
    import time
    import signal
    import threading
    import socket
    import tempfile
    import shutil
    import ssl
    import functools
    import warnings
    import logging
    import platform
    import multiprocessing
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures

# Generated at 2022-06-18 10:00:39.442151
# Unit test for function main
def test_main():
    import sys
    import os
    import io
    import unittest
    import unittest.mock
    import tornado.testing
    import tornado.options
    import tornado.httpclient
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado

# Generated at 2022-06-18 10:00:47.794481
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.headers == {}
    assert request_proxy.body == b""
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect

# Generated at 2022-06-18 10:00:48.413325
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-18 10:00:53.265790
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import subprocess
    import time
    import signal

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")


# Generated at 2022-06-18 10:01:05.181748
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Test for HTTPResponse.rethrow()
    # Create a HTTPResponse object
    request = HTTPRequest("http://www.google.com")
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "http://www.google.com"
    error = HTTPError(code, message="test", response=None)
    request_time = 1.0
    time_info = {}
    reason = "OK"
    start_time = time.time()
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    # Test for HTTPResponse.rethrow()
    response.rethrow()
    # Test for HTTPResponse.

# Generated at 2022-06-18 10:01:17.285958
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import HTTPRequest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import aiohttp
    import requests
    import time
    import json
    import os
    import sys
    import logging
    import unittest
    import threading
    import concurrent.futures
    import multiprocessing
    import random
    import string
    import copy
    import traceback
    import functools
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import ur

# Generated at 2022-06-18 10:01:18.255401
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-18 10:01:39.269096
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Test the fetch method of class AsyncHTTPClient
    # The fetch method is a coroutine, so we need to use the asyncio module to run it
    import asyncio
    import tornado.httpclient
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    # Create an instance of AsyncHTTPClient
    http_client = tornado.httpclient.AsyncHTTPClient()
    # Create a coroutine
    async def main():
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)
    # Run the coroutine

# Generated at 2022-06-18 10:01:51.512907
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import signal
    import socket
    import threading
    import unittest
    import urllib.parse
    import warnings
    import weakref
    import functools
    import logging
    import re
    import ssl
    import tempfile
    import shutil
    import io
    import contextlib
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select

# Generated at 2022-06-18 10:02:03.494423
# Unit test for method close of class AsyncHTTPClient

# Generated at 2022-06-18 10:02:16.160461
# Unit test for function main
def test_main():
    import sys
    import os
    import io
    import unittest
    import tornado.testing
    import tornado.options
    import tornado.httpclient
    import tornado.httputil
    import tornado.platform.asyncio
    import tornado.platform.auto
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.queue
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows_events
    import tornado.platform.windows_utils
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.queue
    import tornado.platform.ep

# Generated at 2022-06-18 10:02:20.805709
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when an instance is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.kwargs = kwargs
    client = MyAsyncHTTPClient(foo=1, bar=2)
    assert client.kwargs == dict(foo=1, bar=2)



# Generated at 2022-06-18 10:02:30.661126
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:02:42.815817
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import unittest
    import urllib.parse
    import warnings
    import threading
    import socket
    import ssl
    import shutil
    import tempfile
    import platform
    import re
    import logging
    import json
    import http.client
    import functools
    import concurrent.futures
    import asyncio
    import contextlib
    import signal
    import pprint
    import io
    import base64
    import hashlib
    import hmac

# Generated at 2022-06-18 10:02:52.578924
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.httpclient
    http_client = tornado.httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except tornado.httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:03:03.228135
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado

# Generated at 2022-06-18 10:03:08.190714
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when an instance is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.kwargs = kwargs
    client = MyAsyncHTTPClient(foo=1, bar=2)
    assert client.kwargs == dict(foo=1, bar=2)


# Generated at 2022-06-18 10:03:39.428441
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import aiohttp
    import aiofiles
    import os
    import json
    import time
    import logging
    import tornado.log
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
   

# Generated at 2022-06-18 10:03:51.501105
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.options import define, options, parse_command_line
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.ioloop
    import tornado.testing


# Generated at 2022-06-18 10:03:52.854895
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False


# Generated at 2022-06-18 10:04:01.492826
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.util import Configurable
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.escape import utf8, native_str
    from tornado.util import Configurable
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.escape import utf8, native_str
    from tornado.util import Configurable
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.escape import utf8, native_str
    from tornado.util import Configurable
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

# Generated at 2022-06-18 10:04:12.091856
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import unittest
    import sys
    import os
    import io
    import subprocess
    import signal
    import time
    import socket
    import threading
    import logging
    import re
    import ssl
    import base64
    import tempfile
    import shutil
    import errno
    import warnings
    import concurrent.futures
    import concurrent.fut

# Generated at 2022-06-18 10:04:24.283733
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import unittest
    import urllib.parse
    import tornado.testing
    import tornado.platform.asyncio

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            class HelloHandler(RequestHandler):
                def get(self):
                    self.write("Hello")

            return Application([("/", HelloHandler)])


# Generated at 2022-06-18 10:04:33.863153
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import subprocess
    import time
    import signal
    import socket
    import threading
    import logging
    import tempfile
    import shutil
    import functools
    import re
    import json
    import base64
    import urllib.parse
    import urllib.request
    import urllib.error
    import ssl
    import warnings
    import email.utils
    import datetime
    import io
    import gzip
    import zlib
    import platform
    import asyncio
    import concurrent.futures


# Generated at 2022-06-18 10:04:43.939016
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:04:54.821342
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:05:04.102372
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import time
    import socket
    import functools
    import sys
    import os
    import logging
    import threading
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.fut

# Generated at 2022-06-18 10:07:03.138684
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # test_AsyncHTTPClient_fetch_impl is not tested.
    pass


# Generated at 2022-06-18 10:07:11.491007
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPConnection

# Generated at 2022-06-18 10:07:22.396433
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"a":1, "b":2}
    req = _RequestProxy(request, defaults)
    assert req.a == 1
    assert req.b == 2
    assert req.c == None
    assert req.url == "http://www.baidu.com"
    assert req.method == "GET"
    assert req.headers == {}
    assert req.body == b""
    assert req.auth_username == None
    assert req.auth_password == None
    assert req.auth_mode == "basic"
    assert req.connect_timeout == 20.0
    assert req.request_timeout == 20.0
    assert req.follow_redirects == True
    assert req.max_redirects == 5
    assert req.user_agent

# Generated at 2022-06-18 10:07:25.149613
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # AsyncHTTPClient.fetch_impl(request, callback) NotImplementedError
    pass



# Generated at 2022-06-18 10:07:27.950229
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method should be implemented by subclasses.
    # It should call callback with an HTTPResponse object.
    pass



# Generated at 2022-06-18 10:07:38.211014
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.ioloop
    import tornado.iostream
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.netutil
    import tornado.locks
    import tornado.queues
    import tornado.process
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
   

# Generated at 2022-06-18 10:07:41.967871
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"


# Generated at 2022-06-18 10:07:42.442654
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:07:50.982437
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio
    import unittest

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class AsyncHTTPClientTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])


# Generated at 2022-06-18 10:08:03.970866
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.options import options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    import unittest
    import os
    import sys
    import time
    import socket
    import logging
    import threading
    import functools
    import subprocess
    import signal
    import errno
    import tempfile
    import shutil
    import ssl
    import re
    import platform
    import warnings
    import inspect
    import base64
    import json
    import urllib.parse
    import email.utils
    import email.message
    import email.policy
    import http.client
   