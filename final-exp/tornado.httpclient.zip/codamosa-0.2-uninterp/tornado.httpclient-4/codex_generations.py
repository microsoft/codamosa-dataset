

# Generated at 2022-06-18 09:59:52.515442
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:00:04.390468
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() frees its resources.
    # This test is a little tricky because the garbage collector
    # doesn't run during the test, so we have to explicitly break
    # cycles to avoid refcount errors.
    import gc
    import logging
    import weakref
    import tornado.ioloop
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.iocp
    import tornado.platform.windows
    import tornado.platform.posix
    import tornado.simple_httpclient
    import tornado.curl_httpclient
    import tornado.netutil
    import tornado.testing

# Generated at 2022-06-18 10:00:17.676655
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.test.util import unittest_run_loop

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)

# Generated at 2022-06-18 10:00:22.392674
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method is called
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, defaults=None):
            self.defaults = defaults
    client = TestAsyncHTTPClient(defaults=dict(a=1))
    assert client.defaults == dict(a=1)

# Generated at 2022-06-18 10:00:35.377434
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import bind_unused_port
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_tornado_future
    from tornado.testing import AsyncHTTPTestCase, ExpectLog
    from tornado.testing import gen_

# Generated at 2022-06-18 10:00:38.306397
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test for method initialize of class AsyncHTTPClient
    # This test is not useful.
    pass


# Generated at 2022-06-18 10:00:47.207186
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    http_client = SimpleAsyncHTTPClient()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close()
    http_client.close

# Generated at 2022-06-18 10:00:50.822629
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # __new__ is a static method
    # __new__ of class AsyncHTTPClient with arguments (force_instance=False, **kwargs)
    # is a constructor
    # raises: RuntimeError
    pass


# Generated at 2022-06-18 10:00:59.186309
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest("http://www.google.com")
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "http://www.google.com"
    error = None
    request_time = 0.1
    time_info = {}
    reason = "OK"
    start_time = time.time()
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    response.rethrow()


# Generated at 2022-06-18 10:01:12.316733
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import pytest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPConnectionParameters
    from tornado.httputil import _RequestProxy
    from tornado.httpclient import HTTPError
    from tornado.httpclient import _RequestStartLine
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import _HTTPConnectionParameters
    from tornado.httpclient import _HTTPConnection
    from tornado.httpclient import _HTTPConnectionDelegate
    from tornado.httpclient import _HTTPRequest
    from tornado.httpclient import _HTTPResponse
    from tornado.httpclient import _HTTPConnectionParameters

# Generated at 2022-06-18 10:01:24.799481
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio
    import aiohttp
    import aiohttp.web
    import aiohttp.test_utils
    import aiohttp.multipart
    import aiohttp.client
    import aiohttp.client_exceptions
    import aiohttp.server
    import aiohttp.streams
   

# Generated at 2022-06-18 10:01:36.655390
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.util import unittest
    from tornado.util import Configurable
    from tornado.web import Application
    from tornado.websocket import WebSocketHandler
    from tornado.ioloop import IOLoop
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.testing import AsyncHTTPTestCase
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import socket
    import sys
    import unittest
    import warnings
    import weakref
    import functools
    import time
    import os
    import io

# Generated at 2022-06-18 10:01:45.688073
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.httpclient
    http_client = tornado.httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except tornado.httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:01:56.849639
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPFile
    from tornado.httputil import parse_body_arguments
    from tornado.httputil import parse_multipart_form_data
    from tornado.httputil import parse_header_links
    from tornado.httputil import _parse_header
    from tornado.httputil import _parse_date
    from tornado.httputil import _parse_content_range
    from tornado.httputil import _parse_cache_control
    from tornado.httputil import _parse_set_cookie
    from tornado.httputil import _parse_dict_header

# Generated at 2022-06-18 10:02:10.515559
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test the initialize method of class AsyncHTTPClient
    # Create an instance of AsyncHTTPClient
    async_http_client = AsyncHTTPClient()
    # Call the initialize method of the instance
    async_http_client.initialize()
    # Check the io_loop attribute of the instance
    assert async_http_client.io_loop == IOLoop.current()
    # Check the defaults attribute of the instance
    assert async_http_client.defaults == HTTPRequest._DEFAULTS
    # Check the _closed attribute of the instance
    assert async_http_client._closed == False
    # Create an instance of AsyncHTTPClient with force_instance=True
    async_http_client = AsyncHTTPClient(force_instance=True)
    # Call the initialize method of the instance
    async_http_client.initialize()
    #

# Generated at 2022-06-18 10:02:11.248637
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:20.678890
# Unit test for method close of class AsyncHTTPClient

# Generated at 2022-06-18 10:02:21.817393
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:33.701988
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import json
    import time
    import os
    import sys
    import logging
    import unittest
    import requests
    import socket
    import threading
    import concurrent.futures
    import tornado.gen
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import json
    import time
    import os
    import sys
    import logging
    import unittest
    import requests
    import socket


# Generated at 2022-06-18 10:02:37.212484
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method should be implemented by subclasses.
    # It should call callback with an HTTPResponse object.
    pass


# Generated at 2022-06-18 10:02:56.424666
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-18 10:02:57.141289
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:03:07.495106
# Unit test for function main
def test_main():
    import sys
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.escape import url_escape
    from tornado.options import define, options
    from tornado.httpclient import HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import functools
    import os
    import socket
    import ssl
    import threading
    import time
    import warnings
    import weakref
    from tornado.test.util import unittest, skipIfNonUnix
    from tornado.test.util import skipIfNoIPv6
    from tornado.test.util import skipOnTravis
    from tornado.test.util import skipIfNoPymongo


# Generated at 2022-06-18 10:03:09.573513
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"a":1}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.a == 1
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.b == None


# Generated at 2022-06-18 10:03:21.268685
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix

# Generated at 2022-06-18 10:03:31.743221
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.ioloop
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import os
    import sys
    import unittest
    import logging
    import time
    import socket
    import threading
    import subprocess
    import signal
    import functools
    import tempfile
    import shutil
    import re
    import json
    import io
    import base64
    import ssl
    import concurrent.futures
    import warnings
    import contextlib
    import urllib.parse
    import urllib.request
    import urll

# Generated at 2022-06-18 10:03:32.477506
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass


# Generated at 2022-06-18 10:03:40.147345
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.headers == {}
    assert request_proxy.body == b""
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect_timeout == 20
    assert request_proxy.request_timeout == 20
    assert request_proxy.follow_redirects == True
    assert request_proxy.max_redirects == 5
    assert request_proxy.user_agent == "tornado/%s"

# Generated at 2022-06-18 10:03:52.295381
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.util import b
    from tornado.log import gen_log
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy


# Generated at 2022-06-18 10:03:58.595344
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.httpserver import HTTPServer
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.netutil import bind_sockets
    from tornado.util import b
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import is_

# Generated at 2022-06-18 10:06:14.758278
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.headers == {}
    assert request_proxy.body == b""
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect

# Generated at 2022-06-18 10:06:15.371388
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:06:26.783005
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import unittest
    import os
    import sys
    import time
    import tornado.ioloop
    import tornado.httpserver
    import tornado.platform.asyncio
    import asyncio
    import functools
    import tornado.web
    import tornado.gen
    import tornado.httpclient
    import tornado.testing
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.locks
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpclient

# Generated at 2022-06-18 10:06:37.090068
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import json
    import time
    import os
    import sys
    import logging
    import tornado.log
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.util
    import tornado.process
    import tornado.netutil
    import tornado.locks
    import tornado.iostream
    import tornado.stack_context


# Generated at 2022-06-18 10:06:49.539546
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.httputil
    import tornado.escape
    import tornado.locks
    import tornado.log
    import tornado.stack_context
    import tornado.template
    import tornado.concurrent
    import tornado.gen
    import tornado.queues

# Generated at 2022-06-18 10:06:59.648333
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
   

# Generated at 2022-06-18 10:07:09.050678
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

# Generated at 2022-06-18 10:07:19.445936
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import pytest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:07:29.642068
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix

# Generated at 2022-06-18 10:07:39.719536
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPRequest
    from tornado.options import define, options, parse_command_line
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import os
    import sys
    import unittest
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.robotparser
    import urllib.parse
    import urllib.error
    import urllib.request
    import urllib