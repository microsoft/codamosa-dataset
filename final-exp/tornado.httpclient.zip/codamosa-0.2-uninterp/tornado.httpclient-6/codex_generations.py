

# Generated at 2022-06-18 09:59:49.871635
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-18 09:59:55.389280
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
   

# Generated at 2022-06-18 10:00:02.154341
# Unit test for method __repr__ of class HTTPResponse

# Generated at 2022-06-18 10:00:13.382314
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="http://www.google.com")
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "http://www.google.com"
    error = HTTPError(code, message="", response=None)
    request_time = 0.0
    time_info = {}
    reason = "OK"
    start_time = 0.0
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    response.rethrow()


# Generated at 2022-06-18 10:00:21.721342
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://www.google.com")
    response = HTTPResponse(request, 200)
    assert response.request == request
    assert response.code == 200
    assert response.reason == "OK"
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer is None
    assert response.effective_url == "http://www.google.com"
    assert response.error is None
    assert response.request_time is None
    assert response.time_info == {}
    assert response.start_time is None


# Generated at 2022-06-18 10:00:34.687310
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import signal
    import unittest
    import threading
    import socket
    import logging
    import tempfile
    import shutil
    import functools
    import urllib.parse
    import ssl
    import http.client
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform

# Generated at 2022-06-18 10:00:45.677980
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import time
    import os
    import sys
    import threading
    import logging
    import socket
    import ssl
    import http.client
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse


# Generated at 2022-06-18 10:00:50.401983
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.httpclient
    http_client = tornado.httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except tornado.httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:01:02.646474
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import logging
    import unittest
    import sys
    import os
    import time
    import json
    import random
    import base64
    import hashlib
    import hmac
    import urllib
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.robotparser
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response

# Generated at 2022-06-18 10:01:14.864763
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:01:57.939186
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.httpclient
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.escape
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.qt
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.qt
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.qt
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.qt
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado

# Generated at 2022-06-18 10:02:11.572170
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import time
    import sys
    import os

    class MainHandler(tornado.web.RequestHandler):
        @tornado.web.asynchronous
        @tornado.gen.coroutine
        def get(self):
            http_client = tornado.httpclient.AsyncHTTPClient()
            response = yield http_client.fetch("http://www.google.com")
            self.write(response.body)
            self.finish()

    application = tornado.web.Application([
        (r"/", MainHandler),
    ])

    if __name__ == "__main__":
        tornado.platform.asyncio.AsyncI

# Generated at 2022-06-18 10:02:20.840677
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.ioloop
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.i

# Generated at 2022-06-18 10:02:33.361664
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
   

# Generated at 2022-06-18 10:02:35.667381
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    assert client._closed == True


# Generated at 2022-06-18 10:02:37.554687
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test for method initialize of class AsyncHTTPClient
    # This test is not implemented
    pass


# Generated at 2022-06-18 10:02:51.001462
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import time
    import unittest
    import urllib.parse
    import warnings
    import functools
    import logging
    import socket
    import ssl
    import threading
    import concurrent.futures
    import subprocess
    import tempfile
    import shutil
    import contextlib
    import io
    import json
    import base64
    import email.utils
    import email.message
    import email.policy
    import hmac
    import hashlib
    import zlib
    import gzip
   

# Generated at 2022-06-18 10:02:53.933118
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['httpclient.py', 'http://www.google.com']
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:03:04.570249
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() works even if the client has
    # never been used.
    client = AsyncHTTPClient()
    client.close()
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    # Test that AsyncHTTPClient.close() removes the client from the
    # cache.
    client = AsyncHTTPClient()
    client.close()
    client2 = AsyncHTTPClient()
    assert client is not client2
    # Test that AsyncHTTPClient.close() removes the client from the
    # cache even if the client was created with force_instance=True.
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    client2 = AsyncHTTPClient()
    assert client is not client2
    # Test that AsyncHTTPClient.close

# Generated at 2022-06-18 10:03:05.599509
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass


# Generated at 2022-06-18 10:03:47.871757
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import subprocess
    import time
    import signal
    import socket
    import threading
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.select
    import tornado.platform.asyncio
    import tornado

# Generated at 2022-06-18 10:03:57.908772
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.options import define, options, parse_command_line
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import AsyncIOMainLoop

# Generated at 2022-06-18 10:04:06.271968
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.gen
    import tornado.locks
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.template
    import tornado.test
    import tornado.testing
    import tornado.util
    import tornado.process
    import tornado.netutil
    import tornado.iostream
    import tornado.tcpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil

# Generated at 2022-06-18 10:04:17.892349
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    class TestAsyncHTTPClient(unittest.TestCase):
        def test_fetch_impl(self):
            from tornado.httpclient import AsyncHTTPClient
            from tornado.httputil import HTTPHeaders
            from tornado.httpclient import HTTPRequest
            from tornado.httpclient import HTTPResponse
            from tornado.httpclient import HTTPError
            from tornado.httpclient import HTTPClient
            from tornado.httpclient import HTTPError
            from tornado.httpclient import HTTPResponse
            from tornado.httpclient import HTTPRequest
            from tornado.httpclient import HTTPClient
            from tornado.httpclient import HTTPError
            from tornado.httpclient import HTTPResponse
            from tornado.httpclient import HTTPRequest
            from tornado.httpclient import HTTPClient
            from tornado.httpclient import HTTPError

# Generated at 2022-06-18 10:04:29.170578
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResp

# Generated at 2022-06-18 10:04:30.177246
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-18 10:04:37.754623
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:04:41.941967
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    client = SimpleAsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False


# Generated at 2022-06-18 10:04:52.829064
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequest

# Generated at 2022-06-18 10:05:02.539143
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    from tornado.escape import utf8

    class HelloHandler(RequestHandler):
        def get(self):
            self.write(b"Hello, world")

    class HelloProxyHandler(RequestHandler):
        def get(self):
            self.write(b"Hello, proxy")

    class HelloRedirectHandler(RequestHandler):
        def get(self):
            self.redirect("/hello")

    class HelloRedirectProxyHandler(RequestHandler):
        def get(self):
            self.redirect("/proxy_hello")


# Generated at 2022-06-18 10:06:03.531536
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.auto
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix

# Generated at 2022-06-18 10:06:12.602481
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.httpclient import AsyncHTTPClient
    client = AsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()

# Generated at 2022-06-18 10:06:23.359580
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop

# Generated at 2022-06-18 10:06:30.709200
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:06:41.537186
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.web
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.iostream
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.gen
    import tornado.escape
    import tornado.httputil
    import tornado.http1connection
    import tornado.ioloop
    import tornado.iostream
   

# Generated at 2022-06-18 10:06:52.828632
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import pytest
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import logging
    import socket
    import sys
    import time
    import unittest
    import urllib.parse
    import weakref
    import zlib
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.log import gen_log
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.test.util import unittest, skipOnTravis, skipIfNoIPv6

# Generated at 2022-06-18 10:07:04.200715
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url='http://www.baidu.com', method='GET')
    defaults = {'method': 'POST'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.defaults == {'method': 'POST'}
    assert request_proxy.request == request
    assert request_proxy.headers == {}
    assert request_proxy.body == b''
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.auth

# Generated at 2022-06-18 10:07:07.002553
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False


# Generated at 2022-06-18 10:07:16.255552
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import os
    import sys
    import unittest
    import urllib.parse
    import warnings

    class HelloHandler(RequestHandler):
        def get(self):
            self.write('Hello')

    class HelloRedirectHandler(RequestHandler):
        def get(self):
            self.redirect('/hello')

    class HelloRedirectHandler2(RequestHandler):
        def get(self):
            self.redirect('/hello2')


# Generated at 2022-06-18 10:07:22.440821
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when an instance is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.kwargs = kwargs
    client = MyAsyncHTTPClient(foo=1)
    assert client.kwargs == dict(foo=1)
    client.close()
