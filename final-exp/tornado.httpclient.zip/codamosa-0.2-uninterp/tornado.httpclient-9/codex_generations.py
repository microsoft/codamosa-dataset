

# Generated at 2022-06-18 10:00:03.421819
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:00:07.991164
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method':'GET'}
    request_proxy = _RequestProxy(request, defaults)
    print(request_proxy.method)


# Generated at 2022-06-18 10:00:20.241930
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import url_escape
    from tornado.util import b
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import aiohttp
    import json
    import time
    import os
    import sys
    import logging
    import logging.handlers
    import threading
    import concurrent.futures
    import functools
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response

# Generated at 2022-06-18 10:00:33.433337
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import unittest
    import tornado.platform.asyncio
    import asyncio
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.web
    import tornado.testing
    import tornado.httpclient
    import tornado.httpserver
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.process
    import tornado.stack_context
    import tornado.locks
    import tornado.concurrent
    import tornado.queues
   

# Generated at 2022-06-18 10:00:42.632423
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="http://www.google.com")
    response = HTTPResponse(request=request, code=200)
    response.rethrow()
    response = HTTPResponse(request=request, code=404)
    try:
        response.rethrow()
    except HTTPError as e:
        assert e.code == 404
        assert e.response == response
        assert e.request == request
        assert e.message == "HTTP 404: Not Found"
    else:
        assert False, "HTTPResponse.rethrow() should raise HTTPError"



# Generated at 2022-06-18 10:00:48.382206
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.gen
    import tornado.locks
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.process
    import tornado.queues
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.test
    import tornado.util
    import tornado.iostream
    import tornado.httputil
    import tornado.escape
    import tornado.locale
    import tornado.log

# Generated at 2022-06-18 10:00:50.379411
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # Test for method fetch of class HTTPClient
    # This method is not implemented; it returns None
    pass


# Generated at 2022-06-18 10:00:58.377792
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:00:59.900726
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-18 10:01:10.281404
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="http://www.google.com")
    response = HTTPResponse(request=request, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()
    response.error = HTTPError(500, message="Internal Server Error", response=response)
    try:
        response.rethrow()
    except HTTPError as e:
        assert e.code == 500
        assert e.message == "Internal Server Error"
        assert e.response == response


# Generated at 2022-06-18 10:02:13.693050
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPRequest
    from tornado.options import define, options, parse_command_line
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import aiohttp
    import os
    import sys
    import unittest
    import urllib.parse
    import logging
    import time
    import json
    import functools
    import inspect
    import types
    import traceback
    import re
    import io
    import random
    import string
    import pycurl
    import socket
    import ssl
    import threading
    import concurrent.futures
    import multiprocessing
    import sub

# Generated at 2022-06-18 10:02:14.442150
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:21.995705
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.ioloop
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.httputil
    import tornado.escape
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
   

# Generated at 2022-06-18 10:02:33.764917
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import subprocess
    import shutil
    import time
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    from tornado.escape import utf8
    from tornado.httputil import HTTPHeaders
    from tornado.platform.auto import set_close_exec
    from tornado.util import b, bytes_type
    from tornado.test.util import unittest, skipOnTravis
    from tornado.test.httpclient_test import HTTPClientCommonTestCase, ExpectLog

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            return None


# Generated at 2022-06-18 10:02:35.252946
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-18 10:02:48.149548
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import json
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_asyncio_future, to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future, to_torn

# Generated at 2022-06-18 10:02:59.204218
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.util import b
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import time
    import os
    import sys
    import signal
    import logging
    import json
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-18 10:03:06.560831
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    client = SimpleAsyncHTTPClient()
    assert client.io_loop is not None
    assert client.defaults == HTTPRequest._DEFAULTS
    client.initialize(defaults=dict(user_agent="MyUserAgent"))
    assert client.defaults == dict(user_agent="MyUserAgent")
    assert isinstance(client.defaults, HTTPHeaders)
    client.close()


# Generated at 2022-06-18 10:03:12.768520
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    import time
    import unittest
    import os
    import sys
    import signal
    import subprocess
    import threading
    import socket
    import time
    import traceback
    import logging
    import json
    import random
    import string
    import base64
    import hashlib
    import hmac
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib

# Generated at 2022-06-18 10:03:24.937214
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future