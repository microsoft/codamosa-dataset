

# Generated at 2022-06-18 09:59:52.941346
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:00:05.013798
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import url_escape
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.escape
    import tornado.httputil
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.auto
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.process
    import tornado.locks
    import tornado.queues
    import tornado.gen
    import tornado.httputil
    import tornado.http1connection
    import tornado.iostream
   

# Generated at 2022-06-18 10:00:18.220309
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import unittest
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")
    class AsyncHTTPClientTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])
        @gen_test
        def test_singleton(self):
            self.assertIsInstance(self.http_client, SimpleAsyncHTTPClient)
            self.assertIs(self.http_client, AsyncHTTPClient())

# Generated at 2022-06-18 10:00:18.858948
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:00:31.934827
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import unittest
    import os
    import sys
    import subprocess
    import time
    import signal
    import shutil
    import tempfile
    import json
    import re
    import logging
    import threading
    import multiprocessing
    import functools
    import asyncio
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:00:43.564311
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import url_escape
    from tornado.options import define, options
    import tornado.testing
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.options
    import tornado.platform.auto
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.iostream
    import tornado.locks
    import tornado.log
    import tornado.stack_context
    import tornado.util
    import tornado.httputil
   

# Generated at 2022-06-18 10:00:44.096026
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:00:57.053898
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method': 'GET'}
    proxy = _RequestProxy(request, defaults)
    assert proxy.method == 'GET'
    assert proxy.url == 'http://www.baidu.com'
    assert proxy.proxy_host == None
    assert proxy.proxy_port == None
    assert proxy.proxy_username == None
    assert proxy.proxy_password == None
    assert proxy.proxy_auth_mode == None
    assert proxy.body == None
    assert proxy.body_producer == None
    assert proxy.auth_username == None
    assert proxy.auth_password == None
    assert proxy.auth_mode == None
    assert proxy.connect_timeout == None
    assert proxy.request_timeout == None
    assert proxy.follow_redirects

# Generated at 2022-06-18 10:01:04.482022
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"a": 1, "b": 2}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.a == 1
    assert request_proxy.b == 2
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.method == "GET"
    assert request_proxy.c == None


# Generated at 2022-06-18 10:01:08.708084
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPRequest
    from tornado.options import define, options, parse_command_line
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.stack_context
    import tornado.locks
    import tornado.process
    import tornado.util
    import tornado.httputil
    import tornado.escape
    import tornado.http

# Generated at 2022-06-18 10:01:36.172139
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import subprocess
    import os
    import sys
    import time
    import signal
    import logging
    import unittest
    import threading
    import socket
    import tempfile
    import shutil
    import re
    import io
    import functools
    import json
    import errno
    import select
    import platform
    import ssl
    import warnings
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures._

# Generated at 2022-06-18 10:01:40.867225
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import sys
    import os
    import time
    import logging
    import socket
    import threading
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread


# Generated at 2022-06-18 10:01:52.659388
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() works even if the client is
    # already closed.
    client = AsyncHTTPClient()
    client.close()
    client.close()
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    client.close()
    # Test that AsyncHTTPClient.close() removes the client from the
    # instance cache.
    client = AsyncHTTPClient()
    client.close()
    client2 = AsyncHTTPClient()
    assert client is not client2
    # Test that AsyncHTTPClient.close() removes the client from the
    # instance cache even if the client was created with
    # force_instance=True.
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    client2 = AsyncHTTPClient()

# Generated at 2022-06-18 10:02:05.105103
# Unit test for method fetch of class AsyncHTTPClient

# Generated at 2022-06-18 10:02:05.949644
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:02:17.951894
# Unit test for function main
def test_main():
    import sys
    import io
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.concurrent import Future
    from tornado.test.util import unittest

    class MainTest(AsyncTestCase):
        def setUp(self):
            super(MainTest, self).setUp()
            self.http_client = AsyncHTTPClient(self.io_loop)
            self.http_client.configure(None, defaults=dict(follow_redirects=False))
            self.http_server.stop()
            self.http

# Generated at 2022-06-18 10:02:30.750903
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.web import Application, RequestHandler
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import os
    import sys
    import threading
    import unittest

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)

# Generated at 2022-06-18 10:02:42.870565
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPClient, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOL

# Generated at 2022-06-18 10:02:55.153940
# Unit test for function main
def test_main():
    import sys
    import os
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import bind_unused_port
    from tornado.httpserver import HTTPServer
    from tornado.web import RequestHandler, Application
    from tornado.escape import native_str

    class MainTest(AsyncTestCase):
        def setUp(self):
            super(MainTest, self).setUp()
            self.http_server = HTTPServer(Application())
            self.sockets = bind_unused_port()
            self.port = self.sockets[0].getsockname()[1]

# Generated at 2022-06-18 10:03:05.733431
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import functools
    import time
    import sys
    import os
    import socket
    import threading
    import ssl
    import warnings
    import contextlib
    import logging
    import tempfile
    import shutil
    import errno
    import json
    import gzip
    import zlib
    import io
    import re
    import email.utils
    import email.message
    import email.policy
    import email.parser
    import email.generator
    import base64
    import hmac
    import hashlib
    import urllib.parse
    import urllib.request
   

# Generated at 2022-06-18 10:03:28.944002
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import logging
    import os
    import shutil
    import tempfile
    import unittest
    import urllib.parse
    import warnings
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AsyncIOMainLoop


# Generated at 2022-06-18 10:03:29.288864
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:03:37.583676
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.escape
    import tornado.platform.asyncio
    import asyncio
    import time
    import json
    import os
    import sys
    import logging
    import unittest
    import functools
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse

# Generated at 2022-06-18 10:03:48.701858
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import threading
    import time
    import unittest
    import urllib.parse
    import warnings
    import weakref
    import functools
    import socket
    import ssl
    import subprocess
    import tempfile
    import shutil
    import contextlib
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread

# Generated at 2022-06-18 10:03:58.706452
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() closes the underlying client
    # and removes it from the cache.
    client = AsyncHTTPClient()
    client.close()
    assert client._closed
    assert IOLoop.current() not in AsyncHTTPClient._async_clients()

    # Test that the client is removed from the cache when it is closed.
    client = AsyncHTTPClient()
    assert IOLoop.current() in AsyncHTTPClient._async_clients()
    client.close()
    assert IOLoop.current() not in AsyncHTTPClient._async_clients()

    # Test that the client is removed from the cache when it is garbage
    # collected.
    client = AsyncHTTPClient()
    assert IOLoop.current() in AsyncHTTPClient._async_clients()
    del client


# Generated at 2022-06-18 10:04:07.624677
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import urllib.parse
    import warnings
    import functools
    import logging
    import time
    import socket
    import ssl
    import threading
    import concurrent.futures
    import subprocess
    import shutil
    import tempfile
    import contextlib
    import io
    import re
    import json
    import base64
    import email.utils
    import mimetypes
    import gzip
    import zlib
    import hmac
    import hashlib
    import platform
    import email.utils
    import mim

# Generated at 2022-06-18 10:04:11.685171
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.headers == {}
    assert request_proxy.body == b""
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect

# Generated at 2022-06-18 10:04:23.816489
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.httpserver import HTTPServer
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.netutil import bind_sockets
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import AsyncIOMainLoop

# Generated at 2022-06-18 10:04:33.464991
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import unittest
    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")
    class TestAsyncHTTPClient(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])
        @gen_test
        def test_fetch_impl(self):
            client = SimpleAsyncHTTPClient(self.io_loop)

# Generated at 2022-06-18 10:04:34.520051
# Unit test for function main
def test_main():
    pass

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:04:49.725665
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # AsyncHTTPClient.__new__ -> AsyncHTTPClient.__new__
    # AsyncHTTPClient.__new__ -> Configurable.__new__
    # Configurable.__new__ -> object.__new__
    pass


# Generated at 2022-06-18 10:04:59.769043
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import logging
    import sys
    import time
    import os
    import threading
    import functools
    import json
    import random
    import string
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.request


# Generated at 2022-06-18 10:05:08.552311
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:05:15.493446
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # __new__ is a class method
    AsyncHTTPClient.__new__(AsyncHTTPClient)
    # __new__ of class AsyncHTTPClient with args
    AsyncHTTPClient.__new__(AsyncHTTPClient, force_instance=True)
    # __new__ of class AsyncHTTPClient with args
    AsyncHTTPClient.__new__(AsyncHTTPClient, force_instance=True, **{})
    # __new__ of class AsyncHTTPClient with args
    AsyncHTTPClient.__new__(AsyncHTTPClient, **{})

# Generated at 2022-06-18 10:05:26.070949
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.headers == {}
    assert request_proxy.body == b""
    assert request_proxy.proxy_host is None
    assert request_proxy.proxy_port is None
    assert request_proxy.proxy_username is None
    assert request_proxy.proxy_password is None
    assert request_proxy.proxy_auth_mode is None
    assert request_proxy.auth_username is None
    assert request_proxy.auth_password is None
    assert request_proxy.auth_mode is None
    assert request_proxy.connect

# Generated at 2022-06-18 10:05:27.932967
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)

# Generated at 2022-06-18 10:05:38.998798
# Unit test for method initialize of class AsyncHTTPClient

# Generated at 2022-06-18 10:05:49.260847
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import unittest

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class TestAsyncHTTPClient(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])

        @gen_test
        def test_close(self):
            client = AsyncHTTPClient(self.io_loop)
            yield client.fetch(self.get_url("/"))
            client.close()
            self.assertTrue(client._closed)

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-18 10:05:54.997096
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    client = SimpleAsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False
    client.close()
    assert client._closed == True


# Generated at 2022-06-18 10:05:59.025624
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    client = SimpleAsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False


# Generated at 2022-06-18 10:06:38.909261
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    import tornado.options
    import tornado.httpclient
    import os
    import sys
    import subprocess
    import unittest
    import time
    import threading
    import socket
    import ssl
    import tempfile
    import shutil
    import functools
    import contextlib
    import logging
    import warnings
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures._base

# Generated at 2022-06-18 10:06:41.447249
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test for method fetch_impl( ... ) of class AsyncHTTPClient
    # This method is abstract and will be tested by the implementation
    # classes.
    pass


# Generated at 2022-06-18 10:06:42.030249
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:06:53.265300
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:07:04.293465
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:07:11.576335
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import logging
    import socket
    import ssl
    import time
    import unittest
    import urllib.parse
    import weakref
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.log import gen_log
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.test.util import unittest, skipOnTravis, skipIfNoIPv6
    from tornado.testing import AsyncHTTPTestCase, ExpectLog

# Generated at 2022-06-18 10:07:12.481923
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-18 10:07:23.865935
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.asyncio
    import tornado.platform.select
    import tornado.platform.caresres

# Generated at 2022-06-18 10:07:33.520375
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://www.baidu.com"
    method = "GET"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36"}
    body = "hello world"
    auth_username = "admin"
    auth_password = "123456"
    auth_mode = "basic"
    connect_timeout = 20.0
    request_timeout = 20.0
    if_modified_since = datetime.datetime.now()
    follow_redirects = True
    max_redirects = 5

# Generated at 2022-06-18 10:07:43.126639
# Unit test for method initialize of class AsyncHTTPClient

# Generated at 2022-06-18 10:08:23.164149
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop
    import tornado.httpserver
    import tornado.httputil
    import tornado.http1connection
    import tornado.iostream
    import tornado.escape
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.posix
    import tornado.platform.auto
    import tornado.platform.windows_utils
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue

# Generated at 2022-06-18 10:08:25.644391
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:08:37.288099
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() works.
    # The test is a bit racy, but it's the best we can do without
    # adding a synchronous close() method.
    client = AsyncHTTPClient()
    client.close()
    client.close()
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    client.close()
    client = AsyncHTTPClient()
    client.close()
    client.close()
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    client.close()
    # Test that AsyncHTTPClient.close() removes the instance from the
    # cache.
    client = AsyncHTTPClient()
    client.close()
    client = AsyncHTTPClient()
    assert client is not None
    client.close()

# Generated at 2022-06-18 10:08:39.230021
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() works even if the client has
    # never been used.
    AsyncHTTPClient().close()


# Generated at 2022-06-18 10:08:50.061921
# Unit test for function main
def test_main():
    import sys
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPClient, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.escape import native_str
    from tornado.util import b
    from tornado.testing import bind_unused_port
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.concurrent import Future
    import asyncio
    import functools
    import socket
    import unittest
    import warnings


# Generated at 2022-06-18 10:08:58.461556
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import urllib.parse
    import functools
    import time
    import sys
    import os
    import socket
    import logging
    import threading
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread

# Generated at 2022-06-18 10:09:10.362393
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.httputil
    import tornado.escape
    import tornado.gen
    import tornado.locks
    import tornado.log
    import tornado.stack_context
    import tornado.testing
    import tornado.util
    import tornado.process
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpserver
    import tornado.simple_

# Generated at 2022-06-18 10:09:19.221738
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import sys
    import io
    import os
    import unittest
    import tempfile
    import shutil
    import subprocess
    import contextlib

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_

# Generated at 2022-06-18 10:09:22.197716
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method':'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.connect_timeout == 20


# Generated at 2022-06-18 10:09:23.181134
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    assert client._closed == True
