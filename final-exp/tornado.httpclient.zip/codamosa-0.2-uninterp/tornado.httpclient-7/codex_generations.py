

# Generated at 2022-06-18 09:59:39.782445
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method is called
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.kwargs = kwargs
    client = TestAsyncHTTPClient(foo=1, bar=2)
    assert client.kwargs == dict(foo=1, bar=2)

# Generated at 2022-06-18 09:59:48.682010
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.httpclient
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.escape
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.gen
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.testing
    import tornado.test.httpclient_test
    import tornado.test.util
    import tornado.util
    import tornado.web

# Generated at 2022-06-18 09:59:58.961033
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:00:06.653418
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when an instance is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.kwargs = kwargs
    client = MyAsyncHTTPClient(foo=1, bar=2)
    assert client.kwargs == dict(foo=1, bar=2)


# Generated at 2022-06-18 10:00:12.056724
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import tornado.process
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.httpclient
    import tornado.httputil
    import tornado.iostream
    import tornado.locks
    import tornado.netutil
    import tornado.platform.auto
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix

# Generated at 2022-06-18 10:00:24.028987
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options
    from tornado.httpclient import HTTPRequest
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.httputil
    import tornado.escape
    import tornado.gen
    import tornado.locks
    import tornado.log
    import tornado.stack_context
    import tornado.template
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.net

# Generated at 2022-06-18 10:00:37.187592
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:00:46.650702
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPClient, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.util import b

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])

        @gen_test
        def test_main(self):
            define("print_headers", type=bool, default=False)

# Generated at 2022-06-18 10:00:51.789327
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # when an instance is created.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs: Any) -> None:
            self.initialized = True

    client = MyAsyncHTTPClient()
    assert client.initialized



# Generated at 2022-06-18 10:00:57.894336
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import functools
    import os
    import signal
    import subprocess
    import tempfile
    import threading
    import time
    import unittest
    import warnings
    import weakref
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:01:08.690887
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass


# Generated at 2022-06-18 10:01:12.073318
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://www.baidu.com")
    response = HTTPResponse(request, 200)
    print(response)


# Generated at 2022-06-18 10:01:12.885551
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 10:01:20.993529
# Unit test for function main
def test_main():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.platform.asyncio
    import tornado.platform.auto
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows_events
    import tornado.platform.windows_utils
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.posix
    import tornado.platform.windows_events

# Generated at 2022-06-18 10:01:33.021223
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:01:44.994572
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest
    import tornado.testing
    import tornado.options
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.curl_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.escape
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform

# Generated at 2022-06-18 10:01:56.107723
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import os
    import sys
    import unittest
    import urllib.parse
    import warnings

    class MainTest(AsyncTestCase):
        def setUp(self):
            super(MainTest, self).setUp()
            self.loop = AsyncIOMainLoop()
            self.loop.make_current()
            self.http_client = AsyncHTTPClient(self.io_loop)
            self.http_server = HTTPServer()
            self.http_server.listen(8888)
            self.http_server.add_sockets

# Generated at 2022-06-18 10:01:56.727850
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:10.348511
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:02:20.204585
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import unittest

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    class AsyncHTTPClientTest(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application([("/", MainHandler)])

        @tornado.testing.gen_test
        def test_fetch(self):
            response = yield self.http_client.fetch(self.get_url("/"))
            self.assertEqual(response.body, b"Hello, world")


# Generated at 2022-06-18 10:02:33.970217
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False


# Generated at 2022-06-18 10:02:46.997817
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import urllib.parse
    import unittest
    import socket
    import ssl
    import logging
    import time
    import threading
    import os
    import sys
    import io
    import json
    import random
    import re
    import subprocess
    import shutil
    import tempfile
    import contextlib
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
   

# Generated at 2022-06-18 10:02:58.365318
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPError

# Generated at 2022-06-18 10:03:08.416928
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url='http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_mode == None
    assert request_proxy.connect_timeout == None
    assert request_proxy.request_timeout == None


# Generated at 2022-06-18 10:03:10.688807
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url='http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.foo == None


# Generated at 2022-06-18 10:03:12.522376
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    assert client._closed == True


# Generated at 2022-06-18 10:03:24.714390
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import functools
    import logging
    import socket
    import ssl
    import unittest
    import urllib.parse
    import weakref
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import IOStream
    from tornado.log import gen_log
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncHTTPTestCase, ExpectLog, bind_unused_port, gen_test

# Generated at 2022-06-18 10:03:34.337409
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.ioloop import IOLoop
    import tornado.testing
    import unittest
    import time
    import os
    import sys
    import socket
    import threading
    import functools
    import logging
    import signal
    import subprocess
    import errno
    import platform
    import tempfile
    import shutil
    import re
    import json
    import warnings
    import types
    import base64
    import ssl
    import selectors
    import concurrent.futures
    import traceback
    import contextlib
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.f

# Generated at 2022-06-18 10:03:43.957780
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options
    from tornado.httpclient import HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import is_future
    from tornado.platform.asyncio import to_asyncio_stream
    from tornado.platform.asyncio import to_tornado_callback
    from tornado.platform.asyncio import to_tornado_future

# Generated at 2022-06-18 10:03:48.700737
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"


# Generated at 2022-06-18 10:04:09.613414
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.web import Application, RequestHandler
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import threading
    import time
    import unittest

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()

# Generated at 2022-06-18 10:04:17.786182
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:04:19.671988
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    assert client._closed == True


# Generated at 2022-06-18 10:04:30.763144
# Unit test for function main
def test_main():
    import sys
    import io
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.platform
    import tornado.gen
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream

# Generated at 2022-06-18 10:04:38.079978
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:04:39.654968
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    return


# Generated at 2022-06-18 10:04:51.034141
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()

# Generated at 2022-06-18 10:05:00.842423
# Unit test for function main
def test_main():
    import sys
    import io
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPClient, HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.netutil import bind_sockets
    from tornado.util import b
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado import gen
    from tornado.concurrent import Future
    from tornado.testing import Async

# Generated at 2022-06-18 10:05:09.492762
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import utf8
    from tornado.concurrent import Future
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import sys
    import os
    import io
    import tempfile
    import shutil
    import functools
    import contextlib
    import socket
    import ssl
    import warnings
    import logging
    import time
    import re
    import base64
    import hashlib
    import hmac
    import email.utils
    import urllib.parse
    import urllib.request
    import urllib.error
   

# Generated at 2022-06-18 10:05:20.393900
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    import os
    import sys
    import threading
    import time
    import unittest
    import urllib.parse
    import urllib.request
    import warnings
    import socket
    import ssl
    import subprocess
    import tempfile
    import shutil
    import functools
    import contextlib
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
   