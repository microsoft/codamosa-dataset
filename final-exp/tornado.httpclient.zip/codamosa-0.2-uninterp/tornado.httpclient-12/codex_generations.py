

# Generated at 2022-06-18 09:59:43.552858
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 09:59:49.025731
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url='http://www.baidu.com')
    response = HTTPResponse(request, 200, None, None, None, None, None, None, None, None)
    response.rethrow()
    response.error = HTTPError(500, message='Internal Server Error', response=response)
    try:
        response.rethrow()
    except HTTPError as e:
        assert e.code == 500
        assert e.message == 'Internal Server Error'
        assert e.response == response


# Generated at 2022-06-18 09:59:49.947397
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-18 09:59:58.148442
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="http://www.google.com")
    response = HTTPResponse(request=request, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()
    response.error = HTTPError(code=404, message="Not Found", response=response)
    try:
        response.rethrow()
    except HTTPError as e:
        assert e.code == 404
        assert e.message == "Not Found"
        assert e.response == response


# Generated at 2022-06-18 10:00:06.480767
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() works even if the IOLoop has already
    # been closed.
    # This is a regression test for #1201
    client = AsyncHTTPClient()
    client.close()
    client.close()
    # Also test that it works with force_instance=True
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    client.close()


# Generated at 2022-06-18 10:00:18.894513
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import time
    import unittest
    import logging
    import sys
    import os
    from tornado.log import access_log, app_log, gen_log
    import io
    import contextlib
    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io

# Generated at 2022-06-18 10:00:23.412069
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert not client._closed
    client.close()
    assert client._closed


# Generated at 2022-06-18 10:00:32.564593
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # test for rethrow
    request = HTTPRequest('http://www.google.com')
    response = HTTPResponse(request, 200, reason='OK')
    response.rethrow()
    response = HTTPResponse(request, 404, reason='Not Found')
    try:
        response.rethrow()
    except HTTPError as e:
        assert e.code == 404
        assert e.response == response
        assert e.message == 'Not Found'
    else:
        assert False, 'should not be here'


# Generated at 2022-06-18 10:00:44.093747
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Test for HTTPResponse.rethrow()
    # Create a request object
    request = HTTPRequest("http://www.google.com")
    # Create a response object
    response = HTTPResponse(request, 200, reason="OK")
    # Check if the response object is created
    assert response is not None
    # Check if the response object is of type HTTPResponse
    assert isinstance(response, HTTPResponse)
    # Check if the response object has an error
    assert response.error is None
    # Check if the response object has a request
    assert response.request is not None
    # Check if the response object has a code
    assert response.code == 200
    # Check if the response object has a reason
    assert response.reason == "OK"
    # Check if the response object has a header
   

# Generated at 2022-06-18 10:00:57.053362
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Test for HTTPResponse.rethrow()
    # Create a HTTPResponse object
    request = HTTPRequest('http://www.google.com')
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = 'http://www.google.com'
    error = None
    request_time = 0.1
    time_info = {}
    reason = 'OK'
    start_time = time.time()
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    # Test for HTTPResponse.rethrow()
    try:
        response.rethrow()
    except HTTPError as e:
        print(e)

# Unit test

# Generated at 2022-06-18 10:01:14.916300
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import logging
    import sys
    import time
    import os
    import json
    import requests
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse

# Generated at 2022-06-18 10:01:22.961687
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.escape
    import tornado.platform.asyncio
    import asyncio
    import time
    import datetime
    import json
    import os
    import sys
    import logging
    import logging.handlers
    import argparse
    import socket
    import ssl
    import urllib.parse
    import functools
    import concurrent.futures
    import traceback
    import subprocess
    import signal
    import base64
    import re
    import hashlib
    import hmac
    import random
    import string
    import uuid
    import pprint
    import inspect
    import copy
    import math
    import collections
    import queue
    import threading
   

# Generated at 2022-06-18 10:01:35.515368
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import unittest

    class HelloHandler(tornado.web.RequestHandler):
        def get(self):
            self.write('Hello, world')

    class HelloAsyncHandler(tornado.web.RequestHandler):
        @tornado.gen.coroutine
        def get(self):
            yield tornado.gen.sleep(0.1)
            self.write('Hello, world')

    class HelloStreamHandler(tornado.web.RequestHandler):
        @tornado.gen.coroutine
        def get(self):
            yield tornado.gen.sleep(0.1)
            self.write('Hello')
            yield tornado.gen.sleep

# Generated at 2022-06-18 10:01:44.281044
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # Test case 1
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-18 10:01:55.531578
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import unittest
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio
    import time
    import functools
    import sys
    import os
    import signal
    import threading
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures

# Generated at 2022-06-18 10:02:08.905713
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.util import Configurable
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.escape import utf8
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPError
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse


# Generated at 2022-06-18 10:02:19.373122
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPRequest
    from tornado.options import options
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.asyncio
    import tornado.platform.caresresolver
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado

# Generated at 2022-06-18 10:02:32.293657
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.ioloop import IOLoop
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import unittest
    import tornado.platform.asyncio
    import asyncio
    import time
    import logging
    import os
    import sys
    import threading
    import concurrent.futures
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:02:43.736622
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import unittest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test

    class MyAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(self, request, callback):
            callback(HTTPResponse(request, 200, buffer=BytesIO(b"OK")))

    class MyAsyncHTTPTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return None

        @gen_test
        def test_fetch(self):
            client = MyAsyncHTTPClient(self.io_loop)
            response = yield client.fetch("http://example.com")
            self.assertEqual(response.body, b"OK")

    unittest.main()

# Generated at 2022-06-18 10:02:53.579371
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.httpclient
    http_client = tornado.httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except tornado.httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:03:35.449141
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:03:39.366936
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:03:51.401865
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import unittest
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser

# Generated at 2022-06-18 10:03:53.187191
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test the method initialize of class AsyncHTTPClient
    # This test case is not implemented yet
    pass


# Generated at 2022-06-18 10:03:53.820779
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:03:57.892270
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.body == None
    assert request_proxy.headers == None
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == None
    assert request_proxy.connect_timeout == None
    assert request_proxy.request_timeout == None
    assert request_proxy.follow_redirects == None
    assert request_

# Generated at 2022-06-18 10:03:58.348901
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-18 10:04:06.992814
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.util import unittest

    class MyAsyncHTTPClient(AsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient(SimpleAsyncHTTPClient):
        pass

    class MyAsyncHTTPClient2(AsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient2(SimpleAsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient3(SimpleAsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient4(SimpleAsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient5(SimpleAsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient6(SimpleAsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient7(SimpleAsyncHTTPClient):
        pass

    class MySimpleAsyncHTTPClient8(SimpleAsyncHTTPClient):
        pass

# Generated at 2022-06-18 10:04:18.591120
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import unittest
    import urllib.parse
    import urllib.request
    import urllib.error
    import socket
    import ssl
    import tempfile
    import shutil
    import functools
    import threading
    import concurrent.futures
    import warnings
    import logging
    import http.server
    import socketserver
    import http.client
    import io
    import gzip
    import zlib
    import base64
    import hmac
    import hashlib
    import binascii
    import email.utils

# Generated at 2022-06-18 10:04:29.862278
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.escape
    import tornado.platform.asyncio
    import asyncio
    import functools
    import time
    import unittest
    import json
    import os
    import sys
    import io
    import socket
    import logging
    import signal
    import threading
    import random
    import subprocess
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures


# Generated at 2022-06-18 10:06:07.298998
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestAsyncHTTPClient(AsyncTestCase):
        def test_AsyncHTTPClient___new__(self):
            from tornado.httpclient import AsyncHTTPClient

            # Test that AsyncHTTPClient is a singleton.
            self.assertIs(AsyncHTTPClient(), AsyncHTTPClient())

            # Test that a new instance can be created with force_instance.
            self.assertIsNot(AsyncHTTPClient(force_instance=True), AsyncHTTPClient())

            # Test that the singleton is tied to the current IOLoop.
            old_loop = IOLoop.current()

# Generated at 2022-06-18 10:06:14.570337
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler
    from tornado.web import Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import unittest
    import subprocess
    import time
    import signal
    import socket
    import threading
    import tempfile
    import shutil
    import functools
    import logging
    import ssl
    import json
    import urllib
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.robotparser
    import urllib.request


# Generated at 2022-06-18 10:06:25.966399
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import json
    import unittest
    import os
    import sys
    import time
    import traceback
    import types
    import warnings
    import re
    import socket
    import ssl
    import threading
    import logging
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.thread

# Generated at 2022-06-18 10:06:36.309733
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import functools
    import socket
    import logging
    import sys
    import time
    import os
    import platform
    import signal
    import subprocess
    import threading
    import concurrent.futures
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process

# Generated at 2022-06-18 10:06:40.882860
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that AsyncHTTPClient.initialize() is called
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.initialized = True
    client = MyAsyncHTTPClient()
    assert client.initialized


# Generated at 2022-06-18 10:06:52.230415
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port
    from tornado.web import RequestHandler, Application
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.caresresolver
    import tornado.platform.auto
    import tornado.platform.posix


# Generated at 2022-06-18 10:06:58.620635
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPMessageDelegate
    from tornado.httpclient import HTTPResponseParser
    from tornado.httpclient import HTTPHeaders
    from tornado.httpclient import HTTPMessage
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPMessageDelegate
    from tornado.httpclient import HTTPResponseParser

# Generated at 2022-06-18 10:07:00.408044
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of the AsyncHTTPClient class is called
    # when an instance of the class is created.
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, defaults=None):
            self.initialized = True
    client = TestAsyncHTTPClient()
    assert client.initialized


# Generated at 2022-06-18 10:07:09.486037
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPConnectionPool
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPMessageDelegate
    from tornado.httpclient import HTTPResponseStartLine
    from tornado.httpclient import HTTPResponseParser
    from tornado.httpclient import HTTPHeaders
    from tornado.httpclient import HTTPRequestParser
    from tornado.httpclient import HTTPRequestStartLine
    from tornado.httpclient import HTTPMessageParser
    from tornado.httpclient import HTTPMessage
    from tornado.httpclient import HTTPConnectionDelegate
    from tornado.httpclient import HTTPConnection

# Generated at 2022-06-18 10:07:19.919729
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPClient, HTTPRequest
    from tornado.options import define, options, parse_command_line
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.httputil
    import tornado.netutil
    import tornado.platform.auto
    import tornado.simple_httpclient
    import tornado.stack_context
    import tornado.util
    import tornado.iostream
    import tornado.locks
    import tornado.gen
    import tornado.escape
    import tornado.httputil
    import tornado.http1connection
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_

# Generated at 2022-06-18 10:09:06.558922
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:09:11.445346
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'method': 'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'
    assert request_proxy.url == 'http://www.baidu.com'


# Generated at 2022-06-18 10:09:19.915712
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import unittest
    import urllib.parse
    import functools
    import os
    import sys
    import time
    import socket
    import errno
    import logging
    import re
    import ssl
    import platform
    import subprocess
    import threading
    import concurrent.futures
    import concurrent.futures._base
    import concurrent.futures.thread
    import concurrent.futures.process
    import concurrent.futures.process
    import concurrent.futures.thread
    import concurrent.futures._base
    import concurrent.futures.process
    import concurrent.f

# Generated at 2022-06-18 10:09:21.108961
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    return


# Generated at 2022-06-18 10:09:26.229149
# Unit test for method __new__ of class AsyncHTTPClient

# Generated at 2022-06-18 10:09:30.648261
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.win32
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.win32
    import tornado.platform.asyncio