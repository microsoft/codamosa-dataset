

# Generated at 2022-06-18 09:59:47.379048
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 09:59:53.563616
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-18 10:00:06.307125
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Test for HTTPResponse.rethrow
    # Create a HTTPResponse object
    request = HTTPRequest("http://www.google.com")
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "http://www.google.com"
    error = HTTPError(code, message="HTTP Error", response=None)
    request_time = 0.1
    time_info = {}
    reason = "OK"
    start_time = time.time()
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    # Test for rethrow
    try:
        response.rethrow()
    except HTTPError as e:
        assert e.code

# Generated at 2022-06-18 10:00:10.304213
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('http://www.google.com')
    response = HTTPResponse(request, 200, {}, None, None, None, None, None, None, None)
    response.rethrow()


# Generated at 2022-06-18 10:00:19.353978
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() works.
    # This is a little tricky because the client is a singleton,
    # so we have to make sure we're not closing the one that the
    # rest of the tests are using.
    io_loop = IOLoop()
    io_loop.make_current()
    client = AsyncHTTPClient(force_instance=True)
    client.close()
    assert client._closed
    assert io_loop not in AsyncHTTPClient._async_clients()
    io_loop.close()


# Generated at 2022-06-18 10:00:26.019443
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url="http://www.baidu.com")
    defaults = {"method": "GET"}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.baidu.com"
    assert request_proxy.proxy_host == None


# Generated at 2022-06-18 10:00:30.049380
# Unit test for method rethrow of class HTTPResponse

# Generated at 2022-06-18 10:00:38.942422
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that AsyncHTTPClient.initialize() is called
    # when an AsyncHTTPClient is created.
    # This is a regression test for a bug in which
    # AsyncHTTPClient.initialize() was not called
    # when an AsyncHTTPClient was created with force_instance=True.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            self.initialized = True
    client = MyAsyncHTTPClient(force_instance=True)
    assert client.initialized


# Generated at 2022-06-18 10:00:43.277171
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.options import define, options, parse_command_line
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.httputil
    import tornado.options
    import tornado.ioloop
    import tornado.gen
    import tornado.concurrent
    import tornado.locks
    import tornado.queues
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.stack_context
    import tornado.escape
    import tornado.httputil


# Generated at 2022-06-18 10:00:49.079680
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest, HTTPClient
    import tornado.testing
    import tornado.web
    import tornado.options
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.options
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.options
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.options
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.options
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.options


# Generated at 2022-06-18 10:00:56.654257
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:00:59.741153
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="http://www.google.com")
    response = HTTPResponse(request, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()
    print("test_HTTPResponse_rethrow passed")


# Generated at 2022-06-18 10:01:12.449274
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url='http://www.google.com')
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = 'http://www.google.com'
    error = None
    request_time = 1.0
    time_info = {}
    reason = 'OK'
    start_time = time.time()
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    response.rethrow()
    assert response.error == None
    assert response.code == 200
    assert response.reason == 'OK'
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer == BytesIO()
    assert response.body == b

# Generated at 2022-06-18 10:01:22.681736
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() frees resources.
    # We can't test this with a mock because the implementation
    # uses weak references.
    #
    # This test is a bit racy because it depends on the garbage
    # collector running at the right time, but it's better than
    # nothing.
    import gc
    import logging
    import weakref
    import time
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.util import unittest


# Generated at 2022-06-18 10:01:35.252202
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url='http://www.baidu.com')
    defaults = {'connect_timeout': 10}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.connect_timeout == 10
    assert request_proxy.url == 'http://www.baidu.com'
    assert request_proxy.method == 'GET'
    assert request_proxy.max_redirects == 5
    assert request_proxy.proxy_host == None
    assert request_proxy.proxy_port == None
    assert request_proxy.proxy_username == None
    assert request_proxy.proxy_password == None
    assert request_proxy.proxy_auth_mode == 'basic'
    assert request_proxy.auth_username == None
    assert request_proxy.auth_password == None
    assert request_proxy.auth_

# Generated at 2022-06-18 10:01:46.809383
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    from tornado.web import Application, RequestHandler
    from tornado.options import define, options, parse_command_line
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.iostream
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.locks
    import tornado.queues
    import tornado.gen
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.http1connection
    import tornado.http2connection
    import tornado.httputil
    import tornado

# Generated at 2022-06-18 10:01:52.478033
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url='http://www.baidu.com')
    response = HTTPResponse(request=request, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()


# Generated at 2022-06-18 10:02:04.830052
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class TestAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(self, request, callback):
            pass

    class TestAsyncHTTPClientTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])

        @gen_test
        def test_fetch_impl(self):
            client = TestAsyncHTTPClient()
            response = yield client.fetch(self.get_url("/"))
            self.assertEqual(response.body, b"Hello, world")

   

# Generated at 2022-06-18 10:02:17.192059
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.escape
    import tornado.platform.asyncio
    import asyncio
    import time
    import threading
    import concurrent.futures
    import logging
    import sys
    import os
    import json
    import random
    import string
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.robotparser
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.robotparser
    import urllib.parse
    import urll

# Generated at 2022-06-18 10:02:29.754563
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test

    class TestAsyncHTTPClient(AsyncHTTPTestCase):
        def get_app(self):
            return None

        @gen_test
        def test_close(self):
            client = AsyncHTTPClient()
            client.close()
            with pytest.raises(RuntimeError):
                yield client.fetch("http://www.google.com")
            client = AsyncHTTPClient(force_instance=True)
            client.close()
            with pytest.raises(RuntimeError):
                yield client.fetch("http://www.google.com")
            client = AsyncHTTPClient()
            client.close()

# Generated at 2022-06-18 10:02:59.970885
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:03:05.495894
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import asyncio
    import logging
    import sys
    import os
    import json
    import time
    import datetime
    import random
    import string
    import functools
    import tornado.escape
    import tornado.ioloop
    import tornado.options
    import tornado.platform.asyncio
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.netutil
    import tornado.process
    import tornado.locks
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.iostream
    import tornado.log
    import tornado.netutil


# Generated at 2022-06-18 10:03:06.096821
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:03:06.700940
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:03:07.583499
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-18 10:03:18.913034
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import unittest

    class TestAsyncHTTPClient(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application([("/", MainHandler)])

        def test_singleton(self):
            self.assertTrue(isinstance(self.http_client, SimpleAsyncHTTPClient))
            self.assertTrue(self.http_client is self.io_loop.asyncio_loop.run_sync(self.http_client.__class__))

# Generated at 2022-06-18 10:03:29.857359
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.ioloop
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httputil
    import tornado.httpclient
    import tornado.escape
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado

# Generated at 2022-06-18 10:03:30.201911
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:03:38.126402
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.ioloop
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import time
    import threading
    import logging
    import sys
    import os
    import signal
    import functools
    import json
    import random
    import string
    import socket
    import time
    import traceback
    import base64
    import hashlib
    import hmac
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse
    import urllib.parse


# Generated at 2022-06-18 10:03:39.384478
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # AsyncHTTPClient.__new__()
    pass


# Generated at 2022-06-18 10:05:52.998541
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPHeaders
    from tornado.httpclient import HTTPMessageDelegate
    from tornado.httpclient import HTTPResponseParser
    from tornado.httpclient import HTTPResponseStartLine
    from tornado.httpclient import HTTPResponseStartLineParser
    from tornado.httpclient import HTTPRequestParser
    from tornado.httpclient import HTTPRequestStartLine
    from tornado.httpclient import HTTPRequestStartLineParser
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnectionDelegate
    from tornado.httpclient import HTTPConnectionParser

# Generated at 2022-06-18 10:05:55.594632
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test for method fetch_impl(self, request, callback)
    # of class AsyncHTTPClient
    pass



# Generated at 2022-06-18 10:06:04.844578
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()

# Generated at 2022-06-18 10:06:08.700213
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    client = SimpleAsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False


# Generated at 2022-06-18 10:06:15.858506
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.concurrent
    import tornado.locks
    import tornado.queues
    import tornado.stack_context
    import tornado.gen
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.simple_http

# Generated at 2022-06-18 10:06:27.268755
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse

# Generated at 2022-06-18 10:06:38.085851
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    from tornado.testing import bind_unused_port
    import os
    import sys
    import time
    import unittest
    import urllib.parse
    import threading
    import subprocess
    import signal
    import socket
    import logging
    import functools
    import multiprocessing
    import concurrent.futures
    import tornado.platform.asyncio
    import asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    import tornado.platform.asyncio

# Generated at 2022-06-18 10:06:49.945445
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.options import define, options, parse_command_line
    import tornado.testing
    import unittest
    import os
    import sys
    import io
    import subprocess
    import time
    import signal
    import threading
    import multiprocessing
    import socket
    import logging
    import functools
    import contextlib
    import warnings
    import traceback
    import types
    import gc
    import re
    import platform
    import errno
    import tempfile
    import shutil
    import base64
    import hashlib
    import hmac
    import email.utils
    import urllib.parse
    import s

# Generated at 2022-06-18 10:06:57.259907
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.httputil
    import tornado.escape
    import tornado.gen
    import tornado.locks
    import tornado.stack_context
    import tornado.template
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.tcpserver
    import tornado.testing
    import tornado.util
    import tornado.web
    import tornado.websocket

# Generated at 2022-06-18 10:07:07.842722
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import tornado.ioloop
    import tornado.httpserver
    import tornado.httputil
    import tornado.http1connection
    import tornado.iostream
    import tornado.escape
    import tornado.gen
    import tornado.locks
    import tornado.simple_httpclient
    import tornado.tcpserver
    import tornado.tcpclient
    import tornado.netutil
    import tornado.stack_context
    import tornado.util
    import tornado.process
    import tornado.queues
    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.tcpclient
    import tornado.tcpserver