

# Generated at 2022-06-18 10:00:12.585875
# Unit test for function main
def test_main():
    import sys
    import unittest
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.options import define, options, parse_command_line
    from tornado.util import b
    from tornado.test.util import unittest

    class HelloHandler(RequestHandler):
        def get(self):
            self.write(b("hello"))

    class HelloRedirectHandler(RequestHandler):
        def get(self):
            self.redirect("/hello")

    class HelloRedirectChainHandler(RequestHandler):
        def get(self):
            self.redirect("/hello_redirect")


# Generated at 2022-06-18 10:00:13.819488
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-18 10:00:25.917269
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.options import define, options
    import os
    import sys
    import unittest

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])

# Generated at 2022-06-18 10:00:38.942497
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    import tornado.httputil
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.wsgi
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue
    import tornado.platform.auto
    import tornado.platform.posix
    import tornado.platform.windows
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.caresresolver
    import tornado.platform.select
    import tornado.platform.epoll
    import tornado.platform.kqueue

# Generated at 2022-06-18 10:00:44.911310
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest("http://www.google.com")
    response = HTTPResponse(request, 200, reason="OK")
    response.rethrow()
    response = HTTPResponse(request, 404, reason="Not Found")
    try:
        response.rethrow()
    except HTTPError as e:
        assert e.code == 404
        assert e.response == response
    else:
        assert False, "Expected HTTPError"


# Generated at 2022-06-18 10:00:46.397397
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:00:54.166770
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-18 10:01:03.642534
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://www.google.com")
    response = HTTPResponse(request, 200)
    assert response.request == request
    assert response.code == 200
    assert response.reason == "OK"
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer is None
    assert response.effective_url == "http://www.google.com"
    assert response.error is None
    assert response.request_time is None
    assert response.time_info == {}
    assert response.start_time is None
    assert response.body == b""


# Generated at 2022-06-18 10:01:09.473686
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('http://www.google.com')
    response = HTTPResponse(request, 200)
    response.rethrow()
    response.error = HTTPError(404)
    try:
        response.rethrow()
    except HTTPError:
        pass
    else:
        assert False


# Generated at 2022-06-18 10:01:20.031011
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.escape import url_escape
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.escape import url_escape
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.escape import url_escape
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders

# Generated at 2022-06-18 10:01:48.208338
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPMessageDelegate
    from tornado.httpclient import HTTPResponseParser
    from tornado.httpclient import HTTPResponseStartLine
    from tornado.httpclient import HTTPHeaders
    from tornado.httpclient import HTTPConnectionParameters
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPRequestParameters
    from tornado.httpclient import HTTPRequestStartLine
    from tornado.httpclient import HTTPRequestHeaders

# Generated at 2022-06-18 10:01:49.376844
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:01:52.248243
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method must be implemented by subclasses.
    # It should call callback with an HTTPResponse object.
    return


# Generated at 2022-06-18 10:02:04.460351
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import time
    import unittest
    import urllib.parse
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import HTTPRequest
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.process import fork_processes
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.util import unittest, skipOnTravis
    from tornado.web import RequestHandler, Application
    from tornado.websocket import WebSocketHandler
    from tornado.escape import utf8
    from tornado.util import b, bytes_type
    from tornado import gen
    from tornado.platform.asyncio import AsyncIOMainLoop


# Generated at 2022-06-18 10:02:16.928645
# Unit test for function main
def test_main():
    import sys
    import unittest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.escape import url_escape
    from tornado.options import define, options, parse_command_line
    from tornado.httpclient import HTTPRequest, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import aiohttp
    import aiohttp.web
    import aiohttp.client
    import aiohttp.multipart
    import aiohttp.server
    import aiohttp.test_utils
    import aiohttp.web_exceptions
    import aiohttp.web_urldispatcher
    import aiohttp.web_ws
    import aio

# Generated at 2022-06-18 10:02:29.377109
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import signal
    import unittest
    import tempfile
    import shutil

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", MainHandler)])


# Generated at 2022-06-18 10:02:30.065702
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:37.159191
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import os
    import sys
    import subprocess
    import time
    import unittest
    import urllib.parse
    import threading
    import socket
    import re
    import signal
    import logging
    import functools
    import tempfile
    import shutil
    import ssl
    import weakref
    import warnings
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.futures
    import concurrent.fut

# Generated at 2022-06-18 10:02:38.173210
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:02:38.900782
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-18 10:03:37.090158
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import time
    import unittest
    import logging
    import sys
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
   

# Generated at 2022-06-18 10:03:37.650614
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-18 10:03:48.746583
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import functools
    import logging
    import os
    import socket
    import sys
    import threading
    import time
    import unittest
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.log import gen_log
    from tornado.netutil import bind_sockets
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase, bind_unused_port, get_unused_port, gen_test, ignore_deprecation, skipIfNonUnix, skipOnTravis

# Generated at 2022-06-18 10:03:58.757168
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import json
    import os
    import sys
    import unittest
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.robotparser
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.response
    import urllib.robotparser
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse


# Generated at 2022-06-18 10:04:07.669749
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Test that AsyncHTTPClient.__new__ returns a new instance
    # when force_instance=True.
    client1 = AsyncHTTPClient(force_instance=True)
    client2 = AsyncHTTPClient(force_instance=True)
    assert client1 is not client2
    client1.close()
    client2.close()

    # Test that AsyncHTTPClient.__new__ returns the same instance
    # when force_instance=False.
    client1 = AsyncHTTPClient()
    client2 = AsyncHTTPClient()
    assert client1 is client2
    client1.close()

    # Test that AsyncHTTPClient.__new__ returns the same instance
    # when force_instance=False and the same IOLoop is used.
    client1 = AsyncHTTPClient()
    client2 = AsyncHTTPClient()


# Generated at 2022-06-18 10:04:19.491031
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient
    import tornado.options
    import tornado.testing
    import tornado.web
    import tornado.httpclient


# Generated at 2022-06-18 10:04:25.860836
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test that the initialize method of AsyncHTTPClient is called
    # correctly.
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, defaults=None):
            self.defaults = defaults
            self.initialized = True

    client = TestAsyncHTTPClient(defaults=dict(a=1))
    assert client.initialized
    assert client.defaults == dict(a=1)



# Generated at 2022-06-18 10:04:35.227581
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPHeaders
    from tornado.httpclient import HTTPMessageDelegate
    from tornado.httpclient import HTTPResponseParser
    from tornado.httpclient import HTTPConnection
    from tornado.httpclient import HTTPConnectionDelegate
    from tornado.httpclient import HTTPConnectionPool
    from tornado.httpclient import HTTPConnectionPoolDelegate
    from tornado.httpclient import HTTPRequestProxy
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import _HTTPRequest
    from tornado.httpclient import _HTTPConnection
    from tornado.httpclient import _HTTPConnectionDelegate

# Generated at 2022-06-18 10:04:38.511523
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    # This method should be implemented by subclasses.
    # It should call callback with an HTTPResponse object.
    return


# Generated at 2022-06-18 10:04:44.502210
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test that AsyncHTTPClient.close() frees the underlying client.
    # This test is a little tricky because the client is cached, so
    # we have to create a new AsyncHTTPClient class to get a new
    # cache.
    class MyAsyncHTTPClient(AsyncHTTPClient):
        pass

    client = MyAsyncHTTPClient()
    client.close()
    client2 = MyAsyncHTTPClient()
    assert client2 is not client



# Generated at 2022-06-18 10:09:24.953023
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    assert client.defaults == HTTPRequest._DEFAULTS
    assert client._closed == False


# Generated at 2022-06-18 10:09:29.599152
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    import tornado.ioloop
    import tornado.platform.asyncio
    import asyncio
    import time
    import pytest
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.concurrent import Future
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import AsyncHTTPClient