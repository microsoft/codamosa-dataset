

# Generated at 2022-06-26 08:01:50.009708
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    try:
        h_t_t_p_response_0 = HTTPResponse(h_t_t_p_client_0, h_t_t_p_client_0, h_t_t_p_client_0, h_t_t_p_client_0, h_t_t_p_client_0)
        h_t_t_p_response_0.rethrow()
    except HTTPError as e:
        print(e.code)


# Generated at 2022-06-26 08:01:53.019923
# Unit test for function main
def test_main():
    out = StringIO()
    sys.stdout = out

    main()
    main()
    main()
    main()
    main()
    main()

    sys.stdout = sys.__stdout__
    out.seek(0)
    data = out.read()
    print(data)


if __name__ == "__main__":
    # test_main()
    pass

# Generated at 2022-06-26 08:02:01.786294
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # NOTE: HTTPClient instance is required to be instantiated firstly,
    # otherwise, it will cause an error when invoking the curl_httpclient's instance,
    # and it will cause that the httpclient_testcase's instance is NoneType.
    HTTPClient()

    response = HTTPResponse(request=None, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()



# Generated at 2022-06-26 08:02:03.557906
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Arrange
    force_instance = False
    # Act
    async_http_client_0 = AsyncHTTPClient(force_instance=force_instance)


# Generated at 2022-06-26 08:02:15.745275
# Unit test for method rethrow of class HTTPResponse

# Generated at 2022-06-26 08:02:23.147603
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
	h_t_t_p_client_0 = HTTPClient()
	request = HTTPRequest('127.0.0.1:8000/', user_agent='', method='GET')
	response = h_t_t_p_client_0.fetch(request, raise_error=False)
	response = h_t_t_p_client_0.fetch('127.0.0.1:8000', raise_error=False)
	print(response.body)

test_HTTPClient_fetch()

# Generated at 2022-06-26 08:02:34.416817
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()
    class HTTPRequest_0:
        def __init__(self, url: str, **kwargs: Any) -> None:
            self.headers = kwargs['headers']
            self.url = url
            self.follow_redirects = False
            self.user_agent = "my-agent"
    # create HTTPRequest class
    request_0 = HTTPRequest_0(url="http://localhost:8888", headers={"test": "test"})
    # run fetch
    h_t_t_p_client_0.fetch(request=request_0, raise_error=False)

# Generated at 2022-06-26 08:02:47.512726
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest('http://example.com/')
    code = 200
    headers = None
    buffer = BytesIO()
    effective_url = 'http://example.com/'
    error = None
    request_time = None
    time_info = {}
    reason = None
    start_time = None
    h_t_t_p_response_0 = HTTPResponse(request, code, headers, buffer, effective_url,
        error, request_time, time_info, reason, start_time)

# Generated at 2022-06-26 08:02:50.253954
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:02:54.707714
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-26 08:03:14.704929
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    http_request_0 = HTTPRequest(url="http://localhost:8080")
    test_HTTPResponse_rethrow_h_t_t_p_response_0 = HTTPResponse(request=http_request_0, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)


# Generated at 2022-06-26 08:03:21.397349
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest("http://www.google.com")
    h_t_t_p_response_0 = h_t_t_p_client_0.fetch(h_t_t_p_request_0)
    h_t_t_p_response_0.rethrow()


# Generated at 2022-06-26 08:03:24.324903
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    cls_0 = AsyncHTTPClient()
    cls_0.close()
    cls_1 = AsyncHTTPClient()
    cls_1.close()


# Generated at 2022-06-26 08:03:31.259401
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    h_t_t_p_client_0 = HTTPClient()
    assert h_t_t_p_client_0._async_client == None
    assert h_t_t_p_client_0._io_loop == None
    assert h_t_t_p_client_0._closed == True
    assert h_t_t_p_client_0.__class__ == HTTPClient
    assert h_t_t_p_client_0._async_client.__class__ == AsyncHTTPClient
    assert h_t_t_p_client_0._io_loop.__class__ == IOLoop
    h_t_t_p_client_0.close()
    assert h_t_t_p_client_0._closed == True


# Generated at 2022-06-26 08:03:44.051532
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('GET', 'https://www.example.com/')
    code = 200
    headers = httputil.HTTPHeaders({'a': 'b'})
    buffer = BytesIO()
    effective_url = 'hg'
    error = None
    request_time = time.time()
    time_info = {'a': 1}
    reason = None
    start_time = time.time()

    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    # with no error, rethrow should pass
    response.rethrow()

    # check if rethrow works with response error
    request = HTTPRequest('GET', 'https://www.example.com/')
    code = 400
    headers = httput

# Generated at 2022-06-26 08:03:47.876894
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    client = AsyncHTTPClient()
    client.initialize()



# Generated at 2022-06-26 08:03:53.104827
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    simple_async_http_client_0.initialize()
    simple_async_http_client_1 = SimpleAsyncHTTPClient()
    simple_async_http_client_1.initialize(defaults=dict(user_agent="MyUserAgent"))


# Generated at 2022-06-26 08:04:03.708270
# Unit test for function main
def test_main():
    with patch('__main__.HTTPClient') as mock_HTTPClient:
        with patch('__main__.parse_command_line') as mock_parse_command_line:
            mock_parse_command_line.return_value = ['abc']

            h_t_t_p_client_0_0 = mock_HTTPClient.return_value
            mock_parse_command_line.return_value = 'abc'
            mock_parse_command_line.return_value = 'abc'
            main()

            mock_HTTPClient.assert_called_with()
            mock_parse_command_line.assert_called_with()

            mock_parse_command_line.return_value = ['abc']
            mock_parse_command_line.return_value = 'abc'
            main()

            mock_HTTPClient.assert_called_with

# Generated at 2022-06-26 08:04:17.364596
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    class TestHTTPResponse(HTTPResponse):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.code = 200
            self.headers = httputil.HTTPHeaders()
            self.buffer = BytesIO()
            self.effective_url = ''
            self.error = None
            self.request_time = None
            self.time_info = {}

    h_t_t_p_response_0 = TestHTTPResponse()
    # Assert that an exception is raised with expected error code.

# Generated at 2022-06-26 08:04:27.792110
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.httpclient
    h_t_t_p_client_0 = AsyncHTTPClient()

# Generated at 2022-06-26 08:04:42.088931
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    Assert(isinstance(a_s_y_n_c_h_t_t_p_client_0, AsyncHTTPClient))
    Assert(isinstance(a_s_y_n_c_h_t_t_p_client_0._instance_cache, weakref.WeakKeyDictionary))


# Generated at 2022-06-26 08:04:46.979354
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    try:
        # Runtime error: fetch() called on closed AsyncHTTPClient
        async_h_t_t_p_client_0 = AsyncHTTPClient()
    except Exception as e:
        print(e)
    async_h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:04:58.042130
# Unit test for function main
def test_main():
    import tempfile
    import sys
    stderr_file = tempfile.mkstemp()
    stderr_file_dup = os.dup(sys.stderr.fileno())
    sys.stderr.flush()
    os.dup2(stderr_file[0], sys.stderr.fileno())
    try:
        main()
    except:
        pass
    sys.stderr.flush()
    os.dup2(stderr_file_dup, sys.stderr.fileno())
    os.close(stderr_file_dup)
    os.lseek(stderr_file[0], 0, os.SEEK_SET)
    error_output = os.read(stderr_file[0], 65536)
    os.close

# Generated at 2022-06-26 08:05:03.747254
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_1 = AsyncHTTPClient()
    print(type(h_t_t_p_client_1))
    h_t_t_p_client_1.initialize()
    print(type(h_t_t_p_client_1))


# Generated at 2022-06-26 08:05:04.745687
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:05:08.404451
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    my_Server = AsyncHTTPClient()
    my_Server.close()


# Generated at 2022-06-26 08:05:09.741712
# Unit test for function main
def test_main():
    main()

# Test function for function main

# Generated at 2022-06-26 08:05:11.461050
# Unit test for function main
def test_main():
    main()
    main()
    main()


# Generated at 2022-06-26 08:05:23.187883
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient
    from copy import copy

    def _fake_fetch(request : HTTPRequest, callback : Callable[[HTTPResponse], None]):
        callback(HTTPResponse(request, request.method,
                              request.body, 200, request.headers,
                              httputil.HTTPHeaders(),
                              request.request_time, 0.1))


    # helper Google search URL generator

# Generated at 2022-06-26 08:05:36.318610
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import HTTPRequest
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    from tornado.web import RequestHandler, Application
    class TestGetHandler(RequestHandler):
        def get(self):
            self.write("Hello")

    class TestHandler2(RequestHandler):
        def get(self):
            self.set_header("Content-Type", "text/html; charset=utf-8")
            self.write("Hello world")

    class TestHandler3(RequestHandler):
        def get(self):
            self.write("Hello world")
            self.set_status(403)

    class TestHandler4(RequestHandler):
        def get(self):
            self.set_header("Content-Type", "text/html; charset=utf-8")
            self.write("Hello world")

# Generated at 2022-06-26 08:05:43.369604
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:05:44.242263
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:05:50.697166
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # unit test for method fetch of object AsyncHTTPClient
    # prepare inputs
    request = HTTPRequest('http://www.google.com')
    callback = functools.partial(handle_response, request)
    # make method call
    try:
        AsyncHTTPClient().fetch_impl(request, callback)
    except NotImplementedError as e:
        return
    raise Exception('AsyncHTTPClient.fetch_impl does not raise NotImplementedError')

# Generated at 2022-06-26 08:05:53.228101
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def f():
        h_t_t_p_client_0 = AsyncHTTPClient()
        h_t_t_p_client_1 = AsyncHTTPClient()

    test_case_0()
    f()


# Generated at 2022-06-26 08:05:59.990878
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # <Value `1` in `_RequestProxy.__getattr__` is not a valid method argument>
    _RequestProxy_0_instance = _RequestProxy(HTTPRequest(url="localhost", method=1), None)
    return _RequestProxy_0_instance

if __name__ == "__main__":
    # Run the tests
    test_case_0()
    test__RequestProxy___getattr__()

# Generated at 2022-06-26 08:06:04.642992
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    try:
        h_t_t_p_client_0 = HTTPClient()
    except Exception as e:
        print("Exception caught : ", e)

    finally:
        h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:06:06.891718
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    for i in range(0, 1):
        if i == 0:
            test_case_0()


# Generated at 2022-06-26 08:06:10.816651
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    c = AsyncHTTPClient()
    request_0 = HTTPRequest()
    def callback_0(response: "HTTPResponse") -> None:
        pass
    c.fetch_impl(request_0, callback_0)


# Generated at 2022-06-26 08:06:14.698146
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        assert True
    except AssertionError as e:
        print('AssertionError raised in test_AsyncHTTPClient_fetch_impl')
        print(e)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 08:06:15.852041
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    AsyncHTTPClient.close()


# Generated at 2022-06-26 08:06:28.049678
# Unit test for function main
def test_main():
    main()    

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 08:06:33.721329
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # case 0
    print("case 0")
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest("http://www.google.com")
    _RequestProxy_0 = _RequestProxy( h_t_t_p_request_0, None)
    assert h_t_t_p_request_0.user_agent == "tornado/6.0.3"
    assert _RequestProxy_0.user_agent == "tornado/6.0.3"
    
    

# Generated at 2022-06-26 08:06:37.762647
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = HTTPClient()
    with pytest.raises(NotImplementedError):
        h_t_t_p_client_0.fetch_impl(h_t_t_p_client_0, None)

# Generated at 2022-06-26 08:06:53.027165
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import json
    import time
    import requests
    import asyncio

    urls = ['https://www.baidu.com']
    start = time.time()
    loop = asyncio.get_event_loop()

    def do_work(url):
        return requests.get(url)

    def done_callback(future):
        result = future.result()
        if result.status_code == 200:
            return result.text
        else:
            return ''

    async def async_do_work(url):
        return await loop.run_in_executor(None, do_work, url)

    async def async_main():
        tasks = [async_do_work(url) for url in urls]
        for task in asyncio.as_completed(tasks):
            print(await task)



# Generated at 2022-06-26 08:06:57.315134
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:06.823531
# Unit test for function main
def test_main():
    # h_t_t_p_client_0 = HTTPClient()
    # args_0 = parse_command_line()
    # response_0 = client.fetch(arg, follow_redirects=options.follow_redirects, validate_cert=options.validate_cert, proxy_host=options.proxy_host, proxy_port=options.proxy_port)
    # print(options.print_headers)
    # h_t_t_p_client_0.close()
    pass


# Generated at 2022-06-26 08:07:09.460557
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()

# Generated at 2022-06-26 08:07:15.074373
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    test_AsyncHTTPClient = AsyncHTTPClient()
    test_HTTPResponse = AsyncHTTPClient()
    test_HTTPRequest = HTTPRequest(url='www.google.com')
    test_AsyncHTTPClient.fetch_impl(test_HTTPRequest, test_HTTPResponse)


# Generated at 2022-06-26 08:07:24.273682
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_request_0 = HTTPRequest()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()

# Generated at 2022-06-26 08:07:25.438127
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:39.257237
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    print("\nTesting method __new__ of class AsyncHTTPClient")

    async_h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:07:49.595797
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    """
    AsyncHTTPClient.fetch_impl() # missing-docstring
    """
    # <Missing function docstring>
    # <Missing function docstring>
    print("---AsyncHTTPClient.fetch_impl()---")
    print("---AsyncHTTPClient.fetch_impl()---")
    print("---AsyncHTTPClient.fetch_impl()---")
    print("---AsyncHTTPClient.fetch_impl()---")

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-26 08:07:55.498878
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    import logging
    logging.basicConfig()
    test_main()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 08:07:57.866102
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:07:59.470696
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client_0 = AsyncHTTPClient()
    http_client_0.close()


# Generated at 2022-06-26 08:08:00.880563
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:08:11.145415
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_response_t_0 = h_t_t_p_client_0.fetch(h_t_t_p_client_0)
    h_t_t_p_request_t_0 = HTTPRequest(h_t_t_p_client_0)
    h_t_t_p_request_proxy_0 = _RequestProxy(h_t_t_p_request_t_0, None)
    h_t_t_p_request_proxy_0.__getattr__(h_t_t_p_request_proxy_0.request)


# Generated at 2022-06-26 08:08:13.673196
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_main()
    test_case_0()

# Generated at 2022-06-26 08:08:15.134404
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    AsyncHTTPClient_init()


# Generated at 2022-06-26 08:08:15.771263
# Unit test for function main
def test_main():
    main()