

# Generated at 2022-06-26 08:02:05.796928
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    force_instance = False
    kwargs = dict()
    # h_t_t_p_client_0 = AsyncHTTPClient(force_instance, **kwargs)
    pass


# Generated at 2022-06-26 08:02:08.916871
# Unit test for function main
def test_main():
    main()
    # main(http_server)

if __name__ == '__main__':
    test_main()
    # test_case_0()

# Generated at 2022-06-26 08:02:10.042487
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-26 08:02:13.242536
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:19.238688
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url='http://www.example.com', method='GET')
    defaults = dict()
    defaults['key'] = 'value'
    # obj of class _RequestProxy
    request_proxy = _RequestProxy(request, defaults)
    # getattr should get request_attr for existing attribute in request
    assert type(request_proxy.request) == HTTPRequest
    # getattr should get the value stored in defaults for its key if request_attr is None
    assert request_proxy.key == 'value'


# Generated at 2022-06-26 08:02:23.323546
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_response_0 = h_t_t_p_client_0.fetch("http://google.com/")

# System test for method fetch of class HTTPClient

# Generated at 2022-06-26 08:02:36.723329
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    headers_0 = httputil.HTTPHeaders()
    buffer_0 = BytesIO()
    effective_url_0 = 'http://127.0.0.1:8888/'
    request_time_0 = 4.878880000
    time_info_0 = {}
    reason_0 = 'HTTP/1.1 200 OK'
    start_time_0 = 3.2

    # Initialization of object
    h_t_t_p_response_0 = HTTPResponse(request=HTTPRequest(), code=200, headers=headers_0, buffer=buffer_0,
                                      effective_url=effective_url_0, error=None, request_time=request_time_0,
                                      time_info=time_info_0, reason=reason_0, start_time=start_time_0)



# Generated at 2022-06-26 08:02:38.160130
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    # Test for method close(...) of class AsyncHTTPClient
    h_t_t_p_client_0.close()



# Generated at 2022-06-26 08:02:41.309988
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:02:48.967940
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # unit test for rethrow of class HTTPResponse
    for i in range(100):
        request = HTTPRequest('http://www.google.com')
        response = HTTPResponse(request, 200, {}, "OK", "http://www.google.com", None, 1, {})
        response.error = HTTPError(404, "Not Found")
        response.rethrow()


# Generated at 2022-06-26 08:03:08.104020
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    from tornado.httpclient import _RequestProxy

    request_0 = HTTPRequest(
        body=utf8("testBody"),
        url="testurl",
        method="post",
        headers={
            "Connection": "keep-alive",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36",
            "Content-Type": "application/json"
        }
    )

# Generated at 2022-06-26 08:03:12.888378
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request = HTTPRequest()
    request_proxy_0 = _RequestProxy(h_t_t_p_request, None)
    __getattr__(request_proxy_0, 'key')


# Generated at 2022-06-26 08:03:18.410081
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    http_request_0 = HTTPRequest("http://www.tornadoweb.org/en/stable/")
    httpr_0 = HTTPResponse(http_request_0, 200)
    assert "#tornado" in httpr_0.body.decode("utf-8")
    httpr_0.rethrow()



# Generated at 2022-06-26 08:03:20.982662
# Unit test for function main
def test_main():
    test_case_0()

# Run tests
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:03:21.588560
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:03:27.369815
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    impl = 'tornado.curl_httpclient.CurlAsyncHTTPClient'
    kwargs = dict(force_instance = True)
    impl = "tornado.simple_httpclient.SimpleAsyncHTTPClient"
    kwargs = dict(force_instance = True, defaults = dict(user_agent = "MyUserAgent"))
    impl = "tornado.httpclient.AsyncHTTPClient"
    kwargs = dict(force_instance = True)
    return


# Generated at 2022-06-26 08:03:28.998123
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():

    request = h_t_t_p_client_0.fetch('http://localhost:8080/test')


# Generated at 2022-06-26 08:03:31.648172
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request_0 = HTTPRequest(None)
    h_t_t_p_request_1 = HTTPRequest(None)
    _RequestProxy_0 = _RequestProxy(h_t_t_p_request_1, None)
    _RequestProxy_0._RequestProxy___getattr__(request_0)


# Generated at 2022-06-26 08:03:40.018225
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    r_e_q_u_e_s_t_0 = HTTPRequest(url = "http://www.google.com")
    _RequestProxy_0 = _RequestProxy(r_e_q_u_e_s_t_0, None)
    try:
        _RequestProxy_0.__getattr__(r_e_q_u_e_s_t_0.method)
    except:
        print('Exception: TypeError')

# Generated at 2022-06-26 08:03:48.821046
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    io_loop_0 = IOLoop()
    async_http_client_0 = AsyncHTTPClient(force_instance=True, defaults=dict(allow_nonstandard_methods=False))
    http_client_1 = HTTPClient(async_http_client_class=async_http_client_0.__class__)
    http_client_2 = HTTPClient(async_http_client_class=async_http_client_0.__class__)

# Generated at 2022-06-26 08:03:55.500421
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass


# Generated at 2022-06-26 08:03:57.034650
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:03:59.842366
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    async_h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:04:05.197424
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Create an instance of class AsyncHTTPClient
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # Call method initialize of class AsyncHTTPClient with arguments
    async_h_t_t_p_client_0.initialize(None)


# Generated at 2022-06-26 08:04:17.488497
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_request_0 = HTTPRequest(url = '', headers = httputil.HTTPHeaders(value = '', value = '', value = '', value = ''), )
    h_t_t_p_client_0 = AsyncHTTPClient()

# Generated at 2022-06-26 08:04:24.104484
# Unit test for function main
def test_main():
    for _ in range(10):
        main()
    print('# unit test for function main passed')

if __name__ == "__main__":
    # main()
    # Unit test for function test_case_0
    test_case_0()
    # Unit test for function main
    test_main()

# Generated at 2022-06-26 08:04:28.558711
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Create an instance of AsyncHTTPClient
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # Call the method
    async_h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:04:31.339958
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:04:33.920865
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    test_class = AsyncHTTPClient()
    test_class.initialize()
    assert test_class is not None


# Generated at 2022-06-26 08:04:35.241277
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:04:47.066053
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test with exception raised
    try:
        AsyncHTTPClient.configure(None, max_clients=0, max_simultaneous_connections=0)
        AsyncHTTPClient().initialize()
    except:
        print("Can't test initialize of method AsyncHTTPClient, because the method is internal")


# Generated at 2022-06-26 08:04:48.127254
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:04:49.600153
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:04:52.412993
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    h_t_t_p_client_1 = HTTPClient()

    h_t_t_p_client_2 = HTTPClient(async_client_class=AsyncHTTPClient)



# Generated at 2022-06-26 08:05:05.004669
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    #  Create a new default AsyncHTTPClient
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    #  Initialize the default AsyncHTTPClient
    async_h_t_t_p_client_0.initialize()
    #  Create a new default AsyncHTTPClient
    async_h_t_t_p_client_1 = AsyncHTTPClient()
    #  Initialize the default AsyncHTTPClient
    async_h_t_t_p_client_1.initialize()
    #  Create a new default AsyncHTTPClient
    async_h_t_t_p_client_2 = AsyncHTTPClient()
    #  Initialize the default AsyncHTTPClient
    async_h_t_t_p_client_2.initialize()
    #  Create a new default

# Generated at 2022-06-26 08:05:13.413300
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    # Check that abstract method fetch_impl of class AsyncHTTPClient raises NotImplementedError
    try:
        a_sync_h_t_t_p_client_0 = AsyncHTTPClient()
        a_sync_h_t_t_p_client_0.fetch_impl(request_0, callback_0)
    except Exception as e:
        assert isinstance(e, NotImplementedError)



# Generated at 2022-06-26 08:05:14.934377
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:05:15.968827
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-26 08:05:22.970053
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:05:26.282827
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:05:38.922350
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    a_sync_http_client_0 = AsyncHTTPClient()
    a_sync_http_client_0.initialize()


# Generated at 2022-06-26 08:05:53.246794
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    async_http_client_0 = AsyncHTTPClient()

# Generated at 2022-06-26 08:05:53.930547
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-26 08:05:55.910858
# Unit test for function main
def test_main():
    # No exception raised, test passed, so we don't need to return anything
    # pass
    main()


# Generated at 2022-06-26 08:05:58.184331
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass


# Generated at 2022-06-26 08:05:59.454012
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:06:02.867792
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.fetch_impl()


# Generated at 2022-06-26 08:06:08.644294
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = HTTPClient()
    try:
        h_t_t_p_client_0.fetch("http://www.google.com/", raise_error=False)
    except Exception as e:
        print("Error: %s" % e)
        # Error: HTTP 599: Timeout

# Generated at 2022-06-26 08:06:10.408625
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
  # TODO: Implement test for method initialize
  pass


# Generated at 2022-06-26 08:06:21.987781
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest('http://127.0.0.1:8888')
    d_e_f_a_u_l_t_s_0 = {'body': 'l_m_g_t_m_y', 'method': 'GET'}
    r_e_q_u_e_s_t_p_r_o_x_y_0 = _RequestProxy(h_t_t_p_request_0, d_e_f_a_u_l_t_s_0)
    r_e_q_u_e_s_t_p_r_o_x_y_0._RequestProxy__getattr__('url')
    r_e_q_u_

# Generated at 2022-06-26 08:06:34.237640
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.httpclient import HTTPRequest
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    # Test with force_instance: True and defaults: {'key1': 'value1'}
    AsyncHTTPClient.configure(None, defaults={'key1': 'value1'})
    # Test with force_instance: False and defaults: {'key2': 'value2'}
    # Test method __new__
    client = AsyncHTTPClient(force_instance=True, defaults={'key2': 'value2'})
    class TestHTTPRequest1(HTTPRequest):
        def __init__(self):
            self.callback = None
            self.headers = {'key1': 'value1', 'key2': 'value2'}
            self.url = "http://www.baidu.com"
            self.request

# Generated at 2022-06-26 08:06:42.768725
# Unit test for function main
def test_main():
# Collect input from command line args
    args = []
    global options
    options = None
    main()

from tornado.platform.auto import set_close_exec
from tornado.log import gen_log
from tornado.util import errno_from_exception

from typing import Iterable, Type, Iterator
from typing import Union
from typing import Optional
from typing import Tuple
from typing import Any
from typing import List
from typing import Callable
from typing import cast

from zmq.eventloop.future import Future

from zmq.eventloop.ioloop import IOLoop
from zmq.eventloop.ioloop import TimeoutError
from zmq.eventloop.ioloop import PeriodicCallback
from zmq.eventloop.ioloop import PollIOLoop
from zmq.eventloop.ioloop import _Timeout

# Generated at 2022-06-26 08:06:49.835115
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def callback(response):
        # It should match the corresponding signature of the original callback: HTTPResponse -> None
        pass
    r_r_0 = HTTPRequest()
    a_h_c_0 = AsyncHTTPClient()
    a_h_c_0.fetch_impl(r_r_0, callback)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:06:52.383555
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()



# Generated at 2022-06-26 08:06:56.824411
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:07:01.462954
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado import httputil
    from tornado.util import Configurable
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.util import console_log
    async_h_t_t_p_client = AsyncHTTPClient()



# Generated at 2022-06-26 08:07:02.704245
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:06.983125
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:07:08.063839
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    AsyncHTTPClient()


# Generated at 2022-06-26 08:07:09.852593
# Unit test for function main
def test_main():
    # Calling the main function
    main()

# Generated at 2022-06-26 08:07:54.754839
# Unit test for function main
def test_main():
    main()

test_case_0()
#test_main()

# Generated at 2022-06-26 08:07:59.794729
# Unit test for function main
def test_main():
    import sys
    import StringIO
    import urllib

    saved_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out

        # Call the function
        main()

        output = out.getvalue().strip()
        assert output == """<p>Hello, world</p>"""
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-26 08:08:00.837331
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:08:04.028201
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_2 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0 = HTTPClient()


# Generated at 2022-06-26 08:08:05.451057
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:08:09.197885
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    try:
        h_t_t_p_client_0.close()
    except RuntimeError:
        pass



# Generated at 2022-06-26 08:08:21.087459
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Test with argument 'force_instance=True'
    async_h_t_t_p_client_0 = AsyncHTTPClient(force_instance=True)

    # Test with argument 'force_instance=True' and 'io_loop=io_loop_0'
    async_h_t_t_p_client_1 = AsyncHTTPClient(io_loop=io_loop_0, force_instance=True)

    # Test with argument 'force_instance=False'
    async_h_t_t_p_client_2 = AsyncHTTPClient(force_instance=False)

    # Test with argument 'force_instance=False' and 'io_loop=io_loop_0'

# Generated at 2022-06-26 08:08:27.395608
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test 1: Test if Exception is thrown
    # Test 2: Test if TypeError is thrown if the request parameter is not of type HTTPRequest
    # Test 3: Test if TypeError is thrown if the callback parameter is not of type Callable[[HTTPResponse], None]
    # Test 4: Test if callback is called with an HTTPResponse as a parameter
    pass


# Generated at 2022-06-26 08:08:28.259114
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:08:30.664074
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()
