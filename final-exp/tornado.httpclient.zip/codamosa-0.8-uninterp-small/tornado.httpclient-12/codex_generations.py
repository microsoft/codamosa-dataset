

# Generated at 2022-06-26 08:02:02.870784
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:04.935736
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    test_client = AsyncHTTPClient()
    print(test_client.fetch_impl(request=None, callback=None))


# Generated at 2022-06-26 08:02:08.077802
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-26 08:02:11.139108
# Unit test for function main
def test_main():
    import random
    import string
    random_salt = ''.join(random.choice('1234567890qwertyuiopasdfghjklzxcvbnm') for _ in range(16))
    test_url = 'https://www.google.com/search?q=' + random_salt
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:02:16.669144
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Test case from class AsyncHTTPClient
    int_0 = -1
    ssl_options_0 = SSLOptions()
    http_request = HTTPRequest('http://www.google.com/', request_timeout=int_0, ssl_options=ssl_options_0)
    http_response = AsyncHTTPClient().fetch(http_request)


# Generated at 2022-06-26 08:02:18.097848
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    test_AsyncHTTPClient_close_0()
    return


# Generated at 2022-06-26 08:02:18.806443
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:19.483561
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:32.044561
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    int_0 = 0
    assert_equal(int_0, 0)
    int_1 = 0
    assert_equal(int_1, 0)
    int_2 = 0
    assert_equal(int_2, 0)
    int_3 = 0
    assert_equal(int_3, 0)
    int_4 = 0
    assert_equal(int_4, 0)
    int_5 = 0
    assert_equal(int_5, 0)
    int_6 = 0
    assert_equal(int_6, 0)
    int_7 = 0
    assert_equal(int_7, 0)
    int_8 = 0
    assert_equal(int_8, 0)
    int_9 = 0
    assert_equal(int_9, 0)
    int_10 = 0

# Generated at 2022-06-26 08:02:35.970436
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    tornado.testing.gen_test(test_AsyncHTTPClient_close_0())
    tornado.testing.gen_test(test_AsyncHTTPClient_close_1())


# Generated at 2022-06-26 08:02:47.032293
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    def f():
        http_client = AsyncHTTPClient()
        http_client.close()
        assert(http_client._closed)
        return http_client
    io_loop = IOLoop.current()
    io_loop.run_sync(f)


# Generated at 2022-06-26 08:02:47.775010
# Unit test for function main
def test_main():
    main()
    print("test_main() finished!")


# Generated at 2022-06-26 08:02:55.638366
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    http_response = HTTPResponse(request=HTTPRequest(url="https://www.google.com"), code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)

    http_response.rethrow()
    print("Unit test for method rethrow of class HTTPResponse: Success")
    # print(http_response.__dict__)


# Generated at 2022-06-26 08:02:59.085296
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # 1. Arrange
    instance = AsyncHTTPClient()

    # 2. Act
    instance.close()

    # 3. Assert
    assert instance._closed == True


# Generated at 2022-06-26 08:03:01.402306
# Unit test for function main
def test_main():
    import sys
    import StringIO
    sys.stdout = StringIO.StringIO()
    main()
    assert True

# Generated at 2022-06-26 08:03:02.031018
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:03:04.454182
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    curr_inst = AsyncHTTPClient()
    curr_inst.close()
    assert curr_inst._closed == True


# Generated at 2022-06-26 08:03:05.548800
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:03:11.942329
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    async def fetch_async() -> HTTPResponse:
        async with AsyncHTTPClient() as client:
            response = await client.fetch("http://www.baidu.com")
        return response

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(fetch_async())



# Generated at 2022-06-26 08:03:23.797824
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    http_client = SimpleAsyncHTTPClient(io_loop=IOLoop.current())
    # Each instance should have its own dict of defaults
    default_headers = http_client.defaults

    http2_client = SimpleAsyncHTTPClient(io_loop=IOLoop.current())
    assert http_client.defaults is not http2_client.defaults
    # If a dict of defaults is passed in, that should be used
    new_default_headers = {'Host': 'example.com'}
    http2_client.initialize(new_default_headers)
    assert new_default_headers is http2_client.defaults
    assert default_headers is not http2_client.defaults
    # If the http_client is closed, it should be removed from the instance cache.

# Generated at 2022-06-26 08:03:37.301916
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    def __new___1():
        '''
        impl = "abc"
        force_instance = False
        '''
        pass  #TODO: implement this test case
    def __new___2():
        '''
        impl = "xyz"
        force_instance = False
        '''
        pass  #TODO: implement this test case
    pass  #TODO: implement this test case


# Generated at 2022-06-26 08:03:39.047815
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    obj = AsyncHTTPClient()
    request = "http://www.google.com"
    raise_error = True
    kwargs = {}
    obj.fetch_impl = MagicMock()
    obj.fetch(request, raise_error, **kwargs)


# Generated at 2022-06-26 08:03:43.427915
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.log import app_log
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient

    request = HTTPRequest('/')
    instance = AsyncHTTPClient()
    instance.fetch_impl(request, None)


# Generated at 2022-06-26 08:03:50.920043
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # get the AsyncHTTPClient instance
    http_client = AsyncHTTPClient()
    # test the static method _async_client_dict_AsyncHTTPClient
    assert len(http_client._async_client_dict_AsyncHTTPClient) == 1
    assert isinstance(
        http_client._async_client_dict_AsyncHTTPClient[IOLoop.current()],
        AsyncHTTPClient,
    )  # type: ignore


# Generated at 2022-06-26 08:04:04.612705
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    def test_AsyncHTTPClient___new____0():
        # - 0: AsyncHTTPClient.__new__
        assert testAsyncHTTPClient___new____0()
        return True

    def test_AsyncHTTPClient___new____1():
        # - 1: AsyncHTTPClient.__new__
        assert testAsyncHTTPClient___new____1()
        return True

    def test_AsyncHTTPClient___new____2():
        # - 2: AsyncHTTPClient.__new__
        assert testAsyncHTTPClient___new____2()
        return True

    def test_AsyncHTTPClient___new____3():
        # - 3: AsyncHTTPClient.__new__
        assert testAsyncHTTPClient___new____3()
        return True


# Generated at 2022-06-26 08:04:12.144462
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    assert SimpleAsyncHTTPClient._instance_cache == {}
    client = AsyncHTTPClient(force_instance=True)
    assert len(SimpleAsyncHTTPClient._instance_cache) == 1
    client.close()
    assert SimpleAsyncHTTPClient._instance_cache == {}



# Generated at 2022-06-26 08:04:18.703790
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    """
    Unit test for initialize of class AsyncHTTPClient
    """
    case_async_client = AsyncHTTPClient()
    case_async_client.initialize()
    # print(case_async_client)
    assert case_async_client._instance_cache == None
    assert case_async_client.io_loop == IOLoop.current()
    assert case_async_client.defaults == HTTPRequest._DEFAULTS
    assert case_async_client.io_loop == IOLoop.current()
    assert case_async_client._closed == False


# Generated at 2022-06-26 08:04:23.977677
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    a = AsyncHTTPClient()
    r = a.close()
    expect = None
    assert r == expect, 'Simple AsyncHTTPClient_close test failed!'
    print('Simple AsyncHTTPClient_close test passed!')


# Generated at 2022-06-26 08:04:34.032860
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    request = HTTPRequest()
    url = request.url
    print ('url is %s' % url)
    kwargs = {'user_agent': 'Hugo'}
    AsyncHTTPClient.configure(None, defaults=kwargs)

    # Origin:
    # https://github.com/tornadoweb/tornado/blob/master/tornado/testing/httpclient_test.py

    # get_httpclient
    # Returns an AsyncHTTPClient instance to be used for testing.
    # Returns:
    #   tornado.testing.AsyncHTTPTestCase
    # AsyncHTTPClient.configure(None, defaults=kwargs)


# Generated at 2022-06-26 08:04:35.763330
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    ac = AsyncHTTPClient()
    ac.close()


# Generated at 2022-06-26 08:04:46.638468
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    assert str(type(AsyncHTTPClient.initialize())).startswith("<class 'tornado.httpclient.AsyncHTTPClient'>")
    assert str(type(HTTPClient().initialize())).startswith("<class 'tornado.httpclient.HTTPClient'>")


# Generated at 2022-06-26 08:04:47.658610
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    assert True == True


# Generated at 2022-06-26 08:04:59.036592
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test a call to a method of an object of type AsyncHTTPClient with
    # arguments that are not instances of HTTPRequest and of type
    # function with arguments that are instances of HTTPResponse
    try:
        h_t_t_p_client_0 = HTTPClient()
        h_t_t_p_client_0.fetch_impl("", lambda response: None)
    except:
        pass
    # Test a call to a method of an object of type AsyncHTTPClient with
    # arguments that are instances of HTTPRequest and of type function
    # with arguments that are not instances of HTTPResponse

# Generated at 2022-06-26 08:05:05.443306
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.google.com/')
    defaults = {'decompress_response': True}
    _RequestProxy_instance = _RequestProxy(request, defaults)
    decompress_response = _RequestProxy_instance.decompress_response
    assert decompress_response == True
    print("Successfully tested _RequestProxy.__getattr__()!")


# Generated at 2022-06-26 08:05:08.966528
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    try:
        #Testing if an exception is raised
        #creating an object of AsyncHTTPClient class
        async_HTTP_client_0 = AsyncHTTPClient()
        #Testing if the object is null
        assert async_HTTP_client_0 is not None
    except Exception as exception:
        print(exception.args)



# Generated at 2022-06-26 08:05:10.234734
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:05:20.209077
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # call test_case_0
    test_case_0()
    # new instance of class AsyncHTTPClient
    async_http_client_0 = AsyncHTTPClient()
    # new instance of class AsyncHTTPClient with force_instance = True
    async_http_client_1 = AsyncHTTPClient(force_instance = True)
    # call method initialize of class AsyncHTTPClient
    async_http_client_0.initialize()
    # call method close of class AsyncHTTPClient
    async_http_client_0.close()
    # call method configure of class AsyncHTTPClient
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")


# Generated at 2022-06-26 08:05:23.208637
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # h_t_t_p_client_0 = HTTPClient()
    print ("\nInside test_HTTPClient_fetch: ")

# Generated at 2022-06-26 08:05:24.878113
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:05:37.556305
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import oauth2
    import tornado.platform.asyncio

# Generated at 2022-06-26 08:05:45.829880
# Unit test for function main
def test_main():
    assert 1 == main()


# Generated at 2022-06-26 08:05:48.994005
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient(force_instance=True, ssl_options=ssl.SSLContext())
    # Testing for method close (line 306)
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:05:54.005486
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    # test_main()
    test_case_0()

# Generated at 2022-06-26 08:05:56.338000
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:05:59.504286
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    AsyncHTTPClient.fetch_impl(test_AsyncHTTPClient_obj,test_HTTPRequest_obj,test_handle_response)


# Generated at 2022-06-26 08:06:08.003827
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0._closed_1 = False
    try :
        h_t_t_p_client_0._closed_1 = True
        h_t_t_p_client_0._closed_1 = False
    except NameError:
        h_t_t_p_client_0._closed_1 = False
    # h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:06:10.572478
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:06:15.225441
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest()
    with pytest.raises(AttributeError):
        _RequestProxy(h_t_t_p_request_0, None)

# Unit tests for class HTTPClient

# Generated at 2022-06-26 08:06:20.233547
# Unit test for function main
def test_main():
    argv_copy = sys.argv[:]
    sys.argv = sys.argv[0:1]
    sys.argv.append("http://www.google.com")
    main()
    sys.argv = argv_copy

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:06:22.601291
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_tp_client_0 = AsyncHTTPClient()
    h_t_tp_client_0.close()


# Generated at 2022-06-26 08:06:48.634317
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    print('\nUnittest for method initialize of class AsyncHTTPClient')
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.initialize(defaults=None)


# Generated at 2022-06-26 08:06:56.818904
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    def test_case_0():
        #http_client = httpclient.HTTPClient()
        h_t_t_p_client_0 = HTTPClient()
        try:
            #response = http_client.fetch("http://www.google.com/")
            response_0 = h_t_t_p_client_0.fetch("http://www.google.com/")
            #print(response.body)
            print(response_0.body)
        except httpclient.HTTPError as e:
            # HTTPError is raised for non-200 responses; the response
            # can be found in e.response.
            #print("Error: " + str(e))
            print("Error: " + str(e))

# Generated at 2022-06-26 08:06:58.880700
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 08:07:01.285496
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    var_0 = AsyncHTTPClient()
    var_1 = var_0.close()
    del var_0


# Generated at 2022-06-26 08:07:01.918189
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:07:10.580049
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_request_0 = HTTPRequest()
    def callback(response):
        response.code
        response.reason
        response.request
        response.body
        response.effective_url
        response.headers
        response.error
        response.buffer = BytesIO()
        response.request_time
        response.code
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    async_h_t_t_p_client_0.fetch_impl(
        h_t_t_p_request_0,
        callback
    )


# Generated at 2022-06-26 08:07:15.132610
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.ioloop import IOLoop
    h_t_t_p_client_0 = AsyncHTTPClient(force_instance=True)
    h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:07:19.593476
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    request_0 = HTTPRequest()
    callback_0 = lambda: None
    async_h_t_t_p_client_0.fetch_impl(request_0, callback_0)


# Generated at 2022-06-26 08:07:21.885295
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    if True:
        h_t_t_p_client_0 = AsyncHTTPClient()
        h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:07:26.729745
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    print('Test of method initialize in class AsyncHTTPClient')
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:08:13.339754
# Unit test for function main
def test_main():
    import mock
    import sys
    sys.modules["tornado"] = __import__("mock")
    import tornado.options
    import tornado.httputil
    import tornado.httpclient

    def mock_parse_command_line():
        return ["http://www.google.com"]

    def mock_fetch(url, *args, **kwargs):
        return HTTPResponse(HTTPRequest(url), 200)

    tornado.options.parse_command_line = mock_parse_command_line
    tornado.httputil.HTTPResponse = HTTPResponse
    tornado.httpclient.HTTPRequest = HTTPRequest
    tornado.httpclient.HTTPClient._fetch_impl = mock_fetch
    with mock.patch('sys.stdout', new=StringIO()) as fake_out:
        main()

# Generated at 2022-06-26 08:08:18.870925
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    object_0 = object()
    object_1 = object()
    # Test with multiple arguments
    async_h_t_t_p_client_0.initialize(defaults=object_0, io_loop=object_1)


# Generated at 2022-06-26 08:08:19.821820
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:08:22.542047
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()
    return


# Generated at 2022-06-26 08:08:28.900559
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = HTTPClient()
    class DummyClass:
        pass
    dummy_object = DummyClass()
    dummy_object.error = None
    h_t_t_p_client_0._async_client.fetch(dummy_object, lambda response: response)


# Generated at 2022-06-26 08:08:33.479787
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()
    f_u_t_u_r_e_0 = h_t_t_p_client_0.fetch("http://example.com")
    f_u_t_u_r_e_0.done()


# Generated at 2022-06-26 08:08:34.741418
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:08:36.884179
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:08:50.800737
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Setup:
    #  - Create an instance of the class
    #  - Get the attributes of the instance
    #  - Create a HTTPRequest instance
    #  - Create a dictionary for request headers
    #  - Create a dictionary for body arguments
    #  - Create a boolean value
    #  - Create a method for callback
    #  - Invoke the fetch method on the instance
    # Verify:
    #  - Verify the result of the fetch
    h_t_t_p_client_0 = AsyncHTTPClient()

# Generated at 2022-06-26 08:09:00.975318
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Create a _RequestProxy object
    request = HTTPRequest(url = "testing_url")
    defaults = {"key0":"value0"}

    # test with attributes exist in request and defaults
    request_proxy_0 = _RequestProxy(request, defaults)
    assert request_proxy_0.url == "testing_url"
    assert request_proxy_0.key0 == "value0"
    # test with attributes exist in request, but not in defaults
    request_proxy_1 = _RequestProxy(request, None)
    assert request_proxy_1.url == "testing_url"
