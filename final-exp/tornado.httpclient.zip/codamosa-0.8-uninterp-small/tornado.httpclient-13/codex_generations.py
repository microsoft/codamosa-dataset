

# Generated at 2022-06-26 08:02:02.988517
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.iostream import StreamClosedError
    from tornado.httputil import HTTPHeaders
    from tornado.util import _accept_encoding
    from tornado.curl_httpclient import _unquote_header_value
    import json
    import logging
    import rfc3986
    import socket
    import ssl
    import urllib.parse
    import zlib

    import _strptime
    __strptime = _strptime._strptime


# Generated at 2022-06-26 08:02:08.825560
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    a_sync_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    future_0 = a_sync_h_t_t_p_client_0.fetch("http://www.google.com", raise_error=True)
    future_0.result().close()
    a_sync_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:02:15.587589
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse(): # Function start
    request = HTTPRequest('http://www.google.com')
    c = httputil.HTTPHeaders()
    b = BytesIO()
    t = time.time()

    h = HTTPResponse(request, 200, c, b, 'http://src.com', None, t, None, 'ok', t)
# Unit test end

# Generated at 2022-06-26 08:02:16.457623
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:17.671814
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    test_AsyncHTTPClient___new__0()


# Generated at 2022-06-26 08:02:19.582758
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    client = AsyncHTTPClient()
    client_new = AsyncHTTPClient()
    assert client == client_new


# Generated at 2022-06-26 08:02:28.186432
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # #TYPE_CHECKING
    h_t_t_p_response_0 = HTTPResponse(request=HTTPRequest(), code=0, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    try:
        h_t_t_p_response_0.rethrow()
    except HTTPError as e:
        print(e)

if __name__ == "__main__":
    test_case_0()
    test_HTTPResponse_rethrow()

# Generated at 2022-06-26 08:02:40.852217
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    h_t_t_p_re_r_e_q_u_e_s_t_0 = HTTPRequest(url=u'https://httpbin.org/cookies')
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_response_0 = h_t_t_p_client_0.fetch(h_t_t_p_re_r_e_q_u_e_s_t_0)
    h_t_t_p_re_s_p_o_n_s_e___r_e_p_r___0 = h_t_t_p_response_0.__repr__()
    assert True


# Generated at 2022-06-26 08:02:48.121146
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_1 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_2 = AsyncHTTPClient(force_instance=True)


# Generated at 2022-06-26 08:02:50.960243
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    h_t_t_p_request_0 = HTTPRequest(method='GET', url="http://www.example.com/")
    h_t_t_p_response_0 = HTTPResponse(request=h_t_t_p_request_0, code=200, headers={"header1":"header2"})


# Generated at 2022-06-26 08:03:06.037506
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    h_t_t_p_client_0 = HTTPClient()
    assert isinstance(h_t_t_p_client_0, HTTPClient)


# Generated at 2022-06-26 08:03:07.266906
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:03:19.444973
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Set test case name
    test_case_AsyncHTTPClient___new__.__name__ = 'test_case_AsyncHTTPClient___new__'

    def setUp():
        #Set up test environment
        pass

    def tearDown():
        #Tear down test environment
        pass

    def test_AsyncHTTPClient___new__():
        a_s_y_n_c_h_t_t_p_client = AsyncHTTPClient()

    # Create test suites
    suites = map(lambda x: unittest.TestLoader().loadTestsFromTestCase(x),
                 [test_case_AsyncHTTPClient___new__])
    big_suite = unittest.TestSuite(suites)

    # Run test suites
    unittest.TextTestRunner(verbosity=2).run(big_suite)


# Generated at 2022-06-26 08:03:23.204728
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    print("Test 1: Test of method close of class AsyncHTTPClient")
    if AsyncHTTPClient.configurable_base is not None:
        # _TestAsyncHTTPClient()
        _test_async_http_client()
        

# Generated at 2022-06-26 08:03:26.814751
# Unit test for function main
def test_main():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class UnitTest(AsyncTestCase):
        @gen_test(timeout=60)
        def test_case_1(self):
            test_case_0()

    unittest.main()
    print("\nEND")

# Generated at 2022-06-26 08:03:31.959068
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        def handle_response(response):
            return response
        from __main__ import test_AsyncHTTPClient_fetch_impl as test_case, AsyncHTTPClient
        a_n_a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
        a_n_a_s_y_n_c_h_t_t_p_client_0.fetch_impl("", handle_response)
    except NotImplementedError as e:
        print("NotImplementedError\n", e)


# Generated at 2022-06-26 08:03:45.414227
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado import gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import unittest
    @gen.coroutine
    def coroutine_fixture_0():
        v_t_url_0 = "http://127.0.0.1:62409/%E3%81%82%E3%81%84%E3%81%86%E3%81%88%E3%81%8A"
        o_http_client_0 = AsyncHTTPClient()
        o_response_0 = yield o_http_client_0.fetch(v_t_url_0)
    @gen.coroutine
    def coroutine_fixture_1():
        v_t_

# Generated at 2022-06-26 08:04:01.989178
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Set the value of input parameter 'name'
    name_0 = 'request'

    # If the following line produces an error, please check the definition of function/method __init__:
    # def __init__(self, request: HTTPRequest, defaults: Optional[Dict[str, Any]]) -> None:
    #

# Generated at 2022-06-26 08:04:12.255467
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    a_sync_h_t_t_p_client_0 = AsyncHTTPClient()
    a_sync_h_t_t_p_client_0.initialize()
    # Test the expected path
    try:
        a_sync_h_t_t_p_client_0.fetch_impl(None, None)
    except NotImplementedError:
        pass
    # Test the expected path
    try:
        a_sync_h_t_t_p_client_0.fetch_impl(None, None)
    except NotImplementedError:
        pass
    # Test the expected path
    try:
        a_sync_h_t_t_p_client_0.fetch_impl(None, None)
    except NotImplementedError:
        pass
    # Test the expected

# Generated at 2022-06-26 08:04:17.049107
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.google.com/search?q={}')
    http_client = HTTPClient()
    _RequestProxy_0 = _RequestProxy(request, {})
    _RequestProxy_0.request = HTTPRequest('http://www.google.com/search?q={}')
    _RequestProxy_0.http_client = http_client

# Generated at 2022-06-26 08:04:36.050123
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    reqs = []  # type: List[Tuple[HTTPRequest, HTTPRequest]]

# Generated at 2022-06-26 08:04:44.982729
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    try:
        test_AsyncHTTPClient_close_0()
    except Exception as exception:
        print('caught exception in test_AsyncHTTPClient_close():', exception)
    try:
        test_AsyncHTTPClient_close_1()
    except Exception as exception:
        print('caught exception in test_AsyncHTTPClient_close():', exception)
        
# Tests expected behaviour of method close of class AsyncHTTPClient when 
# invoked by an instance of AsyncHTTPClient

# Generated at 2022-06-26 08:04:49.634344
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = HTTPClient()
    r_e_q_u_e_s_t_0 = HTTPRequest()
    h_t_t_p_client_0.fetch_impl(r_e_q_u_e_s_t_0, None)



# Generated at 2022-06-26 08:05:00.858788
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os
    from asyncio import get_event_loop
    from tornado import gen
    import time

    @gen.coroutine
    def main(loop):
        pid = os.getpid()
        tmpdir = tempfile.mkdtemp()
        data = b'0123456789'
        file = os.path.join(tmpdir, "file-%d" % pid)

        with open(file, 'wb') as f:
            f.write(data)

        file_url = "file://" + file
        # Wait for an arbitrary amount of time to make sure the file
        # mtime has changed.
        yield gen.sleep(time.time() - os.path.getmtime(file) + 1)

# Generated at 2022-06-26 08:05:03.543814
# Unit test for function main
def test_main():
    # No exception should be thrown
    main()


# Generated at 2022-06-26 08:05:07.810212
# Unit test for function main
def test_main():
    main();


if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:05:15.925310
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
  try:
    # Testing for the default behaviour
    h_t_t_p_client_1 = HTTPClient()
    h_t_t_p_request_1 = HTTPRequest("http://foo.bar/test_case_1")
    h_t_t_p_request_proxy_0 = _RequestProxy(h_t_t_p_request_1, {})
    h_t_t_p_request_proxy_0.__getattr__("foo")

  except Exception as inst:
    assert False


# Generated at 2022-06-26 08:05:19.716757
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    httpclient.fetch("http://www.google.com")


# Generated at 2022-06-26 08:05:21.987179
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:05:35.560488
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    AsyncHTTPClient_0 = AsyncHTTPClient(force_instance=True)
    try:
        assert AsyncHTTPClient_0._instance_cache is None
    except:
        raise RuntimeError()
    try:
        assert AsyncHTTPClient_0.io_loop is not None
    except:
        raise RuntimeError()
    try:
        assert type(AsyncHTTPClient_0.io_loop) is IOLoop
    except:
        raise RuntimeError()
    try:
        assert AsyncHTTPClient_0.defaults == HTTPRequest._DEFAULTS
    except:
        raise RuntimeError()
    try:
        assert AsyncHTTPClient_0._closed is False
    except:
        raise RuntimeError()


# Generated at 2022-06-26 08:05:45.035897
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    h_t_t_p_request_0 = HTTPRequest(
    'http://wwww.test.com',
    method='GET',
    headers={},
    body='',
    validate_cert=False,
    )


# Generated at 2022-06-26 08:05:50.671408
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httputil import HTTPHeaders
    request = HTTPRequest(
        "http://www.example.com",
        method="POST",
        headers=HTTPHeaders({"Content-Length": "0"}),
        body="q=example",
        allow_nonstandard_methods=True,
    )
    c = AsyncHTTPClient()
    a_response_0 = c.fetch_impl(request, None)


# Generated at 2022-06-26 08:05:51.263233
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:05:57.095500
# Unit test for function main
def test_main():
    # Form expected output from test_main
    import os
    import sys
    import platform
    import inspect
    test_main_path = os.path.abspath(inspect.getfile(inspect.currentframe()))
    test_main_dir = os.path.dirname(test_main_path)
    test_main_folder = os.path.basename(test_main_dir)
    test_main_root = test_main_dir[:test_main_dir.rfind(test_main_folder)]
    test_main_expected_output = os.path.join(test_main_root,
        'test_output', 'test_main', 'expected_output.txt')

    # Capture output from function main
    capturedoutput = io.StringIO()
    sys.stdout = capturedoutput

    # Store old

# Generated at 2022-06-26 08:06:09.612495
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = test_AsyncHTTPClient()
    h_t_t_p_client_1 = test_AsyncHTTPClient()
    h_t_t_p_client_3 = h_t_t_p_client_0.__new__(test_AsyncHTTPClient)
    h_t_t_p_client_2 = test_AsyncHTTPClient()
    h_t_t_p_client_2.__init__()
    assert h_t_t_p_client_0 == h_t_t_p_client_1
    assert h_t_t_p_client_0 != h_t_t_p_client_3
    assert h_t_t_p_client_2 == h_t_t_p_client_3


# Generated at 2022-06-26 08:06:11.504966
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:06:13.093998
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 08:06:20.993031
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest

    captured_stdout = io.StringIO()
    sys.stdout = captured_stdout

    testcase_0 = unittest.FunctionTestCase(test_case_0)
    unittest.TextTestRunner().run(testcase_0)

    sys.stdout = sys.__stdout__
    print("Captured stdout:\n%s" % captured_stdout.getvalue())

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 08:06:24.631003
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:06:30.337998
# Unit test for function main
def test_main():
    print("Test main")
    try:
        main()
    except HTTPError as e:
        raise AssertionError("test_main() raised HTTPError")
    else:
        pass


# Generated at 2022-06-26 08:06:37.585273
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = HTTPClient()


# Generated at 2022-06-26 08:06:52.740624
# Unit test for method __getattr__ of class _RequestProxy

# Generated at 2022-06-26 08:06:54.314785
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:06:57.413848
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    h_t_t_p_client_0 = HTTPClient()

test_HTTPClient()

# Generated at 2022-06-26 08:07:09.556821
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # test interface
    http_request = HTTPRequest()
    callback = lambda x: x

    # test whether the interface can be called
    try:
        AsyncHTTPClient.fetch_impl(http_request, callback)
    except NotImplementedError:
        # expected error
        pass
    except Exception:
        assert False, 'Unexpected exception'

    # is called and finished
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        assert response.code == 200, 'Unexpected response code'
    except httpclient.HTTPError as e:
        assert False, 'Unexpected Exception'
    except Exception as e:
        assert False, 'Unexpected Exception'
    http_client.close()



# Generated at 2022-06-26 08:07:11.887111
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    print("Testing AsyncHTTPClient.close ...")
    # Method is not implemented
    pass


# Generated at 2022-06-26 08:07:22.564175
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-26 08:07:24.223498
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:07:32.359484
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    client = AsyncHTTPClient()
    def handle_response(response):
        print("response2")
        print(response)
    request = HTTPRequest("https://baidu.com")
    client.fetch_impl(request, handle_response)
    # try:
    #     response = h_t_t_p_client_0.fetch("https://baidu.com")
    #     print(response.body)
    #     print(response.headers)
    # except HTTPError as e:
    #     print("Error: " + str(e))
    # except Exception as e:
    #     print("Error: " + str(e))
    # h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:37.361126
# Unit test for function main
def test_main():
    h_t_t_p_client_0 = HTTPClient()
    try:
        response = h_t_t_p_client_0.fetch('test_url', follow_redirects=True, validate_cert=True, proxy_host=None, proxy_port=80, request_timeout=3)
        # print(response.headers)
        # print(native_str(response.body))
    except HTTPError as e:
        if e.response is not None:
            response = e.response
        else:
            raise
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:47.261895
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:07:50.485559
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    url = "http://www.google.com"
    request = HTTPRequest(url = url)
    h_t_t_p_client = AsyncHTTPClient()
    callback = h_t_t_p_client.fetch_impl(request, None)



# Generated at 2022-06-26 08:07:54.992572
# Unit test for function main
def test_main():
    from tornado.options import options, define
    from tornado.log import enable_pretty_logging
    enable_pretty_logging()
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    arguments = ['http://www.google.ca']
    main()


# Generated at 2022-06-26 08:07:59.626209
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # h_t_t_p_client_0 = AsyncHTTPClient()
    # print(h_t_t_p_client_0)
    print('test_AsyncHTTPClient_initialize')
    # h_t_t_p_client_0.initialize()
    # print(h_t_t_p_client_0)


# Generated at 2022-06-26 08:08:03.943609
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Instantiating the class
    request = HTTPRequest('http://www.google.com/')
    # Instantiating the class
    defaults = HTTPClient()
    _RequestProxy_0 = _RequestProxy(request, defaults)
    # var = _RequestProxy_0.__getattr__('method')


# Generated at 2022-06-26 08:08:06.290233
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:08:18.847925
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()
    assertTrue(isinstance(h_t_t_p_client_0, AsyncHTTPClient), "Expected a AsyncHTTPClient")
    assertTrue(isinstance(h_t_t_p_client_0, AsyncHTTPClient), "Expected a AsyncHTTPClient")
    assertTrue(isinstance(h_t_t_p_client_0, AsyncHTTPClient), "Expected a AsyncHTTPClient")
    assertTrue(isinstance(h_t_t_p_client_0, AsyncHTTPClient), "Expected a AsyncHTTPClient")
    h_t_t_p_client_0.initialize({})
    assertTrue(not h_t_t_p_client_0._closed, "Expected a not value")

# Generated at 2022-06-26 08:08:22.585712
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Initialize objects
    url_0 = "http://localhost/?"

    # Body of method
    async_http_client_0 = AsyncHTTPClient()
    future_0 = async_http_client_0.fetch(url_0)



# Generated at 2022-06-26 08:08:28.073346
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # create an instance of class AsyncHTTPClient
    #call method fetch of class AsyncHTTPClient
    temp_future = AsyncHTTPClient().fetch("example.com")
    #assert instance of class Future
    assert temp_future == Future()


# Generated at 2022-06-26 08:08:30.483415
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:08:47.151142
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # We initialize a Request object
    request: HTTPRequest = HTTPRequest(url='http://www.google.com')
    # We initialize a IOLoop object
    io_loop: IOLoop = IOLoop.current()
    # We initialize an instance of class AsyncHTTPClient
    async_http_client_0: AsyncHTTPClient = AsyncHTTPClient()
    # We call method initialize of async_http_client_0
    async_http_client_0.initialize(request)


# Generated at 2022-06-26 08:08:48.927805
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client = AsyncHTTPClient()
    http_client.close()


# Generated at 2022-06-26 08:08:55.706679
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_request_0 = HTTPRequest()
    callback_0 = lambda response: response
    try:
        h_t_t_p_client_0 = AsyncHTTPClient()
    except:
        h_t_t_p_client_0 = AsyncHTTPClient()
        raise RuntimeError("Failed to create instance of object AsyncHTTPClient")

    try:
        h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, callback_0)
    except:
        pass


# Generated at 2022-06-26 08:08:59.513712
# Unit test for function main
def test_main():
    main()

# Generated by Mypy
if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    test_main()
    test_case_0()

# Generated at 2022-06-26 08:09:05.753907
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Create an instance of class AsyncHTTPClient
    force_instance_0 = True
    kwargs_0 = dict()
    async_h_t_t_p_client_0 = AsyncHTTPClient(force_instance=force_instance_0, **kwargs_0)


# Generated at 2022-06-26 08:09:07.636054
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e, type(e))

# Generated at 2022-06-26 08:09:11.120694
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()

    # test for method close of class AsyncHTTPClient

    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:09:16.600224
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    print("Testing AsyncHTTPClient.initialize() ...")
    # initialize
    async_http_client_0 = AsyncHTTPClient()
    async_http_client_0.initialize()
    print("AsyncHTTPClient.initialize() tested")


# Generated at 2022-06-26 08:09:23.041756
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    class MockAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self):
            pass

    mock_async_h_t_t_p_client = MockAsyncHTTPClient()  # type: Optional[MockAsyncHTTPClient]

    # Case 1
    try:
        mock_async_h_t_t_p_client.close()
        mock_async_h_t_t_p_client.fetch("http://www.google.com")
    except RuntimeError:
        pass

    # Case 2
    try:
        AsyncHTTPClient("http://www.google.com")
    except TypeError:
        pass



# Generated at 2022-06-26 08:09:31.837496
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def bar(x: int, y: int) -> int:
        return x + y

    # Test without paramas
    #async_h_t_t_p_client_0 = AsyncHTTPClient()

    # Test with params
    #request = HTTPRequest()
    #async_h_t_t_p_client_0.fetch_impl(request, bar)
    #async_h_t_t_p_client_0.fetch_impl(request, bar)(5, 10)
    #request = object()
    #async_h_t_t_p_client_0.fetch_impl(request, bar)
    #async_h_t_t_p_client_0.fetch_impl(request, bar)(5, 10)

    return 0


# Generated at 2022-06-26 08:09:43.951057
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    test_AsyncHTTPClient_close_args_0 = object()
    test_AsyncHTTPClient_close_args_1 = object()
    test_AsyncHTTPClient_close_args_2 = object()
    test_AsyncHTTPClient_close_args_3 = object()
    test_AsyncHTTPClient_close_args_4 = object()
    test_AsyncHTTPClient_close_args_5 = object()
    test_AsyncHTTPClient_close_args_6 = object()
    test_AsyncHTTPClient_close_args_7 = object()
    test_AsyncHTTPClient_close_args_8 = object()
    test_AsyncHTTPClient_close_args_9 = object()
    test_AsyncHTTPClient_close_args_10 = object()
    test_AsyncHTTPClient_close_args_11 = object()
    test_AsyncHTTPClient_

# Generated at 2022-06-26 08:09:45.367082
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # http_client = AsyncHTTPClient()
    # http_client.close()
    pass


# Generated at 2022-06-26 08:09:46.933182
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    
    # h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0 = AsyncHTTPClient()
    
    


# Generated at 2022-06-26 08:09:54.306066
# Unit test for function main
def test_main():
    assert True
    # No input.
    try:
      main()
      assert False
    except SystemExit:
      assert True
    # No input.
    try:
      main()
      assert False
    except SystemExit:
      assert True

if __name__ == "__main__":
    import logging as logger
    logger.basicConfig(level=logger.DEBUG)
    test_main()
    test_case_0()

# Generated at 2022-06-26 08:10:09.466942
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    # check instance type from __new__
    ioloop_0 = IOLoop.current()
    AsyncHTTPClient.configure(SimpleAsyncHTTPClient)
    h_t_t_p_client_0 = AsyncHTTPClient()
    assert isinstance(h_t_t_p_client_0, SimpleAsyncHTTPClient)
    assert h_t_t_p_client_0._instance_cache == AsyncHTTPClient._async_clients()
    assert ioloop_0 in h_t_t_p_client_0._instance_cache
    h_t_t_p_client_1 = AsyncHTTPClient()
    assert h_t_t_p_client_1 is h_t_t_p_client_0
    assert h_t_t_p_client_1._instance_cache == As

# Generated at 2022-06-26 08:10:11.499868
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async_http_client_0 = AsyncHTTPClient()
    async_http_client_0.initialize(defaults=None)


# Generated at 2022-06-26 08:10:16.327840
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_request_0 = HTTPRequest()
    print("Testing fetch_impl of class AsyncHTTPClient...")
    h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, None)
    print("Success!")


# Generated at 2022-06-26 08:10:17.989444
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    assert isinstance(AsyncHTTPClient(), AsyncHTTPClient)


# Generated at 2022-06-26 08:10:30.490594
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.defaults = {'method': 'POST', 'body': None}
    h_t_t_p_client_0.request = h_t_t_p_client_0.HTTPRequest('http://127.0.0.1/', 'GET')
    request_proxy_0 = _RequestProxy(h_t_t_p_client_0.request, h_t_t_p_client_0.defaults)
    assert request_proxy_0._RequestProxy__getattr__('connect_timeout') == h_t_t_p_client_0.request.connect_timeout
    assert request_proxy_0._RequestProxy__getattr__('auth_mode') == h_t_t_p_client

# Generated at 2022-06-26 08:10:42.227338
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async_http_client_0 = AsyncHTTPClient()
    async_http_client_1 = AIOHTTPClient()
    request_0 = HTTPRequest()
    request_1 = HTTPRequest()
    dict_0 = {'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'}
    dict_1 = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'user-agent': 'tornado/6.0a1'}

# Generated at 2022-06-26 08:10:54.512838
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    print("\nUnit test for fetch_impl of AsyncHTTPClient")
    impl = SimpleAsyncHTTPClient(max_clients=10)
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient(impl)
    a_s_y_n_c_h_t_t_p_client_1 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_1.initialize()
    # a_s_y_n_c_h_t_t_p_client_1.fetch_impl(h_t_t_p_request_0, callback_0)
    # a_s_y_n_c_h_t_t_p_client_0.fetch_impl(h_t

# Generated at 2022-06-26 08:10:56.082855
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:10:58.683136
# Unit test for function main
def test_main():
    try:
        main()
    except:
        print('test_main function has failed.')


# Generated at 2022-06-26 08:11:02.635599
# Unit test for function main
def test_main():
    try:
        try:
            test_case_0()
        except:
            import traceback

            traceback.print_exc()

        main()
    except:
        import traceback

        traceback.print_exc()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 08:11:06.704910
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():

    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:11:11.404158
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:11:15.507787
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    try:
        defaults = {'a':0}
        request = HTTPRequest('a.com',method='GET')
        request_proxy = _RequestProxy(request,defaults)

        request_proxy.a
        request_proxy._RequestProxy__getattr__('a')

    except Exception:
        print('Exception occured in method __getattr__ of class _RequestProxy')
        raise

if __name__ == '__main__':
    test_case_0()
    test__RequestProxy___getattr__()

# Generated at 2022-06-26 08:11:17.812908
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 08:11:29.433850
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        from unittest.mock import call
    except ImportError:
        from mock import call
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPResponse
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.log import gen_log
    from tornado.util import Configurable
    from tornado.log import gen_log
    from tornado.log import access_log
    from tornado.log import app_log
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import _RequestProxy
    async def async_magic():
        await gen.sleep(0)
        return "async magic"

# Generated at 2022-06-26 08:11:33.368662
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    with pytest.raises(RuntimeError):
        # Test case where _async_client (previously _closed) is not set
        AsyncHTTPClient().close()
    # Test case where _async_client (previously _closed) is set
    assert not AsyncHTTPClient()._closed
    AsyncHTTPClient().close()
    assert AsyncHTTPClient()._closed
