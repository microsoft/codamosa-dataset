

# Generated at 2022-06-26 08:02:00.361741
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest(url="https://github.com/tornadoweb/tornado/issues/1552")
    code = 200
    reason = "Request was Ok"
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "https://github.com/tornadoweb/tornado/issues/1552"
    error = HTTPError(401, response=HTTPResponse(request=request, code=code, headers=headers, buffer=buffer, effective_url=effective_url), message="Unauthorized")
    request_time = 1.59242312
    time_info = {}
    start_time = 5.68941e-06

    # Invoke the method under test

# Generated at 2022-06-26 08:02:01.188237
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 08:02:07.508693
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Initialization
    request_ = HTTPRequest('GET', 'http://api.adf.ly/api.php?key=5a6e5cc6bf5bd6a5a6e5cc6bf5bd6&uid=5184489&advert_type=int&domain=adf.ly&url=http://www.google.com')
    code_ = 301
    headers_ = None
    buffer_ = None
    effective_url_ = 'http://api.adf.ly/api.php?key=5a6e5cc6bf5bd6a5a6e5cc6bf5bd6&uid=5184489&advert_type=int&domain=adf.ly&url=http://www.google.com'
    error_ = Timeout
    request_time_ = 7.70359802246093

# Generated at 2022-06-26 08:02:18.113932
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    class MockRequest(HTTPRequest):
        def __init__(self):
            super(MockRequest, self).__init__( "GET", "http://www.google.com", callback=None )
    request_0 = MockRequest()
    buffer_0 = BytesIO()
    exception_0 = HTTPError(500, 'test')
    h_t_t_p_response_0 = HTTPResponse(request_0, 500, error=exception_0, buffer=buffer_0)
    if h_t_t_p_response_0.error:
        with pytest.raises(HTTPError) as exception_1:
            h_t_t_p_response_0.rethrow()
        assert exception_1.value.code == 500
        assert exception_1.value.message == 'test'

# Generated at 2022-06-26 08:02:23.585694
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Setup
    pyFunceble.LOAD.UnLoad()  # UnLoad all the loggers.
    pyFunceble.LOAD.Load(load_stats=False)  # Load all the loggers.

    # Do the test here.
    test_case_0()

    # Show the final status of the tests.
    pyFunceble.HELPER.htaccess_helper.FinalTestStatus()


# Generated at 2022-06-26 08:02:24.488318
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    test_case_0()
    test_main()

# Generated at 2022-06-26 08:02:37.708892
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    response = HTTPResponse(async_h_t_t_p_client_0, 200)
    args = ",".join("%s=%r" % i for i in sorted(response.__dict__.items()))

# Generated at 2022-06-26 08:02:50.782554
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    h_t_t_p_response_0 = HTTPResponse(
        h_t_t_p_request_0 = 'h_t_t_p_request_0',
        code = 'code',
        headers = None,
        buffer = None,
        effective_url = None,
        error = None,
        request_time = None,
        time_info = None,
        reason = None,
        start_time = None)
    str_0 = h_t_t_p_response_0.__repr__()
    assert str_0 == 'HTTPResponse(code=code,error=None,request=h_t_t_p_request_0,request_time=None,start_time=None)'


# Generated at 2022-06-26 08:03:02.440438
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    def thread_func_0(func_0, args_0):
        func_0(args_0)
    thread_0 = threading.Thread(target=thread_func_0, args=(test_case_0, None))
    thread_0.start()
    h_t_t_p_response_0 = HTTPResponse(async_h_t_t_p_client_0, 0)
    h_t_t_p_response_0.rethrow()
    print(h_t_t_p_response_0.__repr__())
    print(h_t_t_p_response_0.__repr__())

# Generated at 2022-06-26 08:03:04.026290
# Unit test for function main
def test_main():
    main()

#if __name__ == "__main__":
#    main()

# Generated at 2022-06-26 08:03:18.833341
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    async def async_fetch(http_client):
        request = HTTPRequest(url='http://www.baidu.com/')
        response = await http_client.fetch(request)
        utf8(response.body)

    async def main():
        http_client = HTTPClient()
        await async_fetch(http_client)
        http_client.close()

    try:
        IOLoop.current().run_sync(main)
    except Exception as err:
        print(err)


# Generated at 2022-06-26 08:03:21.218597
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    AsyncHTTPClient().fetch_impl(HTTPRequest(url="https://www.google.com"), lambda response: response)


# Generated at 2022-06-26 08:03:23.795485
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    future = test_case_0()
    if not future.done():
        future.set_result(None)
    assert future.done()


# Generated at 2022-06-26 08:03:28.396358
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)
        finally:
            http_client.close()

    IOLoop.current().run_sync(f)


# Generated at 2022-06-26 08:03:28.871438
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    pass

# Generated at 2022-06-26 08:03:31.814000
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    try:
        AsyncHTTPClient().initialize()
        assert 1 == 0
    except:
        assert 1 == 1


# Generated at 2022-06-26 08:03:34.855667
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    http_response = HTTPResponse(None, 200)
    http_response.error = HTTPError(404)
    http_response.rethrow()


# Generated at 2022-06-26 08:03:37.469818
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-26 08:03:43.798795
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    # req = HTTPRequest(url="http://www.google.com/")
    # client = HTTPClient()
    # resp = client.fetch(req)
    # print(resp.body)
    # client.close()
    test_case_0()


# Generated at 2022-06-26 08:03:45.811991
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # TODO: Test function body
    pass


# Generated at 2022-06-26 08:04:04.453889
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-26 08:04:09.720718
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Create an instance of the AsyncHTTPClient class.
    async_http_client_0 = AsyncHTTPClient()
    # Close the client.
    async_http_client_0.close()


# Generated at 2022-06-26 08:04:13.007490
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

    main()

# Generated at 2022-06-26 08:04:26.095689
# Unit test for method fetch of class AsyncHTTPClient

# Generated at 2022-06-26 08:04:30.435402
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    # Unit test for function test_case_0
    test_case_0()
    # Unit test for function main
    test_main()

# Generated at 2022-06-26 08:04:31.558551
# Unit test for function main
def test_main():
    main()

test_main()

# Generated at 2022-06-26 08:04:35.615762
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Setup
    # Implementation
    h_t_t_p_client_0 = None # type: Optional[AsyncHTTPClient]

    # Testing
    h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:04:41.415297
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test with argument force_instance=True
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient(True)
    # Ternary operator
    x_0 = 3 if True else 2
    assert x_0 == 3


# Generated at 2022-06-26 08:04:52.599292
# Unit test for method __getattr__ of class _RequestProxy

# Generated at 2022-06-26 08:04:58.368689
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_1 = AsyncHTTPClient()
    assert h_t_t_p_client_1.io_loop is not None
    assert h_t_t_p_client_1.defaults == HTTPRequest._DEFAULTS
    assert not h_t_t_p_client_1._closed


# Generated at 2022-06-26 08:05:23.795170
# Unit test for method __getattr__ of class _RequestProxy

# Generated at 2022-06-26 08:05:28.501448
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # local variable
    request = HTTPRequest()
    defaults = dict()
    _RequestProxy(request, defaults).__getattr__("")
    _RequestProxy(request, None).__getattr__("")


# Generated at 2022-06-26 08:05:40.983583
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():

    # Normal case use
    h_t_t_p_request_0 = HTTPRequest("http://www.baidu.com")

    # Normal case use
    h_t_t_p_request_1 = HTTPRequest("http://www.baidu.com", "GET")

    # Normal case use
    h_t_t_p_request_2 = HTTPRequest("http://www.baidu.com", "GET", {})

    # Normal case use
    h_t_t_p_request_3 = HTTPRequest("http://www.baidu.com", "GET", {}, "")

    # Normal case use
    h_t_t_p_request_4 = HTTPRequest("http://www.baidu.com", "GET", {}, "", "")

    # Normal case use
    h_t

# Generated at 2022-06-26 08:05:45.997057
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()
    h_t_t_p_client_0.close()


# Unit tests for method close of class HTTPClient

# Generated at 2022-06-26 08:05:50.213625
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    h_t_t_p_client_0 = HTTPClient()
    request_0 = HTTPRequest("https://www.baidu.com")
    response_0 = h_t_t_p_client_0.fetch(request_0)
    print(response_0.code)


# Generated at 2022-06-26 08:05:51.367546
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    test_case_0()


# Generated at 2022-06-26 08:05:52.963556
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    assert 'AsyncHTTPClient' == AsyncHTTPClient.__name__
    print('AsyncHTTPClient is not implemented yet')



# Generated at 2022-06-26 08:05:58.718720
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()
    h_t_t_p_client_1 = HTTPClient()
    h_t_t_p_client_1.close()
    h_t_t_p_client_2 = HTTPClient()
    h_t_t_p_client_2.close()
    h_t_t_p_client_3 = HTTPClient()
    h_t_t_p_client_3.close()
    h_t_t_p_client_4 = HTTPClient()
    h_t_t_p_client_4.close()
    h_t_t_p_client_5 = HTTPClient()
    h_t_t_p_client_5.close()
   

# Generated at 2022-06-26 08:05:59.840646
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    AsyncHTTPClient().close()


# Generated at 2022-06-26 08:06:12.470973
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # __init__
    '''
    def __init__(
        self,
        io_loop: Optional[asyncio.AbstractEventLoop] = None,
        force_instance: bool = False,
        **kwargs: Any
    ) -> None:
    '''
    # initialize
    '''
    def initialize(self, defaults: Optional[Dict[str, Any]] = None) -> None:
    '''
    AsyncHTTPClient().initialize()
    # initialize
    '''
    def initialize(self, defaults: Optional[Dict[str, Any]] = None) -> None:
    '''
    AsyncHTTPClient().initialize(defaults=None)
    # initialize
    '''
    def initialize(self, defaults: Optional[Dict[str, Any]] = None) -> None:
    '''

# Generated at 2022-06-26 08:06:37.759446
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    assert isinstance(AsyncHTTPClient, object)
    AsyncHTTPClient.initialize(None)


# Generated at 2022-06-26 08:06:44.566768
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_1 = AsyncHTTPClient(force_instance = True)



# Generated at 2022-06-26 08:06:46.671446
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:06:48.501122
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    AsyncHTTPClient_0=AsyncHTTPClient()
    AsyncHTTPClient_0.close()


# Generated at 2022-06-26 08:06:52.200708
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # initialization
    h_t_t_p_client_0 = AsyncHTTPClient()
    # function call
    h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:06:59.957001
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0 = HTTPClient()
    # h_t_t_p_client_0.fetch("https://httpbin.org/get")
    h_t_t_p_client_0.fetch("https://httpbin.org/get")



# Generated at 2022-06-26 08:07:08.279276
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_request_0 = HTTPRequest('http://example.com/blah')
    def handle_response(response):
        pass
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, handle_response)


# Generated at 2022-06-26 08:07:09.907072
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:11.787849
# Unit test for function main
def test_main():
    main()

test_main()
test_case_0()
print("Everything executed")

# Generated at 2022-06-26 08:07:18.434804
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # Force creation of a new client
    async_h_t_t_p_client_1 = AsyncHTTPClient(force_instance=True)
    async_h_t_t_p_client_0.close()
    async_h_t_t_p_client_1.close()


# Generated at 2022-06-26 08:07:40.119147
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Create AsyncHTTPClient object
    h_t_t_p_client = AsyncHTTPClient()
    request = HTTPRequest('http://localhost:8080/')
    callback = lambda response: print(response.body)
    # Call method fetch_impl of object h_t_t_p_client with arguments request and callback
    h_t_t_p_client.fetch_impl(request, callback)


# Generated at 2022-06-26 08:07:43.960472
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    def test_close():
        async_h_t_t_p_client_0 = AsyncHTTPClient()
        # Begin with a call to the method under test
        async_h_t_t_p_client_0.close()

    test_close()


# Generated at 2022-06-26 08:07:55.359421
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    Method_Fetch_Impl = AsyncHTTPClient.fetch_impl
    http_request_0 = HTTPRequest(method='GET', url='http://www.google.com')
    callback_0 = lambda response: None
    return_value_0 = Method_Fetch_Impl(http_request_0, callback_0)
    return return_value_0

    return return_value_0

if __name__ == '__main__':
    test_AsyncHTTPClient_fetch_impl()

# Generated at 2022-06-26 08:07:57.152603
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-26 08:08:00.252236
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as inst:
        print(type(inst))
        print(inst.args)
        print(inst)
        raise


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:08:02.146466
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    # Unit test main
    test_main()

# Generated at 2022-06-26 08:08:05.091961
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:08:07.855931
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    global h_t_t_p_client_0
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:08:16.021073
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
  if __name__ == '__main__':
    #prepare test data
    request_0 = HTTPRequest('report.html')
    callback_0 = None
    #execute test
    try:
      h_t_t_p_client_0 = AsyncHTTPClient()
      h_t_t_p_client_0.fetch_impl(request_0, callback_0)
    except ValueError as e:
      print('Could not execute test, exception: ' + str(e))
    else:
      print('Test completed')


# Generated at 2022-06-26 08:08:17.842221
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()


# Generated at 2022-06-26 08:08:43.495013
# Unit test for function main
def test_main():
    # TODO: Crash on this function
    return
    main()

args2 = ["http://www.google.com"]


# Generated at 2022-06-26 08:08:54.691209
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    url = "abc"
    raise_error = False
    fetch_kwargs = {}
    return_from_fetch = None

    class TestClass:
        pass

    test_obj = TestClass()
    setattr(test_obj, "fetch", lambda request, callback: None)

    def parse_url(url):
        return url

    def extract_host_port(parsed):
        return parsed.netloc

    def is_valid_ip(host):
        return host.isdigit()

    def ip_address(host):
        return host

    def print_message_and_exit(msg):
        pass

    def get_ssl_certificate(host, port):
        return None

    def get_ssl_certificate_hostname(ssl_cert, host_port):
        return None


# Generated at 2022-06-26 08:08:56.376676
# Unit test for function main
def test_main():
    pass



if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:08:59.156066
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    # Implicitly covered by test_simple_httpclient.py
    pass


# Generated at 2022-06-26 08:09:02.334840
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    import timeit
    print(timeit.timeit("test_case_0()", setup="from __main__ import test_case_0", number=1))
    print(timeit.timeit("test_main()", setup="from __main__ import test_main", number=1))

# Generated at 2022-06-26 08:09:07.216312
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Initialize an object of class AsyncHTTPClient
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # Unit test for method close of class AsyncHTTPClient
    async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:09:11.174832
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:09:12.366465
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:09:17.062755
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest()
    defaults = {'key': 'value'}
    rp = _RequestProxy(request, defaults)
    assert(rp.key == 'value')


# Generated at 2022-06-26 08:09:19.259358
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient(force_instance=True)


# Generated at 2022-06-26 08:09:54.928698
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    def test_case_0():
        _RequestProxy_0 = _RequestProxy(HTTPRequest('url', 'method'), 'defaults')
        _RequestProxy_0.request.__getattr__('attr_name')
        h_t_t_p_response_0 = h_t_t_p_client_0.fetch('url', method='method')
        h_t_t_p_response_0.__getattr__('attr_name')


# Generated at 2022-06-26 08:10:01.984888
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.close()



# Generated at 2022-06-26 08:10:09.824015
# Unit test for function main
def test_main():
    # test_case_0 : Call function without arguments
    try:
        main()
    except HTTPError as e:
        if e.response is not None:
            response = e.response
        else:
            raise
    if options.print_headers:
        print(response.headers)
    if options.print_body:
        print(native_str(response.body))
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:10:12.230356
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:10:21.613449
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-26 08:10:23.729845
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()



# Generated at 2022-06-26 08:10:31.527127
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.initialize(a_s_y_n_c_h_t_t_p_client_0.defaults) # test using default


# Generated at 2022-06-26 08:10:40.632654
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # The following line doesn't work in Python 3, because the
    # class was parametrized by AsyncHTTPClient.
    # h_t_t_p_client_0 = AsyncHTTPClient()
    # The following line is a workaround, but it's not quite
    # the same thing, because the type of h_t_t_p_client_0
    # will be AsyncHTTPClient, not the parameterized class.
    h_t_t_p_client_0 = AsyncHTTPClient.configurable_default()()


# Generated at 2022-06-26 08:10:44.165458
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:10:44.834235
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:11:28.681772
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    # Call the constructor
    h_t_t_p_client = AsyncHTTPClient(force_instance=True)
    # Test attribute closed
    assert h_t_t_p_client._closed == False
    # Test method initialize
    h_t_t_p_client.initialize()
    assert h_t_t_p_client.io_loop == IOLoop.current()
    assert h_t_t_p_client.defaults == {"allow_nonstandard_methods": False, "max_redirects": 20, "user_agent": "AsyncHTTPClient"}
    # Test method close
    h_t_t_p_client.close()
    # Test that method close is idempotent
    h_t_t_p_client.close

# Generated at 2022-06-26 08:11:32.814833
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        h_t_t_p_client_0 = HTTPClient()
        h_t_t_p_request_0 = HTTPRequest('/')
        h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, lambda x: x)
    except Exception:
        pass


# Generated at 2022-06-26 08:11:35.243842
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    async_http_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:11:36.674728
# Unit test for function main
def test_main():
    main()
