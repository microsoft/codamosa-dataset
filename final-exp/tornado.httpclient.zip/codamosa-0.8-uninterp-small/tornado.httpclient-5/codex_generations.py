

# Generated at 2022-06-26 08:01:52.957137
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():

    h_t_t_p_request_0 = HTTPRequest()
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_request_0, 400)
    try:
        h_t_t_p_response_0.rethrow()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 08:01:59.838070
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Create a new 'AsyncHTTPClient' object
    obj = AsyncHTTPClient()
    request = HTTPRequest()
    callback = lambda HTTPResponse : None
    # Invoke method
    try:
        obj.fetch_impl(request, callback)
    except NotImplementedError as error:
        # Operation not implemented
        print('Operation not implemented')


# Generated at 2022-06-26 08:02:05.978424
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    print("*********************************************************")
    print("Unit test for method fetch_impl of class AsyncHTTPClient")
    print("*********************************************************")
    async_h_t_t_p_client = AsyncHTTPClient()
    request = HTTPRequest()
    response = HTTPResponse()
    callback = lambda e: e
    exception = NotImplementedError
    print("Test 1: Normal, Test exception thrown")
    try:
        async_h_t_t_p_client.fetch_impl(request, callback)
        print("Test case pass")
    except exception:
        print("Test case fail")



# Generated at 2022-06-26 08:02:07.723256
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:12.677719
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.fetch((h_t_t_p_client_0))


# Generated at 2022-06-26 08:02:19.292393
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    s_0 = 'https://jsonplaceholder.typicode.com/posts'
    http_request_0 = HTTPRequest(url=s_0, method='GET')
    http_client_0 = AsyncHTTPClient()
    s_1 = 'http://jsonplaceholder.typicode.com/posts'
    http_request_1 = HTTPRequest(url=s_1, method='GET', body='aaaaaaaaaaaa')
    future_0 = http_client_0.fetch(request=s_1, raise_error=True, headers={'user-agent': 'curl/7.64.0'})
    m_0 = future_0.result().body
    print(m_0)


# Generated at 2022-06-26 08:02:30.466609
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Create mock object
    if _is_py37:
        _HTTPResponse__self = Mock(spec=HTTPResponse)
    else:
        _HTTPResponse__self = Mock(spec_set=HTTPResponse)
    _HTTPResponse__self.error = None
    h_t_t_p_response_0 = HTTPResponse(_HTTPResponse__self, 200, None, None)
    # Call method
    h_t_t_p_response_0.rethrow()
    # Check if called correct method in mock object
    assert (_HTTPResponse__self.rethrow.call_count == 1)


# Generated at 2022-06-26 08:02:34.202026
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    print("\n=== Unit test for method __new__ of class AsyncHTTPClient ===")
    async_h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:02:44.041938
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    url_0 = 'https://www.google.com'
    h_t_t_p_request_0 = HTTPRequest(url=url_0, method='GET')
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    future_0 = async_h_t_t_p_client_0.fetch(request=h_t_t_p_request_0, raise_error=True)
    future_0.add_done_callback(lambda x: print(x.result()))
    
    # assert False # TODO: implement your test here


# Generated at 2022-06-26 08:02:49.577208
# Unit test for function main
def test_main():

    # Unit test for Tornado (http_client.py) ClientError on
    # tornado.testing.AsyncHTTPTestCase object

    # SUT
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:03:06.111121
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient", max_clients=10, defaults={"connect_timeout": 20.0, "request_timeout": 600.0, "validate_cert": True})

    try:
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
        AsyncHTTPClient()
    except AttributeError as e:
        pass
    except Exception as e:
        pass
    finally:
        AsyncHTTPClient.close()



# Generated at 2022-06-26 08:03:08.883464
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    force_instance = False
    kwargs = {}
    AsyncHTTPClient.__new__(force_instance, **kwargs)


# Generated at 2022-06-26 08:03:17.138513
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request_0 = HTTPRequest(url_2='http://www.baidu.com', headers=61, ca_certs_0=768, allow_ipv6_0=976, body_producer_0=856, decompress_response_0=703, user_agent_0=47, if_modified_since_0=57, auth_mode_0=591)
    _RequestProxy_0 = _RequestProxy(request_0, defaults)
    for var_0 in range(0, 10):
        _RequestProxy_0.__getattr__('headers')


# Generated at 2022-06-26 08:03:19.988713
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 08:03:21.755234
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 08:03:22.406253
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    test_AsyncHTTPClient__new__0()


# Generated at 2022-06-26 08:03:25.308949
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # try:
    #     test1 = AsyncHTTPClient.close()
    #     test2 = AsyncHTTPClient.close()
    # except:
    #     pass
    pass




# Generated at 2022-06-26 08:03:41.842062
# Unit test for method fetch of class AsyncHTTPClient

# Generated at 2022-06-26 08:03:48.394821
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    import sys
    if len(sys.argv)==2 and sys.argv[1] == "--test":
        test_main()
    else:
        main()

# Generated at 2022-06-26 08:03:55.709288
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    import tempfile

    tmp_file = tempfile.mkstemp()[1]
    open(tmp_file, 'a').close()  # touch
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line([tmp_file])
    if len(args) != 1 or args[0] != tmp_file:
      raise RuntimeError


# Generated at 2022-06-26 08:04:08.764554
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    h_t_t_p_client_instance: HTTPClient = HTTPClient()
    assert isinstance(h_t_t_p_client_instance, HTTPClient)


# Generated at 2022-06-26 08:04:10.947859
# Unit test for function main
def test_main():
    main()
    pass

if __name__ == "__main__":
    test_main()
    pass

# Generated at 2022-06-26 08:04:15.169189
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:04:16.384553
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-26 08:04:27.440184
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()


# Generated at 2022-06-26 08:04:40.528695
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    URL = "http://www.google.com"
    with HTTPRequest(URL) as req:
        assert req.url == URL, "Wrong URL"
        assert req.method == "GET", "Wrong method"
        assert isinstance(req.headers, httputil.HTTPHeaders), "not an instance of httputil.HTTPHeaders"
        assert req.body is None, "Body not None"
        assert req.auth_username is None, "Auth_username not None"
        assert req.auth_password is None, "Auth_password not None"
        assert req.auth_mode is None, "Auth_mode not None"
        assert req.connect_timeout == 20.0, "Wrong connect_timeout"
        assert req.request_timeout == 20.0, "Wrong request_timeout"
        assert req.follow_red

# Generated at 2022-06-26 08:04:43.259414
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    request = HTTPRequest()
    callback = lambda response: response
    AsyncHTTPClient.fetch_impl(request, callback)

# Generated at 2022-06-26 08:04:46.877526
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    defaults = dict()
    request = HTTPRequest("http://www.google.com")
    request_proxy_0 = _RequestProxy(request, defaults)
    code = request_proxy_0.code


# Generated at 2022-06-26 08:04:50.944577
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    defaults_list_0 = []
    h_t_t_p_client_0.initialize(defaults_list_0)
    assert h_t_t_p_client_0._closed == 0


# Generated at 2022-06-26 08:04:56.300764
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Create an instance of _RequestProxy
    h_t_t_p_client_3 = _RequestProxy()

    # Call method to test
    try:
        h_t_t_p_client_3.__getattr__(None)
    except NotImplementedError:
        pass



# Generated at 2022-06-26 08:05:10.146816
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-26 08:05:14.840972
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Create an instance of class AsyncHTTPClient
    _AsyncHTTPClient_0 = AsyncHTTPClient()
    # Call method fetch of class AsyncHTTPClient
    response = _AsyncHTTPClient_0.fetch("https://www.google.com/")


# Generated at 2022-06-26 08:05:19.224659
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:05:27.786484
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_1 = HTTPClient()
    request_1 = HTTPRequest(method='GET', url='/api/order/delete')
    request_1.headers['X-Requested-With'] = 'XMLHttpRequest'
    request_1.headers['Referer'] = 'http://www.example.com/order/list'
    request_1.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.6756.400 QQBrowser/10.3.2473.400'

# Generated at 2022-06-26 08:05:33.105860
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    a_s_y_n_c_h_t_t_p_cl_i_ent_0 = AsyncHTTPClient(force_instance=True)
    a_s_y_n_c_h_t_t_p_cl_i_ent_1 = AsyncHTTPClient()


# Generated at 2022-06-26 08:05:37.460035
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    force_instance_0 = True
    test_AsyncHTTPClient___new__0 = AsyncHTTPClient(force_instance_0)
    test_AsyncHTTPClient___new__0.close()
    force_instance_0 = False
    test_AsyncHTTPClient___new__1 = AsyncHTTPClient(force_instance_0)
    test_AsyncHTTPClient___new__1.close()


# Generated at 2022-06-26 08:05:48.999611
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test case:
    request_0 = HTTPRequest()
    callback_0 = handle_response()
    # Test conditions:
    if None not in (request_0, callback_0):
        # test body:
        response_0 = None

# Generated at 2022-06-26 08:05:51.835251
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    # TODO implement this unit test (or refactor so it is not needed anymore)
    pass



# Generated at 2022-06-26 08:06:04.843664
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Define a local class here so it can be passed as an argument to _RequestProxy
    class HTTPRequest_0:
        def __init__(self):
            self.a_t_t_r0 = None
            self.a_t_t_r1 = None
            self.a_t_t_r2 = None

        def get_a_t_t_r0(self):
            return self.a_t_t_r0

        def get_a_t_t_r1(self):
            return self.a_t_t_r1

        def get_a_t_t_r2(self):
            return self.a_t_t_r2

    # Define a local class here so it can be passed as an argument to _RequestProxy

# Generated at 2022-06-26 08:06:16.528265
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    _instance_cache = None  # type: Dict[IOLoop, AsyncHTTPClient]
    _instance_cache = None  # type: Dict[IOLoop, AsyncHTTPClient]
    _instance_cache = None  # type: Dict[IOLoop, AsyncHTTPClient]
    EventLoopKqueue_0 = EventLoopKqueue()
    EventLoopKqueue_1 = EventLoopKqueue()
    EventLoopKqueue_2 = EventLoopKqueue()
    _instance_cache[EventLoopKqueue_0] = EventLoopKqueue_0
    _instance_cache[EventLoopKqueue_1] = EventLoopKqueue_1
    _instance_cache[EventLoopKqueue_2] = EventLoopKqueue_2
    _instance_cache = None  # type: Dict[IOLoop, AsyncHTTPClient

# Generated at 2022-06-26 08:06:40.781311
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    assert True


# Generated at 2022-06-26 08:06:46.716413
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:06:47.402700
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:06:56.180042
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "https://github.com/tornadoweb/tornado"
    url_0 = url
    url_1 = url_0
    url_2 = url_1
    url_3 = url_2
    method_0 = 'GET'
    method_1 = method_0
    method_2 = method_1
    method_3 = method_2
    headers_0 = {}
    headers_1 = headers_0
    headers_2 = headers_1
    headers_3 = headers_2
    body_0 = ""
    body_1 = body_0
    body_2 = body_1
    body_3 = body_2
    auth_username_0 = ""
    auth_username_1 = auth_username_0
    auth_username_2 = auth_username_1
    auth_username_3 = auth

# Generated at 2022-06-26 08:07:01.554834
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    # h_t_t_p_client_0 should be an instance of AsyncHTTPClient
    assert isinstance(h_t_t_p_client_0, AsyncHTTPClient)
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:03.516612
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    unit_test_instance = AsyncHTTPClient()
    unit_test_instance.close()


# Generated at 2022-06-26 08:07:07.602034
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    print("Testing method close of class AsyncHTTPClient")
    # The test is not implemented
    return True


# Generated at 2022-06-26 08:07:08.412808
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:11.051518
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:07:15.585808
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    pass
    # Assign parameters as follows:
    request = None
    defaults = None

    # Call the method
    try:
        _RequestProxy0 = _RequestProxy(request, defaults)
    except Exception as e:
        pass


# Generated at 2022-06-26 08:07:45.562403
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Create an object of HTTPResponse class
    hTTPResponse_0 = HTTPResponse(HTTPRequest("http://httpbin.org/get"), 200, httputil.HTTPHeaders(), BytesIO(), "http://httpbin.org/get", None, None, {}, "OK", None)
    # Try to rethrow the error
    hTTPResponse_0.rethrow()


# Generated at 2022-06-26 08:07:54.621187
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()
    r_0 = "http://www.google.com"
    # Future<HTTPResponse> response = h_t_t_p_client_0.fetch(r_0, True, )
    response = h_t_t_p_client_0.fetch(r_0)
    print(type(response))
    print(type(response.result()))
    print(response.result().code)
    print(response.result().body)


# Generated at 2022-06-26 08:07:56.069501
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    test_case_0()


# Generated at 2022-06-26 08:07:57.001900
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    test_case_0()



# Generated at 2022-06-26 08:07:57.907081
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:08:02.401925
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # test function fetch_impl

    # test argument 'request' of type HTTPRequest
    from .httpclient import HTTPRequest
    h_t_t_p_request_0 = HTTPRequest()

    # test argument 'callback' of type Callable

    # test call of fetch_impl
    test_case_0()


# Generated at 2022-06-26 08:08:06.638160
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Test case 1
    h_t_t_p_client_0 = AsyncHTTPClient()
    # Test case 2
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:08:11.144540
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():

    # Verify the HTTPClient instance is created
    h_t_t_p_client_0 = HTTPClient()
    assert h_t_t_p_client_0 is not None, "ERROR in test_case_0"

import sys
import unittest


# Generated at 2022-06-26 08:08:13.291736
# Unit test for function main
def test_main():
    # Call function main and check its output
    main()


# Generated at 2022-06-26 08:08:15.493123
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client = AsyncHTTPClient()
    http_client.close()


# Generated at 2022-06-26 08:08:51.980806
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    # h_t_t_p_client_0.initialize(defaults = dict(HTTPMethod = None,connect_timeout = None,proxy_host = None,user_agent = None,proxy_port = None,proxy_username = None,proxy_password = None,follow_redirects = None,max_redirects = None,request_timeout = None,use_gzip = None,network_interface = None,allow_nonstandard_methods = None))


# Generated at 2022-06-26 08:08:58.679090
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Arrange
    request = 'http://www.google.com'
    callback = lambda resp: resp.body

    # Act
    # Assert
    try:
        test_case_0().fetch_impl(request, callback)
        print("Correct output")
    except NotImplementedError:
        print("Incorrect output")


# Generated at 2022-06-26 08:09:11.867011
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    """test_AsyncHTTPClient_fetch_impl"""

    print("")
    print("In test_AsyncHTTPClient_fetch_impl")

    # Initialize a mock HTTP request object
    with mock.patch('tornado.httpclient.HTTPResponse') as http_response_mock:
        h_t_t_p_request_0 = HTTPRequest("http://localhost:8080/")
        h_t_t_p_request_0.body = "body"
        h_t_t_p_request_0.method = "GET"
        h_t_t_p_request_0.validate_cert = True
        h_t_t_p_request_0.follow_redirects = True
        h_t_t_p_request_0.use_gzip = True
        h_

# Generated at 2022-06-26 08:09:16.227972
# Unit test for function main
def test_main():
    # test case 0
    test_case_0()
    print('test case 0 passed')
# Boilerplate code
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:09:23.771823
# Unit test for function main
def test_main():
    from mock import MagicMock

    parse_command_line = MagicMock()
    parse_command_line.side_effect = [["arg1", "arg2"], ["arg3", "arg4"]]

    follow_redirects = MagicMock()
    follow_redirects = True

    validate_cert = MagicMock()
    validate_cert = True

    proxy_host = MagicMock()
    proxy_host = "localhost"

    proxy_port = MagicMock()
    proxy_port = 80

    fetch = MagicMock(side_effect=[HTTPResponse({},{"": ""}, 200, None, None, None, None, None, None )])

    print_headers = MagicMock()
    print_headers = True

    print_body = MagicMock()
    print_body = True

    main()


# Generated at 2022-06-26 08:09:25.794492
# Unit test for function main
def test_main():
    main()

# Stop, if the main program is called
if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:09:30.303197
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_request_0 = [HTTPRequest()]
    def callback(response):
        assert response == response
    h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    r = h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0[0], callback)
    assert r == None


# Generated at 2022-06-26 08:09:33.531371
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as err:
        main()
    if 'TypeError' in str(err.value) or 'NameError' in str(err.value):
        assert True
    else:
        assert False


# Generated at 2022-06-26 08:09:38.190099
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_1 = AsyncHTTPClient()
    return h_t_t_p_client_1.initialize(defaults=None)

if __name__ == '__main__':
    test_AsyncHTTPClient_initialize()
    test_case_0()

# Generated at 2022-06-26 08:09:40.427530
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    async_http_client_0 = AsyncHTTPClient(force_instance=True)
    assert type(async_http_client_0) is SimpleAsyncHTTPClient


# Generated at 2022-06-26 08:10:11.087556
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:10:20.607035
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    @gen.coroutine
    def test_case_0():
        import tornado.simple_httpclient
        @gen.coroutine
        def handle_response(response):
            a = response 
            return a
        h_t_t_p_request_0 = tornado.simple_httpclient.HTTPRequest(url='www.google.com')
        a = AsyncHTTPClient()
        a.fetch_impl(h_t_t_p_request_0, handle_response)

    @gen.coroutine
    def test_case_1():
        import tornado.simple_httpclient
        @gen.coroutine
        def handle_response(response):
            a = response 
            return a
        h_t_t_p_request_0 = tornado.simple_httpclient.HTTPRequest(url='www.google.com')

# Generated at 2022-06-26 08:10:28.210469
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    http_client_0 = AsyncHTTPClient()
    def handle_response(response): pass
    http_request_0 = HTTPRequest(url='url_0', headers=httputil.HTTPHeaders())
    http_client_0.fetch_impl(request=http_request_0, callback=handle_response)


# Generated at 2022-06-26 08:10:32.595480
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    test_case_0()
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:10:42.482086
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    try:
        from urllib.parse import urlencode
    except ImportError:
        from urllib import urlencode

#   Generate a valid request for the test bench
    request = HTTPRequest(url="http://127.0.0.1:8000/push?"+urlencode({'Hello':'World'}))

#   Create an object of the test bench
    tb = AsyncHTTPClient()

#   Call the method under test
    try:
        tb.fetch_impl(request, None)
    except NotImplementedError:
        print("pass")
        pass

if __name__ == "__main__":
    test_case_0()
    test_AsyncHTTPClient_fetch_impl()

# Generated at 2022-06-26 08:10:43.261156
# Unit test for function main

# Generated at 2022-06-26 08:10:44.693647
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-26 08:10:50.575142
# Unit test for function main
def test_main():
    try:
        main()
    except:
        print("Exception: {0}".format(sys.exc_info()[0]))
    try:
        test_case_0()
    except:
        print("Exception: {0}".format(sys.exc_info()[0]))


# Generated at 2022-06-26 08:11:03.469614
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Create a new class that subclasses AsyncHTTPClient
    class AsyncHTTPClient_0(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            # Get the value of attribute request
            request_0 = self.request

            # Check if the type of attribute request_0 is HTTPRequest
            if isinstance(request_0, HTTPRequest):
                pass
            else:
                raise TypeError

            # Get the value of attribute callback
            callback_0 = self.callback

            # Check if the type of attribute callback_0 is Callable[[HTTPResponse], None]
            if isinstance(callback_0, Callable[[HTTPResponse], None]):
                pass
            else:
                raise TypeError



# Generated at 2022-06-26 08:11:13.557866
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Create a new subclass of AsyncHTTPClient for testing purposes
    class AsyncHTTPClient_sub(AsyncHTTPClient):
        # Using the overrided method from the parent class
        def fetch_impl(self, request, callback):
            response = HTTPResponse(request, 200)
            callback(response)
    try:
        AsyncHTTPClient_sub().fetch("http://www.google.com")
    except NotImplementedError:
        print("The method fetch_impl is not implemented")
    else:
        print("Method fetch_impl exists in class AsyncHTTPClient")
