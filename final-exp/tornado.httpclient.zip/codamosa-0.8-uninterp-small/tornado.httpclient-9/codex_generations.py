

# Generated at 2022-06-26 08:02:01.569678
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    async_client = AsyncHTTPClient()
    assert type(async_client) == AsyncHTTPClient
    assert type(async_client) == AsyncHTTPClient



# Generated at 2022-06-26 08:02:03.442166
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    return


# Generated at 2022-06-26 08:02:15.629621
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():

    # Case 0
    @gen.coroutine
    def set_up():
        AsyncHTTPClient.configure(
            "tornado.simple_httpclient.SimpleAsyncHTTPClient", max_clients=100
        )
        http_client = AsyncHTTPClient()
        # Example code (user-defined function)
        def handle_response(response: HTTPResponse) -> None:
            if response.error:
                if response._error_is_response_code:
                    print('Error: ' + str(response.error))
            print(response.body)

        # This try-except block is just for handling IOError
        # But this part is not included in the example code

# Generated at 2022-06-26 08:02:23.852932
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import random
    import warnings

    random_int = random.randint(0,2)
    random_int_force_instance = random.randint(0,2)
    if random_int == 1:
        instance_cache = None
    else:
        instance_cache = {[IOLoop]:AsyncHTTPClient}
    if random_int_force_instance == 1:
        force_instance = True
    else:
        force_instance = False

    assert AsyncHTTPClient(force_instance = force_instance, **kwargs).close()


# Generated at 2022-06-26 08:02:30.870611
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    class AsyncHTTPClientStub(AsyncHTTPClient):
        def __init__(self, **kwargs: Any) -> None:
            self._closed = False
            self._io_loop = IOLoop(make_current=False)
    http_client = AsyncHTTPClientStub()
    http_client.close()
    assert http_client._closed == True


# Generated at 2022-06-26 08:02:43.659272
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # create an object of the class AsyncHTTPClient
    obj = AsyncHTTPClient()

    # The defaults are set to "None" before it is changed
    assert obj.defaults == None

    # The io_loop is set to "None" before it is changed
    assert obj._io_loop == None

    # The http_request is set to "None" before it is changed
    assert obj._http_request == None

    # The _closed is set to "True" before it is changed
    assert obj._closed == True

    # perform the actual test
    obj.initialize()

    # The defaults are set to "1" after it is changed
    assert obj.defaults == 1

    # The io_loop is set to "IOLoop" after it is changed
    assert obj._io_loop == IOLoop

    # The http_request

# Generated at 2022-06-26 08:02:53.920556
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        response = response.body
        print(response)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()

#https://github.com/tornadoweb/tornado/blob/master/tornado/httpclient.py

# Generated at 2022-06-26 08:03:06.378300
# Unit test for method rethrow of class HTTPResponse

# Generated at 2022-06-26 08:03:18.411427
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio

    class MainTest(AsyncTestCase):
        @gen_test
        async def test_main(self):
            main()
            #loop = asyncio.get_event_loop()
            #loop.close()
            #main()
            #asyncio.set_event_loop(None)
            #self.io_loop = AsyncIOMainLoop()
            #self.io_loop.make_current()
            #self.io_loop.run_sync(main())

    AsyncIOMainLoop().install()
    MainTest(methodName='test_main').run()

if __name__ == '__main__':
    test_main()
    #test_

# Generated at 2022-06-26 08:03:21.603337
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Build a dummy class to test
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            return None

    # Test code
    request = HTTPRequest(url="http://www.google.com")
    callback = lambda response: None

    # Dummy implementation
    test = TestAsyncHTTPClient()
    test.fetch_impl(request, callback)

    # Real implementation
    test = AsyncHTTPClient()
    test.fetch_impl(request, callback)



# Generated at 2022-06-26 08:04:22.854332
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
  # First test case
  # No exception expected
  AsyncHTTPClient.fetch_impl(object,lambda x : None)


# Generated at 2022-06-26 08:04:34.315459
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_1 = AsyncHTTPClient()
    try:
        response_0 = h_t_t_p_client_1.fetch("http://www.google.com/")
        # print(response_0.body)
    except httpclient.HTTPError as e_0:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e_0))
    except Exception as e_1:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e_1))
    h_t_t_p_client_1.close()


# Generated at 2022-06-26 08:04:37.430819
# Unit test for function main
def test_main():
    h_t_t_p_client_0 = HTTPClient()
    print(h_t_t_p_client_0.max_clients)


# Generated at 2022-06-26 08:04:39.464278
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    AsyncHTTPClient()


# Generated at 2022-06-26 08:04:40.540156
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:04:42.089406
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-26 08:04:47.289967
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_1 = HTTPClient()
    h_t_t_p_request_1 = HTTPRequest(url="", method="")
    h_t_t_p_client_1.fetch_impl(h_t_t_p_request_1, None)


# Generated at 2022-06-26 08:04:56.792804
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # default
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # from __new__, by parameters
    # force_instance is a boolean
    # force_instance has the default value False
    async_h_t_t_p_client_0 = AsyncHTTPClient(force_instance=False)
    # by default, argument force_instance has the default value False
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # force_instance has the default value False
    async_h_t_t_p_client_0 = AsyncHTTPClient(force_instance=False)


# Generated at 2022-06-26 08:05:00.297027
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # test the fetch method
    http_client = AsyncHTTPClient()
    response = http_client.fetch(
        "http://www.tornadoweb.org/en/stable/")
    print(response)


# Generated at 2022-06-26 08:05:09.779373
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():

    def impl_0(self):
        self.defaults = dict()
        self.io_loop = IOLoop.current()
        self._closed = False
        return

    # Test for AsyncHTTPClient.initialize
    # line: 1765
    def impl_1(self, defaults=None):
        self.io_loop = IOLoop.current()
        self.defaults = dict(HTTPRequest._DEFAULTS)
        if defaults is not None:
            self.defaults.update(defaults)
        self._closed = False
        return

    # Test for AsyncHTTPClient.initialize
    # line: 1765
    def impl_2(self, defaults=None):
        self.io_loop = IOLoop.current()
        self.defaults = dict(HTTPRequest._DEFAULTS)

# Generated at 2022-06-26 08:05:55.908595
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass


# Generated at 2022-06-26 08:06:00.788793
# Unit test for function main
def test_main():
    import builtins
    import io

    builtins.print = lambda *args: None
    builtins.input = lambda *args: None
    sys.stdout = io.StringIO()
    main()
    sys.stdout = sys.__stdout__


# Generated at 2022-06-26 08:06:04.882374
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = AsyncHTTPClient()
    # call of fetch_impl
    h_t_t_p_client_0.fetch_impl(request, callback)


# Generated at 2022-06-26 08:06:07.510314
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    c_0 = AsyncHTTPClient()
    c_0.fetch("http://localhost:80")


# Generated at 2022-06-26 08:06:10.859417
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client_0 = AsyncHTTPClient()
    http_client_0.close()
    http_client_1 = AsyncHTTPClient()
    http_client_1.close()


# Generated at 2022-06-26 08:06:13.515015
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:06:22.007206
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Create the HTTPClient
    async_http_client_0 = AsyncHTTPClient()
    # Create the HTTPRequest
    http_request_0 = HTTPRequest('http://placekitten.com/g/1024/768')
    @gen.coroutine
    def gen_fetch(request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]):
        # Call the fetch_impl method of the HTTPClient
        async_http_client_0.fetch_impl(http_request_0, callback)
    gen.Task(gen_fetch)



# Generated at 2022-06-26 08:06:25.097564
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client_0 = HTTPClient()
    http_client_0.close()



# Generated at 2022-06-26 08:06:30.132307
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.initialize(defaults = None)
    return h_t_t_p_client_0


# Generated at 2022-06-26 08:06:37.553055
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Request inbound parameters
    defaults = None
    # Expected result
    expected = None
    # Perform the test
    async_http_client = AsyncHTTPClient()
    async_http_client.initialize()
    # Verify results
    assert async_http_client.defaults == expected

# Compile-time check for type of AsyncHTTPClient.initialize

# Generated at 2022-06-26 08:08:13.764439
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    '''Unit test for method initialize of class AsyncHTTPClient'''
    test_obj = AsyncHTTPClient()
    test_obj.initialize()


# Generated at 2022-06-26 08:08:25.995128
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Case 0:
    #  AsyncHTTPClient._instance_cache = dict()
    #  force_instance = False, **kwargs = None
    #  IOLoop.current() = None
    #  SimpleAsyncHTTPClient.configure(None, defaults=None)
    #  AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient", max_clients=10)
    #  AsyncHTTPClient.__init__(force_instance=False, **kwargs)
    #  SimpleAsyncHTTPClient.__init__(self, io_loop=None, defaults=None)
    #  SimpleAsyncHTTPClient.initialize(defaults=None)
    h_t_t_p_client_0 = AsyncHTTPClient()
     
    # Case 1:
    #  AsyncHTTPClient._instance

# Generated at 2022-06-26 08:08:28.799473
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_1 = HTTPClient()
    h_t_t_p_client_1.close()


# Generated at 2022-06-26 08:08:39.511426
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    print('Running test_case_1')
    request_proxy_0 = _RequestProxy(HTTPRequest(), None)
    setattr(request_proxy_0, '_RequestProxy_request', HTTPRequest())
    setattr(request_proxy_0, '_RequestProxy_defaults', None)
    request_proxy_0.__getattr__('_RequestProxy_request')
    request_proxy_0.__getattr__('_RequestProxy_defaults')
    request_proxy_0.__getattr__('_RequestProxy_request')
    request_proxy_0.__getattr__('_RequestProxy_defaults')
    print('Testing completed successfully')

h_t_t_p_client_0 = HTTPClient()

# Generated at 2022-06-26 08:08:40.418568
# Unit test for function main
def test_main():
    assert test_case_0()


# Generated at 2022-06-26 08:08:50.262228
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    test_AsyncHTTPClient_initialize._configured = False
    if not hasattr(test_AsyncHTTPClient_initialize, "_configured"):
        AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient", defaults={"connect_timeout": 827, "max_clients": 88, "request_timeout": 466})
        test_AsyncHTTPClient_initialize._configured = True
    AsyncHTTPClient.initialize()


# Generated at 2022-06-26 08:08:52.029163
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:09:02.558895
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Initialize i_o_loop with the current loop, defaults with ...
    # patching class AsyncHTTPClient
    class mock_AsyncHTTPClient(AsyncHTTPClient):
        _closed = False
        io_loop = IOLoop.current()

# Generated at 2022-06-26 08:09:12.163514
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    args = ["", "--print_headers=False", "--print_body=True", "--follow_redirects=True", "--validate_cert=True", "--proxy_host=None", "--proxy_port=8080"]
    parse_command_line(args)
    assert options.print_headers == False
    assert options.print_body == True
    assert options.follow_redirects == True
    assert options.validate_cert == True
    assert options.proxy_host == "None"
    assert options.proxy_port == 8080
    main()
    
    

# Generated at 2022-06-26 08:09:19.687999
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Create an instance of AsyncHTTPClient with default arguments
    # Return type: AsyncHTTPClient
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # Create an instance of AsyncHTTPClient with arguments force_instance
    # Return type: AsyncHTTPClient
    async_h_t_t_p_client_1 = AsyncHTTPClient(force_instance = True)
