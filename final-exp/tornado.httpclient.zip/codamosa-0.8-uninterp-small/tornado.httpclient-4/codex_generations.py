

# Generated at 2022-06-26 08:01:52.457643
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    request = HTTPRequest()
    callback = lambda response: response
    # AsyncHTTPClient.fetch_impl(request, callback)
    h_t_t_p_client_0 = HTTPClient()
    callback = lambda response: response
    h_t_t_p_client_0.fetch_impl(request, callback)



# Generated at 2022-06-26 08:01:53.058074
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-26 08:01:55.777811
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:01:56.359236
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:05.847500
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # Test for non-existing URL
    h_t_t_p_client_0 = HTTPClient()

# Generated at 2022-06-26 08:02:16.241015
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    def stub_fetch_impl(self, request, callback):
        print("AsyncHTTPClient.fetch_impl")
        callback(HTTPResponse(request, 200))

    stub_AsyncHTTPClient_fetch = AsyncHTTPClient
    stub_AsyncHTTPClient_fetch.fetch_impl = stub_fetch_impl
    h_t_t_p_client_0 = stub_AsyncHTTPClient_fetch()
    h_t_t_p_request_0 = HTTPRequest('url_0')
    c_o_r_o_0 = h_t_t_p_client_0.fetch(h_t_t_p_request_0)


# Generated at 2022-06-26 08:02:17.490910
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    test_case_0()
    test_main()

# Generated at 2022-06-26 08:02:19.376945
# Unit test for function main
def test_main():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:02:21.678882
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    """Test case for method fetch of class AsyncHTTPClient."""
    test_case_0()


# Generated at 2022-06-26 08:02:24.147248
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()

test_AsyncHTTPClient_fetch_impl()

# Generated at 2022-06-26 08:02:47.081545
# Unit test for function main
def test_main():
    test_case_0()
    h_t_t_p_client_main_0 = HTTPClient()
    h_t_t_p_request_main_0 = HTTPRequest()
    verify_exception(main, TypeError)

# Function to test Exception

# Generated at 2022-06-26 08:02:47.816616
# Unit test for function main
def test_main():
    try:
        main()
    except:
        raise


# Generated at 2022-06-26 08:02:53.261535
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    print("fetch_impl")
    request_0 = HTTPRequest("fetch_impl")
    callback_0 = None
    try:
        AsyncHTTPClient().fetch_impl(request_0, callback_0)
    except NotImplementedError:
        print("Exception NotImplementedError")
    print("End\n")


# Generated at 2022-06-26 08:02:58.468380
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0_1 = AsyncHTTPClient()
    assert h_t_t_p_client_0 == h_t_t_p_client_0_1


# Generated at 2022-06-26 08:03:07.321965
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    instance_cache_0 = AsyncHTTPClient._async_clients()
    io_loop_0 = IOLoop.current()
    if instance_cache_0 is not None and io_loop_0 in instance_cache_0:
        AsyncHTTPClient.__new__(AsyncHTTPClient, force_instance = False)
    else:
        instance_0 = AsyncHTTPClient.__new__(AsyncHTTPClient)
        if instance_cache_0 is not None:
            instance_cache_0[io_loop_0] = instance_0
        return instance_0


# Generated at 2022-06-26 08:03:19.555600
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    test_case_1_var = {}
    # Unit test for method fetch_impl of class AsyncHTTPClient
    def test_case_1(test_AsyncHTTPClient_fetch_impl_0):
        if test_AsyncHTTPClient_fetch_impl_0.fetch_impl:
            return
        if test_AsyncHTTPClient_fetch_impl_0.fetch_impl(test_AsyncHTTPClient_fetch_impl_0.fetch_impl, test_case_1_var["test_case_1_var_0"]):
            return
        if test_AsyncHTTPClient_fetch_impl_0.fetch_impl(test_AsyncHTTPClient_fetch_impl_0.fetch_impl, test_AsyncHTTPClient_fetch_impl_0.fetch_impl):
            return
        return
    test

# Generated at 2022-06-26 08:03:26.997169
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    simple_httpclient_0 = simple_httpclient.SimpleAsyncHTTPClient(max_clients=1000)
    h_t_t_p_response_0 = HTTPResponse(request=simple_httpclient_0.request,code=403, reason='Forbidden', headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, start_time=None)
    assert h_t_t_p_response_0.code == 403
    assert h_t_t_p_response_0.request is not None


# Generated at 2022-06-26 08:03:30.407161
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Create an instance of class AsyncHTTPClient with default arguments
    Future_Response = AsyncHTTPClient().fetch("http://www.google.com")
    t = time.time()
    while (not Future_Response.done()) and ((time.time() - t) < 10):
        time.sleep(0.5)
    Future_Response.result()


# Generated at 2022-06-26 08:03:35.627927
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request_0 = None
    callback_0 = None
    h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, callback_0)

# Generated at 2022-06-26 08:03:39.676222
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    force_instance = False
    kwargs = dict()
    try:
        AsyncHTTPClient___new__(force_instance, **kwargs)
    except TypeError:
        pass


# Generated at 2022-06-26 08:03:52.676537
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:03:53.818850
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:03:57.903682
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_request_0 = HTTPRequest("http://www.example.com", "GET")
    h_t_t_p_request_0.body = "1"
    h_t_t_p_request_0.credential = "1"
    h_t_t_p_request_0.password = "1"
    h_t_t_p_request_0.username = "1"
    h_t_t_p_request_0.url = "1"
    h_t_t_p_request_0.user = "1"
    h_t_t_p_request_0.streaming_callback = "1"
    h_t_t_p_request_0.proxy_password = "1"
    h_t_t_p_request_0

# Generated at 2022-06-26 08:04:05.804149
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()
    http_request_0 = HTTPRequest('http://www.google.com/')
    # Unit test for method fetch of class HTTPClient
    h_t_t_p_client_0.fetch(http_request_0)



# Generated at 2022-06-26 08:04:17.772572
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    async def test_case_1():
        async_http_client_0 = AsyncHTTPClient()
        request_0 = "http://www.google.com"
        response_0 = await async_http_client_0.fetch(request_0)

# Generated at 2022-06-26 08:04:26.674789
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest()
    # Variable h_t_t_p_request_0 is a HTTPRequest
    h_t_t_p_response_0 = h_t_t_p_client_0.fetch(h_t_t_p_request_0)
    # Variable h_t_t_p_response_0 is a HTTPResponse
    var_0 = isinstance(h_t_t_p_response_0, HTTPResponse)


# Generated at 2022-06-26 08:04:30.764485
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def dummy0(*args, **kwargs):
        return None
        pass
    AsyncHTTPClient().fetch_impl(HTTPRequest(), dummy0)


# Generated at 2022-06-26 08:04:31.835504
# Unit test for function main
def test_main():
    main()

test_main()

# Generated at 2022-06-26 08:04:33.002585
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:04:35.287946
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    h_t_t_p_client_0 = HTTPClient()
    response = h_t_t_p_client_0.fetch("https://echo.getpostman.com/get")
    print("Response Body:")
    print(response.body)
    print("Response Status Code:")
    print(response.code)
    print("Response Header:")
    print(response.headers)

# Unit Test for Class AsyncHTTPClient.Configurable

# Generated at 2022-06-26 08:04:56.970271
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:05:01.026296
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse

    # prepare test data
    # call the target function
    h_t_t_p_client_0 = AsyncHTTPClient()
    # write test result


# Generated at 2022-06-26 08:05:03.275711
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:05:06.950735
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    test_case_0()


# Generated at 2022-06-26 08:05:18.823697
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    args = [{'force_instance':True}]
    if len(args) == 1 and isinstance(args[0], dict):
        kwargs = args[0]
    else:
        kwargs = {}
        if len(args) != 0:
            raise TypeError('AsyncHTTPClient.__new__ takes 0 positional argument but 1 was given')
    # _async_client_dict_AsyncHTTPClient
    # _async_clients
    attr_name_0 = '_async_client_dict_' +  'AsyncHTTPClient'
    if not hasattr('AsyncHTTPClient', attr_name_0):
        setattr('AsyncHTTPClient', attr_name_0, weakref.WeakKeyDictionary())
    instance_cache_0 = getattr('AsyncHTTPClient', attr_name_0)


# Generated at 2022-06-26 08:05:27.630300
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    http_request_0 = HTTPRequest(url='https://www.example.com')
    http_request_1 = HTTPRequest(url='https://www.async_http_client.com')
    http_request_2 = HTTPRequest(url='https://www.google.com')
    http_request_3 = HTTPRequest(url='https://www.pluralsight.com')
    http_request_4 = HTTPRequest(url='https://www.youtube.com')
    http_request_5 = HTTPRequest(url='https://www.wikipedia.com')
    http_request_6 = HTTPRequest(url='https://www.facebook.com')
    http_request_7 = HTTPRequest(url='https://www.yahoo.com')
    http

# Generated at 2022-06-26 08:05:33.754296
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def t_func(request, callback):
        pass
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.fetch_impl(HTTPRequest('URL', 'method', {}, 'headers', 'body'), t_func)


# Generated at 2022-06-26 08:05:38.132385
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def fetch_impl(request, callback):
        return
    async_http_client = AsyncHTTPClient()
    request = HTTPRequest()
    callback = lambda response: None
    assert async_http_client.fetch_impl(request, callback) == fetch_impl(request, callback)


# Generated at 2022-06-26 08:05:43.846826
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_request_0 = HTTPRequest("GET", "http://localhost/")
    _RequestProxy_0 = _RequestProxy(h_t_t_p_request_0, None)
    _RequestProxy_0.request.body
    _RequestProxy_0.request.url


# Generated at 2022-06-26 08:05:46.810846
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:01.419231
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    assert type(HTTPClient()) == HTTPClient


# Generated at 2022-06-26 08:07:09.860869
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_1 = AsyncHTTPClient()
    h_t_t_p_request_0 = HTTPRequest('http://www.google.com/')
    h_t_t_p_response_0 = h_t_t_p_client_1.fetch(h_t_t_p_request_0)
    h_t_t_p_response_1 = h_t_t_p_client_1.fetch('http://www.google.com/')


# Generated at 2022-06-26 08:07:14.137643
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient(async_client_class=AsyncHTTPClient, max_clients=3, resolver=None)
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:16.614123
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 08:07:19.267495
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    async_http_client_0 = AsyncHTTPClient()
    assert isinstance(async_http_client_0, AsyncHTTPClient)


# Generated at 2022-06-26 08:07:21.941419
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:31.215849
# Unit test for method fetch_impl of class AsyncHTTPClient

# Generated at 2022-06-26 08:07:34.740188
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    test_case_0()


# Generated at 2022-06-26 08:07:36.513439
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:41.623236
# Unit test for function main
def test_main():
    h_t_t_p_client_0 = HTTPClient()
    test_case_0()
    h_t_t_p_client_0.close()

if __name__ == '__main__':
    # import doctest
    # doctest.testmod()
    test_main()
    # main()

# Generated at 2022-06-26 08:10:42.454059
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_1 = AsyncHTTPClient()
    print(type(h_t_t_p_client_1))
    h_t_t_p_request_0 = HTTPRequest()
    #h_t_t_p_response_0 = h_t_t_p_client_1.fetch_impl(h_t_t_p_request_0, callback=None)
    #print(h_t_t_p_response_0)

if __name__ == '__main__':
    test_case_0()
    test_AsyncHTTPClient_fetch_impl()

# Generated at 2022-06-26 08:10:46.732954
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # 1: Creating an instance of _RequestProxy with empty input
    _req = _RequestProxy(HTTPRequest("https://www.gov.uk"), {})
    
    # 2: Test case for method __getattr__ of class _RequestProxy
    assert True == hasattr(_req, "connect_timeout"), \
            "Method __getattr__ should return True"
    

# Generated at 2022-06-26 08:10:49.900392
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:10:50.424558
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:10:54.658206
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    test_case_0()
    test_main()

# Generated at 2022-06-26 08:11:04.200339
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from .httpclient import AsyncHTTPClient
    import tornado
    import pytest
    import json
    from tornado.httpclient import HTTPRequest, HTTPError
    from tornado.httputil import HTTPHeaders

    async def f():
        http_client = AsyncHTTPClient()
        request = HTTPRequest(
            "http://localhost:8111/json/test_01",
            method='POST',
            headers=HTTPHeaders({'Content-Type': 'application/json'}),
            body=json.dumps({"key": "value"})
        )
        try:
            response = await http_client.fetch(request)
            print(response.body)
            pytest.test_case_0()
        except Exception as e:
            print("Error: %s" % str(e))
            http_client.close()

# Generated at 2022-06-26 08:11:15.273831
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    # testing for type
    r = HTTPRequest("http://www.google.com")
    assert isinstance(r, HTTPRequest)
    # testing for constructor with normal parameters
    r = HTTPRequest("http://www.google.com", method="GET",
                    headers={"User-Agent": "magic browser"},
                    body="hello world")
    assert isinstance(r, HTTPRequest)
    # testing for constructor with optional parameters

# Generated at 2022-06-26 08:11:28.694997
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    # The following line creates an error.  We expect that error to be raised.
    try:
        # h_t_t_p_request_0 = HTTPRequest()
        # _request_proxy_0 = _RequestProxy(h_t_t_p_request_0, None)
        # _request_proxy_0.__getattr__("s")
        raise Exception('Todo: fix this test')
    except HTTPError as e:
        print('Caught exception:', e)
        throw_away_var = typecheck.expect(str, e.message, 'Unknown')
        throw_away_var = typecheck.expect(int, e.code, 0)

# Generated at 2022-06-26 08:11:31.053446
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.initialize(defaults=dict(user_agent="MyUserAgent"))
