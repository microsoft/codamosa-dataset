

# Generated at 2022-06-26 08:02:03.229248
# Unit test for method rethrow of class HTTPResponse

# Generated at 2022-06-26 08:02:09.526293
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Arrange
    class FakeAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]) -> None:
            pass

    client = FakeAsyncHTTPClient()

    # Act and Assert
    try:
        client.fetch_impl(None, None)
    except NotImplementedError as e:
        print('NotImplementedError: ', e)
        assert True
    else:
        assert False
    


# Generated at 2022-06-26 08:02:14.896383
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    # Test for default values in constructor of HTTPRequest
    http_request = HTTPRequest('http://127.0.0.1')
    assert http_request.auth_username == None
    assert http_request.auth_password == None
    assert http_request.auth_mode == None
    assert http_request.connect_timeout == 20.0
    assert http_request.request_timeout == 20.0
    assert http_request.if_modified_since == None
    assert http_request.follow_redirects == True
    assert http_request.max_redirects == 5
    assert http_request.user_agent == None
    assert http_request.use_gzip == None
    assert http_request.network_interface == None
    assert http_request.streaming_callback == None
    assert http_request.header_callback == None


# Generated at 2022-06-26 08:02:16.981857
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    req = HTTPRequest("http://google.com")
    async_client = AsyncHTTPClient()
    async_client.initialize(defaults=req)


# Generated at 2022-06-26 08:02:19.685033
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    _ = AsyncHTTPClient()
    import pytest
    with pytest.raises(NotImplementedError):
        _.fetch_impl(1,1)

# Unit tests for function _RequestProxy

# Generated at 2022-06-26 08:02:26.761646
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    # Set up our class to test, along with some dummy objects
    test_class = AsyncHTTPClient()
    dummy_request = HTTPRequest(url="http://www.google.com")
    dummy_function = lambda x: None

    # Run the method we want to test, and check for NotImplementedError
    with pytest.raises(NotImplementedError):
        test_class.fetch_impl(dummy_request, dummy_function)


# Generated at 2022-06-26 08:02:28.180416
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 08:02:36.766610
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("https://www.baidu.com:8080/test?test=test#test")
    defaults = {"connect_timeout": 10, "request_timeout": 10}
    proxy = _RequestProxy(request, defaults)
    print(proxy.method)
    print(proxy.connect_timeout)
    print(proxy.request_timeout)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:02:41.155355
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.curl_httpclient import CurlAsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import LogTrapTestCase
    from tornado.testing import bind_unused_port
    
    from tornado.testing import ExpectLog

    # Test that when force_instance=True, two AsyncHTTPClients with the same
    # arguments are not identical, and are not cached as singletons.

    class TestAsyncHTTPClient(AsyncHTTPTestCase, LogTrapTestCase):
        def get_app(self) -> Any:
            return None

        def test_force_instance(self) -> None:
            class MyCurlAsyncHTTPClient(CurlAsyncHTTPClient):
                pass

            # Set the default implementation to something other than
            # CurlAsyncHTTPClient.

# Generated at 2022-06-26 08:02:48.018536
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    client = AsyncHTTPClient()
    # Set a request with URL "http://www.google.com/", method "GET" and no body
    request = HTTPRequest("http://www.google.com/", method="GET")
    # Set a callback for dumping the response
    callback = functools.partial(print)
    client.fetch_impl(request, callback)


# Generated at 2022-06-26 08:02:59.656114
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    pass


# Generated at 2022-06-26 08:03:01.690151
# Unit test for function main
def test_main():
    main()

for i in range(200):
    test_case_0()

test_main()

# Generated at 2022-06-26 08:03:09.050874
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # httpclient.AsyncHTTPClient.__new__(force_instance=False, **kwargs)
    async_http_client_0 = AsyncHTTPClient()
    # httpclient.AsyncHTTPClient.__new__(force_instance=False)
    async_http_client_1 = AsyncHTTPClient()
    # httpclient.AsyncHTTPClient.__new__(force_instance=False)
    async_http_client_2 = AsyncHTTPClient()


# Generated at 2022-06-26 08:03:11.737740
# Unit test for function main
def test_main():
    main()


# Boilerplate
async_http_client = HTTPClient()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:03:14.036738
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    x = ioloop.IOLoop.current()
    y = AsyncHTTPClient()
    y.initialize()


# Generated at 2022-06-26 08:03:25.686697
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Example Usage:
    # RequestProxy(request, self.defaults)
    # Future()
    # handle_response(response)
    # response.error
    # self.fetch_impl(request, callback)
    from tornado import locks
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.ioloop import IOLoop

    # Expected input data

# Generated at 2022-06-26 08:03:29.818215
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # 
    print("Start unit test")

    # 
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    IO = IOLoop.current()
    IO.run_sync(f)


# Generated at 2022-06-26 08:03:42.258215
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    cls = AsyncHTTPClient
    h_t_t_p_client_0 = cls()
    cls._async_clients()
    cls._instance_cache = {}
    h_t_t_p_client_0 = cls()
    h_t_t_p_client_0.initialize()
    h_t_t_p_client_0.defaults = {}
    h_t_t_p_client_0.io_loop = IOLoop()
    h_t_t_p_client_0.initialize(defaults = h_t_t_p_client_0.defaults)
    h_t_t_p_client_0.defaults = {}

# Generated at 2022-06-26 08:03:44.407638
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    obj1 = AsyncHTTPClient()
    obj1.close()


# Generated at 2022-06-26 08:03:53.088234
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    try:
        a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()

    except:
        pass

    try:
        a_s_y_n_c_h_t_t_p_client_1 = AsyncHTTPClient(force_instance=True)

    except:
        pass


# Generated at 2022-06-26 08:04:09.258566
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    __test__ = {}

    def test_case_0():
        a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()

    __test__["test_case_0"]()


# Generated at 2022-06-26 08:04:12.325121
# Unit test for function main
def test_main():
    try:
        main()
    except:
        # FIXME: Some version numbers are different
        print_exc()


# Generated at 2022-06-26 08:04:14.009722
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:04:26.645550
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    force_instance_0_0 = bool(True)  # type: bool
    kwargs_0_0 = {}  # type: Dict[str,Any]
    async_h_t_t_p_client_0_0 = AsyncHTTPClient(force_instance_0_0, **kwargs_0_0)
    # Unit test for method __new__ of class AsyncHTTPClient
    force_instance_0_1 = bool(False)  # type: bool
    kwargs_0_1 = {}  # type: Dict[str,Any]
    async_h_t_t_p_client_0_1 = AsyncHTTPClient(force_instance_0_1, **kwargs_0_1)
    # Unit test for method __new__ of class AsyncHTTPClient with kwargs
    force_

# Generated at 2022-06-26 08:04:40.253685
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()

# Generated at 2022-06-26 08:04:43.381485
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    force_instance_0 = True
    async_http_client_0 = AsyncHTTPClient(force_instance=force_instance_0)


# Generated at 2022-06-26 08:04:44.036554
# Unit test for function main
def test_main():
    main()

#Unit test for class HTTPClient

# Generated at 2022-06-26 08:04:45.013956
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 08:04:45.743618
# Unit test for function main
def test_main():

    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:04:48.869201
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.fetch("http://www.google.com/")


# Generated at 2022-06-26 08:05:03.222530
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_1 = AsyncHTTPClient()


# Generated at 2022-06-26 08:05:08.746480
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Method: initialize(self, defaults: Optional[Dict[str, Any]] = None) -> None
    test_case_0()


# Generated at 2022-06-26 08:05:15.162898
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Boilerplate
if __name__ == '__main__':
    import traceback
    from unittest import main, TestCase

    class TestCase(TestCase):
        def test_main(self):
            test_main()

        def test_case_0(self):
            test_case_0()

    main()

# Generated at 2022-06-26 08:05:27.224785
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-26 08:05:29.618413
# Unit test for function main
def test_main():
    # No exception should be thrown for function main
    main()


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 08:05:32.021108
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:05:34.208626
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:05:34.896101
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass



# Generated at 2022-06-26 08:05:35.869912
# Unit test for function main
def test_main():
    args = []
    main()

# Generated at 2022-06-26 08:05:42.073552
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    try:
        async_h_t_t_p_client_0 = AsyncHTTPClient()
    except Exception as err:
        print(err)
    else:
        print("Test for fetch of object async_h_t_t_p_client_0 FAILS")


# Generated at 2022-06-26 08:06:06.321078
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    @gen.coroutine
    def test():
        h_t_t_p_client_0 = AsyncHTTPClient()
        h_t_t_p_client_1 = AsyncHTTPClient()
        h_t_t_p_client_0 == h_t_t_p_client_1
        yield
    test()


# Generated at 2022-06-26 08:06:15.628263
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    AsyncHTTPClient.configure()
    assert_equal(AsyncHTTPClient.configurable_default(), SimpleAsyncHTTPClient)
    assert_equal(AsyncHTTPClient.configurable_base(), AsyncHTTPClient)
    assert_equal(AsyncHTTPClient.__name__, 'AsyncHTTPClient')
    async_http_client_0 = AsyncHTTPClient()
    assert_equal(AsyncHTTPClient.configurable_default(), SimpleAsyncHTTPClient)
    assert_equal(AsyncHTTPClient.configurable_base(), AsyncHTTPClient)
    assert_equal(AsyncHTTPClient.__name__, 'AsyncHTTPClient')



# Generated at 2022-06-26 08:06:19.938467
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        h_t_t_p_client_0 = AsyncHTTPClient()
    except Exception as e:
        print(str(e))
    else:
        print('The test completed successfully.')


# Generated at 2022-06-26 08:06:33.470775
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    import tornado.platform.auto
    # proxy_auth_mode
    # proxy_password
    # proxy_username
    # proxy_port
    # proxy_host
    # headers
    # _headers
    # body
    # _body
    # auth_username
    # auth_password
    # auth_mode
    # decompress_response
    # if_modified_since
    # if_modified_since_float
    # user_agent
    # max_redirects
    # follow_redirects
    # request_timeout
    # connect_timeout
    # prepare_curl_callback
    # header_callback
    # streaming_callback
    # allow_nonstandard_methods
    # validate_cert
    # ca_certs
    # allow_ipv6
    # client_cert
    # client_key


# Generated at 2022-06-26 08:06:41.960847
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Initialize test environment.
    request = HTTPRequest("http://localhost:8888/")
    defaults = {"url" : "http://localhost:8888/"}
    r_e_q_u_e_s_t_p_r_o_x_y = _RequestProxy(
        request,
        defaults
     )
    # Invoke method under test.
    r_e_q_u_e_s_t_p_r_o_x_y.__getattr__("url")
    # Check the result.
    assert r_e_q_u_e_s_t_p_r_o_x_y.url == "http://localhost:8888/"


# Generated at 2022-06-26 08:06:42.876371
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:06:43.509116
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:06:46.717123
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    # Unit test for function main
    test_main()

# Generated at 2022-06-26 08:06:48.893134
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:06:56.851081
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_client_0 = HTTPClient()
    r_e_q_u_e_s_t_0 = HTTPRequest('http://localhost:8000/', 'GET')

# Generated at 2022-06-26 08:07:46.315756
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Test AsyncHTTPClient.close 
    # (1) Default args.
    # (2) force_instance=True
    AsyncHTTPClient.configure(None, defaults=dict(user_agent="MyUserAgent"))
    # or with force_instance:
    client = AsyncHTTPClient(force_instance=True,
        defaults=dict(user_agent="MyUserAgent")) 
    client.close()


# Generated at 2022-06-26 08:07:48.992389
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:52.298018
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 08:07:56.946083
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    a_p_i_url_0 = 'example.com'
    a_p_i_method_0 = 'GET'
    headers_0 = {}
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    http_request_0 = HTTPRequest(url=a_p_i_url_0, method=a_p_i_method_0, headers=headers_0)
    future_0 = a_s_y_n_c_h_t_t_p_client_0.fetch(request=http_request_0)
    assert isinstance(future_0, Future)
    h_t_t_p_response_0 = future_0.result()

# Generated at 2022-06-26 08:07:57.517445
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:07:59.384433
# Unit test for function main
def test_main():
    for i in range(100): # configurable parameter
        test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 08:08:02.452570
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Parameter of the method
    close_AsyncHTTPClient_0 = AsyncHTTPClient()
    # Call the method
    close_AsyncHTTPClient_1 = close_AsyncHTTPClient_0.close()


# Generated at 2022-06-26 08:08:03.035424
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    test_HTTPRequest_0()


# Generated at 2022-06-26 08:08:09.915248
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
  # Create an object of the superclass
  super_class_instance = AsyncHTTPClient(force_instance = False)
  # Create an object of the tested class
  tested_class_instance = AsyncHTTPClient(force_instance = False)
  super_class_instance.close()
  tested_class_instance.close()
  return


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 08:08:17.358862
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    h_t_t_p_request_0 = HTTPRequest("http://www.baidu.com")
    h_t_t_p_client_0 = HTTPClient()
    proxy = _RequestProxy(h_t_t_p_request_0, h_t_t_p_client_0)

    ret = proxy.__getattr__(h_t_t_p_client_0)
    return ret


# Generated at 2022-06-26 08:09:52.235237
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    print('Test: close of class AsyncHTTPClient')
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()  # type: AsyncHTTPClient
    a_s_y_n_c_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:10:06.795346
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    try:
        # This test requires Python 3.5 or later. If you need to run this
        # test on earlier versions of Python, mock the new AsyncHTTPClient
        # keyword "raise_error".
        from unittest.mock import patch
        url = "http://www.google.com"
        i_o_loop_0 = IOLoop.current()
        a_sync_http_client_0 = AsyncHTTPClient()
        future = a_sync_http_client_0.fetch(url)
        h_t_t_p_response_0 = future.result(timeout=3600.0)
    except:
        pass


# Generated at 2022-06-26 08:10:07.727898
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    test_case_0()


# Generated at 2022-06-26 08:10:08.616425
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:10:09.319275
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:10:19.064668
# Unit test for method initialize of class AsyncHTTPClient

# Generated at 2022-06-26 08:10:19.960379
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:10:28.658033
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    impl = "tornado.curl_httpclient.CurlAsyncHTTPClient"
    AsyncHTTPClient.configure(impl)
    http_request_0 = HTTPRequest('http://www.google.com')
    http_client_0 = AsyncHTTPClient()
    http_response_0 = http_client_0.fetch(http_request_0)
    print(http_response_0.body)


# Generated at 2022-06-26 08:10:39.889287
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Initialize stub
    http_request_0 = HTTPRequest()
    # Construct the arguments for method fetch of class AsyncHTTPClient
    # Argument 'request'
    request_0 = http_request_0
    # Optional argument 'raise_error'
    raise_error_0 = True
    # Optional argument '**kwargs'
    kwargs_0 = {}
    # Invoke method
    async_http_client_0 = AsyncHTTPClient()
    result = async_http_client_0.fetch(request_0, raise_error_0, **kwargs_0)



# Generated at 2022-06-26 08:10:41.588985
# Unit test for function main
def test_main():
    main()
