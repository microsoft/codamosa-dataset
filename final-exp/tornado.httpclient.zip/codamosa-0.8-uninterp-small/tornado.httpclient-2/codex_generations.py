

# Generated at 2022-06-26 08:01:55.570014
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:02:02.364225
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    my_request = HTTPRequest()
    my_response = HTTPResponse()
    my_callback = lambda my_response: print(my_response.body)
    # Test exposing an argument to fetch_impl()
    AsyncHTTPClient.configure(None, defaults=dict(user_agent="MyUserAgent"))
    http_client = AsyncHTTPClient()
    http_client.fetch_impl(my_request, my_callback)
    http_client.close()


# Generated at 2022-06-26 08:02:06.964713
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = AsyncHTTPClient()
    request_0 = HTTPRequest("url")
    callback_0 = (lambda HTTPResponse: None)
    h_t_t_p_client_0.fetch_impl(request_0, callback_0)


# Generated at 2022-06-26 08:02:10.205853
# Unit test for function main
def test_main():

    try:
        main()
    except HTTPClientError as error:
        assert error.code == 404
        assert error.response.code == 404
        assert error.response.effective_url == 'https://lkjlkjlkjlkjljlkjlkjlkjlkj.com/'


# Generated at 2022-06-26 08:02:14.740390
# Unit test for function main
def test_main():
    sys.argv.append("http://www.google.com/")
    main()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 08:02:19.007466
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    """HTTPClient.fetch"""
    h_t_t_p_client_1 = HTTPClient()
    h_t_t_p_client_1.fetch("http://www.google.com/")


# Generated at 2022-06-26 08:02:21.982644
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    fetch_impl_1 = AsyncHTTPClient()
    test_case_1 = fetch_impl_1.fetch_impl
    assert test_case_1 is not None


# Generated at 2022-06-26 08:02:23.670678
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    async_h_t_t_p_client_0 = AsyncHTTPClient()


# Generated at 2022-06-26 08:02:31.149330
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # _RequestProxy.__getattr__(self, name)
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest(url='https://www.yahoo.com')
    _RequestProxy_0 = _RequestProxy(h_t_t_p_request_0, None)
    return _RequestProxy_0


# Generated at 2022-06-26 08:02:43.993921
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.testing import AsyncHTTPTestCase

    class DummyAsyncHTTPClient(AsyncHTTPClient):
        async def fetch_impl(self, request: "HTTPRequest", callback: "Callable[[HTTPResponse], None]") -> None:
            response = None
            callback(response)

    class DummyAsyncHTTPTestCase(AsyncHTTPTestCase):
        def get_app(self) -> "Optional[aioresponses]":
            return "app"

    dummy_async_h_t_t_p_test_case_0 = DummyAsyncHTTPTestCase()
    dummy_async_h_t_t_p_test_case_0.setUp()
    dummy_async_h_t_t_p_client_0 = DummyAsyncHTTP

# Generated at 2022-06-26 08:02:53.452043
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:03:00.822627
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    #create AsyncHTTPClient object
    async_h_t_t_p_client_0 = AsyncHTTPClient()

    #create AsyncHTTPClient object
    async_h_t_t_p_client_1 = AsyncHTTPClient(force_instance=True)

    #equivalent to AsyncHTTPClient()
    assert async_h_t_t_p_client_1 == AsyncHTTPClient()


# Generated at 2022-06-26 08:03:12.645193
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test

    class MainTest(AsyncTestCase):
        @gen_test
        def test_main(self):
            # Note that this test requires an actual network connection
            # and the ability to resolve www.google.com.  Mock out these
            # aspects of AsyncHTTPClient if necessary.
            #
            # We open a subprocess because unittest.mock isn't available
            # on python 2.6
            output = yield self.subprocess_environment(
                sys.executable,
                "-c",
                "from tornado.httpclient import main; main()",
                "http://www.google.com/",
                "https://www.google.com/",
            )
            self.assertIn("<title>Google</title>", output.decode("utf-8"))

# Generated at 2022-06-26 08:03:24.411418
# Unit test for method __getattr__ of class _RequestProxy

# Generated at 2022-06-26 08:03:27.217851
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_client_0 = AsyncHTTPClient()
    try:
        h_t_t_p_client_0.fetch_impl()
    except NotImplementedError:
        pass


# Generated at 2022-06-26 08:03:33.599438
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # test obj construction
    try:
        AsyncHTTPClient.configure(None)
        async_http_client_0 = AsyncHTTPClient()
    except Exception:
        async_http_client_0 = None
    finally:
        if async_http_client_0:
            async_http_client_0.close()

    # test method calls
    try:
        AsyncHTTPClient.configure(None)
        async_http_client_1 = AsyncHTTPClient()
        response = async_http_client_1.fetch("http://www.google.com")
    except Exception:
        response = None
    finally:
        if async_http_client_1:
            async_http_client_1.close()

    # test obj attr types

# Generated at 2022-06-26 08:03:35.946355
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_1 = AsyncHTTPClient()


# Generated at 2022-06-26 08:03:39.544764
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_0.rethrow()


# Generated at 2022-06-26 08:03:41.743670
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 08:03:53.705763
# Unit test for method __new__ of class AsyncHTTPClient

# Generated at 2022-06-26 08:04:15.459408
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # 1.
    h_t_t_p_request_0 = HTTPRequest()
    def handle_response(response: "HTTPResponse") -> None:
        pass
    test_AsyncHTTPClient_0 = AsyncHTTPClient()
    test_AsyncHTTPClient_0.fetch_impl(h_t_t_p_request_0, handle_response)
    # 2.
    test_AsyncHTTPClient_1 = AsyncHTTPClient()
    test_AsyncHTTPClient_1.fetch_impl(h_t_t_p_request_0, handle_response)


# Generated at 2022-06-26 08:04:25.612633
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Define a class that implements fetch_impl
    class test_class_0(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass
    # Create an instance of the class
    async_http_client_0 = test_class_0()
    # Invoke method fetch_impl of the instance
    http_request_0 = HTTPRequest(url='/', method='GET')
    async_http_client_0.fetch_impl(http_request_0, None)


# Generated at 2022-06-26 08:04:29.250109
# Unit test for function main
def test_main():
    sys.argv = ["httpclient_test","--help"]
    main()

if __name__ == "__main__":
    test_main()
    test_case_0()

# Generated at 2022-06-26 08:04:30.385147
# Unit test for function main
def test_main():
    test_main_0()


# Generated at 2022-06-26 08:04:39.849978
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Initialize the class
    test_instance = AsyncHTTPClient()
    # Import the required function
    from tornado.httpclient import HTTPRequest
    # Initialize the argument
    arg_request = HTTPRequest(url="https://google.com")
    arg_callback = lambda HTTPResponse: None
    # Execute the test function
    try:
        test_instance.fetch_impl(arg_request, arg_callback)
    except Exception as e:
        print("test_AsyncHTTPClient_fetch_impl failed: " + str(e))


# Generated at 2022-06-26 08:04:42.755814
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:04:46.975336
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    async_http_client = AsyncHTTPClient()
    http_request = HTTPRequest()
    http_response = HTTPResponse()
    async_http_client.fetch_impl(http_request, http_response)


# Generated at 2022-06-26 08:04:58.040547
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.concurrent import Future
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future
    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase, gen_test
    from tornado.test.util import unittest
    import asynctest
    import asyncio
    AsyncIOMainLoop().install()
    class TestAsyncHTTPClientInitialize(AsyncHTTPTestCase):
        def get_app(self):
            return self.get_http_server()

# Generated at 2022-06-26 08:05:07.156208
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient(force_instance = True, user_agent = "MyUserAgent")
    h_t_t_p_client_1 = AsyncHTTPClient(force_instance = False, user_agent = "MyUserAgent")

    assert h_t_t_p_client_0 is h_t_t_p_client_1
    assert h_t_t_p_client_0._instance_cache is not None
    assert h_t_t_p_client_1._instance_cache is not None
    assert h_t_t_p_client_1._instance_cache == h_t_t_p_client_0._instance_cache


# Generated at 2022-06-26 08:05:12.636392
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()

    http_client_0 = AsyncHTTPClient()

    http_client_0.initialize()

    http_client_0.close()

    AsyncIOMainLoop().close(all_fds=True)


# Generated at 2022-06-26 08:05:38.261132
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    h_t_t_p_client_0 = HTTPClient()
    print('HTTPClient constructor test OK!')


# Generated at 2022-06-26 08:05:43.939841
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.auto import SetProxy

    _method_0 = AsyncHTTPClient.initialize

    @gen.coroutine
    def wrapper():
        client_0 = AsyncHTTPClient()

    wrapper().__next__()
    raise StopIteration


# Generated at 2022-06-26 08:05:52.666688
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import random
    # Force instance creation
    l_t___s_s_p_i_n_t_i_d__r_a_n_d_o_m_0 = random.randint(0, 1000)
    l_t___s_s_p_i_n_t_i_d__r_a_n_d_o_m_1 = random.randint(0, 1000)
    l_t___s_s_p_i_n_t_i_d__r_a_n_d_o_m_2 = random.randint(0, 1000)
    l_t___s_s_p_i_n_t_i_d__r_a_n_d_o_m_3 = random.randint(0, 1000)
    l_t___s_s_

# Generated at 2022-06-26 08:06:05.493264
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import options
    from tornado.util import raise_exc_info

    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(
            self,
            defaults: Optional[Dict[str, Any]] = None,
            max_clients: Optional[int] = None,
            max_simultaneous_requests: Optional[int] = None,
            max_time: Optional[float] = None,
        ) -> None:
            self.defaults = defaults or {}
            self.max_clients = max_clients

    # Test that max_clients is passed to initialize()
    client = TestAsyncHTTPClient(max_clients=42)
    assert client.max_clients == 42

    # Test that options are passed to initialize()
    options.proxy

# Generated at 2022-06-26 08:06:16.293494
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    a = HTTPRequest("GET", "http://localhost:8888")
    b = a
    c = b
    c = _RequestProxy(c, None)
    c.request.method = "get"
    c.defaults = None
    t_e_s_t__RequestProxy___getattr__0 = c.method
    t_e_s_t__RequestProxy___getattr__1 = c.http_version
    t_e_s_t__RequestProxy___getattr__2 = c.request_timeout
    return (t_e_s_t__RequestProxy___getattr__0, t_e_s_t__RequestProxy___getattr__1, t_e_s_t__RequestProxy___getattr__2)


# Generated at 2022-06-26 08:06:17.890026
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:06:22.813331
# Unit test for function main
def test_main():
    print('Test main')
    main()


# Generated at 2022-06-26 08:06:34.254843
# Unit test for function main
def test_main():
    main()
    # Verify that the cookies from the client are added to the new request
    h_t_t_p_client_0 = HTTPClient()
    # Verify that a response body was received for the client's RequestProxy
    h_t_t_p_client_0.fetch("http://fakeurl.1")
    # Verify that a response body was received for the client's RequestProxy
    h_t_t_p_client_0.fetch("http://fakeurl.2")
    # Verify that a response body was received for the client's RequestProxy
    h_t_t_p_client_0.fetch("http://fakeurl.3")
    # Verify that a response body was received for the client's RequestProxy
    h_t_t_p_client_0.fetch("http://fakeurl.4")
    #

# Generated at 2022-06-26 08:06:36.689016
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:06:50.255349
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient(force_instance=True,
            defaults=dict(user_agent="MyUserAgent"))
    a_s_y_n_c_h_t_t_p_client_0.close()

    # Unit test for method fetch of class AsyncHTTPClient
    @gen.coroutine
    def wrapper():
        response = yield a_s_y_n_c_h_t_t_p_client_0.fetch("http://www.google.com")
        print(response.body)
    IOLoop.current().run_sync(wrapper)

test_case_0()

# Generated at 2022-06-26 08:07:16.299740
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    if not callable(AsyncHTTPClient.fetch_impl):
        raise TypeError('"fetch_impl" is not a function')
    try:
        AsyncHTTPClient.fetch_impl(HTTPRequest(url="http://www.google.com"), h_t_t_p_response_0_callback)
    except NotImplementedError:
        pass


# Generated at 2022-06-26 08:07:23.570759
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Create an instance of class AsyncHTTPClient
    async_http_client_0 = AsyncHTTPClient(force_instance=False)
    try:
        # Assert that async_http_client_0._closed is False
        if (not async_http_client_0._closed):
            raise AssertionError()
        # Assert that async_http_client_0.defaults is empty
        if (async_http_client_0.defaults != {}):
            raise AssertionError()
    finally:
        # Close the asynchronous HTTP client async_http_client_0
        async_http_client_0.close()


# Generated at 2022-06-26 08:07:34.575228
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    h_t_t_p_client_0 = HTTPClient()
    # h_t_t_p_client_0.fetch()
    # h_t_t_p_client_0.close()
    h_t_t_p_request_0 = HTTPRequest(url='http://httpbin.org/redirect/2', follow_redirects=True, connect_timeout=30.0, request_timeout=30.0, proxy_host='localhost', proxy_port=8118)
    # h_t_t_p_client_0.fetch(h_t_t_p_request_0)
    # h_t_t_p_client_0.close()
    # h_t_t_p_request_0.rethrow()



# Generated at 2022-06-26 08:07:36.764515
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:07:38.595234
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()


# Generated at 2022-06-26 08:07:40.531223
# Unit test for function main
def test_main():
    main()

test_case_0()

test_main()

# Generated at 2022-06-26 08:07:41.621430
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    pass


# Generated at 2022-06-26 08:07:54.107954
# Unit test for function main
def test_main():
    from io import BytesIO
    from io import StringIO
    from unittest import mock
    
    # mock out stdin, stdout and stderr
    stdin_mock = mock.Mock(unsafe=True)
    stdout_mock = mock.Mock(unsafe=True)
    stderr_mock = mock.Mock(unsafe=True)
    # mock them as attributes on the module
    sys.modules[__name__].stdin = stdin_mock
    sys.modules[__name__].stdout = stdout_mock
    sys.modules[__name__].stderr = stderr_mock
    
    # create an instance of the IO class to emulate a file
    # from which the sys module can read

# Generated at 2022-06-26 08:07:57.433390
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    h_t_t_p_request_0 = HTTPRequest('http://google.com')
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_request_0, 0)
    test_case_0()

# Generated at 2022-06-26 08:08:08.367266
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    """Function to test fetching an HTTP resource using the fetch_impl method"""
    # Create a fake HTTPRequest object
    request_0 = HTTPRequest()
    # Configure the method to be used
    request_0.method = "GET"
    # Configure the url of the resource
    request_0.url = "https://www.google.com/"
    # Configure the callback to be used
    callback_0 = get_content_length
    # Create an object of class AsyncHTTPClient
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # Call function to be tested
    async_h_t_t_p_client_0.fetch_impl(request_0, callback_0)

# Function to test fetching an HTTP resource using the fetch method