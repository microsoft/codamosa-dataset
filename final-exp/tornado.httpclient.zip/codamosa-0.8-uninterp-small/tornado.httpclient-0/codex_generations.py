

# Generated at 2022-06-26 08:01:50.875291
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    import os, sys, traceback
    if not os.path.exists(os.environ['TORNADO_TEST_DIR']):
        os.mkdir(os.environ['TORNADO_TEST_DIR'])
    fd = open(os.path.join(os.environ['TORNADO_TEST_DIR'], 'test_httpclient.stderr'), 'wb')
    sys.stderr = fd
    try:
        test_main()
    except:
        traceback.print_exc(file=sys.stderr)
    finally:
        fd.close()

# Generated at 2022-06-26 08:01:53.483387
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    self = HTTPResponse(request=None, code=None, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    __repr__(self)


# Generated at 2022-06-26 08:01:56.432425
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    args = [None, 'force_instance=True', '**kwargs']
    AsyncHTTPClient().__new__(**args)


# Generated at 2022-06-26 08:02:03.289322
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    client = AsyncHTTPClient()
    try:
        response = client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    client.close()


# Generated at 2022-06-26 08:02:08.165210
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
            print(response.body)
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

# Generated at 2022-06-26 08:02:13.391785
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        raise NotImplementedError
    except NotImplementedError:
        print("It's a NotImplementedError Exception")
    except:
        print("Other kind of exception")


# Generated at 2022-06-26 08:02:13.938610
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:02:19.149352
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    l_cw1dele_Fn_d = test_case_0()
    # init the AsyncHTTPClient with a new IOLoop
    a_c = AsyncHTTPClient()
    # init a new IOLoop with force_instance and the AsyncHTTPClient
    i_l = IOLoop.current()
    # call close on it
    a_c.close()
    # close() called on closed AsyncHTTPClient, should fail
    if a_c._closed:
        a_c.fetch("http://www.google.com")

# Generated at 2022-06-26 08:02:31.636763
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Initialize
    async def test_0(): # Unhandled exception
        import asyncio
        import io
        import logging
        import socket

        from tornado.httpclient import AsyncHTTPClient, HTTPResponse, HTTPRequest
        from tornado.httpclient import HTTPError


        def handle_response(response: HTTPResponse) -> None:
            if response.error:
                print("Error: %s" % response.error)
            else:
                print(response.body)

        request = HTTPRequest(url="http://www.google.com")
        http_client = AsyncHTTPClient()
        await http_client.fetch(request, callback=handle_response)
    # Test case 0: Normal case
    asyncio.get_event_loop().run_until_complete(test_0())
    # Test case 1:

# Generated at 2022-06-26 08:02:34.875123
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    print("testing __new__ of AsyncHTTPClient")
    impl_0 = AsyncHTTPClient.configure()
    test_AsyncHTTPClient___new__.result = None


# Generated at 2022-06-26 08:03:02.880434
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import HTTPResponse

    class HTTPRequest:
        def __init__(self, url=None, **kwargs):
            if url is None:
                url = 'http://www.google.com'
            self.url = url
            self.headers = httputil.HTTPHeaders()
            if kwargs:
                raise ValueError("kwargs can't be used if request is an HTTPRequest object")

    @gen.coroutine
    def handleResponse(response):
        assert isinstance(response, HTTPResponse)

    @gen.coroutine
    def fetch1():
        raise_error = True
        request = HTTPRequest('http://localhost:8888')
        request.headers = httputil.HTTPHeaders(request.headers)

# Generated at 2022-06-26 08:03:14.416304
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # a_s_y_n_c_h_t_t_p_client_0 is an instance of class AsyncHTTPClient
    a_s_y_n_c_h_t_t_p_client_0 = AsyncHTTPClient()
    # a_s_y_n_c_h_t_t_p_client_1 is an instance of class AsyncHTTPClient
    a_s_y_n_c_h_t_t_p_client_1 = AsyncHTTPClient()
    # a_s_y_n_c_h_t_t_p_client_2 is an instance of class AsyncHTTPClient
    a_s_y_n_c_h_t_t_p_client_2 = AsyncHTTPClient()



# Generated at 2022-06-26 08:03:21.218835
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    # Test 1
    h_t_t_p_client_0 = HTTPClient()
    test_HTTPRequest_0 = HTTPRequest(
        "Accept-Encoding", "Accept", "User-Agent", "Connection", "If-Modified-Since"
    )
    h_t_t_p_client_0.fetch_impl(test_HTTPRequest_0, None)



# Generated at 2022-06-26 08:03:23.796844
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:03:30.875370
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://localhost:8888/")
    request_proxy_0 = _RequestProxy(request, None)
    request_attr = request_proxy_0.__getattr__("_http_client")

# Generated at 2022-06-26 08:03:35.626077
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    print('Testing method __new__ of class AsyncHTTPClient...')

    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print('Test case 0 FAILED: ' + str(e))

test_AsyncHTTPClient___new__()

# Generated at 2022-06-26 08:03:37.579317
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    force_instance_0 = False

# Generated at 2022-06-26 08:03:47.881715
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # this test case comes from tornado test case.
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import asyncio

    class DummyAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super(DummyAsyncHTTPClient, self).__init__(*args, **kwargs)

        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            raise RuntimeError("should not be called")

    class MockAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super(MockAsyncHTTPClient, self).__init__(*args, **kwargs)

# Generated at 2022-06-26 08:03:53.939076
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Test with a subclass
    class test_class(AsyncHTTPClient):
        pass
    test_class_instance = test_class()
    assert test_class_instance.io_loop == IOLoop.current(), "AsyncHTTPClient object should have io_loop == IOLoop.current()"
    assert test_class_instance.defaults == HTTPRequest._DEFAULTS, "AsyncHTTPClient object should have defaults == HTTPRequest._DEFAULTS"
    test_class_instance.initialize()
    # TODO: Add test cases:
    # dict(user_agent="MyUserAgent")



# Generated at 2022-06-26 08:03:56.892658
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:04:07.041064
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:04:08.476279
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-26 08:04:10.173643
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 08:04:13.818883
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:04:18.638902
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    client.initialize(defaults={'method': 'GET'})
    assert client.defaults == {'method': 'GET'}
    

# Generated at 2022-06-26 08:04:28.119511
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    url = 'http://127.0.0.1:9000'

# Generated at 2022-06-26 08:04:29.205239
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:04:32.542201
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.close()
    h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:04:46.038802
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Create an instance of type 'HTTPRequest'
    request_0 = HTTPRequest(transparent_proxy=1, proxy_username=None, connect_timeout=None, allow_nonstandard_methods=None, follow_redirects=True, max_redirects=20, streaming_callback=True, proxy_password=None, user_agent='tornado/4.5.3', decompress_response=True, proxy_port=None, auth_username=None, auth_mode=None, header_callback=None, body_length=0, auth_password=None, headers=None, url_data=None, request_timeout=20.0, url=None, proxy_host=None, use_gzip=None, proxy_auth_mode=None)
    # AsyncHTTPClient.fetch_impl(request, handle_response=handle_response)

# Generated at 2022-06-26 08:04:57.103296
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.httpclient import AsyncHTTPClient

    # Test that if force_instance=True, a new client is created each time.
    a_h_c0 = AsyncHTTPClient()
    a_h_c1 = AsyncHTTPClient(force_instance=True)
    assert id(a_h_c0) != id(a_h_c1)
    # Test that the cache works, and that client has access to its cache.
    a_h_c2 = AsyncHTTPClient()
    assert id(a_h_c0) == id(a_h_c2)
    assert a_h_c0._instance_cache is a_h_c2._instance_cache
    assert id(a_h_c0) in a_h_c2._instance_cache
    # Test that the cache works for the test

# Generated at 2022-06-26 08:05:20.496489
# Unit test for method fetch_impl of class AsyncHTTPClient

# Generated at 2022-06-26 08:05:23.661284
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:05:36.099718
# Unit test for function main
def test_main():
    # This function will run the function main with test values and check the output.
    # Create a command line argument list with the test arguments
    args = ['filename']
    # Create a new instance of the OptionParser class
    tornado.options.OptionParser = lambda: None
    # Create a new instance of an Options instance to hold the values of the options
    tornado.options.options = options = Options()
    # Set the option values
    options.print_headers = True
    options.print_body = True
    options.follow_redirects = True
    options.validate_cert = True
    options.proxy_host = None
    options.proxy_port = None
    # Parse the command line arguments
    args = args
    # Call the main function
    main()


# Generated at 2022-06-26 08:05:48.849388
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    print("Test: close of class AsyncHTTPClient")
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    async_h_t_t_p_client_0.close()
    async_h_t_t_p_client_1 = AsyncHTTPClient()
    async_h_t_t_p_client_1.close()
    async_h_t_t_p_client_1.close()
    AsyncHTTPClient.configure('', '')
    async_h_t_t_p_client_2 = AsyncHTTPClient()
    async_h_t_t_p_client_2.close()
    async_h_t_t_p_client_2.close()


# Generated at 2022-06-26 08:06:04.653240
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Parameters for the test case
    h_t_t_p_request_0 = HTTPRequest()
    h_t_t_p_request_0.body = b"/\xf7"
    h_t_t_p_request_0.url = "http://example.com/hello?foo=bar"
    h_t_t_p_request_0.validate_cert = True
    h_t_t_p_request_0.proxy_host = "proxy.example.com"
    h_t_t_p_request_0.proxy_port = 8080
    h_t_t_p_request_0.request_timeout = 50
    h_t_t_p_request_0.auth_username = "username"

# Generated at 2022-06-26 08:06:11.100365
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    h_t_t_p_c_lient_0 = AsyncHTTPClient()
    http_request_0 = HTTPRequest("", "", {}, "", "", "", "", None, {})
    assert h_t_t_p_c_lient_0.fetch_impl(http_request_0, lambda a: None) == NotImplementedError
    
    

# Generated at 2022-06-26 08:06:22.652779
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_r_request_0 = HTTPRequest(url='x')
    h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h_h

# Generated at 2022-06-26 08:06:27.270153
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:06:38.754643
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-26 08:06:53.740210
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Test for __getattr__ in class _RequestProxy
    request_0 = HTTPRequest("http://www.example.com")
    request_1 = HTTPRequest("http://www.google.com")
    request_2 = HTTPRequest("http://www.example.com")
    request_3 = HTTPRequest("http://www.google.com")
    request_4 = HTTPRequest("http://www.example.com")
    request_5 = HTTPRequest("http://www.google.com")
    request_6 = HTTPRequest("http://www.example.com")
    request_7 = HTTPRequest("http://www.google.com")
    request_8 = HTTPRequest("http://www.example.com")
    request_9 = HTTPRequest("http://www.google.com")

# Generated at 2022-06-26 08:07:16.197243
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    test_client = AsyncHTTPClient()
    test_request = HTTPRequest("https://www.google.com")
    test_response = test_client.fetch(test_request)
    test_response.result()

    test_client.close()
    test_client = AsyncHTTPClient()
    test_request = HTTPRequest("https://www.bing.com")
    test_response = test_client.fetch(test_request)
    test_response.result()

    test_client.close()


# Generated at 2022-06-26 08:07:18.572094
# Unit test for function main
def test_main():
     main()
     print("Test for main completed")

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 08:07:26.690080
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(method='get', url='www.google.com')
    print("Instantiate HTTPResponse object")
    response = HTTPResponse(request = request, code = 200, headers = httputil.HTTPHeaders(), buffer = b'buffer1', 
            effective_url = 'www.google.com', error = None, request_time = 1.0, time_info = None, reason = 'OK', 
            start_time = 1.0)
    print("Method rethrow: ")
    response.rethrow()

# Generated at 2022-06-26 08:07:35.192167
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    resp = HTTPResponse(request = None,
                        code = 0,
                        headers = None)
    try:
        resp.rethrow()
    except HTTPError as err:
        assert(err.status_code == 0)
    else:
        raise AssertionError

if __name__ == "__main__":
    test_case_0()

    test_HTTPResponse_rethrow()

# Generated at 2022-06-26 08:07:39.020925
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:07:40.375192
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:41.464726
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:07:49.356549
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    r = [[''], 1, 2, [], [{}, {}]]
    try:
        h_t_t_p_client_0 = HTTPClient()
        h_t_t_p_client_0.fetch(r[0], method=r[1], headers=r[2], body=r[3])
    except:
        return
    if type(r[0]) is not str:
        try:
            h_t_t_p_client_0.fetch(r[0], method=r[1], headers=r[2], body=r[3])
        except:
            return


# Generated at 2022-06-26 08:07:52.695340
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    http_c_lient_0 = AsyncHTTPClient(force_instance=True)


# Generated at 2022-06-26 08:07:59.895825
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-26 08:08:12.150726
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 08:08:13.898661
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 08:08:15.670289
# Unit test for function main
def test_main():
    # Replace 'pass' with unit test code
    pass


# Generated at 2022-06-26 08:08:22.371136
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    print("Testing method fetch_impl of class AsyncHTTPClient...")
    h_t_t_p_request_0 = HTTPRequest()
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, None)
    print("Done testing method fetch_impl of class AsyncHTTPClient, " +
          "no errors detected")


# Generated at 2022-06-26 08:08:34.823539
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    """Tests the __new__ method of the AsyncHTTPClient class.
    """
    # Test cases
    def test_case_0():
        """Test case 0 for __new__"""
        h_t_t_p_client_0 = AsyncHTTPClient()
        h_t_t_p_client_1 = AsyncHTTPClient(force_instance=True)
        h_t_t_p_client_0 = AsyncHTTPClient(force_instance=True)
        h_t_t_p_client_1 = AsyncHTTPClient()

    def test_case_1():
        """Test case 1 for __new__"""
        h_t_t_p_client_0 = AsyncHTTPClient(force_instance=True)

    # Test suite.

# Generated at 2022-06-26 08:08:36.516852
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-26 08:08:44.112335
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    http_request_0 = HTTPRequest('lkxgegtias')
    def handle_response_0(response_0: HTTPResponse) -> None:
        pass
    async_http_client_0 = AsyncHTTPClient()
    async_http_client_0.fetch_impl(http_request_0, handle_response_0)


# Generated at 2022-06-26 08:08:48.883528
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Test with default args
    async_h_t_t_p_client_0 = AsyncHTTPClient()
    # Test with arg force_instance=True
    async_h_t_t_p_client_1 = AsyncHTTPClient(force_instance=True)



# Generated at 2022-06-26 08:08:55.194751
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    http_client_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest(url='')
    _RequestProxy_0 = _RequestProxy(h_t_t_p_request_0, defaults={})
    # assert _RequestProxy_0.__getattr__('_body') is None
    assert _RequestProxy_0.__getattr__('_body') == b'', 'ERROR:__getattr__ in method test__RequestProxy___getattr__ of class _RequestProxy'


# Generated at 2022-06-26 08:08:56.686527
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # TODO: write your code here.
    pass


# Generated at 2022-06-26 08:09:30.097983
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    g_t_s_t_s_t_s_t = HTTPClient()
    g_t_s_t_s_t_s_t.fetch_impl(
        str('gtsss'),
        lambda: 0,
    )

HTTPRequest.DEFAULTS = dict(
    connect_timeout=20.0,
    request_timeout=20.0,
    follow_redirects=True,
    max_redirects=5,
    decompress_response=True,
    validate_cert=True,
    proxy_host=None,
    proxy_port=None,
    proxy_username=None,
    proxy_password=None,
    allow_nonstandard_methods=False,
    use_gzip=True,
)  # type: Dict[str, Any]
HTTPRequest._DE

# Generated at 2022-06-26 08:09:30.875370
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 08:09:33.722026
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient()


if __name__ == '__main__':
    test_AsyncHTTPClient___new__()

# Generated at 2022-06-26 08:09:37.121418
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:09:41.044549
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_0.fetch("http://www.google.com/")
    #
    h_t_t_p_client_1 = HTTPClient()
    h_t_t_p_client_1.fetch("http://www.google.com/")

# Generated at 2022-06-26 08:09:48.334989
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Test Case 0
    try:
        AsyncHTTPClient()
        test_case_0()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-26 08:09:57.713172
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    # Test case for AsyncHTTPClient.fetch_impl
    import tornado.web
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase

    class BlockingHandler(tornado.web.RequestHandler):
        def get(self):
            yield gen.sleep(0.5)
            self.write('hello world!')

    class BlockingTestCase(AsyncHTTPTestCase, LogTrapTestCase):
        def get_app(self):
            return tornado.web.Application([('/', BlockingHandler)])

        @gen.coroutine
        def test_blocking(self):
            # Use curl_httpclient to avoid blocking on open sockets
            client = AsyncHTTPClient(force_instance=True, impl=CurlAsyncHTTPClient)
            response = yield client.fetch(self.get_url('/'))


# Generated at 2022-06-26 08:10:03.310746
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    print('Case 0')
    try:
        test_case_0()
        print('Case 0 passed')
    except Exception as e:
        print('Case 0 failed')
        print(e)
    print('Case 1')
    try:
        test_case_1()
        print('Case 1 passed')
    except Exception as e:
        print('Case 1 failed')
        print(e)
    print('Case 2')
    try:
        test_case_2()
        print('Case 2 passed')
    except Exception as e:
        print('Case 2 failed')
        print(e)
    print('Case 3')
    try:
        test_case_3()
        print('Case 3 passed')
    except Exception as e:
        print('Case 3 failed')
        print(e)
    print('Case 4')


# Generated at 2022-06-26 08:10:05.629587
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    h_t_t_p_client_0 = AsyncHTTPClient(force_instance = True)


# Generated at 2022-06-26 08:10:16.130743
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    output_error = []
    output = []
    http_client_0 = HTTPClient()
    h_t_t_p_client_0 = HTTPClient()
    try:
        response_0 = h_t_t_p_client_0.fetch("http://www.google.com/")
        if response_0.code != 200:
            output_error.append(response_0.code)
        else:
            output.append(response_0.code)
    except HTTPError as e_0:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        output_error.append("Error: " + str(e_0))