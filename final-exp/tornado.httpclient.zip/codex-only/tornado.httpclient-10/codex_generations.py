

# Generated at 2022-06-24 08:30:26.547964
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient.configure(None)
    io_loop = IOLoop()
    io_loop.make_current()
    client1 = AsyncHTTPClient()
    client2 = AsyncHTTPClient()
    assert client1 is client2
    client1.close()
    client2.close()
    io_loop.close()



# Generated at 2022-06-24 08:30:31.782207
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    import tornado.testing

    class TestAsyncHTTPClient(tornado.testing.AsyncHTTPTestCase):
        def get_app(self) -> application:
            return Application([])

        def test_http_client_constructor(self) -> None:
            @gen.coroutine
            def f() -> None:
                response = yield AsyncHTTPClient().fetch(self.get_url("/"))
                assert response.body == b"Hello"

            IOLoop.current().run_sync(f)

    test_AsyncHTTPClient()



# Generated at 2022-06-24 08:30:40.419968
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://example.com/foo")
    response = HTTPResponse(
        request=request,
        code=200,
        headers=None,
        buffer=None,
        effective_url=None,
        error=None,
        request_time=None,
        time_info=None,
        reason=None,
        start_time=None,
    )
    assert response.request == request
    assert response.code == 200
    assert response.reason == "Unknown"
    assert response.body == b""

    headers = httputil.HTTPHeaders({
        "Content-Type": "text/html",
        "Content-Length": "100",
    })

# Generated at 2022-06-24 08:30:42.294762
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    assert AsyncHTTPClient(force_instance=True, defaults=dict(user_agent="MyUserAgent")).close() != None, f"AsyncHTTPClient.close() != None"

# Generated at 2022-06-24 08:30:43.755617
# Unit test for function main
def test_main():
    httpclient.main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:30:54.974461
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    http_request = HTTPRequest(url='http://example.com/')
    assert http_request.headers == httputil.HTTPHeaders()
    assert http_request.proxy_host is None
    assert http_request.proxy_port is None
    assert http_request.proxy_username is None
    assert http_request.proxy_password == ''
    assert http_request.url == 'http://example.com/'
    assert http_request.method == 'GET'
    assert http_request.body is None
    assert http_request.body_producer is None
    assert http_request.auth_username is None
    assert http_request.auth_password is None
    assert http_request.auth_mode is None
    assert http_request.connect_timeout == 20.0
    assert http_request.request_timeout == 20.0


# Generated at 2022-06-24 08:30:57.447216
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-24 08:31:05.592647
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async_http_client = AsyncHTTPClient()
    async_http_client.initialize()

    assert "" == async_http_client.defaults["auth_username"]
    assert None == async_http_client.defaults["body_producer"]
    assert "" == async_http_client.defaults["connect_timeout"]
    assert "" == async_http_client.defaults["decompress_response"]
    assert "" == async_http_client.defaults["expect_100_continue"]
    assert "" == async_http_client.defaults["follow_redirects"]
    assert "" == async_http_client.defaults["max_redirects"]
    assert "" == async_http_client.defaults["max_buffer_size"]
    assert "" == async_http_client.defaults["network_interface"]
   

# Generated at 2022-06-24 08:31:09.207429
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    hc = HTTPClient(async_client_class=AsyncHTTPClient)
    del hc



# Generated at 2022-06-24 08:31:10.199485
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    inst = AsyncHTTPClient()
    inst.close()

# Generated at 2022-06-24 08:31:21.331159
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.web import Application, RequestHandler
    import requests

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    def test_HTTPResponse_rethrow():

        app = Application([("/", MainHandler)])
        server = HTTPServer(app)
        server.listen(8888)
        loop = IOLoop.current()

# Generated at 2022-06-24 08:31:28.178102
# Unit test for function main
def test_main():
  import sys
  sys.argv.append("http://www.example.com/")
  from tornado.options import options
  options.print_headers = False
  options.print_body = True
  options.follow_redirects = True
  options.validate_cert = True
  main()


__all__ = [
    "HTTPResponse",
    "HTTPRequest",
    "HTTPError",
    "AsyncHTTPClient",
    "HTTPClient",
    "main",
    "CurlAsyncHTTPClient",
    "CurlError",
    "SimpleAsyncHTTPClient",
    "HTTPClientError",
]

# Generated at 2022-06-24 08:31:32.222550
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Constructor of AsyncHTTPClient
    # AsyncHTTPClient(force_instance=False, **kwargs) -> AsyncHTTPClient
    client = AsyncHTTPClient()
    # AsyncHTTPClient.initialize(defaults=None) -> None
    client.initialize()
    # AsyncHTTPClient.initialize(defaults=None) -> None
    client.initialize(defaults=dict(user_agent="MyUserAgent"))



# Generated at 2022-06-24 08:31:35.967874
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    httpRequest = HTTPRequest('http://www.baidu.com', method='POST', headers={'head': 'head'}, body='body')
    assert httpRequest.headers == {'head': 'head'}
    assert httpRequest.url == 'http://www.baidu.com'
    assert httpRequest.method == 'POST'
    assert httpRequest.body == 'body'


# Generated at 2022-06-24 08:31:46.683389
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    x = HTTPResponse(
        request = None,
        code = 200,
        headers = httputil.HTTPHeaders({"key1": "value1"}),
        buffer = None,
        effective_url = "",
        error = None,
        request_time = 0,
        time_info = None,
        reason = None,
        start_time = None
    )
    expected = "HTTPResponse(headers={'Key1': 'value1'}, effective_url='', code=200, request=None, error=None, request_time=0, start_time=None, time_info={}, reason=None, buffer=None)"
    assert str(x) == expected
    assert repr(x) == expected
    # assert str(x.__repr___()) == expected


# Generated at 2022-06-24 08:31:49.418632
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    # __del__ of class 'HTTPClient'
    # The __del__ method of class 'HTTPClient'
    pass

# Generated at 2022-06-24 08:32:01.997155
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest('http://www.google.com')
    assert HTTPRequest == type(request)
    assert 'http://www.google.com' == request.url
    assert 'GET' == request.method
    assert isinstance(request.body, bytes)
    assert b'' == request.body
    assert None is request.proxy_host
    assert None is request.proxy_port
    assert 0 == request.connect_timeout
    assert 0 == request.request_timeout
    assert True is request.follow_redirects
    assert 5 == request.max_redirects
    assert '' == request.user_agent
    assert False is request.use_gzip
    assert False is request.network_interface
    assert None is request.streaming_callback
    assert None is request.header_callback
    assert None is request.prepare_curl

# Generated at 2022-06-24 08:32:09.192674
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

	# Create a instance of Class HTTPRequest
	request = HTTPRequest(url='http://www.google.com', headers=dict(Host='reqres.in'))

	# Create a instance of Class AsyncHTTPClient
	an_http_client = AsyncHTTPClient()

	# Create a callback
	def handle_response(response):
		print(response)

	# Call the method fetch_impl and pass the required arguments
	an_http_client.fetch_impl(request=request, callback=handle_response)


# test the functionality of unit test AsyncHTTPClient
test_AsyncHTTPClient_fetch_impl()

# Generated at 2022-06-24 08:32:09.752662
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-24 08:32:10.772635
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    a = HTTPClient()
    a.__del__()



# Generated at 2022-06-24 08:32:12.369345
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(self, request, callback)
    pass


# Generated at 2022-06-24 08:32:15.433454
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    client = HTTPClient()
    client.close()


# Generated at 2022-06-24 08:32:20.137517
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    import os
    import tornado.ioloop
    http_client = HTTPClient()
    io_loop = tornado.ioloop.IOLoop.current()
    assert isinstance(http_client, HTTPClient)
    assert isinstance(io_loop, tornado.ioloop.IOLoop)
    http_client.close()



# Generated at 2022-06-24 08:32:22.640543
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    try:
        http_client = httpclient.HTTPClient()
    except Exception:
        http_client = None
    if http_client: # Created successfully
        http_client.__del__()



# Generated at 2022-06-24 08:32:33.712056
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import _configured_class

    class TestAsyncHTTPClient(AsyncHTTPClient):
        pass

    class MyTest(AsyncTestCase):
        @gen_test
        def test(self):
            client1 = TestAsyncHTTPClient()

            def make_client() -> AsyncHTTPClient:
                return AsyncHTTPClient()

            client2 = yield gen.coroutine(make_client)()
            client3 = yield gen.coroutine(make_client)()
            # Two clients have been created
            assert client1 is not client2
            assert client1 is not client3
            # Client 2 and 3 are the same. They have been created by
            # the same IOLoop.
            assert client2 is client3

            # Client 2 and 3 are instances of the default class

# Generated at 2022-06-24 08:32:39.703854
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    from tornado import gen, ioloop
    import tornado.curl_httpclient

    @gen.coroutine
    def main():
        tornado.curl_httpclient.AsyncHTTPClient.configure(
            tornado.curl_httpclient.CurlAsyncHTTPClient
        )
        http_client = tornado.curl_httpclient.AsyncHTTPClient(
            defaults=dict(user_agent="my-user-agent/1.0",)
        )

        # Test synchronous
        try:
            response = http_client.fetch("http://www.google.com/")
            print(response.body)
        except Exception as e:
            print("Error: %s" % e)

        # Test asynchronous

# Generated at 2022-06-24 08:32:45.150710
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    pass

    # request = HTTPRequest('http://www.baidu.com', method='GET', body='body')
    # defaults = {'headers': {'h1': 'h1'}}
    # request_proxy = _RequestProxy(request, defaults)
    # assert request_proxy.headers['h1'] == 'h1'
    # assert request_proxy.body == 'body'
    # assert request_proxy.method == 'GET'
    # assert request_proxy.url == 'http://www.baidu.com'



# Generated at 2022-06-24 08:32:51.359990
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    HTTPClientError = tornado.httpclient.HTTPClientError
    http_client_error = HTTPClientError(code = 1)
    assert http_client_error.__repr__() == "HTTP 1: Unknown"

    http_client_error = HTTPClientError(code = 2,
                                        message = "2",
                                        response = "haha")
    assert http_client_error.__repr__() == "HTTP 2: 2"

# Generated at 2022-06-24 08:32:53.947758
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    client = AsyncHTTPClient()
    assert isinstance(client, AsyncHTTPClient)
    client2 = AsyncHTTPClient()
    assert client is client2



# Generated at 2022-06-24 08:32:57.583875
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    code = 599
    message = "HTTP 599: Test"
    e = HTTPClientError(code, message)
    assert e.code == 599
    assert e.message == "Test"
    assert str(e) == message

HTTPError = HTTPClientError

# The following exceptions are no longer used except for backwards
# compatibility.  New code should catch the base classes (HTTPError or
# IOError) instead of these subclasses.



# Generated at 2022-06-24 08:33:02.489315
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from .httpclient import AsyncHTTPClient

    client = AsyncHTTPClient()
    request = HTTPRequest('http://www.google.com')
    response = client.fetch(request)
    assert isinstance(response, HTTPResponse)
    assert response.code == 200



# Generated at 2022-06-24 08:33:04.560507
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():  # type: ignore
    # This test is not only for mypy, but also ensures that the no-args constructor
    # initializes everything properly.
    AsyncHTTPClient()
    AsyncHTTPClient(force_instance=True)



# Generated at 2022-06-24 08:33:08.846021
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    a = HTTPClient(async_client_class=SimpleAsyncHTTPClient)
    a.fetch('http://www.google.com/')
    a.close()
    # a is now closed
    a.fetch('http://www.google.com/')


# Generated at 2022-06-24 08:33:17.349765
# Unit test for method __getattr__ of class _RequestProxy

# Generated at 2022-06-24 08:33:18.587308
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()



# Generated at 2022-06-24 08:33:21.146119
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://www.google.com")
    proxy = _RequestProxy(request, None)
    assert proxy.request == request
    assert proxy.defaults == None

# Generated at 2022-06-24 08:33:25.293879
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Prepare parameter
    request = _RequestProxy(request=HTTPRequest(url='/'),defaults={'a':object()})
    request.__dict__['request'] = HTTPRequest(url='/')
    # Run
    result = request.__getattr__('request')
    # Verify
    assert result is request.request
    # Clean up - None


# Generated at 2022-06-24 08:33:32.677315
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()

# Generated at 2022-06-24 08:33:42.470326
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest(
        url='https://localhost',
        headers={
            'user-agent': 'my-user-agent'
        })
    response = HTTPResponse(
        request=request,
        code=200,
        headers=httputil.HTTPHeaders(),
        buffer=BytesIO(),
        effective_url='https://localhost',
        error=None,
        request_time=0.0,
        time_info={},
        reason='Unknown',
        start_time=0.0
    )
    ret = response.__repr__()
    print(ret)



# Generated at 2022-06-24 08:33:50.521059
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import tornado.testing

    class ExpectException(Exception):
        pass
    
    class TestAsyncHTTPClient(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            raise NotImplementedError()
        
        def test_fetch_impl(self):
            # test whether function fetch_impl of class AsyncHTTPClient yield a future instance.
            # self.http_client is an instance of AsyncHTTPClient class.
            @gen.coroutine
            def go():
                future = self.http_client.fetch_impl(self.get_url())
                self.assertTrue(isinstance(future, Future))
                with self.assertRaises(KeyError):
                    yield future
            self.io_loop.run_sync(go)
            # test whether a callback given to fetch

# Generated at 2022-06-24 08:33:53.318942
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client = AsyncHTTPClient()
    response = http_client.fetch("http://www.google.com/")
    http_client.close()

# Generated at 2022-06-24 08:33:56.689254
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    hc = HTTPClient()
    print(hc.fetch("http://www.google.com"))



# Generated at 2022-06-24 08:33:59.408869
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # super(AsyncHTTPClient, cls).configure(impl, **kwargs)
    pass # TODO


# Generated at 2022-06-24 08:34:03.298505
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    c = AsyncHTTPClient()
    c1 = AsyncHTTPClient()
    c.close()
    assert bool(c._closed is True)
    c1.close()
    assert bool(c1._closed is True)


# Generated at 2022-06-24 08:34:06.421565
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    obj = AsyncHTTPClient()
    request = HTTPRequest()
    callback = lambda : 0
    return obj.fetch_impl(request, callback)

# Generated at 2022-06-24 08:34:09.663206
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():

    h = HTTPClientError(code=404, message=None)
    assert h.__repr__() == 'HTTP 404: Unknown'

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:34:17.385947
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://test.test.test"
    # url = "https://test.test.test"
    # url = "https://test.test.test:8080"
    # url = "https://user:pass@test.test.test:8080"
    # url = "https://user:pass@test.test.test:8080/path?query"
    assert HTTPRequest(url=url).url == url

if __name__ == "__main__":
    test_HTTPRequest()

# Generated at 2022-06-24 08:34:25.522770
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://127.0.0.1:8000/test"
    method = "GET"
    headers = {
        "Content-Type": "text/html",
        "charset": "utf-8"
    }
    body = utf8("hello world!")
    auth_username = "test"
    auth_password = "test"
    auth_mode = "basic"
    connect_timeout = 20.0
    request_timeout = 20.0
    if_modified_since = datetime.datetime.now()
    follow_redirects = True
    max_redirects = 5

# Generated at 2022-06-24 08:34:36.412279
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # tests that the method rethrow() of class HTTPResponse raises an
    # HTTPError if the error attribute is not None
    response = HTTPResponse(
        request=HTTPRequest(url='http://www.bbc.co.uk'),
        code=200,
        headers=httputil.HTTPHeaders(),
        buffer=BytesIO(),
        effective_url='http://www.bbc.co.uk',
        error=None,
        request_time=3.14,
        time_info={'connect':3.14},
        reason='OK',
        start_time=3.14
    )
    with pytest.raises(HTTPError):
        response.rethrow()



# Generated at 2022-06-24 08:34:41.390408
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # impl could not be None
    class MyAsyncHTTPClient(AsyncHTTPClient):
        """The `AsyncHTTPClient` implementation in tornado.simple_httpclient
        simply calls `HTTPConnection.fetch()`.
        """

        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], Any]
        ) -> None:
            pass

    impl = MyAsyncHTTPClient()
    raise NotImplementedError()


# Generated at 2022-06-24 08:34:46.291354
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import tornado.simple_httpclient
    tornado.simple_httpclient.AsyncHTTPClient._instance_cache = None
    http_client = tornado.simple_httpclient.AsyncHTTPClient()
    http_client.close()
    # assert http_client==None


# Generated at 2022-06-24 08:34:54.288982
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    assert _RequestProxy(HTTPRequest("url"), {'code': 123}).url == 'url'
    assert _RequestProxy(HTTPRequest("url"), {'code': 123}).code == 123
    assert _RequestProxy(HTTPRequest("url"), {'code': 123}).method is None
    assert _RequestProxy(HTTPRequest("url", method='GET'), {}).method == 'GET'
    assert _RequestProxy(HTTPRequest("url"), {'method': 'GET'}).method == 'GET'
    assert _RequestProxy(HTTPRequest("url", method='GET'), {'method': 'PUT'}).method == 'GET'



# Generated at 2022-06-24 08:34:55.484676
# Unit test for method rethrow of class HTTPResponse

# Generated at 2022-06-24 08:35:01.339676
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from yapic.di import Injector

    i = Injector()
    i.binder.bind(AsyncHTTPClient, to="tornado.simple_httpclient.SimpleAsyncHTTPClient")
    i.evaluate()
    assert isinstance(AsyncHTTPClient(), AsyncHTTPClient)
    assert "tornado.simple_httpclient" in AsyncHTTPClient.__module__
    assert "test_AsyncHTTPClient___new__.<locals>" in AsyncHTTPClient._async_clients()[IOLoop.current()].__module__

# Generated at 2022-06-24 08:35:03.199587
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()


# Generated at 2022-06-24 08:35:07.241224
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    url = "http://113.110.229.90:5000/"
    http_client = HTTPClient()
    try:
        response = http_client.fetch(url)
        print(response)
    except:
        print("error")
    finally:
        http_client.close()

# Generated at 2022-06-24 08:35:13.507991
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    pass


# Generated at 2022-06-24 08:35:25.450725
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest(url = 'http://www.host.com')
    code = 200
    headers = httputil.HTTPHeaders({'Content-Type': 'text/html'})
    body = b'aaa'
    buffer = BytesIO(body)
    effective_url = 'http://www.host.com'
    error = None
    request_time = 1.0
    time_info = {'starttransfer_time':0.5, 'namelookup_time':0.2}
    reason = 'OK'
    start_time = 2.0

# Generated at 2022-06-24 08:35:30.545161
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # HTTPResponse.__repr__() -> str
    # __repr__ method is a convenient way to generate object representation.
    # It is helpful to debug.
    request = HTTPRequest('http://www.baidu.com')
    h = HTTPResponse(request, 999)
    print(h.__repr__())


# Example of using  class HTTPResponse

# Generated at 2022-06-24 08:35:31.808110
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    client = HTTPClient()
    client.close()



# Generated at 2022-06-24 08:35:33.323289
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    print(HTTPRequest.__doc__)
    


# Generated at 2022-06-24 08:35:35.158984
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    with pytest.raises(Exception):
        HTTPClient().close()



# Generated at 2022-06-24 08:35:40.123375
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    tornado.options.options.logging = 'debug'
    http_client = HTTPClient(defaults=dict(user_agent="my-user-agent1"))
    http_client.close()
    assert http_client._closed == True


# Generated at 2022-06-24 08:35:43.996757
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    def mock_close(): pass
    http_client = httpclient.HTTPClient(mock_close)
    http_client.close = mock_close
    http_client.__del__()
    mock_close.assert_called_once_with()

# Generated at 2022-06-24 08:35:49.190320
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    defaults = {"connect_timeout": 100, "request_timeout": 100}
    request = HTTPRequest("http://127.0.0.1:8999", connect_timeout=None, 
        request_timeout=None)
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.request_timeout == 100
    assert request_proxy.connect_timeout == 100
    assert request_proxy.proxy_host is None


# Generated at 2022-06-24 08:35:52.495664
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    io_loop = IOLoop.current()
    io_loop.run_sync(functools.partial(httpclient.AsyncHTTPClient.fetch, "https://google.com", callback=None))
    io_loop.stop()
    io_loop.close()

# Generated at 2022-06-24 08:35:53.495334
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-24 08:36:01.776238
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(404, "Not Found", "response")
    except HTTPClientError as e:
        assert e.code == 404
        assert e.message == "Not Found"
        assert e.response == "response"


HTTPError = HTTPClientError

RequestStartEvent = collections.namedtuple("RequestStartEvent", ("request", "time"))
RequestEndEvent = collections.namedtuple("RequestEndEvent", ("request", "response"))



# Generated at 2022-06-24 08:36:02.844579
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass


# Generated at 2022-06-24 08:36:09.383277
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async_client_class = AsyncHTTPClient
    instance_cache = cls._async_clients()  # call instance_cache method of AsyncHTTPClient class
    if instance_cache is not None and instance_cache in instance_cache: # check if instance_cache is not None,and it is present in instance_cache
        return instance_cache[instance_cache]  # return instance_cache[instance_cache]
    instance = super(AsyncHTTPClient, cls).__new__(cls, **kwargs)  # type: ignore
    # Make sure the instance knows which cache to remove itself from.
    # It can't simply call _async_clients() because we may be in
    # __new__(AsyncHTTPClient) but instance.__class__ may be
    # SimpleAsyncHTTPClient.
    instance._instance_cache = instance_cache

# Generated at 2022-06-24 08:36:11.627777
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    async def test():
        client = AsyncHTTPClient()
        return client._closed
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    return None

# Generated at 2022-06-24 08:36:24.938923
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://github.com/"
    method = "POST"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    body = "name=zhaogonglong@gmail.com"
    auth_username = "zhao"
    auth_password = "gong"
    auth_mode = "basic"
    connect_timeout = 20.0
    request_timeout = 20.0
    if_modified_since = 1
    follow_redirects = True
    max_redirects = 5

# Generated at 2022-06-24 08:36:27.745536
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    e = HTTPClientError(404, 'message', 'response')
    eq(str(e), 'HTTP 404: message')

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:36:30.200953
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://www.google.com"
    req = HTTPRequest(url)
    assert req.url == url


# Generated at 2022-06-24 08:36:34.735526
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    import tornado.httpclient
    request1 = tornado.httpclient.HTTPRequest(url="www.baidu.com",method="GET")
    request_proxy1 = _RequestProxy(request=request1,defaults={})
    assert request_proxy1.method == "GET"

# Generated at 2022-06-24 08:36:39.758047
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    client = AsyncHTTPClient()
    try:
        response = client.fetch("http://www.google.com")
    except Exception as e:
        print("Error: %s" % e)
    else:
        print(response.body)

test_AsyncHTTPClient_fetch()


# Generated at 2022-06-24 08:36:46.268785
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    assert isinstance(AsyncHTTPClient(), AsyncHTTPClient)
    assert AsyncHTTPClient(force_instance=True) is not AsyncHTTPClient(force_instance=True)
    b = AsyncHTTPClient(force_instance=True)
    assert b is not AsyncHTTPClient(force_instance=True)
    assert b.io_loop is AsyncHTTPClient().io_loop
    assert b is AsyncHTTPClient(force_instance=True, defaults={"hello": "world"})



# Generated at 2022-06-24 08:36:53.135045
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import AsyncHTTPClient
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.autoreload

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    application = tornado.web.Application([(r"/", MainHandler)])
    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(8888)
    tornado.autoreload.start()

    # Start IOLoop
    tornado.ioloop.IOLoop.instance().start()

    client = AsyncHTTPClient()
    response = client.fetch("http://localhost:8888")

# Generated at 2022-06-24 08:36:59.000098
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    request = "https://baike.baidu.com/item/%E6%B5%8B%E8%AF%95/21312771"
    httpclient_obj = HTTPClient()
    response = httpclient_obj.fetch(request)
    assert response.code == 200 or response.code == 304



# Generated at 2022-06-24 08:37:05.158127
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-24 08:37:10.022555
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://localhost:80/")
    resp = HTTPResponse(request, 200)
    assert resp.request.url == request.url
    # TODO: Could add more unit tests for this class

# Exported for callers that need a request object

# Generated at 2022-06-24 08:37:11.541854
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    obj = AsyncHTTPClient()
    assert isinstance(obj, AsyncHTTPClient)



# Generated at 2022-06-24 08:37:20.272037
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    import pytest
    try:
        HTTPResponse(None, None, None).rethrow()
    except Exception as e:
        if isinstance(e, HTTPError):
            pytest.fail("The method should not raise any exception")
        else:
            pytest.fail("The method should not raise any exception")


# defines a single interface compatible with both yield and callback-based
# HTTP clients.  (Callback-based clients are not required to return a
# Future, but they may.)  May also be used with Futures (as long as the
# Future's ``result()`` method takes a callback).

# Generated at 2022-06-24 08:37:32.088656
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('http://www.google.co.kr')
    request.auth_username = None
    request.auth_password = None
    request.auth_mode = None
    request.connect_timeout = 20.0
    request.request_timeout = 20.0
    request.follow_redirects = True
    request.max_redirects = 5
    request.user_agent = 'Tornado/4.2.0'
    request.decompress_response = True
    request.network_interface = None
    request.expect_100_continue = False
    request.proxy_host = None
    request.proxy_port = None
    request.proxy_username = None
    request.proxy_password = None
    request.proxy_auth_mode = 'basic'

# Generated at 2022-06-24 08:37:35.371880
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # this test uses the curl client to fetch urls for coverage
    # just verify that the AsyncHTTPClient constructor does not crash
    from tornado.curl_httpclient import CurlAsyncHTTPClient
    CurlAsyncHTTPClient()



# Generated at 2022-06-24 08:37:48.380334
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    request = 'a string'
    raise_error = 'a string'
    kwargs = {'kwarg1': 'a string', 'kwarg2': 'a string'}
    client = AsyncHTTPClient()

# Generated at 2022-06-24 08:37:57.313531
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    """Test constructor of class HTTPResponse"""

    http_response = HTTPResponse(
        HTTPRequest(url = "http://www.google.com"),
        code=200,
        headers=None,
        buffer=None,
        effective_url = None,
        error = None,
        request_time = None,
        time_info = None,
        reason = None,
        start_time = None
    )
    assert isinstance(http_response, HTTPResponse), "Object is not of class HTTPResponse"


# Generated at 2022-06-24 08:38:03.524662
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    _req = HTTPRequest('https://www.google.com')
    _dct = dict(method = 'GET')
    _proxy = _RequestProxy(_req,_dct)
    assert(_proxy.method == 'GET')
    assert(_proxy.method == _dct['method'])
    assert(_proxy.method != _req.method)

# Generated at 2022-06-24 08:38:04.262663
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-24 08:38:10.140626
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("www.baidu.com",method="GET")
    defaults = {"connect_timeout":30}
    request_proxy = _RequestProxy(request,defaults)
    print(request_proxy.request.url)
    print(request_proxy.connect_timeout)

# test__RequestProxy()


# Generated at 2022-06-24 08:38:11.372023
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass


# Generated at 2022-06-24 08:38:12.196824
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    self = HTTPClient()

# Generated at 2022-06-24 08:38:12.901806
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-24 08:38:16.152192
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # This tests the implementation of AsyncHTTPClient, which could
    # change in the future
    client = AsyncHTTPClient()
    assert isinstance(client, AsyncHTTPClient)



# Generated at 2022-06-24 08:38:21.017364
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(599,"Timeout",response=HTTPResponse(request=HTTPRequest(),code=599))
    except HTTPClientError as e:
        if e.code != 599 and e.message != "Timeout" and e.response.code != 599:
            raise Exception("HTTPClientError does not correctly initialise HTTP response object")

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:38:33.569754
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    body = b'body of HTTPResponse'
    buffer = BytesIO(body)
    http_response = HTTPResponse(request=None, code=200, headers=None, buffer=buffer,
                                 effective_url=None, error=None, request_time=0.0,
                                 time_info=None, reason=None, start_time=0.0)
    http_response_repr = http_response.__repr__()
    assert isinstance(http_response_repr, str)
    assert 'HTTPResponse' in http_response_repr
    assert 'code=200' in http_response_repr
    assert 'reason=' in http_response_repr
    assert 'buffer=' in http_response_repr
    assert 'effective_url=' in http_response_repr

# Generated at 2022-06-24 08:38:34.369913
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-24 08:38:40.055604
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-24 08:38:42.771674
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    a = _RequestProxy(HTTPRequest(url="www.abc.com"),{"a":"b"})
    if a.a != "b":
        raise RuntimeError("a.a does not equal to b")



# Generated at 2022-06-24 08:38:53.985677
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = 'http://www.baidu.com'
    method = 'GET'
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'
    request = HTTPRequest(url, method=method, user_agent=user_agent)
    print(request.url)
    print(request.body)
    print(request.method)
    print(request.user_agent)
    print(request.headers)
    print(request.start_time)

if __name__ == '__main__':
    test_HTTPRequest()


# Generated at 2022-06-24 08:38:54.902066
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    pass



# Generated at 2022-06-24 08:39:03.173669
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))


# Generated at 2022-06-24 08:39:04.230501
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass # TODO


# Generated at 2022-06-24 08:39:09.111299
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():  # type: ignore
    from _pytest.monkeypatch import MonkeyPatch
    monkeypatch = MonkeyPatch()

    def mock_loop():
        return mock_loop

    monkeypatch.setattr(asyncio, "get_event_loop", mock_loop)

    AsyncHTTPClient()
    AsyncHTTPClient(force_instance=True)

    monkeypatch.undo()



# Generated at 2022-06-24 08:39:11.808533
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    a_HTTPClient = HTTPClient()
    a_HTTPClient.__del__()

# Generated at 2022-06-24 08:39:15.552976
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    client = AsyncHTTPClient()
    assert isinstance(client, AsyncHTTPClient)
    client2 = AsyncHTTPClient()
    assert client is client2



# Generated at 2022-06-24 08:39:20.048856
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    HTTPClientError.__repr__(HTTPClientError(400, response=HTTPResponse(request=HTTPRequest(url='http://example.com/'), code=200, headers=None, buffer=None, effective_url='http://example.com/', error=None, request_time=1, time_info=None)))

HTTPClientError.__repr__ = test_HTTPClientError___repr__


HTTPError = HTTPClientError



# Generated at 2022-06-24 08:39:22.370382
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    HTTPClient("tornado.curl_httpclient.CurlAsyncHTTPClient")



# Generated at 2022-06-24 08:39:24.510295
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # type: () -> None
    test_AsyncHTTPClient_initialize()
    pass


# Generated at 2022-06-24 08:39:26.260522
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    _AsyncHTTPClient()



# Generated at 2022-06-24 08:39:27.989302
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    r = HTTPResponse(HTTPRequest('http://test.com'), 403)
    r.rethrow()

# Generated at 2022-06-24 08:39:40.706818
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-24 08:39:42.384056
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado
    # client = AsyncHTTPClient(max_clients=200)
    return NotImplemented


# Generated at 2022-06-24 08:39:46.079929
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    response = http_client.fetch("http://www.google.com/")
    assert response is not None
    del http_client


# Generated at 2022-06-24 08:39:56.875354
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest('url')
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = 'url'
    error = None
    request_time = 10
    time_info = {}
    reason = None
    start_time = None
    obj = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    assert repr(obj) == 'HTTPResponse(code=200,effective_url=\'url\',error=None,headers=HTTPHeaders({}),request=HTTPRequest(\'url\'),request_time=10.0,reason=\'Unknown\',start_time=None,time_info={},url=\'url\')'



# Generated at 2022-06-24 08:39:58.739194
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    object_ = HTTPClient()
    object_.close()
    object_ = None
    raise Exception('TODO')


# Generated at 2022-06-24 08:40:06.272912
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    assert isinstance(AsyncHTTPClient(), SimpleAsyncHTTPClient)
    assert isinstance(AsyncHTTPClient(force_instance=False), SimpleAsyncHTTPClient)
    assert isinstance(AsyncHTTPClient(force_instance=True), SimpleAsyncHTTPClient)

    AsyncHTTPClient.configure('tornado.test.httpclient_test.CustomAsyncHTTPClient')
    assert isinstance(AsyncHTTPClient(force_instance=False), CustomAsyncHTTPClient)

# Generated at 2022-06-24 08:40:18.869028
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def start_server(i):
        import socket
        import time
        import threading
        s = socket.socket()
        s.bind(("localhost", 0))
        s.listen(5)
        c, addr = s.accept()
        time.sleep(i)
        c.send(b'HTTP/1.1 200 OK\r\nConnection: close\r\n'
               b'Content-Length: 2\r\n\r\nhi')
        c.close()
        s.close()
        threading.Thread(target=start_server, args=(i+1,)).start()

    threading.Thread(target=start_server, args=(0,)).start()
    ioloop = IOLoop.instance()
    client = AsyncHTTPClient(io_loop=ioloop)

# Generated at 2022-06-24 08:40:23.745838
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            raise Exception('Not implemented')
    import os
    import sys
    import unittest
    import unittest.mock


    class AsyncHTTPClientTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.async_client = TestAsyncHTTPClient(io_loop=self.io_loop)

        def tearDown(self):
            self.async_client.close()
            self.io_loop.close()
