

# Generated at 2022-06-24 08:30:29.627780
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    # Constructors with wrong type of parameter cases
    with pytest.raises(TypeError):
        HTTPRequest(url=2231)
    with pytest.raises(TypeError):
        HTTPRequest(url="www.google.com", method=2)
    with pytest.raises(TypeError):
        HTTPRequest(url="www.google.com", method="GET", 
                    headers='{}', body=8.8)
    with pytest.raises(TypeError):
        HTTPRequest(url="www.google.com", method="GET", 
                    headers={}, body=8.8)
    with pytest.raises(TypeError):
        HTTPRequest(url="www.google.com", method="GET", 
                    headers={}, body='byte string', 
                    auth_username=100)

# Generated at 2022-06-24 08:30:31.616668
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    return __repr__(self) == __str__(self)


# alias for backwards compatibility with Tornado 4.0
HTTPError = HTTPClientError



# Generated at 2022-06-24 08:30:32.834625
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:30:39.306476
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    try:
        http_client.fetch("http://www.google.com/")
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()
    print(http_client._closed)



# Generated at 2022-06-24 08:30:44.727018
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.testing import AsyncHTTPTestCase
    httpclient.AsyncHTTPClient.configure(httpclient.CurlAsyncHTTPClient)
    class TestAsyncHTTPClient(AsyncHTTPTestCase):
        def test_AsyncHTTPClient(self):
            async def f():
                http_client = AsyncHTTPClient()
                try:
                    response = await http_client.fetch("http://www.google.com")
                except Exception as e:
                    print("Error: %s" % e)
                else:
                    print(response.body)
            self.io_loop.run_sync(f)
            http_client.close()


# Generated at 2022-06-24 08:30:53.309747
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    defaults = {
        "body": "default",
        "body_producer": lambda x, y: None,
        "auth_username": "username",
        "auth_mode": "basic",
        "auth_password": "password",
    }
    # body is None
    request = HTTPRequest(url="http://google.com", method="GET")
    proxy = _RequestProxy(request, defaults)
    assert proxy.body == defaults["body"]
    assert proxy.body_producer == defaults["body_producer"]
    assert proxy.auth_username == defaults["auth_username"]
    assert proxy.auth_mode == defaults["auth_mode"]
    assert proxy.auth_password == defaults["auth_password"]

    # body is defined

# Generated at 2022-06-24 08:30:54.750765
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    h = HTTPResponse(request=HTTPRequest("url"), code=200)


# Generated at 2022-06-24 08:30:56.162684
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    http_client_error = HTTPClientError(code=404, message='Not Found')
    assert isinstance(http_client_error.__repr__(), str)


HTTPError = HTTPClientError

# Generated at 2022-06-24 08:31:02.116880
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    c = HTTPResponse('request', 'code', 'headers',
        'buffer', 'effective_url', 'error', 'request_time', 'time_info',
        'reason', 'start_time')
    assert repr(c) == "HTTPResponse(code='code',effective_url='effective_url',error='error',headers='headers',reason='reason',request='request',request_time='request_time',start_time='start_time',time_info='time_info')"
    
    


# Generated at 2022-06-24 08:31:14.468427
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest()
    print(HTTPResponse(request, code=200).__dict__)
    print(HTTPResponse(request, code=200, headers=None).__dict__)
    print(HTTPResponse(request, code=200, buffer=None).__dict__)
    print(HTTPResponse(request, code=200, effective_url=None).__dict__)
    error = HTTPError()
    print(HTTPResponse(request, code=200, error=error).__dict__)
    print(HTTPResponse(request, code=200, request_time=None).__dict__)
    print(HTTPResponse(request, code=200, time_info=None).__dict__)

# Generated at 2022-06-24 08:31:21.647781
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    def __test_AsyncHTTPClient_initialize():
        assert 0== AsyncHTTPClient().initialize() ==0

    def __test_AsyncHTTPClient_initialize_1():
        assert 0== AsyncHTTPClient().initialize() ==0

    __test_AsyncHTTPClient_initialize()
    __test_AsyncHTTPClient_initialize_1()
    __test_AsyncHTTPClient_initialize_2()

# Generated at 2022-06-24 08:31:26.121736
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    htpr = HTTPResponse(request=HTTPRequest(method="GET", url="http://localhost"),
                         code=200, headers=None, buffer=None, effective_url=None,
                         error=None, request_time=None, time_info=None)
    assert htpr.rethrow() is None



# Generated at 2022-06-24 08:31:27.079931
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass



# Generated at 2022-06-24 08:31:34.374407
# Unit test for function main
def test_main():
    import time
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase

    from tornado.options import define, options
    from tornado.util import b

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)

    class MainTest(AsyncHTTPTestCase, LogTrapTestCase):
        def handle_request(self, response):
            if __debug__:
                self.io_loop.add_callback(self.stop)


# Generated at 2022-06-24 08:31:42.165798
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import _RequestProxy


    ####
    ####TEST START
    ####
    # Tests of _RequestProxy.__getattr__
    #
    class Test(AsyncHTTPClient):

        def initialize(self, io_loop, defaults=None):
            self.defaults = defaults


# Generated at 2022-06-24 08:31:45.102439
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient")
    http_client = AsyncHTTPClient()
    # do something
    http_client.close()


# Generated at 2022-06-24 08:31:49.164189
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    AsyncHTTPClient.configure(SimpleAsyncHTTPClient)
    assert isinstance(AsyncHTTPClient(), SimpleAsyncHTTPClient)
    AsyncHTTPClient.configure(None)
    # If a default class has been registered, that should work too
    assert isinstance(AsyncHTTPClient(), SimpleAsyncHTTPClient)



# Generated at 2022-06-24 08:31:50.289110
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    HTTPClientError(599)


HTTPError = HTTPClientError  # type: Type[HTTPClientError]



# Generated at 2022-06-24 08:31:52.948511
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    # type: () -> None
    request = HTTPRequest("hostname:80")
    assert _RequestProxy(request, None)

# Generated at 2022-06-24 08:31:54.731729
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:31:55.939498
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass



# Generated at 2022-06-24 08:31:57.013056
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    HTTPClientError(404, message="test", response=HTTPResponse('test', code=404))

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:32:03.223356
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test the path of 'if self._closed:'
    from tornado.httpclient import AsyncHTTPClient
    from httpclient import HTTPRequest
    from httpclient import HTTPResponse
    client = AsyncHTTPClient()
    client.close()
    client.fetch_impl(request=HTTPRequest(), callback=lambda _: None)
    client.fetch_impl(request=HTTPRequest(), callback=lambda _: None)


# Generated at 2022-06-24 08:32:11.115368
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    '''
    Args:
        self: instance of class HTTPResponse, just for test
    '''
    print("test_HTTPResponse___repr__ is running...")

    http_response_instance = HTTPResponse(None, 200, None, None, None, None, None, None)

    expected_result = "HTTPResponse(effective_url=None,time_info={},reason=None,headers={},start_time=None,request_time=None,request=None,buffer=None,code=200)"
    actual_result = http_response_instance.__repr__()

    assert(expected_result == actual_result)
    print("the test result of HTTPResponse.__repr__ is passed!")



# Generated at 2022-06-24 08:32:22.368872
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    """Test for method __repr__ of class HTTPClientError"""
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_sockets
    from tornado.web import Application, RequestHandler
    import os

    # Setup
    def test_HTTPClientError___repr___setup(self):
        # Setup
        from tornado import gen
        from tornado.httpclient import AsyncHTTPClient
        from tornado.httpserver import HTTPServer
        from tornado.ioloop import IOLoop
        from tornado.netutil import bind_sockets
        from tornado.web import Application, RequestHandler
        import os
        import sys


# Generated at 2022-06-24 08:32:33.158333
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # For type annotation
    import typing
    # pyre-fixme[8]: Attribute has type `FrameType`; used as `None`.
    typing.get_type_hints(test_HTTPClient_fetch)

    from tornado import stack_context

    import io
    import socket
    import ssl
    import unittest
    from unittest import mock
    from tornado import gen

    from tornado.httpclient import HTTPResponse, HTTPRequest, AsyncHTTPClient

    # When this unit test is executed by `_get_unittest_module()`,
    # `AsyncHTTPClient.configure` is defined.
    # Otherwise, the class attribute is not defined.

# Generated at 2022-06-24 08:32:39.322953
# Unit test for function main
def test_main():
  import sys
  import unittest

  if sys.version_info < (3, 0):
    from mock import patch
  else:
    from unittest.mock import patch

  from tornado.testing import AsyncTestCase, main as unittest_main

  from tornado.httpclient import HTTPError

  class MainTest(AsyncTestCase):
    def setUp(self):
      super(MainTest, self).setUp()
      self.mock_http_client = patch('tornado.httpclient.HTTPClient')
      self.mock_http_client.start()

    def tearDown(self):
      self.mock_http_client.stop()


# Generated at 2022-06-24 08:32:41.869733
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    with pytest.raises(RuntimeError):
        raise RuntimeError()
    AsyncHTTPClient(force_instance=True)

# Generated at 2022-06-24 08:32:45.946896
# Unit test for function main
def test_main():
    import sys
    import functools
    import io
    import unittest
    import warnings

    try:
        import ssl  # type: ignore
    except ImportError:
        raise unittest.SkipTest("ssl module not present")

    from tornado.httpclient import HTTPError, HTTPRequest
    from tornado.testing import AsyncHTTPTestCase, gen_test


# Generated at 2022-06-24 08:32:52.037336
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.simple_httpclient as simple_httpclient
    http_client = HTTPClient(simple_httpclient.SimpleAsyncHTTPClient)
    try:
        response = http_client.fetch("https://www.google.com/")
        print(response.body)
    except HTTPError as e:
        print("Error: " + str(e))
    except Exception as e:
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-24 08:33:00.541717
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    def get_arg_by_index(args, index):
        return args.split(',')[index].split('=')[1]
    request = HTTPRequest("http://www.google.com", method="GET")
    res = HTTPResponse(request, code=200, reason="OK",
        headers={"Content-Type": "text/html"},
        buffer=BytesIO(b"test_HTTPResponse_body"),
        effective_url="http://www.google.com",
        error=None,
        request_time=0.01,
        time_info={"queue": 0.01, "namelookup": 0.01, "connect": 0.01, "pre_transfer": 0.01, "starttransfer": 0.01, "total": 0.01},
        start_time=0.01)

# Generated at 2022-06-24 08:33:09.283930
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    try:
        http_client = httpclient.HTTPClient()
        try:
            response = http_client.fetch("http://www.google.com/")
            print(response.body)
        except httpclient.HTTPError as e:
            # HTTPError is raised for non-200 responses; the response
            # can be found in e.response.
            print("Error: " + str(e))
        except Exception as e:
            # Other errors are possible, such as IOError.
            print("Error: " + str(e))
        http_client.close()
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))



# Generated at 2022-06-24 08:33:17.711114
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    import requests
    import tornado
    import tornado.gen
    import tornado.ioloop
    import tornado.web

    from typing import ClassVar
    from tornado.httpclient import AsyncHTTPClient

    class HelloHandler(tornado.web.RequestHandler):

        count: ClassVar[int] = 0          # Class member
        url: ClassVar[str] = 'http://localhost:8888/'  # Class member

        def get(self):
            HelloHandler.count += 1
            HelloHandler.url += str(HelloHandler.count)
            self.write("Hello, world")

    class MainHandler(tornado.web.RequestHandler):

        count: ClassVar[int] = 1          # Class member
        url: ClassVar[str] = 'http://localhost:8888/'  # Class member


# Generated at 2022-06-24 08:33:18.392225
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-24 08:33:21.393816
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    ex = HTTPClientError(code=1, message='Error')
    assert ex.code == 1
    assert ex.message == 'Error'
    assert ex.response is None
    assert str(ex) == 'HTTP 1: Error'
    assert repr(ex) == 'HTTP 1: Error'

HTTPError = HTTPClientError  # Backwards compatibility alias



# Generated at 2022-06-24 08:33:30.240745
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    global a
    a = urllib3_version_info[0]
    if a == 2:
        assert hasattr(_RequestProxy(None, None), 'test') is False
        assert hasattr(_RequestProxy(HTTPRequest(url='test'), None), 'url') == 'test'
        assert hasattr(_RequestProxy(HTTPRequest(url='test'), None), 'test') is False
        assert hasattr(_RequestProxy(HTTPRequest(url='test'), {'url': 'default'}), 'url') == 'test'
        assert hasattr(_RequestProxy(HTTPRequest(url='test'), {'url': 'default'}), 'test') is False
        assert hasattr(_RequestProxy(None, {'url': 'default'}), 'url') == 'default'

# Generated at 2022-06-24 08:33:35.198023
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    # type: () -> None

    # test that __getattr__ works when the attribute exists in request
    class RequestWithHeader(HTTPRequest):
        def __init__(self, headers):
            # type: (Dict[str, str]) -> None
            HTTPRequest.__init__(self, "http://www.example.com/", headers=headers)

    class DefaultWithHeader(object):
        def __init__(self, headers):
            # type: (Dict[str, str]) -> None
            self.headers = headers

    req = RequestWithHeader(headers={"Foo": "Bar"})
    d = DefaultWithHeader(headers={"Bar": "Baz"})
    rp = _RequestProxy(req, d)
    assert rp.headers == {"Foo": "Bar"}

    # test that __getattr__

# Generated at 2022-06-24 08:33:45.649090
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.iostream import IOStream
    from tornado.platform.auto import AutoIOLoop

    def _fetch_impl(self, request, callback):

        def handle_stream(stream, error=None):
            if error:
                logging.warning("HTTP connection retry failed: %s", error)
                # Retry the request once.
                # Retries are currently disabled for CurlAsyncHTTPClient
                # because max_clients is not supported by libcurl,
                # and we cannot easily implement the clean semantics of
                # tornado.simple_httpclient.SimpleAsyncHTTPClient
                # (i.e. close() and free the socket) after reaching
                # max_clients.  There is no problem with the retry if
                # the following request succeeds.
                self.fetch_impl(request, callback)
                return
           

# Generated at 2022-06-24 08:33:53.275931
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    class MyRequest(HTTPRequest):
        pass

    # With default parameters
    http_response = HTTPResponse(MyRequest(url="http://localhost"))
    assert http_response.code == 0
    assert http_response.reason == "Unknown"
    assert http_response.headers == httputil.HTTPHeaders()
    assert isinstance(http_response.buffer, BytesIO)
    assert not http_response.buffer.getvalue()
    assert http_response.effective_url == "http://localhost"
    assert not http_response.error
    assert not http_response.time_info
    assert not http_response._body
    assert http_response.request == MyRequest(url="http://localhost")
    assert not http_response._error_is_response_code

    # With random parameters
    http_response = HTTPR

# Generated at 2022-06-24 08:34:06.420861
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch(): 
    async_client_class = AsyncHTTPClient
    # Set intial values
    request = HTTPRequest("http://google.com")
    kwargs = {'method':'GET', 'raise_error':True}
    response = cast(HTTPResponse, self._io_loop.run_sync(functools.partial(self._async_client.fetch, request, **kwargs)))
    # Do we get the expected result?
    self.assertTrue(response.code == 200)

# Generated at 2022-06-24 08:34:15.259494
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
  http_client = HTTPClient()

  try:
      response = http_client.fetch("http://www.google.com/")
      print(response.body)
  except httpclient.HTTPError as e:
      # HTTPError is raised for non-200 responses; the response
      # can be found in e.response.
      print("Error: " + str(e))
  except Exception as e:
      # Other errors are possible, such as IOError.
      print("Error: " + str(e))
  http_client.close()



# Generated at 2022-06-24 08:34:23.518749
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    import tornado.httpclient
    import tornado.httputil
    import tornado.iostream
    import tornado.testing
    import tornado.util
    from tornado.httpclient import HTTPRequest, HTTPResponse
    def test_HTTPResponse___repr__():
        import tornado.httpclient
        import tornado.httputil
        import tornado.iostream
        import tornado.testing
        import tornado.util
        from tornado.httpclient import HTTPRequest, HTTPResponse
        request = HTTPRequest(
            url='/',
            headers={'Host': 'localhost:8888', 'Accept': '*/*'},
            connect_timeout=20,
            request_timeout=20,
            decompress_response=True,
            proxy_auth_mode='basic',
        )

# Generated at 2022-06-24 08:34:31.055217
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    # Confirm that an HTTPClient is closed when it is garbage-collected.
    # (but not before, which would confuse other tests)
    with mock.patch('tornado.httpclient.AsyncHTTPClient') as AsyncHTTPClient:
        client = httpclient.HTTPClient()
        assert not AsyncHTTPClient.return_value.close.called
        client = None
        assert AsyncHTTPClient.return_value.close.called



# Generated at 2022-06-24 08:34:37.987136
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    req = HTTPRequest(url='https://www.baidu.com')
    resp = HTTPResponse(request=req, code=200)
    error = HTTPClientError(code=400, message='bad request', response=resp)
    print('error repr:', repr(error))
test_HTTPClientError___repr__()

# Rename to avoid collisions with web.HTTPError
HTTPError = HTTPClientError

TResponse = TypeVar("TResponse", bound=HTTPResponse)



# Generated at 2022-06-24 08:34:41.367128
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    req = HTTPRequest('http://localhost:5000/')
    resp = HTTPResponse(request=req, code=200)
    print(resp)

# Generated at 2022-06-24 08:34:43.043497
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    assert not http_client._closed


# Generated at 2022-06-24 08:34:44.485855
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-24 08:34:51.158874
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    # For now there is only an error message.
    #
    # Note:
    #   It is a good habit to be explicit about variables' type when
    #   possible to help the reader
    http_client_error = HTTPClientError(404, 'test_baidu_not_found')
    assert http_client_error.__repr__() == 'HTTP 404: test_baidu_not_found'
test_HTTPClientError___repr__()

# Generated at 2022-06-24 08:34:53.985080
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()

__all__ = [
    "AsyncHTTPClient",
    "HTTPRequest",
    "HTTPResponse",
    "HTTPError",
    "HTTPClient",
]



# Generated at 2022-06-24 08:35:02.473060
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    import time

# Generated at 2022-06-24 08:35:06.432461
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    async def test_async_client(**kwargs: Any) -> "AsyncHTTPClient":
        return AsyncHTTPClient(**kwargs)

    http_client = HTTPClient(async_client_class=test_async_client)
    assert isinstance(http_client._async_client, AsyncHTTPClient)



# Generated at 2022-06-24 08:35:18.683918
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    url = 'http://www.example.com'
    request = HTTPRequest(url, 'POST', {'Header1':'Value1'}, 'body')
    response = HTTPResponse(request, 200)

    # Test constructor with empty arguments
    assert response.request == request
    assert response.code == 200
    assert response.reason == 'OK'
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer is None
    assert response.body == b""
    assert response.effective_url == url
    assert response.error == None
    assert response.request_time == None
    assert response.time_info == {}
    assert response.start_time == None

    # Test constructor with arguments
    code = 301
    reason = 'Redirect'
    headers = {'Header1': 'Value1'}

# Generated at 2022-06-24 08:35:23.090069
# Unit test for function main
def test_main():
    globals()["HTTPClient"] = ClosableHTTPClient
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:35:24.674700
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:35:27.520589
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    e = HTTPClientError(527, "Test Message", "Test Response")
    assert e.code == 527
    assert e.message == "Test Message"
    assert e.response == "Test Response"
    assert str(e) == "HTTP 527: Test Message"
    assert repr(e) == "HTTP 527: Test Message"

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:35:29.791051
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    assert isinstance(AsyncHTTPClient(), AsyncHTTPClient)
    AsyncIOMainLoop().close()



# Generated at 2022-06-24 08:35:34.397000
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    from tornado.util import ObjectDict
    from tornado.httputil import HTTPHeaders
    import json

    # example of HTTPRequest

# Generated at 2022-06-24 08:35:36.397127
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    http_client.close()
    assert True



# Generated at 2022-06-24 08:35:47.857292
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    def _fake_close(*args: Any, **kwargs: Any) -> None:
        pass

    async_client = mock.MagicMock(AsyncHTTPClient, spec=())  # type: ignore
    io_loop = mock.MagicMock(IOLoop, spec=())  # type: ignore
    io_loop.close = _fake_close
    http_client = HTTPClient(async_client_class=async_client, io_loop=io_loop)
    assert http_client._async_client is async_client
    assert http_client._io_loop is io_loop
    http_client.close()
    async_client.close.assert_called_once_with()
    io_loop.close.assert_called_once_with()


# To support retries with redirection, we have to be able to


# Generated at 2022-06-24 08:35:50.647737
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    # verify that the method behaves correctly

    obj = HTTPClientError(code = int(), message = str(), response = HTTPResponse())
    result = obj.__repr__()
    assert result is not None

# Generated at 2022-06-24 08:35:55.159315
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient

    async def test_close_no_instance(self):
        http_client = AsyncHTTPClient()
        self.assertFalse(http_client._closed)
        http_client.close()
        self.assertTrue(http_client._closed)
        # Close is idempotent
        http_client.close()
        self.assertTrue(http_client._closed)
    

# Generated at 2022-06-24 08:35:57.652873
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    httperror = HTTPClientError(404)
    assert str(httperror) == "HTTP 404: Not Found"


# Generated at 2022-06-24 08:36:01.100556
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    response = http_client.fetch("https://www.baidu.com/")
    print(response.body)
test_HTTPClient()


# Generated at 2022-06-24 08:36:05.357150
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    try:
        HTTPClient()
        assert False
    except AssertionError:
        print("HTTPClient.__del__ is OK")
# Test for method __del__ of class HTTPClient
test_HTTPClient___del__()


# Generated at 2022-06-24 08:36:10.117759
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://localhost/')
    defaults = {'request_timeout':15, 'if_modified_since':'Thu, 29 Mar 2012 15:30:00 GMT'}
    rp = _RequestProxy(request, defaults)
    assert rp.request_timeout == 15
    assert rp.if_modified_since == 'Thu, 29 Mar 2012 15:30:00 GMT'


# Generated at 2022-06-24 08:36:16.904907
# Unit test for constructor of class HTTPResponse

# Generated at 2022-06-24 08:36:24.499431
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    e = HTTPClientError(code=404)
    assert e.code == 404
    assert e.message == 'Not Found'
    assert str(e) == 'HTTP 404: Not Found'
    # e.status_code is also supported for compatibility with requests
    assert e.status_code == 404
    del e.status_code


HTTPError = HTTPClientError  # type: Type[HTTPClientError]



# Generated at 2022-06-24 08:36:33.512167
# Unit test for constructor of class _RequestProxy

# Generated at 2022-06-24 08:36:44.840313
# Unit test for function main
def test_main():
    url = "http://httpbin.org/get"
    try:
        request = HTTPRequest(url)
    except Exception as e:
        raise Exception("Fail to create HTTPRequest")
    try:
        response = HTTPClient().fetch(request)
    except Exception as e:
        raise Exception("Fail to get HTTP response")    
    try:
        response_header = response.headers
    except Exception as e:
        raise Exception("Fail to get HTTP response header")
    try:
        response_body = response.body
    except Exception as e:
        raise Exception("Fail to get HTTP response body")
    try:
        response_code = response.code
    except Exception as e:
        raise Exception("Fail to get HTTP response code")
    if(response_code != 200):
        raise Exception("Fail to get HTTP response code 200")


# Generated at 2022-06-24 08:36:52.757993
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(404, 'Not Found')
    assert error.code == 404
    assert error.message == 'Not Found'
    assert error.response == None

    response = HTTPResponse(HTTPRequest('http://example.com'), 404)
    error = HTTPClientError(404, 'Not Found', response)
    assert error.code == 404
    assert error.message == 'Not Found'
    assert error.response == response

if sys.version_info >= (3, 8):
    class HTTPError(HTTPClientError):
        """Deprecated alias for `HTTPClientError`."""
else:
    class HTTPError(HTTPClientError):
        """Deprecated alias for `HTTPClientError`."""


# Generated at 2022-06-24 08:37:04.269153
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import time
    import random
    import string

    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient

    ioloop = IOLoop.instance()
    AsyncHTTPClient.configure('tornado.curl_httpclient.CurlAsyncHTTPClient')
    clients = []
    for i in range(1, 10):
        client = AsyncHTTPClient(force_instance=True)
        clients.append(client)

    @gen.coroutine
    def f():
        responses = yield [ i.fetch('http://www.google.com') for i in clients ]
    ioloop.run_sync(f)

    clients[0].close()
    clients[0].close()


# Generated at 2022-06-24 08:37:14.899113
# Unit test for method fetch_impl of class AsyncHTTPClient

# Generated at 2022-06-24 08:37:21.196095
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(
        400,
        message="The request is invalid",
        response=HTTPResponse(
            HTTPRequest("http://www.example.com"),
            400,
            reason="Bad Request",
            headers={"Content-Type": "text/plain; charset=utf-8"},
            body=b"The request is invalid\n",
        ),
    )
    assert error.code == 400
    assert error.message == "The request is invalid"
    assert error.response.error == error
    assert error.response.code == 400
    assert error.response.reason == "Bad Request"
    assert error.response.headers["Content-Type"] == "text/plain; charset=utf-8"
    assert error.response.body == b"The request is invalid\n"

# In the past,

# Generated at 2022-06-24 08:37:24.212259
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
  # Test for signature: Callable[[Union[str, HTTPRequest], bool], Future[HTTPResponse]]
  result = True
  return result


# Generated at 2022-06-24 08:37:26.823334
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    rp = _RequestProxy(Request(), {})
    assert rp.request == Request()



# Generated at 2022-06-24 08:37:27.831490
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass
    
    

# Generated at 2022-06-24 08:37:32.595051
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    assert HTTPResponse(request=HTTPRequest('GET', 'URL'), code=200, headers=None, buffer=BytesIO(), effective_url='effective_url', error=None, request_time=None, time_info=None, reason=None, start_time=None).rethrow()


# Generated at 2022-06-24 08:37:35.939612
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    httpclienterror = HTTPClientError(code=1, message=None, response=None)
    # self.assertListEqual([], list(httpclienterror))
    self.assertEqual('HTTP 1: Unknown', httpclienterror.__repr__())

# Generated at 2022-06-24 08:37:39.971480
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    instance = AsyncHTTPClient()
    # Test includes calls to object __init__, HTTPRequest, HTTPResponse, IOLoop, _RequestProxy
    instance.close()


# Generated at 2022-06-24 08:37:44.189458
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request_proxy = _RequestProxy(
        HTTPRequest("GET", "http://www.google.com"), None
    )
    assert request_proxy.method == "GET"
    assert request_proxy.url == "http://www.google.com"



# Generated at 2022-06-24 08:37:51.592825
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "test_url"
    method = "GET"
    headers = None # type: Optional[Union[Dict[str, str], httputil.HTTPHeaders]]
    body = None  # type: Optional[Union[bytes, str]]
    auth_username = None # type: Optional[str]
    auth_password = None # type: Optional[str]
    auth_mode = None # type: Optional[str]
    connect_timeout = None # type: Optional[float]
    request_timeout = None # type: Optional[float]
    if_modified_since = None # type: Optional[Union[float, datetime.datetime]]
    follow_redirects = None # type: Optional[bool]
    max_redirects = None # type: Optional[int]
    user_agent = None # type: Optional[str]

# Generated at 2022-06-24 08:38:02.676202
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Test the method _RequestProxy.__getattr__ of class _RequestProxy with arguments of correct type
    # border and extreme cases
    request = HTTPRequest('www.google.com')
    defaults = None
    request_proxy = _RequestProxy(request, defaults)
    url = request_proxy.url
    assert url == 'www.google.com'
    method = request_proxy.method
    assert method == 'GET'
    # Test if the exception is correctly raised, method __getattr__ of class _RequestProxy
    try:
        method = request_proxy.type
    except:
        pass
    else:
        raise Exception('type does not exist')

# Unit tests for class HTTPRequest

# Generated at 2022-06-24 08:38:10.499920
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    client = AsyncHTTPClient()
    request = HTTPRequest("http://127.0.0.1:8080")
    def callback(response):
        pass
    client.fetch_impl(request, callback)

# Generated at 2022-06-24 08:38:13.658796
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    requestProxy = _RequestProxy(HTTPRequest(None), None)
    assert requestProxy.request == HTTPRequest(None)
    assert requestProxy.defaults == None



# Generated at 2022-06-24 08:38:24.219758
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    err = HTTPClientError(404, message="client error")
    assert err.code is 404
    assert str(err) == "HTTP 404: client error"
    assert repr(err) == "HTTP 404: client error"

    err = HTTPClientError(404, message="client error", response=HTTPResponse(HTTPRequest("http://example.com"), 404))
    assert err.code is 404
    assert str(err) == "HTTP 404: client error"
    assert repr(err) == "HTTP 404: client error"
    assert err.response is not None

# Alias for backwards compatibility with Tornado 4.0, which
# used HTTPError for both client- and server-generated errors
HTTPError = HTTPClientError

# TODO(bdarnell): remove this class's __str__ method
# when deprecation cycle is complete.

# Generated at 2022-06-24 08:38:27.732599
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    default_headers = {'Accept-Language': 'en-us'}
    a=AsyncHTTPClient()
    a.initialize(default_headers)
    assert a.defaults == default_headers



# Generated at 2022-06-24 08:38:28.268329
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 08:38:28.933529
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 08:38:35.103207
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Construct a _RequestProxy object
    request = HTTPRequest(url="http://www.example.com")
    proxy = _RequestProxy(request=request, defaults=None)
    assert proxy.request == request
    assert proxy.defaults is None
    assert type(proxy.request) == HTTPRequest
    assert proxy.url == "http://www.example.com"
    assert type(proxy.url) == str


# Generated at 2022-06-24 08:38:37.292864
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    h = HTTPResponse(None, 0, None, None, None, None, None, None)


# Generated at 2022-06-24 08:38:41.465758
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # :: HTTPResponse
    response = HTTPResponse(request=HTTPRequest(), code=0, headers=None, buffer=None,
                            effective_url=None, error=None, request_time=None, time_info=None,
                            reason=None)
    # :: str
    test_repr = response.__repr__()


# Generated at 2022-06-24 08:38:54.100158
# Unit test for function main
def test_main():
    with patch.object(HTTPClient, "fetch") as mock_fetch:
        with patch.object(tornado.options, 'parse_command_line') as mock_parse_command_line:
            mock_parse_command_line.return_value = ["arg1"]
            mock_response = MagicMock()
            mock_response.headers = "headers"
            mock_response.body = "body"
            mock_fetch.return_value = mock_response
            main()
            assert mock_response.headers == "headers"
            assert mock_response.body == "body"
            mock_fetch.assert_called_once_with("arg1", follow_redirects=True, validate_cert=True, proxy_host=None, proxy_port=None)
            mock_parse_command_line.assert_called_once()

# Generated at 2022-06-24 08:39:03.775265
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    """Unit test for method fetch of class HTTPClient"""
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as ex:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(ex))
    except Exception as ex:
        # Other errors are possible, such as IOError.
        print("Error: " + str(ex))
    http_client.close()



# Generated at 2022-06-24 08:39:06.873338
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    err = HTTPClientError(404)
    assert isinstance(err, HTTPClientError)
    assert err.code == 404
    assert '404' in str(err)

# Unit tests for class HTTPClientError

# Generated at 2022-06-24 08:39:09.672282
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # type: () -> None
    # Ensure the constructor doesn't take any arguments
    try:
        AsyncHTTPClient(foo=1)  # type: ignore
    except TypeError:
        pass



# Generated at 2022-06-24 08:39:21.762403
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    import unittest
    from io import BytesIO
    from six.moves import urllib

    class DummyResponse(HTTPResponse):
        pass

    url = "https://www.example.com/"
    request = HTTPRequest(
        url,
        connect_timeout=20,
        request_timeout=20,
        decompress_response=False,
        proxy_host="127.0.0.1",
        proxy_port=80,
        headers=httputil.HTTPHeaders(test="test/test"),
    )

# Generated at 2022-06-24 08:39:29.146027
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    data = {
        "request": None,
        "code": 200,
        "headers": None,
        "buffer": None,
        "effective_url": None,
        "error": None,
        "request_time": None,
        "reason": None,
    }
    http_response = HTTPResponse(**data)
    assert http_response.request == data["request"]
    assert http_response.code == data["code"]
    assert http_response.headers == data["headers"]



# Generated at 2022-06-24 08:39:37.512105
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():

    @gen.coroutine
    def f():
        http_client = AsyncHTTPClient()
        try:
            response = yield http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    def g():
        loop = IOLoop.current()
        loop.run_sync(f)
        loop.close()

    g()



# Generated at 2022-06-24 08:39:42.265310
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    # Python function, can be called from Python and JavaScript
    return "HTTP %d: %s" % (404, "Not Found")


HTTPError = HTTPClientError  # type: ignore



# Generated at 2022-06-24 08:39:50.131703
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import unittest
    from tornado.testing import bind_unused_port
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.web import RequestHandler, Application

    class MainHandler(RequestHandler):
        def get(self):
            self.write('hello tornado!')

    class MainTest(AsyncTestCase):

        def setUp(self):
            super(MainTest, self).setUp()
            app = Application([(r'/', MainHandler)])
            self.http_server = HTTPServer(app)
            sock, port = bind_unused_port()
            self.http_server.add_socket(sock)

            self.http_client = AsyncHTTPClient()


# Generated at 2022-06-24 08:39:54.996285
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import requests
    http_client = HTTPClient()
    try:
        response = http_client.fetch("https://www.baidu.com/")

        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))



# Generated at 2022-06-24 08:40:04.859090
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase

    from tornado.web import RequestHandler

    class HelloHandler(RequestHandler):
        def get(self):
            self.write("Hello")

    class TestHTTPClient(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", HelloHandler)])

        def test_command_line(self):
            self.http_client.fetch(self.get_url("/"), self.stop)
            response = self.wait()
            self.assertEqual(response.body, b"Hello")


# Generated at 2022-06-24 08:40:08.015378
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    assert http_client._closed == True
    assert http_client._io_loop == IOLoop.current()
    assert http_client._async_client.__class__.__name__ == "HTTPClientImpl"
    http_client.close()
    assert http_client._closed == True
    assert http_client._io_loop == IOLoop.current()

# Generated at 2022-06-24 08:40:20.211487
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    import types
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncHTTPTestCase
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    # setUpClass and tearDownClass don't work for old-style classes,
    # so this is all in a function.
    def do_test_AsyncHTTPClient(self):
        self.assertIsInstance(self.http_client, SimpleAsyncHTTPClient)
        self.assertNotEqual(  # These are the same instance.
            id(self.http_client), id(AsyncHTTPClient())
        )
        self.assertIsInstance(self.http_client.io_loop, AsyncIOMainLoop)

        http_client = AsyncHTTPClient(force_instance=True)
        # These are different instances

# Generated at 2022-06-24 08:40:29.133880
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():        
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()
test_HTTPClient_fetch()
