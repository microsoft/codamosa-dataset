

# Generated at 2022-06-24 08:30:27.893483
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    # http_client.close()



# Generated at 2022-06-24 08:30:29.624793
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    instance = AsyncHTTPClient()
    assert isinstance(instance, AsyncHTTPClient)




# Generated at 2022-06-24 08:30:37.026324
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-24 08:30:41.824310
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    class A(AsyncHTTPClient):
        def __init__(self, **kwargs: Any) -> None:
            pass

    class B(AsyncHTTPClient):
        def __init__(self, **kwargs: Any) -> None:
            pass

    try:
        A.configure(B, arg='b')
        b = A()
        assert isinstance(b, B)
    finally:
        A.configure(None)
    return # type: ignore

test_AsyncHTTPClient()



# Generated at 2022-06-24 08:30:46.769625
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # No need to test this
    pass

__all__ = [
    "AsyncHTTPClient",
    "HTTPRequest",
    "HTTPResponse",
    "HTTPError",
    "main",
]

# Generated at 2022-06-24 08:30:57.865051
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    response: HTTPResponse