

# Generated at 2022-06-24 08:30:31.595289
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.ioloop
    import time
    from tornado.httpclient import AsyncHTTPClient
    import json
    import tornado.gen
    def test_func():
        def handle_response(response):
            if response.error:
                print("Error:", response.error)
            else:
                print(response.body)
        http_client = AsyncHTTPClient()
        http_client.fetch("http://www.tornadoweb.org/en/stable/", handle_response)
    tornado.ioloop.IOLoop.current().run_sync(test_func)


# Generated at 2022-06-24 08:30:37.443455
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-24 08:30:37.975495
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-24 08:30:46.508896
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
        print("running test_HTTPResponse_rethrow ...")
        try:
            http_client = AsyncHTTPClient()
            http_client.fetch(url,method='POST',body='{"error":true,"msg":"error","data":"data"}',callback=handle_response)
        except HTTPError as e:
            print(str(e))
        #response = http_client.fetch(url,method='POST',body='{"error":true,"msg":"error","data":"data"}')
        #response.rethrow()


# Generated at 2022-06-24 08:30:47.355282
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    obj = AsyncHTTPClient()
    obj.close()
    pass


# Generated at 2022-06-24 08:30:58.335354
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():

    request1 = HTTPRequest("http://localhost", method="GET")
    code1 = 200
    headers1 = httputil.HTTPHeaders()
    headers1.add("content-type", "text/html")
    headers1.add("content-length", "10")
    buffer1 = BytesIO()
    buffer1.write(b'<html><body>Hello, world</body></html>')
    buffer1.seek(0)
    effective_url1 = "http://localhost"
    error1 = None
    request_time1 = 1
    time_info1 = {"queue": 0.1}
    reason1 = httputil.responses.get(code1, "Unknown")

    # Unit test for constructor of class HTTPResponse

# Generated at 2022-06-24 08:31:03.656078
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    client1 = AsyncHTTPClient()
    assert isinstance(client1, AsyncHTTPClient)
    with pytest.warns(DeprecationWarning):
        client2 = AsyncHTTPClient()
    assert client1 is client2
    IOLoop.current().close()
    assert client1._closed
    client3 = AsyncHTTPClient(force_instance=True)
    assert isinstance(client3, AsyncHTTPClient)
    assert client3 is not client1
    IOLoop.current().close()
    assert client3._closed



# Generated at 2022-06-24 08:31:14.860412
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # test_AsyncHTTPClient___new__()
    # Test that AsyncHTTPClient.__new__ handles cache correctly.
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    
    
    # Create a dummy AsyncHTTPClient class with a counter for
    # number of instances created.
    class DummyAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, *args, **kwargs) -> None:
            self.counter = DummyAsyncHTTPClient.counter
            DummyAsyncHTTPClient.counter += 1
            super(DummyAsyncHTTPClient, self).__init__(*args, **kwargs)
    
        def initialize(self, *args, **kwargs) -> None:
            self.init_counter = DummyAsyncHTTPClient.counter

# Generated at 2022-06-24 08:31:19.987131
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    assert http_client._io_loop,IOLoop
    assert http_client._async_client,AsyncHTTPClient
    http_client.close()
    print('HTTPClient test passed')


# Generated at 2022-06-24 08:31:29.240628
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing

    def handle_request(response: tornado.httpclient.HTTPResponse) -> None:
        response.rethrow()
        self.assertEqual(response.code, 599)
        self.assertEqual(response.headers["Content-Type"], "text/html")
        self.assertEqual(
            response.body, b"<html><body>the server is misbehaving</body></html>"
        )
        self.stop()

    @gen.coroutine
    def do_test() -> None:
        client = tornado.httpclient.AsyncHTTPClient()

# Generated at 2022-06-24 08:31:33.543010
# Unit test for method __repr__ of class HTTPClientError

# Generated at 2022-06-24 08:31:39.884217
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = 'http://www.baidu.com'
    method = 'GET'
    headers = {
        'x-test-header': 'test-header-value',
        'x-test-header2': 'test-header-value2'
    }
    body = 'some body'

    request = HTTPRequest(
        url, method, headers, body
    )
    assert(request.url == 'http://www.baidu.com')
    assert(request.method == 'GET')
    assert(request.headers['x-test-header'] == 'test-header-value')
    assert(request.headers['x-test-header2'] == 'test-header-value2')
    assert(request.body == b'some body')


# Generated at 2022-06-24 08:31:41.502230
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    z = HTTPClient()
    z.close()
    assert z._closed == True

# Generated at 2022-06-24 08:31:44.970453
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    '''
    assert not isinstance(AsyncHTTPClient(force_instance=True), AsyncHTTPClient), \
        "#1: Got unexpected type: %r" % type(AsyncHTTPClient(force_instance=True))
    '''
    return



# Generated at 2022-06-24 08:31:48.030605
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    ret = HTTPClientError(code=500, message="Internal Server Error", response="No Content")
    assert(ret == "HTTP 500: Internal Server Error")
test_HTTPClientError___repr__()

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:32:00.301731
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.log import gen_log
    from tornado.iostream import IOStream
    from tornado.iostream import SSLIOStream
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.simple_httpclient import _HTTPConnection
    from tornado.simple_httpclient import _HTTPConnectionDelegate
    from tornado.httputil import HTTPServerConnectionDelegate
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import ResponseStartLine
    from tornado.httputil import parse_body_arguments
    from tornado.concurrent import Future
    from tornado.concurrent import TracebackFuture
    from tornado.options import define, options, parse_command_line
    import io
    import logging
    import ssl
    import sys
    import unittest
    import socket
    import errno
    import logging

# Generated at 2022-06-24 08:32:09.605915
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.concurrent import Future
    from tornado.gen import Return

    from .httpclient import AsyncHTTPClient, HTTPRequest

    class AsyncHTTPNegativeClient(AsyncHTTPClient):
        def fetch_impl(self, request, callback):
            response = HTTPResponse(request, 200)
            callback(response)
        # test for the Return block
        def myFetch(self, request):
            future = Future()

            def callback(response):
                future_set_result_unless_cancelled(future, response)

            self.fetch_impl(request, callback)
            return Return(future)

    http_client = AsyncHTTPNegativeClient()
    request = HTTPRequest(url="https://www.baidu.com")
    future = http_client.fetch(request)

# Generated at 2022-06-24 08:32:16.281789
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import tornado.platform.asyncio
    asyncio = tornado.platform.asyncio.AsyncIOMainLoop().asyncio_loop
    asyncio.set_debug(True)
    import asyncio
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest

    server = tornado.httpserver.HTTPServer(tornado.web.RequestHandler)
    server.listen(8888)
    client = AsyncHTTPClient()
    response = client.fetch("http://127.0.0.1:8888/")
    client.close() # 无错误检测

# Generated at 2022-06-24 08:32:17.396383
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    from tornado.httpclient import HTTPClient

    http_client = HTTPClient()
    http_client.fetch("http://www.google.com/")
    assert isinstance(http_client, HTTPClient)


# Generated at 2022-06-24 08:32:20.391415
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    #from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    _io_loop = IOLoop(make_current=False)
    def make_client() -> AsyncHTTPClient:
        import asyncio
        asyncio.sleep(0)
        return AsyncHTTPClient()
    _async_client = _io_loop.run_sync(make_client)
    http_client = HTTPClient()
    assert http_client
    response = http_client.fetch(HTTPRequest(url="http://www.google.com/"))
    assert response

# Generated at 2022-06-24 08:32:28.254769
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    url = "www.baidu.com"
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch(url)
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    loop = IOLoop.current()
    f()
    loop.start()



# Generated at 2022-06-24 08:32:32.683324
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    print('test__RequestProxy___getattr___')
    cc = _RequestProxy(None, {'headers':{'user-agent':'test_user_agent'}})
    print(cc.headers)
    print(cc.test)
    print(cc.request)

test__RequestProxy___getattr__()


# Generated at 2022-06-24 08:32:34.346670
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # test_AsyncHTTPClient_initialize is not tested because it is
    # called in the constructor
    pass


# Generated at 2022-06-24 08:32:38.583634
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # http_client_test.AsyncHTTPClientTest.test_singleton
    http_client1 = AsyncHTTPClient()
    http_client2 = AsyncHTTPClient()
    assert http_client1 is http_client2
    http_client1.close()



# Generated at 2022-06-24 08:32:39.477560
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    HTTPClientError(200, 'OK')

HTTPError = HTTPClientError


# Generated at 2022-06-24 08:32:39.913984
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 08:32:46.325563
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    request = "https://www.baidu.com"
    raise_error = True
    http_client = AsyncHTTPClient()
    response = http_client.fetch(request, raise_error)
    print("\n")
    print("Content-Type: ", response.headers['Content-Type'])
    print("")
    print("URL: ", request)
    print("")
    print("Body:", response.body)

test_AsyncHTTPClient_fetch()


# Generated at 2022-06-24 08:32:55.740944
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    #pylint: disable=import-outside-toplevel
    from tornado.test.util import unittest
    try:
        #pylint: disable=unused-variable,unused-import,import-outside-toplevel
        import simplejson as json
    except ImportError:
        import json
    # Make sure this class can be serialized by simplejson.
    # See https://github.com/tornadoweb/tornado/issues/1079
    obj = HTTPClientError(599)
    assert json.loads(json.dumps(obj, default=lambda o: o.__dict__))['code'] == 599


HTTPError = HTTPClientError

# Generated at 2022-06-24 08:33:00.519675
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    async def test1():
        http_client.close()
    IOLoop.current().run_sync(test1)
    return True

# Generated at 2022-06-24 08:33:05.001738
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async def f():
        instance = AsyncHTTPClient()
        await gen.sleep(0)
        assert isinstance(instance, type(AsyncHTTPClient()))
        assert instance.io_loop == IOLoop.current()

    IOLoop.current().run_sync(f)
    

# Generated at 2022-06-24 08:33:11.866240
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(
        url="http://localhost:8888/test/test?test=test",
        connect_timeout=10,
        request_timeout=10,
    )
    n = 0
    response = HTTPResponse(request, code=200)
    response.rethrow()
    n += 1
    response = HTTPResponse(request, code=404)
    try:
        response.rethrow()
    except:
        n += 1
    response = HTTPResponse(request, code=200, error=HTTPError(404, "Not Found", response=response))
    try:
        response.rethrow()
    except:
        n += 1
    assert n == 3



# Generated at 2022-06-24 08:33:22.594769
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import logging
    import tornado.log


    class MyAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self):
            self.io_loop = IOLoop.current()
            self.defaults = dict(HTTPRequest._DEFAULTS)
            self._closed = False

        def close(self):
            pass

        def fetch_impl(
            self, request: Union["HTTPRequest"], callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass

    @gen.coroutine
    def test_future_type() -> None:
        """AsyncHTTPClient.fetch returns a Future"""
        tornado.log.enable_pretty_logging()
        #tornado.log.app_log.setLevel(logging.DEBUG)
        http_client = MyAsyncHTTPClient()

# Generated at 2022-06-24 08:33:24.561078
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # 1. __init__
    request = HTTPRequest(url='https://www.google.com/')
    httpResponse = HTTPResponse(request=request, code=200, headers="")
    print(httpResponse)


# Generated at 2022-06-24 08:33:34.459983
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.escape import native_str
    import logging
    import sys
    import unittest
    import os

    class MainTest(AsyncHTTPTestCase):

        def setUp(self):
            super(MainTest, self).setUp()
            self._stderr = sys.stderr
            sys.stderr = open(os.devnull, 'w')

        def tearDown(self):
            super(MainTest, self).tearDown()
            sys.stderr = self._stderr


# Generated at 2022-06-24 08:33:42.366876
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import asyncio
    async def do_fetch():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error:", e)
        else:
            print(response.body)
    asyncio.run(do_fetch())
# python -m unittest -v tornado.simple_httpclient.test_client

# Generated at 2022-06-24 08:33:43.082846
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-24 08:33:54.844879
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import os
    
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    from asyncio import get_event_loop, set_event_loop, new_event_loop
    
    AsyncIOMainLoop().install()
    
    async def f(request):
        cli = AsyncHTTPClient()
        response = await cli.fetch(request)
        print(response.body)
    
    import sys
    
    
    if __name__ == "__main__":
        req = "http://www.google.com/"
        if len(sys.argv) > 1:
            req = sys.argv[1]
        f(req)
        loop = get_event_loop()
        loop.run_forever()

# Generated at 2022-06-24 08:33:57.685964
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    for i in range(10):
        pass
    # Prepare the parameters
    url = 'www.google.com'
    request = HTTPRequest(url=url)
    raise_error = True
    kwargs = None
    # Call the method
    AsyncHTTPClient.fetch(request, raise_error, **kwargs)
# vim:ai:et:ts=4:sw=4:sts=4:fenc=utf8:

# Generated at 2022-06-24 08:34:09.771381
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    A = AsyncHTTPClient()

# Generated at 2022-06-24 08:34:19.637527
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    req = HTTPRequest("method", "url")
    resp = HTTPResponse(req, 200, reason="test reraise error", error=HTTPError(200, "test reraise error"))
    assert resp.__repr__() == "HTTPResponse(body=None,buffer=None,code=200,error=HTTPError(code=200,message='test reraise error',response=<tornado.httpclient.HTTPResponse object at 0x10c1f6cc0>),headers={},request=<HTTPRequest method=method url=url>,request_time=None,time_info={},effective_url='url',reason='test reraise error',start_time=None)"


# Generated at 2022-06-24 08:34:24.080170
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    code = 200
    headers = None
    buffer = None
    effective_url = None
    error = None
    request_time = None
    time_info = None
    reason = None
    start_time = None
    request = HTTPRequest("http://www.example.com")
    a = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    print(a.__repr__())


# Generated at 2022-06-24 08:34:36.190546
# Unit test for method rethrow of class HTTPResponse

# Generated at 2022-06-24 08:34:39.022737
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url = "http://www.google.com", method = "GET")
    defaults = {"method": "POST", "body": "Hello World"}
    req = _RequestProxy(request, defaults)

    # Test for a attribute not in neither request nor defaults
    assert getattr(req, "body") == None

    # Test for a attribute in request
    assert getattr(req, "method") == "GET"

    # Test for a attribute in defaults
    assert getattr(req, "body") == "Hello World"


# Generated at 2022-06-24 08:34:45.873322
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    """Tests HTTPRequest class constructor.

    Checks if all arguments were properly passed to the class constructor.
    """

# Generated at 2022-06-24 08:34:47.865274
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # This test doesn't make sense in python2
    pass



# Generated at 2022-06-24 08:34:49.545815
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    a = AsyncHTTPClient()
    a.close()



# Generated at 2022-06-24 08:34:54.637018
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    req = HTTPRequest("http://127.0.0.1")
    req_proxy = _RequestProxy(req, {})
    assert req_proxy.request is req
    assert req_proxy.defaults == {}
    assert req_proxy.url == req.url
    assert req_proxy.user_agent == "tornado/%s" % __version__
test__RequestProxy___getattr__()


# Generated at 2022-06-24 08:34:56.688304
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    HTTPClientError(
        403,
        message='Forbidden',
        response=None
    ).__repr__()

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:35:01.501016
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    try:
        http_client = HTTPClient()
        response = http_client.fetch("http://www.google.com/")
        response.body

    except HTTPError as e:
        errormsg = "Error: " + str(e)
    except Exception as e:
        errormsg = "Error: " + str(e)
    finally:
        http_client.close()
    return errormsg



# Generated at 2022-06-24 08:35:08.791821
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest('http://www.baidu.com')
    req = _RequestProxy(request, {'body_producer': None, 'expect_100_continue': False})
    print(req.body_producer) # None
    print(req.expect_100_continue) # False

# test__RequestProxy()

# A thread for fetching URLs.  Used by SimpleAsyncHTTPClient.

# Generated at 2022-06-24 08:35:09.906580
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    assert HTTPClientError(404).code == 404
    assert HTTPClientError(404).message == "Not Found"

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:35:11.950466
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    assert issubclass(AsyncHTTPClient, Configurable)
    assert issubclass(HTTPClient, object)



# Generated at 2022-06-24 08:35:24.104123
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    import tornado.gen

    url = "http://google.com"

    def test(loop):

        @gen.coroutine
        def coroutine():
            http_client = AsyncHTTPClient()
            try:
                response = yield http_client.fetch(url, raise_error=True)
                print(response.body)
            except Exception as e:
                print("Error: %s" % e)
            else:
                print(response.body)


        def main():

            coroutine()

        # loop.run_until_complete(asyncio.gather(coroutine()))

        # coroutine()
        # print(unicode(response.body, errors='replace'))

# Generated at 2022-06-24 08:35:25.664913
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    #c = HTTPClient()
    #assert isinstance(c, HTTPClient)
    pass


# Generated at 2022-06-24 08:35:27.455992
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    assert HTTPClientError(1, message='1', response='1').__repr__() == 'HTTP 1: 1'
    assert HTTPClientError(1, message='1').__repr__() == 'HTTP 1: 1'

# Generated at 2022-06-24 08:35:27.822097
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    assert True


# Generated at 2022-06-24 08:35:32.056905
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    def setUp(self):
        self.async_client = AsyncHTTPClient()
        self.http_client = HTTPClient()
        self.stop()
        self.stop()
        self.stop()

    def test_fetch(self):
        url = self.get_url('/')
        self.http_client.fetch(url, self.stop)
        response = self.wait()
        self.assertEqual(200, response.code)
        response.rethrow()

# Generated at 2022-06-24 08:35:39.457610
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    async def _fetch(http_client,request,raise_error=True,**kwargs):
        #logging.info('feching %s', request)
        request = _RequestProxy(request, self.defaults, **kwargs)
        # Lowercase headers for easier access.
        for k, v in request.headers.items():
            request.headers[k.lower()] = v
        # If there is a Content-Encoding header, we want to decode the
        # body based on that encoding, but we're not going to
        # automatically encode it when we send the request.
        # Neither urllib, urllib2, nor curl do this automatically.
        content_encoding = request.headers.pop('content-encoding', None)

# Generated at 2022-06-24 08:35:44.513306
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://localhost/")
    request_proxy = _RequestProxy(request, {})

    assert request.proxy_host is None
    assert request_proxy.proxy_host is None

    assert request.method is None
    assert request_proxy.method is None

    request_proxy.defaults = {"proxy_host": "foo", "method": "GET"}
    assert request_proxy.proxy_host is None
    assert request_proxy.method == "GET"

    request.proxy_host = "bar"
    request.method = "GET"
    assert request_proxy.proxy_host == "bar"
    assert request_proxy.method == "GET"



# Generated at 2022-06-24 08:35:47.054233
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    client = AsyncHTTPClient()
    assert client.fetch_impl(request= 1,callback=2) == NotImplementedError


# Generated at 2022-06-24 08:35:53.364322
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://www.google.com")
    assert request.url == "http://www.google.com"
    response = HTTPResponse(code=200, headers={'key1': 'value1'}, request=request)
    assert response.code == 200
    assert response.headers == {'key1': 'value1'}
    assert response.request == request
    assert response.effective_url == "http://www.google.com"
    assert response.start_time is None
    assert response.request_time is None
    assert response.body == b""

# Generated at 2022-06-24 08:36:03.308106
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # Create an object of class HTTPResponse
    req = HTTPRequest('url')
    http_response = HTTPResponse(req, 200)

    actual = http_response.__repr__()
    expected = 'HTTPResponse(code=200, effective_url=\'url\', error=None, request=<tornado.httpclient.HTTPRequest object at 0x1042f8c18>, request_time=None, reason=\'OK\', start_time=None, time_info={}, buffer=None, headers=HTTPHeaders({})'
    assert actual == expected


# Generated at 2022-06-24 08:36:05.889975
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    # type: () -> None
    http_error = HTTPClientError(1, "a", None)
    assert http_error.__repr__() == "HTTP 1: a"

# Compatibility alias.
HTTPError = HTTPClientError



# Generated at 2022-06-24 08:36:09.643405
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(404, 'Not Found', 'response')
    assert error.code == 404
    assert error.message == 'Not Found'
    assert error.response == 'response'
    assert error.__str__() == 'HTTP 404: Not Found'

HTTPError = HTTPClientError  # deprecated alias



# Generated at 2022-06-24 08:36:10.209449
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    pass

# Generated at 2022-06-24 08:36:10.984228
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    NotImplementedError


# Generated at 2022-06-24 08:36:12.039156
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass



# Generated at 2022-06-24 08:36:15.457057
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    request = HTTPRequest("https://de.wikipedia.org/wiki/Tor%C3%B6n")
    response = HTTPClient().fetch(request)
    assert response.code == 200


# Generated at 2022-06-24 08:36:28.373782
# Unit test for function main
def test_main():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import os
    import shutil
    import tempfile
    import logging
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    import functools
    import ssl
    import unittest
    # Prepare certificates and test HTTPS server
    class EchoHandler(tornado.web.RequestHandler):
        def get(self):
            self.finish(self.request.uri)
    class ClientCertEchoHandler(tornado.web.RequestHandler):
        def get(self):
            self.finish(self.request.uri)
    class AuthHandler(tornado.web.RequestHandler):
        def get(self):
            self.finish(self.request.uri)

# Generated at 2022-06-24 08:36:35.726660
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    assert client.defaults == {'validate_cert': True}
    client.initialize(defaults={'validate_cert': False, 'proxy_host': '192.168.0.1'})
    assert client.defaults == {'validate_cert': False, 'proxy_host': '192.168.0.1'}


    client = AsyncHTTPClient()
    assert client.defaults == {'validate_cert': True}
    client.initialize(defaults={'validate_cert': False})

# Generated at 2022-06-24 08:36:39.378379
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    client = AsyncHTTPClient()
    assert(isinstance(client, AsyncHTTPClient))
    # TODO: Test for force_instance

# Test for method close of class AsyncHTTPClient

# Generated at 2022-06-24 08:36:49.461688
# Unit test for function main
def test_main():
    import os
    import tornado
    from tornado.testing import AsyncHTTPTestCase
    from tornado.httpclient import AsyncHTTPClient
    from tornado.options import define, options, parse_command_line
    import sys

    class HTTPClientTest(AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application()

        def test_main(self):
            define("print_headers", type=bool, default=False)
            define("print_body", type=bool, default=True)
            define("follow_redirects", type=bool, default=True)
            define("validate_cert", type=bool, default=True)
            define("proxy_host", type=str)
            define("proxy_port", type=int)

# Generated at 2022-06-24 08:37:02.701888
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    print("testing _RequestProxy.__getattr__()...")
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    client = SimpleAsyncHTTPClient(io_loop=IOLoop.current())
    print("client is: " + str(client))


# Generated at 2022-06-24 08:37:13.592356
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    # test_HTTPClient_close_01 function is started.
    # This function tests method close of class HTTPClient.
    def test_HTTPClient_close_01():
        # Initialization of variables and constants.
        async_client_class = None
        """
        kwargs = {
            "connect_timeout": 3,
            "request_timeout": 3,
            "max_clients": 10,
            "max_header_size": None
        }
        """
        # Create an instance of HTTPClient.
        http_client = HTTPClient(async_client_class)
        # Call method close of HTTPClient.
        http_client.close()
        # Verify that variable _closed is True.
        assert http_client._closed == True
    # Call function test_HTTPClient_close_01.
    test_HTTPClient_close

# Generated at 2022-06-24 08:37:19.423973
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
  # Test that AsyncHTTPClient.close() deletes the instance
  # from the instance cache.
  io_loop = IOLoop()
  client = AsyncHTTPClient(io_loop=io_loop)
  client2 = AsyncHTTPClient(io_loop=io_loop)
  assert client is client2
  client.close()
  client3 = AsyncHTTPClient(io_loop=io_loop)
  assert client3 is not client



# Generated at 2022-06-24 08:37:25.898612
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(400, "bad request")
    except HTTPClientError as e:
        assert e.code == 400
        assert e.message == "bad request"

HTTPError = HTTPClientError

# The _RequestProxy class exists primarily to add a __str__ method
# to the otherwise opaque _RequestProxy objects produced by
# SimpleAsyncHTTPClient

# Generated at 2022-06-24 08:37:36.188053
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    class TestAsyncHTTPClient(AsyncHTTPClient):
        pass
    try:
        import pycurl  # type: ignore
    except ImportError:
        raise unittest.SkipTest("pycurl not present")
    from tornado.platform.auto import set_close_exec
    from tornado.curl_httpclient import CurlAsyncHTTPClient

    # Monkey patch pycurl to change the curl_socket_t type to socket.socket,
    # so that we can compare it below.
    saved_curl_socket_t = pycurl.Curl.curl_socket_t
    pycurl.Curl.curl_socket_t = socket.socket

    # Some versions of pycurl use the old pycurl.CurlMulti.info_read
    # method, which returns a tuple instead of a list.

# Generated at 2022-06-24 08:37:40.309363
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    global class_flag, method_flag
    class_flag = method_flag = True
    http_client = HTTPClient()
    http_client.close()
    assert class_flag == method_flag == True


# Generated at 2022-06-24 08:37:49.717399
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    assert HTTPClientError(404).code == 404
    assert HTTPClientError(404).message == 'Not Found'
    assert HTTPClientError(404, message='test').message == 'test'
    assert HTTPClientError(404, message=None).message == 'Not Found'
    assert HTTPClientError(404, response=None).response is None
    assert HTTPClientError(404, response=HTTPResponse(None, 200)).response.code == 200

    assert str(HTTPClientError(404)) == 'HTTP 404: Not Found'
    assert repr(HTTPClientError(404)) == 'HTTP 404: Not Found'


HTTPError = HTTPClientError



# Generated at 2022-06-24 08:38:02.789678
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import tornado.testing
    import tornado.gen

    class ExpectedException(Exception):
        pass

    class TestAsyncHTTPClient(tornado.testing.AsyncHTTPTestCase):
        def get_app(self) -> Any:
            pass

        def test_fetch_impl(self) -> None:
            loop = self.io_loop
            async def f() -> None:
                try:
                    await loop.run_in_executor(None, self.http_client.fetch_impl, None, None)
                except ExpectedException:
                    pass
                else:     
                    self.fail("Expected Exception")

            loop.run_until_complete(f())

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-24 08:38:05.050079
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    http_error = HTTPClientError(404)
    assert http_error.__repr__() == "HTTP 404: Unknown"

# Generated at 2022-06-24 08:38:11.735295
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-24 08:38:15.993188
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    """
    Unit test for method __del__ of class HTTPClient
    """
    raise NotImplementedError('%s.%s not yet implemented' % (__name__, test_HTTPClient___del__.__name__))



# Generated at 2022-06-24 08:38:25.295523
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    # Initialize self._closed at the beginning of the constructor
    # so that an exception raised here doesn't lead to confusing
    # failures in __del__.
    import tornado

    H = tornado.httpclient.HTTPClient

    def mock__init__(self, async_client_class=None, **kwargs):
        self._closed = True
        self._io_loop = tornado.ioloop.IOLoop(make_current=False)
        if async_client_class is None:
            async_client_class = tornado.httpclient.AsyncHTTPClient

        # Create the client while our IOLoop is "current", without
        # clobbering the thread's real current IOLoop (if any).
        def make_client():
            import tornado

            tornado.gen.sleep(0)
            assert async_client_class is not None
           

# Generated at 2022-06-24 08:38:33.796176
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    req = HTTPRequest(url="url")
    code = 1
    headers = {"1":1}
    buffer = BytesIO()
    effective_url = "www.baidu.com"
    error = None
    request_time = 1
    time_info = {"val":1}
    reason = "OK"
    start_time =()
    resp = HTTPResponse(req,code,headers,buffer,effective_url,error,request_time,time_info,reason,start_time)
    assert(resp.code == code)



# Generated at 2022-06-24 08:38:36.790518
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(599)
    except HTTPClientError as e:
        assert(e.code == 599)
        assert(str(e) == "HTTP 599: Unknown")



# Generated at 2022-06-24 08:38:44.071991
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # __new__ of AsyncHTTPClient called without any parameter
    async_http_client = AsyncHTTPClient.__new__(AsyncHTTPClient)
    assert async_http_client._instance_cache == None
    assert async_http_client._closed == False
    assert async_http_client.io_loop == None
    assert async_http_client.defaults == {'user_agent': 'Tornado/2.0', 'connect_timeout': 20.0, 'request_timeout': 20.0}
    # __new__ of AsyncHTTPClient called with force_instance=True
    async_http_client = AsyncHTTPClient.__new__(AsyncHTTPClient, force_instance=True)
    assert async_http_client._instance_cache == None
    assert async_http_client._closed == False
    assert async_http_client

# Generated at 2022-06-24 08:38:46.431503
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    # type: (...) -> None
    client = HTTPClient()
    client.close()


# Generated at 2022-06-24 08:38:55.908315
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    """
    >>> test__RequestProxy()
    {'method': 'GET', 'url': 'http://example.com/', 'headers': {}, 'body': None}
    >>> req = HTTPRequest('http://example.com/')
    >>> _RequestProxy(req, {'method': 'POST'}).__dict__
    {'request': <__main__.HTTPRequest object at 0x...>, 'defaults': {'method': 'POST'}}
    >>> test__RequestProxy()
    {'method': 'POST', 'url': 'http://example.com/', 'headers': {}, 'body': None}
    """
    r = _RequestProxy(HTTPRequest('http://example.com/'), {'method': 'GET'})
    import pprint
    return pprint.pformat(r.__dict__)


# Generated at 2022-06-24 08:39:00.746762
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    code = 200
    message = 'OK'
    response = 200
    obj = HTTPClientError(code, message, response)
    assert 'HTTP 200: OK' == obj.__repr__()


# Generated at 2022-06-24 08:39:03.632916
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    async_client = AsyncHTTPClient()
    http_client = HTTPClient(async_client)
    http_client.__del__()
    assert http_client._async_client is not None



# Generated at 2022-06-24 08:39:12.474304
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado import ioloop
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient
    #Since SimpleAsyncHTTPClient is default, we should get SimpleAsyncHTTPClient.
    simple_client = AsyncHTTPClient()
    assert isinstance(simple_client, SimpleAsyncHTTPClient)
    #We can also specify to use SimpleAsyncHTTPClient
    simple_client = AsyncHTTPClient(force_instance=True)
    assert isinstance(simple_client, SimpleAsyncHTTPClient)
    #If we configure it, we should get the class we configured it to return.
    AsyncHTTPClient.configure(None, max_clients=10)
    simple_client = AsyncHTTPClient()
    assert isinstance(simple_client, SimpleAsyncHTTPClient)

# Generated at 2022-06-24 08:39:14.649145
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    obj_test_AsyncHTTPClient_initialize = SimpleAsyncHTTPClient()
    obj_test_AsyncHTTPClient_initialize.initialize()
    #pass



# Generated at 2022-06-24 08:39:15.917010
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    http_client.close()
    assert isinstance(http_client, HTTPClient)



# Generated at 2022-06-24 08:39:17.937656
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    client = HTTPClient()
    request = 'http://www.baidu.com'
    response = client.fetch(request)


_DEFAULT_CA_CERTS = None  # type: Optional[str]



# Generated at 2022-06-24 08:39:26.099907
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        HTTPClientError(404, "abc").__str__()
    except IndexError as error:
        print("Error:", error)
    else:
        print("Success.")

test_HTTPClientError()


HTTPError = HTTPClientError



# Generated at 2022-06-24 08:39:38.376924
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.test.util import unittest, ExpectLog
    import httptest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    server = httptest.HTTPServer(httptest.HTTPTestRequestHandler)
    server.start()
    url = server.get_url()
    class MyHTTPClient(AsyncHTTPClient):
        def fetch_impl(self, request: "HTTPRequest",
                       callback: "Callable[[HTTPResponse], None]") -> None:
            self.io_loop.add_callback(lambda: callback(HTTPResponse(request, 200)))

# Generated at 2022-06-24 08:39:48.715633
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    print('Test for method rethrow of class HTTPResponse')
    request = HTTPRequest(url='http://www.baidu.com')
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = 'http://www.baidu.com'
    error = HTTPError(code, message='test', response=HTTPResponse(request=request, code=code, headers=headers, buffer=buffer, effective_url=effective_url))
    start_time = time.time()
    request_time = time.time()
    time_info = {'test1': 0.1, 'test2': 0.2}
    reason = 'test'

# Generated at 2022-06-24 08:39:51.891139
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    test_http_client = HTTPClient()
    test_url = 'https://www.github.com'
    response = test_http_client.fetch(request=test_url, raise_error=True)
    assert response.code == 200
    test_http_client.close()


# Generated at 2022-06-24 08:39:56.175924
# Unit test for function main
def test_main():
    with mock.patch.object(BaseHTTPClient, 'close'):
        with mock.patch.object(HTTPClient, 'fetch') as fetch:
            with mock.patch('tornado.options.parse_command_line') as parse_command_line:
                parse_command_line.return_value = ['http://foo/bar']
                fetch.return_value = 'foo'
                main()
                fetch.assert_called_with('http://foo/bar', validate_cert=True, follow_redirects=True, proxy_host=None, proxy_port=None)


# Generated at 2022-06-24 08:39:58.250787
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

    # Tornado AsyncHTTPClient:
    #     class AsyncHTTPClient(Configurable)

# Generated at 2022-06-24 08:40:04.555704
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    req = HTTPRequest(url="http://test.com")
    defaults = {'method': 'GET'}
    proxy = _RequestProxy(req, defaults)
    assert proxy.method == 'GET'
    # even if the default is None, the value should be returned
    defaults = {'user_agent': None}
    proxy = _RequestProxy(req, defaults)
    assert proxy.user_agent == None



# Generated at 2022-06-24 08:40:12.231775
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    import tornado.httpclient as httpclient
    clienterror = httpclient.HTTPClientError(599, message = None, response = None)
    assert repr(clienterror) == 'HTTP 599: Unknown'
# Before Tornado 5.1 this error class was called "HTTPError" instead
# of "HTTPClientError".  many users have defined their own "HTTPError"
# classes that inherit from tornado's, so we preserve the old name
# for now
HTTPError = HTTPClientError



# Generated at 2022-06-24 08:40:16.171313
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # pass
    a = AsyncHTTPClient(force_instance=True)
    a.initialize(defaults=None)
    a.close()
    assert a._closed is True



# Generated at 2022-06-24 08:40:27.866297
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import typing
    import unittest
    from tornado.concurrent import Future
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders, parse_body_arguments
    from tornado.iostream import IOStream
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase

    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs) -> None:
            pass

    class MySimpleAsyncHTTPClient(SimpleAsyncHTTPClient):
        def initialize(self, **kwargs) -> None:
            pass

    class AsyncHTTPClientTestCase(AsyncHTTPTestCase):
        def get_app(self) -> Any:
            return None
