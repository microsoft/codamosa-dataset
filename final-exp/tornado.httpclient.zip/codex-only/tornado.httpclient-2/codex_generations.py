

# Generated at 2022-06-24 08:30:34.233602
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    # test __init__ with full arguments
    ht_reqest = HTTPRequest(url='www.quandl.com')
    ht_response = HTTPResponse(request=ht_reqest, code=200, headers={},
                               buffer=b'', effective_url = 'www.quandl.com',
                               error = None, request_time = 1.24,
                               time_info = {1.2:'1.24'}, reason = 'OK',
                               start_time = 12.33)
    print(ht_response.request)
    print(ht_response.code)
    print(ht_response.reason)
    print(ht_response.headers)
    print(ht_response.buffer)
    print(ht_response.body)
    print(ht_response.effective_url)


# Generated at 2022-06-24 08:30:37.013963
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    a = HTTPClient()
    a.close()
    try:
        response = a.fetch("http://www.google.com/")
    except HTTPError as e:
        print("Error: " + str(e))

# Generated at 2022-06-24 08:30:41.983058
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    h = httpclient.HTTPClient()
    try:
        response = h.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    h.close()


# Generated at 2022-06-24 08:30:51.943630
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://example.com")
    assert _RequestProxy(request, None).request is request
    assert _RequestProxy(request, None).url == "http://example.com"
    assert _RequestProxy(request, {"url": "http://localhost"}).url == "http://localhost"
    assert _RequestProxy(request, {}).url == "http://example.com"
    request = HTTPRequest("http://localhost")
    assert _RequestProxy(request, None).url == "http://localhost"
    assert _RequestProxy(request, {"url": "http://example.com"}).url == "http://localhost"



# Generated at 2022-06-24 08:30:52.391329
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-24 08:30:58.149961
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    import pytest
    req = HTTPRequest("GET", "127.0.0.1")
    default = {'test_default': "default_value"}
    proxy = _RequestProxy(req, default)
    assert proxy.test_default == "default_value"
    assert proxy.method == req.method
    assert proxy.url == req.url
    assert proxy.enable_compression == req.enable_compression # noqa:E501
    with pytest.raises(AttributeError):
        proxy.method_not_exist # noqa:F821

# ------------------------------------------------------------------------------
# Synchronous HTTP client
# ------------------------------------------------------------------------------



# Generated at 2022-06-24 08:31:05.897512
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado_py3.ioloop import IOLoop
    from tornado_py3.httpclient import AsyncHTTPClient
    from tornado_py3.simple_httpclient import SimpleAsyncHTTPClient
    ioloop = IOLoop()
    a = AsyncHTTPClient()
    # Initialize self._closed at the beginning of the constructor
    # so that an exception raised here doesn't lead to confusing
    # failures in __del__.
    a._closed = True
    assert a._closed == True
    assert a._io_loop == ioloop
    assert a._async_client.__class__ == SimpleAsyncHTTPClient
    a.close()
    assert a._closed == True
    a._closed = False
    a.close()
    assert a._closed == True
    # a.close()
    # assert a._closed == True
#

# Generated at 2022-06-24 08:31:10.455787
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Test  rethrow raise exception
    r = HTTPResponse(HTTPRequest(),200,{},None,None,Exception())
    try:
        r.rethrow()
    except:
        return True
    else:
        return False



# Generated at 2022-06-24 08:31:16.089136
# Unit test for function main
def test_main():
    import sys
    import pandas
    print(sys.argv[1])
    df = pandas.read_csv(sys.argv[1])
    df.columns = ['doc_id','query','query_id','url','label']
    print(df.shape)
    print(df.head())
    main()
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-24 08:31:17.490908
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass



# Generated at 2022-06-24 08:31:24.556056
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    client = AsyncHTTPClient()
    request = "http://localhost:8080"
    # Order is important here. The last response is the one that
    # get's handled.
    responses = []
    def handle_response(response):
        responses.append(response)
        client.io_loop.stop()
    client.fetch(request, callback=handle_response)
    client.io_loop.start()
    assert len(responses) == 1
    response = responses[0]
    assert response.code == 200
    assert response.body == b"Hello"

# Generated at 2022-06-24 08:31:30.623713
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-24 08:31:31.755571
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
	obj = HTTPClientError(None)
	r = repr(obj)
	assert r == 'HTTP None: Unknown'


# Generated at 2022-06-24 08:31:35.060342
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(599, 'Error')
    except HTTPClientError as e:
        assert e.code == 599
        assert e.response is None
        assert isinstance(e, HTTPClientError)


# Alias for compatibility with code written for Tornado < 5.1
HTTPError = HTTPClientError

# Alias for compatibility with code written for older versions of Tornado.
HTTPError = HTTPClientError
IOError = HTTPClientError



# Generated at 2022-06-24 08:31:38.193090
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    # Try to fetch url
    url = "https://www.tutorialspoint.com/python/"
    response = http_client.fetch(url)
    print(response.body)
    http_client.close()


# Generated at 2022-06-24 08:31:39.942142
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    assert not http_client._closed
    http_client.close()
    assert http_client._closed



# Generated at 2022-06-24 08:31:44.150664
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    """Test the method fetch_impl of class AsyncHTTPClient"""
    # Test that the method fetch_impl is callable
    try:
        AsyncHTTPClient().fetch_impl(HTTPRequest(),lambda x: x)
    except NotImplementedError:
        print("Method fetch_impl of class AsyncHTTPClient is not implemented")


# Generated at 2022-06-24 08:31:44.800504
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    pass

# Generated at 2022-06-24 08:31:48.185694
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    err = HTTPClientError(503, message='503 message', response=None)
    assert err.code == 503
    assert err.message == '503 message'
    assert err.response is None


# Alias for backward compatibility
HTTPError = HTTPClientError



# Generated at 2022-06-24 08:31:59.621121
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop

    class MainTestHandler(RequestHandler):
        def get(self):
            self.write('test')

    class MainTest(AsyncHTTPTestCase):
        @gen_test
        def test_main_test(self):
            app = Application([(r"/", MainTestHandler)])
            self.http_server = self.get_http_server()
            self.http_server.listen(self.get_http_port())
            loop = IOLoop.instance()
            loop.run_sync(main)

    MainTest().test_main_test()



# Generated at 2022-06-24 08:32:08.872622
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    '''
    Test HTTPRequest constructor
    '''
    url = 'http://www.google.com'
    method = 'GET'
    headers = {"name": "HttpRequest"}
    body = 'request body'
    auth_username = 'username'
    auth_password = 'password'
    connect_timeout = 20
    request_timeout = 20
    if_modified_since = datetime.datetime.now()
    follow_redirects = True
    max_redirects = 5
    user_agent = 'Agent'
    decompress_response = True
    network_interface = '0.0.0.0'
    streaming_callback = lambda x : x
    header_callback = lambda x : x
    prepare_curl_callback = lambda x : x
    proxy_host = 'proxy_host'
    proxy_port

# Generated at 2022-06-24 08:32:16.980878
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    CUT = HTTPClientError
    # Given
    http_client_error = HTTPClientError(404, "Not Found", None)
    expected_result = "HTTP 404: Not Found"
    # When
    actual_result = repr(http_client_error)
    # Then
    assert actual_result == expected_result, "expected result: {}, actual result: {}".format(expected_result, actual_result)

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:32:18.996993
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():

    testobj = HTTPClientError()
    assert testobj
test_HTTPClientError___repr__()

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:32:25.922658
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Ensure that we close the AsyncHTTPClient instance. Tornado's
    # test suite does not trigger all code paths that use this function,
    # but I have confirmed via valgrind that it is called when needed.
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase

    class AsyncHTTPCloseTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", HelloHandler)])

    AsyncHTTPCloseTestCase().tearDown()
    # The following would segfault if the issue wasn't fixed.
    AsyncHTTPClient.configure(SimpleAsyncHTTPClient)
    AsyncHTTPCloseTestCase().tearDown()

# Generated at 2022-06-24 08:32:28.278330
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    hc = HTTPClient()
    assert not hc._closed, "The value should be false"
    hc.close()
    assert hc._closed, "The close method does not work well"
    return True



# Generated at 2022-06-24 08:32:29.002948
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    pass



# Generated at 2022-06-24 08:32:35.896018
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-24 08:32:41.503537
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Test the fetch method of AsyncHTTPClient class
    # precondition: IOLoop is not running

    # setup
    # create fake HTTPRequest instance
    from .httputil import HTTPHeaders, HTTPMessageDelegate, HTTPConnectionParameters, _normalize_headers, HTTPRequest, _RequestProxy, _HTTPRequestTuple
    from .util import _GzipDelegator, _get_sockaddr
    from .concurrent import Future, chain_future
    from .ioloop import IOLoop
    from .http1connection import HTTP1Connection, _DEFAULT_CHUNK_SIZE
    from .http1connection import _HEADERS_RECEIVED as _HTTP1CONN_HEADERS_RECEIVED
    import _thread
    import time
    import logging
    import typing

    _CONNECTION_TIMEOUT = 20.

# Generated at 2022-06-24 08:32:48.819958
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # TODO: Implement test
    h = HTTPResponse(HTTPRequest("https://api.github.com/user"),
        code=200,
        headers=None,
        buffer=None,
        effective_url="https://api.github.com/",
        error=None,
        request_time=4.3,
        time_info=[],
        reason="accepted",
        start_time=0)
    expected = "HTTPResponse(code=200,effective_url='https://api.github.com/',"
    assert repr(h) == expected



# Generated at 2022-06-24 08:32:55.199334
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    r = HTTPResponse(
        request=None,
        code=200,
        headers=None,
        effective_url='',
        error=None,
        request_time=None,
        time_info=None,
        reason='reason',
        start_time=None
    )
    assert repr(r) == "HTTPResponse(code=200, effective_url='', reason='reason', request=None, request_time=None, start_time=None, time_info=None)"



# Generated at 2022-06-24 08:32:56.906865
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    assert client.io_loop == IOLoop.current()


# Generated at 2022-06-24 08:33:01.197889
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.httpclient
    http_client = tornado.httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except tornado.httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()
test_HTTPClient_fetch()


# Generated at 2022-06-24 08:33:03.017888
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    inst = AsyncHTTPClient()
    inst.close()


# Generated at 2022-06-24 08:33:11.421698
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    
 
    methods = ['GET', 'POST', 'DELETE', 'PUT', 'HEAD', 'OPTIONS',
        'PATCH', 'TRACE', 'CONNECT']
    headers = dict(random.choice(list(httputil.HTTPHeaders.__dict__.items())))
    url = random.choice(['https://www.cnn.com', 'https://www.cnbc.com', 'https://www.washingtonpost.com'])
    request = HTTPRequest(method = random.choice(methods), headers = headers, url = url)
    code = random.randint(200, 500)
    headers2 = dict(random.choice(list(httputil.HTTPHeaders.__dict__.items())))
    buffer = BytesIO(b'kldfnvjdvj')
    effective_url

# Generated at 2022-06-24 08:33:13.761075
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    with pytest.raises(NotImplementedError):
        AsyncHTTPClient().initialize()


# Generated at 2022-06-24 08:33:16.445584
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    """Test if the method close of class AsyncHTTPClient works well."""
    http_client = AsyncHTTPClient()
    http_client.close()


# Generated at 2022-06-24 08:33:23.114824
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    kwargs = dict()
    kwargs['url'] = 'http://www.baidu.com'
    kwargs['method'] = 'GET'
    kwargs['body'] = 'msg'
    kwargs['auth_username'] = 'u'
    kwargs['auth_password'] = 'p'
    kwargs['auth_mode'] = 'basic'
    kwargs['connect_timeout'] = 20
    kwargs['request_timeout'] = 20
    kwargs['if_modified_since'] = datetime.datetime.now()
    kwargs['follow_redirects'] = True
    kwargs['max_redirects'] = 5
    kwargs['user_agent'] = 'browser'
    kwargs['use_gzip'] = True

# Generated at 2022-06-24 08:33:31.927167
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    cacerts = None
    http_client = SimpleAsyncHTTPClient()
    http_client._max_buffer_size = 100
    http_proxy = _RequestProxy(HTTPRequest(url='',connect_timeout=5,request_timeout=5),
                              defaults = {'cacerts':cacerts,'http_client':http_client})
    cases = [
        (http_proxy.cacerts, cacerts),
        (http_proxy.http_client, http_client),
        (http_proxy.foo, None),
        (http_proxy.bar, None)
    ]
    for case in cases:
        assert case[0] == case[1]



# Generated at 2022-06-24 08:33:33.976970
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
	request=HTTPRequest('url')
	defaults=None
	request_attr=_RequestProxy(request,defaults)
	assert request_attr.url == 'url'


# Generated at 2022-06-24 08:33:40.039880
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    http_client = AsyncHTTPClient()
    http_client.initialize()
    assert http_client.defaults == {"follow_redirects": True, "max_redirects": 5, "user_agent": "tornado/4.0"}
    assert http_client.io_loop == IOLoop.current()
    assert http_client._closed == False
    # Test with defaults
    http_client = AsyncHTTPClient()
    http_client.initialize(defaults={"abc": "123"})
    assert http_client.defaults == {"abc": "123", "follow_redirects": True, "user_agent": "tornado/4.0", "max_redirects": 5}


# Generated at 2022-06-24 08:33:43.176866
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    """
    Tests the fetch_impl method of AsyncHTTPClient
    """
    # TODO: Not yet implemented
    pass


# Generated at 2022-06-24 08:33:52.446299
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    from tornado.options import define, options, parse_command_line
    define("foo", type=str, help="help for foo")
    define("foo2", type=str, help="help for foo2")
    parse_command_line()
    request = HTTPRequest(url="http://www.baidu.com")
    request._foo = "foo"
    req_proxy = _RequestProxy(request, options.as_dict())
    req_proxy.foo = "bar"
    req_proxy._foo = "baz"
    assert request.foo == "foo"
    assert req_proxy.foo == "bar"
    assert request.foo2 == "bar"



# Generated at 2022-06-24 08:33:54.842408
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    assert AsyncHTTPClient() is AsyncHTTPClient()



# Generated at 2022-06-24 08:34:00.251928
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    def test1():
        # test AsyncHTTPClient.fetch
        import sys
        import tornado.ioloop
        import tornado.httpclient
        # AsyncHTTPClient.configure writes to the module, so we need
        # a separate import space to prevent tests from interfering
        # with each other.
        http_client = tornado.httpclient.AsyncHTTPClient()
        try:
            response = yield http_client.fetch("http://www.tornadoweb.org/")
            print(response.error)
        except tornado.httpclient.HTTPError as e:
            # HTTPError is raised for non-200 responses; the response
            # can be found in e.response.
            print("Error: " + str(e))

# Generated at 2022-06-24 08:34:01.568160
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()


# Generated at 2022-06-24 08:34:03.453948
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    # test close with no parameter
    a = HTTPClient()
    assert isinstance(a, HTTPClient)


# Generated at 2022-06-24 08:34:06.095944
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    assert isinstance(AsyncHTTPClient(), SimpleAsyncHTTPClient)



# Generated at 2022-06-24 08:34:17.954679
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # class AsyncHTTPClient(Configurable):
    #     def fetch_impl(
    #         self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
    #     ) -> None:
    #         raise NotImplementedError()
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import bind_unused_port
    from tornado.testing import ExpectLog
    from tornado.testing import LogTrapTestCase
    from tornado.testing import main
    import tornado.web
    import json
    import unittest
    import urllib

    # We just test the HTTPRequest here, because HTTPClient and its
    # subclasses are tested extensively elsewhere.

# Generated at 2022-06-24 08:34:25.880491
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import pytest, os
    from tornado.ioloop import IOLoop
    # From tornado.curl_httpclient import CurlAsyncHTTPClient
    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse
    # test __new__()
    force_instance = True
    request = HTTPRequest('/')
    response = AsyncHTTPClient().fetch(request)
    # From tornado.testing import AsyncHTTPTestCase, gen_test
    chunk_size = 8 << 10
    chunk_size2 = chunk_size // 2
    chunk_size3 = chunk_size // 3
    chunk_size4 = chunk_size // 4
    client_timeout = 100
    source = '012345678' * chunk_size
    source_len = len(source)
    source_len

# Generated at 2022-06-24 08:34:29.825013
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    class Dummy(object):
        pass
    request = Dummy()
    request.body = "123"

    proxy = _RequestProxy(request, defaults=dict(body="456"))

    # Test if attribute from request can be accessed by proxy.
    assert proxy.body == "123"

    # Test if attribute from defaults can be accessed by proxy.
    assert proxy.body2 == "456"

    # Test if not existing attribute throws an AttributeError.
    with pytest.raises(AttributeError):
        proxy.not_existing


# Generated at 2022-06-24 08:34:33.112818
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()



# Generated at 2022-06-24 08:34:46.102094
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import pytest
    from asyncio import coroutine
    from unittest import mock

    from tornado.simple_httpclient import SimpleAsyncHTTPClient, _HTTPConnection

    @coroutine
    def test_it(mocker):
        io_loop = IOLoop.current()
        client = mocker.patch.object(SimpleAsyncHTTPClient, '__new__')

        # This will call __new__ on SimpleAsyncHTTPClient
        AsyncHTTPClient.configure()

        # Make sure we call AsyncHTTPClient.__new__ and not
        # SimpleAsyncHTTPClient.__new__ again.
        AsyncHTTPClient(force_instance=True)

        # Make sure we create or reuse OpenSSL connection

# Generated at 2022-06-24 08:34:48.462246
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    assert(AsyncHTTPClient.__new__(AsyncHTTPClient, force_instance=False, **{}) is not None)

# Generated at 2022-06-24 08:34:52.181275
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    h = HTTPResponse(None, 200)
    assert h.code == 200
    h = HTTPResponse(None, 400, reason="Bad")
    assert h.code == 400
    assert h.reason == "Bad"


# Generated at 2022-06-24 08:34:59.257838
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado import testing

    class DummyAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, io_loop, defaults):
            self.io_loop = io_loop
            self.defaults = defaults

        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass

    @testing.gen_test
    def test_initialize():
        io_loop = IOLoop()
        client = DummyAsyncHTTPClient(io_loop, defaults=dict(a=1))
        assert client.io_loop is io_loop
        assert client.defaults["a"] == 1

    test_initialize()



# Generated at 2022-06-24 08:35:01.405517
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    http_response = HTTPResponse(None, None)

# Generated at 2022-06-24 08:35:02.876489
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    pass


# Generated at 2022-06-24 08:35:06.119921
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(403, message="msg", response="response")
    assert error.code == 403
    assert error.message == "msg"
    assert error.response == "response"

# XXX deprecated alias
HTTPError = HTTPClientError



# Generated at 2022-06-24 08:35:08.569514
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    httpClient = HTTPClient()
    assert isinstance(httpClient, HTTPClient), 'Should be of type HTTPClient'
    httpClient.close()
    assert httpClient._closed, 'Should be True'



# Generated at 2022-06-24 08:35:10.864582
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    cl = HTTPClient("https://www.google.com/")
    cl.fetch("http://localhost")
    print("test success")
test_HTTPClient_fetch()


# Generated at 2022-06-24 08:35:16.728428
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-24 08:35:19.243506
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(500)
    except HTTPClientError as e:
        assert e.response is None
        assert e.code == 500
    else:
        raise ValueError("invalid error")


# This class is available for backwards compatibility
HTTPError = HTTPClientError



# Generated at 2022-06-24 08:35:23.722883
# Unit test for function main
def test_main():
    """
    This unit test calls main to sanity check whether calling main programmatically doesn't throw an Exception
    """
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:35:25.482026
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-24 08:35:26.688994
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    httpClient = HTTPClient()
    httpClient.close()

# Generated at 2022-06-24 08:35:35.846176
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    class ReprableObject(object):
        def __repr__(self) -> str:
            return 'repr("hello")'
    http_response = HTTPResponse(
        request = HTTPRequest("http://example.com/request"),
        code = 200,
        headers = None,
        buffer = BytesIO(""),
        effective_url = "http://example.com/effective_url",
        error = IOError("hello"),
        request_time = 2,
        time_info = {"a": 1, "b": 2},
        reason = "ok",
        start_time = ReprableObject(),
    )

# Generated at 2022-06-24 08:35:41.351729
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # self.assertRaises(TypeError, self.http_client.fetch, 'http://www.google.com/',
    #                                   body='asdf')
    print("asdfasdf")
    # self.http_client.fetch('http://www.google.com/', body='asdf')



# Generated at 2022-06-24 08:35:49.053520
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('http://baidu.com')
    code = 200
    buffer = BytesIO()

    # test case 1
    res = HTTPResponse(request, code, buffer)
    res.error = None
    res.rethrow()

    # test case 2
    res.error = HTTPError(res.code, res.reason)
    try:
        res.rethrow()
    except HTTPError as e:
        print(e)
        print(e.__class__.__name__)
        print(e.code)



# Generated at 2022-06-24 08:35:51.080866
# Unit test for function main
def test_main():
    # Test for py27
    if sys.version_info[0] >= 3:
        return
    else:
        return



# Generated at 2022-06-24 08:36:03.581034
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest ('https://www.google.com/',method='GET')
    response = HTTPResponse (request,200,{'a':1,'b':2},BytesIO(),'https://www.google.com/',None,0,{},None,0)
    assert repr(response) == "HTTPResponse(a={'a': 1, 'b': 2}, body=b'', buffer=<_io.BytesIO object at 0x7f78f42dbcc0>, code=200, effective_url='https://www.google.com/', error=None, headers={'a': 1, 'b': 2}, reason='Unknown', request=<tornado.httpclient.HTTPRequest at 0x7f78f42dbc18>, request_time=0, start_time=0, time_info={})"



# Generated at 2022-06-24 08:36:06.444218
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://foo.com")
    defaults = {'method': 'GET', 'connect_timeout': 0.0005, 'request_timeout': 0.006}
    proxy = _RequestProxy(request, defaults)
    assert(proxy.method == 'GET')
    assert(proxy.connect_timeout == 0.0005)
    assert(proxy.request_timeout == 0.006)
    assert(proxy.url == "http://foo.com")
    assert(proxy.headers is None)



# Generated at 2022-06-24 08:36:14.547583
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():


    instance_cache_bk = AsyncHTTPClient._instance_cache.copy()
    try:
        AsyncHTTPClient._instance_cache = {}
        client1 = AsyncHTTPClient()
        client2 = AsyncHTTPClient()
        assert client1 is not client2
        client3 = AsyncHTTPClient(force_instance=True)
        client4 = AsyncHTTPClient(force_instance=True)
        assert client3 is not client4
        client5 = AsyncHTTPClient()
        assert client1 is not client5
        assert client1 is not client3
        assert client4 is not client5
        with pytest.raises(RuntimeError):
            client1.close()
            client2.close()
            raise Exception()
        assert AsyncHTTPClient._instance_cache == {}
    finally:
        AsyncHTTPClient._instance

# Generated at 2022-06-24 08:36:27.562362
# Unit test for method __repr__ of class HTTPResponse

# Generated at 2022-06-24 08:36:37.277659
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    defaults = {"key": "default"}

# Generated at 2022-06-24 08:36:43.239458
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)
    # test after
    IOLoop.current().run_sync(f, timeout=100)



# Generated at 2022-06-24 08:36:48.426051
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    req=HTTPRequest(url="http://www.baidu.com")
    defaults = {'connect_timeout': 8, 'request_timeout': 9}
    r1=_RequestProxy(req,defaults)
    assert r1.url=='http://www.baidu.com'
    assert r1.connect_timeout==8
    assert r1.request_timeout==9



# Generated at 2022-06-24 08:37:01.619557
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-24 08:37:03.276259
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    http_client.close()



# Generated at 2022-06-24 08:37:05.260199
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = httpclient.HTTPClient()
    http_client.close()


# Generated at 2022-06-24 08:37:06.406283
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()



# Generated at 2022-06-24 08:37:07.587706
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])



# Generated at 2022-06-24 08:37:16.936543
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import json

    import tornado.ioloop
    import tornado.web
    import tornado.gen

    class MainHandler(tornado.web.RequestHandler):
        @tornado.gen.coroutine
        def get(self):
            response = yield tornado.httpclient.AsyncHTTPClient().fetch('http://ip.42.pl/raw')
            print(response.body)
            self.write(json.dumps(dict(text=response.body)))

    app = tornado.web.Application([
        (r"/", MainHandler),
    ])

    app.listen(8888)
    tornado.ioloop.IOLoop.current().start()
test_AsyncHTTPClient_fetch()



# Generated at 2022-06-24 08:37:23.526872
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    req = HTTPRequest('http://example.com', 'GET')
    assert req.method == 'GET'
    defaults = {'method': 'POST'}
    req_proxy = _RequestProxy(req, defaults)
    assert req_proxy.method == 'GET'
    assert req_proxy.body == None
    assert req_proxy.url == 'http://example.com'

# Generated at 2022-06-24 08:37:24.048293
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-24 08:37:30.147482
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # if  AsyncHTTPClient.close() exist
    assert(hasattr(AsyncHTTPClient, 'close'))
    # if the method return type is not bool
    assert(isinstance(AsyncHTTPClient.close(), bool))
    # if the method return type is not void
    res = AsyncHTTPClient.close()
    assert(res == None or res == None)

# Generated at 2022-06-24 08:37:35.372020
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url="http://localhost:8888/test.html", method="GET")
    request_proxy = _RequestProxy(request, defaults={})
    request_proxy.__getattr__(name="method")
    request_proxy.__getattr__(name="defaults")
    request_proxy.__getattr__(name="url")
    request_proxy.__getattr__(name="1")



# Generated at 2022-06-24 08:37:39.524666
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    AsyncHTTPClient.configure(None, defaults=None)
    assert AsyncHTTPClient._instance_cache is None
    assert AsyncHTTPClient()._instance_cache is None



# Generated at 2022-06-24 08:37:50.520301
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
	print('\n\n\n\n\n\n\n')
	http_client = httpclient.HTTPClient()
	request = HTTPRequest("http://www.google.com/")
	try:
		response = http_client.fetch(request)
		print(response.body)
	except httpclient.HTTPError as e:
		# HTTPError is raised for non-200 responses; the response
		# can be found in e.response.
		print("Error: " + str(e))
	except Exception as e:
		# Other errors are possible, such as IOError.
		print("Error: " + str(e))
	finally:
		http_client.close()
	print('\n\n\n\n\n\n\n')



# Generated at 2022-06-24 08:38:04.161085
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url = "http://www.google.com",
                            method = "GET",
                            body = "abc=123")
    response = HTTPResponse(code = 200,
                            headers = None,
                            buffer = None,
                            effective_url = None,
                            error = None,
                            request_time = 1.0,
                            time_info = None,
                            reason = None,
                            request = request,
                            start_time = None)
    response.rethrow()

# Generated at 2022-06-24 08:38:06.769407
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    """
    Test for the constructor of the class HTTPClient.
    """
    HttpClient = HTTPClient()
    assert not HttpClient._closed



# Generated at 2022-06-24 08:38:18.804646
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    def get_instance(cls):
        if cls.__name__ == 'AsyncHTTPClient':
            return cls()
        else:
            return cls
    AsyncHTTPClient.configure = get_instance
    _instance_cache = {}
    _closed = True
    io_loop = "io"
    _async_client_dict_AsyncHTTPClient = {io_loop: "instance"}
    def get_instance_cache(cls):
        return _instance_cache
    def get_closed(self):
        return _closed
    def set_closed(self, x):
        nonlocal _closed
        _closed = x
    def get_async_client_dict(cls):
        return _async_client_dict_AsyncHTTPClient

# Generated at 2022-06-24 08:38:31.646789
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # Test for the method __repr__(self) of class HTTPResponse
    count = 0
    from tornado.escape import utf8
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    request = HTTPRequest('http://www.google.com/?test=test')
    code = 200
    headers = None
    buffer = None
    effective_url = None
    error = None
    request_time = None
    time_info = None
    reason = None
    start_time = None
    response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)
    r = repr(response)

# Generated at 2022-06-24 08:38:32.904984
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # TODO
    pass


# Generated at 2022-06-24 08:38:40.216336
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-24 08:38:52.714898
# Unit test for function main
def test_main():
    import sys
    import io
    from tornado.testing import AsyncTestCase, main, bind_unused_port
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest

    def handle_request(response):
        assert response.code == 200
        assert b"Hello" in response.body
        assert b"Host" in response.body
        assert response.headers[b"Content-Type"] == b"text/html"
        assert response.headers[b"Date"]
        assert response.headers[b"Server"]

    class MainTest(AsyncTestCase):
        def test_main(self):
            sock, port = bind_unused_port()
            with sock:
                with io.open(sys.executable, "rb") as f:
                    python_code = f.read()

                http_server = HTTPServer()
               

# Generated at 2022-06-24 08:39:05.079662
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    import pytest
    from tornado.ioloop import IOLoop, PeriodicCallback
    from tornado.httputil import HTTPHeaders
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import _RequestProxy, HTTPResponse, HTTPRequest, HTTPResponse
    from tornado import testing
    from tornado.concurrent import Future
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest
    from tornado.test.httpclient_test import AsyncHTTPClientTestCase, ExpectLog, SimpleHandler
    import time
    import os,sys
    import inspect
    import warnings
    print("test_HTTPClient___del__")

# Generated at 2022-06-24 08:39:11.854959
# Unit test for function main
def test_main():
    with mock.patch('tornado.options.parse_command_line') as mock_parse_command_line:
        with mock.patch('tornado.options.options') as mock_options:
            with mock.patch('tornado.httpclient.HTTPClient') as mock_HTTPClient:
                with mock.patch('tornado.httpclient.HTTPError') as mock_HTTPError:
                    with mock.patch('builtins.print') as mock_print:
                        mock_parse_command_line.return_value = ['foo']
                        mock_options.follow_redirects = True
                        mock_options.validate_cert = True
                        mock_options.proxy_host = None
                        mock_options.proxy_port = None
                        mock_client = mock.MagicMock()
                        mock_client.fetch.return_value = 'bar'


# Generated at 2022-06-24 08:39:14.780168
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    hc = HTTPClient()
    hc.close()
    assert hc._closed == True

# Generated at 2022-06-24 08:39:24.088087
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    _defaults = dict(arg="arg")

# Generated at 2022-06-24 08:39:25.883216
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass



# Generated at 2022-06-24 08:39:27.989756
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    t = AsyncHTTPClient()
    t.close()
    t.close()
    t.close()


# Generated at 2022-06-24 08:39:40.706454
# Unit test for function main
def test_main():
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import functools
    import logging
    import threading
    import time
    import unittest

    from tornado.options import define, options, parse_command_line
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.util import unittest

    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)



# Generated at 2022-06-24 08:39:42.384199
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    assert isinstance(HTTPRequest(url="url").url, str)
    assert isinstance(HTTPRequest(url=0).url, str)


# Generated at 2022-06-24 08:39:54.473431
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import HTTPRequest, HTTPResponse
    from tornado.httputil import HTTPHeaders
    import tornado.ioloop
    import tornado.simple_httpclient
    import tornado.httpclient
    import tornado.netutil
    import fcntl
    import tornado.locks
    import socket
    import tornado.simple_httpclient
    import tornado.concurrent
    import tornado.ioloop
    import tornado.iostream
    import tornado.log
    import tornado.stack_context
    import tornado.tcpclient
    import tornado.test.util
    from tornado.testing import AsyncHTTPTestCase
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import json
    _MY_IP = '127.0.0.1'
    _MY_PORT = 8888


# Generated at 2022-06-24 08:40:02.107561
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    class Client(AsyncHTTPClient):
        pass

    # Test that the constructor is a no-op with the default value of
    # force_instance.
    for io_loop in [None, IOLoop.current()]:
        c1 = Client()
        assert c1.io_loop is IOLoop.current()
        c2 = Client(io_loop=io_loop)
        assert c2.io_loop is IOLoop.current()
        assert c1 is c2

    # Test force_instance=True.
    c1 = Client(force_instance=True)
    c2 = Client(force_instance=True, io_loop=c1.io_loop)
    assert c1 is not c2
    assert c1.io_loop is c2.io_loop

    # Test close().

# Generated at 2022-06-24 08:40:05.444940
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.curl_httpclient import CurlAsyncHTTPClient
    client = CurlAsyncHTTPClient()
    client.close()
    pass



# Generated at 2022-06-24 08:40:17.933515
# Unit test for method __del__ of class HTTPClient

# Generated at 2022-06-24 08:40:26.494017
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import os
    import socket
    import threading
    import time
    import unittest

    import tornado
    import tornado.concurrent
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.testing
    import tornado.test.util
    import tornado.test.httpclient_test
    from tornado.httpclient import HTTPError, HTTPResponse
    from tornado.httputil import HTTPHeaders, parse_url_origin

    # SSLv3 is disabled by default because of POODLE
    # (http://en.wikipedia.org/wiki/POODLE)
    # There are still servers that only support SSLv3, so tests are
    # conditional on the PROTOCOL_SS