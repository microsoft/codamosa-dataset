

# Generated at 2022-06-24 08:30:25.355871
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-24 08:30:37.512474
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    r = HTTPRequest('https:://www.baidu.com')
    h = HTTPResponse(r, 200)
    print(h)
    assert isinstance(h, HTTPResponse)
    assert isinstance(h.error, type(None))
    assert isinstance(h.request, HTTPRequest)
    assert isinstance(h.code, int)
    assert isinstance(h.reason, str)
    assert isinstance(h.headers, httputil.HTTPHeaders)
    assert isinstance(h.buffer, BytesIO)
    assert isinstance(h.body, bytes)
    assert h.body == b''
    assert isinstance(h.effective_url, str)
    assert isinstance(h.start_time, float)
    assert isinstance(h.request_time, float)
   

# Generated at 2022-06-24 08:30:45.056706
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest('http://example.com')
    proxy = _RequestProxy(request, {'foo': 'bar'})
    assert proxy.request is request
    assert proxy.foo == 'bar'
    assert proxy.url == 'http://example.com'
    request = HTTPRequest(url='http://example.com')
    proxy = _RequestProxy(request, {'foo': 'bar'})
    assert proxy.request is request
    assert proxy.foo == 'bar'
    assert proxy.url == 'http://example.com'


# Generated at 2022-06-24 08:30:46.648684
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    client_error = HTTPClientError(599, message='HTTP 599: Timeout')
    assert client_error.__repr__() == 'HTTP 599: Timeout'


HTTPError = HTTPClientError

# Generated at 2022-06-24 08:30:47.181180
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
  pass

# Generated at 2022-06-24 08:30:48.330434
# Unit test for function main
def test_main():
    with mock.patch('tornado.httpclient.main',
                    return_value=None):
        main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:30:49.745278
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    request = 'request'
    callback = 'callback'
    assert_raises(NotImplementedError, AsyncHTTPClient().fetch_impl, request, callback)



# Generated at 2022-06-24 08:30:54.788984
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import pickle
    import sys
    import types

    def unbound_method(o, m):
        def f(*args, **kwargs):
            return getattr(o, m)(*args, **kwargs)

        return f

    instance_method = unbound_method(HTTPClient, "fetch")
    #
    # hasattr(async_tcp_server, '_on_connections_cleaned')
    # hasattr(async_tcp_server, '_on_connections_cleaned')
    #
    AsyncHTTPClient.fetch_impl
    # hasattr(instance_method, '__dict__')
    # hasattr(instance_method, '__class__')
    # hasattr(instance_method, '__weakref__')
    # hasattr(instance_method, '__func__

# Generated at 2022-06-24 08:30:59.595084
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('http://www.google.com',method="GET")
    r = HTTPResponse(request, 301)
    try:
        r.rethrow()
    except:
        assert True
    return


# Generated at 2022-06-24 08:31:06.959436
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import inspect
    import random
    import types
    import pytest
    import tornado
    import tornado.web
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.httpclient
    import tornado.testing
    import tornado.test.web_test


    class HelloWorldHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello world")

    def make_app():
        return tornado.web.Application([("/", HelloWorldHandler)])

    class AsyncHTTPTestCase(tornado.testing.AsyncHTTPTestCase):

        # make the test server available on instance for
        # inspection by tests.
        server = None # type: Any

        def get_app(self):
            return make_app()

    # Unit test for method fetch of class HTTPClient

# Generated at 2022-06-24 08:31:12.760443
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():  # type: ignore
    import tornado.platform.asyncio
    import tornado.platform.twisted
    import tornado.platform.select

    # AsyncHTTPClient is an abstract class, so test the
    # SimpleAsyncHTTPClient implementation instead.
    client = httpclient.AsyncHTTPClient()
    assert isinstance(client, httpclient.SimpleAsyncHTTPClient)
    httpclient.AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    client = httpclient.AsyncHTTPClient()
    assert isinstance(client, httpclient.CurlAsyncHTTPClient)
    httpclient.AsyncHTTPClient.configure(None)
    client = httpclient.AsyncHTTPClient()
    assert isinstance(client, httpclient.SimpleAsyncHTTPClient)

    # Test that max_clients works

# Generated at 2022-06-24 08:31:14.371410
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    http_error = HTTPClientError(404,"")
    result = http_error.__repr__()
    print(result)


# Generated at 2022-06-24 08:31:26.210453
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    default_kwargs = dict(HTTPRequest._DEFAULTS)
    for k, v in dict(
        max_clients=10,
        max_buffer_size=10 * 1024 * 1024,
        defaults={},
        validate_cert=True,
        max_header_size=64 * 1024,
        max_body_size=None,
        proxy_host=None,
        proxy_port=None,
        proxy_username=None,
        proxy_password=None,
        proxy_auth_mode=None,
        allow_ipv6=False,
        tcp_keepalive=None,
        tcp_keepalive_options=None,
        defaults=default_kwargs,
        monitor=None,
    ).items():
        print(k, v)


# Generated at 2022-06-24 08:31:30.689437
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    import tornado.httpclient
    h = tornado.httpclient.HTTPClientError(403)
    assert repr(h) == 'HTTP 403: Forbidden'
    assert str(h) == 'HTTP 403: Forbidden'

# The class name HTTPError has been used since before version 2.0,
# so we preserve the old name for compatibility.
# By subclassing the new class, we can continue to use the new
# docstring.
HTTPError = HTTPClientError



# Generated at 2022-06-24 08:31:35.758168
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    global __unit_test_result
    __unit_test_result = False
    try:
        global __unit_test_result
        global __unit_test_pass
        global __unit_test_fail
        url = 'http://example.com'
        http_client = HTTPClient()
        http_client.close()
    except:
        print('Unit test HTTPClient close fails')
        __unit_test_result = False
        __unit_test_fail = __unit_test_fail + 1
    else:
        print('Unit test HTTPClient close passes')
        __unit_test_result = True
        __unit_test_pass = __unit_test_pass + 1
    return __unit_test_result

# Generated at 2022-06-24 08:31:36.751220
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:31:38.643263
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    pass



# Generated at 2022-06-24 08:31:47.737695
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    post_data={'name':'Bob'}
    post_data=urllib.parse.urlencode(post_data)
    post_data=post_data.encode('utf-8')
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch(
            "https://www.baidu.com/",
            method='POST',
            body=post_data
        )
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_

# Generated at 2022-06-24 08:32:01.950903
# Unit test for constructor of class _RequestProxy

# Generated at 2022-06-24 08:32:02.953516
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    HTTPRequest(url="http://localhost")


# Generated at 2022-06-24 08:32:03.698386
# Unit test for function main
def test_main():
    v = main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-24 08:32:07.379542
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    h = HTTPResponse(HTTPRequest("GET", "https://www.baidu.com/"), 200, reason="OK")
    h.rethrow()
    print("Pass")
test_HTTPResponse_rethrow()
 

# Generated at 2022-06-24 08:32:14.503828
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.log import gen_log

    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch(
                HTTPRequest(
                    url="http://www.google.com/robots.txt",
                    method="GET",
                    body=b"Hello",
                    headers={"Content-Type": "text/html"},
                    auth_username="XXX",
                    auth_password="YYY"
                ), raise_error=False
            )
            gen_log.info(response.body)
        except Exception as e:
            gen_log.warning(e)
        await http_client.close()

    IOLoop.current().run_sync(f)

# Generated at 2022-06-24 08:32:20.892720
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # Make sure AsyncHTTPClient.close cleans up its IOLoop
    client = AsyncHTTPClient()
    assert not client.io_loop.closed
    client.close()
    assert client.io_loop.closed
    # Make sure that using the same implementation class with force_instance
    # doesn't close the IOLoop.
    client = AsyncHTTPClient(force_instance=True)
    assert not client.io_loop.closed



# Generated at 2022-06-24 08:32:23.615596
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    resp = HTTPResponse(HTTPRequest(method="GET"), 200)
    err = HTTPClientError(599, "", resp)
    assert err.__repr__() == str(err)


HTTPError = HTTPClientError



# Generated at 2022-06-24 08:32:26.602481
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    """
    :return: nothing
    """
    x = HTTPResponse(request=None, code=None, headers=None, buffer=None,
                     effective_url=None, error=None, request_time=None,
                     reason=None, start_time=None, time_info=None)

# Generated at 2022-06-24 08:32:29.707768
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # HTTPResponse has no __init__ method.
    args = ",".join("%s=%r" % i for i in sorted(HTTPResponse.__dict__.items()))
    code = "HTTPResponse(%s)" % args
    assert eval(code) != None


# Generated at 2022-06-24 08:32:35.885582
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    
    import tornado.httpclient
    
    # Create an instance of the class AsyncHTTPClient
    http_client = tornado.httpclient.AsyncHTTPClient()
    
    # Call the method fetch of the class AsyncHTTPClient
    response = http_client.fetch('http://www.google.com/')
    
    # Verify that the response is an instance of the class HTTPResponse
    assert isinstance(response, tornado.httpclient.HTTPResponse)
    print(response.body)

test_AsyncHTTPClient_fetch()


# Generated at 2022-06-24 08:32:46.771775
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # Implicitly exercises the "private" __new__ method,
    # allowing us to test the *class* instead of an *instance*.
    ioloop = IOLoop.current()
    # cache is initially empty
    assert not AsyncHTTPClient._async_clients()
    # The first one we create is a magic singleton
    AsyncHTTPClient()  # type: ignore
    assert ioloop in AsyncHTTPClient._async_clients()
    # the second one shares the cache with the first
    assert AsyncHTTPClient() is AsyncHTTPClient._async_clients()[ioloop]
    # but if we create an instance with force_instance,
    # it doesn't go in the cache

# Generated at 2022-06-24 08:32:48.517455
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    client = HTTPClient()
    client.close()
    assert client._closed == True


# Generated at 2022-06-24 08:32:58.082503
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest('https://www.google.com')
    response = HTTPResponse(request, 200)
    assert response.status_code == 200
    assert response.reason == 'OK'
    assert response.effective_url == 'https://www.google.com'
    assert len(response.headers) == 0
    assert response.buffer is None
    assert response.body == b''
    assert response.error is None
    assert response.request_time is None
    assert len(response.time_info) == 0
    assert response.start_time is None
    assert response.status == '200 OK'
    assert response.url == 'https://www.google.com'
    assert repr(response) == 'HTTPResponse(code=200,effective_url=\'https://www.google.com\')'



# Generated at 2022-06-24 08:33:02.488454
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    with IOLoop.current() as io_loop:
        client = AsyncHTTPClient(force_instance=True)
        assert isinstance(client, AsyncHTTPClient)
        assert id(client.io_loop) == id(io_loop)



# Generated at 2022-06-24 08:33:11.129028
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest
    import mock
    import tornado.testing

    class FetchImpl(tornado.testing.AsyncHTTPTestCase):
        @mock.patch("tornado.httpclient.HTTPRequest")
        def test_fetch_impl(self, mock_request):
            import tornado.httpclient

            def test():
                client = tornado.httpclient.AsyncHTTPClient()
                response = tornado.httpclient.HTTPResponse(
                    tornado.httpclient.HTTPRequest(url="http://example.com"),
                    200,
                    error=None,
                    request_time=0.1,
                    code=200,
                )
                callback = mock.MagicMock()
                client.fetch_impl(mock_request, callback)
                self.assertEqual(callback.call_count, 1)

# Generated at 2022-06-24 08:33:18.280914
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    @gen.coroutine
    def f():
        http_client = AsyncHTTPClient()
        try:
            response = yield http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)
        finally:
            http_client.close()
    IOLoop.current().run_sync(f)


# Generated at 2022-06-24 08:33:26.365455
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import AsyncHTTPClient
    import tornado.ioloop
    import tornado.web

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    def handle_request(response):
        print(response.body)
        tornado.ioloop.IOLoop.current().stop()

    if __name__ == "__main__":
        app = tornado.web.Application([(r"/", MainHandler)])
        http_server = app.listen(8888)

        http_client = AsyncHTTPClient()
        http_client.fetch("http://localhost:8888/", handle_request)
        tornado.ioloop.IOLoop.current().start()


# Generated at 2022-06-24 08:33:28.432813
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    http_client


# Generated at 2022-06-24 08:33:30.848616
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import tornado.simple_httpclient
    obj = tornado.simple_httpclient.SimpleAsyncHTTPClient()
    assert isinstance(obj, tornado.simple_httpclient.SimpleAsyncHTTPClient)


# Generated at 2022-06-24 08:33:38.652627
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(404)
    assert str(error) == "HTTP 404: Not Found"
    assert error.__repr__() == "HTTP 404: Not Found"
    error = HTTPClientError(404, "File not found")
    assert str(error) == "HTTP 404: File not found"
    assert error.__repr__() == "HTTP 404: File not found"
    error = HTTPClientError(404, message="File not found")
    assert str(error) == "HTTP 404: File not found"
    assert error.__repr__() == "HTTP 404: File not found"
    error = HTTPClientError(404, response="File not found")
    assert str(error) == "HTTP 404: Not Found"
    assert error.__repr__() == "HTTP 404: Not Found"
    error = HTTPClientError

# Generated at 2022-06-24 08:33:44.701410
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://example.com")
    assert _RequestProxy(request, dict()) == request
    assert _RequestProxy(request, None) == request
    request2 = HTTPRequest("http://example2.com")
    assert _RequestProxy(request, request2) == request


# Generated at 2022-06-24 08:33:52.567280
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse(): 
    header1 = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36"}
    header2 = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36", "Referer": "http://www.baidu.com"}
    req = HTTPRequest("https://www.baidu.com", None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-24 08:33:53.940597
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass



# Generated at 2022-06-24 08:34:06.420426
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from requests import get
    from tornado.concurrent import Future
    from tornado.escape import json_decode
    from tornado.httpclient import (AsyncHTTPClient,
                                    HTTPRequest,
                                    HTTPResponse)
    @gen.coroutine
    def main():
        http_client = AsyncHTTPClient()
        request = HTTPRequest(
            url='http://localhost:8900/api/resource/Party',
            method='GET',
            connect_timeout=10.0,
            request_timeout=10.0)
        response = yield http_client.fetch(request)
        print(response.body)
        http_client.close()
    
    from tornado import ioloop
    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-24 08:34:11.098105
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler
    import tornado
    def test_async_close(io_loop: tornado.ioloop.IOLoop):
        http_client = AsyncHTTPClient()
        self.assertFalse(http_client.closed)
        http_client.close()
        self.assertTrue(http_client.closed)

        http_client = AsyncHTTPClient()
        self.assertFalse(http_client.closed)
        # Close the loop and wait for a callback to run.
        io_loop.add_callback(io_loop.stop)
        io_loop.stop()
        self.assertTrue(http_client.closed)
        http_client.close()

# Generated at 2022-06-24 08:34:21.228529
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado
    import tornado.testing
    import time
    import unittest
    
    class AsyncHTTPClient_class(tornado.httpclient.AsyncHTTPClient):
        def fetch_impl(self, request, callback):
            assert isinstance(request, tornado.httpclient.HTTPRequest)
            assert callable(callback)
            # test_AsyncHTTPClient.py:32: AssertionError: expected True, got False
            # tornado.testing.gen_test(test_AsyncHTTPClient_fetch_impl)
            # test_AsyncHTTPClient.py:32: AssertionError: expected True, got False
            assert tornado.httpclient.HTTPClient() != None
            assert tornado.httpclient.HTTPClient() != None
            
            # test_AsyncHTTPClient.py:33: AssertionError: expected True, got False
           

# Generated at 2022-06-24 08:34:29.483318
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    url = "https://www.magsor.com"
    request = HTTPRequest(url)
    assert isinstance(request, HTTPRequest)

    headers = httputil.HTTPHeaders()
    headers['content-type'] = 'application/json'
    buffer = BytesIO()

    code = 200
    response = HTTPResponse(request, code, headers=headers, buffer=buffer)
    # assert isinstance(response, HTTPResponse)

# Generated at 2022-06-24 08:34:31.289284
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    assert HTTPRequest("http://www.google.com").url == "http://www.google.com"



# Generated at 2022-06-24 08:34:38.187278
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    if __name__ == '__main__':
        import logging
        logging.basicConfig()
        asyncio.get_event_loop().run_until_complete(f())


# Generated at 2022-06-24 08:34:40.019406
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass



# Generated at 2022-06-24 08:34:41.316221
# Unit test for function main
def test_main():
    HTTPRequest('http://www.google.com')

# Generated at 2022-06-24 08:34:45.766109
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    class test_Args:
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
    cls = HTTPClient()
    cls.close()

# Generated at 2022-06-24 08:34:51.204857
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest(url="http://www.google.com", method="GET")
    defaults = dict(connect_timeout=1000, request_timeout=2000)
    proxy = _RequestProxy(request, defaults)
    assert proxy.request.url == "http://www.google.com"
    assert proxy.connect_timeout == 1000
    assert proxy.request_timeout == 2000

# Generated at 2022-06-24 08:34:59.107629
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Test for rethrow method of class HTTPResponse
    print("Start to test rethrow method of class HTTPResponse")
    import io
    import tornado.httpserver
    import tornado.ioloop
    from tornado.options import define, options, parse_command_line
    from tornado.web import RequestHandler, Application

    define("port", default=8888, help="run on the given port", type=int)


# Generated at 2022-06-24 08:35:00.187037
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    AsyncHTTPClient.initialize()



# Generated at 2022-06-24 08:35:13.303131
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # Can't use unittest.skipIf() here since it's executed at import
    # time.
    if not hasattr(AsyncHTTPClient, "_impl"):
        return

    class MyAsyncHTTPClient(AsyncHTTPClient):
        pass

    class MyHTTPRequest(HTTPRequest):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super(MyHTTPRequest, self).__init__(*args, **kwargs)
            self.modified = True

    AsyncHTTPClient.configure(MyAsyncHTTPClient, defaults=dict(proxy_host="localhost"))
    client = AsyncHTTPClient()
    assert isinstance(client, MyAsyncHTTPClient)
    assert client.defaults["proxy_host"] == "localhost"
    client2 = AsyncHTTPClient()
    assert client is client2
   

# Generated at 2022-06-24 08:35:25.294768
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from .HTTPRequest import HTTPRequest
    from .HTTPResponse import HTTPResponse
    from .HTTPResponse import HTTPResponse as my_HTTPResponse
    from .HTTPError import HTTPError
    import json
    import pytest
    import random
    import string
    import io
    import struct
    import sys
    import requests
    import time
    import socket
    
    
    
    
    
    
    
    
    
    
    
    # Test 1
    body = b"1234"
    my_body = "1234"
    response_code = 200
    #print (response_code)
    client = HTTPClient()
    content_type = "application/json"
    arg_url = "https://127.0.0.1:8000"

# Generated at 2022-06-24 08:35:28.542516
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    hc = HTTPClient()
    print(hc)
    print(hc.fetch('http://www.baidu.com'))
    hc.close()


if __name__ == '__main__':
    test_HTTPClient()

# Generated at 2022-06-24 08:35:35.626675
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import inspect, asyncio, os, sys
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0,parentdir) 
    from vdom.helpers import var
    from vdom.helpers import eval
    from vdom.helpers import css
    from vdom.helpers import get_env
    from tornado.web import HTTPError
    from tornado_py3.httpclient import AsyncHTTPClient
    url = "http://localhost:8080/test"

# Generated at 2022-06-24 08:35:37.775915
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    client = HTTPClient(async_client_class=AsyncHTTPClient)
    assert isinstance(client,HTTPClient)
    assert client._closed == False
    client.close()
    assert client._closed == True
test_HTTPClient_close()


# Generated at 2022-06-24 08:35:40.482447
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    client.initialize()
    assert True


# Generated at 2022-06-24 08:35:44.325217
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    with pytest.raises(HTTPClientError) as cm:
        raise HTTPClientError(404, 'Not Found')
    e = cm.value
    assert e.code == 404
    assert str(e) == 'HTTP 404: Not Found'


# Generated at 2022-06-24 08:35:51.713286
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    import tornado.testing
    from tornado.locks import Event
    from tornado.netutil import bind_unused_port
    from tornado.test.util import unittest

    class TestHTTPClient(unittest.TestCase):
        def test_async_client(self):
            with self.assertRaises(RuntimeError):
                client = HTTPClient(async_client_class=AsyncHTTPClient)
            # For coverage.
            HTTPClient().close()

            # This is in its own thread to avoid the current event loop
            # being cleared by the TestCase.
            event = Event()

            def async_client():
                asyncio_loop = IOLoop()
                async def make_client():
                    await gen.sleep(0)
                    # We have to make an async client (which will spin up
                    # an ioloop) so that

# Generated at 2022-06-24 08:36:01.046058
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    io_loop = IOLoop(make_current=False)
    # test when force_instance is False
    instance = AsyncHTTPClient()
    assert instance is AsyncHTTPClient()
    assert instance is AsyncHTTPClient()
    assert instance.__class__ is AsyncHTTPClient.configurable_default()
    assert instance.io_loop is io_loop
    assert instance._closed is False
    # test when force_instance is True
    instance = AsyncHTTPClient(force_instance=True)
    assert instance


# Generated at 2022-06-24 08:36:06.275513
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    d = dict(
        request=None,
        code=404,
        headers=None,
        buffer=None,
        effective_url=None,
        error=None,
        request_time=None,
        time_info=None,
        reason=None
    )
    r = HTTPResponse(**d)
    assert r.code == 404
    assert r.reason == "Unknown"

# Generated at 2022-06-24 08:36:07.249948
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    print(AsyncHTTPClient)


# Generated at 2022-06-24 08:36:11.598693
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    request_obj = HTTPRequest('url')
    assert request_obj.url == 'url'
    assert request_obj.method == 'GET'
    assert request_obj.connect_timeout == 20
    assert request_obj.request_timeout == 20
    assert request_obj.follow_redirects == True
    assert request_obj.max_redirects == 5


# Generated at 2022-06-24 08:36:12.887881
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("/")
    proxy = _RequestProxy(request, None)
    assert request.follow_redirects is proxy.follow_redirects



# Generated at 2022-06-24 08:36:19.231041
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        assert response.body
    except httpclient.HTTPError as e:
        print("Error: " + str(e))
    except Exception as e:
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-24 08:36:24.350408
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest

    class Test(unittest.TestCase):
        def test_AsyncHTTPClient_fetch_impl(self):
            self.assertRaises(NotImplementedError, AsyncHTTPClient().fetch_impl)


# Generated at 2022-06-24 08:36:29.886594
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    result = HTTPResponse(HTTPRequest(url='http://example.com'), 200, )
    assert repr(result) == "HTTPResponse(code=200,error=None,headers={},request=http://example.com,request_time=None,time_info={},effective_url=http://example.com,reason='OK',start_time=None)"

if __name__ == "__main__":
    import doctest
    import sys
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 08:36:36.122230
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = mock.MagicMock()
    request.url = 'test url'
    headers = mock.MagicMock()
    buffer = mock.MagicMock()
    error = mock.MagicMock()
    time_info = mock.MagicMock()
    response = HTTPResponse(request, 404, headers, buffer, 'test url', error, 0.5, time_info)

    response.rethrow()

    self.assertTrue(error.reraise.called)


# Generated at 2022-06-24 08:36:47.276808
# Unit test for method __repr__ of class HTTPClientError

# Generated at 2022-06-24 08:36:48.164665
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass


# Generated at 2022-06-24 08:36:55.329050
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    method_name = 'HTTPClient.close'
    http_client = HTTPClient()
    assert http_client._closed == True, '%s:%s assert failed.' % (method_name, '001')
    http_client.close()
    assert http_client._closed == True, '%s:%s assert failed.' % (method_name, '002')
test_HTTPClient_close()


# Generated at 2022-06-24 08:37:08.098351
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    headers = {'Content-Length': '10'}
    request = HTTPRequest('http://localhost:8080/', headers=headers)
    response = HTTPResponse(request, 200, headers, BytesIO(b'1234678910'))
    response.rethrow()
    request = HTTPRequest('http://localhost:8080/', headers=headers)
    response = HTTPResponse(request, 401, headers, BytesIO(b'1234678910'))
    try:
        response.rethrow()
        assert False
    except HTTPError as e:
        assert str(e) == '401: Unauthorized'
    request = HTTPRequest('http://localhost:8080/', headers=headers)

# Generated at 2022-06-24 08:37:10.015548
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    h = HTTPClient()
    response = h.fetch("http://www.google.com/")
    print("Response body => " + response.body)

test_HTTPClient()

# Generated at 2022-06-24 08:37:12.469008
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    """
    constructor of class HTTPRequest
    """

    request = HTTPRequest(url = "http://127.0.0.1:8888")
    assert request

# Generated at 2022-06-24 08:37:22.283457
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    
    class UnitTestAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            # Avoid the magic of `AsyncHTTPClient` constructor so we
            # can run tests without an IOLoop.
            super(UnitTestAsyncHTTPClient, self).initialize(**kwargs)
            self.requests: Dict[
                str,
                Callable[
                    [
                        "HTTPRequest",
                        Callable[["HTTPResponse"], None],
                    ],
                    None,
                ],
            ] = {}
    

# Generated at 2022-06-24 08:37:30.146455
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    s = HTTPResponse(request=1, code=2, headers=3, buffer=4, effective_url=5, error=6, request_time=7, time_info=8, reason=9, start_time=10)
    assert repr(s) == 'HTTPResponse(code=2,effective_url=5,error=6,headers=3,request=1,request_time=7,reason=9,start_time=10,time_info=8)'



# Generated at 2022-06-24 08:37:31.185763
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    HTTPClientError(599)


# Generated at 2022-06-24 08:37:33.652052
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    a = HTTPClientError(1, "message", HTTPResponse(HTTPRequest("GET", "http://example.com"), 200))
    b = "HTTP 1: message"
    assert a.__repr__() == b
test_HTTPClientError___repr__()

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:37:39.464298
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest('url')
    request_proxy = _RequestProxy(request, {})
    assert request.url == request_proxy.url
    request_proxy = _RequestProxy(request, {'url': 'url_default', 'method': 'POST'})
    assert request_proxy.url == request.url
    assert request_proxy.method == 'POST'


# Generated at 2022-06-24 08:37:46.107027
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    code = gen_integer_value()
    message = gen_string_value()
    response = gen_HTTPResponse_with_request_http_headers_body_error_time_info_start_time()
    http_error = HTTPClientError(code=code, message=message, response=response)
    assert http_error.__repr__() == http_error.__str__()


# Generated at 2022-06-24 08:37:53.316223
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # testing different situations
    # test 1: there is an error while executing this request
    # test 2: there is no error while executing this request
    # test 3: request is a string URL
    # test 4: this request raise_error is True

    # test 1:
    # http client is closed
    http = HTTPClient()
    http.close()
    request = None
    try:
        response = http.fetch(request)
        assert False
    except Exception as e:
        assert True

    # request is None
    http = HTTPClient()
    request = None
    try:
        response = http.fetch(request)
        assert False
    except Exception as e:
        assert True

    # test 2:
    http = HTTPClient()
    request = "http://www.google.com/"
    response = http.f

# Generated at 2022-06-24 08:38:05.529549
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest('xxx')
    code = 200
    http_headers = {'content-type': 'text/html'}
    buffer = BytesIO(b"hello")
    effective_url = "http://example.com"
    error = HTTPError(code, message="reason")
    request_time = 0.3
    time_info = {'name_lookup': 0.1, 'connect': 0.2, 'queue': 0.01}
    reason = "ok"
    start_time = time.time()


# Generated at 2022-06-24 08:38:09.249648
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    assert '<class \'tornado.httpclient.HTTPResponse\'>' == repr(HTTPResponse(None, None))


# Generated at 2022-06-24 08:38:13.223016
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import AsyncHTTPClient
    
    url = "http://www.google.com"
    client = AsyncHTTPClient()
    http_req = client.fetch(url)

test_AsyncHTTPClient_fetch()

# Generated at 2022-06-24 08:38:19.509831
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    #this test is not complete, just a demo to how you can use the python unittest module

    client = AsyncHTTPClient()
    # call the method you want to test
    client.initialize()
    # check if your result is as expected
    assert client.io_loop == IOLoop.current()
    assert client.defaults == dict(HTTPRequest._DEFAULTS)
    assert client._closed == False


# Generated at 2022-06-24 08:38:30.265102
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    a = HTTPResponse(
        request=HTTPRequest(url="a"),
        code=12,
        buffer=BytesIO(),
        reason="xxx",
        start_time=time.time(),
    )
    assert repr(a) == "HTTPResponse(buffer=<_io.BytesIO object at 0x7f7552b5f308>,code=12,error=None,request=<__main__.HTTPRequest object at 0x7f7552b5f240>,request_time=None,start_time=1570789853.9043651,time_info={},url='a')"
##



# Generated at 2022-06-24 08:38:40.540816
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import pytest
    from tornado.locks import Lock
    from tornado.testing import AsyncTestCase

    with pytest.raises(RuntimeError, match=r'.*multiple IOLoops.*'):
        AsyncHTTPClient()
    io_loop = IOLoop()
    io_loop.make_current()
    http_client = AsyncHTTPClient()
    http_client2 = AsyncHTTPClient()
    assert http_client is http_client2
    assert http_client.io_loop is http_client2.io_loop is io_loop
    assert id(http_client) == id(http_client2)
    http_client2.close()
    http_client3 = AsyncHTTPClient()
    assert http_client is http_client3

# Generated at 2022-06-24 08:38:41.160181
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-24 08:38:46.432253
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('https://jsonplaceholder.typicode.com/todos/1')
    response = HTTPResponse(request, '200', None, None, None, None, None, None)
    response.rethrow()

# Generated at 2022-06-24 08:38:49.950116
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    client.initialize(defaults=dict(user_agent="MyUserAgent"))
    assert client.defaults == AsyncHTTPClient._DEFAULTS


# Generated at 2022-06-24 08:38:53.556154
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {'method':'GET'}
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.method == 'GET'

# Generated at 2022-06-24 08:38:55.430973
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient(force_instance=True)



# Generated at 2022-06-24 08:39:07.201324
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    request = HTTPRequest('http://www.baidu.com', method='GET', headers={},
                          body='dummy')

    assert isinstance(request, HTTPRequest)
    assert request.headers == httputil.HTTPHeaders()
    assert request.body == b'dummy'
    assert request.proxy_host is None
    assert request.proxy_port is None
    assert request.proxy_username is None
    assert request.proxy_password == ''
    assert request.proxy_auth_mode is None
    assert request.url == 'http://www.baidu.com'
    assert request.method == 'GET'
    assert request.auth_username is None
    assert request.auth_password is None
    assert request.auth_mode is None
    assert request.connect_timeout is None
    assert request.request_timeout is None


# Generated at 2022-06-24 08:39:07.857999
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    pass


# Generated at 2022-06-24 08:39:15.032727
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    import tornado
    import tornado.httputil
    import tornado.ioloop
    import tornado.testing

    from tornado import gen
    from tornado import ioloop
    from tornado.httpclient import AsyncHTTPClient

    class DummyAsyncHTTPClient(AsyncHTTPClient):
        _request_counter = 0

        def initialize(self, io_loop, defaults=None):
            super(DummyAsyncHTTPClient, self).initialize(io_loop, defaults)
            self.io_loop = io_loop
            self.defaults = defaults or {}

        def fetch_impl(self, request, callback):
            self._request_counter += 1
            self.io_loop.add_callback(callback, None)

    class AsyncHTTPClientTest(tornado.testing.AsyncTestCase):
        def tearDown(self):
            self.io_loop

# Generated at 2022-06-24 08:39:15.763994
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    exc = HTTPClientError(500)
    assert exc.message == 'Internal Server Error'

# Generated at 2022-06-24 08:39:21.094196
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import pytest
    from tornado.httpclient import AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.concurrent import return_future
    from tornado.web import RequestHandler, Application
    from tornado.ioloop import IOLoop

    def async_fetch(url, callback=None):
        client = AsyncHTTPClient()
        if callback is None:
            future = client.fetch(url)
            return future
        else:
            client.fetch(url, callback=callback)

    def sync_fetch(url):
        client = AsyncHTTPClient()
        return client.fetch(url)

    @return_future
    def async_fetch_no_callback(url, future):
        client = AsyncHTTPClient()

# Generated at 2022-06-24 08:39:31.904259
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    assert AsyncHTTPClient.configurable_default() is SimpleAsyncHTTPClient
    AsyncHTTPClient.configure(
        "tornado.test.async_test.test_httpclient.TestCls",
        foo="bar",
    )
    assert TestCls.foo == "bar"
    mock_ioloop = DummyIOLoop()
    AsyncHTTPClient()
    assert TestCls.closed
    assert TestCls.io_loop is mock_ioloop
    TestCls.closed = False
    TestCls.io_loop = None
    a = AsyncHTTPClient(force_instance=True)
    assert a.foo == "bar"
    assert not TestCls.closed
    assert TestCls.io_loop is None
    AsyncHTTPClient()
    assert TestCls.closed
    a.close

# Generated at 2022-06-24 08:39:33.471609
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    inst = HTTPClientError(404)
    assert inst.__repr__() == 'HTTP 404: Not Found'


HTTPError = HTTPClientError

# Generated at 2022-06-24 08:39:40.706959
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(500)
    except HTTPClientError as e:
        assert e.code == 500
        assert e.response is None
        assert 'HTTP' in str(e)
    try:
        raise HTTPClientError(500, 'message', 'response')
    except HTTPClientError as e:
        assert e.code == 500
        assert e.message == 'message'
        assert e.response == 'response'
        assert 'HTTP' in str(e)

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:39:52.097264
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase

    class DummyHandler(object):
        def initialize(self, request: "HTTPRequest") -> None:
            self.request = request

        def get(self) -> None:
            self.write(b"hello")

    class TestCase(AsyncHTTPTestCase):
        def get_app(self) -> Any:
            return Application([("/", DummyHandler)])

        @gen_test
        async def test_AsyncHTTPClient_constructor(self) -> None:
            http_client = AsyncHTTPClient()
            self.assertTrue(isinstance(http_client, SimpleAsyncHTTPClient))
            self.assertEqual(http_client._instance_cache, AsyncHTTPClient._async_clients())

            http_client

# Generated at 2022-06-24 08:39:56.980399
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    response = HTTPResponse(None,200,HTTPResponse)
    try:
        raise HTTPClientError(code=302,message="Redirect error",response=response)
    except HTTPError as error:
        print(error)
    pass
test_HTTPClientError()

HTTPError = HTTPClientError



# Generated at 2022-06-24 08:39:59.616491
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request__object = HTTPRequest("https://www.baidu.com", "GET", )
    response = HTTPResponse(request__object, 200, headers=None)
    response.rethrow()
    pass



# Generated at 2022-06-24 08:40:02.894420
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    url = 'https://www.google.com'
    assert isinstance(http_client.fetch(url), HTTPResponse)
    http_client.close()
test_HTTPClient_fetch()

#####################################################################
# The following classes and functions are copied from httputil.py.
# The function definitions have been modified to work with callbacks.
########



# Generated at 2022-06-24 08:40:08.883240
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    class A(object):
        def __init__(self, **kwargs: Any) -> None:
            pass
        def fetch(self, request: Union["HTTPRequest", str], **kwargs: Any) -> "HTTPResponse":
            return ""
        def close(self) -> None:
            pass
    http = HTTPClient(async_client_class = A)




# Generated at 2022-06-24 08:40:14.521543
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient(defaults=dict(user_agent="MyUserAgent"))
    assert client.defaults == {'follow_redirects': True, 'max_redirects': 5, 'user_agent': 'MyUserAgent'}
    assert client.io_loop == IOLoop.current()
    assert client._closed == False

# Generated at 2022-06-24 08:40:22.429889
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-24 08:40:33.231225
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    """Unit test for method __repr__ of class HTTPResponse"""    
    # Case 1: No failures.
    request = HTTPRequest("https://www.example.com", method="GET")
    code = 200
    headers = httputil.HTTPHeaders()
    effective_url = "https://www.example.com"
    error = None
    request_time = 1
    time_info = {'namelookup': 2, 'connect': 3, 'pretransfer': 4, 'starttransfer': 5, 'total': 6}
    reason = "OK"
    start_time = time.time()
    http_response = HTTPResponse(request, code, headers, None, effective_url, error, request_time, time_info, reason, start_time)