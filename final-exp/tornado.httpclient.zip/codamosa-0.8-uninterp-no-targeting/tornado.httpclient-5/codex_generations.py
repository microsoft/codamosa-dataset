

# Generated at 2022-06-22 03:40:46.222770
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    url = 'google.com'
    output = HTTPClient().fetch(url)
    log.info(output.status_code)
    log.info(output)
    assert(output.status_code == 200)



# Generated at 2022-06-22 03:40:47.302512
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    #implicitly invoked by
    #test_RequestProxy___repr__()
    assert True

#_RequestStartLine

# Generated at 2022-06-22 03:40:54.923249
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    req = HTTPRequest("http://google.com/")
    httpr = HTTPResponse(req, 200, headers=httputil.HTTPHeaders(), buffer=BytesIO())
    assert httpr.request == req
    assert httpr.code == 200
    assert httpr.headers == httputil.HTTPHeaders()
    assert httpr.buffer == BytesIO()
    assert httpr.effective_url == req.url
    assert httpr.error is None
    assert httpr.start_time is None
    assert httpr.request_time is None
    assert httpr.time_info == {}
    assert httpr.body == b""

# Generated at 2022-06-22 03:40:59.578263
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # _RequestProxy.__getattr__
    req = HTTPRequest('http://www.google.com', method='GET')
    query = _RequestProxy(req, {'method':'POST'})
    try:
        assert query.method == 'GET'
    finally:
        del query



# Generated at 2022-06-22 03:41:03.287695
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-22 03:41:07.876920
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    req = HTTPRequest(
        url = "http://www.tencent.com",
        headers = {"Content-Type": "application/json"},
        proxy_host = "localhost",
        proxy_port = 3128,
    )
    assert req.url == "http://www.tencent.com"
    assert req.proxy_host == "localhost"
    assert req.proxy_port == 3128
    assert req.headers == {"Content-Type": "application/json"}

    # None argument
    req.body = None
    assert req.body is None
    req_proxy1 = _RequestProxy(req, "default_url")
    assert req_proxy1.proxy_host == "localhost"
    assert req_proxy1.proxy_port == 3128
    assert req_proxy1.url == "http://www.tencent.com"

# Generated at 2022-06-22 03:41:12.622087
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url = 'http://www.baidu.com')
    code = '404'
    headers = httputil.HTTPHeaders('404')
    response = HTTPResponse(request, code, headers)
    print(response)
    # assert_raises(HTTPError, response.rethrow())


# Generated at 2022-06-22 03:41:24.231587
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from .httpclient import HTTPRequest
    from tornado.httputil import parse_response_start_line
    import tornado.testing
    import tornado.web
    import unittest

    @tornado.gen.coroutine
    def _test_fetch_impl(fetch_impl):
        client = AsyncHTTPClient()
        requests = [HTTPRequest('http://example.com/a', method='GET',
                                body='a'),
                    HTTPRequest('http://example.com/b', method='POST',
                                body='b')]
        responses = [HTTPResponse(request, 200, buffer=BytesIO(b'abc'))
                     for request in requests]

        class RequestHandler(tornado.web.RequestHandler):
            def initialize(self, responses):
                self.responses = responses


# Generated at 2022-06-22 03:41:25.080132
# Unit test for function main
def test_main():
    try:
        main()
    except BaseException as e:
        print(str(e))

# Generated at 2022-06-22 03:41:29.183079
# Unit test for function main
def test_main():
    from tornado.testing import gen_test

    @gen_test
    def test_main_async(self):
        from tornado.options import define, options, parse_command_line
        # self.stop is a coroutine which allows you to stop the main loop
        define("print_headers", type=bool, default=False)
        define("print_body", type=bool, default=True)
        define("follow_redirects", type=bool, default=True)
        define("validate_cert", type=bool, default=True)
        define("proxy_host", type=str)
        define("proxy_port", type=int)
        args = parse_command_line()
        client = HTTPClient()

# Generated at 2022-06-22 03:41:56.183636
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    r = HTTPResponse(None, 200)
    assert repr(r) == "HTTPResponse(code=200,reason='OK',request=None)"


# Generated at 2022-06-22 03:42:04.106535
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import doctest
    from tornado.httputil import HTTPHeaders

    from tornado import gen
    from tornado import ioloop

    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import AsyncHTTPClient

    @gen.coroutine
    def f():
        http_client = AsyncHTTPClient()
        try:
            response = yield http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    ioloop.IOLoop.instance().run_sync(f)



# Generated at 2022-06-22 03:42:12.433938
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    client = httpclient.HTTPClient()
    try:
        response = client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    client.close()


# Generated at 2022-06-22 03:42:26.103557
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.httpclient import HTTPRequest, HTTPResponse, HTTPError
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test, ExpectLog
    from tornado import web
    import asyncio
    import tornado
    import typing
    import tornado.httputil
    import tornado.concurrent

    if tornado.version_info < (5,0):
        raise SkipTest("AsyncHTTPClient requires Tornado 5.0 or above")
    AsyncIOMainLoop().install()

    class HelloWorldHandler(web.RequestHandler):
        def get(self):
            self.write({"hello": "world"})

    class MainHandler(web.RequestHandler):
        @gen.coroutine
        def get(self):
            http_client = AsyncHTTPClient()


# Generated at 2022-06-22 03:42:37.224447
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.httpclient import HTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClientError
    from tornado.httpclient import HTTPClientConnectionClosed
    from tornado.httpclient import HTTPCookie
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import parse_cookie_header
    from tornado.ioloop import IOLoop
    from tornado.stack_context import ExceptionStackContext, NullContext
    from tornado.testing import bind_unused_port
    from tornado.testing import AsyncHTTPTestCase
    import os
    import select
    import socket
    import threading
    import tornado
    import unittest
    import warnings


# Generated at 2022-06-22 03:42:41.136571
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    client = AsyncHTTPClient.configured_class()
    assert isinstance(client, AsyncHTTPClient)
    assert client._instance_cache is None



# Generated at 2022-06-22 03:42:53.279703
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    # preparation
    request = HTTPRequest("http://localhost:8080/")
    code = 123
    reason = "some reason"
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "http://www.baidu.com"
    error = RuntimeError("some error")
    error_message = "some error message"
    request_time = 2
    time_info = {
        "queue": 1,
        "namelookup": 1,
        "connect": 1,
        "appconnect": 1,
        "pretransfer": 1,
        "redirect": 1,
        "starttransfer": 1,
        "total": 1
    }
    start_time = time.time()

    # run test

# Generated at 2022-06-22 03:43:07.567523
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.ioloop import IOLoop
    import unittest
    from .util import unittest

    class DummyAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(
            self,
            request: "HTTPRequest",
            callback: Callable[["HTTPResponse"], None],
        ) -> None:
            pass

    class SimpleAsyncHTTPClientTest(unittest.TestCase):
        def setUp(self) -> None:
            self._client = DummyAsyncHTTPClient()
            self._client.initialize()
            self._response = None  # type: Optional[HTTPResponse]
            self._exception = None  # type: Optional[Exception]
            self._called = False

        def tearDown(self) -> None:
            self._client.close()


# Generated at 2022-06-22 03:43:08.685702
# Unit test for function main
def test_main():
    with mock.patch('tornado.httpclient.main') as mock_main:
        mock_main.return_value = None
        main()
        assert mock_main.called

# Generated at 2022-06-22 03:43:22.626917
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # self = <tornado.httpclient.AsyncHTTPClient object at 0x7fca6fdb7ed0>
    self = AsyncHTTPClient.configure()
    # force_instance = False
    force_instance = False
    # kwargs = {}
    kwargs = {}
    # io_loop = <_UnixSelectorEventLoop running=False closed=False debug=False>
    io_loop = IOLoop.current()
    # cached_val = <tornado.httpclient.AsyncHTTPClient object at 0x7fca6fdb7ed0>
    cached_val = AsyncHTTPClient.configure()
    # instance = <tornado.httpclient.AsyncHTTPClient object at 0x7fca6fdb7ed0>

# Generated at 2022-06-22 03:44:26.028415
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import IOStream
    from tornado.test.util import unittest

    def fake_close():
        stream.closed = True

    def raise_error(msg, *args):
        raise Exception(msg % args)

    stream = IOStream(0, IOStream.READ, raise_error)
    stream.closed = False
    stream.close = fake_close
    stream.read_until_close = lambda callback, streaming_callback: callback()
    request = HTTPRequest("/", method="GET", headers=HTTPHeaders())
    response = HTTPResponse(request, 200, buffer=BytesIO(), request_time=0,
                            headers=HTTPHeaders(), effective_url="http://localhost/")
    response.request

# Generated at 2022-06-22 03:44:38.591578
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():

    # Test passed
    # TODO: This test will go into AsyncHTTPClientTestCase
    from tornado.escape import native_str
    from tornado.httpclient import HTTPResponse, HTTPRequest, AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase
    import threading
    import time
    
    class MyAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, io_loop: IOLoop, max_clients: int,
                       defaults: Optional[Any]) -> None:
            super().initialize(io_loop=io_loop, max_clients=max_clients,
                               defaults=defaults)
            self.num_requests = 0
            self.num_timeouts = 0

# Generated at 2022-06-22 03:44:43.186290
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    raise NotImplementedError
test__RequestProxy___getattr__()


# This is a dummy HTTPResponse class used by _RequestProxy when the
# client has not actually been fetched yet.  We can't create the
# response until we've got all the headers, but the caller may want to
# examine the response before the request is complete.

# Generated at 2022-06-22 03:44:55.480143
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    try:
        from unittest import mock
    except ImportError:
        import mock

    from tornado.ioloop import IOLoop
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado import testing

    class DummyAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, *args, **kwargs):
            super(DummyAsyncHTTPClient, self).__init__(*args, **kwargs)
            self.called = True

    @testing.gen_test
    def test_singleton():
        # super(AsyncHTTPClient, cls).__new__(cls, **kwargs)
        with mock.patch.object(AsyncHTTPClient, 'configurable_base') as configurable_base:
            configurable_base.return_value = SimpleAsyncHTTPClient
            SimpleAsyncHTTPClient.__new__

# Generated at 2022-06-22 03:44:57.909540
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    #self = AsyncHTTPClient()
    #self._closed = True
    AsyncHTTPClient().close()
    print(None)


# Generated at 2022-06-22 03:45:01.429814
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
	# TODO: Implement test
	pass


# Generated at 2022-06-22 03:45:10.505681
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    try:
        AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")

        loop = IOLoop.instance()
        client = AsyncHTTPClient()

        def handle_request(response: "HTTPResponse") -> None:
            print(response.headers)
            print(response.body)
            client.close()
            loop.stop()

        request = HTTPRequest(url='https://example.com', validate_cert=False)
        client.fetch(request, handle_request)
        loop.start()

    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_AsyncHTTPClient_fetch()

# Generated at 2022-06-22 03:45:13.806013
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async_client = AsyncHTTPClient()
    async_client.close()

# Generated at 2022-06-22 03:45:21.265699
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    # Test that HTTPClientError could be called when there is no response
    try:
        raise HTTPClientError(400)
    except HTTPClientError as e:
        assert e.code == 400
        assert e.message == "Bad Request"

    # Test that HTTPClientError could be called when response is not None
    response = HTTPResponse(HTTPRequest(url='http://localhost:8080/'), 400, {})
    try:
        raise HTTPClientError(400, response=response)
    except HTTPClientError as e:
        assert e.code == 400
        assert e.message == "Bad Request"
        assert e.response == response

    # Test that HTTPClientError could be called when response is None but message is not None

# Generated at 2022-06-22 03:45:23.889403
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    http_client.close()



# Generated at 2022-06-22 03:48:57.278522
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    class FakeRequest:
        foo = None

    fake_request = FakeRequest()
    defaults = {"foo": 666}
    proxy = _RequestProxy(fake_request, defaults)
    assert proxy.foo == 666

    fake_request.foo = 123
    assert fake_request.foo == 123
    assert proxy.foo == 123



# Generated at 2022-06-22 03:49:09.619879
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    req = HTTPRequest(url="http://www.google.com", validate_cert=False)
    resp = HTTPResponse(
        request=req,
        code=200,
        headers=None,
        buffer=BytesIO(),
        effective_url="http://www.google.com",
        error=None,
        request_time=1,
        time_info={"queue": 0.2},
        reason="OK",
        start_time=0.5,
    )
    print(resp)  # HTTPResponse(body=b'', code=200, error=None, headers={}, request=HTTPRequest(url='http://www.google.com'), request_time=1, time_info={'queue': 0.2}, reason='OK', start_time=0.5, effective_url='http://www.

# Generated at 2022-06-22 03:49:11.308027
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    http_client = AsyncHTTPClient()
    http_client.close()



# Generated at 2022-06-22 03:49:20.419943
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = 'http://127.0.0.1:8080'
    method = 'GET'
    headers = {}
    body = 'body'
    auth_username = 'username'
    auth_password = 'password'
    auth_mode = 'basic'
    connect_timeout = 1.0
    request_timeout = 1.0
    if_modified_since = 1.0
    follow_redirects = True
    max_redirects = 1
    user_agent = 'useragent'
    use_gzip = True
    network_interface = 'eth0'
    streaming_callback = lambda x: 1
    header_callback = lambda x: 1
    prepare_curl_callback = lambda x: 1
    proxy_host = '127.0.0.1'
    proxy_port = 8080
    proxy_username

# Generated at 2022-06-22 03:49:32.144129
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest
    import tornado
    import tornado.httpclient
    AsyncHTTPClient = tornado.httpclient.AsyncHTTPClient
    
    http_client = AsyncHTTPClient(force_instance=True, defaults=dict(user_agent="MyUserAgent"))
    assert http_client.defaults == dict(user_agent="MyUserAgent")
    assert http_client._instance_cache is None
    assert http_client.io_loop is not None
    assert not http_client._closed
    http_client.close()
    assert http_client._closed
    assert http_client._instance_cache is None
    assert http_client.io_loop is not None
    
    http_client = AsyncHTTPClient.configure(None, defaults=dict(user_agent="MyUserAgent"))
    assert http_client._instance_cache is not None

# Generated at 2022-06-22 03:49:32.991980
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-22 03:49:39.543163
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    e = HTTPClientError(code=404, message='message')
    assert e.code == 404
    assert e.message == 'message'


HTTPError = HTTPClientError


# Generated at 2022-06-22 03:49:44.090805
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    """
    @param request:
    @type request:
    @param callback:
    @type callback:
    @return:
    @rtype:
    """
    print("TODO: AsyncHTTPClient.fetch_impl")

# Generated at 2022-06-22 03:49:52.364845
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Test _RequestProxy.__getattr__ method
    request = HTTPRequest('GET', 'www.baidu.com')
    defaults = {'user_agent': 'IE 8.0'}
    proxy = _RequestProxy(request, defaults)
    assert proxy.request == request
    assert proxy.defaults == defaults
    assert proxy.method == 'GET'
    assert proxy.user_agent == 'IE 8.0'
    assert proxy.connect_timeout == 20.0
    request = HTTPRequest('GET', 'www.baidu.com', connect_timeout=100.0)
    proxy = _RequestProxy(request, defaults)
    assert proxy.method == 'GET'
    assert proxy.user_agent == 'IE 8.0'
    assert proxy.connect_timeout == 100.0


# Generated at 2022-06-22 03:49:58.553677
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    # This unit test is designed to test the method __del__ of class HTTPClient
    from tornado.httpclient import HTTPClient
    # 1. We create a HTTPClient object with default values
    http_client = HTTPClient()

    # 2. We close the HTTPClient
    http_client.close()

    # 3. We check that __del__ works correctly
    assert isinstance(http_client, object)