

# Generated at 2022-06-22 03:40:33.014230
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    httpclient = AsyncHTTPClient()
    httpclient.initialize()

# Generated at 2022-06-22 03:40:39.636382
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()




# Generated at 2022-06-22 03:40:40.248044
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    pass

# Generated at 2022-06-22 03:40:49.707272
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    HCE = HTTPClientError
    hce = HCE(123, response='a')
    assert hce.code == 123
    assert hce.message == 'Unknown'
    assert hce.response == 'a'
    hce = HCE(123, 'abc', response='a')
    assert hce.code == 123
    assert hce.message == 'abc'
    assert hce.response == 'a'
    hce = HCE(123)
    assert hce.code == 123
    assert hce.message == 'Unknown'
    assert hce.response is None
    hce = HCE(123, 'abc')
    assert hce.code == 123
    assert hce.message == 'abc'
    assert hce.response is None
    hce = HCE(123, response='a')
    assert h

# Generated at 2022-06-22 03:40:58.708506
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Tests function fetch_impl of class AsyncHTTPClient
    # async def test_AsyncHTTPClient_fetch_impl(self):
    for client_class in self.async_http_clients:
        client = client_class()
        response = mock.Mock()
        callback = mock.Mock()
        request = HTTPRequest("/")
        client.fetch_impl(request, callback)
        callback.assert_called_once_with(response)
        client.close()

    # Not support callable impl
    # client = self.get_async_client()
    # if isinstance(client, tornado.httpclient.AsyncHTTPClient):
    #     # CurlAsyncHTTPClient can't take a callable,
    #     # so skip this part of the test
    #     continue
    # called = False
    #

# Generated at 2022-06-22 03:41:01.135084
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    assert(hasattr(_RequestProxy(HTTPRequest(
        'https://www.google.com/search?q=python'), None), 'url') == True)
test__RequestProxy()


CurlError = pycurl.error  # type: Any  # this is not a class in pypy



# Generated at 2022-06-22 03:41:01.875319
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # AsyncHTTPClient.close()
    pass

# Generated at 2022-06-22 03:41:06.312671
# Unit test for function main
def test_main():
    with mock.patch('tornado.options.parse_command_line', return_value=['c']) as parse_command_line:
        with mock.patch('tornado.httpclient.HTTPClient') as http_client:
            http_client_instance = mock.Mock()
            http_client.return_value = http_client_instance
            try:
                main()
            except HTTPError:
                pass
            http_client_instance.fetch.assert_called_with('c', follow_redirects=True, validate_cert=True, proxy_host=None, proxy_port=None)
            http_client_instance.close.assert_called_once_with()
        parse_command_line.assert_called_once_with()



# Generated at 2022-06-22 03:41:15.248389
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    import unittest
    import tornado.testing

    class TestCase(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application()
        def test_rethrow(self):
            fetch_future = self.http_client.fetch(self.get_url('/'))
            fetch_future.add_done_callback(self.stop)
            response = self.wait()
            self.assertRaises(HTTPError, response.rethrow)

    if __name__ == '__main__':
        unittest.main()


# Generated at 2022-06-22 03:41:26.108114
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    assert HTTPClientError(1, message='error message').message == 'error message'
    assert HTTPClientError(1).message == 'Unknown'


if sys.version_info < (3,):
    HTTPClientError.__unicode__ = lambda self: u"HTTP %d: %s" % (
        self.code,
        self.message,
    )
else:
    HTTPClientError.__str__ = lambda self: "%s(code=%d, message=%r)" % (
        self.__class__.__name__,
        self.code,
        self.message,
    )


# Alias for backwards compatibility
HTTPError = HTTPClientError

# Generated at 2022-06-22 03:41:53.653226
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    from io import BytesIO
    from tornado import httputil
    from tornado.httpclient import HTTPError, HTTPRequest, HTTPResponse

# Generated at 2022-06-22 03:42:04.200794
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(404, 'Not Found', '...response string...')

HTTPError = HTTPClientError


# These constants have been moved from `tornado.escape` and are subject to
# removal in a future release.  They have been added here temporarily for
# compatibility.

# Generated at 2022-06-22 03:42:06.370306
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    AsyncHTTPClient()

# Generated at 2022-06-22 03:42:15.804969
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-22 03:42:20.491349
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    try:
        raise HTTPClientError(code=404, message='Test', response=None)
    except Exception as e:
        print(repr(e))

# Alias for backwards compatibility
HTTPError = HTTPClientError


# Generated at 2022-06-22 03:42:24.195429
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    # tests close method
    testClient = HTTPClient()
    testClient.close()
    assert testClient._closed == True
    assert testClient._async_client._closed == True



# Generated at 2022-06-22 03:42:28.718131
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.escape
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, gen_test, bind_unused_port
    from tornado.web import Application, RequestHandler

    class MainHandler(RequestHandler):
        def get(self):
            self.write(b"Hello world")

    class PostHandler(RequestHandler):
        def initialize(self, test):
            self.test = test

        @gen.coroutine
        def post(self):
            # Verify that we can read the value using both
            # self.get_body_argument and the full body.
            self.test.assertEqual(
                self.get_body_argument("x"), "1"
            )  # type:

# Generated at 2022-06-22 03:42:32.519258
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    http_client.close()
    try:
        http_client.fetch("http://www.google.com/")
        assert False
    except Exception as e:
        assert isinstance(e, RuntimeError)



# Generated at 2022-06-22 03:42:40.693683
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import asyncio
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com/")
            print("finished fetch; closing")
            http_client.close()
            print("response.body")
        except Exception as e:
            print("Error: %s" % e)
    asyncio.run(f())

# Generated at 2022-06-22 03:42:45.468147
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.google.com', 'GET', {}, None, None, 60, 60)
    defaults = {'method': 'GET'}
    req_proxy = _RequestProxy(request, defaults)
    assert(req_proxy.method == 'GET')



# Generated at 2022-06-22 03:44:13.435184
# Unit test for constructor of class HTTPResponse

# Generated at 2022-06-22 03:44:15.677838
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass



# Generated at 2022-06-22 03:44:18.161800
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient(AsyncHTTPClient)
    http_client.close()
# test_HTTPClient_close.__doc__ = HTTPClient.close.__doc__

# Generated at 2022-06-22 03:44:22.536962
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    req = HTTPRequest('http://example.com')
    resp = HTTPResponse(req, code=200, headers=None, buffer=None, effective_url=None)
    assert resp.rethrow() is None


# Generated at 2022-06-22 03:44:30.842637
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    request = HTTPRequest(url="http://wwww.baidu.com", headers=HTTPHeaders({"content-type":"application/json"}))
    resp = HTTPResponse(request=request, code=200, headers=HTTPHeaders({"content-type":"application/json"}))
    try:
        resp.rethrow()
    except HTTPError as e:
        print(e)



# Generated at 2022-06-22 03:44:33.187038
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    import httpclient
    with httpclient.HTTPClient() as http_client:
        assert httpclient is not None
    assert httpclient is None


# Generated at 2022-06-22 03:44:34.076467
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()



# Generated at 2022-06-22 03:44:36.923715
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    AsyncHTTPClient = create_autospec(AsyncHTTPClient)
    obj = AsyncHTTPClient()
    obj.close()


# Generated at 2022-06-22 03:44:50.369960
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # type: () -> None
    import tornado.escape
    import tornado.testing
    from tornado.httpclient import HTTPResponse
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application, RequestHandler, url


    class HelloHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")


    class BrokenHandler(RequestHandler):
        def get(self):
            raise Exception("oops")


    class HostnameHandler(RequestHandler):
        def get(self):
            self.write(self.request.host)


    class EchoPostHandler(RequestHandler):
        def post(self):
            self.write(self.request.body)



# Generated at 2022-06-22 03:45:03.394838
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # Verify the async_clients property returns a WeakKeyDictionary for the
    # current class that successfully stores and removes elements
    h = AsyncHTTPClient()
    wkds = AsyncHTTPClient._async_clients()
    assert wkds == {h.io_loop: h}
    # If this fails, it may be because the `io_loop` attribute is somehow
    # leaking between instances.  It can also fail because of weird
    # multiprocessing or multithreading issues.
    h.close()
    assert not wkds

    # Verify that the AsyncHTTPClient uses the proper subclass
    # (CurlAsyncHTTPClient or SimpleAsyncHTTPClient) based on if
    # tornado.curl_httpclient is available