

# Generated at 2022-06-22 03:40:28.703238
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass



# Generated at 2022-06-22 03:40:39.296028
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    """Unit test for constructor of class HTTPResponse
    """
    request = HTTPRequest(
        url="https://www.google.com.hk",
        headers=httputil.HTTPHeaders(),
        method="GET",
        body=None,
    )
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = "https://www.google.com.hk"
    error = HTTPError(code, message="Unknown", response=None)
    request_time = 5.0
    time_info = {"queue": 0.5}
    reason = "Unknown"
    start_time = time.time()
    print("\nHTTPResponse Constructor Test:")
    print("\tRequest URL:", request.url)

# Generated at 2022-06-22 03:40:40.687033
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    http_client_error = HTTPClientError(1,'Test',None)
    assert http_client_error.__repr__() == str(http_client_error)


# Generated at 2022-06-22 03:40:44.791828
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    # setup
    request = HTTPRequest("http://www.example.com")
    defaults = {"chunk_size": 1024}
    request_proxy = _RequestProxy(request, defaults)

    # assert
    assert request_proxy.request == request
    assert request_proxy.defaults == defaults

    # test __getattr__
    assert request_proxy.url == "http://www.example.com"
    assert request_proxy.chunk_size == 1024



# Generated at 2022-06-22 03:40:45.375164
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-22 03:40:50.024158
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # try:
    #     response = http_client.fetch("http://www.google.com/")
    #     print(response.body)
    # except httpclient.HTTPError as e:
    #     # HTTPError is raised for non-200 responses; the response
    #     # can be found in e.response.
    #     print("Error: " + str(e))
    # except Exception as e:
    #     # Other errors are possible, such as IOError.
    #     print("Error: " + str(e))
    return


# Generated at 2022-06-22 03:40:57.153459
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("test", user_agent="kuro")
    defaults = {
        "connect_timeout": 1234.5,
        "request_timeout": 5678.9
    }
    reqproxy = _RequestProxy(request, defaults)
    # test1
    assert reqproxy.user_agent == "kuro"
    # test2
    assert reqproxy.connect_timeout == 1234.5
    # test3
    assert reqproxy.request_timeout == 5678.9

# Generated at 2022-06-22 03:40:57.841304
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    pass



# Generated at 2022-06-22 03:41:04.822018
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():

    class MockAsyncHTTPClient(AsyncHTTPClient):

        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass

    @gen.coroutine
    def mocked_fetch(request):
        raise gen.Return(MockAsyncHTTPClient().fetch(request))
    request = HTTPRequest("http://example.com", headers={"Host": "example.com"},
                          validate_cert=True)
    response = yield mocked_fetch(request)
    assert isinstance(response, HTTPResponse)
    request.headers["Host"] = "differenthost.com"
    response_validate_cert_false = yield mocked_fetch(request)
    assert isinstance(response_validate_cert_false, HTTPResponse)

# Generated at 2022-06-22 03:41:06.934031
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    import doctest
    doctest.testmod(HTTPResponse)

# Generated at 2022-06-22 03:41:22.871606
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httpserver

    class WebSocketHandler(tornado.websocket.WebSocketHandler):
        def check_origin(self, origin):
            return True

        def open(self):
            pass

        def on_message(self, message):
            pass

        def on_close(self):
            pass

    class TestHandler(tornado.web.RequestHandler):
        def get(self):
            pass

    import time

    def test():
        http_client = tornado.httpclient.HTTPClient()
        time.sleep(1)
        http_client.close()

    tornado.testing.run_test(test)


# Generated at 2022-06-22 03:41:26.586190
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(123)
    except HTTPClientError as e:
        assert e.code == 123
        assert e.message == 'Unknown'
        assert e.response == None

HTTPError = HTTPClientError


# Generated at 2022-06-22 03:41:30.224765
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    t1 = AsyncHTTPClient()
    t2 = AsyncHTTPClient()
    assert t1 == t2
    t1.close()
    t2.close()
    t1 = None
    t2 = None


# Generated at 2022-06-22 03:41:38.156298
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    obj = HTTPClientError(999)
    assert obj.code == 999
    assert obj.message == "Unknown"
    assert obj.response == None
    obj = HTTPClientError(200)
    assert obj.code == 200
    assert obj.message == "OK"
    assert obj.response == None


HTTPError = HTTPClientError
"""Alias for `HTTPClientError`.

.. versionchanged:: 5.1
   Renamed from ``HTTPError`` to ``HTTPClientError`` to avoid collisions with
   `tornado.web.HTTPError`. This alias remains for backwards compatibility.
"""



# Generated at 2022-06-22 03:41:45.348181
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    from tornado.httpclient import HTTPRequest, HTTPResponse
    import cStringIO
    request = HTTPRequest("http://127.0.0.1:8888/")
    headers = httputil.HTTPHeaders()
    buffer = cStringIO.StringIO()
    response = HTTPResponse(request, 200, headers, buffer, "http://127.0.0.1:8888/")

# Generated at 2022-06-22 03:41:54.215486
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.web import RequestHandler, Application
    import time

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class BaseTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([('/', MainHandler)])


        @gen_test
        def test_sync(self):
            # sync() must be a coroutine because it calls AsyncHTTPClient.sync()
            # that always needs yield
            http_client = HTTPClient()

# Generated at 2022-06-22 03:42:00.836729
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # Create an IOLoop, create an AsyncHTTPClient, then destroy the IOLoop
    # and recreate it.  The key is making sure the first IOLoop (and
    # its associated caches) are destroyed before the new one is
    # created.
    client = AsyncHTTPClient()
    IOLoop.clear_current()
    IOLoop.clear_instance()
    ioloop = IOLoop()
    ioloop.close()



# Generated at 2022-06-22 03:42:07.992736
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import typing
    import pprint
    logger = logging.getLogger(__name__)

    # Setup --------------------------------------------------------------------
    async_http_client = AsyncHTTPClient()
    # Exercise -----------------------------------------------------------------
    async_http_client.close()
    # Verify -------------------------------------------------------------------
    pass


# Generated at 2022-06-22 03:42:18.981288
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    pass
    # def test__RequestProxy():
    #     request = HTTPRequest("http://www.baidu.com")
    #     defaults = {"charset": "utf-8"}
    #     request_proxy = _RequestProxy(request, defaults)
    #     assert request_proxy.request == request, "request_proxy.request == request"
    #     assert request_proxy.defaults == defaults, "request_proxy.defaults == defaults"
    #     assert request_proxy.url == request.url, "request_proxy.url == request.url"
    #     assert request_proxy.charset == "utf-8", "request_proxy.charset == utf-8"

"""
DNS解析由浏览器负责
"""



# Generated at 2022-06-22 03:42:24.794017
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    if __name__ == "__main__":
        import asyncio
        from tornado.platform.asyncio import AsyncIOMainLoop
        from tornado.testing import AsyncHTTPTestCase, gen_test


        class HTTPClientTest(AsyncHTTPTestCase):
            def get_app(self):
                return Application([url("/", self.index)])

            @gen.coroutine
            def index(self, request):
                yield gen.sleep(0.01)
                self.stop()

            @gen_test
            def test_httpclient(self):
                client = yield asyncio.wait_for(
                    AsyncHTTPClient(), timeout=self.io_loop.time() + 5
                )
                client.fetch(HTTPRequest(url=self.get_url("/")), callback=self.stop)
                yield gen

# Generated at 2022-06-22 03:42:41.634207
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    @gen.coroutine
    def f():
        http_client = AsyncHTTPClient()
        try:
            response = yield http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)
    f()
    IOLoop.current().run_sync(f)


# Generated at 2022-06-22 03:42:53.740187
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.concurrent import Future
    from tornado.escape import native_str
    from tornado.gen import multi
    from tornado.httpclient import HTTPError, HTTPRequest
    from tornado.httputil import HTTPHeaders, HTTPMessageDelegate
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port, ExpectLog
    from tornado.test.util import unittest

    class _MockRequestDelegate(HTTPMessageDelegate):
        _expected_request_headers = HTTPHeaders(
            {"Expect": "100-continue"} + _DEFAULT_HEADERS
        )


# Generated at 2022-06-22 03:43:08.134489
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    # type: () -> None
    msg = "test error message"
    err = HTTPClientError(404, message=msg)
    assert err.message == msg
    assert str(err) == "HTTP 404: %s" % msg


HTTPError = HTTPClientError

# curl_httpclient uses a global lock to protect the share handle from
# concurrent access.  This means that it is not safe to use the
# curl_httpclient from multiple threads.  IOLoop implementations are
# generally not thread-safe, so this lock should not normally be an
# issue in real code, but it can make unit testing more difficult.
# As a workaround, HTTPRequest (and thus AsyncHTTPClient) has an
# "unlock_curl" method that releases the lock by calling
# curl_httpclient.global_cleanup.  This allows tests to use an
#

# Generated at 2022-06-22 03:43:21.658264
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncTestCase, ExpectLog

    from distributed.utils_test import gen_test

    # `AsyncHTTPClient.__new__` is tricky! It sets up a cache, and if
    # you call it in the wrong order, it gets confused.

    class CacheTestCase(AsyncTestCase):
        def setUp(self) -> None:
            super().setUp()
            # We make a new IOLoop here because we're going to get
            # confused otherwise.
            loop, self.loop = self.loop, IOLoop()


# Generated at 2022-06-22 03:43:32.103511
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    # first test that the constructor works properly
    r = HTTPRequest(method='GET', url='http://www.example.com')
    r_proxy = _RequestProxy(r, {'proxy_host': 'www.example.org', 'proxy_port': '19999'})
    assert r_proxy.method == 'GET'
    assert r_proxy.url == 'http://www.example.com'
    assert r_proxy.proxy_host == 'www.example.org'
    assert r_proxy.proxy_port == '19999'
    # now test that the defaults work properly
    r = HTTPRequest(method='GET', url='http://www.example.com')
    r_proxy = _RequestProxy(r, {'proxy_host': 'www.example.org', 'proxy_port': '19999'})
    r_proxy

# Generated at 2022-06-22 03:43:44.895695
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    body = "hello world"
    if_modified_since = datetime.datetime.now
    follow_redirects = True
    max_redirects = 5
    user_agent = "tornado"
    decompress_response = True
    streaming_callback = lambda x: None
    header_callback = lambda x: None
    prepare_curl_callback = lambda x: None
    allow_nonstandard_methods = False
    validate_cert = True
    ca_certs = None
    allow_ipv6 = True
    client_key = "hello"
    client_cert = "world"

# Generated at 2022-06-22 03:43:46.420412
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    print(http_client)
    print(http_client._async_client)
    print(http_client._io_loop)
    http_client.close()

test_HTTPClient()



# Generated at 2022-06-22 03:43:58.865136
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # Test with a correct URL
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("https://www.google.com/")
        print(response.body)
        assert response.code == 200
    except httpclient.HTTPError as e:
        print("Error: " + str(e))
        assert False
    except Exception as e:
        print("Error: " + str(e))
        assert False
    http_client.close()

    # Test with a wrong URL
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/WRONG")
        print(response.body)
        assert False
    except httpclient.HTTPError as e:
        print("Error: " + str(e))


# Generated at 2022-06-22 03:44:08.765909
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    import logging
    import tornado.httpclient
    import tornado.testing
    def test_rethrow(self):
        r_error = tornado.httpclient.HTTPError(599, "test error")
        r_response = tornado.httpclient.HTTPResponse(tornado.testing.gen_test(self.stop), 599, error=r_error)
        self.assertTrue(r_response.error)

        def check_error():
            r_response.rethrow()
            raise Exception("should not have gotten here")
        self.assertRaises(tornado.httpclient.HTTPError, check_error)
        r_response.error = None
        r_response.rethrow()

        r_response.code = 599
        self.assertTrue(r_response.error)

# Generated at 2022-06-22 03:44:15.586227
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    'test_HTTPRequest'

# Generated at 2022-06-22 03:45:42.529853
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request_proxy = _RequestProxy(
        request=HTTPRequest("http://test.com"),
        defaults={"username": "test"}
    )
    # This is test for __getattr__
    assert request_proxy.username == "test"
    assert request_proxy.request.url == "http://test.com"



# Generated at 2022-06-22 03:45:49.295868
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest('test_url', method="test_method")
    response = HTTPResponse(request, code=200, headers=[('HTTP', 'test_header')],
                            buffer=BytesIO(b'test_body'), effective_url='test_effective_url',
                            error=HTTPError(100, reason="test_error"),
                            request_time=10, time_info=['test_time_info'],
                            reason="test_reason", start_time=1)
    assert response.request == request
    assert response.code == 200
    assert response.reason == "test_reason"
    assert response.headers == [('HTTP', 'test_header')]
    assert response.buffer == BytesIO(b'test_body')
    assert response.body == b'test_body'

# Generated at 2022-06-22 03:45:52.811153
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    print("Test HTTPResponse constructor.")
    req = HTTPRequest('http://localhost:8888/')
    res = HTTPResponse(req, 200)
    pprint.pprint(res)


# Generated at 2022-06-22 03:46:03.393481
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import asyncio
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application

    class SimpleHandler(RequestHandler):
        def get(self):
            self.write('test')

    class WebTestCase(AsyncHTTPTestCase):
        def get_app(self) -> "Application":
            return Application([('/', SimpleHandler)])

        @gen_test
        def test_fetch(self) -> None:
            response = yield self.http_client.fetch(self.get_url('/'))
            self.assertEqual('test', response.body.decode('utf-8'))

    if __name__ == '__main__':
        import unittest
        unittest.main()

# Generated at 2022-06-22 03:46:13.450900
# Unit test for method rethrow of class HTTPResponse

# Generated at 2022-06-22 03:46:15.132892
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    h = HTTPResponse(None, None, None, None, None, None, None, None, None, None)
    h.rethrow()



# Generated at 2022-06-22 03:46:24.557917
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    res = HTTPResponse(
        code = 200,
        reason = "OK",
        error = None,
        request_time = 10.0,
        time_info = {
            "namelookup":0.0,
            "connect":0.0,
            "appconnect":0.0,
            "pretransfer":0.0,
            "redirect":10.0,
            "starttransfer":10.0,
            "total":10.0
        }
    )
    # print(repr(res))



# Generated at 2022-06-22 03:46:26.305452
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    http_client = AsyncHTTPClient()
    assert isinstance(http_client, AsyncHTTPClient)

# Generated at 2022-06-22 03:46:29.099679
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    rp = _RequestProxy(HTTPRequest('http://www.google.com/',method='GET'),{'proxy_host': 'localhost'})
    assert rp.url == 'http://www.google.com/'
    assert rp.method == 'GET'
    #assert rp.proxy_host == 'localhost'
    assert rp.proxy_host2 == None

# Generated at 2022-06-22 03:46:31.073314
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    assert hasattr(_RequestProxy(request=HTTPRequest('https://www.google.com'), defaults={}), "request")
    assert hasattr(_RequestProxy(request=HTTPRequest('https://www.google.com'), defaults={}), "defaults")



# Generated at 2022-06-22 03:48:03.555071
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
  async def f():
    http_client = AsyncHTTPClient(force_instance=True)
    http_client.close()
    http_client.close()
    print(http_client.io_loop)
  ioloop = IOLoop.current()
  ioloop.run_sync(f)


# Generated at 2022-06-22 03:48:05.409589
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient(HTTPRequest)


# Generated at 2022-06-22 03:48:19.185304
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "https://api.github.com/repos/the14thdoctor/tornado_alchemy/commits"
    headers = {
        "Accept": "application/json",
        "Accept-Language": "en_US",
        "Date": "Fri, 22 Mar 2019 15:36:13 GMT",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36",
    }

    request = HTTPRequest(url = url, headers = headers)
    assert request.headers == headers
    assert request.url == url


if __name__ == '__main__':
    test_HTTPRequest()

# Generated at 2022-06-22 03:48:24.120134
# Unit test for function main
def test_main():
    # Override the default AsyncHTTPClient for the test with
    # a version that does not actually make HTTP requests.
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, io_loop, **kwargs):
            super(TestAsyncHTTPClient, self).initialize(io_loop, **kwargs)
            self.current_request = None  # type: Optional[_RequestProxy]
            self.requests = []  # type: List[_RequestProxy]

        def fetch_impl(
            self, request: HTTPRequest, callback: Callable[[HTTPResponse], None]
        ) -> HTTPResponse:
            self.requests.append(request)
            if request.callback is not None:
                request.callback(HTTPResponse(request, 200, buffer=BytesIO(b"foo")))
           

# Generated at 2022-06-22 03:48:28.511197
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    async def foo():
        hc = AsyncHTTPClient()
        hc.initialize()

    loop = IOLoop.current()
    loop.run_sync(foo)

    hc = AsyncHTTPClient(force_instance=True)
    hc.initialize()



# Generated at 2022-06-22 03:48:30.052007
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass



# Generated at 2022-06-22 03:48:34.180291
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    method = HTTPClientError(code=500, message="tornado.httpclient.HTTPClientError")
    method._HTTPResponse__repr__()
# Create an alias for backwards compatibility
HTTPError = HTTPClientError



# Generated at 2022-06-22 03:48:36.845406
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    global _RequestProxy
    rp = _RequestProxy(HTTPRequest("http://www.baidu.com/"),{'test':'david','test2':'lh'})
    print(rp.test)
    print(rp.test2)
test__RequestProxy___getattr__()

# Generated at 2022-06-22 03:48:40.511088
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import requests
    import json
    import logging
    logging.basicConfig(level = logging.INFO,format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    url = 'http://127.0.0.1:8888/post_request_fetcher_test'
    payload = {"name":"jerry"}
    s = requests.session()
    s.keep_alive = False
    for i in range(10):
        r = s.post(url,data=json.dumps(payload))
        logger.info(f"httpclient_fetch_test_result == {r.text}")

# Generated at 2022-06-22 03:48:41.509286
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    client = HTTPClient()
    client.fetch('http://www.gooogle.com/')
    del client

