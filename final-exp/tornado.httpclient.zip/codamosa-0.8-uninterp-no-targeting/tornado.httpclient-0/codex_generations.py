

# Generated at 2022-06-22 03:40:38.398675
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    def close_cb(client):
        client._closed = True

    async_client = mock.MagicMock()
    async_client.close = close_cb

    io_loop = mock.MagicMock()
    io_loop.current = None

# Generated at 2022-06-22 03:40:45.653655
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://www.google.com"
    method = "GET"
    headers = {}
    body = "Body"
    auth_username = "User"
    auth_password = "Pass"
    auth_mode = "basic"
    connect_timeout = 20
    request_timeout = 20
    if_modified_since = 0
    follow_redirects = True
    max_redirects = 5
    user_agent = "UserAgent"
    use_gzip = True
    network_interface = "interface"
    streaming_callback = lambda chunk: print(chunk)
    header_callback = lambda chunk: print(chunk)
    prepare_curl_callback = lambda curl: curl.setopt(pycurl.URL, "http://www.google.com")
    proxy_host = "ProxyHost"
    proxy

# Generated at 2022-06-22 03:40:47.160078
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    self = object
    request = None
    callback = None
    NotImplementedError()

# Generated at 2022-06-22 03:40:53.152972
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    obj = HTTPResponse(request=None,
                       code=200,
                       headers=None,
                       buffer=None,
                       effective_url=None,
                       error=None,
                       request_time=None,
                       time_info=None,
                       reason=None,
                       start_time=None)
    result = obj.__repr__()
    assert result != None


# Generated at 2022-06-22 03:40:57.428849
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    try:
        AsyncHTTPClient(force_instance=False)
        AsyncHTTPClient(force_instance=True)
    except TypeError:
        raise AssertionError()
    AsyncHTTPClient.configure("test")
    try:
        AsyncHTTPClient(force_instance=False)
        AsyncHTTPClient(force_instance=True)
    except TypeError:
        raise AssertionError()



# Generated at 2022-06-22 03:41:04.552114
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado import testing
    from tornado import ioloop

    class MyHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            pass

        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            callback(HTTPResponse(request, 200, buffer=b('Test')))

    @testing.gen_test
    def test_close():
        # Test closing while fetch is in progress
        http_client = MyHTTPClient()
        http_client.fetch('http://www.example.com/', self.stop)
        response = yield self.wait()
        assert response.body == b('Test')

        http_client.close()
        self.io_loop.add_callback(self.stop)
       

# Generated at 2022-06-22 03:41:08.849953
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    HTTPResponse(HTTPRequest('url'),code=200, headers=None , buffer=None, effective_url=None, error=BaseException(),
                 request_time=None, time_info=None).__repr__()



# Generated at 2022-06-22 03:41:17.307907
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():

    from tornado.httpclient import AsyncHTTPClient

    @gen_test
    def test_AsyncHTTPClient___new__():

        client = AsyncHTTPClient()

        nonlocals = test_AsyncHTTPClient___new__.__dict__
        nonlocals["client"] = client
        nonlocals["id"] = id(client)

        test = Test({})
        nonlocals["test"] = test

        test.equal(nonlocals["id"], 10779808)

        client2 = AsyncHTTPClient()

        nonlocals["client2"] = client2
        nonlocals["id2"] = id(client2)

        test.equal(nonlocals["id2"], 10779808)

        test.equal(nonlocals["client"], nonlocals["client2"])

    test_AsyncHTTPClient___new__()




# Generated at 2022-06-22 03:41:19.154011
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    req = HTTPRequest("http:www.baidu.com", method = "get")
    proxy = _RequestProxy(request = req, defaults = {})
    assert isinstance(proxy, _RequestProxy)
    assert proxy.method == "get"

test__RequestProxy()



# Generated at 2022-06-22 03:41:21.875501
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # TODO: Implement unit test method.
    pass


# Generated at 2022-06-22 03:41:48.497611
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://www.baidu.com"
    method = "GET"
    headers = {"Content-Type": "application/json"}
    body = "abc"
    auth_username = "robot"
    auth_password = "123456"
    auth_mode = "basic"
    connect_timeout = 20.0
    request_timeout = 20.0
    if_modified_since = None
    follow_redirects = True
    max_redirects = 5
    user_agent = None
    decompress_response = True
    network_interface = None
    streaming_callback = None
    header_callback = None 
    prepare_curl_callback = None
    proxy_host = None
    proxy_port = None
    proxy_username = None
    proxy_password = ""

# Generated at 2022-06-22 03:41:49.797761
# Unit test for function main
def test_main():
    with mock.patch('tornado.httpclient.main.parse_command_line'):
        with mock.patch('tornado.httpclient.main.HTTPClient'):
            main()

# Generated at 2022-06-22 03:41:51.210176
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://zhihu.com")
    defaults = {"max_clients": "30"}
    _request_proxy = _RequestProxy(request, defaults)
    assert _request_proxy.defaults == defaults


# Generated at 2022-06-22 03:41:59.155627
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():

    # setup

    # create arg
    code = 1

    # create arg
    message = 'message'

    # create arg
    response = mock.Mock()

    # exercise
    e = HTTPClientError(code, message, response)
    v = e.__repr__()

    # verify
    assert repr(v) == repr('HTTP 1: message')


HTTPError = HTTPClientError



# Generated at 2022-06-22 03:42:00.836448
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()
    AsyncHTTPClient(force_instance=True)

test_AsyncHTTPClient()



# Generated at 2022-06-22 03:42:12.436115
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import json
    import tornado.ioloop
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest

    url = 'https://www.baidu.com/'
    body = b'hello world'
    headers = {'Content-Type': 'text/json'}
    request = HTTPRequest(url=url, method='POST', body=body, headers=headers)

    def handle_request(response):
        print(response.code)
        print(response.error)
        print(json.loads(response.body))

    AsyncHTTPClient().fetch(request, handle_request)
    tornado.ioloop.IOLoop.current().start()


# Generated at 2022-06-22 03:42:16.821800
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()
    client.close()
    with pytest.raises(RuntimeError):
        client.fetch("http://www.google.com/")


# Generated at 2022-06-22 03:42:20.638372
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    http_response = HTTPResponse(request, code, headers, buffer)
    # Type-checking
    assert isinstance(http_response.__repr__(), str)


# Generated at 2022-06-22 03:42:31.502011
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import pytest
    import tornado
    import tornado.httpclient
    import tornado.simple_httpclient
    def f():
        this_future = Future()
        client = AsyncHTTPClient()
        assert client.io_loop is IOLoop.current()
        assert isinstance(client, tornado.simple_httpclient.SimpleAsyncHTTPClient)
        future_set_result_unless_cancelled(this_future, client)
        return this_future
    client1 = f().result()
    client2 = f().result()
    assert client1 is client2
    AsyncHTTPClient.configure(tornado.curl_httpclient.CurlAsyncHTTPClient)
    client3 = f().result()
    assert isinstance(client3, tornado.curl_httpclient.CurlAsyncHTTPClient)
    assert client3 is not client1

# Generated at 2022-06-22 03:42:41.410070
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    try:
        import pytest
    except ImportError:
        raise unittest.SkipTest("pytest not installed")
    pytest.importorskip("tornado.curl_httpclient")

    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://example.com")
        print(response.body)
    except Exception as e:
        print("Error:", str(e))
    http_client.close()



# Generated at 2022-06-22 03:43:08.473075
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    httpr = HTTPResponse(HTTPRequest(url="http://www.google.com"), code=200)
    print(httpr)

# The following four classes are used by the AsyncHTTPClient as
# contexts for request and response objects.  Based on the
# implementation, these may not be necessary for users of
# ``AsyncHTTPClient``, but they are necessary for the implementation.

# _RequestProxy and _ResponseProxy wrap around the actual ``HTTPRequest``
# and ``HTTPResponse`` objects created by applications, so that they can
# ensure that ``HTTPRequest`` objects are only used once.  The
# ``HTTPRequest`` and ``HTTPResponse`` objects are also accessible
# (e.g. ``_RequestProxy.request is request``), so that this
# indirection is completely transparent to application code.
#
# _Request

# Generated at 2022-06-22 03:43:12.973829
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    """test_HTTPClient___del__"""
    hc = HTTPClient()
    try:
        hc.close()
        assert True is True
    except Exception as e:
        assert False is True



# Generated at 2022-06-22 03:43:14.829224
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    http_client.close()

# Generated at 2022-06-22 03:43:26.687693
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    print(__file__, "test_HTTPClient_fetch")

    import os
    import random
    import time
    import requests
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient

    def handler(request):
        request_body = request.body.decode('utf-8')
        request.write(request_body)

    class SimpleHTTPRequestHandler(tornado.web.RequestHandler):
        def head(self):
            self._handle()

        def get(self):
            self._handle()

        def post(self):
            self._handle()

        def put(self):
            self._handle()

        def delete(self):
            self._handle()

        def options(self):
            self._handle()

        def patch(self):
            self._handle()


# Generated at 2022-06-22 03:43:33.868068
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient(async_client_class=AsyncHTTPClient)
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-22 03:43:36.942414
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    httpclinerror = HTTPClientError(1,'message',None)
    print(httpclinerror.__repr__())


# Generated at 2022-06-22 03:43:47.266670
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest(url="http://test.test", method="GET")
    code = 200
    reason = "OK"
    headers = {"Accept": "test"}
    buffer = BytesIO(b"test")
    effective_url = "http://test.test"
    error = None
    request_time = None
    time_info = {}

# Generated at 2022-06-22 03:43:49.038647
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    class Foo(object):
        pass
    foo = Foo()
    request = HTTPRequest('http://example.com', foo = foo)
    defaults = {'bar': 'bar'}
    proxy = _RequestProxy(request, defaults)
    assert proxy.foo == foo
    assert proxy.bar == 'bar'



# Generated at 2022-06-22 03:43:54.826036
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    http_client_error = HTTPClientError(501, message='Not implemented', response=None)
    assert http_client_error.response == None
    assert http_client_error.code == 501
    assert http_client_error.message == 'Not implemented'


# Generated at 2022-06-22 03:43:55.740253
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # The test of method __getattr__ of class _RequestProxy is not written yet... pass
    pass


# Generated at 2022-06-22 03:44:36.354438
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    class DummyAsyncHTTPClient(SimpleAsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            # print("Fake fetch_impl function in class {}".format(self.__class__.__name__))
            raise NotImplementedError()
    from tornado.curl_httpclient import CurlAsyncHTTPClient
    class DummyCurlAsyncHTTPClient(CurlAsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            # print("Fake fetch_impl function in class {}".format(self.__class__.__name__))
            raise Not

# Generated at 2022-06-22 03:44:39.850598
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    # Verify that a bare HTTPRequest() has all of the _DEFAULTS populated
    assert len(HTTPRequest("/").__dict__) == len(HTTPRequest._DEFAULTS)

# Generated at 2022-06-22 03:44:45.709425
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    r = _RequestProxy(HTTPRequest('http://foo'), {'connect_timeout': 10})
    assert r.connect_timeout == 10
    r2 = _RequestProxy(r, {'connect_timeout': 20})
    assert r2.connect_timeout == 10

# vi: ts=4 sw=4 et

# Generated at 2022-06-22 03:44:47.551364
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    assert client.io_loop is not None



# Generated at 2022-06-22 03:44:52.807012
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client = AsyncHTTPClient()
    http_client.close()
    response = http_client.fetch("http://www.google.com/")
    try:
        print("Body: %r" % response.body)
    except HTTPError as e:
        print("Error: %s" % e)


# Generated at 2022-06-22 03:45:02.728855
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        assert response is not None
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()
    return response



# Generated at 2022-06-22 03:45:12.211991
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-22 03:45:18.780608
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-22 03:45:19.485731
# Unit test for function main
def test_main():
    print("test")
    # main()
    

# Generated at 2022-06-22 03:45:23.519617
# Unit test for function main
def test_main():
    import functools
    import io

    import pytest
    import tornado
    import tornado.locks
    import tornado.testing

    import asyncio

    from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPClient

    @tornado.testing.gen_test
    def test_main(mock_httpclient):
        stdout = io.StringIO()
        with mock_httpclient.patch(functools.partial(stdout.write, flush=True)) as mock:
            mock.get(
                "/foo",
                headers={"Content-Type": "text/plain"},
                body="Hello",
                times=1,
            )
            mock.get(
                "/bar",
                headers={"Content-Type": "text/plain"},
                body="Goodbye",
                times=1,
            )

# Generated at 2022-06-22 03:46:10.141013
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    #pass
    http_request = HTTPRequest(url = "https://httpbin.org/post",method = "POST",headers = {"User-Agent":"Mozilla/5.0"},body = "")
    print(http_request.__dict__)

test_HTTPRequest()

# Generated at 2022-06-22 03:46:17.832761
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from io import BytesIO
    from datetime import datetime
    from tornado.options import define, options, parse_command_line
    import sys
    import tornado.testing
    import unittest

    define("test_HTTPRequest", type=str,
           help="Test_HTTPRequest test module to run, e.g. 'foo' or 'foo.bar.baz'")

    parse_command_line()

    if not options.test_HTTPRequest:
        print("No test module specified.\n"
              "Pass the test module name to test on the command line, e.g:\n"
              "\n"
              "    python -m tornado.testing test_HTTPRequest "
              "tornado.test.httpclient_test\n")

# Generated at 2022-06-22 03:46:21.488635
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        HTTPClientError(404, "Not Found")
    except Exception as e:
        assert e.code == 404


HTTPError = HTTPClientError  # type: Type[HTTPClientError]



# Generated at 2022-06-22 03:46:32.679966
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # set up
    import tornado.ioloop
    import tornado.web
    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")
    def make_app():
        return tornado.web.Application([
            (r"/", MainHandler),
        ])
    app = make_app()
    # exec
    def f():
        http_client = tornado.httpclient.AsyncHTTPClient()
        try:
            response = http_client.fetch("http://localhost:8080/")
            print(response.body)
        except tornado.httpclient.HTTPError as e:
            # HTTPError is raised for non-200 responses; the response
            # can be found in e.response.
            print("Error: " + str(e))

# Generated at 2022-06-22 03:46:34.883837
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    c = HTTPClient()
    del c


# Generated at 2022-06-22 03:46:46.474074
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-22 03:46:52.229778
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # TODO: HTTPResponse(HTTPError(code)) does not invoke the body
    # setter below, because HTTPError is an Exception rather than
    # BaseException.  This seems like a sneaky bug that could bite
    # people.
    request = HTTPRequest(url='https://www.baidu.com')
    code = 200
    reason = "OK"
    response = HTTPResponse(request, code, reason)
    assert response.code == 200
    #  Test exception case
    response.error = HTTPError(code, reason)
    try:
        response.rethrow()
    except HTTPError:
        pass



# Generated at 2022-06-22 03:46:58.990933
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.baidu.com")
    defaults = {"code": 200}
    assert request.code == _RequestProxy(request, defaults).code
    defaults = {"code": 404}
    assert defaults['code'] == _RequestProxy(request, defaults).code
# Unit test end

_DEFAULT_CA_CERTS = None  # type: Optional[str]
_DEFAULT_CA_CERTS_DIR = None  # type: Optional[str]



# Generated at 2022-06-22 03:47:09.117626
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # 1. 请求成功， self.error = None
    response = HTTPResponse(
        request=HTTPRequest(url="http://127.0.0.1:5000/post"), code=200
    )
    response.rethrow()
    assert response is not None

    # 2. 请求失败， self.error = HTTPError
    response = HTTPResponse(
        request=HTTPRequest(url="http://127.0.0.1:5000/post"), code=306
    )
    with pytest.raises(HTTPError):
        response.rethrow()
    assert response is not None


# Generated at 2022-06-22 03:47:18.289536
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.escape import to_unicode
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httputil import url_concat
    from tornado.testing import AsyncHTTPTestCase, gen_test

    class MainHandler(RequestHandler):
        def get(self):
            query_arguments = self.request.query_arguments
            self.write(query_arguments)

    class TestAsyncHTTPClient(AsyncHTTPTestCase):
        def get_app(self):
            return Application([('/', MainHandler)])

        @gen_test
        def test_fetch(self):
            response = yield AsyncHTTPClient().fetch(self.get_url('/'))
            self.assertEqual(response.code, 200)


# Generated at 2022-06-22 03:48:34.577888
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(500, 'test')
    assert error.code == 500
    assert error.message == 'test'
    assert error.response is None


HTTPError = HTTPClientError



# Generated at 2022-06-22 03:48:41.247632
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    req = HTTPRequest('http://www.baidu.com')
    res = HTTPResponse(request=req, code=200, headers=None, buffer=None, effective_url='http://www.baidu.com', error=None, request_time=None, time_info=None, reason=None, start_time=None)
    print(res)


# Generated at 2022-06-22 03:48:41.742139
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-22 03:48:43.932449
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    print("test __getattr__ of _RequestProxy")
    a = _RequestProxy(1, 2)
    print(a.request)
    print(a.defaults)
    print(a.sample)
test__RequestProxy___getattr__()

_DEFAULT_CA_CERTS = os.path.join(os.path.dirname(__file__), "cacerts.txt")



# Generated at 2022-06-22 03:48:48.119033
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    # Prepare the input data
    host = "www.google.com"
    http_client = httpclient.HTTPClient()
    # Call the tested method
    # The tested method should not raise
    http_client.fetch(host)

# Generated at 2022-06-22 03:48:53.762310
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://localhost/")
    rp = _RequestProxy(request, {"connect_timeout": 10})
    assert rp.connect_timeout == 10
    request.connect_timeout = 20
    assert rp.connect_timeout == 20

# Add this in case the above test is used as the body of a unit test
test__RequestProxy()

# Generated at 2022-06-22 03:48:56.154149
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://www.google.com"
    method = "GET"
    body_producer = lambda write: write("Hello!")

    request = HTTPRequest(url, method, body_producer=body_producer)
    print(type(request._body))

    print(request.body_producer)
    print(type(request.body_producer))




# Generated at 2022-06-22 03:48:59.316441
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    """
    Test for method __new__ of class AsyncHTTPClient in module
    tornado.httpclient.
    """
    # Run tests for __new__ of class AsyncHTTPClient in module tornado.httpclient
    pass


# Generated at 2022-06-22 03:49:01.730990
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    assert issubclass(AsyncHTTPClient, Configurable)

# Unit tests for _async_clients()

# Generated at 2022-06-22 03:49:13.624573
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    impl: Union[None, str, Type[Configurable]] = None 
    class DummyAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl( 
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            request.headers = httputil.HTTPHeaders(request.headers)
            response = Future()
            response.set_result("")
            callback(cast("HTTPResponse", response))
    AsyncHTTPClient.configure(DummyAsyncHTTPClient)
    http_client = AsyncHTTPClient()
    response = http_client.fetch("http://www.google.com")
    http_client.close()
    return response