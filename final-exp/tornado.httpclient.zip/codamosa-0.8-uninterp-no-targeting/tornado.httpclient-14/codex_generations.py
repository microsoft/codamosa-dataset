

# Generated at 2022-06-22 03:40:38.630554
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application, RequestHandler
    import json
    import tornado

    class HelloHandler(RequestHandler):
        def get(self, name):
            self.set_status(200)
            self.set_header("Content-Type", "application/json")
            self.write(json.dumps({"hello": name}))

    def get_app() -> Application:
        return Application([("/([a-z]+)", HelloHandler)])

    class TestHandler(AsyncHTTPTestCase):
        def get_app(self):
            return get_app()

        def test_hello(self):
            # HTTPClient() is a blocking HTTP client
            http_client = HTTPClient()

# Generated at 2022-06-22 03:40:43.937551
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-22 03:40:44.678262
# Unit test for function main
def test_main():
    assert True



# Generated at 2022-06-22 03:40:54.508102
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado
    import json
    import time
    import httplib2
    import requests
    import aiohttp

    server_port = 18888
    httpclient = HTTPClient()

# Generated at 2022-06-22 03:41:02.562343
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    import unittest # type: ignore
    from unittest.mock import patch

    class MainTest(AsyncTestCase, unittest.TestCase):
        @patch('tornado.httpclient.HTTPClient')
        @patch('tornado.httputil.HTTPResponse')
        @patch('tornado.httpclient.HTTPClient.fetch', return_value = None)
        @patch('tornado.httpclient.HTTPError')
        @patch('tornado.options.parse_command_line', return_value = ['testurl'])
        def test_main(self, parse_command_line, HTTPError, fetch, httpr, http):
            main()
            # self.assertEqual(httpr.call_count, 1)

    MainTest().test

# Generated at 2022-06-22 03:41:11.355230
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-22 03:41:17.137194
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    from tornado.test.util import unittest

    class FakeAsyncHTTPClient(AsyncHTTPClient):
        pass

    class Test(unittest.TestCase):
        def test(self) -> None:
            client = AsyncHTTPClient()
            self.assertTrue(isinstance(client, FakeAsyncHTTPClient))

    AsyncHTTPClient.configure(FakeAsyncHTTPClient, defaults=dict(foo="bar"))
    try:
        Test().test()
    finally:
        # Avoid trouble in tests that don't call configure()
        AsyncHTTPClient.configure(None)



# Generated at 2022-06-22 03:41:17.857447
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-22 03:41:27.496633
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://localhost:5000/test")
    response = HTTPResponse(
        request, 200, headers=None, buffer=None, effective_url=None, error=None,
        request_time=None, time_info=None, reason=None, start_time=None
    )
    assert response.request == request
    assert response.code == 200
    assert response.reason == "OK"
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer == None
    assert response._body == None
    assert response.effective_url == request.url
    assert response.error == None
    assert response.request_time == None
    assert response.time_info == {}


# Generated at 2022-06-22 03:41:34.890745
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    class _MyAsyncHTTPClient(AsyncHTTPClient):
        pass

    AsyncHTTPClient.configure(_MyAsyncHTTPClient)
    try:
        client1 = AsyncHTTPClient()
        client2 = AsyncHTTPClient()
        assert isinstance(client1, _MyAsyncHTTPClient)
        assert client1 is client2
    finally:
        AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient")


HTTPRequest = httputil.HTTPRequest
HTTPResponse = httputil.HTTPResponse

