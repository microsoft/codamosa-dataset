

# Generated at 2022-06-22 03:40:52.328065
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import os, tornado.httpclient
    def handle_response(response):
        if response.error:
            print("Error:", response.error)
        else:
            print(response.body)
    # 创建一个httpclient实例
    http_client = tornado.httpclient.AsyncHTTPClient()
    # 发起get请求
    http_client.fetch("http://www.baidu.com/", handle_response)
    # 发起post请求

# Generated at 2022-06-22 03:40:54.530047
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient(
        async_client_class=None,
    )
    assert http_client._closed == True
    http_client.close()
    assert http_client._closed == True


# Generated at 2022-06-22 03:41:00.704207
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('http://localhost')
    code = 302
    headers = None
    buffer = io.BytesIO(b'hello')
    effective_url = 'http://localhost'
    error = ValueError('error')
    request_time = 3
    time_info = {}
    reason = 'not found'
    start_time = time.time()

    response = HTTPResponse(request, code, headers, buffer,
                            effective_url, error,
                            request_time, time_info,
                            reason, start_time)
    assert response.body == b'hello'
    assert response.reason == 'not found'
    assert response.headers == {}
    assert response.error == ValueError('error')
    assert response.request == request

    with pytest.raises(HTTPError):
        response.re

# Generated at 2022-06-22 03:41:01.461838
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()


# Generated at 2022-06-22 03:41:07.564111
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado import gen
    from tornado.simple_httpclient import _DEFAULT_CA_CERTS

    http_client = AsyncHTTPClient()
    client = http_client._async_client.__class__
    assert client.__name__ == 'SimpleAsyncHTTPClient'

    def test_configure_defaults(kwargs, expected):
        # test that configure can set default values
        kwargs['max_clients'] = 123
        client = AsyncHTTPClient.configure(**kwargs)
        assert client.__name__ == 'SimpleAsyncHTTPClient'
        http_client = client()
        assert http_client.max_clients == 123
        assert http_client.io_loop is IOLoop.current()
        assert http_client.defaults == expected


# Generated at 2022-06-22 03:41:08.024435
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass



# Generated at 2022-06-22 03:41:16.909358
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    import unittest
    import httpclient
    import tornadotest.async_test
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
    except httpclient.HTTPError as e:
        print("Error: " + str(e))
        assert False
    except Exception as e:
    # Other errors are possible, such as IOError.
        print("Error: " + str(e))
        assert False
    print(response.body)
    http_client.close()


# Generated at 2022-06-22 03:41:20.041701
# Unit test for function main
def test_main():
	import sys 
	import os
	log = logging.getLogger()
	log.setLevel(logging.DEBUG)
	stream_handler = logging.StreamHandler(sys.stdout)
	log.addHandler(stream_handler)
	main()
	log.removeHandler(stream_handler)
	del sys.path[0]
	os.chdir('..')

if __name__ == "__main__":
	test_main()
# vim: set noexpandtab ts=4 sts=4 sw=4 :

# Generated at 2022-06-22 03:41:23.917048
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    HTTPClientFactory.initialize()

# Generated at 2022-06-22 03:41:35.004233
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    AsyncHTTPClient.configure(None, defaults=dict(user_agent="MyUserAgent"))
    # or with force_instance:
    client = AsyncHTTPClient(force_instance=True,
        defaults=dict(user_agent="MyUserAgent"))

    def handle_response(response: HTTPResponse) -> None:
        if response.error:
            if raise_error or not response._error_is_response_code:
                future_set_exception_unless_cancelled(future, response.error)
                return
        future_set_result_unless_cancelled(future, response)

    async def f2(self, request: str, raise_error: bool=True, **kwargs: Any) -> Union[object, Future[HTTPResponse]]:
        if self._closed:
            raise RuntimeError

# Generated at 2022-06-22 03:42:14.914298
# Unit test for function main
def test_main():
    import __main__
    try:
        orig_name = __main__.__name__
        __main__.__name__ = "tornado.httpclient_test"
        main()
    finally:
        __main__.__name__ = orig_name
# test_main()
if __name__ == "__main__":
    main()



# Generated at 2022-06-22 03:42:22.693352
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    _io_loop = IOLoop()

    async def a():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com/")
            print(response.body)
        except Exception as e:
            # Other errors are possible, such as IOError.
            print("Error: " + str(e))

    _io_loop.run_until_complete(a())
    _io_loop.close()



# Generated at 2022-06-22 03:42:26.592358
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    h = HTTPClient()
    assert h._closed == False
    h.close()
    assert h._closed == True
    del h
    print("test_HTTPClient___del__ pass")


# Generated at 2022-06-22 03:42:31.361635
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://www.example.com",method = "POST")
    defaults = {
        "allow_nonstandard_methods": True,
        "validate_cert": True,
        "ca_certs": None
    }
    proxy_request = _RequestProxy(request,defaults)
    print(proxy_request.method)



# Generated at 2022-06-22 03:42:34.626806
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    error = HTTPClientError(code=999, message="UnitTest", response=None)
    assert "HTTP 999: UnitTest" == error.__repr__()


# Generated at 2022-06-22 03:42:37.833334
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    client = AsyncHTTPClient()
    assert client._instance_cache == AsyncHTTPClient._async_clients()

# Generated at 2022-06-22 03:42:50.956450
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    def fake_request(url):
        return HTTPRequest(url=url)
    response = HTTPResponse(request=fake_request(url='www.baidu.com'), code=200, headers=None)
    print(response)


from functools import partial
import threading
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterable
from typing import Optional
from typing import Tuple
from typing import Union

from tornado import concurrent
from tornado import httputil
from tornado import ioloop
from tornado import loc
from tornado import stack_context
from tornado import gen
from tornado import netutil
from tornado import process
from tornado.log import gen_log
from tornado.util import ObjectDict
import tornado.platform.auto
import tornado.platform.caresresolver
import tornado.platform.tw

# Generated at 2022-06-22 03:43:02.914685
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # AsyncHTTPClient.__new__()
    # Subclass of AsyncHTTPClient
    class SubClient(AsyncHTTPClient):
        def initialize(self, *args, **kwargs):
            pass
    c1 = SubClient()
    c2 = SubClient(max_clients=10)
    assert c1.io_loop is IOLoop.instance()
    assert c2.io_loop is IOLoop.instance()
    assert c1.max_clients == c2.max_clients == 10
    AsyncHTTPClient.configure("tornado.test.httpclient_test.SubClient", max_clients=20)
    c3 = SubClient()
    assert c3.io_loop is IOLoop.instance()
    assert c3.max_clients == 20
    c1.close()
    c

# Generated at 2022-06-22 03:43:05.705415
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    with AsyncHTTPClient() as http_client:
        raise ValueError

_ARG_DEFAULT = object()



# Generated at 2022-06-22 03:43:09.831447
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    io_loop = AsyncIOMainLoop()
    io_loop.make_current()
    # Check for deprecated IOLoop argument
    with pytest.raises(TypeError):
        AsyncHTTPClient(io_loop=io_loop)
    client = AsyncHTTPClient(force_instance=True)
    assert isinstance(client, SimpleAsyncHTTPClient)
    client2 = AsyncHTTPClient()
    assert client is client2



# Generated at 2022-06-22 03:44:03.601921
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-22 03:44:04.718009
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()



# Generated at 2022-06-22 03:44:12.860507
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "https://www.google.com"
    method = "GET"
    headers = None
    body = None
    auth_username = None
    auth_password = None
    auth_mode = None
    connect_timeout = None
    request_timeout = None
    if_modified_since = None
    follow_redirects = None
    max_redirects = None
    user_agent = None
    use_gzip = None
    network_interface = None
    streaming_callback = None
    header_callback = None
    prepare_curl_callback = None
    proxy_host = None
    proxy_port = None
    proxy_username = None
    proxy_password = None
    proxy_auth_mode = None
    allow_nonstandard_methods = None
    validate_cert = None

# Generated at 2022-06-22 03:44:26.169190
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import bind_sockets
    from tornado.tcpserver import TCPServer
    from tornado.testing import AsyncTestCase, bind_unused_port

    def handle_stream(stream: IOStream, address: Any) -> None:
        # Consume the entire request body to avoid hanging the test.
        stream.read_until_close(callback=lambda data: None)

    class TestServer(TCPServer):
        def handle_stream(self, stream: IOStream, address: Any) -> None:
            handle_stream(stream, address)


# Generated at 2022-06-22 03:44:38.684346
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    response = HTTPResponse(
        request = HTTPRequest(
            url = "http://www.example.com",
            method = "GET",
        ),
        code = 200,
        reason = "OK",
        headers = httputil.HTTPHeaders(),
        effective_url = "http://www.example.com",
        buffer = BytesIO(),
        request_time = 0.5,
        start_time = 1531533151,
        time_info = {
            "namelookup": 0.1,
            "connect": 0.2,
            "appconnect": 0.3,
            "pretransfer": 0.4,
        },
    )
    assert response.request.url == "http://www.example.com"
    assert response.request.method == "GET"
    assert response.effective

# Generated at 2022-06-22 03:44:51.223893
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    def body_producer(write):
        print("write")
        return write("write")
    import functools

# Generated at 2022-06-22 03:44:52.612535
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    class_ = HTTPResponse
    assert class_.__repr__()



# Generated at 2022-06-22 03:45:05.608135
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    """
    # Unit test of constructor of class HTTPResponse
    """
    request = HTTPRequest('url')
    
    code = 200
    headers = httputil.HTTPHeaders()
    request_time = 12.3
    time_info = {'total':3.14}
    reason = 'OK'
    start_time = time.time()
    buffer = BytesIO(b"I am a buffer")
    print('buffer=',buffer)
    print('buffer.getvalue()=',buffer.getvalue())
    res = HTTPResponse(request, code, headers, buffer, request_time=request_time,
                       time_info=time_info, reason=reason, start_time=start_time)
    print('res.code=',res.code)

# Generated at 2022-06-22 03:45:14.566937
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    # Note: This test requires that at least one header be set, otherwise
    # self.request.headers has a value of None and there's nothing to test.
    http_req = HTTPRequest('http://localhost',
                           headers={'Accept': 'text/html'})
    req_proxy = _RequestProxy(http_req, None)

    # If a value isn't set in the HTTPRequest, the default is used.
    assert req_proxy.proxy_host == None

    # If a value is set in the HTTPRequest, it overrides the default.
    assert "Accept" in req_proxy.headers
    http_req.proxy_host = "localhost"
    assert req_proxy.proxy_host == "localhost"



# Generated at 2022-06-22 03:45:15.815319
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    print(isinstance(AsyncHTTPClient(), AsyncHTTPClient))