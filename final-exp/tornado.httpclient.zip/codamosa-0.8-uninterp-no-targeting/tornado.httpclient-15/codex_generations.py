

# Generated at 2022-06-22 03:40:32.245340
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    try:
        http_client = HTTPClient()
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-22 03:40:36.533167
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import pytest
    import io
    import asyncio
    import tornado.web
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.gen
    import tornado.httpclient
    @tornado.gen.coroutine
    def f():
        http_client = tornado.httpclient.AsyncHTTPClient()
        response = yield http_client.fetch("https://www.baidu.com")
        assert response is not None
        print(response.body.decode())
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(f())
    print("AsyncHTTPClient.fetch test end")


# Generated at 2022-06-22 03:40:41.868825
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    a = dict(abc=123)
    req = HTTPRequest(url="http://google.ca")
    reqproxy = _RequestProxy(req, a)
    assert reqproxy.url == "http://google.ca"
    assert reqproxy.abc == 123
    assert reqproxy.def_ == None

# Generated at 2022-06-22 03:40:44.580441
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    class A(AsyncHTTPClient):
        pass
    a1 = A()
    a2 = A()
    assert a1 is a2



# Generated at 2022-06-22 03:40:45.270604
# Unit test for function main
def test_main():
    assert 0 == 1, "Failed"

# Generated at 2022-06-22 03:40:55.054031
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():

    # Arrange
    import tornado.web


    async def async_fetch_test():
        http_client = httpclient.AsyncHTTPClient()
        try:
            response = await http_client.fetch("https://www.google.com/")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)


    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            # Act
            async_fetch_test()
            self.write("Hello, world")


    def make_app():
        return tornado.web.Application([(r"/", MainHandler)])


    if __name__ == "__main__":
        app = make_app()
        app.listen(8888)
        tornado.ioloop

# Generated at 2022-06-22 03:40:59.897568
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    r = HTTPResponse(HTTPRequest("http://localhost:8080/"), 200)
    assert r.request.url == "http://localhost:8080/"
    assert r.code == 200
    assert r.reason == "OK"
    assert r.headers == httputil.HTTPHeaders()
    assert r.buffer == None
    assert r.effective_url == "http://localhost:8080/"
    assert r.error == None


# AsyncHTTPClient is a registered futures.Executor, so it can also be
# used with the `concurrent.futures` module
register(AsyncHTTPClient)



# Generated at 2022-06-22 03:41:01.808162
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    pass


# Generated at 2022-06-22 03:41:06.296459
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    """ method of class AsyncHTTPClient
    """
    # impl = None
    # kwargs = {}    
    # AsyncHTTPClient.configure(impl, **kwargs)
    # CoroutineResult(gen)
    gen_test_AsyncHTTPClient_fetch_impl = test_AsyncHTTPClient_fetch_impl()
    # run loop
    loop = asyncio.get_event_loop()
    loop.run_until_complete(gen_test_AsyncHTTPClient_fetch_impl)
    loop.close()
    
    
    
    


# Generated at 2022-06-22 03:41:07.900651
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    httpclient = AsyncHTTPClient()
    assert httpclient._closed == False
    httpclient.close()
    assert httpclient._closed == True


# Generated at 2022-06-22 03:42:22.420967
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest('http://example.com')
    response = HTTPResponse(request, 200, reason='OK')
    print(response)
test_HTTPResponse()

# Generated at 2022-06-22 03:42:23.891269
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
	pass



# Generated at 2022-06-22 03:42:26.723251
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    client = HTTPClient()
    assert isinstance(client, HTTPClient)
    assert not client._closed
    client.close()
    assert client._closed


# Generated at 2022-06-22 03:42:34.290058
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    import sys
    request = HTTPRequest(url='', method='GET')
    defaults = {"key1":1, "key2":2}
    request_proxy = _RequestProxy(request, defaults)
    for key in defaults.keys():
        if getattr(request_proxy, key) != None:
            print("Success.")
            sys.exit(0)
        else:
            print("Failed to get attrs from request_proxy.")
            sys.exit(1)
    # The test case below should not be executed.
    #assert(getattr(request_proxy, 'key1') == None)
    #assert(getattr(request_proxy, 'key2') == None)
    #assert(getattr(request_proxy, 'key3') == None)
    return
test__RequestProxy___getattr__()


# Generated at 2022-06-22 03:42:41.634345
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    """
    Unit test for method __getattr__ of class _RequestProxy
    """
    ioloop = tornado.ioloop.IOLoop.current()
    client = tornado.httpclient.AsyncHTTPClient(io_loop=ioloop)
    client.fetch("http://www.google.com")
    # ioloop.run_sync(lambda: client.fetch("http://www.google.com"))


# Generated at 2022-06-22 03:42:53.695489
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, io_loop: IOLoop, force_instance: bool, defaults: dict) -> None:
            self.initialize(defaults)
            if self._instance_cache is not None:
                self._instance_cache[io_loop] = self
    ioloop = IOLoop()
    client = TestAsyncHTTPClient(
        ioloop, force_instance=True, defaults=dict(user_agent="Unit Test"))
    assert client._instance_cache.get(ioloop) == client
    assert list(client._instance_cache.keys()) == [ioloop]
    client2 = TestAsyncHTTPClient(
        ioloop, force_instance=True, defaults=dict(user_agent="None"))

# Generated at 2022-06-22 03:42:54.689535
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    return None


# Generated at 2022-06-22 03:42:59.886576
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    url = "http://127.0.0.1:8888"
    hc = HTTPClient()
    print(hc.fetch(url).body)

test_HTTPClient_fetch()


# Generated at 2022-06-22 03:43:10.595148
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Create an instance of a subclass.
    import tornado.httpclient
    http_client = tornado.httpclient.AsyncHTTPClient()

    # Example of using an instance's method fetch.
    # try:
    #     response = await http_client.fetch("http://www.google.com/")
    # except httpclient.HTTPError as e:
    #     # HTTPError is raised for non-200 responses; the response
    #     # can be found in e.response.
    #     print("Error: " + str(e))
    # except Exception as e:
    #     # Other errors are possible, such as IOError.
    #     print("Error: " + str(e))
    pass

# Generated at 2022-06-22 03:43:13.656989
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    httpclient = HTTPClient()
    httpclient.close()
    # call
    httpclient.__del__()



# Generated at 2022-06-22 03:44:45.301291
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    pass



# Generated at 2022-06-22 03:44:47.019670
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    HTTPClient = httpclient.HTTPClient
    _closed = True
    _io_loop = IOLoop(make_current = False)

# Generated at 2022-06-22 03:44:49.666359
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    hc = HTTPClient()
    hc.close()
    hc.close() # no error

# Generated at 2022-06-22 03:44:53.358372
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    class X:
        def __init__(self):
            self.aa = 333
    a = X()
    r = HTTPResponse(a, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    r.__repr__()

# Generated at 2022-06-22 03:45:06.334185
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    """
    def test_HTTPClientError___repr__(self):
        # There is a cyclic reference between self and self.response,
        # which breaks the default __repr__ implementation.
        # (especially on pypy, which doesn't have the same recursion
        # detection as cpython).
        resp = httpclient.HTTPResponse(
            httpclient.HTTPRequest('GET', 'http://example.com/'), 200)
        err = httpclient.HTTPClientError(599, response=resp)
        self.assertEqual(str(err), 'HTTP 599: Unknown')
        self.assertEqual(repr(err), str(err))
    """

# Generated at 2022-06-22 03:45:14.878580
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    # Check the normal constructor
    r = HTTPResponse(None, 200, {}, None, None, None, 1.0, {}, "Reason", 2.0)
    assert r.body == b""
    assert r.request_time == 1.0
    assert r.reason == "Reason"
    assert r.start_time == 2.0

    # Check the error constructor
    r = HTTPResponse(None, 404, {}, None, None, None, 1.0, {}, "Reason", 2.0)
    assert r.error
    assert r.error.response is r
    r._error_is_response_code = False
    assert not r.error



# Generated at 2022-06-22 03:45:17.940889
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import unittest
    class _AsyncHTTPClientTestCase(unittest.TestCase):
        def test_close(self):
            ...

    test_module = _AsyncHTTPClientTestCase('test_close')
    test_module.test_close()

# Generated at 2022-06-22 03:45:18.943153
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():

    pass



# Generated at 2022-06-22 03:45:25.398692
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    instance = HTTPClientError(code = 1, message = None, response = None)
    assert isinstance(instance, HTTPClientError)
    assert isinstance(instance, Exception)
    assert instance.__repr__() == "HTTPClientError(code=1, message=None, response=None)"
    assert instance.__str__() == "HTTP 1: Unknown"

# Remaining tests for class HTTPClientError

# Generated at 2022-06-22 03:45:28.950540
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    cls = AsyncHTTPClient
    AsyncHTTPClient._instance_cache = {}
    cls = AsyncHTTPClient
    instance = cls(force_instance=True)
    assert isinstance(instance, AsyncHTTPClient)

# Generated at 2022-06-22 03:49:57.110532
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
	client = HTTPClient()
	client.close()

# Generated at 2022-06-22 03:49:59.626125
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    test_HTTPRequest = HTTPRequest('https://google.com')
    assert isinstance(HTTPClient().fetch(test_HTTPRequest), HTTPResponse)



# Generated at 2022-06-22 03:50:01.845511
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest('www.sina.com.cn')
    response = HTTPResponse(request, 200, reason='normal')
    print(response)


# Generated at 2022-06-22 03:50:04.765194
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    req = _RequestProxy(HTTPRequest('/a'), dict(b='/b', c='/c'))
    assert req.request.url == '/a'
    assert req.b == '/b'
    assert req.c == '/c'
    assert req.d is None



# Generated at 2022-06-22 03:50:16.654865
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    import json
    import tornado.ioloop
    import tornado.web
    import tornado.testing
    import tornado.httpserver

    class JsonHandler(tornado.web.RequestHandler):
        def get(self):
            self.set_header("Content-Type", "application/json")
            self.write(json.dumps({"headers": dict(self.request.headers)}))

    class JsonTest(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application([("/json", JsonHandler)])

        def initialize(self, impl):
            self.http_client = impl()
            self.http_client.initialize(defaults={"header1": "foo"})
