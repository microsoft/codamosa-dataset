

# Generated at 2022-06-22 03:40:53.276455
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import unittest
    from tornado.escape import utf8
    from tornado import gen
    from tornado.httpclient import HTTPResponse, HTTPRequest
    from tornado.httputil import _has_streaming_response
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import ResponseStartLine
    from tornado.httputil import _dechunk
    from tornado.httputil import _parse_response_start_line
    from tornado.httputil import _parse_headers
    from tornado.httputil import _parse_url_args
    from tornado.httputil import _parse_body_arguments
    from tornado.httputil import urlencode
    from tornado.http1connection import HTTP1ConnectionParameters
    from tornado.httpserver import HTTPServer
    from tornado.httpserver import _BadRequestException


# Generated at 2022-06-22 03:41:02.440452
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    req = HTTPRequest('http://www.baidu.com')
    req.proxy_host = '123.123.123.123'
    req.proxy_port = 3128
    req.proxy_username = 'my_name'
    req.proxy_password = 'my_password'
    req.proxy_auth_mode = 'basic'
    req.body = 'request body'
    req.method = 'POST'
    req.validate_cert = None  # type: ignore
    req.ca_certs = None
    req.client_key = 'hello'
    req.client_cert = 'world'
    req.ssl_options = SSLContext(PROTOCOL_TLSv1)
    req.expect_100_continue = False
    req.streaming_callback = None

# Generated at 2022-06-22 03:41:08.211478
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    """
    Tests the destructor of HTTPClient.  The destructor closes the
    HTTP client and loops.  Instead of writing a mock, we want to test
    if the destructor works as expected or if it throws an exception.
    """
    http_client = HTTPClient()
    http_client.close()


# Generated at 2022-06-22 03:41:13.482751
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    resp=HTTPResponse(None, 0)
    e=HTTPClientError(0, None, resp)
    if e.__repr__() != e.__repr__():
        # This will fail for some implementations of __repr__.
        # It's not clear that it's worth fixing i.e. by changing
        # the signature of __repr__ to return a str.
        pass

HTTPError = HTTPClientError


# Generated at 2022-06-22 03:41:16.632132
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    url='http://127.0.0.1:8888/'
    response=HTTPClient().fetch(url)
    # print(response.body)
    print(response.request_time)



# Generated at 2022-06-22 03:41:17.766432
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest('http://www.google.com', method='GET')
    _RequestProxy(request, {})



# Generated at 2022-06-22 03:41:21.551246
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    assert isinstance(AsyncHTTPClient(), AsyncHTTPClient)


# Generated at 2022-06-22 03:41:23.083950
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    error = HTTPClientError(404)
from typing import NamedTuple


# Generated at 2022-06-22 03:41:24.751714
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    hc = HTTPClient()
    hc.close()

# Generated at 2022-06-22 03:41:30.029924
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    global http_client

    http_client = AsyncHTTPClient()
    try:
        response = http_client.fetch("http://www.baidu.com/", raise_error=False)
        print(type(response))
        print(response)
    except Exception as e:
        print("Error: %s" % e)


if __name__ == "__main__":
    test_AsyncHTTPClient_fetch()

# Generated at 2022-06-22 03:41:36.552328
# Unit test for function main
def test_main():
    from tornado.testing import main

    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 03:41:48.725452
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    ioloop = IOLoop.current()
    httpclient = AsyncHTTPClient()
    httpclient.close()
    httpclient.initialize()

# Generated at 2022-06-22 03:41:57.112162
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    @gen.coroutine
    def test():
        AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
        http_client = AsyncHTTPClient()
        request = HTTPRequest("http://www.google.com/")
        response = yield http_client.fetch(request)
        print(response.body)

    IOLoop.instance().run_sync(test)

# Generated at 2022-06-22 03:41:58.965989
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    http_client.close()

# Generated at 2022-06-22 03:42:00.272412
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    AsyncHTTPClient(force_instance=True)

# Generated at 2022-06-22 03:42:04.040878
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    # type: () -> None
    """
    >>> str(HTTPClientError(555, 'foo'))
    'HTTP 555: foo'
    >>> str(HTTPClientError(555, 'foo', HTTPResponse(HTTPRequest('http://example.com'), 555, 'foo')))
    'HTTP 555: foo'
    """
    pass



# Generated at 2022-06-22 03:42:07.613688
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    http_client.fetch('http://www.baidu.com', callback=print_response, method='GET')


# Generated at 2022-06-22 03:42:11.037213
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    client_1 = AsyncHTTPClient()
    request = HTTPRequest('https://www.baidu.com', method='GET')
    callback = lambda x: None
    assert client_1.fetch_impl(request, callback) == None


# Generated at 2022-06-22 03:42:15.152865
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    """Test the constructor of class HTTPRequest

    :return: No Return
    """
    http_request_object = HTTPRequest("http://www.google.com")
    # print(json.dumps(http_request_object, default=lambda o: o.__dict__, sort_keys=True, indent=4))



# Generated at 2022-06-22 03:42:19.361662
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    response = HTTPResponse(None, 200)
    assert str(response)


# Create missing methods of pycurl to satisfy the type checker
# These methods aren't called in practice

# Generated at 2022-06-22 03:42:33.802916
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    class AAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, defaults: Optional[Dict[str, Any]] = None) -> None:
            pass
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass
    a1 = AAsyncHTTPClient()
    a2 = AAsyncHTTPClient()
    assert a1 is a2
    a3 = AAsyncHTTPClient(force_instance=True)
    assert a1 is not a3
    a4 = AAsyncHTTPClient(force_instance=True)
    assert a4 is not a3


# Generated at 2022-06-22 03:42:41.903848
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from tornado.httpclient import HTTPRequest
    request = HTTPRequest(url='http://www.baidu.com')
    http_client = HTTPClient()
    response = http_client.fetch(request)
    assert response.headers is not None
    assert response.body is not None
    assert response.effective_url == 'http://www.baidu.com/'
    assert response.code == 200
    print(response.body)
    http_client.close()

# Generated at 2022-06-22 03:42:46.011537
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    # type: () -> None
    with HTTPClient() as http_client:
        http_client.fetch('http://www.google.com/')


# Patch self._async_client's fetch method to raise an error if called.

# Generated at 2022-06-22 03:42:56.111936
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    headers = httputil.HTTPHeaders()
    headers.add("Free", "Beer")
    headers.add("Star", "Wars")
    request = HTTPRequest("https://www.google.com")
    buffer = BytesIO()

    response = HTTPResponse(
        request,
        code = 200,
        headers = headers,
        buffer = buffer,
        effective_url = "https://www.google.com?query=true",
        error = None,
        request_time = 1,
        reason = "OK",
        time_info = {"queue": 100, "app connect": 1234, "connect": 12, "start transfer": 3},
        start_time = 100
    )

    print(response.body)

# Generated at 2022-06-22 03:43:05.255153
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://www.google.com")
    response = HTTPResponse(request, 200)
    assert response.request == request
    assert response.code == 200
    assert response.reason == "OK"
    assert response.effective_url == request.url
    assert response.start_time is None
    assert response.time_info == {}
    assert response.headers == httputil.HTTPHeaders()
    assert response.body == b""
    assert response.error is None
    assert response.request_time is None

# Generated at 2022-06-22 03:43:18.556672
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado import simple_httpclient
    from tornado.httpclient import HTTPRequest
    http_client = AsyncHTTPClient()
    assert isinstance(http_client, simple_httpclient.SimpleAsyncHTTPClient)
    assert http_client._instance_cache is AsyncHTTPClient._async_clients()
    http_client.fetch("http://localhost/")
    http_client2 = AsyncHTTPClient()
    assert http_client is http_client2
    http_client3 = AsyncHTTPClient(force_instance=True)
    assert http_client3._instance_cache is None
    assert http_client is not http_client3
    assert isinstance(http_client3, simple_httpclient.SimpleAsyncHTTPClient)
    http_client3.fetch("http://localhost/")
    AsyncHTTPClient.configure(None)

# Generated at 2022-06-22 03:43:25.194571
# Unit test for constructor of class _RequestProxy

# Generated at 2022-06-22 03:43:33.937725
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    # check __getattr__ works
    class FakeRequest:
        def __init__(self):
            self.foo = 0
    fake_request = FakeRequest()
    request_proxy = _RequestProxy(fake_request, None)
    assert request_proxy.foo == 0
    # check __setattr__ works
    request_proxy.foo = 1
    assert fake_request.foo == 1
    # check __init__ works
    fake_defaults = {'foo': 2}
    request_proxy = _RequestProxy(fake_request, fake_defaults)
    assert request_proxy.foo == 1
    fake_request.foo = None
    assert request_proxy.foo == 2


# Generated at 2022-06-22 03:43:34.925334
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 03:43:42.465305
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    import requests
    url = 'http://httpbin.org/get'
    s = requests.Session()
    def test_1(url):
        return s.get(url)
    def test_2(url):
        return s.get(url)
    res1 = test_1(url)
    time.sleep(2)
    res2 = test_2(url)
    print('res2 is: %s' % (res2))

# sys.setrecursionlimit(3000)
# test_HTTPClient_close()



# Generated at 2022-06-22 03:47:41.257728
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.http1connection as http1connection
    from tornado.http1connection import HTTP1ConnectionParameters
    import tornado.httpserver as httpserver
    import tornado.httputil as httputil
    import tornado.netutil as netutil
    import tornado.websocket as websocket
    import tornado.iostream as iostream
    import logging
    import time
    import unittest
    import traceback
    import sys

    class HTTPServer(httpserver.HTTPServer):
        def __init__(self, io_loop=None, ssl_options=None, **kwargs):
            super().__init__(io_loop=io_loop, ssl_options=ssl_options, **kwargs)

# Generated at 2022-06-22 03:47:50.446799
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    headers = httputil.HTTPHeaders()
    headers['location'] = 'http://baidu.com'
    buffer = BytesIO()
    buffer.write('hello'.encode('utf8'))
    buffer.seek(0)
    time_info = {'queue': 1.0, 'connect': 2.0, 'processing': 3.0, 'total': 10.0}
    print(HTTPResponse(HTTPRequest(), 200, headers, buffer, 'http://baidu.com', None, 1.0, time_info, 'OK'))


# Generated at 2022-06-22 03:47:52.575988
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    response = http_client.fetch("http://www.google.com/")
    print(response.body)
    return response



# Generated at 2022-06-22 03:47:53.768120
# Unit test for function main
def test_main():
    try:
        print("running test_main")
        main()
        # no error, check value
        pass
    except Exception as e:
        raise



# Generated at 2022-06-22 03:48:06.577918
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.web import Application, RequestHandler

    import unittest

    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    import asyncio

    async def get(url):
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch(url)
        except Exception as e:
            print("Error: %s" % e)
            return False
        else:
            print(response.body)
            return True

    class MainHandler(RequestHandler):
        async def get(self):
            await asyncio.sleep(1)
            self.write(b"Hello, world")

    def make_app():
        return Application([("/", MainHandler)])


# Generated at 2022-06-22 03:48:07.187860
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-22 03:48:12.544651
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    instance = HTTPClientError(0, )
    assert repr(instance) == 'HTTP 0: Unknown'


# For backwards compatibility.  TODO: deprecate in favor of HTTPClientError.
HTTPError = HTTPClientError


# Generated at 2022-06-22 03:48:18.697448
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    
    async def f():
        import asyncio
        response = await AsyncHTTPClient().fetch('http://www.google.com')
        print(response.body)
    
    asyncio.get_event_loop().run_until_complete(f())

# Generated at 2022-06-22 03:48:22.458288
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    response = http_client.fetch("http://www.google.com/")
    http_client.close()
    print(response.body)


# Generated at 2022-06-22 03:48:34.180449
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.platform.asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()
    # Test that silence_logging doesn't silence the debug messages of child coroutines
    # not silence other messages
    test_AsyncHTTPClient_fetch_impl.num_calls = 0
    def async_coroutine():
        test_AsyncHTTPClient_fetch_impl.num_calls += 1
    class LoggingMixin(object):

        def _log(self, level, *args, **kwargs):
            if test_AsyncHTTPClient_fetch_impl.num_calls == 1:
                assert level == logging.DEBUG
            else:
                assert level == logging.INFO
            return self._orig_log(level, *args, **kwargs)