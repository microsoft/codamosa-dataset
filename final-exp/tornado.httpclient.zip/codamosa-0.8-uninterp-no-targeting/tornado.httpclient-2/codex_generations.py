

# Generated at 2022-06-22 03:40:32.940572
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    from datetime import datetime
    from tornado import stack_context
    from tornado.httpclient import HTTPError, HTTPResponse, AsyncHTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.ioloop import IOLoop
    from tornado.test.util import unittest
    import tornado.testing
    import types
    import json
    import urllib
    def HTTPClientError_json(self, *args, **kwargs):
        return json.dumps(self.__repr__())
    HTTPClientError_json.__name__ = HTTPClientError.__repr__.__name__
    HTTPClientError.__repr__ = types.MethodType(HTTPClientError_json, HTTPClientError)

# Generated at 2022-06-22 03:40:34.539844
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    pass


# Generated at 2022-06-22 03:40:36.796626
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient(async_client_class = AsyncHTTPClient)
    assert http_client._closed == False
    http_client.close()
    assert http_client._closed == True



# Generated at 2022-06-22 03:40:41.468502
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.gen import engine, Return
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import tornado.testing
    import tornado.httpclient

    def fetch_impl(self, request, callback):
        pass
    
    tornado.httpclient.AsyncHTTPClient.fetch_impl = fetch_impl
    class MyHTTPClientTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application()
    
        @gen_test
        def test_fetch_impl(self):
            client = tornado.httpclient.AsyncHTTPClient(self.io_loop)
            request = tornado.httpclient.HTTPRequest('http://127.0.0.1/')
            response = yield client.fetch(request)

# Generated at 2022-06-22 03:40:47.480707
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    password = 'password'
    username = 'username'
    # Init test arguments
    io_loop = IOLoop.current()

    async def make_client():
        http_client = AsyncHTTPClient(io_loop=io_loop)
        return http_client

    async def fetch_async(url, callback, **kwargs):
        http_client = await make_client()
        try:
            await http_client.fetch(url, callback)
        except HTTPError as e:
            callback(e)
        finally:
            http_client.close()

    async def fetch_coroutine(url, **kwargs):
        http_client = await make_client()
        try:
            return await http_client.fetch(url)
        finally:
            http_client.close()

    check_proxy = kw

# Generated at 2022-06-22 03:40:53.186297
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    req = HTTPRequest(url="http://www.google.com")
    res = HTTPResponse(request=req, code=200, headers={})
    #assert res.rethrow() is None
    res = HTTPResponse(request=req, code=500, headers={})
    #assert res.error is not None
    #assert res.rethrow() is not None


# Generated at 2022-06-22 03:40:59.562996
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    test_headers = {"TestHeader": "TestHeader_Value"}
    test_buffer = BytesIO("Test_Buffer")
    test_effective_url = "Test_effective_url"
    test_reason = "Test_reason"
    test_request_time = 12.34
    test_start_time = 56.78
    test_time_info = {"TestTimeInfo": 9.87}
    client = AsyncHTTPClient()
    def test_fetch():
        http_client = AsyncHTTPClient()
        response = http_client.fetch("http://www.google.com", raise_error=False)
        # check for return type of function
        assert isinstance(response, HTTPResponse), "HTTPResponse"
        assert response.code == 200
        # Check for Type of Class

# Generated at 2022-06-22 03:41:11.216031
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest('', '', headers=None, follow_redirects=True, max_redirects=5)
    response = HTTPResponse(request, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason='OK', start_time=None)
    assert repr(response) == "HTTPResponse(request_time=None,reason='OK',code=200,buffer=None,effective_url='',error=None,headers=None,request=<tornado.httpclient.HTTPRequest object at 0x000001D9524B68D0>,start_time=None,time_info={})"


# Generated at 2022-06-22 03:41:13.153084
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    from tornado.httpclient import HTTPClient
    http_client = HTTPClient()
    http_client.close()
    assert http_client._closed




# Generated at 2022-06-22 03:41:25.386382
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "https://github.com"
    method = "GET"
    headers = {"Accept": "*/*"}
    body = "body"
    auth_username = "username"
    auth_password = "password"
    auth_mode = "basic"
    connect_timeout = 10
    request_timeout = 10
    if_modified_since = datetime.datetime.now()
    follow_redirects = True
    max_redirects = 5
    user_agent = "user agent"
    use_gzip = 0
    network_interface = "eth0"
    proxy_host = "proxy_host"
    proxy_port = 80
    proxy_username = "proxy_username"
    proxy_password = "proxy_password"
    proxy_auth_mode = "basic"

# Generated at 2022-06-22 03:41:50.315781
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    temp_req = HTTPRequest("https://www.baidu.com", "GET", headers="{ 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36'}", if_modified_since="2020-08-05T22:00:00", decompress_response="True", validate_cert="True")
    temp_response = HTTPResponse(temp_req, 200, reason="OK")

# Generated at 2022-06-22 03:41:52.401435
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    b=HTTPClient()
    assert b.fetch("http://localhost:8090")


# Generated at 2022-06-22 03:41:58.432631
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    AsyncHTTPClient.configure(None, defaults=None)
    async_client = AsyncHTTPClient(force_instance=True, defaults=None)
    async_client = AsyncHTTPClient(force_instance=False, defaults=None)
    assert True



# Generated at 2022-06-22 03:42:02.515000
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    err = HTTPClientError(404, None, None)
    assert repr(err) == "HTTP 404: Not Found"
    assert str(err) == "HTTP 404: Not Found"
    assert err.code == 404
    assert err.message == "Not Found"
    assert err.response is None

HTTPError = HTTPClientError



# Generated at 2022-06-22 03:42:06.947235
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    http_response = HTTPResponse(None, None)
    print(http_response.__repr__())

# Generated at 2022-06-22 03:42:14.129923
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    assert HTTPClientError(404).code == 404
    assert HTTPClientError(404).message == 'Not Found'
    assert HTTPClientError(404, 'Test').message == 'Test'
    assert HTTPClientError(404).response == None
    assert HTTPClientError(404, response="test").response == "test"
    assert str(HTTPClientError(404)).startswith('HTTP 404:')
    assert repr(HTTPClientError(404)).startswith('HTTP 404:')
    assert HTTPClientError(404).args == (404, 'Not Found', None)

HTTPError = HTTPClientError



# Generated at 2022-06-22 03:42:19.359046
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    code = 500
    message = "Error message"
    response = "HTTPResponse"
    error = HTTPClientError(code, message, response)
    assert error.code == code
    assert error.message == message
    assert error.response == response

HTTPError = HTTPClientError



# Generated at 2022-06-22 03:42:19.966777
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 03:42:30.793448
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://www.example.com")
    rp = _RequestProxy(request, None)
    assert rp.url == request.url


# Generated at 2022-06-22 03:42:43.687804
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # 初始化
    io_loop = IOLoop()
    io_loop.make_current()
    io_loop.close()
    io_loop = IOLoop()
    io_loop.make_current()
    # 创建实例
    client = AsyncHTTPClient()
    # 获取url参数，从网页中获取
    url = "https://www.baidu.com/"
    req = HTTPRequest(url, method="GET")
    # 获取返回值
    resp = client.fetch(req)
    print(resp)
    # 将返回值转化为字符串形

# Generated at 2022-06-22 03:42:54.178438
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    try:
        raise HTTPClientError(404, 'A test message')
    except HTTPClientError as e:
        assert e.code == 404, e.code
        assert e.message == 'A test message', e.message
        assert e.response is None, e.response


HTTPError = HTTPClientError



# Generated at 2022-06-22 03:42:58.359940
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    pass

_RequestProxy = collections.namedtuple("_RequestProxy", ("request",))



# Generated at 2022-06-22 03:43:08.233732
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.util import _ObjectDict
    from tornado.httpclient import HTTPRequest, HTTPResponse
    
    @gen.coroutine
    def coroutine_test():
        print('Start coroutine_test')
        def callback(response: "HTTPResponse") -> None:
            print(response)
            print('Finish coroutine_test')
        a=AsyncHTTPClient()
        a.fetch_impl(HTTPRequest(url="https://pypi.org/project/tornado/#files"), callback)
        yield gen.sleep(10)
    
    IOLoop.current().run_sync(coroutine_test)

# Generated at 2022-06-22 03:43:21.761935
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    # Unnamed argument
    bad_request_error = HTTPClientError(400)
    assert bad_request_error.code == 400
    assert bad_request_error.message == "Bad Request"
    assert bad_request_error.response is None

    # Named argument
    not_found_error = HTTPClientError(code=404, message="Not Found")
    assert not_found_error.code == 404
    assert not_found_error.message == "Not Found"
    assert not_found_error.response is None

    # Named argument with response
    request_timeout_error = HTTPClientError(code=599, message="timeout", response=None)
    assert request_timeout_error.code == 599
    assert request_timeout_error.message == "timeout"
    assert request_timeout_error.response is None


HTTPError = HTTP

# Generated at 2022-06-22 03:43:30.032283
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    import unittest.mock as mock
    response = HTTPResponse(
        request=mock.Mock(), 
        code=301, 
        headers=mock.Mock(), 
        buffer=mock.Mock(), 
        effective_url=mock.Mock(),
        error=mock.Mock(),
        request_time=mock.Mock(),
        time_info=mock.Mock(),
        reason=None,
        start_time=mock.Mock())
    with mock.patch.object(response, 'error') as fake_error:
        response.rethrow()
        assert fake_error.called


# Generated at 2022-06-22 03:43:30.983451
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    pass


# Generated at 2022-06-22 03:43:34.415257
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    #Defining the variables
    request = HTTPRequest(auth_mode='basic')
    defaults = {'auth_mode': 'basic'}
    request_proxy = _RequestProxy(request, defaults)
    #Using the method __getattr__
    assert(request_proxy.auth_mode == 'basic')
    return True

# Generated at 2022-06-22 03:43:39.426515
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest("http://example.com")
    defaults = {
        "auth_username": "foo",
        "auth_password": "bar",
        "auth_mode": "basic",
    }
    proxy = _RequestProxy(request, defaults)
    assert proxy.auth_username == "foo"
    assert proxy.auth_password == "bar"
    assert proxy.auth_mode == "basic"

    request.auth_username = "abc"
    request.auth_password = "def"
    request.auth_mode = "digest"
    assert proxy.auth_username == "abc"
    assert proxy.auth_password == "def"
    assert proxy.auth_mode == "digest"

    # Proxy without defaults should return None for unknown attributes.
    proxy2 = _RequestProxy(request, None)
    assert proxy

# Generated at 2022-06-22 03:43:40.726694
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass



# Generated at 2022-06-22 03:43:41.761506
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()



# Generated at 2022-06-22 03:44:00.001025
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    '''
    Tests
    - default handling
    - custom handling
    '''

# Generated at 2022-06-22 03:44:06.985495
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        import pycurl
    except ImportError:
        return
    class MockAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass
    response = MockAsyncHTTPClient().fetch("http://www.google.com/")
    assert isinstance(response, Future)
    assert response.done() == False
    with pytest.raises(NotImplementedError):
        MockAsyncHTTPClient().fetch_impl(HTTPRequest("http://www.google.com"), None)
# Unit tests for method close() of the class AsyncHTTPClient

# Generated at 2022-06-22 03:44:13.127464
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import asyncio
    from tornado.httpclient import AsyncHTTPClient
    async def main():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.baidu.com/")
            print(response.body)
        except Exception as e:
            # Other errors are possible, such as IOError.
            print("Error: " + str(e))
        http_client.close()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    loop.close()

# Generated at 2022-06-22 03:44:17.801054
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    a = AsyncHTTPClient()
    assert a.io_loop == IOLoop.current()
    assert a.defaults == dict(HTTPRequest._DEFAULTS)
    assert a._closed == False

# Generated at 2022-06-22 03:44:26.460730
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # The only purpose of this function is to help detect a change in
    # the method signature of AsyncHTTPClient, which can cause
    # incompatibilities when it is called by user code that was written
    # with an older signature in mind.  The error raised by the
    # interpreter will look like
    # 'TypeError: object.__new__() takes no parameters', but this is
    # not very specific to the situation, so we add a more specific
    # error message.
    AsyncHTTPClient(force_instance=True)  # type: ignore



# Generated at 2022-06-22 03:44:30.125071
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    def call_HTTPC():
        http_client = HTTPClient()
        response = http_client.fetch("http://www.google.com/")
        return response


# Generated at 2022-06-22 03:44:31.402571
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    instance = HTTPClient()
    instance.close()

# Generated at 2022-06-22 03:44:33.785848
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    """In this testcase, we test the method __new__ of class AsyncHTTPClient.
    """
    pass



# Generated at 2022-06-22 03:44:42.484866
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()

HTTPRequest = httputil.HTTPRequest

# Generated at 2022-06-22 03:44:54.888319
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
  http_client = httpclient.HTTPClient()
  try:
    response = http_client.fetch("http://www.google.com/")
    print(response.body)
  except httpclient.HTTPError as e:
    # HTTPError is raised for non-200 responses; the response
    # can be found in e.response.
    print("Error: " + str(e))
  except Exception as e:
    # Other errors are possible, such as IOError.
    print("Error: " + str(e))
  http_client.close()
   
if __name__ == '__main__':
  test_HTTPClient_fetch()
from tornado.concurrent import Future
from tornado.escape import utf8
from tornado import gen, httputil
from tornado.http1connection import HTTP1ServerConnection
from tornado import httpserver

# Generated at 2022-06-22 03:46:10.971318
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    c = HTTPClient()
    assert c._closed == True
    assert c._io_loop.make_current() == False
    assert c._async_client._closed == True
    assert c._io_loop.stop() == False
    assert c._closed == True

# Generated at 2022-06-22 03:46:18.283584
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    loop_ioloop = __import__("tornado", fromlist=["ioloop"]).ioloop.IOLoop()
    AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient")
    argument_HTTPRequest = __import__("tornado.httpclient", fromlist=["httpclient"]).httpclient.HTTPRequest("url", "method", "headers", "body", "auth_username", "auth_password")
    argument_request = "url"
    argument_raise_error = False
    argument_callback_impl = lambda response: None
    http_client = AsyncHTTPClient()
    # Test using argument 'request' as HTTPRequest
    future = http_client.fetch(argument_HTTPRequest, raise_error=argument_raise_error, callback=argument_callback_impl)
    assert future is not None
   

# Generated at 2022-06-22 03:46:21.531369
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient(force_instance=True)
    AsyncHTTPClient(raise_error=False, force_instance=True)
    assert AsyncHTTPClient._async_clients()


# Generated at 2022-06-22 03:46:23.956219
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    request = HTTPRequest('http://www.baidu.com')
    defaults = {'connect_timeout': 0.2}
    req = _RequestProxy(request, defaults)
    assert req.connect_timeout == 0.2
    assert req.request.connect_timeout == 0.2
    assert req.url == 'http://www.baidu.com'
    assert req.body is None

test__RequestProxy()

# Generated at 2022-06-22 03:46:24.367863
# Unit test for function main
def test_main():
    return

# Generated at 2022-06-22 03:46:28.461523
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    exc = HTTPClientError(500)
    assert exc.code == 500
    assert exc.message == "Internal Server Error"
    assert exc.response is None

    exc = HTTPClientError(599)
    assert exc.code == 599
    assert exc.message == "Unknown"
    assert exc.response is None

HTTPError = HTTPClientError



# Generated at 2022-06-22 03:46:33.355685
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    import unittest

    class Test_RequestProxy___getattr__(unittest.TestCase):

        # Test method __getattr__ of class _RequestProxy
        def test__RequestProxy___getattr__(
            self
        ) -> None:
            request = object()
            defaults = {}
            _req = _RequestProxy(
                request=request,
                defaults=defaults,
            )

            request_attr = object()
            name = "name"
            setattr(request, name, request_attr)
            self.assertEqual(_req.__getattr__(name), request_attr)

            request_attr = None
            setattr(request, name, request_attr)
            self.assertEqual(_req.__getattr__(name), None)

            request_attr = None

# Generated at 2022-06-22 03:46:45.672023
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from tornado.httpclient import HTTPRequest
    from tornado.testing import AsyncHTTPTestCase
    
    # Test Request
    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("hello main page")
    class HelloHandler(tornado.web.RequestHandler):
        def get(self,name):
            self.write("hello"+name)
    class NameHandler(tornado.web.RequestHandler):
        def get(self,name):
            self.write("my name is "+name)
    class Application(tornado.web.Application):
        def __init__(self):
            handlers = [
                (r"/",MainHandler),
                (r"/hello/(\w+)",HelloHandler),
                (r"/name/(\w+)",NameHandler)
            ]
           

# Generated at 2022-06-22 03:46:47.835580
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    req = HTTPRequest('http://example.com/')
    res = HTTPResponse(req, 200)
    print(res)


# Generated at 2022-06-22 03:46:56.649050
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    http_client = AsyncHTTPClient()