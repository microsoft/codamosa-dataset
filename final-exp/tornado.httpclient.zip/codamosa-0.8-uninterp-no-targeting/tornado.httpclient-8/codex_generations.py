

# Generated at 2022-06-22 03:40:56.084477
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('https://api.ipify.org', method='GET')
    code = 200
    headers = httputil.HTTPHeaders({'Content-Length':'31', 'Content-Type':'text/html; charset=UTF-8'})
    buffer = io.BytesIO('{"errorCode":0,"errorMsg":null}')
    effective_url = 'https://api.ipify.org'
    error = None
    request_time = None
    time_info = {}
    reason = 'OK'
    start_time = None

    response = HTTPResponse(request, code, headers=headers, buffer=buffer, effective_url=effective_url, error=error, request_time=request_time, time_info=time_info, reason=reason, start_time=start_time)

    response.re

# Generated at 2022-06-22 03:41:01.938305
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    import sys
    import io

# Generated at 2022-06-22 03:41:06.217998
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    client = HTTPClient()
    assert client._closed == True
    assert client._io_loop.make_current == False
    client._io_loop.close()
    client._closed = False



# Generated at 2022-06-22 03:41:08.247594
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    assert True

_MIN_SUPPORTED_VERSION = (7, 33, 0)
_MIN_SUPPORTED_VERSION_STR = ".".join(str(i) for i in _MIN_SUPPORTED_VERSION)



# Generated at 2022-06-22 03:41:12.306023
# Unit test for method __getattr__ of class _RequestProxy

# Generated at 2022-06-22 03:41:16.729302
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    r = _RequestProxy(None, {})
    p = _RequestProxy(r, {})
    assert p.request == r
    assert p.defaults == {}
    assert p.url == None
    assert p.method == None
    assert p.body == None
    assert p.body_producer == None
    assert p.auth_username == None
    assert p.auth_password == None
    assert p.auth_mode == None
    assert p.connect_timeout == None
    assert p.request_timeout == None
    assert p.follow_redirects == None
    assert p.max_redirects == None
    assert p.user_agent == None
    assert p.use_gzip == None
    assert p.network_interface == None
    assert p.streaming_callback == None
    assert p.header_callback

# Generated at 2022-06-22 03:41:29.675481
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import asyncio
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    
    client = AsyncHTTPClient()
    request = HTTPRequest(url="https://www.baidu.com/img/bd_logo1.png", method='GET')
    response = client.fetch(request)
    print(response)
    # asyncio.get_event_loop().run_forever()



# Generated at 2022-06-22 03:41:35.112881
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest(url="http://example.com", method="get")
    response = HTTPResponse(
        request, code=200, reason="OK", start_time=1.0, request_time=1.5
    )
    assert response.code == 200
    assert response.code == 200
    assert response.request_time == 1.5



# Generated at 2022-06-22 03:41:48.404608
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_tornado_future
    import asyncio
    import pytest
    import time
    import timeit
    try:  # Python >= 3.8
        from asyncio import all_tasks
    except ImportError:  # Python < 3.8
        from asyncio import Task
        def all_tasks(loop):
            return set(Task.all_tasks(loop))
    loop = asyncio.get_event_loop()
    AsyncIOMainLoop().install()
    http_client = AsyncHTTPClient()
    request = HTTPRequest(url="http://www.google.com/")
    async def fetch_future():
        return await http_client.f

# Generated at 2022-06-22 03:41:56.289629
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    # type: () -> None
    assert repr(HTTPResponse(HTTPRequest("GET", "http://localhost"), 404)) == "HTTPResponse(buffer=None,code=404,error=None,headers={},request=<tornado.httpclient.HTTPRequest object at 0x00000000025FBE10>,request_time=None,time_info={},effective_url='http://localhost',reason='Not Found')"

# Generated at 2022-06-22 03:42:15.322051
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # initialize(self, defaults: Optional[Dict[str, Any]] = None) -> None
    client = AsyncHTTPClient()
    client.initialize(defaults={"timeout":12})

# Generated at 2022-06-22 03:42:22.375665
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    print("start test method close of class HTTPClient")
    # initilize a object of class HTTPClient
    http_client = HTTPClient()
    # assert that this object is not closed
    assert http_client._closed != True
    # call method close
    http_client.close()
    # assert this object was closed
    assert http_client._closed == True
    print("done the test method close of class HTTPClient")
    pass


# Generated at 2022-06-22 03:42:30.773256
# Unit test for function main
def test_main():
    from tornado.options import define, options, parse_command_line
    define("print_headers", type=bool, default=False)
    define("print_body", type=bool, default=True)
    define("follow_redirects", type=bool, default=True)
    define("validate_cert", type=bool, default=True)
    define("proxy_host", type=str)
    define("proxy_port", type=int)
    args = parse_command_line()
    client = HTTPClient()

# Generated at 2022-06-22 03:42:43.685355
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-22 03:42:53.233436
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # Fetch a page
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()
# End of test



# Generated at 2022-06-22 03:42:57.103426
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    # the class is private, so we still test the public functionality
    r = HTTPRequest(url="http://example.com/")
    p = _RequestProxy(r, {"hello": "world"})
    assert p.url == "http://example.com/"
    assert p.hello == "world"
    assert p.world == None

# Generated at 2022-06-22 03:43:02.750052
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    r = HTTPResponse(request=None, code=200)
    assert r.code == 200

# === HTTP CLIENT OBJECTS ===

# FIXME: 'host' is confusing since it could be a hostname or a
# full uri (with scheme).  httpclient should probably only work with
# urls.



# Generated at 2022-06-22 03:43:13.775274
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    assert len(AsyncHTTPClient._async_clients()) == 0
    for i in range(10):
        a = AsyncHTTPClient()
    assert len(AsyncHTTPClient._async_clients()) == 1
    assert AsyncHTTPClient._async_clients()[IOLoop.current()] is a
    b = AsyncHTTPClient(force_instance=True)
    assert b._instance_cache is None
    assert a is not b
    b.close()
    assert AsyncHTTPClient._async_clients()[IOLoop.current()] is a
    a.close()
    assert len(AsyncHTTPClient._async_clients()) == 0



# Generated at 2022-06-22 03:43:17.284831
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    def foo():
        http_client = HTTPClient()
        http_client.close()
        assert http_client._closed == True

    foo()


# Generated at 2022-06-22 03:43:18.614192
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()



# Generated at 2022-06-22 03:44:31.314730
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = tornado.httpclient.HTTPRequest('url', 'method')
    defaults = {'connect_timeout': 7.0}
    proxy = tornado.httpclient._RequestProxy(request, defaults)

    assert(proxy.connect_timeout == 7.0)
    assert(proxy.request_timeout == request.request_timeout)


# constants from the curl C library, stolen from pycurl
CURL_SSLVERSION_TLSv1 = 1
CURL_SSLVERSION_SSLv2 = 2
CURL_SSLVERSION_SSLv3 = 3
CURL_SSLVERSION_DEFAULT = 0

# Curl doesn't have good constants for these.  The numbers come
# from curl_easy_setopt.html in the curl docs.
CURLPROTO_HTTP = 1
CURLPROTO_HTTPS = (1 << 1)
CURLPR

# Generated at 2022-06-22 03:44:39.761786
# Unit test for method close of class HTTPClient

# Generated at 2022-06-22 03:44:50.052047
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    # pylint: disable=unused-variable
    # pylint: disable=no-member
    http_error = HTTPClientError(500)
    http_error = HTTPClientError(500, message="The error message")
    http_error = HTTPClientError(500, message="The error message", response="The response")
    assert http_error.code == 500
    assert http_error.message == "The error message"
    assert http_error.response == "The response"
    # pylint: enable=unused-variable
    # pylint: enable=no-member


HTTPError = HTTPClientError



# Generated at 2022-06-22 03:45:03.016453
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    from tornado import httpclient
    request = httpclient.HTTPRequest(
        url='http://www.baidu.com',
        connect_timeout=10.0,
        request_timeout=10.0,
        decompress_response=True,
        proxy_host='127.0.0.1',
        proxy_port=1080,
        proxy_username='user',
        proxy_password='password',
        proxy_auth_mode='basic',
        allow_nonstandard_methods=True,
        validate_cert=True,
        ca_certs='ca_certs',
        allow_ipv6=True,
        client_key='client_key',
        client_cert='client_cert',
        auth_username='',
        auth_password='',
        auth_mode='basic',
    )
    response = http

# Generated at 2022-06-22 03:45:06.752576
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest("https://www.cnblogs.com/python-test/")
    response = HTTPResponse(request, 301)
    assert repr(response) == "HTTPResponse(code=301,error=None,request=<tornado.httputil.HTTPRequest object at 0x7f126a390a10>,request_time=None)"



# Generated at 2022-06-22 03:45:17.136916
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest('https://www.baidu.com', method='GET')
    code = 200
    headers = {'a': 1, 'b': 2}
    buffer = BytesIO(b'aaa')
    error = None
    request_time = 0.1
    time_info = {'a': 0.1, 'b': 0.2}
    reason = 'OK'
    start_time = 0

    response = HTTPResponse(request, code, headers, buffer, error, request_time, time_info, reason)
    assert response.request == request
    assert response.code == code
    assert response.headers == headers
    assert response.body == buffer.getvalue()
    assert response.error == error
    assert response.request_time == request_time
    assert response.time_info == time_info

# Generated at 2022-06-22 03:45:28.549555
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    # from .. import httputil
    # from . import HTTPRequest
    # from . import HTTPError

    request = HTTPRequest('/')
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url = 'http://localhost:1234/'
    error = HTTPError(404)
    request_time = 2
    time_info = {}
    reason = "reason"
    start_time = 1

    # test all args
    response1 = HTTPResponse(request, code, headers, buffer, effective_url, error,
                             request_time, time_info, reason, start_time)
    assert response1.request == request
    assert response1.code == code
    assert response1.reason == reason
    assert response1.headers == headers
    assert response1

# Generated at 2022-06-22 03:45:41.445702
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Test that an HTTP client can make a request to a server
    # and get a response back.
    # TODO: This test is not very robust because it doesn't necessarily
    # exercise code in other parts of AsyncHTTPClient.
    io_loop = IOLoop()  # type: IOLoop
    io_loop.make_current()
    server = HTTPServer()
    server.listen(TEST_PORT)
    io_loop.add_callback(HTTPRequest, callback=stop)

    def on_fetch(f: Future[HTTPResponse]) -> None:
        response = f.result()
        self.assertEqual(response.body, b"")
        self.assertEqual(response.request_time, 0)
        self.assertNotEqual(response.code, 599)
        server.stop()

# Generated at 2022-06-22 03:45:47.354326
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()
test_HTTPClient_fetch()


# Generated at 2022-06-22 03:45:51.729371
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    """
    Test the method __getattr__ of class _RequestProxy.
    """
    pass
# End of test for method __getattr__ of class _RequestProxy


# TODO: move user_agent_header, default_user_agent, and parse_user_agent
# back down into SimpleAsyncHTTPClient (which is the only place they're used)



# Generated at 2022-06-22 03:49:02.161234
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    
    class AsyncHTTPClientTest(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application([])
        
        @tornado.testing.gen_test
        def test_fetch(self):
            response = yield self.http_client.fetch(self.get_url('/'))
            self.assertEqual(response.code, 200)
            self.assertEqual(response.body, b'Hello world')
    
    test = AsyncHTTPClientTest()
    test.test_fetch()


# Generated at 2022-06-22 03:49:03.877827
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    from tornado._httpclient import HTTPClientError
    assert HTTPClientError(500, message="Internal Server Error").__repr__() == "HTTP 500: Internal Server Error"


HTTPError = HTTPClientError



# Generated at 2022-06-22 03:49:04.858959
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass



# Generated at 2022-06-22 03:49:10.125266
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    a=HTTPResponse(request=HTTPRequest("http://localhost:8000/"), code=404)
    assert a.error is None
    a.rethrow()
    assert a.error



# Generated at 2022-06-22 03:49:15.558834
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    init = AsyncHTTPClient.initialize
    instance = AsyncHTTPClient()
    assert callable(init)
    #args
    assert init(instance) == None
    #kwargs
    assert init(instance, defaults={}) == None
    #args and kwargs
    assert init(instance, None) == None


# Generated at 2022-06-22 03:49:16.593857
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    x = HTTPClient()


# Generated at 2022-06-22 03:49:28.093062
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = '10.8.1.1:80'
    method = 'GET'
    headers = httputil.HTTPHeaders()
    body = 'test'
    auth_username = 'user.name'
    auth_password = 'password'
    auth_mode = 'basic'
    connect_timeout = 5.0
    request_timeout = 5.0
    if_modified_since = time.time()
    follow_redirects = True
    max_redirects = 5
    user_agent = 'test'
    use_gzip = True
    network_interface = 'localhost'
    streaming_callback = lambda x: None
    header_callback = lambda x: None
    prepare_curl_callback = lambda x: None
    proxy_host = '10.8.1.1'
    proxy_port = 80


# Generated at 2022-06-22 03:49:34.330229
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # Additional kwargs are passed to the constructor and may be tested.
    # The first arg of configure() sets the implementation class.
    AsyncHTTPClient.configure("tornado.test.httpclient_test.DummyAsyncHTTPClient")



# Generated at 2022-06-22 03:49:37.098216
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    #__new__ is tested in the constructor
    pass

# Generated at 2022-06-22 03:49:46.937498
# Unit test for function main
def test_main():
    def FakeHandler(*args,**kwargs):
        pass
    request=HTTPRequest(path='/test/test')
    response=HTTPResponse(request,code=200,headers={'a':1})
    truncate_fun=MagicMock(return_value="")
    with patch('tornado.httpclient.HTTPClient.fetch',return_value=response),\
    patch('builtins.print',truncate_fun), \
    patch('tornado.httpserver.HTTPRequest.uri',return_value=''):
        main()
        assert truncate_fun.call_args_list[0][0][0]==""
test_main()