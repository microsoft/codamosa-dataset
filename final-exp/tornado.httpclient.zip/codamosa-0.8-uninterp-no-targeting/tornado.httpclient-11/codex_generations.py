

# Generated at 2022-06-22 03:40:45.352678
# Unit test for function main
def test_main():
    # type: () -> None
    """Unit test for function main"""
    import tornado.testing
    from tornado.escape import utf8, _unicode  # type: ignore
    import io

    class MainTest(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application()

        def test_main(self):
            old_stdout = sys.stdout

# Generated at 2022-06-22 03:40:49.476645
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request=HTTPRequest("http://www.google.com")
    #repr(request)
    #print(request)
    #my_request=request
    #request = HTTP_Request("http://www.google.com")
    #print(request == my_request)
    code=200
    headers=httputil.HTTPHeaders()
    buffer=BytesIO()
    effective_url="http://www.google.com"
    error=None
    request_time=0.44444444
    time_info={"queue":0.111111111,"namelookup":0.22222222,"connect":0.33333333,"pretransfer":0.44444444,"starttransfer":0.55555555,"total":0.66666666}
    reason="OK"
    start_time=time.time()
   

# Generated at 2022-06-22 03:40:57.330647
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    async def async_http_client():
        return AsyncHTTPClient()
    httpclient = HTTPClient(async_client_class=async_http_client)
    httpclient.close()
    assert httpclient._closed == True
    httpclient = HTTPClient()
    assert httpclient._closed ==False
    httpclient.close()
    assert httpclient._closed == True
    del httpclient
    httpclient = HTTPClient(async_client_class=async_http_client)
    httpclient.close()
    assert httpclient._closed == True
    httpclient = HTTPClient()
    assert httpclient._closed ==False
    httpclient.close()
    assert httpclient._closed == True

# Generated at 2022-06-22 03:40:59.359801
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    client = AsyncHTTPClient()
    url = "http://www.baidu.com"
    client.fetch(url)

# Generated at 2022-06-22 03:41:05.845583
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    import unittest
    from httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.test.util import unittest
    import io


    class AsyncHTTPClientTest(unittest.TestCase):
        def test_initialize(self):
            client = AsyncHTTPClient()
            self.assertTrue(client.defaults is not None)
            self.assertTrue(HTTPRequest._DEFAULTS["allow_nonstandard_methods"])
            client.close()

            client = AsyncHTTPClient(allow_nonstandard_methods=False)
            self.assertFalse(client.defaults["allow_nonstandard_methods"])
            client.close()

            client = AsyncHTTPClient(
                defaults={"user_agent": "foo", "allow_ipv6": False}
            )
            self.assertE

# Generated at 2022-06-22 03:41:09.714453
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # test initialize with defaults=None and **kwargs
    AsyncHTTPClient.configure(None, defaults=dict(user_agent="MyUserAgent"))
    client = AsyncHTTPClient(force_instance=True,
        defaults=dict(user_agent="MyUserAgent"))
    client.initialize()
    client.initialize(defaults={"user_agent": "MyUserAgent"})


# Generated at 2022-06-22 03:41:12.357716
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # TODO: Would like to test the method initialize of class AsyncHTTPClient
    #       but don't know what to test for.
    pass


# Generated at 2022-06-22 03:41:16.806910
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    class HTTPRequest:
        ''' Dummy HTTPRequest class for testing 
        '''
        def __init__(self, defaults: Optional[Dict[str, Any]] = None) -> None:
            self.defaults = defaults
        
        def __getattr__(self, name: str) -> Any:
            return self.defaults.get(name, None)
    
    #  Initialization of the request object to be tested
    sample_dict = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}
    test_request = HTTPRequest(defaults=sample_dict)
    
    #  Initialization of the _RequestProxy object to be tested
    test_request_proxy = _RequestProxy(test_request, sample_dict)
    
    #  Testing of an existing key

# Generated at 2022-06-22 03:41:18.173813
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    client = AsyncHTTPClient()
    assert client is not None



# Generated at 2022-06-22 03:41:22.415196
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Test of method __new__ of class  AsyncHTTPClient
    pass


# Generated at 2022-06-22 03:41:33.715009
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient", max_clients=32)
    print(AsyncHTTPClient.configured_class())
    print(AsyncHTTPClient.configured_class().__qualname__)
    return AsyncHTTPClient.configured_class().__qualname__ == "CurlAsyncHTTPClient"


# Generated at 2022-06-22 03:41:47.226513
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    AsyncHTTPClient.configure(None, max_clients=10)
    expected_response = '{"id": 1, "name": "A green door", "price": 12.50, "tags": ["home", "green"]}'

    @gen.coroutine
    def f():
        try:
            http_client = AsyncHTTPClient()
            response = yield http_client.fetch("http://rest-service.guides.spring.io/greeting")
        except Exception as e:
            print("Error: %s" % e)
        else:
            assert response.body == expected_response
            print(response.body)
        finally:
            http_client.close()

    IOLoop.current().run_sync(f)
test_AsyncHTTPClient_fetch()


# Generated at 2022-06-22 03:41:55.145605
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    request = HTTPRequest(url= "http://localhost:8080")
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO()
    effective_url= "http://localhost:8080"
    error = None
    request_time=None
    time_info = {}
    reason = "OK"
    start_time = None
    http_response = HTTPResponse(request, code, headers, buffer, effective_url, error,
                                 request_time, time_info, reason, start_time)

# Generated at 2022-06-22 03:41:59.358963
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    """Test for method __repr__ of class HTTPClientError"""
    r = HTTPClientError(1, "a", HTTPResponse(None, None, None, None, None, None, None, None, None, None ) )
    assert r.__repr__() == 'HTTP 1: a'


# Generated at 2022-06-22 03:42:06.413603
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    '''
    Test if initialize method of class AsyncHTTPClient initializes io_loop attribute.
    '''
    from tornado import ioloop
    from tornado.httpserver import HTTPServer
    from tornado.web import Application, RequestHandler

    class Handler(RequestHandler):
        '''
        Handler class to test HTTP request.
        '''
        def get(self):
            '''
            Test if get method returns 100 bytes of response.
            '''
            self.write("A" * 100)

    app = Application([(r"/", Handler)])
    default_server = HTTPServer(app)
    default_server.listen(8090)
    loop = ioloop.IOLoop.current()
    loop.start()


# Generated at 2022-06-22 03:42:16.320957
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        print("Error: " + str(e))
    except Exception as e:
        print("Error: " + str(e))
    http_client.close()
    # Prints out the following:
    # b'<!doctype html><html itemscope="" itemtype="http://schema.org/SearchResultsPage" lang="en"><head><meta content="Search the world\'s information, including webpages, images, videos and more. Google has many special features to help you find exactly what you\'re looking for." name="description">
    # ...
    # <meta content="//static.googleusercontent.com/images/google_favicon

# Generated at 2022-06-22 03:42:19.870113
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()  # type: ignore

# Was a configuration argument; now deprecated.
del AsyncHTTPClient.configurable_base



# Generated at 2022-06-22 03:42:20.547091
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    pass



# Generated at 2022-06-22 03:42:25.111900
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-22 03:42:35.770103
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():  # pragma: no cover
    def test():
        e = HTTPClientError(500)
        assert e.code == 500
        assert e.message != None
        assert e.response == None
        assert e.__str__() == str(e)
        assert e.__repr__() == str(e)
        assert e.__repr__() == e.__str__()
        assert e.__str__() == "HTTP 500: Internal Server Error"
        e = HTTPClientError(500, response="foo")
        assert e.code == 500
        assert e.message != None
        assert e.response == "foo"
        assert e.__str__() == str(e)
        assert e.__repr__() == str(e)
        assert e.__repr__() == e.__str__()
        assert e

# Generated at 2022-06-22 03:43:37.304626
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    response = HTTPResponse(HTTPRequest('http://www.douban.com'), 200, None, None, "http://www.douban.com/", None, 0, {"msg": "ok", "code": 0}, "success", 1.1)
    result = response.__repr__()
    assert result == "HTTPResponse(buffer=None,code=200,error=None,effective_url='http://www.douban.com/',headers={},request_time=0,request=<tornado.httpclient.HTTPRequest object at 0x7fe8a0c24a90>,reason='success',start_time=1.1,time_info={'msg': 'ok', 'code': 0})"

# Generated at 2022-06-22 03:43:38.680729
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    req = _RequestProxy(HTTPRequest(url="http://www.baidu.com/"), None)
    assert req is not None, "should be equal"


# Generated at 2022-06-22 03:43:43.561506
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    _HTTPClientError = HTTPClientError(
        code=403,
        message='HTTP 403: Forbidden',
        response=None)
    _repr = repr(_HTTPClientError)
    # TODO: add assert after repr implementation


HTTPError = HTTPClientError  # Deprecated alias.



# Generated at 2022-06-22 03:43:55.597650
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import json
    from collections import OrderedDict
    from tornado.httpclient import HTTPRequest
    from tornado import gen

    @gen.coroutine
    def fetch_coroutine(request_string, **kwargs):
        # print(str(request_string))
        http_client = HTTPClient()
        response = http_client.fetch(request_string, **kwargs)
        raise gen.Return(response)

    @gen.coroutine
    def fetch_coroutine_HTTPRequest(request, **kwargs):
        # print(request)
        http_client = HTTPClient()
        response = http_client.fetch(request, **kwargs)
        raise gen.Return(response)


# Generated at 2022-06-22 03:44:00.086986
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import time
    http_client = HTTPClient()
    # url = "https://www.baidu.com"
    url = "http://www.google.com/"
    print(http_client.fetch(url))
    time.sleep(5)
    http_client.close()
# test_HTTPClient_fetch()


# Generated at 2022-06-22 03:44:06.216937
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import asyncio
    loop = asyncio.get_event_loop()

    def fetch_impl(request, callback):
        # type: (HTTPRequest, Callable[[HTTPResponse], None]) -> None
        response = HTTPResponse(
            request, 200, buffer=BytesIO(b"hello world"))
        loop.call_soon(callback, response)

    client = AsyncHTTPClient()
    client.fetch_impl = fetch_impl
    loop.run_until_complete(client.fetch("http://example.com"))


#------------------------------------------------------------------------------
# Base request class
#------------------------------------------------------------------------------



# Generated at 2022-06-22 03:44:14.235653
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # constructor of class HTTPRequest
    req1 = HTTPRequest("http://www.google.com")

    # constructor of class AsyncHTTPClient
    # 默认用的是异步的实现方法
    async_client1 = AsyncHTTPClient()
    # 通过run_sync的方法可以同步的获取response
    resp1 = async_client1.fetch(req1)
    resp2 = async_client1.fetch(req1)
    resp3 = async_client1.fetch(req1)
    resp4 = async_client1.fetch(req1)
    resp5 = async_client1.fetch(req1)
    resp6 = async_client1.fetch(req1)
   

# Generated at 2022-06-22 03:44:16.657625
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    http_client.close()


# Generated at 2022-06-22 03:44:19.763457
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass

_REQUEST_CLASS = "tornado.httpclient.HTTPRequest"
_RESPONSE_CLASS = "tornado.httpclient.HTTPResponse"



# Generated at 2022-06-22 03:44:29.252352
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    client = HTTPClient()
    assert isinstance(client, HTTPClient)
    assert isinstance(client._async_client, AsyncHTTPClient)
    assert client._async_client.__class__.__name__ == 'SimpleAsyncHTTPClient'
    assert not isinstance(AsyncHTTPClient, SimpleAsyncHTTPClient)
    assert not isinstance(AsyncHTTPClient, CurlAsyncHTTPClient)
    assert not isinstance(CurlAsyncHTTPClient, SimpleAsyncHTTPClient)
    client.close()
    assert client._closed
    # test for constructor, __del__ and close()
