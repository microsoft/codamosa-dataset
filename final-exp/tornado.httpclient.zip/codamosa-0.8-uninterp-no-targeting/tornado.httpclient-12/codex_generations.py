

# Generated at 2022-06-22 03:40:44.191025
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    _response = HTTPResponse(HTTPRequest("a"), 200, None, None, None, None)
    try:
        _response.rethrow()
    except:
        pass
    else:
        assert 0, "Unit test_HTTPResponse_rethrow failed"


# Generated at 2022-06-22 03:40:45.398326
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    _ = AsyncHTTPClient()  # no error



# Generated at 2022-06-22 03:40:49.345864
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    http_client = HTTPClient()
    response = http_client.fetch('https://api.github.com/zen')
    print(response.body)
    http_client.close()
# test_HTTPClient_close()


# Generated at 2022-06-22 03:40:58.369624
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    assert AsyncHTTPClient().__class__.__name__ == "SimpleAsyncHTTPClient"
    AsyncHTTPClient.configure("tornado.test.test_httpclient.DummyAsyncHTTPClient")
    assert AsyncHTTPClient().__class__.__name__ == "DummyAsyncHTTPClient"
    import types
    assert isinstance(AsyncHTTPClient()._instance_cache, types.WeakKeyDictionary)
    assert AsyncHTTPClient.configured_class().__name__ == "DummyAsyncHTTPClient"
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    assert AsyncHTTPClient.configured_class().__name__ == "CurlAsyncHTTPClient"
    AsyncHTTPClient.configure(None)

# Generated at 2022-06-22 03:41:02.000821
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    from vcr.serializers import yamlserializer
    from vcr.stubs import VCRHTTPConnection
    msg = HTTPClientError(code=200)
    try:
        repr(msg)
    except TypeError:
        import pdb, sys; pdb.Pdb(stdout=sys.__stderr__).set_trace()  # XXX BREAKPOINT
    pass

# Generated at 2022-06-22 03:41:11.262673
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    response = HTTPResponse(
        request=HTTPRequest(
            url="http://www.baidu.com",
            method="GET",
            headers={"User_Agent": "http_client"}
        ),
        code=200,
        headers={"header": "value"},
        buffer="buffer",
        effective_url="effective_url",
        request_time=1,
        time_info={"a": 5},
        reason="reason"
    )
    assert response.request.method == "GET"
    assert response.headers["header"] == "value"



# Generated at 2022-06-22 03:41:12.421685
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    instance = AsyncHTTPClient()
    instance.initialize()


# Generated at 2022-06-22 03:41:17.888436
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    #https://github.com/pallets/werkzeug/blob/master/werkzeug/test.py
    #https://github.com/pallets/werkzeug/blob/master/werkzeug/test.py
    client = AsyncHTTPClient(force_instance=True)
    assert client.io_loop is IOLoop.current()
    assert isinstance(client, client.__class__)
    assert not hasattr(client, "defaults")


# Generated at 2022-06-22 03:41:23.636663
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    from tornado.httpclient import HTTPClient
    from .util import unittest
    from .httpclient_test import _TestHTTPClient
    class _TestHTTPClientImpl(_TestHTTPClient, HTTPClient):
        pass
    class __TestHTTPClient___del__(unittest.TestCase):
        def test_HTTPClient___del__1(self):
            _TestHTTPClientImpl()
    del _TestHTTPClientImpl


# Generated at 2022-06-22 03:41:26.586340
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    response=HTTPResponse(HTTPRequest(""), 200, {"aa":"aa"}, BytesIO())
    print(response.__repr__())


# Generated at 2022-06-22 03:42:00.407030
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    a=HTTPClientError(404,'Not Found')
    assert repr(a)=='HTTP 404: Not Found'

# Generated at 2022-06-22 03:42:05.437341
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(
        method="GET",
        url="http://localhost/local.html",
        headers={"Content-Type": "application/json"},
        body="",
        )
    # request_proxy = _RequestProxy(request, {})
    # print(request_proxy.request)
    # print(request_proxy.request.method)
    # print(request_proxy.method)
    # print(request_proxy.defaults)
    # print(request_proxy.defaults)


# Generated at 2022-06-22 03:42:15.488119
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    # class attributes are not tested
    response = HTTPResponse(request=HTTPRequest('GET', 'http://example.com'),
                            code=200,
                            headers={'Content-Type': 'text/html'},
                            buffer=BytesIO(),
                            effective_url='http://example.com/',
                            request_time=2,
                            time_info={},
                            reason='OK',
                            start_time=time.time())
    print(response)  # doctest: +ELLIPSIS
    # Output:
    # HTTPResponse(buffer=<_io.BytesIO object at ...>,
    #              code=200,
    #              effective_url='http://example.com/',
    #              error=None,
    #              headers={'Content-Type': 'text/html'

# Generated at 2022-06-22 03:42:20.915892
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    client = AsyncHTTPClient()
    future = client.fetch("http://www.google.com")
    response = future.result()
    assert response.code == 200
    assert b"Google" in response.body
    client.close()
# test_AsyncHTTPClient_fetch()



# Generated at 2022-06-22 03:42:29.025468
# Unit test for function main
def test_main():
    import subprocess
    import os.path
    import sys
    import tornado
    import tornado.httpserver
    import tornado.ioloop
    import tornado.websocket
    import tornado.web
    import tornado.testing
    import urllib
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import url_escape
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port
    from tornado.test.util import unittest

    class HelloWorldHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello world")

    class EchoHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(self.request.uri)

    class PostHandler(tornado.web.RequestHandler):
        def post(self):
            self

# Generated at 2022-06-22 03:42:29.749232
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    HTTPRequest("http://www.baidu.com")

# Generated at 2022-06-22 03:42:42.700665
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-22 03:42:54.523410
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    # curl_httpclient, simple_httpclient, httpplus
    import unittest
    import httpclient

    class HTTPRequestTest(unittest.TestCase):
        def setUp(self):
            import httpclient
            class MockHTTPClient(httpclient.AsyncHTTPClient):
                def __init__(self): pass
            self.client = MockHTTPClient()

        def test_HTTPRequest(self):
            request = httpclient.HTTPRequest("www.test.com", method="METHOD", headers={"a": "b"}, body="body")
            self.assertEqual("METHOD", request.method)

            import httpclient
            self.assertIsInstance(request.headers, httpclient.HTTPHeaders)
            self.assertIsInstance(request.headers, dict)


# Generated at 2022-06-22 03:43:08.426270
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient")
    http_client = AsyncHTTPClient()
    try:
        response = http_client.fetch("http://www.google.com")
        #response= http_client.fetch("https://api.ipify.org/?format=json")
        print(response.body)
    except Exception:
        # Other errors are possible, such as IOError.
        print("Error: ")
    #http_client.close()
test_AsyncHTTPClient_fetch()

#------------------------------------------------------------------------------
# Copyright (C) 2012-2013 Bloomberg Finance L.P.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to
# deal in the Software without restriction, including

# Generated at 2022-06-22 03:43:21.953140
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    import shutil
    import os
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tornado.testing
    import asyncio
    import sys
    import tornado.httpclient
    from tornado.platform.asyncio import AsyncIOMainLoop
    import unittest
    import uuid
    import pytest


    try:
        import aiohttp
    except ImportError:
        # aiohttp is not installed, so can't test the proxy
        # functionality.  Expect the test to be skipped.
        # In Windows, when this test is run in the CI environment,
        # ImportError will be raised because the aiohttp module
        # is not installed.
        pass


# Generated at 2022-06-22 03:43:45.821800
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # Use the class to ensure we don't get any instance-specific
    # kwargs for the call to _AsyncHTTPClientFactory.__new__
    obj = AsyncHTTPClient()

# Next two functions are copied from urllib.parse, but with all the
# caching and type-checking removed
_ALWAYS_SAFE = frozenset(b"ABCDEFGHIJKLMNOPQRSTUVWXYZ" b"abcdefghijklmnopqrstuvwxyz" b"0123456789" b"-_.!~*'()")  # type: Union[bytes, str]
_URL_SAFE = _ALWAYS_SAFE | frozenset(b"$&+,/:;=?@[]")  # type: Union[bytes, str]



# Generated at 2022-06-22 03:43:46.839386
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Nothing to do here
    pass


# Generated at 2022-06-22 03:43:57.816608
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url='www.example.com')
    response = HTTPResponse(request, 200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    response.rethrow()
    response = HTTPResponse(request, 404, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    try:
        response.rethrow()
        assert False
    except HTTPError as e:
        print(e)
        assert True



# Generated at 2022-06-22 03:44:02.314624
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    def f():
        http_client = AsyncHTTPClient()
        try:
            response = http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)
    test_AsyncHTTPClient_fetch.__dict__.update(locals())


# Generated at 2022-06-22 03:44:06.391853
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpserver import HTTPServer
    import tornado.web
    import tornado.escape

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            class DummyHandler(tornado.web.RequestHandler):
                def get(self):
                    self.write(tornado.escape.json_encode(args))

            return tornado.web.Application([('/', DummyHandler)],
                                           **app_settings)

        @gen_test
        def test_main(self):
            args.append(self.get_url('/'))
            main()
            args.append(self.get_url('/'))
            main()


# Generated at 2022-06-22 03:44:14.379709
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # Configuration of AsyncHTTPClient can happen at import time,
    # so for the following tests we need to save the state and restore it.
    old_config = AsyncHTTPClient._DEFAULT_IMPL  # type: Any

# Generated at 2022-06-22 03:44:16.657796
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    client = HTTPClient()
    client.close()

# Generated at 2022-06-22 03:44:17.669638
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    assert True


HTTPError = HTTPClientError



# Generated at 2022-06-22 03:44:19.186924
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass



# Generated at 2022-06-22 03:44:31.364556
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="http://www.example.com",method='POST')
    code = 200
    reason = "OK"
    headers = {}
    buffer = BytesIO()
    effective_url="http://www.example.com/"
    error = HTTPError(404, "Not Found")
    request_time = 2.33
    time_info = {'queue': 1.5, 'connect': 2.8, 'appconnect': 2.4, 'pretransfer': 3.2,
                 'starttransfer': 5.0, 'total': 5.0}
    start_time = time.time()

# Generated at 2022-06-22 03:45:05.200457
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    pass


# Generated at 2022-06-22 03:45:11.021752
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    def test_AsyncHTTPClient_fetch_handle_response(response: "HTTPResponse") -> None:
        # Expect that the response is an instance of HTTPResponse
        assert isinstance(response, HTTPResponse)

    req = HTTPRequest(url="http://www.google.com")
    client = AsyncHTTPClient()
    client.fetch_impl(request=req, callback=test_AsyncHTTPClient_fetch_handle_response)



# Generated at 2022-06-22 03:45:16.869495
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
  code = 404
  message = "Not found"
  response = None
  http_error = HTTPClientError(code, message, response)
  assert http_error.code == code
  assert http_error.message == message
  assert http_error.response == response

HTTPError = HTTPClientError  # an alias for backwards compatibility



# Generated at 2022-06-22 03:45:26.771630
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
  request = HTTPRequest(url='www.google.com')
  code = 200
  headers=None
  buffer=None
  effective_url=None
  error=HTTPError(500,'Intentionally made')
  request_time=10
  time_info = 'info'
  reason=None
  start_time=time.time()

  res = HTTPResponse(request=request,code=code,headers=headers,buffer=buffer,effective_url=effective_url,error=error,request_time=request_time,time_info=time_info,reason=reason,start_time=start_time)
  res.rethrow()
  assert True

# ------------------------------------------------- test_IOLoop

# Generated at 2022-06-22 03:45:35.841837
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    request = HTTPRequest("http://localhost")
    response = HTTPResponse(request, code=500, headers=None, buffer=None)
    assert response.request == request
    assert response.code == 500
    assert response.headers == httputil.HTTPHeaders()
    assert response.buffer == None
    assert response.body == b''
    assert response.effective_url == request.url
    assert response.error == HTTPError(500, message='Internal Server Error')
    assert response.request_time == None
    assert response.time_info == {}



# Generated at 2022-06-22 03:45:36.437333
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    pass



# Generated at 2022-06-22 03:45:44.759970
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    import pytest
    from tornado.testing import AsyncHTTPTestCase, gen_test

    # -- Unit test for method __del__ of class HTTPClient
    @gen_test
    async def test_gen(self) -> None:
        # Make sure HTTPClient.__del__ doesn't throw an exception
        # if the ioloop has been closed
        http_client = httputil.HTTPClient()
        await gen.sleep(0)
        http_client.close()
        await gen.sleep(0)
        del http_client
        await gen.sleep(0)
        assert 1 == 1



# Generated at 2022-06-22 03:45:48.829736
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest("http://github.com")
    response = HTTPResponse(request, code=200,
        headers=None, buffer=None, error=None,
        request_time=0, time_info=None, reason=None, start_time=None)
    response.rethrow()
    response = HTTPResponse(request, code=404,
        headers=None, buffer=None, error=None,
        request_time=0, time_info=None, reason=None, start_time=None)
    response.rethrow()


# Generated at 2022-06-22 03:46:00.115804
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url='url',method='get')# type: ignore
    code = 200
    reason = None
    headers = {'a':1}# type: ignore
    buffer = None
    effective_url = request.url
    error = None
    request_time = None
    time_info = None
    reason =None 
    start_time = time.time()
    response = HTTPResponse(request,
        200,
        headers,
        buffer,
        effective_url,
        error,
        request_time,
        time_info,
        reason,
        start_time)
    response._error_is_response_code = False
    try:
        response.rethrow()
    except:
        return 1
    else:
        return 0




# Generated at 2022-06-22 03:46:01.600019
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    http_client = HTTPClient()
    http_client.close()

# Generated at 2022-06-22 03:46:29.970150
# Unit test for function main
def test_main():
    """test main function"""
    import unittest
    import mock

    class Mock(object):
        '''
        Mock class
        '''
        pass
    mock_object = Mock()
    mock_object.return_value = None
    with mock.patch("tornado.httpclient.HTTPClient.__init__", mock_object), \
        mock.patch("tornado.httpclient.HTTPClient.close", mock_object), \
        mock.patch("tornado.httpclient.HTTPClient.fetch", mock_object):
        httpclient.main()



# Generated at 2022-06-22 03:46:38.104269
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    instance_cache = AsyncHTTPClient._async_clients()
    io_loop = IOLoop.current()
    if isinstance(instance_cache[io_loop], AsyncHTTPClient):
        #_async_clients() returns a reference to a cached object
        assert isinstance(AsyncHTTPClient(), AsyncHTTPClient)
    else:
        #_async_clients() returns a reference to a new object
        assert isinstance(AsyncHTTPClient(), AsyncHTTPClient)


# Generated at 2022-06-22 03:46:48.915085
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = 'www.baidu.com'
    method = 'GET'
    headers = {'Content-Type': 'application/json'}
    body = '{"username":"ashu","password":"123456"}'
    auth_username = "ashu"
    auth_password = '123456'
    auth_mode = "basic"
    connect_timeout = 2.3
    request_timeout = 1000.3
    if_modified_since = datetime.datetime.now()
    follow_redirects = True
    max_redirects = 5
    user_agent = "Mozilla/5.0"
    use_gzip = True
    network_interface = "47.99.201.224"
    streaming_callback = lambda x: x
    header_callback = lambda x: x
    prepare_curl_callback

# Generated at 2022-06-22 03:46:52.565730
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    u"""
    first we create an instance of class HTTPResponse,
    then we use a built-in function __repr__ to get the representation
    of this object.
    """
    i = HTTPResponse()
    print("%s" % (i.__repr__()))


# Generated at 2022-06-22 03:46:56.802831
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
  from copy import copy
  from tornado.httpclient import HTTPClientError
  error = HTTPClientError(404, 'Not Found', None)
  assert error.code == 404
  assert error.message == 'Not Found'
  assert error.response == None
  assert repr(error) == 'HTTP 404: Not Found'

HTTPError = HTTPClientError



# Generated at 2022-06-22 03:47:01.047968
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    reg_request=r"gets the content at the given URL."
    request=r"http://www.abcd.com"
    ob=HTTPClient()
    a=ob.fetch(request=request)
    assert a.body == reg_request

# Generated at 2022-06-22 03:47:09.876686
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
  # mock instance of class HTTPRequest
  request = mock.Mock(spec=HTTPRequest)
  # set attr to mock instance of class HTTPRequest
  request.foo = 'foo'
  # mock instances of class dict
  defaults = mock.Mock(spec=dict)
  # set attr to mock instances of class dict
  defaults = {}
  # mock instance of class _RequestProxy
  request_proxy = mock.Mock(spec=_RequestProxy)
  # call method __getattr__ of class _RequestProxy
  request_proxy.__getattr__('foo')


# Generated at 2022-06-22 03:47:18.874030
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('www.baidu.com')
    defaults = {'method':'POST'}
    _RequestProxy_instance = _RequestProxy(request, defaults)
    assert(_RequestProxy_instance.method == 'POST')
    assert(_RequestProxy_instance.method == 'GET')
    assert(_RequestProxy_instance.proxy_host == None)


RequestStartEvent = collections.namedtuple(
    "RequestStartEvent",
    ["request", "io_loop", "context", "start_time"],
)
RequestEndEvent = collections.namedtuple(
    "RequestEndEvent",
    ["request", "response", "io_loop", "context", "start_time", "end_time"],
)

# From http://www.iana.org/assignments/http-status-codes
_HTTP_STATUS_C

# Generated at 2022-06-22 03:47:31.078689
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    from tornado.escape import utf8
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPRequest, HTTPResponse, HTTPError
    from tornado.httpclient import (
        _RequestProxy,
        AsyncHTTPClient,
        HTTPRequest,
        HTTPError,
        HTTPResponse,
    )
    from tornado.ioloop import IOLoop
    from tornado.simple_httpclient import SimpleAsyncHTTPClient


    class DelayedHTTPClient(SimpleAsyncHTTPClient):
        def fetch_impl(self, request, callback):
            from tornado.gen import sleep

            IOLoop.current().add_callback(sleep, 0.1)
            IOLoop.current().add_callback(self._do_fetch, request, callback)


    http_client = AsyncHTTPClient()

    http

# Generated at 2022-06-22 03:47:35.222497
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    client = HTTPClient()
    import sys
    if sys.version_info.major == 3:
        assert client._async_client.__class__.__name__ == 'SimpleAsyncHTTPClient'
    else:
        assert client._async_client.__class__.__name__ == 'SimpleAsyncHTTPClient'