

# Generated at 2022-06-22 03:40:36.476657
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    assert HTTPClientError(404, response=None) is not None
    assert HTTPClientError(599, response=None) is not None

# Alias for backward compatibility
HTTPError = HTTPClientError  # type: Type[HTTPClientError]

# These exceptions are no longer used internally but are left as aliases
# for old user code.

# Generated at 2022-06-22 03:40:40.021208
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    obj = HTTPClient()
    obj.close()
    obj.__del__()


# Generated at 2022-06-22 03:40:45.358921
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
        async_client_class = "tornado.curl_httpclient.CurlAsyncHTTPClient"
        request = HTTPRequest(url="http://google.com")

        def _handle_response(response):
            pass

        if async_client_class is None:
            async_client_class = AsyncHTTPClient

        s = AsyncHTTPClient()
        s.fetch_impl(request,_handle_response)



# Generated at 2022-06-22 03:40:51.663435
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    class FakeRequest():
        def __init__(self):
            self.method = "GET"
            self.body = "foo"
            self.allow_nonstandard_methods = False
            self.connect_timeout = 1.0
            self.request_timeout = 1.0
            self.proxy_host = "127.0.0.1"
            self.proxy_port = 8080
            self.proxy_username = "me"
            self.proxy_password = "pwd"
            self.follow_redirects = True
            self.max_redirects = 10
            self.headers = httputil.HTTPHeaders()
            self.auth_username = "me"
            self.auth_password = "pwd"
            self.auth_mode = "basic"
            self.decompress_response = False


# Generated at 2022-06-22 03:41:00.394651
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    print(HTTPRequest.__doc__)
    url = "http://example.com"
    method = "GET"
    headers = {"content-type": "text/html; charset=utf-8"}
    body = b"";
    auth_username = "username"
    auth_password = "password"
    auth_mode = "basic"
    connect_timeout = 20.0
    request_timeout = 20.0
    if_modified_since = time.time()
    follow_redirects = True
    max_redirects = 5
    user_agent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
    use_gzip = True
    network_

# Generated at 2022-06-22 03:41:02.154795
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    instance = HTTPClientError(code=1, message=None, response=None)
    assert isinstance(instance.__repr__(), str)

HTTPError = HTTPClientError



# Generated at 2022-06-22 03:41:06.909709
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    import unittest
    from tornado.testing import AsyncHTTPTestCase
    from tornado.httpclient import AsyncHTTPClient

    class _RequestProxyTestClass(AsyncHTTPTestCase):
        def get_app(self):
            return None

        def test_request_proxy(self):
            pass
            req = HTTPRequest('http://www.google.com')
            req_2 = _RequestProxy(req, AsyncHTTPClient._DEFAULTS)
            self.assertEqual(req_2.request_timeout, AsyncHTTPClient._DEFAULTS['request_timeout'], 'test request_timeout')
            self.assertEqual(req_2.connect_timeout, AsyncHTTPClient._DEFAULTS['connect_timeout'], 'test connect_timeout')

# Generated at 2022-06-22 03:41:13.483249
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    try:
        import pycurl  # type: ignore
    except ImportError:
        pycurl = None  # type: ignore
    if not pycurl:
        raise unittest.SkipTest("pycurl is not present")
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    with closing(AsyncHTTPClient()) as client:
        response = yield client.fetch("http://www.tornadoweb.org/")
        self.assertEqual(response.code, 200)
        self.assertTrue(response.body.startswith(b"<!DOCTYPE html>"))


# Generated at 2022-06-22 03:41:25.834814
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.httpclient import AsyncHTTPClient
    
    http_client = HTTPClient()
    
    class MyHTTPResponse(HTTPResponse):
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
    
    class MyAsyncHTTPClient(AsyncHTTPClient):
        _my_response = MyHTTPResponse(1, 2)
    
        async def fetch(self, request: HTTPRequest, **kwargs: Any) -> MyHTTPResponse:
            return self._my_response
    

# Generated at 2022-06-22 03:41:26.561417
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 03:41:36.031075
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url1, method1, headers1, body1 = 'www.baidu.com', 'POST', {'a': '1', 'b': '2'}, 'TestBody'
    testobj = HTTPRequest(url1, method1, headers1, body1)
    assert testobj.url == url1
    assert testobj.method == method1
    assert testobj.headers == {'a': '1', 'b': '2'}
    assert testobj.body == b'TestBody'


# Generated at 2022-06-22 03:41:48.634459
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url = "http://localhost"
    method = "GET"
    headers = None
    body = None
    auth_username = None
    auth_password = None
    auth_mode = None
    connect_timeout = None
    request_timeout = None
    if_modified_since = None
    follow_redirects = None
    max_redirects = None
    user_agent = None
    decompress_response = None
    network_interface = None
    streaming_callback = None
    header_callback = None
    prepare_curl_callback = None
    proxy_host = None
    proxy_port = None
    proxy_username = None
    proxy_password = None
    proxy_auth_mode = None
    allow_nonstandard_methods = None
    validate_cert = None
    ca_certs = None
    allow

# Generated at 2022-06-22 03:41:51.326886
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    httpResponse = HTTPResponse(None, 400, None, None, None)
    httpResponse.rethrow()


# Generated at 2022-06-22 03:41:55.354253
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    if __name__ == '__main__':
        http_client = HTTPClient()
        http_client.close()


# Generated at 2022-06-22 03:42:04.727988
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    _impl = AsyncHTTPClient.configure(
        impl=None, 
    )
    _instance = AsyncHTTPClient(
        force_instance=True, 
    )
    # Test coverage for HTTPRequest.__init__
    # Test coverage for HTTPRequest.__setattr__
    # Test coverage for HTTPRequest.__delattr__
    # Test coverage for HTTPRequest.__repr__
    # Test coverage for HTTPRequest.rebuild_auth
    # Test coverage for HTTPRequest.url
    # Test coverage for HTTPRequest.version
    # Test coverage for HTTPRequest.method
    # Test coverage for HTTPRequest.body
    # Test coverage for HTTPRequest.headers
    # Test coverage for HTTPRequest.auth_username
    # Test coverage for HTTPRequest.auth_password
    # Test coverage for HTTPRequest.auth_mode
    # Test coverage

# Generated at 2022-06-22 03:42:07.190722
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    http_client.close()

# Generated at 2022-06-22 03:42:11.674301
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
	@gen.coroutine
	def foo(url: str) -> Any:
		http_client = HTTPClient()
		response = http_client.fetch(url)
		http_client.close()
		return response
	IOLoop.current().run_sync(lambda: foo("https://www.google.com"))


# Generated at 2022-06-22 03:42:12.384170
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 03:42:17.121900
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from urllib import request
    from urllib.error import HTTPError, URLError
    http_client = HTTPClient()
    for url in ['http://www.baidu.com', 'http://www.baidu.com']:
        try:
            response = http_client.fetch(url)
            print(response.headers)
        except HTTPError as err:
            print(err)
        except URLError as err:
            print(err)
    http_client.close()



# Generated at 2022-06-22 03:42:28.713706
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(
            'http://localhost:8888/echo',
            method='GET',
        )
    response = HTTPResponse(
            request,
            code=200,
            headers=None,
            buffer=None,
            effective_url=None,
            error=None,
            request_time=None,
            time_info=None,
            reason=None,
            start_time=None,
        )
    # There was no error so no exception is raised
    response.rethrow()
    response.error = 1
    try:
        response.rethrow()
    except:
        print("test_HTTPResponse_rethrow pass")
    else:
        print("test_HTTPResponse_rethrow fail")


# Generated at 2022-06-22 03:42:41.470270
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    httpclient = AsyncHTTPClient()
    httpclient.close()


# Generated at 2022-06-22 03:42:42.179728
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    pass



# Generated at 2022-06-22 03:42:51.004999
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-22 03:42:52.045991
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass


# Generated at 2022-06-22 03:42:59.186832
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Testing with SimpleAsyncHTTPClient as it is the default class
    # used by AsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest

    # Object of class SimpleAsyncHTTPClient which is a subclass
    # of AsyncHTTPClient
    client_obj = AsyncHTTPClient()
    # Valid request object
    request = HTTPRequest(url="http://www.google.com")
    # Callback to handle response
    # NOTE: This is an empty method as it is not required in
    # our test case
    def callback(response):
        pass
    # Calling the method to be tested
    client_obj.fetch_impl(request, callback)

# Generated at 2022-06-22 03:43:06.478954
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    from tornado.httputil import HTTPHeaders


# Generated at 2022-06-22 03:43:15.285609
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    with tornado.simple_httpclient.SimpleAsyncHTTPClient() as http_client:
        print(http_client.instance_cache)
        response = http_client.fetch("http://www.google.com")
        print(response.body)
        http_client.close(all_futures=True)

# Idiomatically, the accessor method is named after the variable, with
# a leading underscore.  But in this case that would shadow the
# global variable in the module named after the class.

# Generated at 2022-06-22 03:43:22.371286
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    import unittest
    from tornado.testing import AsyncTestCase
    from tornado.httpclient import AsyncHTTPClient

    class test__RequestProxy(AsyncTestCase):
        @gen_test
        async def test_request(self):
            data = b"0123456789" * 100000
            client = AsyncHTTPClient()
            response = await client.fetch("http://www.google.com/")
            self.assertTrue(response.body)
            self.assertEqual(response.request.method, "GET")
            self.assertEqual(response.code, 200)

            response = await client.fetch("http://www.google.com/", method="HEAD")
            self.assertFalse(response.body)
            self.assertEqual(response.request.method, "HEAD")
            self.assertEqual

# Generated at 2022-06-22 03:43:26.855446
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    req = HTTPRequest("http://www.163.com")
    resp = HTTPResponse(request=req, code=200, headers=None, buffer=None, effective_url=None, error=None, request_time=None, time_info=None, reason=None, start_time=None)
    print(resp)



# Generated at 2022-06-22 03:43:34.258348
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    print("testing function test_HTTPClient")

    http_client = HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        body = response.body
        print(body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()
