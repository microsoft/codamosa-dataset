

# Generated at 2022-06-22 03:40:33.202986
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    http_client.close()
    return http_client

# Generated at 2022-06-22 03:40:38.270055
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('www.baidu.com', method='GET', headers={'User-Agent': 'Mozilla/5.0'})
    response = HTTPResponse(request, 301, headers={'Location': 'https://www.baidu.com'}, effective_url='https://www.baidu.com')
    try:
        response.rethrow()
    except HTTPError as e:
        print(e)



# Generated at 2022-06-22 03:40:45.320525
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    exp = 'HTTP 500: Internal Server Error'
    err = HTTPClientError(code=500, message=exp)
    act = err.__repr__()
    assert exp == act, 'HTTPClientError.__repr__()'


HTTPError = HTTPClientError
TimeoutError = IOError

# It's common for servers that reject PUT/PATCH/etc with a 405 to use
# a 404 error page as the response body instead of an empty response body
# with a custom Allow header.  This regex finds common 404 bodies
# that don't have a meaningful response.
_BAD_ALLOW_HEADER_REGEX = re.compile(b"<(?:head>|html>|/head>|body>|/body>|h1>|/h1>)", re.I)



# Generated at 2022-06-22 03:40:48.019138
# Unit test for constructor of class HTTPClientError
def test_HTTPClientError():
    h = HTTPClientError(404, 'message', 'response')
    assert h.code == 404
    assert h.message == 'message'
    assert h.response == 'response'
    assert str(h) == 'HTTP 404: message'


# Generated at 2022-06-22 03:40:49.560694
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-22 03:40:58.562232
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import asyncio
    async def main():
        http_client = AsyncHTTPClient() 
        # Note: We use tornado.httpclient.HTTPRequest instead of tornado.httputil.HTTPRequest directly.
        # In the API document, we use tornado.httputil.HTTPRequest for the request, this is for convenience.
        # tornado.httputil.HTTPRequest is the base class for request and has no implementations. 
        # tornado.httpclient.HTTPRequest is the subclass which provides the implementations.
        # tornado.httpclient.HTTPRequest is still an alias of tornado.httputil.HTTPRequest which means the type of request is
        # still tornado.httputil.HTTPRequest. So don't get confused.
        request = tornado.httpclient.HTTPRequest("http://www.google.com")

# Generated at 2022-06-22 03:41:05.256492
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    #1
    async_client = AsyncHTTPClient(io_loop=IOLoop.current())
    response = async_client.fetch("http://www.baidu.com/")
    print(response)
    assert isinstance(response, HTTPResponse)
    #2
    try:
        http_client = HTTPClient(io_loop=IOLoop.current())
        response = http_client.fetch("http://www.baidu.com/")
        print(response)
        assert isinstance(response, HTTPResponse)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))

# Generated at 2022-06-22 03:41:10.149710
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado import ioloop
    from tornado import stack_context

    def handle_response(response):
        assert response.body == b"async"

    def main():
        request = HTTPRequest(url="http://localhost:8890/test")
        client = AsyncHTTPClient()
        client.fetch_impl(request, handle_response)

    io_loop = ioloop.IOLoop.instance()
    io_loop.add_callback(stack_context.wrap(main))
    io_loop.start()



# Generated at 2022-06-22 03:41:22.201096
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    req = create_mock_request()
    code = 200
    headers = httputil.HTTPHeaders()
    buffer = BytesIO(b'asdf')
    effective_url = 'http://www.google.com'
    error = None
    request_time = 1.2
    time_info = {'queue': 0.1, 'namelookup': 0.3}
    reason = 'OK'

    resp = HTTPResponse(
        request=req,
        code=code,
        headers=headers,
        buffer=buffer,
        effective_url=effective_url,
        error=error,
        request_time=request_time,
        time_info=time_info,
        reason=reason
    )

    assert(resp.request == req)
    assert(resp.code == code)


# Generated at 2022-06-22 03:41:25.526004
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    with HTTPClient() as http_client:
        http_client.fetch(url="https://www.google.com/")
    # This test should get here without crashing
    del http_client


# Generated at 2022-06-22 03:41:38.396419
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    client = AsyncHTTPClient()
    assert isinstance(client, AsyncHTTPClient)



# Generated at 2022-06-22 03:41:41.192161
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    resp = HTTPResponse(HTTPRequest(), 500)
    resp.rethrow()
    assert resp.error.code == 500


# Generated at 2022-06-22 03:41:42.562279
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-22 03:41:52.824451
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.httpclient import HTTPRequest
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import gen_test, AsyncHTTPTestCase

    class TestAsyncHTTPClient(AsyncHTTPTestCase):
        def get_app(self):
            return Application([])

        @gen_test
        def test_AsyncHTTPClient___new__(self):
            http_client = AsyncHTTPClient()
            self.assertIsInstance(http_client, SimpleAsyncHTTPClient)

        @gen_test
        def test_AsyncHTTPClient___new___force_instance(self):
            http_client = AsyncHTTPClient(force_instance=True)
            self.assertIsInstance(http_client, SimpleAsyncHTTPClient)
            http_client2 = AsyncHTTPClient(force_instance=True)

# Generated at 2022-06-22 03:42:00.362227
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    def_a = {'hoge': 'a', 'fuga': 'b'}
    rp = _RequestProxy(None, def_a)
    a = rp.hoge
    print(a)
    b = rp.fuga
    print(b)
    c = rp.piyo
    print(c)
test__RequestProxy___getattr__()

# Generated at 2022-06-22 03:42:07.086016
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():

    try:
        raise Exception
    except Exception:
        response = HTTPResponse(HTTPRequest("GET", "http://127.0.0.1:8080/"), 20, error=sys.exc_info()[1])
        response.rethrow()
    return response

# Generated at 2022-06-22 03:42:07.765988
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass

# Generated at 2022-06-22 03:42:09.379965
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    f = AsyncHTTPClient()
    f.initialize()




# Generated at 2022-06-22 03:42:10.339544
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    httpclient.HTTPClient()



# Generated at 2022-06-22 03:42:11.674584
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    obj = HTTPResponse
    assert 1 == 1



# Generated at 2022-06-22 03:42:25.530006
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-22 03:42:32.563682
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = HTTPClient()
    try:
        response = http_client.fetch("https://www.google.com/")
        print(response.body)
    except HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()

run_test(test_HTTPClient_fetch, "Test for method fetch of class HTTPClient")


# Generated at 2022-06-22 03:42:45.968470
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    # Test the HTTPClient method close
    # The following tests are designed using the Python Unittest
    # framework.
    # The tests are designed on tornado version 5.1.1
    # The tests are designed on Python version 3.6.0
    # The tests are run on Windows 10

    # Get the function from the tornado module
    from tornado.httpclient import HTTPClient

    # Test for successful close of HTTPClient
    # The below test does not guarantee that the HTTPClient has closed, only
    # that the close method has executed successfully.
    # This means that if a new HTTPClient is created, it will be in the
    # same state as the original HTTPClient and so may overwrite the
    # original.
    # This is necessary as there is no way to check that the HTTPClient has
    # actually closed.
    http_client = HTTPClient()
   

# Generated at 2022-06-22 03:42:56.698280
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    class TestHTTPRequest(HTTPRequest):
        pass


# Generated at 2022-06-22 03:43:00.199505
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    req = HTTPRequest("www.baidu.com")
    res = HTTPResponse(req,1)
    HTTPResponse.rethrow(res)


# Generated at 2022-06-22 03:43:08.473513
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    # Call:
    res = HTTPResponse.__repr__(HTTPResponse)
    # Test:
    assert(res == ('HTTPResponse(body=None,'
                   ' buffer=None,'
                   ' code=None,'
                   ' error=None,'
                   ' effective_url=None,'
                   ' headers=None,'
                   ' request=None,'
                   ' reason=None,'
                   ' request_time=None,'
                   ' start_time=None,'
                   ' time_info={})'))
    

# Generated at 2022-06-22 03:43:10.652807
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    a = HTTPClient()
    a.__del__()
    
test_HTTPClient___del__()


# Generated at 2022-06-22 03:43:24.323983
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    instance = AsyncHTTPClient()
    instance.initialize()
    assert instance.io_loop == IOLoop.current()

# Generated at 2022-06-22 03:43:25.280368
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    AsyncHTTPClient()


# Generated at 2022-06-22 03:43:29.290937
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('http://www.google.com')
    _RequestProxy(request, None)
    _RequestProxy(request, {})


# Generated at 2022-06-22 03:44:07.471395
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # test whether the function could get the function fetch_impl
    # of class AsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test
    class TestAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, **kwargs):
            super(TestAsyncHTTPClient, self).__init__(**kwargs)
            self.call_count = 0
        def fetch_impl(self, request, callback):
            self.call_count += 1
            callback(HTTPResponse(request, 200, buffer=BytesIO(b"response1")))
            callback(HTTPResponse(request, 200, buffer=BytesIO(b"response2")))

# Generated at 2022-06-22 03:44:08.011782
# Unit test for method close of class HTTPClient
def test_HTTPClient_close():
    a = 1

# Generated at 2022-06-22 03:44:11.825368
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    req = HTTPRequest(url="http://localhost/")
    response = HTTPResponse(request=req, code=200, headers = None, buffer = None,
                            effective_url = None, error = None, request_time = None,
                            time_info = None, reason = None, start_time = None)
    response.rethrow()


# Generated at 2022-06-22 03:44:16.407596
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    http_client_error = HTTPClientError(404, "Not Found", None)
    assert http_client_error.__repr__() == "HTTP 404: Not Found"


HTTPError = HTTPClientError  # type: Type[HTTPClientError]



# Generated at 2022-06-22 03:44:20.854316
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    req = HTTPRequest("http://localhost:8888/test")
    client = HTTPClient()
    response = client.fetch(req)
    print(response.body)

if __name__ == "__main__":
    test_HTTPClient_fetch()

# Generated at 2022-06-22 03:44:30.536549
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('http://www.google.com')
    code = 200
    headers = {'Content-Type': 'text/html'}
    buffer = BytesIO(b'Hello World')
    effective_url = 'http://www.google.com'
    error = None
    request_time = 2.0
    time_info = {'queue':3.0}
    reason = 'OK'
    h = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason)
    print(h)
    h.rethrow()

# Generated at 2022-06-22 03:44:31.548887
# Unit test for function main
def test_main():
    global native_str
    native_str = str
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 03:44:40.361085
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():    
    from tornado.httpclient import HTTPClient, HTTPRequest
    request_type = HTTPClient()
    request = HTTPRequest('http://www.google.com/', raise_error=True) # type: ignore
    try:
        response = request_type.fetch(request)
        print('HTTPClient.fetch: ', response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    response.body

# Generated at 2022-06-22 03:44:46.237544
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    try:
        # Make it possible to test both implementations
        AsyncHTTPClient.configure(None)
        AsyncHTTPClient()
        AsyncHTTPClient.configure(None)
        AsyncHTTPClient()
    finally:
        AsyncHTTPClient.configure(None)


# Generated at 2022-06-22 03:44:50.097999
# Unit test for constructor of class AsyncHTTPClient
def test_AsyncHTTPClient():
    # calling the abstract constructor should raise an exception
    try:
        AsyncHTTPClient()
    except NotImplementedError:
        pass
    else:
        raise Exception("expected NotImplementedError")



# Generated at 2022-06-22 03:46:43.165725
# Unit test for constructor of class HTTPResponse

# Generated at 2022-06-22 03:46:45.718553
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    h = HTTPClient()
    r = h.fetch('http://www.google.com/')
    print(r.body)



# Generated at 2022-06-22 03:46:52.492229
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    print('################running test_AsyncHTTPClient_fetch()')
    import tornado.ioloop
    from tornado.testing import AsyncTestCase, gen_test, main
    from tornado.httpclient import HTTPRequest, HTTPResponse

    class AsyncHTTPClientTest(AsyncTestCase):
        def setUp(self):
            print('setUp')
            super(AsyncHTTPClientTest, self).setUp()
            self.http_client = AsyncHTTPClient()
            self.stop()
            self.wait()

        def tearDown(self):
            print('tearDown')
            self.http_client.close()
            super(AsyncHTTPClientTest, self).tearDown()


# Generated at 2022-06-22 03:47:04.351211
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # If a client has been created with force_instance=True then close()
    # should remove the cache entry.
    client = AsyncHTTPClient(force_instance=True)
    assert client is AsyncHTTPClient(force_instance=True)
    client.close()
    assert client is not AsyncHTTPClient(force_instance=True)
    assert client is not AsyncHTTPClient(force_instance=True)  # another new one

    # If a client was not created with force_instance=True, then close()
    # should have no effect.
    client = AsyncHTTPClient()
    assert client is AsyncHTTPClient()
    client.close()
    assert client is AsyncHTTPClient()

    # The same instance should be used for a subclass.
    class SubAsyncHTTPClient(AsyncHTTPClient):
        pass

    client = SubAsyncHTTP

# Generated at 2022-06-22 03:47:12.230362
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    # find a website and test
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-22 03:47:13.809766
# Unit test for method __del__ of class HTTPClient
def test_HTTPClient___del__():
    http_client = HTTPClient()
    http_client.close()
    http_client._closed = True

# Generated at 2022-06-22 03:47:22.210275
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    import inspect
    from tornado.log import app_log
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import _RequestProxy
    from pprint import pprint
    from typing import Any
    from typing import Dict


    class MyHTTPRequest(HTTPRequest):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
        def __repr__(self):
            return "(my request)"
        def __str__(self):
            return "(my request str)"

    # without defaults
    req = MyHTTPRequest(url="http://example.com/")
    rp = _RequestProxy(req, defaults=None)
    assert str(rp) == "(my request str)"
    assert rp.url == "http://example.com/"
    assert rp.proxy_

# Generated at 2022-06-22 03:47:34.005881
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url="https://www.baidu.com")
    code = 200
    headers = None
    buffer = None
    effective_url = None
    error = None
    request_time = None
    time_info = None
    reason = None
    start_time = None
    res = HTTPResponse(
        request=request,
        code=code,
        headers=headers,
        buffer=buffer,
        effective_url=effective_url,
        error=error,
        request_time=request_time,
        time_info=time_info,
        reason=reason,
        start_time=start_time,
    )
    res.rethrow()



# Generated at 2022-06-22 03:47:37.516262
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    assert HTTPResponse(request=None, code=404, headers=None, body="body",
                        effective_url="http://www.example.com",
                        error=None, reason="reason",
                        request_time=2.0, time_info=None)

# Generated at 2022-06-22 03:47:45.869009
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    import asyncio
    async def f():
        http_client = AsyncHTTPClient(force_instance=True)
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(f())


# Generated at 2022-06-22 03:49:47.169113
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # default_values is a dictionary which serves as a default request attribute
    default_values = {
        "body": "123",
        "proxy_host": "example.com"
    }
    # request is a HTTPRequest object with request attribute
    request = HTTPRequest("www.google.com", **default_values)
    # request_proxy is a _RequestProxy object with request attribute and default_values
    request_proxy = _RequestProxy(request, default_values)
    # The difference is that request_proxy.body is not None, but request.body is None
    # because attribute body is defined in request_proxy
    assert request_proxy.body is not None


# A single global ``AsyncHTTPClient`` instance, used by
# `~tornado.ioloop.IOLoop.fetch`.  It is also possible to use `HTTPClient`


# Generated at 2022-06-22 03:49:49.257908
# Unit test for constructor of class HTTPRequest
def test_HTTPRequest():
    url='http://blog.csdn.net/zhzhl202/article/details/7738137'
    print(HTTPRequest(url))
    print(HTTPRequest(url=url))



# Generated at 2022-06-22 03:49:50.339401
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-22 03:49:56.574908
# Unit test for constructor of class _RequestProxy
def test__RequestProxy():
    r = HTTPRequest('http://www.example.com')
    p = _RequestProxy(r, {'foo': 'bar'})
    assert p.url == r.url # normal property lookup
    assert p.foo == 'bar' # property lookup with defaults
    assert p.bar == None # property lookup with defaults
    assert p.request == r # request attribute lookup
    assert p.defaults == {'foo': 'bar'} # defaults attribute lookup



# Generated at 2022-06-22 03:49:58.614266
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
  a=_RequestProxy(request=None,defaults=None)
  assert a.__getattr__('test') == None
  b=_RequestProxy(request=None,defaults={'test':1111})
  assert b.__getattr__('test') == 1111
test__RequestProxy___getattr__()

# Generated at 2022-06-22 03:50:06.405187
# Unit test for constructor of class _RequestProxy

# Generated at 2022-06-22 03:50:08.799551
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Just a smoke test.
    AsyncHTTPClient()


# Generated at 2022-06-22 03:50:15.828035
# Unit test for method __repr__ of class HTTPClientError
def test_HTTPClientError___repr__():
    
    

    # make an instance
    item = HTTPClientError(code=777)

    

    
    
    
    
    

    
    
    

    
    
    

    
    
    

    
    
    

    
    
    

    # test __repr__
    # HTTPResponse object with useful repr
    assert repr(item) == "HTTP 777: Unknown"


HTTPError = HTTPClientError

