

# Generated at 2022-06-22 15:40:49.536847
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado import testing
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import AsyncHTTPClient
    class TestAsyncHTTPClient(testing.AsyncHTTPTestCase):
        def get_app(self):
            return None

        def test_initialize(self):
            AsyncHTTPClient.configure(SimpleAsyncHTTPClient)
            client = AsyncHTTPClient()
            # The IO loop should be the same as the one created by the
            # test case.
            self.assertEqual(self.io_loop, client.io_loop)
            # The implementation class should be configured.
            self.assertEqual(SimpleAsyncHTTPClient, client.__class__)



# Generated at 2022-06-22 15:40:59.975936
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.util import b
    import tornado.autoreload

    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.web
    import tornado.testing
    import tornado.escape
    import unittest
    import functools
    import logging
    import sys
    import os
    import time

    # This is an ugly hack necessary to get test_main to work
    # without being installed as a package.
    # We have to add the path to the submodule it's using,
    # "tornado.test.runtests", to sys.path.
    # For a proper install, this should just be "import tornado.test.runt

# Generated at 2022-06-22 15:41:04.731768
# Unit test for function main
def test_main():
    from unittest import mock

    def execute_mock(*args, **kwargs):
        print(args)
        print(kwargs)

    with mock.patch('tornado.options.parse_command_line', return_value=["test"]):
        with mock.patch('tornado.options.options',
                        return_value=mock.Mock(print_body=True,
                                               print_headers=False,
                                               follow_redirects=True,
                                               validate_cert=False,
                                               proxy_host="proxy_host",
                                               proxy_port=8888)):
            with mock.patch('sys.exit', return_value=None) as se:
                with mock.patch('sys.stdout.write', side_effect=execute_mock) as sw:
                    main()


# Generated at 2022-06-22 15:41:10.458988
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    a = HTTPRequest('http://www.google.com')
    b = _RequestProxy(a, None)
    print(b.url)
    c = _RequestProxy(a, {'url':'http://www.baidu.com'})
    print(c.url)
    print(c.a)

# Call test function of each method
test__RequestProxy___getattr__()



# Generated at 2022-06-22 15:41:11.433284
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    assert False, "Test not implemented"

# Generated at 2022-06-22 15:41:12.187153
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-22 15:41:15.376688
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # AsyncHTTPClient.initialize is tested in the class's constructor
    pass

# Generated at 2022-06-22 15:41:23.657624
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest('www.baidu.com')
    request_proxy = _RequestProxy(request, None)
    assert request_proxy.url == 'www.baidu.com'

    defaults = {
        'url' : 'www.google.com',
        'method' : 'GET'
    }
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.url == 'www.baidu.com'
    assert request_proxy.method == 'GET'


# Generated at 2022-06-22 15:41:35.367181
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.concurrent import Future
    from tornado.testing import AsyncHTTPTestCase, gen_test, ExpectLog, bind_unused_port

    # Force a non-global AsyncHTTPClient instance.
    client = SimpleAsyncHTTPClient(force_instance=True)

    @gen_test
    def f():
        future = Future()
        sock, port = bind_unused_port()
        client.fetch(
            "http://127.0.0.1:%d/" % port,
            callback=future_set_result_unless_cancelled,
            callback_arg=future,
        )
        yield future
        # Close the client before the IOLoop is closed.
        client.close()

    # The call to close() should not act as a cancellation point

# Generated at 2022-06-22 15:41:48.139196
# Unit test for function main
def test_main():
    try:
        main()
    except Exception as e:
        raise AssertionError(str(e))
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for function main
# Test case for

# Generated at 2022-06-22 15:42:00.031874
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    settings = {}
    client = AsyncHTTPClient(force_instance=True)
    assert client.initialize(**settings) == None


# Generated at 2022-06-22 15:42:09.691790
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # initialize request
    request = HTTPRequest("url")
    # initialize defaults
    defaults = {}
    # create a new object _RequestProxy
    proxy = _RequestProxy(request, defaults)
    # check the result of __getattr__
    # the name of attributes
    name = "url"
    assert getattr(request, name) == proxy.__getattr__(name)
    # the name of defaults
    name = "method"
    assert defaults.get(name, None) == proxy.__getattr__(name)
    return proxy

if __name__ == "__main__":
    proxy = test__RequestProxy___getattr__()  # type: ignore

# Generated at 2022-06-22 15:42:20.893192
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    try:
        req = HTTPRequest(url='https://twitter.com')
        code = 200
        headers = request.headers
        buffer = request.buffer
        effective_url = request.effective_url
        error = HTTPError(request, code, message=request.reason)
        request_time = 10.0
        time_info = {}
        reason = request.reason
        start_time = time.time()
        response = HTTPResponse(req, code, headers, buffer, effective_url, error,
                         request_time, time_info, reason, start_time)
        response.rethrow()
    except HTTPError as e:
        assert(e is not None)
        print("HTTPError")
        raise e

# Generated at 2022-06-22 15:42:30.747535
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Create a new subclass of class AsyncHTTPClient
    class AsyncHTTPClient_fetch_impl(AsyncHTTPClient):
        pass

    async_http_client = AsyncHTTPClient_fetch_impl()
    # Raise an exception of type NotImplementedError
    with pytest.raises(NotImplementedError):
        # Call method fetch_impl of class AsyncHTTPClient_fetch_impl
        async_http_client.fetch_impl(HTTPRequest(url="http://www.google.com"), lambda response: None)
    del AsyncHTTPClient_fetch_impl

"""
A proxy for an HTTP request which handles defaults and other
normalizations of the request parameters.
"""



# Generated at 2022-06-22 15:42:31.316042
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:42:39.958523
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    io_loop = IOLoop()
    assert io_loop.current() == io_loop
    client1 = AsyncHTTPClient()
    # Check that the client uses IOLoop.current by default
    # and that the initialize() method sets self.io_loop
    assert client1.io_loop is io_loop
    client2 = AsyncHTTPClient(io_loop=io_loop)
    assert client2.io_loop is io_loop
    client3 = AsyncHTTPClient(force_instance=True)
    assert client3.io_loop != io_loop


# Generated at 2022-06-22 15:42:47.425026
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    request = None
    raise_error = None
    kwargs = None
    self = None
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    self = AsyncHTTPClient()
    if self._closed:
        raise RuntimeError("fetch() called on closed AsyncHTTPClient")
    if not isinstance(request, HTTPRequest):
        request = HTTPRequest(url=request, **kwargs)
    else:
        if kwargs:
            raise ValueError(
                "kwargs can't be used if request is an HTTPRequest object"
            )
    # We may modify this

# Generated at 2022-06-22 15:42:47.904844
# Unit test for function main
def test_main():
    pass



# Generated at 2022-06-22 15:43:01.430848
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Test for  method fetch_impl of class AsyncHTTPClient

    from tornado.httpclient import AsyncHTTPClient

    from tornado.testing import AsyncHTTPTestCase

    from tornado.test.util import unittest

    from tornado import gen

    from tornado.web import RequestHandler

    from tornado.escape import native_str

    from tornado.httpserver import HTTPServer

    import sys

    import threading

    # Dummy class for keep refs to monkey_patch method 'fetch_impl()'
    # of class AsyncHTTPClient
    class _AsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass


# Generated at 2022-06-22 15:43:05.363287
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def fetch_impl():
        class AsyncHTTPClient:
            def fetch_impl(self, request, callback):
                raise NotImplementedError()
        return AsyncHTTPClient()
    a = fetch_impl()
    assert isinstance(a.fetch_impl("request", "callback"), NotImplementedError)

# Generated at 2022-06-22 15:43:14.369987
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    assert isinstance(client, AsyncHTTPClient)
    client.close()


# Generated at 2022-06-22 15:43:19.199756
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # Given a request
    def handle_request(response):
        # When we rethrow the response
        response.rethrow()
    req = HTTPRequest("http://www.google.com")
    http_client = HTTPClient()
    res = http_client.fetch(req, handle_request)

# Generated at 2022-06-22 15:43:30.790667
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # Set up mock objects
    def mock_get_event_loop():
        mock_get_event_loop.call_count += 1
        return mock_get_event_loop.event_loop

    mock_get_event_loop.call_count = 0
    mock_get_event_loop.event_loop = mock.Mock()
    # Call method and check result
    result = tornado.httpclient.AsyncHTTPClient.__new__(tornado.httpclient.AsyncHTTPClient)
    # Check calls
    mock_get_event_loop.event_loop.assert_has_calls(
        [mock.call.get_event_loop()], any_order=False
    )
    # Check attributes
    assert result.io_loop == mock_get_event_loop.event_loop

# Generated at 2022-06-22 15:43:35.112924
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    client = AsyncHTTPClient()
    request = HTTPRequest(url="http://www.google.com")
    callback = lambda response: print(response.error)
    client.fetch_impl(request, callback)

# Generated at 2022-06-22 15:43:37.962836
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest(url='www.baidu.com')
    response = HTTPResponse(request=request,code=200)
    if response.rethrow():
        print('rethrow is True')
    else:
        print('rethrow is False')

if __name__ == '__main__':
    # Unit test for method __repr__ of class HTTPRequest
    test_HTTPRequest_repr()
    # Unit test for method __repr__ of class HTTPResponse
    test_HTTPResponse_rethrow()

# Generated at 2022-06-22 15:43:39.740633
# Unit test for function main
def test_main():
    (res, req) = tornado.testing.mock_unused_http_args()


# Generated at 2022-06-22 15:43:47.593286
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    import tornado.httpclient
    http_client = tornado.httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except tornado.httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()


# Generated at 2022-06-22 15:44:00.252909
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    # Test that AsyncHTTPClient.fetch() returns a Future (using mock
    # objects to avoid an actual HTTP request):

    class MockAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super(MockAsyncHTTPClient, self).__init__(*args, **kwargs)
            self.exception = None  # type: Optional[Exception]
            self.response = None  # type: Optional[HTTPResponse]

        def fetch_impl(
            self,
            request: HTTPRequest,
            callback: Callable[[HTTPResponse], None],
        ) -> None:
            if self.exception is not None:
                callback(HTTPResponse(request, 599, error=self.exception))

# Generated at 2022-06-22 15:44:09.790898
# Unit test for method fetch_impl of class AsyncHTTPClient

# Generated at 2022-06-22 15:44:13.743986
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():

    # Tests for method initialize of class AsyncHTTPClient
    client = AsyncHTTPClient()
    try:
        defaults = client.defaults
        assert defaults is not None
        assert defaults['user_agent'] == 'AsyncHTTPClient'
    finally:
        client.close()



# Generated at 2022-06-22 15:46:05.864123
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient
    import tornado.ioloop

    @gen.coroutine
    def f():
        client = AsyncHTTPClient()
        # yield client.fetch('http://localhost/path')
        yield client.fetch('https://www.w3schools.com/xml/simple.xml')  # 1
        print('done')
    io_loop = tornado.ioloop.IOLoop.current()
    io_loop.run_sync(f)

test_AsyncHTTPClient_fetch()


# Generated at 2022-06-22 15:46:13.540175
# Unit test for function main
def test_main():
    try:
        from tornado.options import define, options, parse_command_line
    except ImportError:
        raise SkipTest("main() requires tornado")
        
    parser = OptionParser()
    parser.add_option("--print_headers", action="store_true", dest="print_headers", default=False, help="")
    parser.add_option("--print_body", action="store_true", dest="print_body", default=True, help="")
    parser.add_option("--follow_redirects", action="store_true", dest="follow_redirects", default=True, help="")
    parser.add_option("--validate_cert", action="store_true", dest="validate_cert", default=True, help="")

# Generated at 2022-06-22 15:46:15.077836
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    H = HTTPResponse(None, 0, None, None, None, None, None, None, None, None)
    assert H.rethrow() == None


# Generated at 2022-06-22 15:46:21.589464
# Unit test for function main
def test_main():
    tornado.options.define("print_headers", type=bool, default=False)
    tornado.options.define("print_body", type=bool, default=True)
    tornado.options.define("follow_redirects", type=bool, default=True)
    tornado.options.define("validate_cert", type=bool, default=True)
    tornado.options.define("proxy_host", type=str)
    tornado.options.define("proxy_port", type=int)
    tornado.options.args = ['http://google.com']
    main()



# Generated at 2022-06-22 15:46:22.887173
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http = AsyncHTTPClient()
    http.close()
    return http._closed

# Generated at 2022-06-22 15:46:33.594846
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    clients = AsyncHTTPClient._async_clients()
    assert len(clients) == 0
    assert not AsyncHTTPClient._instance_cache

    client_1 = AsyncHTTPClient.configured_class()()
    assert client_1._instance_cache is clients
    assert len(clients) == 1
    assert clients[IOLoop.current()] is client_1
    assert AsyncHTTPClient._instance_cache is clients

    client_2 = AsyncHTTPClient.configured_class()()
    assert client_2._instance_cache is clients
    assert len(clients) == 1
    assert clients[IOLoop.current()] is client_2
    assert AsyncHTTPClient._instance_cache is clients

    client_1.close()
    assert len(clients) == 0
# AsyncHTTPClient._async

# Generated at 2022-06-22 15:46:40.024119
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # This mock class is used to test functions which
    # reference curl_httpclient.CurlAsyncHTTPClient class
    class MockAsyncHTTPClient(AsyncHTTPClient):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)

        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            httputil.parse_output(self, request, callback)


    # This mock class is used to test functions which
    # reference simple_httpclient.SimpleAsyncHTTPClient class

# Generated at 2022-06-22 15:46:47.457195
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase

    class DummyHTTPClient(AsyncHTTPClient):
        def initialize(self, **kwargs):
            """Initialize the global state of this client."""
            super().initialize(**kwargs)
            self._server = None  # type: DummyHTTPClient.DummyHTTPServer
            self._fetching = set()  # type: Set[Future[HTTPResponse]]
            self.io_loop.add_callback(self._start)

        def _start(self):
            self._server = DummyHTTPClient.DummyHTTPServer(self.io_loop)
            self._server.listen(8888, "127.0.0.1", self.io_loop)

# Generated at 2022-06-22 15:46:48.095759
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-22 15:46:49.350677
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest("http://www.google.com", method="GET")
    response = HTTPResponse(request, 200)
    response.rethrow()


# Generated at 2022-06-22 15:48:00.655448
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    __tracebackhide__ = True
    client1 = AsyncHTTPClient()
    assert isinstance(client1, AsyncHTTPClient)
    # FIXME: client1 is not automatically closed?
    #assert client1._closed # new AsyncHTTPClient should be closed immediately
    client2 = AsyncHTTPClient()
    assert isinstance(client2, AsyncHTTPClient)
    assert client1 is client2  # should be singleton



# Generated at 2022-06-22 15:48:02.428025
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    a = AsyncHTTPClient()
    b = HTTPRequest()
    # This is a default method call.
    a.fetch_impl(b, None)


# Generated at 2022-06-22 15:48:03.674183
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    AsyncHTTPClient.fetch_impl(request, callback)
    return



# Generated at 2022-06-22 15:48:05.041840
# Unit test for function main
def test_main():
    pass

if __name__ == "__main__":
    main()


# Generated at 2022-06-22 15:48:15.051032
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import time
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.gen
    import tornado.httpserver
    import tornado.ioloop
    import tornado.netutil
    import tornado.testing
    import tornado.web
    from tornado.httpclient import HTTPRequest
    from tornado.curl_httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPError
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase


# Generated at 2022-06-22 15:48:15.675017
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-22 15:48:18.326156
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    request_obj = HTTPRequest()
    response_obj = HTTPResponse()

    assert request_obj is not None
    assert response_obj is not None
    

# Generated at 2022-06-22 15:48:28.091410
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase

    class MainTest(AsyncHTTPTestCase, LogTrapTestCase):
        def get_app(self):
            return Application()

        def test_main(self):
            # Make sure the test server is up and running before we start
            self.fetch("/")

            # Save the old state of the sys module
            old_argv = [sys.argv[0]]
            old_argv.extend(sys.argv[1:])
            old_stdout = sys.stdout
            old_stdout_fileno = sys.stdout.fileno()
            old_stdout_isatty = os.isatty(old_stdout_fileno)

# Generated at 2022-06-22 15:48:38.864844
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # This test is run twice with the same client to check the second time.
    # the instance has been initialized.
    client = AsyncHTTPClient()

# Generated at 2022-06-22 15:48:48.981158
# Unit test for method fetch_impl of class AsyncHTTPClient