

# Generated at 2022-06-22 15:40:33.690341
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass



# Generated at 2022-06-22 15:40:34.288845
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-22 15:40:35.811267
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # Note: Function 'fetch_impl' has no unit tests.
    pass


# Generated at 2022-06-22 15:40:42.242015
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import tornado.platform.auto

    

    class MyAsyncHTTPClient(AsyncHTTPClient):
        pass

    tornado.platform.auto.set_close_exec(False)

    # this call should create a singleton
    client1 = AsyncHTTPClient()
    # mocked out here because google.com isn't guaranteed to work
    # in all environments
    client1.fetch_impl = Mockable()

    assert isinstance(client1, AsyncHTTPClient)
    client1.fetch_impl.assert_called_with(ANY, ANY)
    client1.fetch_impl.kwargs["request"].url = "foo"
    client1.fetch_impl.assert_called_with(ANY, ANY)

    # a second call to get the same singleton
    client2 = AsyncHTTPClient()

# Generated at 2022-06-22 15:40:44.454734
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # AsyncHTTPClient.fetch_impl(request, callback)
    pass


# Generated at 2022-06-22 15:40:46.118331
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    instance = AsyncHTTPClient()
    instance.initialize(defaults=None)

# Generated at 2022-06-22 15:40:47.328090
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()

# Generated at 2022-06-22 15:41:00.082018
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing

    import tornado.testing
    import tornado.web
    import tornado.httpclient

    class FooHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("bar")

    class TestAsyncHTTPClient(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application([("/foo", FooHandler)])

        def test_fetch(self):
            response = self.fetch("/foo")
            self.assertEqual(response.body, b"bar")
            self.assertEqual(response.code, 200)

            # test streaming
            chunks = []
            future = self.http_client.fetch(self.get_url("/foo"), streaming_callback=chunks.append)
            response = future.result()


# Generated at 2022-06-22 15:41:11.521254
# Unit test for method fetch_impl of class AsyncHTTPClient

# Generated at 2022-06-22 15:41:15.954201
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    client = AsyncHTTPClient()
    request = HTTPRequest("www.baidu.com")
    callback = lambda x:x
    client.fetch_impl(request, callback)


# Generated at 2022-06-22 15:41:28.776528
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    try:
        client = AsyncHTTPClient()
        url = "https://www.google.com/"
        request = HTTPRequest(url=url)
        response = client.fetch(request, raise_error=False)
        print(response.code)
        print(response.body)
    finally:
        client.close()

test_AsyncHTTPClient_fetch()


# Generated at 2022-06-22 15:41:33.271792
# Unit test for function main
def test_main():
    from tornado.options import options
    from tornado.options import define
    from tornado.options import parse_command_line
    import os
    
    class TestMain(unittest.TestCase):
        def setUp(self):
            define('test', type=str)
            define('test2', type=str)
            options.test = None
            options.test2 = None
        
        def test_main(self):
            parse_command_line(['test', 'arg1', 'arg2'])
            self.assertTrue(options.test == 'arg1')
            self.assertTrue(options.test2 == '')
    suite = unittest.TestLoader().loadTestsFromTestCase(TestMain)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-22 15:41:35.833619
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    http_client.close()
    assert http_client._closed == True

# Generated at 2022-06-22 15:41:44.198768
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    """
    def initialize(self, defaults: Optional[Dict[str, Any]] = None) -> None:
"""
    client = AsyncHTTPClient()
    client.initialize(defaults = None)
    assert client.io_loop == IOLoop.current()
    assert client.defaults == {"follow_redirects": True, 
                "max_redirects": 5, "validate_cert": True, "use_gzip": False}
    assert client._closed == False

# Generated at 2022-06-22 15:41:45.306454
# Unit test for function main
def test_main():
    from tornado.httpclient import main
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:41:47.706805
# Unit test for function main
def test_main():
    HTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    main()

# Generated at 2022-06-22 15:41:48.819930
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass



# Generated at 2022-06-22 15:41:54.076807
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request_attr = "request_attr"
    defaults = {"default": "default"}
    request = HTTPRequest("url")
    request_proxy = _RequestProxy(request, defaults)
    assert request_proxy.request_attr == "request_attr"
    assert request_proxy.default == "default"


# Generated at 2022-06-22 15:41:57.652847
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    client = AsyncHTTPClient()
    assert client._instance_cache is not None
    assert IOLoop.current() in client._instance_cache
    assert isinstance(client, AsyncHTTPClient)
    assert isinstance(client, Configurable)

# Generated at 2022-06-22 15:42:00.693192
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://example.com")
    defaults = {"key": "value"}
    proxy = _RequestProxy(request, defaults)
    assert request.key is None
    assert proxy.key == "value"


# Generated at 2022-06-22 15:42:08.985571
# Unit test for function main
def test_main():
    # capture command line args for function main
    command_line_args = ['http://example.com']
    try:
        sys.argv = ['httpclient.py', 'http://example.com']
    except:
        pass
    main()

# Generated at 2022-06-22 15:42:09.560290
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    return


# Generated at 2022-06-22 15:42:10.358270
# Unit test for function main
def test_main():
    main()
    #do some asserts...



# Generated at 2022-06-22 15:42:11.875675
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    AsyncHTTPClient.configure(None)
    client = AsyncHTTPClient()
    client.close()
    

# Generated at 2022-06-22 15:42:25.701203
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    import os
    import sys

    class MainTestCase(AsyncHTTPTestCase, LogTrapTestCase):
        def get_app(self):
            return None

        def get_http_client(self):
            return HTTPClient()

        def test_main(self):
            # The --print_headers option makes this test too chatty,
            # but otherwise it's a useful manual test.
            if "TORNADO_HTTPCLIENT_TEST_PRINT_HEADERS" in os.environ:
                self.http_client.fetch(
                    self.get_url("/"),
                    self.stop,
                    method="HEAD",
                    validate_cert=False,
                )
                response = self.wait()

# Generated at 2022-06-22 15:42:26.258601
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-22 15:42:32.795142
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    def fake_fetch_impl(request, callback):
        return None

    with mock.patch('tornado.httpclient.AsyncHTTPClient') as mockAsyncHTTPClient:
        mockAsyncHTTPClient.fetch_impl.side_effect = fake_fetch_impl
        mockAsyncHTTPClient.return_value = mockAsyncHTTPClient
        mockAsyncHTTPClient.configure(impl='curl')
        assert mockAsyncHTTPClient.fetch() != None


# Generated at 2022-06-22 15:42:33.747297
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass



# Generated at 2022-06-22 15:42:44.325397
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPClient
    import tornado.ioloop
    import tornado.web


    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    async def async_fetch(url):
        http_client = AsyncHTTPClient()
        response = await http_client.fetch(url)
        return response.body

    def sync_fetch(url):
        http_client = HTTPClient()
        return http_client.fetch(url)

    def test_async_fetch():
        app = tornado.web.Application([
            (r"/", MainHandler),
        ])
        app.listen(8888)

# Generated at 2022-06-22 15:42:47.186219
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest(url= 'www.google.com')
    defaults = {'proxy_host': 'www.google.com'}
    import tornado.httpclient as HttpClient
    proxy = HttpClient._RequestProxy(request,defaults)
    print(proxy)
    print(proxy.__getattr__('proxy_host'))
    print(proxy.__getattr__('proxy_port'))

test__RequestProxy___getattr__()


# Generated at 2022-06-22 15:43:04.650877
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    def test_default_value():
        httpClient = AsyncHTTPClient()
        assert(not httpClient._closed)
        httpClient.close()
        assert(httpClient._closed)
    test_default_value()


# Generated at 2022-06-22 15:43:14.424575
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    from tornado.httpclient import _RequestProxy
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPRequest
    request = HTTPRequest(url='', headers=HTTPHeaders(), method='get')
    defaults = None
    proxy = _RequestProxy(request, defaults)
    from tornado.httputil import HTTPHeaders
    assert proxy.headers == HTTPHeaders()
    assert proxy.method == 'get'
    assert proxy.url == ''
    assert proxy.defaults == None
    assert proxy.request == request

    defaults = {'headers': {}, 'method': 'post', 'url': 'http://127.0.0.1', 'defaults': None}
    proxy = _RequestProxy(request, defaults)
    assert proxy.headers == HTTPHeaders()
    assert proxy.method == 'get'
   

# Generated at 2022-06-22 15:43:27.906851
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    
    class DummyAsyncHTTPClient(AsyncHTTPClient):
        pass
    
    
    AsyncHTTPClient.configure(DummyAsyncHTTPClient)
    client1 = AsyncHTTPClient()
    client2 = AsyncHTTPClient()
    assert client1 is client2
    assert isinstance(client1, DummyAsyncHTTPClient)
    assert client1._instance_cache is AsyncHTTPClient._async_clients()
    
    
    
    
    # force_instance=True bypasses the instance cache
    client1 = AsyncHTTPClient(force_instance=True)
    client2 = AsyncHTTPClient(force_instance=True)
    assert client1 is not client2
   

# Generated at 2022-06-22 15:43:29.430062
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    obj = AsyncHTTPClient()
    obj.close()

    # Test the close method of AsyncHTTPClient

# Generated at 2022-06-22 15:43:30.905963
# Unit test for function main
def test_main():
    pass


if __name__ == "__main__":
    main()
    test_main()

# Generated at 2022-06-22 15:43:39.130151
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase
    from tornado.test.util import unittest
    from tornado.options import define, options

    define("httpclient_test_url", type=str)

    class MainTest(AsyncTestCase):
        def test_main(self):
            self.io_loop.run_sync(lambda: self.io_loop.spawn_callback(main))

    if not options.httpclient_test_url:
        raise unittest.SkipTest("httpclient_test_url not specified")

    test_main()

# Generated at 2022-06-22 15:43:41.171963
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    client = SimpleAsyncHTTPClient()
    client.initialize()
    


# Generated at 2022-06-22 15:43:43.086331
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    url = 'http://httpbin.org/user-agent'
    http_client = AsyncHTTPClient(force_instance=True)
    response = http_client.fetch(url)
    print("type of response is",type(response))
    print("response.rethrow() is",response.rethrow())
    print("--------------------------------")

# Generated at 2022-06-22 15:43:53.112808
# Unit test for function main
def test_main():
    import tornado.options
    import tornado.testing
    import tornado.options
    import tornado.testing
    from tornado.log import gen_log
    from tornado.testing import AsyncHTTPTestCase, main
    import tornado.web
    import http.server
    import unittest


    class SimpleHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"hello world")


    PORT = 8887
    class _TestHTTPClient(tornado.testing.AsyncTestCase,
                          tornado.testing.LogTrapTestCase):
        def setUp(self):
            super(_TestHTTPClient, self).setUp()

# Generated at 2022-06-22 15:44:05.358467
# Unit test for method __new__ of class AsyncHTTPClient

# Generated at 2022-06-22 15:44:39.596925
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import os
    import sys
    import unittest
    if hasattr(unittest, "SkipTest"):
        raise unittest.SkipTest("Skip, since test_httpclient_compatibility.py tests this")
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins
    import mock
    import tornado
    import tornado.testing

    from tornado import httpclient

    from tornado.httputil import HTTPHeaders, split_host_and_port
    from tornado.platform.asyncio import to_asyncio_future, AsyncIOMainLoop

    # By setting a custom global AsyncHTTPClient, we can override
    # the implementation-specific default.  This also provides
    # compatibility with Tornado 3 where there is no
    # AsyncHTTPClient

# Generated at 2022-06-22 15:44:46.097784
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    # This is a fragile test; it depends on the implementation details
    # of AsyncHTTPClient that only one will be created per thread.
    # It also depends on the implementation details of the
    # tornado.concurrent.Future class that the Future instances will
    # have a unique id (their object address).  The test does not
    # check the actual value of the Future instances, but simply the
    # fact that they are cached and reused.

    # FIXME: This test is known to fail on PyPy because it sets
    # sys.platform to "pypy" instead of something like "linux2".
    # This may also be true of some other platforms.
    if True:
        return  # Rest of this test is known to fail on PyPy.

    # if not hasattr(

# Generated at 2022-06-22 15:44:57.034730
# Unit test for function main
def test_main():
    # TODO: Run this test in a separate process
    import sys

    if sys.version_info >= (3,):
        error = b"HTTP 599: Unexpected error"
        print_str = b"print("
    else:
        error = "HTTP 599: Unexpected error"
        print_str = "print("

    def run(cmd: List[str], expected: bytes) -> None:
        p = subprocess.Popen(
            [sys.executable, "-u", "-m", __package__] + cmd,
            stderr=subprocess.STDOUT,
            stdout=subprocess.PIPE,
            stdin=subprocess.PIPE,
        )
        with p:
            # Make sure the child process dies when the parent does
            p.wait()

# Generated at 2022-06-22 15:45:03.282116
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, ExpectLog
    from tornado.web import RequestHandler, Application
    from tornado.options import define
    from tornado.httpserver import HTTPServer
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import StreamClosedError
    from tornado.httpclient import HTTPRequest, _BadResponse

    define("httpclient_test_port", type=int, default=None)
    define("async_httpclient_test_port", type=int, default=None)
    define("async_httpclient_test_path", type=str, default=None)

    class MainHandler(RequestHandler):
        def get(self):
            self.write(b"0123456789abcdef")

    class RedirectHandler(RequestHandler):
        def get(self):
            self.red

# Generated at 2022-06-22 15:45:05.135616
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    """Test for method close of class AsyncHTTPClient."""
    pass

# Generated at 2022-06-22 15:45:09.349875
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    @gen.coroutine
    def f():
        http_client = AsyncHTTPClient()
        try:
            response = yield http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)



# Generated at 2022-06-22 15:45:14.634164
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # class AsyncHTTPClient(Configurable):
    #     ...
    #     def fetch_impl(
    #         self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
    #     ) -> None:
    #         raise NotImplementedError()
    # => AsyncHTTPClient.fetch_impl implements a abstract method (abstract methods or abstract class).
    # => It is warning when running the unit test.
    client = AsyncHTTPClient()
    request = HTTPRequest('http://www.google.com', method='GET')
    client.fetch_impl(request, callback=None)



# Generated at 2022-06-22 15:45:20.954697
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.testing
    client = AsyncHTTPClient()
    try:
        response = test_AsyncHTTPClient_fetch.gen.throw(None)
    except StopIteration as exc:
        try:
            response = exc.args[0]
        except IndexError:
            response = None
        return response
    result = yield client.fetch('http://www.google.com')
    assert result.code == 200
test_AsyncHTTPClient_fetch.gen = test_AsyncHTTPClient_fetch()
test_AsyncHTTPClient_fetch.gen.send(None)

# Generated at 2022-06-22 15:45:29.205146
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    import tornado.escape
    import tornado.gen
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOLoop().install()
    import asyncio
    import typing

    @typing.overload
    def fetch():
        ...

    @typing.overload
    def fetch(request: str):
        ...

    @typing.overload
    def fetch(request: 'tornado.httputil.HTTPMessage'):
        ...

    def fetch(request="http://localhost/"):
        if isinstance(request, str):
            request = tornado.httpclient.HTTPRequest(url=request)
        client = tornado.httpclient.AsyncHTTPClient()

# Generated at 2022-06-22 15:45:35.932898
# Unit test for function main
def test_main():
    try:
        # Simulate tornado command line options
        import sys
        import pathlib
        sys.argv=["python","file://"+str(pathlib.Path(__file__).parent.absolute())+"/100_requests_million_times_test.py"]

        # Run main
        main()
    except ImportError as e:
        print("\n# Import error:", e)
        fail()
# main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:47:14.253810
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    test_request = HTTPRequest("https://www.google.com")
    test_code = 200
    test_headers = {"some header": "some header value"}
    test_buffer = BytesIO()
    test_effective_url = "https://www.test_effective_url.com"
    test_error = HTTPError(403)
    test_request_time = 0.1
    test_time_info = {"queue":0.1}
    test_reason = "test reason"

    test_object = HTTPResponse(test_request, test_code, test_headers, test_buffer, test_effective_url, test_error, test_request_time, test_time_info, test_reason)
    assert test_object.request == test_request
    assert test_object.code == test_code
    assert test_

# Generated at 2022-06-22 15:47:25.630054
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, main
    from tornado.util import b
    from tornado.web import RequestHandler, Application
    import tornado.httpserver
    import tornado.netutil
    import functools
    import socket
    import threading
    import urllib.parse

    class MainHandler(RequestHandler):

        def get(self):
            self.write(b("0123456789"))
            self.flush()
            self.write(b("abcdefghij"))

    class ThreadedHTTPServer(threading.Thread):

        def __init__(self, application):
            super(ThreadedHTTPServer, self).__init__()
            self.daemon = True
            self.http_server = tornado.httpserver.HTTPServer(application)

# Generated at 2022-06-22 15:47:31.352070
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.httputil import _normalize_headers
    from tornado import ioloop
    import weakref
    impl_name = ioloop.IOLoop._impl_class.__name__
    attr_name = "_async_client_dict_" + impl_name
    assert getattr(AsyncHTTPClient, attr_name) == {}
    c1 = AsyncHTTPClient()
    assert "_instance_cache" in c1.__dict__
    assert c1._instance_cache == getattr(AsyncHTTPClient, attr_name)
    assert c1.__class__.__name__ == impl_name
    assert getattr(AsyncHTTPClient, attr_name) == {IOLoop.current(): c1}
    assert c1 == AsyncHTTPClient()

# Generated at 2022-06-22 15:47:32.996608
# Unit test for function main
def test_main():
    try:
        main()
    except:
        return 0
    return 1


# Generated at 2022-06-22 15:47:33.533503
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    return None

# Generated at 2022-06-22 15:47:36.975915
# Unit test for function main
def test_main():
    # The test framework doesn't support command line options,
    # so just make sure this function runs without raising an error
    HTTPClient.configure(SimpleAsyncHTTPClient)
    main()
    HTTPClient.configure(CurlAsyncHTTPClient)
    main()



# Generated at 2022-06-22 15:47:38.485397
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    c = AsyncHTTPClient()
    c.close()

# Generated at 2022-06-22 15:47:39.341322
# Unit test for function main
def test_main():
    assert False


# Generated at 2022-06-22 15:47:48.125091
# Unit test for function main
def test_main():
    m = HTTPResponse(
        HTTPRequest("GET", "http://www.example.com/"),
        200,
        httputil.HTTPHeaders(),
        BytesIO(b"Example"),
        "http://www.example.com/",
    )
    assert m.body == b"Example"

    m = HTTPResponse(
        HTTPRequest("GET", "http://www.example.com/"),
        200,
        httputil.HTTPHeaders(),
        BytesIO(b"Example"),
        "http://www.example.com/",
    )
    m.body
    assert m._body == b"Example"


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:47:49.998421
# Unit test for function main
def test_main():
    sys.argv.append('-h')
    main()
    sys.argv.remove('-h')

