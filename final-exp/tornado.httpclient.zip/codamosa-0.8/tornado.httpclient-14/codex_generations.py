

# Generated at 2022-06-22 15:40:28.330667
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    async def test_working_http() -> None:
        """
        Test a simple working http request.
        """
        async with AsyncHTTPClient() as client:
            http_client = HTTPClient(async_client_class=type(client))
            response = http_client.fetch("https://www.google.com/")
            assert response.code == 200
            http_client.close()
    IOLoop.current().run_sync(test_working_http)

test_HTTPClient()



# Generated at 2022-06-22 15:40:30.177866
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def fetch_impl(self, request: HTTPRequest, callback: Callable[HTTPRequest, None]) -> None:
        pass
    
    assert True


# Generated at 2022-06-22 15:40:32.608559
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass

# Generated at 2022-06-22 15:40:34.040560
# Unit test for function main
def test_main():
    cli.main()
if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:40:34.613591
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-22 15:40:36.470725
# Unit test for function main
def test_main():
    if __name__ == 'httpclient.main':
        main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:40:48.186643
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, main
    import tornado
    import tornado.httpserver

    class MainTest(AsyncHTTPTestCase):
        def get_app(self):
            class EchoHandler(tornado.web.RequestHandler):
                def get(self):
                    self.write(self.request.headers['X-Foo'])

            return tornado.web.Application([('/', EchoHandler)])

        def test_main(self):
            self.http_client.fetch(
                self.get_url('/'), self.stop,
                method='GET', headers={'X-Foo': 'a value'})
            response = self.wait()
            self.assertEqual(response.body, b'a value')

    main()

if __name__ == "__main__":
    main()
#

# Generated at 2022-06-22 15:40:59.229012
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-22 15:40:59.779502
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    pass

# Generated at 2022-06-22 15:41:00.860294
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    c = AsyncHTTPClient()  # type: ignore
    print(c.io_loop)

# Generated at 2022-06-22 15:43:26.093022
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    http_client = httpclient.HTTPClient()
    try:
        response = http_client.fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    finally:
        http_client.close()



# Generated at 2022-06-22 15:43:30.918446
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    print("run test_AsyncHTTPClient_initialize")
    client = AsyncHTTPClient(force_instance=True)
    assert client.defaults == HTTPRequest._DEFAULTS
    client = AsyncHTTPClient(force_instance=True, defaults={"test_1": "test_2"})
    assert client.defaults == {**HTTPRequest._DEFAULTS, "test_1": "test_2"}



# Generated at 2022-06-22 15:43:34.479371
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    __tracebackhide__ = True
    AsyncHTTPClient.configure('tornado.curl_httpclient.CurlAsyncHTTPClient')
    return 'ok'


# Generated at 2022-06-22 15:43:45.267489
# Unit test for function main
def test_main():
    from tornado.testing import gen_test, AsyncTestCase, AsyncHTTPClient

    class MainTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
            self.http_client = AsyncHTTPClient(self.io_loop)

        @gen_test
        def test_main(self):
            url = self.get_url("/main_file")
            # create a file
            with open("/tmp/main_file", "w") as f:
                f.write("Hello World!")
            try:
                result = yield self.http_client.fetch(url)
                self.assertEqual(result.body, b"Hello World!")
            finally:
                os.remove

# Generated at 2022-06-22 15:43:51.747453
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    for client in [AsyncHTTPClient, SimpleAsyncHTTPClient]:
        # Use the async_client argument to avoid creating the
        # singleton if it doesn't already exist (so we don't
        # accidentally affect other tests)
        client(force_instance=True,
        defaults=dict(user_agent="MyUserAgent")).initialize()
        client(force_instance=True).initialize(
            defaults=dict(user_agent="MyUserAgent")
        )



# Generated at 2022-06-22 15:44:04.620595
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import bind_unused_port
    from tornado.web import RequestHandler, Application

    class TestHandler(RequestHandler):
        def get(self):
            self.write("get")

    class TestCase(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", TestHandler)])

        @gen_test(timeout=60)
        async def test_httpclient_singleton_per_instance(self):
            # AsyncHTTPClient is a singleton per IOLoop,
            # but we can have more than one IOLoop.
            client1 = AsyncHTTPClient(self.io_loop)
            client2 = AsyncHTTPClient()
            self.assertNotEqual(client1, client2)
            # Both clients can fetch something

# Generated at 2022-06-22 15:44:08.092545
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    request = HTTPRequest("http://www.google.com")
    _request = _RequestProxy(request, None)
    print(getattr(_request, "headers"))
    print(getattr(_request, "body"))
    print(getattr(_request, "method"))
    print(getattr(_request, "asdasdasd"))

# Generated at 2022-06-22 15:44:11.595170
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    instance = AsyncHTTPClient()
    close = AsyncHTTPClient.close
    assert isinstance(close, type)
    close = close.__get__(instance)
    close = functools.partial(close, instance)
    assert isinstance(close, functools.partial)



# Generated at 2022-06-22 15:44:18.434820
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import tornado.testing
    from tornado.test.util import unittest


    @unittest.skipIf(tornado.version_info < (4, ), "not supported in this tornado version")
    class AsyncHTTPClientTest(tornado.testing.AsyncHTTPTestCase):
        def get_app(self) -> Any:
            return self.app

        def test_AsyncHTTPClient(self) -> None:
            import tornado.simple_httpclient

            AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient", max_clients=10)
            self.assertIsInstance(AsyncHTTPClient(), tornado.simple_httpclient.SimpleAsyncHTTPClient)
            self.assertTrue(AsyncHTTPClient().max_clients, 10)

# Generated at 2022-06-22 15:44:20.040196
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    """test_AsyncHTTPClient___new__"""
    # TODO
    pass

# Generated at 2022-06-22 15:48:17.294570
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    assert AsyncHTTPClient.configurable_default().__name__ == 'SimpleAsyncHTTPClient'
    assert AsyncHTTPClient.configurable_base().__name__ == 'AsyncHTTPClient'



# Generated at 2022-06-22 15:48:17.952339
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 15:48:27.940601
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import tornado.testing
    def _handle_request(response):
        self.assertTrue(isinstance(response, HTTPResponse))
        self.assertEqual(response.code, 200)
        self.assertEqual(b"Hello", response.body)
        self.stop()
    class _MockAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(self, request, callback):
            self.io_loop.add_callback(callback, HTTPResponse(request, 200, buffer=BytesIO(b"Hello"), request_time=0.1))
    self.http_client = _MockAsyncHTTPClient()
    self.http_client.fetch("http://example.com/", self.stop)
    result = self.wait()

# Generated at 2022-06-22 15:48:29.148380
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest

    with pytest.raises(RuntimeError):
        AsyncHTTPClient.close()


# Generated at 2022-06-22 15:48:31.882201
# Unit test for function main
def test_main():
    import sys
    import os
    os.system(sys.executable + ' httpclient.py')



# Generated at 2022-06-22 15:48:32.791266
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    assert True



# Generated at 2022-06-22 15:48:34.123666
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    obj=HTTPResponse(None,None,None,None,None,None)


#-----------------------------------------------------------------------------------------------------------------------



# Generated at 2022-06-22 15:48:35.817076
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()

# Generated at 2022-06-22 15:48:42.522363
# Unit test for function main

# Generated at 2022-06-22 15:48:51.605167
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    d = {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
    }
    r = HTTPRequest("url", "method", body="", auth_username="123", auth_password="456", connect_timeout=10000, request_timeout=10000, follow_redirects=False, max_redirects=20, user_agent="me", decompress_response=False, proxy_host=None, proxy_port=None, proxy_username=None, proxy_password=None, proxy_auth_mode="basic", allow_nonstandard_methods=False, validate_cert=True, ca_certs=None, allow_ipv6=True, client_key=None, client_cert=None, ssl_options=None, expect_100_continue=False)
    rp = _