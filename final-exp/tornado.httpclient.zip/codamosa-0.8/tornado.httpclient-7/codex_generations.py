

# Generated at 2022-06-22 15:40:31.188276
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient

    AsyncHTTPClient.configure(None, defaults=dict(user_agent="MyUserAgent"))
    client = AsyncHTTPClient()  # type: ignore
    assert isinstance(client, SimpleAsyncHTTPClient)
    assert client.defaults == dict(user_agent="MyUserAgent", max_clients=10)
    client2 = AsyncHTTPClient()
    assert client is client2
    client.close()



# Generated at 2022-06-22 15:40:40.106213
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def fetch_impl(request, callback):
        print("first")
        print(request)
        response = HTTPResponse(request, 200, None, None, {})
        callback(response)
    
    kwargs = {'foo': 'bar'}
    AsyncHTTPClient.configure('AsyncHTTPClient', **kwargs)
    async_client = AsyncHTTPClient()
    async_client.fetch_impl = fetch_impl
    future = async_client.fetch('http://www.google.com')
    response = future.result()
    print("second")
    print(response.body)
    print(kwargs)
    print(response.__dict__)


# Generated at 2022-06-22 15:40:46.714871
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.gen import coroutine, Future
    
    # test AsyncHTTPClient.fetch_impl()
    async def f():
        http_client = AsyncHTTPClient()
        try:
            response = await http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)
        else:
            print(response.body)

    IOLoop.current().run_sync(f)
    
    # test AsyncHTTPClient.fetch_impl() with future
    @coroutine
    def f_future():
        http_client = AsyncHTTPClient()
        try:
            response = yield http_client.fetch("http://www.google.com")
        except Exception as e:
            print("Error: %s" % e)

# Generated at 2022-06-22 15:40:51.991889
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    @asyncio.coroutine
    def test():
        try:
            client = AsyncHTTPClient()
            client.close()
            assert client._closed == True
        except Exception as e:
            print('Error: ', e)
            assert False
        else:
            assert True

    loop = asyncio.get_event_loop()
    coro = test()
    future = asyncio.ensure_future(coro)
    loop.run_until_complete(future)


# Generated at 2022-06-22 15:40:59.511932
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    http_client = HTTPClient()
    try:
        response = httpclient.HTTPClient().fetch("http://www.google.com/")
        print(response.body)
    except httpclient.HTTPError as e:
        # HTTPError is raised for non-200 responses; the response
        # can be found in e.response.
        print("Error: " + str(e))
    except Exception as e:
        # Other errors are possible, such as IOError.
        print("Error: " + str(e))
    http_client.close()



# Generated at 2022-06-22 15:41:11.300408
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():

    # Test if the instance is initialized correctly by checking if the members
    # are correctly initialized or not.
    client = AsyncHTTPClient()
    client.initialize()
    assert client.io_loop.__class__ == IOLoop
    assert isinstance(client._closed, bool)
    assert isinstance(client.defaults, dict)
    client.close()
    # Test if the _closed is set to correct value after initialize()
    client = AsyncHTTPClient()
    client.initialize()
    assert client._closed == False
    client.close()
    # Test if the io_loop is set to correct value after initialize()
    client = AsyncHTTPClient()
    client.initialize()
    assert client.io_loop == IOLoop.current()
    client.close()


# Generated at 2022-06-22 15:41:24.339680
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    # test with an error
    request1 = HTTPRequest("www.google.com")
    response1 = HTTPResponse(request1, code=302, headers=None, buffer=None, effective_url=None, 
                        error=HTTPError(code=301, response=HTTPResponse(request1, code=301, error=None)), 
                        request_time=0.015, time_info={'starttransfer_time': 0.0, 'total_time': 0.015})
    try:
        response1.rethrow()
    except HTTPError:
        pass
    else:
        print("The exception is not passed to the next layer")

    # test without an error
    request2 = HTTPRequest("www.google.com")

# Generated at 2022-06-22 15:41:25.356070
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-22 15:41:37.777708
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():

    if __name__ == "__main__":
        # Test body
        request = HTTPRequest("https://www.tornadoweb.org")
        code = 200
        headers = httputil.HTTPHeaders()
        buffer = BytesIO()
        effective_url = "https://www.tornadoweb.org"
        error = None
        request_time = None
        time_info = None
        reason = None
        start_time = None
        http_response = HTTPResponse(request, code, headers, buffer, effective_url, error, request_time, time_info, reason, start_time)

        method_rethrow_result_true = http_response.rethrow()

        # Test body
        request = HTTPRequest("https://www.tornadoweb.org")
        code = 200

# Generated at 2022-06-22 15:41:41.806622
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    class request:
        def __init__(self):
            self.request = "request"
        def returnSelf(self):
            return self
    assert ("request" == _RequestProxy(request().returnSelf(), None).request)



# Generated at 2022-06-22 15:43:48.106534
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-22 15:43:49.006494
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    pass


# Generated at 2022-06-22 15:44:03.140435
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    import tornado.httpserver
    import tornado.netutil
    import tornado.web
    from tornado.escape import utf8
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import IOStream
    import tornado.testing
    import tornado.web
    import socket
    import functools
    class HTTPServerTest(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application([
                (r"/hello", HelloWorldHandler),
                (r"/close", CloseHandler),
            ])
        def test_large_response(self):
            self.http_client.fetch(self.get_url('/hello'), self.handle_response)
            # make sure no exceptions get thrown
            self

# Generated at 2022-06-22 15:44:12.633657
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import asynctest

    async def _test_AsyncHTTPClient_close(http_client: "AsyncHTTPClient") -> None:
        http_client._closed = True
        http_client.close()
        # check if calling close() twice has no effect
        http_client.close()
        http_client._closed = False
        http_client.close()

    asyncio_test(
        asynctest.mock.Mock(),
        _test_AsyncHTTPClient_close,
        http_client=AsyncHTTPClient(force_instance=True),
    )



# Generated at 2022-06-22 15:44:21.043289
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    # This method is called by __new__ __init__ when object type is AsyncHTTPClient
    # __new__ method should have signature __new__(cls, *args, **kwargs)
    # __new__ method should be staticmethod
    assert repr(AsyncHTTPClient) == "<class 'tornado.httpclient.AsyncHTTPClient'>"
    assert (
        repr(async_client)
        == "<tornado.httpclient.AsyncHTTPClient object at 0x7fb8877c0450>"
    )

# Generated at 2022-06-22 15:44:22.040359
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    AsyncHTTPClient()



# Generated at 2022-06-22 15:44:28.971093
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders

    class MyAsyncHTTPClient(AsyncHTTPClient):

        def __init__(self, **kwargs: Any) -> None:
            super().__init__(**kwargs)
            self.kwargs = kwargs

        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            callback(
                self.kwargs.get("response", None)
                or self.kwargs.get("response_callback")()
            )

    def assert_kwargs(expected_kwargs: Dict[str, Any], **override_kwargs: Any) -> None:
        client = My

# Generated at 2022-06-22 15:44:39.851878
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler, Application
    from tornado.httpserver import HTTPServer
    from tornado.testing import bind_unused_port
    from tornado.util import b
    import logging
    import os
    import signal
    import subprocess
    import sys
    import unittest

    # the test server replies with the current time
    class CurrentTimeHandler(RequestHandler):
        def get(self):
            self.write(str(self.application.current_time))

    class TestMain(AsyncHTTPTestCase, unittest.TestCase):
        def get_app(self):
            return Application([("/", CurrentTimeHandler)])

        def test_basic(self):
            self.http_server.current_time = 12345
            port = self.get_http_port()

# Generated at 2022-06-22 15:44:43.945900
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    mock = MagicMock()
    with patch.object(AsyncHTTPClient, 'fetch_impl', mock):
        request = HTTPRequest("http://www.google.com/")
        def myCallback(response):
            pass
        http_client = AsyncHTTPClient()
        http_client.fetch_impl(request, myCallback)
        mock.assert_called_with(request, myCallback)



# Generated at 2022-06-22 15:44:55.745342
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from typing import Dict
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop

    d = {}  # type: Dict[str, Any]
    d["_AsyncHTTPClient__instance_cache"] = None

    # Create the client while our IOLoop is "current", without
    # clobbering the thread's real current IOLoop (if any).
    async def make_client() -> "AsyncHTTPClient":
        await gen.sleep(0)
        assert d["AsyncHTTPClient"] is not None
        return d["AsyncHTTPClient"]()
    io_loop = IOLoop(make_current=False)
    d["AsyncHTTPClient"] = io_loop.run_sync(make_client)
    io_loop.close()

# Unit

# Generated at 2022-06-22 15:47:30.162304
# Unit test for method __getattr__ of class _RequestProxy

# Generated at 2022-06-22 15:47:35.663550
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def func_test_AsyncHTTPClient_fetch_impl(
            self: Any, request: Any, callback: Any) -> None:
        assert type(request) is _RequestProxy
        assert type(callback) is Callable
        assert type(request.request) is HTTPRequest

    from tornado.httpclient import AsyncHTTPClient

    AsyncHTTPClient.fetch_impl = func_test_AsyncHTTPClient_fetch_impl
    AsyncHTTPClient.configure(None)
    hc = AsyncHTTPClient()
    hc.fetch('http://www.baidu.com')
    test_AsyncHTTPClient_fetch_impl.__globals__['hc'].close()
    test_AsyncHTTPClient_fetch_impl.__globals__['AsyncHTTPClient'].configure(None)



# Generated at 2022-06-22 15:47:37.724129
# Unit test for function main
def test_main():
    try:
        main()
    except:
        pass



# Generated at 2022-06-22 15:47:39.230655
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:47:49.065123
# Unit test for function main
def test_main():
    import sys
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    from tornado.web import RequestHandler, Application

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

    class EchoHeaderHandler(RequestHandler):
        def get(self):
            self.write(self.request.headers.get("X-Foo", "Not set"))

    class MainTest(AsyncHTTPTestCase, LogTrapTestCase):
        def get_app(self):
            return Application([("/", MainHandler), ("/echo", EchoHeaderHandler)])

        def test_main(self):
            main()  # type: ignore

            # we can't access the AsyncHTTPClient directly, so we just
            # check its log output

# Generated at 2022-06-22 15:47:52.869574
# Unit test for function main
def test_main():
    Future()
    AsyncHTTPClient()
    # IOLoop()
    _RequestStartTimeMixin()
    _RequestProxy()
    HTTPResponse()
    HTTPClientError()
    HTTPError()
    HTTPRequest()

# Generated at 2022-06-22 15:47:58.908195
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    http_client = AsyncHTTPClient()
    def handle_response(response: "HTTPResponse") -> None:
        if response.error:
            if raise_error or not response._error_is_response_code:
                future_set_exception_unless_cancelled(future, response.error)
                return
        future_set_result_unless_cancelled(future, response)
    http_client.fetch_impl(cast(HTTPRequest, request_proxy), handle_response)

# Generated at 2022-06-22 15:48:00.137957
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # test for the initialize() method in class AsyncHTTPClient
    pass


# Generated at 2022-06-22 15:48:05.831960
# Unit test for function main
def test_main():
    from tornado.testing import AsyncHTTPTestCase, main, gen_test, LogTrapTestCase
    from tornado.web import RequestHandler
    from tornado.httputil import HTTPHeaders
    from urllib.parse import urlencode
    from tornado.concurrent import futures
    
    class HelloWorldHandler(RequestHandler):
        def initialize(self, status_code):
            self.set_status(status_code)

        def get(self):
            self.write("Hello world!")


# Generated at 2022-06-22 15:48:16.132943
# Unit test for function main
def test_main():
    from tornado import testing
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    from tornado.web import RequestHandler, Application
    import tornado.httpserver
    from tornado.httpclient import HTTPRequest, HTTPError
    from tornado.httputil import HTTPHeaders

    class HelloHandler(RequestHandler):
        def get(self):
            self.write('Hello, world')

    class GzipHandler(RequestHandler):
        def get(self):
            self.set_header('Content-Type', 'application/octet-stream')
            self.set_header('Content-Encoding', 'gzip')