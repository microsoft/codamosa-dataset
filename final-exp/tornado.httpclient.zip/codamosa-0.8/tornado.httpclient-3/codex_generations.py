

# Generated at 2022-06-22 15:40:27.665360
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 15:40:29.501555
# Unit test for function main
def test_main():
    # Nothing to test currently
    pass

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:40:38.760574
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    class DummyAsyncHTTPClient(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            pass

    x = DummyAsyncHTTPClient.configure(None)


# --------------------------
# _RequestProxy
# --------------------------

# This object is returned by AsyncHTTPClient.fetch.  It has the same
# interface as HTTPResponse, but it can be closed to cancel the
# request.  After it is closed, the HTTPResponse is available as
# self.response.

# Generated at 2022-06-22 15:40:49.748639
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import time
    import traceback
    import logging
    import multiprocessing
    import sys
    import getopt
    import os
    import random
    import signal
    import socket
    import sys
    import threading
    import time

    class Thread(threading.Thread):
        """Thread class with a stop() method. The thread itself has to check
        regularly for the stopped() condition."""

        def __init__(self, func, args=()):
            super().__init__(None, func, args)
            self._stop_event = threading.Event()

        def stop(self):
            self._stop_event.set()

        def stopped(self):
            return self._stop_event.is_set()

        def run(self):
            while not self.stopped():
                super().run()


# Generated at 2022-06-22 15:40:50.384070
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass


# Generated at 2022-06-22 15:41:02.694238
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    client = AsyncHTTPClient(force_instance=True)
    request = HTTPRequest(
        "http://www.baidu.com",
        method="GET",
        auth_username="xw",
        auth_password="123456",
        headers={"user-agent": "my-user-agent"},
        follow_redirects=True,
        max_redirects=5,
        allow_nonstandard_methods=False,
        validate_cert=False,
        proxy_host="localhost",
        proxy_port=8080,
        proxy_username="xw",
        proxy_password="123456",
    )
    request_proxy = _RequestProxy(request, None)
    print(request_proxy)
    print(request_proxy.request)
    print(request_proxy.defaults)

# Generated at 2022-06-22 15:41:06.010060
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    request = "http://www.google.com"
    response = HTTPClient().fetch(request)
    print(response.body)

# test_HTTPClient_fetch()


# Generated at 2022-06-22 15:41:10.200765
# Unit test for function main
def test_main():
    from tornado.testing import AsyncTestCase, gen_test
    class Test(AsyncTestCase):
        @gen_test
        def test_main(self):
            self.assertTrue(False)
    # Test construction of the HTTPClient class
    Test()
    self.assertTrue(False)
    # Test construction of the HTTPRequest class
    Test()
    self.assertTrue(False)
    # Test construction of the HTTPResponse class
    Test()
    self.assertTrue(False)
    # Test construction of the HTTPClientError class
    Test()
    self.assertTrue(False)
    # Test construction of the _RequestProxy class
    Test()
    self.assertTrue(False)
    # Testing function main
    main()
    self.assertTrue(False)

# Unit tests for the HTTPRequest class

# Generated at 2022-06-22 15:41:11.868878
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    return
AsyncHTTPClient.configure("tornado.simple_httpclient.SimpleAsyncHTTPClient")



# Generated at 2022-06-22 15:41:13.947546
# Unit test for function main
def test_main():
    args = 'https://httpbin.org/anything'
    client = HTTPClient()
    response = client.fetch(
        args,
        follow_redirects=True,
        validate_cert=True
    )
    assert response
    assert response.body


if __name__ == "__main__":
    main()  # type: ignore

# Generated at 2022-06-22 15:41:35.416976
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    class MainHandler(RequestHandler):
        def get(self):
            self.write("hello")
    class SomeRequestHandler(RequestHandler):
        def on_response(self, response):
            wait = self.get_argument("wait", None)
            if not wait:
                self.finish("ok")
            else:
                self.set_header("Did-Not-Close", "true")
                AsyncHTTPClient().fetch("http://example.com", self.on_response)


# Generated at 2022-06-22 15:41:37.087212
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    pass


# Generated at 2022-06-22 15:41:48.189950
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def mock_fetch_impl(request, callback):
        return True
    monkeypatch.setattr(AsyncHTTPClient, 'fetch_impl', mock_fetch_impl)
    a = AsyncHTTPClient()
    test_url = 'http://www.google.com'
    test_response = a.fetch(test_url)
    assert isinstance(a, AsyncHTTPClient)
    def mock_handle_response(response):
        return True
    monkeypatch.setattr(AsyncHTTPClient, 'handle_response', mock_handle_response)
    a.fetch_impl(test_response, mock_handle_response)
    assert isinstance(a, AsyncHTTPClient)


# Generated at 2022-06-22 15:41:52.069361
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    pass

# Generated at 2022-06-22 15:41:55.422578
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    async def async_test() -> None:
        cli = AsyncHTTPClient()
        cli.close()
    event_loop = asyncio.get_event_loop()
    event_loop.run_until_complete(async_test())

# Generated at 2022-06-22 15:41:57.003422
# Unit test for function main
def test_main():
    try:
        main()
    except Exception:
        pass


# Generated at 2022-06-22 15:42:05.548680
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    defaults = {"key0": "value0", "key1": "value1"}
    request = HTTPRequest("http://example.com")
    # test return attribute of request
    proxy = _RequestProxy(request, defaults)
    assert proxy.url == "http://example.com"
    # test return default attribute
    proxy = _RequestProxy(request, defaults)
    assert proxy.connect_timeout == 20
    # test return None
    proxy = _RequestProxy(request, None)
    assert proxy.connect_timeout is None


# Generated at 2022-06-22 15:42:15.885624
# Unit test for constructor of class HTTPRequest

# Generated at 2022-06-22 15:42:28.388872
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    from tornado.concurrent import Future

    # Simple test of fetch_impl to make sure it accepts a callback
    # and does not raise an exception.

    class DummyImpl(AsyncHTTPClient):
        def fetch_impl(
            self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
        ) -> None:
            callback(None)

    response = Future()

    def callback(response_future: Future[HTTPResponse]) -> None:
        response.set_result(None)

    # AsyncHTTPClient.fetch_impl is not part of the public API and
    # tests should not use it.  See test_httpclient.py for more
    # thorough testing of the AsyncHTTPClient interface.
    DummyImpl().fetch_impl(HTTPRequest("/"), callback)

# Generated at 2022-06-22 15:42:30.078388
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    __tracebackhide__ = True
    req = HTTPRequest(url="example.com")
    reqp = _RequestProxy(req, {"client_cert": "foo.pem"})
    assert None == reqp.method
    assert "foo.pem" == reqp.client_cert

# Generated at 2022-06-22 15:42:45.606543
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    c = AsyncHTTPClient()
    def handle_response(response: "HTTPResponse") -> None:
        pass
    with pytest.raises(NotImplementedError):
        c.fetch_impl(HTTPRequest("http://foo"), handle_response)

# Generated at 2022-06-22 15:42:50.065547
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import pytest
    
    with pytest.raises(NotImplementedError):
        # setUp function
        self = AsyncHTTPClient()
        # function to test
        request = HTTPRequest()
        callback = None
        self.fetch_impl(request, callback)


import typing
from typing import Any, Optional, Callable, Union, Tuple

import socket
import ssl

from tornado import iostream
from tornado.escape import native_str
from tornado.http1connection import HTTP1ConnectionParameters
from tornado.httputil import _DEFAULT_CA_CERTS, _DEFAULT_CA_PATH, _DEFAULT_CIPHERS
from tornado.locks import Event
from tornado.log import gen_log
from tornado.tcpserver import TCPServer
from tornado import gen
from tornado.iostream import StreamCl

# Generated at 2022-06-22 15:42:51.628555
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.ioloop import IOLoop
    i_loop = IOLoop.current()
    self_ = AsyncHTTPClient()
    del i_loop
    self_.close()

# Generated at 2022-06-22 15:42:53.893610
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    request = AsyncHTTPClient.request
    error = AsyncHTTPClient.error
    def callback():
        pass

    res = AsyncHTTPClient.fetch(request, callback)
    res = AsyncHTTPClient.fetch(request)
    res = AsyncHTTPClient.fetch(request, raise_error=False)



# Generated at 2022-06-22 15:43:03.982986
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import sys ,os
    import pytest
    print(os.path.dirname(os.path.abspath(__file__)))
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_tornado.util import unittest
    import test_tornado.gen_test
    import test_tornado.httpclient_test
    import test_tornado.httpserver_test
    import test_tornado.netutil_test


# Generated at 2022-06-22 15:43:09.433561
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
  class MockAsyncHTTPClient(tornado.httpclient.AsyncHTTPClient):
    def __init__(self):
      pass
    def fetch_impl(self, request, callback):
      pass
  with pytest.raises(NotImplementedError):
    MockAsyncHTTPClient().fetch_impl(request=None, callback=None)
    
    

# Generated at 2022-06-22 15:43:12.028642
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import string
    import random
    def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for _ in range(size))



# Generated at 2022-06-22 15:43:19.704301
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest


    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase


    from tornado import httpclient


    @unittest.skipIf(httpclient.AsyncHTTPClient is httpclient.SimpleAsyncHTTPClient, 'Only for CurlAsyncHTTPClient')
    class HTTPClientMainTest(AsyncHTTPTestCase, LogTrapTestCase):
        def get_app(self):
            return Application([('/', HelloWorldHandler)])

        def test_main(self):
            stream = io.BytesIO()
            cache_file = os.path.join(
                self.get_document_root(), "tornado", "httpclient.py"
            )

# Generated at 2022-06-22 15:43:23.176297
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    # create a mock object of class AsyncHTTPClient
    mock_obj = mock.MagicMock(spec=AsyncHTTPClient)
    request, callback = mock.MagicMock(), mock.MagicMock()
    # test the call with request_proxy
    request_proxy = _RequestProxy(request, mock_obj.defaults)
    print(mock_obj.fetch_impl.__doc__)
    mock_obj.fetch_impl(request_proxy, callback)
    mock_obj.assert_called_with(request_proxy, callback)


# Generated at 2022-06-22 15:43:29.300399
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    from datetime import timedelta
    from tornado.httputil import HTTPHeaders
    from tornado.ioloop import IOLoop
    from tornado.httputil import HTTPHeaders
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import pycurl

    # Get a curl handle that's configured for our test server.
    def get_curl_handle(**kwargs):
        # Get a curl handle that's configured for our test server.
        curl = pycurl.Curl()
        kwargs.setdefault('assert_same_host', False)
        kwargs.setdefault('cafile', self.get_ssl_options()['ca_certs'])
        self.set_curl_client_config(curl, **kwargs)
        return curl
    # Use the CurlAsyncHTTPClient,