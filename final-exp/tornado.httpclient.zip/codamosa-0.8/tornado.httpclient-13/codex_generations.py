

# Generated at 2022-06-22 15:40:12.027477
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    http_client = AsyncHTTPClient()
    http_client.close()


# Generated at 2022-06-22 15:40:16.520473
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.curl_httpclient import CurlAsyncHTTPClient

    assert isinstance(AsyncHTTPClient(), SimpleAsyncHTTPClient)

    AsyncHTTPClient.configure(CurlAsyncHTTPClient)
    assert isinstance(AsyncHTTPClient(), CurlAsyncHTTPClient)

    AsyncHTTPClient.configure(SimpleAsyncHTTPClient)
    assert isinstance(AsyncHTTPClient(), SimpleAsyncHTTPClient)

    AsyncHTTPClient.configure(None)
    assert isinstance(AsyncHTTPClient(), SimpleAsyncHTTPClient)


# Generated at 2022-06-22 15:40:20.972515
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import unittest

    class Testcase(unittest.TestCase):
        def test_fetch_impl(self):
            import string
            import random

            def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
                return "".join(random.choice(chars) for _ in range(size))

            class MyAsyncHTTPClient(AsyncHTTPClient):
                def fetch_impl(
                    self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
                ) -> None:
                    callback("")

            my_instance = MyAsyncHTTPClient()
            # print(my_instance.fetch("http://www.google.com"))
            self.assertEqual("", my_instance.fetch("http://www.google.com"))
           

# Generated at 2022-06-22 15:40:30.988988
# Unit test for function main
def test_main():
    with patch('tornado.httpclient.HTTPClient.fetch') as fetch:
        with patch('tornado.options.parse_command_line') as parse_command_line:
            with patch('tornado.options.options') as options:
                with patch('sys.argv', new=['http://www.test.com']):
                    parse_command_line.return_value = ["http://www.test.com"]
                    options.follow_redirects = True
                    options.validate_cert = True
                    options.proxy_host = '127.0.0.1'
                    options.proxy_port = 9090
                    main()
                    fetch.assert_called_once_with(ANY, validate_cert=True, proxy_host='127.0.0.1', proxy_port=9090, follow_redirects=True)

# Generated at 2022-06-22 15:40:40.766470
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    class_attr = "HTTPResponse"
    request = {'url': 'http://github.com', 'headers': {'User-Agent': 'Python/3.8', 'Accept-Encoding': 'gzip, deflate, compress', 'Accept': '*/*', 'Connection': 'keep-alive'}}
    code = 200
    headers = {'Server': 'GitHub.com', 'Date': 'Thu, 25 Jun 2020 21:52:45 GMT', 'X-GitHub-Request-Id': 'F8EC:5A5F:1BAA5:1C8E9:5EF566A6'}
    buffer = b''
    effective_url = 'http://github.com'
    error = None
    request_time = 0.9925270080566406

# Generated at 2022-06-22 15:40:42.030994
# Unit test for function main
def test_main():
    _RequestProxy('').__init__()

# Generated at 2022-06-22 15:40:51.112518
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    future = Future()
    io_loop = IOLoop.current()
    async_client = AsyncHTTPClient()
    async_client.initialize()
    assert async_client.defaults == {'allow_ipv6': True, 'connect_timeout': 20.0, 'network_interface': None, 'proxy_host': None, 'proxy_password': None, 'proxy_port': None, 'proxy_username': None, 'request_timeout': 20.0, 'user_agent': 'tornado/' + '.'.join(str(x) for x in tornado.version_info[0:2]), 'validate_cert': True, 'validate_cert_host': True, 'xheaders': False}
    assert async_client.io_loop == IOLoop.current()



# Generated at 2022-06-22 15:40:55.964496
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    body = BytesIO()
    h = HTTPResponse(HTTPRequest(url="www.google.com"), 200, headers = "test", buffer = body, effective_url = None, error = None, request_time = None, time_info = None, reason = "OK", start_time = None)
    print(h.__repr__())

test_HTTPResponse___repr__()



# Generated at 2022-06-22 15:41:02.685197
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():


    class MyAsyncHTTPClient(AsyncHTTPClient):
        pass

    class MyOtherAsyncHTTPClient(AsyncHTTPClient):
        pass

    # Make sure different classes get distinct caches
    assert AsyncHTTPClient._async_clients() is not MyAsyncHTTPClient._async_clients()
    assert (
        AsyncHTTPClient._async_clients() is not MyOtherAsyncHTTPClient._async_clients()
    )

    cache = AsyncHTTPClient._async_clients()
    io_loop = IOLoop.current()
    assert io_loop not in cache

    # Check singleton behavior
    async_client1 = AsyncHTTPClient()
    assert isinstance(async_client1, AsyncHTTPClient)
    assert io_loop in cache
    assert cache[io_loop] is async_client1


# Generated at 2022-06-22 15:41:14.422142
# Unit test for method __repr__ of class HTTPResponse
def test_HTTPResponse___repr__():
    obj = HTTPResponse(
        request=HTTPRequest(method='GET', url=URL('http://www.google.com/search')),
        code=200,
        headers=HTTPHeaders(Content_Type=[]),
        buffer=BytesIO(),
        effective_url=URL('http://www.google.com/search'),
        error=None,
        request_time=0.0001,
        time_info={},
        reason='OK',
        start_time=time.time(),
    )

# Generated at 2022-06-22 15:41:31.171801
# Unit test for method rethrow of class HTTPResponse
def test_HTTPResponse_rethrow():
    request = HTTPRequest('https://www.test.com')
    response = HTTPResponse(request, code = 200)
    try:
        response.rethrow()
    except Exception as e:
        print(e)

# test_HTTPResponse_rethrow()



# Generated at 2022-06-22 15:41:43.822513
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    client = AsyncHTTPClient()
    response = client.fetch('http://httpbin.org/get')

# Generated at 2022-06-22 15:41:46.110020
# Unit test for function main
def test_main():
    try:
        main()
    except (Exception, KeyboardInterrupt):
        pass


# Generated at 2022-06-22 15:41:54.833650
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    # Test for the default None case
    request = HTTPRequest('url')
    proxy = _RequestProxy(request, None)
    assert_equal(proxy.nonexistent, None)
    # Test when there is a value in self.request
    proxy = _RequestProxy(request, dict(method='method'))
    assert_equal(proxy.method, 'method')
    # Test when there is a value in self.defaults
    proxy = _RequestProxy(HTTPRequest('url'), dict(method='method'))
    assert_equal(proxy.method, 'method')



# Generated at 2022-06-22 15:41:56.392132
# Unit test for function main
def test_main():
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:42:04.959765
# Unit test for method fetch of class HTTPClient
def test_HTTPClient_fetch():
    async_client_class_ = AsyncHTTPClient
    kwargs_ = {}
    request_ = HTTPRequest("https://pytorch.org/docs/stable/torch.htmler-class.html")
    http_client = HTTPClient(async_client_class_, **kwargs_)
    response = http_client.fetch(request_)
    assert response.__class__.__name__ == "HTTPResponse"
    http_client.close()

test_HTTPClient_fetch()
 


# Generated at 2022-06-22 15:42:05.952242
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    assert False, "NYI"



# Generated at 2022-06-22 15:42:16.402913
# Unit test for function main
def test_main():
    content = main.__code__.co_consts[0][1]
    assert type(content) == bytes

# Generated at 2022-06-22 15:42:19.397515
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    response = AsyncHTTPClient.fetch_Impl(HTTPRequest, lambda: None)
    return response

# Generated at 2022-06-22 15:42:22.295544
# Unit test for constructor of class HTTPClient
def test_HTTPClient():
    client = HTTPClient()
    assert isinstance(client._async_client, AsyncHTTPClient)
    assert client._io_loop.is_running()


# Generated at 2022-06-22 15:42:32.386549
# Unit test for function main
def test_main():
    import sys

    sys.argv = ["/usr/bin/python", "--", "example.com"]
    assert main() is None
    assert sys.argv == ["/usr/bin/python", "--", "example.com"]


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:42:43.147286
# Unit test for method fetch of class AsyncHTTPClient

# Generated at 2022-06-22 15:42:45.091111
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    import doctest
    import tornado.simple_httpclient
    doctest.run_docstring_examples(
        tornado.simple_httpclient.SimpleAsyncHTTPClient.fetch_impl,
        globals(),
        name="SimpleAsyncHTTPClient.fetch_impl",
        optionflags=doctest.ELLIPSIS,
    )



# Generated at 2022-06-22 15:42:46.053521
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:42:57.981643
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    from tornado.escape import native_str
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPRequest
    import time
    import timeit
    from urllib.parse import urlparse
    url = 'http://www.baidu.com'
    request = HTTPRequest(url,
                          method="GET",
                          headers=HTTPHeaders({"Content-Type": "application/x-www-form-urlencoded"}),
                          body=None)
    t = timeit.Timer('httpclient.AsyncHTTPClient().fetch(request)', 'import tornado.httpclient;httpclient = tornado.httpclient')
    print(t.timeit(number=1))
    # http_client = AsyncHTTPClient()
    # future = http_client.fetch(request)
    # import time


# Generated at 2022-06-22 15:43:09.651389
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    import pytest
    from tornado.testing import AsyncHTTPTestCase
    import tornado.web
    import tornado.httpclient
    
    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("hello")
    class HelloHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("world")

    application = tornado.web.Application([
    (r"/", MainHandler),
    (r"/hello", HelloHandler),
    ])
    
    
    class MyTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return application
        def test_HTTPClient_close(self):
            http_client = tornado.httpclient.HTTPClient()
            response1 = http_client.fetch(self.get_url("/hello"))

# Generated at 2022-06-22 15:43:15.341509
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    request = HTTPRequest(url="http://www.google.com")
    call_back = lambda response : print(response.body)
    method = AsyncHTTPClient.fetch_impl(request, call_back)
    assert method == None
# class HTTPRequest


# Generated at 2022-06-22 15:43:22.325795
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    assert AsyncHTTPClient.fetch_impl({"url": "http://www.google.com/"})


if hasattr(AsyncHTTPClient, "configure"):
    _DefaultAsyncHTTPClient = AsyncHTTPClient.configure("")  # type: ignore
else:
    _DefaultAsyncHTTPClient = AsyncHTTPClient  # type: ignore



# Generated at 2022-06-22 15:43:24.431481
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    client = AsyncHTTPClient()
    client.close()


# Generated at 2022-06-22 15:43:25.455145
# Unit test for function main
def test_main():
    pass

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:43:43.504993
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def outer_fetch(request, callback):
        nonlocal ret
        ret = request
        callback(ret)
    fetch_impl = AsyncHTTPClient.fetch_impl
    AsyncHTTPClient.fetch_impl = outer_fetch
    headers = {"Host": "www.google.com",
               "Accept-Encoding": "identity"}
    request = HTTPRequest("http://www.google.com/", "GET", headers)
    client = AsyncHTTPClient()
    future = client.fetch("http://www.google.com/",
                          raise_error=False,
                          request_timeout=1000)
    assert future == ret
    assert request == AsyncHTTPClient.fetch_impl.__wrapped__
    AsyncHTTPClient.fetch_impl = fetch_impl
    return request

# Unit test

# Generated at 2022-06-22 15:43:48.853276
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    print("\n[start test_AsyncHTTPClient_fetch_impl]")
    response = AsyncHTTPClient().fetch("http://127.0.0.1:8081/")
    print(response)
    response_body = response.body.decode("utf-8")
    print("response_body: ", end="")
    print(response_body)
    print("[end test_AsyncHTTPClient_fetch_impl]")


# Generated at 2022-06-22 15:43:51.973355
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    obj = AsyncHTTPClient()
    obj.initialize(defaults=None)
    assert obj.io_loop != None


# Generated at 2022-06-22 15:44:04.534631
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # self = AsyncHTTPClient()
    self._closed = True
    self._io_loop = IOLoop(make_current=False)
    class async_client_class:
        def __init__(self, **kwargs):
            pass

        def close(self):
            pass
    # self._async_client = self._io_loop.run_sync(make_client)
    self._async_client = async_client_class()
    self._closed = False
    # def __del__(self):
    #     self.close()
    # def close(self):
    if not self._closed:
        self._async_client.close()
        self._io_loop.close()
        self._closed = True
    return True


# Generated at 2022-06-22 15:44:09.629770
# Unit test for function main
def test_main():
    # Test when host is valid
    global args
    args = ["www.google.com"]
    client = HTTPClient()
    response = client.fetch('https://www.google.com')
    print(response.headers)
    print(native_str(response.body))
    client.close()
    assert(response.body != b'')
    args = ["www.abc.com"]
    response = client.fetch('https://www.abc.com')
    client.close()
    assert(response.body == b'')


# Generated at 2022-06-22 15:44:12.277458
# Unit test for method close of class AsyncHTTPClient
def test_AsyncHTTPClient_close():
    # type: () -> None
    cls = AsyncHTTPClient()
    assert cls.close is not None


# Generated at 2022-06-22 15:44:18.988668
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    # initialize(self, defaults=None)
    import time
    import unittest

    from tornado import escape
    from tornado.http1connection import HTTP1ConnectionParameters
    from tornado import httputil
    from tornado.iostream import IOStream
    from tornado.testing import AsyncHTTPTestCase, ExpectLog, LogTrapTestCase
    from tornado.test.util import unittest
    from tornado.web import RequestHandler, Application, asynchronous, stream_request_body
    from tornado.httputil import HTTPServerRequest

    class ConnectionState(object):
        def __init__(self, client) -> None:
            self.client = client

        def _on_finish(self, data) -> None:
            self.client.on_finish(data)


# Generated at 2022-06-22 15:44:20.879053
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    request = "test"
    raise_error = True
    print(AsyncHTTPClient().fetch(request,raise_error))

test_AsyncHTTPClient_fetch()


# Generated at 2022-06-22 15:44:28.355316
# Unit test for function main
def test_main():
    from io import StringIO
    import sys
    import unittest
    import tornado

    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase, gen_test
    from tornado.web import Application, RequestHandler
    from tornado.options import define

    define("test_main", type=bool, default=False)
    define("test_main_async", type=bool, default=False)

    @gen_test
    def test_main_async():
        from tornado.options import options
        options.test_main_async = True

# Generated at 2022-06-22 15:44:39.744056
# Unit test for function main
def test_main():
    from tornado.simple_httpclient import _HTTPConnection
    from tornado.util import bytes_type

    assert _HTTPConnection.STREAMING_CHUNK_SIZE == 65536

    # test case for the main function
    httpclient_reload()
    from tornado.test.util import unittest
    from tornado.test.httpclient_test import _TestHTTPConnectionDelegate
    from tornado.test.util import ObjectDict

    class DummyHTTPClient(HTTPClient):
        _HTTPConnection = _TestHTTPConnectionDelegate

    # Test chunked encoding
    client = DummyHTTPClient()

# Generated at 2022-06-22 15:46:27.620022
# Unit test for method fetch of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch():
    def test_handle_response(response: "HTTPResponse") -> None:
        if response.error:
            if raise_error or not response._error_is_response_code:
                future_set_exception_unless_cancelled(future, response.error)
                return
        future_set_result_unless_cancelled(future, response)
    
    
    cls = AsyncHTTPClient()
    # HTTPRequest
    request = HTTPRequest(url='http://www.google.com/')
    future = Future()
    cls.fetch_impl(request, test_handle_response)
    # HTTPRequest with raise_error = True
    request = HTTPRequest(url='http://www.google.com/')
    future = Future()

# Generated at 2022-06-22 15:46:31.720988
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    print("0")
    def fetch_impl(
        self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]
    ) -> None:
        return

# Generated at 2022-06-22 15:46:37.939098
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    import tornado.httpclient
    from tornado.platform.asyncio import AsyncIOMainLoop

    loop = AsyncIOMainLoop()
    loop.make_current()
    client = tornado.httpclient.AsyncHTTPClient()
    assert client is tornado.httpclient.AsyncHTTPClient()
    client.close()
    client = tornado.httpclient.AsyncHTTPClient(force_instance=True)
    assert client is not tornado.httpclient.AsyncHTTPClient()
    client.close()
    loop.close()



# Generated at 2022-06-22 15:46:39.022060
# Unit test for function main
def test_main():
  import tornado_test
  tornado_test.main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-22 15:46:41.738682
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    http_client = AsyncHTTPClient(force_instance=True)
    print(isinstance(http_client, AsyncHTTPClient))
    assert isinstance(http_client, AsyncHTTPClient)



# Generated at 2022-06-22 15:46:45.942254
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    set_expected_exceptions(NotImplementedError)
    def main():
        class MyAsyncHTTPClient(AsyncHTTPClient):
            def fetch_impl(self, request: "HTTPRequest", callback: Callable[["HTTPResponse"], None]) -> None:
                pass
        MyAsyncHTTPClient().fetch_impl(HTTPRequest('url'), lambda r: None)
    main()


httpclient = HTTPClient()


# Generated at 2022-06-22 15:46:46.508458
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass



# Generated at 2022-06-22 15:46:51.008509
# Unit test for method __new__ of class AsyncHTTPClient
def test_AsyncHTTPClient___new__():
    from tornado.httputil import HTTPHeaders
    from tornado.simple_httpclient import _HTTPConnection
    class A(AsyncHTTPClient):
        def initialize(self, **kwargs: Any) -> None:
            self.defaults = dict(HTTPRequest._DEFAULTS)
            self.defaults.update(kwargs)
    h = HTTPHeaders()
    h.add('Host', 'example.com')
    h.add('Accept-Encoding', 'gzip')
    a = A(defaults=dict(user_agent='TornadoTest/1.0', headers=h))
    b = AsyncHTTPClient()
    assert isinstance(a, type(b))
    assert a.defaults["headers"] == h
    assert a.defaults["user_agent"] == "TornadoTest/1.0"
   

# Generated at 2022-06-22 15:46:51.576204
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    def run_test():
        pass


# Generated at 2022-06-22 15:46:51.976410
# Unit test for method initialize of class AsyncHTTPClient
def test_AsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-22 15:49:56.536386
# Unit test for method __getattr__ of class _RequestProxy
def test__RequestProxy___getattr__():
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import _RequestProxy
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.web import Application
    from tornado.web import url
    from tornado.httpclient import HTTPError
    import time
    import datetime
    import unittest
    import os.path
    import sys
    import logging
    import tornado
    import urllib
    import urllib.parse as urlparse
    import threading
    import socket
    import ssl
    import concurrent.futures
    import certifi
    import re
    import base64
    import hashlib
    import inspect
    import textwrap
    import html
    import json
    import http.cookies

# Generated at 2022-06-22 15:49:57.127756
# Unit test for method fetch_impl of class AsyncHTTPClient
def test_AsyncHTTPClient_fetch_impl():
    pass
