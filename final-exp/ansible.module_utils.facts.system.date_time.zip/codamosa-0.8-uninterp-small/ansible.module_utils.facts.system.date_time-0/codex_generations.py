

# Generated at 2022-06-24 23:52:40.972951
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_1.collect(), dict)
    assert isinstance(date_time_fact_collector_1.collect(), type({}))
    assert isinstance(date_time_fact_collector_1.collect().keys(), list)
    assert isinstance(date_time_fact_collector_1.collect().keys(), type([]))
    assert not isinstance(date_time_fact_collector_1.collect().keys(), str)
    assert not isinstance(date_time_fact_collector_1.collect().keys(), bytes)
    assert not isinstance(date_time_fact_collector_1.collect().keys(), type(None))

# Generated at 2022-06-24 23:52:43.109119
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Run method collect of DateTimeFactCollector
    date_time_fact_collector_collect_0 = DateTimeFactCollector().collect()
    # Confirm the values are of the type returned in the documentation
    assert(isinstance(date_time_fact_collector_collect_0, dict))

# Generated at 2022-06-24 23:52:45.094158
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:52:48.431929
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0, DateTimeFactCollector)

# Generated at 2022-06-24 23:52:49.977098
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:58.309366
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:53:04.148637
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    date_time_facts = date_time_fact_collector_0.collect()

    if 'date_time' in date_time_facts:
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:53:08.148068
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:53:11.060446
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:53:20.116785
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

    # Test with no arguments
    assert not date_time_fact_collector_1.collect()
    # TODO: fix this test
    #assert isinstance(date_time_fact_collector_1.collect(), dict)
    #assert isinstance(date_time_fact_collector_1.collect()['date_time'], dict)
    #assert date_time_fact_collector_1.collect()['date_time']['year'], str
    #assert date_time_fact_collector_1.collect()['date_time']['month'], str
    #assert date_time_fact_collector_1.collect()['date_time']['weekday'], str
    #assert date_time_fact_collector_

# Generated at 2022-06-24 23:53:26.759232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts = {}
    result = date_time_fact_collector_0.collect()
    assert result is None


# Generated at 2022-06-24 23:53:31.627896
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    expected_keys = [
        'year',
        'month',
        'weekday',
        'weekday_number',
        'weeknumber',
        'day',
        'hour',
        'minute',
        'second',
        'epoch',
        'epoch_int',
        'date',
        'time',
        'iso8601_micro',
        'iso8601',
        'iso8601_basic',
        'iso8601_basic_short',
        'tz',
        'tz_dst',
        'tz_offset',
    ]
    date_time_facts = date_time_fact_collector_0.collect()['date_time']
    assert set(date_time_facts.keys()) == set

# Generated at 2022-06-24 23:53:33.402363
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert(date_time_fact_collector_0.collect() is not None)


# Generated at 2022-06-24 23:53:42.338772
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector = DateTimeFactCollector()
    date_time_facts = date_time_collector.collect()

    date_time_facts = date_time_facts['date_time']

    epoch = date_time_facts['epoch']

    assert isinstance(int(epoch), int)
    assert int(epoch) > 0

    assert len(date_time_facts['iso8601_micro']) == len('YYYY-MM-DDThh:mm:ss.mmmZ')

    assert len(date_time_facts['iso8601']) == len('YYYY-MM-DDThh:mm:ssZ')

    assert len(date_time_facts['iso8601_basic']) > len('YYYYMMDDTHHMMSSmmm')


# Generated at 2022-06-24 23:53:48.756719
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts_dict_0 = date_time_fact_collector_0.collect()
    assert date_time_facts_dict_0['date_time']['day'] == datetime.datetime.now().strftime('%d')
    assert date_time_facts_dict_0['date_time']['iso8601_basic'] == datetime.datetime.now().strftime("%Y%m%dT%H%M%S%f")


# Generated at 2022-06-24 23:53:58.261278
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    facts_dict = date_time_fact_collector_1.collect()
    assert facts_dict['date_time']['year'] is not None, "date_time_fact_collector_1.collect: date_time.year"
    assert facts_dict['date_time']['month'] is not None, "date_time_fact_collector_1.collect: date_time.month"
    assert facts_dict['date_time']['weekday'] is not None, "date_time_fact_collector_1.collect: date_time.weekday"

# Generated at 2022-06-24 23:54:00.081012
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:54:10.706431
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()

    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.name == 'date_time'
    assert date_time_fact_collector_0._fact_ids == set()

    date_time_facts_dict = date_time_fact_collector_0.collect()
    assert date_time_facts_dict['date_time']['year'] == now.strftime('%Y')
    assert date_time_facts_dict['date_time']['month'] == now.strftime('%m')
    assert date_time_facts_dict['date_time']['weekday'] == now.strftime('%A')

# Generated at 2022-06-24 23:54:16.670345
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    keys = [
        'iso8601_basic', 'date', 'epoch_int', 'tz_offset', 'weekday',
        'iso8601_basic_short', 'epoch', 'iso8601', 'time', 'weekday_number',
        'hour', 'tz', 'iso8601_micro', 'day', 'month', 'year', 'minute',
        'second', 'weeknumber', 'tz_dst'
    ]
    result_set = set(dtfc.collect().keys())
    assert result_set == set(keys)

# Generated at 2022-06-24 23:54:25.992124
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_1.collect()['date_time']
    assert date_time_facts['year'][:4] == now.strftime("%Y")
    assert date_time_facts['month'][:2] == now.strftime("%m")
    assert date_time_facts['weekday'][:3] == now.strftime("%A")[:3]
    assert date_time_facts['weekday_number'][:1] == now.strftime("%w")[:1]

# Generated at 2022-06-24 23:54:44.412627
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    now = datetime.datetime.now()
    utcnow = datetime.datetime.utcnow()
    date_time_facts_0 = date_time_fact_collector_0.collect()
    date_time_facts_0_0 = date_time_facts_0.get('date_time')
    date_time_facts_0_0_0 = date_time_facts_0_0.get('year')
    assert date_time_facts_0_0_0 == now.strftime('%Y')
    date_time_facts_0_0_1 = date_time_facts_0_0.get('month')
    assert date_time_facts_0_0_1 == now.strftime('%m')
   

# Generated at 2022-06-24 23:54:46.744554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector.collect(None, None), dict)

# Generated at 2022-06-24 23:54:53.380327
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    #
    # Setup code for test_case_0
    #
    test_case_0()

    #
    #
    #
    # CODE FOR TEST CASE 0 STARTS HERE
    #
    #
    #
    # get the collect method of DateTimeFactCollector
    get_collect = getattr(date_time_fact_collector_0, "collect")
    # call the method get_collect
    fact = get_collect()
    print(fact)
    #
    #
    #
    # CODE FOR TEST CASE 0 ENDS HERE
    #
    #
    #
    # #
    # Setup code for test_case_1
    #
    #
    #
    # CODE FOR TEST CASE 1 STARTS HERE
    #
    #
    #
    #
    # #
    # Setup code for test

# Generated at 2022-06-24 23:55:04.886761
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # create an instance of DateTimeFactCollector
    date_time_fact_collector_1 = DateTimeFactCollector()
    # call collect of DateTimeFactCollector
    result = date_time_fact_collector_1.collect()
    # check if result is a dict
    if isinstance(result, dict) is False:
        raise AssertionError("Expected an instance of dict, got {0} instead.".format(
            repr(result.__class__)))
    # check if result['date_time'] is a dict
    if isinstance(result['date_time'], dict) is not True:
        raise AssertionError("Expected dict, got {0} instead.".format(
            repr(result['date_time'].__class__)))
    # get a new instance of DateTimeFactCollector
    date

# Generated at 2022-06-24 23:55:07.816740
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:12.663517
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()

    assert('date_time' in result)


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:55:14.434747
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect = DateTimeFactCollector()
    date_time_fact_collector_collect.collect()

# Generated at 2022-06-24 23:55:16.686026
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:19.960052
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:55:32.539873
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()
    date_time_facts = collected_facts['date_time']
    now = datetime.datetime.now()
    assert int(date_time_facts['year']) == now.year
    assert int(date_time_facts['weekday_number']) == now.weekday()
    assert int(date_time_facts['weeknumber']) == now.isocalendar()[1]
    assert int(date_time_facts['day']) == now.day
    assert int(date_time_facts['hour']) == now.hour
    assert int(date_time_facts['minute']) == now.minute
    assert int(date_time_facts['second']) == now.second

# Generated at 2022-06-24 23:55:52.436556
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

    date_time_facts = date_time_fact_collector_1.collect()
    assert date_time_facts['date_time'] is not None

# Generated at 2022-06-24 23:55:59.370184
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    m_datetime_datetime_0 = datetime.datetime()
    m_datetime_datetime_0.strftime = Mock()
    m_time_time_0 = time.time()
    m_time_time_0 = Mock()
    m_time_time_0.__float__ = Mock(return_value=0.0)
    m_time_time_0.__int__ = Mock(return_value=0)
    m_time_time_0.__trunc__ = Mock(return_value=0)
    m_time_time_0.__mod__ = Mock(return_value=0.0)
    m_time_time_1 = time.time()
    m_time_time_1 = Mock()

# Generated at 2022-06-24 23:56:03.638510
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert type(date_time_fact_collector_0.collect()) is dict
    assert isinstance(date_time_fact_collector_0, DateTimeFactCollector)


# Generated at 2022-06-24 23:56:08.088648
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:19.790799
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    edtc0 = DateTimeFactCollector()
    factsdict = edtc0.collect()
    assert isinstance(factsdict, dict)
    assert 'date_time' in factsdict
    date_time_dict = factsdict.get('date_time')
    assert isinstance(date_time_dict, dict)
    assert 'year' in date_time_dict
    assert isinstance(date_time_dict.get('fqdn'), str)
    assert date_time_dict.get('year').isdigit()
    assert 'month' in date_time_dict
    assert date_time_dict.get('month').isdigit()
    assert 'weekday' in date_time_dict
    assert isinstance(date_time_dict.get('weekday'), str)
    assert 'weekday_number' in date_time_

# Generated at 2022-06-24 23:56:26.492784
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_module_0 = AnsibleModule(argument_spec={})
    ansible_module_0.params['gather_subset'] = ['!all', 'network']
    ansible_module_0.params['filter'] = 'ipv4'
    ansible_module_0.params['gather_network_resources'] = ['interface']
    ansible_module_0.params['validate_certs'] = True
    ansible_module_0.params['include_ipv6'] = True
    ansible_module_0.params['config_profile'] = 'test_value_3'
    ansible_module_0.params['fail_on_missing_params'] = True

# Generated at 2022-06-24 23:56:28.275872
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:56:39.701090
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert isinstance(result, dict)
    assert 'date_time' in result
    assert isinstance(result['date_time'], dict)
    assert 'year' in result['date_time']
    assert isinstance(result['date_time']['year'], str)
    assert 'month' in result['date_time']
    assert isinstance(result['date_time']['month'], str)
    assert 'weekday' in result['date_time']
    assert isinstance(result['date_time']['weekday'], str)
    assert 'weekday_number' in result['date_time']
    assert isinstance(result['date_time']['weekday_number'], str)
    assert 'weeknumber' in result['date_time']

# Generated at 2022-06-24 23:56:41.543910
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:56:47.222597
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_fact_0 = DateTimeFactCollector()
    assert isinstance(test_fact_0._fact_ids, set)
    test_fact_1 = {}
    assert isinstance(test_fact_1, dict)
    test_fact_2 = DateTimeFactCollector()
    assert isinstance(test_fact_2.get_facts(), dict)
    assert isinstance(test_fact_2._fact_ids, set)

# Generated at 2022-06-24 23:57:25.745434
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    module_1 = object()
    collected_facts_1 = object()

# Generated at 2022-06-24 23:57:36.795453
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_date_time_fact_collector = DateTimeFactCollector()
    test_date_time_fact_collector_collect = test_date_time_fact_collector.collect()
    assert test_date_time_fact_collector_collect['date_time']['date']
    assert test_date_time_fact_collector_collect['date_time']['day']
    assert test_date_time_fact_collector_collect['date_time']['hour']
    assert test_date_time_fact_collector_collect['date_time']['iso8601_basic']
    assert test_date_time_fact_collector_collect['date_time']['iso8601_basic_short']

# Generated at 2022-06-24 23:57:43.150125
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Instance creation for test
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Call of method
    output = date_time_fact_collector_0.collect(module=None, collected_facts=None)

    assert output
    assert isinstance(output, dict)
    assert 'date_time' in output
    assert isinstance(output['date_time'], dict)

# Generated at 2022-06-24 23:57:44.588744
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:57:54.177965
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # no args passed
    dummy_date = datetime.datetime(2000, 5, 1, 20, 15, 1)
    dummy_date_str = '%Y-%m-%d'
    dummy_time_str = '%H:%M:%S'

    def fake_datetime(x):
        return dummy_date

    def fake_datetime_strftime(x):
        if 'date' in x:
            return dummy_date.strftime(dummy_date_str)
        elif 'time' in x:
            return dummy_date.strftime(dummy_time_str)
        else:
            return dummy_date.strftime(x)

    date_time_fact_collector_collect = DateTimeFactCollector()

# Generated at 2022-06-24 23:57:56.333939
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:00.176579
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:01.776528
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert isinstance(DateTimeFactCollector().collect(), dict)

# Generated at 2022-06-24 23:58:10.149365
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect()['date_time']['year'] == '2017'
    assert date_time_fact_collector_1.collect()['date_time']['month'] == '11'
    assert date_time_fact_collector_1.collect()['date_time']['weekday'] == 'Sunday'
    assert date_time_fact_collector_1.collect()['date_time']['weekday_number'] == '7'
    assert date_time_fact_collector_1.collect()['date_time']['weeknumber'] == '45'
    assert date_time_fact_collector_1.collect()['date_time']['day'] == '12'
   

# Generated at 2022-06-24 23:58:13.043832
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert len(date_time_fact_collector.collect(module=None, collected_facts=None)) == 1


# Generated at 2022-06-24 23:59:25.254408
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    now = datetime.datetime.today().strftime("%Y-%m-%dT%H:%M:%SZ")
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:59:34.178433
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_dict = {}
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect(test_dict)

# Generated at 2022-06-24 23:59:37.280166
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    return


# Generated at 2022-06-24 23:59:43.177351
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts_dict_0 = date_time_fact_collector_0.collect()
    assert type(date_time_facts_dict_0) is dict


# Generated at 2022-06-24 23:59:53.066054
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts = DateTimeFactCollector().collect()

# Generated at 2022-06-24 23:59:57.978858
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts_dict = date_time_fact_collector_0.collect()
    assert date_time_facts_dict['date_time']['minute'] == "28"
    assert date_time_facts_dict['date_time']['hour']   == "23"
    assert date_time_facts_dict['date_time']['tz']     == "CET"


# Generated at 2022-06-25 00:00:04.456968
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    input_params = {}
    input_params['module'] = None
    input_params['collected_facts'] = None
    date_time_fact_collector = DateTimeFactCollector()
    returned_value = date_time_fact_collector.collect(**input_params)

    assert returned_value is not None
    assert returned_value['date_time']['year'] is not None
    assert returned_value['date_time']['month'] is not None
    assert returned_value['date_time']['weekday'] is not None
    assert returned_value['date_time']['weekday_number'] is not None
    assert returned_value['date_time']['weeknumber'] is not None
    assert returned_value['date_time']['day'] is not None

# Generated at 2022-06-25 00:00:06.276496
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-25 00:00:11.796659
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector._module = None
    date_time_fact_collector._collect_subset = None
    date_time_fact_collector._gather_subset = None
    date_time_fact_collector._gather_network_resources = None
    date_time_fact_collector.collect()

# Generated at 2022-06-25 00:00:17.910496
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1._module = None
    date_time_fact_collector_1._collect_subset = None
    date_time_fact_collector_1._gather_subset = None
    date_time_fact_collector_1._gather_network_resources = None
    date_time_fact_collector_1._gather_subset = [u'date_time']
    date_time_facts = {}
    collected_facts = {}
    collected_facts['ansible_facts'] = {'date_time': {}}
    collected_facts['ansible_facts']['date_time']['epoch_int'] = '1587651373'

# Generated at 2022-06-25 00:01:40.015599
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:41.416619
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-25 00:01:52.085554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert 'date_time' in var_1
    assert isinstance(var_1['date_time'], dict)
    assert 'epoch_int' in var_1['date_time']
    assert 'tz_dst' in var_1['date_time']
    assert 'epoch' in var_1['date_time']
    assert 'time' in var_1['date_time']
    assert 'weekday_number' in var_1['date_time']
    assert 'iso8601' in var_1['date_time']
    assert 'day' in var_1['date_time']

# Generated at 2022-06-25 00:01:53.127844
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert callable(DateTimeFactCollector.collect)


# Generated at 2022-06-25 00:01:58.446217
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-25 00:02:09.254747
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Set up mock
    date_time_fact_collector = DateTimeFactCollector()

    # Invoke method
    answer = date_time_fact_collector.collect()

# Generated at 2022-06-25 00:02:10.725832
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:02:14.929797
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1 == var_0

# Generated at 2022-06-25 00:02:24.936010
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1['date_time']['date'] == '2019-01-12'
    assert var_1['date_time']['epoch'] == '1547291939'
    assert var_1['date_time']['epoch_int'] == '1547291939'
    assert var_1['date_time']['hour'] == '10'
    assert var_1['date_time']['iso8601'] == '2019-01-12T10:39:14Z'
    assert var_1['date_time']['iso8601_basic'] == '20190112T1039144441'

# Generated at 2022-06-25 00:02:28.621831
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = DateTimeFactCollector()
    var_0.collect(collected_facts=dict())
    var_1 = DateTimeFactCollector()
    var_1.collect(module=None, collected_facts=dict())
    var_2 = DateTimeFactCollector()
    var_2.collect()

if __name__ == '__main__':
    test_DateTimeFactCollector_collect()
    test_case_0()