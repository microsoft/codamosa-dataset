

# Generated at 2022-06-24 23:52:40.089501
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    fact_instance = {}
    result = date_time_fact_collector.collect(fact_instance)
    assert type(result) is dict,\
        "Incorrect data type returned."

# Generated at 2022-06-24 23:52:49.117107
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()

    assert type(result) == dict
    assert 'date_time' in result
    assert type(result['date_time']) == dict

    date_time = result['date_time']

    assert type(date_time['year']) == str
    assert type(date_time['month']) == str
    assert type(date_time['weekday']) == str
    assert type(date_time['weekday_number']) == str
    assert type(date_time['weeknumber']) == str
    assert type(date_time['day']) == str
    assert type(date_time['hour']) == str
    assert type(date_time['minute']) == str

# Generated at 2022-06-24 23:52:51.395237
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector_1 = DateTimeFactCollector()

    ret = date_time_fact_collector_1.collect()
    assert type(ret) is dict
    assert 'date_time' in ret


# Generated at 2022-06-24 23:52:55.560619
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collect_return_value_1 = date_time_fact_collector_1.collect()
    assert collect_return_value_1 != {}, "DateTimeFactCollector.collect returned the wrong value."

# Generated at 2022-06-24 23:52:59.396669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result_0 = date_time_fact_collector_0.collect()
    assert len(result_0) == 1
    assert 'date_time' in result_0.keys()


# Generated at 2022-06-24 23:53:03.998449
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['day'] == time.strftime('%d')

# Generated at 2022-06-24 23:53:09.035414
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    output_dict_0 = date_time_fact_collector_1.collect()
    assert 'date_time' in output_dict_0


# Generated at 2022-06-24 23:53:11.061479
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:18.112629
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Mock of module
    module_mock = '''Mock of module'''
    # Mock of collected_facts
    collected_facts_mock = '''Mock of collected_facts'''
    # Instantiation of class object DateTimeFactCollector
    date_time_fact_collector_obj = DateTimeFactCollector()
    # Call of method collect of class DateTimeFactCollector
    date_time_fact_collector_obj.collect(module=module_mock, collected_facts=collected_facts_mock)

# Generated at 2022-06-24 23:53:28.048265
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1_facts = date_time_fact_collector_1.collect()
    assert date_time_fact_collector_1_facts is not None
    assert date_time_fact_collector_1_facts['date_time']['epoch'] == str(int(time.time()))
    assert date_time_fact_collector_1_facts['date_time']['tz_dst'] == time.tzname[1]

# Generated at 2022-06-24 23:53:34.117932
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Run module code in unit test which sets return value from class collect
    # function to a local variable named result
    date_time_fact_collector_1 = DateTimeFactCollector()
    result = date_time_fact_collector_1.collect()

    # Test collect function return value is a dict with valid key
    assert result['date_time']
    # Test collect function return value is a dict with a non-empty value
    assert result['date_time'] is not None

# Generated at 2022-06-24 23:53:39.245899
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:44.721272
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert isinstance(date_time_facts, dict)
    assert 'date_time' in date_time_facts
    assert isinstance(date_time_facts['date_time'], dict)

# Generated at 2022-06-24 23:53:46.042551
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:53:47.606499
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:53:58.168157
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts = {}

# Generated at 2022-06-24 23:53:59.643442
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:54:10.584660
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    ret_val_1 = date_time_fact_collector_1.collect()
    assert ret_val_1 is not None
    assert isinstance(ret_val_1, dict)
    assert 'date_time' in ret_val_1
    date_time_facts_1 = ret_val_1['date_time']
    assert isinstance(date_time_facts_1, dict)

# Generated at 2022-06-24 23:54:18.095679
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    fact_dict = date_time_fact_collector_0.collect()
    assert fact_dict['date_time']['year'] == "2017"
    assert fact_dict['date_time']['month'] == "12"
    assert fact_dict['date_time']['month'] == "12"
    assert fact_dict['date_time']['weekday'] == "Friday"
    assert fact_dict['date_time']['weekday_number'] == "5"
    assert fact_dict['date_time']['weeknumber'] == "49"
    assert fact_dict['date_time']['day'] == "01"
    assert fact_dict['date_time']['hour'] == "02"
    assert fact_

# Generated at 2022-06-24 23:54:21.705315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-24 23:54:33.832647
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_module_facts_0 = {}
    ansible_module_facts_0['date_time'] = None
    collect_data_0 = date_time_fact_collector_0.collect(module=None, collected_facts=ansible_module_facts_0)
    assert (collect_data_0['date_time']['year'] == '2015')
    assert (collect_data_0['date_time']['day'] == '24')
    assert (collect_data_0['date_time']['hour'] == '14')
    assert (collect_data_0['date_time']['second'] ==  '18')

# Generated at 2022-06-24 23:54:38.419594
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts_dict_1 = date_time_fact_collector_1.collect()
    assert isinstance(date_time_facts_dict_1['date_time'], dict)


# Generated at 2022-06-24 23:54:47.642113
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_facts_dict_0 = date_time_fact_collector_0.collect()
    dict_0 = ansible_facts_dict_0['date_time']
    assert dict_0['epoch'] is not None
    assert dict_0['epoch_int'] is not None
    assert dict_0['iso8601'] is not None
    assert dict_0['iso8601_basic'] is not None
    assert dict_0['iso8601_basic_short'] is not None
    assert dict_0['iso8601_micro'] is not None
    assert dict_0['time'] is not None
    assert dict_0['date'] is not None
    assert dict_0['second'] is not None

# Generated at 2022-06-24 23:54:50.664683
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtf_collector_0 = DateTimeFactCollector()
    dtf_collector_1 = DateTimeFactCollector()
    assert (dtf_collector_0 is not dtf_collector_1)
    assert (dtf_collector_0.collect() == dtf_collector_1.collect())


# Generated at 2022-06-24 23:54:52.213321
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test Case #0
    try:
        test_case_0()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-24 23:55:04.426093
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ansible_facts = dict()
    # We need to fake a system like Windows which does not
    # supply precise information on the timezone
    ansible_facts['system'] = 'Windows'
    # We also mock out the datetime class so we don't need
    # to wait for the tests to complete.  Note that we need
    # to specify both local and UTC time values and that we
    # need to specify them both in an odd way ;-)
    datetime.datetime = lambda *args, **kwargs: datetime.datetime(2014, 6, 1, 10, 40, 38, 775806)
    datetime.datetime.utcnow = lambda *args, **kwargs: datetime.datetime(2014, 6, 1, 8, 40, 38, 775806)

# Generated at 2022-06-24 23:55:14.735920
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_2 = DateTimeFactCollector()
    date_time_fact_collector_3 = DateTimeFactCollector()
    date_time_fact_collector_4 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()
    date_time_fact_collector_2.collect()
    date_time_fact_collector_3.collect()
    date_time_fact_collector_4.collect()

test_case_0()
test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:55:23.140430
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test case with missing argument.
    try:
        date_time_fact_collector_collect_0 = DateTimeFactCollector().collect()
    except Exception as e:
        assert 'argument "collected_facts" is required' in str(e)

    # Test case with missing argument.
    try:
        date_time_fact_collector_collect_1 = DateTimeFactCollector().collect(
            module='module_name'
        )
    except Exception as e:
        assert 'argument "collected_facts" is required' in str(e)

    # Test case with valid argument.
    date_time_fact_collector_collect_2 = DateTimeFactCollector().collect(
        module='module_name',
        collected_facts=dict()
    )
    assert 'date_time' in date_time_fact

# Generated at 2022-06-24 23:55:26.737514
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    facts = date_time_fact_collector_0.collect()
    print (facts)


# Generated at 2022-06-24 23:55:38.845578
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:55:47.996092
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:49.021686
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:55:52.983824
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collected_facts = dict()
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect(None, collected_facts)
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:55:55.581411
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:58.706905
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert('date_time' not in collected_facts)
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect(module=None, collected_facts=collected_facts)
    assert(collected_facts['date_time'])

# Generated at 2022-06-24 23:56:06.023501
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collectTest = DateTimeFactCollector()
    res = collectTest.collect()
    assert ('date_time' in res)
    assert ('year' in res['date_time'])
    assert ('month' in res['date_time'])
    assert ('weekday' in res['date_time'])
    assert ('weekday_number' in res['date_time'])
    assert ('day' in res['date_time'])
    assert ('hour' in res['date_time'])
    assert ('minute' in res['date_time'])
    assert ('second' in res['date_time'])
    assert ('epoch' in res['date_time'])
    assert ('epoch_int' in res['date_time'])
    assert ('date' in res['date_time'])

# Generated at 2022-06-24 23:56:10.287037
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector = date_time_fact_collector_0.collect()
    print(date_time_fact_collector)
    d = datetime.datetime.utcfromtimestamp(time.time())
    print(d.strftime("%Y-%m-%dT%H:%M:%S.%fZ"))

if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:56:18.463282
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    test_date_time = date_time_fact_collector_1.collect()
    assert 'date_time' in test_date_time
    # assert test_date_time['date_time']['iso8601_micro'][-1] == 'Z'
    assert test_date_time['date_time']['second'] != ''

# Generated at 2022-06-24 23:56:28.094252
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:56:39.605357
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = date_time_fact_collector_0.collect()
    assert 'date_time' in facts_dict
    assert 'date' in facts_dict['date_time']
    assert 'time' in facts_dict['date_time']
    assert 'year' in facts_dict['date_time']
    assert 'month' in facts_dict['date_time']
    assert 'weekday' in facts_dict['date_time']
    assert 'weekday_number' in facts_dict['date_time']
    assert 'weeknumber' in facts_dict['date_time']
    assert 'day' in facts_dict['date_time']
    assert 'hour' in facts_dict['date_time']
    assert 'minute' in facts_dict

# Generated at 2022-06-24 23:56:56.732307
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:57:03.534603
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    '''
    test_DateTimeFactCollector_collect
    '''
    dates = DateTimeFactCollector().collect()
    assert 'date_time' in dates, "DateTimeFactCollector.collect() returned %s instead of %s" % (dates, 'date_time')

# Generated at 2022-06-24 23:57:06.567590
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:57:10.612781
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0 failed: " + str(e))


# Run unit tests
if __name__ == "__main__":
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:57:11.589533
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert 0


# Generated at 2022-06-24 23:57:14.372184
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    date_time_fact_collector_0.name

# Generated at 2022-06-24 23:57:17.503623
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:57:20.717986
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert len(date_time_fact_collector_1.collect()) > 0

# Generated at 2022-06-24 23:57:31.516594
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect_0 = DateTimeFactCollector()
    ansible_facts = {}
    collected_facts = {}
    ansible_facts_0 = date_time_fact_collector_collect_0.collect(collected_facts=collected_facts)
    assert "date_time" in ansible_facts_0
    assert ansible_facts_0["date_time"]["date"] == "2019-08-07"
    assert ansible_facts_0["date_time"]["epoch"] == "1565579020"
    assert ansible_facts_0["date_time"]["month"] == "08"
    assert ansible_facts_0["date_time"]["time"] == "12:23:40"

# Generated at 2022-06-24 23:57:34.698381
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Check that collect returns a dictionary
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert (isinstance(result, dict))


# Generated at 2022-06-24 23:57:52.902315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert 1 == 1


# Generated at 2022-06-24 23:57:56.557885
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect(date_time_fact_collector_1)
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 23:58:01.203866
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    date_time_fact_collector_0.collect()
    date_time_fact_collector_0.collect()
    date_time_fact_collector_0.collect()
    date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:58:05.760917
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:11.463759
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert callable(DateTimeFactCollector.collect)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:58:13.845391
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:58:18.554716
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect(date_time_fact_collector_0)

# Generated at 2022-06-24 23:58:23.886359
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print("Testing DateTimeFactCollector.collect")
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect(date_time_fact_collector_0)

test_case_0()
test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:58:29.703783
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect(date_time_fact_collector)
    assert var is not None
    assert len(var['date_time']) == 22
    assert var['date_time']['day'] == str(datetime.datetime.utcnow().day)
    assert var['date_time']['month'] == datetime.datetime.utcnow().strftime('%m')
    assert var['date_time']['weekday'] == datetime.datetime.utcnow().strftime('%A')
    assert var['date_time']['weekday_number'] == datetime.datetime.utcnow().strftime('%w')
    assert var['date_time']['weeknumber'] == dat

# Generated at 2022-06-24 23:58:33.245354
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:59:13.302664
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_collector_0 = DateTimeFactCollector()
    facts_dict_0 = date_time_collector_0.collect()
    var_0 = facts_dict_0.get('date_time')
    var_1 = var_0.get('epoch_int')
    var_2 = var_0.get('date')
    var_3 = var_0.get('year')
    var_4 = var_0.get('epoch')
    var_5 = var_0.get('day')
    var_6 = var_0.get('time')
    var_7 = var_0.get('iso8601')
    var_8 = var_0.get('tz_dst')
    var_9 = var_0.get('weekday')

# Generated at 2022-06-24 23:59:19.729097
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:59:26.387988
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:59:27.857379
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ansible_0 = DateTimeFactCollector()
    if ansible_0.collect().get('date_time'):
        assert True
    else:
        assert False


# Generated at 2022-06-24 23:59:38.547252
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_2 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_2.collect()

# Generated at 2022-06-24 23:59:48.966586
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect(date_time_fact_collector_0)
    assert type(var_0) == dict
    assert set(var_0) == {"date_time"}
    assert type(var_0["date_time"]) == dict

# Generated at 2022-06-24 23:59:55.503431
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect(date_time_fact_collector)
    assert result


# Generated at 2022-06-25 00:00:01.443284
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect(date_time_fact_collector_0)


# Generated at 2022-06-25 00:00:07.510848
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect(date_time_fact_collector_0)

# Generated at 2022-06-25 00:00:12.198057
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    try: 
        test_case_0()
    except Exception as exception:
        print(exception)
        assert False


# Generated at 2022-06-25 00:01:29.445875
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect(date_time_fact_collector_0)
    var_1 = date_time_fact_collector_0.collect(date_time_fact_collector_0)
    assert var_1 is not None



# Generated at 2022-06-25 00:01:35.813801
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-25 00:01:41.080986
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect(date_time_fact_collector_1)

    assert var_1 is not None


# Generated at 2022-06-25 00:01:43.307405
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:01:44.905097
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # return_value = collect(self=<ansible.module_utils.facts.system.date_time.DateTimeFactCollector object at 0x7fceb6aab470>)
    # assert return_value == NA # var return_value is checked to be NA in the calling function
    pass

# Generated at 2022-06-25 00:01:47.182971
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-25 00:01:51.981528
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = time.strftime('%Y-%m-%dT%H:%M:%SZ')
    assert now


# Generated at 2022-06-25 00:01:58.286168
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # No errors raised
    date_time_fact_collector = DateTimeFactCollector()
    output = date_time_fact_collector.collect(date_time_fact_collector)
    # Check the output is what is expected
    assert isinstance(output, dict)
    assert 'date_time' in output.keys()
    assert len(output) == 1
    date_time = output['date_time']
    assert 'year' in date_time.keys()
    assert isinstance(date_time['year'], str)
    assert len(date_time['year']) == 4
    assert 'month' in date_time.keys()
    assert isinstance(date_time['month'], str)
    assert len(date_time['month']) == 2
    assert 'weekday' in date_time.keys()


# Generated at 2022-06-25 00:02:09.089831
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    c = DateTimeFactCollector()
    result = c.collect()
    assert result['date_time']['date'] == time.strftime('%Y-%m-%d')
    assert result['date_time']['time'] == time.strftime('%H:%M:%S')
    assert result['date_time']['iso8601_micro'] == time.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    assert result['date_time']['iso8601'] == time.strftime("%Y-%m-%dT%H:%M:%SZ")
    assert result['date_time']['iso8601_basic'] == time.strftime("%Y%m%dT%H%M%S%f")
   

# Generated at 2022-06-25 00:02:15.521543
# Unit test for method collect of class DateTimeFactCollector