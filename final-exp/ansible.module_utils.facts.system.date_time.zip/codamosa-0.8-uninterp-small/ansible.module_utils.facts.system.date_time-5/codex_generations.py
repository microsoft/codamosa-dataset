

# Generated at 2022-06-24 23:52:32.443831
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

    # TODO: need to implement assertion tests
    assert True == True

# Generated at 2022-06-24 23:52:38.289836
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:52:45.182621
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:48.263198
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:52:49.793083
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:52:51.318040
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # We can not test this method, because there is nothing to test
    assert True


# Generated at 2022-06-24 23:52:58.769206
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    dt_facts_dict = date_time_fact_collector.collect()

    assert isinstance(dt_facts_dict, dict)
    assert isinstance(dt_facts_dict['date_time'], dict)

    # time.asctime() returns the human-readable date and time in the GMT time zone.
    # The format is hard-coded in the implementation of asctime() and cannot be changed.
    utctime = time.asctime(time.gmtime(float(dt_facts_dict['date_time']['epoch'])))
    assert str(dt_facts_dict['date_time']['epoch']) == str(int(time.time()))

# Generated at 2022-06-24 23:53:02.482954
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:53:09.937851
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    collect_ret_val = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:53:16.935522
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    input_collect_0 = {}
    input_collect_0['ansible_module_args'] = {}
    input_collect_0['ansible_facts'] = {}
    input_collect_0['ansible_module_args']['filter'] = '*'

    DateTimeFactCollector_collect = DateTimeFactCollector().collect(
        module=None, collected_facts=input_collect_0)
    print(DateTimeFactCollector_collect)


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:53:26.571277
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

    assert var_0['date_time'].keys() == ['weekday_number', 'weekday', 'date', 'tz_offset', 'year', 'day', 'weeknumber', 'tz_dst', 'epoch_int', 'time', 'iso8601_basic_short', 'second', 'tz', 'epoch', 'month', 'iso8601', 'iso8601_basic', 'iso8601_micro', 'hour', 'minute'], 'Incorrect value returned by DateTimeFactCollector.collect()'

# Generated at 2022-06-24 23:53:29.648768
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()
    assert date_time_fact_collector_1.name == 'date_time'

# Generated at 2022-06-24 23:53:33.321701
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()

# Test method get_fact_names()

# Generated at 2022-06-24 23:53:34.053567
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:53:39.465253
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = DateTimeFactCollector()
    var_1 = var_0.collect()
    assert type(var_1) == dict
    assert len(var_1) == 1

# Generated at 2022-06-24 23:53:50.182579
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:51.533954
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = None
    var_0 = DateTimeFactCollector()
    var_1 = var_0.collect()
    assert isinstance(var_1, dict)



# Generated at 2022-06-24 23:53:54.392837
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print("date_time.py:test_DateTimeFactCollector_collect")
    assert True


# Generated at 2022-06-24 23:54:01.782623
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector.date_time import DateTimeFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    
    assert len(var_0) == 1

# Generated at 2022-06-24 23:54:04.356405
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:15.466772
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)

    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

    var_1 = var_0.get('date_time')
    assert var_1 is not None
    assert 'year' in var_1
    assert 'month' in var_1
    assert 'weekday' in var_1
    assert 'weekday_number' in var_1
    assert 'weeknumber' in var_1
    assert 'day' in var_1
    assert 'hour' in var_1
    assert 'minute' in var_1
    assert 'second' in var_1
    assert 'epoch' in var_1

   

# Generated at 2022-06-24 23:54:24.858323
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # It seems that the values for the global variables in the DateTimeFactCollector.collect() function is not being set which makes it produce an error. 
    # The values for the global variables will be set using the below lines:
    global YEAR
    YEAR = '2018'
    global MONTH
    MONTH = '04'
    global WEEKDAY
    WEEKDAY = 'Tuesday'
    global WEEKDAY_NUMBER
    WEEKDAY_NUMBER = '2'
    global WEEKNUMBER
    WEEKNUMBER = '14'
    global DAY
    DAY = '24'
    global HOUR
    HOUR = '15'
    global MINUTE
    MINUTE = '08'
    global SECOND
    SECOND = '30'
    global EPOCH
    EPOCH = '1524560310'
    global EPOCH_INT


# Generated at 2022-06-24 23:54:26.304674
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    obj_DateTimeFactCollector = DateTimeFactCollector()
    obj_DateTimeFactCollector.collect()

# Generated at 2022-06-24 23:54:34.615126
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert len(var_0['date_time']) == 20
    assert var_0['date_time']['day'] == '08'
    assert var_0['date_time']['tz_offset'] == '+0100'
    assert var_0['date_time']['epoch_int'] == '1528910986'
    assert var_0['date_time']['second'] == '06'
    assert var_0['date_time']['month'] == '06'
    assert var_0['date_time']['year'] == '2018'
    assert var_0['date_time']['weeknumber'] == '23'

# Generated at 2022-06-24 23:54:36.182530
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:39.219315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:41.317441
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    a = DateTimeFactCollector()
    assert type(a.collect()) == type({})

# Generated at 2022-06-24 23:54:44.877282
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect()


# Generated at 2022-06-24 23:54:47.194431
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test case CUT 0
    test_case_0()
    pass

if __name__ == "__main__":
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:57.650943
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0 is not None
    assert isinstance(var_0['date_time']['epoch'], str)
    assert isinstance(var_0['date_time']['epoch_int'], str)
    assert isinstance(var_0['date_time']['iso8601_micro'], str)
    assert isinstance(var_0['date_time']['iso8601'], str)
    assert isinstance(var_0['date_time']['iso8601_basic'], str)
    assert isinstance(var_0['date_time']['iso8601_basic_short'], str)

# Generated at 2022-06-24 23:55:08.015003
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert "date_time" in var_1
    assert "date_time" in var_1
    assert type(var_1["date_time"]) == dict
    assert "iso8601_micro" in var_1["date_time"]
    assert type(var_1["date_time"]["iso8601_micro"]) == str
    assert var_1["date_time"]["iso8601_micro"] != ''
    assert "iso8601" in var_1["date_time"]
    assert type(var_1["date_time"]["iso8601"]) == str
    assert var_1["date_time"]["iso8601"] != ''

# Generated at 2022-06-24 23:55:13.701429
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:55:16.259590
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect() is not None


# Generated at 2022-06-24 23:55:21.408241
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert date_time_fact_collector_0.name == 'date_time'


# Generated at 2022-06-24 23:55:24.327458
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:27.085850
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0.collect(), dict)


# Generated at 2022-06-24 23:55:39.103928
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'date_time' in var_0
    assert len(var_0) == 1

# Generated at 2022-06-24 23:55:46.444728
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 23:55:51.513415
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert isinstance(var_1, dict)  # isinstance(x, classinfo), Return true if the object argument is an instance of the classinfo argument, or of a (direct, indirect or virtual) subclass thereof. If object is not an object of the given type, the function always returns false.

# Generated at 2022-06-24 23:55:52.539231
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = DateTimeFactCollector()
    var_0.collect()

# Generated at 2022-06-24 23:56:01.112837
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:56:03.738778
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    # AssertionError
    assert var_0 == {}


# Generated at 2022-06-24 23:56:08.446942
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect() == {}

# Generated at 2022-06-24 23:56:16.084853
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1.get('date_time')
    assert var_1.get('date_time').get('day')
    assert var_1.get('date_time').get('time')
    assert var_1.get('date_time').get('weekday_number')
    assert var_1.get('date_time').get('weekday')
    assert var_1.get('date_time').get('iso8601_basic_short')
    assert var_1.get('date_time').get('iso8601_basic')
    assert var_1.get('date_time').get('date')

# Generated at 2022-06-24 23:56:20.310280
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert type(var_0) is dict
    assert 'date_time' in var_0
    assert type(var_0['date_time']) is dict

# Generated at 2022-06-24 23:56:21.712648
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Prints to stderr/stdout for debug/info
    pass



# Generated at 2022-06-24 23:56:24.573602
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 23:56:34.507473
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print('Test method collect of class DateTimeFactCollector')
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:37.973651
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert date_time.date_time_fact_collector.collect() == 'date_time'

# Generated at 2022-06-24 23:56:46.337510
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # set up object
    date_time_fact_collector_1 = DateTimeFactCollector()
    # set up expected results

# Generated at 2022-06-24 23:57:12.105676
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['iso8601_basic_short'] == datetime.datetime.now().strftime("%Y%m%dT%H%M%S")
    assert var_0['date_time']['date'] == datetime.datetime.now().strftime("%Y-%m-%d")
    assert var_0['date_time']['epoch_int'] == str(int(datetime.datetime.now().strftime('%s')))
    assert var_0['date_time']['hour'] == datetime.datetime.now().strftime("%H")

# Generated at 2022-06-24 23:57:14.960128
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:57:20.353965
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:57:24.401673
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:57:28.453380
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert len(var_1.keys()) == 1
    assert len(var_1['date_time'].keys()) == 16


# Generated at 2022-06-24 23:57:35.744939
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import ansible.module_utils.facts.collectors.date_time
    import datetime
    import time

    date_time_fact_collector_0 = ansible.module_utils.facts.collectors.date_time.DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    datetime_0 = datetime.datetime.now()
    datetime_0 += datetime.timedelta(seconds=-time.timezone, microseconds=-time.altzone)
    assert 'date_time' in var_0
    assert 'epoch' in var_0['date_time']
    assert 'epoch_int' in var_0['date_time']
    assert 'date' in var_0['date_time']
   

# Generated at 2022-06-24 23:57:45.518828
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_2 = {}
    var_2['date_time'] = {}
    var_2['date_time']['tz_offset'] = ''
    var_2['date_time']['year'] = ''
    var_2['date_time']['weekday_number'] = ''
    var_2['date_time']['epoch_int'] = ''
    var_2['date_time']['weekday'] = ''
    var_2['date_time']['time'] = ''
    var_2['date_time']['epoch'] = ''
    var_2['date_time']['tz'] = ''
    var_2['date_time']['month'] = ''

# Generated at 2022-06-24 23:57:49.852031
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    print(var_0)

# vim: set filetype=python:

# Generated at 2022-06-24 23:57:54.194824
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:02.677135
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_0 = DateTimeFactCollector()
    var_1 = var_0.collect()
    # Verifying keys exist
    var_3 = var_1.has_key('date_time')
    assert var_3
    var_4 = var_1.has_key('date_time')
    assert var_4
    var_5 = var_1.has_key('date_time')
    assert var_5
    var_6 = var_1.has_key('date_time')
    assert var_6
    var_7 = var_1.has_key('date_time')
    assert var_7
    var_8 = var_1.has_key('date_time')
    assert var_8
    var_9 = var_1.has_key('date_time')
    assert var_9


# Generated at 2022-06-24 23:58:33.375771
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # No input variables to method
    # Test #0
    test_case_0()

# Generated at 2022-06-24 23:58:41.276960
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector._fact_ids = set([""])
    collected_facts = dict()
    collected_facts[""] = dict()
    var = date_time_fact_collector.collect(collected_facts)
    assert list(var) == ["date_time"]
    nested_var_0 = var["date_time"]
    assert nested_var_0["second"] == "00"
    assert nested_var_0["minute"] == "00"
    assert nested_var_0["hour"] == "00"
    assert nested_var_0["year"] == "2014"
    assert nested_var_0["iso8601_micro"] == "2014-06-26T00:00:00.000000Z"
    assert nested_var

# Generated at 2022-06-24 23:58:52.973666
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:59:02.726943
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()

# Generated at 2022-06-24 23:59:07.454358
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert var_1 != None


# Generated at 2022-06-24 23:59:10.026970
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:59:14.962412
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var = DateTimeFactCollector()
    # Call method collect of class DateTimeFactCollector
    var.collect()



# Generated at 2022-06-24 23:59:20.785507
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}
    date_time_fact_collector_0_collect = date_time_fact_collector_0.collect(collected_facts_0)

# Generated at 2022-06-24 23:59:27.552555
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Given: The DateTimeFactCollector object
    date_time_collector = DateTimeFactCollector()

    # When: We collect the facts
    date_time_facts = date_time_collector.collect()

    # Then: The facts exist
    assert 'date_time' in date_time_facts
    # Then: The facts have the right keys
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']

# Generated at 2022-06-24 23:59:31.355223
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass



# Generated at 2022-06-25 00:00:50.606534
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}
    collected_facts_0['ansible_date_time'] = {}
    var_0 = date_time_fact_collector_0.collect(module=None, collected_facts=collected_facts_0)

# Generated at 2022-06-25 00:00:59.138586
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:01.616923
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()



# Generated at 2022-06-25 00:01:09.618306
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-25 00:01:20.343305
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'date_time' in var_0
    assert var_0['date_time'] is not None
    assert isinstance(var_0['date_time'], dict)
    assert var_0['date_time']['tz'] is not None
    assert var_0['date_time']['day'] is not None
    assert var_0['date_time']['weekday'] is not None
    assert var_0['date_time']['year'] is not None
    assert var_0['date_time']['hour'] is not None

# Generated at 2022-06-25 00:01:24.347252
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    data_time_dict = date_time_fact_collector_0.collect()
    assert data_time_dict["date_time"]["iso8601"] != ""

# Generated at 2022-06-25 00:01:28.152468
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    assert type(var_1) is dict
    assert var_1 == {}


# Generated at 2022-06-25 00:01:31.706305
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:34.478099
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:01:45.949441
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  date_time_fact_collector = DateTimeFactCollector(namespace='ansible_date_time')
  result = date_time_fact_collector.collect(module=None, collected_facts=None)
  assert result['ansible_date_time']['date'] is not None
  assert result['ansible_date_time']['epoch'] is not None
  assert result['ansible_date_time']['epoch_int'] is not None
  assert result['ansible_date_time']['hour'] is not None
  assert result['ansible_date_time']['iso8601'] is not None
  assert result['ansible_date_time']['iso8601_basic'] is not None