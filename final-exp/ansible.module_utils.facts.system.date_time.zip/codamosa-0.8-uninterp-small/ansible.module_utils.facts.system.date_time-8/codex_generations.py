

# Generated at 2022-06-24 23:52:31.647412
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert date_time_fact_collector_0.collect() == "date_time"

# Generated at 2022-06-24 23:52:37.532020
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test case 0
    date_time_fact_collector_0 = DateTimeFactCollector()
    module_0 = None
    collected_facts_0 = None
    # Collect the facts.
    facts_dict_0 = date_time_fact_collector_0.collect(module_0, collected_facts_0)
    assert isinstance(facts_dict_0, dict)

# Generated at 2022-06-24 23:52:45.633597
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time = DateTimeFactCollector()
    date_time_facts = date_time.collect()['date_time']
    assert int(date_time_facts['weeknumber']) >= 36
    assert int(date_time_facts['second']) >= 0
    assert int(date_time_facts['minute']) >= 0
    assert int(date_time_facts['weekday_number']) >= 0
    assert int(date_time_facts['day']) >= 1
    assert int(date_time_facts['epoch']) > 0
    assert int(date_time_facts['year']) >= 2017
    assert int(date_time_facts['hour']) >= 0
    assert int(date_time_facts['month']) >= 1
    assert int(date_time_facts['epoch_int']) > 0

# Generated at 2022-06-24 23:52:48.632507
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:52:56.610290
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import datetime

    test_instance = DateTimeFactCollector()

    now = datetime.datetime.now()

    # Ensure the standard date/time formats are populated
    date_time_facts = test_instance.collect()['date_time']
    for format in ['date', 'time', 'iso8601', 'iso8601_micro', 'iso8601_basic', 'iso8601_basic_short']:
        assert date_time_facts[format]

    # Ensure the individual date/time fields are populated
    for field in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second',
                  'epoch', 'epoch_int', 'tz', 'tz_dst', 'tz_offset']:
        assert date_time_facts[field]

   

# Generated at 2022-06-24 23:53:01.739946
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Set up test case
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Invoke method
    result = date_time_fact_collector_0.collect()

    # Tests
    assert "date_time" in result
    assert "year" in result["date_time"]
    assert "month" in result["date_time"]
    assert "weekday" in result["date_time"]
    assert "weekday_number" in result["date_time"]
    assert "weeknumber" in result["date_time"]
    assert "day" in result["date_time"]
    assert "hour" in result["date_time"]
    assert "minute" in result["date_time"]
    assert "second" in result["date_time"]
    assert "epoch" in result["date_time"]


# Generated at 2022-06-24 23:53:05.097748
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

if __name__ == '__main__':
    #test_case_0()
    #test_DateTimeFactCollector_collect()
    pass

# Generated at 2022-06-24 23:53:08.384622
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:10.546423
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:53:20.090206
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:53:25.206023
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:53:27.944050
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    fact_collector_obj = DateTimeFactCollector()
    facts_dict = fact_collector_obj.collect()
    assert facts_dict['date_time']['month'] == datetime.datetime.now().strftime('%m')

# Generated at 2022-06-24 23:53:32.893981
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
   date_time_fact_collector_1 = DateTimeFactCollector()
   assert date_time_fact_collector_1.collect() == {}

# Generated at 2022-06-24 23:53:38.146166
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
    Test collect function of DateTimeFactCollector
    """
    date_time_fact_collector = DateTimeFactCollector()
    # pylint: disable=protected-access
    collected_facts = date_time_fact_collector.collect()
    assert isinstance(collected_facts['date_time'], dict)
    assert isinstance(collected_facts['date_time']['date'], str)
    assert isinstance(collected_facts['date_time']['year'], str)
    assert isinstance(collected_facts['date_time']['month'], str)
    assert isinstance(collected_facts['date_time']['weekday_number'], str)
    assert isinstance(collected_facts['date_time']['weekday'], str)
    assert isinstance

# Generated at 2022-06-24 23:53:48.448453
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:53:49.965381
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert(DateTimeFactCollector().collect() != {})

# Generated at 2022-06-24 23:53:58.349056
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:54:00.804540
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    returned_val = date_time_fact_collector_1.collect(None, None)
    assert returned_val == {}


# Generated at 2022-06-24 23:54:06.577180
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    module_0 = None
    collected_facts_0 = None
    assert isinstance(
        date_time_fact_collector_0.collect(module_0, collected_facts_0),
        dict)



# Generated at 2022-06-24 23:54:15.887053
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = {}

# Generated at 2022-06-24 23:54:25.281764
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:54:33.833547
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    # assert date_time_fact_collector_0.collected_facts == {'date_time': {'epoch_int': '1540567586', 'day': '19', 'epoch': '1540567586', 'month': '11', 'hour': '01', 'date': '2018-10-19', 'time': '01:59:46', 'weekday_number': '5', 'weekday': 'Friday', 'second': '46', 'weeknumber': '42', 'tz': 'CEST', 'minute': '59', 'iso8601_micro': '2018-10-19T00:59:46.959127Z', 'tz_dst': 'CEST',

# Generated at 2022-06-24 23:54:43.489946
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result == {'date_time': {'day': '', 'weekday': '', 'epoch': '', 'date': '', 'month': '', 'time': '', 'epoch_int': '', 'year': '', 'iso8601_micro': '', 'hour': '', 'second': '', 'iso8601_basic_short': '', 'weekday_number': '', 'weeknumber': '', 'iso8601': '', 'iso8601_basic': '', 'tz_offset': '', 'tz': '', 'minute': '', 'tz_dst': ''}}


# Generated at 2022-06-24 23:54:45.228950
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:52.910169
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collectors.date_time import DateTimeFactCollector

    # Initialize DateTimeFactCollector class object
    date_time_fact_collector = DateTimeFactCollector()
    # Make a call to the method collect of class DateTimeFactCollector to set the epoch timestamp
    date_time_fact_collector.collect()

    objDateTimeFactCollector = DateTimeFactCollector()
    # Make a call to the method collect of class DateTimeFactCollector to collect facts about date and time
    objDateTimeFactCollector.collect()

    # Assert that the method collect of class DateTime

# Generated at 2022-06-24 23:54:54.686440
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:05.885774
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:09.945373
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:19.541208
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    facts_dict = dict()
    collect_facts = dict()

# Generated at 2022-06-24 23:55:31.875698
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}

# Generated at 2022-06-24 23:55:52.039119
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:56:00.965998
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Test with no args:
    result = date_time_fact_collector_0.collect()
    assert result['date_time']['year'] == datetime.datetime.utcnow().strftime('%Y')
    assert result['date_time']['date'] == datetime.datetime.utcnow().strftime('%Y-%m-%d')
    assert result['date_time']['time'] == datetime.datetime.utcnow().strftime('%H:%M:%S')

    # Test with args:
    result = date_time_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 23:56:04.880878
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Initialize test case variables
    class MockModule:
        pass

    class CollectedFacts:
        pass

    module_0 = MockModule()
    collected_facts_0 = CollectedFacts()

    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)


# Generated at 2022-06-24 23:56:08.572010
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_facts_0 = DateTimeFactCollector()
    date_time_facts_0.collect()

# Test DateTimeFactCollector.name property

# Generated at 2022-06-24 23:56:16.163665
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = {}
    collected_facts.update(date_time_fact_collector.collect())
    assert collected_facts["date_time"]["year"] == datetime.datetime.now().strftime("%Y")
    assert collected_facts["date_time"]["month"] == datetime.datetime.now().strftime("%m")
    assert collected_facts["date_time"]["weekday"] == datetime.datetime.now().strftime("%A")
    assert collected_facts["date_time"]["weekday_number"] == datetime.datetime.now().strftime("%w")
    assert collected_facts["date_time"]["weeknumber"] == datetime.datetime.now().strftime("%W")
   

# Generated at 2022-06-24 23:56:18.694129
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:56:19.785232
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:26.493269
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    return_value = date_time_fact_collector_0.collect()
    assert return_value['date_time']['year'] == '2020'
    assert return_value['date_time']['month'] == '06'
    assert return_value['date_time']['weekday'] == 'Wednesday'
    assert return_value['date_time']['weekday_number'] == '3'
    assert return_value['date_time']['weeknumber'] == '23'
    assert return_value['date_time']['day'] == '03'
    assert return_value['date_time']['hour'] == '08'
    assert return_value['date_time']['minute'] == '43'
    assert return_

# Generated at 2022-06-24 23:56:27.677479
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert 'date_time' in date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:56:39.251262
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector = DateTimeFactCollector()

    result = date_time_fact_collector.collect()

    assert result['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert result['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert result['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert result['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert result['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert result['date_time']['day'] == datetime.datetime.now().str

# Generated at 2022-06-24 23:57:20.291051
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:57:31.210789
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_facts_0 = date_time_fact_collector_0.collect()
    date_time_0 = ansible_facts_0['date_time']
    assert date_time_0['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_0['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_0['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_0['weekday_number'] == datetime.datetime.now().strftime('%w')
    assert date_time_0['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert date_

# Generated at 2022-06-24 23:57:33.409955
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time = date_time_fact_collector.collect()
    assert date_time['date_time']['epoch'].isdigit()

# Generated at 2022-06-24 23:57:39.693119
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    date_time_fact_collector_1 = DateTimeFactCollector()
    module_1 = None
    date_time_facts = date_time_fact_collector_1.collect(module=module_1)
    assert date_time_facts['date_time']['iso8601_basic_short'] > '20160908T231431'


# Generated at 2022-06-24 23:57:42.157312
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    args = {}
    date_time_fact_collector = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector.collect(**args), dict)

# Generated at 2022-06-24 23:57:44.865739
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts
    assert date_time_facts['date_time']['epoch'] == time.strftime('%s')



# Generated at 2022-06-24 23:57:50.361087
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = dict()
    date_time_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert collected_facts_0['date_time']['year'] == '2016'


# Generated at 2022-06-24 23:57:53.852738
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()


# Generated at 2022-06-24 23:57:56.106032
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:58:01.346242
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    f = date_time_fact_collector_1.collect()
    assert 'date_time' in f
    assert 'epoch' in f['date_time']
    assert 'epoch_int' in f['date_time']
    assert 'iso8601' in f['date_time']
    assert 'tz_dst' in f['date_time']


# Generated at 2022-06-24 23:59:07.476498
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_obj_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_obj_0.collect(), dict)

# Generated at 2022-06-24 23:59:15.698220
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:59:17.492735
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:59:22.567474
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect = DateTimeFactCollector()
    result = date_time_fact_collector_collect.collect()
    assert 'date_time' in result.keys()
    assert isinstance(result['date_time'], dict)
    assert len(result['date_time']) == 22
    assert result['date_time']['date'] == time.strftime('%Y-%m-%d')
    assert result['date_time']['time'] == time.strftime('%H:%M:%S')
    assert result['date_time']['iso8601_micro'].startswith(time.strftime('%Y-%m-%dT%H:%M:%S'))
    assert result['date_time']['iso8601'] == time.strftime

# Generated at 2022-06-24 23:59:24.353442
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()
    assert type(collected_facts) == dict

# Generated at 2022-06-24 23:59:25.864787
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:59:28.269452
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    collected_facts = {}
    collected_facts['ansible_check_mode'] = False
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect(collected_facts=collected_facts)


# Generated at 2022-06-24 23:59:32.593035
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()
#

# Generated at 2022-06-24 23:59:43.406209
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_cases = [0]

    for test_case in test_cases:
        print("Testing method 'collect' of class 'DateTimeFactCollector' - Test Case #" + str(test_case))
        if test_case == 0:
            date_time_fact_collector_0 = DateTimeFactCollector()
            result = date_time_fact_collector_0.collect()
            assert 'date_time' in result
            assert 'year' in result['date_time']
            assert 'month' in result['date_time']
            assert 'weekday' in result['date_time']
            assert 'weekday_number' in result['date_time']
            assert 'weeknumber' in result['date_time']
            assert 'day' in result['date_time']

# Generated at 2022-06-24 23:59:53.360280
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}
    collected_facts_0['ansible_system'] = 'Linux'
    facts_dict_0 = date_time_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert 'date_time' in facts_dict_0
    date_time_facts_0 = facts_dict_0['date_time']

# Generated at 2022-06-25 00:02:20.766455
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_collect = date_time_fact_collector.collect()
    assert date_time_fact_collector_collect

# Generated at 2022-06-25 00:02:24.063397
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    if date_time_fact_collector_0.collect() != {}:
        raise AssertionError



# Generated at 2022-06-25 00:02:30.468387
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    now = datetime.datetime.now()
    epoch_ts = time.time()