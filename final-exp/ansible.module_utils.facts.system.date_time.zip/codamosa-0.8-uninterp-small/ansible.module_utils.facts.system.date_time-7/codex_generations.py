

# Generated at 2022-06-24 23:52:40.868209
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    # test_DateTimeFactCollector_collect_0
    collected_facts_0 = dict()
    date_time_fact_collector_0.collect(None, collected_facts_0)
    date_time_0 = date_time_fact_collector_0.collect(None, collected_facts_0)

# Generated at 2022-06-24 23:52:42.254164
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    result = date_time_fact_collector_1.collect()

    assert result['date_time'] != {}

# Generated at 2022-06-24 23:52:44.979880
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:52:48.093879
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert not date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:51.427026
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    with patch.object(DateTimeFactCollector, "collect", autospec=True) as mock_collect_0:
        date_time_fact_collector_0 = DateTimeFactCollector()
        collect_ret = mock_collect_0.return_value = {}
        assert date_time_fact_collector_0.collect == (collect_ret)

# Generated at 2022-06-24 23:52:54.663315
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:56.511704
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:52:58.241350
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    if 'date_time' not in date_time_fact_collector_0.collect():
        raise AssertionError()


# Generated at 2022-06-24 23:53:08.511759
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    import copy
    import time

    # Set up test case
    date_time_fact_collector = DateTimeFactCollector()

    # Test return
    return_dict = date_time_fact_collector.collect()
    orig_dict = copy.deepcopy(return_dict)

    # Assert that the return value of date_time_fact_collector.collect() is not None
    assert return_dict['date_time'] is not None

    # Assert that the date_time values are not empty
    assert return_dict['date_time']['year'] is not None
    assert return_dict['date_time']['month'] is not None
    assert return_dict['date_time']['weekday'] is not None
    assert return_dict['date_time']['weekday_number'] is not None

# Generated at 2022-06-24 23:53:13.048348
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    """
        Tests that the DateTimeFactCollector.collect() method adds
        a dictionary named 'date_time' with the expected format to the
        module. If a date_time dictionary already exists in the module,
        the test fails and the returned fact dictionary is printed.
    """

    module_0 = dict(date_time=dict(foo='bar'))
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_dict_0 = date_time_fact_collector_0.collect(module_0)

    # Print out the returned fact dictionary
    # if the test fails

# Generated at 2022-06-24 23:53:23.099154
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.file_exists('/ansible/mandible')
    date_time_fact_collector_1.case_insensitive_fs()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:53:24.970973
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:53:27.523853
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_date_time = date_time_fact_collector_0.collect()
    assert ansible_date_time['date_time']['iso8601'].endswith('Z')
    assert ansible_date_time['date_time']['iso8601'].startswith('20')
    assert 'weekday' in ansible_date_time['date_time']


# Generated at 2022-06-24 23:53:37.382153
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in facts_dict_0
    date_time_0 = facts_dict_0['date_time']
    assert 'month' in date_time_0
    assert 'weekday_number' in date_time_0
    assert 'iso8601_basic_short' in date_time_0
    assert 'date' in date_time_0
    assert 'day' in date_time_0
    assert 'hour' in date_time_0
    assert 'iso8601_basic' in date_time_0
    assert 'year' in date_time_0
    assert 'time' in date_time_0

# Generated at 2022-06-24 23:53:47.791175
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.state = {'date_time': {}}
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:53:52.688536
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert 'date_time' in date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:53:57.314392
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:54:01.568328
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_returned = date_time_fact_collector.collect()
    assert facts_returned is not None

# Generated at 2022-06-24 23:54:12.004433
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # Scenario 1: Tests for a successful execution of the method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:54:17.244585
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result['date_time']['epoch_int'] == str(int(time.time()))

# Generated at 2022-06-24 23:54:29.553569
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:54:34.799809
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0 is not None, 'date_time_fact_collector.collect() returned None'
    assert ('date_time' in var_0) and (var_0['date_time'] is not None), 'date_time_fact_collector.collect() missing "date_time" key'

# Generated at 2022-06-24 23:54:44.856668
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['year'] == '2017'
    assert var_0['date_time']['month'] == '10'
    assert var_0['date_time']['weekday'] == 'Thursday'
    assert var_0['date_time']['weekday_number'] == '4'
    assert var_0['date_time']['weeknumber'] == '41'
    assert var_0['date_time']['day'] == '19'
    assert var_0['date_time']['hour'] == '20'
    assert var_0['date_time']['minute'] == '05'
    assert var_

# Generated at 2022-06-24 23:54:45.646812
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # TODO: define test case
    pass

# Generated at 2022-06-24 23:54:53.296363
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert isinstance(var_1, dict)
    assert var_1['date_time']['epoch'] == ""
    assert var_1['date_time']['weekday_number'] == ""
    assert var_1['date_time']['date'] == ""
    assert var_1['date_time']['second'] == ""
    assert var_1['date_time']['weeknumber'] == ""
    assert var_1['date_time']['time'] == ""
    assert var_1['date_time']['day'] == ""
    assert var_1['date_time']['hour'] == ""

# Generated at 2022-06-24 23:55:04.773705
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in var_0
    assert 'year' in var_0['date_time']
    assert 'month' in var_0['date_time']
    assert 'weekday' in var_0['date_time']
    assert 'weekday_number' in var_0['date_time']
    assert 'weeknumber' in var_0['date_time']
    assert 'day' in var_0['date_time']
    assert 'hour' in var_0['date_time']
    assert 'minute' in var_0['date_time']
    assert 'second' in var_0['date_time']
    assert 'epoch' in var_

# Generated at 2022-06-24 23:55:16.502716
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    path_0 = '/Users/konradsobon/Documents/Development/ansible_tower/ansible_tower/awx/plugins/modules/tower_job_launch'
    path_1 = '/Users/konradsobon/Documents/Development/ansible_tower/ansible_tower/awx/plugins/modules/tower_job_list'
    path_2 = '/Users/konradsobon/Documents/Development/ansible_tower/ansible_tower/awx/plugins/modules/tower_job_template'
    path_3 = '/Users/konradsobon/Documents/Development/ansible_tower/ansible_tower/awx/plugins/modules/tower_job_wait'

# Generated at 2022-06-24 23:55:29.268106
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:34.895281
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    var_1_keys = [u'date_time']

    assert sorted(var_1) == var_1_keys


# Generated at 2022-06-24 23:55:39.313288
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect()['ansible_date_time']['year'] == datetime.datetime.now().strftime('%Y')


# Generated at 2022-06-24 23:55:50.331766
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  # Instantiate the DateTimeFactCollector class
  date_time_fact_collector_obj = DateTimeFactCollector()
  # Invoke method
  date_time_fact_collector_obj.collect()

# Generated at 2022-06-24 23:55:52.885873
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    var_1 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:55.250473
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert type(var_0) == dict
    assert type(var_0['date_time']) == dict

# Generated at 2022-06-24 23:56:04.087065
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert var_0['date_time']['time'] == datetime.datetime.fromtimestamp(time.time()).strftime('%H:%M:%S')
    assert var_0['date_time']['weekday_number'] == datetime.datetime.fromtimestamp(time.time()).strftime('%w')


# Generated at 2022-06-24 23:56:14.653199
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert 'date_time' in var_1
    assert 'year' in var_1['date_time']
    assert 'month' in var_1['date_time']
    assert 'weekday' in var_1['date_time']
    assert 'weekday_number' in var_1['date_time']
    assert 'weeknumber' in var_1['date_time']
    assert 'day' in var_1['date_time']
    assert 'hour' in var_1['date_time']
    assert 'minute' in var_1['date_time']
    assert 'second' in var_1['date_time']
    assert 'epoch' in var_

# Generated at 2022-06-24 23:56:17.467545
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Set up test data
    date_time_fact_collector = DateTimeFactCollector()

    # Invoke method
    return_value = date_time_fact_collector.collect()

    # Check for positive result
    assert(return_value['date_time']['epoch'] is not None)

    # Check for negative result
    assert(return_value['date_time']['epoch'] != '')

# Generated at 2022-06-24 23:56:28.017716
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var = DateTimeFactCollector()

# Generated at 2022-06-24 23:56:39.542525
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert(isinstance(var,dict))
    assert(var['date_time']['time'] != None)
    assert(var['date_time']['year'] != None)
    assert(var['date_time']['tz_offset'] != None)
    assert(var['date_time']['day'] != None)
    assert(var['date_time']['tz'] != None)
    assert(var['date_time']['tz_dst'] != None)
    assert(var['date_time']['epoch'] != None)
    assert(var['date_time']['epoch_int'] != None)

# Generated at 2022-06-24 23:56:43.004383
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
  date_time_fact_collector_0 = DateTimeFactCollector()
  now = datetime.datetime.now()
  var_0 = date_time_fact_collector_0.collect()
  assert var_0['date_time']['year'] == now.strftime('%Y')
  

# Generated at 2022-06-24 23:56:51.330219
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    # Case 1:
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:57:08.839127
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_1.collect(), {})


# Generated at 2022-06-24 23:57:18.839967
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['second'] == datetime.datetime.now().strftime('%S')
    assert var_0['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert var_0['date_time']['time'] == datetime.datetime.now().strftime('%H:%M:%S')
    assert var_0['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert var_0['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert var

# Generated at 2022-06-24 23:57:29.629578
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # None value for module in method collect of class DateTimeFactCollector
    var_1 = date_time_fact_collector_0.collect()
    var_1_key_0 = 'date_time'
    assert var_1[var_1_key_0]['hour'] == str(datetime.datetime.utcfromtimestamp(time.time()).strftime('%H'))
    # None value for collected_facts in method collect of class DateTimeFactCollector
    var_2 = date_time_fact_collector_0.collect()
    var_2_key_0 = 'date_time'

# Generated at 2022-06-24 23:57:37.439963
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_2 = DateTimeFactCollector()
    var_2 = date_time_fact_collector_2.collect()
    assert var_2['date_time']['time']
    # Generated assertion for: date_time_fact_collector_2.collect()['date_time']['time']
    assert var_2['date_time']['weekday_number']
    # Generated assertion for: date_time_fact_collector_2.collect()['date_time']['weekday_number']
    assert var_2['date_time']['epoch']
    # Generated assertion for: date_time_fact_collector_2.collect()['date_time']['epoch']
    assert var_2['date_time']['tz_dst']


# Generated at 2022-06-24 23:57:45.625997
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0
    assert isinstance(var_0, dict)
    assert sorted(list(var_0.keys())) == [u'date_time']
    assert isinstance(var_0[u'date_time'], dict)

# Generated at 2022-06-24 23:57:49.198732
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:58:00.785246
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_0.collect()
    assert len(var_1) == 1
    assert var_1['date_time']['weekday'] == 'Tuesday'
    assert var_1['date_time']['day'] == '31'
    assert int(var_1['date_time']['weeknumber']) == 43
    assert var_1['date_time']['tz_offset'] == '-0400'
    assert var_1['date_time']['date'] == '2018-10-31'
    assert var_1['date_time']['year'] == '2018'
    assert var_1['date_time']['tz'] == 'EDT'
    assert var_1

# Generated at 2022-06-24 23:58:06.186989
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    if test_DateTimeFactCollector_collect.__name__ == 'main':
        test_case_0()

if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:58:15.121983
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_DateTimeFactCollector_collect = DateTimeFactCollector()
    var = test_case_DateTimeFactCollector_collect.collect()

# Generated at 2022-06-24 23:58:17.382644
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()  # None


# Generated at 2022-06-24 23:58:48.095100
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 23:58:50.738662
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()



# Generated at 2022-06-24 23:58:55.562088
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Need to define DateTimeFactCollector.
    if True:
        date_time_fact_collector = DateTimeFactCollector()
        var = date_time_fact_collector.collect()
        # Now, we try to access some properties of date_time.
        var.date_time.day
        var.date_time.iso8601
        var.date_time.iso8601_micro


# Generated at 2022-06-24 23:59:02.181136
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Test with valid arg.
    var_0 = date_time_fact_collector_0.collect()
    # Test with invalid arg.
    var_1 = date_time_fact_collector_0.collect(module=None)
    # Test with invalid arg.
    var_2 = date_time_fact_collector_0.collect(module='', collected_facts=None)



# Generated at 2022-06-24 23:59:13.100770
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:59:16.647601
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1 in (None, {})


# Generated at 2022-06-24 23:59:17.833681
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert callable(DateTimeFactCollector.collect)


# Generated at 2022-06-24 23:59:26.105205
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collection = date_time_fact_collector_0.collect()
    date_time_facts = collection['date_time']
    assert type(date_time_facts) is dict
    assert date_time_facts.has_key("year")
    assert type(date_time_facts['year']) is str
    assert date_time_facts.has_key("month")
    assert type(date_time_facts['month']) is str
    assert date_time_facts.has_key("weekday")
    assert type(date_time_facts['weekday']) is str
    assert date_time_facts.has_key("weekday_number")
    assert type(date_time_facts['weekday_number']) is str
    assert date_

# Generated at 2022-06-24 23:59:28.340497
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert var_1.keys() == ['date_time']
    assert var_1['date_time'] is not None



# Generated at 2022-06-24 23:59:38.635209
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    x = date_time_fact_collector_1
    var_1 = x.collect()
    if (var_1.get('date_time', {}).get('minute') == ''):
        var_1['date_time']['minute'] = '%M'
    if (var_1.get('date_time', {}).get('date') == ''):
        var_1['date_time']['date'] = '%Y-%m-%d'
    if (var_1.get('date_time', {}).get('weekday') == ''):
        var_1['date_time']['weekday'] = '%A'

# Generated at 2022-06-25 00:01:02.316010
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    cur_time = datetime.datetime.utcnow()
    named_tuple = time.localtime() # used for weekday and tz

# Generated at 2022-06-25 00:01:12.393875
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert var is not None
    assert 'date_time' in var
    assert 'year' in var['date_time']
    assert 'month' in var['date_time']
    assert 'weekday' in var['date_time']
    assert 'weekday_number' in var['date_time']
    assert 'weeknumber' in var['date_time']
    assert 'day' in var['date_time']
    assert 'hour' in var['date_time']
    assert 'minute' in var['date_time']
    assert 'second' in var['date_time']
    assert 'epoch' in var['date_time']

# Generated at 2022-06-25 00:01:18.584076
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test for module import error
    try:
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts.collector import DateTimeFactCollector
    except ImportError:
        DateTimeFactCollector = None

    if DateTimeFactCollector is not None:
        date_time_fact_collector_0 = DateTimeFactCollector()
        var_0 = date_time_fact_collector_0.collect()


# Generated at 2022-06-25 00:01:19.774190
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:01:24.863327
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = collected_facts_1 = dict()
    var_0 = date_time_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert var_0 == collected_facts_1


# Generated at 2022-06-25 00:01:28.687737
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time = date_time_fact_collector.collect()
    assert isinstance(date_time, dict)

# Generated at 2022-06-25 00:01:31.245632
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_1 = DateTimeFactCollector()
    var_1.collect()

# Generated at 2022-06-25 00:01:36.128767
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    try:
        var_0 = DateTimeFactCollector()
        try:
            var_0.collect()
        except Exception as var_1:
            print('Exception: {}'.format(repr(var_1)))
            assert False

        assert True
    except Exception as var_2:
        print('Exception: {}'.format(repr(var_2)))
        assert False

    assert True



# Generated at 2022-06-25 00:01:43.289109
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect() == date_time_fact_collector_1.collect()
    assert date_time_fact_collector_0.collect() is date_time_fact_collector_1.collect()
    date_time_fact_collector_0.collect()
    assert date_time_fact_collector_0.collect() is not date_time_fact_collector_1.collect()
    assert date_time_fact_collector_0.collect() != date_time_fact_collector_1.collect()
    assert date_time_fact_collector_0.collect() == date_time_fact_collector_

# Generated at 2022-06-25 00:01:52.252839
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()