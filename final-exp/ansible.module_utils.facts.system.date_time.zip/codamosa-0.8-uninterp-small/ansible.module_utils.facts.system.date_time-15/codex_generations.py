

# Generated at 2022-06-24 23:52:34.569521
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()

# Generated at 2022-06-24 23:52:43.672350
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:52:54.099207
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Case 0
    # run the collect function
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    # test the result is a type of dict
    assert (isinstance(result, dict)) == True
    # test result has a date_time key
    assert (result.has_key('date_time')) == True
    result_date_time = result['date_time']
    # test result_date_time has a type of dict and at least 15 keys
    assert (isinstance(result_date_time, dict)) == True
    assert (len(result_date_time) >= 15) == True
    assert (result_date_time.has_key('year')) == True

# Generated at 2022-06-24 23:52:55.503791
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:53:06.142905
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1_result = date_time_fact_collector_1.collect()
    assert '2017-07-19' == date_time_fact_collector_1_result['date_time']['date']
    assert '2017' == date_time_fact_collector_1_result['date_time']['year']
    assert '07' == date_time_fact_collector_1_result['date_time']['month']
    assert 'Wednesday' == date_time_fact_collector_1_result['date_time']['weekday']
    assert '3' == date_time_fact_collector_1_result['date_time']['weekday_number']

# Generated at 2022-06-24 23:53:17.923701
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d1 = DateTimeFactCollector()
    result = d1.collect()
    assert isinstance(result, dict)
    assert 'date_time' in result
    assert isinstance(result['date_time']['date'], str)
    assert len(result['date_time']['date']) == 10
    assert result['date_time']['date'].count('-') == 2
    assert isinstance(result['date_time']['time'], str)
    assert len(result['date_time']['time']) == 8
    assert result['date_time']['time'].count(':') == 2
    assert result['date_time']['tz_dst'] in result['date_time']['tz']

# Generated at 2022-06-24 23:53:28.047256
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = {}
    returned_facts = date_time_fact_collector.collect(collected_facts=collected_facts)
    assert len(returned_facts['date_time']) == 19
    assert sorted(returned_facts['date_time'])[0] == 'date'
    assert sorted(returned_facts['date_time'])[1] == 'day'
    assert sorted(returned_facts['date_time'])[2] == 'epoch'
    assert sorted(returned_facts['date_time'])[3] == 'epoch_int'
    assert sorted(returned_facts['date_time'])[4] == 'hour'
    assert sorted(returned_facts['date_time'])[5]

# Generated at 2022-06-24 23:53:37.545607
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    ansible_collected_facts_0 = {}
    ansible_collected_facts_0['ansible_os_family'] = 'Debian'
    ansible_collected_facts_0['ansible_distribution'] = 'Ubuntu'
    ansible_collected_facts_0['ansible_distribution_version'] = '16.04'
    ansible_collected_facts_0['ansible_distribution_release'] = 'xenial'
    ansible_collected_facts_0['ansible_distribution_major_version'] = '16'
    ansible_collected_facts_0['ansible_os_name'] = 'Ubuntu'

# Generated at 2022-06-24 23:53:47.949216
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    d_collector_0 = DateTimeFactCollector()
    facts_dict_0 = d_collector_0.collect({})
    # Test expected values of attributes of facts_dict_0
    attr_value_0 = facts_dict_0.date_time.tz_dst
    attr_value_1 = facts_dict_0.date_time.epoch_int
    attr_value_2 = facts_dict_0.date_time.day
    attr_value_3 = facts_dict_0.date_time.tz
    attr_value_4 = facts_dict_0.date_time.month
    attr_value_5 = facts_dict_0.date_time.tz_offset
    attr_value_6 = facts_dict_0.date_time.time
    attr_

# Generated at 2022-06-24 23:53:56.704675
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    from ansible.module_utils.facts.collector.date_time import DateTimeFactCollector

    mocker, fact_collection_0 = create_mock_object(DateTimeFactCollector)
    empty_fact_collection = dict()

    mocker.patch.object(DateTimeFactCollector, 'collect')
    fact_collection_0.collect(collected_facts=empty_fact_collection)

    DateTimeFactCollector.collect.assert_called_with(fact_collection_0, collected_facts=empty_fact_collection)

# Generated at 2022-06-24 23:54:05.966763
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


if __name__ == "__main__":
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:09.216253
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:54:12.269197
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:54:23.834466
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    actual = date_time_fact_collector.collect()
    assert actual['date_time']['date'] == datetime.datetime.now().strftime('%Y-%m-%d')
    assert actual['date_time']['day'] == datetime.datetime.now().strftime('%d')
    assert actual['date_time']['epoch'] == datetime.datetime.now().strftime('%s')
    assert actual['date_time']['epoch_int'] == datetime.datetime.now().strftime('%s')
    assert actual['date_time']['hour'] == datetime.datetime.now().strftime('%H')
    assert actual['date_time']['iso8601'] == datetime

# Generated at 2022-06-24 23:54:26.189043
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    ansible___module_utils__facts__collector__date_time = date_time_fact_collector.collect()


# Generated at 2022-06-24 23:54:28.519756
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert 'date_time' in date_time_fact_collector_0.collect(collected_facts={})

# Generated at 2022-06-24 23:54:36.103022
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()


# Generated at 2022-06-24 23:54:45.947850
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    fd = date_time_fact_collector_1.collect()
    assert isinstance(fd, dict)
    assert fd.get('date_time')
    assert isinstance(fd.get('date_time'), dict)
    assert fd.get('date_time').get('year')
    assert fd.get('date_time').get('month')
    assert fd.get('date_time').get('weekday')
    assert fd.get('date_time').get('weekday_number')
    assert fd.get('date_time').get('weeknumber')
    assert fd.get('date_time').get('day')
    assert fd.get('date_time').get('hour')

# Generated at 2022-06-24 23:54:53.451406
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert(date_time_fact_collector_1.collect()['date_time']['year'] == datetime.datetime.now().strftime('%Y'))
    assert(date_time_fact_collector_1.collect()['date_time']['month'] == datetime.datetime.now().strftime('%m'))
    assert(date_time_fact_collector_1.collect()['date_time']['weekday'] == datetime.datetime.now().strftime('%A'))
    assert(date_time_fact_collector_1.collect()['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w'))

# Generated at 2022-06-24 23:55:04.948426
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    ansible_module_facts_0 = {}
    ansible_module_facts_0['ansible_date_time_timezone'] = "test_timezone"
    ansible_module_facts_0['ansible_date_time_timezone_dst'] = "test_timezone_dst"
    ansible_module_facts_0['ansible_date_time_timezone_offset'] = "test_timezone_offset"
    ansible_module_facts_0['ansible_date_time_formatted'] = "test_formatted"
    ansible_module_facts_0['ansible_date_time_iso8601'] = "test_iso8601"

# Generated at 2022-06-24 23:55:14.078274
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_case_0()
# end of test_DateTimeFactCollector_collect



# Generated at 2022-06-24 23:55:22.589209
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Create DateTimeFactCollector instance for testing
    date_time_fact_collector = DateTimeFactCollector()
    # Get timestamp in seconds
    epoch_ts = time.time()
    # Get datetime.datetime instance from timestamp
    now = datetime.datetime.fromtimestamp(epoch_ts)
    # Collect facts from DateTimeFactCollector instance
    collected_facts = date_time_fact_collector.collect()
    # Get date_time facts
    date_time_facts = collected_facts.get('date_time')
    assert date_time_facts['year'] == now.strftime('%Y')
    assert date_time_facts['month'] == now.strftime('%m')
    assert date_time_facts['weekday'] == now.strftime('%A')
    assert date_time_

# Generated at 2022-06-24 23:55:33.463886
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    assert date_time_fact_collector.collect()['date_time']['minute'] == datetime.datetime.now().strftime('%M')
    assert date_time_fact_collector.collect()['date_time']['epoch'] == datetime.datetime.now().strftime('%s')
    assert date_time_fact_collector.collect()['date_time']['tz'] == datetime.datetime.now().strftime("%Z")
    assert date_time_fact_collector.collect()['date_time']['tz_dst'] == time.tzname[1]

# Generated at 2022-06-24 23:55:44.319909
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_collect = date_time_fact_collector.collect()
    assert isinstance(date_time_fact_collector_collect, dict)
    assert 'date_time' in date_time_fact_collector_collect
    assert isinstance(date_time_fact_collector_collect['date_time'], dict)
    assert 'year' in date_time_fact_collector_collect['date_time']
    assert 'month' in date_time_fact_collector_collect['date_time']
    assert 'weekday' in date_time_fact_collector_collect['date_time']
    assert 'weekday_number' in date_time_fact_collector_collect['date_time']

# Generated at 2022-06-24 23:55:55.620063
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

    # TODO: mock dates to validate that the string formats are correct
    # If the date is mocked, we can also test that the date is correct
    date_time_facts = date_time_fact_collector.collect()
    assert 'date_time' in date_time_facts
    assert 'year' in date_time_facts['date_time']
    assert 'month' in date_time_facts['date_time']
    assert 'weekday' in date_time_facts['date_time']
    assert 'weekday_number' in date_time_facts['date_time']
    assert 'weeknumber' in date_time_facts['date_time']
    assert 'day' in date_time_facts['date_time']
    assert 'hour' in date_

# Generated at 2022-06-24 23:56:03.292867
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    ret = DateTimeFactCollector().collect()

    assert(type(ret) == dict)
    assert('date_time' in ret)
    assert('year' in ret['date_time'])
    assert('month' in ret['date_time'])
    assert('weekday' in ret['date_time'])
    assert('weekday_number' in ret['date_time'])
    assert('weeknumber' in ret['date_time'])
    assert('day' in ret['date_time'])
    assert('hour' in ret['date_time'])
    assert('minute' in ret['date_time'])
    assert('second' in ret['date_time'])
    assert('epoch' in ret['date_time'])
    assert('epoch_int' in ret['date_time'])

# Generated at 2022-06-24 23:56:14.594948
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_collect = date_time_fact_collector.collect()
    assert date_time_fact_collector_collect['date_time']['year'] == str(datetime.datetime.now().year)
    assert date_time_fact_collector_collect['date_time']['month'] == str(datetime.datetime.now().month)
    assert date_time_fact_collector_collect['date_time']['weekday'] == str(datetime.datetime.now().strftime("%A"))
    assert date_time_fact_collector_collect['date_time']['weekday_number'] == str(datetime.datetime.now().strftime("%w"))
    assert date_time_

# Generated at 2022-06-24 23:56:25.459634
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:56:27.816379
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Initialize class instance
    date_time_fact_collector = DateTimeFactCollector()

    # Call method collect on class instance
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:56:39.348781
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_dict_0 = date_time_fact_collector_0.collect()
    date_time_fact_dict_1 = date_time_fact_collector_0.collect()
    date_time_fact_dict_2 = date_time_fact_collector_0.collect()
    date_time_fact_dict_3 = date_time_fact_collector_0.collect()
    assert date_time_fact_dict_0.get('date_time') is not None
    assert date_time_fact_dict_1.get('date_time') is not None
    assert date_time_fact_dict_2.get('date_time') is not None

# Generated at 2022-06-24 23:57:03.080736
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()

# Generated at 2022-06-24 23:57:06.128396
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:57:07.693447
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    assert isinstance(dt.collect(), dict)

# Generated at 2022-06-24 23:57:10.333209
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print('\nTesting collect')
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:57:12.429825
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:57:14.911562
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert date_time_fact_collector_1.collect() != {}


# Generated at 2022-06-24 23:57:17.714851
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:57:24.462834
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setup test
    date_time_fact_collector = DateTimeFactCollector()
    ansible_module_args = dict()

    # exercise and assert
    results = date_time_fact_collector.collect(ansible_module_args)

    # Verify
    assert results['date_time']['year']
    assert results['date_time']['month']
    assert results['date_time']['weekday']
    assert results['date_time']['weekday_number']
    assert results['date_time']['weeknumber']
    assert results['date_time']['day']
    assert results['date_time']['hour']
    assert results['date_time']['minute']
    assert results['date_time']['second']

# Generated at 2022-06-24 23:57:27.494174
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    _date_time_fact_collector = DateTimeFactCollector()
    facts = _date_time_fact_collector.collect()
    assert(len(facts['date_time']) > 0)


# Generated at 2022-06-24 23:57:35.134532
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert(DateTimeFactCollector().collect()['date_time']['iso8601']).startswith("2017-")
    assert(DateTimeFactCollector().collect()['date_time']['iso8601']).endswith("Z")
    assert(DateTimeFactCollector().collect()['date_time']['iso8601_basic']).startswith("2017")
    assert(DateTimeFactCollector().collect()['date_time']['iso8601_basic_short']).startswith("2017")
    assert(DateTimeFactCollector().collect()['date_time']['weekday']).lower() == "saturday" or "sunday"
    assert(DateTimeFactCollector().collect()['date_time']['tz']).lower() == "mst" or "mdt"

# Generated at 2022-06-24 23:58:12.745763
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    result = DateTimeFactCollector().collect()
    assert result['date_time']['month']
    assert result['date_time']['date']
    assert result['date_time']['iso8601_basic']


# Generated at 2022-06-24 23:58:17.890955
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:58:26.935720
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:58:38.304882
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

# Generated at 2022-06-24 23:58:41.519521
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    assert bool(date_time_fact_collector_0._fact_ids)

# Generated at 2022-06-24 23:58:44.501629
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    for i in range(50):
        date_time_collector = DateTimeFactCollector()
        collected_facts = date_time_collector.collect()
        print(collected_facts)
        print(collected_facts.keys())
        assert 'date_time' in collected_facts.keys()


# Generated at 2022-06-24 23:58:54.367312
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # test cases
    date_time_fact_collector = DateTimeFactCollector()

    # Case 0: if date_time_facts exists in collection facts, date_time_facts will not be collected

# Generated at 2022-06-24 23:59:01.018583
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setting up test
    date_time_fact_collector = DateTimeFactCollector()
    # Test execution
    collected_facts = date_time_fact_collector.collect()
    # Asserting collected facts
    assert 'date_time' in collected_facts
    assert 'year' in collected_facts['date_time']
    assert 'month' in collected_facts['date_time']
    assert 'weekday' in collected_facts['date_time']
    assert 'weekday_number' in collected_facts['date_time']
    assert 'weeknumber' in collected_facts['date_time']
    assert 'day' in collected_facts['date_time']
    assert 'hour' in collected_facts['date_time']
    assert 'minute' in collected_facts['date_time']
    assert 'second' in collected_facts

# Generated at 2022-06-24 23:59:12.168154
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts = {}
    facts_dict = {}
    date_time_facts = {}
    # Store the timestamp once, then get local and UTC versions from that
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)

    date_time_facts['year'] = now.strftime('%Y')
    date_time_facts['month'] = now.strftime('%m')
    date_time_facts['weekday'] = now.strftime('%A')
    date_time_facts['weekday_number'] = now.strftime('%w')

# Generated at 2022-06-24 23:59:22.573959
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Given: the DateTimeFactCollector obj
    date_time_fact_collector = DateTimeFactCollector()
    # When: collect() is called
    collected_facts = date_time_fact_collector.collect()
    # Then: check if the dictionary returned has the correct keys
    correct_keys = set(['year', 'month', 'weekday', 'weekday_number', 'weeknumber',
                        'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int',
                        'date', 'time', 'iso8601_micro', 'iso8601', 'iso8601_basic',
                        'iso8601_basic_short', 'tz', 'tz_dst', 'tz_offset'])
    assert set(collected_facts['date_time'].keys()) == correct_keys

# Generated at 2022-06-25 00:00:47.361722
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-25 00:00:55.061134
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    res = date_time_fact_collector_1.collect(module=None, collected_facts=None)
    assert 'date_time' in res
    assert len(res) == 1
    assert 'year' in res.get('date_time')
    assert 'month' in res.get('date_time')
    assert 'weekday' in res.get('date_time')
    assert 'weekday_number' in res.get('date_time')
    assert 'weeknumber' in res.get('date_time')
    assert 'day' in res.get('date_time')
    assert 'hour' in res.get('date_time')
    assert 'minute' in res.get('date_time')
    assert 'second' in res.get

# Generated at 2022-06-25 00:01:03.925963
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert 'date_time' in date_time_facts, 'Facts about date and time are compiled'
    date_time_facts = date_time_facts['date_time']
    assert date_time_facts['iso8601_micro'][-1] == 'Z', 'ISO 8601 micro seconds ends in Z'
    assert date_time_facts['tz'] == time.strftime("%Z"), 'time zone is set to %Z'
    assert date_time_facts['tz_dst'] == time.tzname[1], 'time zone dst is set to time.tzname[1]'

# Generated at 2022-06-25 00:01:12.445523
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-25 00:01:22.120287
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # initialize
    date_time_fact_collector = DateTimeFactCollector()

    # execute
    result = date_time_fact_collector.collect()

    # assert

# Generated at 2022-06-25 00:01:26.444798
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = {}
    facts_dict = date_time_fact_collector_0.collect(collected_facts = None)
    assert facts_dict is not None


# Generated at 2022-06-25 00:01:31.356807
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    dict = date_time_fact_collector_1.collect()
    assert dict['date_time']['month'] == '09'
    assert dict['date_time']['weekday_number'] == '2'
    assert dict['date_time']['time'] == '11:50:11'

# Generated at 2022-06-25 00:01:34.691724
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert 'date_time' in result
    assert 'epoch_int' in result['date_time']

# Generated at 2022-06-25 00:01:40.320247
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()


# Generated at 2022-06-25 00:01:51.354349
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_1.collect()
    assert date_time_facts['date_time']['epoch'] == '1498556395'
    assert date_time_facts['date_time']['second'] == '55'
    assert date_time_facts['date_time']['date'] == '2017-06-25'
    assert date_time_facts['date_time']['tz_offset'] == '-0400'
    assert date_time_facts['date_time']['tz_dst'] == 'EDT'
    assert date_time_facts['date_time']['tz'] == 'EDT'