

# Generated at 2022-06-24 23:52:34.239115
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dt = DateTimeFactCollector()
    assert dt.collect() == {}

# Generated at 2022-06-24 23:52:43.494299
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:52:53.195980
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    def check_for_key(key):
        assert key in date_time_facts
        assert isinstance(date_time_facts[key], basestring)

    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()['date_time']

    for key in ('year', 'month', 'weekday', 'weekday_number', 'weeknumber',
                'day', 'hour', 'minute', 'second', 'epoch_int', 'epoch',
                'date', 'time', 'iso8601_micro', 'iso8601',
                'iso8601_basic', 'iso8601_basic_short', 'tz', 'tz_dst',
                'tz_offset'):
        yield check_for_key, key

# Generated at 2022-06-24 23:52:59.246328
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Input parameters initialization
    valid_module_object = None
    collected_facts = None

    # Date/time facts collection
    date_time_facts = DateTimeFactCollector().collect(valid_module_object, collected_facts)

    # Assertions
    assert date_time_facts is not None
    assert date_time_facts['date_time'] is not None
    assert date_time_facts['date_time']['year'] != ''
    assert date_time_facts['date_time']['month'] != ''
    assert date_time_facts['date_time']['weekday'] != ''
    assert date_time_facts['date_time']['weekday_number'] != ''
    assert date_time_facts['date_time']['weeknumber'] != ''

# Generated at 2022-06-24 23:53:03.164285
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time = date_time_fact_collector.collect()
    print(date_time)

# Generated at 2022-06-24 23:53:05.631457
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result is not None


# Generated at 2022-06-24 23:53:17.452669
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_2 = DateTimeFactCollector()
    date_time_fact_collector_3 = DateTimeFactCollector()
    date_time_fact_collector_4 = DateTimeFactCollector()
    date_time_fact_collector_5 = DateTimeFactCollector()
    date_time_fact_collector_6 = DateTimeFactCollector()
    date_time_fact_collector_7 = DateTimeFactCollector()
    date_time_fact_collector_8 = DateTimeFactCollector()
    date_time_fact_collector_9 = DateTimeFactCollector()
    date_time_fact_collector

# Generated at 2022-06-24 23:53:22.422430
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    facts_dict = {}
    res = date_time_fact_collector_0.collect(facts_dict)
    assert res['date_time'] != {}


# Generated at 2022-06-24 23:53:26.981925
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    assert type(date_time_fact_collector_1.collect()) is dict


# Generated at 2022-06-24 23:53:34.665574
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}
    facts_dict_0 = date_time_fact_collector_0.collect(collected_facts_0)
    assert facts_dict_0['date_time']['date'] == '2016-03-03'
    assert facts_dict_0['date_time']['day'] == '03'
    assert facts_dict_0['date_time']['epoch'].isdigit() is True
    assert facts_dict_0['date_time']['epoch_int'].isdigit() is True
    assert facts_dict_0['date_time']['hour'] == '19'

# Generated at 2022-06-24 23:53:48.756871
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:53:50.191193
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    data_time_fact_collector = DateTimeFactCollector()
    data_time_fact_collector.collect()

# Testing method collect using json and unittest.mock module

# Generated at 2022-06-24 23:54:00.729728
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts_dict = date_time_fact_collector.collect()
    assert (facts_dict['date_time']['year'] == datetime.datetime.utcnow().strftime('%Y'))
    assert (facts_dict['date_time']['month'] == datetime.datetime.utcnow().strftime('%m'))
    assert (facts_dict['date_time']['weekday'] == datetime.datetime.utcnow().strftime('%A'))
    assert (facts_dict['date_time']['weekday_number'] == datetime.datetime.utcnow().strftime('%w'))

# Generated at 2022-06-24 23:54:10.723295
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:54:18.218531
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector  = DateTimeFactCollector()
    date_time_fact_collector_collect = date_time_fact_collector.collect()

    assert len(date_time_fact_collector_collect) > 0
    assert date_time_fact_collector_collect[u"date_time"]["year"] == "2018"
    assert date_time_fact_collector_collect[u"date_time"]["day"] == "07"
    assert date_time_fact_collector_collect[u"date_time"]["month"] == "07"
    assert date_time_fact_collector_collect[u"date_time"]["hour"] == "07"
    assert date_time_fact_collector_collect[u"date_time"]["minute"] == "12"

# Generated at 2022-06-24 23:54:19.538018
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert False, "Test not implemented"

# Unit test class DateTimeFactCollector

# Generated at 2022-06-24 23:54:21.084398
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:54:23.019607
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:54:26.034116
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts_dict_1 = date_time_fact_collector_1.collect()
    assert isinstance(date_time_facts_dict_1, dict)


# Generated at 2022-06-24 23:54:34.424070
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    assert (DateTimeFactCollector().collect()['date_time']['time'] == time.strftime("%H:%M:%S"))
    assert (DateTimeFactCollector().collect()['date_time']['date'] == time.strftime("%Y-%m-%d"))
    assert (DateTimeFactCollector().collect()['date_time']['month'] == time.strftime("%m"))
    assert (DateTimeFactCollector().collect()['date_time']['year'] == time.strftime("%Y"))
    assert (DateTimeFactCollector().collect()['date_time']['day'] == time.strftime("%d"))
    assert (DateTimeFactCollector().collect()['date_time']['weekday'] == time.strftime("%A"))

# Generated at 2022-06-24 23:54:41.638583
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-24 23:54:48.829708
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    var_1 = date_time_fact_collector_0.name
    var_2 = date_time_fact_collector_0.collect()
    var_3 = date_time_fact_collector_0._fact_ids
    var_4 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:54:49.902428
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    test_0_DateTimeFactCollector_collect()


# Unit test main program

# Generated at 2022-06-24 23:54:53.607444
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_dict_0 = date_time_fact_collector_0.collect()
    assert date_time_dict_0['date_time']


# Generated at 2022-06-24 23:55:05.056841
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:16.698198
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_1 = set({'year', 'iso8601_micro', 'epoch', 'date', 'day', 'hour', 'second', 'weekday', 'time', 'month', 'epoch_int', 'minute', 'tz_dst', 'weekday_number', 'tz_offset', 'iso8601', 'iso8601_basic_short', 'iso8601_basic', 'tz', 'weeknumber'})
    date_time_fact_collector_0._fact_ids = var_1
    var_2 = date_time_fact_collector_0.collect()
    print(var_2.keys())
    print(date_time_fact_collector_0._fact_ids)
    print(var_2.keys())
    assert var

# Generated at 2022-06-24 23:55:23.403484
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Test the default output of DateTimeFactCollector.collect
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert (var_0['date_time']['date'] is not None)
    assert (var_0['date_time']['tz'] is not None)
    assert (var_0['date_time']['iso8601_micro'] is not None)
    assert (var_0['date_time']['iso8601'] is not None)
    assert (var_0['date_time']['epoch_int'] is not None)
    assert (var_0['date_time']['iso8601_basic'] is not None)

# Generated at 2022-06-24 23:55:26.278019
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

test_case_0()

# Generated at 2022-06-24 23:55:29.460227
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()
    assert var['date_time']['year']

# Generated at 2022-06-24 23:55:39.443526
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    time_now = time.time()
    time_now_utc = datetime.datetime.utcfromtimestamp(time_now).strftime('%Y-%m-%dT%H:%M:%SZ')
    date_time_fact_collector = DateTimeFactCollector()
    var_0 = date_time_fact_collector.collect()
    assert var_0['date_time']["iso8601"] == time_now_utc
    assert var_0['date_time']["epoch"] == str(int(time.time()))
    assert var_0['date_time']["epoch_int"] == str(int(time.time()))

if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect

# Generated at 2022-06-24 23:55:51.690300
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    args = []
    # The following call:
    #     test_case_0
    # should be replaced by the following call:
    #     create_module
    # once the 'create_module' function has been implemented.
    test_case_0()
    assert True # TODO: implement your test here


# Generated at 2022-06-24 23:55:54.226384
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:56:05.119476
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # collection_1 = DateTimeFactCollector()
    # result_1 = collection_1.collect()
    # Only check for return types
    assert isinstance(var_0, dict)
    # Check for return values
    assert 'date_time' in var_0
    for key in var_0['date_time'].keys():
        assert key in ['year', 'month', 'weekday', 'weekday_number', 'weeknumber', 'day', 'hour', 'minute', 'second', 'epoch', 'epoch_int', 'date', 'time', 'tz', 'tz_dst', 'tz_offset', 'iso8601', 'iso8601_basic', 'iso8601_basic_short', 'iso8601_micro']

# Generated at 2022-06-24 23:56:11.042656
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()

    assert isinstance(date_time_facts, dict)
    assert set(date_time_facts.keys()) == {'date_time'}

# Generated at 2022-06-24 23:56:16.626509
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Instantiate DateTimeFactCollector
    date_time_fact_collector = DateTimeFactCollector()
    var = date_time_fact_collector.collect()

    assert isinstance(var, dict)

# Generated at 2022-06-24 23:56:27.897634
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:30.638576
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:56:38.143769
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    print('Testing date_time.DateTimeFactCollector.collect')
    fixture_path = 'tests/fixtures/unit/ansible/module_utils/facts/collectors/date_time/DateTimeFactCollector.collect.json'
    with open(fixture_path) as fixture_file:
        expected_return = json.load(fixture_file)
        print(expected_return)

    test_case_0_instance_0 = DateTimeFactCollector()
    returned_value = test_case_0_instance_0.collect()
    print(returned_value)
    assert returned_value == expected_return

# Generated at 2022-06-24 23:56:40.774424
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 23:56:49.054646
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:57:05.201389
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    pass

# Generated at 2022-06-24 23:57:16.661133
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:57:18.530917
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()


# Generated at 2022-06-24 23:57:25.069734
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['time'] == "17:05:34"
    assert var_0['date_time']['epoch'] == "1526276734"
    assert var_0['date_time']['tz_dst'] == "BST"
    assert var_0['date_time']['tz'] == "BST"
    assert var_0['date_time']['epoch_int'] == "1526276734"
    assert var_0['date_time']['iso8601'] == "2018-05-12T16:05:34Z"

# Generated at 2022-06-24 23:57:33.613046
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}
    var_0 = date_time_fact_collector_0.collect(collected_facts=collected_facts_0)

# Generated at 2022-06-24 23:57:44.006998
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    this_class_0 = DateTimeFactCollector()
    var_0 = this_class_0.collect()

# Generated at 2022-06-24 23:57:48.907983
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Define a mock to replace the method 'collect' in the module 'ansible.module_utils.facts.collector'.
    # TODO: test the mock output
    pass

# Generated at 2022-06-24 23:57:50.396813
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:58:01.279049
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['time'] == time.strftime('%H:%M:%S')
    assert var_0['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert var_0['date_time']['weeknumber'] == datetime.datetime.now().strftime('%W')
    assert var_0['date_time']['iso8601'] == datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

# Generated at 2022-06-24 23:58:06.705973
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_2 = DateTimeFactCollector()
    date_time_fact_collector_3 = DateTimeFactCollector()
    assert date_time_fact_collector_2.collect() == date_time_fact_collector_3.collect()

# Generated at 2022-06-24 23:58:47.239447
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0["date_time"]["year"] == time.strftime("%Y")
    assert var_0["date_time"]["month"] == time.strftime("%m")
    assert var_0["date_time"]["weekday"] == time.strftime("%A")
    assert var_0["date_time"]["weekday_number"] == time.strftime("%w")
    assert var_0["date_time"]["weeknumber"] == time.strftime("%W")
    assert var_0["date_time"]["day"] == time.strftime("%d")

# Generated at 2022-06-24 23:58:56.412255
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert var_0['date_time']['tz_offset'] == time.strftime("%z")
    assert date_time_fact_collector_0.name == 'date_time'
    assert date_time_fact_collector_0._fact_ids == set()
    assert var_0['date_time']['iso8601_basic'] == time.strftime("%Y%m%dT%H%M%S%f")
    assert var_0['date_time']['weekday_number'] == time.strftime("%w")
    assert var_0['date_time']['minute'] == time.strftime("%M")

# Generated at 2022-06-24 23:59:07.370448
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert 'date_time' in var_1
    assert isinstance(var_1['date_time'], dict)
    assert 'year' in var_1['date_time']
    assert 'month' in var_1['date_time']
    assert 'weekday' in var_1['date_time']
    assert 'weekday_number' in var_1['date_time']
    assert 'weeknumber' in var_1['date_time']
    assert 'day' in var_1['date_time']
    assert 'hour' in var_1['date_time']

# Generated at 2022-06-24 23:59:11.888343
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

    assert 'date_time' in var_1
    assert 'year' in var_1['date_time']
    assert 'epoch_int' in var_1['date_time']



# Generated at 2022-06-24 23:59:18.678649
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:59:20.250817
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert 'date_time' in var_1

# Generated at 2022-06-24 23:59:27.027128
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_1 = DateTimeFactCollector()
    var_2 = var_1.collect()
    assert var_2.get('date_time')
    var_3 = var_2.get('date_time')
    assert var_3.get('day')
    assert var_3.get('epoch')
    assert var_3.get('epoch_int')
    assert var_3.get('hour')
    assert var_3.get('iso8601')
    assert var_3.get('iso8601_basic')
    assert var_3.get('iso8601_basic_short')
    assert var_3.get('iso8601_micro')
    assert var_3.get('minute')
    assert var_3.get('month')
    assert var_3.get('second')
    assert var_3

# Generated at 2022-06-24 23:59:28.908905
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Unit tests for class DateTimeFactCollector

# Generated at 2022-06-24 23:59:32.368592
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:59:39.898174
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    var_1 = DateTimeFactCollector()
    var_2 = var_1.collect()
    assert isinstance(var_2, dict)

# Generated at 2022-06-25 00:01:02.222547
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    data_time_fact_collector = DateTimeFactCollector()
    date_time_facts = data_time_fact_collector.collect()
    assert date_time_facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')

# Generated at 2022-06-25 00:01:07.357455
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()

# Generated at 2022-06-25 00:01:09.198368
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:01:16.033760
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Setup input arguments
    module = None
    collected_facts = None

    # Create instance of class DateTimeFactCollector
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Call method collect of class DateTimeFactCollector
    var_0 = date_time_fact_collector_0.collect()

    # Test whether the method completed successfully
    assert var_0 != None

# Generated at 2022-06-25 00:01:21.732625
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    assert 'date_time' in var_0

# Generated at 2022-06-25 00:01:25.518709
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-25 00:01:33.899607
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:45.911926
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    var_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-25 00:01:48.781410
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    var_1 = date_time_fact_collector_1.collect()
    assert var_1['date_time']['weekday'] == 'Monday'

# Generated at 2022-06-25 00:01:52.049029
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    symbol_map = DateTimeFactCollector._symbol_map
    assert symbol_map == {'SHIFT-JIS': 'cp932', 'SHIFT_JIS': 'cp932', 'eucJP': 'euc_jp', 'eucJP-ms': 'euc_jp_ms'}
