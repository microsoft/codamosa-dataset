

# Generated at 2022-06-24 23:52:40.624259
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:52:50.866137
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    ansible_facts = date_time_fact_collector_1.collect()
    date_time_fact_1 = ansible_facts.get('date_time')
    assert type(date_time_fact_1.get('year')) is str
    assert type(date_time_fact_1.get('month')) is str
    assert type(date_time_fact_1.get('weekday')) is str
    assert type(date_time_fact_1.get('weekday_number')) is str
    assert type(date_time_fact_1.get('weeknumber')) is str
    assert type(date_time_fact_1.get('day')) is str

# Generated at 2022-06-24 23:52:54.496759
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:52:56.851140
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Invoke method collect of DateTimeFactCollector
    assert('date_time' in date_time_fact_collector_0.collect())


# Generated at 2022-06-24 23:52:58.240579
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()

    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:53:08.511564
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    result = date_time_fact_collector_1.collect()
    assert isinstance(result, dict)
    assert 'date_time' in result.keys()
    assert isinstance(result['date_time'], dict)
    assert 'year' in result['date_time'].keys()
    assert isinstance(result['date_time']['year'], str)
    assert 'month' in result['date_time'].keys()
    assert isinstance(result['date_time']['month'], str)
    assert 'weekday' in result['date_time'].keys()
    assert isinstance(result['date_time']['weekday'], str)
    assert 'weekday_number' in result['date_time'].keys()

# Generated at 2022-06-24 23:53:17.669537
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()

# Generated at 2022-06-24 23:53:19.490554
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:53:22.784428
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Mock module and collected_facts
    test_DateTimeFactCollector_collect_0 = DateTimeFactCollector()
    assert isinstance(test_DateTimeFactCollector_collect_0.collect(), dict)

# Generated at 2022-06-24 23:53:31.400177
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result_dict = date_time_fact_collector_0.collect()
    # Make sure all the keys are in the result
    assert result_dict.keys() == set(['date_time'])
    result_dict_sub_dict = result_dict['date_time']
    required_keys = ['epoch','year','month','day','time']
    for key in required_keys:
        assert key in result_dict_sub_dict


if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:53:38.312706
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:53:39.261112
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    DateTimeFactCollector().collect()

# Generated at 2022-06-24 23:53:50.112098
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Call method collect and check result
    result = date_time_fact_collector_0.collect()
    assert result['date_time']['epoch_int'] == str(int(time.time()))
    assert result['date_time']['epoch'] == str(int(time.time()))
    assert result['date_time']['tz_offset'].endswith('00')
    assert result['date_time']['tz'] == 'UTC'
    assert result['date_time']['iso8601_basic'].endswith('00')
    assert result['date_time']['iso8601_micro'].endswith('00.000000')

# Generated at 2022-06-24 23:53:52.594311
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:53:57.264396
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_collect = DateTimeFactCollector()
    date_time_fact_collector_collect.collect()

# Generated at 2022-06-24 23:54:05.811691
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:54:15.219492
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['year'] == datetime.datetime.now().strftime('%Y')
    assert date_time_facts['date_time']['month'] == datetime.datetime.now().strftime('%m')
    assert date_time_facts['date_time']['weekday'] == datetime.datetime.now().strftime('%A')
    assert date_time_facts['date_time']['weekday_number'] == datetime.datetime.now().strftime('%w')

# Generated at 2022-06-24 23:54:18.626760
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect() is not None

if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:54:27.821470
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    dtfc = DateTimeFactCollector()
    _facts = dtfc.collect()

    assert isinstance(_facts.get('date_time'), dict) is True
    assert isinstance(_facts.get('date_time').get('year'), str) is True
    assert isinstance(_facts.get('date_time').get('month'), str) is True
    assert isinstance(_facts.get('date_time').get('weekday'), str) is True
    assert isinstance(_facts.get('date_time').get('weekday_number'), str) is True
    assert isinstance(_facts.get('date_time').get('weeknumber'), str) is True
    assert isinstance(_facts.get('date_time').get('day'), str) is True
    assert isinstance(_facts.get('date_time').get('hour'), str) is True

# Generated at 2022-06-24 23:54:35.624229
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    assert date_time_facts['date_time']['year']
    assert date_time_facts['date_time']['month']
    assert date_time_facts['date_time']['weekday']
    assert date_time_facts['date_time']['weekday_number']
    assert date_time_facts['date_time']['weeknumber']
    assert date_time_facts['date_time']['day']
    assert date_time_facts['date_time']['hour']
    assert date_time_facts['date_time']['minute']
    assert date_time_facts['date_time']['second']
    assert date_time

# Generated at 2022-06-24 23:54:45.380625
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 23:54:53.041164
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result['date_time']['year'] == '2017'
    assert result['date_time']['month'] == '08'
    assert result['date_time']['weekday'] == 'Friday'
    assert result['date_time']['weekday_number'] == '5'
    assert result['date_time']['weeknumber'] == '32'
    assert result['date_time']['day'] == '25'
    assert result['date_time']['hour'] == '11'
    assert result['date_time']['minute'] == '30'
    assert result['date_time']['second'] == '13'

# Generated at 2022-06-24 23:54:57.971947
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()
    date_time_facts = collected_facts.get('date_time')
    assert date_time_facts is not None, 'date_time_facts is None'
    assert len(date_time_facts) > 0, 'date_time_facts is empty'
    date = date_time_facts.get('date')
    assert date is not None, 'date is None'
    assert len(date) > 0, 'date is empty'
    time = date_time_facts.get('time')
    assert time is not None, 'time is None'
    assert len(time) > 0, 'time is empty'
    epoch = date_time_facts.get('epoch')

# Generated at 2022-06-24 23:55:01.408732
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Arrange

    # run the code to be tested
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

    # Act


# Generated at 2022-06-24 23:55:04.818336
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector.collect()
    print('date_time_facts=')
    print(date_time_facts)


# Generated at 2022-06-24 23:55:08.907148
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_0.collect()
    assert isinstance(date_time_facts, dict)

# Generated at 2022-06-24 23:55:12.341351
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    # Call method collect of date_time_fact_collector_0
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:55:16.422125
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_2 = DateTimeFactCollector()
    date_time_fact_collector_2.collect()
    # Returned dictionary is not empty
    assert len(date_time_fact_collector_2.collect()) > 0


# Generated at 2022-06-24 23:55:24.115502
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_instance = DateTimeFactCollector()
    result = date_time_fact_collector_instance.collect()
    assert isinstance(result, dict)
    assert 'date_time' in result
    date_time_facts = result['date_time']
    assert isinstance(date_time_facts, dict)
#    assert 'year' in date_time_facts
#    assert isinstance(date_time_facts['year'], str)
#    assert 'month' in date_time_facts
#    assert isinstance(date_time_facts['month'], str)
#    assert 'weekday' in date_time_facts
#    assert isinstance(date_time_facts['weekday'], str)
#    assert 'weekday_number' in date_time_facts
#    assert is

# Generated at 2022-06-24 23:55:26.856842
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    # Call method collect
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:55:48.064880
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    assert(date_time_fact_collector_0 is not None)

# Generated at 2022-06-24 23:55:54.749294
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()
    date_time_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:55:58.790610
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector_result = {}
    date_time_fact_collector_result = date_time_fact_collector.collect()
    print(date_time_fact_collector_result)
    assert date_time_fact_collector_result is not None


if __name__ == '__main__':
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:56:06.084793
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    date_time_fact_collector_1 = DateTimeFactCollector()

    # Create a mock 'dict' object and populate with some data

# Generated at 2022-06-24 23:56:08.146397
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    collected_facts_0 = {}
    date_time_fact_collector_0.collect(collected_facts=collected_facts_0)
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:19.818932
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

# Generated at 2022-06-24 23:56:23.154441
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    module_0 = None
    collected_facts_0 = None

    return_value_0 = date_time_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)


# Generated at 2022-06-24 23:56:24.800151
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:56:26.420457
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    assert date_time_fact_collector.collect() != None


# Generated at 2022-06-24 23:56:28.778233
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect()
    assert result['date_time']['weekday'] == 'Monday'

# Generated at 2022-06-24 23:57:10.799890
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()

    facts_dict = date_time_fact_collector_0.collect()

    # Check that the facts_dict is of the right type
    assert(isinstance(facts_dict, dict))

    # Check that the facts_dict is correct
    date_time_facts = facts_dict['date_time']
    assert(date_time_facts['hour']      == time.strftime('%H'))
    assert(date_time_facts['year']      == time.strftime('%Y'))
    assert(date_time_facts['minute']    == time.strftime('%M'))
    assert(date_time_facts['weekday']   == time.strftime('%A'))

# Generated at 2022-06-24 23:57:12.883738
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1.collect()


# Generated at 2022-06-24 23:57:21.753586
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()

# Generated at 2022-06-24 23:57:27.392895
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_fact_collector_1_result = date_time_fact_collector_1.collect()
    assert date_time_fact_collector_1_result['date_time']['tz_dst'] == 'CEST'

# Generated at 2022-06-24 23:57:29.593852
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    result_0 = date_time_fact_collector_0.collect()

# Generated at 2022-06-24 23:57:37.424473
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    epoch_ts = time.time()
    now = datetime.datetime.fromtimestamp(epoch_ts)
    utcnow = datetime.datetime.utcfromtimestamp(epoch_ts)
    test_facts = date_time_fact_collector_0.collect()
    assert test_facts['date_time']['year'] == now.strftime('%Y')
    assert test_facts['date_time']['month'] == now.strftime('%m')
    assert test_facts['date_time']['weekday'] == now.strftime('%A')
    assert test_facts['date_time']['weekday_number'] == now.strftime('%w')

# Generated at 2022-06-24 23:57:40.316712
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_fact_collector_0.collect()


# Generated at 2022-06-24 23:57:42.896185
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert date_time_fact_collector_0.collect()


if __name__ == '__main__':
    pass

# Generated at 2022-06-24 23:57:49.258454
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():

    # Initialize the object
    date_time_fact_collector = DateTimeFactCollector()

    # Call the method
    date_time_facts = date_time_fact_collector.collect()

    # Should return a dictionary
    assert isinstance(date_time_facts, dict)

    # Should contain the key 'date_time'
    assert 'date_time' in date_time_facts

    # Should contain the key 'iso8601_micro'
    assert 'iso8601_micro' in date_time_facts['date_time']

    # Should contain the key 'iso8601'
    assert 'iso8601' in date_time_facts['date_time']

    # Should contain the key 'epoch'
    assert 'epoch' in date_time_facts['date_time']

    # Should contain the key 'ep

# Generated at 2022-06-24 23:57:53.237166
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    date_time_fact_collector.collect()

# Generated at 2022-06-24 23:59:06.289718
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    collected_facts = date_time_fact_collector.collect()
    date_time_facts = collected_facts['date_time']
    # Check if year, month, day and hour are in collected_facts
    assert date_time_facts['year']
    assert date_time_facts['month']
    assert date_time_facts['day']
    assert date_time_facts['hour']


if __name__ == "__main__":
    test_case_0()
    test_DateTimeFactCollector_collect()

# Generated at 2022-06-24 23:59:09.241210
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    # Test for the 'date_time' fact.
    date_time_fact_collector = DateTimeFactCollector()
    assert len(date_time_fact_collector.collect()) == 1

# Generated at 2022-06-24 23:59:20.928861
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    facts = {'__fake_ansible_module': 'fake_ansible_module',
             '__fake_collected_facts': 'fake_collected_facts',
             }
    facts = date_time_fact_collector.collect(facts)
    assert facts
    assert facts['date_time']
    assert 'iso8601' in facts['date_time']
    assert 'iso8601_micro' in facts['date_time']
    assert 'iso8601_basic' in facts['date_time']
    assert 'iso8601_basic_short' in facts['date_time']
    assert 'tz' in facts['date_time']
    assert 'tz_dst' in facts['date_time']

# Generated at 2022-06-24 23:59:27.640229
# Unit test for method collect of class DateTimeFactCollector

# Generated at 2022-06-24 23:59:38.633631
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()
    date_time_facts_dict_1 = date_time_fact_collector_1.collect()
    assert not date_time_facts_dict_1 == None
    assert len(date_time_facts_dict_1) == 1
    assert type(date_time_facts_dict_1) is dict
    assert 'date_time' in date_time_facts_dict_1
    assert not date_time_facts_dict_1['date_time'] == None
    assert type(date_time_facts_dict_1['date_time']) is dict
    assert 'year' in date_time_facts_dict_1['date_time']
    assert not date_time_facts_dict_1['date_time']['year'] == None
   

# Generated at 2022-06-24 23:59:40.522862
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector = DateTimeFactCollector()
    result = date_time_fact_collector.collect()
    assert 'date_time' in result
    assert isinstance(result['date_time'], dict)


# Generated at 2022-06-24 23:59:44.499071
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_0 = DateTimeFactCollector()
    assert isinstance(date_time_fact_collector_0, DateTimeFactCollector)
    # No assertion error, then test passes
    assert True

# Generated at 2022-06-24 23:59:51.231212
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    now = datetime.datetime.fromtimestamp(time.time())
    utcnow = datetime.datetime.utcfromtimestamp(time.time())

    date_time_fact_collector_0 = DateTimeFactCollector()
    date_time_facts = date_time_fact_collector_0.collect()['date_time']

    assert date_time_facts['year'] == now.strftime('%Y')

    assert date_time_facts['month'] == now.strftime('%m')

    assert date_time_facts['weekday'] == now.strftime('%A')

    assert date_time_facts['weekday_number'] == now.strftime('%w')

    assert date_time_facts['weeknumber'] == now.strftime('%W')


# Generated at 2022-06-24 23:59:53.632403
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    expected_result = ['date_time']
    date_time_fact_collector_0 = DateTimeFactCollector()
    result = date_time_fact_collector_0.collect().keys()

    assert result == expected_result

# Generated at 2022-06-25 00:00:05.078840
# Unit test for method collect of class DateTimeFactCollector
def test_DateTimeFactCollector_collect():
    date_time_fact_collector_1 = DateTimeFactCollector()